"""LangChain integration — auto trust-score every chain/agent run.

Usage:
    from ainfera_sdk.langchain import AinferaTrustCallback

    cb = AinferaTrustCallback(api_key="your-key", agent_id="my-agent")
    chain.invoke(input, config={"callbacks": [cb]})

The callback records chain lifecycle events (start, tool calls, end/error) and
posts a lightweight trust event to the Ainfera API after each run. When
LangSmith tracing is active the resulting trust score is attached to the run's
metadata so it shows up in the LangSmith trace view.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any
from uuid import UUID

from .client import Ainfera

if TYPE_CHECKING:
    from .types import TrustScore

try:
    from langchain_core.callbacks import BaseCallbackHandler

    LANGCHAIN_AVAILABLE = True
except ImportError:  # pragma: no cover - exercised only when extra is missing
    LANGCHAIN_AVAILABLE = False

    class BaseCallbackHandler:  # type: ignore[no-redef]
        """Stub used when langchain-core is not installed."""


logger = logging.getLogger(__name__)


class AinferaTrustCallback(BaseCallbackHandler):
    """LangChain callback that records runs against the Ainfera trust API.

    Parameters
    ----------
    api_key:
        Ainfera API key. Falls back to ``AINFERA_API_KEY``.
    agent_id:
        Id of the agent to attach events to. Required so the server knows
        which agent's trust score to update.
    base_url:
        Optional override for the Ainfera API base URL.
    client:
        Optional pre-built ``Ainfera`` client (useful for tests / reuse).
    threshold:
        Optional minimum score. If set and the post-run score falls below it,
        a warning is logged. Hard-fail gating belongs in the CrewAI decorator;
        LangChain callbacks run in trace paths and should not raise.
    """

    raise_error: bool = False

    def __init__(
        self,
        api_key: str | None = None,
        *,
        agent_id: str | None = None,
        base_url: str | None = None,
        client: Ainfera | None = None,
        threshold: int | None = None,
    ) -> None:
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "langchain-core is not installed. Install with: "
                "pip install 'ainfera-sdk[langchain]'"
            )
        self.agent_id = agent_id
        self.threshold = threshold
        self._client = client or Ainfera(api_key=api_key, base_url=base_url)
        self._owns_client = client is None
        self._runs: dict[UUID, dict[str, Any]] = {}

    # --- lifecycle ---

    def on_chain_start(
        self,
        serialized: dict[str, Any] | None,
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        **_: Any,
    ) -> None:
        name = None
        if isinstance(serialized, dict):
            name = serialized.get("name") or (serialized.get("id") or [None])[-1]
        self._runs[run_id] = {
            "chain": name,
            "start": time.monotonic(),
            "tools": [],
            "errors": [],
        }

    def on_tool_start(
        self,
        serialized: dict[str, Any] | None,
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **_: Any,
    ) -> None:
        tool_name = None
        if isinstance(serialized, dict):
            tool_name = serialized.get("name") or (serialized.get("id") or [None])[-1]
        target = self._runs.get(parent_run_id) if parent_run_id else None
        if target is not None:
            target["tools"].append(tool_name)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **_: Any,
    ) -> None:
        record = self._runs.pop(run_id, None)
        if record is None:
            return
        self._record_event(
            event_type="langchain.chain_error",
            duration_ms=self._duration_ms(record),
            tools=record["tools"],
            error=f"{type(error).__name__}: {error}",
        )

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        record = self._runs.pop(run_id, None)
        if record is None:
            return
        score = self._record_event(
            event_type="langchain.chain_end",
            duration_ms=self._duration_ms(record),
            tools=record["tools"],
        )
        if score is None:
            return
        # Best-effort: attach to LangSmith run metadata via the tracer if present.
        self._attach_metadata(kwargs, score)
        if self.threshold is not None and score.overall_score < self.threshold:
            logger.warning(
                "Ainfera trust score %.0f below threshold %s for agent %s",
                score.overall_score,
                self.threshold,
                self.agent_id,
            )

    # --- helpers ---

    @staticmethod
    def _duration_ms(record: dict[str, Any]) -> int:
        return int((time.monotonic() - record["start"]) * 1000)

    def _record_event(self, **data: Any) -> TrustScore | None:
        if self.agent_id is None:
            return None
        try:
            self._client.trust.record_event(
                self.agent_id,
                event_type=str(data.pop("event_type")),
                data=data,
            )
            return self._client.get_trust_score(self.agent_id)
        except Exception as exc:  # pragma: no cover - network best-effort
            logger.debug("Ainfera trust event failed: %s", exc)
            return None

    def _attach_metadata(self, kwargs: dict[str, Any], score: TrustScore) -> None:
        tags = kwargs.get("tags")
        if isinstance(tags, list):
            tags.append(f"ainfera:trust:{score.grade}:{int(score.overall_score)}")

    def close(self) -> None:
        if self._owns_client:
            self._client.close()


__all__ = ["AinferaTrustCallback", "LANGCHAIN_AVAILABLE"]
