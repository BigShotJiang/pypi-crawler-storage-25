"""Billing resource — account overview and usage."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .types import BillingOverview, UsageRecord

if TYPE_CHECKING:
    from .client import _AsyncHttp, _SyncHttp


class BillingResource:
    """Synchronous billing API."""

    def __init__(self, http: _SyncHttp) -> None:
        self._http = http

    def overview(self) -> BillingOverview:
        """Return current-period billing overview for the authenticated account."""
        return BillingOverview.model_validate(self._http.get("/v1/billing/overview"))

    def usage(
        self,
        *,
        start: str | None = None,
        end: str | None = None,
        agent_id: str | None = None,
    ) -> list[UsageRecord]:
        """Return metered usage records, optionally filtered by date or agent."""
        params: dict[str, str] = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        if agent_id:
            params["agent_id"] = agent_id
        data = self._http.get("/v1/billing/usage", params=params)
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [UsageRecord.model_validate(u) for u in items]


class AsyncBillingResource:
    """Asynchronous billing API."""

    def __init__(self, http: _AsyncHttp) -> None:
        self._http = http

    async def overview(self) -> BillingOverview:
        return BillingOverview.model_validate(await self._http.get("/v1/billing/overview"))

    async def usage(
        self,
        *,
        start: str | None = None,
        end: str | None = None,
        agent_id: str | None = None,
    ) -> list[UsageRecord]:
        params: dict[str, str] = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        if agent_id:
            params["agent_id"] = agent_id
        data = await self._http.get("/v1/billing/usage", params=params)
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [UsageRecord.model_validate(u) for u in items]


__all__ = ["AsyncBillingResource", "BillingResource"]
