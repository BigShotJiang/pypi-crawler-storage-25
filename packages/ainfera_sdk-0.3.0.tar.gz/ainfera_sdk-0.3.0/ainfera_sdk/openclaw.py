"""OpenClaw helpers — skill scanning, agent registration, and discovery.

Usage:
    from ainfera_sdk.openclaw import OpenClawTrust

    trust = OpenClawTrust(api_key="your-key")
    result = trust.scan_skill("github-manager")
    print(f"{result.grade} {int(result.overall_score)}")

    agent = trust.register_agent(name="my-bot", description="...")
    agents = trust.discover("research assistant", min_trust=800)
"""

from __future__ import annotations

from typing import Any

from .client import Ainfera
from .types import PublicAgent, TrustScore


class OpenClawTrust:
    """Convenience wrapper around the trust + registry resources.

    ``OpenClawTrust`` is a thin facade over :class:`Ainfera` that groups the
    three calls most commonly used in OpenClaw integrations: scan a skill,
    register an agent, and discover agents by query.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        client: Ainfera | None = None,
    ) -> None:
        self._client = client or Ainfera(api_key=api_key, base_url=base_url)
        self._owns_client = client is None

    def scan_skill(self, skill_id: str) -> TrustScore:
        """Run a NeMo Guardrails safety/quality evaluation for a skill."""
        return self._client.trust.evaluate(skill_id)

    def register_agent(
        self,
        *,
        name: str,
        description: str | None = None,
        framework: str = "openclaw",
        **extra: Any,
    ) -> PublicAgent:
        """Register an agent in the Ainfera public registry."""
        config: dict[str, Any] = {"name": name, "framework": framework, **extra}
        if description is not None:
            config["description"] = description
        return self._client.register_agent(config)

    def discover(
        self,
        query: str,
        *,
        min_trust: int | None = None,
        trust_grade: str | None = None,
        framework: str | None = None,
        limit: int = 20,
    ) -> list[PublicAgent]:
        """Semantic search of the public agent registry."""
        return self._client.search_agents(
            query,
            framework=framework,
            min_trust=min_trust,
            trust_grade=trust_grade,
            limit=limit,
        )

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> OpenClawTrust:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


__all__ = ["OpenClawTrust"]
