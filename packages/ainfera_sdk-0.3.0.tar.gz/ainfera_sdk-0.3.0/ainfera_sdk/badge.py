"""Embeddable trust badge URLs and snippets."""

from __future__ import annotations

_DEFAULT_BASE = "https://api.ainfera.ai"
_BADGE_SCRIPT = "https://badge.ainfera.ai/v1.js"
_PUBLIC_PAGE = "https://ainfera.ai/trust"


class TrustBadge:
    """Generate embeddable trust badge URLs and HTML/Markdown snippets.

    The badge is a public, server-rendered SVG that reflects the agent's
    current trust score (grade + score on a 0-1000 scale).
    """

    @staticmethod
    def url(agent_id: str, size: str = "md", *, base_url: str = _DEFAULT_BASE) -> str:
        """Return the URL of the JSON badge endpoint."""
        return f"{base_url.rstrip('/')}/v1/public/trust/{agent_id}/badge?size={size}"

    @staticmethod
    def svg_url(agent_id: str, *, base_url: str = _DEFAULT_BASE) -> str:
        """Return the URL of the SVG badge image."""
        return f"{base_url.rstrip('/')}/v1/public/trust/{agent_id}/badge.svg"

    @staticmethod
    def html_snippet(agent_id: str, size: str = "md") -> str:
        """Return an HTML snippet that renders the live badge."""
        return (
            f'<script src="{_BADGE_SCRIPT}"></script>\n'
            f'<div data-ainfera-trust="{agent_id}" data-size="{size}"></div>'
        )

    @staticmethod
    def markdown_badge(agent_id: str, *, base_url: str = _DEFAULT_BASE) -> str:
        """Return a Markdown badge suitable for READMEs."""
        svg = TrustBadge.svg_url(agent_id, base_url=base_url)
        return f"[![Ainfera Trust]({svg})]({_PUBLIC_PAGE}/{agent_id})"


__all__ = ["TrustBadge"]
