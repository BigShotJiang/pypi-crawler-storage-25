"""Ainfera Python SDK — trust scoring and agent discovery for the AI agent economy.

Powered by NVIDIA NIM inference and NeMo Guardrails safety evaluation.
"""

from __future__ import annotations

__version__ = "0.3.0"

from .badge import TrustBadge
from .client import Ainfera, AinferaClient, AsyncAinfera
from .exceptions import (
    AinferaError,
    ApiError,
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .openclaw import OpenClawTrust
from .types import (
    Agent,
    Anomaly,
    BillingOverview,
    ExecutionRun,
    PublicAgent,
    RegistryStats,
    TrustCheckResult,
    TrustDimensions,
    TrustEvent,
    TrustGrade,
    TrustHistoryEntry,
    TrustScore,
    UsageRecord,
)

# Framework-specific integrations — require optional dependencies.
try:  # pragma: no cover - import-time branch
    from .langchain import AinferaTrustCallback
except ImportError:  # pragma: no cover
    AinferaTrustCallback = None  # type: ignore[assignment,misc]

try:  # pragma: no cover
    from .crewai import TrustGateError, ainfera_trust
except ImportError:  # pragma: no cover
    ainfera_trust = None  # type: ignore[assignment]
    TrustGateError = None  # type: ignore[assignment,misc]

__all__ = [
    "Agent",
    "Ainfera",
    "AinferaClient",
    "AinferaError",
    "AinferaTrustCallback",
    "Anomaly",
    "ApiError",
    "AsyncAinfera",
    "AuthError",
    "BillingOverview",
    "ExecutionRun",
    "NotFoundError",
    "OpenClawTrust",
    "PublicAgent",
    "RateLimitError",
    "RegistryStats",
    "ServerError",
    "TrustBadge",
    "TrustCheckResult",
    "TrustDimensions",
    "TrustEvent",
    "TrustGateError",
    "TrustGrade",
    "TrustHistoryEntry",
    "TrustScore",
    "UsageRecord",
    "ValidationError",
    "__version__",
    "ainfera_trust",
]
