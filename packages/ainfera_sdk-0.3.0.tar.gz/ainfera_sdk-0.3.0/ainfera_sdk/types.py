"""Pydantic v2 response models for the Ainfera API."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict


class _Model(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")


class TrustGrade(str, Enum):
    """Letter grade bucket for a composite trust score (0-1000)."""

    AAA = "AAA"  # 900-1000
    AA = "AA"  # 800-899
    A = "A"  # 700-799
    BBB = "BBB"  # 600-699
    BB = "BB"  # 500-599
    B = "B"  # 400-499
    CCC = "CCC"  # 0-399

    @classmethod
    def from_score(cls, score: int) -> TrustGrade:
        if score >= 900:
            return cls.AAA
        if score >= 800:
            return cls.AA
        if score >= 700:
            return cls.A
        if score >= 600:
            return cls.BBB
        if score >= 500:
            return cls.BB
        if score >= 400:
            return cls.B
        return cls.CCC


class TrustDimensions(_Model):
    """Five dimensions that compose the trust score (each 0-1).

    Safety is evaluated server-side via NVIDIA NeMo Guardrails.
    """

    safety: float
    reliability: float
    quality: float
    performance: float
    reputation: float


class TrustCheckResult(_Model):
    """Result of a CI/CD trust check comparing two commits."""

    score_before: int
    score_after: int
    diff: int
    dimensions_diff: dict[str, float]
    passed: bool
    threshold: int
    comment_markdown: str


class Agent(_Model):
    """A deployed AI agent."""

    id: str
    name: str
    description: str | None = None
    framework: str
    compute_tier: str
    status: str
    owner_id: str | None = None
    endpoint_url: str | None = None
    created_at: datetime
    updated_at: datetime


class TrustScore(_Model):
    """Composite trust score for an agent."""

    agent_id: str
    overall_score: float
    grade: str
    dimensions: dict[str, float]
    computed_at: datetime


class TrustHistoryEntry(_Model):
    """A point-in-time trust score."""

    agent_id: str
    overall_score: float
    grade: str
    recorded_at: datetime


class Anomaly(_Model):
    """A detected behavioral anomaly."""

    id: str
    agent_id: str
    anomaly_type: str
    severity: str
    description: str
    detected_at: datetime


class TrustEvent(_Model):
    """A trust-relevant event recorded against an agent."""

    id: str
    agent_id: str
    event_type: str
    data: dict[str, Any]
    recorded_at: datetime


class PublicAgent(_Model):
    """A publicly discoverable agent in the registry."""

    id: str
    name: str
    description: str | None = None
    framework: str
    trust_score: float | None = None
    grade: str | None = None
    published_at: datetime


class RegistryStats(_Model):
    """Aggregate statistics for the public registry."""

    total_agents: int
    total_frameworks: int
    average_trust_score: float
    updated_at: datetime


class UsageRecord(_Model):
    """A single usage/metering record."""

    period_start: datetime
    period_end: datetime
    agent_id: str | None = None
    metric: str
    quantity: float
    unit: str


class BillingOverview(_Model):
    """Current billing state for the authenticated account."""

    account_id: str
    plan: str
    current_period_start: datetime
    current_period_end: datetime
    amount_due_cents: int
    currency: str
    usage: list[UsageRecord]


class ExecutionRun(_Model):
    """A single execution of an agent."""

    id: str
    agent_id: str
    status: str
    input: dict[str, Any] | None = None
    output: dict[str, Any] | None = None
    started_at: datetime
    finished_at: datetime | None = None


__all__ = [
    "Agent",
    "Anomaly",
    "BillingOverview",
    "ExecutionRun",
    "PublicAgent",
    "RegistryStats",
    "TrustCheckResult",
    "TrustDimensions",
    "TrustEvent",
    "TrustGrade",
    "TrustHistoryEntry",
    "TrustScore",
    "UsageRecord",
]
