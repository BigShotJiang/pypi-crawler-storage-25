"""Top-level sync and async clients for the Ainfera API."""

from __future__ import annotations

import os
from types import TracebackType
from typing import Any

import httpx

from . import __version__
from .agents import AgentsResource, AsyncAgentsResource
from .badge import TrustBadge
from .billing import AsyncBillingResource, BillingResource
from .exceptions import AinferaError, raise_for_status
from .execution import AsyncExecutionResource, ExecutionResource
from .registry import AsyncRegistryResource, RegistryResource
from .trust import AsyncTrustResource, TrustResource
from .types import (
    PublicAgent,
    TrustCheckResult,
    TrustHistoryEntry,
    TrustScore,
)

DEFAULT_BASE_URL = "https://api.ainfera.ai"
DEFAULT_TIMEOUT = 30.0
USER_AGENT = f"ainfera-sdk-python/{__version__}"


def _resolve_base_url(base_url: str | None) -> str:
    return base_url or os.environ.get("AINFERA_API_URL", DEFAULT_BASE_URL)


def _resolve_api_key(api_key: str | None) -> str | None:
    return api_key if api_key is not None else os.environ.get("AINFERA_API_KEY")


def _headers(api_key: str | None) -> dict[str, str]:
    headers: dict[str, str] = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
    }
    if api_key:
        headers["X-Ainfera-Key"] = api_key
    return headers


def _handle_response(response: httpx.Response) -> Any:
    """Parse a response or raise a typed exception."""
    if response.is_success:
        if response.status_code == 204 or not response.content:
            return None
        ctype = response.headers.get("content-type", "")
        if "application/json" in ctype:
            return response.json()
        return response.text

    body: Any = None
    try:
        body = response.json()
    except ValueError:
        body = response.text

    message = response.reason_phrase or f"HTTP {response.status_code}"
    if isinstance(body, dict):
        message = str(body.get("message") or body.get("error") or message)
    raise_for_status(response.status_code, message, body)


class _SyncHttp:
    """Thin wrapper around httpx.Client for resource classes."""

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        return _handle_response(self._client.get(path, params=params))

    def post(
        self,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        return _handle_response(self._client.post(path, json=json, params=params))

    def patch(self, path: str, *, json: Any = None) -> Any:
        return _handle_response(self._client.patch(path, json=json))

    def delete(self, path: str) -> Any:
        return _handle_response(self._client.delete(path))


class _AsyncHttp:
    """Thin wrapper around httpx.AsyncClient for async resource classes."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client

    async def get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        return _handle_response(await self._client.get(path, params=params))

    async def post(
        self,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        return _handle_response(await self._client.post(path, json=json, params=params))

    async def patch(self, path: str, *, json: Any = None) -> Any:
        return _handle_response(await self._client.patch(path, json=json))

    async def delete(self, path: str) -> Any:
        return _handle_response(await self._client.delete(path))


class Ainfera:
    """Ainfera API client for trust scoring and agent discovery.

    Powered by NVIDIA NIM inference and NeMo Guardrails safety evaluation.

    Example:
        >>> client = Ainfera(api_key="ainf_sk_live_...")
        >>> score = client.get_trust_score("research-agent")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: httpx.Client | None = None,
    ) -> None:
        resolved_key = _resolve_api_key(api_key)
        resolved_url = _resolve_base_url(base_url)
        self._owns_client = http_client is None
        self._http_client = http_client or httpx.Client(
            base_url=resolved_url,
            headers=_headers(resolved_key),
            timeout=timeout,
        )
        self.api_key = resolved_key
        self.base_url = resolved_url

        http = _SyncHttp(self._http_client)
        self.agents = AgentsResource(http)
        self.trust = TrustResource(http)
        self.billing = BillingResource(http)
        self.execution = ExecutionResource(http)
        self.registry = RegistryResource(http)

    # --- Flat trust & discovery convenience methods ---

    def get_trust_score(self, agent_id: str) -> TrustScore:
        """Return the current composite trust score for an agent."""
        return self.trust.get_score(agent_id)

    def get_trust_history(
        self, agent_id: str, days: int = 30
    ) -> list[TrustHistoryEntry]:
        """Return trust score history. `days` is a server-side filter hint."""
        del days  # forwarded by server once supported
        return self.trust.get_history(agent_id)

    def evaluate_trust(self, agent_id: str) -> TrustScore:
        """Trigger a server-side NeMo Guardrails safety evaluation."""
        return self.trust.evaluate(agent_id)

    def search_agents(
        self,
        query: str,
        *,
        framework: str | None = None,
        min_trust: int | None = None,
        trust_grade: str | None = None,
        limit: int = 20,
    ) -> list[PublicAgent]:
        """Semantic search of the public agent marketplace (NIM embeddings)."""
        return self.registry.search(
            q=query,
            framework=framework,
            min_trust=min_trust,
            trust_grade=trust_grade,
            limit=limit,
        )

    def get_agent(self, agent_id: str) -> PublicAgent:
        """Fetch a publicly listed agent."""
        return self.registry.get(agent_id)

    def publish_agent(self, agent_id: str) -> PublicAgent:
        """Publish an owned agent to the discovery marketplace."""
        return self.registry.publish(agent_id)

    def register_agent(self, config: dict[str, Any]) -> PublicAgent:
        """Register an agent from an `ainfera.yaml`-style config dict."""
        return self.registry.register(config)

    def get_badge_url(self, agent_id: str, size: str = "md") -> str:
        """Return the public JSON badge URL (for dynamic rendering)."""
        return TrustBadge.url(agent_id, size, base_url=self.base_url)

    def get_badge_svg(self, agent_id: str) -> str:
        """Return the public SVG badge URL."""
        return TrustBadge.svg_url(agent_id, base_url=self.base_url)

    def trust_check(
        self,
        agent_id: str,
        *,
        commit_sha: str,
        base_sha: str | None = None,
    ) -> TrustCheckResult:
        """Run a CI/CD trust check for a commit (formats a PR-ready comment)."""
        return self.trust.check(agent_id, commit_sha=commit_sha, base_sha=base_sha)

    def close(self) -> None:
        if self._owns_client:
            self._http_client.close()

    def __enter__(self) -> Ainfera:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()


class AsyncAinfera:
    """Asynchronous client for the Ainfera API.

    Example:
        >>> async with AsyncAinfera(api_key="ainf_sk_live_...") as client:
        ...     agents = await client.agents.list()
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        resolved_key = _resolve_api_key(api_key)
        resolved_url = _resolve_base_url(base_url)
        self._owns_client = http_client is None
        self._http_client = http_client or httpx.AsyncClient(
            base_url=resolved_url,
            headers=_headers(resolved_key),
            timeout=timeout,
        )
        self.api_key = resolved_key
        self.base_url = resolved_url

        http = _AsyncHttp(self._http_client)
        self.agents = AsyncAgentsResource(http)
        self.trust = AsyncTrustResource(http)
        self.billing = AsyncBillingResource(http)
        self.execution = AsyncExecutionResource(http)
        self.registry = AsyncRegistryResource(http)

    async def aclose(self) -> None:
        if self._owns_client:
            await self._http_client.aclose()

    async def __aenter__(self) -> AsyncAinfera:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()


# Alias for the forward-looking name used in the 0.2.x docs & examples.
AinferaClient = Ainfera


__all__ = ["AinferaClient", "AinferaError", "Ainfera", "AsyncAinfera"]
