"""Tests for the TrustBadge helper."""

from __future__ import annotations

from ainfera_sdk import TrustBadge


def test_svg_url() -> None:
    url = TrustBadge.svg_url("ag_1")
    assert url == "https://api.ainfera.ai/v1/public/trust/ag_1/badge.svg"


def test_url_includes_size() -> None:
    assert "size=sm" in TrustBadge.url("ag_1", size="sm")


def test_url_respects_base_url() -> None:
    url = TrustBadge.svg_url("ag_1", base_url="https://staging.ainfera.ai/")
    assert url.startswith("https://staging.ainfera.ai/")


def test_markdown_badge_links_to_public_page() -> None:
    md = TrustBadge.markdown_badge("ag_1")
    assert "![Ainfera Trust]" in md
    assert "https://ainfera.ai/trust/ag_1" in md
    assert "/badge.svg" in md


def test_html_snippet_uses_data_attributes() -> None:
    html = TrustBadge.html_snippet("ag_1", size="lg")
    assert 'data-ainfera-trust="ag_1"' in html
    assert 'data-size="lg"' in html
    assert "badge.ainfera.ai/v1.js" in html
