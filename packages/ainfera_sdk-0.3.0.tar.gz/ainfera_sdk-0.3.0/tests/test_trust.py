"""Tests for the trust resource."""

from __future__ import annotations

from pytest_httpx import HTTPXMock

from ainfera_sdk import Ainfera, AsyncAinfera, TrustScore

BASE_URL = "https://api.test.ainfera.ai"


SCORE = {
    "agent_id": "ag_1",
    "overall_score": 92.5,
    "grade": "A",
    "dimensions": {"reliability": 95.0, "safety": 90.0},
    "computed_at": "2026-04-13T00:00:00Z",
}


def test_get_score(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(url=f"{BASE_URL}/v1/trust/ag_1/score", json=SCORE)
    client = Ainfera(api_key="x", base_url=BASE_URL)
    score = client.trust.get_score("ag_1")
    assert isinstance(score, TrustScore)
    assert score.overall_score == 92.5
    assert score.grade == "A"
    assert score.dimensions["reliability"] == 95.0


def test_get_history(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/trust/ag_1/history",
        json={
            "items": [
                {
                    "agent_id": "ag_1",
                    "overall_score": 90.0,
                    "grade": "A",
                    "recorded_at": "2026-04-12T00:00:00Z",
                }
            ]
        },
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    history = client.trust.get_history("ag_1")
    assert len(history) == 1
    assert history[0].overall_score == 90.0


def test_get_anomalies(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/trust/ag_1/anomalies",
        json={
            "items": [
                {
                    "id": "an_1",
                    "agent_id": "ag_1",
                    "anomaly_type": "latency_spike",
                    "severity": "medium",
                    "description": "p99 latency doubled",
                    "detected_at": "2026-04-13T00:00:00Z",
                }
            ]
        },
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    anomalies = client.trust.get_anomalies("ag_1")
    assert len(anomalies) == 1
    assert anomalies[0].anomaly_type == "latency_spike"


def test_record_event(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/trust/ag_1/events",
        method="POST",
        json={
            "id": "ev_1",
            "agent_id": "ag_1",
            "event_type": "hallucination",
            "data": {"confidence": 0.8},
            "recorded_at": "2026-04-13T00:00:00Z",
        },
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    event = client.trust.record_event("ag_1", event_type="hallucination", data={"confidence": 0.8})
    assert event.event_type == "hallucination"


def test_recompute(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/trust/ag_1/recompute",
        method="POST",
        json=SCORE,
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    score = client.trust.recompute("ag_1")
    assert score.grade == "A"


def test_badge_url() -> None:
    client = Ainfera(api_key="x", base_url=BASE_URL)
    assert client.trust.badge_url("ag_1") == f"{BASE_URL}/v1/trust/ag_1/badge.svg"


async def test_async_get_score(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(url=f"{BASE_URL}/v1/trust/ag_1/score", json=SCORE)
    async with AsyncAinfera(api_key="x", base_url=BASE_URL) as client:
        score = await client.trust.get_score("ag_1")
    assert score.overall_score == 92.5
