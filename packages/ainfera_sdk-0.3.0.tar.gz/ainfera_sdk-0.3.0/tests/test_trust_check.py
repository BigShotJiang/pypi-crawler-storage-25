"""Tests for the trust_check / evaluate endpoints and AinferaClient flat API."""

from __future__ import annotations

from pytest_httpx import HTTPXMock

from ainfera_sdk import AinferaClient, TrustCheckResult, TrustGrade

BASE_URL = "https://api.test.ainfera.ai"

CHECK_RESPONSE = {
    "score_before": 820,
    "score_after": 780,
    "diff": -40,
    "dimensions_diff": {"safety": -0.05, "reliability": 0.0},
    "passed": False,
    "threshold": 800,
    "comment_markdown": "### Trust dropped\nScore 820 → 780 ❌",
}

SCORE_RESPONSE = {
    "agent_id": "ag_1",
    "overall_score": 847.0,
    "grade": "AA",
    "dimensions": {
        "safety": 0.91,
        "reliability": 0.88,
        "quality": 0.82,
        "performance": 0.80,
        "reputation": 0.78,
    },
    "computed_at": "2026-04-14T00:00:00Z",
}


def test_trust_check_returns_result(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/trust/ag_1/check",
        method="POST",
        json=CHECK_RESPONSE,
    )
    client = AinferaClient(api_key="x", base_url=BASE_URL)
    result = client.trust_check("ag_1", commit_sha="abc123")
    assert isinstance(result, TrustCheckResult)
    assert result.passed is False
    assert result.diff == -40
    assert "Trust dropped" in result.comment_markdown


def test_evaluate_trust_posts_to_evaluate(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/trust/ag_1/evaluate",
        method="POST",
        json=SCORE_RESPONSE,
    )
    client = AinferaClient(api_key="x", base_url=BASE_URL)
    score = client.evaluate_trust("ag_1")
    assert score.grade == "AA"
    assert score.overall_score == 847.0


def test_flat_get_trust_score(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/trust/ag_1/score",
        json=SCORE_RESPONSE,
    )
    client = AinferaClient(api_key="x", base_url=BASE_URL)
    score = client.get_trust_score("ag_1")
    assert score.grade == "AA"


def test_search_agents_sends_filters(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE_URL}/v1/registry/agents"
            "?page=1&per_page=5&q=research&framework=langchain&min_trust=700"
        ),
        json={"items": []},
    )
    client = AinferaClient(api_key="x", base_url=BASE_URL)
    results = client.search_agents(
        "research", framework="langchain", min_trust=700, limit=5
    )
    assert results == []


def test_publish_agent(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/registry/agents/ag_1/publish",
        method="POST",
        json={
            "id": "ag_1",
            "name": "research-agent",
            "framework": "langchain",
            "trust_score": 850.0,
            "grade": "AA",
            "published_at": "2026-04-14T00:00:00Z",
        },
    )
    client = AinferaClient(api_key="x", base_url=BASE_URL)
    agent = client.publish_agent("ag_1")
    assert agent.id == "ag_1"
    assert agent.grade == "AA"


def test_badge_url_methods(httpx_mock: HTTPXMock) -> None:
    client = AinferaClient(api_key="x", base_url=BASE_URL)
    assert client.get_badge_svg("ag_1") == f"{BASE_URL}/v1/public/trust/ag_1/badge.svg"
    assert "size=md" in client.get_badge_url("ag_1")


def test_trust_grade_from_score() -> None:
    assert TrustGrade.from_score(950) is TrustGrade.AAA
    assert TrustGrade.from_score(750) is TrustGrade.A
    assert TrustGrade.from_score(399) is TrustGrade.CCC
