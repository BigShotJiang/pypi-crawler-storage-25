"""Tests for the top-level client and error handling."""

from __future__ import annotations

import os

import pytest
from pytest_httpx import HTTPXMock

from ainfera_sdk import (
    Ainfera,
    AsyncAinfera,
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
    __version__,
)

BASE_URL = "https://api.test.ainfera.ai"


def test_version_is_set() -> None:
    assert __version__ == "0.3.0"


def test_api_key_defaults_to_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AINFERA_API_KEY", "from-env")
    client = Ainfera(base_url=BASE_URL)
    assert client.api_key == "from-env"


def test_base_url_defaults_to_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AINFERA_API_URL", "https://custom.ainfera.ai")
    monkeypatch.delenv("AINFERA_API_KEY", raising=False)
    client = Ainfera(api_key="x")
    assert client.base_url == "https://custom.ainfera.ai"


def test_base_url_defaults_to_production() -> None:
    # Only when env var is not set
    saved = os.environ.pop("AINFERA_API_URL", None)
    try:
        client = Ainfera(api_key="x")
        assert client.base_url == "https://api.ainfera.ai"
    finally:
        if saved is not None:
            os.environ["AINFERA_API_URL"] = saved


def test_context_manager_closes(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/registry/stats",
        json={
            "total_agents": 0,
            "total_frameworks": 0,
            "average_trust_score": 0.0,
            "updated_at": "2026-04-13T00:00:00Z",
        },
    )
    with Ainfera(api_key="x", base_url=BASE_URL) as client:
        stats = client.registry.stats()
    assert stats.total_agents == 0


def test_auth_error_on_401(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents?page=1&per_page=20",
        status_code=401,
        json={"message": "Invalid API key"},
    )
    client = Ainfera(api_key="bad", base_url=BASE_URL)
    with pytest.raises(AuthError) as excinfo:
        client.agents.list()
    assert excinfo.value.status_code == 401


def test_not_found_error_on_404(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents/missing",
        status_code=404,
        json={"message": "Not found"},
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    with pytest.raises(NotFoundError):
        client.agents.get("missing")


def test_validation_error_on_422(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents",
        status_code=422,
        json={"message": "Bad payload"},
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    with pytest.raises(ValidationError):
        client.agents.create(name="", framework="langchain")


def test_rate_limit_error_on_429(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/registry/stats",
        status_code=429,
        json={"message": "Too many requests"},
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    with pytest.raises(RateLimitError):
        client.registry.stats()


def test_server_error_on_500(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/registry/stats",
        status_code=503,
        json={"message": "Upstream error"},
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    with pytest.raises(ServerError):
        client.registry.stats()


def test_sends_api_key_header(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/registry/stats",
        json={
            "total_agents": 1,
            "total_frameworks": 1,
            "average_trust_score": 90.0,
            "updated_at": "2026-04-13T00:00:00Z",
        },
    )
    client = Ainfera(api_key="ainf_sk_abc", base_url=BASE_URL)
    client.registry.stats()
    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["X-Ainfera-Key"] == "ainf_sk_abc"
    assert request.headers["User-Agent"].startswith("ainfera-sdk-python/")


async def test_async_client(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/registry/stats",
        json={
            "total_agents": 5,
            "total_frameworks": 2,
            "average_trust_score": 88.0,
            "updated_at": "2026-04-13T00:00:00Z",
        },
    )
    async with AsyncAinfera(api_key="x", base_url=BASE_URL) as client:
        stats = await client.registry.stats()
    assert stats.total_agents == 5
