"""Shared pytest fixtures."""

from __future__ import annotations

import pytest

from ainfera_sdk import Ainfera, AsyncAinfera

BASE_URL = "https://api.test.ainfera.ai"
API_KEY = "ainf_sk_test_dummy"


@pytest.fixture
def client() -> Ainfera:
    return Ainfera(api_key=API_KEY, base_url=BASE_URL)


@pytest.fixture
async def async_client() -> AsyncAinfera:
    return AsyncAinfera(api_key=API_KEY, base_url=BASE_URL)


@pytest.fixture
def base_url() -> str:
    return BASE_URL
