"""Tests for the agents resource."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from ainfera_sdk import Agent, Ainfera, AsyncAinfera

BASE_URL = "https://api.test.ainfera.ai"


def _agent_fixture(agent_id: str = "ag_1", name: str = "demo") -> dict[str, object]:
    return {
        "id": agent_id,
        "name": name,
        "description": "demo agent",
        "framework": "langchain",
        "compute_tier": "standard",
        "status": "running",
        "created_at": "2026-04-13T00:00:00Z",
        "updated_at": "2026-04-13T00:00:00Z",
    }


def test_list(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents?page=1&per_page=20",
        json={"items": [_agent_fixture("ag_1"), _agent_fixture("ag_2", "other")]},
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    agents = client.agents.list()
    assert len(agents) == 2
    assert all(isinstance(a, Agent) for a in agents)
    assert agents[0].id == "ag_1"


def test_list_accepts_bare_array(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents?page=2&per_page=5",
        json=[_agent_fixture("ag_1")],
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    agents = client.agents.list(page=2, per_page=5)
    assert len(agents) == 1


def test_get(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(url=f"{BASE_URL}/v1/agents/ag_1", json=_agent_fixture())
    client = Ainfera(api_key="x", base_url=BASE_URL)
    agent = client.agents.get("ag_1")
    assert agent.id == "ag_1"
    assert agent.framework == "langchain"


def test_create(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents",
        method="POST",
        json=_agent_fixture("ag_new", "new-agent"),
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    agent = client.agents.create(
        name="new-agent",
        framework="langchain",
        description="hello",
        compute_tier="standard",
    )
    assert agent.id == "ag_new"

    request = httpx_mock.get_request()
    assert request is not None
    assert request.method == "POST"
    body = request.read().decode()
    assert "new-agent" in body
    assert "langchain" in body


def test_update(httpx_mock: HTTPXMock) -> None:
    updated = _agent_fixture()
    updated["name"] = "renamed"
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents/ag_1",
        method="PATCH",
        json=updated,
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    agent = client.agents.update("ag_1", name="renamed")
    assert agent.name == "renamed"


def test_delete(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents/ag_1",
        method="DELETE",
        status_code=204,
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    assert client.agents.delete("ag_1") is None


def test_kill_and_unkill(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents/ag_1/kill",
        method="POST",
        status_code=204,
    )
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents/ag_1/unkill",
        method="POST",
        status_code=204,
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    assert client.agents.kill("ag_1") is None
    assert client.agents.unkill("ag_1") is None


async def test_async_list_and_get(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents?page=1&per_page=20",
        json={"items": [_agent_fixture()]},
    )
    httpx_mock.add_response(url=f"{BASE_URL}/v1/agents/ag_1", json=_agent_fixture())
    async with AsyncAinfera(api_key="x", base_url=BASE_URL) as client:
        agents = await client.agents.list()
        one = await client.agents.get("ag_1")
    assert len(agents) == 1
    assert one.id == "ag_1"


@pytest.mark.parametrize("tier", ["standard", "gpu-a10", "gpu-h100"])
def test_create_accepts_various_tiers(httpx_mock: HTTPXMock, tier: str) -> None:
    httpx_mock.add_response(
        url=f"{BASE_URL}/v1/agents",
        method="POST",
        json=_agent_fixture(),
    )
    client = Ainfera(api_key="x", base_url=BASE_URL)
    client.agents.create(name="demo", framework="langchain", compute_tier=tier)
