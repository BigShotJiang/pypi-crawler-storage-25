# CLAUDE.md — Ainfera Python SDK

## Project
Python SDK for the Ainfera AI agent infrastructure platform.
Wraps the REST API at api.ainfera.ai with typed Python methods.
Published as `ainfera-sdk` on PyPI. Part of the Ainfera ecosystem
(platform-api, console, cli, sdk-python, infra, sandbox-runtime).

Company: Ainfera. Pre-funding.

## Architecture
- Thin wrapper around httpx (sync) and httpx.AsyncClient (async)
- Sub-clients: agents, trust, billing, execution, registry
- All responses deserialized into Pydantic v2 models
- Typed exceptions: AuthError(401), NotFoundError(404), ApiError(5xx)
- No state — each method is a single HTTP call

## Tech Stack
- Python 3.10+
- httpx for HTTP (sync + async)
- Pydantic v2 for response models
- pytest + pytest-httpx for testing
- ruff for linting/formatting
- mypy for type checking

## API Base URL
- Production: https://api.ainfera.ai
- Override via AINFERA_API_URL env var or client constructor

## Usage Pattern
```python
from ainfera_sdk import Ainfera
client = Ainfera(api_key="ainf_sk_live_...")
agents = client.agents.list()
score = client.trust.get_score(agent_id)
```

## Async Pattern
```python
from ainfera_sdk import AsyncAinfera
async with AsyncAinfera(api_key="...") as client:
    agents = await client.agents.list()
```

## Conventions
- All public methods have type hints and docstrings
- All responses are Pydantic models (not raw dicts)
- Errors raise typed exceptions, never return None for failures
- Tests mock HTTP with pytest-httpx, no real API calls
- 100% type coverage with mypy --strict
