import logging
from time import sleep
from typing import Optional

import requests


def _getlogger():
    logger = logging.getLogger(__name__)
    return logger


_logger = _getlogger()


def _l(info: str):
    _logger.info(info)


class HOOKHTTP:

    _NOBEARER = 0
    _BEARERTOKEN = 1
    _BEARERACCESS = 2

    _METHODPOST = 0
    _METHODDEL = 1
    _METHODGET = 2

    _RETRY_AFTER = 'Retry-After'
    _TIMEOUT = 30
    _MAX_429_RETRIES = 5
    _DEFAULT_RETRY_DELAY = 5

    def __init__(self, base_url: str, unitest: bool):
        self._base_url = base_url
        self._access_token: str = ''
        self._authenticationtoken: str = ''
        self._unittest: bool = unitest

    def set_tokes(self, access_token: str, authentication_token: str):
        self._access_token = access_token
        self._authenticationtoken = authentication_token

    def _construct_url(self, endpoint: str) -> str:
        return f'{self._base_url}/v2/{endpoint}'

    def hook_response(self,
                      endpoint: str,
                      method: int = _METHODPOST,
                      body: Optional[dict] = None,
                      bearer: int = _BEARERACCESS,
                      xml_data: Optional[bytes] = None,

                      requestmethod: Optional[str] = None,
                      data: Optional[bytes] = None,
                      requestheaders: Optional[dict] = None) -> requests.Response:

        if bearer != self._NOBEARER:
            headers = {
                'Authorization': f'Bearer {self._access_token if bearer == self._BEARERACCESS else self._authenticationtoken}'
            }
        else:
            headers = {}

        url = self._construct_url(
            endpoint=endpoint) if requestmethod is None else endpoint
        _l(url)
        no_request = 0
        while True:
            if requestmethod is not None:
                response = requests.request(
                    url=url, data=data, method=requestmethod, headers=requestheaders, timeout=self._TIMEOUT)
            else:
                if method == self._METHODDEL:
                    response = requests.delete(
                        url, headers=headers, timeout=self._TIMEOUT)
                elif method == self._METHODPOST:
                    if xml_data is None:
                        response = requests.post(
                            url, json=body or {}, headers=headers, timeout=self._TIMEOUT)
                    else:
                        headers = headers | {"Content-Type": "application/xml"}
                        response = requests.post(
                            url, data=xml_data, headers=headers, timeout=self._TIMEOUT)
                else:
                    response = requests.get(
                        url, headers=headers, timeout=self._TIMEOUT)

            if response.status_code == 400:
                try:
                    exce = response.json()[
                        'exception']['exceptionDetailList'][0]
                    details = exce['details']
                    errmsg = ' '.join(details)
                except (KeyError, IndexError, TypeError, ValueError):
                    errmsg = response.text
                _logger.error(errmsg)
                raise ValueError(errmsg)

            if response.status_code == 429 and not self._unittest:
                # RETRY_AFTER can be even 1 hours which strangle test
                # eneter limiter loop only if not unittest
                no_request += 1
                if no_request > self._MAX_429_RETRIES:
                    break
                retry_after = response.headers.get(self._RETRY_AFTER)
                no_of_sec = int(
                    retry_after) if retry_after is not None else self._DEFAULT_RETRY_DELAY * (2 ** (no_request - 1))
                _l(f'429 Too Many Requests, próba {no_request}/{self._MAX_429_RETRIES}, czekam {no_of_sec}s')
                sleep(no_of_sec)
            else:
                break

        response.raise_for_status()
        return response

    def hook(self, endpoint: str, method: int = _METHODPOST, body: dict | None = None, bearer: int = _BEARERACCESS) -> dict:

        response = self.hook_response(
            endpoint=endpoint, method=method, body=body, bearer=bearer)
        return response.json() if response.status_code != 204 else {}
