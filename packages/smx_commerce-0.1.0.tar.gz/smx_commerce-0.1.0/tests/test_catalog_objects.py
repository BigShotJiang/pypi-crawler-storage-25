﻿import pytest

from smx_commerce.catalog import (
    BillingMode,
    Category,
    CategoryStatus,
    Money,
    PriceStatus,
    Product,
    ProductKind,
    ProductPrice,
    ProductStatus,
)


def test_money_converts_major_amount_to_cents():
    amount = Money.from_major("149.99", "eur")

    assert amount.amount_cents == 14999
    assert amount.currency == "EUR"
    assert amount.major() == amount.major().__class__("149.99")


def test_category_validates_slug_and_public_status():
    category = Category(slug="ai-bootcamps", name="AI Bootcamps")

    assert category.slug == "ai-bootcamps"
    assert category.status == CategoryStatus.ACTIVE
    assert category.is_public is True


def test_invalid_category_slug_is_rejected():
    with pytest.raises(ValueError):
        Category(slug="AI Bootcamps", name="AI Bootcamps")


def test_one_time_product_can_be_purchasable():
    price = ProductPrice(
        code="standard",
        label="Standard",
        amount=Money.from_major("299.00", "EUR"),
    )

    product = Product(
        slug="example-product",
        name="Example Product",
        kind=ProductKind.EVENT,
        status=ProductStatus.ACTIVE,
        category_slugs=["ai-bootcamps"],
        prices=[price],
    )

    assert product.is_public is True
    assert product.is_purchasable is True
    assert product.primary_price == price


def test_paused_product_is_not_purchasable_even_with_active_price():
    price = ProductPrice(
        code="standard",
        label="Standard",
        amount=Money.from_major("299.00", "EUR"),
    )

    product = Product(
        slug="example-product",
        name="Example Product",
        status=ProductStatus.PAUSED,
        prices=[price],
    )

    assert product.is_public is False
    assert product.is_purchasable is False


def test_recurring_price_requires_billing_interval():
    with pytest.raises(ValueError):
        ProductPrice(
            code="monthly",
            label="Monthly",
            amount=Money.from_major("49.00", "EUR"),
            billing_mode=BillingMode.RECURRING,
        )


def test_inactive_price_does_not_make_product_purchasable():
    price = ProductPrice(
        code="old-price",
        label="Old Price",
        amount=Money.from_major("199.00", "EUR"),
        status=PriceStatus.INACTIVE,
    )

    product = Product(
        slug="example-product",
        name="Example Product",
        status=ProductStatus.ACTIVE,
        prices=[price],
    )

    assert product.active_prices == []
    assert product.is_purchasable is False


def test_archived_product_cannot_be_reactivated():
    product = Product(
        slug="example-product",
        name="Example Product",
        status=ProductStatus.ARCHIVED,
    )

    with pytest.raises(ValueError):
        product.activate()
