from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def test_admin_home_requires_auth_for_json_request(tmp_path):
    client = create_client(tmp_path)

    response = client.get("/commerce/admin")

    assert response.status_code == 401
    assert response.get_json()["error"] == "admin authentication required"


def test_admin_home_redirects_to_login_for_browser_request(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin",
        headers={"Accept": "text/html"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    assert response.headers["Location"].endswith("/commerce/admin/login")


def test_admin_home_redirects_to_products_after_session_login(tmp_path):
    client = create_client(tmp_path)

    login = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert login.status_code == 200

    response = client.get(
        "/commerce/admin",
        headers={"Accept": "text/html"},
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/products"


def test_admin_home_accepts_header_key_and_redirects_to_products(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin",
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/products"
