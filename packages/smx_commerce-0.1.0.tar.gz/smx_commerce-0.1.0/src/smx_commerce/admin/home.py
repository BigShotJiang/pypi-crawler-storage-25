from __future__ import annotations

from flask import Blueprint, redirect


def create_admin_home_blueprint() -> Blueprint:
    bp = Blueprint("smx_commerce_admin_home", __name__)

    @bp.get("/", strict_slashes=False)
    def admin_home():
        return redirect("/commerce/admin/products", code=303)

    return bp
