from __future__ import annotations

from dataclasses import dataclass
import os


@dataclass(frozen=True)
class CommerceConfig:
    database_url: str
    echo_sql: bool = False
    admin_api_key: str | None = None

    @classmethod
    def from_env(cls) -> "CommerceConfig":
        return cls(
            database_url=os.getenv(
                "SMX_COMMERCE_DATABASE_URL",
                "sqlite+pysqlite:///./smx_commerce_dev.db",
            ),
            echo_sql=os.getenv("SMX_COMMERCE_ECHO_SQL", "").lower() in {"1", "true", "yes"},
            admin_api_key=os.getenv("SMX_COMMERCE_ADMIN_API_KEY") or None,
        )

    @classmethod
    def from_mapping(cls, values: dict | None) -> "CommerceConfig":
        values = values or {}
        return cls(
            database_url=values.get(
                "database_url",
                os.getenv(
                    "SMX_COMMERCE_DATABASE_URL",
                    "sqlite+pysqlite:///./smx_commerce_dev.db",
                ),
            ),
            echo_sql=bool(values.get("echo_sql", False)),
            admin_api_key=values.get("admin_api_key") or os.getenv("SMX_COMMERCE_ADMIN_API_KEY") or None,
        )
