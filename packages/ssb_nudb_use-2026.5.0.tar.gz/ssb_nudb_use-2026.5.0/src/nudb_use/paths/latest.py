"""Location utilities for discovering the latest shared NUDB datasets."""

from pathlib import Path

from dapla_metadata.datasets.dapla_dataset_path_info import DaplaDatasetPathInfo
from fagfunksjoner.paths.versions import get_latest_fileversions
from nudb_config import settings

from nudb_use.nudb_logger import LoggerStack
from nudb_use.nudb_logger import logger

ENV = "daplalab_mounted"

SHARED_ROOT_EXTERNAL = settings.paths[ENV].get(
    "shared_root_external", "/buckets/shared"
)
SHARED_UTDANNING_EXTERNAL = settings.paths[ENV].get(
    "shared_utdanning_external", "/buckets/shared/utd-nudb/utdanning/"
)
SHARED_UTDANNING_INTERNAL = settings.paths[ENV].get(
    "shared_utdanning_internal", "/buckets/delt-utdanning/nudb-data"
)
PRODUKT = settings.paths[ENV].get("produkt", "/buckets/produkt/nudb-data/")

POSSIBLE_PATHS = [
    Path(SHARED_UTDANNING_EXTERNAL),
    Path(SHARED_UTDANNING_INTERNAL),
    Path(PRODUKT),
]


def _add_delt_path(path: str | Path) -> None:
    global POSSIBLE_PATHS

    if not isinstance(path, Path):
        path = Path(path)

    if not path.is_dir():
        raise OSError(
            f"'{path}' is not a directory!"
        )  # OSError might not be the right choice

    POSSIBLE_PATHS.append(path)


def _hide_produkt_paths() -> None:
    """Hide produkt path for utd-nudb developers."""
    global POSSIBLE_PATHS
    global PRODUKT

    produkt = Path(PRODUKT)
    if produkt in POSSIBLE_PATHS:
        logger.info(f"Removing {produkt} from searchable paths...")
        POSSIBLE_PATHS.remove(produkt)
    else:
        logger.warning(f"{produkt} is not in searchable paths, nothing to remove...")


def _reveal_produkt_paths() -> None:
    """Reveal produkt path for utd-nudb developers."""
    global POSSIBLE_PATHS
    global PRODUKT

    produkt = Path(PRODUKT)
    if produkt not in POSSIBLE_PATHS:
        logger.info(f"Adding {produkt} to searchable paths...")
        POSSIBLE_PATHS.append(produkt)
    else:
        logger.warning(f"{produkt} is already in searchable paths, nothing to add...")


def _get_available_files(filename: str = "", filetype: str = "parquet") -> list[Path]:
    global POSSIBLE_PATHS
    # For custom paths we don't know if there is a klargjorte-data
    # directory, so we search in the directory directly as well
    # We could perhaps rework this logic into _add_delt_path()
    # and add the /klargjorte-data to the paths in POSSIBLE_PATHS
    filepattern = f"{filename}*" if filename else "*"

    globs = [
        f"klargjorte-data/*/{filepattern}.{filetype}",
        f"*/{filepattern}.{filetype}",
        f"{filepattern}.{filetype}",
    ]

    logger.debug(f"globs = {globs}")
    files = []

    for path in POSSIBLE_PATHS:
        if not path.is_dir():
            continue

        for glob in globs:
            files += list(path.glob(glob))

    if files:
        logger.info(
            f"Found relevant files locally in POSSIBLE_PATHS, not using glob from config: {files}"
        )
        return files

    # Fall back to the dataset config for external datasets that live in other teams
    if (
        filename in settings.datasets
        and settings.datasets[filename].team != settings.dapla_team
    ):
        datameta = settings.datasets[filename]
        if datameta.team and datameta.bucket and datameta.path_glob:
            local_path = Path(
                f"{SHARED_ROOT_EXTERNAL}/{datameta.team}/{datameta.bucket}/"
            )
            found_files = list(local_path.glob(datameta.path_glob))
            if found_files:
                return found_files
        # If we are here, the file looks external, but we couldnt find it locally
        msg = f"Either you need to get access to and mount locally the bucket {datameta.bucket} from the team {datameta.team}.\n"
        msg += f"Or the config is missing an important value for the dataset `{filename}`, the team name: `{datameta.team}`,"
        msg += f"the bucket name: `{datameta.bucket}` or full path glob: `/buckets/shared/{datameta.team}/{datameta.bucket}/{datameta.path_glob}`"
        raise FileNotFoundError(msg)

    return files


def get_file_short_name(p: Path) -> str:
    """Get short name of a file, from a path.

    Args:
        p: Path that potentially includes period/version information.

    Returns:
        str: File short name without period and version fragments.
    """
    p = Path(p)  # In case someone sends a str...
    short_name = DaplaDatasetPathInfo(p).dataset_short_name

    return short_name if short_name else ""


def latest_shared_path(dataset_name: str = "") -> tuple[str, Path]:
    """Return the newest shared dataset path.

    This is a convenience wrapper around `latest_shared_paths` that returns
    the most recent dataset entry (by sorted key).

    Args:
        dataset_name: Optional dataset identifier to filter available paths
            before selecting the newest entry.

    Returns:
        tuple[str, Path]: The dataset key and its latest path.

    Raises:
        KeyError: If we cant find any files, we cant pick the latest one...
    """
    paths = latest_shared_paths(dataset_name)
    if isinstance(paths, Path):
        return dataset_name, paths

    paths_dict: dict[str, Path] = paths
    if not paths_dict:
        raise KeyError(
            f"Can't pick the latest shared path for a file you cant read: {dataset_name} - make sure you can access the file, and the bucket is mounted."
        )
    last_key = max(paths_dict.keys())
    last_path = paths_dict[last_key]
    logger.info(f"{dataset_name} name: {last_key} at: {last_path}.")

    return last_key, last_path


def latest_shared_paths(dataset_name: str = "") -> dict[str, Path] | Path:
    """Find the last shared version and period of each stem in the shared folder.

    Args:
        dataset_name: Optional dataset identifier. When provided only the path
            for that dataset is returned.

    Returns:
        dict[str, Path] | Path: Mapping of dataset stems to their newest paths,
        or a single `Path` when `dataset_name` is supplied.
    """
    with LoggerStack("Finding all the latest shared paths for NUDB."):
        # Filter to only the last versions of each period
        latest_parquets = sorted(
            get_latest_fileversions(_get_available_files(dataset_name))
        )
        logger.info(latest_parquets)
        # Filtering out earlier periods of the same files

        paths_dict: dict[str, Path] = {}
        for p in latest_parquets:
            paths_dict[get_file_short_name(p)] = p

        # We should probably log what we found as latest files to disk?
        if dataset_name and dataset_name in paths_dict:
            logger.info(
                f"Found {dataset_name} in the paths_dict, returning single Path."
            )
            logger.info(f"Selected path: '{paths_dict[dataset_name]}'.'")

            return paths_dict[dataset_name]

        paths_str = ",\n".join(list(paths_dict.keys()))
        logger.warning(
            f"Did not find {dataset_name} in the paths_dict, all found path keys: {paths_str} - do you have access and the file mounted?"
        )

        return paths_dict
