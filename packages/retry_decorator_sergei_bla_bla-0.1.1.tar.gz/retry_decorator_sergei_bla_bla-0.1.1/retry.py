
def retryDecorator(counter: int = 3):
    def decorator(func):
        def wrapper(*args, **kwargs):
            attempts = 1 if counter <= 0 else counter
            while attempts:
                try:
                    print("Call connection")
                    return func(*args, **kwargs)
                except ConnectionError:
                    print("Make retry")
                    attempts -= 1
            raise ConnectionError("Can't connect to DB")

        return wrapper

    return decorator


