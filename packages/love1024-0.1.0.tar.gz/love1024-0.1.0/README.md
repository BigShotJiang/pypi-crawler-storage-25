# 🎉 Love1024 - 程序员鼓励师

> AI 编程助手语音播报伴侣 —— 让 AI 在每次任务完成后用温柔的声音鼓励你！
>
> 支持 **CodeBuddy** · **Claude Code** 等主流 AI 编程工具

## ✨ 功能特性

- 🎤 **智能语音播报** - 感知会话内容，AI 生成场景化鼓励文案并语音播放
- 🔌 **多平台支持** - CodeBuddy IDE/CLI、Claude Code/CLI，一键检测自动注册
- 🎭 **8 种鼓励风格** - 甜美、傲娇、PUA、知性、元气、台湾甜心、暖男学长、忠犬男友
- 🔊 **3 种语音引擎** - edge-tts 在线 / Qwen3-TTS 本地 MLX / Qwen3-TTS 云端
- 🎨 **AI 情感语气** - Qwen3-TTS 引擎下，大模型动态生成语气指令控制语音情感
- 🗣️ **丰富音色** - edge-tts 中日双语音色 + Qwen3 云端 24 种个性音色
- 🤫 **4 档静默力度** - 话唠 → 适中 → 安静 → 专注，灵活控制播报频率
- 🔧 **交互式向导** - 彩色终端 TUI，5 步完成全部配置
- 📝 **播报日志** - JSONL 格式记录每次播报，随时回顾

## 🔊 三种语音引擎

| 引擎 | 特点 | 适合场景 |
|------|------|----------|
| 🌐 **edge-tts** | 微软在线 TTS，零配置，音色多 | 所有用户（默认） |
| 🍎 **Qwen3-TTS MLX** | 本地离线，Apple Silicon Metal 加速 | Mac M 系列用户 |
| ☁️ **Qwen3-TTS 云端** | 阿里云百炼 API，24 种音色 | 所有用户，需百炼 Key |

**Qwen3-TTS 的核心优势**：用自然语言控制情感，大模型根据场景动态生成语气指令——

```
修完隐蔽 Bug  →  语气: "用惊喜又佩服的语气"   文案: "这个Bug藏得这么深都被你找出来了~"
深夜推代码    →  语气: "用温柔关怀的语气"       文案: "辛苦了，今天也很努力呢"
傲娇风格     →  语气: "用傲娇不屑暗含关心的语气" 文案: "哼...总算把配置搞对了"
```

> 💡 Qwen3-TTS 是可选功能，不装也完全不影响使用，edge-tts 开箱即用。

## 🎭 8 种鼓励师风格

| 风格 | 性格 | 示例台词 |
|------|------|---------|
| 💕 甜美可爱 | 温柔甜美小天使 | "主人太厉害了，代码写得好棒！" |
| 😤 傲娇 | 嘴硬心软 | "哼，不是因为想夸你才说的…" |
| 🎭 PUA 大师 | 先抑后扬 | "就这？…开玩笑的，其实很厉害！" |
| 🌸 知性温柔 | 沉稳优雅 | "又完成了一个里程碑，值得记录" |
| ⚡ 元气满满 | 活力四射 | "冲鸭！！主人是最棒的！！" |
| 🧋 台湾甜心 | 软糯嗲嗲 | "哇～哥哥你好厉害哦～" |
| ☀️ 暖男学长 | 温柔体贴可靠 | "辛苦了，这个问题不好处理，但你做到了" |
| 🐶 忠犬男友 | 热情专一崇拜 | "又搞定了！我超级骄傲的好不好！" |

## 📦 安装

```bash
# 从 PyPI 安装
pip3 install love1024

# 或从 GitHub 安装最新版
pip3 install git+https://github.com/lyqandhh/love1024.git

# 运行安装向导
love1024 setup
```

## 🚀 快速开始

```bash
love1024 setup    # 交互式向导：风格 → 称呼 → API → 语音引擎/音色 → 静默力度
love1024 test     # 测试语音播放
love1024 config   # 随时修改任意配置项
```

向导完成后**重启对应的 AI 编程工具**即可生效。

## 🎛️ 命令一览

| 命令 | 说明 |
|------|------|
| `love1024 setup` | 交互式安装向导 |
| `love1024 config` | 修改配置（风格/引擎/音色/API 等） |
| `love1024 test` | 播放测试语音 |
| `love1024 on` / `off` | 开启/关闭语音播报 |
| `love1024 voices` | 查看可用语音列表 |
| `love1024 log` | 查看播报历史 |
| `love1024 install-hook` | 自动检测已安装工具并注册 Hook |
| `love1024 uninstall` | 卸载并清理配置 |

## ⚙️ 配置文件

配置文件位于 `~/.config/love1024/config.toml`：

```toml
[llm]
api_key = "sk-xxx"
base_url = "https://dashscope.aliyuncs.com/compatible-mode/v1"
model = "deepseek-v3"

[voice]
tts_engine = "qwen3-cloud"          # "edge-tts" | "qwen3-tts" | "qwen3-cloud"
# edge-tts 配置
zh_voice = "zh-CN-XiaoyiNeural"
ja_voice = "ja-JP-NanamiNeural"
# Qwen3-TTS MLX 本地配置
qwen3_model = "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit"
qwen3_speaker = "Vivian"
# Qwen3-TTS 云端配置
qwen3_cloud_api_key = "sk-xxx"
qwen3_cloud_voice = "Cherry"
qwen3_cloud_model = "qwen3-tts-instruct-flash"

[personality]
style = "sweet"                     # sweet|tsundere|pua|gentle|energetic|taiwan|senpai|loyal
owner_name = "主人"
zh_ratio = 90

[behavior]
silent_level = 2                    # 1=话唠 2=适中 3=安静 4=专注
enabled = true
```

## 🔇 静默力度

| 级别 | 模式 | 播报时机 |
|:----:|------|---------|
| 1 | 🗣️ 话唠 | 几乎每次回复都播报 |
| 2 | ⚖️ 适中 | 仅在任务完成时（默认） |
| 3 | 🤫 安静 | 仅在重要里程碑时 |
| 4 | 🎯 专注 | 仅在明确阶段完成时 |

## 🖥️ 系统要求

- **macOS**（使用 afplay 播放音频）
- **Python 3.9+**
- **AI 编程工具**：CodeBuddy IDE/CLI 或 Claude Code/CLI（任一即可）
- **LLM API Key**（支持 OpenAI 兼容 API，如 [阿里云百炼](https://bailian.console.aliyun.com/) / [DeepSeek](https://platform.deepseek.com/) 等）
- （可选）Apple Silicon + `mlx-audio`：Qwen3-TTS 本地引擎
- （可选）阿里云百炼 API Key：Qwen3-TTS 云端引擎

## 🤝 Contributing

欢迎提交 Issue 和 Pull Request！详见 [CONTRIBUTING.md](CONTRIBUTING.md)。

## 📄 License

MIT
