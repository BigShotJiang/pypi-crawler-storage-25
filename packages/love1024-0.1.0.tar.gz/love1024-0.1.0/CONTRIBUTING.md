# 贡献指南

感谢你对 Love1024 的关注！欢迎任何形式的贡献。

## 如何贡献

### 报告 Bug

- 在 [Issues](https://github.com/lyqandhh/love1024/issues) 中搜索是否已有相同问题
- 如果没有，创建新 Issue，描述问题、复现步骤和环境信息

### 提交功能建议

- 在 Issues 中提交 Feature Request，描述你想要的功能和使用场景

### 提交代码

1. Fork 本仓库
2. 创建你的分支：`git checkout -b feature/my-feature`
3. 提交改动：`git commit -m "feat: add some feature"`
4. 推送分支：`git push origin feature/my-feature`
5. 提交 Pull Request

### 开发环境搭建

```bash
# 克隆仓库
git clone https://github.com/lyqandhh/love1024.git
cd love1024

# 创建虚拟环境
python3 -m venv .venv
source .venv/bin/activate

# 安装开发依赖（可编辑模式）
pip install -e .

# 测试运行
love1024 --help
```

### 新增鼓励师风格

1. 在 `src/love1024/presets/` 下新建 TOML 文件（参考已有风格）
2. 在 `src/love1024/presets/__init__.py` 中注册新风格
3. 在 `wizard.py` 的风格选择列表中添加入口

### Commit 规范

推荐使用 [Conventional Commits](https://www.conventionalcommits.org/)：

- `feat:` 新功能
- `fix:` 修复 Bug
- `docs:` 文档更新
- `refactor:` 重构
- `chore:` 构建/工具变更

## 行为准则

请尊重每一位参与者。我们致力于为所有人提供一个友好、安全、包容的参与环境。
