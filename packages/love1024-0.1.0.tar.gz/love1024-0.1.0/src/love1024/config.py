"""配置管理器 - TOML 配置文件读写、默认配置生成、旧版迁移"""

import os
import sys
from typing import Optional

# TOML 读取：Python 3.11+ 内置 tomllib，3.10 用 tomli
if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None

try:
    import tomli_w
except ImportError:
    tomli_w = None


CONFIG_DIR = os.path.expanduser("~/.config/love1024")
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.toml")
OLD_CONFIG_PATH = os.path.expanduser("~/.codebuddy/hooks/.voice_hook_config")


def get_default_config() -> dict:
    """返回默认配置"""
    return {
        "llm": {
            "api_key": "",
            "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
            "model": "deepseek-v3",
        },
        "voice": {
            "tts_engine": "edge-tts",  # "edge-tts" | "qwen3-tts" | "qwen3-cloud"
            "zh_voice": "zh-CN-XiaoyiNeural",
            "zh_rate": "+0%",
            "zh_pitch": "+0Hz",
            "ja_voice": "ja-JP-NanamiNeural",
            "ja_rate": "-20%",
            "ja_pitch": "+8Hz",
            # Qwen3-TTS MLX 本地配置
            "qwen3_model": "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit",
            "qwen3_speaker": "Vivian",
            # Qwen3-TTS 云端配置（阿里云百炼）
            "qwen3_cloud_api_key": "",
            "qwen3_cloud_voice": "Cherry",
            "qwen3_cloud_model": "qwen3-tts-instruct-flash",
        },
        "personality": {
            "style": "sweet",
            "owner_name": "主人",
            "owner_name_ja": "ご主人様",
            "zh_ratio": 90,
            "custom_prompt": "",
        },
        "behavior": {
            "enabled": True,
            "silent_level": 2,
            "log_enabled": True,
        },
    }


def ensure_config_dir():
    """确保配置目录存在"""
    os.makedirs(CONFIG_DIR, exist_ok=True)


def config_exists() -> bool:
    """检查配置文件是否已存在"""
    return os.path.exists(CONFIG_PATH)


def old_config_exists() -> bool:
    """检查旧版配置文件是否存在"""
    return os.path.exists(OLD_CONFIG_PATH)


def load_config() -> dict:
    """加载配置文件，不存在则返回默认配置"""
    if not os.path.exists(CONFIG_PATH):
        return get_default_config()

    if tomllib is None:
        return get_default_config()

    try:
        with open(CONFIG_PATH, "rb") as f:
            user_cfg = tomllib.load(f)
        # 合并：用户配置覆盖默认值
        default = get_default_config()
        for section, values in default.items():
            if section not in user_cfg:
                user_cfg[section] = values
            elif isinstance(values, dict):
                for k, v in values.items():
                    if k not in user_cfg[section]:
                        user_cfg[section][k] = v
        return user_cfg
    except Exception:
        return get_default_config()


def save_config(cfg: dict):
    """保存配置到 TOML 文件"""
    if tomli_w is None:
        raise RuntimeError("tomli_w 未安装，无法保存配置。请运行: pip install tomli-w")

    ensure_config_dir()
    with open(CONFIG_PATH, "wb") as f:
        tomli_w.dump(cfg, f)


def migrate_old_config() -> Optional[dict]:
    """
    迁移旧版 key=value 配置文件到新 TOML 格式。
    返回迁移后的配置 dict，如果无旧配置则返回 None。
    """
    if not old_config_exists():
        return None

    old_cfg = {}
    try:
        with open(OLD_CONFIG_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    old_cfg[k.strip()] = v.strip()
    except Exception:
        return None

    if not old_cfg:
        return None

    # 映射旧字段到新配置结构
    cfg = get_default_config()

    if "TOKENHUB_API_KEY" in old_cfg:
        cfg["llm"]["api_key"] = old_cfg["TOKENHUB_API_KEY"]
    if "TOKENHUB_BASE_URL" in old_cfg:
        cfg["llm"]["base_url"] = old_cfg["TOKENHUB_BASE_URL"]
    if "TOKENHUB_MODEL" in old_cfg:
        cfg["llm"]["model"] = old_cfg["TOKENHUB_MODEL"]
    if "OWNER_NAME" in old_cfg:
        cfg["personality"]["owner_name"] = old_cfg["OWNER_NAME"]
    if "OWNER_NAME_JA" in old_cfg:
        cfg["personality"]["owner_name_ja"] = old_cfg["OWNER_NAME_JA"]

    return cfg


def get_hook_command(platform_id: str = "") -> str:
    """获取 Hook 命令路径（love1024 hook --platform xxx）"""
    import shutil
    # 优先使用虚拟环境中的 love1024（支持 MLX 加速）
    venv_love1024 = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))))),
        "qwen3-tts-env", "bin", "love1024"
    )
    if os.path.exists(venv_love1024):
        base = venv_love1024
    else:
        path = shutil.which("love1024")
        base = path if path else "love1024"

    cmd = f"{base} hook"
    if platform_id:
        cmd += f" --platform {platform_id}"
    return cmd


# ─────────────────────────────────────────────
# 多平台 Hook 支持
# ─────────────────────────────────────────────

# 支持的平台配置
PLATFORMS = {
    "codebuddy": {
        "name": "CodeBuddy IDE / CLI",
        "settings_path": "~/.codebuddy/settings.json",
        "event": "Stop",
    },
    "claude": {
        "name": "Claude Code / CLI",
        "settings_path": "~/.claude/settings.json",
        "event": "Stop",
    },
}


def detect_installed_platforms() -> list[dict]:
    """
    自动检测当前系统安装了哪些 AI 编程工具。
    返回 [{"id": "codebuddy", "name": "...", "installed": True, "hooked": True}, ...]
    """
    results = []
    for pid, info in PLATFORMS.items():
        settings_path = os.path.expanduser(info["settings_path"])
        # 检测是否安装（settings 目录或文件存在）
        settings_dir = os.path.dirname(settings_path)
        installed = os.path.isdir(settings_dir)
        # 检测是否已注册 hook
        hooked = _check_hook_in_file(settings_path)
        results.append({
            "id": pid,
            "name": info["name"],
            "settings_path": settings_path,
            "installed": installed,
            "hooked": hooked,
        })
    return results


def _check_hook_in_file(settings_path: str) -> bool:
    """检查指定 settings.json 中是否已注册 love1024 hook"""
    if not os.path.exists(settings_path):
        return False
    try:
        import json
        with open(settings_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        hooks = data.get("hooks", {}).get("Stop", [])
        for hook_group in hooks:
            for h in hook_group.get("hooks", []):
                cmd = h.get("command", "")
                if "love1024" in cmd:
                    return True
        return False
    except Exception:
        return False


def register_hook(platform_id: str) -> tuple[bool, str]:
    """
    向指定平台的 settings.json 注册 love1024 hook。
    返回 (success, message)。
    CodeBuddy 和 Claude Code 的 hooks 格式相同。
    """
    import json

    if platform_id not in PLATFORMS:
        return False, f"不支持的平台: {platform_id}"

    info = PLATFORMS[platform_id]
    settings_path = os.path.expanduser(info["settings_path"])
    hook_cmd = get_hook_command(platform_id)

    # 读取现有配置
    if os.path.exists(settings_path):
        try:
            with open(settings_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
    else:
        # 确保目录存在
        os.makedirs(os.path.dirname(settings_path), exist_ok=True)
        data = {}

    # 检查是否已注册（如果命令过期则自动升级）
    data.setdefault("hooks", {}).setdefault("Stop", [])
    hooks = data["hooks"]["Stop"]
    for hook_group in hooks:
        for h in hook_group.get("hooks", []):
            cmd = h.get("command", "")
            if "love1024" in cmd:
                if cmd == hook_cmd:
                    return True, f"{info['name']}: Hook 已存在，无需重复注册"
                # 命令不一致（如缺少 --platform），自动升级
                h["command"] = hook_cmd
                try:
                    with open(settings_path, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    return True, f"{info['name']}: ✅ Hook 已升级（增加 --platform 参数）"
                except Exception as e:
                    return False, f"{info['name']}: ❌ 升级失败 ({e})"

    # 添加 hook
    entry = {
        "matcher": "",
        "hooks": [
            {
                "type": "command",
                "command": hook_cmd,
                "timeout": 15,
            }
        ],
    }
    hooks.append(entry)

    # 写回
    try:
        with open(settings_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True, f"{info['name']}: ✅ Hook 注册成功"
    except Exception as e:
        return False, f"{info['name']}: ❌ 写入失败 ({e})"


def unregister_hook(platform_id: str) -> tuple[bool, str]:
    """从指定平台移除 love1024 hook"""
    import json

    if platform_id not in PLATFORMS:
        return False, f"不支持的平台: {platform_id}"

    info = PLATFORMS[platform_id]
    settings_path = os.path.expanduser(info["settings_path"])

    if not os.path.exists(settings_path):
        return True, f"{info['name']}: 配置文件不存在，无需操作"

    try:
        with open(settings_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return False, f"{info['name']}: 读取配置失败"

    hooks = data.get("hooks", {}).get("Stop", [])
    new_hooks = []
    removed = False
    for hook_group in hooks:
        new_group_hooks = [
            h for h in hook_group.get("hooks", [])
            if "love1024" not in h.get("command", "")
        ]
        if len(new_group_hooks) < len(hook_group.get("hooks", [])):
            removed = True
        if new_group_hooks:
            hook_group["hooks"] = new_group_hooks
            new_hooks.append(hook_group)

    data["hooks"]["Stop"] = new_hooks
    try:
        with open(settings_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True, f"{info['name']}: {'已移除 Hook' if removed else '未找到 Hook'}"
    except Exception as e:
        return False, f"{info['name']}: 写入失败 ({e})"


def register_all_hooks() -> list[tuple[str, bool, str]]:
    """检测所有已安装平台并注册 Hook，返回结果列表"""
    results = []
    for p in detect_installed_platforms():
        if p["installed"]:
            ok, msg = register_hook(p["id"])
            results.append((p["name"], ok, msg))
    return results


def check_any_hook_registered() -> bool:
    """检查是否有任何平台已注册 love1024 hook"""
    for p in detect_installed_platforms():
        if p["hooked"]:
            return True
    return False


# 兼容旧接口
def check_hook_registered() -> bool:
    return check_any_hook_registered()


def get_hook_register_command() -> str:
    """生成手动注册命令（兼容旧逻辑，仅针对 CodeBuddy）"""
    hook_cmd = get_hook_command()
    script = (
        "import json, os, sys; "
        "p = os.path.expanduser('~/.codebuddy/settings.json'); "
        "d = json.load(open(p)) if os.path.exists(p) else {}; "
        "d.setdefault('hooks', {}).setdefault('Stop', []); "
        "hooks = d['hooks']['Stop']; "
        f"entry = {{'matcher': '', 'hooks': [{{'type': 'command', 'command': '{hook_cmd}', 'timeout': 15}}]}}; "
        "already = any('love1024' in h.get('command','') for g in hooks for h in g.get('hooks',[])); "
        "hooks.append(entry) if not already else None; "
        "open(p, 'w').write(json.dumps(d, indent=2, ensure_ascii=False)); "
        "print('✅ Hook 注册成功！' if not already else '⚠️  Hook 已存在，无需重复注册')"
    )
    return f'python3 -c "{script}"'


def get_hook_json_snippet() -> str:
    """生成 settings.json 的 hooks 配置片段"""
    cmd = get_hook_command()
    import json
    snippet = {
        "hooks": {
            "Stop": [
                {
                    "matcher": "",
                    "hooks": [
                        {
                            "type": "command",
                            "command": cmd,
                            "timeout": 15,
                        }
                    ],
                }
            ]
        }
    }
    return json.dumps(snippet, indent=2, ensure_ascii=False)
