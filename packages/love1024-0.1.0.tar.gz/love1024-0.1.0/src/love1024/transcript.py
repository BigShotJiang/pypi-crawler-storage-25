"""会话内容提取器 - 解析 CodeBuddy / Claude Code transcript 文件"""

import json
import os


def get_recent_messages_text(msg_dir: str, max_chars: int = 2000) -> str:
    """
    提取最近几条消息的文本内容，拼接后不超过 max_chars。
    msg_dir: transcript index.json 同级的 messages/ 目录
    """
    try:
        all_files = [
            f for f in os.listdir(msg_dir)
            if f.endswith(".json") and not f.startswith(".")
        ]
        files = sorted(
            all_files,
            key=lambda f: os.path.getmtime(os.path.join(msg_dir, f)),
            reverse=True,
        )
        parts = []
        total = 0
        for fname in files[:15]:
            try:
                with open(os.path.join(msg_dir, fname), encoding="utf-8", errors="ignore") as fh:
                    d = json.loads(fh.read())
                role = d.get("role", "")
                if role not in ("assistant", "user"):
                    continue
                m = json.loads(d.get("message", "{}"))
                texts = [
                    c.get("text", "")
                    for c in m.get("content", [])
                    if c.get("type") == "text"
                ]
                text = "\n".join(texts).strip()
                if not text:
                    continue
                chunk = f"[{role}]: {text[:500]}\n"
                parts.append(chunk)
                total += len(chunk)
                if total >= max_chars:
                    break
            except Exception:
                pass
        parts.reverse()
        return "\n".join(parts)
    except Exception:
        return ""


def is_orchestrator_session(msg_dir: str) -> bool:
    """判断是否为编排器主会话（含 rules/teammate-message）"""
    try:
        all_files = [
            f for f in os.listdir(msg_dir)
            if f.endswith(".json") and not f.startswith(".")
        ]
        oldest = sorted(
            all_files,
            key=lambda f: os.path.getmtime(os.path.join(msg_dir, f)),
        )
        first_content = ""
        for f in oldest[:3]:
            with open(os.path.join(msg_dir, f), encoding="utf-8", errors="ignore") as fh:
                first_content += fh.read()
        return (
            "<teammate-message>" in first_content
            or "requestedrules" in first_content.lower()
            or "agent_requestable_workspace_rules" in first_content.lower()
        )
    except Exception:
        return False


def extract_conversation(transcript_path: str) -> str:
    """
    从 transcript_path (index.json) 中提取最近对话文本。
    返回空字符串表示无内容。
    """
    if not transcript_path or not os.path.exists(transcript_path):
        return ""

    transcript_dir = os.path.dirname(transcript_path)
    msg_dir = os.path.join(transcript_dir, "messages")

    if not os.path.isdir(msg_dir):
        return ""

    return get_recent_messages_text(msg_dir)


def extract_conversation_jsonl(jsonl_path: str, max_chars: int = 2000) -> str:
    """
    从 Claude Code 的 JSONL transcript 文件中提取最近对话文本。
    Claude Code transcript 格式：每行一个 JSON 对象，包含 type/message 等字段。
    """
    if not jsonl_path or not os.path.exists(jsonl_path):
        return ""

    try:
        with open(jsonl_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        parts = []
        total = 0
        # 从后往前读取最近的消息
        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except Exception:
                continue

            # Claude Code JSONL 格式：
            # {"type": "assistant", "message": {"content": [{"type": "text", "text": "..."}]}}
            # 或更简单的: {"role": "assistant", "content": "..."}
            role = entry.get("type", entry.get("role", ""))
            if role not in ("assistant", "user", "human"):
                continue

            # 提取文本内容
            text = ""
            msg = entry.get("message", {})
            if isinstance(msg, dict):
                content = msg.get("content", [])
                if isinstance(content, list):
                    text = "\n".join(
                        c.get("text", "")
                        for c in content
                        if isinstance(c, dict) and c.get("type") == "text"
                    ).strip()
                elif isinstance(content, str):
                    text = content.strip()
            elif isinstance(msg, str):
                text = msg.strip()

            # 也尝试直接从 content 字段取
            if not text:
                content = entry.get("content", "")
                if isinstance(content, str):
                    text = content.strip()
                elif isinstance(content, list):
                    text = "\n".join(
                        c.get("text", "")
                        for c in content
                        if isinstance(c, dict) and c.get("type") == "text"
                    ).strip()

            if not text:
                continue

            display_role = "assistant" if role in ("assistant",) else "user"
            chunk = f"[{display_role}]: {text[:500]}\n"
            parts.append(chunk)
            total += len(chunk)
            if total >= max_chars:
                break

        parts.reverse()
        return "\n".join(parts)
    except Exception:
        return ""
