"""LLM 客户端 - 调用 OpenAI 兼容 API 生成播报文案"""

import json
import urllib.request
import urllib.error


def ask_llm(
    conversation_text: str,
    system_prompt: str,
    api_key: str,
    base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1",
    model: str = "deepseek-v3",
    timeout: int = 12,
) -> str:
    """
    调用 LLM 生成播报文案。
    返回模型输出文本，失败返回空字符串。
    注意：CodeBuddy Hook 超时为 15s，需在此之内完成 LLM + TTS。
    """
    if not api_key:
        return ""

    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Agent近期对话内容：\n{conversation_text}"},
        ],
        "max_tokens": 100,
        "temperature": 1.1,
        "stream": False,
        "enable_thinking": False,  # 关闭思考模式（Qwen3.5 等），加速响应
    }).encode("utf-8")

    req = urllib.request.Request(
        f"{base_url.rstrip('/')}/chat/completions",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result["choices"][0]["message"]["content"].strip()
    except urllib.error.HTTPError as e:
        return f"ERROR:HTTP {e.code} {e.reason}"
    except urllib.error.URLError as e:
        return f"ERROR:连接失败 {e.reason}"
    except TimeoutError:
        return "ERROR:请求超时"
    except Exception as e:
        return f"ERROR:{e}"


def verify_connection(
    api_key: str,
    base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1",
    model: str = "deepseek-v3",
    timeout: int = 20,
) -> tuple[bool, str]:
    """
    验证 LLM API 连通性。
    返回 (success: bool, message: str)。
    """
    if not api_key:
        return False, "API Key 为空"

    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "user", "content": "回复OK两个字"},
        ],
        "max_tokens": 10,
        "stream": False,
    }).encode("utf-8")

    req = urllib.request.Request(
        f"{base_url.rstrip('/')}/chat/completions",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            content = result["choices"][0]["message"]["content"].strip()
            return True, f"连接成功，模型回复: {content}"
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}: {e.reason}"
    except urllib.error.URLError as e:
        return False, f"连接失败: {e.reason}"
    except Exception as e:
        return False, f"错误: {e}"
