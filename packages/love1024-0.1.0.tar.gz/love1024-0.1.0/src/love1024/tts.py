"""语音合成与播放引擎 - 支持 edge-tts / Qwen3-TTS MLX / Qwen3-TTS 云端"""

import subprocess
import tempfile
import shutil
import os
import json
import urllib.request
import urllib.error
import base64


# ─────────────────────────────────────────────
# Qwen3-TTS MLX 单例管理（避免重复加载模型）
# ─────────────────────────────────────────────
_qwen3_model = None
_qwen3_model_id = None


def _get_qwen3_model(model_id: str):
    """延迟加载 Qwen3-TTS MLX 模型（单例，进程内复用）"""
    global _qwen3_model, _qwen3_model_id
    if _qwen3_model is not None and _qwen3_model_id == model_id:
        return _qwen3_model

    from mlx_audio.tts.utils import load_model as mlx_load_model
    _qwen3_model = mlx_load_model(model_id)
    _qwen3_model_id = model_id
    return _qwen3_model


def check_qwen3_tts() -> bool:
    """检查 Qwen3-TTS (MLX) 是否可用"""
    try:
        import mlx.core as mx
        if not mx.metal.is_available():
            return False
        import mlx_audio  # noqa: F401
        return True
    except ImportError:
        return False


def get_qwen3_speakers() -> list[dict]:
    """Qwen3-TTS CustomVoice 可用说话人"""
    return [
        {"name": "Vivian", "lang": "中文", "desc": "明亮年轻女性"},
        {"name": "Serena", "lang": "中文", "desc": "温柔女性"},
        {"name": "Uncle_Fu", "lang": "中文", "desc": "低沉成熟男性"},
        {"name": "Dylan", "lang": "中文", "desc": "北京口音男性"},
        {"name": "Eric", "lang": "中文", "desc": "四川口音男性"},
        {"name": "Ryan", "lang": "英文", "desc": "节奏感男性"},
        {"name": "Aiden", "lang": "英文", "desc": "阳光男性"},
        {"name": "Ono_Anna", "lang": "日文", "desc": "活泼女性"},
        {"name": "Sohee", "lang": "韩文", "desc": "温暖女性"},
    ]


QWEN3_MODELS = [
    {"name": "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit", "desc": "0.6B 8bit（轻量，推荐）"},
    {"name": "mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-8bit", "desc": "1.7B 8bit（更佳音质）"},
    {"name": "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-bf16", "desc": "0.6B bf16（高精度）"},
    {"name": "mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-bf16", "desc": "1.7B bf16（最佳音质）"},
]


# ─────────────────────────────────────────────
# edge-tts 引擎
# ─────────────────────────────────────────────

def speak_edge(
    text: str,
    voice: str = "zh-CN-XiaoyiNeural",
    rate: str = "+0%",
    pitch: str = "+0Hz",
    timeout: int = 15,
) -> bool:
    """使用 edge-tts 合成语音并用 afplay 播放（异步）"""
    tmp = tempfile.mktemp(suffix=".mp3")
    try:
        result = subprocess.run(
            ["edge-tts", "--voice", voice, "--rate", rate, "--pitch", pitch,
             "--text", text, "--write-media", tmp],
            timeout=timeout,
            capture_output=True,
        )
        if result.returncode == 0:
            subprocess.Popen(["afplay", tmp])
            return True
        return False
    except Exception:
        return False


def preview_edge(
    text: str,
    voice: str = "zh-CN-XiaoyiNeural",
    rate: str = "+0%",
    pitch: str = "+0Hz",
) -> bool:
    """edge-tts 预览（同步播放，等待完成）"""
    tmp = tempfile.mktemp(suffix=".mp3")
    try:
        result = subprocess.run(
            ["edge-tts", "--voice", voice, "--rate", rate, "--pitch", pitch,
             "--text", text, "--write-media", tmp],
            timeout=15,
            capture_output=True,
        )
        if result.returncode != 0:
            return False
        subprocess.run(["afplay", tmp], timeout=30)
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────
# Qwen3-TTS MLX 引擎
# ─────────────────────────────────────────────

def speak_qwen3(
    text: str,
    model_id: str = "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit",
    speaker: str = "Vivian",
    instruct: str = "",
) -> bool:
    """使用 Qwen3-TTS MLX 合成语音并播放（异步）"""
    try:
        import mlx.core as mx
        import numpy as np
        import soundfile as sf

        model = _get_qwen3_model(model_id)
        results = model.generate_custom_voice(
            text=text,
            speaker=speaker,
            instruct=instruct,
            verbose=False,
        )

        audio_parts = []
        for result in results:
            audio_parts.append(result.audio)

        if not audio_parts:
            return False

        audio = mx.concatenate(audio_parts, axis=0)
        audio_np = np.array(audio.tolist(), dtype=np.float32)

        tmp = tempfile.mktemp(suffix=".wav")
        sf.write(tmp, audio_np, model.sample_rate)
        subprocess.Popen(["afplay", tmp])
        return True
    except Exception:
        return False


def preview_qwen3(
    text: str,
    model_id: str = "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit",
    speaker: str = "Vivian",
    instruct: str = "",
) -> bool:
    """Qwen3-TTS MLX 预览（同步播放，等待完成）"""
    try:
        import mlx.core as mx
        import numpy as np
        import soundfile as sf

        model = _get_qwen3_model(model_id)
        results = model.generate_custom_voice(
            text=text,
            speaker=speaker,
            instruct=instruct,
            verbose=False,
        )

        audio_parts = []
        for result in results:
            audio_parts.append(result.audio)

        if not audio_parts:
            return False

        audio = mx.concatenate(audio_parts, axis=0)
        audio_np = np.array(audio.tolist(), dtype=np.float32)

        tmp = tempfile.mktemp(suffix=".wav")
        sf.write(tmp, audio_np, model.sample_rate)
        subprocess.run(["afplay", tmp], timeout=60)
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────
# Qwen3-TTS 云端引擎（阿里云百炼 API）
# ─────────────────────────────────────────────

# 云端可用音色列表
QWEN3_CLOUD_VOICES = [
    {"name": "Cherry", "desc": "芊悦 - 阳光积极亲切小姐姐", "gender": "女"},
    {"name": "Serena", "desc": "苏瑶 - 温柔小姐姐", "gender": "女"},
    {"name": "Chelsie", "desc": "千雪 - 二次元虚拟女友", "gender": "女"},
    {"name": "Momo", "desc": "茉兔 - 撒娇搞怪逗你开心", "gender": "女"},
    {"name": "Vivian", "desc": "十三 - 拽拽的可爱小暴躁", "gender": "女"},
    {"name": "Nini", "desc": "邻家妹妹 - 又软又黏的嗓音", "gender": "女"},
    {"name": "Mia", "desc": "乖小妹 - 温顺如春水", "gender": "女"},
    {"name": "Bella", "desc": "萌宝 - 小萝莉", "gender": "女"},
    {"name": "Bunny", "desc": "萌小姬 - 萌属性爆棚", "gender": "女"},
    {"name": "Stella", "desc": "少女阿月 - 甜到发腻的少女音", "gender": "女"},
    {"name": "Maia", "desc": "四月 - 知性与温柔的碰撞", "gender": "女"},
    {"name": "Seren", "desc": "小婉 - 温和舒缓助眠", "gender": "女"},
    {"name": "Elias", "desc": "墨讲师 - 严谨知性讲解", "gender": "女"},
    {"name": "Bellona", "desc": "燕铮莺 - 洪亮清晰有书评", "gender": "女"},
    {"name": "Ethan", "desc": "晨煦 - 阳光温暖有活力", "gender": "男"},
    {"name": "Moon", "desc": "月白 - 率性帅气", "gender": "男"},
    {"name": "Kai", "desc": "凯 - 耳朵的SPA", "gender": "男"},
    {"name": "Nofish", "desc": "不吃鱼 - 设计师慵懒男声", "gender": "男"},
    {"name": "Neil", "desc": "阿闻 - 专业新闻主持人", "gender": "男"},
    {"name": "Pip", "desc": "顽屁小孩 - 调皮童真", "gender": "男"},
    {"name": "Mochi", "desc": "沙小弥 - 聪明伶俐小大人", "gender": "男"},
    {"name": "Eldric Sage", "desc": "沧明子 - 沉稳睿智老者", "gender": "男"},
    {"name": "Vincent", "desc": "田叔 - 沙哑烟嗓", "gender": "男"},
    {"name": "Arthur", "desc": "徐大爷 - 质朴嗓音讲故事", "gender": "男"},
]


def _qwen3_cloud_synthesize(
    text: str,
    api_key: str,
    voice: str = "Cherry",
    instructions: str = "",
    model: str = "qwen3-tts-instruct-flash",
) -> str:
    """
    调用百炼 DashScope Qwen3-TTS API 合成语音。
    非实时模式：返回音频 URL，下载后保存为临时文件。
    返回临时音频文件路径，失败返回空字符串。
    """
    tmp = tempfile.mktemp(suffix=".wav")

    # 构建请求体
    input_data = {
        "text": text,
        "voice": voice,
    }
    if instructions:
        input_data["instructions"] = instructions
        input_data["optimize_instructions"] = True

    payload = json.dumps({
        "model": model,
        "input": input_data,
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        # 从响应中提取音频 URL
        audio_url = result.get("output", {}).get("audio", {}).get("url", "")
        if not audio_url:
            return ""

        # 下载音频文件
        audio_req = urllib.request.Request(audio_url)
        with urllib.request.urlopen(audio_req, timeout=30) as audio_resp:
            with open(tmp, "wb") as f:
                f.write(audio_resp.read())
        return tmp
    except Exception:
        return ""


def speak_qwen3_cloud(
    text: str,
    api_key: str,
    voice: str = "Cherry",
    instructions: str = "",
    model: str = "qwen3-tts-instruct-flash",
) -> bool:
    """Qwen3-TTS 云端合成并播放（异步）"""
    tmp = _qwen3_cloud_synthesize(text, api_key, voice, instructions, model)
    if tmp:
        subprocess.Popen(["afplay", tmp])
        return True
    return False


def preview_qwen3_cloud(
    text: str,
    api_key: str,
    voice: str = "Cherry",
    instructions: str = "",
    model: str = "qwen3-tts-instruct-flash",
) -> bool:
    """Qwen3-TTS 云端预览（同步播放）"""
    tmp = _qwen3_cloud_synthesize(text, api_key, voice, instructions, model)
    if tmp:
        subprocess.run(["afplay", tmp], timeout=60)
        return True
    return False


def check_qwen3_cloud(api_key: str) -> bool:
    """检查百炼 TTS API 是否可用"""
    if not api_key:
        return False
    try:
        payload = json.dumps({
            "model": "qwen3-tts-instruct-flash",
            "input": "测试",
            "voice": "Cherry",
            "response_format": "mp3",
        }).encode("utf-8")
        req = urllib.request.Request(
            "https://dashscope.aliyuncs.com/compatible-mode/v1/audio/speech",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status == 200
    except Exception:
        return False


# ─────────────────────────────────────────────
# 统一接口（根据引擎自动分发）
# ─────────────────────────────────────────────

def speak(
    text: str,
    voice: str = "zh-CN-XiaoyiNeural",
    rate: str = "+0%",
    pitch: str = "+0Hz",
    timeout: int = 15,
    engine: str = "edge-tts",
    qwen3_model: str = "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit",
    qwen3_speaker: str = "Vivian",
    qwen3_instruct: str = "",
    qwen3_cloud_api_key: str = "",
    qwen3_cloud_voice: str = "Cherry",
    qwen3_cloud_model: str = "qwen3-tts-instruct-flash",
) -> bool:
    """统一语音合成接口，根据 engine 参数分发到对应引擎"""
    if engine == "qwen3-tts":
        return speak_qwen3(text, qwen3_model, qwen3_speaker, qwen3_instruct)
    elif engine == "qwen3-cloud":
        return speak_qwen3_cloud(text, qwen3_cloud_api_key, qwen3_cloud_voice, qwen3_instruct, qwen3_cloud_model)
    else:
        return speak_edge(text, voice, rate, pitch, timeout)


def preview_voice(
    text: str,
    voice: str = "zh-CN-XiaoyiNeural",
    rate: str = "+0%",
    pitch: str = "+0Hz",
    engine: str = "edge-tts",
    qwen3_model: str = "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit",
    qwen3_speaker: str = "Vivian",
    qwen3_instruct: str = "",
    qwen3_cloud_api_key: str = "",
    qwen3_cloud_voice: str = "Cherry",
    qwen3_cloud_model: str = "qwen3-tts-instruct-flash",
) -> bool:
    """统一预览接口"""
    if engine == "qwen3-tts":
        return preview_qwen3(text, qwen3_model, qwen3_speaker, qwen3_instruct)
    elif engine == "qwen3-cloud":
        return preview_qwen3_cloud(text, qwen3_cloud_api_key, qwen3_cloud_voice, qwen3_instruct, qwen3_cloud_model)
    else:
        return preview_edge(text, voice, rate, pitch)


# ─────────────────────────────────────────────
# edge-tts 语音列表（保留原有功能）
# ─────────────────────────────────────────────

def list_voices(lang_filter: str = "") -> list[dict]:
    """列出 edge-tts 可用语音"""
    try:
        result = subprocess.run(
            ["edge-tts", "--list-voices"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            return []

        voices = []
        for line in result.stdout.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split()
            if len(parts) >= 2 and parts[0] == "Name:":
                voice_name = parts[1]
                if not lang_filter or voice_name.startswith(lang_filter):
                    voices.append({"name": voice_name})
        return voices
    except Exception:
        return []


def get_zh_ja_voices() -> list[str]:
    """获取中文和日语 edge-tts 语音列表"""
    try:
        result = subprocess.run(
            ["edge-tts", "--list-voices"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            return []

        voices = []
        for line in result.stdout.strip().split("\n"):
            parts = line.split()
            if len(parts) >= 2 and parts[0] == "Name:":
                name = parts[1]
                if name.startswith("zh-CN") or name.startswith("ja-JP"):
                    voices.append(name)
        return voices
    except Exception:
        return []


def check_edge_tts() -> bool:
    """检查 edge-tts 是否可用"""
    return shutil.which("edge-tts") is not None


def check_afplay() -> bool:
    """检查 afplay 是否可用（macOS）"""
    return shutil.which("afplay") is not None
