"""CLI 主入口和命令路由"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="love1024",
        description="🎉 Love1024 - 程序员鼓励师，CodeBuddy 会话语音播报助手",
    )
    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # setup - 交互式向导
    subparsers.add_parser("setup", help="运行交互式安装向导")

    # config - 修改配置
    subparsers.add_parser("config", help="查看/修改当前配置")

    # test - 测试语音
    test_parser = subparsers.add_parser("test", help="播放测试语音")
    test_parser.add_argument("--text", "-t", default="", help="自定义测试文本")

    # hook - Hook 运行时入口（CodeBuddy 调用）
    hook_parser = subparsers.add_parser("hook", help="CodeBuddy Stop Hook 入口（由 CodeBuddy 调用）")
    hook_parser.add_argument("--platform", "-p", default="", help="来源平台 (codebuddy/claude)")

    # log - 查看日志
    log_parser = subparsers.add_parser("log", help="查看播报历史日志")
    log_parser.add_argument("--count", "-n", type=int, default=20, help="显示条数")
    log_parser.add_argument("--clear", action="store_true", help="清空日志")

    # voices - 语音列表
    subparsers.add_parser("voices", help="查看可用的语音列表")

    # on/off - 开关语音播报
    subparsers.add_parser("on", help="开启语音播报")
    subparsers.add_parser("off", help="关闭语音播报")

    # install-hook - Hook 注册
    subparsers.add_parser("install-hook", help="获取 CodeBuddy Hook 注册配置片段")

    # uninstall - 卸载
    subparsers.add_parser("uninstall", help="清理所有配置和 Hook")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return

    if args.command == "setup":
        _cmd_setup()
    elif args.command == "config":
        _cmd_config()
    elif args.command == "test":
        _cmd_test(args.text)
    elif args.command == "hook":
        _cmd_hook(args.platform)
    elif args.command == "log":
        _cmd_log(args.count, args.clear)
    elif args.command == "voices":
        _cmd_voices()
    elif args.command == "on":
        _cmd_toggle(True)
    elif args.command == "off":
        _cmd_toggle(False)
    elif args.command == "install-hook":
        _cmd_install_hook()
    elif args.command == "uninstall":
        _cmd_uninstall()


def _cmd_setup():
    from love1024.wizard import run_wizard
    run_wizard()


def _cmd_config():
    from rich.console import Console
    from rich.syntax import Syntax
    from love1024.config import load_config, CONFIG_PATH, config_exists
    from love1024.wizard import run_partial_config, run_wizard

    console = Console()

    if not config_exists():
        console.print("[yellow]尚未配置，请先运行: love1024 setup[/yellow]")
        return

    run_partial_config()


def _cmd_test(text: str = ""):
    from rich.console import Console
    from love1024.config import load_config, config_exists
    from love1024.tts import preview_voice

    console = Console()

    if not config_exists():
        console.print("[yellow]尚未配置，请先运行: love1024 setup[/yellow]")
        return

    cfg = load_config()
    owner = cfg.get("personality", {}).get("owner_name", "主人")
    engine = cfg.get("voice", {}).get("tts_engine", "edge-tts")

    if not text:
        text = f"{owner}，你今天的代码写得太棒了！继续加油！"

    if engine == "qwen3-tts":
        qwen3_model = cfg.get("voice", {}).get("qwen3_model", "")
        qwen3_speaker = cfg.get("voice", {}).get("qwen3_speaker", "Vivian")
        console.print(f"[dim]引擎: Qwen3-TTS MLX | 说话人: {qwen3_speaker} | 文本: {text}[/dim]")
        console.print("[dim]正在生成...[/dim]")
        ok = preview_voice(
            text,
            engine="qwen3-tts",
            qwen3_model=qwen3_model,
            qwen3_speaker=qwen3_speaker,
        )
    elif engine == "qwen3-cloud":
        cloud_voice = cfg.get("voice", {}).get("qwen3_cloud_voice", "Cherry")
        cloud_key = cfg.get("voice", {}).get("qwen3_cloud_api_key", "")
        console.print(f"[dim]引擎: Qwen3-TTS 云端 | 音色: {cloud_voice} | 文本: {text}[/dim]")
        console.print("[dim]正在生成...[/dim]")
        ok = preview_voice(
            text,
            engine="qwen3-cloud",
            qwen3_cloud_api_key=cloud_key,
            qwen3_cloud_voice=cloud_voice,
        )
    else:
        voice = cfg.get("voice", {}).get("zh_voice", "zh-CN-XiaoyiNeural")
        rate = cfg.get("voice", {}).get("zh_rate", "+0%")
        pitch = cfg.get("voice", {}).get("zh_pitch", "+0Hz")
        console.print(f"[dim]引擎: edge-tts | 语音: {voice} | 文本: {text}[/dim]")
        console.print("[dim]正在生成...[/dim]")
        ok = preview_voice(text, voice, rate, pitch)

    if ok:
        console.print("[green]✅ 播放完成！[/green]")
    else:
        console.print("[red]❌ 播放失败，请检查 TTS 引擎配置[/red]")


def _cmd_hook(platform: str = ""):
    from love1024.hook import run_hook
    sys.exit(run_hook(platform=platform) or 0)


def _cmd_log(count: int, clear: bool):
    from rich.console import Console
    from rich.table import Table
    from love1024.logger import read_recent_logs, clear_log

    console = Console()

    if clear:
        clear_log()
        console.print("[green]日志已清空[/green]")
        return

    logs = read_recent_logs(count)
    if not logs:
        console.print("[dim]暂无播报日志[/dim]")
        return

    table = Table(title=f"最近 {len(logs)} 条播报记录", show_lines=True)
    table.add_column("时间", style="dim", width=19, no_wrap=True)
    table.add_column("场景", no_wrap=True)
    table.add_column("文案", style="cyan", ratio=2)
    table.add_column("语气", style="green", ratio=1)
    table.add_column("语音", style="dim", no_wrap=True)

    for log in logs:
        time = log.get("time", "")
        scene = log.get("scene", log.get("event", ""))
        text = log.get("text", log.get("llm_output", log.get("error", "")))
        engine = log.get("tts_engine", "")

        # 语气列：Qwen3 显示完整 instruct，edge-tts 显示 rate/pitch
        instruct = log.get("instruct", "")
        if instruct:
            emotion = instruct
        else:
            rate = log.get("rate", "")
            pitch = log.get("pitch", "")
            emotion = f"{rate} {pitch}".strip() if (rate or pitch) else ""

        voice = log.get("voice", "")

        # 根据场景类型着色
        if scene == "error":
            text_display = f"[red]❌ {text}[/red]"
            scene_display = f"[red]{scene}[/red]"
        elif scene == "silent":
            text_display = f"[dim]{text if text else '(静默)'}[/dim]"
            scene_display = f"[dim]{scene}[/dim]"
        else:
            text_display = f"[cyan]{text}[/cyan]" if text else ""
            scene_display = scene

        table.add_row(time, scene_display, text_display, emotion, voice)

    console.print(table)


def _cmd_voices():
    from rich.console import Console
    from rich.table import Table
    from love1024.tts import get_zh_ja_voices

    console = Console()
    console.print("[bold]可用的中文/日语语音：[/bold]\n")

    voices = get_zh_ja_voices()
    if not voices:
        console.print("[yellow]无法获取语音列表，请检查 edge-tts 是否安装[/yellow]")
        return

    table = Table()
    table.add_column("语音名称", style="cyan")
    table.add_column("语言", width=8)
    for v in voices:
        lang = "中文" if v.startswith("zh-") else "日语"
        table.add_row(v, lang)

    console.print(table)


def _cmd_toggle(enable: bool):
    from rich.console import Console
    from love1024.config import load_config, save_config, config_exists

    console = Console()

    if not config_exists():
        console.print("[yellow]尚未配置，请先运行: love1024 setup[/yellow]")
        return

    cfg = load_config()
    current = cfg.get("behavior", {}).get("enabled", True)

    if enable == current:
        status = "[green]开启[/green]" if enable else "[dim]关闭[/dim]"
        console.print(f"语音播报已经是 {status} 状态，无需操作。")
        return

    cfg["behavior"]["enabled"] = enable
    save_config(cfg)

    if enable:
        console.print("[bold green]✅ 语音播报已开启！[/bold green]")
    else:
        console.print("[bold yellow]🔇 语音播报已关闭，鼓励师进入静默模式。[/bold yellow]")
        console.print("[dim]重新开启请运行: love1024 on[/dim]")


def _cmd_install_hook():
    from rich.console import Console
    from rich.table import Table
    from rich import box
    from love1024.config import detect_installed_platforms, register_hook

    console = Console()

    platforms = detect_installed_platforms()
    installed = [p for p in platforms if p["installed"]]

    if not installed:
        console.print("[yellow]未检测到任何支持的 AI 编程工具。[/yellow]")
        console.print("[dim]支持：CodeBuddy IDE/CLI、Claude Code/CLI[/dim]")
        return

    # 显示检测结果
    table = Table(title="🔍 检测到的 AI 编程工具", box=box.SIMPLE)
    table.add_column("工具", style="cyan")
    table.add_column("状态", width=12)
    table.add_column("Hook", width=12)

    need_register = False
    for p in platforms:
        if p["installed"]:
            hook_status = "[green]✅ 已注册[/green]" if p["hooked"] else "[yellow]⚠️ 未注册[/yellow]"
            table.add_row(p["name"], "[green]已安装[/green]", hook_status)
            if not p["hooked"]:
                need_register = True
        else:
            table.add_row(p["name"], "[dim]未安装[/dim]", "[dim]-[/dim]")

    console.print(table)

    if not need_register:
        console.print("\n[bold green]✅ 所有平台 Hook 已注册，无需操作！[/bold green]")
        return

    # 一键注册所有未注册的平台
    console.print()
    for p in installed:
        if not p["hooked"]:
            ok, msg = register_hook(p["id"])
            if ok:
                console.print(f"  [green]{msg}[/green]")
            else:
                console.print(f"  [red]{msg}[/red]")

    console.print("\n[dim]请重启对应的 AI 编程工具使 Hook 生效。[/dim]")


def _cmd_uninstall():
    from rich.console import Console
    from InquirerPy import inquirer
    from love1024.config import CONFIG_DIR, CONFIG_PATH
    from love1024.logger import LOG_PATH
    import shutil, os

    console = Console()
    confirm = inquirer.confirm(
        message="确定要卸载 Love1024？将删除所有配置和日志。",
        default=False,
    ).execute()

    if not confirm:
        console.print("[yellow]已取消[/yellow]")
        return

    # 删除配置目录
    if os.path.exists(CONFIG_DIR):
        shutil.rmtree(CONFIG_DIR)
        console.print(f"[green]已删除配置目录: {CONFIG_DIR}[/green]")

    # 删除日志
    if os.path.exists(LOG_PATH):
        os.remove(LOG_PATH)
        console.print(f"[green]已删除日志: {LOG_PATH}[/green]")

    console.print()
    console.print("[yellow]提示：请手动从 ~/.codebuddy/settings.json 中移除 Hook 配置[/yellow]")
    console.print("[yellow]提示：运行 `pip uninstall codebuddy-love1024` 移除包[/yellow]")
    console.print()
    console.print("[dim]感谢使用 Love1024，期待下次相见！👋[/dim]")


def _mask_config(cfg: dict) -> dict:
    """隐藏敏感信息"""
    import copy
    masked = copy.deepcopy(cfg)
    key = masked.get("llm", {}).get("api_key", "")
    if key and len(key) > 8:
        masked["llm"]["api_key"] = key[:4] + "****" + key[-4:]
    return masked


if __name__ == "__main__":
    main()
