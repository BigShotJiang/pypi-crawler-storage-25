"""Love1024 - 程序员鼓励师，CodeBuddy 会话语音播报助手"""

__version__ = "0.1.0"
