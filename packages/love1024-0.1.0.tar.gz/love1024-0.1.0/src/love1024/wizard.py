"""交互式安装向导 - 彩色终端 TUI 向导流程"""

from typing import Optional
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box
from InquirerPy import inquirer
from InquirerPy.separator import Separator

from love1024.config import (
    load_config, save_config, config_exists, old_config_exists,
    migrate_old_config, get_default_config, check_hook_registered,
    get_hook_register_command,
    detect_installed_platforms, register_hook, register_all_hooks,
)
from love1024.presets import get_all_presets, load_preset
from love1024.llm import verify_connection
from love1024.tts import (
    preview_voice, check_edge_tts, check_afplay, get_zh_ja_voices,
    check_qwen3_tts, get_qwen3_speakers, QWEN3_MODELS,
    QWEN3_CLOUD_VOICES,
)

console = Console()

BANNER = r"""
[bold magenta]
  _                    _  ___ ____  _  _
 | |    _____   _____ / |/ _ \___ \| || |
 | |   / _ \ \ / / _ \| | | | |__) | || |_
 | |__| (_) \ V /  __/| | |_| / __/|__   _|
 |_____\___/ \_/ \___|_|\___/_____|  |_|
[/bold magenta]
[dim]🎉 程序员鼓励师 - CodeBuddy 会话语音播报助手[/dim]
"""


def run_wizard():
    """运行完整的安装向导"""
    console.print(BANNER)
    console.print()

    # 幂等检查
    if config_exists():
        action = _handle_existing_config()
        if action == "cancel":
            console.print("[yellow]已取消。[/yellow]")
            return
        elif action == "keep":
            console.print("[green]保留现有配置，跳至 Hook 注册检查。[/green]")
            _step_hook_registration()
            _step_finish()
            return
        # action == "reconfigure" -> 继续走完整向导

    # 旧版迁移检查
    cfg = None
    if old_config_exists():
        cfg = _handle_old_config_migration()

    if cfg is None:
        cfg = get_default_config()

    console.print(Panel("开始配置你的程序员鼓励师！", style="bold cyan", box=box.DOUBLE))
    console.print()

    # Step 1: 风格选择
    cfg = _step_style(cfg)

    # Step 2: 称呼设置
    cfg = _step_owner_name(cfg)

    # Step 3: LLM API 配置
    cfg = _step_llm_api(cfg)

    # Step 4: 语音选择
    cfg = _step_voice(cfg)

    # Step 5: SILENT 力度
    cfg = _step_silent_level(cfg)

    # Step 6: 保存配置
    save_config(cfg)
    console.print()
    console.print("[bold green]✅ 配置已保存！[/bold green]")

    # Step 7: Hook 注册
    _step_hook_registration()

    # Step 8: 测试播放
    _step_test_voice(cfg)

    # Step 9: 完成
    _step_finish()


def _handle_existing_config() -> str:
    """处理已有配置的情况"""
    console.print(Panel(
        "[yellow]检测到已有配置文件[/yellow]\n"
        "~/.config/love1024/config.toml",
        title="⚠️ 已安装",
        style="yellow",
    ))
    action = inquirer.select(
        message="请选择操作：",
        choices=[
            {"name": "📝 重新配置（备份旧配置后重走向导）", "value": "reconfigure"},
            {"name": "🔗 保留配置，仅检查 Hook 注册", "value": "keep"},
            {"name": "❌ 取消", "value": "cancel"},
        ],
    ).execute()
    if action == "reconfigure":
        # 备份旧配置
        import shutil
        import datetime
        from love1024.config import CONFIG_PATH
        backup = CONFIG_PATH + f".bak.{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
        shutil.copy2(CONFIG_PATH, backup)
        console.print(f"[dim]旧配置已备份到: {backup}[/dim]")
    return action


def _handle_old_config_migration() -> Optional[dict]:
    """处理旧版配置迁移"""
    console.print(Panel(
        "[yellow]检测到旧版配置文件[/yellow]\n"
        "~/.codebuddy/hooks/.voice_hook_config",
        title="🔄 迁移提示",
        style="yellow",
    ))
    migrate = inquirer.confirm(
        message="是否自动迁移旧配置到新格式？",
        default=True,
    ).execute()
    if migrate:
        cfg = migrate_old_config()
        if cfg:
            console.print("[green]✅ 旧配置已迁移，以下为迁移后的默认值（可在后续步骤中修改）[/green]")
            return cfg
        else:
            console.print("[yellow]迁移失败，将使用默认配置[/yellow]")
    return None


def _step_style(cfg: dict) -> dict:
    """Step 1: 选择鼓励师风格"""
    console.print("\n[bold cyan]Step 1/5[/bold cyan] 选择鼓励师风格\n")

    presets = get_all_presets()
    choices = []
    for preset in presets:
        meta = preset.get("meta", {})
        choices.append({
            "name": f"{meta.get('display_name', '?')}  {meta.get('description', '')}",
            "value": meta.get("name", ""),
        })
    choices.append(Separator())
    choices.append({"name": "🎲 随机风格 - 每次播报随机切换风格，永远充满新鲜感", "value": "_random"})
    choices.append({"name": "✏️  自定义风格描述", "value": "_custom"})

    style = inquirer.select(
        message="选择你喜欢的风格：",
        choices=choices,
        default=cfg.get("personality", {}).get("style", "sweet"),
    ).execute()

    if style == "_random":
        cfg["personality"]["style"] = "_random"
        cfg["personality"]["custom_prompt"] = ""
        # 展示所有可用风格
        names = [p.get("meta", {}).get("display_name", "?") for p in presets]
        console.print(f"[green]已选择: 🎲 随机风格模式[/green]")
        console.print(f"[dim]每次播报将从以下风格中随机选择: {', '.join(names)}[/dim]")
    elif style == "_custom":
        custom = inquirer.text(
            message="输入自定义风格描述（用于 System Prompt）：",
            default="温柔甜美，偶尔搞怪",
        ).execute()
        cfg["personality"]["style"] = "sweet"  # 降级用 sweet 的模板结构
        cfg["personality"]["custom_prompt"] = custom
        console.print(f"[green]已设置自定义风格: {custom}[/green]")
    else:
        cfg["personality"]["style"] = style
        cfg["personality"]["custom_prompt"] = ""
        # 显示预览
        preset = load_preset(style)
        if preset:
            meta = preset.get("meta", {})
            console.print(f"[green]已选择: {meta.get('display_name', style)}[/green]")
            console.print(f"[dim]预览: \"{meta.get('preview', '')}\"[/dim]")

    return cfg


def _step_owner_name(cfg: dict) -> dict:
    """Step 2: 设置称呼"""
    console.print("\n[bold cyan]Step 2/5[/bold cyan] 设置称呼\n")

    name_zh = inquirer.text(
        message="中文称呼（如 主人、小哥哥、大佬）：",
        default=cfg.get("personality", {}).get("owner_name", "主人"),
    ).execute()

    name_ja = inquirer.text(
        message="日语称呼（如 ご主人様、先輩、マスター）：",
        default=cfg.get("personality", {}).get("owner_name_ja", "ご主人様"),
    ).execute()

    zh_ratio = inquirer.number(
        message="中文播报比例（0-100%，剩余为日语）：",
        default=cfg.get("personality", {}).get("zh_ratio", 90),
        min_allowed=0,
        max_allowed=100,
    ).execute()

    cfg["personality"]["owner_name"] = name_zh
    cfg["personality"]["owner_name_ja"] = name_ja
    cfg["personality"]["zh_ratio"] = int(zh_ratio)

    console.print(f"[green]称呼设置完成: {name_zh} / {name_ja}（中文 {zh_ratio}%）[/green]")
    return cfg


def _step_llm_api(cfg: dict) -> dict:
    """Step 3: 配置大模型 API"""
    console.print("\n[bold cyan]Step 3/5[/bold cyan] 配置大模型 API\n")

    # 预设 API 地址
    api_provider = inquirer.select(
        message="选择 API 服务商：",
        choices=[
            {"name": "🟠 阿里云百炼（推荐，新用户有免费额度）", "value": "https://dashscope.aliyuncs.com/compatible-mode/v1"},
            {"name": "🟢 DeepSeek 官方", "value": "https://api.deepseek.com/v1"},
            {"name": "✏️  自定义 Base URL（支持任何 OpenAI 兼容 API）", "value": "_custom"},
        ],
        default="https://dashscope.aliyuncs.com/compatible-mode/v1",
    ).execute()

    if api_provider == "_custom":
        base_url = inquirer.text(
            message="输入 API Base URL：",
            default=cfg.get("llm", {}).get("base_url", ""),
        ).execute()
    else:
        base_url = api_provider

    if base_url == "https://dashscope.aliyuncs.com/compatible-mode/v1":
        console.print(
            "\n[bold yellow]💡 阿里云百炼 API Key 获取地址：[/bold yellow]\n"
            "[bold cyan]https://bailian.console.aliyun.com/#/api-key[/bold cyan]\n"
            "[dim]登录阿里云 → 进入百炼控制台 → API Key 管理 → 创建 Key[/dim]\n"
        )
    elif base_url == "https://api.deepseek.com/v1":
        console.print(
            "\n[bold yellow]💡 DeepSeek API Key 获取地址：[/bold yellow]\n"
            "[bold cyan]https://platform.deepseek.com/api_keys[/bold cyan]\n"
            "[dim]登录 DeepSeek → API Keys → 创建 Key[/dim]\n"
        )

    api_key = inquirer.secret(
        message="输入 API Key：",
        default=cfg.get("llm", {}).get("api_key", ""),
    ).execute()

    # 根据服务商推荐默认模型名
    default_model = cfg.get("llm", {}).get("model", "deepseek-v3.2")
    if base_url == "https://dashscope.aliyuncs.com/compatible-mode/v1":
        default_model = "deepseek-v3"

    model = inquirer.text(
        message="模型名称：",
        default=default_model,
    ).execute()

    cfg["llm"]["base_url"] = base_url
    cfg["llm"]["api_key"] = api_key
    cfg["llm"]["model"] = model

    # 验证连通性
    console.print("[dim]正在验证 API 连通性...[/dim]")
    ok, msg = verify_connection(api_key, base_url, model)
    if ok:
        console.print(f"[bold green]✅ {msg}[/bold green]")
    else:
        console.print(f"[bold red]❌ {msg}[/bold red]")
        retry = inquirer.confirm(
            message="API 验证失败，是否继续（可以稍后在 config 中修改）？",
            default=True,
        ).execute()
        if not retry:
            return _step_llm_api(cfg)  # 重新配置

    return cfg


def _step_voice(cfg: dict) -> dict:
    """Step 4: 语音选择（支持引擎切换）"""
    console.print("\n[bold cyan]Step 4/5[/bold cyan] 语音选择\n")

    # 检测可用引擎
    has_edge = check_edge_tts()
    has_qwen3 = check_qwen3_tts()

    engine_choices = []
    if has_edge:
        engine_choices.append({"name": "🌐 edge-tts（在线，需联网，音色多）", "value": "edge-tts"})
    if has_qwen3:
        engine_choices.append({"name": "🍎 Qwen3-TTS MLX（本地离线，Apple Silicon 加速，情感丰富）", "value": "qwen3-tts"})
    engine_choices.append({"name": "☁️  Qwen3-TTS 云端（阿里云百炼，任何电脑，情感丰富）", "value": "qwen3-cloud"})

    if len(engine_choices) == 1:
        engine = engine_choices[0]["value"]
        console.print(f"[dim]使用 TTS 引擎: {engine}[/dim]")
    else:
        current_engine = cfg.get("voice", {}).get("tts_engine", "edge-tts")
        engine = inquirer.select(
            message="选择语音合成引擎：",
            choices=engine_choices,
            default=current_engine,
        ).execute()

    cfg["voice"]["tts_engine"] = engine

    if engine == "qwen3-tts":
        cfg = _step_voice_qwen3(cfg)
    elif engine == "qwen3-cloud":
        cfg = _step_voice_qwen3_cloud(cfg)
    else:
        cfg = _step_voice_edge(cfg)

    return cfg


def _step_voice_qwen3_cloud(cfg: dict) -> dict:
    """Qwen3-TTS 云端语音配置"""
    owner = cfg.get("personality", {}).get("owner_name", "主人")

    # API Key
    current_key = cfg.get("voice", {}).get("qwen3_cloud_api_key", "")
    if not current_key:
        console.print(
            "\n[bold yellow]💡 百炼 TTS API Key 获取地址：[/bold yellow]\n"
            "[bold cyan]https://bailian.console.aliyun.com/#/api-key[/bold cyan]\n"
            "[dim]可复用你的百炼 LLM API Key，TTS 和 LLM 用同一个 Key[/dim]\n"
        )
    api_key = inquirer.secret(
        message="输入百炼 API Key（用于 TTS 语音合成）：",
        default=current_key,
    ).execute()
    cfg["voice"]["qwen3_cloud_api_key"] = api_key

    # 选择音色
    voice_choices = [
        {"name": f"{v['name']}  ({v['gender']} - {v['desc']})", "value": v["name"]}
        for v in QWEN3_CLOUD_VOICES
    ]
    current_voice = cfg.get("voice", {}).get("qwen3_cloud_voice", "Cherry")

    console.print("\n[dim]提示：选择后会立即播放试听，不满意可以重新选。[/dim]\n")
    while True:
        cloud_voice = inquirer.select(
            message="选择云端音色（选完立即试听）：",
            choices=voice_choices,
            default=current_voice,
        ).execute()
        console.print("[dim]正在生成语音...[/dim]")
        ok = preview_voice(
            f"{owner}，太棒了，代码写得好棒！继续加油哦！",
            engine="qwen3-cloud",
            qwen3_cloud_api_key=api_key,
            qwen3_cloud_voice=cloud_voice,
        )
        if not ok:
            console.print("[red]生成失败，请检查 API Key 是否正确[/red]")
            retry = inquirer.confirm(message="重新输入 API Key？", default=True).execute()
            if retry:
                api_key = inquirer.secret(message="输入百炼 API Key：").execute()
                cfg["voice"]["qwen3_cloud_api_key"] = api_key
                continue
            break
        satisfied = inquirer.confirm(message="满意这个声音吗？", default=True).execute()
        if satisfied:
            break
        console.print("[dim]好的，重新选一个试试～[/dim]\n")

    cfg["voice"]["qwen3_cloud_voice"] = cloud_voice
    console.print(f"[green]语音设置完成: Qwen3-TTS 云端 / {cloud_voice}[/green]")
    return cfg


def _step_voice_qwen3(cfg: dict) -> dict:
    """Qwen3-TTS 语音配置"""
    owner = cfg.get("personality", {}).get("owner_name", "主人")

    # 选择模型
    model_choices = [
        {"name": f"{m['desc']}  ({m['name'].split('/')[-1]})", "value": m["name"]}
        for m in QWEN3_MODELS
    ]
    current_model = cfg.get("voice", {}).get(
        "qwen3_model", "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit"
    )
    qwen3_model = inquirer.select(
        message="选择 Qwen3-TTS 模型：",
        choices=model_choices,
        default=current_model,
    ).execute()
    cfg["voice"]["qwen3_model"] = qwen3_model

    # 选择说话人
    speakers = get_qwen3_speakers()
    speaker_choices = [
        {"name": f"{s['name']}  ({s['lang']} - {s['desc']})", "value": s["name"]}
        for s in speakers
    ]
    current_speaker = cfg.get("voice", {}).get("qwen3_speaker", "Vivian")

    console.print("\n[dim]提示：选择后会立即播放试听（首次需下载模型），不满意可以重新选。[/dim]\n")
    while True:
        speaker = inquirer.select(
            message="选择说话人（选完立即试听）：",
            choices=speaker_choices,
            default=current_speaker,
        ).execute()
        console.print("[dim]正在生成语音（首次加载模型可能较慢）...[/dim]")
        preview_voice(
            f"{owner}，太棒了，代码写得好棒！继续加油哦！",
            engine="qwen3-tts",
            qwen3_model=qwen3_model,
            qwen3_speaker=speaker,
        )
        satisfied = inquirer.confirm(message="满意这个声音吗？", default=True).execute()
        if satisfied:
            break
        console.print("[dim]好的，重新选一个试试～[/dim]\n")

    cfg["voice"]["qwen3_speaker"] = speaker
    console.print(f"[green]语音设置完成: Qwen3-TTS / {speaker}[/green]")
    return cfg


def _step_voice_edge(cfg: dict) -> dict:
    """edge-tts 语音配置（原有逻辑）"""

    if not check_edge_tts():
        console.print("[yellow]⚠️ edge-tts 未安装，正在安装...[/yellow]")
        import subprocess
        subprocess.run(["pip", "install", "edge-tts"], capture_output=True)

    if not check_afplay():
        console.print("[red]⚠️ afplay 不可用，语音播放可能无法正常工作（仅 macOS 支持）[/red]")

    owner = cfg.get("personality", {}).get("owner_name", "主人")

    # 中文语音选择 + 试听循环
    zh_voices = [
        "zh-CN-XiaoxiaoNeural", "zh-CN-XiaoyiNeural",
        "zh-CN-YunjianNeural", "zh-CN-YunxiNeural",
        "zh-CN-YunxiaNeural", "zh-CN-YunyangNeural",
        "zh-CN-liaoning-XiaobeiNeural", "zh-CN-shaanxi-XiaoniNeural",
    ]
    console.print("[dim]提示：选择后会立即播放试听，不满意可以重新选。[/dim]\n")
    while True:
        zh_voice = inquirer.select(
            message="选择中文语音（选完立即试听）：",
            choices=zh_voices,
            default=cfg.get("voice", {}).get("zh_voice", "zh-CN-XiaoyiNeural"),
        ).execute()
        console.print("[dim]正在生成语音...[/dim]")
        preview_voice(f"{owner}，太棒了，代码写得好棒！继续加油哦！", zh_voice)
        satisfied = inquirer.confirm(message="满意这个声音吗？", default=True).execute()
        if satisfied:
            break
        console.print("[dim]好的，重新选一个试试～[/dim]\n")

    # 日语语音选择 + 试听循环
    ja_voices = ["ja-JP-NanamiNeural", "ja-JP-KeitaNeural"]
    console.print()
    while True:
        ja_voice = inquirer.select(
            message="选择日语语音（选完立即试听）：",
            choices=ja_voices,
            default=cfg.get("voice", {}).get("ja_voice", "ja-JP-NanamiNeural"),
        ).execute()
        console.print("[dim]正在生成语音...[/dim]")
        owner_ja = cfg.get("personality", {}).get("owner_name_ja", "ご主人様")
        preview_voice(f"{owner_ja}、すごいですね！コードが素晴らしい！", ja_voice)
        satisfied = inquirer.confirm(message="满意这个声音吗？", default=True).execute()
        if satisfied:
            break
        console.print("[dim]好的，重新选一个试试～[/dim]\n")

    cfg["voice"]["zh_voice"] = zh_voice
    cfg["voice"]["ja_voice"] = ja_voice

    # 应用预设的语音参数（随机模式用 sweet 默认参数）
    style = cfg.get("personality", {}).get("style", "sweet")
    preset_style = "sweet" if style == "_random" else style
    preset = load_preset(preset_style)
    if preset and "voice" in preset:
        pv = preset["voice"]
        cfg["voice"]["zh_rate"] = pv.get("zh_rate", "+0%")
        cfg["voice"]["zh_pitch"] = pv.get("zh_pitch", "+0Hz")
        cfg["voice"]["ja_rate"] = pv.get("ja_rate", "-20%")
        cfg["voice"]["ja_pitch"] = pv.get("ja_pitch", "+8Hz")

    console.print(f"[green]语音设置完成: {zh_voice} / {ja_voice}[/green]")
    return cfg


def _step_silent_level(cfg: dict) -> dict:
    """Step 5: SILENT 力度"""
    console.print("\n[bold cyan]Step 5/5[/bold cyan] 静默力度设置\n")

    level = inquirer.select(
        message="选择静默力度（控制播报频率）：",
        choices=[
            {"name": "🗣️  话唠模式 - 几乎每次回复都播报", "value": 1},
            {"name": "⚖️  适中模式 - 仅在任务完成时播报（推荐）", "value": 2},
            {"name": "🤫 安静模式 - 仅在重要里程碑时播报", "value": 3},
            {"name": "🎯 专注模式 - 仅在明确完成时播报", "value": 4},
        ],
        default=cfg.get("behavior", {}).get("silent_level", 2),
    ).execute()

    cfg["behavior"]["silent_level"] = level
    labels = {1: "话唠", 2: "适中", 3: "安静", 4: "专注"}
    console.print(f"[green]静默力度: {labels.get(level, '适中')}[/green]")
    return cfg


def _step_hook_registration():
    """Hook 注册引导 - 自动检测多平台并一键注册"""
    console.print()
    from rich.table import Table

    platforms = detect_installed_platforms()
    installed = [p for p in platforms if p["installed"]]

    if not installed:
        console.print("[yellow]未检测到任何支持的 AI 编程工具。[/yellow]")
        console.print("[dim]支持的工具：CodeBuddy IDE/CLI、Claude Code/CLI[/dim]")
        return

    # 显示检测结果
    table = Table(title="🔍 检测到的 AI 编程工具", box=box.SIMPLE)
    table.add_column("工具", style="cyan")
    table.add_column("状态", width=12)
    table.add_column("Hook", width=12)

    all_hooked = True
    for p in platforms:
        if p["installed"]:
            hook_status = "[green]✅ 已注册[/green]" if p["hooked"] else "[yellow]⚠️ 未注册[/yellow]"
            table.add_row(p["name"], "[green]已安装[/green]", hook_status)
            if not p["hooked"]:
                all_hooked = False
        else:
            table.add_row(p["name"], "[dim]未安装[/dim]", "[dim]-[/dim]")

    console.print(table)

    if all_hooked:
        console.print("\n[bold green]✅ 所有平台 Hook 已注册，无需操作！[/bold green]")
        return

    # 一键注册
    console.print()
    do_register = inquirer.confirm(
        message="为所有已安装的工具注册 Hook？",
        default=True,
    ).execute()

    if not do_register:
        console.print("[dim]跳过 Hook 注册，以后可运行 `love1024 install-hook` 注册[/dim]")
        return

    for p in installed:
        if not p["hooked"]:
            ok, msg = register_hook(p["id"])
            if ok:
                console.print(f"  [green]{msg}[/green]")
            else:
                console.print(f"  [red]{msg}[/red]")

    console.print("\n[dim]注册完成后请重启对应的 AI 编程工具使 Hook 生效。[/dim]")


def _step_test_voice(cfg: dict):
    """测试语音播放"""
    console.print()
    do_test = inquirer.confirm(message="🎤 播放测试语音？", default=True).execute()
    if do_test:
        owner = cfg.get("personality", {}).get("owner_name", "主人")
        engine = cfg.get("voice", {}).get("tts_engine", "edge-tts")
        text = f"{owner}，love1024 安装成功啦！以后每次完成任务都会鼓励你哦！"

        console.print("[dim]正在生成语音...[/dim]")
        if engine == "qwen3-tts":
            ok = preview_voice(
                text,
                engine="qwen3-tts",
                qwen3_model=cfg.get("voice", {}).get("qwen3_model", ""),
                qwen3_speaker=cfg.get("voice", {}).get("qwen3_speaker", "Vivian"),
            )
        elif engine == "qwen3-cloud":
            ok = preview_voice(
                text,
                engine="qwen3-cloud",
                qwen3_cloud_api_key=cfg.get("voice", {}).get("qwen3_cloud_api_key", ""),
                qwen3_cloud_voice=cfg.get("voice", {}).get("qwen3_cloud_voice", "Cherry"),
            )
        else:
            voice = cfg.get("voice", {}).get("zh_voice", "zh-CN-XiaoyiNeural")
            rate = cfg.get("voice", {}).get("zh_rate", "+0%")
            pitch = cfg.get("voice", {}).get("zh_pitch", "+0Hz")
            ok = preview_voice(text, voice, rate, pitch)

        if ok:
            console.print("[green]🎵 播放完成！[/green]")
        else:
            console.print("[red]播放失败，请检查 TTS 引擎配置[/red]")


def _step_finish():
    """完成总结"""
    console.print()
    table = Table(title="🎉 安装完成！", box=box.ROUNDED, style="green")
    table.add_column("项目", style="cyan")
    table.add_column("状态", style="green")
    table.add_row("配置文件", "~/.config/love1024/config.toml ✅")

    # 多平台 Hook 状态
    platforms = detect_installed_platforms()
    hook_parts = []
    for p in platforms:
        if p["installed"]:
            status = "✅" if p["hooked"] else "⚠️"
            hook_parts.append(f"{status} {p['name']}")
    table.add_row("Hook 注册", " | ".join(hook_parts) if hook_parts else "⚠️ 未检测到工具")

    edge_ok = check_edge_tts()
    qwen3_ok = check_qwen3_tts()
    engines = []
    if edge_ok:
        engines.append("edge-tts")
    if qwen3_ok:
        engines.append("Qwen3-TTS MLX")
    engines.append("Qwen3-TTS 云端")
    table.add_row("语音引擎", f"✅ {' / '.join(engines)}")
    console.print(table)

    console.print()
    console.print("[bold]常用命令：[/bold]")
    console.print("  [cyan]love1024 test[/cyan]          测试语音播放")
    console.print("  [cyan]love1024 config[/cyan]        修改配置")
    console.print("  [cyan]love1024 log[/cyan]           查看播报日志")
    console.print("  [cyan]love1024 voices[/cyan]        查看可用语音")
    console.print("  [cyan]love1024 install-hook[/cyan]  获取 Hook 注册配置")
    console.print()
    if check_hook_registered():
        console.print(Panel(
            "[bold yellow]⚠️  请重启 CodeBuddy 使 Hook 配置生效！[/bold yellow]\n"
            "[dim]重启后，每次任务完成时语音鼓励将自动触发。[/dim]",
            border_style="yellow",
        ))
        console.print()
    console.print("[bold magenta]享受编程，Love1024 会一直陪着你！💕[/bold magenta]")


def run_partial_config():
    """分项修改配置 - 只改你想改的那一块"""
    cfg = load_config()

    while True:
        # 显示当前关键配置摘要
        style = cfg.get("personality", {}).get("style", "sweet")
        style_display = "🎲 随机" if style == "_random" else style
        owner = cfg.get("personality", {}).get("owner_name", "主人")
        zh_ratio = cfg.get("personality", {}).get("zh_ratio", 90)
        voice = cfg.get("voice", {}).get("zh_voice", "-")
        tts_engine = cfg.get("voice", {}).get("tts_engine", "edge-tts")
        engine_display = tts_engine
        if tts_engine == "qwen3-tts":
            engine_display = f"Qwen3-TTS ({cfg.get('voice', {}).get('qwen3_speaker', 'Vivian')})"
        level_map = {1: "话唠", 2: "适中", 3: "安静", 4: "专注"}
        level = level_map.get(cfg.get("behavior", {}).get("silent_level", 2), "适中")
        api_key = cfg.get("llm", {}).get("api_key", "")
        key_display = (api_key[:4] + "****" + api_key[-4:]) if len(api_key) > 8 else ("未设置" if not api_key else api_key)

        console.print(f"\n[dim]当前：风格=[cyan]{style_display}[/cyan]  称呼=[cyan]{owner}[/cyan]  中文比例=[cyan]{zh_ratio}%[/cyan]  引擎=[cyan]{engine_display}[/cyan]  静默=[cyan]{level}[/cyan]  Key=[cyan]{key_display}[/cyan][/dim]\n")

        action = inquirer.select(
            message="选择要修改的项目：",
            choices=[
                {"name": "🎨 切换鼓励师风格", "value": "style"},
                {"name": "👤 修改称呼 / 中日比例", "value": "owner"},
                {"name": "🔑 修改 API Key / 模型", "value": "llm"},
                {"name": "🎤 更换语音 / 切换 TTS 引擎", "value": "voice"},
                {"name": "🔇 调整静默力度", "value": "silent"},
                Separator(),
                {"name": "💾 保存并退出", "value": "save"},
                {"name": "❌ 放弃修改", "value": "cancel"},
            ],
        ).execute()

        if action == "style":
            cfg = _step_style(cfg)
            # 切换风格后同步预设的语音参数（随机模式跳过，运行时动态选择）
            new_style = cfg.get("personality", {}).get("style", "sweet")
            if new_style == "_random":
                console.print("[dim]随机模式：语音参数将在每次播报时跟随选中的风格动态调整[/dim]")
            else:
                preset = load_preset(new_style)
                if preset and "voice" in preset:
                    pv = preset["voice"]
                    cfg["voice"]["zh_rate"] = pv.get("zh_rate", "+0%")
                    cfg["voice"]["zh_pitch"] = pv.get("zh_pitch", "+0Hz")
                    cfg["voice"]["ja_rate"] = pv.get("ja_rate", "-20%")
                    cfg["voice"]["ja_pitch"] = pv.get("ja_pitch", "+8Hz")
                    console.print(f"[dim]已同步 {new_style} 预设的语音参数[/dim]")
        elif action == "owner":
            cfg = _step_owner_name(cfg)
        elif action == "llm":
            cfg = _step_llm_api(cfg)
        elif action == "voice":
            cfg = _step_voice(cfg)
        elif action == "silent":
            cfg = _step_silent_level(cfg)
        elif action == "save":
            save_config(cfg)
            console.print("\n[bold green]✅ 配置已保存！[/bold green]")
            break
        elif action == "cancel":
            console.print("[yellow]已放弃修改。[/yellow]")
            break
