"""Hook 运行时入口 - CodeBuddy Stop Hook 事件处理

此模块只导入标准库和内部模块，不导入 rich/InquirerPy，确保快速启动（<1s）。
由 `love1024 hook` 子命令调用，或直接作为 Hook command 执行。
"""

import json
import sys
import os

# 内部模块延迟导入，减少 import 开销
# from love1024.transcript import extract_conversation
# from love1024.llm import ask_llm
# from love1024.tts import speak
# from love1024.prompt import build_system_prompt
# from love1024.config import load_config
# from love1024.logger import write_log


def run_hook(platform: str = ""):
    """Hook 主入口：读取 stdin → 确定平台 → 提取会话 → LLM 分析 → 语音播报

    Args:
        platform: 来源平台标识（由 --platform 参数传入，如 "codebuddy"/"claude"）
    """
    from love1024.config import load_config
    from love1024.transcript import extract_conversation, extract_conversation_jsonl
    from love1024.prompt import build_system_prompt
    from love1024.llm import ask_llm
    from love1024.tts import speak
    from love1024.logger import write_log

    # 1. 读取 stdin
    raw = sys.stdin.read()
    try:
        data = json.loads(raw)
    except Exception:
        data = {}

    # 2. 确定来源平台：优先用命令行参数，回退到自动检测
    if not platform:
        platform = _detect_platform(data)
    session_id = data.get("session_id", "")
    cwd = data.get("cwd", "")

    # 3. 记录调用（包含 client/version 等关键字段值便于诊断）
    write_log({
        "event": "hook_called",
        "platform": platform,
        "session_id": session_id,
        "transcript_path": data.get("transcript_path", ""),
        "client": data.get("client", ""),
        "version": data.get("version", ""),
        "stdin_keys": list(data.keys())[:10],
        "raw_len": len(raw),
    })

    # 4. 根据平台提取会话内容
    conversation = _extract_conversation_by_platform(data, platform)
    if not conversation:
        write_log({
            "event": "no_conversation",
            "platform": platform,
            "session_id": session_id,
            "transcript_path": data.get("transcript_path", ""),
        })
        _output_continue()
        return 0

    # 4. 加载配置
    cfg = load_config()
    llm_cfg = cfg.get("llm", {})
    voice_cfg = cfg.get("voice", {})
    personality = cfg.get("personality", {})
    behavior = cfg.get("behavior", {})
    tts_engine = voice_cfg.get("tts_engine", "edge-tts")

    # 开关检查：disabled 时直接跳过
    if not behavior.get("enabled", True):
        _output_continue()
        return 0

    api_key = llm_cfg.get("api_key", "")
    if not api_key:
        _output_continue()
        return 0

    # 5. 构建 System Prompt（根据 TTS 引擎注入不同格式规则）
    system_prompt = build_system_prompt(
        style=personality.get("style", "sweet"),
        owner_zh=personality.get("owner_name", "主人"),
        owner_ja=personality.get("owner_name_ja", "ご主人様"),
        zh_ratio=personality.get("zh_ratio", 90),
        silent_level=behavior.get("silent_level", 2),
        custom_prompt=personality.get("custom_prompt", ""),
        tts_engine=tts_engine,
    )

    # 6. 调用 LLM
    voice_text = ask_llm(
        conversation_text=conversation,
        system_prompt=system_prompt,
        api_key=api_key,
        base_url=llm_cfg.get("base_url", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
        model=llm_cfg.get("model", "deepseek-v3"),
    )

    # 7. 处理 LLM 输出
    if not voice_text or voice_text.startswith("ERROR:"):
        # LLM 调用失败（超时/欠费/网络错误）
        error_msg = voice_text if voice_text else "LLM 无响应"
        write_log({
            "session_id": session_id,
            "scene": "error",
            "text": error_msg.replace("ERROR:", ""),
            "last_text": conversation[:100],
            "llm_output": voice_text,
        })
        _output_continue()
        return 0

    if voice_text.strip() == "SILENT":
        # 大模型主动判断不需要播报
        write_log({
            "session_id": session_id,
            "scene": "silent",
            "text": "大模型判定无需播报",
            "last_text": conversation[:100],
            "llm_output": voice_text,
        })
        _output_continue()
        return 0

    # 8. 解析 LLM 输出
    # edge-tts 格式：zh|+10%|+5Hz|文案  或  zh|文案
    # qwen3-tts 格式：zh|语气指令|文案  或  zh|文案
    parts = voice_text.split("|")

    def _valid_rate(s: str) -> bool:
        s = s.strip()
        return s.endswith("%") and len(s) >= 2

    def _valid_pitch(s: str) -> bool:
        s = s.strip()
        return s.endswith("Hz") and len(s) >= 3

    lang = "zh"
    text = voice_text.strip()
    dyn_rate = None
    dyn_pitch = None
    qwen3_instruct = ""

    if tts_engine in ("qwen3-tts", "qwen3-cloud"):
        # Qwen3-TTS 格式解析
        if len(parts) == 3:
            # zh|语气指令|文案
            lang = parts[0].strip().lower()
            qwen3_instruct = parts[1].strip()
            text = parts[2].strip()
        elif len(parts) == 2:
            # zh|文案（无语气指令）
            lang = parts[0].strip().lower()
            text = parts[1].strip()
        # else: 兜底用整段文本
    else:
        # edge-tts 格式解析
        if len(parts) == 4 and _valid_rate(parts[1]) and _valid_pitch(parts[2]):
            lang = parts[0].strip().lower()
            dyn_rate = parts[1].strip()
            dyn_pitch = parts[2].strip()
            text = parts[3].strip()
        elif len(parts) == 2:
            lang = parts[0].strip().lower()
            text = parts[1].strip()

    # 9. 根据语言选语音参数（edge-tts 用）
    if lang == "ja":
        voice = voice_cfg.get("ja_voice", "ja-JP-NanamiNeural")
        rate = dyn_rate if dyn_rate else voice_cfg.get("ja_rate", "-20%")
        pitch = dyn_pitch if dyn_pitch else voice_cfg.get("ja_pitch", "+8Hz")
    else:
        voice = voice_cfg.get("zh_voice", "zh-CN-XiaoyiNeural")
        rate = dyn_rate if dyn_rate else voice_cfg.get("zh_rate", "+0%")
        pitch = dyn_pitch if dyn_pitch else voice_cfg.get("zh_pitch", "+0Hz")

    # 10. TTS 引擎配置
    qwen3_model = voice_cfg.get("qwen3_model", "mlx-community/Qwen3-TTS-12Hz-0.6B-CustomVoice-8bit")
    qwen3_speaker = voice_cfg.get("qwen3_speaker", "Vivian")
    qwen3_cloud_api_key = voice_cfg.get("qwen3_cloud_api_key", "")
    qwen3_cloud_voice = voice_cfg.get("qwen3_cloud_voice", "Cherry")
    qwen3_cloud_model = voice_cfg.get("qwen3_cloud_model", "qwen3-tts-instruct-flash")

    # 11. 日志中的语音标识
    if tts_engine == "edge-tts":
        voice_label = voice
    elif tts_engine == "qwen3-tts":
        voice_label = f"qwen3:{qwen3_speaker}"
    else:
        voice_label = f"cloud:{qwen3_cloud_voice}"

    write_log({
        "session_id": session_id,
        "cwd": cwd,
        "last_text": conversation[:100],
        "text": text,
        "voice": voice_label,
        "rate": rate if tts_engine == "edge-tts" else "",
        "pitch": pitch if tts_engine == "edge-tts" else "",
        "instruct": qwen3_instruct if tts_engine != "edge-tts" else "",
        "tts_engine": tts_engine,
    })
    speak(
        text, voice, rate, pitch,
        engine=tts_engine,
        qwen3_model=qwen3_model,
        qwen3_speaker=qwen3_speaker,
        qwen3_instruct=qwen3_instruct,
        qwen3_cloud_api_key=qwen3_cloud_api_key,
        qwen3_cloud_voice=qwen3_cloud_voice,
        qwen3_cloud_model=qwen3_cloud_model,
    )

    _output_continue()
    return 0


def _output_continue():
    """输出 Hook 标准响应"""
    print(json.dumps({"continue": True}, ensure_ascii=False))


def _detect_platform(data: dict) -> str:
    """根据 stdin JSON 字段特征自动检测来源平台"""
    transcript = data.get("transcript_path", "")

    # 优先根据 transcript_path 路径判断（最准确）
    if transcript:
        if "CodeBuddy" in transcript or "codebuddy" in transcript.lower():
            return "codebuddy"
        if ".claude" in transcript:
            return "claude"
        # 有 transcript_path 但无法判断来源，默认 CodeBuddy
        return "codebuddy"

    # 无 transcript_path 时，用 client 字段值判断
    client = str(data.get("client", "")).lower()
    if "codebuddy" in client:
        return "codebuddy"
    if "claude" in client:
        return "claude"

    # client 也无法判断时，检查 Claude 独有字段
    if "last_assistant_message" in data:
        return "claude"

    # hook_event_name 是 CodeBuddy 和 Claude 共有的字段，
    # 无法区分来源，默认 CodeBuddy（更常见的场景）
    return "codebuddy"


def _extract_conversation_by_platform(data: dict, platform: str) -> str:
    """根据平台从 stdin 数据中提取会话内容"""
    from love1024.transcript import extract_conversation, extract_conversation_jsonl

    if platform == "claude":
        # Claude Code: 优先用 last_assistant_message（最简单直接）
        last_msg = data.get("last_assistant_message", "")
        if last_msg:
            return f"[assistant]: {last_msg[:2000]}"
        # 降级：解析 transcript_path（Claude 用 .jsonl 格式）
        transcript_path = data.get("transcript_path", "")
        if transcript_path:
            return extract_conversation_jsonl(transcript_path)
        return ""

    else:
        # CodeBuddy: 解析 transcript_path 下的 messages/ 目录
        transcript_path = data.get("transcript_path", "")
        if transcript_path:
            return extract_conversation(transcript_path)

        # transcript_path 为空时，尝试通过 session_id 搜索
        session_id = data.get("session_id", "")
        if session_id:
            found = _find_codebuddy_transcript(session_id)
            if found:
                return extract_conversation(found)

        return ""


def _find_codebuddy_transcript(session_id: str) -> str:
    """通过 session_id 在 CodeBuddy 数据目录中搜索对应的 index.json"""
    import glob

    base_dirs = [
        os.path.expanduser("~/Library/Application Support/CodeBuddyExtension/Data"),
        os.path.expanduser("~/Library/Application Support/CodeBuddy CN/User/globalStorage"),
    ]

    for base in base_dirs:
        if not os.path.isdir(base):
            continue
        # 在 history 子目录中搜索匹配 session_id 的 index.json
        pattern = os.path.join(base, "**", "history", "**", session_id, "index.json")
        matches = glob.glob(pattern, recursive=True)
        if matches:
            # 返回最新修改的那个
            matches.sort(key=lambda p: os.path.getmtime(p), reverse=True)
            return matches[0]

    return ""
