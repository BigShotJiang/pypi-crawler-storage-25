"""Prompt 模板渲染器 - 从预设加载并替换占位符"""

import random

from love1024.presets import load_preset, get_preset_names

# SILENT 力度规则文本
SILENT_RULES = {
    1: '   - 只有在用户明确说"等一下"或"暂停"时才静默，其他情况尽量播报',
    2: "   - 仅在任务明确完成或有阶段性成果时播报，中间过程的回复静默",
    3: "   - 只有在重要里程碑（如整个阶段完成、测试全部通过、代码推送成功）时播报",
    4: '   - 除非看到非常明确的完成标志（如"全部完成"、"所有测试通过"、"部署成功"），否则都输出 SILENT',
}

# edge-tts 语音情绪参数说明
VOICE_PARAM_RULES_EDGE = """语音情绪参数说明（根据内容情绪自行选择合适值）：
- rate（语速）：范围 -20% 到 +25%，正数更快/兴奋，负数更慢/温柔
- pitch（音调）：范围 -5Hz 到 +12Hz，正数更高亢/开心，负数更低沉/平静
- 参考区间：
  - 兴奋/重大成果：rate +10%~+20%，pitch +6Hz~+10Hz
  - 平静/普通完成：rate +0%~+5%，pitch +0Hz~+3Hz
  - 温柔/修复问题：rate -5%~+0%，pitch +2Hz~+5Hz"""

# Qwen3-TTS 语气指令说明
VOICE_PARAM_RULES_QWEN3 = """语音情绪指令说明（根据内容情绪用自然语言描述语气）：
- instruct（语气指令）：用一句简短的中文描述朗读时的语气和情感
- 【重要】每次必须选择不同的语气描述，严禁连续使用完全相同的语气指令！
- 参考示例（每个风格提供多种变体，每次随机选一种）：
  - 兴奋/重大成果："用非常兴奋激动的语气" / "用惊喜到不敢相信的语气" / "用激动得语速加快的语气"
  - 甜美/普通完成："用温柔甜美的语气" / "用撒娇般开心的语气" / "用软萌可爱的语气"
  - 温柔/修复问题："用轻柔关怀的语气，语速稍慢" / "用心疼又欣慰的语气" / "用温暖安抚的语气"
  - 傲娇/嘴硬心软："用傲娇不屑但暗含关心的语气" / "用嘴硬心软勉强承认的语气" /
    "用故作冷淡但藏不住开心的语气" / "用不情愿夸人的别扭语气" / "用假装漫不经心实则很在意的语气"
  - 元气/打气："用充满活力热情洋溢的语气" / "用像啦啦队长一样振奋的语气" / "用兴奋到快喊出来的语气"
  - 撒娇/台湾腔："用软糯撒娇的语气，尾音上扬" / "用嗲嗲的崇拜语气" / "用俏皮甜蜜的语气"
  - 知性/沉稳："用沉稳优雅的语气" / "用平和温暖的语气" / "用淡淡欣慰的语气"
  - 暖男/体贴："用温柔体贴的语气" / "用宠溺关怀的语气" / "用低沉温暖让人安心的语气"
  - PUA/先抑后扬："用先质疑再真诚认可的语气" / "用调侃中带着佩服的语气" / "用假装嫌弃实则欣赏的语气"
  - 忠犬/崇拜："用热情崇拜的语气" / "用兴奋到停不下来的语气" / "用骄傲炫耀的语气"
- 【发音优化】文案中避免使用容易被TTS读错的多音字词汇，优先用口语化同义词替代：
  重构→改写/重写、调用→跑/执行、调试→排查、处理→搞定/解决、
  重载→重新加载、行数→多少行、还行→不错、干净→利落/整洁
- 指令要简短（10字以内），只描述语气情感，不要重复文案内容"""

# edge-tts 输出格式补丁（追加到模板末尾，替换原有格式说明）
OUTPUT_FORMAT_PATCH_EDGE = ""

# Qwen3-TTS 输出格式补丁（替换模板中的格式和示例）
OUTPUT_FORMAT_PATCH_QWEN3 = """

【重要】输出格式已变更为 Qwen3-TTS 模式：
- 输出格式：`语言|语气指令|文案`，语言只填 `zh` 或 `ja`。如需静默则只输出 SILENT。
- 语气指令：用简短中文描述朗读语气（如"用开心的语气"），不要写 rate/pitch 数值。
- 忽略模板中所有 rate/pitch 相关的示例格式，统一使用新格式。

正确示例：
- zh|用兴奋的语气|太棒了，测试全通过啦~
- zh|用温柔关怀的语气|辛苦了，Bug终于修好了~
- ja|甘えた声で|テスト全部通った♪ すごいです！
- SILENT"""


def build_system_prompt(
    style: str = "sweet",
    owner_zh: str = "主人",
    owner_ja: str = "ご主人様",
    zh_ratio: int = 90,
    silent_level: int = 2,
    custom_prompt: str = "",
    tts_engine: str = "edge-tts",
) -> str:
    """
    根据风格和配置生成最终的 System Prompt。
    tts_engine: "edge-tts" 或 "qwen3-tts"，决定注入不同的格式规则。
    """
    if custom_prompt:
        template = custom_prompt
    else:
        # 随机风格：每次调用随机选一个预设
        if style == "_random":
            names = get_preset_names()
            style = random.choice(names) if names else "sweet"

        preset = load_preset(style)
        if preset and "prompt" in preset:
            template = preset["prompt"].get("template", "")
        else:
            preset = load_preset("sweet")
            template = preset["prompt"]["template"] if preset else ""

    if not template:
        return ""

    ja_ratio = 100 - zh_ratio
    silent_rule = SILENT_RULES.get(silent_level, SILENT_RULES[2])

    # 根据 TTS 引擎选择参数规则
    if tts_engine in ("qwen3-tts", "qwen3-cloud"):
        voice_param_rules = VOICE_PARAM_RULES_QWEN3
        output_patch = OUTPUT_FORMAT_PATCH_QWEN3
    else:
        voice_param_rules = VOICE_PARAM_RULES_EDGE
        output_patch = OUTPUT_FORMAT_PATCH_EDGE

    result = (
        template
        .replace("{OWNER_ZH}", owner_zh)
        .replace("{OWNER_JA}", owner_ja)
        .replace("{ZH_RATIO}", str(zh_ratio))
        .replace("{JA_RATIO}", str(ja_ratio))
        .replace("{SILENT_RULES}", silent_rule)
        .replace("{VOICE_PARAM_RULES}", voice_param_rules)
    )

    # 追加输出格式补丁
    if output_patch:
        result += output_patch

    return result
