"""风格预设模板包 - 加载和管理内置鼓励师风格"""

import os
import sys
from typing import Optional, List

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None

PRESETS_DIR = os.path.dirname(os.path.abspath(__file__))


def get_preset_names() -> List[str]:
    """获取所有可用的预设名称列表"""
    names = []
    for f in sorted(os.listdir(PRESETS_DIR)):
        if f.endswith(".toml"):
            names.append(f[:-5])
    return names


def load_preset(name: str) -> Optional[dict]:
    """加载指定名称的预设，返回 dict 或 None"""
    path = os.path.join(PRESETS_DIR, f"{name}.toml")
    if not os.path.exists(path):
        return None
    if tomllib is None:
        return None
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except Exception:
        return None


def get_all_presets() -> List[dict]:
    """获取所有预设的完整信息列表"""
    presets = []
    for name in get_preset_names():
        preset = load_preset(name)
        if preset:
            presets.append(preset)
    return presets


def get_preset_choices() -> List[dict]:
    """获取用于 InquirerPy 选择列表的预设选项"""
    choices = []
    for preset in get_all_presets():
        meta = preset.get("meta", {})
        choices.append({
            "name": f"{meta.get('display_name', meta.get('name', '?'))}  {meta.get('description', '')}",
            "value": meta.get("name", ""),
        })
    return choices
