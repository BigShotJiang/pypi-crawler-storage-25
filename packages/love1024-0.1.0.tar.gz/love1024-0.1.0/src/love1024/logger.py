"""日志模块 - JSONL 格式写入和读取"""

import json
import os
import datetime

LOG_PATH = "/tmp/love1024.log"


def write_log(record: dict):
    """写入一条 JSONL 日志记录"""
    try:
        record.setdefault("time", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception:
        pass


def read_recent_logs(count: int = 20) -> list[dict]:
    """读取最近 N 条日志"""
    if not os.path.exists(LOG_PATH):
        return []
    try:
        with open(LOG_PATH, "r", encoding="utf-8") as f:
            lines = f.readlines()
        records = []
        for line in lines[-count:]:
            line = line.strip()
            if line:
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
        return records
    except Exception:
        return []


def clear_log():
    """清空日志"""
    try:
        if os.path.exists(LOG_PATH):
            os.remove(LOG_PATH)
    except Exception:
        pass
