__all__ = ["HEADERS"]

HEADERS = {
    "User-Agent": "mihomo/1.19.23",
}
