import json
import aiohttp
from typing import Dict, Any, Tuple

_MAX_ERR_BODY = 1200


def _truncate(s: str, max_len: int = _MAX_ERR_BODY) -> str:
    if len(s) <= max_len:
        return s
    return s[:max_len] + "…"


class AsyncClient:
    """异步客户端基类"""

    def __init__(self, api_key: str, base_url: str = "https://test-llm-v2.pixelarrayai.com"):
        self.base_url = base_url
        self.api_key = api_key
        self.headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
        }

    async def _request(self, method: str, url: str, **kwargs) -> Tuple[Dict[str, Any], bool, str]:
        """统一的异步请求方法。第三项为失败时的服务端 message 或 HTTP 说明。"""
        async with aiohttp.ClientSession() as session:
            req_method = getattr(session, method.lower())

            # 处理params参数
            params = kwargs.pop("params", None)
            json_data = kwargs.pop("json", None)

            async with req_method(
                f"{self.base_url}{url}", headers=self.headers, params=params, json=json_data, **kwargs
            ) as resp:
                text = await resp.text()
                try:
                    result = json.loads(text) if text else {}
                except Exception:
                    return {}, False, f"HTTP {resp.status}; 非 JSON 响应: {_truncate(text)}"
                if not isinstance(result, dict):
                    return {}, False, f"HTTP {resp.status}; 非对象 JSON: {_truncate(str(result))}"
                if resp.status == 200 and result.get("status_code") == 200:
                    return (result.get("data") or {}), True, ""
                raw_msg = result.get("message")
                m = (raw_msg if isinstance(raw_msg, str) else (str(raw_msg) if raw_msg is not None else "")).strip()
                msg = m or (
                    f"HTTP {resp.status}" if resp.status != 200 else f"status_code={result.get('status_code')}"
                )
                data = result.get("data")
                if not m and isinstance(data, dict) and len(data) > 0:
                    try:
                        msg = f"{msg}; data={_truncate(json.dumps(data, ensure_ascii=False))}"
                    except Exception:
                        pass
                return result.get("data") or {}, False, msg
