from pixelarrayllm.client import AsyncClient
from typing import Union, List, Dict, Any, AsyncGenerator, Optional
import json
import aiohttp
import asyncio


class LLMCallManagerAsync:
    """
    异步LLM模型调用管理器

    用于调用各种云服务厂商的LLM模型，支持文本生成、图片生成、图片编辑等多种功能。
    支持流式响应，可以实时获取模型生成的内容。
    """

    @staticmethod
    def _call_model_body(
        provider: str,
        model: str,
        input: Dict[str, Any],
        is_stream: bool,
        accept_parameters: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        acc: Dict[str, Any] = dict(accept_parameters or {})
        if not is_stream:
            acc["is_stream"] = False
        body: Dict[str, Any] = {
            "provider": provider,
            "model": model,
            "input": input,
        }
        if acc:
            body["accept_parameters"] = acc
        return body

    def __init__(self, api_key: str, base_url: str = "https://test-llm-v2.pixelarrayai.com"):
        """
        初始化LLM调用管理器

        Args:
            api_key (str): API密钥，用于身份验证
            base_url (str): 服务端基础URL，默认为 "https://test-llm-v2.pixelarrayai.com"
        """
        self.api_key = api_key
        self.base_url = base_url
        self.async_client = AsyncClient(api_key, base_url)

    async def list_models(self) -> List[Dict[str, Any]]:
        """
        获取可用的模型列表

        Returns:
            List[Dict[str, Any]]: 模型列表，每个模型包含以下字段：
                - provider (str): 云服务厂商，如 "google", "aliyun"
                - model (str): 模型名称，如 "gemini-3-flash-preview", "wan-2-7-image-pro"
                - type (str): API类型，如 "text_generation", "image_generation"
                - accept_parameters (dict): 接受的参数配置
                - default_parameters (dict, 可选): 默认参数
                - modelKey (str): 唯一标识符，格式为 "{provider}-{model}"

        Raises:
            Exception: 当获取模型列表失败时抛出异常

        Example:
            >>> manager = LLMCallManagerAsync(api_key="your_api_key")
            >>> models = await manager.list_models()
            >>> print(models)
            [
                {
                    "provider": "google",
                    "model": "gemini-3-flash-preview",
                    "type": "text_generation",
                    "accept_parameters": {...},
                    "modelKey": "google-gemini-3-flash-preview"
                },
                ...
            ]
        """
        data, success, err = await self.async_client._request("POST", "/api/llm/list_models", json={})
        if not success:
            raise Exception(f"获取模型列表失败: {err}" if err else "获取模型列表失败")
        return data

    async def call_model(
        self,
        provider: str,
        model: str,
        input: Dict[str, Any],
        is_stream: bool = True,
        accept_parameters: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator:
        """
        调用LLM模型（支持流式和非流式响应）

        该方法会向服务端发送请求，并返回一个异步生成器，用于接收响应数据。
        响应以JSON格式逐行返回，每行是一个完整的JSON对象。

        Args:
            provider (str): 云服务厂商名称
                - "google": Google云服务
                - "aliyun": 阿里云服务

            model (str): 模型名称，具体可用的模型请通过 list_models() 方法获取
                常见模型示例：
                - "gemini-3-flash-preview": Google文本生成模型
                - "gemini-2-5-flash-image": Google图片生成模型
                - "wan-2-7-image-pro": 阿里云万相图片生成模型
                - "qwen-image-edit-plus": 阿里云图片编辑模型

            input (Dict[str, Any]): 模型输入参数，格式如下：
                {
                    # 文本输入（可选，根据模型要求）
                    "texts": [
                        {"type": "text", "content": "用户输入的文本内容", "tag": "default"}
                    ],

                    # 图片输入（可选，根据模型要求）
                    "images": [
                        {
                            "type": "base64",  # 或 "url"
                            "content": "base64编码的图片数据",  # 单条字符串，不包含 data URI 前缀
                            "tag": "default",
                        }
                    ],

                    # 音频输入（可选，仅部分模型支持）
                    "audios": [
                        {"type": "base64", "content": "base64编码的音频数据", "tag": "default"}
                    ],

                    # 视频输入（可选，仅部分模型支持）
                    "videos": [
                        {"type": "base64", "content": "base64编码的视频数据", "tag": "default"}
                    ]
                }

                参数说明：
                - texts: 文本槽，必须为数组，元素为 {"type", "content", "tag"}；content 为字符串
                - images / audios / videos: 每段 ``content`` 为**单一字符串**（一个 URL 或一段 base64），多素材用数组中的多个对象分段，与 ``tag`` 一一对应

                注意：
                - 不同模型接受的参数不同，请根据 list_models 与模型配置提供；accept_parameters 控制项键名与 docs/api_io_spec.md §2.3 一致（如 ratio、with_audio、generate_count、resolution 等），均为 snake_case
                - **ratio**：请使用 **宽高比字符串**，如 ``"16:9"``、``"9:16"``、``"1:1"``；万相 2.7 / Qwen 图像编辑 Plus 等服务端 **拒绝** ``1K``/``2K`` 或 ``宽*高`` 像素串
                - 豆包 TTS（doubao-tts-v1 / v2）的 **voice_id** 在 accept_parameters 中为 **普通字符串**（与 list_voices 的 voice_type 一致），例如：
                  ``accept_parameters={"voice_id": "zh_male_guangzhoudege_emo_mars_bigtts"}``，勿再使用 ``{"type": "text", "content": "..."}`` 包裹
                - 必填参数必须提供，否则会返回错误
                - base64编码的数据不应包含data URI前缀（如"data:image/png;base64,"）

            is_stream (bool, optional): 是否流式 NDJSON，默认 True。网关仅在 **accept_parameters** 中接收 ``is_stream``，且 **仅 text_generation** 允许。本参数为 False 时会写入请求体 ``accept_parameters``；为 True 时不发送该键。

        Yields:
            Dict[str, Any]: 流式响应数据块，每个chunk是一个字典，格式如下：

            0. 预计生成时间 chunk（流式时可能为首行，仅当该模型有历史调用记录时存在）:
                {"estimated_generation_time": 12.3456}  # 单位：秒，可向用户展示「预计约 X 秒」

            1. 内容响应chunk（流式生成过程中）:
                {
                    "response": {
                        # 文本响应（文本生成模型）
                        "texts": {
                            "content": "模型生成的文本片段",
                            "type": "text"
                        },
                        # 思考过程（部分推理/深度思考模型会增量返回，与 text 并行）
                        "reasoning": {
                            "content": "思考片段",
                            "type": "text"
                        },
                        # 或图片响应（图片生成/编辑模型）
                        "images": {
                            "content": ["图片数据1", "图片数据2", ...],  # base64字符串数组或URL字符串数组
                            "type": "base64"  # 或 "url"
                        }
                    }
                }

                注意：流式响应中，文本内容会分多次返回，每次返回一个文本片段。
                需要将所有chunk中的text.content拼接起来才能得到完整文本。
                若存在 reasoning，则拼接各chunk的response.reasoning.content 得到完整思考过程。

            2. 完成响应chunk（最后一个chunk，包含使用统计）:
                {
                    "request_id": "请求唯一标识符",
                    "success": True,  # 布尔值，表示请求是否成功
                    "usage": { ... },  # 使用统计信息
                    "estimated_generation_time": 12.3456  # 可选，单位秒（有历史记录时存在）
                }

                注意：最后一个chunk同时包含request_id和usage字段；非流式时单次返回的字典也可能含 estimated_generation_time。

        Raises:
            Exception: 当HTTP状态码不是200时抛出异常，异常信息包含状态码

        Example:
            >>> manager = LLMCallManagerAsync(api_key="your_api_key")
            >>>
            >>> # 示例1: 文本生成（流式返回，默认）
            >>> async for chunk in manager.call_model(
            ...     provider="google",
            ...     model="gemini-3-flash-preview",
            ...     input={
            ...         "texts": [
            ...             {"content": "Hello, please tell me a joke", "type": "text", "tag": "default"}
            ...         ]
            ...     },
            ...     is_stream=True  # 默认值，可省略
            ... ):
            ...     if chunk.get("estimated_generation_time") is not None:
            ...         print(f"预计生成时间: 约 {chunk['estimated_generation_time']:.1f} 秒")
            ...     if "response" in chunk:
            ...         # 处理内容响应
            ...         if "text" in chunk["response"]:
            ...             print(chunk["response"]["text"]["content"], end="")
            ...     elif "request_id" in chunk:
            ...         # 处理完成响应
            ...         print(f"\\n请求ID: {chunk['request_id']}")
            ...         print(f"使用统计: {chunk['usage']}")
            >>>
            >>> # 示例2: 图片生成（带图片输入）
            >>> async for chunk in manager.call_model(
            ...     provider="google",
            ...     model="gemini-2-5-flash-image",
            ...     input={
            ...         "images": [{"type": "base64", "content": base64_image_data, "tag": "default"}],
            ...         "texts": [{"content": "把照片改为白底", "type": "text", "tag": "default"}]
            ...     }
            ... ):
            ...     if "response" in chunk:
            ...         if "images" in chunk["response"]:
            ...             # 处理图片响应
            ...             images = chunk["response"]["images"]["content"]
            ...             for img in images:
            ...                 # 如果是base64，需要添加data URI前缀才能显示
            ...                 img_data_uri = f"data:image/png;base64,{img}"
            >>>
            >>> # 示例3: 图片编辑（使用URL；ratio 用宽高比如 16:9）
            >>> async for chunk in manager.call_model(
            ...     provider="aliyun",
            ...     model="qwen-image-edit-plus",
            ...     input={
            ...         "images": [
            ...             {"type": "url", "content": "https://example.com/image1.png", "tag": "default"},
            ...             {"type": "url", "content": "https://example.com/image2.png", "tag": "default"},
            ...         ],
            ...         "texts": [{"content": "图1中的女生穿着图2中的黑色裙子按图3的姿势坐下", "type": "text", "tag": "default"}]
            ...     },
            ...     is_stream=False,
            ...     accept_parameters={"ratio": "16:9"},
            ... ):
            ...     # 处理响应...
        """
        timeout = aiohttp.ClientTimeout(total=900)  # 15 分钟，与网关 LLM 总超时一致

        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                f"{self.base_url}/api/llm/call_model",
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": self.api_key,
                },
                json=self._call_model_body(provider, model, input, is_stream, accept_parameters),
            ) as resp:
                if resp.status != 200:
                    err_text = await resp.text()
                    msg = f"调用模型失败: {resp.status}"
                    if err_text.strip():
                        try:
                            first = err_text.strip().split("\n", 1)[0]
                            body = json.loads(first)
                            if isinstance(body, dict) and body.get("message"):
                                msg = str(body["message"])
                        except (json.JSONDecodeError, TypeError, ValueError):
                            msg = err_text.strip()[:2000]
                    raise Exception(msg)

                # 流式读取：在字节层按 \n 切分，避免 str 反复拼接拷贝；换行处为 ASCII，不截断 UTF-8 多字节字符
                buf = bytearray()

                async for chunk_bytes in resp.content.iter_chunked(8192):
                    buf.extend(chunk_bytes)
                    while True:
                        i = buf.find(b"\n")
                        if i < 0:
                            break
                        line_bytes = bytes(buf[:i])
                        del buf[: i + 1]
                        line = line_bytes.decode("utf-8", errors="ignore").strip()
                        if line:
                            try:
                                yield json.loads(line)
                            except json.JSONDecodeError:
                                continue

                if buf:
                    line = buf.decode("utf-8", errors="ignore").strip()
                    if line:
                        try:
                            yield json.loads(line)
                        except json.JSONDecodeError:
                            pass

    async def create_model_task(
        self,
        provider: str,
        model: str,
        input: Dict[str, Any],
        accept_parameters: Optional[Dict[str, Any]] = None,
    ) -> str:
        body = {
            "provider": provider,
            "model": model,
            "input": input,
        }
        if accept_parameters:
            body["accept_parameters"] = dict(accept_parameters)
        data, success, err = await self.async_client._request("POST", "/api/llm/create_model_task", json=body)
        if not success or not isinstance(data, dict) or not data.get("task_id"):
            raise Exception(f"创建模型任务失败: {err}" if err else "创建模型任务失败")
        return str(data["task_id"])

    async def poll_model_task(self, task_id: str) -> Dict[str, Any]:
        data, success, err = await self.async_client._request(
            "POST",
            "/api/llm/poll_model_task",
            json={"task_id": task_id},
        )
        if not success or not isinstance(data, dict):
            raise Exception(f"查询模型任务失败: {err}" if err else "查询模型任务失败")
        return data

    async def poll_model_task_until_done(
        self,
        task_id: str,
        *,
        poll_interval_seconds: float = 2.0,
        timeout_seconds: float = 900.0,
    ) -> Dict[str, Any]:
        deadline = asyncio.get_event_loop().time() + timeout_seconds
        while True:
            item = await self.poll_model_task(task_id)
            if bool(item.get("done")):
                return item
            if asyncio.get_event_loop().time() >= deadline:
                raise TimeoutError(f"轮询任务超时: task_id={task_id}")
            await asyncio.sleep(poll_interval_seconds)
