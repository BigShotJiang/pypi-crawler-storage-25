from pixelarrayllm.client import AsyncClient
from typing import Dict, Any, List, Optional, Union


def _task_id_to_query_param(task_id: Optional[Union[str, List[str]]]) -> Optional[str]:
    """将 ``task_id`` 转为 GET Query ``task_id`` 单字符串：列表在客户端用英文逗号拼接，与服务端解析规则一致。"""
    if task_id is None:
        return None
    if isinstance(task_id, list):
        parts = [str(x).strip() for x in task_id if str(x).strip()]
        if not parts:
            return None
        return ",".join(parts)
    s = str(task_id).strip()
    return s if s else None


class UsageStatsManagerAsync:
    """异步使用统计管理器（对应服务端 `/api/usage/*` 接口）"""

    def __init__(self, api_key: str, base_url: str = "https://test-llm-v2.pixelarrayai.com"):
        self.api_key = api_key
        self.base_url = base_url
        self.async_client = AsyncClient(api_key, base_url)

    async def get_user_stats(
        self,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        api_type: Optional[str] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key: Optional[str] = None,
        task_id: Optional[Union[str, List[str]]] = None,
    ) -> Dict[str, Any]:
        """
        获取当前 API Key 对应用户的使用汇总（GET /api/usage/user_stats）。

        输入（均为可选查询参数，与服务端 Query 一致）：
            start_time: 开始时间，格式 ``YYYY-MM-DD HH:MM:SS``。
            end_time: 结束时间，格式 ``YYYY-MM-DD HH:MM:SS``。
            api_type: API 类型，如 ``text_generation``、``image_generation``。
            provider: 云服务厂商代码，如 ``aliyun``、``google``。
            model_name: 模型名称筛选。
            api_key: 多 Key 场景下指定参与统计的 API Key 完整值（与请求头 X-API-Key 可不同，用于筛选）。
            task_id: 按 ``api_usage_logs.task_id`` 筛选。可传 **单个字符串**（多个 ID 仍可用英文逗号或换行写在同一字符串内），或传 **字符串列表** ``["id_a", "id_b"]``（SDK 内拼接为 Query ``task_id``）；每项最长 128 字符、最多 50 个由服务端处理。

        输出（``AsyncClient`` 已解包为接口 ``data`` 字段，下同）：
            summary: 汇总对象，字段含
                total_calls(int)、success_calls(int)、success_rate(float, 0~1)、
                avg_response_time(float, 秒)、total_cost(float|None，元，无消费时为 None)。
            logs: 恒为空列表；明细请用 ``get_recent_logs``。
        """
        params: Dict[str, str] = {}
        if start_time:
            params["start_time"] = start_time
        if end_time:
            params["end_time"] = end_time
        if api_type:
            params["api_type"] = api_type
        if provider:
            params["provider"] = provider
        if model_name:
            params["model_name"] = model_name
        if api_key:
            params["api_key"] = api_key
        tid = _task_id_to_query_param(task_id)
        if tid:
            params["task_id"] = tid

        data, success, err = await self.async_client._request("GET", "/api/usage/user_stats", params=params)
        if not success:
            raise Exception(f"获取用户使用统计失败: {err}" if err else "获取用户使用统计失败")
        return data

    async def get_daily_summary(
        self,
        date: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        获取每日使用汇总（GET /api/usage/daily_summary）。

        输入：
            date: 日期 ``YYYY-MM-DD``，省略则服务端按当天处理。
            api_key: API-KEY筛选，传完整值；不传则按当前用户当天全部记录统计。

        输出：
            api_type_summary: 列表，项含 api_type、call_count、avg_response_time 等。
            provider_summary: 列表，项含 provider、call_count、avg_response_time 等。
        """
        params: Dict[str, str] = {}
        if date:
            params["date"] = date
        if api_key:
            params["api_key"] = api_key

        data, success, err = await self.async_client._request("GET", "/api/usage/daily_summary", params=params)
        if not success:
            raise Exception(f"获取每日使用汇总失败: {err}" if err else "获取每日使用汇总失败")
        return data

    async def get_recent_logs(
        self,
        limit: int = 50,
        offset: int = 0,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        api_type: Optional[str] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key: Optional[str] = None,
        task_id: Optional[Union[str, List[str]]] = None,
    ) -> Dict[str, Any]:
        """
        分页获取使用记录（GET /api/usage/recent_logs）。

        输入：
            limit: 每页条数，默认 50（与历史 SDK 一致）；服务端限制 1~200。
            offset: 偏移量，默认 0。
            start_time / end_time: 时间范围，格式 ``YYYY-MM-DD HH:MM:SS``。
            api_type / provider / model_name / api_key: 与汇总接口相同的筛选维度。
            task_id: 按 ``api_usage_logs.task_id`` 筛选。可传单个字符串，或字符串列表 ``["id_a", "id_b"]``（见 ``get_user_stats`` 说明）。

        输出：
            logs: 记录列表。每条常见字段：
                id, user_id, api_key, request_id, task_id, api_type, provider, model_name,
                usage, response_time, cost, status, error_message,
                has_request_params, has_response, retry_count, create_time；
                request_params / response 默认不返回，需按需调专用接口拉取。
            total: 满足条件的总条数（用于分页）。
        """
        params: Dict[str, str] = {
            "limit": str(max(1, min(limit, 200))),
            "offset": str(max(0, offset)),
        }
        if start_time:
            params["start_time"] = start_time
        if end_time:
            params["end_time"] = end_time
        if api_type:
            params["api_type"] = api_type
        if provider:
            params["provider"] = provider
        if model_name:
            params["model_name"] = model_name
        if api_key:
            params["api_key"] = api_key
        tid = _task_id_to_query_param(task_id)
        if tid:
            params["task_id"] = tid

        data, success, err = await self.async_client._request("GET", "/api/usage/recent_logs", params=params)
        if not success:
            raise Exception(f"获取最近使用记录失败: {err}" if err else "获取最近使用记录失败")
        return data

    async def get_performance_stats(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        api_type: Optional[str] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        按 api_type + provider + model_name 聚合的性能统计（GET /api/usage/performance_stats）。

        输入：
            start_date / end_date: 日期 ``YYYY-MM-DD``；若均省略，服务端使用「用户注册日 0 点」至「当前时间」。
            api_type / provider / model_name / api_key: 可选筛选，语义与 ``get_recent_logs`` 一致。

        输出：
            performance_stats: 列表，每项典型字段：
                api_type, provider, model_name,
                total_calls, avg_response_time, min_response_time, max_response_time,
                success_calls（数值类型以服务端返回为准）。
        """
        params: Dict[str, str] = {}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        if api_type:
            params["api_type"] = api_type
        if provider:
            params["provider"] = provider
        if model_name:
            params["model_name"] = model_name
        if api_key:
            params["api_key"] = api_key

        data, success, err = await self.async_client._request("GET", "/api/usage/performance_stats", params=params)
        if not success:
            raise Exception(f"获取性能统计失败: {err}" if err else "获取性能统计失败")
        return data

    async def get_model_usage_ratio(
        self,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        api_type: Optional[str] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        各模型调用次数及占比（GET /api/usage/model_usage_ratio）。

        输入：
            start_time / end_time: 格式 ``YYYY-MM-DD HH:MM:SS``，可选，表示统计时间窗。
            api_type / provider / model_name / api_key: 可选筛选。

        输出：
            model_ratios: 列表，每项字段：
                model_name(str)、provider(str)、call_count(int)、ratio(float，百分比数值，如 35.5 表示 35.5%）。
        """
        params: Dict[str, str] = {}
        if start_time:
            params["start_time"] = start_time
        if end_time:
            params["end_time"] = end_time
        if api_type:
            params["api_type"] = api_type
        if provider:
            params["provider"] = provider
        if model_name:
            params["model_name"] = model_name
        if api_key:
            params["api_key"] = api_key

        data, success, err = await self.async_client._request("GET", "/api/usage/model_usage_ratio", params=params)
        if not success:
            raise Exception(f"获取模型调用比例失败: {err}" if err else "获取模型调用比例失败")
        return data
