"""
Seedance 2.0 私域素材库（方舟素材 API 经本服务转发）

- **鉴权**：使用 PixelArray 微服务的 ``api_key``（请求头 ``X-API-Key``），无需在客户端配置火山 AK/SK。
- **网关路径**：``/api/llm/ark_assets/*``（``base_url`` 一般为 ``https://test-llm-v2.pixelarrayai.com``）。
- **服务端**：须已配置 ``VOLCENGINE_ACCESS_KEY_ID`` / ``VOLCENGINE_ACCESS_KEY_SECRET``，且控制台已开通素材资产库权限。
- **项目隔离**：``project_name`` 须与素材所在火山项目、推理接入点一致；不传时方舟侧多为 ``default``。
- **生成视频**：素材 ``Status`` 为 ``Active`` 后，用 :meth:`SeedanceAssetsManagerAsync.asset_reference` 得到 ``asset://...``，
  填入 ``LLMCallManagerAsync.call_model`` 的 ``input`` 中 ``images`` / ``videos`` / ``audios`` 的 URL 列表（配合 Seedance 2.0 模型）。

**真人人像（LivenessFace）——其它项目集成时的调用顺序**（勿用 :meth:`create_group` 建组）：

1. **先**调用 :meth:`create_visual_validate_session`（``callback_url`` 可省略，见返回 ``callback_url_used``）。保存 ``byted_token_convenience`` / ``BytedToken``，
   并让用户在浏览器或 WebView 打开 ``h5_link_convenience`` 完成活体。
2. 用户通过后，方舟跳转 CallbackURL，``resultCode=10000`` 表示成功。须在 **BytedToken 约 120 秒有效期内**，用**同一会话**的 Token 调用
   :meth:`get_visual_validate_result` 换取 ``group_id_convenience`` / ``GroupId``。
3. **轮询**：若单次调用尚未返回组 ID（上游可能略有延迟），可对**同一** ``byted_token`` **间隔数秒重复调用** :meth:`get_visual_validate_result`，
   直到拿到组 ID或失败（总时长勿超过 Token 有效期；间隔可参考 2～5 秒）。
4. 拿到 ``group_id`` 后：:meth:`upload_asset` → :meth:`wait_until_active` → :meth:`asset_reference`；列表筛选 ``group_type="LivenessFace"``。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from pixelarrayllm.client import AsyncClient

_JSON = Dict[str, Any]

# 方舟 CreateAssetGroup.GroupType / List Filter.GroupType（与官方一致）
ARK_GROUP_TYPE_AIGC = "AIGC"
ARK_GROUP_TYPE_LIVENESS_FACE = "LivenessFace"


class SeedanceAssetsManagerAsync:
    """
    Seedance 私域素材库管理（异步）。

    **虚拟人像推荐流程**：:meth:`create_group` → :meth:`upload_asset` → :meth:`wait_until_active`
    → :meth:`asset_reference` 再调用视频生成。

    **真人人像（与其它项目对接）**：必须先 :meth:`create_visual_validate_session`，用户完成 H5 后再调用 :meth:`get_visual_validate_result`
    换取组 ID；若一次未返回 ``group_id_convenience``，可对同一 ``byted_token`` **轮询**后者直至成功或超时（详见模块顶部说明与两方法 docstring）。

    返回值一般为网关 ``data`` 字典，内含方舟返回字段（如 ``Result``、``Items``、``asset_uri``、``h5_link_convenience`` 等），具体以服务端为准。
    """

    def __init__(self, api_key: str, base_url: str = "https://test-llm-v2.pixelarrayai.com"):
        """
        Args:
            api_key: PixelArray 用户 API Key（与 ``LLMCallManagerAsync`` 相同）。
            base_url: 微服务根地址，不含路径后缀；生产环境默认 ``https://test-llm-v2.pixelarrayai.com``。
        """
        self.api_key = api_key
        self.base_url = base_url
        self._client = AsyncClient(api_key, base_url)

    async def _post(self, path: str, payload: _JSON) -> Any:
        data, ok, err = await self._client._request("POST", path, json=payload)
        if not ok:
            raise Exception(f"素材库请求失败: {path}" + (f" ({err})" if err else ""))
        return data

    @staticmethod
    def asset_reference(asset_id: str) -> str:
        """
        将方舟返回的素材 ID 转为 Seedance 2.0 视频生成可用的 URI。

        Args:
            asset_id: 素材 ID，形如 ``asset-20260318...``；若已带 ``asset://`` 前缀则原样返回。

        Returns:
            ``asset://<asset_id>``，用于 ``call_model`` 里 ``images`` / ``videos`` / ``audios`` 的 ``url`` 类型内容
            （提示词中请用「图片 1、视频 1」指代，勿直接写 ID）。
        """
        aid = asset_id.strip()
        if aid.startswith("asset://"):
            return aid
        return f"asset://{aid}"

    async def create_group(
        self,
        name: str,
        description: str = "",
        *,
        group_type: str = ARK_GROUP_TYPE_AIGC,
        project_name: Optional[str] = None,
    ) -> _JSON:
        """
        创建素材组（Asset Group）。

        Args:
            name: 素材组合名称，用于控制台与列表展示。
            description: 文字说明，可空字符串。
            group_type: **仅** ``AIGC``（虚拟人像，默认 ``ARK_GROUP_TYPE_AIGC``）。勿传 ``LivenessFace``：网关会拒绝；
                真人人像组须通过 :meth:`create_visual_validate_session` / :meth:`get_visual_validate_result` 取得。
            project_name: 火山资源项目名。与上传素材、推理 Endpoint 须在同一项目；不传则服务端/方舟常用 ``default``。

        Returns:
            网关返回的 ``data``，常含 ``group_id_convenience`` 或方舟 ``Result.Id`` 等，请以实际响应为准。
        """
        body: _JSON = {"name": name, "description": description, "group_type": group_type}
        if project_name:
            body["project_name"] = project_name
        return await self._post("/api/llm/ark_assets/create_asset_group", body)

    async def create_visual_validate_session(
        self,
        callback_url: Optional[str] = None,
        *,
        project_name: Optional[str] = None,
    ) -> _JSON:
        """
        真人人像：**第一步**——创建 H5 活体认证会话（方舟 ``CreateVisualValidateSession``）。

        与其它项目集成时，须**先**调用本方法，再让用户打开返回中的 H5 链接完成活体，之后才调用 :meth:`get_visual_validate_result`。

        Args:
            callback_url: 认证结束后跳转 URL；省略时使用服务端默认托管 CallbackURL（响应 ``callback_url_used`` 为实际值）。
            project_name: 资源项目名，素材组将创建在该项目内。

        Returns:
            网关 ``data``，常含 ``h5_link_convenience``（用户打开）、``byted_token_convenience``（与后续 ``get_visual_validate_result`` 的 ``byted_token`` 一致）、
            ``callback_url_used`` 等。
        """
        body: _JSON = {}
        if callback_url and str(callback_url).strip():
            body["callback_url"] = str(callback_url).strip()
        if project_name:
            body["project_name"] = project_name
        return await self._post("/api/llm/ark_assets/create_visual_validate_session", body)

    async def get_visual_validate_result(
        self,
        byted_token: str,
        *,
        project_name: Optional[str] = None,
    ) -> _JSON:
        """
        真人人像：**用户完成 H5 活体之后**调用——用 ``CreateVisualValidateSession`` 返回的 **BytedToken**
        （与 ``byted_token_convenience`` 相同）查询素材组 ID（方舟 ``GetVisualValidateResult``）。

        **时效**：Token 约 **120 秒**有效，须在用户活体通过后尽快调用。

        **轮询**：若单次响应中尚无 ``group_id_convenience`` / ``GroupId``，可对**同一** ``byted_token`` **间隔数秒重复调用**本方法，
        直到拿到组 ID 或明确失败（总时长勿超过 Token 有效期；间隔可参考 2～5 秒）。

        Args:
            byted_token: 与 :meth:`create_visual_validate_session` 返回的 ``BytedToken`` / ``byted_token_convenience`` 一致。
            project_name: 与创建会话时一致。

        Returns:
            网关 ``data``，成功时常含 ``group_id_convenience``（``group-...``），再用于 :meth:`upload_asset`。
        """
        body: _JSON = {"byted_token": byted_token.strip()}
        if project_name:
            body["project_name"] = project_name
        return await self._post("/api/llm/ark_assets/get_visual_validate_result", body)

    async def upload_asset(
        self,
        group_id: str,
        url: str,
        asset_type: str,
        *,
        name: Optional[str] = None,
        project_name: Optional[str] = None,
    ) -> _JSON:
        """
        上传单个素材（CreateAsset，异步处理）。

        Args:
            group_id: 目标素材组 ID，形如 ``group-...``。**AIGC** 组来自 :meth:`create_group`；**LivenessFace** 组须来自 :meth:`get_visual_validate_result`，勿混用。
            url: 素材文件 **公网可访问** 的 HTTP(S) 地址；图片/视频/音频格式限制见方舟文档。
            asset_type: 素材类型，取值：``Image``、``Video``、``Audio``（大小写与官方一致）。
            name: 可选展示名，仅用于列表检索，**不参与**模型推理。
            project_name: 资源项目名，须与 ``group_id`` 所在项目一致；不传则多为 ``default``。

        Returns:
            网关 ``data``，通常含素材 ``Id``；需再 :meth:`get_asset` 或 :meth:`wait_until_active` 直至 ``Status`` 为 ``Active``。
        """
        body: _JSON = {
            "group_id": group_id,
            "url": url,
            "asset_type": asset_type,
        }
        if name:
            body["name"] = name
        if project_name:
            body["project_name"] = project_name
        return await self._post("/api/llm/ark_assets/create_asset", body)

    async def get_asset(self, asset_id: str, *, project_name: Optional[str] = None) -> _JSON:
        """
        查询单个素材详情与处理状态。

        Args:
            asset_id: 素材 ID，形如 ``asset-...``。
            project_name: 素材所在项目名；与上传时 ``project_name`` 不一致会导致查不到，建议与入库时一致。

        Returns:
            含 ``Status`` 等字段：``Processing``（处理中）、``Active``（可用）、``Failed``（失败）。
        """
        body: _JSON = {"id": asset_id}
        if project_name:
            body["project_name"] = project_name
        return await self._post("/api/llm/ark_assets/get_asset", body)

    def _build_asset_filter(
        self,
        *,
        group_type: str = ARK_GROUP_TYPE_AIGC,
        group_ids: Optional[Union[str, List[str]]] = None,
        statuses: Optional[List[str]] = None,
        name: Optional[str] = None,
        extra: Optional[_JSON] = None,
    ) -> _JSON:
        f: _JSON = {"GroupType": group_type}
        if group_ids is not None:
            f["GroupIds"] = group_ids if isinstance(group_ids, list) else [group_ids]
        if statuses:
            f["Statuses"] = statuses
        if name:
            f["Name"] = name
        if extra:
            f.update(extra)
        return f

    async def list_assets(
        self,
        *,
        group_type: str = ARK_GROUP_TYPE_AIGC,
        group_ids: Optional[Union[str, List[str]]] = None,
        statuses: Optional[List[str]] = None,
        name: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None,
        filter_extra: Optional[_JSON] = None,
    ) -> _JSON:
        """
        分页查询素材列表（ListAssets）。

        Args:
            group_type: 方舟 ``Filter.GroupType``：``ARK_GROUP_TYPE_AIGC`` = 虚拟人像；``ARK_GROUP_TYPE_LIVENESS_FACE`` = 真人人像。
                默认 AIGC；**查真人人像素材时必须显式传** ``LivenessFace``，否则默认 AIGC 下查不到。
            group_ids: 只查指定素材组，单个 ID 字符串或 ID 列表，形如 ``group-...``。
            statuses: 状态列表，常见取值：``Active``（已就绪可用）、``Processing``（处理中）、``Failed``（失败）。
            name: 按素材名称 **模糊** 搜索（对应上传时的 ``name``）。
            page: 页码，从 1 开始。
            page_size: 每页条数，建议 1～100。
            sort_by: 排序字段，以方舟文档为准（如 ``GroupId``）。
            sort_order: 排序方向，常见 ``Asc`` / ``Desc``。
            filter_extra: 额外合并进方舟 ``Filter`` 的键值（可覆盖同名键），用于官方文档中的扩展筛选项。

        Returns:
            通常含 ``Items``、``TotalCount``、``PageNumber``、``PageSize``。
        """
        flt = self._build_asset_filter(
            group_type=group_type,
            group_ids=group_ids,
            statuses=statuses,
            name=name,
            extra=filter_extra,
        )
        body: _JSON = {
            "filter": flt,
            "page_number": page,
            "page_size": page_size,
        }
        if sort_by:
            body["sort_by"] = sort_by
        if sort_order:
            body["sort_order"] = sort_order
        return await self._post("/api/llm/ark_assets/list_assets", body)

    async def list_groups(
        self,
        *,
        group_type: str = ARK_GROUP_TYPE_AIGC,
        name: Optional[str] = None,
        group_ids: Optional[Union[str, List[str]]] = None,
        page: int = 1,
        page_size: int = 10,
        filter_extra: Optional[_JSON] = None,
    ) -> _JSON:
        """
        分页查询素材组列表（ListAssetGroups）。

        Args:
            group_type: ``AIGC`` | ``LivenessFace``（模块常量 ``ARK_GROUP_TYPE_*``）。列真人人像组须为 ``LivenessFace``。
            name: 按素材组名称 **模糊** 搜索。
            group_ids: 指定一个或多个素材组 ID 精确筛选。
            page: 页码，从 1 开始。
            page_size: 每页条数。
            filter_extra: 合并进 ``Filter`` 的扩展字段。

        Returns:
            通常含 ``Items``、``TotalCount`` 等。
        """
        flt: _JSON = {"GroupType": group_type}
        if name:
            flt["Name"] = name
        if group_ids is not None:
            flt["GroupIds"] = group_ids if isinstance(group_ids, list) else [group_ids]
        if filter_extra:
            flt.update(filter_extra)
        return await self._post(
            "/api/llm/ark_assets/list_asset_groups",
            {"filter": flt, "page_number": page, "page_size": page_size},
        )

    async def wait_until_active(
        self,
        asset_id: str,
        *,
        project_name: Optional[str] = None,
        interval_seconds: float = 3.0,
        timeout_seconds: float = 120.0,
    ) -> _JSON:
        """
        轮询 GetAsset，直到素材 ``Status`` 为 ``Active``，或失败/超时。

        Args:
            asset_id: 上传接口返回的素材 ID。
            project_name: 与 :meth:`upload_asset` 使用的项目名一致。
            interval_seconds: 两次查询间隔（秒），默认 3，范围以服务端接口校验为准（约 1～30）。
            timeout_seconds: 最长等待时间（秒），默认 120，超时抛错。

        Returns:
            网关封装结果，通常含 ``get_asset_response`` 与 ``asset_uri``。
        """
        body: _JSON = {
            "asset_id": asset_id,
            "interval_seconds": interval_seconds,
            "timeout_seconds": timeout_seconds,
        }
        if project_name:
            body["project_name"] = project_name
        return await self._post("/api/llm/ark_assets/wait_asset_active", body)

    async def update_group(
        self,
        group_id: str,
        name: str,
        *,
        description: str = "",
        project_name: Optional[str] = None,
    ) -> _JSON:
        """
        修改素材组名称与描述（UpdateAssetGroup）。

        Args:
            group_id: 素材组 ID ``group-...``。
            name: 新的展示名称。
            description: 新的描述文字；空字符串表示清空描述（若方舟支持）。
            project_name: 该素材组所在项目名，需与创建时一致。

        Returns:
            方舟/网关返回体。
        """
        body: _JSON = {
            "group_id": group_id,
            "name": name,
            "description": description,
        }
        if project_name:
            body["project_name"] = project_name
        return await self._post("/api/llm/ark_assets/update_asset_group", body)

    async def delete_asset(self, asset_id: str, *, project_name: Optional[str] = None) -> _JSON:
        """
        删除单个素材（DeleteAsset），**不可恢复**。

        Args:
            asset_id: 素材 ID ``asset-...``。
            project_name: 素材所在项目名，与入库时一致。

        Returns:
            删除结果，具体字段以方舟返回为准。
        """
        body: _JSON = {"id": asset_id}
        if project_name:
            body["project_name"] = project_name
        return await self._post("/api/llm/ark_assets/delete_asset", body)
