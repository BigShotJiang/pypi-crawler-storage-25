import os
import uuid
import time

from git import Repo
import chromadb
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# AI SDKs
from openai import OpenAI
import google.generativeai as genai
import anthropic

# ─────────────────────────────────────────────
# GLOBALS
# ─────────────────────────────────────────────
_ai_config     = {}
_openai_client = None
_claude_client = None
_language      = "English"
_ai_disabled   = False

CHROMA_CLIENT = chromadb.PersistentClient(path="./chroma_db")

SUPPORTED_EXT = (
    ".py", ".c", ".h", ".cpp", ".js", ".ts", ".md", ".txt",
    ".java", ".go", ".rs", ".php", ".rb", ".swift",
    ".cs", ".html", ".css", ".json", ".yaml", ".yml", ".xml",
    ".sh", ".bat", ".ps1", ".gradle", ".makefile",
    ".ini", ".cfg", ".conf", ".log", ".sql", ".ipynb",
    ".vue", ".jsx", ".tsx", ".dart", ".scala",
    ".pl", ".lua", ".r", ".m", ".kt", ".kts",
    ".groovy", ".clj", ".cljs", ".coffee", ".elm",
)

# Extensionless files to match by exact name
SUPPORTED_NAMES = ("Dockerfile", "Makefile", "makefile")

AI_OPTIONS = {
    "gemini": {
        "name": "Gemini",
        "text_model": "models/gemini-2.5-flash",
        "embed_model": "models/text-embedding-004",
    },
    "openai": {
        "name": "OpenAI",
        "text_model": "gpt-4o-mini",
        "embed_model": "text-embedding-3-large",
    },
    "claude": {
        "name": "Claude",
        "text_model": "claude-sonnet-4-5",
        "embed_model": None,  # Claude has no embedding API; Gemini embeddings used as fallback
    },
}


# ─────────────────────────────────────────────
# INIT
# ─────────────────────────────────────────────
def init(ai_choice: str, api_key: str, language: str = "English"):
    global _ai_config, _openai_client, _claude_client, _language

    _language  = language
    _ai_config = AI_OPTIONS[ai_choice]

    if ai_choice == "gemini":
        genai.configure(api_key=api_key)

    elif ai_choice == "openai":
        _openai_client = OpenAI(api_key=api_key)

    elif ai_choice == "claude":
        # Claude has no embeddings — configure Gemini as fallback embedder.
        # Set GEMINI_API_KEY in your .env for RAG to work with --ai claude.
        _claude_client = anthropic.Anthropic(api_key=api_key)
        gemini_key = os.getenv("GEMINI_API_KEY")
        if gemini_key:
            genai.configure(api_key=gemini_key)
        else:
            print(
                "⚠️  Warning: Claude has no embedding API. "
                "Set GEMINI_API_KEY in .env for RAG to work correctly. "
                "Without it, chat/RAG results will be unreliable."
            )


# ─────────────────────────────────────────────
# COLLECTION PER REPO
# ─────────────────────────────────────────────
def get_collection(repo_name: str):
    safe_name = repo_name.replace("-", "_").replace(".", "_")
    return CHROMA_CLIENT.get_or_create_collection(name=f"repo_{safe_name}")


# ─────────────────────────────────────────────
# AI — GENERATE
# ─────────────────────────────────────────────
def safe_generate(prompt: str, retries: int = 2) -> str | None:
    global _ai_disabled

    if _ai_disabled:
        return None

    for attempt in range(retries):
        try:
            name = _ai_config["name"]

            if name == "Gemini":
                model = genai.GenerativeModel(_ai_config["text_model"])
                res   = model.generate_content(
                    prompt,
                    generation_config={"max_output_tokens": 8192},
                )
                return getattr(res, "text", None)

            elif name == "OpenAI":
                res = _openai_client.chat.completions.create(
                    model=_ai_config["text_model"],
                    max_tokens=4096,
                    messages=[{"role": "user", "content": prompt}],
                )
                return res.choices[0].message.content

            elif name == "Claude":
                res = _claude_client.messages.create(
                    model=_ai_config["text_model"],
                    max_tokens=4096,
                    messages=[{"role": "user", "content": prompt}],
                )
                return res.content[0].text

        except Exception as e:
            err = str(e)
            if "429" in err or "quota" in err.lower():
                print("⚠️  Quota exceeded → AI disabled for this session")
                _ai_disabled = True
                return None
            print(f"⚠️  Generation error (attempt {attempt + 1}/{retries}): {err}")
            if attempt < retries - 1:
                time.sleep(2)

    return None


# ─────────────────────────────────────────────
# AI — EMBED
# ─────────────────────────────────────────────
def embed_text(text: str) -> list[float]:
    try:
        name = _ai_config["name"]

        if name == "Gemini":
            return genai.embed_content(
                model=_ai_config["embed_model"],
                content=text,
            )["embedding"]

        elif name == "OpenAI":
            res = _openai_client.embeddings.create(
                model=_ai_config["embed_model"],
                input=text,
            )
            return res.data[0].embedding

        elif name == "Claude":
            # Fallback: use Gemini embeddings if GEMINI_API_KEY is set
            try:
                return genai.embed_content(
                    model="models/text-embedding-004",
                    content=text,
                )["embedding"]
            except Exception:
                pass

        # Last resort: zero vector (RAG will be unreliable)
        return [0.0] * 1536

    except Exception:
        return [0.0] * 1536


# ─────────────────────────────────────────────
# REPO — CLONE & LOAD
# ─────────────────────────────────────────────
def clone_repo(url: str, branch: str = None) -> tuple[str, str]:
    os.makedirs("repos", exist_ok=True)
    name = url.rstrip("/").split("/")[-1].replace(".git", "")
    path = os.path.join("repos", name)

    if not os.path.exists(path):
        print(f"📥 Cloning {url} ...")
        kwargs = {"branch": branch} if branch else {}
        Repo.clone_from(url, path, **kwargs)
    else:
        print(f"✅ Repo already exists at {path}")

    return path, name


def load_files(repo_path: str) -> list[tuple[str, str]]:
    files_data = []

    for root, _, files in os.walk(repo_path):
        if any(part.startswith(".") for part in root.split(os.sep)):
            continue
        for file in files:
            if file.endswith(SUPPORTED_EXT) or file in SUPPORTED_NAMES:
                try:
                    with open(os.path.join(root, file), "r", errors="ignore") as f:
                        content = f.read().strip()
                        if content:
                            files_data.append((file, content))
                except Exception:
                    pass

    print(f"📂 Loaded {len(files_data)} source files")
    return files_data


# ─────────────────────────────────────────────
# CHUNKING
# ─────────────────────────────────────────────
def chunk_by_file(files: list[tuple[str, str]], max_chars: int = 3000) -> list[str]:
    chunks, current = [], ""

    for fname, content in files:
        piece = f"\n# FILE: {fname}\n{content}\n"
        if len(current) + len(piece) > max_chars:
            if current:
                chunks.append(current)
            current = piece
        else:
            current += piece

    if current:
        chunks.append(current)

    return chunks


# ─────────────────────────────────────────────
# CHROMADB — STORE & QUERY
# ─────────────────────────────────────────────
def store_chunks(files: list[tuple[str, str]], repo_name: str):
    collection = get_collection(repo_name)
    print("💾 Storing embeddings...")

    for fname, content in files:
        emb = embed_text(content)
        collection.add(
            documents=[content],
            embeddings=[emb],
            ids=[str(uuid.uuid4())],
            metadatas=[{"file": fname}],
        )


def query_rag(question: str, repo_name: str) -> str:
    collection = get_collection(repo_name)

    emb  = embed_text(question)
    res  = collection.query(query_embeddings=[emb], n_results=5)
    docs = res.get("documents", [[]])[0]
    context = "\n".join(docs) if docs else ""

    prompt = f"""Answer in {_language}.

Context from codebase:
{context}

Question:
{question}
"""
    return safe_generate(prompt) or "⚠️ AI unavailable."


# ─────────────────────────────────────────────
# ANALYSIS
# ─────────────────────────────────────────────
def analyze_repo(files: list[tuple[str, str]]) -> str:
    print("\n🔍 Analyzing repo...\n")
    chunks    = chunk_by_file(files)
    summaries = []

    for i, chunk in enumerate(chunks, 1):
        print(f"  Chunk {i}/{len(chunks)}")
        res = safe_generate(f"""Analyze this code chunk in {_language}.
Provide an in-depth explanation covering:
- What this code does and its purpose
- Key functions/classes and their logic in detail
- Important algorithms or patterns used
- Any notable code snippets worth highlighting (include them as-is)
- Dependencies and how they interact

Code:
{chunk}
""")
        if res:
            summaries.append(res)

    if not summaries:
        return "⚠️ AI unavailable — no analysis generated."

    return safe_generate(f"""Respond ONLY in {_language}.

Using the summaries below, write a comprehensive and detailed technical report with these sections:

### Summary
A thorough overview of what this project does, its goals, and target use case.

### Architecture
Detailed explanation of how the system is structured, component relationships, data flow, and design patterns used. Include relevant code snippets to illustrate.

### Tech Stack
Every library, framework, and tool used — explain why each one is likely used and what role it plays.

### Code Highlights
Notable or interesting code patterns, clever implementations, or important functions. Include actual code snippets with explanations.

### Issues
Specific bugs, anti-patterns, security concerns, or technical debt found in the code with references to where they appear.

### Suggested Improvements
Concrete, actionable improvements with example code snippets showing how to implement them.

Be thorough and elaborate. Do not summarize — explain in depth.

Summaries:
{chr(10).join(summaries)}
""") or "⚠️ Final synthesis failed."


# ─────────────────────────────────────────────
# DIAGRAMS
# ─────────────────────────────────────────────
def _clean(name: str) -> str:
    return (
        name.replace(".py", "_py")
            .replace(".", "_")
            .replace("-", "_")
            .replace("/", "_")
    )


def generate_diagram(files: list[tuple[str, str]]):
    G = nx.DiGraph()

    for fname, content in files:
        for line in content.splitlines():
            line = line.strip()
            if line.startswith(("import ", "from ", "#include")):
                G.add_edge(fname, line)

    os.makedirs("output", exist_ok=True)
    plt.figure(figsize=(12, 9))
    nx.draw(G, with_labels=True, node_size=800, font_size=7, arrows=True)
    plt.tight_layout()
    plt.savefig("output/diagram.png", dpi=150)
    plt.close()
    print("📊 Saved output/diagram.png")


def generate_mermaid(files: list[tuple[str, str]]):
    lines, seen = ["graph TD"], set()

    for fname, content in files:
        file_node = _clean(fname)

        for line in content.splitlines():
            line   = line.strip()
            module = None

            if line.startswith("import "):
                parts = line.replace(",", " ").split()
                if len(parts) >= 2:
                    module = _clean(parts[1])

            elif line.startswith("from "):
                parts = line.split()
                if len(parts) >= 2:
                    module = _clean(parts[1])

            elif line.startswith("#include"):
                module = _clean(line.replace("#include", "").strip())

            if module:
                edge = f"{file_node} --> {module}"
                if edge not in seen:
                    lines.append(f"    {edge}")
                    seen.add(edge)

    os.makedirs("output", exist_ok=True)
    with open("output/mermaid.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("🗺️  Saved output/mermaid.txt")


# ─────────────────────────────────────────────
# PDF
# ─────────────────────────────────────────────
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _register_fonts():
    font_dir = os.path.join(_BASE_DIR, "fonts")
    mappings = {
        "NotoLatin":      "NotoSans-Regular.ttf",
        "NotoBengali":    "NotoSansBengali-Regular.ttf",
        "NotoDevanagari": "NotoSansDevanagari-Regular.ttf",
    }
    for font_name, filename in mappings.items():
        path = os.path.join(font_dir, filename)
        if os.path.exists(path):
            pdfmetrics.registerFont(TTFont(font_name, path))


def _get_font(language: str) -> str:
    lang = language.lower()
    if lang in ("bengali", "bangla"):
        font = "NotoBengali"
    elif lang == "hindi":
        font = "NotoDevanagari"
    else:
        font = "NotoLatin"

    try:
        pdfmetrics.getFont(font)
        return font
    except KeyError:
        return "Helvetica"


def generate_pdf(text: str):
    os.makedirs("output", exist_ok=True)
    _register_fonts()
    font = _get_font(_language)

    styles = {
        "title": ParagraphStyle("title", fontName=font, fontSize=20, textColor=colors.darkblue),
        "head":  ParagraphStyle("head",  fontName=font, fontSize=14, textColor=colors.blue),
        "body":  ParagraphStyle("body",  fontName=font, fontSize=11),
    }

    story = [
        Paragraph(f"Repo Analysis Report ({_language})", styles["title"]),
        Spacer(1, 12),
    ]

    for section in text.split("###"):
        lines = section.strip().splitlines()
        if not lines:
            continue
        heading = lines[0].strip()
        if not heading:
            continue
        story.append(Paragraph(heading, styles["head"]))
        body_text = "<br/>".join(l for l in lines[1:] if l.strip())
        if body_text:
            story.append(Paragraph(body_text, styles["body"]))
        story.append(Spacer(1, 10))

    diagram_path = "output/diagram.png"
    if os.path.exists(diagram_path):
        story.append(Image(diagram_path, width=420, height=300))

    SimpleDocTemplate("output/report.pdf").build(story)
    print("📄 Saved output/report.pdf")