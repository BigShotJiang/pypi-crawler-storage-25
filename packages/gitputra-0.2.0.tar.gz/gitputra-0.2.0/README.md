# 🔍 GitPutra

<p align="center">
  <img src="https://img.shields.io/pypi/v/gitputra?color=blue&label=PyPI&logo=pypi&logoColor=white" alt="PyPI Version">
  <img src="https://img.shields.io/pypi/pyversions/gitputra?color=blue&logo=python&logoColor=white" alt="Python Versions">
  <img src="https://img.shields.io/pypi/dm/gitputra?color=green&label=Downloads&logo=pypi&logoColor=white" alt="Downloads">
  <img src="https://img.shields.io/pypi/l/gitputra?color=yellow" alt="License">
  <img src="https://img.shields.io/badge/AI-Gemini%20%7C%20OpenAI%20%7C%20Claude-blueviolet?logo=openai&logoColor=white" alt="AI Providers">
</p>

<p align="center">
  <b>AI-powered GitHub repository analyzer CLI.</b><br>
  Clone any repo, generate a structured analysis report, visualize architecture, and chat with your codebase — all from the terminal.
</p>

---

## ✨ Features

- 🔍 **Deep Repo Analysis** — AI-generated structured report covering Summary, Architecture, Tech Stack, Issues, and Suggested Improvements
- 💬 **RAG Chat** — Ask questions about any codebase using Retrieval-Augmented Generation (ChromaDB + embeddings)
- 🤖 **Multi-AI Support** — Works with Google Gemini, OpenAI, and Anthropic Claude
- 🌿 **Branch Support** — Analyze or chat with any specific branch of a repo
- 📊 **Dependency Diagrams** — Auto-generates NetworkX graph diagram + Mermaid flowchart
- 📄 **Multilingual PDF Reports** — Exports analysis as a styled PDF in ~110 languages
- 🗂️ **Smart Indexing** — Skips re-embedding if a repo is already indexed; run `clear-db` to reset
- 📁 **48+ File Types** — Supports Python, C/C++, Java, Go, Rust, JS/TS, and many more

---

## 📦 Installation

```bash
pip install gitputra
```

Requires Python 3.10+

---

## 🚀 Usage & Examples

### Analyze a Repository

```bash
gitputra analyze https://github.com/user/repo --ai gemini --key YOUR_API_KEY
```

With options:

```bash
# Use OpenAI, output in Bengali, skip diagram
gitputra analyze https://github.com/user/repo --ai openai --key YOUR_KEY --lang Bengali --no-diagram

# Use Claude, skip PDF
gitputra analyze https://github.com/user/repo --ai claude --key YOUR_KEY --no-pdf
```

Outputs saved to `./output/`:
- `report.pdf` — Full analysis report
- `diagram.png` — Dependency graph
- `mermaid.txt` — Mermaid flowchart source

### Chat with a Repository

```bash
gitputra chat https://github.com/user/repo --ai gemini --key YOUR_API_KEY
```

```
💬 Chat mode [repo] — ask anything about the repo. Type 'exit' to quit.

>>  What does the main.py file do?
>>  How is authentication handled?
>>  exit
```

> If `analyze` was already run on the repo, `chat` reuses the existing index automatically.

### Analyze or Chat with a Specific Branch

```bash
# Analyze a specific branch
gitputra analyze https://github.com/user/repo --branch dev --ai gemini --key YOUR_API_KEY

# Chat with a specific branch
gitputra chat https://github.com/user/repo --branch feature/my-branch --ai gemini --key YOUR_API_KEY
```

> If `--branch` is not specified, the repo's default branch is used.

### Clear the Local Index

```bash
gitputra clear-db
```

### Show Info & Capabilities

```bash
gitputra info
```

### Check Version

```bash
gitputra --version
```

---

## 🤖 AI Providers

| Flag | Provider | Text Model | Embedding Model |
|------|----------|------------|-----------------|
| `--ai gemini` | Google Gemini | gemini-2.5-flash | text-embedding-004 |
| `--ai openai` | OpenAI | gpt-4o-mini | text-embedding-3-large |
| `--ai claude` | Anthropic Claude | claude-sonnet-4-5 | via `GEMINI_API_KEY` fallback |

> **Note:** Claude has no embedding API. For RAG/chat with `--ai claude`, set `GEMINI_API_KEY` in your `.env` file to enable embeddings.

### Setting up your API Key

**Option 1 — `.env` file (recommended):**

```env
API_KEY=your_api_key_here
GEMINI_API_KEY=your_gemini_key  # only needed for --ai claude with chat
```

**Option 2 — CLI flag:**

```bash
gitputra analyze https://github.com/user/repo --key YOUR_API_KEY
```

> Avoid Option 2 in shared environments — CLI flags appear in shell history.

---

## 🌍 Supported Languages (PDF Output)

GitPutra can generate PDF reports in ~110 languages across 3 scripts:

### Latin Script (~100 languages)
English, French, Spanish, Portuguese, Italian, German, Dutch, Swedish, Norwegian, Danish, Finnish, Polish, Czech, Slovak, Hungarian, Romanian, Croatian, Serbian (Latin), Slovenian, Albanian, Lithuanian, Latvian, Estonian, Turkish, Azerbaijani, Uzbek, Kazakh (Latin), Turkmen, Indonesian, Malay, Filipino, Swahili, Zulu, Xhosa, Afrikaans, Yoruba, Igbo, Hausa, Somali, Kinyarwanda, Welsh, Irish, Basque, Catalan, Galician, Maltese, Icelandic, Faroese, Vietnamese, Hawaiian, Maori, and more.

### Bengali Script
Bengali, Assamese

### Devanagari Script
Hindi, Marathi, Nepali, Sanskrit, Maithili, Konkani, Bodo, Dogri

> The AI response language depends on the chosen model's capability. Use `--lang` to set the output language.

```bash
gitputra analyze https://github.com/user/repo --ai gemini --key KEY --lang Bengali
```

---

## 📁 Supported File Extensions (48 types)

| Category | Extensions |
|----------|-----------|
| Python | `.py`, `.ipynb` |
| C/C++ | `.c`, `.h`, `.cpp` |
| Web | `.js`, `.ts`, `.jsx`, `.tsx`, `.html`, `.css`, `.vue` |
| JVM | `.java`, `.kt`, `.kts`, `.scala`, `.groovy`, `.clj`, `.cljs` |
| Systems | `.go`, `.rs`, `.swift`, `.dart` |
| Scripting | `.sh`, `.bat`, `.ps1`, `.pl`, `.lua`, `.r`, `.m`, `.rb`, `.php`, `.coffee`, `.elm` |
| Config | `.json`, `.yaml`, `.yml`, `.xml`, `.ini`, `.cfg`, `.conf`, `.gradle`, `.makefile` |
| Docs | `.md`, `.txt`, `.log`, `.sql` |
| Special | `Dockerfile`, `Makefile` |

---

## 👨‍💻 Author

**Adityava Gangopadhyay**

- 📧 Email: adityava49cse@gmail.com
- 🔗 LinkedIn: [adityava-gangopadhyay](https://www.linkedin.com/in/adityava-gangopadhyay)
- 📦 PyPI: [pypi.org/project/gitputra](https://pypi.org/project/gitputra/)

Feel free to reach out for any suggestions or issues!

---

## 📄 License

MIT License — free to use, modify, and distribute.