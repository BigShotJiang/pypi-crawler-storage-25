from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DEFAULT_REF = "refs/git-as-memory/memory/v1"
SCHEMA_VERSION = 1


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def git(repo: str, args: list[str], *, input_text: str | None = None, env: dict[str, str] | None = None, allow_failure: bool = False) -> str:
    full_env = os.environ.copy()
    if env:
        full_env.update(env)
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=repo,
            input=input_text,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=full_env,
            check=True,
        )
        return result.stdout.rstrip("\n")
    except subprocess.CalledProcessError as error:
        if allow_failure:
            return ""
        raise RuntimeError((error.stderr or error.stdout or str(error)).strip()) from error


def resolve_repo(repo: str) -> str:
    return git(repo, ["rev-parse", "--show-toplevel"]).strip()


def ref_exists(repo: str, ref: str) -> bool:
    return bool(git(repo, ["rev-parse", "--verify", "--quiet", ref], allow_failure=True))


def ref_commit(repo: str, ref: str) -> str | None:
    if not ref_exists(repo, ref):
        return None
    return git(repo, ["rev-parse", ref])


def object_exists(repo: str, spec: str) -> bool:
    result = subprocess.run(
        ["git", "cat-file", "-e", spec],
        cwd=repo,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return result.returncode == 0


def hash_text(repo: str, text: str) -> str:
    return git(repo, ["hash-object", "-w", "--stdin"], input_text=text)


def stable_id(content: str) -> str:
    digest = hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    return f"{stamp}-{digest}"


def safe_segment(value: str) -> str:
    parts = [part for part in value.replace("\\", "/").split("/") if part]
    safe = "-".join(parts)
    safe = re.sub(r"[^a-zA-Z0-9._-]", "-", safe)
    safe = re.sub(r"-+", "-", safe).strip("-.")
    return safe or str(uuid.uuid4())


def memory_base_path(memory_type: str, memory_id: str) -> str:
    return f"memories/{safe_segment(memory_type)}/{safe_segment(memory_id)}"


def write_index_blob(repo: str, env: dict[str, str], filepath: str, content: str) -> None:
    blob = hash_text(repo, content)
    git(repo, ["update-index", "--add", "--cacheinfo", "100644", blob, filepath], env=env)


def remove_index_path(repo: str, env: dict[str, str], filepath: str) -> None:
    git(repo, ["update-index", "--force-remove", filepath], env=env, allow_failure=True)


def with_temporary_index(repo: str, ref: str, callback):
    with tempfile.TemporaryDirectory(prefix="git-as-memory-index-") as tmp:
        env = {"GIT_INDEX_FILE": str(Path(tmp) / "index")}
        if ref_exists(repo, ref):
            git(repo, ["read-tree", f"{ref}^{{tree}}"], env=env)
        return callback(env)


def commit_index(repo: str, ref: str, env: dict[str, str], message: str) -> str:
    tree = git(repo, ["write-tree"], env=env)
    parent = ref_commit(repo, ref)
    args = ["commit-tree", tree]
    if parent:
        args.extend(["-p", parent])
    args.extend(["-m", message])
    now = utc_now()
    commit_env = {
        **env,
        "GIT_AUTHOR_NAME": os.environ.get("GIT_AUTHOR_NAME", "git-as-memory"),
        "GIT_AUTHOR_EMAIL": os.environ.get("GIT_AUTHOR_EMAIL", "git-as-memory@local"),
        "GIT_AUTHOR_DATE": os.environ.get("GIT_AUTHOR_DATE", now),
        "GIT_COMMITTER_NAME": os.environ.get("GIT_COMMITTER_NAME", "git-as-memory"),
        "GIT_COMMITTER_EMAIL": os.environ.get("GIT_COMMITTER_EMAIL", "git-as-memory@local"),
        "GIT_COMMITTER_DATE": os.environ.get("GIT_COMMITTER_DATE", now),
    }
    commit = git(repo, args, env=commit_env)
    if parent:
        git(repo, ["update-ref", ref, commit, parent])
    else:
        git(repo, ["update-ref", ref, commit])
    return commit


def init_store(repo_input: str, ref: str = DEFAULT_REF) -> str:
    repo = resolve_repo(repo_input)
    schema_path = ".git-as-memory/schema.json"
    if object_exists(repo, f"{ref}:{schema_path}"):
        commit = ref_commit(repo, ref)
        assert commit is not None
        return commit

    def write(env: dict[str, str]) -> str:
        schema = {
            "schema_version": SCHEMA_VERSION,
            "kind": "git-as-memory",
            "ref": ref,
            "layout": {
                "memory": "memories/<type>/<id>/memory.json",
                "source": "memories/<type>/<id>/source.md",
                "events": "memories/<type>/<id>/events.jsonl",
            },
        }
        write_index_blob(repo, env, schema_path, json.dumps(schema, indent=2) + "\n")
        return commit_index(repo, ref, env, "Initialize git-as-memory store")

    return with_temporary_index(repo, ref, write)


def list_ref_paths(repo_input: str, ref: str = DEFAULT_REF, pattern: str = "**") -> list[str]:
    repo = resolve_repo(repo_input)
    if not ref_exists(repo, ref):
        return []
    paths = git(repo, ["ls-tree", "-r", "--name-only", ref]).splitlines()
    return [path for path in paths if fnmatch.fnmatchcase(path, pattern)]


def read_ref_file(repo_input: str, filepath: str, ref: str = DEFAULT_REF) -> str:
    repo = resolve_repo(repo_input)
    if not object_exists(repo, f"{ref}:{filepath}"):
        raise RuntimeError(f"Path not found in {ref}: {filepath}")
    return git(repo, ["show", f"{ref}:{filepath}"])


def read_memory_at_path(repo: str, ref: str, filepath: str) -> dict[str, Any] | None:
    try:
        record = json.loads(git(repo, ["show", f"{ref}:{filepath}"]))
        base = filepath.removesuffix("/memory.json")
        result: dict[str, Any] = {"record": record, "path": filepath}
        source_path = f"{base}/source.md"
        events_path = f"{base}/events.jsonl"
        if object_exists(repo, f"{ref}:{source_path}"):
            result["sourceMarkdown"] = git(repo, ["show", f"{ref}:{source_path}"])
        if object_exists(repo, f"{ref}:{events_path}"):
            result["eventsJsonl"] = git(repo, ["show", f"{ref}:{events_path}"])
        return result
    except Exception:
        return None


def list_memories(repo_input: str, ref: str = DEFAULT_REF, include_deleted: bool = False) -> list[dict[str, Any]]:
    repo = resolve_repo(repo_input)
    memories: list[dict[str, Any]] = []
    for filepath in list_ref_paths(repo, ref, "**/memory.json"):
        memory = read_memory_at_path(repo, ref, filepath)
        if memory and (include_deleted or not memory["record"].get("deleted_at")):
            memories.append(memory)
    return sorted(memories, key=lambda item: item["record"]["updated_at"], reverse=True)


def find_memory(repo_input: str, memory_id: str, *, ref: str = DEFAULT_REF, memory_type: str | None = None, include_deleted: bool = False) -> dict[str, Any] | None:
    repo = resolve_repo(repo_input)
    if memory_type:
        filepath = f"{memory_base_path(memory_type, memory_id)}/memory.json"
        if object_exists(repo, f"{ref}:{filepath}"):
            memory = read_memory_at_path(repo, ref, filepath)
            if memory and (include_deleted or not memory["record"].get("deleted_at")):
                return memory
        return None
    for memory in list_memories(repo, ref, include_deleted):
        if memory["record"]["id"] == memory_id:
            return memory
    return None


def write_memory(
    repo_input: str,
    content: str,
    *,
    ref: str = DEFAULT_REF,
    memory_id: str | None = None,
    memory_type: str = "semantic",
    tags: list[str] | None = None,
    confidence: float | None = None,
    source_markdown: str | None = None,
    events_jsonl: str | None = None,
    metadata: dict[str, Any] | None = None,
    message: str | None = None,
) -> dict[str, Any]:
    repo = resolve_repo(repo_input)
    now = utc_now()
    memory_id = memory_id or stable_id(content)
    base = memory_base_path(memory_type, memory_id)
    record_path = f"{base}/memory.json"
    existing = None
    if object_exists(repo, f"{ref}:{record_path}"):
        existing = json.loads(git(repo, ["show", f"{ref}:{record_path}"]))
    record = {
        "schema_version": SCHEMA_VERSION,
        "id": memory_id,
        "type": memory_type,
        "content": content,
        "tags": tags if tags is not None else (existing or {}).get("tags", []),
        "metadata": metadata if metadata is not None else (existing or {}).get("metadata", {}),
        "created_at": (existing or {}).get("created_at", now),
        "updated_at": now,
    }
    if confidence is not None:
        record["confidence"] = confidence
    elif existing and "confidence" in existing:
        record["confidence"] = existing["confidence"]

    def write(env: dict[str, str]) -> dict[str, Any]:
        write_index_blob(repo, env, record_path, json.dumps(record, indent=2) + "\n")
        if source_markdown is not None:
            write_index_blob(repo, env, f"{base}/source.md", source_markdown)
        if events_jsonl is not None:
            write_index_blob(repo, env, f"{base}/events.jsonl", events_jsonl)
        commit = commit_index(repo, ref, env, message or f"Memory: write {memory_type}/{memory_id}")
        return {"commit": commit, "ref": ref, "path": record_path, "record": record}

    return with_temporary_index(repo, ref, write)


def delete_memory(repo_input: str, memory_id: str, *, ref: str = DEFAULT_REF, memory_type: str | None = None) -> dict[str, Any]:
    repo = resolve_repo(repo_input)
    memory = find_memory(repo, memory_id, ref=ref, memory_type=memory_type, include_deleted=True)
    if not memory:
        raise RuntimeError(f"Memory not found: {memory_id}")
    record = {**memory["record"], "updated_at": utc_now(), "deleted_at": utc_now()}

    def write(env: dict[str, str]) -> dict[str, Any]:
        write_index_blob(repo, env, memory["path"], json.dumps(record, indent=2) + "\n")
        commit = commit_index(repo, ref, env, f"Memory: delete {record['type']}/{memory_id}")
        return {"commit": commit, "ref": ref, "path": memory["path"], "record": record}

    return with_temporary_index(repo, ref, write)


def purge_memory(repo_input: str, memory_id: str, *, ref: str = DEFAULT_REF, memory_type: str | None = None) -> str:
    repo = resolve_repo(repo_input)
    memory = find_memory(repo, memory_id, ref=ref, memory_type=memory_type, include_deleted=True)
    if not memory:
        raise RuntimeError(f"Memory not found: {memory_id}")
    base = memory["path"].removesuffix("/memory.json")

    def purge(env: dict[str, str]) -> str:
        remove_index_path(repo, env, f"{base}/memory.json")
        remove_index_path(repo, env, f"{base}/source.md")
        remove_index_path(repo, env, f"{base}/events.jsonl")
        return commit_index(repo, ref, env, f"Memory: purge {memory['record']['type']}/{memory_id}")

    return with_temporary_index(repo, ref, purge)


def search_memories(repo_input: str, query: str, *, ref: str = DEFAULT_REF, include_deleted: bool = False) -> list[dict[str, Any]]:
    terms = [term for term in query.lower().split() if term]
    results = []
    for memory in list_memories(repo_input, ref, include_deleted):
        record = memory["record"]
        haystack = "\n".join(
            [
                record.get("id", ""),
                record.get("type", ""),
                record.get("content", ""),
                " ".join(record.get("tags", [])),
                json.dumps(record.get("metadata", {})),
                memory.get("sourceMarkdown", ""),
            ]
        ).lower()
        if all(term in haystack for term in terms):
            results.append(memory)
    return results


def glob_memories(repo_input: str, pattern: str = "*", *, ref: str = DEFAULT_REF, include_deleted: bool = False, files: bool = False) -> list[dict[str, Any]]:
    entries = []
    for memory in list_memories(repo_input, ref, include_deleted):
        record = memory["record"]
        key = f"{record['type']}/{record['id']}"
        if fnmatch.fnmatchcase(key, pattern) or fnmatch.fnmatchcase(record["id"], pattern):
            entry = {"key": key, "type": record["type"], "id": record["id"], "path": memory["path"]}
            if files:
                base = memory["path"].removesuffix("/memory.json")
                entry["files"] = list_ref_paths(repo_input, ref, f"{base}/**")
            entries.append(entry)
    return entries


def memory_history(repo_input: str, memory_id: str, *, ref: str = DEFAULT_REF, memory_type: str | None = None) -> list[dict[str, str]]:
    repo = resolve_repo(repo_input)
    memory = find_memory(repo, memory_id, ref=ref, memory_type=memory_type, include_deleted=True)
    if not memory:
        return []
    out = git(repo, ["log", "--format=%H%x09%aI%x09%s", ref, "--", memory["path"]], allow_failure=True)
    rows = []
    for line in out.splitlines():
        commit, date, subject = line.split("\t", 2)
        rows.append({"commit": commit, "date": date, "subject": subject})
    return rows


def print_json(value: Any) -> None:
    print(json.dumps(value, indent=2))


def print_memory(memory: dict[str, Any]) -> None:
    record = memory["record"]
    print(f"# {record['id']}")
    print(f"type: {record['type']}")
    print(f"updated: {record['updated_at']}")
    if record.get("tags"):
        print(f"tags: {', '.join(record['tags'])}")
    if record.get("deleted_at"):
        print(f"deleted: {record['deleted_at']}")
    print()
    print(record["content"])
    if memory.get("sourceMarkdown"):
        print("\n## Source\n")
        print(memory["sourceMarkdown"])


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--repo", default=os.getcwd())
    parser.add_argument("--ref", default=DEFAULT_REF)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="git-as-memory")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init")
    add_common(init)

    write = sub.add_parser("write")
    add_common(write)
    write.add_argument("content", nargs="*")
    write.add_argument("--stdin", action="store_true")
    write.add_argument("--id")
    write.add_argument("--type", default="semantic")
    write.add_argument("--tag", action="append", default=[])
    write.add_argument("--confidence", type=float)
    write.add_argument("--source")
    write.add_argument("--source-file")
    write.add_argument("--events-file")
    write.add_argument("--metadata")
    write.add_argument("--message")

    list_cmd = sub.add_parser("list")
    add_common(list_cmd)
    list_cmd.add_argument("--all", action="store_true")
    list_cmd.add_argument("--json", action="store_true")

    glob_cmd = sub.add_parser("glob")
    add_common(glob_cmd)
    glob_cmd.add_argument("pattern", nargs="?", default="*")
    glob_cmd.add_argument("--all", action="store_true")
    glob_cmd.add_argument("--files", action="store_true")
    glob_cmd.add_argument("--json", action="store_true")

    for name in ("show", "read"):
        show = sub.add_parser(name)
        add_common(show)
        show.add_argument("id")
        show.add_argument("--type")
        show.add_argument("--all", action="store_true")
        show.add_argument("--json", action="store_true")

    search = sub.add_parser("search")
    add_common(search)
    search.add_argument("query", nargs="+")
    search.add_argument("--all", action="store_true")
    search.add_argument("--json", action="store_true")

    history = sub.add_parser("history")
    add_common(history)
    history.add_argument("id")
    history.add_argument("--type")
    history.add_argument("--json", action="store_true")

    delete = sub.add_parser("delete")
    add_common(delete)
    delete.add_argument("id")
    delete.add_argument("--type")

    purge = sub.add_parser("purge")
    add_common(purge)
    purge.add_argument("id")
    purge.add_argument("--type")

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "init":
            commit = init_store(args.repo, args.ref)
            print_json({"ok": True, "ref": args.ref, "commit": commit})
        elif args.command == "write":
            content = sys.stdin.read() if args.stdin else " ".join(args.content)
            if not content.strip():
                raise RuntimeError("Missing memory content. Pass text or use --stdin.")
            source = args.source
            if args.source_file:
                source = Path(args.source_file).read_text()
            events = Path(args.events_file).read_text() if args.events_file else None
            metadata = json.loads(args.metadata) if args.metadata else None
            result = write_memory(
                args.repo,
                content,
                ref=args.ref,
                memory_id=args.id,
                memory_type=args.type,
                tags=args.tag,
                confidence=args.confidence,
                source_markdown=source,
                events_jsonl=events,
                metadata=metadata,
                message=args.message,
            )
            print_json({"ok": True, **result})
        elif args.command == "list":
            memories = list_memories(args.repo, args.ref, args.all)
            if args.json:
                print_json(memories)
            else:
                for memory in memories:
                    record = memory["record"]
                    deleted = " deleted" if record.get("deleted_at") else ""
                    print(f"{record['id']}\t{record['type']}{deleted}\t{record['updated_at']}\t{record['content']}")
        elif args.command == "glob":
            entries = glob_memories(args.repo, args.pattern, ref=args.ref, include_deleted=args.all, files=args.files)
            if args.json:
                print_json(entries)
            elif args.files:
                for entry in entries:
                    for file in entry.get("files", []):
                        print(file)
            else:
                for entry in entries:
                    print(entry["key"])
        elif args.command in ("show", "read"):
            memory_type = args.type
            memory_id = args.id
            if "/" in args.id and not memory_type:
                memory_type, memory_id = args.id.split("/", 1)
            memory = find_memory(args.repo, memory_id, ref=args.ref, memory_type=memory_type, include_deleted=args.all)
            if not memory:
                raise RuntimeError(f"Memory not found: {args.id}")
            print_json(memory) if args.json else print_memory(memory)
        elif args.command == "search":
            results = search_memories(args.repo, " ".join(args.query), ref=args.ref, include_deleted=args.all)
            if args.json:
                print_json(results)
            else:
                for memory in results:
                    record = memory["record"]
                    print(f"{record['id']}\t{record['type']}\t{record['updated_at']}\t{record['content']}")
        elif args.command == "history":
            rows = memory_history(args.repo, args.id, ref=args.ref, memory_type=args.type)
            if args.json:
                print_json(rows)
            else:
                for row in rows:
                    print(f"{row['commit'][:12]}\t{row['date']}\t{row['subject']}")
        elif args.command == "delete":
            result = delete_memory(args.repo, args.id, ref=args.ref, memory_type=args.type)
            print_json({"ok": True, **result})
        elif args.command == "purge":
            commit = purge_memory(args.repo, args.id, ref=args.ref, memory_type=args.type)
            print_json({"ok": True, "ref": args.ref, "commit": commit})
        return 0
    except Exception as error:
        print(f"git-as-memory: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
