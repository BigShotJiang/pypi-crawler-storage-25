"""Git-native append-only memory store for agents."""

__version__ = "0.1.1"
