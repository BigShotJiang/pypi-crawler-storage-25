"""Tests for the event listener."""

import asyncio
import hashlib
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from micromech.core.config import ChainConfig, MicromechConfig
from micromech.core.models import MechRequest
from micromech.runtime.listener import EventListener

MECH_ADDR = "0x" + "ab" * 20
OTHER_MECH = "0x" + "cd" * 20

# Reusable ChainConfig for tests
CHAIN_CFG = ChainConfig(
    chain="gnosis",
    marketplace_address="0x735FAAb1c4Ec41128c367AFb5c3baC73509f70bB",
    factory_address="0x8b299c20F87e3fcBfF0e1B86dC0acC06AB6993EF",
    staking_address="0xCAbD0C941E54147D40644CF7DA7e36d70DF46f44",
    mech_address="0x77af31De935740567Cf4fF1986D04B2c964A786a",
)

# ChainConfig with MECH_ADDR for tests that filter by mech address
CHAIN_CFG_MECH = ChainConfig(
    chain="gnosis",
    marketplace_address="0x735FAAb1c4Ec41128c367AFb5c3baC73509f70bB",
    factory_address="0x8b299c20F87e3fcBfF0e1B86dC0acC06AB6993EF",
    staking_address="0xCAbD0C941E54147D40644CF7DA7e36d70DF46f44",
    mech_address=MECH_ADDR,
)


def _make_event(
    mech_addr: str,
    request_ids: list[bytes] | None = None,
    request_datas: list[bytes] | None = None,
) -> dict:
    """Create a mock decoded MarketplaceRequest event."""
    if request_ids is None:
        request_ids = [b"\xaa" * 32]
    if request_datas is None:
        request_datas = [b""]
    return {
        "args": {
            "priorityMech": mech_addr,
            "requester": "0x" + "00" * 20,
            "numRequests": len(request_ids),
            "requestIds": request_ids,
            "requestDatas": request_datas,
        },
        "event": "MarketplaceRequest",
        "blockNumber": 1000,
    }


class TestParseRequestData:
    def test_parse_json_payload(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        data = json.dumps({"prompt": "Will ETH hit 10k?", "tool": "llm"}).encode()
        prompt, tool, extra = listener._parse_request_data(data)
        assert prompt == "Will ETH hit 10k?"
        assert tool == "llm"
        assert extra == {}

    def test_parse_json_with_extra_params(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        data = json.dumps(
            {
                "prompt": "test",
                "tool": "llm",
                "model": "qwen",
                "nonce": 42,
            }
        ).encode()
        prompt, tool, extra = listener._parse_request_data(data)
        assert prompt == "test"
        assert tool == "llm"
        assert extra == {"model": "qwen", "nonce": 42}

    def test_parse_empty_data(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        prompt, tool, extra = listener._parse_request_data(b"")
        assert prompt == ""
        assert tool == ""

    def test_parse_invalid_json(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        prompt, tool, extra = listener._parse_request_data(b"not json")
        assert prompt == ""
        assert tool == ""

    def test_parse_binary_data(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        prompt, tool, extra = listener._parse_request_data(bytes(range(256)))
        assert prompt == ""
        assert tool == ""


class TestParseMarketplaceEvent:
    def test_parse_valid_event(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH)
        data = json.dumps({"prompt": "hello", "tool": "echo"}).encode()
        event = _make_event(MECH_ADDR, request_datas=[data])

        reqs = listener._parse_marketplace_event(event, MECH_ADDR)
        assert len(reqs) == 1
        assert reqs[0].prompt == "hello"
        assert reqs[0].tool == "echo"

    def test_filters_other_mech(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        event = _make_event(OTHER_MECH)
        reqs = listener._parse_marketplace_event(event, MECH_ADDR)
        assert reqs == []

    def test_accepts_when_no_mech_filter(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        event = _make_event(MECH_ADDR)
        reqs = listener._parse_marketplace_event(event, None)
        assert len(reqs) == 1

    def test_request_id_from_bytes(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        rid = b"\xee" * 32
        event = _make_event(MECH_ADDR, request_ids=[rid])
        reqs = listener._parse_marketplace_event(event, None)
        assert len(reqs) == 1
        assert reqs[0].request_id == "ee" * 32

    def test_sender_populated_from_requester(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        requester = "0x" + "ab" * 20
        event = _make_event(MECH_ADDR)
        event["args"]["requester"] = requester
        reqs = listener._parse_marketplace_event(event, None)
        assert len(reqs) == 1
        assert reqs[0].sender == requester

    def test_multiple_requests_share_same_sender(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        requester = "0x" + "cd" * 20
        data1 = json.dumps({"prompt": "q1", "tool": "echo"}).encode()
        data2 = json.dumps({"prompt": "q2", "tool": "llm"}).encode()
        event = _make_event(
            MECH_ADDR,
            request_ids=[b"\x01" * 32, b"\x02" * 32],
            request_datas=[data1, data2],
        )
        event["args"]["requester"] = requester
        reqs = listener._parse_marketplace_event(event, None)
        assert len(reqs) == 2
        assert reqs[0].sender == requester
        assert reqs[1].sender == requester

    def test_multiple_requests_in_event(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        data1 = json.dumps({"prompt": "q1", "tool": "echo"}).encode()
        data2 = json.dumps({"prompt": "q2", "tool": "llm"}).encode()
        event = _make_event(
            MECH_ADDR,
            request_ids=[b"\x01" * 32, b"\x02" * 32],
            request_datas=[data1, data2],
        )
        reqs = listener._parse_marketplace_event(event, None)
        assert len(reqs) == 2
        assert reqs[0].prompt == "q1"
        assert reqs[1].prompt == "q2"


class TestFetchEvents:
    def test_fetch_with_mock_contract(self):
        bridge = MagicMock()
        data = json.dumps({"prompt": "q1", "tool": "echo"}).encode()

        bridge.with_retry.side_effect = lambda fn, **kw: fn()

        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH, bridge=bridge)
        mock_contract = MagicMock()
        mock_contract.events.MarketplaceRequest.get_logs.return_value = [
            _make_event(MECH_ADDR, request_datas=[data])
        ]
        listener._marketplace_contract = mock_contract

        requests = listener._fetch_events(100, 200)
        assert len(requests) == 1
        assert requests[0].prompt == "q1"

    def test_fetch_handles_exception(self):
        bridge = MagicMock()

        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH, bridge=bridge)
        mock_contract = MagicMock()
        mock_contract.events.MarketplaceRequest.get_logs.side_effect = Exception("rpc")
        listener._marketplace_contract = mock_contract

        requests = listener._fetch_events(100, 200)
        assert requests == []

    def test_fetch_passes_mech_address_filter(self):
        """Verify get_logs receives argument_filters with priorityMech."""
        bridge = MagicMock()
        bridge.with_retry.side_effect = lambda fn, **kw: fn()
        bridge.web3.to_checksum_address.side_effect = lambda a: a

        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH, bridge=bridge)
        mock_contract = MagicMock()
        mock_contract.events.MarketplaceRequest.get_logs.return_value = []
        listener._marketplace_contract = mock_contract

        listener._fetch_events(100, 200)

        mock_contract.events.MarketplaceRequest.get_logs.assert_called_once_with(
            from_block=100,
            to_block=200,
            argument_filters={"priorityMech": MECH_ADDR},
        )

    def test_fetch_skips_when_no_mech_address(self):
        """Without mech_address, _fetch_events returns empty (no unfiltered queries)."""
        bridge = MagicMock()

        chain_cfg = ChainConfig(
            chain="gnosis",
            marketplace_address="0x735FAAb1c4Ec41128c367AFb5c3baC73509f70bB",
            factory_address="0x8b299c20F87e3fcBfF0e1B86dC0acC06AB6993EF",
            staking_address="0xCAbD0C941E54147D40644CF7DA7e36d70DF46f44",
        )
        listener = EventListener(MicromechConfig(), chain_cfg, bridge=bridge)

        result = listener._fetch_events(100, 200)
        assert result == []


class TestPollOnce:
    @pytest.mark.asyncio
    async def test_poll_without_bridge_returns_empty(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG, bridge=None)
        result = await listener.poll_once()
        assert result == []

    @pytest.mark.asyncio
    async def test_poll_no_new_blocks(self):
        bridge = MagicMock()
        bridge.with_retry.side_effect = lambda fn, **kw: fn()
        bridge.web3.eth.block_number = 100

        listener = EventListener(MicromechConfig(), CHAIN_CFG, bridge=bridge)
        listener._last_block = 100
        result = await listener.poll_once()
        assert result == []

    @pytest.mark.asyncio
    async def test_poll_handles_exception(self):
        bridge = MagicMock()
        bridge.with_retry.side_effect = Exception("timeout")

        listener = EventListener(MicromechConfig(), CHAIN_CFG, bridge=bridge)
        result = await listener.poll_once()
        assert result == []


class TestAdvanceBlock:
    def test_advance_block(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        listener._polled_to_block = 500
        listener.advance_block()
        assert listener._last_block == 500
        assert listener._polled_to_block is None

    def test_advance_block_noop_when_none(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        listener._last_block = 100
        listener.advance_block()
        assert listener._last_block == 100


class TestRunLoop:
    @pytest.fixture(autouse=True)
    def _fast_poll(self, monkeypatch):
        """Use 1-second poll interval for run-loop tests."""
        monkeypatch.setattr(
            "micromech.runtime.listener.DEFAULT_EVENT_POLL_INTERVAL",
            1,
        )

    @pytest.mark.asyncio
    async def test_run_stops_on_stop(self):
        config = MicromechConfig()
        listener = EventListener(config, CHAIN_CFG, bridge=None)

        async def callback(req):
            pass

        async def stop_soon():
            await asyncio.sleep(0.2)
            listener.stop()

        asyncio.create_task(stop_soon())
        await asyncio.wait_for(listener.run(callback), timeout=3.0)
        assert listener._running is False

    @pytest.mark.asyncio
    async def test_run_with_mock_events(self):
        config = MicromechConfig()
        listener = EventListener(config, CHAIN_CFG, bridge=None)
        received = []

        async def callback(req):
            received.append(req)

        call_count = 0

        async def mock_poll():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                req = MechRequest(request_id="r1", prompt="test", tool="echo")
                listener._polled_to_block = 100
                return [req]
            listener.stop()
            return []

        listener.poll_once = mock_poll
        await asyncio.wait_for(listener.run(callback), timeout=5.0)
        assert len(received) == 1
        assert listener._last_block == 100

    def test_stop(self):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        listener._running = True
        listener.stop()
        assert listener._running is False

    @pytest.mark.asyncio
    async def test_run_handles_callback_error(self):
        """Callback errors don't crash the loop but prevent block advance."""
        config = MicromechConfig()
        listener = EventListener(config, CHAIN_CFG, bridge=None)
        advanced_after_error = None

        async def failing_callback(req):
            raise RuntimeError("callback boom")

        call_count = 0

        async def mock_poll():
            nonlocal call_count, advanced_after_error
            call_count += 1
            if call_count == 1:
                req = MechRequest(request_id="r1", prompt="test", tool="echo")
                listener._polled_to_block = 200
                return [req]
            # Capture whether block was advanced after the first (failed) iteration
            advanced_after_error = listener._last_block
            listener.stop()
            return []

        listener.poll_once = mock_poll
        await asyncio.wait_for(listener.run(failing_callback), timeout=5.0)
        # Block should NOT have advanced after the failed callback iteration
        assert advanced_after_error is None


class TestResolveRequest:
    """Test _resolve_request with IPFS multihash data."""

    @pytest.mark.asyncio
    async def test_resolve_ipfs_multihash(self):
        """Requests with IPFS multihash data get resolved via IPFS."""
        config = MicromechConfig(ipfs={"enabled": True})
        listener = EventListener(config, CHAIN_CFG)

        # Build a valid 34-byte multihash (0x12 0x20 + 32-byte sha256)
        digest = hashlib.sha256(b"test payload").digest()
        multihash_data = bytes([0x12, 0x20]) + digest

        req = MechRequest(
            request_id="r1",
            data=multihash_data,
            prompt="",  # Empty — needs IPFS resolution
            tool="",
        )

        ipfs_payload = {"prompt": "Will ETH hit 10k?", "tool": "llm", "nonce": 42}
        with patch(
            "micromech.ipfs.client.fetch_json_from_ipfs",
            new_callable=AsyncMock,
        ) as mock_fetch:
            mock_fetch.return_value = ipfs_payload
            resolved = await listener._resolve_request(req)

        assert resolved.prompt == "Will ETH hit 10k?"
        assert resolved.tool == "llm"
        assert resolved.extra_params == {"nonce": 42}
        assert resolved.request_id == "r1"

    @pytest.mark.asyncio
    async def test_resolve_skips_when_prompt_present(self):
        """If prompt is already set, IPFS resolution is skipped."""
        config = MicromechConfig(ipfs={"enabled": True})
        listener = EventListener(config, CHAIN_CFG)

        req = MechRequest(
            request_id="r1",
            data=b"\x12\x20" + b"\x00" * 32,
            prompt="already set",
            tool="echo",
        )

        resolved = await listener._resolve_request(req)
        assert resolved.prompt == "already set"

    @pytest.mark.asyncio
    async def test_resolve_skips_when_ipfs_disabled(self):
        """With IPFS disabled, multihash data is not resolved."""
        config = MicromechConfig(ipfs={"enabled": False})
        listener = EventListener(config, CHAIN_CFG)

        digest = hashlib.sha256(b"test").digest()
        req = MechRequest(
            request_id="r1",
            data=bytes([0x12, 0x20]) + digest,
            prompt="",
            tool="",
        )

        resolved = await listener._resolve_request(req)
        assert resolved.prompt == ""  # Not resolved

    @pytest.mark.asyncio
    async def test_resolve_handles_ipfs_error(self):
        """IPFS fetch failure marks request with decode_error tool."""
        config = MicromechConfig(ipfs={"enabled": True})
        listener = EventListener(config, CHAIN_CFG)

        digest = hashlib.sha256(b"test").digest()
        req = MechRequest(
            request_id="r1",
            data=bytes([0x12, 0x20]) + digest,
            prompt="",
            tool="",
        )

        with patch(
            "micromech.ipfs.client.fetch_json_from_ipfs",
            new_callable=AsyncMock,
            side_effect=RuntimeError("gateway timeout"),
        ):
            resolved = await listener._resolve_request(req)

        assert resolved.tool == "(decode_error)"
        assert resolved.request_id == req.request_id

    @pytest.mark.asyncio
    async def test_resolve_preserves_sender_and_metadata(self):
        """sender, timeout, delivery_method and is_offchain are preserved after IPFS resolution."""
        config = MicromechConfig(ipfs={"enabled": True})
        listener = EventListener(config, CHAIN_CFG)

        digest = hashlib.sha256(b"test payload").digest()
        multihash_data = bytes([0x12, 0x20]) + digest

        req = MechRequest(
            request_id="r99",
            sender="0xDeaDbeefdEAdbeefdEadbEEFdeadbeEFdEaDbeeF",
            data=multihash_data,
            prompt="",
            tool="",
            timeout=600,
            delivery_method="legacy",
            is_offchain=True,
        )

        ipfs_payload = {"prompt": "test prompt", "tool": "llm"}
        with patch(
            "micromech.ipfs.client.fetch_json_from_ipfs",
            new_callable=AsyncMock,
        ) as mock_fetch:
            mock_fetch.return_value = ipfs_payload
            resolved = await listener._resolve_request(req)

        assert resolved.sender == "0xDeaDbeefdEAdbeefdEadbEEFdeadbeEFdEaDbeeF"
        assert resolved.timeout == 600
        assert resolved.delivery_method == "legacy"
        assert resolved.is_offchain is True
        assert resolved.prompt == "test prompt"
        assert resolved.tool == "llm"

    @pytest.mark.asyncio
    async def test_resolve_only_changes_payload_fields(self):
        """_resolve_request must not modify any field except prompt, tool, extra_params."""
        config = MicromechConfig(ipfs={"enabled": True})
        listener = EventListener(config, CHAIN_CFG)

        digest = hashlib.sha256(b"invariant").digest()
        multihash_data = bytes([0x12, 0x20]) + digest

        req = MechRequest(
            request_id="r-inv",
            sender="0xDeaDbeefdEAdbeefdEadbEEFdeadbeEFdEaDbeeF",
            data=multihash_data,
            prompt="",
            tool="",
            timeout=600,
            delivery_method="legacy",
            is_offchain=True,
            signature="0xdeadbeef",
        )

        ipfs_payload = {"prompt": "resolved", "tool": "llm"}
        with patch(
            "micromech.ipfs.client.fetch_json_from_ipfs",
            new_callable=AsyncMock,
        ) as mock_fetch:
            mock_fetch.return_value = ipfs_payload
            resolved = await listener._resolve_request(req)

        payload_fields = {"prompt", "tool", "extra_params"}
        original = req.model_dump(exclude=payload_fields)
        after = resolved.model_dump(exclude=payload_fields)
        assert original == after, "_resolve_request must only modify prompt/tool/extra_params"

    @pytest.mark.asyncio
    async def test_resolve_ipfs_sender_in_payload_does_not_override_req_sender(self):
        """A malicious IPFS payload with 'sender' must not override req.sender."""
        config = MicromechConfig(ipfs={"enabled": True})
        listener = EventListener(config, CHAIN_CFG)

        digest = hashlib.sha256(b"malicious").digest()
        multihash_data = bytes([0x12, 0x20]) + digest

        real_sender = "0xDeaDbeefdEAdbeefdEadbEEFdeadbeEFdEaDbeeF"
        req = MechRequest(
            request_id="r-sec",
            sender=real_sender,
            data=multihash_data,
            prompt="",
            tool="",
        )

        malicious_payload = {
            "prompt": "legit prompt",
            "tool": "llm",
            "sender": "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
        }
        with patch(
            "micromech.ipfs.client.fetch_json_from_ipfs",
            new_callable=AsyncMock,
        ) as mock_fetch:
            mock_fetch.return_value = malicious_payload
            resolved = await listener._resolve_request(req)

        assert resolved.sender == real_sender
        assert "sender" in resolved.extra_params
        assert resolved.extra_params["sender"] == "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045"

    @pytest.mark.asyncio
    async def test_resolve_non_multihash_data(self):
        """Non-multihash binary data is returned as-is."""
        config = MicromechConfig(ipfs={"enabled": True})
        listener = EventListener(config, CHAIN_CFG)

        req = MechRequest(
            request_id="r1",
            data=b"not a multihash",
            prompt="",
            tool="",
        )

        resolved = await listener._resolve_request(req)
        assert resolved is req


class TestGetMarketplaceContract:
    def test_lazy_loads_contract(self):
        bridge = MagicMock()
        mock_contract = MagicMock()
        bridge.web3.eth.contract.return_value = mock_contract

        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH, bridge=bridge)
        contract = listener._get_marketplace_contract()
        assert contract is mock_contract

        # Second call returns cached
        contract2 = listener._get_marketplace_contract()
        assert contract2 is mock_contract
        bridge.web3.eth.contract.assert_called_once()


class TestParseMarketplaceEventEdgeCases:
    def test_string_request_data(self):
        """String request data is converted to bytes."""
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        data_str = json.dumps({"prompt": "hello", "tool": "echo"})
        event = _make_event(
            MECH_ADDR,
            request_datas=[data_str],
        )
        reqs = listener._parse_marketplace_event(event, None)
        assert len(reqs) == 1
        assert reqs[0].prompt == "hello"

    def test_string_request_id(self):
        """String request IDs (not bytes) are handled."""
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        event = {
            "args": {
                "priorityMech": MECH_ADDR,
                "requestIds": ["abc123"],
                "requestDatas": [b""],
            },
        }
        reqs = listener._parse_marketplace_event(event, None)
        assert len(reqs) == 1
        assert reqs[0].request_id == "abc123"

    def test_missing_request_data(self):
        """When requestDatas is shorter than requestIds, empty data is used."""
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        event = _make_event(
            MECH_ADDR,
            request_ids=[b"\x01" * 32, b"\x02" * 32],
            request_datas=[json.dumps({"prompt": "q1"}).encode()],
        )
        reqs = listener._parse_marketplace_event(event, None)
        assert len(reqs) == 2
        assert reqs[0].prompt == "q1"
        assert reqs[1].prompt == ""  # Missing data -> empty


class TestBlockPersistence:
    def test_load_last_block_reads_file(self, tmp_path):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        listener._block_state_path = tmp_path / ".last_block_gnosis"
        listener._block_state_path.write_text("12345")
        assert listener._load_last_block() == 12345

    def test_load_last_block_returns_none_when_missing(self, tmp_path):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        listener._block_state_path = tmp_path / ".last_block_gnosis"
        assert listener._load_last_block() is None

    def test_load_last_block_returns_none_on_empty_file(self, tmp_path):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        listener._block_state_path = tmp_path / ".last_block_gnosis"
        listener._block_state_path.write_text("")
        assert listener._load_last_block() is None

    def test_load_last_block_returns_none_on_corrupt_file(self, tmp_path):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        listener._block_state_path = tmp_path / ".last_block_gnosis"
        listener._block_state_path.write_text("not_a_number")
        assert listener._load_last_block() is None

    def test_save_last_block_writes_file(self, tmp_path):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        state = tmp_path / ".last_block_gnosis"
        listener._block_state_path = state
        listener._save_last_block(99999)
        assert state.read_text() == "99999"

    def test_save_last_block_handles_write_error(self, tmp_path):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        listener._block_state_path = (
            tmp_path / "nonexistent_dir" / ".last_block_gnosis"
        )
        # Should not raise — write errors are silently logged
        listener._save_last_block(100)

    def test_advance_block_persists_to_disk(self, tmp_path):
        listener = EventListener(MicromechConfig(), CHAIN_CFG)
        state = tmp_path / ".last_block_gnosis"
        listener._block_state_path = state
        listener._polled_to_block = 42000
        listener.advance_block()
        assert listener._last_block == 42000
        assert state.read_text() == "42000"

    @pytest.mark.asyncio
    async def test_poll_once_uses_persisted_block(self, tmp_path):
        """On startup, poll_once loads _last_block from disk instead of lookback."""
        bridge = MagicMock()
        bridge.with_retry.side_effect = lambda fn, **kw: fn()
        bridge.web3.eth.block_number = 50000

        listener = EventListener(
            MicromechConfig(), CHAIN_CFG_MECH, bridge=bridge
        )
        state = tmp_path / ".last_block_gnosis"
        listener._block_state_path = state
        state.write_text("49900")

        with patch.object(
            listener, "_fetch_events", return_value=[]
        ) as mock_fetch:
            await listener.poll_once()

        # Should scan from 49901 (persisted + 1), not from 50000 - lookback
        mock_fetch.assert_called_once_with(49901, 50000)

    @pytest.mark.asyncio
    async def test_poll_once_falls_back_to_lookback_when_no_persist(
        self, tmp_path
    ):
        """Without persisted state, poll_once uses DEFAULT_EVENT_LOOKBACK_BLOCKS."""
        from micromech.core.constants import DEFAULT_EVENT_LOOKBACK_BLOCKS

        bridge = MagicMock()
        bridge.with_retry.side_effect = lambda fn, **kw: fn()
        bridge.web3.eth.block_number = 50000

        listener = EventListener(
            MicromechConfig(), CHAIN_CFG_MECH, bridge=bridge
        )
        listener._block_state_path = tmp_path / ".last_block_gnosis"

        with patch.object(
            listener, "_fetch_events", return_value=[]
        ) as mock_fetch:
            await listener.poll_once()

        expected_from = 50000 - DEFAULT_EVENT_LOOKBACK_BLOCKS + 1
        mock_fetch.assert_called_once_with(expected_from, 50000)


class TestAdaptivePolling:
    """Test adaptive polling interval in EventListener.run()."""

    @pytest.mark.asyncio
    async def test_interval_increases_when_idle(self):
        """Interval backs off when no requests found."""
        from micromech.core.constants import DEFAULT_EVENT_POLL_INTERVAL

        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH)
        calls = []

        async def mock_poll_once():
            return []  # no requests

        listener.poll_once = mock_poll_once

        original_sleep = asyncio.sleep

        async def tracked_sleep(t):
            calls.append(t)
            if len(calls) >= 4:
                listener.stop()
            await original_sleep(0)  # don't actually wait

        with patch("asyncio.sleep", tracked_sleep):
            await listener.run(callback=AsyncMock())

        # Each idle poll increases interval (15 → 22.5 → 33.75 → ...)
        assert calls[0] >= DEFAULT_EVENT_POLL_INTERVAL
        assert calls[1] > calls[0]
        assert calls[2] > calls[1]
        # Should not exceed 60s
        assert all(t <= 60 for t in calls)

    @pytest.mark.asyncio
    async def test_interval_resets_on_activity(self):
        """Interval snaps back to default when requests arrive."""
        from micromech.core.constants import DEFAULT_EVENT_POLL_INTERVAL

        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH)
        call_count = 0
        calls = []

        async def mock_poll_once():
            nonlocal call_count
            call_count += 1
            if call_count == 3:
                # Simulate activity on 3rd poll
                return [MechRequest(request_id="test", prompt="hi", tool="echo")]
            return []

        listener.poll_once = mock_poll_once
        listener.advance_block = lambda: None

        original_sleep = asyncio.sleep

        async def tracked_sleep(t):
            calls.append(t)
            if len(calls) >= 4:
                listener.stop()
            await original_sleep(0)

        with patch("asyncio.sleep", tracked_sleep):
            await listener.run(callback=AsyncMock())

        # calls[0], calls[1]: idle → increasing
        assert calls[1] > calls[0]
        # calls[2]: after activity → snapped back to default
        assert calls[2] == DEFAULT_EVENT_POLL_INTERVAL


# ===========================================================================
# Fallback mode
# ===========================================================================


class TestFallbackMode:
    """Fallback mode must not widen the event listener."""

    def _make_fallback_config(self) -> MicromechConfig:
        return MicromechConfig(
            chains={"gnosis": CHAIN_CFG_MECH.model_dump()},
            fallback_mode_enabled=True,
        )

    def test_fallback_mode_still_filters_non_matching_priority(self):
        """Fallback harvesting is queue-based; listener remains own-mech only."""
        cfg = self._make_fallback_config()
        listener = EventListener(cfg, CHAIN_CFG_MECH)
        event = _make_event(OTHER_MECH)

        reqs = listener._parse_marketplace_event(event, MECH_ADDR)

        assert reqs == []

    def test_normal_mode_still_filters_other_mech(self):
        """Without fallback mode, events for OTHER_MECH are filtered out."""
        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH)
        event = _make_event(OTHER_MECH)

        reqs = listener._parse_marketplace_event(event, MECH_ADDR)

        assert reqs == []

    def test_priority_mech_set_for_own_requests(self):
        """priority_mech field is populated even for our own requests."""
        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH)
        event = _make_event(MECH_ADDR)

        reqs = listener._parse_marketplace_event(event, MECH_ADDR)

        assert len(reqs) == 1
        assert reqs[0].priority_mech == MECH_ADDR

    def test_fallback_fetch_still_uses_priority_mech_filter(self):
        """With fallback enabled, get_logs remains filtered to our mech."""
        cfg = self._make_fallback_config()
        bridge = MagicMock()
        bridge.with_retry.side_effect = lambda fn, **kw: fn()
        bridge.web3.to_checksum_address.return_value = MECH_ADDR

        listener = EventListener(cfg, CHAIN_CFG_MECH, bridge=bridge)
        mock_contract = MagicMock()
        mock_contract.events.MarketplaceRequest.get_logs.return_value = []
        listener._marketplace_contract = mock_contract

        listener._fetch_events(100, 200)

        call_kwargs = mock_contract.events.MarketplaceRequest.get_logs.call_args.kwargs
        assert "argument_filters" in call_kwargs
        assert call_kwargs["argument_filters"] == {"priorityMech": MECH_ADDR}

    def test_normal_fetch_uses_priority_mech_filter(self):
        """Without fallback mode, get_logs is called with priorityMech filter."""
        bridge = MagicMock()
        bridge.with_retry.side_effect = lambda fn, **kw: fn()
        bridge.web3.to_checksum_address.return_value = MECH_ADDR

        listener = EventListener(MicromechConfig(), CHAIN_CFG_MECH, bridge=bridge)
        mock_contract = MagicMock()
        mock_contract.events.MarketplaceRequest.get_logs.return_value = []
        listener._marketplace_contract = mock_contract

        listener._fetch_events(100, 200)

        call_kwargs = mock_contract.events.MarketplaceRequest.get_logs.call_args.kwargs
        assert call_kwargs["argument_filters"] == {"priorityMech": MECH_ADDR}
