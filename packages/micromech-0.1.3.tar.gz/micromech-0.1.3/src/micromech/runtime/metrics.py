"""In-memory metrics collector for the dashboard.

Tracks request lifecycle events since server start. Provides counters,
averages, and a rolling event log for real-time streaming.
"""

import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class MetricsEvent:
    """A single event in the activity feed."""

    timestamp: float
    # request_received, execution_started, execution_done, delivered, failed, etc.
    event_type: str
    request_id: str
    chain: str = ""
    tool: str = ""
    is_offchain: bool = False
    execution_time: float = 0.0
    error: str = ""
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "iso": datetime.fromtimestamp(self.timestamp, tz=timezone.utc).isoformat(),
            "event": self.event_type,
            "request_id": self.request_id,
            "chain": self.chain,
            "tool": self.tool,
            "is_offchain": self.is_offchain,
            "execution_time": round(self.execution_time, 3) if self.execution_time else 0,
            "error": self.error,
            "details": self.details,
        }


@dataclass
class MetricsCollector:
    """In-memory metrics — resets on restart, no persistence needed.

    Thread-safe for asyncio single-threaded event loop (all calls are
    non-yielding dataclass mutations).
    """

    start_time: float = field(default_factory=time.time)

    # Counters
    requests_received: int = 0
    executions_started: int = 0
    executions_completed: int = 0
    executions_failed: int = 0
    executions_skipped: int = 0
    deliveries_completed: int = 0
    deliveries_failed: int = 0
    # Deliveries that were accepted by the Safe TX but rejected on-chain by the
    # marketplace contract as late (responseTimeout exceeded). Distinct from
    # deliveries_failed (which covers TX failures). Used for rollback monitoring:
    # if mech_late_delivery_count > 2× baseline, consider disabling parallel delivery.
    mech_late_delivery_count: int = 0

    # Rolling execution times (last 1000)
    _exec_times: deque[float] = field(default_factory=lambda: deque(maxlen=1000))
    _delivery_age_seconds: deque[float] = field(default_factory=lambda: deque(maxlen=1000))
    _delivery_prep_seconds: deque[float] = field(default_factory=lambda: deque(maxlen=1000))
    _safe_lock_wait_seconds: deque[float] = field(default_factory=lambda: deque(maxlen=1000))
    _safe_submit_seconds: deque[float] = field(default_factory=lambda: deque(maxlen=1000))

    # Event log for real-time feed (last 200 events)
    _events: deque[MetricsEvent] = field(default_factory=lambda: deque(maxlen=200))

    @property
    def uptime_seconds(self) -> int:
        return int(time.time() - self.start_time)

    @property
    def avg_execution_time(self) -> float:
        if not self._exec_times:
            return 0.0
        return sum(self._exec_times) / len(self._exec_times)

    @property
    def p95_execution_time(self) -> float:
        return self._p95(self._exec_times)

    @staticmethod
    def _avg(values: deque[float]) -> float:
        if not values:
            return 0.0
        return sum(values) / len(values)

    @staticmethod
    def _p95(values: deque[float]) -> float:
        if not values:
            return 0.0
        sorted_times = sorted(values)
        idx = int(len(sorted_times) * 0.95)
        return sorted_times[min(idx, len(sorted_times) - 1)]

    @property
    def success_rate(self) -> float:
        total = self.executions_completed + self.executions_failed
        if total == 0:
            return 100.0
        return (self.executions_completed / total) * 100.0

    def record_request_received(
        self, request_id: str, tool: str, is_offchain: bool, chain: str = ""
    ) -> None:
        self.requests_received += 1
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="request_received",
                request_id=request_id,
                chain=chain,
                tool=tool,
                is_offchain=is_offchain,
            )
        )

    def record_execution_started(self, request_id: str, tool: str, chain: str = "") -> None:
        self.executions_started += 1
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="execution_started",
                request_id=request_id,
                chain=chain,
                tool=tool,
            )
        )

    def record_execution_done(
        self, request_id: str, tool: str, execution_time: float, chain: str = ""
    ) -> None:
        self.executions_completed += 1
        self._exec_times.append(execution_time)
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="execution_done",
                request_id=request_id,
                chain=chain,
                tool=tool,
                execution_time=execution_time,
            )
        )

    def record_execution_failed(
        self,
        request_id: str,
        tool: str,
        error: str,
        execution_time: float = 0.0,
        chain: str = "",
    ) -> None:
        self.executions_failed += 1
        if execution_time:
            self._exec_times.append(execution_time)
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="failed",
                request_id=request_id,
                chain=chain,
                tool=tool,
                error=error,
                execution_time=execution_time,
            )
        )

    def record_delivery(self, request_id: str, chain: str = "") -> None:
        self.deliveries_completed += 1
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="delivered",
                request_id=request_id,
                chain=chain,
            )
        )

    def record_delivery_timing(
        self,
        request_id: str,
        *,
        chain: str = "",
        age_seconds: float = 0.0,
        prep_seconds: float = 0.0,
        safe_lock_wait_seconds: float = 0.0,
        safe_submit_seconds: float = 0.0,
    ) -> None:
        """Record delivery latency breakdown for operational diagnosis."""
        if age_seconds >= 0:
            self._delivery_age_seconds.append(age_seconds)
        if prep_seconds >= 0:
            self._delivery_prep_seconds.append(prep_seconds)
        if safe_lock_wait_seconds >= 0:
            self._safe_lock_wait_seconds.append(safe_lock_wait_seconds)
        if safe_submit_seconds >= 0:
            self._safe_submit_seconds.append(safe_submit_seconds)
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="delivery_timing",
                request_id=request_id,
                chain=chain,
                details={
                    "age_seconds": round(age_seconds, 3),
                    "prep_seconds": round(prep_seconds, 3),
                    "safe_lock_wait_seconds": round(safe_lock_wait_seconds, 3),
                    "safe_submit_seconds": round(safe_submit_seconds, 3),
                },
            )
        )

    def record_delivery_failed(self, request_id: str, error: str, chain: str = "") -> None:
        self.deliveries_failed += 1
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="delivery_failed",
                request_id=request_id,
                chain=chain,
                error=error,
            )
        )

    def record_late_delivery(self, request_id: str, chain: str = "") -> None:
        """Record a delivery that was mined but rejected on-chain as late (responseTimeout)."""
        self.mech_late_delivery_count += 1
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="late_delivery",
                request_id=request_id,
                chain=chain,
            )
        )

    def record_skipped(self, request_id: str, tool: str, reason: str, chain: str = "") -> None:
        self.executions_skipped += 1
        self._events.append(
            MetricsEvent(
                timestamp=time.time(),
                event_type="skipped",
                request_id=request_id,
                chain=chain,
                tool=tool,
                error=reason,
            )
        )

    def get_live_snapshot(self) -> dict[str, Any]:
        """Lightweight snapshot for SSE streaming (no DB hit)."""
        return {
            "uptime": self.uptime_seconds,
            "requests_received": self.requests_received,
            "executions_started": self.executions_started,
            "executions_completed": self.executions_completed,
            "executions_failed": self.executions_failed,
            "executions_skipped": self.executions_skipped,
            "deliveries_completed": self.deliveries_completed,
            "deliveries_failed": self.deliveries_failed,
            "mech_late_delivery_count": self.mech_late_delivery_count,
            "avg_execution_time": round(self.avg_execution_time, 3),
            "p95_execution_time": round(self.p95_execution_time, 3),
            "avg_delivery_age_seconds": round(self._avg(self._delivery_age_seconds), 3),
            "p95_delivery_age_seconds": round(self._p95(self._delivery_age_seconds), 3),
            "avg_delivery_prep_seconds": round(self._avg(self._delivery_prep_seconds), 3),
            "p95_delivery_prep_seconds": round(self._p95(self._delivery_prep_seconds), 3),
            "avg_safe_lock_wait_seconds": round(self._avg(self._safe_lock_wait_seconds), 3),
            "p95_safe_lock_wait_seconds": round(self._p95(self._safe_lock_wait_seconds), 3),
            "avg_safe_submit_seconds": round(self._avg(self._safe_submit_seconds), 3),
            "p95_safe_submit_seconds": round(self._p95(self._safe_submit_seconds), 3),
            "success_rate": round(self.success_rate, 1),
        }

    def get_events_since(self, since_ts: float) -> list[dict[str, Any]]:
        """Get events after a timestamp (for incremental SSE updates)."""
        return [e.to_dict() for e in self._events if e.timestamp > since_ts]

    def get_recent_events(self, limit: int = 50) -> list[dict[str, Any]]:
        """Get most recent events."""
        events = list(self._events)[-limit:]
        return [e.to_dict() for e in events]
