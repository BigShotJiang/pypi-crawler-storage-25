"""Delivery manager — submits tool results on-chain.

Calls deliverToMarketplace(requestIds[], datas[]) on the mech contract
via the mech service's Safe multisig.

Delivery transport strategy:
- Production (bridge has safe_service): _via_safe — Gnosis Safe execTransaction.
- Test/local (Anvil, bridge without safe_service): _via_impersonation — direct
  transact() via Anvil auto-impersonate. This path does NOT work on real nodes.

Batching strategy:
- On-chain requests are accumulated and flushed together in a single Safe TX
  when either config.delivery_batch_size requests are ready OR the oldest
  request has been waiting config.delivery_flush_timeout_seconds seconds.
- IPFS uploads for a batch are parallelized with asyncio.gather.
- Off-chain (HTTP) requests are delivered 1:1 as before.
"""

import asyncio
import json
import re
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Optional

from loguru import logger

from micromech.core.config import ChainConfig, MicromechConfig
from micromech.core.constants import (
    DEFAULT_DELIVERY_MAX_RETRIES,
    DEFAULT_DELIVERY_WORKERS,
    GAS_FALLBACK,
    GAS_FLOOR_DELIVERY,
    IPFS_API_URL,
    MARKETPLACE_MAX_RESPONSE_TIMEOUT,
    REQUEST_STATUS_DELIVERED,
    REQUEST_STATUS_DOES_NOT_EXIST,
    REQUEST_STATUS_REQUESTED_EXPIRED,
    REQUEST_STATUS_REQUESTED_PRIORITY,
)
from micromech.core.locks import get_safe_lock as get_safe_lock  # re-exported for compat
from micromech.core.models import RequestRecord
from micromech.core.persistence import PersistentQueue

if TYPE_CHECKING:
    from micromech.runtime.metrics import MetricsCollector


TX_RECEIPT_TIMEOUT = 120  # seconds

_REQUEST_STATUS_LABELS = {
    REQUEST_STATUS_DOES_NOT_EXIST: "does_not_exist",
    REQUEST_STATUS_REQUESTED_PRIORITY: "requested_priority",
    REQUEST_STATUS_REQUESTED_EXPIRED: "requested_expired",
    REQUEST_STATUS_DELIVERED: "delivered",
}


# Redacts 0x-prefixed hex blobs ≥ 64 chars (private keys, tx hashes, sigs).
_HEX_BLOB_RE = re.compile(r"0x[0-9a-fA-F]{64,}", re.ASCII)
_URL_USERINFO_RE = re.compile(r"(https?://)([^/@\s:]+):([^/@\s]+)@", re.IGNORECASE)
_SECRET_QUERY_RE = re.compile(
    r"([?&](?:api[_-]?key|access[_-]?token|token|auth|authorization|key|secret|password|pass)=)[^&\s]+",
    re.IGNORECASE,
)
_AUTH_HEADER_RE = re.compile(r"\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+", re.IGNORECASE)
_RPC_PATH_KEY_RE = re.compile(r"(/v[23]/)[A-Za-z0-9_-]{16,}")


def _sanitize_error(exc: BaseException, _depth: int = 0) -> str:
    """Return a redacted string of an exception, traversing __cause__ and __context__ up to depth 5.

    Replaces 0x[64+ hex chars] with 0x[REDACTED] to prevent accidental key
    or signature leakage in log lines and error messages.
    """
    if _depth > 5:
        return "..."
    msg = _HEX_BLOB_RE.sub("0x[REDACTED]", str(exc))
    msg = _URL_USERINFO_RE.sub(r"\1[REDACTED]:[REDACTED]@", msg)
    msg = _SECRET_QUERY_RE.sub(r"\1[REDACTED]", msg)
    msg = _AUTH_HEADER_RE.sub(r"\1 [REDACTED]", msg)
    msg = _RPC_PATH_KEY_RE.sub(r"\1[REDACTED]", msg)
    chained = exc.__cause__ if exc.__cause__ is not None else exc.__context__
    if chained is not None:
        chain_msg = _sanitize_error(chained, _depth + 1)
        label = "caused by" if exc.__cause__ is not None else "context"
        msg = f"{msg} ({label}: {chain_msg})"
    return msg


def _record_age_seconds(record: RequestRecord) -> float:
    created = record.request.created_at
    if created.tzinfo is None:
        created = created.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - created).total_seconds()


def _wait_and_check_receipt(web3: Any, tx_hash: Any, error_prefix: str) -> str:
    """Wait for transaction receipt and return hex hash. Raises on revert."""
    receipt = web3.eth.wait_for_transaction_receipt(
        tx_hash,
        timeout=TX_RECEIPT_TIMEOUT,
    )
    if receipt["status"] != 1:
        msg = f"{error_prefix} transaction reverted: {tx_hash.hex()}"
        raise RuntimeError(msg)
    return tx_hash.hex()


def _decode_delivery_flags(
    web3: Any,
    receipt: Any,
    marketplace_address: str,
    num_requests: int,
) -> list[bool]:
    """Decode MarketplaceDelivery event from a mined TX receipt.

    Returns list[bool] of length num_requests. True = the marketplace accepted
    the delivery (within responseTimeout); False = timeout (contract rejected
    it as late but did not revert the TX).

    Falls back to [True] * num_requests on any parsing error so that a missing
    or undecodable event never incorrectly marks requests as failed.
    Logs a WARNING whenever the fallback fires so operators can investigate.
    """
    from micromech.runtime.contracts import load_marketplace_abi

    # Normalize once for emitter-address comparison (defense-in-depth).
    norm_marketplace = marketplace_address.lower()
    try:
        marketplace = web3.eth.contract(
            address=web3.to_checksum_address(marketplace_address),
            abi=load_marketplace_abi(),
        )
        for log in receipt.get("logs", []):
            # Only process logs emitted by the marketplace contract.
            # process_log matches topic[0] but does NOT verify the emitter
            # address, so a different contract emitting the same event
            # signature would otherwise be decoded as our event.
            if log.get("address", "").lower() != norm_marketplace:
                continue
            try:
                event = marketplace.events.MarketplaceDelivery()
                decoded = event.process_log(log)
                flags = list(decoded["args"]["deliveredRequests"])
                if len(flags) == num_requests:
                    return flags
                # Length mismatch — shouldn't happen, but don't corrupt batch
                logger.warning(
                    "MarketplaceDelivery flags mismatch: got {} expected {}"
                    " — treating all as delivered (fallback)",
                    len(flags),
                    num_requests,
                )
                return [True] * num_requests
            except Exception as inner_exc:
                # Log decode failure only when the log comes from the marketplace
                # (already passed address filter) — helps diagnose ABI changes.
                logger.debug(
                    "Failed to decode MarketplaceDelivery log from marketplace: {}",
                    inner_exc,
                )
                continue  # try next log
    except Exception as exc:
        logger.warning(
            "Could not build marketplace contract for event decoding: {}"
            " — treating all {} request(s) as delivered (fallback)",
            exc,
            num_requests,
        )
        return [True] * num_requests

    logger.warning(
        "MarketplaceDelivery event not found in receipt"
        " — treating all {} request(s) as delivered (fallback)",
        num_requests,
    )
    return [True] * num_requests


def _batch_age_seconds(records: list[RequestRecord]) -> float:
    """Return age in seconds of the oldest record's request creation time."""
    now = datetime.now(timezone.utc)
    oldest = min(r.request.created_at for r in records)
    if oldest.tzinfo is None:
        oldest = oldest.replace(tzinfo=timezone.utc)
    return (now - oldest).total_seconds()


class DeliveryManager:
    """Delivers executed responses on-chain.

    Periodically checks for undelivered responses and submits them.
    Requires iwa bridge for chain operations. Without a bridge,
    delivery is skipped (requests stay in EXECUTED state).
    """

    def __init__(
        self,
        config: MicromechConfig,
        chain_config: ChainConfig,
        queue: PersistentQueue,
        bridge: Optional[Any] = None,
        metrics: "MetricsCollector | None" = None,
    ):
        self.config = config
        self.chain_config = chain_config
        self.queue = queue
        self.bridge = bridge
        self._running = False
        self._delivered_count = 0
        self._mech_contract: Optional[Any] = None
        self._metrics = metrics
        self._wallet_warning_logged = False
        self._ipfs_warning_logged = False
        self._delivery_failures: dict[str, int] = {}
        self._in_flight: set[str] = set()
        self._wake_event = asyncio.Event()

    @property
    def delivered_count(self) -> int:
        return self._delivered_count

    @property
    def _has_safe(self) -> bool:
        """Check if bridge has Safe service available (production path)."""
        return (
            self.bridge is not None
            and hasattr(self.bridge, "wallet")
            and hasattr(self.bridge.wallet, "safe_service")
        )

    @property
    def _chain_name(self) -> str:
        """Chain name from this delivery manager's config."""
        return self.chain_config.chain

    def wake(self) -> None:
        """Wake the delivery loop after a request becomes deliverable."""
        self._wake_event.set()

    def _get_nonce_allocator(self, multisig: str) -> Any:
        """Return the NonceAllocator for this delivery manager's Safe multisig."""
        return self.bridge.wallet.safe_service.get_allocator(
            multisig,
            self._chain_name,
            gap_alert_threshold=self.config.nonce_gap_alert_threshold,
        )

    def _get_mech_contract(self) -> Any:
        """Lazy-load the mech contract instance."""
        if self._mech_contract is None:
            mech_addr = self.chain_config.mech_address
            if not mech_addr:
                msg = "mech_address not configured"
                raise ValueError(msg)

            web3 = self.bridge.web3
            from micromech.runtime.contracts import load_mech_abi

            abi = load_mech_abi()
            self._mech_contract = web3.eth.contract(
                address=web3.to_checksum_address(mech_addr),
                abi=abi,
            )
        return self._mech_contract

    def _get_marketplace_status(self, request_id: str) -> int:
        """Return MechMarketplace.getRequestStatus(request_id)."""
        from micromech.runtime.contracts import load_marketplace_abi

        web3 = self.bridge.web3
        contract = web3.eth.contract(
            address=web3.to_checksum_address(self.chain_config.marketplace_address),
            abi=load_marketplace_abi(),
        )
        req_id_bytes = self._request_id_to_bytes(request_id)
        return self.bridge.with_retry(
            lambda: contract.functions.getRequestStatus(req_id_bytes).call()
        )

    def _classify_rejected_delivery(self, request_id: str) -> str:
        """Classify a false MarketplaceDelivery flag using current chain state."""
        try:
            status = self._get_marketplace_status(request_id)
        except Exception as e:
            logger.warning(
                "Could not classify rejected delivery for {}: {}",
                request_id[:16] + "...",
                _sanitize_error(e),
            )
            return "on_chain_rejected: status_unknown"
        label = _REQUEST_STATUS_LABELS.get(status, f"status_{status}")
        if status in (REQUEST_STATUS_DOES_NOT_EXIST, REQUEST_STATUS_DELIVERED):
            return f"on_chain_unavailable: {label}"
        if status == REQUEST_STATUS_REQUESTED_EXPIRED:
            return "on_chain_timeout"
        if status == REQUEST_STATUS_REQUESTED_PRIORITY:
            return "on_chain_rejected: requested_priority"
        return f"on_chain_rejected: {label}"

    def _mark_unavailable_on_chain(
        self,
        record: RequestRecord,
        status: int,
    ) -> None:
        """Remove an executed request from the delivery queue when chain state is final."""
        label = _REQUEST_STATUS_LABELS.get(status, f"status_{status}")
        req_id = record.request.request_id
        reason = f"on_chain_unavailable: {label}"
        logger.info(
            "Discarding {} before delivery: marketplace status={}",
            req_id[:16] + "...",
            label,
        )
        self.queue.mark_failed(req_id, reason)
        self._delivery_failures.pop(req_id, None)
        if self._metrics:
            self._metrics.record_delivery_failed(
                req_id,
                reason,
                chain=self._chain_name,
            )

    def _is_priority_request(self, record: RequestRecord) -> bool:
        """Return whether this mech is the priority mech for a request, if known."""
        priority_mech = (getattr(record.request, "priority_mech", None) or "").lower()
        mech_address = (self.chain_config.mech_address or "").lower()
        return bool(priority_mech and mech_address and priority_mech == mech_address)

    def _request_id_to_bytes(self, request_id: str) -> bytes:
        """Convert a request ID string to bytes32.

        On-chain IDs are stored as exactly 64 hex chars (bytes32), with or without
        "0x" prefix — converted directly.  IDs with "0x" prefix but wrong length
        raise ValueError (delivery mismatch risk).  Off-chain / non-hex IDs are
        sha256-hashed to get a deterministic bytes32.
        """
        has_prefix = request_id.startswith("0x")
        hex_candidate = request_id[2:] if has_prefix else request_id

        if has_prefix or len(hex_candidate) == 64:
            try:
                req_id_bytes = bytes.fromhex(hex_candidate)
                if len(req_id_bytes) != 32:
                    msg = (
                        f"request_id {request_id[:20]}... is {len(req_id_bytes)} bytes "
                        f"(expected 32); refusing to pad/truncate to avoid delivery mismatch"
                    )
                    raise ValueError(msg)
                return req_id_bytes
            except ValueError:
                raise
        # Non-hex IDs (e.g. "http-abc123") — sha256 for deterministic bytes32
        import hashlib

        return hashlib.sha256(request_id.encode()).digest()

    def _increment_failure(self, request_id: str, error: str) -> None:
        """Increment per-request failure counter; mark_failed after MAX_RETRIES.

        Prevents poison-pill batches from stalling indefinitely: a single broken
        record (bad IPFS payload, malformed ID, etc.) will permanently fail after
        DEFAULT_DELIVERY_MAX_RETRIES consecutive attempts and stop blocking the
        rest of the batch.  Transient errors (RPC blip, TX revert) need several
        failures before they reach the terminal state.
        """
        count = self._delivery_failures.get(request_id, 0) + 1
        self._delivery_failures[request_id] = count
        if count >= DEFAULT_DELIVERY_MAX_RETRIES:
            logger.error(
                "Request {} failed {} consecutive times ({}), marking as failed",
                request_id[:20] + "...",
                count,
                error,
            )
            self.queue.mark_failed(request_id, f"max_retries ({count}x): {error}")
            self._delivery_failures.pop(request_id, None)
        else:
            logger.warning(
                "Request {} failure {}/{}: {}",
                request_id[:20] + "...",
                count,
                DEFAULT_DELIVERY_MAX_RETRIES,
                error,
            )

    async def deliver_batch(self) -> int:
        """Deliver undelivered responses. On-chain: batched; off-chain: 1:1.

        On-chain records are accumulated and flushed together in a single Safe TX
        when config.delivery_batch_size records are ready or the oldest record
        has been waiting config.delivery_flush_timeout_seconds seconds.
        """
        if self.bridge is None:
            return 0

        # Check if wallet is available for signing
        try:
            _ = self.bridge.wallet.key_storage
        except Exception:
            if not self._wallet_warning_logged:
                logger.warning(
                    "Delivery skipped: no wallet available. "
                    "Set wallet_password in secrets.env or use the web wizard."
                )
                self._wallet_warning_logged = True
            return 0

        batch_size = self.config.delivery_batch_size
        flush_timeout = self.config.delivery_flush_timeout_seconds

        # Pull 2× batch size to ensure we get a full on-chain batch even when
        # off-chain records share the limit.  On-chain batch is then capped at
        # the configured batch size; off-chain processes all extras 1:1.
        records = self.queue.get_undelivered(limit=batch_size * 2, chain=self._chain_name)
        if not records:
            return 0

        onchain = [r for r in records if not r.request.is_offchain][:batch_size]
        offchain = [r for r in records if r.request.is_offchain]

        delivered = 0

        # --- On-chain: batch by size or time ---
        if onchain:
            full_batch = len(onchain) >= batch_size
            old_enough = _batch_age_seconds(onchain) >= flush_timeout
            should_flush = full_batch or old_enough
            if should_flush:
                flush_reason = "size" if full_batch else "timeout"
                logger.debug(
                    "Flushing on-chain batch chain={} size={} reason={} oldest_age={:.1f}s",
                    self._chain_name,
                    len(onchain),
                    flush_reason,
                    _batch_age_seconds(onchain),
                )
                delivered += await self._deliver_onchain_batch(onchain)

        # --- Off-chain: 1:1 (unchanged) ---
        for record in offchain:
            try:
                tx_hash, ipfs_hash = await self._deliver_one(record)
                if tx_hash:
                    self.queue.mark_delivered(
                        record.request.request_id,
                        tx_hash=tx_hash,
                        ipfs_hash=ipfs_hash,
                    )
                    delivered += 1
                    self._delivered_count += 1
                    if self._metrics:
                        self._metrics.record_delivery(
                            record.request.request_id, chain=self._chain_name
                        )
                    logger.opt(colors=True).info(
                        "<green>[{}] Delivered (offchain) {} tool={} tx={}</green>",
                        self._chain_name,
                        record.request.request_id[:16] + "...",
                        record.request.tool,
                        tx_hash[:18] + "...",
                    )
            except Exception as e:
                err_str = _sanitize_error(e)
                logger.error(
                    "Delivery failed for {}: {}",
                    record.request.request_id,
                    err_str,
                )
                if self._metrics:
                    self._metrics.record_delivery_failed(
                        record.request.request_id, err_str, chain=self._chain_name
                    )
                self.queue.mark_failed(record.request.request_id, f"delivery: {err_str}")

        return delivered

    async def _deliver_onchain_batch(self, records: list[RequestRecord]) -> int:
        """Prepare (IPFS in parallel) and submit all on-chain records in one Safe TX.

        IPFS uploads run concurrently. Records that fail IPFS prep are marked
        failed individually; the rest are batched into a single deliverToMarketplace call.
        """
        # Parallel IPFS uploads
        prep_started = time.monotonic()
        prepare_results = await asyncio.gather(
            *[self._prepare_onchain(r) for r in records],
            return_exceptions=True,
        )
        batch_prep_seconds = time.monotonic() - prep_started

        good: list[tuple[RequestRecord, bytes, bytes, Optional[str], float]] = []
        for record, result in zip(records, prepare_results):
            if isinstance(result, Exception):
                logger.exception(
                    "IPFS prep failed for {}: {}",
                    record.request.request_id,
                    result,
                )
                if self._metrics:
                    self._metrics.record_delivery_failed(
                        record.request.request_id, str(result), chain=self._chain_name
                    )
                # Use retry counter — IPFS failures may be transient; only
                # mark_failed permanently after MAX_RETRIES consecutive failures.
                self._increment_failure(record.request.request_id, f"ipfs_prep: {result}")
            else:
                req_id_bytes, delivery_data, ipfs_cid_hex = result  # type: ignore[misc]
                good.append(
                    (
                        record,
                        req_id_bytes,
                        delivery_data,
                        ipfs_cid_hex,
                        batch_prep_seconds,
                    )
                )

        if not good:
            return 0

        req_id_bytes_list = [item[1] for item in good]
        datas = [item[2] for item in good]

        try:
            safe_lock_wait_seconds = 0.0
            if self._has_safe:
                from micromech.core.bridge import get_service_info

                svc_info = get_service_info(self._chain_name)
                multisig = svc_info.get("multisig_address")
                if not multisig:
                    raise ValueError(
                        f"[{self._chain_name}] multisig_address not configured"
                        " — cannot dispatch on-chain batch"
                    )
                lock_wait_started = time.monotonic()
                async with get_safe_lock(multisig):
                    safe_lock_wait_seconds = time.monotonic() - lock_wait_started
                    submit_started = time.monotonic()
                    tx_hash, delivered_flags = await asyncio.to_thread(
                        self._submit_batch_delivery, req_id_bytes_list, datas
                    )
                    safe_submit_seconds = time.monotonic() - submit_started
            else:
                submit_started = time.monotonic()
                tx_hash, delivered_flags = await asyncio.to_thread(
                    self._submit_batch_delivery, req_id_bytes_list, datas
                )
                safe_submit_seconds = time.monotonic() - submit_started
            n_delivered = 0
            n_timed_out = 0
            for (
                record,
                _,
                _,
                ipfs_cid_hex,
                prep_seconds,
            ), accepted in zip(good, delivered_flags):
                req_id = record.request.request_id
                self._delivery_failures.pop(req_id, None)
                if accepted:
                    self.queue.mark_delivered(
                        req_id,
                        tx_hash=tx_hash,
                        ipfs_hash=ipfs_cid_hex,
                    )
                    self._delivered_count += 1
                    n_delivered += 1
                    if self._metrics:
                        self._metrics.record_delivery(req_id, chain=self._chain_name)
                        self._metrics.record_delivery_timing(
                            req_id,
                            chain=self._chain_name,
                            age_seconds=_record_age_seconds(record),
                            prep_seconds=prep_seconds,
                            safe_lock_wait_seconds=safe_lock_wait_seconds,
                            safe_submit_seconds=safe_submit_seconds,
                        )
                    logger.opt(colors=True).info(
                        "<green>[{}] Delivered {} tool={} tx={}</green>",
                        self._chain_name,
                        req_id[:16] + "...",
                        record.request.tool,
                        tx_hash[:18] + "...",
                    )
                else:
                    reason = self._classify_rejected_delivery(req_id)
                    logger.warning(
                        "Request {} was not accepted by marketplace (reason={}, tx={})",
                        req_id[:16] + "...",
                        reason,
                        tx_hash[:18] + "...",
                    )
                    self.queue.mark_delivery_rejected(
                        req_id,
                        error=reason,
                        tx_hash=tx_hash,
                        ipfs_hash=ipfs_cid_hex,
                    )
                    if reason == "on_chain_timeout":
                        n_timed_out += 1
                    if self._metrics:
                        if reason == "on_chain_timeout":
                            self._metrics.record_late_delivery(req_id, chain=self._chain_name)
                        self._metrics.record_delivery_failed(req_id, reason, chain=self._chain_name)
            ids_short = ", ".join(r.request.request_id[:10] for r, *_ in good)
            logger.info(
                "Batch TX mined: {} delivered, {} timed out (tx={} ids=[{}])",
                n_delivered,
                n_timed_out,
                tx_hash[:18] + "...",
                ids_short,
            )
            return n_delivered
        except Exception as e:
            ids = [r.request.request_id[:16] for r, *_ in good]
            logger.exception(
                "Batch delivery failed chain={} size={} ids={} — will retry (failure {}/{})",
                self._chain_name,
                len(good),
                ids,
                max(
                    (self._delivery_failures.get(r.request.request_id, 0) + 1 for r, *_ in good),
                    default=1,
                ),
                DEFAULT_DELIVERY_MAX_RETRIES,
            )
            err_str = _sanitize_error(e)
            for record, *_ in good:
                if self._metrics:
                    self._metrics.record_delivery_failed(
                        record.request.request_id, err_str, chain=self._chain_name
                    )
                # Increment per-record counter; mark_failed only after MAX_RETRIES.
                # TX reverts may be transient (gas, nonce, RPC) — leave in EXECUTED
                # until the retry budget is exhausted.
                self._increment_failure(record.request.request_id, f"tx: {err_str}")
            return 0

    async def _prepare_onchain(self, record: RequestRecord) -> tuple[bytes, bytes, Optional[str]]:
        """Build payload, upload to IPFS, return (req_id_bytes, delivery_data, ipfs_cid_hex).

        Raises if record has no result. Falls back to raw JSON if IPFS is unavailable.
        """
        if record.result is None:
            raise ValueError(f"No result for {record.request.request_id}")

        request_id = record.request.request_id

        response_payload = json.dumps(
            {
                "requestId": request_id,
                "result": record.result.output,
                "prompt": record.request.prompt,
                "tool": record.request.tool,
            },
            separators=(",", ":"),
        ).encode("utf-8")

        ipfs_cid_hex: Optional[str] = None
        try:
            from micromech.ipfs.client import (
                cid_hex_to_multihash_bytes,
                push_to_ipfs,
            )

            _, cid_hex = await push_to_ipfs(
                response_payload,
                api_url=IPFS_API_URL,
            )
            delivery_data = cid_hex_to_multihash_bytes(cid_hex)
            ipfs_cid_hex = cid_hex
            if self._ipfs_warning_logged:
                logger.info("IPFS recovered — resuming CID-based delivery")
                self._ipfs_warning_logged = False
        except Exception as e:
            if not self._ipfs_warning_logged:
                logger.warning(
                    "IPFS unavailable, delivering raw: {}",
                    e,
                )
                self._ipfs_warning_logged = True
            delivery_data = response_payload

        req_id_bytes = self._request_id_to_bytes(request_id)
        return req_id_bytes, delivery_data, ipfs_cid_hex

    async def _deliver_one(
        self,
        record: RequestRecord,
    ) -> tuple[Optional[str], Optional[str]]:
        """Deliver a single response (used for off-chain / HTTP requests).

        Returns (tx_hash, ipfs_cid_hex) or (None, None).

        Pushes the result to IPFS first (if enabled), then delivers on-chain:
        - On-chain: deliverToMarketplace(requestIds[], datas[])
        - Off-chain: deliverMarketplaceWithSignatures(...)
        """
        if record.result is None:
            logger.error(
                "No result for {}",
                record.request.request_id,
            )
            return None, None

        request_id = record.request.request_id

        # Build response payload
        response_payload = json.dumps(
            {
                "requestId": request_id,
                "result": record.result.output,
                "prompt": record.request.prompt,
                "tool": record.request.tool,
            },
            separators=(",", ":"),
        ).encode("utf-8")

        # Push to IPFS and get multihash bytes for delivery
        ipfs_cid_hex: Optional[str] = None
        try:
            from micromech.ipfs.client import (
                cid_hex_to_multihash_bytes,
                push_to_ipfs,
            )

            _, cid_hex = await push_to_ipfs(
                response_payload,
                api_url=IPFS_API_URL,
            )
            delivery_data = cid_hex_to_multihash_bytes(
                cid_hex,
            )
            ipfs_cid_hex = cid_hex
        except Exception as e:
            if not self._ipfs_warning_logged:
                logger.warning(
                    "IPFS unavailable, delivering raw: {}",
                    e,
                )
                self._ipfs_warning_logged = True
            delivery_data = response_payload

        if record.request.is_offchain:
            tx_hash = await asyncio.to_thread(
                self._submit_offchain_delivery,
                record,
                delivery_data,
            )
        else:
            # On-chain single-delivery (legacy path). In practice the main
            # delivery loop routes on-chain requests through
            # _deliver_onchain_batch / _deliver_single_onchain, which handle
            # timeout detection via the returned flags. Timeout flags are
            # intentionally discarded here — this path should never be reached
            # for on-chain requests in normal operation.
            logger.warning(
                "_deliver_one called for on-chain request {} — timeout detection unavailable"
                " on this path; use _deliver_onchain_batch or _deliver_single_onchain instead",
                record.request.request_id[:20],
            )
            tx_hash, _ = await asyncio.to_thread(
                self._submit_delivery,
                request_id,
                delivery_data,
            )
        return tx_hash, ipfs_cid_hex

    def _submit_batch_delivery(
        self,
        req_id_bytes_list: list[bytes],
        datas: list[bytes],
        safe_nonce: Optional[int] = None,
    ) -> tuple[str, list[bool]]:
        """Submit deliverToMarketplace([ids...], [datas...]) in a single Safe TX.

        Returns (tx_hash, delivered_flags) where delivered_flags[i] is True if
        the marketplace accepted request i (within responseTimeout) or False if
        it was rejected as a late delivery (on-chain timeout).
        """
        mech_contract = self._get_mech_contract()
        from micromech.core.bridge import get_service_info

        svc_info = get_service_info(self.chain_config.chain)
        multisig = svc_info.get("multisig_address")
        if not multisig:
            raise ValueError("multisig_address not configured — cannot deliver")
        from_addr = self.bridge.web3.to_checksum_address(multisig)

        fn_call = mech_contract.functions.deliverToMarketplace(
            req_id_bytes_list,
            datas,
        )
        label = f"BatchDelivery[{len(req_id_bytes_list)}]"
        tx_hash = self._submit_tx(fn_call, from_addr, label, safe_nonce=safe_nonce)

        # Parse per-request delivery outcome from the MarketplaceDelivery event.
        # False flags are non-reverting marketplace rejections. They can mean the
        # request was already delivered by another mech, is still priority-gated,
        # or did not satisfy the delivery-rate constraints.
        web3 = self.bridge.web3
        try:
            tx_hash_bytes = bytes.fromhex(tx_hash.removeprefix("0x"))
            receipt = web3.eth.get_transaction_receipt(tx_hash_bytes)
            if receipt is None:
                receipt = web3.eth.wait_for_transaction_receipt(
                    tx_hash_bytes, timeout=TX_RECEIPT_TIMEOUT
                )
        except Exception as e:
            logger.warning(
                "Could not fetch receipt for {} to check delivery flags: {}",
                tx_hash[:18],
                e,
            )
            return tx_hash, [True] * len(req_id_bytes_list)

        flags = _decode_delivery_flags(
            web3,
            receipt,
            self.chain_config.marketplace_address,
            len(req_id_bytes_list),
        )
        return tx_hash, flags

    def _submit_delivery(self, request_id: str, data: bytes) -> tuple[str, list[bool]]:
        """Submit deliverToMarketplace for a single request.

        Converts request_id to bytes32 and delegates to _submit_batch_delivery.
        Kept for backward compatibility (used by _deliver_one for on-chain path).
        """
        req_id_bytes = self._request_id_to_bytes(request_id)
        return self._submit_batch_delivery([req_id_bytes], [data])

    def _submit_offchain_delivery(self, record: RequestRecord, delivery_data: bytes) -> str:
        """Submit deliverMarketplaceWithSignatures for off-chain (HTTP) requests.

        Calls mech.deliverMarketplaceWithSignatures(requester, deliverWithSignatures[],
        deliveryRates[], paymentData).
        """
        mech_contract = self._get_mech_contract()
        from micromech.core.bridge import get_service_info

        svc_info = get_service_info(self.chain_config.chain)
        multisig = svc_info.get("multisig_address")
        if not multisig:
            raise ValueError("multisig_address not configured — cannot deliver")
        from_addr = self.bridge.web3.to_checksum_address(multisig)

        # requester: the sender from the HTTP request, or our own address
        requester_addr = record.request.sender or from_addr
        requester = self.bridge.web3.to_checksum_address(requester_addr)

        # Build the original request data
        request_data = record.request.data or json.dumps(
            {"prompt": record.request.prompt, "tool": record.request.tool},
            separators=(",", ":"),
        ).encode("utf-8")

        # Signature: from the HTTP request, or empty bytes
        sig_hex = record.request.signature or ""
        signature = bytes.fromhex(sig_hex.removeprefix("0x")) if sig_hex else b""

        # deliverWithSignatures is an array of tuples
        deliver_with_sigs = [(request_data, signature, delivery_data)]

        delivery_rates = [self.chain_config.delivery_rate]
        payment_data = b""

        fn_call = mech_contract.functions.deliverMarketplaceWithSignatures(
            requester,
            deliver_with_sigs,
            delivery_rates,
            payment_data,
        )
        return self._submit_tx(fn_call, from_addr, "Offchain delivery")

    def _submit_tx(
        self,
        fn_call: Any,
        from_addr: str,
        label: str = "TX",
        safe_nonce: Optional[int] = None,
    ) -> str:
        """Submit a contract call via Safe (prod) or impersonation (local/test).

        Production: bridge has safe_service → _via_safe (Gnosis Safe execTransaction).
        Local/test: bridge without safe_service → _via_impersonation (Anvil only).
        Any failure propagates as an exception — no silent fallbacks.
        """
        if self._has_safe:
            return self._via_safe(fn_call, from_addr, label, safe_nonce=safe_nonce)
        return self._via_impersonation(fn_call, from_addr, label)

    def _via_safe(
        self,
        fn_call: Any,
        from_addr: str,
        label: str = "TX",
        safe_nonce: Optional[int] = None,
    ) -> str:
        """Submit via Gnosis Safe execTransaction (production path)."""
        mech_address = self.bridge.web3.to_checksum_address(
            self.chain_config.mech_address,
        )
        call_data = fn_call.build_transaction({"from": from_addr})["data"]
        tx_hash = self.bridge.wallet.safe_service.execute_safe_transaction(
            safe_address_or_tag=from_addr,
            to=mech_address,
            value=0,
            chain_name=self._chain_name,
            data=call_data,
            safe_nonce=safe_nonce,
            allow_nonce_refresh=safe_nonce is None,
        )
        logger.info("Safe {} submitted chain={}: {}", label, self._chain_name, tx_hash)
        return tx_hash if isinstance(tx_hash, str) else tx_hash.hex()

    def _via_impersonation(self, fn_call: Any, from_addr: str, label: str = "TX") -> str:
        """Submit via direct transact() — only works on Anvil (auto-impersonate).

        Used in tests where the bridge has no safe_service. Not valid on real nodes.
        Gas is estimated via iwa's chain_interface (10% buffer, 500_000 on failure);
        floors at GAS_FLOOR_DELIVERY.
        """
        try:
            ci = self.bridge.wallet.chain_interfaces.get(self._chain_name)
            gas = max(ci.estimate_gas(fn_call, {"from": from_addr}), GAS_FLOOR_DELIVERY)
        except Exception as e:
            logger.warning(
                "Gas estimation failed ({}), using fallback {}", type(e).__name__, GAS_FALLBACK
            )
            gas = GAS_FALLBACK
        tx_hash = fn_call.transact({"from": from_addr, "gas": gas})
        return _wait_and_check_receipt(self.bridge.web3, tx_hash, label)

    async def _deliver_concurrent(self) -> int:
        """Deliver up to DEFAULT_DELIVERY_WORKERS requests concurrently.

        Each on-chain request becomes one Safe TX (batch_size=1), preserving
        delivery_delta == nonce_delta for staking liveness.  An in-flight set
        prevents the same request being picked up by two concurrent workers.
        When a Safe service is available, NonceAllocator pre-assigns sequential
        nonces so workers submit their Safe TXs in parallel without GS026 races.
        """
        if self.bridge is None:
            return 0

        try:
            _ = self.bridge.wallet.key_storage
        except Exception:
            if not self._wallet_warning_logged:
                logger.warning(
                    "Delivery skipped: no wallet available. "
                    "Set wallet_password in secrets.env or use the web wizard."
                )
                self._wallet_warning_logged = True
            return 0

        # Fetch a larger batch so finalized on-chain records can drain without
        # blocking fresh deliveries. Delivery slots are still capped after the
        # availability check.
        _FINALIZED_SWEEP_LIMIT = 100
        records = self.queue.get_undelivered(
            limit=max(DEFAULT_DELIVERY_WORKERS * 4, _FINALIZED_SWEEP_LIMIT),
            chain=self._chain_name,
        )
        if not records:
            return 0

        now = datetime.now(timezone.utc)

        def _age_seconds(r: Any) -> float:
            created = r.request.created_at
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            return (now - created).total_seconds()

        candidates = [r for r in records if r.request.request_id not in self._in_flight]
        deliverable: list[RequestRecord] = []
        for r in candidates:
            age = _age_seconds(r)
            should_check_status = (
                not r.request.is_offchain and age > MARKETPLACE_MAX_RESPONSE_TIMEOUT
            )
            if should_check_status:
                try:
                    status = await asyncio.to_thread(
                        self._get_marketplace_status,
                        r.request.request_id,
                    )
                except Exception as status_err:
                    logger.warning(
                        "Could not check marketplace status for stale request {}: {}"
                        " — keeping queued",
                        r.request.request_id[:16] + "...",
                        _sanitize_error(status_err),
                    )
                    continue
                else:
                    if status in (
                        REQUEST_STATUS_DOES_NOT_EXIST,
                        REQUEST_STATUS_DELIVERED,
                    ):
                        self._mark_unavailable_on_chain(r, status)
                        continue
                    if (
                        status == REQUEST_STATUS_REQUESTED_PRIORITY
                        and not self._is_priority_request(r)
                    ):
                        logger.debug(
                            "Stale request {} is still priority-gated, keeping queued",
                            r.request.request_id[:16] + "...",
                        )
                        continue
                    if status not in (
                        REQUEST_STATUS_REQUESTED_PRIORITY,
                        REQUEST_STATUS_REQUESTED_EXPIRED,
                    ):
                        label = _REQUEST_STATUS_LABELS.get(status, f"status_{status}")
                        logger.debug(
                            "Unknown marketplace status {} for {}, keeping queued",
                            label,
                            r.request.request_id[:16] + "...",
                        )
                        continue
            deliverable.append(r)

        onchain = [r for r in deliverable if not r.request.is_offchain][:DEFAULT_DELIVERY_WORKERS]
        offchain = [r for r in deliverable if r.request.is_offchain]

        selected = onchain + offchain
        if not selected:
            return 0

        for r in selected:
            self._in_flight.add(r.request.request_id)

        # safe_lock ensures only one consumer (delivery or payment_withdraw) submits
        # Safe TXs at a time, for both parallel and serial paths.
        # Parallel path also pre-assigns sequential nonces to prevent GS026 collisions.
        onchain_results: list[bool | BaseException] = []
        if onchain and self._has_safe:
            from micromech.core.bridge import get_service_info

            svc_info = get_service_info(self._chain_name)
            multisig = svc_info.get("multisig_address")
            if not multisig:
                raise ValueError(
                    f"[{self._chain_name}] multisig_address not configured"
                    " — cannot dispatch on-chain"
                )

            if self.config.parallel_nonce_enabled:
                lock_wait_started = time.monotonic()
                async with get_safe_lock(multisig):
                    safe_lock_wait_seconds = time.monotonic() - lock_wait_started
                    allocator = self._get_nonce_allocator(multisig)
                    try:
                        allocator.check_stuck(len(onchain))
                    except Exception:
                        # check_stuck failed — clean up _in_flight so requests
                        # can be retried on the next tick rather than leaking.
                        for r in onchain:
                            self._in_flight.discard(r.request.request_id)
                        raise

                    async def _dispatch(r: RequestRecord) -> bool:
                        # H4: prepare before allocating so a prep failure doesn't
                        # orphan a nonce slot and leave a gap in the Safe TX queue.
                        prep_started = time.monotonic()
                        try:
                            prep_data = await self._prepare_onchain(r)
                        except Exception as e:
                            logger.warning(
                                "[{}] Pre-allocation prep failed for {}: {}",
                                self._chain_name,
                                r.request.request_id,
                                _sanitize_error(e),
                            )
                            # H1: discard here — _deliver_single_onchain never called
                            self._in_flight.discard(r.request.request_id)
                            return False
                        prep_seconds = time.monotonic() - prep_started

                        _ALLOCATE_TIMEOUT = 15  # seconds; prevents indefinite thread-pool hang
                        nonce = None
                        try:
                            nonce = await asyncio.wait_for(
                                asyncio.to_thread(allocator.allocate),
                                timeout=_ALLOCATE_TIMEOUT,
                            )
                        except Exception:
                            logger.warning(
                                "[{}] Nonce allocator blocked/timed-out for {}, skipping",
                                self._chain_name,
                                r.request.request_id,
                            )
                            # H1: discard here — _deliver_single_onchain never called
                            self._in_flight.discard(r.request.request_id)
                            return False
                        # _deliver_single_onchain has its own except+finally; it
                        # never propagates. The finally here releases the nonce
                        # whether delivery succeeded, returned False, or (in the
                        # unlikely event of a future refactor) raised.
                        try:
                            result = await self._deliver_single_onchain(
                                r,
                                safe_nonce=nonce,
                                _prep_data=prep_data,
                                _prep_seconds=prep_seconds,
                                _safe_lock_wait_seconds=safe_lock_wait_seconds,
                            )
                            if not result:
                                allocator.invalidate("delivery_failed")
                            return result
                        finally:
                            allocator.release(nonce)

                    onchain_results = list(
                        await asyncio.gather(
                            *[_dispatch(r) for r in onchain], return_exceptions=True
                        )
                    )
            else:
                prepared_onchain: list[
                    tuple[RequestRecord, tuple[bytes, bytes, Optional[str]], float]
                ] = []
                try:
                    for r in onchain:
                        prep_started = time.monotonic()
                        try:
                            prep_data = await self._prepare_onchain(r)
                        except Exception as e:
                            err_str = _sanitize_error(e)
                            logger.exception(
                                "Delivery failed for {}: {}",
                                r.request.request_id[:20] + "...",
                                err_str,
                            )
                            self._increment_failure(r.request.request_id, f"tx: {err_str}")
                            if self._metrics:
                                self._metrics.record_delivery_failed(
                                    r.request.request_id,
                                    err_str,
                                    chain=self._chain_name,
                                )
                            self._in_flight.discard(r.request.request_id)
                        else:
                            prepared_onchain.append((r, prep_data, time.monotonic() - prep_started))

                    if prepared_onchain:
                        lock_wait_started = time.monotonic()
                        async with get_safe_lock(multisig):
                            safe_lock_wait_seconds = time.monotonic() - lock_wait_started
                            for r, prep_data, prep_seconds in prepared_onchain:
                                onchain_results.append(
                                    await self._deliver_single_onchain(
                                        r,
                                        _prep_data=prep_data,
                                        _prep_seconds=prep_seconds,
                                        _safe_lock_wait_seconds=safe_lock_wait_seconds,
                                    )
                                )
                except BaseException:
                    for r in selected:
                        self._in_flight.discard(r.request.request_id)
                    raise
        elif onchain:
            # No Safe configured — submit directly without lock
            for r in onchain:
                onchain_results.append(await self._deliver_single_onchain(r))

        offchain_tasks = [self._deliver_single_offchain_concurrent(r) for r in offchain]
        offchain_results = await asyncio.gather(*offchain_tasks, return_exceptions=True)
        results = onchain_results + list(offchain_results)
        n_delivered = sum(1 for r in results if r is True)
        if n_delivered:
            logger.info(
                "Tick delivered {} request(s) on-chain={} off-chain={}",
                n_delivered,
                sum(1 for r in onchain_results if r is True),
                sum(1 for r in offchain_results if r is True),
            )
        return n_delivered

    async def _deliver_single_onchain(
        self,
        record: RequestRecord,
        safe_nonce: Optional[int] = None,
        _prep_data: Optional[tuple[bytes, bytes, Optional[str]]] = None,
        _prep_seconds: float = 0.0,
        _safe_lock_wait_seconds: float = 0.0,
    ) -> bool:
        """Prepare and submit one on-chain request as a single Safe TX.

        One delivery = one Safe TX nonce, preserving staking liveness.
        Always removes the record from in-flight in the finally block.
        _prep_data: pre-computed (req_id_bytes, delivery_data, ipfs_cid_hex) tuple.
        Set by callers that prepare before entering nonce-sensitive sections.
        """
        try:
            if _prep_data is not None:
                req_id_bytes, delivery_data, ipfs_cid_hex = _prep_data
            else:
                prep_started = time.monotonic()
                req_id_bytes, delivery_data, ipfs_cid_hex = await self._prepare_onchain(record)
                _prep_seconds = time.monotonic() - prep_started
            submit_started = time.monotonic()
            tx_hash, delivered_flags = await asyncio.to_thread(
                self._submit_batch_delivery,
                [req_id_bytes],
                [delivery_data],
                safe_nonce,
            )
            safe_submit_seconds = time.monotonic() - submit_started
            req_id = record.request.request_id
            self._delivery_failures.pop(req_id, None)
            if not delivered_flags:
                logger.warning(
                    "[{}] No delivery flags returned for {}; treating as accepted (fallback)",
                    self._chain_name,
                    record.request.request_id[:16] + "...",
                )
            accepted = delivered_flags[0] if delivered_flags else True
            if accepted:
                self.queue.mark_delivered(
                    req_id,
                    tx_hash=tx_hash,
                    ipfs_hash=ipfs_cid_hex,
                )
                self._delivered_count += 1
                if self._metrics:
                    self._metrics.record_delivery(req_id, chain=self._chain_name)
                    self._metrics.record_delivery_timing(
                        req_id,
                        chain=self._chain_name,
                        age_seconds=_record_age_seconds(record),
                        prep_seconds=_prep_seconds,
                        safe_lock_wait_seconds=_safe_lock_wait_seconds,
                        safe_submit_seconds=safe_submit_seconds,
                    )
                logger.opt(colors=True).info(
                    "<green>[{}] Delivered {} tool={} tx={}</green>",
                    self._chain_name,
                    req_id[:16] + "...",
                    record.request.tool,
                    tx_hash[:18] + "...",
                )
                logger.debug(
                    "[{}] Delivery timing {} age={:.2f}s prep={:.2f}s "
                    "lock_wait={:.2f}s submit={:.2f}s",
                    self._chain_name,
                    req_id[:16] + "...",
                    _record_age_seconds(record),
                    _prep_seconds,
                    _safe_lock_wait_seconds,
                    safe_submit_seconds,
                )
            else:
                reason = self._classify_rejected_delivery(req_id)
                logger.warning(
                    "Request {} was not accepted by marketplace (reason={}, tx={})",
                    req_id[:16] + "...",
                    reason,
                    tx_hash[:18] + "...",
                )
                self.queue.mark_delivery_rejected(
                    req_id,
                    error=reason,
                    tx_hash=tx_hash,
                    ipfs_hash=ipfs_cid_hex,
                )
                if self._metrics:
                    if reason == "on_chain_timeout":
                        self._metrics.record_late_delivery(req_id, chain=self._chain_name)
                    self._metrics.record_delivery_failed(req_id, reason, chain=self._chain_name)
            return accepted
        except Exception as e:
            err_str = _sanitize_error(e)
            logger.exception(
                "Delivery failed for {}: {}",
                record.request.request_id[:20] + "...",
                err_str,
            )
            self._increment_failure(record.request.request_id, f"tx: {err_str}")
            if self._metrics:
                self._metrics.record_delivery_failed(
                    record.request.request_id,
                    err_str,
                    chain=self._chain_name,
                )
            return False
        finally:
            self._in_flight.discard(record.request.request_id)

    async def _deliver_single_offchain_concurrent(self, record: RequestRecord) -> bool:
        """Deliver one off-chain request, removing from in-flight when done."""
        try:
            tx_hash, ipfs_hash = await self._deliver_one(record)
            if tx_hash:
                self.queue.mark_delivered(
                    record.request.request_id,
                    tx_hash=tx_hash,
                    ipfs_hash=ipfs_hash,
                )
                self._delivered_count += 1
                if self._metrics:
                    self._metrics.record_delivery(record.request.request_id, chain=self._chain_name)
                logger.opt(colors=True).info(
                    "<green>[{}] Delivered (offchain) {} tool={} tx={}</green>",
                    self._chain_name,
                    record.request.request_id[:16] + "...",
                    record.request.tool,
                    tx_hash[:18] + "...",
                )
                return True
            return False
        except Exception as e:
            err_str = _sanitize_error(e)
            logger.error(
                "Delivery failed for {}: {}",
                record.request.request_id,
                err_str,
            )
            self._increment_failure(record.request.request_id, f"delivery: {err_str}")
            if self._metrics:
                self._metrics.record_delivery_failed(
                    record.request.request_id,
                    err_str,
                    chain=self._chain_name,
                )
            return False
        finally:
            self._in_flight.discard(record.request.request_id)

    # TODO(H1): crash recovery for STATUS_DELIVERING
    # If the process dies between _submit_batch_delivery and mark_delivered, the
    # records remain in STATUS_EXECUTED (or a hypothetical STATUS_DELIVERING) and
    # will be re-submitted on next startup, potentially double-delivering.
    # Fix requires a STATUS_DELIVERING state + schema migration to detect in-flight
    # batches on startup and check the chain for the TX hash before re-submitting.

    async def run(self) -> None:
        """Run the delivery loop.

        Concurrent mode is the default because it preserves staking liveness:
        one on-chain delivery per Safe nonce. Batch mode is explicit and should
        only be enabled when that nonce/delivery ratio no longer matters.
        """
        self._running = True
        interval = self.config.delivery_interval

        if self.bridge is None:
            logger.info("Delivery manager: no bridge — delivery disabled")
        else:
            if self.config.batch_delivery_enabled:
                logger.info(
                    "Delivery manager started (interval {}s, mode=batch, batch_size {}, flush_timeout {}s)",
                    interval,
                    self.config.delivery_batch_size,
                    self.config.delivery_flush_timeout_seconds,
                )
            else:
                logger.info(
                    "Delivery manager started (interval {}s, mode=concurrent, workers {})",
                    interval,
                    DEFAULT_DELIVERY_WORKERS,
                )

        while self._running:
            self._wake_event.clear()
            try:
                if self.config.batch_delivery_enabled:
                    count = await self.deliver_batch()
                else:
                    count = await self._deliver_concurrent()
                if count:
                    logger.debug("Delivered {} responses", count)

            except Exception as e:
                logger.exception("Delivery loop error: {}", e)
            try:
                await asyncio.wait_for(self._wake_event.wait(), timeout=interval)
            except asyncio.TimeoutError:
                pass

    def stop(self) -> None:
        self._running = False
        self._wake_event.set()
