"""IPFS client — push and pull data via HTTP.

Push uses iwa's IPFS API (requires an IPFS node with /api/v0/add).
Pull uses any public IPFS gateway (read-only HTTP GET).
CID computation is pure (no network needed).
"""

import base64
import hashlib
import json
from typing import Any, Optional

import aiohttp
from loguru import logger

_DEFAULT_GATEWAY = "https://gateway.autonolas.tech/ipfs/"

# Multihash prefix for sha2-256: function code (0x12) + digest length (0x20)
_SHA256_MULTIHASH_PREFIX = bytes([0x12, 0x20])

# CIDv1 prefix: version(1) + codec(raw=0x55) + multihash(sha256=0x12, len=0x20)
_CIDV1_RAW_SHA256_PREFIX = bytes([0x01, 0x55, 0x12, 0x20])


def compute_cid(data: bytes) -> str:
    """Compute CIDv1 base32 string for raw data.

    Returns a bafkrei... CID (raw codec, sha2-256).
    """
    digest = hashlib.sha256(data).digest()
    cid_bytes = _CIDV1_RAW_SHA256_PREFIX + digest
    b32 = base64.b32encode(cid_bytes).decode().lower().rstrip("=")
    return "b" + b32


def compute_cid_hex(data: bytes) -> str:
    """Compute CIDv1 hex representation (f01551220...).

    This is the format used internally by iwa and the OLAS contracts.
    """
    digest = hashlib.sha256(data).digest()
    cid_bytes = _CIDV1_RAW_SHA256_PREFIX + digest
    return "f" + cid_bytes.hex()


def cid_hex_to_multihash_bytes(cid_hex: str) -> bytes:
    """Extract multihash bytes from CIDv1 hex string.

    f01551220<sha256hex> → bytes(0x12 0x20 <sha256>)
    f(1) + 01(2) + 55(2) = 5 hex chars to skip, leaving 1220<sha256>
    """
    return bytes.fromhex(cid_hex[5:])


def is_ipfs_multihash(data: bytes) -> bool:
    """Check if data looks like a truncated IPFS multihash (sha2-256).

    On-chain requestData contains 34 bytes: 0x12 + 0x20 + 32-byte SHA-256 digest.
    """
    return len(data) == 34 and data[:2] == _SHA256_MULTIHASH_PREFIX


def normalize_to_multihash(data: bytes) -> Optional[bytes]:
    """Normalize on-chain requestData to a 34-byte sha2-256 multihash, or None.

    Handles two formats emitted by different OLAS clients:
    - 34 bytes (0x12 0x20 + sha256): our test script / standard format.
    - 32 bytes (sha256 only): iwa/triton truncates cid_hex[9:] which drops the
      multihash prefix, producing a bare 32-byte sha256 digest.
    """
    if len(data) == 34 and data[:2] == _SHA256_MULTIHASH_PREFIX:
        return data
    if len(data) == 32:
        return _SHA256_MULTIHASH_PREFIX + data
    return None


def multihash_to_cid(data: bytes) -> str:
    """Convert raw multihash bytes (0x12 0x20 <digest>) back to a CID string.

    Used to reconstruct the CID from on-chain requestData for IPFS fetch.
    """
    if len(data) < 34 or data[:2] != _SHA256_MULTIHASH_PREFIX:
        msg = f"Invalid multihash: expected 34 bytes starting with 0x1220, got {len(data)} bytes"
        raise ValueError(msg)
    digest = data[2:34]
    cid_bytes = _CIDV1_RAW_SHA256_PREFIX + digest
    b32 = base64.b32encode(cid_bytes).decode().lower().rstrip("=")
    return "b" + b32


async def fetch_from_ipfs(
    cid: str,
    gateway: str = _DEFAULT_GATEWAY,
    timeout: int = 30,
) -> bytes:
    """Fetch data from IPFS via HTTP gateway.

    Args:
        cid: The IPFS CID string (bafkrei... or Qm...).
        gateway: Gateway base URL (must end with /).
        timeout: Request timeout in seconds.

    Returns:
        Raw bytes from IPFS.
    """
    url = f"{gateway}{cid}"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
            resp.raise_for_status()
            data = await resp.read()
            logger.debug("Fetched {} bytes from IPFS: {}", len(data), cid[:16])
            return data


def _parse_varint(data: bytes, pos: int) -> tuple[int, int]:
    result, shift = 0, 0
    while pos < len(data):
        b = data[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result, pos


def _extract_dagpb_link_hash(data: bytes) -> Optional[bytes]:
    """Extract the first link's multihash from a DAG-PB encoded IPFS node.

    DAG-PB (protobuf) structure:
      PBNode { repeated PBLink Links = 2; optional bytes Data = 1; }
      PBLink { optional bytes Hash = 1; optional string Name = 2; ... }
    Returns the raw multihash bytes (0x12 0x20 + sha256) or None.
    """
    pos = 0
    try:
        while pos < len(data):
            tag, pos = _parse_varint(data, pos)
            field, wire = tag >> 3, tag & 0x7
            if wire == 2:
                length, pos = _parse_varint(data, pos)
                val = data[pos:pos + length]
                pos += length
                if field == 2:  # Links
                    ipos = 0
                    while ipos < len(val):
                        itag, ipos = _parse_varint(val, ipos)
                        ifield, iwire = itag >> 3, itag & 0x7
                        if iwire == 2:
                            ilen, ipos = _parse_varint(val, ipos)
                            ival = val[ipos:ipos + ilen]
                            ipos += ilen
                            if ifield == 1:  # Hash
                                return ival
                        elif iwire == 0:
                            _, ipos = _parse_varint(val, ipos)
                        else:
                            break
            elif wire == 0:
                _, pos = _parse_varint(data, pos)
    except Exception:
        pass
    return None


def _extract_unixfs_data(data: bytes) -> Optional[bytes]:
    """Extract raw file content from a UnixFS-wrapped PBNode.

    UnixFS structure (inside PBNode.Data):
      message Data { DataType Type = 1; optional bytes Data = 2; ... }
    Returns the file content bytes, or None.
    """
    pos = 0
    try:
        while pos < len(data):
            tag, pos = _parse_varint(data, pos)
            field, wire = tag >> 3, tag & 0x7
            if wire == 2:
                length, pos = _parse_varint(data, pos)
                val = data[pos:pos + length]
                pos += length
                if field == 1:  # PBNode.Data = UnixFS message
                    ipos = 0
                    while ipos < len(val):
                        itag, ipos = _parse_varint(val, ipos)
                        ifield, iwire = itag >> 3, itag & 0x7
                        if iwire == 2:
                            ilen, ipos = _parse_varint(val, ipos)
                            ival = val[ipos:ipos + ilen]
                            ipos += ilen
                            if ifield == 2:  # UnixFS.Data = file content
                                return ival
                        elif iwire == 0:
                            _, ipos = _parse_varint(val, ipos)
                        else:
                            break
            elif wire == 0:
                _, pos = _parse_varint(data, pos)
    except Exception:
        pass
    return None


async def fetch_json_from_ipfs(
    cid: str,
    gateway: str = _DEFAULT_GATEWAY,
    timeout: int = 30,
) -> dict:
    """Fetch and parse JSON from IPFS.

    Handles multiple encodings:
    - Raw JSON (our format and most mechs)
    - DAG-PB + UnixFS (Valory/open-autonomy agents format)
    """
    data = await fetch_from_ipfs(cid, gateway, timeout)

    # 1. Try direct JSON
    try:
        return json.loads(data)
    except (ValueError, UnicodeDecodeError):
        pass

    # 2. Try DAG-PB: parse outer node → follow link → parse inner UnixFS → JSON
    link_hash = _extract_dagpb_link_hash(data)
    if link_hash is not None and len(link_hash) == 34 and link_hash[:2] == _SHA256_MULTIHASH_PREFIX:
        try:
            inner_cid = multihash_to_cid(link_hash)
            inner_data = await fetch_from_ipfs(inner_cid, gateway, timeout)
            content = _extract_unixfs_data(inner_data)
            if content is not None:
                return json.loads(content)
        except Exception:
            pass

    raise ValueError(
        f"Unrecognised IPFS format (tried JSON, DAG-PB+UnixFS); first bytes: {data[:8].hex()}"
    )


async def push_to_ipfs(
    data: bytes,
    api_url: Optional[str] = None,
) -> tuple[str, str]:
    """Push data to IPFS. Returns (CID string, CID hex).

    Uses iwa's IPFS API if available, otherwise computes CID locally.
    """
    try:
        from iwa.core.ipfs import push_to_ipfs_async

        return await push_to_ipfs_async(data, api_url=api_url)
    except ImportError:
        # No iwa — compute CID locally (data won't actually be on IPFS)
        cid_str = compute_cid(data)
        cid_hex = compute_cid_hex(data)
        logger.warning("iwa not available — CID computed locally, data NOT pushed to IPFS")
        return cid_str, cid_hex


async def push_json_to_ipfs(
    obj: dict[str, Any],
    api_url: Optional[str] = None,
) -> tuple[str, str]:
    """Push JSON object to IPFS. Returns (CID string, CID hex)."""
    data = json.dumps(obj, separators=(",", ":")).encode("utf-8")
    return await push_to_ipfs(data, api_url=api_url)
