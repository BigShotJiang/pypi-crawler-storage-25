"""Bridge to iwa framework for wallet, chain, and contract operations.

iwa is an optional dependency. When not installed, operations that
require it will raise ImportError with a clear message.
"""

from typing import Any, Optional

from loguru import logger

_IWA_AVAILABLE = False
try:
    from iwa.core.chain import ChainInterfaces
    from iwa.core.wallet import Wallet

    _IWA_AVAILABLE = True
except ImportError:
    pass


def require_iwa() -> None:
    """Raise if iwa is not installed."""
    if not _IWA_AVAILABLE:
        msg = "iwa is required for chain operations. Install it with: pip install iwa"
        raise ImportError(msg)


class IwaBridge:
    """Wrapper to use iwa services from micromech.

    Provides:
    - Wallet (key management, signing)
    - ChainInterface (web3, RPC rotation)
    - Contract interactions (mech, marketplace, staking)
    """

    def __init__(self, chain_name: str = "gnosis") -> None:
        require_iwa()
        self.chain_name = chain_name
        self._wallet: Optional[Any] = None
        self._chain_interface: Optional[Any] = None

    @property
    def wallet(self) -> Any:
        """Lazy-load wallet via get_wallet() (respects wizard password)."""
        if self._wallet is None:
            self._wallet = get_wallet()
            logger.debug("iwa Wallet initialized")
        return self._wallet

    @property
    def chain_interface(self) -> Any:
        """Lazy-load chain interface with RPC rotation."""
        if self._chain_interface is None:
            interfaces = ChainInterfaces()
            ci = interfaces.get(self.chain_name)
            if ci is None:
                msg = f"Chain '{self.chain_name}' not found in iwa ChainInterfaces"
                raise ValueError(msg)
            self._chain_interface = ci
            logger.debug("iwa ChainInterface initialized for {}", self.chain_name)
        return self._chain_interface

    @property
    def web3(self) -> Any:
        """Get web3 instance (with RPC rotation)."""
        return self.chain_interface.web3

    def with_retry(self, fn: Any, **kwargs: Any) -> Any:
        """Execute a function with iwa's RPC auto-rotation."""
        return self.chain_interface.with_retry(fn, **kwargs)


def create_bridges(config: Any) -> dict[str, "IwaBridge"]:
    """Create IwaBridge instances for all enabled chains in config."""
    bridges: dict = {}
    try:
        for chain_name in config.enabled_chains:
            try:
                bridges[chain_name] = IwaBridge(chain_name=chain_name)
            except Exception as e:
                logger.warning("Bridge failed for {}: {}", chain_name, e)
    except Exception:
        logger.warning("iwa not available — running without chain access")
    return bridges


# Cached instances (avoid re-probing RPCs on every call)
_cached_wallet: Optional[Any] = None
_cached_interfaces: Optional[Any] = None
# Set by web setup wizard (POST /api/setup/wallet)
_cached_key_storage: Optional[Any] = None


def get_wallet() -> Any:
    """Get or create a Wallet instance.

    Priority:
    1. Return cached wallet if available.
    2. If web wizard set _cached_key_storage, build Wallet from it
       (uses the password the user entered in the wizard).
    3. Try standard Wallet() which reads wallet_password from env/secrets.
       Only if wallet file already exists (never auto-create).
    """
    global _cached_wallet  # noqa: PLW0603

    if _cached_wallet is not None:
        return _cached_wallet

    # Path A: Web wizard provided a KeyStorage with user's password.
    # Build Wallet manually to ensure the wizard password is used for signing.
    if _cached_key_storage is not None:
        logger.debug("get_wallet: building from wizard KeyStorage")

        from iwa.core.db import init_db
        from iwa.core.wallet import (
            AccountService,
            BalanceService,
            PluginService,
            SafeService,
            TransactionService,
            TransferService,
        )

        # WARNING: object.__new__(Wallet) bypasses Wallet.__init__ which
        # normally reads the wallet file and prompts for a password.  We do
        # this because Wallet has no factory/classmethod that accepts a
        # pre-built KeyStorage.  ALL service attributes that Wallet.__init__
        # would set are assigned explicitly below.  If Wallet gains new
        # attributes in a future iwa release, they must be added here too.
        wallet = object.__new__(Wallet)
        wallet.key_storage = _cached_key_storage
        wallet.account_service = AccountService(_cached_key_storage)
        wallet.balance_service = BalanceService(
            _cached_key_storage,
            wallet.account_service,
        )
        wallet.safe_service = SafeService(
            _cached_key_storage,
            wallet.account_service,
        )
        wallet.transaction_service = TransactionService(
            _cached_key_storage,
            wallet.account_service,
            wallet.safe_service,
        )
        wallet.transfer_service = TransferService(
            _cached_key_storage,
            wallet.account_service,
            wallet.balance_service,
            wallet.safe_service,
            wallet.transaction_service,
        )
        wallet.plugin_service = PluginService()
        wallet.chain_interfaces = ChainInterfaces()
        init_db()

        _cached_wallet = wallet
        return _cached_wallet

    # Path B: No wizard — try standard Wallet() (env password).
    # Only if wallet file exists (never auto-create).
    from pathlib import Path

    from iwa.core.constants import WALLET_PATH

    if Path(WALLET_PATH).exists():
        try:
            _cached_wallet = Wallet()
            if not hasattr(_cached_wallet, "chain_interfaces"):
                _cached_wallet.chain_interfaces = ChainInterfaces()
            return _cached_wallet
        except (AttributeError, TypeError):
            logger.debug("Wallet() failed")

    msg = "No wallet available. Use the web wizard or set wallet_password in secrets.env."
    raise RuntimeError(msg)


# ERC20 balanceOf — module-level constant (was duplicated across functions)
_ERC20_BALANCE_ABI = [
    {
        "inputs": [{"name": "account", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function",
    }
]


def _fetch_balances_for_address(chain_name: str, address: str) -> Optional[tuple[float, float]]:
    """Fetch (native, OLAS) balances for an address via iwa's ChainInterface.

    Returns None on RPC or interface failure. Callers must treat None
    differently from (0.0, 0.0) — None means "unknown", zero means "empty".
    Fail-closed to avoid misleading funding alerts (H4 / OWASP A04).
    """
    global _cached_interfaces  # noqa: PLW0603

    if not _IWA_AVAILABLE:
        return None
    if not address:
        return None

    try:
        if _cached_interfaces is None:
            _cached_interfaces = ChainInterfaces()
        ci = _cached_interfaces.get(chain_name)
        if not ci:
            return None

        native_wei = ci.with_retry(lambda: ci.web3.eth.get_balance(address))
        native = float(ci.web3.from_wei(native_wei, "ether"))
    except Exception:
        logger.debug("Failed to fetch native balance for {} on {}", address, chain_name)
        return None

    # OLAS balance is best-effort — if it fails we still return native with 0.0 OLAS,
    # because OLAS may legitimately not be deployed on this chain.
    olas_balance = 0.0
    try:
        olas_addr = ci.chain.get_token_address("OLAS")
        if olas_addr:
            contract = ci.web3.eth.contract(address=str(olas_addr), abi=_ERC20_BALANCE_ABI)
            raw = ci.with_retry(lambda: contract.functions.balanceOf(address).call())
            olas_balance = float(ci.web3.from_wei(raw, "ether"))
    except Exception:
        logger.debug("Failed to check OLAS balance for {} on {}", address, chain_name)

    return native, olas_balance


def check_balances(chain_name: str) -> Optional[tuple[float, float]]:
    """Check (native, OLAS) balances for the cached master wallet on a chain.

    Returns None on failure (unknown) — NOT (0.0, 0.0). Callers must
    distinguish "unknown" from "empty".
    """
    if not _IWA_AVAILABLE:
        return None

    address: Optional[str] = None
    if _cached_key_storage is not None:
        address = str(_cached_key_storage.get_address_by_tag("master"))
    elif _cached_wallet is not None:
        address = _cached_wallet.master_account.address

    if not address:
        return None

    return _fetch_balances_for_address(chain_name, address)


def check_address_balances(chain_name: str, address: str) -> Optional[tuple[float, float]]:
    """Check (native, OLAS) balances for any address on a chain.

    Returns None on failure (unknown). See `check_balances` for rationale.
    """
    return _fetch_balances_for_address(chain_name, address)


# OLAS price cache — prevents hammering the pricing API from /status, /last_rewards,
# /claim (M3/M4). Short TTL so price updates remain visible within ~60s.
_OLAS_PRICE_CACHE_TTL_SECONDS = 60.0
_olas_price_cache: dict[str, float] = {}  # keys: "value", "ts"


def get_olas_price_eur() -> Optional[float]:
    """Get current OLAS price in EUR via iwa's PriceService.

    Cached for ~60s. Returns last-known value on failure if cache is warm,
    else None.
    """
    import time

    now = time.monotonic()
    cached_value = _olas_price_cache.get("value")
    cached_ts = _olas_price_cache.get("ts", 0.0)
    if cached_value is not None and (now - cached_ts) < _OLAS_PRICE_CACHE_TTL_SECONDS:
        return cached_value

    try:
        from iwa.core.pricing import PriceService

        value = PriceService().get_token_price("autonolas", "eur")
        if value is not None:
            _olas_price_cache["value"] = value
            _olas_price_cache["ts"] = now
        return value
    except Exception:
        logger.debug("Failed to fetch OLAS price")
        # Fall back to last-known value if we have one; else None.
        return cached_value


def check_safe_balance(chain_name: str) -> Optional[float]:
    """Check native token balance of the service's Safe multisig.

    Returns native balance in whole units (e.g. xDAI), or None on failure.
    Callers must handle None (unknown balance) differently from 0.0 (empty).
    """
    try:
        if not _IWA_AVAILABLE:
            return None

        svc_info = get_service_info(chain_name)
        multisig = svc_info.get("multisig_address")
        if not multisig:
            return None

        global _cached_interfaces  # noqa: PLW0603
        if _cached_interfaces is None:
            _cached_interfaces = ChainInterfaces()
        ci = _cached_interfaces.get(chain_name)
        if not ci:
            return None

        native_wei = ci.with_retry(
            lambda: ci.web3.eth.get_balance(multisig),
        )
        return float(ci.web3.from_wei(native_wei, "ether"))
    except Exception:
        logger.debug("Failed to check safe balance on {}", chain_name)
        return None


_service_info_cache: dict[str, tuple[float, dict]] = {}
_SERVICE_INFO_TTL = 30  # seconds


def _get_attr(obj: Any, name: str, default: Any = None) -> Any:
    """Get attribute from dict-like or object, with fallback."""
    if hasattr(obj, "get"):
        return obj.get(name, default)
    return getattr(obj, name, default)


def get_service_info(chain_name: str) -> dict:
    """Read service data from iwa's olas plugin (cached 30s).

    Returns dict with service_id, service_key, multisig_address
    (or empty dict if unavailable).
    """
    import time

    now = time.monotonic()
    if chain_name in _service_info_cache:
        ts, cached = _service_info_cache[chain_name]
        if now - ts < _SERVICE_INFO_TTL:
            return cached
    try:
        from iwa.core.models import Config

        olas = Config().get_plugin_config("olas")
        if olas:
            services = _get_attr(olas, "services")
            if services:
                items = services.values() if hasattr(services, "values") else services
                for service in items:
                    svc_chain = _get_attr(service, "chain_name", "")
                    if svc_chain == chain_name:
                        svc_id = _get_attr(service, "service_id")
                        multisig = _get_attr(service, "multisig_address")
                        agent = _get_attr(service, "agent_address")
                        result = {
                            "service_id": svc_id,
                            "service_key": f"{chain_name}:{svc_id}",
                            "multisig_address": multisig,
                            "agent_address": str(agent) if agent else None,
                        }
                        _service_info_cache[chain_name] = (now, result)
                        return result
    except ImportError:
        pass
    _service_info_cache[chain_name] = (now, {})
    return {}
