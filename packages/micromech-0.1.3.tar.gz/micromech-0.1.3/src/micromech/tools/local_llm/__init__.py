"""Local LLM tool package."""
