"""
agentloop-py-openai — drop-in OpenAI SDK wrapper for AgentLoop.

    from openai import OpenAI
    from agentloop import AgentLoop
    from agentloop_openai import wrap_openai

    openai = wrap_openai(
        OpenAI(),
        loop=AgentLoop(api_key="ak_..."),
    )

    # Unchanged OpenAI call — AgentLoop hooks fire automatically
    resp = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
        agentloop={"user_id": "u_123"},
    )

    # Streaming works the same way (added in v0.2.0):
    stream = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
        stream=True,
    )
    for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="")

What `user_id` does (changed in v0.2.2):
    `user_id` tags the logged turn for per-user filtering in the
    dashboard. It does NOT filter memory retrieval — search returns
    the full org-wide memory corpus by default, regardless of which
    user this call is for. To scope retrieval to memories tagged with
    a specific user, set `search_user_id` explicitly:

        agentloop={
            "user_id": "u_123",          # tag the log
            "search_user_id": "u_123",   # opt-in: scope retrieval too
        }

    Prior to v0.2.2 the wrapper silently forwarded `user_id` to search
    as well, which suppressed retrieval of org-wide corrections. The
    fix is non-breaking for the default case; only callers who relied
    on the old per-user-search behavior need to set `search_user_id`.

For async code, use AsyncOpenAI + wrap_async_openai:

    from openai import AsyncOpenAI
    from agentloop.aio import AsyncAgentLoop
    from agentloop_openai import wrap_async_openai

    async with AsyncAgentLoop(api_key="ak_...") as loop:
        openai = wrap_async_openai(AsyncOpenAI(), loop=loop)
        stream = await openai.chat.completions.create(..., stream=True)
        async for chunk in stream:
            ...
"""

from ._ask import (
    PerCallOptions,
    WrapOptions,
    ask_with_agentloop,
    ask_with_agentloop_async,
)
from ._streaming import AgentLoopAsyncStream, AgentLoopStream
from ._wrap import wrap_async_openai, wrap_openai

__all__ = [
    # Sync
    "wrap_openai",
    "ask_with_agentloop",
    # Async
    "wrap_async_openai",
    "ask_with_agentloop_async",
    # Streaming wrappers (exposed for users who want to construct manually)
    "AgentLoopStream",
    "AgentLoopAsyncStream",
    # Configuration
    "PerCallOptions",
    "WrapOptions",
]

__version__ = "0.2.2"
