"""
Core helper that wraps a single OpenAI chat-completions call in the
AgentLoop cycle: search → inject → call → log_turn.

Exported as `ask_with_agentloop` for callers who want explicit control.
The `wrap_openai` Proxy in wrap.py builds on top of this.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable

from agentloop import AgentLoop, Memory

if TYPE_CHECKING:
    from openai import OpenAI


# ---------------------------------------------------------------------------
# Configuration dataclasses
# ---------------------------------------------------------------------------


@dataclass
class PerCallOptions:
    """Per-call overrides passed via the `agentloop` keyword to wrapped calls.

    Every field is optional. A wrapped call with no `agentloop` kwarg at
    all still works — the wrap-time config applies.
    """

    #: Tag the logged turn with this end-user id. Used for per-user
    #: filtering and analytics in the dashboard. Does NOT filter memory
    #: retrieval — by default, search returns the full org-wide memory
    #: corpus regardless of which user this call is for. To scope
    #: retrieval to memories tagged with a specific user, set
    #: `search_user_id` explicitly. (Prior to 0.2.2, `user_id` was
    #: silently forwarded to search as well, which suppressed retrieval
    #: of any org-wide correction. The fix is non-breaking for the
    #: default case but anyone who relied on the old per-user-search
    #: behavior should set `search_user_id` to keep it.)
    user_id: str | None = None
    #: Optional: scope memory retrieval to memories tagged with this
    #: user_id. Leave None (default) to search the full org corpus —
    #: which is what most callers want. Only set this when you have a
    #: reason to want per-user retrieval (e.g. a personal-assistant
    #: agent where each end-user has their own preference history).
    search_user_id: str | None = None
    session_id: str | None = None
    signals: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None
    #: Per-call tags. Folded into the logged turn's metadata under "tags",
    #: so reviewers can filter by tag in the dashboard ("show me turns
    #: from enterprise customers"). Distinct from WrapOptions.search_tags
    #: which filters which memories the search retrieves.
    tags: list[str] | None = None
    #: Skip AgentLoop entirely — no search, no log_turn. Useful for
    #: health checks, system calls, or any turn you don't want reviewed.
    skip: bool = False
    #: Skip only memory retrieval for this call. Log_turn still fires.
    #: Pass False to disable, or a dict like {"limit": 5, "tags": [...]}
    #: to override defaults.
    search: bool | dict[str, Any] = True


@dataclass
class WrapOptions:
    """Configuration passed to `wrap_openai(client, loop=..., ...)`."""

    loop: AgentLoop

    #: How to inject retrieved memories into the messages array. Default
    #: prepends a "Trusted facts from past corrections:" block to the
    #: first system message (or creates one if absent).
    inject_memories: Callable[[list[Memory], list[dict[str, Any]]], list[dict[str, Any]]] | None = None

    #: Auto-detect signals from the assistant's response. Merged with
    #: any per-call signals the caller passed.
    detect_signals: Callable[[str, str, list[Memory]], dict[str, Any] | None] | None = None

    search_limit: int = 3
    search_tags: list[str] = field(default_factory=list)

    #: If True, log_turn is skipped when no signals fired. Default False
    #: — log every turn so reviewers see baseline behavior.
    only_log_when_signaled: bool = False


# ---------------------------------------------------------------------------
# Default memory injector
# ---------------------------------------------------------------------------


def default_inject_memories(
    memories: list[Memory], messages: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Default: append a "Trusted facts" block to the first system message."""
    if not memories:
        return messages

    facts_block = "\n\nTrusted facts from past corrections:\n" + "\n".join(
        f"- {m.fact}" for m in memories
    )

    for i, msg in enumerate(messages):
        if msg.get("role") == "system":
            updated = list(messages)
            existing = msg.get("content", "") or ""
            if isinstance(existing, str):
                updated[i] = {**msg, "content": existing + facts_block}
            return updated

    # No system message — prepend one.
    return [
        {"role": "system", "content": "You are a helpful assistant." + facts_block},
        *messages,
    ]


# ---------------------------------------------------------------------------
# Extract the question from an OpenAI messages array
# ---------------------------------------------------------------------------


def extract_question(messages: list[dict[str, Any]]) -> str:
    """Last user message, text content only."""
    for msg in reversed(messages):
        if msg.get("role") != "user":
            continue
        content = msg.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            # Multi-part: concat text parts, skip image parts
            parts = [
                p["text"]
                for p in content
                if isinstance(p, dict) and p.get("type") == "text"
            ]
            return "\n".join(parts)
    return ""


def extract_answer(completion: Any) -> str:
    """Pull text content from a ChatCompletion response object.

    Accesses `.choices[0].message.content` which is the OpenAI SDK's
    object shape. Tolerates missing fields by returning empty string.
    """
    try:
        choices = getattr(completion, "choices", None) or completion.get("choices", [])
        if not choices:
            return ""
        msg = getattr(choices[0], "message", None) or choices[0].get("message", {})
        content = getattr(msg, "content", None) if hasattr(msg, "content") else msg.get("content")
        return content or ""
    except (AttributeError, KeyError, IndexError, TypeError):
        return ""


# ---------------------------------------------------------------------------
# Main entry point — non-streaming
# ---------------------------------------------------------------------------


def _detect_and_log(
    *,
    question: str,
    answer: str,
    memories: list[Memory],
    config: WrapOptions,
    per_call: PerCallOptions,
    partial: bool = False,
) -> None:
    """Run the detect_signals hook and log_turn — shared by streaming and
    non-streaming paths.

    `partial=True` adds metadata.partial=True so reviewers can filter out
    streams that were cancelled mid-flight (broken ctrl+c, dropped
    connection, etc.). The turn still gets logged because hiding partial
    responses entirely would create silent gaps in the review queue —
    better to surface them with a flag.
    """
    if not question or not answer:
        return

    auto_signals = (
        config.detect_signals(question, answer, memories)
        if config.detect_signals
        else None
    ) or {}
    merged_signals: dict[str, Any] = {**auto_signals, **(per_call.signals or {})}

    should_log = not config.only_log_when_signaled or len(merged_signals) > 0
    if not should_log:
        return

    metadata = dict(per_call.metadata or {})
    if partial:
        # Reviewers + filtering: clearly mark partial responses without
        # forcing them into a separate signal namespace.
        metadata["partial"] = True
    if per_call.tags:
        # Don't clobber user-supplied "tags" key in metadata. Merge.
        existing = metadata.get("tags")
        if isinstance(existing, list):
            # Dedupe while preserving order
            seen = set(existing)
            merged = list(existing) + [t for t in per_call.tags if t not in seen]
            metadata["tags"] = merged
        else:
            metadata["tags"] = list(per_call.tags)

    try:
        config.loop.log_turn(
            question=question,
            agent_response=answer,
            user_id=per_call.user_id,
            session_id=per_call.session_id,
            signals=merged_signals or None,
            metadata=metadata or None,
        )
    except Exception as e:  # noqa: BLE001
        # log_turn already swallows network errors when throw_on_error is
        # False (default), but defend against unexpected exception types.
        # The whole point is to never break the user's call.
        import logging
        logging.getLogger("agentloop.openai").warning(
            "agentloop log_turn failed: %s", e
        )


async def _detect_and_log_async(
    *,
    question: str,
    answer: str,
    memories: list[Memory],
    config: WrapOptions,
    per_call: PerCallOptions,
    partial: bool = False,
) -> None:
    """Async version of _detect_and_log. Detects whether the loop is sync
    or async and routes accordingly."""
    if not question or not answer:
        return

    auto_signals = (
        config.detect_signals(question, answer, memories)
        if config.detect_signals
        else None
    ) or {}
    merged_signals: dict[str, Any] = {**auto_signals, **(per_call.signals or {})}

    should_log = not config.only_log_when_signaled or len(merged_signals) > 0
    if not should_log:
        return

    metadata = dict(per_call.metadata or {})
    if partial:
        metadata["partial"] = True
    if per_call.tags:
        existing = metadata.get("tags")
        if isinstance(existing, list):
            seen = set(existing)
            merged = list(existing) + [t for t in per_call.tags if t not in seen]
            metadata["tags"] = merged
        else:
            metadata["tags"] = list(per_call.tags)

    import inspect
    log_turn = config.loop.log_turn
    is_async = inspect.iscoroutinefunction(log_turn)

    try:
        if is_async:
            await log_turn(
                question=question,
                agent_response=answer,
                user_id=per_call.user_id,
                session_id=per_call.session_id,
                signals=merged_signals or None,
                metadata=metadata or None,
            )
        else:
            # Sync loop in async chain — dispatch to executor so we don't
            # block the event loop on the HTTP call.
            import asyncio
            await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: log_turn(
                    question=question,
                    agent_response=answer,
                    user_id=per_call.user_id,
                    session_id=per_call.session_id,
                    signals=merged_signals or None,
                    metadata=metadata or None,
                ),
            )
    except Exception as e:  # noqa: BLE001
        import logging
        logging.getLogger("agentloop.openai").warning(
            "agentloop log_turn failed (async): %s", e
        )


def ask_with_agentloop(
    client: OpenAI,
    *,
    messages: list[dict[str, Any]],
    per_call: PerCallOptions | None = None,
    config: WrapOptions,
    **create_kwargs: Any,
) -> Any:
    """Run one OpenAI chat-completions call through the full AgentLoop cycle.

    Use this directly if you want explicit control (custom signal
    detection, conditional skipping, non-chat endpoints). The
    `wrap_openai` Proxy builds on top of this for the drop-in case.

    When `stream=True` is in create_kwargs, returns a streaming wrapper
    instead of a complete ChatCompletion. The wrapper passes chunks
    through to the caller transparently and logs the assembled turn at
    end-of-stream. See _streaming.AgentLoopStream.
    """
    per_call = per_call or PerCallOptions()

    if per_call.skip:
        return client.chat.completions.create(messages=messages, **create_kwargs)

    streaming = bool(create_kwargs.get("stream"))

    question = extract_question(messages)

    # ---- 1. Retrieve memories ----
    memories: list[Memory] = []
    if per_call.search is not False and question:
        search_config = per_call.search if isinstance(per_call.search, dict) else {}
        memories = config.loop.search(
            question,
            limit=search_config.get("limit", config.search_limit),
            user_id=per_call.search_user_id,
            tags=search_config.get("tags") or (config.search_tags or None),
        )

    # ---- 2. Inject memories into prompt ----
    injector = config.inject_memories or default_inject_memories
    augmented_messages = injector(memories, messages)

    # ---- 3. Call the LLM ----
    if streaming:
        # Returns an iterator of ChatCompletionChunk. Wrap it so we can
        # accumulate the response and log_turn at end-of-stream.
        from ._streaming import AgentLoopStream
        stream = client.chat.completions.create(
            messages=augmented_messages, **create_kwargs
        )
        return AgentLoopStream(
            stream,
            question=question,
            memories=memories,
            config=config,
            per_call=per_call,
        )

    completion = client.chat.completions.create(
        messages=augmented_messages, **create_kwargs
    )
    answer = extract_answer(completion)

    # ---- 4. Detect signals + log_turn ----
    _detect_and_log(
        question=question,
        answer=answer,
        memories=memories,
        config=config,
        per_call=per_call,
    )

    return completion


async def ask_with_agentloop_async(
    client: Any,
    *,
    messages: list[dict[str, Any]],
    per_call: PerCallOptions | None = None,
    config: WrapOptions,
    **create_kwargs: Any,
) -> Any:
    """Async equivalent of ask_with_agentloop.

    `client` should be an AsyncOpenAI instance. Both streaming and
    non-streaming are supported.
    """
    per_call = per_call or PerCallOptions()

    if per_call.skip:
        return await client.chat.completions.create(messages=messages, **create_kwargs)

    streaming = bool(create_kwargs.get("stream"))

    question = extract_question(messages)

    # ---- 1. Retrieve memories ----
    # Search is sync by default (most users have AgentLoop, not AsyncAgentLoop).
    # Detect and dispatch.
    import inspect
    memories: list[Memory] = []
    if per_call.search is not False and question:
        search_config = per_call.search if isinstance(per_call.search, dict) else {}
        search_fn = config.loop.search
        search_kwargs = dict(
            limit=search_config.get("limit", config.search_limit),
            user_id=per_call.search_user_id,
            tags=search_config.get("tags") or (config.search_tags or None),
        )
        if inspect.iscoroutinefunction(search_fn):
            memories = await search_fn(question, **search_kwargs)
        else:
            import asyncio
            memories = await asyncio.get_event_loop().run_in_executor(
                None, lambda: search_fn(question, **search_kwargs)
            )

    # ---- 2. Inject memories into prompt ----
    injector = config.inject_memories or default_inject_memories
    augmented_messages = injector(memories, messages)

    # ---- 3. Call the LLM ----
    if streaming:
        from ._streaming import AgentLoopAsyncStream
        stream = await client.chat.completions.create(
            messages=augmented_messages, **create_kwargs
        )
        return AgentLoopAsyncStream(
            stream,
            question=question,
            memories=memories,
            config=config,
            per_call=per_call,
        )

    completion = await client.chat.completions.create(
        messages=augmented_messages, **create_kwargs
    )
    answer = extract_answer(completion)

    # ---- 4. Detect signals + log_turn ----
    await _detect_and_log_async(
        question=question,
        answer=answer,
        memories=memories,
        config=config,
        per_call=per_call,
    )

    return completion
