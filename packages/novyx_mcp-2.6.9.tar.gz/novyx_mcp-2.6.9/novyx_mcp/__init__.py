__version__ = "2.6.9"

from .server import mcp as create_server

__all__ = ["create_server"]
