from collections import defaultdict
import functools
from itertools import islice
import multiprocessing
import numpy as np

from .utility import convert
from .w90file import W90_file, auto_kptirr, check_shape
from .io import sparselist_to_dict
from ..utility import cached_einsum


class MMN(W90_file):
    """
    class to store overlaps between Bloch functions at neighbouring k-points
    the MMN file of wannier90

    MMN.data[ik, ib, m, n] = <u_{m,k}|u_{n,k+b}>

    Parameters
    ----------
    seedname : str
        the prefix of the file (including relative/absolute path, but not including the extension  `.mmn`)

    Attributes
    ----------
    data : np.ndarray(shape=(NK, NNB, NB, NB), dtype=complex)
        the overlap matrix elements between the Wavefunctions at neighbouring k-points
    neighbours : np.ndarray(shape=(NK, NNB), dtype=int)
        the indices of the neighbouring k-points
    G : np.ndarray(shape=(NK, NNB, 3), dtype=int)
        the reciprocal lattice vectors connecting the k-points
    """

    npz_tags = ["NK"]
    npz_keys_dict_int = ["data", "bk_reorder"]
    extension = "mmn"

    def __init__(self, data, bk_reorder=None, NK=None):
        super().__init__(data=data, NK=NK)
        shape = check_shape(self.data)
        assert len(shape) == 3, f"MMN data should have 4 dimensions, got {len(shape)}"
        assert shape[1] == shape[2], f"MMN data should have NB x NB shape, got {shape[1]} x {shape[2]}"
        self.NNB = shape[0]
        if bk_reorder is None:
            bk_reorder = {ik: np.arange(self.NNB) for ik in self.data.keys()}
        bk_reorder = sparselist_to_dict(bk_reorder)
        self.NB = shape[1]
        if bk_reorder is None:
            bk_reorder = sparselist_to_dict([np.arange(self.NNB, dtype=int) for _ in range(self.NK)])
        self.bk_reorder = bk_reorder

    @classmethod
    def from_w90_file(cls, seedname, bkvec, npar=multiprocessing.cpu_count(), selected_kpoints=None):
        f_mmn_in = open(seedname + ".mmn", "r")
        f_mmn_in.readline()
        NB, NK, NNB = np.array(f_mmn_in.readline().split(), dtype=int)
        if selected_kpoints is None:
            selected_kpoints = np.arange(NK)
        block = 1 + NB * NB
        data = []
        headstring = []
        mult = 4

        # TODO: FIXME: npar = 0 does not work
        if npar > 0:
            pool = multiprocessing.Pool(npar)
        # TODO : do text conversion only for selected kpoints
        for j in range(0, NNB * NK, npar * mult):
            x = list(islice(f_mmn_in, int(block * npar * mult)))
            if len(x) == 0:
                break
            headstring += x[::block]
            y = [x[i * block + 1:(i + 1) * block] for i in range(npar * mult) if (i + 1) * block <= len(x)]
            if npar > 0:
                data += pool.map(convert, y)
            else:
                data += [convert(z) for z in y]

        if npar > 0:
            pool.close()
            pool.join()
        f_mmn_in.close()
        data = [d[:, 0] + 1j * d[:, 1] for d in data]
        data = np.array(data).reshape(NK, NNB, NB, NB).transpose((0, 1, 3, 2))
        data = {ik: data[ik] for ik in selected_kpoints}
        headstring = np.array([s.split() for s in headstring], dtype=int).reshape(NK, NNB, 5)
        assert np.all(headstring[:, :, 0] - 1 == np.arange(NK)[:, None])
        neighbours = headstring[:, :, 1] - 1
        G = headstring[:, :, 2:]
        bk_reorder = [None for _ in range(NK)]
        for ik in selected_kpoints:
            bk_reorder[ik] = bkvec.reorder_bk_vectors(ik, neighbours[ik], G[ik], data[ik])


        return MMN(data=data,
                   bk_reorder=bk_reorder,
                   NK=NK)

    def to_w90_file(self, seedname):
        f_mmn_out = open(seedname + ".mmn", "w")
        f_mmn_out.write("MMN file\n")
        f_mmn_out.write(f"{self.NB} {self.NK} {self.NNB}\n")
        for ik in range(self.NK):
            for ib in range(self.NNB):
                f_mmn_out.write(f"{ik + 1} {self.neighbours[ik, ib] + 1} {' '.join(map(str, self.G[ik][ib]))}\n")
                for m in range(self.NB):
                    for n in range(self.NB):
                        f_mmn_out.write(f"{self.data[ik][ib, n, m].real} {self.data[ik][ib, n, m].imag}\n")
        f_mmn_out.close()

    def select_bands(self, selected_bands, var_select=False):
        return super().select_bands(selected_bands, dimensions=(1, 2), var_select=var_select)




    def equals(self, other, tolerance=1e-8, check_reorder=True):
        iseq, message = super().equals(other, tolerance)
        if not iseq:
            return iseq, message
        if self.NNB != other.NNB:
            return False, f"the number of neighbouring bands is not equal: {self.NNB} and {other.NNB} correspondingly"
        if check_reorder:
            for ik in self.bk_reorder.keys():
                if not np.all(self.bk_reorder[ik] == other.bk_reorder[ik]):
                    return False, f"the bk_reorder vectors are not equal for k-point {ik}: {self.bk_reorder[ik]} and {other.bk_reorder[ik]} correspondingly"
        return True, ""


    @classmethod
    def from_bandstructure(cls,
                           bandstructure,
                           bkvec,
                           bandstructure_left=None,
                           normalize=False,
                           verbose=False,
                           selected_kpoints=None,
                           kptirr=None,
                           NK=None,
                           symmetrizer=None,
                           symmetrizer_left=None,
                           irreducible=False,
                           irred_bk_only=True,
                           include_paw=True,
                           include_pseudo=True,
                           ):
        """
        Create an AMN object from a BandStructure object
        So far only delta-localised s-orbitals are implemented

        Parameters
        ----------
        bandstructure : BandStructure
            the band structure object
        normalize : bool
            if True, the wavefunctions are normalised
        param_search_bk : dict
            additional parameters for `:func:find_bk_vectors`

        Returns
        -------
        MMN 
        """
        if irreducible:
            assert symmetrizer is not None, "Symmetrizer should be provided if irreducible is True"
            if symmetrizer_left is None:
                symmetrizer_left = symmetrizer
            if kptirr is None:
                kptirr = symmetrizer.kptirr
            kpt2kptirr = symmetrizer.kpt2kptirr
            kpt_from_kptirr_isym = symmetrizer.kpt_from_kptirr_isym
            kpt_grid = symmetrizer.kpoints_all
        else:
            kpt_grid = np.array([kp.k for kp in bandstructure.kpoints])

        NK, selected_kpoints, kptirr = auto_kptirr(
            bandstructure, selected_kpoints=selected_kpoints, kptirr=kptirr, NK=NK)
        print(f"NK= {NK}, selected_kpoints = {selected_kpoints}, kptirr = {kptirr}")

        identity_operation = bandstructure.spacegroup.get_identity_operation()

        spinor = bandstructure.spinor
        nspinor = 2 if spinor else 1

        if verbose:
            print("Creating mmn. ")

        if selected_kpoints is None:
            selected_kpoints = np.arange(NK)



        NB = bandstructure.num_bands
        NNB = bkvec.NNB


        # now get the neighbour kpoint' wavefunctions, if those points do not belong to the irreducible k-points
        if hasattr(bandstructure, "kpoints_paw"):
            use_paw = True
            kpoints_in = bandstructure.kpoints_paw
        else:
            use_paw = False
            kpoints_in = bandstructure.kpoints
        kpoints_sel = [kpoints_in[ik] for ik in selected_kpoints]
        kpoints_dict_all = {ik: kpoints_sel[ik] for ik in kptirr}  # a dictionary to store kpoints that are not in the original bandstructure

        if symmetrizer is not None and irred_bk_only:
            bkirr, bk2bkirr, bk_from_bk_irr_isym, bk_map = symmetrizer.get_bk_mapping(bkvec.bk_grid, bkvec.neighbours)
        else:
            bkirr = [np.arange(NNB) for _ in kptirr]
            bk2bkirr = np.array([np.arange(NNB) for _ in kptirr])
            bk_from_bk_irr_isym = np.zeros((len(kptirr), NNB), dtype=int)
            bk_map = None


        for ikirr, kirr in enumerate(kptirr):
            for ib, ik2 in enumerate(bkvec.neighbours[kirr]):
                if ib in bkirr[ikirr]:
                    ik2 = int(ik2)
                    if ik2 not in kpoints_dict_all:
                        # if use_paw:
                        #     raise RuntimeError("PAW k-points should be provided for all k-points in the Monkhorst-Pack grid")``
                        isym = kpt_from_kptirr_isym[ik2]
                        # print(f"isym = {isym}, ik2={ik2}, {kpt_from_kptirr_isym=}")
                        ik_origin = kpt2kptirr[ik2]
                        kp_origin = kpoints_sel[ik_origin]
                        symop = bandstructure.spacegroup.symmetries[isym]
                        kp2 = kp_origin.get_transformed_copy(symmetry_operation=symop,
                                                        k_new=kpt_grid[ik2])
                        kpoints_dict_all[ik2] = kp2



        data = defaultdict(lambda: np.zeros((NNB, NB, NB), dtype=complex))
        if use_paw:
            wavefunc_all = Grid_PAW_all(kpoints_dict_all=kpoints_dict_all,
                                        product=functools.partial(bandstructure.overlap_paw.product, include_paw=include_paw, include_pseudo=include_pseudo),
                                        identity_operation=identity_operation)
        else:
            wavefunc_all = Grid_ig_all(kpoints_dict_all, bkvec.G, NB, nspinor, normalize=normalize)

        if bandstructure_left is not None:
            if use_paw:
                kpoints_in_left = bandstructure_left.kpoints_paw
            else:
                kpoints_in_left = bandstructure_left.kpoints
            kpoints_sel_left = [kpoints_in_left[ik] for ik in selected_kpoints]
            kpoints_dict_all_left = {ik: kpoints_sel_left[ik] for ik in kptirr}
            if use_paw:
                wavefunc_all_left = Grid_PAW_all(kpoints_dict_all=kpoints_dict_all_left,
                                                product=functools.partial(bandstructure.overlap_paw.product, include_paw=include_paw, include_pseudo=include_pseudo),
                                                identity_operation=identity_operation)
            else:
                wavefunc_all_left = Grid_ig_all(kpoints_dict_all_left, bkvec.G, NB, nspinor, normalize=normalize)
        else:
            wavefunc_all_left = wavefunc_all


        # but are needed for the finite-difference scheme (obtained by symmetry)
        for ikirr, kirr in enumerate(kptirr):
            bra = wavefunc_all_left.get_WF(kirr, conj=True)
            # overlaps = wavefunc_all.product(bra, bra)
            # overlaps_err = np.max(abs((overlaps - np.eye(NB))))
            # print(f"Calculating overlaps for k-point {ikirr} orthonorm_error = {overlaps_err}")
            # print(f"Calculating overlaps for k-point {ikirr}({kirr} on the grid) the little group  is {symmetrizer.isym_little[ikirr]}, {bk_from_bk_irr_isym[ikirr]=}")
            ib_is_set = np.zeros(NNB, dtype=bool)
            for ib in bkirr[ikirr]:  # only calculate for irreducible bk points
                assert not ib_is_set[ib], f"bk index {ib} for k-point {kirr} is already set."
                ik2 = int(bkvec.neighbours[kirr][ib])
                ket = wavefunc_all.get_WF(ik2, conj=False, G=bkvec.G[kirr][ib])
                data[kirr][ib, :, :] = wavefunc_all.product(bra, ket, bk=bkvec.bk_red[ib])
                ib_is_set[ib] = True

            for ib, ik2 in enumerate(bkvec.neighbours[kirr]):
                if ib not in bkirr[ikirr]:
                    assert not ib_is_set[ib], f"bk index {ib} for k-point {kirr} is already set."
                    ib_origin = bk2bkirr[ikirr][ib]
                    ikb_origin = int(bkvec.neighbours[kirr][ib_origin])
                    isym = bk_from_bk_irr_isym[ikirr][ib]
                    assert symmetrizer.kptirr2kpt[ikirr, isym] == kirr
                    # print(f"  Symmetry operation {isym} is used to get the overlaps for k-point {ikirr} and bk index {ib} from bk index {ib_origin} (ikikirr={ikikirr})")
                    # print(f"calling symmetrizer.transform_Mmn_kb with isym={isym}, ikirr={ikikirr}, ib={ib_origin}, ikb={ikb_origin}")
                    data[kirr][ib, :, :] = symmetrizer.transform_Mmn_kb(M=data[kirr][ib_origin],
                                                                        isym=isym, ikirr=ikirr, ib=ib_origin,
                                                                        ikb=ikb_origin,
                                                                        bk_grid_map=bk_map, bk_cart=bkvec.bk_cart,
                                                                        symmetrizer_left=symmetrizer_left)
                    ib_is_set[ib] = True
        return MMN(
            data=data,
            NK=NK,
            bk_reorder=None
        )


class Grid_PAW_all:

    def __init__(self, kpoints_dict_all, identity_operation, product):
        self.kpoints_dict_all = kpoints_dict_all
        self.identity_operation = identity_operation
        self.product = product

    def get_WF(self, ik, G=0, conj=False):
        kp = self.kpoints_dict_all[ik]
        kp = kp.get_transformed_copy(symmetry_operation=self.identity_operation, k_new=kp.k + G)
        return kp


class Grid_ig_all:

    def __init__(self, kpoints_dict_all, G, NB, nspinor, normalize=False):
        self.kpoints_dict_all = kpoints_dict_all
        ig_list = [kp.ig for kp in kpoints_dict_all.values()]

        igmin_k = np.array([ig[:, :3].min(axis=0) for ig in ig_list])
        igmax_k = np.array([ig[:, :3].max(axis=0) for ig in ig_list])

        del ig_list
        self.NB = NB
        self.nspinor = nspinor

        Gloc = np.array([g for g in G.values()])

        self.igmin_glob = igmin_k.min(axis=0) - Gloc.max(axis=(0, 1))
        self.igmax_glob = igmax_k.max(axis=0) - Gloc.min(axis=(0, 1))

        self.ig_grid = self.igmax_glob - self.igmin_glob + 1
        # print(f"ig_grid = {ig_grid}, igmin_glob = {igmin_glob}, igmax_glob = {igmax_glob}")
        self.normalize = normalize
        if normalize:
            self.norm = {ik2: np.linalg.norm(kp.WF.reshape(NB, -1), axis=1)
                         for ik2, kp in kpoints_dict_all.items()}

    def get_WF(self, ik, conj=False, G=0):
        kp1 = self.kpoints_dict_all[ik]
        bra = np.zeros((self.NB, self.nspinor) + tuple(self.ig_grid), dtype=complex)
        for ig, g in enumerate(kp1.ig):
            _g = g[:3] - self.igmin_glob - G
            assert np.all(_g >= 0) and np.all(_g < self.ig_grid), \
                f"g {_g} out of bounds for ig_grid {self.ig_grid} at ik1={ik}, ig={ig}"
            for ispinor in range(self.nspinor):
                bra[:, ispinor, _g[0], _g[1], _g[2]] = kp1.WF[:, ig, ispinor]
        if conj:
            bra = bra.conj()
        if self.normalize:
            bra[:] = bra / self.norm[ik][:, None, None, None, None]
        return bra

    def product(self, bra, ket, bk=None):
        """
        Calculate the product <bra|ket> 
        bk is not used for the grid representation, but is kept for compatibility with the PAW representation
        """
        return cached_einsum('asijk,bsijk->ab', bra, ket)
