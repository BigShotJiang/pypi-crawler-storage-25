
import numpy as np

from ..fourier.rvectors import Rvectors

from ..utility import str2bool
from termcolor import cprint
from .system_R import System_R
from collections import defaultdict
from scipy.constants import physical_constants, angstrom
from .needed_data import NeededData

bohr = physical_constants['Bohr radius'][0] / angstrom


def get_system_fplo(hamdata="+hamdata",
                mp_grid=None,
                **parameters):
    """
    System initialized from the `+hamdata` file written by `FPLO <https://www.fplo.de/>`__ code,

    Parameters
    ----------
    hamdata : str
        name (and path) of the "+hamdata" file to be read
    mp_grid : [nk1,nk2,nk3]
        size of Monkhorst-Pack grid used in ab initio calculation. Needed for MDRS


    Notes
    -----
    see also  parameters of the :class:`~wannierberri.System`
    """
    if "name" not in parameters:
        parameters["name"] = "ASE"

    parameters, param_needed_data = NeededData.get_parameters(**parameters)
    needed_data = NeededData(**param_needed_data, force_internal_terms_only=True)
    system = System_R(force_internal_terms_only=True, **parameters)
    need_SS = needed_data.need_any('SS')
    f = open(hamdata, "r")
    allread = False
    while not allread:
        line = next(f)
        if line.startswith("end spin:"):
            break
        elif line.startswith("lattice_vectors:"):
            real_lattice_bohr = np.array([next(f).split() for _ in range(3)], dtype=float)
            inv_real_lattice = np.linalg.inv(real_lattice_bohr)
        elif line.startswith("nwan:"):
            system.num_wann = int(next(f))
        elif line.startswith("nspin:"):
            nspin = int(next(f))
            assert nspin == 1, "spin-polarized calculations arte not supported yeet"
        elif line.startswith("have_spin_info:"):
            have_spin = str2bool(next(f))
            if (not have_spin) and system.need_R_any(['SS', 'SHA', 'SR', 'SH', 'SHR', 'SA']):
                raise ValueError("spin info required, but not contained in the file")
        elif line.startswith("wancenters:"):
            wannier_centers_cart_bohr = np.array([next(f).split() for _ in range(system.num_wann)], dtype=float)
        elif line.startswith("wannames:"):
            system.wannier_names = np.array([next(f).strip() for _ in range(system.num_wann)])
        elif line.startswith("spin:"):
            ispin = int(next(f))
            assert ispin == 1, f"spin = 1 expected, got {ispin}"
            Ham_R = defaultdict(lambda: np.zeros((system.num_wann, system.num_wann), dtype=complex))
            if need_SS:
                SS_R = defaultdict(lambda: np.zeros((system.num_wann, system.num_wann, 3), dtype=complex))
            while True:
                line = next(f)
                if line.startswith("end spin:"):
                    allread = True
                    break
                elif line.startswith("Tij, Hij"):
                    iw, jw = [int(x) for x in next(f).split()]
                    iw -= 1
                    jw -= 1
                    arread = []
                    while True:
                        line = next(f)
                        if line.startswith("end Tij, Hij"):
                            break
                        arread.append(line.split())
                    if len(arread) == 0:
                        continue
                    arread = np.array(arread, dtype=float)
                    Rvec_loc = arread[:, :3] + (
                        wannier_centers_cart_bohr[None, iw] - wannier_centers_cart_bohr[None, jw])
                    Rvec_loc = Rvec_loc.dot(inv_real_lattice)  # should be integer now
                    iRvec = np.array(np.round(Rvec_loc), dtype=int)
                    assert (abs(iRvec - Rvec_loc).max() < 1e-8)
                    iRvec = [tuple(ir) for ir in iRvec]
                    for iR, a in zip(iRvec, arread):
                        Ham_R[iR][iw, jw] = a[3] + 1j * a[4]
                        if need_SS:
                            SS_R[iR][iw, jw, :] = a[5:11:2] + 1j * a[6:11:2]
    f.close()
    # Reading of file finished

    system.set_real_lattice(real_lattice_bohr * bohr)
    system.wannier_centers_cart = wannier_centers_cart_bohr * bohr
    iRvec = list(Ham_R.keys())
    system.set_R_mat('Ham', np.array([Ham_R[iR] for iR in iRvec]))
    if need_SS:
        system.set_R_mat('SS', np.array([SS_R[iR] for iR in iRvec]))

    system.rvec = Rvectors(lattice=system.real_lattice, iRvec=iRvec, shifts_left_red=system.wannier_centers_red)

    system.do_at_end_of_init()
    print("FPLO system initialized")
    print(f"wannier_centers_cart: {system.wannier_centers_cart}")
    print(f"wannier_centers_red: {system.wannier_centers_red}")
    if mp_grid is not None:
        system.do_ws_dist(mp_grid=mp_grid)

    cprint(f"Reading the FPLO Wannier system from {hamdata} finished successfully", 'green', attrs=['bold'])
    return system
