"""
Agentbyte - Enterprise-ready agent framework with DDD principles.

Building agents from scratch following Chapter 4 patterns with:
- Async-first architecture
- Event-based streaming
- Clean Architecture (Port/Adapter pattern)
- Domain-Driven Design

Architecture Layers:
- domain/         - Core business logic (entities, value objects, services)
- application/    - Use cases, ports (interfaces)
- infrastructure/ - Adapters, external integrations
"""

from agentbyte.__about__ import VERSION
from agentbyte.agents import Agent
from agentbyte.entity import Entity
from agentbyte.middleware import init_auto_instrumentation_from_env
from agentbyte.notebook import configure_notebook_logging
from agentbyte.messages import (
    AssistantMessage,
    Message,
    SystemMessage,
    ToolMessage,
    UserMessage,
)
from agentbyte.orchestration import (
    AIOrchestrator,
    BaseOrchestrator,
    ExecutionPlan,
    PlanBasedOrchestrator,
    PlanStep,
    RoundRobinOrchestrator,
    StepProgressEvaluation,
)
from agentbyte.presets import (
    build_chat_client,
    get_ai_orchestrator,
    get_orchestrator,
    get_plan_based_orchestrator,
    get_query_rewriter,
    get_researcher,
    get_reviewer,
    get_round_robin_orchestrator,
    get_workflow,
    get_writer,
)
from agentbyte.session import BaseSession, InMemorySession, Session
from agentbyte.termination import (
    BaseTermination,
    CancellationTermination,
    CompositeTermination,
    ExternalTermination,
    FunctionCallTermination,
    HandoffTermination,
    MaxMessageTermination,
    TextMentionTermination,
    TimeoutTermination,
    TokenUsageTermination,
)
from agentbyte.webui import WebUIServer, create_app, serve

# Auto-instrument with OpenTelemetry if enabled.
# Must be set BEFORE importing agentbyte for transparent instrumentation.
try:
    init_auto_instrumentation_from_env()
except Exception:
    # Gracefully continue if instrumentation setup fails.
    pass


__all__ = [
    "VERSION",
    "Agent",
    "Entity",
    "Session",
    "BaseSession",
    "InMemorySession",
    "configure_notebook_logging",
    # Messages
    "Message",
    "UserMessage",
    "SystemMessage",
    "AssistantMessage",
    "ToolMessage",
    # Orchestration
    "AIOrchestrator",
    "BaseOrchestrator",
    "ExecutionPlan",
    "PlanBasedOrchestrator",
    "PlanStep",
    "RoundRobinOrchestrator",
    "StepProgressEvaluation",
    # Presets
    "build_chat_client",
    "get_query_rewriter",
    "get_researcher",
    "get_writer",
    "get_reviewer",
    "get_orchestrator",
    "get_round_robin_orchestrator",
    "get_ai_orchestrator",
    "get_plan_based_orchestrator",
    "get_workflow",
    # Termination
    "BaseTermination",
    "MaxMessageTermination",
    "TextMentionTermination",
    "TokenUsageTermination",
    "TimeoutTermination",
    "FunctionCallTermination",
    "HandoffTermination",
    "ExternalTermination",
    "CancellationTermination",
    "CompositeTermination",
    # WebUI
    "WebUIServer",
    "create_app",
    "serve",
]
