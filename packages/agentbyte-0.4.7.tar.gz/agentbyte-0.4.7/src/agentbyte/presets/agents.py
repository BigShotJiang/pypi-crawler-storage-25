"""Default LLM-only agent builders."""

from __future__ import annotations

from typing import Any

from agentbyte.agents import Agent
from agentbyte.llm import BaseChatCompletionClient

from .clients import build_chat_client


def _resolve_model_client(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
) -> BaseChatCompletionClient:
    if model_client is not None:
        return model_client
    return build_chat_client(provider=provider, model=model, config=config)


def get_query_rewriter(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    name: str = "query_rewriter",
    description: str = "Query rewriter that clarifies and enriches search prompts.",
    example_tasks: list[str] | None = None,
    **kwargs: Any,
) -> Agent:
    """Build the default query rewriter agent."""
    client = _resolve_model_client(
        model_client,
        provider=provider,
        model=model,
        config=config,
    )
    return Agent(
        name=name,
        description=description,
        instructions=(
            "You rewrite user queries to make them clearer and more search-ready.\n"
            "Return:\n"
            "1. A one-sentence clarified intent\n"
            "2. Three to five improved query variations\n"
            "3. One recommended best version\n"
            "Keep the response concise, plain text, and directly usable."
        ),
        model_client=client,
        example_tasks=example_tasks
        or [
            "Rewrite: best laptops for coding and gaming",
            "Rewrite: solar energy benefits article topic",
        ],
        **kwargs,
    )


def get_researcher(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    name: str = "researcher",
    description: str = "Research specialist for concise factual context and key insights.",
    example_tasks: list[str] | None = None,
    **kwargs: Any,
) -> Agent:
    """Build the default researcher agent."""
    client = _resolve_model_client(
        model_client,
        provider=provider,
        model=model,
        config=config,
    )
    return Agent(
        name=name,
        description=description,
        instructions=(
            "You are a researcher.\n"
            "Gather the most relevant factual points from your model knowledge.\n"
            "Be concise, prioritize clarity, and surface assumptions or uncertainty when needed.\n"
            "Do not claim live browsing, verified sources, or quotes you cannot actually support."
        ),
        model_client=client,
        example_tasks=example_tasks
        or [
            "Gather key points about the benefits of solar energy.",
            "Summarize the main advantages of remote work.",
        ],
        **kwargs,
    )


def get_writer(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    name: str = "writer",
    description: str = "Writer who turns available material into clear user-facing prose.",
    example_tasks: list[str] | None = None,
    **kwargs: Any,
) -> Agent:
    """Build the default writer agent."""
    client = _resolve_model_client(
        model_client,
        provider=provider,
        model=model,
        config=config,
    )
    return Agent(
        name=name,
        description=description,
        instructions=(
            "You are a writer.\n"
            "Turn the available material into brief, clear, polished prose for the user.\n"
            "Do not invent facts or sources.\n"
            "When the answer is complete, end your response with the word TERMINATE."
        ),
        model_client=client,
        example_tasks=example_tasks
        or [
            "Write a brief article about solar energy benefits.",
            "Draft a short note on why renewable energy matters.",
        ],
        **kwargs,
    )


def get_reviewer(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    name: str = "reviewer",
    description: str = "Reviewer who checks clarity, completeness, and unsupported claims.",
    example_tasks: list[str] | None = None,
    **kwargs: Any,
) -> Agent:
    """Build the default reviewer agent."""
    client = _resolve_model_client(
        model_client,
        provider=provider,
        model=model,
        config=config,
    )
    return Agent(
        name=name,
        description=description,
        instructions=(
            "You are a reviewer.\n"
            "Check drafts for clarity, completeness, internal consistency, and unsupported claims.\n"
            "If the content needs work, provide brief, actionable feedback.\n"
            "If it is ready, respond with the single word APPROVED."
        ),
        model_client=client,
        example_tasks=example_tasks
        or [
            "Review a short article about solar energy benefits.",
            "Review a note about remote work productivity.",
        ],
        **kwargs,
    )


__all__ = [
    "get_query_rewriter",
    "get_researcher",
    "get_reviewer",
    "get_writer",
]
