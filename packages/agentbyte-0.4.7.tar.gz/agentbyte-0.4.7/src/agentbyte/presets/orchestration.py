"""Default preset orchestrator builders."""

from __future__ import annotations

from typing import Any, Literal

from agentbyte.agents.types import AgentResponse
from agentbyte.llm import BaseChatCompletionClient
from agentbyte.messages import UserMessage
from agentbyte.orchestration import (
    AIOrchestrator,
    PlanStep,
    PlanBasedOrchestrator,
    RoundRobinOrchestrator,
    StepProgressEvaluation,
)
from agentbyte.termination import (
    BaseTermination,
    CompositeTermination,
    MaxMessageTermination,
    TextMentionTermination,
)

from .agents import get_researcher, get_reviewer, get_writer
from .clients import build_chat_client


class ReviewGatedPlanBasedOrchestrator(PlanBasedOrchestrator):
    """Plan-based preset that requires explicit reviewer approval on review steps."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._review_revision_rounds = 0

    async def evaluate_step_progress(
        self, step: PlanStep, result: AgentResponse
    ) -> StepProgressEvaluation:
        agent_output = self._extract_agent_output(result)
        if step.agent_name.casefold().strip() != "reviewer":
            return await super().evaluate_step_progress(step, result)

        if "approved" in agent_output.casefold():
            return StepProgressEvaluation(
                step_completed=True,
                failure_reason="None",
                confidence_score=0.99,
                suggested_improvements=[],
            )

        return StepProgressEvaluation(
            step_completed=False,
            failure_reason=(
                "Reviewer did not explicitly approve the content. "
                "The reviewer must respond with APPROVED when the final draft is ready."
            ),
            confidence_score=0.95,
            suggested_improvements=[
                "Revise the draft using the review feedback.",
                "Ask the reviewer to explicitly confirm readiness with APPROVED once resolved.",
            ],
        )

    async def update_shared_state(self, result: AgentResponse) -> None:
        """Insert writer -> reviewer revision loops when final review is not approved."""
        new_messages = [
            message
            for message in result.messages[self._last_context_size :]
            if not isinstance(message, UserMessage)
        ]
        self.shared_messages.extend(new_messages)

        current_step = self._get_current_step()
        if current_step is None:
            return

        attempts = self.step_attempts.setdefault(self.current_step_index, [])
        attempts.append(result)

        evaluation = await self.evaluate_step_progress(current_step, result)
        if evaluation.step_completed:
            self.step_results[self.current_step_index] = result
            self.retry_instructions.pop(self.current_step_index, None)
            if current_step.agent_name.casefold().strip() == "reviewer":
                self._review_revision_rounds = 0
            self.current_step_index += 1
            self.current_step_retry_count = 0
            return

        if (
            current_step.agent_name.casefold().strip() == "reviewer"
            and self.execution_plan is not None
            and self._review_revision_rounds < self.max_step_retries
        ):
            self._review_revision_rounds += 1
            reviewer_feedback = self._extract_agent_output(result)
            insertion_index = self.current_step_index + 1
            self.execution_plan.steps[insertion_index:insertion_index] = [
                PlanStep(
                    task=(
                        "Revise the draft based on the reviewer feedback below and "
                        "produce an updated final draft:\n\n"
                        f"{reviewer_feedback}"
                    ),
                    agent_name="writer",
                    reasoning="The reviewer requested revisions, so the writer should update the draft.",
                ),
                PlanStep(
                    task=(
                        "Review the revised draft. Respond with APPROVED only if it is ready. "
                        "Otherwise provide concise feedback on what still needs improvement."
                    ),
                    agent_name="reviewer",
                    reasoning="The reviewer is the final approval gate after the revision pass.",
                ),
            ]
            self.current_step_index += 1
            self.current_step_retry_count = self._review_revision_rounds
            return

        self.current_step_retry_count += 1
        if self.current_step_retry_count <= self.max_step_retries:
            self.retry_instructions[self.current_step_index] = (
                self._create_retry_instructions(current_step, evaluation)
            )
            return

        self._failed_step_indices.add(self.current_step_index)
        self.retry_instructions.pop(self.current_step_index, None)
        self.current_step_index += 1
        self.current_step_retry_count = 0

    def _reset_for_run(self) -> None:
        """Reset preset-specific review-loop state."""
        super()._reset_for_run()
        self._review_revision_rounds = 0

    def _generate_final_result(self) -> str:
        """Prefer the latest writer draft over the final reviewer approval message."""
        for message in reversed(self.shared_messages):
            if (
                hasattr(message, "role")
                and message.role == "assistant"
                and getattr(message, "source", "") == "writer"
            ):
                return message.content
        return super()._generate_final_result()


def _resolve_model_client(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
) -> BaseChatCompletionClient:
    if model_client is not None:
        return model_client
    return build_chat_client(provider=provider, model=model, config=config)


def get_round_robin_orchestrator(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    termination: BaseTermination | None = None,
    max_iterations: int = 6,
    name: str = "round_robin_research_writer",
    description: str = "Default round-robin researcher/writer collaboration preset.",
    **kwargs: Any,
) -> RoundRobinOrchestrator:
    """Build the default round-robin orchestrator preset."""
    del kwargs
    client = _resolve_model_client(
        model_client,
        provider=provider,
        model=model,
        config=config,
    )
    orchestrator = RoundRobinOrchestrator(
        agents=[get_researcher(client), get_writer(client)],
        termination=termination
        or CompositeTermination(
            [TextMentionTermination("TERMINATE"), MaxMessageTermination(6)],
            mode="any",
        ),
        max_iterations=max_iterations,
    )
    orchestrator.name = name
    orchestrator.description = description
    orchestrator.example_tasks = [
        "Write a brief article about solar energy benefits.",
        "Create a short note on renewable energy advantages.",
    ]
    return orchestrator


def get_ai_orchestrator(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    termination: BaseTermination | None = None,
    max_iterations: int = 8,
    recent_messages_limit: int = 12,
    name: str = "ai_research_writer_reviewer",
    description: str = "Default AI-driven researcher/writer/reviewer collaboration preset.",
    **kwargs: Any,
) -> AIOrchestrator:
    """Build the default AI-driven orchestrator preset."""
    del kwargs
    client = _resolve_model_client(
        model_client,
        provider=provider,
        model=model,
        config=config,
    )
    orchestrator = AIOrchestrator(
        agents=[get_researcher(client), get_writer(client), get_reviewer(client)],
        termination=termination
        or CompositeTermination(
            [
                TextMentionTermination("APPROVED"),
                TextMentionTermination("TERMINATE"),
                MaxMessageTermination(8),
            ],
            mode="any",
        ),
        model_client=client,
        max_iterations=max_iterations,
        recent_messages_limit=recent_messages_limit,
    )
    orchestrator.name = name
    orchestrator.description = description
    orchestrator.example_tasks = [
        "Write a brief article about solar energy benefits.",
        "Draft a concise note on remote work benefits.",
    ]
    return orchestrator


def get_plan_based_orchestrator(
    model_client: BaseChatCompletionClient | None = None,
    *,
    provider: str | None = None,
    model: str | None = None,
    config: dict[str, Any] | None = None,
    termination: BaseTermination | None = None,
    max_iterations: int = 8,
    max_step_retries: int = 2,
    recent_messages_limit: int = 5,
    name: str = "plan_based_research_writer_reviewer",
    description: str = "Default plan-based researcher/writer/reviewer collaboration preset.",
    **kwargs: Any,
) -> PlanBasedOrchestrator:
    """Build the default plan-based orchestrator preset."""
    del kwargs
    client = _resolve_model_client(
        model_client,
        provider=provider,
        model=model,
        config=config,
    )
    orchestrator = ReviewGatedPlanBasedOrchestrator(
        agents=[get_researcher(client), get_writer(client), get_reviewer(client)],
        termination=termination or MaxMessageTermination(8),
        model_client=client,
        max_iterations=max_iterations,
        max_step_retries=max_step_retries,
        recent_messages_limit=recent_messages_limit,
    )
    orchestrator.name = name
    orchestrator.description = description
    orchestrator.example_tasks = [
        "Research, write, and review a short article about solar energy benefits."
    ]
    return orchestrator


def get_orchestrator(
    pattern: Literal["round_robin", "ai", "plan_based"] = "ai",
    model_client: BaseChatCompletionClient | None = None,
    **kwargs: Any,
) -> RoundRobinOrchestrator | AIOrchestrator | PlanBasedOrchestrator:
    """Build one of the default orchestrator presets."""
    if pattern == "round_robin":
        return get_round_robin_orchestrator(model_client=model_client, **kwargs)
    if pattern == "ai":
        return get_ai_orchestrator(model_client=model_client, **kwargs)
    if pattern == "plan_based":
        return get_plan_based_orchestrator(model_client=model_client, **kwargs)
    raise ValueError(
        "Unsupported orchestrator pattern. Expected 'round_robin', 'ai', or 'plan_based'."
    )


__all__ = [
    "get_ai_orchestrator",
    "get_orchestrator",
    "get_plan_based_orchestrator",
    "get_round_robin_orchestrator",
]
