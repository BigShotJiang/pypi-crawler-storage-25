"""Workflow runner with streaming events and bounded parallel execution."""

from __future__ import annotations

import asyncio
import os
from contextlib import contextmanager
from datetime import datetime
from typing import Any, AsyncGenerator

from agentbyte.cancellation_token import CancellationToken
from agentbyte.workflow.core.checkpoint import (
    CheckpointConfig,
    CheckpointValidationResult,
    WorkflowCheckpoint,
)
from agentbyte.workflow.core.models import (
    CheckpointSavedEvent,
    Context,
    EdgeActivatedEvent,
    StepCompletedEvent,
    StepExecution,
    StepFailedEvent,
    StepProgressEvent,
    StepStartedEvent,
    StepStatus,
    WorkflowCancelledEvent,
    WorkflowCompletedEvent,
    WorkflowCompletionMode,
    WorkflowEvent,
    WorkflowExecution,
    WorkflowFailedEvent,
    WorkflowResumedEvent,
    WorkflowStartedEvent,
    WorkflowStatus,
)
from agentbyte.workflow.core.workflow import Workflow
from agentbyte.workflow.steps.step import BaseStep


class WorkflowRunner:
    """Executes workflows with dependency resolution and bounded concurrency."""

    def __init__(self, max_concurrent_steps: int = 5) -> None:
        self.max_concurrent_steps = max_concurrent_steps
        self._execution_semaphore = asyncio.Semaphore(max_concurrent_steps)
        self._cancellation_tokens: dict[str, CancellationToken] = {}

    async def run(
        self,
        workflow: Workflow,
        initial_input: dict[str, Any] | None = None,
        cancellation_token: CancellationToken | None = None,
        checkpoint: WorkflowCheckpoint | None = None,
        checkpoint_config: CheckpointConfig | None = None,
    ) -> WorkflowExecution:
        """Run a workflow to completion and return the final execution state."""

        final_execution: WorkflowExecution | None = None
        async for event in self.run_stream(
            workflow,
            initial_input,
            cancellation_token,
            checkpoint,
            checkpoint_config,
        ):
            if isinstance(event, WorkflowCompletedEvent):
                final_execution = event.execution
            elif isinstance(event, WorkflowFailedEvent):
                final_execution = event.execution
                raise RuntimeError(event.error)
            elif isinstance(event, WorkflowCancelledEvent):
                final_execution = event.execution
                raise RuntimeError(event.reason)

        if final_execution is None:
            msg = "Workflow finished without a terminal execution state"
            raise RuntimeError(msg)
        return final_execution

    async def run_stream(
        self,
        workflow: Workflow,
        initial_input: dict[str, Any] | None = None,
        cancellation_token: CancellationToken | None = None,
        checkpoint: WorkflowCheckpoint | None = None,
        checkpoint_config: CheckpointConfig | None = None,
    ) -> AsyncGenerator[WorkflowEvent, None]:
        """Run a workflow and yield structured events in real time."""

        workflow_id = self._get_workflow_id(workflow)
        payload = initial_input.copy() if initial_input else {}

        if cancellation_token is not None:
            self._cancellation_tokens[workflow_id] = cancellation_token

        execution: WorkflowExecution | None = None

        with self._start_workflow_span(
            workflow=workflow,
            workflow_id=workflow_id,
            initial_input=payload,
            is_resume=checkpoint is not None,
        ) as workflow_span:
            try:
                if checkpoint is not None:
                    validation = self.validate_checkpoint(workflow, checkpoint)
                    if not validation.can_resume:
                        self._mark_span_error(
                            workflow_span,
                            f"Checkpoint validation failed: {validation.errors}",
                        )
                        yield WorkflowFailedEvent(
                            timestamp=datetime.now(),
                            workflow_id=workflow_id,
                            error=f"Checkpoint validation failed: {validation.errors}",
                        )
                        return
                    execution = checkpoint.execution.model_copy(deep=True)
                    execution.status = WorkflowStatus.RUNNING
                    yield WorkflowResumedEvent(
                        timestamp=datetime.now(),
                        workflow_id=workflow_id,
                        checkpoint_id=checkpoint.checkpoint_id,
                        completed_steps=list(checkpoint.completed_step_ids),
                        pending_steps=list(checkpoint.pending_step_ids),
                    )
                else:
                    yield WorkflowStartedEvent(
                        timestamp=datetime.now(),
                        workflow_id=workflow_id,
                        initial_input=payload,
                    )

                    validation = workflow.validate_workflow()
                    if not validation.is_valid:
                        self._mark_span_error(
                            workflow_span,
                            f"Workflow validation failed: {validation.errors}",
                        )
                        yield WorkflowFailedEvent(
                            timestamp=datetime.now(),
                            workflow_id=workflow_id,
                            error=f"Workflow validation failed: {validation.errors}",
                        )
                        return

                    if workflow.start_step_id:
                        start_step = workflow.steps[workflow.start_step_id]
                        try:
                            start_step.input_type(**payload)
                        except Exception as exc:
                            self._mark_span_error(
                                workflow_span,
                                (
                                    "Initial input validation failed for start step "
                                    f"'{workflow.start_step_id}': {exc}"
                                ),
                            )
                            yield WorkflowFailedEvent(
                                timestamp=datetime.now(),
                                workflow_id=workflow_id,
                                error=(
                                    "Initial input validation failed for start step "
                                    f"'{workflow.start_step_id}': {exc}"
                                ),
                            )
                            return

                    execution = WorkflowExecution(
                        workflow_id=workflow_id,
                        status=WorkflowStatus.RUNNING,
                        start_time=datetime.now(),
                        state=workflow.config.initial_state.copy(),
                    )
                    execution.state.update(payload)

                async for event in self._execute_workflow_stream(
                    workflow=workflow,
                    execution=execution,
                    initial_input=payload,
                    checkpoint_config=checkpoint_config,
                ):
                    yield event

                if execution.status == WorkflowStatus.CANCELLED:
                    self._mark_span_cancelled(workflow_span)
                    return

                execution.status = WorkflowStatus.COMPLETED
                execution.end_time = datetime.now()
                self._mark_workflow_span_success(workflow_span, workflow, execution)
                yield WorkflowCompletedEvent(
                    timestamp=datetime.now(),
                    workflow_id=workflow_id,
                    execution=execution,
                )
            except Exception as exc:
                if execution is not None:
                    execution.status = WorkflowStatus.FAILED
                    execution.error = str(exc)
                    execution.end_time = datetime.now()
                self._mark_span_error(workflow_span, exc)
                yield WorkflowFailedEvent(
                    timestamp=datetime.now(),
                    workflow_id=workflow_id,
                    error=str(exc),
                    execution=execution,
                )
            finally:
                self._cancellation_tokens.pop(workflow_id, None)

    async def _execute_workflow_stream(
        self,
        workflow: Workflow,
        execution: WorkflowExecution,
        initial_input: dict[str, Any],
        checkpoint_config: CheckpointConfig | None = None,
    ) -> AsyncGenerator[WorkflowEvent, None]:
        completed_steps: set[str] = {
            step_id
            for step_id, step_execution in execution.step_executions.items()
            if step_execution.status == StepStatus.COMPLETED
        }
        running_tasks: dict[str, asyncio.Task[dict[str, Any]]] = {}
        progress_queue: asyncio.Queue[tuple[str, dict[str, Any]]] = asyncio.Queue()
        workflow_id = self._get_workflow_id(workflow)
        steps_since_last_checkpoint = 0

        while True:
            cancellation_token = self._cancellation_tokens.get(workflow_id)

            if cancellation_token and cancellation_token.is_cancelled() and not running_tasks:
                execution.status = WorkflowStatus.CANCELLED
                execution.end_time = datetime.now()
                yield WorkflowCancelledEvent(
                    timestamp=datetime.now(),
                    workflow_id=workflow_id,
                    execution=execution,
                    reason="Cancelled by user",
                )
                return

            if workflow.end_step_ids:
                if workflow.config.completion_mode == WorkflowCompletionMode.ALL_END:
                    if all(step_id in completed_steps for step_id in workflow.end_step_ids):
                        break
                else:  # ANY_END (default)
                    if any(step_id in completed_steps for step_id in workflow.end_step_ids):
                        break
            if len(completed_steps) == len(workflow.steps):
                break

            ready_steps = [
                step
                for step in workflow.get_ready_steps(execution)
                if step.step_id not in completed_steps and step.step_id not in running_tasks
            ]

            if not (cancellation_token and cancellation_token.is_cancelled()):
                available_slots = max(0, self.max_concurrent_steps - len(running_tasks))
                for step in ready_steps[:available_slots]:
                    step_id = step.step_id
                    input_data = self._prepare_step_input(
                        step_id=step_id,
                        workflow=workflow,
                        execution=execution,
                        initial_input=initial_input,
                    )

                    execution.step_executions[step_id] = StepExecution(
                        step_id=step_id,
                        status=StepStatus.RUNNING,
                        start_time=datetime.now(),
                        input_data=input_data,
                    )
                    yield StepStartedEvent(
                        timestamp=datetime.now(),
                        workflow_id=workflow_id,
                        step_id=step_id,
                        input_data=input_data,
                    )

                    task = asyncio.create_task(
                        self._run_step_with_semaphore(
                            workflow=workflow,
                            step=step,
                            input_data=input_data,
                            workflow_state=execution.state,
                            progress_queue=progress_queue,
                        )
                    )
                    if cancellation_token is not None:
                        cancellation_token.link_future(task)
                    running_tasks[step_id] = task

            if not ready_steps and not running_tasks:
                remaining_steps = set(workflow.steps) - completed_steps
                if remaining_steps:
                    msg = (
                        "Workflow stuck: remaining steps "
                        f"{sorted(remaining_steps)} cannot be executed"
                    )
                    raise RuntimeError(msg)
                break

            if not running_tasks:
                continue

            done, _ = await asyncio.wait(
                running_tasks.values(),
                return_when=asyncio.FIRST_COMPLETED,
                timeout=0.01,
            )

            while not progress_queue.empty():
                step_id, progress_data = progress_queue.get_nowait()
                yield StepProgressEvent(
                    timestamp=datetime.now(),
                    workflow_id=workflow_id,
                    step_id=step_id,
                    message=progress_data["message"],
                    completed=progress_data.get("completed"),
                    total=progress_data.get("total"),
                    metadata=progress_data.get("metadata", {}),
                )

            if not done:
                continue

            for task in done:
                step_id = next(
                    sid for sid, running_task in running_tasks.items() if running_task is task
                )
                step_execution = execution.step_executions[step_id]

                try:
                    result = await task
                    step_execution.status = StepStatus.COMPLETED
                    step_execution.output_data = result
                    step_execution.end_time = datetime.now()
                    execution.state[f"{step_id}_output"] = result
                    completed_steps.add(step_id)
                    steps_since_last_checkpoint += 1

                    yield StepCompletedEvent(
                        timestamp=datetime.now(),
                        workflow_id=workflow_id,
                        step_id=step_id,
                        output_data=result,
                        duration_seconds=self._duration_seconds(step_execution),
                    )

                    for edge in workflow.edges:
                        if edge.from_step != step_id:
                            continue
                        if workflow._evaluate_edge_condition(edge, execution):
                            yield EdgeActivatedEvent(
                                timestamp=datetime.now(),
                                workflow_id=workflow_id,
                                from_step=step_id,
                                to_step=edge.to_step,
                                data=result,
                            )

                    if (
                        checkpoint_config is not None
                        and checkpoint_config.auto_save
                        and steps_since_last_checkpoint >= checkpoint_config.save_interval_steps
                    ):
                        checkpoint_obj = self._create_checkpoint(
                            workflow=workflow,
                            execution=execution,
                            checkpoint_type="auto",
                        )
                        await checkpoint_config.store.save(checkpoint_obj)
                        yield CheckpointSavedEvent(
                            timestamp=datetime.now(),
                            workflow_id=workflow_id,
                            checkpoint_id=checkpoint_obj.checkpoint_id,
                            completed_steps=len(completed_steps),
                            total_steps=len(workflow.steps),
                        )
                        if checkpoint_config.auto_cleanup:
                            await checkpoint_config.store.cleanup_old(
                                workflow_id=workflow_id,
                                keep_last_n=checkpoint_config.keep_last_n,
                            )
                        steps_since_last_checkpoint = 0
                except asyncio.CancelledError:
                    step_execution.status = StepStatus.CANCELLED
                    step_execution.end_time = datetime.now()
                    step_execution.error = "Step was cancelled"
                    yield StepFailedEvent(
                        timestamp=datetime.now(),
                        workflow_id=workflow_id,
                        step_id=step_id,
                        error="Step was cancelled",
                        duration_seconds=self._duration_seconds(step_execution),
                    )
                except Exception as exc:
                    step_execution.status = StepStatus.FAILED
                    step_execution.end_time = datetime.now()
                    step_execution.error = str(exc)
                    yield StepFailedEvent(
                        timestamp=datetime.now(),
                        workflow_id=workflow_id,
                        step_id=step_id,
                        error=str(exc),
                        duration_seconds=self._duration_seconds(step_execution),
                    )
                    # Tolerate branch failure when ALL downstream join steps are SKIP_FAILED
                    downstream_ids = [
                        edge.to_step for edge in workflow.edges if edge.from_step == step_id
                    ]
                    if downstream_ids and all(
                        workflow.is_step_failure_tolerated(dsid) for dsid in downstream_ids
                    ):
                        step_execution.status = StepStatus.FAILED_TOLERATED
                        completed_steps.add(step_id)
                    else:
                        raise
                finally:
                    del running_tasks[step_id]

    async def _run_step_with_semaphore(
        self,
        workflow: Workflow,
        step: BaseStep[Any, Any],
        input_data: dict[str, Any],
        workflow_state: dict[str, Any],
        progress_queue: asyncio.Queue[tuple[str, dict[str, Any]]],
    ) -> dict[str, Any]:
        async with self._execution_semaphore:
            context = Context.from_state_ref(workflow_state)

            def progress_callback(progress_data: dict[str, Any]) -> None:
                progress_queue.put_nowait((step.step_id, progress_data))

            context._progress_callback = progress_callback
            with self._start_step_span(workflow, step, input_data) as step_span:
                try:
                    result = await step.run(input_data, context)
                    self._mark_step_span_success(step_span, step, result)
                    return result
                except asyncio.CancelledError:
                    self._mark_span_cancelled(step_span)
                    raise
                except Exception as exc:
                    self._mark_span_error(step_span, exc)
                    raise

    def _prepare_step_input(
        self,
        step_id: str,
        workflow: Workflow,
        execution: WorkflowExecution,
        initial_input: dict[str, Any],
    ) -> dict[str, Any]:
        if step_id == workflow.start_step_id:
            return initial_input.copy()

        dependencies = workflow.get_step_dependencies(step_id)

        # Identify always-edge dependencies (these form the fan-in set)
        always_dep_ids = [
            dep for dep in dependencies
            if any(
                edge.from_step == dep and edge.to_step == step_id and edge.condition.type == "always"
                for edge in workflow.edges
            )
        ]

        # Fan-in: ≥2 always-edge dependencies → collect all branch outputs into an envelope
        if len(always_dep_ids) >= 2:
            branch_outputs: dict[str, dict[str, Any]] = {}
            failed_branches: list[str] = []
            for dep_id in always_dep_ids:
                dep_exec = execution.step_executions.get(dep_id)
                if (
                    dep_exec is not None
                    and dep_exec.status == StepStatus.COMPLETED
                    and dep_exec.output_data is not None
                ):
                    branch_outputs[dep_id] = dep_exec.output_data.copy()
                else:
                    failed_branches.append(dep_id)
            return {"branch_outputs": branch_outputs, "failed_branches": failed_branches}

        # Single dependency: pass through the upstream output directly (original behaviour)
        for dependency_id in dependencies:
            dependency_execution = execution.step_executions.get(dependency_id)
            if (
                dependency_execution is not None
                and dependency_execution.status == StepStatus.COMPLETED
                and dependency_execution.output_data is not None
            ):
                return dependency_execution.output_data.copy()

        return initial_input.copy()

    def cancel_workflow(self, workflow_id: str) -> bool:
        """Cancel an in-flight workflow execution if one is registered."""

        cancellation_token = self._cancellation_tokens.get(workflow_id)
        if cancellation_token is None:
            return False
        cancellation_token.cancel()
        return True

    @staticmethod
    def _get_workflow_id(workflow: Workflow) -> str:
        return workflow.id

    @staticmethod
    def _duration_seconds(step_execution: StepExecution) -> float:
        if step_execution.start_time and step_execution.end_time:
            return (step_execution.end_time - step_execution.start_time).total_seconds()
        return 0.0

    def validate_checkpoint(
        self,
        workflow: Workflow,
        checkpoint: WorkflowCheckpoint,
    ) -> CheckpointValidationResult:
        """Validate checkpoint compatibility before resume."""

        errors: list[str] = []
        workflow_id = self._get_workflow_id(workflow)
        if checkpoint.workflow_id != workflow_id:
            errors.append(
                f"Checkpoint workflow_id '{checkpoint.workflow_id}' does not match '{workflow_id}'"
            )
        if checkpoint.workflow_structure_hash != workflow.compute_structure_hash():
            errors.append("Workflow structure changed since checkpoint was created")

        return CheckpointValidationResult(
            is_valid=not errors,
            errors=errors,
            can_resume=not errors,
            checkpoint_info={
                "checkpoint_id": checkpoint.checkpoint_id,
                "completed_steps": len(checkpoint.completed_step_ids),
                "pending_steps": len(checkpoint.pending_step_ids),
                "workflow_version": checkpoint.workflow_version,
            },
        )

    def _create_checkpoint(
        self,
        workflow: Workflow,
        execution: WorkflowExecution,
        checkpoint_type: str = "manual",
    ) -> WorkflowCheckpoint:
        version = str(workflow.config.metadata.get("version", "1.0.0"))
        return WorkflowCheckpoint.from_execution(
            execution=execution,
            workflow_id=self._get_workflow_id(workflow),
            workflow_version=version,
            workflow_structure_hash=workflow.compute_structure_hash(),
            all_step_ids=list(workflow.steps.keys()),
            checkpoint_type=checkpoint_type,
        )

    @staticmethod
    def _otel_enabled() -> bool:
        return os.getenv("AGENTBYTE_ENABLE_OTEL", "false").lower() in ("true", "1", "yes")

    @contextmanager
    def _start_workflow_span(
        self,
        workflow: Workflow,
        workflow_id: str,
        initial_input: dict[str, Any],
        is_resume: bool,
    ) -> Any:
        if not self._otel_enabled():
            yield None
            return

        try:
            from opentelemetry import trace

            tracer = trace.get_tracer("agentbyte.workflow")
            with tracer.start_as_current_span(f"workflow {workflow.config.name}") as span:
                span.set_attribute("agentbyte.workflow.id", workflow_id)
                span.set_attribute("agentbyte.workflow.name", workflow.config.name)
                span.set_attribute("agentbyte.workflow.step_count", len(workflow.steps))
                span.set_attribute("agentbyte.workflow.edge_count", len(workflow.edges))
                span.set_attribute("agentbyte.workflow.end_step_count", len(workflow.end_step_ids))
                span.set_attribute("agentbyte.workflow.resumed", is_resume)
                span.set_attribute("agentbyte.workflow.run_mode", "stream")
                span.set_attribute(
                    "agentbyte.workflow.input_keys",
                    ",".join(sorted(initial_input.keys())),
                )
                yield span
        except Exception:
            yield None

    @contextmanager
    def _start_step_span(
        self,
        workflow: Workflow,
        step: BaseStep[Any, Any],
        input_data: dict[str, Any],
    ) -> Any:
        if not self._otel_enabled():
            yield None
            return

        try:
            from opentelemetry import trace

            tracer = trace.get_tracer("agentbyte.workflow")
            with tracer.start_as_current_span(f"workflow step {step.step_id}") as span:
                span.set_attribute("agentbyte.workflow.id", self._get_workflow_id(workflow))
                span.set_attribute("agentbyte.workflow.name", workflow.config.name)
                span.set_attribute("agentbyte.workflow.step.id", step.step_id)
                span.set_attribute(
                    "agentbyte.workflow.step.name",
                    step.metadata.name,
                )
                span.set_attribute(
                    "agentbyte.workflow.step.type",
                    step.__class__.__name__,
                )
                span.set_attribute(
                    "agentbyte.workflow.step.input_keys",
                    ",".join(sorted(input_data.keys())),
                )
                yield span
        except Exception:
            yield None

    @staticmethod
    def _mark_span_error(span: Any, error: Any) -> None:
        if span is None:
            return

        span.set_attribute("agentbyte.workflow.status", "failed")
        span.set_attribute("agentbyte.workflow.error", str(error))

        try:
            from opentelemetry.trace import Status, StatusCode

            if isinstance(error, Exception):
                span.record_exception(error)
            span.set_status(Status(StatusCode.ERROR, str(error)))
        except Exception:
            return

    @staticmethod
    def _mark_span_cancelled(span: Any) -> None:
        if span is None:
            return

        span.set_attribute("agentbyte.workflow.status", "cancelled")

    @staticmethod
    def _mark_workflow_span_success(
        span: Any,
        workflow: Workflow,
        execution: WorkflowExecution,
    ) -> None:
        if span is None:
            return

        span.set_attribute("agentbyte.workflow.status", execution.status.value)
        span.set_attribute(
            "agentbyte.workflow.completed_steps",
            len(
                [
                    step_execution
                    for step_execution in execution.step_executions.values()
                    if step_execution.status == StepStatus.COMPLETED
                ]
            ),
        )
        span.set_attribute("agentbyte.workflow.total_steps", len(workflow.steps))

        try:
            from opentelemetry.trace import Status, StatusCode

            span.set_status(Status(StatusCode.OK))
        except Exception:
            return

    @staticmethod
    def _mark_step_span_success(
        span: Any,
        step: BaseStep[Any, Any],
        result: dict[str, Any],
    ) -> None:
        if span is None:
            return

        span.set_attribute("agentbyte.workflow.step.status", "completed")
        span.set_attribute(
            "agentbyte.workflow.step.output_keys",
            ",".join(sorted(result.keys())),
        )
        span.set_attribute(
            "agentbyte.workflow.step.type",
            step.__class__.__name__,
        )

        try:
            from opentelemetry.trace import Status, StatusCode

            span.set_status(Status(StatusCode.OK))
        except Exception:
            return


__all__ = ["WorkflowRunner"]