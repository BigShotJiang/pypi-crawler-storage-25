"""Core data models for Agentbyte workflows."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Callable
from typing import TypeVar
from uuid import uuid4

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field

InputType = TypeVar("InputType", bound=BaseModel)
OutputType = TypeVar("OutputType", bound=BaseModel)


class WorkflowCompletionMode(str, Enum):
    """Controls when a workflow is considered complete."""

    ANY_END = "any_end"   # Stop as soon as ANY declared end step finishes (default)
    ALL_END = "all_end"   # Wait until ALL declared end steps have finished


class JoinFailureMode(str, Enum):
    """Controls how a fan-in (join) step handles upstream branch failures."""

    FAIL_FAST = "fail_fast"       # Re-raise immediately on any branch failure (default)
    SKIP_FAILED = "skip_failed"   # Tolerate partial failures; pass failed branch IDs in envelope


class StepStatus(str, Enum):
    """Status of a step in workflow execution."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    FAILED_TOLERATED = "failed_tolerated"  # failed but downstream join step has SKIP_FAILED mode
    SKIPPED = "skipped"
    CANCELLED = "cancelled"


class WorkflowStatus(str, Enum):
    """Status of workflow execution."""

    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class EdgeCondition(BaseModel):
    """Defines conditions for workflow edges."""

    type: str = Field(
        default="always",
        description="Type of condition: always, output_based, state_based",
    )
    expression: str | None = Field(
        default=None,
        description="Python expression to evaluate",
    )
    field: str | None = Field(
        default=None,
        description="Field to check in output or state",
    )
    value: Any | None = Field(default=None, description="Expected value")
    operator: str | None = Field(
        default=None,
        description="Comparison operator: ==, !=, >, <, in, etc.",
    )


class Edge(BaseModel):
    """Represents a connection between workflow steps."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    from_step: str = Field(description="Source step ID")
    to_step: str = Field(description="Target step ID")
    condition: EdgeCondition = Field(default_factory=EdgeCondition)

    model_config = ConfigDict(extra="forbid")


class StepExecution(BaseModel):
    """Tracks execution details of a step."""

    step_id: str
    status: StepStatus = StepStatus.PENDING
    start_time: datetime | None = None
    end_time: datetime | None = None
    input_data: dict[str, Any] | None = None
    output_data: dict[str, Any] | None = None
    error: str | None = None
    retry_count: int = 0

    model_config = ConfigDict(extra="forbid")


class WorkflowExecution(BaseModel):
    """Tracks execution of an entire workflow."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    workflow_id: str
    status: WorkflowStatus = WorkflowStatus.CREATED
    start_time: datetime | None = None
    end_time: datetime | None = None
    state: dict[str, Any] = Field(default_factory=dict)
    step_executions: dict[str, StepExecution] = Field(default_factory=dict)
    error: str | None = None

    model_config = ConfigDict(extra="forbid")


class StepMetadata(BaseModel):
    """Metadata for workflow steps."""

    name: str
    description: str | None = None
    tags: list[str] = Field(default_factory=list)
    max_retries: int = 0
    timeout_seconds: float | None = None
    join_failure_mode: JoinFailureMode = JoinFailureMode.FAIL_FAST

    model_config = ConfigDict(extra="forbid")


class WorkflowMetadata(BaseModel):
    """Metadata for workflows."""

    name: str
    description: str | None = None
    version: str = "1.0.0"
    tags: list[str] = Field(default_factory=list)
    author: str | None = None
    created_at: datetime = Field(default_factory=datetime.now)

    model_config = ConfigDict(extra="forbid")


class Context(BaseModel):
    """Simple typed context for workflow steps."""

    state: dict[str, Any] = Field(
        default_factory=dict,
        description="Shared mutable workflow state",
    )
    _progress_callback: Callable[[dict[str, Any]], None] | None = None

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    @classmethod
    def from_state_ref(cls, state_dict: dict[str, Any]) -> Context:
        """Create context with direct reference to state dict (no copy)."""
        instance = cls(state={})
        instance.__dict__["state"] = state_dict
        return instance

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from workflow state."""
        return self.state.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set a value in workflow state."""
        self.state[key] = value

    def update(self, updates: dict[str, Any]) -> None:
        """Update multiple values in workflow state."""
        self.state.update(updates)

    def emit_progress(
        self,
        message: str,
        completed: int | None = None,
        total: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Emit a progress update from within a workflow step."""
        if self._progress_callback:
            progress_data = {
                "message": message,
                "completed": completed,
                "total": total,
                "metadata": metadata or {},
            }
            self._progress_callback(progress_data)

    def to_dict(self) -> dict[str, Any]:
        """Convert context to dictionary."""
        return {
            "workflow_state": self.state,
            **self.state,
        }


class WorkflowValidationResult(BaseModel):
    """Result of workflow validation."""

    is_valid: bool
    errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    has_cycles: bool = False
    unreachable_steps: list[str] = Field(default_factory=list)

    model_config = ConfigDict(extra="forbid")


class WorkflowEventType(str, Enum):
    """Types of workflow events."""

    WORKFLOW_STARTED = "workflow_started"
    WORKFLOW_COMPLETED = "workflow_completed"
    WORKFLOW_FAILED = "workflow_failed"
    WORKFLOW_CANCELLED = "workflow_cancelled"
    WORKFLOW_RESUMED = "workflow_resumed"
    CHECKPOINT_SAVED = "checkpoint_saved"
    STEP_STARTED = "step_started"
    STEP_COMPLETED = "step_completed"
    STEP_FAILED = "step_failed"
    STEP_PROGRESS = "step_progress"
    EDGE_ACTIVATED = "edge_activated"


class WorkflowEvent(BaseModel):
    """Base class for workflow events."""

    event_type: WorkflowEventType
    timestamp: datetime
    workflow_id: str

    model_config = ConfigDict(extra="forbid")

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        return f"[{time_str}] {self.event_type.value}"

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return (
            f"{class_name}(event_type='{self.event_type.value}', "
            f"workflow_id='{self.workflow_id[:8]}...', "
            f"timestamp='{self.timestamp}')"
        )


class WorkflowStartedEvent(WorkflowEvent):
    """Workflow execution started."""

    event_type: WorkflowEventType = WorkflowEventType.WORKFLOW_STARTED
    initial_input: dict[str, Any]

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        return f"[{time_str}] 🚀 Workflow started with input: {self.initial_input}"


class WorkflowCompletedEvent(WorkflowEvent):
    """Workflow execution completed successfully."""

    event_type: WorkflowEventType = WorkflowEventType.WORKFLOW_COMPLETED
    execution: WorkflowExecution

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        duration = None
        if self.execution.start_time and self.execution.end_time:
            duration = (
                self.execution.end_time - self.execution.start_time
            ).total_seconds()
        duration_str = f" in {duration:.2f}s" if duration else ""
        return (
            f"[{time_str}] ✅ Workflow completed{duration_str} "
            f"({len(self.execution.step_executions)} steps)"
        )


class WorkflowFailedEvent(WorkflowEvent):
    """Workflow execution failed."""

    event_type: WorkflowEventType = WorkflowEventType.WORKFLOW_FAILED
    error: str
    execution: WorkflowExecution | None = None


class WorkflowCancelledEvent(WorkflowEvent):
    """Workflow execution was cancelled."""

    event_type: WorkflowEventType = WorkflowEventType.WORKFLOW_CANCELLED
    execution: WorkflowExecution
    reason: str


class WorkflowResumedEvent(WorkflowEvent):
    """Workflow resumed from checkpoint."""

    event_type: WorkflowEventType = WorkflowEventType.WORKFLOW_RESUMED
    checkpoint_id: str
    completed_steps: list[str]
    pending_steps: list[str]

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        return (
            f"[{time_str}] 🔄 Resumed from checkpoint "
            f"({len(self.completed_steps)} completed, "
            f"{len(self.pending_steps)} pending)"
        )


class CheckpointSavedEvent(WorkflowEvent):
    """Checkpoint saved during execution."""

    event_type: WorkflowEventType = WorkflowEventType.CHECKPOINT_SAVED
    checkpoint_id: str
    completed_steps: int
    total_steps: int

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        progress = (
            (self.completed_steps / self.total_steps * 100)
            if self.total_steps > 0
            else 0
        )
        return (
            f"[{time_str}] 💾 Checkpoint saved "
            f"({self.completed_steps}/{self.total_steps} steps, {progress:.0f}%)"
        )


class StepStartedEvent(WorkflowEvent):
    """Step execution started."""

    event_type: WorkflowEventType = WorkflowEventType.STEP_STARTED
    step_id: str
    input_data: dict[str, Any]

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        return f"[{time_str}] ▶️  Step '{self.step_id}' started"


class StepCompletedEvent(WorkflowEvent):
    """Step execution completed successfully."""

    event_type: WorkflowEventType = WorkflowEventType.STEP_COMPLETED
    step_id: str
    output_data: dict[str, Any]
    duration_seconds: float

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        return f"[{time_str}] ✅ Step '{self.step_id}' completed → {self.output_data}"


class StepFailedEvent(WorkflowEvent):
    """Step execution failed."""

    event_type: WorkflowEventType = WorkflowEventType.STEP_FAILED
    step_id: str
    error: str
    duration_seconds: float

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        return f"[{time_str}] ❌ Step '{self.step_id}' failed: {self.error}"


class StepProgressEvent(WorkflowEvent):
    """Progress update from within a step execution."""

    event_type: WorkflowEventType = WorkflowEventType.STEP_PROGRESS
    step_id: str
    message: str
    completed: int | None = None
    total: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        progress_str = ""
        if self.completed is not None and self.total is not None:
            percentage = (self.completed / self.total * 100) if self.total > 0 else 0
            progress_str = f" ({self.completed}/{self.total}, {percentage:.0f}%)"
        return f"[{time_str}] 🔄 Step '{self.step_id}': {self.message}{progress_str}"


class EdgeActivatedEvent(WorkflowEvent):
    """Edge between steps activated (data flowing)."""

    event_type: WorkflowEventType = WorkflowEventType.EDGE_ACTIVATED
    from_step: str
    to_step: str
    data: dict[str, Any]

    def __str__(self) -> str:
        time_str = self.timestamp.strftime("%H:%M:%S")
        return f"[{time_str}] 🔗 {self.from_step} → {self.to_step}"


__all__ = [
    "InputType",
    "OutputType",
    "WorkflowCompletionMode",
    "JoinFailureMode",
    "StepStatus",
    "WorkflowStatus",
    "EdgeCondition",
    "Edge",
    "StepExecution",
    "WorkflowExecution",
    "StepMetadata",
    "WorkflowMetadata",
    "Context",
    "WorkflowValidationResult",
    "WorkflowEventType",
    "WorkflowEvent",
    "WorkflowStartedEvent",
    "WorkflowCompletedEvent",
    "WorkflowFailedEvent",
    "WorkflowCancelledEvent",
    "WorkflowResumedEvent",
    "CheckpointSavedEvent",
    "StepStartedEvent",
    "StepCompletedEvent",
    "StepFailedEvent",
    "StepProgressEvent",
    "EdgeActivatedEvent",
]
