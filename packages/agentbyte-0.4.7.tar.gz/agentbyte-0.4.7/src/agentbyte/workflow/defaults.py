"""Default workflow and step factories for quick-start examples."""

from __future__ import annotations

from agentbyte.agents import BaseAgent
from agentbyte.workflow.core.models import EdgeCondition, StepMetadata
from agentbyte.workflow.core.workflow import Workflow, WorkflowConfig
from agentbyte.workflow.steps import AgentbyteAgentStep, EchoStep, HttpStep
from agentbyte.workflow.steps.echo import EchoOutput


def create_echo_chain_workflow(name: str = "echo_chain") -> Workflow:
    """Create a simple two-step echo pipeline."""

    first = EchoStep(step_id="echo_in", metadata=StepMetadata(name="echo_in"))
    second = EchoStep(
        step_id="echo_out",
        metadata=StepMetadata(name="echo_out"),
        input_type=EchoOutput,
        output_type=EchoOutput,
        suffix="!",
    )
    return Workflow(WorkflowConfig(name=name)).chain(first, second)


def create_simple_agent_workflow(agent: BaseAgent, name: str = "simple_agent") -> Workflow:
    """Wrap a single Agentbyte agent as a one-step workflow."""

    workflow = Workflow(WorkflowConfig(name=name))
    workflow.set_start_step(
        AgentbyteAgentStep(
            step_id="agent",
            metadata=StepMetadata(name="agent"),
            agent=agent,
        )
    ).add_end_step("agent")
    return workflow


def create_conditional_workflow(name: str = "conditional_workflow") -> Workflow:
    """Create a minimal conditional branch workflow based on echo output."""

    start = EchoStep(step_id="start", metadata=StepMetadata(name="start"))
    success = EchoStep(
        step_id="success",
        metadata=StepMetadata(name="success"),
        input_type=EchoOutput,
        output_type=EchoOutput,
        prefix="success: ",
    )
    failure = EchoStep(
        step_id="failure",
        metadata=StepMetadata(name="failure"),
        input_type=EchoOutput,
        output_type=EchoOutput,
        prefix="failure: ",
    )
    workflow = Workflow(WorkflowConfig(name=name))
    workflow.add_step(start).add_step(success).add_step(failure)
    workflow.set_start_step(start).add_end_step(success).add_end_step(failure)
    workflow.add_edge(
        start,
        success,
        EdgeCondition(type="output_based", field="result", operator="==", value="go"),
    )
    workflow.add_edge(
        start,
        failure,
        EdgeCondition(type="output_based", field="result", operator="!=", value="go"),
    )
    return workflow


def get_default_workflows() -> dict[str, Workflow]:
    """Return built-in workflow templates."""

    return {
        "echo_chain": create_echo_chain_workflow(),
        "conditional": create_conditional_workflow(),
    }


def get_default_steps() -> dict[str, object]:
    """Return a small registry of default reusable step instances."""

    return {
        "echo": EchoStep(step_id="echo", metadata=StepMetadata(name="echo")),
        "http": HttpStep(step_id="http", metadata=StepMetadata(name="http")),
    }


__all__ = [
    "create_conditional_workflow",
    "create_echo_chain_workflow",
    "create_simple_agent_workflow",
    "get_default_steps",
    "get_default_workflows",
]
