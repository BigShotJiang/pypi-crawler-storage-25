"""Dataset loading and registry.

Provides a load_dataset() function that discovers and loads datasets
from the data/samples/ directory.
"""

from pathlib import Path

from agentbyte.dataset.base import BaseDataset, DatasetConfig
from agentbyte.dataset.sqlite import SQLiteDataset
from agentbyte.dataset.json import JSONDataset


# Registry of dataset locations
DATASETS_ROOT = Path(__file__).parent.parent.parent.parent / "data" / "samples"


def load_dataset(dataset_id: str) -> BaseDataset:
    """Load a dataset by ID.
    
    Dataset IDs follow the pattern: "category/name"
    Example: "contracts/asmd", "contracts/esmd"
    
    This function:
    1. Looks for data/samples/{category}/{name}/
    2. Reads config.json for metadata (engine, table_name, etc.)
    3. Reads data.json for schema + records
    4. Returns a Dataset object with lazy connection
    
    Args:
        dataset_id: Dataset identifier (e.g., "contracts/asmd")
        
    Returns:
        Dataset object with engine, in_memory, table_name, and connect()
        
    Raises:
        FileNotFoundError: If dataset or config files not found
        ValueError: If config is invalid
        
    Example:
        >>> ds = load_dataset("contracts/asmd")
        >>> print(ds.engine)              # "sqlite"
        >>> print(ds.table_name)          # "contracts_asmd"
        >>> conn = ds.connect()
        >>> rows = conn.execute("SELECT * FROM contracts_asmd").fetchall()
    """
    # Parse dataset ID
    parts = dataset_id.split("/")
    if len(parts) != 2:
        raise ValueError(
            f"Dataset ID must be 'category/name', got: {dataset_id}"
        )
    category, name = parts

    # Find dataset directory
    dataset_dir = DATASETS_ROOT / category / name
    if not dataset_dir.is_dir():
        raise FileNotFoundError(
            f"Dataset not found at: {dataset_dir}\n"
            f"Available datasets at: {DATASETS_ROOT}"
        )

    # Load config.json
    config_path = dataset_dir / "config.json"
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    import json

    with open(config_path, "r", encoding="utf-8") as f:
        config_data = json.load(f)

    config = DatasetConfig(**config_data)

    # Find data file (try data.json first, then data.sqlite in future)
    data_path = dataset_dir / "data.json"
    if not data_path.exists():
        raise FileNotFoundError(
            f"Data file not found: {data_path}\n"
            f"Expected: {dataset_dir}/data.json"
        )

    # Create and return dataset implementation based on engine
    if config.engine == "sqlite":
        return SQLiteDataset(
            dataset_id=dataset_id,
            config=config,
            data_path=data_path,
        )
    elif config.engine == "json":
        return JSONDataset(
            dataset_id=dataset_id,
            config=config,
            data_path=data_path,
        )
    else:
        raise NotImplementedError(
            f"Engine '{config.engine}' not yet supported.\n"
            f"Currently supported engines: sqlite, json\n"
            f"Future support planned for: duckdb, lance, qdrant"
        )
