"""Pluggable storage for WebUI sessions."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable

from agentbyte.context import AgentContext


class SessionStore(ABC):
    """Abstract persistence layer for WebUI sessions."""

    @abstractmethod
    async def get(self, session_id: str) -> AgentContext | None:
        """Return a stored session context or ``None``."""

    @abstractmethod
    async def save(self, session_id: str, context: AgentContext) -> None:
        """Persist the full session context."""

    @abstractmethod
    async def list(self) -> Iterable[tuple[str, AgentContext]]:
        """Return all stored sessions."""

    @abstractmethod
    async def delete(self, session_id: str) -> bool:
        """Delete a session if present."""

    @abstractmethod
    async def clear_all(self) -> int:
        """Delete all stored sessions and return the removed count."""


class InMemorySessionStore(SessionStore):
    """Volatile in-memory session store for local UI use."""

    def __init__(self) -> None:
        self._store: dict[str, AgentContext] = {}

    async def get(self, session_id: str) -> AgentContext | None:
        context = self._store.get(session_id)
        return context.model_copy(deep=True) if context is not None else None

    async def save(self, session_id: str, context: AgentContext) -> None:
        self._store[session_id] = context.model_copy(deep=True)

    async def list(self) -> Iterable[tuple[str, AgentContext]]:
        return [
            (session_id, context.model_copy(deep=True))
            for session_id, context in self._store.items()
        ]

    async def delete(self, session_id: str) -> bool:
        return self._store.pop(session_id, None) is not None

    async def clear_all(self) -> int:
        count = len(self._store)
        self._store.clear()
        return count


__all__ = ["InMemorySessionStore", "SessionStore"]
