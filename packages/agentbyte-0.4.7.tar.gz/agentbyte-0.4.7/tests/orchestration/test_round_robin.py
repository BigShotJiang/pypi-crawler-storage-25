import pytest
from typing import List, Union, AsyncGenerator, Any, Optional

from agentbyte.orchestration.round_robin import RoundRobinOrchestrator
from agentbyte.agents.base import BaseAgent
from agentbyte.agents.types import AgentResponse, Usage
from agentbyte.messages import Message, UserMessage, AssistantMessage
from agentbyte.termination.max_message import MaxMessageTermination
from agentbyte.context import AgentContext
from agentbyte.cancellation_token import CancellationToken


class MockAgent(BaseAgent):
    def __init__(self, name: str, responses: List[str]):
        self.name = name
        self.description = f"Description of {name}"
        self.responses = responses
        self._resp_idx = 0
        self.tools = []

    async def run(
        self,
        task: Optional[Union[UserMessage, List[Message]]] = None,
        context: Optional[AgentContext] = None,
        cancellation_token: Optional[CancellationToken] = None,
    ) -> AgentResponse:
        resp_text = self.responses[self._resp_idx % len(self.responses)]
        self._resp_idx += 1
        ctx = context or AgentContext()
        # Ensure task is in history if provided
        if task and not ctx.messages:
            if isinstance(task, UserMessage):
                ctx.messages.append(task)
            elif isinstance(task, list):
                ctx.messages.extend(task)
        msg = AssistantMessage(content=resp_text, source=self.name)
        ctx.messages.append(msg)
        return AgentResponse(source=self.name, context=ctx, finish_reason="stop")

    async def run_stream(
        self,
        task: Optional[Union[UserMessage, List[Message]]] = None,
        context: Optional[AgentContext] = None,
        cancellation_token: Optional[CancellationToken] = None,
        verbose: bool = False,
        stream_tokens: bool = False,
    ) -> AsyncGenerator[Union[Message, Any, AgentResponse], None]:
        resp_text = self.responses[self._resp_idx % len(self.responses)]
        self._resp_idx += 1

        ctx = context or AgentContext()

        # 1. First yield the context message (BaseOrchestrator should filter it)
        if task:
            if isinstance(task, UserMessage):
                yield task
                if not ctx.messages:
                    ctx.messages.append(task)
            elif isinstance(task, list):
                for m in task:
                    yield m
                    if not ctx.messages:
                        ctx.messages.append(m)

        # 2. Yield assistant message
        msg = AssistantMessage(content=resp_text, source=self.name)
        yield msg

        # 3. Yield final response
        ctx.messages.append(msg)
        yield AgentResponse(
            source=self.name,
            context=ctx,
            usage=Usage(tokens_input=5, tokens_output=5),
            finish_reason="stop",
        )


@pytest.mark.asyncio
class TestRoundRobinOrchestrator:
    async def test_agent_cycling(self):
        a1 = MockAgent("a1", ["r1"])
        a2 = MockAgent("a2", ["r2"])
        a3 = MockAgent("a3", ["r3"])

        # Use max_iterations=6 to ensure 2 full cycles (6 agent responses)
        # Use a large message limit so it doesn't stop early
        term = MaxMessageTermination(100)
        orchestrator = RoundRobinOrchestrator([a1, a2, a3], term, max_iterations=6)

        response = await orchestrator.run(UserMessage(content="start", source="user"))

        # Verify order in shared_messages
        # Messages: User, a1, a2, a3, a1, a2, a3
        assert len(orchestrator.shared_messages) == 7
        assert orchestrator.shared_messages[1].source == "a1"
        assert orchestrator.shared_messages[2].source == "a2"
        assert orchestrator.shared_messages[3].source == "a3"
        assert orchestrator.shared_messages[4].source == "a1"
        assert orchestrator.shared_messages[5].source == "a2"
        assert orchestrator.shared_messages[6].source == "a3"

        # Verify metadata
        assert response.pattern_metadata["cycles_completed"] == 2
        assert response.pattern_metadata["agents_order"] == ["a1", "a2", "a3"]

    async def test_context_preparation(self):
        a1 = MockAgent("a1", ["r1"])
        term = MaxMessageTermination(2)
        orchestrator = RoundRobinOrchestrator([a1], term)

        # Test empty history context
        context0 = await orchestrator.prepare_context_for_agent(a1)
        assert "It is now your turn" in context0

        # Test non-empty history context
        orchestrator.shared_messages.append(UserMessage(content="hello", source="user"))
        orchestrator.shared_messages.append(AssistantMessage(content="hi", source="a1"))

        context1 = await orchestrator.prepare_context_for_agent(a1)
        assert "progress/history so far" in context1
        assert "hello" in context1
        assert "hi" in context1

    async def test_state_update_skips_echo(self):
        a1 = MockAgent("a1", ["r1"])
        term = MaxMessageTermination(2)
        orchestrator = RoundRobinOrchestrator([a1], term)

        # Mock result from agent
        # index 0 is context echo, index 1 is actual response
        ctx = AgentContext()
        msg_echo = UserMessage(content="context", source="orchestrator")
        msg_resp = AssistantMessage(content="response", source="a1")
        ctx.messages = [msg_echo, msg_resp]

        result = AgentResponse(source="a1", context=ctx, finish_reason="stop")

        await orchestrator.update_shared_state(result)

        # Should only have added msg_resp
        assert len(orchestrator.shared_messages) == 1
        assert orchestrator.shared_messages[0].content == "response"

    async def test_reset(self):
        a1 = MockAgent("a1", ["r1"])
        a2 = MockAgent("a2", ["r2"])
        term = MaxMessageTermination(10)
        orchestrator = RoundRobinOrchestrator([a1, a2], term)

        # Advance index
        await orchestrator.select_next_agent()  # a1
        assert orchestrator.current_agent_index == 1

        orchestrator._reset_for_run()
        assert orchestrator.current_agent_index == 0
