from __future__ import annotations

from types import SimpleNamespace

from agentbyte.presets.workflow import get_workflow


def _dummy_client():
    return SimpleNamespace(model="test-model")


def test_get_workflow_returns_linear_research_writer_reviewer_workflow():
    workflow = get_workflow(model_client=_dummy_client())

    validation = workflow.validate_workflow()

    assert validation.is_valid
    assert workflow.start_step_id == "researcher"
    assert workflow.end_step_ids == ["reviewer"]
    assert [(edge.from_step, edge.to_step) for edge in workflow.edges] == [
        ("researcher", "research_to_writer"),
        ("research_to_writer", "writer"),
        ("writer", "writer_to_reviewer"),
        ("writer_to_reviewer", "reviewer"),
    ]
    assert [step_id for step_id in workflow.steps if step_id in {"researcher", "writer", "reviewer"}] == [
        "researcher",
        "writer",
        "reviewer",
    ]
