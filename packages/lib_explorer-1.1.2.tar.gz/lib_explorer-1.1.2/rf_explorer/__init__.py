
"""
RF Explorer package initialization.
"""

__version__ = "1.1.2"
__author__ = "Khaledlim"