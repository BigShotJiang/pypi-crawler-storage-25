"""
scanner.py
Scan installed Python modules and Robot Framework libraries.
"""
import pkgutil
import os, sys
import contextlib
from rich.console import Console
from rich.table import Table
from rf_explorer.utils import list_rpa_libraries

console = Console()

ROBOT_BUILTIN_LIBRARIES = {
    "BuiltIn",
    "Collections",
    "DateTime",
    "Dialogs",
    "OperatingSystem",
    "Process",
    "Screenshot",
    "String",
    "Telnet",
    "XML",
}

# Optional -> If Robot Framework is installed
try:
    from robot.libdoc import LibraryDocumentation
except ImportError:
    LibraryDocumentation = None


# ======================================================
# HELPERS
# ======================================================

@contextlib.contextmanager
def suppress_output():
    old_out, old_err = sys.stdout, sys.stderr
    sys.stdout = open(os.devnull, "w")
    sys.stderr = open(os.devnull, "w")
    try:
        yield
    finally:
        sys.stdout.close()
        sys.stderr.close()
        sys.stdout = old_out
        sys.stderr = old_err


def is_internal(name):
    return name.startswith("_") or "__" in name


def classify(name):
    lname = name.lower()

    # Robot built-in libraries
    if name in ROBOT_BUILTIN_LIBRARIES:
        return "robot"

    if "py" in lname:
        return "python"

    # Explicit Robot naming conventions
    if lname.startswith("rpa"):
        return "robot"
    if lname.endswith("library"):
        return "robot"
    if "robotframework" in lname:
        return "robot"

    if name and name[0].isupper() and any(c.islower() for c in name):
        return "robot"

    return "python"

def probe_robot_keywords(lib_name):

    if LibraryDocumentation is None:
        return False, 0
    try:
        with suppress_output():
            doc = LibraryDocumentation(lib_name)
            return True, len(doc.keywords)
    except Exception:
        return False, 0

# ======================================================
# MAIN SCAN ENGINE
# ======================================================

def scan_modules():
    """Scan installed modules & classify them."""
    modules = sorted([name for _, name, _ in pkgutil.iter_modules()])

    modules.extend(list_rpa_libraries())
    modules = sorted(set(modules))

    console.log(f"🔍[magenta][b] Scan of [cyan]{len(modules)}[/cyan] modules...[/b][/magenta]\n")

    robot_libs = []
    python_libs = []
    unknown_libs = []
    skipped = 0

    for name in modules:
        if is_internal(name):
            skipped += 1
            continue

        category = classify(name)

        if category == "robot":
            is_robot, kw_count = probe_robot_keywords(name)

            lname = name.lower()
            trusted_name = (
                name in ROBOT_BUILTIN_LIBRARIES
                or lname.startswith("rpa")
                or lname.endswith("library")
                or "robotframework" in lname
            )
            has_internal_upper = any(c.isupper() for c in name[1:])

            if is_robot and (trusted_name or kw_count > 0 or has_internal_upper):
                robot_libs.append((name, kw_count))
            else:
                python_libs.append(name)
        else:
            python_libs.append(name)

    return {
        "robot": robot_libs,
        "python": python_libs,
        "unknown": unknown_libs,
        "skipped": skipped
    }

# ======================================================
# PRINT RESULT (improved)
# ======================================================

def print_scan(result, show_all=False, filter_type=None):
    total_robot = len(result["robot"])
    total_python = len(result["python"])
    total_unknown = len(result["unknown"])
    total_skipped = result.get("skipped", 0)

    # Merge unknown into skipped
    merged_skipped = total_skipped + total_unknown

    total_all = total_robot + total_python + merged_skipped

    # ---------------- ROBOT SECTION ----------------
    if show_all or filter_type == "robot" or filter_type is None:
        table = Table(title=f"Robot Framework Libraries • [bold cyan]{total_robot}[/bold cyan] found",
                      title_style="bold yellow")
        table.title_justify = "left"
        table.add_column("Library", style="cyan", min_width=20)
        table.add_column("Keywords", style="green", min_width=5)
        for lib, kw in sorted(result["robot"]):
            table.add_row(lib, str(kw))

        console.print(table)
        console.print()

    # ---------------- PYTHON SECTION ---------------
    if show_all or filter_type == "python" or filter_type is None:
        table = Table(title=f"Python Modules • [bold cyan]{total_python}[/bold cyan] found",
                      title_style="bold yellow")
        table.add_column("Module", style="cyan")
        table.title_justify = "left"
        for mod in sorted(result["python"]):
            table.add_row(mod)

        console.print(table)
        console.print()

    # ---------------- INTERNAL MERGED --------------
    if show_all and merged_skipped:
        console.print(
            f"[dim] [bold cyan]{merged_skipped}[/bold cyan] internal/system modules skipped (hidden or not usable)[/dim]\n"
        )