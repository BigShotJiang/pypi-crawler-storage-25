
import argparse, os
from rf_explorer.audit.core import AuditResult, Collector
from rf_explorer.audit.scanner import RobotScanner, PythonKeywordScanner, VariableScanner
from rf_explorer.audit.exporters import export_json, export_html, export_excel
from rf_explorer.audit import __version__


def build_parser(prog=None):
    parser = argparse.ArgumentParser(description="RF Audit Tool", prog=prog)
    parser.add_argument("--path", help="Path file or folder", required=False)
    parser.add_argument("--version", action="store_true")

    parser.add_argument("--all", action="store_true")
    parser.add_argument("--tests", action="store_true")
    parser.add_argument("--keywords", action="store_true")
    parser.add_argument("--variables", action="store_true")

    parser.add_argument("--export-json")
    parser.add_argument("--export-html")
    parser.add_argument("--export-excel")

    return parser


def execute_audit(args):
    if args.version:
        print(__version__)
        return 0

    if not args.path:
        print("Error: --path is required")
        return 2

    if not os.path.exists(args.path):
        print("Error: path not found")
        return 2

    if not any([args.all, args.tests, args.keywords, args.variables]):
        print("No scan option provided")
        return 2

    if args.all:
        args.tests = args.keywords = args.variables = True

    result = AuditResult()

    scanners = []

    if args.tests:
        scanners.append(RobotScanner())

    if args.keywords:
        scanners.append(PythonKeywordScanner())

    if args.variables:
        scanners.append(VariableScanner())

    Collector(scanners).run(args.path, result)

    summary = result.summary.copy()
    libs = len(getattr(result, "libraries", []))
    ress = len(getattr(result, "resources", []))
    tags = getattr(result, "tags", {})

    ordered = {"libraries": libs, "resources": ress}
    ordered.update(summary)
    ordered["tags"] = len(tags)
    print("SUMMARY:", ordered)

    if args.export_json:
        export_json(result, args.export_json)

    if args.export_html:
        export_html(result, args.export_html, scanned_path=args.path)

    if args.export_excel:
        export_excel(result, args.export_excel)

    return 0


def run_cli(argv=None, prog=None):
    parser = build_parser(prog=prog)
    args = parser.parse_args(argv)
    return execute_audit(args)

def main():
    raise SystemExit(run_cli())

if __name__ == "__main__":
    main()
