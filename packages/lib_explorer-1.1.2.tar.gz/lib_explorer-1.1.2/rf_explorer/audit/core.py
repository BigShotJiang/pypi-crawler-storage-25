
class Collector:
    def __init__(self, scanners):
        self.scanners = scanners

    def run(self, path, result):
        for scanner in self.scanners:
            scanner.scan(path, result)

class AuditResult:
    def __init__(self):
        self.files = []
        self.summary = {
            "suites": 0,
            "tests": 0,
            "keywords": 0,
            "variables": 0
        }
        self.tags = {}
        self.libraries = []  
        self.resources = []  
        self.libraries_set = set()  
        self.resources_set = set()  

class Issue:
    def __init__(self, severity, rule, message, file):
        self.severity = severity
        self.rule = rule
        self.message = message
        self.file = file
