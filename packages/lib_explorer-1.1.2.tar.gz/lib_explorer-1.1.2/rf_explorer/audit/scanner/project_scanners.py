import os
import ast
from pathlib import Path
try:
    import yaml as _yaml
except ImportError:
    _yaml = None


def _iter_robot_files(path):
    for file in iter_files(path):
        if file.endswith((".robot", ".resource")):
            yield file


def _split_cells(raw_line):
    return [cell for cell in raw_line.replace("\t", "  ").split("  ") if cell]


def _normalize_section(stripped_line):
    if not (stripped_line.startswith("***") and stripped_line.endswith("***")):
        return None
    return stripped_line.strip("*").strip().lower()


def _suite_name(file_path):
    stem = Path(file_path).stem.replace("_", " ").replace("-", " ")
    return " ".join(part if part.isupper() else part.capitalize() for part in stem.split())


def _parse_robot_file(file_path):
    tests = []
    keywords = []
    variables = []
    libraries = []
    resources = []
    variable_files = []
    tags = {}
    section = None
    current_test_tags = []

    try:
        with open(file_path, encoding="utf-8") as handle:
            lines = handle.readlines()
    except OSError:
        return {
            "tests": tests,
            "keywords": keywords,
            "variables": variables,
            "libraries": libraries,
            "resources": resources,
            "tags": tags,
        }

    for raw_line in lines:
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        next_section = _normalize_section(stripped)
        if next_section:
            section = next_section
            current_test_tags = []
            continue

        cells = _split_cells(raw_line.rstrip())
        if not cells:
            continue

        first = cells[0]

        if section == "settings":
            setting = first.lower()
            args = cells[2:] if len(cells) > 2 else []
            if setting == "library" and len(cells) >= 2:
                libraries.append({"name": cells[1], "args": args, "type": "library"})
            elif setting == "resource" and len(cells) >= 2:
                resources.append({"name": cells[1], "args": args, "type": "resource"})
            elif setting == "variables" and len(cells) >= 2:
                variable_files.append(cells[1])
            continue

        if section == "variables":
            if raw_line[:1].isspace() or first == "...":
                continue
            variables.append(" = ".join(cells[:2]) if len(cells) > 1 else first)
            continue

        if section == "keywords":
            if raw_line[:1].isspace() or first == "...":
                continue

            if first.startswith("["):
                continue
            keywords.append(first)
            continue

        if section == "test cases":
            if raw_line[:1].isspace() or first == "...":
                tag_cells = cells[1:] if first.lower() == "[tags]" else []
                if tag_cells:
                    current_test_tags.extend(tag_cells)
                continue

            if first.startswith("["):
                continue

            if current_test_tags:
                for tag in current_test_tags:
                    tags[tag] = tags.get(tag, 0) + 1
                current_test_tags = []

            tests.append(first)

    if current_test_tags:
        for tag in current_test_tags:
            tags[tag] = tags.get(tag, 0) + 1

    return {
        "tests": tests,
        "keywords": keywords,
        "variables": variables,
        "libraries": libraries,
        "resources": resources,
        "variable_files": variable_files,
        "tags": tags,
    }

def _parse_yaml_variable_file(file_path):
    """Extract top-level keys from a YAML variable file as Robot Framework variables."""
    if _yaml is None:
        return []
    try:
        with open(file_path, encoding="utf-8") as handle:
            data = _yaml.safe_load(handle)
    except (OSError, _yaml.YAMLError):
        return []
    if not isinstance(data, dict):
        return []
    variables = []
    for key, value in data.items():
        if isinstance(value, dict):
            items_str = ", ".join(f"{k}={v}" for k, v in value.items())
            variables.append(f"&{{{key}}} = {{{items_str}}}")
        elif isinstance(value, list):
            variables.append(f"@{{{key}}} = {value}")
        else:
            variables.append(f"${{{key}}} = {value}")
    return variables


def iter_files(path):
    if os.path.isfile(path):
        yield path
    else:
        for r,_,f in os.walk(path):
            for x in f:
                yield os.path.join(r,x)

class PythonKeywordScanner:
    def scan(self, path, result):
        for file in iter_files(path):
            if not file.endswith(".py"):
                continue
            try:
                tree = ast.parse(open(file,encoding="utf-8").read())
            except:
                continue

            funcs = [n.name for n in ast.walk(tree)
                     if isinstance(n, ast.FunctionDef) and not n.name.startswith("_")]

            if funcs:
                result.files.append({"type":"keywords","file":file,"values":funcs})
                result.summary["keywords"] += len(funcs)


class RobotScanner:
    def scan(self, path, result):
        for file in _iter_robot_files(path):
            parsed = _parse_robot_file(file)

            if parsed["tests"]:
                result.files.append(
                    {"type": "suite", "name": _suite_name(file), "tests": parsed["tests"], "file": file}
                )
                result.summary["suites"] += 1
                result.summary["tests"] += len(parsed["tests"])

            if parsed["keywords"]:
                result.files.append({"type": "keywords", "file": file, "values": parsed["keywords"]})
                result.summary["keywords"] += len(parsed["keywords"])

            for library in parsed["libraries"]:
                key = (library["name"], tuple(library["args"]))
                if key not in result.libraries_set:
                    result.libraries_set.add(key)
                    result.libraries.append(library)

            for resource in parsed["resources"]:
                key = (resource["name"], tuple(resource["args"]))
                if key not in result.resources_set:
                    result.resources_set.add(key)
                    result.resources.append(resource)

            for tag, count in parsed["tags"].items():
                result.tags[tag] = result.tags.get(tag, 0) + count


class VariableScanner:
    def scan(self, path, result):
        for file in _iter_robot_files(path):
            parsed = _parse_robot_file(file)
            if not parsed["variables"]:
                continue
            result.files.append({"type": "variables", "file": file, "values": parsed["variables"]})
            result.summary["variables"] += len(parsed["variables"])

        for file in iter_files(path):
            if not file.endswith((".yml", ".yaml")):
                continue
            if os.path.basename(file).startswith("."):
                continue
            variables = _parse_yaml_variable_file(file)
            if not variables:
                continue
            result.files.append({"type": "variables", "file": file, "values": variables})
            result.summary["variables"] += len(variables)
