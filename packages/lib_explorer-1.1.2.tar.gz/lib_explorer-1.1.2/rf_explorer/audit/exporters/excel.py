from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

HEADER_FILL = PatternFill("solid", fgColor="1F4E79")  
HEADER_FONT = Font(color="FFFFFF", bold=True)
CENTER = Alignment(vertical="center", horizontal="center", wrap_text=True)

BORDER = Border(
    left=Side(style="thin", color="D9D9D9"),
    right=Side(style="thin", color="D9D9D9"),
    top=Side(style="thin", color="D9D9D9"),
    bottom=Side(style="thin", color="D9D9D9"),
)

def style_header(row):
    for cell in row:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = CENTER
        cell.border = BORDER

def style_cells(ws):
    for row in ws.iter_rows():
        for cell in row:
            cell.border = BORDER
            cell.alignment = Alignment(vertical="center", wrap_text=True)

def auto_width(ws):
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            if cell.value:
                max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(max_len + 3, 50)

def export_excel(result, path):
    wb = Workbook()

    default_sheet = wb.active
    wb.remove(default_sheet)

    # ===================== SETTINGS (Libraries + Resources) =====================
    ws_set = wb.create_sheet("Settings")
    ws_set.append(["Library", "Resource"])
    style_header(ws_set[1])
    libs = sorted(result.libraries, key=lambda l: str(l.get('name', ''))) if hasattr(result, 'libraries') and result.libraries else []
    ress = sorted(result.resources, key=lambda r: str(r.get('name', ''))) if hasattr(result, 'resources') and result.resources else []
    max_len = max(len(libs), len(ress))
    for i in range(max_len):
        lib_name = libs[i].get('name', '') if i < len(libs) else ''
        res_name = ress[i].get('name', '') if i < len(ress) else ''
        ws_set.append([lib_name, res_name])
    style_cells(ws_set)
    auto_width(ws_set)

    # ===================== TAGS =====================
    if hasattr(result, 'tags') and result.tags:
        ws_tag = wb.create_sheet("Tags")
        ws_tag.append(["Tag", "Test Count"])
        style_header(ws_tag[1])
        for tag, count in sorted(result.tags.items(), key=lambda x: -x[1]):
            ws_tag.append([tag, count])
        style_cells(ws_tag)
        auto_width(ws_tag)

    # ===================== SUITES =====================
    suites = [f for f in result.files if f.get("type") == "suite"]
    if suites:
        ws_suite = wb.create_sheet("Suites")
        ws_suite.append(["Suite Name", "File", "Tests"])
        style_header(ws_suite[1])

        for s in suites:
            tests = ", ".join(s.get("tests", []))
            ws_suite.append([s.get("name"), s.get("file"), tests])

        ws_suite.freeze_panes = "A2"
        style_cells(ws_suite)
        auto_width(ws_suite)

    # ===================== KEYWORDS =====================
    keywords = [f for f in result.files if f.get("type") == "keywords"]
    if keywords:
        ws_kw = wb.create_sheet("Keywords")
        ws_kw.append(["File", "Keyword"])
        style_header(ws_kw[1])

        for kw in keywords:
            for k in kw.get("values", []):
                ws_kw.append([kw.get("file"), k])

        ws_kw.freeze_panes = "A2"
        style_cells(ws_kw)
        auto_width(ws_kw)

    # ===================== VARIABLES =====================
    variables = [f for f in result.files if f.get("type") == "variables"]
    if variables:
        ws_var = wb.create_sheet("Variables")
        ws_var.append(["File", "Variable"])
        style_header(ws_var[1])

        for var in variables:
            for v in var.get("values", []):
                ws_var.append([var.get("file"), v])

        ws_var.freeze_panes = "A2"
        style_cells(ws_var)
        auto_width(ws_var)

    wb.save(path)
