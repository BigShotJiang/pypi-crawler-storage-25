import os
from html import escape

def export_html(result, path, scanned_path=None):

    if scanned_path is None:
        scanned_path = os.path.dirname(path)

    if os.path.isfile(scanned_path):
        folder_name = os.path.basename(os.path.dirname(scanned_path))
    else:
        folder_name = os.path.basename(os.path.normpath(scanned_path))

    tests_count = result.summary.get("tests", 0)
    keywords_count = result.summary.get("keywords", 0)
    variables_count = result.summary.get("variables", 0)
    libraries_count = len(getattr(result, "libraries", []))
    resources_count = len(getattr(result, "resources", []))

    html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="utf-8">
    <title>Robot Framework Audit - {folder_name}</title>

    <style>

    * {{
        margin:0;
        padding:0;
        box-sizing:border-box;
    }}

    body {{
        font-family:Segoe UI, Arial, sans-serif;
        background:#f5f7fb;
        color:#1f2937;
        padding:28px;
    }}

    .topbar {{
        display:flex;
        align-items:baseline;
        gap:16px;
        margin-bottom:24px;
    }}

    h1 {{
        font-size:38px;
        font-weight:800;
    }}

    .project-name {{
        font-size:24px;
        color:#6b7280;
    }}

    .summary {{
        display:grid;
        grid-template-columns:repeat(5, minmax(0, 1fr));
        gap:18px;
    }}

    @media (max-width: 1400px) {{
        .summary {{
            grid-template-columns:repeat(3, minmax(0, 1fr));
        }}
    }}

    @media (max-width: 900px) {{
        .summary {{
            grid-template-columns:repeat(2, minmax(0, 1fr));
        }}
    }}

    @media (max-width: 600px) {{
        .summary {{
            grid-template-columns:1fr;
        }}
    }}

    .card {{
        background:white;
        border-radius:18px;
        padding:20px;
        display:flex;
        align-items:center;
        gap:16px;
        border:1px solid #edf0f5;
        box-shadow:0 4px 12px rgba(0,0,0,.06);
        transition:.2s;
    }}

    .card:hover {{
        transform:translateY(-4px);
        box-shadow:0 10px 18px rgba(0,0,0,.08);
    }}

    .icon {{
        width:54px;
        height:54px;
        border-radius:50%;
        display:flex;
        justify-content:center;
        align-items:center;
        color:white;
        font-size:24px;
        font-weight:bold;
    }}

    .tests .icon {{ background:#22c55e; }}
    .keywords .icon {{ background:#3b82f6; }}
    .variables .icon {{ background:#f59e0b; }}
    .libraries .icon {{ background:#7c3aed; }}
    .resources .icon {{ background:#06b6d4; }}

    .card-title {{
        font-size:18px;
        font-weight:700;
    }}

    .card-value {{
        font-size:34px;
        font-weight:800;
        line-height:1;
        margin-top:4px;
    }}

    .card-sub {{
        font-size:13px;
        color:#6b7280;
        margin-top:4px;
    }}

    .search-wrap {{
        margin:24px 0;
    }}

    .search {{
        width:420px;
        max-width:100%;
        padding:14px 16px;
        border-radius:14px;
        border:1px solid #dbe2ea;
        background:white;
        font-size:15px;
        outline:none;
    }}

    .section {{
        margin-top:28px;
    }}

    .section h2 {{
        font-size:26px;
        margin-bottom:14px;
    }}

    .box {{
        background:white;
        border-radius:18px;
        padding:18px;
        margin-bottom:14px;
        border:1px solid #edf0f5;
        box-shadow:0 4px 12px rgba(0,0,0,.06);
        transition:.2s;
    }}

    .box:hover {{
        transform:translateY(-3px);
        box-shadow:0 10px 18px rgba(0,0,0,.08);
    }}

    .header {{
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:18px;
        cursor:pointer;
    }}

    .file {{
        font-size:16px;
        font-weight:700;
    }}

    .path {{
        font-size:13px;
        color:#6b7280;
        margin-top:4px;
    }}

    .count {{
        font-size:14px;
        font-weight:700;
        color:#374151;
    }}

    .content {{
        display:none;
        margin-top:16px;
        padding-top:14px;
        border-top:1px solid #edf0f5;
    }}

    .pills {{
        display:flex;
        flex-wrap:wrap;
        gap:10px;
    }}

    .file-pill {{
        display:inline-block;
        padding:10px 16px;
        border-radius:999px;
        margin:8px 10px 0 0;
        font-size:14px;
        font-weight:600;
    }}

    .test-pill {{
        background:#dcfce7;
        color:#166534;
    }}

    .keyword-pill {{
        background:#dbeafe;
        color:#1d4ed8;
    }}

    .var-pill {{
        background:#fef3c7;
        color:#b45309;
    }}

    .lib {{
        background:#f3e8ff;
        color:#6d28d9;
    }}

    .res {{
        background:#ccfbf1;
        color:#0f766e;
    }}

    .tag {{
        background:#eff6ff;
        color:#1d4ed8;
    }}

    .empty {{
        color:#9ca3af;
    }}

    </style>

    <script>

    function toggle(id){{
        let el = document.getElementById(id);

        if(el.style.display === "block")
            el.style.display = "none";
        else
            el.style.display = "block";
    }}

    function filterItems(){{
        let q = document.getElementById("search").value.toLowerCase();
        let boxes = document.getElementsByClassName("box");

        for(let b of boxes){{
            let txt = b.innerText.toLowerCase();
            b.style.display = txt.includes(q) ? "block" : "none";
        }}
    }}

    </script>
    </head>

    <body>

    <div class="topbar">
        <h1>Robot Framework Audit</h1>
        <div class="project-name" style="font-size:48px;font-weight:800;letter-spacing:1.5px;line-height:1.1;">{folder_name}</div>
    </div>

    <div class="summary">

    <div class="card libraries">
    <div class="icon">📦</div>
    <div>
    <div class="card-title">Libraries</div>
    <div class="card-value">{libraries_count}</div>
    <div class="card-sub">Imported libraries</div>
    </div>
    </div>

    <div class="card resources">
    <div class="icon">📄</div>
    <div>
    <div class="card-title">Resources</div>
    <div class="card-value">{resources_count}</div>
    <div class="card-sub">Resource files</div>
    </div>
    </div>

    <div class="card tests">
    <div class="icon">✔</div>
    <div>
    <div class="card-title">Tests</div>
    <div class="card-value">{tests_count}</div>
    <div class="card-sub">Test cases</div>
    </div>
    </div>

    <div class="card keywords">
    <div class="icon">⚙</div>
    <div>
    <div class="card-title">Keywords</div>
    <div class="card-value">{keywords_count}</div>
    <div class="card-sub">Defined keywords</div>
    </div>
    </div>

    <div class="card variables">
    <div class="icon">$</div>
    <div>
    <div class="card-title">Variables</div>
    <div class="card-value">{variables_count}</div>
    <div class="card-sub">Defined variables</div>
    </div>
    </div>

    </div>

    <div class="search-wrap">
    <input id="search" class="search" placeholder="Search..." onkeyup="filterItems()">
    </div>
    """

    idx = 0

    # SETTINGS
    html += "<div class='section'><h2>Settings</h2>"

    libs = getattr(result, "libraries", [])
    html += f"""
    <div class="box">
    <div class="header" onclick="toggle('libs')">
    <div class="file">Libraries</div>
    <div class="count">{libraries_count} libraries</div>
    </div>
    <div class="content" id="libs">
    """

    if libs:
        for lib in libs:
            html += f"<span class='file-pill lib'>{escape(os.path.basename(str(lib.get('name',''))))}</span>"
    else:
        html += "<div class='empty'>No libraries found.</div>"

    html += "</div></div>"

    res_list = getattr(result, "resources", [])
    html += f"""
<div class="box">
<div class="header" onclick="toggle('res')">
<div class="file">Resources</div>
<div class="count">{resources_count} resources</div>
</div>
<div class="content" id="res">
"""

    if res_list:
        for res in res_list:
            html += f"<span class='file-pill res'>{escape(os.path.basename(str(res.get('name',''))))}</span>"
    else:
        html += "<div class='empty'>No resources found.</div>"

    html += "</div></div></div>"

    # SUITES / TESTS
    html += "<div class='section'><h2>Suites / Tests</h2>"

    suite_files = [item for item in result.files if item["type"] == "suite"]

    if not suite_files:
        html += """
    <div class="box">
    <div class="header" onclick="toggle('empty-suites')">
    <div class="file">Suites / Tests</div>
    <div class="count">0 tests</div>
    </div>
    <div class="content" id="empty-suites">
    <div class='empty'>No suites or tests found.</div>
    </div>
    </div>
    """

    for f in suite_files:

        cid = f"s{idx}"
        idx += 1

        suite_name = escape(str(f.get("name", "N/A")))
        full_path = escape(str(f.get("file", "N/A")))
        count = len(f.get("tests", []))

        html += f"""
        <div class="box">
        <div class="header" onclick="toggle('{cid}')">
        <div>
        <div class="file">{suite_name}</div>
        <div class="path">{full_path}</div>
        </div>
        <div class="count">{count} tests</div>
        </div>

        <div class="content" id="{cid}">
        """

        for t in f.get("tests", []):
            html += f"<span class='file-pill test-pill'>{escape(str(t))}</span>"

        html += "</div></div>"

    html += "</div>"

    # KEYWORDS
    html += f"<div class='section'><h2>Keywords</h2>"

    keyword_files = [item for item in result.files if item["type"] == "keywords"]

    if not keyword_files:
        html += """
        <div class="box">
        <div class="header" onclick="toggle('empty-keywords')">
        <div class="file">Keywords</div>
        <div class="count">0 keywords</div>
        </div>
        <div class="content" id="empty-keywords">
        <div class='empty'>No keywords found.</div>
        </div>
        </div>
        """

    for f in keyword_files:
        cid = f"k{idx}"
        idx += 1
        full_path = str(f.get("file", ""))
        filename = os.path.basename(full_path)
        count = len(f.get("values", []))
        html += f"""
        <div class="box">
        <div class="header" onclick="toggle('{cid}')">
        <div>
        <div class="file">{escape(filename)}</div>
        <div class="path">{escape(full_path)}</div>
        </div>
        <div class="count">{count} keywords</div>
        </div>
        <div class="content" id="{cid}">
        """
        for k in f.get("values", []):
            html += f"<span class='file-pill keyword-pill'>{escape(str(k))}</span>"
        html += "</div></div>"
    html += "</div>"

    # VARIABLES
    html += "<div class='section'><h2>Variables</h2>"

    variable_files = [item for item in result.files if item["type"] == "variables"]

    if not variable_files:
        html += """
        <div class="box">
        <div class="header" onclick="toggle('empty-variables')">
        <div class="file">Variables</div>
        <div class="count">0 variables</div>
        </div>
        <div class="content" id="empty-variables">
        <div class='empty'>No variables found.</div>
        </div>
        </div>
        """

    for f in variable_files:

        cid = f"v{idx}"
        idx += 1

        full_path = str(f.get("file", ""))
        filename = os.path.basename(full_path)
        count = len(f.get("values", []))

        html += f"""
        <div class="box">
        <div class="header" onclick="toggle('{cid}')">
        <div>
        <div class="file">{escape(filename)}</div>
        <div class="path">{escape(full_path)}</div>
        </div>
        <div class="count">{count} variables</div>
        </div>

        <div class="content" id="{cid}">
        """

        for v in f.get("values", []):
            html += f"<span class='file-pill var-pill'>{escape(str(v))}</span>"

        html += "</div></div>"

    html += "</div>"

    # TAGS
    tags_count = len(result.tags) if hasattr(result, "tags") and result.tags else 0
    html += f"""
    <div class='section'>
    <h2>Tags</h2>
    <div class="box">
    <div class="header" onclick="toggle('tags')">
    <div class="file">Tags</div>
    <div class="count">{tags_count} tags</div>
    </div>
    <div class="content" id="tags">
    """
    if hasattr(result, "tags") and result.tags:
        for tag, count in sorted(result.tags.items(), key=lambda x: -x[1]):
            html += f"<span class='file-pill tag'>{escape(str(tag))} ({count})</span>"
    else:
        html += "<div class='empty'>No tags found.</div>"
    html += """
    </div>
    </div>
    </div>

    </body>
    </html>
    """
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)