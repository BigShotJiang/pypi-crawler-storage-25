import json

def export_json(result, path):

    data = result.__dict__.copy()
    data.pop('libraries_set', None)
    data.pop('resources_set', None)
    if 'libraries' in data:
        data['libraries'] = list(data['libraries'])
    if 'resources' in data:
        data['resources'] = list(data['resources'])

    ordered = {}
 
    for k in ['libraries', 'resources', 'tags']:
        if k in data:
            ordered[k] = data[k]
    for k in data:
        if k not in ordered and k != 'summary':
            ordered[k] = data[k]

    summary = data.get('summary', {})
    summary_ordered = {}
    summary_ordered['libraries'] = len(data.get('libraries', []))
    summary_ordered['resources'] = len(data.get('resources', []))
    tags = data.get('tags', {})
    summary_ordered['tags'] = len(tags) if tags else 0
    for k in summary:
        if k not in summary_ordered:
            summary_ordered[k] = summary[k]
    ordered['summary'] = summary_ordered

    if 'summary' in ordered:
        summary_value = ordered.pop('summary')
        ordered['summary'] = summary_value

    with open(path, "w", encoding="utf-8") as f:
        json.dump(ordered, f, indent=2, ensure_ascii=False)
