# RF Explorer

![Python Version](https://img.shields.io/badge/python-3.9%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Status](https://img.shields.io/badge/status-stable-brightgreen)

PyPI: https://pypi.org/project/lib-explorer/  
GitHub: https://github.com/khaledlim/rf-explorer

RF Explorer is an interactive command-line tool to explore Python modules and Robot Framework libraries.
It renders readable, syntax-highlighted documentation directly in the terminal using Rich.

## Audit Report Preview

![RF Explorer Audit Report Preview](docs/images/audit-report-preview.png)

## Highlights

- Interactive terminal mode (menu-driven UI with InquirerPy)
- Direct CLI mode for quick commands
- Python module exploration: functions, classes, methods, and docstrings
- Robot Framework library exploration: keywords, arguments, documentation, and examples
- Installed package listing with filtering
- Environment scan (Python, Robot Framework, or full)
- Global Robot keyword search

## Installation

```bash
pip install lib-explorer
```

## Quick Start

```bash
# Interactive mode
rf-explorer

# Help and version
rf-explorer --help
rf-explorer --version
```

## CLI Usage

```text
rf-explorer
rf-explorer --help
rf-explorer --version

rf-explorer python <module> [regex|--all]
rf-explorer robot <library> [regex|--all]

rf-explorer --list
rf-explorer --list --filter <text>

rf-explorer --scan robot
rf-explorer --scan python
rf-explorer --scan --all

rf-explorer --search <keyword-or-regex>

rf-explorer audit --path <folder-path> --all
rf-explorer audit --path <folder-path> --all --export-html report.html
rf-explorer audit --path <folder-path>  --tests --keywords --variables

```

## Examples

### Explore a Python module

```bash
rf-explorer python requests
rf-explorer python requests get
rf-explorer python requests --all
```

### Explore a Robot Framework library

```bash
rf-explorer robot JSONLibrary
rf-explorer robot JSONLibrary Convert
rf-explorer robot JSONLibrary --all
```

### List installed packages

```bash
rf-explorer --list
rf-explorer --list --filter py
```

### Scan environment

```bash
rf-explorer --scan robot
rf-explorer --scan python
rf-explorer --scan --all
```

### Search Robot keywords globally

```bash
rf-explorer --search browser
```

### Audit Robot project content

```bash
rf-explorer audit --path <folder-path> --all --export-html report.html
rf-explorer audit --path <folder-path> --all --export-json audit.json
rf-explorer audit --path <folder-path> --all --export-excell export.xlsx
```

## Notes

- Requires Python 3.9+
- Works best in a terminal that supports colors

## License

MIT (see LICENSE)
