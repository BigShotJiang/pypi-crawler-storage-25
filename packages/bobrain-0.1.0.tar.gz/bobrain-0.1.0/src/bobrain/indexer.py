"""Indexer: markdown → chunks → embeddings → LanceDB + BM25 pickle."""
from __future__ import annotations

import hashlib
import os
import pickle
import re
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import lancedb
from fastembed import TextEmbedding
from fugashi import Tagger
from rank_bm25 import BM25Okapi
from tqdm import tqdm

MODEL_NAME = "intfloat/multilingual-e5-large"
VECTOR_DIM = 1024
TABLE_NAME = "chunks"

# Directories we never want to scan, even when the user points --root at a
# parent that contains them. Without this, `bobrain index ~/myrepo` happily
# walks into .venv/ (hundreds of vendored READMEs) or node_modules/.
_EXCLUDE_DIRS = frozenset({
    ".venv", "venv", ".env",
    "node_modules",
    ".git",
    "__pycache__",
    ".mypy_cache", ".ruff_cache", ".pytest_cache",
    "dist", "build", ".cache",
    ".obsidian", ".trash",
})

_NOISE_POS = {"助詞", "助動詞", "補助記号", "空白", "記号"}
_tagger: Tagger | None = None


def _get_tagger() -> Tagger:
    global _tagger
    if _tagger is None:
        _tagger = Tagger()
    return _tagger


@dataclass
class Chunk:
    id: str
    text: str
    path: str
    namespace: str


def iter_markdown(
    root: Path, extra_excludes: Iterable[str] = ()
) -> Iterable[Path]:
    excludes = _EXCLUDE_DIRS | set(extra_excludes)
    for p in root.rglob("*.md"):
        if not p.is_file():
            continue
        if any(part in excludes for part in p.parts):
            continue
        yield p


def chunk_markdown(text: str, max_chars: int = 1000) -> list[str]:
    sections = re.split(r"\n(?=#{1,6} )", text)
    chunks: list[str] = []
    for s in sections:
        s = s.strip()
        if not s:
            continue
        if len(s) <= max_chars:
            chunks.append(s)
            continue
        buf: list[str] = []
        buf_len = 0
        for para in s.split("\n\n"):
            if buf_len + len(para) > max_chars and buf:
                chunks.append("\n\n".join(buf))
                buf = [para]
                buf_len = len(para)
            else:
                buf.append(para)
                buf_len += len(para) + 2
        if buf:
            chunks.append("\n\n".join(buf))
    return chunks


def hash_id(path: str, idx: int, text: str) -> str:
    h = hashlib.sha256()
    h.update(path.encode())
    h.update(str(idx).encode())
    h.update(text.encode())
    return h.hexdigest()[:16]


def build_chunks(
    root: Path, namespace: str, extra_excludes: Iterable[str] = ()
) -> list[Chunk]:
    chunks: list[Chunk] = []
    for p in iter_markdown(root, extra_excludes):
        chunks.extend(chunks_for_file(p, namespace))
    return chunks


def chunks_for_file(file_path: Path, namespace: str) -> list[Chunk]:
    text = file_path.read_text(encoding="utf-8", errors="ignore")
    return [
        Chunk(
            id=hash_id(str(file_path), i, c),
            text=c,
            path=str(file_path),
            namespace=namespace,
        )
        for i, c in enumerate(chunk_markdown(text))
    ]


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed documents for indexing. Uses passage_embed so e5 prefixes are applied."""
    model = TextEmbedding(model_name=MODEL_NAME)
    out: list[list[float]] = []
    bar = tqdm(
        total=len(texts),
        desc="embed",
        unit="ch",
        disable=_progress_disabled(),
        file=sys.stderr,
        leave=False,
    )
    for v in model.passage_embed(texts):
        out.append([float(x) for x in v])
        bar.update(1)
    bar.close()
    return out


def _progress_disabled() -> bool:
    """Suppress progress bars when not running in a TTY or when explicitly silenced."""
    if os.environ.get("BOBRAIN_QUIET"):
        return True
    return not sys.stderr.isatty()


@contextmanager
def _phase(name: str, n: int | None = None):
    """Time a phase and print 'phase: 1.2s (N items)' to stderr on exit."""
    t0 = time.perf_counter()
    try:
        yield
    finally:
        dt = time.perf_counter() - t0
        suffix = f" ({n} items)" if n is not None else ""
        print(f"  {name}: {dt:.1f}s{suffix}", file=sys.stderr)


def tokenize(text: str) -> list[str]:
    tagger = _get_tagger()
    tokens: list[str] = []
    for w in tagger(text):
        if w.feature.pos1 in _NOISE_POS:
            continue
        lemma = getattr(w.feature, "lemma", None) or w.surface
        lemma = lemma.split("-", 1)[0]
        token = lemma.lower().strip()
        if token:
            tokens.append(token)
    return tokens


def _chunks_to_rows(chunks: list[Chunk]) -> list[dict]:
    if not chunks:
        return []
    texts = [c.text for c in chunks]
    vectors = embed_texts(texts)
    return [
        {
            "id": c.id,
            "text": c.text,
            "path": c.path,
            "namespace": c.namespace,
            "vector": v,
        }
        for c, v in zip(chunks, vectors)
    ]


def _rebuild_bm25(table, data_dir: Path) -> None:
    """Re-dump the BM25 pickle from every row currently in the LanceDB table."""
    arrow_table = table.to_arrow().select(["id", "text", "path", "namespace"])
    records = arrow_table.to_pylist()
    texts = [r["text"] for r in records]
    tokenized = [tokenize(t) for t in texts]
    bm25 = BM25Okapi(tokenized) if tokenized else None
    with (data_dir / "bm25.pkl").open("wb") as f:
        pickle.dump(
            {
                "bm25": bm25,
                "ids": [r["id"] for r in records],
                "texts": texts,
                "paths": [r["path"] for r in records],
                "namespaces": [r["namespace"] for r in records],
            },
            f,
        )


def _table_exists(db, name: str) -> bool:
    # LanceDB >= 0.30 returns a ListTablesResponse(tables=[...]) wrapper,
    # so `name in db.list_tables()` is always False. Use `.tables`.
    return name in db.list_tables().tables


def _table_vector_dim(table) -> int | None:
    """Return the declared vector dim of the chunks table, or None if unknown."""
    for field in table.schema:
        if field.name == "vector" and hasattr(field.type, "list_size"):
            return field.type.list_size
    return None


def _upsert_rows(data_dir: Path, where: str, rows: list[dict]):
    """Delete existing rows matching `where`, then insert `rows`. Returns the table."""
    data_dir.mkdir(parents=True, exist_ok=True)
    db = lancedb.connect(str(data_dir / "lancedb"))

    if _table_exists(db, TABLE_NAME):
        table = db.open_table(TABLE_NAME)
        existing_dim = _table_vector_dim(table)
        if existing_dim is not None and existing_dim != VECTOR_DIM:
            # The embedding model changed since this index was built; the old
            # FixedSizeList column can't accept new rows. Drop and let the
            # rest of this call recreate the table with the current schema.
            db.drop_table(TABLE_NAME)
        else:
            table.delete(where)
            if rows:
                table.add(rows)
            return table

    if rows:
        return db.create_table(TABLE_NAME, data=rows)
    return None


def _escape_sql(value: str) -> str:
    return value.replace("'", "''")


def build_index(
    root: Path,
    namespace: str,
    data_dir: Path,
    extra_excludes: Iterable[str] = (),
) -> int:
    """Re-index all markdown under `root` for `namespace` (other namespaces untouched)."""
    with _phase("scan"):
        chunks = build_chunks(root, namespace, extra_excludes)
    with _phase("embed", n=len(chunks)):
        rows = _chunks_to_rows(chunks)
    with _phase("db-write", n=len(rows)):
        table = _upsert_rows(
            data_dir,
            where=f"namespace = '{_escape_sql(namespace)}'",
            rows=rows,
        )
    if table is None:
        return 0
    with _phase("bm25"):
        _rebuild_bm25(table, data_dir)
    return len(chunks)


def reindex_file(file_path: Path, namespace: str, data_dir: Path) -> int:
    """Re-index a single file. Existing rows for that path (any namespace) are replaced."""
    chunks = chunks_for_file(file_path, namespace)
    rows = _chunks_to_rows(chunks)
    table = _upsert_rows(
        data_dir,
        where=f"path = '{_escape_sql(str(file_path))}'",
        rows=rows,
    )
    if table is None:
        return 0
    _rebuild_bm25(table, data_dir)
    return len(chunks)


def remove_file(file_path: Path, data_dir: Path) -> None:
    """Drop all chunks for a deleted file and rebuild the BM25 pickle."""
    db = lancedb.connect(str(data_dir / "lancedb"))
    if not _table_exists(db, TABLE_NAME):
        return
    table = db.open_table(TABLE_NAME)
    table.delete(f"path = '{_escape_sql(str(file_path))}'")
    _rebuild_bm25(table, data_dir)
