__version__ = "0.4.6"
APP_TITLE = "Adbnik"
