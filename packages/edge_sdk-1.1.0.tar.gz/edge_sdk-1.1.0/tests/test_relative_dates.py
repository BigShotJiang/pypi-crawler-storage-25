"""Tests for relative date parsing."""

from datetime import date

from edge.client.base import _parse_relative_date, BaseClient


def test_ytd():
    today = date.today()
    assert _parse_relative_date("YTD") == date(today.year, 1, 1)


def test_mtd():
    today = date.today()
    assert _parse_relative_date("MTD") == date(today.year, today.month, 1)


def test_qtd():
    today = date.today()
    q_month = ((today.month - 1) // 3) * 3 + 1
    assert _parse_relative_date("QTD") == date(today.year, q_month, 1)


def test_1y():
    today = date.today()
    result = _parse_relative_date("1Y")
    assert result.year == today.year - 1


def test_6m():
    result = _parse_relative_date("6M")
    assert result is not None
    today = date.today()
    # Should be roughly 6 months ago
    diff = (today - result).days
    assert 150 < diff < 200


def test_1w():
    result = _parse_relative_date("1W")
    today = date.today()
    assert (today - result).days == 7


def test_30d():
    result = _parse_relative_date("30D")
    today = date.today()
    assert (today - result).days == 30


def test_case_insensitive():
    assert _parse_relative_date("1y") == _parse_relative_date("1Y")
    assert _parse_relative_date("ytd") == _parse_relative_date("YTD")


def test_iso_date_returns_none():
    assert _parse_relative_date("2025-01-01") is None


def test_random_string_returns_none():
    assert _parse_relative_date("corn") is None


def test_format_date_resolves_relative():
    result = BaseClient._format_date("1Y")
    today = date.today()
    expected_year = today.year - 1
    assert result.startswith(str(expected_year))


def test_format_date_passes_iso_through():
    assert BaseClient._format_date("2025-03-15") == "2025-03-15"


def test_format_date_none():
    assert BaseClient._format_date(None) is None
