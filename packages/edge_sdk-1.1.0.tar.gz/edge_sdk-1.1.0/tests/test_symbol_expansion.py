"""Tests for bare root symbol expansion and exchange inference."""

from edge.client.base import _expand_symbol, _expand_symbols, _infer_exchange


def test_bare_root_expands():
    assert _expand_symbol("ZC") == "ZC*1"
    assert _expand_symbol("LE") == "LE*1"
    assert _expand_symbol("CL") == "CL*1"
    assert _expand_symbol("DL") == "DL*1"   # Class III Milk
    assert _expand_symbol("DK") == "DK*1"   # Class IV Milk


def test_already_qualified_unchanged():
    assert _expand_symbol("ZC*1") == "ZC*1"
    assert _expand_symbol("ZCZ26") == "ZCZ26"
    assert _expand_symbol("ZCZ26|500C") == "ZCZ26|500C"
    assert _expand_symbol("ZC*2") == "ZC*2"


def test_unknown_root_unchanged():
    assert _expand_symbol("FAKE") == "FAKE"
    assert _expand_symbol("ES") == "ES"


def test_expand_list():
    result = _expand_symbols(["ZC", "ZS", "LE"])
    assert result == ["ZC*1", "ZS*1", "LE*1"]


def test_expand_comma_string():
    result = _expand_symbols("ZC,ZS,LE")
    assert result == ["ZC*1", "ZS*1", "LE*1"]


def test_expand_mixed():
    result = _expand_symbols(["ZC", "ZS*1", "ZCZ26"])
    assert result == ["ZC*1", "ZS*1", "ZCZ26"]


def test_infer_exchange_cbot():
    assert _infer_exchange(["ZC*1"]) == "CBOT"
    assert _infer_exchange(["ZS*1"]) == "CBOT"


def test_infer_exchange_nymex():
    assert _infer_exchange(["CL*1"]) == "NYMEX"


def test_infer_exchange_cme_default():
    assert _infer_exchange(["LE*1"]) == "CME"
    assert _infer_exchange(["UNKNOWN*1"]) == "CME"


def test_infer_exchange_first_known_wins():
    # ZC is CBOT, should win even though LE is CME
    assert _infer_exchange(["ZC*1", "LE*1"]) == "CBOT"
