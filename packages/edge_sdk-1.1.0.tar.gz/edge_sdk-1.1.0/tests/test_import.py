"""Test that the package can be imported."""


def test_import():
    """Test basic package imports."""
    import edge
    from edge import Edge
    from edge.config import EdgeConfig
    from edge.exceptions import EdgeAPIError, AuthenticationError, ServiceUnavailableError

    assert hasattr(edge, "__version__")
    assert edge.__version__ == "1.0.1"
    assert Edge is not None
    assert EdgeConfig is not None
    assert EdgeAPIError is not None


def test_exception_hierarchy():
    from edge.exceptions import (
        EdgeAPIError,
        AuthenticationError,
        ConfigurationError,
        DataNotFoundError,
        ServiceUnavailableError,
        ValidationError,
    )

    assert issubclass(AuthenticationError, EdgeAPIError)
    assert issubclass(ConfigurationError, EdgeAPIError)
    assert issubclass(DataNotFoundError, EdgeAPIError)
    assert issubclass(ServiceUnavailableError, EdgeAPIError)
    assert issubclass(ValidationError, EdgeAPIError)


def test_commodities():
    from edge.commodities import COMMODITIES, infer_exchange, list_commodities

    assert "ZC" in COMMODITIES
    assert "LE" in COMMODITIES
    assert "CL" in COMMODITIES
    assert "DL" in COMMODITIES  # Class III Milk (Barchart symbol)

    assert infer_exchange("ZC*1") == "CBOT"
    assert infer_exchange("LE*1") == "CME"
    assert infer_exchange("CL*1") == "NYMEX"
    assert infer_exchange("UNKNOWN*1") == "CME"  # default

    grains = list_commodities(sector="Grains")
    assert len(grains) == 5
    dairy = list_commodities(sector="Dairy")
    assert len(dairy) == 6
