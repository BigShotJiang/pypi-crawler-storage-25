"""Static commodity registry with exchange mappings."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CommodityInfo:
    symbol: str
    name: str
    sector: str
    exchange: str


COMMODITIES: dict[str, CommodityInfo] = {
    # Grains
    "ZC": CommodityInfo("ZC", "Corn", "Grains", "CBOT"),
    "ZS": CommodityInfo("ZS", "Soybeans", "Grains", "CBOT"),
    "ZW": CommodityInfo("ZW", "Chicago SRW Wheat", "Grains", "CBOT"),
    "ZL": CommodityInfo("ZL", "Soybean Oil", "Grains", "CBOT"),
    "ZM": CommodityInfo("ZM", "Soybean Meal", "Grains", "CBOT"),
    # Livestock
    "LE": CommodityInfo("LE", "Live Cattle", "Livestock", "CME"),
    "GF": CommodityInfo("GF", "Feeder Cattle", "Livestock", "CME"),
    "HE": CommodityInfo("HE", "Lean Hogs", "Livestock", "CME"),
    # Energy
    "CL": CommodityInfo("CL", "Crude Oil (WTI)", "Energy", "NYMEX"),
    "NG": CommodityInfo("NG", "Natural Gas", "Energy", "NYMEX"),
    "RB": CommodityInfo("RB", "RBOB Gasoline", "Energy", "NYMEX"),
    "HO": CommodityInfo("HO", "Heating Oil", "Energy", "NYMEX"),
    # Dairy
    "DL": CommodityInfo("DL", "Class III Milk", "Dairy", "CME"),
    "DK": CommodityInfo("DK", "Class IV Milk", "Dairy", "CME"),
    "BJ": CommodityInfo("BJ", "Cash-Settled Cheese", "Dairy", "CME"),
    "BD": CommodityInfo("BD", "Cash-Settled Butter", "Dairy", "CME"),
    "DF": CommodityInfo("DF", "Non-Fat Dry Milk", "Dairy", "CME"),
    "DG": CommodityInfo("DG", "Dry Whey", "Dairy", "CME"),
}


def infer_exchange(symbol: str) -> str:
    """Return the exchange for a known root symbol, or ``CME`` as default."""
    root = symbol.split("*")[0].rstrip("0123456789")
    info = COMMODITIES.get(root)
    return info.exchange if info else "CME"


def list_commodities(sector: str | None = None) -> list[CommodityInfo]:
    """List known commodities, optionally filtered by sector."""
    items = list(COMMODITIES.values())
    if sector:
        items = [c for c in items if c.sector.lower() == sector.lower()]
    return items
