"""Shared type definitions for the Edge SDK."""

from __future__ import annotations

from typing import Literal, Union

from datetime import date, datetime

Interval = Literal["1m", "5m", "15m", "1h", "4h"]
SortOrder = Literal["asc", "desc"]
VolumeType = Literal["contract", "total"]

# Symbols can be passed as a single string or a list of strings.
SymbolInput = Union[str, list[str]]

# Dates accept ISO strings, date/datetime objects, or relative shorthands.
DateInput = Union[str, date, datetime, None]
