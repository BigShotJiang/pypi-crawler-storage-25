"""Custom exceptions for Edge SDK."""


class EdgeAPIError(Exception):
    """Base exception for all Edge API errors."""

    def __init__(self, message: str, status_code: int | None = None):
        self.status_code = status_code
        super().__init__(message)


class ConfigurationError(EdgeAPIError):
    """Raised when there's a configuration issue."""


class AuthenticationError(EdgeAPIError):
    """Raised when authentication fails (401)."""


class DataNotFoundError(EdgeAPIError):
    """Raised when requested data is not found (404)."""


class ServiceUnavailableError(EdgeAPIError):
    """Raised when the backend service is unavailable (503)."""


class ValidationError(EdgeAPIError):
    """Raised when request parameters fail validation (400/422)."""
