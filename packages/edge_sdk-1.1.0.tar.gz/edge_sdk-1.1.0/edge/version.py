"""Version information for edge-sdk package."""

__version__ = "1.1.0"
