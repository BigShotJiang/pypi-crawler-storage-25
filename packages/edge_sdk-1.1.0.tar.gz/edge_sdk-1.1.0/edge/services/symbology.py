"""Symbology service — wraps ``/symbology/*`` endpoints."""

from __future__ import annotations

from datetime import date

import pandas as pd

from edge.client.base import BaseClient


class SymbologyService:
    """Symbol resolution, translation, search, and validation via the
    market-data-service ``/symbology`` API."""

    def __init__(self, client: BaseClient):
        self._c = client

    def resolve(
        self,
        symbol: str,
        symbol_format: str | None = None,
        as_of: str | date | None = None,
    ) -> dict:
        """Resolve any symbol to its canonical instrument."""
        body: dict = {"symbol": symbol}
        if symbol_format is not None:
            body["symbol_format"] = symbol_format
        if as_of is not None:
            body["as_of"] = as_of if isinstance(as_of, str) else as_of.isoformat()
        return self._c._post("/symbology/resolve", json=body)

    def translate(
        self,
        symbol: str,
        to_provider: str,
        from_format: str | None = None,
        as_of: str | date | None = None,
    ) -> dict:
        """Translate a symbol to a specific provider's native format."""
        body: dict = {"symbol": symbol, "to_provider": to_provider}
        if from_format is not None:
            body["from_format"] = from_format
        if as_of is not None:
            body["as_of"] = as_of if isinstance(as_of, str) else as_of.isoformat()
        return self._c._post("/symbology/translate", json=body)

    def search(self, query: str, limit: int = 20) -> pd.DataFrame:
        """Search instruments by root, name, or ID."""
        resp = self._c._get("/symbology/search", params={"q": query, "limit": limit})
        return self._c._to_dataframe(resp.get("results", []))

    def validate(self, symbols: list[str], symbol_format: str | None = None) -> pd.DataFrame:
        """Validate a batch of symbols."""
        body: dict = {"symbols": symbols}
        if symbol_format is not None:
            body["symbol_format"] = symbol_format
        resp = self._c._post("/symbology/validate", json=body)
        return self._c._to_dataframe(resp.get("results", []))
