"""Edge SDK — Python client for the Edge market data platform."""

from .version import __version__
from .client.edge_client import Edge
from .exceptions import (
    AuthenticationError,
    ConfigurationError,
    DataNotFoundError,
    EdgeAPIError,
    ServiceUnavailableError,
    ValidationError,
)

__all__ = [
    "__version__",
    "Edge",
    "EdgeAPIError",
    "AuthenticationError",
    "ConfigurationError",
    "DataNotFoundError",
    "ServiceUnavailableError",
    "ValidationError",
]
