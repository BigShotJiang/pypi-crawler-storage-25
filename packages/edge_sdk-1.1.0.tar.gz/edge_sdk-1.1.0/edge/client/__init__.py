"""Edge API Client module."""

from .base import BaseClient

__all__ = ["BaseClient"]
