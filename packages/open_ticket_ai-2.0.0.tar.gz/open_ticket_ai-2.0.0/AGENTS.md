# Agent Guidelines for Open Ticket AI

This document is **authoritative**. Follow these rules strictly when adding, moving, or generating files.

> **Runtime docs landing:** [`docs/index.md`](./docs/index.md). Internal
> Markdown documentation for the Runtime project lives there
> (architecture, ops notes, internal references). The customer-facing
> Astro/Vue website also lives under `docs/` at the website level — see
> the convention note below.

> **Important:** The Astro/Vue website and all docs live under the `/docs` directory. Any instructions mentioning "website", "docs", Astro, or Vue components refer to files inside `docs/`.

The Astro Website is in the /docs directory!
So when I am refering to a website Astro or Vue Components to change or Pages to change.
I am speaking about the content in the /docs folder!

## Information on Python Open Ticket Automation Platform (NOT FOR WEBSITE)
### Repository Layout

The repo is a single Python package — no workspace, no plugins.

```
open-ticket-ai/
├── src/
│   └── open_ticket_ai/            # all application code
│       ├── core/                   # base abstractions (Pipe, TicketSystemService, etc.)
│       ├── pipes/                  # pipe implementations (composite, classification, orchestrators, etc.)
│       ├── hf_local/               # HuggingFace local classification service
│       ├── otobo_znuny/            # OTOBO/Znuny ticket system connector
│       ├── zammad/                 # Zammad ticket system connector
│       ├── api/                    # FastAPI REST API
│       ├── pipeline.py             # pipe tree construction
│       ├── settings.py             # env-var driven settings
│       ├── main.py                 # entry point
│       └── workflow_manager.py     # background workflow management
├── tests/                          # all tests
│   ├── unit/                       # fast isolated tests
│   ├── integration/                # I/O and cross-component tests
│   ├── e2e/                        # end-to-end flows
│   └── conftest.py                 # shared fixtures
├── pyproject.toml                  # project config
```

#### Absolute rules

- **Never** place tests under any `src/` path. Forbidden: `src/**/tests`, `src/**/test_*.py`.
- All unit tests in `tests/unit/`.
- Integration/e2e tests in `tests/integration/`, `tests/e2e/`.
- Keep sample inputs/golden files under a sibling `data/` directory next to the tests that use them.
- Python version: **3.14** only. Use modern typing (PEP 695). No code comments.

### Tests Layout (required)

```
tests/
├── unit/
│   ├── core/            # core module tests
│   ├── pipes/           # pipe implementation tests
│   ├── hf_local/        # HF classification tests
│   ├── otobo_znuny/     # OTOBO/Znuny tests
│   └── conftest.py
├── integration/
│   └── zammad/          # Zammad live integration tests
├── e2e/                 # CLI/app-level
├── data/
└── conftest.py          # shared fixtures
```

#### Naming rules

- Test files: `test_*.py` only.
- Keep fixtures in `conftest.py` or `tests/**/fixtures_*.py` (no global helper modules under `src/`).
- **NO** `__init__.py` files in test directories. Test directories are not Python packages.

#### Fixture guidelines

- Check existing fixtures before creating new ones: `uv run -m pytest --fixtures`
- Follow naming conventions: `mock_*`, `sample_*`, `tmp_*`, `empty_*`, `*_factory`

### Pytest configuration (root `pyproject.toml`)

### How to run

- From repo root:
    - `uv sync`
    - `uv run -m pytest` (all tests)
    - `uv run -m pytest tests/unit` (unit tests only)

### CI / Quality gates

- Lint: `uv run ruff check .` (no warnings allowed)
- Types: `uv run mypy .` (no ignores added without justification in PR)
- Tests: `uv run -m pytest`
- No test files under `src/**` will be accepted. PRs that create them must be changed.

#### Copilot PR Automation

The `.github/workflows/copilot-pr-retry.yml` workflow automatically handles PRs created by `github-copilot[bot]`. When checks fail, it labels the PR with `retry-needed` and `copilot-pr`, comments with failure details, and closes the PR to enable retry. This only affects Copilot bot PRs.

### Architectural expectations (short)

- Prefer composition and DI (Injector) over inheritance.
- Pydantic v2 for data models; explicit type annotations everywhere.
- No monkey patching; avoid reflection “magic.”
- Documentation in Markdown (VitePress), not as docstrings or comments in code.

### Documentation Structure

All documentation lives in `/docs` directory.

## Website/Docs Component System (Astro + Vue)

The customer-facing website lives in `/docs` and uses:
- **Astro** for static site generation
- **Vue 3** for interactive components
- **Storybook** for component development
- **Tailwind CSS** with custom design tokens

### Transition System

**Location**: `docs/src/components/vue/core/transitions/`

**When to Use**:
- Dialog/Modal, Menu, Popover, Dropdown, Toast, Slide-over panels (required)
- Accordion (optional; collapse is tricky, prefer no animation unless needed)

**Choosing Transitions**:
- **Default**: `UiTransitionFadeScale` with `strength='sm'` for panels/dialogs
- **Backdrops**: `UiTransitionFade`
- **Menus**: `UiTransitionSlide direction='down'`
- **Slide-overs**: `UiTransitionSlide direction='left'` or `'right'`
- **Toasts**: `UiTransitionSlide direction='up'`

**Usage Example**:
```vue
<TransitionRoot :show="isOpen" as="template">
  <UiTransitionFade>
    <div class="fixed inset-0 bg-black/80" />
  </UiTransitionFade>
  <UiTransitionFadeScale strength="sm">
    <DialogPanel>...</DialogPanel>
  </UiTransitionFadeScale>
</TransitionRoot>
```

**Rules**:
- All presets include `motion-reduce` support; never remove these classes
- Always reuse presets/wrappers; never hand-write transition strings
- For custom needs, import presets: `import { fadeScaleSm } from './presets'` and use with `v-bind`

---

## Checklist for contributors (must pass) (When making Python changes, NOT website changes)

- [ ] New unit tests added under `tests/unit/`
- [ ] No files under any `src/**/tests`
- [ ] Root-level integration/e2e tests only in `tests/`
- [ ] No `__init__.py` in any test directories
- [ ] Check existing fixtures before creating new ones
- [ ] `uv run ruff check .` clean
- [ ] `uv run mypy .` clean
- [ ] `uv run -m pytest` green

## Checklist for contributors (must pass) (When making Website/Docs changes in /docs)

- [ ] Run `npm run format` in the `/docs` directory to format all files with Prettier
- [ ] Run `npm run format:check` to verify all files are formatted correctly
- [ ] Run `npm run lint` to check for ESLint issues
- [ ] Run `npm run lint:fix` to auto-fix ESLint issues
