---
name: nw-competitive-positioning
description: Comparative methodology for positioning nWave against ECC, Superpowers, Gas Town, Cursor, Aider, Continue.dev using Dunford's 5-component positioning framework. Evidence-based — every comparison cell cites a source. Identifies and avoids the feature-without-value-anchor anti-pattern.
user-invocable: false
disable-model-invocation: true
---

# Competitive Positioning

Position nWave against named competitors using evidence-based comparison only — every cell in the matrix cites a source and a date. Apply Dunford's 5-component positioning sequence [F6.3] rather than feature-led pitching. Avoid speculation about competitor roadmaps.

## Core principles (research-anchored)

1. **Positioning precedes messaging** [F6.3]. Dunford [25]: "Storytelling, messaging, a tag line, your vision, branding — these are all examples of things that happen after positioning. Each of these things requires positioning as an input." Pitch wording without positioning analysis is premature.
2. **Compete on differentiated value, not feature count** [F6.3]. Dunford [24]: positioning starts with "Competitive Alternatives" and asks "What do we have that the alternatives do not?" → "What is the value those capabilities enable?" Feature lists divorced from value are the canonical failure mode.
3. **Feature without value-anchor = "Anything you want!"** [F6.3]. Dunford [24] verbatim: she recounts demoing a feature where "when customers asked us what they would do with that feature, our reply was 'Anything you want!'" — naming feature-without-value-anchor as a positioning failure.
4. **Pitch frame correlates with star velocity (weak signal)** [F4.1-F4.6]. Outcome-first and performance-first pitches cluster at higher star counts than methodology-first pitches in the 2026-05-09 snapshot. Caveat: stars are vanity; retention data is not in this evidence set.
5. **Conceptual surface area is install friction at concept layer** [F4.2, F4.3]. Superpowers ships 6 concepts behind 1 install line; nWave ships ~10+ concepts behind ~3 install stages. Both reduce trial conversion.

## Dunford 5-component positioning framework [F6.3]

Source: [24, 25] — primary author, two cross-referencing essays on aprildunford.com. Confidence: **High** after 2026-05-13 follow-up retrieval.

| Component | Dunford verbatim question | nWave answer (illustrative) |
|-----------|---------------------------|------------------------------|
| 1. Competitive Alternatives | What would the user do if our product didn't exist? | (a) Cursor/Aider for IDE-coupled AI; (b) ECC for skill optimization; (c) Superpowers for methodology-light skills; (d) hand-rolled CLAUDE.md + adhoc TDD |
| 2. Differentiated Features or Capabilities | "What do we have that the alternatives do not?" | Closed-loop wave methodology end-to-end (DISCOVER → DELIVER); DES deterministic enforcement; peer-review agents per specialist; mutation-testing tier |
| 3. Value for customers | "What is the value those capabilities enable?" | Production-grade discipline preserved under AI velocity: "the AI does most of the typing; you remain responsible for quality" [F6.1] |
| 4. Target Customer Segmentation | "Who are the customers that care a lot about our value?" | AI-era craftsmen (10+ years experience, valuesystem-uncertain under AI); enterprises/defense/government with discipline-grade requirements |
| 5. Market Category | "What market category makes our value obvious?" | Executable software-engineering methodology for AI-assisted development (parallel to Fowler's progressive design [F6.2]) |

Core definition [25]: "Positioning defines how your product is a leader at delivering something that a well-defined set of customers cares a lot about."

## Comparison matrix (2026-05-09 snapshot)

Sources: [4]-[9] retrieved 2026-05-09. Every cell cites source-and-date.

| Tool | Pitch frame | Pitch first words | Install lines | Concepts to learn | Stars |
|------|-------------|-------------------|---------------|-------------------|-------|
| nWave | Methodology-first | "Disciplined software development waves" | ~3 (pipx install + setup stages) | ~10+ (23 agents, 21 cmds, 98 skills, 6 waves, TDD 3-phase canon, DES, hex arch) | ~500 |
| ECC [4] | Performance-first | "Performance optimization system for AI agent harnesses" | 2 (`/plugin marketplace add` + `/plugin install`) | Hidden — agents activate automatically | 140,000+ |
| Superpowers [5] | Methodology-first | "Agentic skills framework & software development methodology that works" | 1 (`/plugin install superpowers@claude-plugins-official`) | 6 (skills, phases, TDD red-green-refactor, subagent delegation, git worktrees, systematic verification) | 189,000 |
| Gas Town [6] | Orchestration-first | "work persists in git-backed hooks, enabling reliable multi-agent workflows" | 4+ prereqs (Go, Git, Dolt, beads, tmux) | ~5 (agents, mailboxes, identities, handoffs, persistence) | 15,100 |
| Cursor [7] | Outcome-first | "Extraordinarily productive" | 1 (download) | ~3 (autocomplete, agent, chat) | commercial |
| Aider [8] | Outcome-first | "AI pair programming in your terminal" | 2 + API key | 4 (LLM choice, API key, codebase context, pair-programmer model) | OSS |
| Continue.dev [9] | Outcome-first | "Quality control for your software factory" | GitHub auth | n/a (auto) | commercial |

### Pitch frame taxonomy [F4.1-F4.6]

- **Outcome-first**: Cursor, Aider, Continue.dev. Leads with what the user gets.
- **Performance-first**: ECC. Leads with optimization/measurement framing.
- **Methodology-first**: Superpowers, nWave today. Leads with the discipline/method.
- **Orchestration-first**: Gas Town. Leads with multi-agent coordination as the differentiator.

## Position gap analysis (nWave today)

Applying Dunford [24]: nWave's pitch leads with **mechanism** (waves, agents, DES, TDD) — i.e. component 2 (differentiated features) without anchoring component 3 (value). This is the exact "Anything you want!" failure mode Dunford names [24].

Reposition direction (hypothesis — needs A/B test):
- Against ECC: "production discipline, not just optimization" — different value anchor for the same customer (AI-era developer).
- Against Superpowers: "full-wave methodology with DES enforcement + peer-review-per-specialist, not just composable skills" — different customer segment (craftsmen requiring auditable discipline vs hobbyist seeking lightweight workflow).
- Against Cursor: not a direct competitor — Cursor sells the IDE, nWave sells the methodology. The pitch should clarify the non-overlap.

## Star-velocity hypothesis (weak signal)

In the 2026-05-09 snapshot, outcome-first + low-concept pitches correlate with higher star counts:

- Cursor (commercial, outcome-first, ~3 concepts)
- ECC (140K, performance-first, hidden concepts)
- Superpowers (189K, methodology-first but only 6 concepts)
- nWave (~500, methodology-first, ~10+ concepts)

Caveats [F4 counter-evidence]: stars are vanity; not direct adoption metric. Superpowers' 189K stars may reflect agentic-coding hype, not sustained MAU. Independent retention/usage data not located. Treat star-velocity as a proxy with caveat, not as conclusive.

## Methodology rules

1. Every cell in the comparison matrix cites source + date.
2. No comparison of competitor roadmaps (unverified by definition).
3. Token-cost comparisons require same-task empirical probe (the D13 probe is N=1 robust per the research file — cite explicitly).
4. Stars count is a weak signal — pair with growth-rate or retention data when available.
5. Pitch wording quoted verbatim, with retrieval date.

## Anti-patterns

1. **Feature-without-value-anchor pitch** [F6.3]. Listing capabilities without naming the value Dunford asks "What is the value those capabilities enable?" — if your pitch can't answer, the pitch is in the failure mode.
2. **Skipping positioning, jumping to messaging** [F6.3 verbatim 25]. Writing tag-lines / hero copy without first running the 5-component analysis.
3. **Competitor-roadmap speculation**. "ECC will probably add X" — unverifiable, drops review confidence.
4. **Stars-as-success-metric**. Optimizing for stars optimizes for hype-cycle visibility, not retention. Star data is acceptable as a weak proxy, not as a target.
5. **Internal nWave-dev metrics in public comparison**. Memory rule 2026-04-30: never cite internal repo paths, token counts, or operational data in user-facing competitive analysis.

## Confidence flags

- Dunford 5-component framework [F6.3]: **High confidence** after 2026-05-13 follow-up. [24] + [25] both primary author essays cross-referencing each other.
- Competitor matrix [F4.1-F4.6]: **High confidence on pitch wording, install lines, concepts** (primary repo/landing pages). **Lower confidence on stars** (snapshot date 2026-05-09; numbers drift).
- Star-velocity hypothesis: **Hypothesis-grade only** — correlation observed in this snapshot, not validated experimentally. Pair with retention data when available before treating as causal.

## References

[4] github.com/affaan-m/everything-claude-code
[5] github.com/obra/superpowers
[6] github.com/gastownhall/gastown
[7] cursor.com
[8] aider.chat
[9] continue.dev
[21] aprildunford.com
[24] Dunford — A Quickstart Guide to Positioning. https://aprildunford.com/post/a-quickstart-guide-to-positioning
[25] Dunford — An Introduction to Positioning. https://aprildunford.com/post/an-introduction-to-positioning
