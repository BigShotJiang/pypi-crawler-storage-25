---
name: nw-onboarding-design
description: Diegetic teaching patterns (Stripe 4242, Vercel git push) and progressive disclosure applied to developer-tool onboarding. Targets sub-60s TTV. Documents when diegetic teaching applies and when explicit prompts are appropriate (post-2010 Yeoman → Vite shift).
user-invocable: false
disable-model-invocation: true
---

# Onboarding Design

Design onboarding interventions that respect Vision Principle 4 (zero added runtime tokens where possible) and surface the AI-era epistemic-reassurance message in-flow rather than behind a wall of pre-reading. Default to diegetic teaching: the user performs the real action with a low-stakes literal and the system reciprocates with the value.

## Core principles (research-anchored)

1. **Show ANY win fast; reveal killer value progressively** [F1.1, F5.1]. Stripe [1] and Vercel [3] both deliver a visible system response within seconds of a real user action. The first win is small; the value is revealed by repetition and depth.
2. **Diegetic > tutorial-mode** [F5.1, F5.2]. Teaching embedded in production surfaces beats teaching in a separate "tutorial mode" because it avoids the bifurcation cost (user must context-switch back to real work).
3. **Concepts are introduced lazily, only when the next step requires them** [F2.1 H8, F5.3]. Concept-first onboarding gates productive action behind acquisition; nWave currently inverts the pattern [F5.3].
4. **Target TTV ≤ 60 seconds** [F1.1, F5.1]. Below this threshold the user's curiosity carries them through small frictions; above it, the trial cohort drops off [F1.2].
5. **Tutorial-mode is appropriate only for genuine conceptual-model shifts** — and even then, post-2010 ecosystem evidence (Yeoman → Vite) suggests zero-config wins over explicit-prompts tutorials.

## Diegetic teaching — canonical patterns

### Stripe test card [F5.2, F1.1]

Source [1] verbatim: "When testing interactively, use a card number, such as 4242 4242 4242 4242. Enter the card number in the Dashboard or in any payment form."

Mechanics:
- Card accepts any CVC, any future expiry.
- Inline in the "Testing interactively" section — not a separate tutorial.
- User uses the production-surface form with a test literal.
- System reciprocates with the production behavior (charge confirmation).

Why it works: the lesson "this is how you charge a card" is delivered via the action of charging a test card. No "tutorial step 1..N". The friction of synthesizing test data is removed.

### Vercel git push → URL [F5.1]

Source [3] verbatim: "Vercel allows for automatic deployments on every branch push and merges onto the production branch of your GitHub, GitLab, and Bitbucket projects."

Mechanics:
- User performs an action they already know (`git push`).
- System reciprocates with the user's win condition (live URL).
- All concepts (preview deployments, branch tracking, production branch) are inferred from the surface — not pre-taught.
- TTV: first push → first URL is typically < 60s after project import.

Why it works: the existing mental model (push to deploy) is the affordance. No new vocabulary required before first value.

### Replit fork [F5.2]

Source [9] (cross-ref to ecosystem norm): one-click fork delivers a running environment in the same surface as the code. Zero install. Lesson is delivered by the artifact itself.

## When diegetic fails — Yeoman → Vite shift

Post-2010 ecosystem evidence: Yeoman generators relied on explicit interactive prompts ("what name? what license? what test runner?"). Vite and similar zero-config tools eclipsed Yeoman in npm download share by adopting sensible defaults + lazy configuration.

Lesson: when teaching requires interactive prompts at install time, the diegetic primitive has failed. The fix is **better defaults**, not better prompts.

Confidence flag: primary citation for Yeoman → Vite shift (State of JS surveys, npm-trends data) NOT retrieved in the 2026-05-09 research pass — flagged as gap in research file. Treat this section as **Medium confidence** anchored on ecosystem-pattern observation, not retrieved data.

## Progressive disclosure for developer tools

| Phase | Goal | Surface area |
|-------|------|--------------|
| First touch (≤60s) | One small win the user keeps | Minimum: 1 command, 1 artifact, 0 new vocabulary |
| First session (≤30min) | Sketch the value model | Reveal 2-3 core concepts, in the context of the user's first artifact |
| First week | Calibrate confidence | Expose feature surface on demand (autocomplete, in-context help, not menu nesting) |
| Expansion | Team / advanced | Full feature surface available via flat command space |

Hick's law applicability: decision time grows logarithmically with number of options. Flat command spaces beat menu hierarchies at this scale. Primary Hick's-law citation NOT retrieved in 2026-05-09 research — flag as **Medium confidence reference**.

## nWave inversion — the current anti-pattern [F5.3]

Source [F5.3 + Eldon [22] + Tsvetan Discord]: nWave's onboarding requires reading multi-section CLAUDE.md, learning wave sequence DISCOVER → DELIVER, understanding agent dispatch grammar, and configuring DES hooks BEFORE the user's first productive action. The first useful output (running a wave, dispatching an agent) is gated behind concept acquisition.

Verbatim Tsvetan Discord: "massively complex for newcomers."

This inverts the Stripe/Vercel pattern (action-first, concepts inferred). It is the structural cause of the ECC vs nWave star gap [F4.1].

Confidence flag: F5.3 specifically (the "nWave inverts the pattern" claim) is **Medium confidence** — grounded in Discord touchpoints + Eldon interview, both internal sources. The general principle (diegetic > tutorial-mode) is **High confidence** via Stripe + Vercel primary sources. Mark inline accordingly when proposing interventions.

## Redesign primitives for nWave (illustrative — not committed)

1. **First-command produces an artifact the user keeps** — not a status message. The artifact IS the value.
2. **Configuration via discovery, not interrogation** — `/nw-init` for brownfield (per Vel's Discord ask) should scan the repo and propose, not prompt for, configuration. Sensible defaults.
3. **Concept introduction lazy** — show only the concept needed for the next step. Don't introduce "wave methodology" before the user has finished one wave.
4. **In-flow epistemic reassurance** [F6.4] — surface "this is the discipline that stops AI from deleting tests to make them pass" at the moment AI would have done so. Not in a tutorial preamble.

## Anti-patterns

1. **Concept-first onboarding** [F5.3]. Required pre-reading gates productive action. Violates Nielsen H10 [2] ("It's best if the system doesn't need any additional explanation.")
2. **Tutorial-mode bifurcation** [F5.1, F5.2]. Separate "learn mode" the user must exit to do real work. Even when the tutorial is well-designed, the context-switch cost erodes TTV.
3. **Mandatory-prompt configuration** (Yeoman pattern). Interactive prompts at install time. Replace with sensible defaults + lazy reveal.
4. **Popup tooltips / coach-marks at first launch**. Adds tokens (verbosity), interrupts the user's first action, and is forgotten before relevance arises.
5. **"MUST USE" framing in onboarding copy**. Aggressive imperative framing is the disease being cured for the AI-era craftsman audience [F6.4]. Direct affirmative statements only.
6. **TTV > 60s with no compensating differentiation**. Acceptable only when the unmet need cannot be satisfied by alternatives (Kubernetes pattern); does not apply to nWave today.

## Confidence flags

- Stripe [1] **High confidence** — official primary source.
- Vercel [3] **High confidence** — official primary documentation.
- F5.3 (nWave-specific inversion claim) **Medium confidence** — internal sources; general principle is High.
- Yeoman → Vite ecosystem shift: **Medium confidence reference** — primary citation not retrieved (State of JS, npm-trends gap surfaced in research file).
- Hick's law CLI application: **Medium confidence reference** — primary citation not retrieved.
- Game-design tutorial citations (Schell, Koster, Mario 1-1): **NOT cited** — game-design references explicitly flagged out-of-scope in research pass.

## References

[1] Stripe — Testing. https://docs.stripe.com/testing
[3] Vercel — Deploying Git Repositories. https://vercel.com/docs/git
[9] continue.dev
[22] Eldon Ferran de Pol interview, nWave-internal, 2026-05-09.
