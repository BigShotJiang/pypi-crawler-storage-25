---
name: nw-pitch-optimization
description: AI-era epistemic-reassurance pitch framing for craftsman audiences. Combines Beck's "augmented coding" anchor [F6.1], Fowler's progressive-design alignment [F6.2], Dunford's 5-component positioning [F6.3], and the Eldon buyer-voice gap [F6.4]. Surfaces hypothesis-grade pitch candidate for A/B testing — not settled copy.
user-invocable: false
disable-model-invocation: true
---

# Pitch Optimization

Optimize nWave's pitch for the AI-era craftsman audience using Beck's "augmented coding" framing as primary anchor, Fowler's progressive-design as structural alignment, and Dunford's 5-component positioning as the order-of-operations. The buyer-voice anchor is the Eldon transcript [22]: "Alex is so far ahead of us that he has better reasons for why we should continue to value it. Than we do yet." The pitch must supply those reasons compactly, in the buyer's own vocabulary.

## Core principles (research-anchored)

1. **Anchor on Beck's "augmented coding"** [F6.1]. Three sources [15, 16, 17] cross-reference the same framing. Pitch nWave as the **executable methodology** for what Beck describes. Quote Beck directly when load-bearing.
2. **Align structurally with Fowler's progressive design** [F6.2]. Three Fowler articles [18, 19, 20] describe "capabilities → components → interactions → contracts → implementation" — which IS the nWave wave sequence. Pitch the structural alignment.
3. **Apply Dunford 5-component sequence before drafting copy** [F6.3]. Dunford [25]: "Storytelling, messaging, a tag line, your vision, branding — these are all examples of things that happen after positioning." Pitch wording without positioning is premature.
4. **Surface AI-context-specific reasons, not generic methodology endorsement** [F6.4]. The buyer (Eldon, AI-era craftsman) wants AI-context-specific reasons their craft applies, not "TDD is good." Reasons must be compact.
5. **Hypothesis-grade copy needs A/B test, not commit** [F6.1, F6.4]. Eldon is N=1 qualitative. Beck's framing is recent (2024-25) and blog-tier. Treat candidate pitch as hypothesis to validate, not settled positioning.

## Beck's augmented-coding framing [F6.1]

Sources [15, 16, 17] — three independent references converging on the same Beck framing. Confidence: **High** (Beck is primary author + cited speaker at GOTO Copenhagen 2024).

Beck verbatim definition [15, 16]: **augmented coding** = "keeping traditional software engineering values while using AI assistance, caring about readable code, manageable complexity, good test coverage, solid architecture, and systems that can be maintained. The AI does most of the typing, but you're still responsible for the quality being equivalent to hand-written work."

Beck on TDD specifically [15]: TDD is "a superpower when working with AI agents" because tests stop AI regressions. Documented failure mode: "having trouble stopping AI agents from deleting tests in order to make them 'pass!'"

Beck's BPlusTree3 project [15]: production-grade B+ tree in Python and Rust, used to document the augmented-coding methodology.

### nWave value-prop in one sentence (Beck-anchored)

Hypothesis-grade — needs A/B test:

> *The test discipline that stops the AI from deleting tests to make them pass.*

This phrasing draws directly from Beck's documented failure mode [15]. It is one of three pitch candidates; not yet validated.

## Fowler progressive-design alignment [F6.2]

Sources [18, 19, 20] — Martin Fowler primary author, three cross-referencing articles on martinfowler.com.

Fowler verbatim [18]: "Rather than asking AI to immediately produce code, walk through progressive levels of design: capabilities, components, interactions, contracts, and only then implementation. The patterns require discipline to sustain. The same discipline applies to AI."

Mapping to nWave waves:

| Fowler stage | nWave wave |
|--------------|------------|
| Capabilities | DISCOVER (opportunity + evidence) |
| Components / interactions | DISCUSS / DESIGN |
| Contracts | DISTILL (acceptance tests as contracts) |
| Implementation | DELIVER (Outside-In TDD) |

Pitch framing: nWave is **the executable version of Fowler's progressive-design pattern**. Fowler describes the discipline; nWave encodes it so the developer doesn't have to re-derive it per session — saving cognitive bandwidth [18].

Fowler's three required skills [19] (Thoughtworks SPDD): **alignment, abstraction-first, iterative review**. These map to nWave's wave structure + peer-review-per-specialist + DES enforcement.

## Dunford 5-component positioning [F6.3]

Source: [24, 25]. See `nw-competitive-positioning` for the full 5-component table. Pitch implication: run the 5-component analysis BEFORE writing pitch copy.

Verbatim anti-pattern [24]: Dunford recounts a feature she showed "in every demo" where "when customers asked us what they would do with that feature, our reply was 'Anything you want!'" — naming feature-without-value-anchor as the failure mode.

Application to nWave: current pitch leads with mechanism (waves, agents, DES, TDD) — i.e. Dunford's component 2 (differentiated features) without component 3 (value). This is the exact "Anything you want!" failure mode.

Reposition direction: lead with the value Beck names + the discipline-under-AI promise + the AI-context-specific reasons (per the buyer voice below). Mechanism is a supporting detail, not the headline.

## Buyer voice — Eldon interview [F6.4]

Source [22]: Eldon Ferran de Pol interview, 2026-05-09 (~60 min). Confidence: **High as qualitative N=1 datum; not generalizable beyond pattern-hypothesis.**

Verbatim (load-bearing, ~14:48-14:53):

> "We need to come to the conclusion that most of the practices that we have valued for 20 years apply just as much as they always have done. But we are going through the process of questioning ourselves. (...) Alex is so far ahead of us that he has better reasons for why we should continue to value it. Than we do yet."

Analysis: the pitch frame is **NOT** "learn this new methodology" but **"the methodology you already practice, now executable under AI."** Eldon's quote IS the buyer's articulation of the Knowledge-fit positioning gap [F3.2]: he agrees the values hold under AI, but doesn't yet have the *reasons-why*. The pitch must supply those reasons compactly.

## AI-context-specific reasons to surface

The craftsman audience wants reasons that are specifically about AI failure modes — not generic TDD/craftsmanship endorsement. Candidate reasons (sourcing notes inline):

| Reason | What AI amplifies | How nWave addresses it | Source confidence |
|--------|-------------------|------------------------|---------------------|
| Test theater | LLMs write tests that look right but pass on broken code | nWave enforces test-first + acceptance-as-truth (memory rule [feedback_acceptance_tests_are_truth]) | **Medium** — internal memory rule, not external citation |
| Dark code (unused/unreachable) | LLMs generate at scale | nWave's contract tests + acceptance gates | **Medium** — internal claim, needs primary citation |
| Mutation-killing scope | LLMs miss mutations a human reviewer catches | nWave's mutation testing tier | **Medium** — internal claim |
| AI deleting tests to make them pass | Documented Beck failure mode [15] | nWave's DES + peer-review agents | **High** — Beck [15] primary source |

Confidence flag on "80 AI-amplified smells" framing: **NO primary source retrieved** in the 2026-05-09 research pass. Do not include "80 smells" in pitch copy as a concrete number until a primary citation exists. The qualitative claim (AI amplifies smells that scale with volume) is defensible; the specific count is not.

## Pitch wording skeleton

Structure:
1. **Headline**: AI-context-specific value claim (one sentence). Beck-anchored if possible.
2. **Sub**: epistemic reassurance for the craftsman (one sentence) — supplies the "reasons-why" the buyer wants.
3. **Three reasons** (≤1 line each) + one-link-each evidence (Beck blog, Fowler article, mutation-testing skill).
4. **Single call-to-action** — install command verbatim, ≤80 characters.

### Candidate headline + sub (hypothesis-grade, A/B-testable)

> **nWave: the executable methodology for production-grade AI-assisted coding.**
>
> *The discipline of TDD, peer review, and progressive design — enforced for you, so AI accelerates without eroding quality.*

Source-decomposition for this candidate:
- "executable methodology" — researcher inference (~25% — needs validation; nWave-specific framing).
- "production-grade AI-assisted coding" — Beck's "augmented coding" [15, 16, 17] (~50% solidly grounded).
- "discipline of TDD, peer review, progressive design — enforced for you" — Beck [15] + Fowler [18] (~25% solidly grounded).
- "AI accelerates without eroding quality" — Beck verbatim [15]: "the AI does most of the typing, but you're still responsible for the quality."

Confidence: **Hypothesis-grade only.** ~75% of the wording draws from cited primary sources; ~25% is researcher inference. The phrasing should be validated against the Eldon-cohort buyer voice (N≥5 craftsmen interviews) before commit to landing page.

## Forbidden framings (anti-patterns)

1. **"MUST USE" / "CRITICAL" / "ABSOLUTE" / "ENTERPRISE-GRADE"** — aggressive imperative framing repels the AI-era craftsman audience [F6.4]. Memory rule (nWave anti-pattern): the framing is the disease being cured.
2. **"Disciplined TDD" without AI-context reason** — generic methodology endorsement. The buyer already values discipline; what they need is AI-context-specific reason it still applies [F6.4].
3. **Long feature list without prioritization** — Krug "don't make me think" violation; Dunford "Anything you want!" anti-pattern [F6.3].
4. **Internal nWave-dev metrics quoted publicly** — memory rule 2026-04-30. Use absolute or industry-norm framing instead.
5. **Tag-line before positioning analysis** [F6.3]. Dunford [25]: "Each of these things requires positioning as an input." Run the 5-component analysis first; draft copy after.
6. **Premature numeric anchors** — e.g. "80 AI-amplified smells" without primary citation. Qualitative claim survives; specific count requires source.

## Confidence flags (summary)

- Beck "augmented coding" [F6.1]: **High** — three sources [15, 16, 17], Beck primary author.
- Fowler progressive design [F6.2]: **High** — three primary articles [18, 19, 20].
- Dunford 5-component [F6.3]: **High** — primary essays [24, 25] retrieved 2026-05-13.
- Eldon buyer voice [F6.4]: **High as N=1 qualitative**; pattern-hypothesis until N≥5 cohort.
- Candidate pitch wording: **Hypothesis-grade only** — needs A/B test on landing page; ~75% sourced, ~25% researcher inference.
- "80 smells" specific count: **NOT cited** — do not use as concrete number in copy.

## References

[15] Pragmatic Engineer — TDD, AI agents and coding with Kent Beck. https://newsletter.pragmaticengineer.com/p/tdd-ai-agents-and-coding-with-kent
[16] SoftwareSeni — Augmented Coding. https://www.softwareseni.com/augmented-coding-the-responsible-alternative-to-vibe-coding/
[17] GOTO Copenhagen 2024 — Kent Beck. https://gotocph.com/2024/speakers/3628/kent-beck
[18] Fowler — Patterns for Reducing Friction in AI-Assisted Development. https://martinfowler.com/articles/reduce-friction-ai/
[19] Fowler — Structured-Prompt-Driven Development. https://martinfowler.com/articles/structured-prompt-driven/
[20] Fowler — Exploring Generative AI. https://martinfowler.com/articles/exploring-gen-ai.html
[21] aprildunford.com
[22] Eldon Ferran de Pol interview, nWave-internal, 2026-05-09.
[24] Dunford — A Quickstart Guide to Positioning. https://aprildunford.com/post/a-quickstart-guide-to-positioning
[25] Dunford — An Introduction to Positioning. https://aprildunford.com/post/an-introduction-to-positioning
