---
name: nw-adoption-funnel-analysis
description: Methodology for classifying adoption-friction evidence by funnel stage, selecting a behavior-grounded aha-moment (not a vanity metric), applying Balfour's Four Fits framework, and structuring friction-log records. Anchors interventions to verified pain location.
user-invocable: false
disable-model-invocation: true
---

# Adoption Funnel Analysis

Classify each piece of adoption-friction evidence by funnel stage and root cause before recommending intervention. Pain location anchors intervention location. Aha-moment selection must be causal (behavior shift correlates with retention), not correlational. Source-cite every TTV threshold and aha-moment candidate.

## Core principles (research-anchored)

1. **Locate pain in the funnel before sizing intervention** [F3.2]. Pre-retention pain is solved by pitch/onboarding; mid-retention pain is solved by feature work. Misplaced interventions miss the user population.
2. **Aha-moment must be behavior-grounded, not number-grounded** [F3.1, F3.3]. The "7 friends in 10 days" pattern is a behavior shift (social-graph density), not the number itself. Three independent industry sources (Mixpanel [14], Amplitude [26, 27], Reforge [28]) converge on: correlation is not causation.
3. **Validate aha-moment candidates experimentally** [F3.3]. Reforge prescribes: "run experiments to see if increasing the percentage of users hitting that moment increases their retention rate" [28]. Observed correlation alone is insufficient.
4. **All four fits must align to grow** [F1.2, F3.2]. Balfour [23]: "You need all four fits to align to be able to grow into a $100M+ company in a venture backed timeframe." Top-level fits are Market-Product, Product-Channel, Channel-Model, Model-Market. Single-axis pivots fail because "when you change one component within the framework, you need to revisit and change the rest" [23].
5. **TTV target sub-60s for first useful output** [F1.1, F5.1]. Stripe [1] and Vercel [3] set the diegetic benchmark — the user does a real action with a low-stakes literal and gets the system's value back inside a minute.
6. **Founder-only evidence is N=0 for funnel purposes**. Founder's own opinion is generating-hypothesis-grade, not validating-hypothesis-grade. Probe-first before sizing.

## Funnel stage methodology

| Stage | Definition | Signal type | Evidence shape |
|-------|------------|-------------|----------------|
| pre-discovery | User has not heard of product | counterfactual only | survey + analog-tool usage data |
| discovery | Has seen pitch, not tried | scope/comparison questions | Discord/Slack threads, pitch-page bounce rate |
| trial | Installed, not completed first task | install→first-value drop-off | telemetry on first-command success, complexity feedback |
| early-retention | First-task success, deciding whether to continue | TTV > threshold; "feels heavy" | Day-1 → Day-7 retention curve |
| mid-retention | Regular use, exploring features | discoverability gaps | missing-command requests, expansion friction |
| expansion | Team / advanced workflows | brownfield, compliance asks | enterprise-fit conversations |

Map every evidence item to exactly one stage. If unclear, surface as `stage: unknown` and propose a clarifying probe — do not assign a guess.

## Aha-moment selection framework

Sources [11, 12, 13] converge on the Facebook origin: "when someone added at least seven friends within their first 10 days of having an account, they were far more likely to stick around for the long term" [11]. Chamath Palihapitiya [13]: "7 friends in 10 days was their single sole focus."

Selection rules (derived from [14, 26, 27, 28]):

1. **Behavior-grounded**: the candidate must name a behavior shift, not a count. ("First peer-reviewed defect caught" beats "first 3 waves completed".)
2. **Causally linked to product value-prop**: if the activated behavior is unrelated to why the product exists, it is a vanity metric per [26]: "Vanity metrics usually [are those] that tell us that we're succeeding, even if they probably mean nothing."
3. **Validate experimentally** [28]: "a good activation metric is causal for your retention, not just correlative." Run an experiment increasing the percentage of users hitting the moment and measure retention delta.
4. **Guard against selection bias** [27]: "if you focus solely on users who completed a specific onboarding flow, you might incorrectly attribute their retention to the flow itself."

### nWave aha-moment candidate evaluation (illustrative)

| Candidate | Behavior-grounded? | Causally linked to value-prop? | Experimentally validated? |
|-----------|--------------------|---------------------------------|-----------------------------|
| First wave completed | No — activity metric | Weak — does not exercise discipline | Not yet |
| First GREEN acceptance test under DES dispatch | Partial — names test-discipline behavior | Yes — exercises core discipline | Not yet — probe required |
| **First peer-reviewed defect AI would have shipped** | Yes — names review-catches-AI-error behavior | Yes — directly exercises augmented-coding value-prop [F6.1] | Not yet — probe required |

Recommendation pattern: surface "first peer-reviewed defect AI would have shipped" as candidate, then prescribe the experiment per [28] before declaring it the aha-moment.

## Balfour Four Fits framework [F1.2, F3.2]

Source: [23] Balfour, *Building a Growth Framework Towards a $100 Million Product*. Top-level fits (verbatim re-statement):

| Fit | Definition | nWave self-assessment (illustrative) |
|-----|------------|--------------------------------------|
| Market-Product | Audience needs the product can satisfy | Verified for AI-era craftsmen (Eldon [22], Tsvetan Discord) |
| Product-Channel | Product is shaped for the channels reaching the audience | Weak — pitch is methodology-heavy on landing page |
| Channel-Model | Channels economically support the pricing/revenue model | Untested for nWave |
| Model-Market | Pricing/model matches what the market will pay | Untested for nWave |

Coupling property [23]: "When you change one component within the framework, you need to revisit and change the rest." Pivoting the Audience (e.g. broadening from craftsmen to all devs) requires revisiting Product, Channel, and Model. Single-axis pivots fail.

### Sub-decomposition (activation surface within Market-Product fit)

The secondary "Audience / Promise / Urgency / Knowledge" framing applies inside Market-Product fit only, as the activation sub-surface. For nWave today:
- Audience fit: verified (Eldon).
- Promise fit: articulated (production-grade discipline).
- Urgency fit: partly articulated (AI changes the rules).
- **Knowledge fit: weakest** — gap between user's current mental model and what they need to extract value. Eldon [22] verbatim ("Alex is so far ahead of us that he has better reasons for why we should continue to value it. Than we do yet.") IS the Knowledge-fit gap manifesting.

## TTV benchmarks for developer tooling [F1.1, F5.1, F1.2]

Target: first useful output ≤ 60 seconds from install completion.

Anchors:
- Stripe [1]: test card `4242 4242 4242 4242` accepted in any payment form, any future expiry, any CVC. Inline in "Testing interactively" section, not a separate tutorial.
- Vercel [3]: "Vercel allows for automatic deployments on every branch push and merges onto the production branch of your GitHub, GitLab, and Bitbucket projects." First aha-moment = push → URL.
- Balfour [23]: "How quickly could we get the target audience to experience value." TTV is a Market-Product fit input.

Counter-evidence: Kubernetes shipped multi-day TTV and won enterprise adoption via ecosystem lock-in + cloud-provider managed offerings. Inference: high TTV is survivable only when (a) the unmet need is impossible to satisfy by alternatives and (b) the ecosystem builds a paved-road wrapper. Neither applies to nWave today.

## Friction-log record structure

Per evidence item, record:

| Field | Required values |
|-------|-----------------|
| source | citation (file:line, URL, transcript timestamp, Discord message link) |
| date | ISO date |
| N | integer; founder-self = 0 for funnel-validation purposes |
| funnel_stage | one of: pre-discovery, discovery, trial, early-retention, mid-retention, expansion, unknown |
| evidence_quality | anecdote \| N>1 pattern \| empirical probe \| cohort data |
| falsifiable_hypothesis | one sentence, predicate-form |
| corroboration | list of distinct sources confirming the same pattern (count, not just citation) |

Refuse to proceed with funnel analysis if every evidence item has `N=0` (founder-only) or `evidence_quality=anecdote` without ≥1 corroboration.

## Anti-patterns

1. **Number-chasing without behavior shift** [F3.3]. Setting "users complete 3 waves in week 1" as aha-moment because 3 waves correlate with retention — without testing whether forcing the behavior causes retention. Source [28]: "a good activation metric is causal for your retention, not just correlative."
2. **Single-axis Four-Fits pivot** [F1.2]. Broadening audience without revisiting product/channel/model. Source [23]: "When you change one component within the framework, you need to revisit and change the rest."
3. **Founder-only evidence treated as funnel data**. Treating the founder's confidence as N=1 evidence is a category error — founder-self generates hypotheses, does not validate them.
4. **Mid-flow intervention for pre-trial pain**. Adding features to mid-retention surface to address users who never finished trial. Locate the stage first.

## Confidence flags

- All findings cited here (F1.1, F1.2, F3.1, F3.2, F3.3) are at **High confidence** after the 2026-05-13 follow-up. Balfour Four Fits (F1.2, F3.2) upgraded from Medium → High via primary essay retrieval [23]. Mixpanel caveat (F3.3) upgraded from Medium → High via cross-reference with Amplitude [26, 27] and Reforge [28].
- Reforge [28] HTTP 403 on direct fetch — verbatim quotes attributed via WebSearch snippet aggregation, flagged `partial-access` in research source analysis.

## References

[1] Stripe — Testing. https://docs.stripe.com/testing
[3] Vercel — Deploying Git Repositories. https://vercel.com/docs/git
[11] Mode — Facebook's "Aha" Moment. https://mode.com/blog/facebook-aha-moment-simpler-than-you-think/
[12] Aakash Gupta — Ultimate Guide: Activation. https://www.news.aakashg.com/p/ultimate-guide-activation
[13] LinkedIn — How Chamath Palihapitiya Improved FB User Retention.
[14] Mixpanel — Magic numbers are an illusion. https://mixpanel.com/blog/magic-numbers-are-an-illusion/
[22] Eldon Ferran de Pol interview, nWave-internal, 2026-05-09.
[23] Balfour — Building a Growth Framework Towards a $100M Product. https://brianbalfour.com/essays/hubspot-growth-framework-100m
[26] Amplitude — Breaking the Vanity Metric Cycle. https://amplitude.com/blog/breaking-vanity-metric-cycle
[27] Amplitude — The Aha Moment. https://amplitude.com/blog/aha-moment
[28] Reforge — Activation: Correlation Analysis. https://www.reforge.com/c/retention-series-eg/activation/correlation-analysis (partial-access)
