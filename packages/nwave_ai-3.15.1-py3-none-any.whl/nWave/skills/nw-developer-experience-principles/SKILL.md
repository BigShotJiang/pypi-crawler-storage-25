---
name: nw-developer-experience-principles
description: Nielsen 10 heuristics applied to CLI/agent surfaces, with Fowler's cognitive-bandwidth framing and Krug/Norman cross-references. Cite by heuristic number, not by name-drop. Identifies the three Nielsen heuristics nWave currently violates (H6 Recognition vs Recall, H8 Aesthetic and Minimalist Design, H10 Help and Documentation).
user-invocable: false
disable-model-invocation: true
---

# Developer Experience Principles

Apply UX heuristics with citations (not name-drops) to developer-tool friction. The unit of citation is the heuristic NUMBER and the source [N], not the author's name. Nielsen's 10 heuristics generalize from UI to CLI/agent surfaces but are an informed prior, not a theorem — translate and note the translation.

## Core principles (research-anchored)

1. **Cite by number, not by author** [F2.1]. "Per Nielsen heuristic 6 [2]" beats "per Nielsen". Heuristic-by-number is testable; name-drop is rhetorical.
2. **Heuristics are informed prior on dev surfaces, not theorem** [F2.1, counter-evidence]. Nielsen never validated his heuristics on CLI/agent surfaces. Apply with explicit translation; flag where translation is non-obvious.
3. **Cognitive bandwidth is the scarce resource** [F6.2]. Fowler [18]: "Software development is a contest of engineer cognitive bandwidth — how clearly we can think, frame problems, and make decisions." DX principle: reduce concepts-to-learn per minute-of-value-extracted.
4. **Recognition over recall is the dominant lever for dev tools** [F2.1]. Users will not memorize 21+ slash commands. Surfaces that demand recall lose to surfaces that present affordances.
5. **Surface area at first contact must be minimal** [F2.1]. Aesthetic and Minimalist Design (H8): "Interfaces should not contain information which is irrelevant or rarely needed." 23 agents + 21 commands + 98 skills exposed on first touch violates this.

## The 10 Nielsen heuristics applied to CLI/agent surfaces

Source: Nielsen Norman Group [2], originally 1994-04-24, most recent revision 2024-01-30 — 30-year canonical stability.

| # | Heuristic | CLI/agent translation | nWave assessment |
|---|-----------|------------------------|------------------|
| 1 | Visibility of System Status | Progress indicators on long-running waves, turn counter, phase transitions visible | Partial — DES emits events, surface to user is uneven |
| 2 | Match Between System and Real World | Use developer vocabulary, not internal jargon (avoid "DES dispatch" in user surface; use "workflow run") | Mixed — internal vocabulary leaks |
| 3 | User Control and Freedom | Undo / cancel / resume-from-checkpoint | Strong — DES supports resume |
| 4 | Consistency and Standards | Command grammar consistent across waves; flag naming uniform | Strong within nWave; weak across-ecosystem (subagent vs agent vs skill terminology) |
| 5 | Error Prevention | Confirmation on destructive ops; pre-flight checks | Strong (preflight_checker.py) |
| 6 | **Recognition Rather than Recall** | Affordances over memorization; autocomplete; in-context help | **WEAK — 21 commands + 23 agents + 98 skills require recall** |
| 7 | Flexibility and Efficiency of Use | Accelerators for experts; sensible defaults for novices | Mixed — defaults exist but profile/rigor surface is undocumented to newcomer |
| 8 | **Aesthetic and Minimalist Design** | Minimize surface at first contact; reveal on demand | **WEAK — first-touch shows entire framework surface** |
| 9 | Help Users Recognize/Diagnose/Recover from Errors | Plain-language errors; remediation steps included | Mixed |
| 10 | **Help and Documentation** | "It's best if the system doesn't need any additional explanation." | **WEAK — productive use gated behind reading multi-section CLAUDE.md** |

The three weakest (H6, H8, H10) are the primary DX gap surface for nWave.

### Verbatim heuristic statements (load-bearing)

H6 [2]: "Minimize the user's memory load by making elements, actions, and options visible. The user should not have to remember information from one part of the interface to another."

H8 [2]: "Interfaces should not contain information which is irrelevant or rarely needed. Every extra unit of information in an interface competes with the relevant units of information and diminishes their relative visibility."

H10 [2]: "It's best if the system doesn't need any additional explanation."

## Fowler cognitive-bandwidth framing [F6.2]

Sources [18, 19, 20] (three independent Fowler articles on martinfowler.com — primary author cross-reference).

Verbatim [18]: "Software development is a contest of engineer cognitive bandwidth — how clearly we can think, frame problems, and make decisions."

Verbatim [18]: "Rather than asking AI to immediately produce code, walk through progressive levels of design: capabilities, components, interactions, contracts, and only then implementation. The patterns require discipline to sustain. The same discipline applies to AI."

Three required skills per Thoughtworks SPDD [19]: **alignment, abstraction-first, iterative review.**

DX implication: dev-tool surfaces that consume cognitive bandwidth at first touch (heavy concept load, methodology-first pitch) reduce the bandwidth available for the user's actual problem. The pitch is competing with the user's work — minimize the pitch's bandwidth cost.

## Krug + Norman cross-references (lighter-weight anchors)

Krug, *Don't Make Me Think* (canonical UX text):
- Clarity over cleverness — affordances must be obvious without inference.
- Scannability — surfaces are scanned, not read.
- Satisficing — users pick the first plausible option, not the optimal one.

Norman, *The Design of Everyday Things* (canonical design text):
- Affordance — what the object permits.
- Signifier — the visible signal that announces the affordance.
- Feedback — the system's response to the user's action.
- Conceptual model — the user's mental representation of how the system works.

These are not retrieved with primary citation in the 2026-05-09 research pass — surface as **Medium confidence reference** ([F2.1 counter-evidence] notes peer-reviewed CLI/agent-specific UX research not located). Cite the source text by title, not by URL, until primary citation work is done.

## Case studies (positive patterns)

| Tool | Heuristic pattern | Verbatim signal | Source |
|------|-------------------|-----------------|--------|
| Stripe | H1+H6 — visible status + recognition affordance | `4242 4242 4242 4242` accepted in any payment form | [1] |
| Vercel | H6+H8 — recognition (git push is already known) + minimalist (no new vocabulary) | "automatic deployments on every branch push" | [3] |
| Superpowers | H8 — 6 concepts, single install line | "agentic skills framework & software development methodology that works" | [5] |
| Cursor | H8+H10 — zero-methodology landing, sub-minute autocomplete TTV | "extraordinarily productive" + download → autocomplete | [7] |
| Aider | H8 — 4 concepts, terminal-native (no new mental model) | "AI pair programming in your terminal" | [8] |

## Anti-patterns

1. **Name-drop without heuristic number** — "Per Nielsen" with no specific heuristic identified. Block on review.
2. **Surface-area-first onboarding** — showing 23 agents / 21 commands / 98 skills at first touch. Violates H8.
3. **Required-reading gate** — productive use blocked behind CLAUDE.md, wave docs, skill files. Violates H10.
4. **Memorization-required command grammar** — 21 slash commands user must recall. Violates H6.
5. **Cognitive-bandwidth-heavy pitch** [F6.2] — pitch that requires the user to assemble a methodology mental model before evaluating fit. Competes with the user's own work.
6. **Ignoring translation gap** — applying Nielsen heuristics to CLI without naming the translation step. Heuristics were validated on UI, not CLI; flag the inference.

## Confidence flags

- Nielsen [2] **High confidence** — canonical 30-year primary source, originally 1994, revised 2024.
- Fowler [18, 19, 20] **High confidence** — primary author, three cross-referencing articles on the same domain.
- Krug, Norman: **Medium confidence as referenced here** — primary citations not retrieved in the 2026-05-09 research pass. Cite by title until follow-up probe closes the gap.
- **Knowledge gap** [F2.1 counter-evidence]: peer-reviewed empirical work specifically applying Nielsen heuristics to CLI/agent surfaces not located. Treat translations as informed prior, not theorem.

## References

[1] Stripe — Testing. https://docs.stripe.com/testing
[2] Nielsen — 10 Usability Heuristics for User Interface Design. https://www.nngroup.com/articles/ten-usability-heuristics/
[3] Vercel — Deploying Git Repositories. https://vercel.com/docs/git
[5] obra/superpowers. https://github.com/obra/superpowers
[7] Cursor. https://cursor.com
[8] Aider. https://aider.chat
[18] Fowler — Patterns for Reducing Friction in AI-Assisted Development. https://martinfowler.com/articles/reduce-friction-ai/
[19] Fowler — Structured-Prompt-Driven Development. https://martinfowler.com/articles/structured-prompt-driven/
[20] Fowler — Exploring Generative AI. https://martinfowler.com/articles/exploring-gen-ai.html
