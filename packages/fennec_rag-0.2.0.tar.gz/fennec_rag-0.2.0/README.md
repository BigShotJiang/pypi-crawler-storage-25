# 🦊 fennec-rag

A comprehensive, production-ready **Retrieval-Augmented Generation (RAG)** framework with first-class **Arabic language support**, multi-provider embeddings, and a rich set of advanced RAG strategies.

[![PyPI version](https://badge.fury.io/py/fennec-rag.svg)](https://badge.fury.io/py/fennec-rag)
[![Python](https://img.shields.io/pypi/pyversions/fennec-rag)](https://pypi.org/project/fennec-rag/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## ✨ Features

- 🌍 **Arabic-first NLP** — dedicated Arabic chunker, embedder, and prompt templates
- 🔌 **Multi-provider LLMs** — OpenAI, Anthropic, Gemini, Mistral, HuggingFace, Ollama
- 🗄️ **Multiple vector databases** — FAISS, ChromaDB, Pinecone
- 🧩 **Advanced RAG strategies** — Conversational, Agentic, Graph, Multi-hop, Federated, Self-improving, Streaming, Domain-specific
- 🛡️ **Hallucination Guard** — built-in hallucination detection and grounding
- 📊 **Observability & Evaluation** — tracing, metrics, dashboards, RAG evaluation suite
- 📄 **Rich document loaders** — PDF, DOCX, HTML, CSV, JSON, Excel, Web, Directory
- 💾 **Caching & Persistence** — multi-level cache, backup, encryption support
- 🔍 **Hybrid Search** — BM25 + semantic search with TF-IDF and Stanza
- 🧠 **Memory systems** — Buffer, Window, Summary, and Entity memory
- 🔌 **Plugin system** — extensible architecture for custom components
- 🖥️ **Chat UI** — built-in RAG chat interface

---

## 📦 Installation

### Basic install (core only)
```bash
pip install fennec-rag
```

### With specific providers
```bash
# OpenAI + FAISS
pip install "fennec-rag[openai,faiss]"

# Anthropic + ChromaDB
pip install "fennec-rag[anthropic,chroma]"

# Google Gemini + Pinecone
pip install "fennec-rag[gemini,pinecone]"

# Arabic NLP support
pip install "fennec-rag[arabic]"

# Document loaders
pip install "fennec-rag[pdf,docx,html,excel]"

# Full install (all optional dependencies)
pip install "fennec-rag[all]"
```
---

## 🗂️ Architecture

```
fennec_rag/
├── rag/
│   ├── core/              # RAGSystem, MultiDocRAG, Reranker, PromptRouter
│   ├── agentic_rag/       # Agent-based RAG with tool use
│   ├── conversational_rag/ # Multi-turn conversation with history
│   ├── graph_rag/         # Knowledge graph RAG
│   ├── hybrid_search/     # BM25 + semantic hybrid search
│   ├── multi_hop/         # Multi-hop question decomposition
│   ├── federated_rag/     # Federated multi-source RAG
│   ├── self_improving_rag/ # HyDE + recursive refinement
│   ├── streaming_rag/     # Token streaming
│   ├── domain_rag/        # Domain-specific RAG
│   └── rag_ui/            # Built-in Chat UI
├── embeddings/            # OpenAI, Gemini, HuggingFace, Mistral, Ollama, Arabic
├── vector_database/       # FAISS, ChromaDB, Pinecone
├── llm/                   # OpenAI, Anthropic, Gemini, Mistral, HuggingFace, Ollama
│   └── hallucination/     # HallucinationGuard, ProtectedLLMInterface
├── chunks/                # Arabic & multilingual text chunkers
├── document_loaders/      # PDF, DOCX, HTML, CSV, JSON, Excel, Web, Directory
├── memory/                # Buffer, Window, Summary, Entity memory
├── cache/                 # Multi-level cache system
├── prompt/                # PromptTemplate, ChatTemplate, FewShotTemplate
├── router/                # SemanticRouter for intent routing
├── context/               # Context management & allocation
├── output_parser/         # JSON, YAML, CSV, Pydantic, List parsers
├── observability/         # Tracing, metrics, anomaly detection, dashboards
├── evaluator/             # RAG evaluation & reporting
├── monitor/               # Real-time performance monitoring
├── persistence/           # State persistence & backup
└── plugins/               # Extensible plugin system
```

---

## 🔧 Optional Dependencies

| Extra | Packages | Use case |
|-------|----------|----------|
| `faiss` | faiss-cpu | FAISS vector database |
| `chroma` | chromadb | ChromaDB vector database |
| `pinecone` | pinecone-client | Pinecone vector database |
| `openai` | openai | OpenAI LLM & embeddings |
| `anthropic` | anthropic | Claude LLM |
| `gemini` | google-genai | Google Gemini LLM & embeddings |
| `mistral` | mistralai | Mistral LLM & embeddings |
| `huggingface` | transformers, torch | Local HuggingFace models |
| `sentence-transformers` | sentence-transformers | Sentence embeddings |
| `ollama` | aiohttp | Ollama local LLM |
| `pdf` | pypdf, PyPDF2 | PDF loading |
| `docx` | python-docx | Word document loading |
| `excel` | openpyxl | Excel file loading |
| `html` | beautifulsoup4, lxml | HTML loading |
| `web` | aiohttp, beautifulsoup4 | Web page loading |
| `arabic` | stanza, camel-tools | Advanced Arabic NLP |
| `jinja2` | jinja2 | Jinja2 prompt templates |
| `observability` | fastapi, uvicorn | Observability API server |
| `eval` | scikit-learn | RAG evaluation metrics |
| `crypto` | cryptography | Encrypted persistence |
| `all` | everything above | Full installation |

---

## 📝 License

MIT License — see [LICENSE](LICENSE) for details.
