import os
import sys
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Set
from collections import deque
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from chunks import DocumentChunk
from .knowledge_graph import KnowledgeGraph
from .node import GraphNode
from .edges import GraphEdge
from .config import ConfigGraphRAG


logger = logging.getLogger(__name__)


class GraphRAG:
    """
    Optimized GraphRAG that leverages VectorDatabase.
    GraphRAG محسّن يستفيد من VectorDatabase.

    """

    def __init__(
        self,
        vector_db,
        llm: Optional[Any] = None,
        config: Optional[ConfigGraphRAG] = None,
    ):
        """
        Initialize GraphRAG.

        Args:
            vector_db: VectorDatabase instance (required)
            llm:       any object with .generate(prompt) — optional
            config:    GraphRAG configuration
        """
        logger.info("🚀 Initializing GraphRAG...")

        self.vector_db = vector_db
        self.embedder  = vector_db.embedder
        self.llm       = llm
        self.config    = config or ConfigGraphRAG()

        # FIX 6: pass config so KnowledgeGraph uses the same settings
        self.graph = KnowledgeGraph(config=self.config)

        # chunk_id -> node_id  (fast lookup used in retrieve)
        self._chunk_to_node: Dict[str, str] = {}
        # node_id  -> [chunk_ids]
        self._node_to_chunks: Dict[str, List[str]] = {}
        # FIX 2: set per node_id for O(1) membership test
        self._node_to_chunks_set: Dict[str, Set[str]] = {}
        # doc_id   -> full text (for rich LLM context)
        self._doc_contents: Dict[str, str] = {}

        logger.info(
            "✅ GraphRAG initialized | llm=%s",
            type(llm).__name__ if llm else "None",
        )

    # ------------------------------------------------------------------
    # Document ingestion
    # ------------------------------------------------------------------

    def add_document_with_relations(
        self,
        content: str,
        entities: List[Dict[str, Any]],
        relations: List[Dict[str, Any]],
        doc_id: str,
        metadata: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """
        Add document with entities and relations.

        FIX 3: all entity chunks are collected first then added to the
        vector DB in a single batch call instead of one call per entity.
        """
        metadata = metadata or {}
        self._doc_contents[doc_id] = content.strip()
        results = {"nodes_added": 0, "edges_added": 0, "chunks_created": 0}

        try:
            # 1. Build nodes + collect chunks (no DB write yet)
            batch_chunks: List[DocumentChunk] = []

            for entity in entities:
                entity_text = (
                    entity.get("text")
                    or entity.get("name")
                    or entity.get("content")
                    or entity["id"]
                )

                node = GraphNode(
                    id=entity["id"],
                    content=entity_text,
                    node_type=entity.get("type", "entity"),
                    metadata={
                        **{
                            k: v for k, v in entity.items()
                            if k not in ("id", "type", "text", "name", "content", "metadata")
                        },
                        **entity.get("metadata", {}),
                        "doc_id": doc_id,
                        **metadata,
                    },
                )
                self.graph.add_node(node)

                chunk = DocumentChunk(
                    chunk_id=f"entity_{entity['id']}",
                    doc_id=doc_id,
                    text=entity_text,
                    metadata={"node_id": entity["id"], "type": "entity", **metadata},
                )
                batch_chunks.append(chunk)

                # Update mappings
                self._chunk_to_node[chunk.chunk_id] = entity["id"]
                if entity["id"] not in self._node_to_chunks:
                    self._node_to_chunks[entity["id"]]     = []
                    self._node_to_chunks_set[entity["id"]] = set()
                self._node_to_chunks[entity["id"]].append(chunk.chunk_id)
                self._node_to_chunks_set[entity["id"]].add(chunk.chunk_id)

                results["nodes_added"]   += 1
                results["chunks_created"] += 1

            # FIX 3: single batch write instead of N individual writes
            if batch_chunks:
                self.vector_db.add(batch_chunks)

            # 2. Add relations
            for rel in relations:
                edge = GraphEdge(
                    source=rel["source"],
                    target=rel["target"],
                    relation=rel.get("type", "related"),
                    weight=rel.get("weight", 1.0),
                    bidirectional=rel.get("bidirectional", False),
                )
                self.graph.add_edge(edge)
                results["edges_added"] += 1

            logger.info(
                "✅ Added %d nodes, %d edges, %d chunks (1 batch write)",
                results["nodes_added"], results["edges_added"], results["chunks_created"],
            )
            return results

        except Exception as e:
            logger.error(f"❌ Error adding document: {e}")
            raise

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def retrieve_with_context(
        self,
        query: str,
        k: int = None,
        context_depth: int = None,
        min_similarity: float = 0.0,
        combine_scores: bool = True,
    ) -> List[Dict[str, Any]]:
        """Retrieve with graph context expansion."""
        k             = k             or self.config.k
        context_depth = context_depth or self.config.context_depth

        try:
            logger.debug(f"🔍 Processing query: {query[:50]}...")

            vector_results = self.vector_db.search(
                query=query,
                top_k=k * 2,
                score_threshold=min_similarity,
            )

            if not vector_results:
                logger.warning("No matching results found")
                return []

            node_scores: Dict[str, float] = {}
            for chunk, score in vector_results:
                if chunk.chunk_id in self._chunk_to_node:
                    node_id = self._chunk_to_node[chunk.chunk_id]
                    node_scores[node_id] = max(node_scores.get(node_id, 0.0), score)

            expanded = (
                self._expand_graph_context(node_scores, context_depth, combine_scores)
                if context_depth > 0
                else node_scores
            )

            results = self._build_results(expanded, query)[:k]
            logger.info(f"✅ Retrieved {len(results)} results")
            return results

        except Exception as e:
            logger.error(f"❌ Retrieval failed: {e}")
            return []

    def _expand_graph_context(
        self,
        initial_nodes: Dict[str, float],
        depth: int,
        combine_scores: bool = True,
    ) -> Dict[str, float]:
        """Expand context via BFS graph traversal."""
        expanded: Dict[str, float] = dict(initial_nodes)
        visited:  Set[str]         = set()
        queue = deque()

        for node_id, score in initial_nodes.items():
            queue.append((node_id, score, 0))
            visited.add(node_id)

        while queue:
            node_id, score, current_depth = queue.popleft()
            if current_depth >= depth:
                continue

            for neighbor_id in self.graph.get_neighbors(node_id, max_depth=1):
                if neighbor_id not in visited:
                    visited.add(neighbor_id)
                    decay         = 0.5 ** (current_depth + 1)
                    n_score       = score * decay
                    if neighbor_id not in expanded:
                        expanded[neighbor_id] = n_score
                    elif combine_scores:
                        expanded[neighbor_id] = max(expanded[neighbor_id], n_score)
                    queue.append((neighbor_id, n_score, current_depth + 1))

        return expanded

    def _build_results(
        self,
        node_scores: Dict[str, float],
        query: str,
    ) -> List[Dict[str, Any]]:
        """
        Build final results from node scores.

        FIX 2: uses _node_to_chunks_set (a set per node) for O(1) membership
        test instead of scanning all vector_db.chunks linearly per node.
        """
        results = []

        for node_id, score in node_scores.items():
            if node_id not in self.graph.nodes:
                continue

            node = self.graph.nodes[node_id]

            # FIX 2: O(1) set lookup instead of O(chunks) linear scan
            chunk_ids_set = self._node_to_chunks_set.get(node_id, set())
            related_chunks = [
                {"text": chunk.text, "metadata": chunk.metadata}
                for chunk in self.vector_db.chunks
                if chunk.chunk_id in chunk_ids_set
            ]

            neighbors = list(self.graph.get_neighbors(node_id, max_depth=1))
            neighbor_info = [
                {
                    "id":      nid,
                    "content": self.graph.nodes[nid].content,
                    "type":    self.graph.nodes[nid].node_type,
                }
                for nid in neighbors[:5]
                if nid in self.graph.nodes
            ]

            results.append({
                "id":             node_id,
                "content":        node.content,
                "type":           node.node_type,
                "score":          float(score),
                "metadata":       dict(node.metadata),
                "related_chunks": related_chunks,
                "neighbors":      neighbor_info,
            })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results

    # ------------------------------------------------------------------
    # Node context / semantic search
    # ------------------------------------------------------------------

    def get_node_context(
        self,
        node_id: str,
        max_depth: int = 2,
        include_chunks: bool = True,
    ) -> Dict[str, Any]:
        """Get comprehensive context for a node."""
        if node_id not in self.graph.nodes:
            return {}

        node = self.graph.nodes[node_id]
        neighbors_by_depth = {
            depth: [
                {
                    "id":      nid,
                    "content": self.graph.nodes[nid].content,
                    "type":    self.graph.nodes[nid].node_type,
                }
                for nid in self.graph.get_neighbors(node_id, max_depth=depth)
                if nid in self.graph.nodes
            ]
            for depth in range(1, max_depth + 1)
        }

        context: Dict[str, Any] = {
            "node": {
                "id":       node_id,
                "content":  node.content,
                "type":     node.node_type,
                "metadata": dict(node.metadata),
            },
            "neighbors_by_depth": neighbors_by_depth,
        }

        if include_chunks:
            chunk_ids_set = self._node_to_chunks_set.get(node_id, set())
            context["related_chunks"] = [
                {"text": chunk.text, "metadata": chunk.metadata}
                for chunk in self.vector_db.chunks
                if chunk.chunk_id in chunk_ids_set
            ]

        return context

    def semantic_search(
        self,
        query: str,
        top_k: int = 5,
        include_graph_info: bool = True,
    ) -> List[Dict[str, Any]]:
        """Pure semantic search using vector DB."""
        results = []
        for chunk, score in self.vector_db.search(query=query, top_k=top_k):
            result: Dict[str, Any] = {
                "text":     chunk.text,
                "score":    float(score),
                "metadata": chunk.metadata,
            }
            if include_graph_info and chunk.chunk_id in self._chunk_to_node:
                node_id = self._chunk_to_node[chunk.chunk_id]
                if node_id in self.graph.nodes:
                    result["graph_node"] = {
                        "id":              node_id,
                        "type":            self.graph.nodes[node_id].node_type,
                        "neighbors_count": len(
                            self.graph.get_neighbors(node_id, max_depth=1)
                        ),
                    }
            results.append(result)
        return results

    # ------------------------------------------------------------------
    # Generation
    # ------------------------------------------------------------------

    def _build_graph_context(self, results: list) -> str:
        """Convert graph results to rich LLM context string."""
        seen_docs: Set[str] = set()
        doc_sections: List[str] = []
        entity_lines: List[str] = []

        for r in results:
            doc_id = r.get("metadata", {}).get("doc_id", "")
            if doc_id and doc_id not in seen_docs and doc_id in self._doc_contents:
                seen_docs.add(doc_id)
                doc_sections.append(
                    f"--- Document: {doc_id} ---\n{self._doc_contents[doc_id]}"
                )

            line = f"• [{r['type']}] {r['content']}"
            if r.get("neighbors"):
                neighbor_names = ", ".join(n["content"] for n in r["neighbors"][:4])
                line += f" conect wiht: {neighbor_names}"
            entity_lines.append(line)

        parts = []
        if doc_sections:
            parts.append("text source:\n" + "\n\n".join(doc_sections))
        if entity_lines:
            parts.append("entity source:\n" + "\n".join(entity_lines))
        return "\n\n".join(parts)

    def _build_prompt(self, query: str, context: str, language: str = "ar") -> str:

        if language == "ar":
            return (
                f"أنت نظام إجابة يعتمد فقط على المعلومات المقدمة (RAG system).\n\n"

                f" قواعد صارمة:\n"
                f"- استخدم فقط المعلومات الموجودة في السياق أدناه\n"
                f"- ممنوع إضافة أي معلومات من معرفتك العامة\n"
                f"- ممنوع إعطاء أمثلة أو شرح غير مذكور في السياق\n"
                f"- إذا لم تكن الإجابة موجودة صراحة في السياق، قل: \"لا توجد معلومات كافية للإجابة\"\n"
                f"- لا تستنتج أو تخمّن\n"
                f"- لا تعمم أو تضيف تفاصيل خارج النص\n\n"
                f" أسلوب الإجابة:\n"
                f"- إجابة مباشرة فقط\n"
                f"- بدون حشو أو شرح إضافي\n"
                f"- استخدم نفس المصطلحات الموجودة في السياق\n\n"
                f" السياق:\n{context}\n\n"
                f" السؤال: {query}\n"
                f" الإجابة:"
            )        
        if language == "en":
            return (
                f"You are an answer system that relies solely on the provided information (RAG system).\n\n"

                f" Strict rules:\n"
                f"- Use only the information present in the context below\n"
                f"- Do not add any information from your general knowledge\n"
                f"- Do not provide examples or explanations not mentioned in the context\n"
                f"- If the answer is not explicitly present in the context, say: \"There is not enough information to answer\"\n"
                f"- Do not infer or guess\n"
                f"- Do not generalize or add details outside the text\n\n"
                f" Answer style:\n"
                f"- Provide a direct answer only\n"
                f"- No fluff or additional explanations\n"
                f"- Use the same terminology found in the context\n\n"
                f"Context:\n{context}\n\n"
                f"Question: {query}\n"
                f" Answer:"
            )

    def query(
        self,
        query: str,
        k: int = None,
        language: str = "ar",
        include_sources: bool = False,
        **llm_kwargs,
    ) -> str:
        """
        Main query interface: retrieve → build prompt → generate.

        FIX 4: ``k`` is now an explicit parameter forwarded directly to
        retrieve_with_context, so callers can override the default top-k
        without it being swallowed by **llm_kwargs.
        """
        if not query or not query.strip():
            return "⚠️ Enter a correct query"

        try:
            # FIX 4: pass k explicitly
            results = self.retrieve_with_context(query, k=k or self.config.k)

            if not results:
                return "❌ not found informations "

            context = self._build_graph_context(results)

            if self.llm:
                prompt = self._build_prompt(query, context, language=language)
                answer = self.llm.generate(prompt, **llm_kwargs)
            else:
                answer = f"Based on the cognitive schema:\n{context}"

            if include_sources:
                sources = "\n".join(
                    f"• [{r['type']}] {r['id']} (score: {r['score']:.2f})"
                    for r in results
                )
                answer = f"{answer}\n\n📚 Source :\n{sources}"

            logger.info("✅ Answer generated successfully")
            return answer

        except Exception as exc:
            logger.error("❌ Query error: %s", exc)
            return f"❌ Error generating answer: {exc}"

    def generate(self, query: str, k: int = None, **kwargs) -> str:
        """
        Alias for query() — keeps compatibility with other RAG types.

        FIX 4: ``k`` is extracted before **kwargs so it reaches
        retrieve_with_context and is not forwarded to the LLM.
        """
        return self.query(query, k=k, **kwargs)

    def get_statistics(self) -> Dict[str, Any]:
        return {
            "graph":     self.graph.get_stats(),
            "vector_db": self.vector_db.get_stats(),
            "mappings": {
                "chunks_to_nodes":   len(self._chunk_to_node),
                "nodes_with_chunks": len(self._node_to_chunks),
            },
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str) -> None:
        """Save system state."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        self.vector_db.save(path / "vector_db")

        import json
        graph_data = {
            "nodes": [node.to_dict() for node in self.graph.nodes.values()],
            "edges": [edge.to_dict() for edge in self.graph.edges],
        }
        with open(path / "graph.json", "w", encoding="utf-8") as f:
            json.dump(graph_data, f, ensure_ascii=False, indent=2)

        mappings = {
            "chunk_to_node":      self._chunk_to_node,
            "node_to_chunks":     self._node_to_chunks,
            # sets are not JSON-serialisable — store as lists
            "node_to_chunks_set": {k: list(v) for k, v in self._node_to_chunks_set.items()},
            "doc_contents":       self._doc_contents,
        }
        with open(path / "mappings.json", "w", encoding="utf-8") as f:
            json.dump(mappings, f, ensure_ascii=False, indent=2)

        logger.info(f"💾 System saved to: {path}")

    def load(self, path: str) -> None:
        """
        Load system state.

        FIX 5: updates self.embedder after replacing self.vector_db so the
        reference never points to the old database's embedder.
        """
        path = Path(path)

        self.vector_db = self.vector_db.load(path / "vector_db", embedder=self.embedder)
        # FIX 5: keep embedder in sync with the newly loaded vector_db
        self.embedder = self.vector_db.embedder

        import json
        with open(path / "mappings.json", "r", encoding="utf-8") as f:
            mappings = json.load(f)

        self._chunk_to_node  = mappings["chunk_to_node"]
        self._node_to_chunks = mappings["node_to_chunks"]
        # Restore sets (stored as lists for JSON compatibility)
        self._node_to_chunks_set = {
            k: set(v) for k, v in mappings.get("node_to_chunks_set", {}).items()
        }
        self._doc_contents = mappings.get("doc_contents", {})

        logger.info(f"📂 System loaded from: {path}")

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def aquery(self, query: str, k: int = None, **kwargs) -> str:
        """Async version of query()."""
        import asyncio
        return await asyncio.to_thread(self.query, query, k=k, **kwargs)

    async def agenerate(self, query: str, k: int = None, **kwargs) -> str:
        """Async generation — delegates to aquery()."""
        import asyncio
        return await asyncio.to_thread(self.query, query, k=k, **kwargs)

    async def aretrieve(self, query: str, top_k: int = None, k: int = None, **kwargs):
        """
        Async retrieval.

        FIX 1: accepts ``top_k`` (used by federat._call_generate) and maps it
        to ``k`` so retrieve_with_context actually honours the requested limit.
        """
        import asyncio
        effective_k = k or top_k   # FIX 1: top_k → k
        return await asyncio.to_thread(
            self.retrieve_with_context, query, effective_k, **kwargs
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False

    def __repr__(self) -> str:
        return (
            f"GraphRAG(nodes={len(self.graph.nodes)}, "
            f"edges={len(self.graph.edges)}, "
            f"llm={type(self.llm).__name__ if self.llm else 'None'})"
        )