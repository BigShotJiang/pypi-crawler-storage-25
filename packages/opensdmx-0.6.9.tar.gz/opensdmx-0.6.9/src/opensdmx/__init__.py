"""opensdmx — Python interface to any SDMX 2.1 REST API."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("opensdmx")
except PackageNotFoundError:
    __version__ = "0.0.0"

from .base import get_provider, set_provider, set_timeout, set_extra_headers, get_extra_headers
from .discovery import (
    ConstraintsTimeout,
    ConstraintsUnavailable,
    all_available,
    dimensions_info,
    get_available_values,
    get_dimension_values,
    load_dataset,
    print_dataset,
    reset_filters,
    search_dataset,
    set_filters,
)
from .retrieval import fetch, get_data, parse_time_period, run_query
from .embed import build_embeddings, semantic_search
from .cli import main

__all__ = [
    "ConstraintsTimeout",
    "ConstraintsUnavailable",
    "set_provider",
    "get_provider",
    "all_available",
    "search_dataset",
    "load_dataset",
    "print_dataset",
    "dimensions_info",
    "get_dimension_values",
    "get_available_values",
    "set_filters",
    "reset_filters",
    "get_data",
    "fetch",
    "run_query",
    "build_embeddings",
    "semantic_search",
    "set_timeout",
    "set_extra_headers",
    "get_extra_headers",
    "parse_time_period",
    "main",
    "__version__",
]
