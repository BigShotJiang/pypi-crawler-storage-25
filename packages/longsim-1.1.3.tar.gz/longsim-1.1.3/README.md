# Public-Exemplar

External Exemplar Project (Simulated Data and Public Datasets)

## Some Considerations
 1. Make sure that the Simulator repository is editable by all users: `chmod -R o+w Simulator`

## Uploading to PyPi
 1. Change to the parent directory: `cd PATH/To/Simulator/`
 2. Activate any valid environment
 2. Build: `python -m build`
 3. Upload using twine: 
    ```bash
    twine check dist/*
    twine upload --verbose dist/*
    ```