################################################################
#                   Definition of the DAG Model                #
#  * The Data-Generating Model brings together the various     #
#    components.                                               #
#  * Responsible only for generating a single individual run.  #
################################################################

import collections as pyc
import numpy as np
import pandas as pd

from . import cause_models
from . import disease_models
from . import utils


class DPMRegularRisks:
    """"
    Simulator for a disease progression model with fully-observed risk-computations.

    Main Modelling Assumptions:
        * All Risk Model readouts are observed at all points in time.
        * The length of the simulation is governed by a binomial distribution, but constrained to have at least 1
          observation.
        * The simulation ends when the randomly-generated number of time-points is met OR the disease outcome is true.
    """
    def __init__(
            self,
            covariate_models: dict,
            state_model: tuple,
            length_distribution: tuple,
            stop_on_disease: bool = True,
            show_all: bool = False,
    ):
        """
        Initialises the Simulator

        :param covariate_models: Specification of the covariates (including exposure event). Dict of two-tuple
                                 initialisers for CauseModel implementations, named for recording state. Note that the
                                 emitted vectors must all be the same size.
        :param state_model: Model for State of Disease. Two-Tuple Initialiser for an instance of StateModel
        :param length_distribution: Two-tuple representing the n and p parameters of a binomial distribution to generate
                                    length of simulation.
        :param stop_on_disease: If True (default) stop generating when the disease outcome is encountered: otherwise
                                continue to the maximum.
        :param show_all: If True (default False), all computed parameters are stored in the simulated output.
        """
        # Initialise Models
        self.__covariates = {k: cause_models.__dict__[cm[0]](**cm[1]) for k, cm in covariate_models.items()}
        self.__disease = disease_models.__dict__[state_model[0]](**state_model[1])
        self.__len_n = length_distribution[0]
        self.__len_p = length_distribution[1]
        self.__sod = stop_on_disease
        self.__verbose = show_all

    def stop_condition(self, last_outcome):
        return self.__sod and (last_outcome > 0.5)

    def simulate(self, rng):
        """
        Simulate a single run of observations

        :param rng: Random number generator or seed
        :return: Pandas DataFrame
        """
        # A) Setup
        rng = np.random.default_rng(rng)  # Wrap Random Number Generator in case it is a seed
        max_T = (self.__len_n if self.__len_p < 0 else max(rng.binomial(self.__len_n, self.__len_p), 1)) - 1

        # B) Setup DataFrame Storage
        samples = pyc.defaultdict(list)

        # C) First Time-Point: Reset everything
        # C.1) Covariates
        cov = {}
        for k in self.__covariates.keys():
            cov[k] = self.__covariates[k].reset(rng).initial_effect
            samples[f'cov_{k}'].append(self.__covariates[k].observation)
            if self.__verbose:
                samples[f'cov_{k}_state'].append(utils.format_output(self.__covariates[k].state))
                samples[f'cov_{k}_effect'].append(utils.format_output(self.__covariates[k].initial_effect))
        # C.2) Disease State
        self.__disease.reset(cov, rng)
        if self.__verbose:
            samples['disease'].append(utils.format_output(self.__disease.state))
        # C.3) Observations of Disease & Outcome
        for k, obs in self.__disease.observations.items():
            samples[f'risk_{k}'].append(utils.format_output(obs))
        samples['outcome'].append(utils.format_output(self.__disease.outcome))
        # C.4) Other Variables to be recorded
        for k, otr in self.__disease.diagnostics.items():
            samples[f'diag_{k}'].append(utils.format_output(otr))

        # D) Iterate up to Maximum time-point
        t = 1 # Already did first time-step
        while (t < max_T) and (not self.stop_condition(samples['outcome'][-1])):
            # D.1) Covariates
            cov = {}
            for k in self.__covariates.keys():
                cov[k] = self.__covariates[k].advance(rng).dynamic_effect
                samples[f'cov_{k}'].append(self.__covariates[k].observation)
                if self.__verbose:
                    samples[f'cov_{k}_state'].append(utils.format_output(self.__covariates[k].state))
                    samples[f'cov_{k}_effect'].append(utils.format_output(self.__covariates[k].dynamic_effect))
            # D.2) Disease State
            self.__disease.advance(cov, rng)
            if self.__verbose:
                samples['disease'].append(utils.format_output(self.__disease.state))
            # D.3) Observations of Disease & Outcome
            for k, obs in self.__disease.observations.items():
                samples[f'risk_{k}'].append(utils.format_output(obs))
            samples['outcome'].append(utils.format_output(self.__disease.outcome))
            # D.4) Other Variables to be recorded
            for k, otr in self.__disease.diagnostics.items():
                samples[f'diag_{k}'].append(utils.format_output(otr))
            # D.5) Update Time
            t += 1

        # E) Convert to Pandas DataFrame and return
        samples = pd.DataFrame(samples)
        return samples
