#################################################################
#                Definition of Disease Models Class             #
#  * The state model encapsulates the (latent) state and is the #
#    central variable of interest.                              #
#  * It is responsible for maintaining state, and fusing        #
#    causal information from events and covariates.             #
#  * It also encapsulates observations and outcome              #
#################################################################
import abc
import copy as cp

from . import seeders
from . import transfer_functions
from . import utils


class DiseaseModel(abc.ABC):
    """
    Defines the Interface for the Disease State Model.
    """
    def __init__(self, observation_models: dict, outcome_model: tuple):
        """
        Initialises the class
        """
        # Objects
        self.__observation_models = {
            k: transfer_functions.__dict__[rm[0]](**rm[1]) for k, rm in observation_models.items()
        }
        self.__outcome_model = transfer_functions.__dict__[outcome_model[0]](**outcome_model[1])

        # States
        self._state = None
        self.__observations = {k: None for k in observation_models.keys()}   # Observations of the State (Risk Models)
        self.__outcome = None                                                # Outcome (Diagnosis)
        self._other = {}                                                     # Other (Diagnostic) Variables

    def reset(self, covariates: dict, rng):
        """
        Reset the State Vector and initialise observations

        :param covariates: Covariates to handle initialisation
        :param rng: Random number generator
        :return: Self, for chaining
        """
        # Reset State
        self._reset_state(covariates, rng)

        # Update Observations
        for k, mdl in self.__observation_models.items():
            self.__observations[k] = utils.format_output(mdl.transform(self._state, rng))
        self.__outcome = utils.format_output(self.__outcome_model.transform(self._state, rng))

        # Return self
        return self

    def advance(self, covariates: dict, rng):
        """
        Advance the State Vector according to dynamics and update observations

        :param covariates: Covariates which effect transition dynamics
        :param rng: Random number generator
        :return: self
        """
        # Advance State
        self._advance_state(covariates, rng)

        # Update Observations
        for k, mdl in self.__observation_models.items():
            self.__observations[k] = utils.format_output(mdl.transform(self._state, rng))
        self.__outcome = utils.format_output(self.__outcome_model.transform(self._state, rng))

        # Return self
        return self

    @property
    def state(self):
        return cp.copy(self._state)

    @property
    def observations(self):
        return cp.copy(self.__observations)

    @property
    def diagnostics(self):
        return cp.copy(self._other)

    @property
    def outcome(self):
        return cp.copy(self.__outcome)

    @abc.abstractmethod
    def _reset_state(self, covariates, rng):
        pass

    @abc.abstractmethod
    def _advance_state(self, covariates, rng):
        pass


class DMLinearAdditive(DiseaseModel):
    """
    Defines a Linear Transition with Additive Covariate effects
    """
    def __init__(
            self,
            observation_models: dict,
            outcome_model: tuple,
            seeder: tuple,
            transition_model: tuple,
            negate_covariates: bool=False
    ):
        """
        Initialises the Linear Additive Model

        :param observation_models: See DiseaseModel.__init__
        :param outcome_model: See DiseaseModel.__init__
        :param seeder: Model for seeding from
        :param transition_model: Model for defining Transition dynamics
        :param negate_covariates: If True, negate covariate contributions rather than adding them (useful for time)
        """
        # Initialise Base Class
        super().__init__(observation_models, outcome_model)

        # Initialise own
        self._seeder = seeders.__dict__[seeder[0]](**seeder[1])
        self._transition_model = transfer_functions.__dict__[transition_model[0]](**transition_model[1])
        self._sign = -1 if negate_covariates else 1

    def _reset_state(self, covariates, rng):
        self._state = utils.format_state(self._seeder.seed(rng))          # First Generate Random seeded state
        for cov in covariates.values(): self._state += (cov * self._sign) # Now Add contribution from covariates

    def _advance_state(self, covariates, rng):
        self._state = utils.format_state(self._transition_model.transform(self._state, rng))
        for cov in covariates.values(): self._state += (cov * self._sign)


class DMWarpedAdditive(DiseaseModel):
    """
    Defines a Linear Transition model with additive effects, but with the potential of time-warping: i.e. the step
    between states is not necessarily fixed. This is implemented as a multiplicative effect of the covariates.

    Notes:
         1. This model is only valid with transition dynamics which are real-valued and additive.
         2. The time-warping is only applied to the contribution of covariates: as such, the state
            change itself is insensitive to time-warping. This can be circumvented by having a
            covariate act for the state-change.
         3. The time-warping is randomly generated before any state updates
    """

    def __init__(
            self,
            observation_models: dict,
            outcome_model: tuple,
            seeder: tuple,
            transition_model: tuple,
            warping_model: tuple,
            warp_covariates: dict
    ):
        """
        Initialises the Warped Additive Model

        :param observation_models: See DiseaseModel.__init__
        :param outcome_model: See DiseaseModel.__init__
        :param seeder: Model for seeding from
        :param transition_model: Model for defining Transition dynamics
        :param warping_model: Distribution over time-step size
        :param warp_covariates: Which covariates are potentially effected by the warp
        """
        # Initialise Base Class
        super().__init__(observation_models, outcome_model)

        # Update Time as another reporting variable
        self._other['TimeStep'] = None

        # Initialise own
        self._seeder = seeders.__dict__[seeder[0]](**seeder[1])
        self._transition_model = transfer_functions.__dict__[transition_model[0]](**transition_model[1])
        self._warping_model = seeders.__dict__[warping_model[0]](**warping_model[1])
        self._warp_cov = cp.deepcopy(warp_covariates)

    def _reset_state(self, covariates, rng):
        # Update State
        self._state = utils.format_state(self._seeder.seed(rng))    # First Generate Random seeded state
        for cov in covariates.values(): self._state += cov          # Now Add contribution from covariates
        # Also update Other Reporting Variables
        self._other['TimeStep'] = 0

    def _advance_state(self, covariates, rng):
        # Define Time-Warp (and store)
        _tw = self._warping_model.seed(rng)
        self._other['TimeStep'] = utils.format_output(_tw)
        # Update State (without time-warping)
        self._state = utils.format_state(self._transition_model.transform(self._state, rng))
        # Add contribution from covariates
        for c_name, cov in covariates.items():
            self._state += ((cov * _tw) if self._warp_cov[c_name] else cov)
