#################################################################
#               Definition of Transfer Functions                #
#   * These classes must implement a transform() method that    #
#     transforms the state.                                     #
#   * The classes themselves should not keep track of state.    #
#   * The state is in general a 1D vector (but can be scalar)   #
#################################################################
import abc
import copy as cp
import mpctools.extensions.npext as npext
import mpctools.extensions.utils as mptutils
import numpy as np
import scipy.stats as sstats

from . import utils


class TransferFunction(abc.ABC):
    """
    Abstract class for Transfer Functions.

    Responsible for passing in a valid state
    """
    def __init__(self):
        pass

    def transform(self, state, rng):
        """
        Public transform method

        :param state: State variable
        :param rng: Random Number generator (if needed)
        :return: transformed variable
        """
        return self._transform(utils.format_state(state), rng)

    @abc.abstractmethod
    def _transform(self, state, rng):
        pass


#####################################################################################
#    Probabilistic
#####################################################################################


class TFConditionalCategorical(TransferFunction):
    """
    (Conditional) Categorical Distribution

    Basically used to implement a Markov-chain. Note that this currently assumes that the state is a scalar
    """
    def __init__(self, probabilities):
        """
        Initialises the Class

        :param probabilities: an SxS matrix showing how each state (first-index) transitions to another
        """
        super().__init__()
        self.__probs = npext.sum_to_one(utils.format_transform(probabilities), axis=1)

    def _transform(self, state, rng):
        """
        Transitions the state forward by way of a conditional categorical distribution
        """
        probs = self.__probs[np.squeeze(state)]
        return rng.choice(len(probs), size=1, p=probs)


class TFGaussian(TransferFunction):
    """
    Simple Linear Multiplication plus Gaussian noise
    """
    def __init__(self, linear_matrix, means, covariance):
        """
        Initialises the Model

        :param linear_matrix: Transfer Matrix (linear mapping)
        :param means: The per-dimension mean (used as a bias term as well)
        :param covariance: Covariance matrix: can be also None or 0 (deterministic)
        """
        super().__init__()
        self.__A = utils.format_transform(linear_matrix)
        self.__U = np.atleast_1d(means)
        self.__C = None if ((covariance is None) or (covariance == 0)) else utils.format_transform(covariance)

    def _transform(self, state, rng):
        if self.__C is None:
            return self.__A @ state + self.__U
        else:
            return self.__A @ state + rng.multivariate_normal(self.__U, self.__C, size=(1,)).T


class TFTruncatedGaussian(TransferFunction):
    """
    Implements a truncated Gaussian following a linear transfer function.

    Note that the underlying scipy.stats truncated normal does not support single-side truncation: as such, if
      an upper/lower bound is not required, then this is transformed to 1000 standard deviations.
    """
    def __init__(self, reduction_matrix, mean, stdev, low, high):
        """
        Initialises the Model

        :param reduction_matrix: Transfer Matrix (linear mapping). Should map to scalar
        :param mean: The scalar mean of the distribution
        :param stdev: The scalar standard deviation of the distribution
        :param trunc_low: Lower bound of the truncation range (can be None)
        :param trunc_high: Upper bound of the truncation range (can be None)
        """
        super().__init__()
        self.__A = utils.format_transform(reduction_matrix)
        if self.__A.shape[0] != 1:
            raise ValueError('Truncated Gaussian currently only supports scalar output')
        self.__U = np.squeeze(mean)
        self.__C = np.squeeze(stdev)
        self.__min = mptutils.default(low, -1000)
        self.__max = mptutils.default(high, 1000)

    def _transform(self, state, rng):
        mean = np.squeeze(self.__A @ state + self.__U)
        a = (self.__min - mean) / self.__C
        b = (self.__max - mean) / self.__C
        return sstats.truncnorm.rvs(a, b, loc=mean, scale=self.__C, size=(1,), random_state=rng).T


#####################################################################################
#    Deterministic
#####################################################################################


class TFConstant(TransferFunction):
    """
    Constant output
    """
    def __init__(self, constant):
        """
        Initialises the Class
        """
        super().__init__()
        self.__constant = constant

    def _transform(self, state, rng=None):
        """
        Outputs the state

        :param state: input state
        :param rng: Random-Number Generator (ignored in this case)
        :return: copy of state
        """
        return cp.copy(self.__constant)


class TFIdentity(TransferFunction):
    """
    Defines an Identity (just emit the internal state)
    """
    def __init__(self):
        """
        Initialises the Class
        """
        super().__init__()

    def _transform(self, state, rng=None):
        """
        Outputs the state

        :param state: input state
        :param rng: Random-Number Generator (ignored in this case)
        :return: copy of state
        """
        return cp.copy(state)


class TFMap(TransferFunction):
    """
    Deterministic Mapping
    """
    def __init__(self, dict_map: dict):
        """
        Initialises the Class

        :param dict_map: Mapping based on a dictionary of key-value pairs.
        """
        super().__init__()
        self.__map = dict_map

    def _transform(self, state, rng=None):
        """
        Outputs the state

        :param state: input state (should be integral)
        :param rng: Random-Number Generator (ignored in this case)
        :return: copy of state
        """
        return self.__map[int(np.squeeze(state))]


class TFReLU(TransferFunction):
    """
    Defines a ReLU model: i.e. a linear mapping with a minimum

    Note that this is only valid for a uni-variate output (i.e. linear_matrix must be 1XD)
    """
    def __init__(self, linear_matrix, bias, slope=1):
        """
        Initialises the class

        :param linear_matrix: Pre-multiplier matrix (1xD)
        :param bias: Bias term
        """
        super().__init__()
        self.__A = utils.format_transform(linear_matrix)
        if self.__A.shape[0] != 1:
            raise ValueError('ReLU Activation requires scalar output')
        self.__U = bias
        self.__S = slope

    def _transform(self, state, rng=None):
        return max(np.squeeze(self.__A @ state + self.__U), 0) * self.__S


class TFLinear(TFGaussian):
    """
    Deterministic version of Linear Transition
    """
    def __init__(self, linear_matrix, bias):
        """
        Initialises the model

        :param linear_matrix: Linear Transform Matrix
        :param bias: Bias Term
        """
        super().__init__(linear_matrix, bias, None)


class TFThreshold(TransferFunction):
    """
    Defines a transform based on a linear-mixing and subsequently a threshold.
    """
    def __init__(self, reduction_matrix, threshold, true_value=1.0):
        """
        Initialises the class

        :param reduction_matrix: The pre-multiplier matrix to scale and reduce to scalar.
        :param threshold: The threshold beyond which the output is positive.
        :param true_value: The value to use for when the threshold is exceeded
        """
        super().__init__()
        self.__B = np.atleast_1d(reduction_matrix)
        self.__T = threshold
        self.__V = true_value

    def _transform(self, state, rng=None):
        """
        Outputs the linearly-transformed state

        :param state:
        :return: state emitted
        """
        return float(np.squeeze(self.__B @ state) > self.__T) * self.__V
