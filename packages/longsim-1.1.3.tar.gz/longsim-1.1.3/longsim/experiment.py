################################################################
#                  Definition of the Experiment                #
#  * The experiment encapsulates a complete experimental       #
#    setup.                                                    #
################################################################

import json
import mpctools.extensions.utils as mptutils
import mpctools.parallel as mptpar
import numpy as np
import os
import pandas as pd
import runpy
import scipy.stats as scstats

from . import data_generators
from . import utils


class Experiment:
    """
    Defines the Experimental configuration and running experiments.
    """
    def __init__(self, experimental_config: dict, parameter_config: str, data_generator: str, cfg_path: str, njobs=20, verbose=False):
        """
        Initialises the Experiment

        :param experimental_config: Configuration relating to the overall scope of the experiment. A dictionary.
        :param parameter_config: Configuration file for defining the methods for sampling parameters for the experiment.
        :param data_generator: Configuration file for defining the data-generating process
        """
        # Get Globals
        self.__J = experimental_config['PARAMETER_SAMPLES']
        self.__M = experimental_config['REPLICAS']
        self.__N = experimental_config['DATA_SAMPLES']
        self.__tstep = experimental_config['TIMESTEP']
        self.__random_seed = experimental_config['RANDOM_SEED']

        # Initialise Configuration dict and get parameter config
        self.__exp_cfg = {'EXPERIMENT': experimental_config, 'CFG_PATH': cfg_path}
        _ = runpy.run_path(os.path.join(cfg_path, parameter_config), init_globals={'CONFIG': self.__exp_cfg})
        self.__dcfg_path = os.path.join(cfg_path, data_generator)  # Store path

        # Other parameters
        self.__njobs = njobs
        self.__verbose = verbose

    def generate_experiment(self, output_dir, reseed=None):
        """
        Generate an experimental run

        :param output_dir: Directory where to store the experiments.
        :param reseed: If not None, reseed the random generator.
        :return: self, for chaining.
        """
        # Resolve Seed and randomness
        seed = self.__random_seed if reseed is None else reseed
        param_gen = np.random.default_rng(seed=seed)

        # Create Base Directory
        mptutils.make_dir(output_dir, _clear=True)
        with open(os.path.join(output_dir, 'Experiment.cfg'), 'w') as fout:
            fout.write('CONFIG = ')
            json.dump(self.__exp_cfg, fout, indent=2)

        # Iteration 1: Generate Random Parameters
        pbar = mptpar.ProgressBar(self.__J * self.__M).reset('Configurations')
        simulation_runs = []
        for j in range(self.__J):
            # Create Directory
            param_path = os.path.join(output_dir, f'ParameterSet_{j}')
            mptutils.make_dir(param_path)

            # Generate Parameters & store
            params = self._sample_params(param_gen, j)
            sim_cfg = runpy.run_path(self.__dcfg_path, init_globals={'TIMESTEP': self.__tstep, 'PARAMETERS': params})['DATA_GENERATOR']
            with open(os.path.join(param_path, 'DataGenerator.cfg'), 'w') as fout:
                fout.write('PARAMETERS = ')
                json.dump(params, fout, indent=2)  # Indicate samples parameters for convenience
                fout.write('\nDATA_GENERATOR = ')
                json.dump(sim_cfg, fout, indent=2)

            # Generate Random Replicas
            for m in range(self.__M):
                mptutils.make_dir(os.path.join(param_path, f'Replica_{m}'))
                simulation_runs.append((sim_cfg, seed+(j*self.__M)+m, self.__N, os.path.join(param_path, f'Replica_{m}', 'Data.bz2')))
                pbar.update()

        # Iteration 2: Parallel generation
        mptpar.parallelise(self._generate_replica, simulation_runs, n_jobs=self.__njobs, title='Simulating')

        # Return self
        return self

    def _sample_params(self, generator, index):
        """
        Convenience method to sample a particular parameter configuration

        :param generator: The current state of the random-number generator
        :param index: Used to iterate through grid-parameter (including in recursive fashion)
        :return: Dictionary with initialised parameters
        """
        params = {}
        recurse_grids = 1
        for p, (method, kwargs) in self.__exp_cfg['PARAMETERS'].items():
            if method.lower() == 'constant':
                params[p] = kwargs
            elif method.lower() == 'gridsearch':
                params[p] = kwargs[(index // recurse_grids) % len(kwargs)] # With wraparound
                recurse_grids *= len(kwargs)
            elif method in {'beta', 'truncnorm'}:
                params[p] = utils.format_output(scstats.__dict__[method].rvs(**kwargs, random_state=generator))
            else:
                params[p] = utils.format_output(generator.__getattribute__(method)(**kwargs))
        return params

    def _generate_replica(self, args):
        """
        Generate a replica of the experimental configuration

        :param sim_cfg: Simulator (Data-Generating) configuration
        :param seed: Random Seed to initialise with
        :return: Pandas DataFrame with simulated data.
        """
        # Expand Parameters
        sim_cfg, seed, num_samples, _path = args

        # Initialise Simulator and random number generator
        simulator = data_generators.__dict__[sim_cfg[0]](**sim_cfg[1], show_all=self.__verbose)
        sim_gen = np.random.default_rng(seed)

        # Generate Simulated Data
        data = {}
        for n in range(num_samples):
            data[n] = simulator.simulate(sim_gen)

        # Concatenate
        pd.concat(data, names=['Subject', 'Index']).to_pickle(_path)

