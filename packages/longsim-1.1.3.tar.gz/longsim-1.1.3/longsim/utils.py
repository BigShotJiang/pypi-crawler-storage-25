#################################################################
#                    Other General Utilities                    #
#################################################################
import copy as cp
import numpy as np


def format_state(v):
    """
    Formats the variable v as a state-vector (1D Column)

    :param v: scalar or list-like
    :return: 2D array representing a column vector
    """
    # Remove singleton dimensions
    v = np.squeeze(v)

    # Convert to column (if possible)
    if np.ndim(v) < 2:
        return np.atleast_2d(v).T  # If scalar, then transpose does not matter: if vector, this is row by default
    else:
        raise ValueError(f"'v' has {np.ndim(v)} non-singleton dimensions: cannot convert to column.")


def format_transform(m):
    """
    Formats the variable as a transform matrix

    :param m: Scalar or 2D array (1D would be ambiguous)
    :return: 2D matrix
    """
    match np.ndim(m):

        case 0:
            return np.atleast_2d(m)

        case 1:
            raise ValueError("1D vector is ambiguous. Pass a scalar or 2D matrix")

        case 2:
            return m

        case _:
            raise ValueError(f"Cannot convert {np.ndim(m)}-dimensional tensor to 2D matrix.")


def format_output(v):
    """
    Formats an output variable to minimal dimensionality

    :param v: array-like
    :return: minimal dimensionality representation of v (always a copy)
    """
    v = np.squeeze(v)
    return v.item() if (np.ndim(v) == 0) else cp.copy(v)
