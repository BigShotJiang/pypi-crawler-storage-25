################################################################
#                 Definition of Seeder Classes                 #
# * These are used to initialise state vectors etc.            #
# * Guaranteed to return a State Representation                #
################################################################
import abc
import mpctools.extensions.npext as npext

from . import utils


class Seeder(abc.ABC):

    def __init__(self):
        pass

    def seed(self, rng):
        """
        Generates the state-vector

        :param rng: Random number generator
        :return: Initialised state-vector (2D Column)
        """
        return utils.format_state(self._seed(rng))

    @abc.abstractmethod
    def _seed(self, rng):
        pass


class SUniform(Seeder):
    """
    Uniform distribution over N-D vector.

    Basically a wrapper around np.random.generator.uniform()
    """
    def __init__(self, low, high, size):
        """
        Initialises the seeder

        :param size: Size of the vector to generate (scalar or None)
        :param low: Lower boundary of the output interval
        :param high: Upper boundary of the output interval (not inclusive)
        """
        super().__init__()
        self.__s = size
        self.__l = low
        self.__h = high

    def _seed(self, rng):
        """
        Seeds the vector

        :param rng: Random number generator
        :return: Vector uniformly distributed
        """
        return rng.uniform(self.__l, self.__h, self.__s)


class SIntegers(Seeder):
    """
    Uniform distribution over range

    Basically a wrapper around np.random.generator.integers()
    """
    def __init__(self, low, high, size):
        """
        Initialises the seeder

        :param size: Size of the vector to generate (None or scalar)
        :param low: Lower boundary of the output interval
        :param high: Upper boundary of the output interval (not inclusive)
        """
        super().__init__()
        self.__s = size
        self.__l = low
        self.__h = high

    def _seed(self, rng):
        """
        Seeds the vector

        :param rng: Random number generator
        :return: Vector uniformly distributed
        """
        return rng.integers(self.__l, self.__h, self.__s)


class SCategorical(Seeder):
    """
    Categorical Distribution.

    Currently, this supports only size 1
    """
    def __init__(self, probabilities):
        """
        Initialises the seeder

        :param probabilities: The distribution over each value
        """
        super().__init__()
        self.__probs = npext.sum_to_one(probabilities)  # Ensure that they sum to 1

    def _seed(self, rng):
        """
        :param rng: Random Number Generator
        :return: random integer from 0 to len(probs)-1.
        """
        return rng.choice(len(self.__probs), size=1, p=self.__probs)


class SBeta(Seeder):
    """
    Beta distribution (optionally with scaling)
    """
    def __init__(self, alpha, beta, low=0, high=1):
        """
        Initialises the seeder

        :param alpha: Alpha parameter for Beta
        :param beta: Beta parameter for Beta
        :param low: Lower-bound of output interval
        :param high: Upper-bound of output interval
        """
        super().__init__()
        self.__a = alpha
        self.__b = beta
        self.__l = low
        self.__s = high - low

    def _seed(self, rng):
        return rng.beta(self.__a, self.__b) * self.__s + self.__l


class SGaussian(Seeder):
    """
    Gaussian Random Variable
    """
    def __init__(self, loc, scale, size=1):
        """
        Initialises the seeder

        :param loc: Mean
        :param scale: Standard-Deviation
        :param size: Size of the tensor
        """
        super().__init__()
        self.__sz = size
        self.__mu = loc
        self.__sd = scale

    def _seed(self, rng):
        """
        Seeds the vector

        :param rng: Random number generator
        :return: Vector normally distributed
        """
        return rng.normal(loc=self.__mu, scale=self.__sd, size=self.__sz)


class SMixtureModel(Seeder):
    """
    Mixture Model, where each component can be an arbitrary distribution

    Currently supports only scalar.
    """
    def __init__(self, components, probabilities):
        """
        Initialises the seeder

        :param components: List of two-tuple initialisers of component distributions
        :param probabilities: Probability over each component
        """
        super().__init__()

        # Setup the probabilities
        self.__mixture = SCategorical(probabilities)
        self.__components = [globals()[c[0]](**c[1]) for c in components]

    def _seed(self, rng):
        return self.__components[int(self.__mixture.seed(rng))].seed(rng)


class SConstant(Seeder):
    """
    Constant output
    """

    def __init__(self, constant):
        """
        Initialises the Class
        """
        super().__init__()
        self.__constant = constant

    def _seed(self, rng):
        return self.__constant
