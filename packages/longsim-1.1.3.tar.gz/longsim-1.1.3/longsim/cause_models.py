####################################################################
#                Definition of Cause Models Classes                #
#  * Cause Models include Covariates and Exposure Events.          #
#  * These classes encapsulates everything about a causal variable #
#      1. Internal State, with dynamic transitions, not exposed    #
#      2. Observation: i.e. how it is observed                     #
#      3. Initialisation Effect: how it effects the disease at     #
#         initialisation.                                          #
#      4. Dynamic Effect: how it effects the disease transition    #
#         dynamics.                                                #
####################################################################

import abc
import copy as cp
from . import seeders
from . import transfer_functions
from . import utils


class CauseModel(abc.ABC):
    """
    Abstract Base Class for Cause Model

    Responsible for:
        1. Maintaining the State variable (self._state) and observations/effects and models
        2. Generates observations and effects: note that these are generated during reset() and advance() and can then
           be queried multiple times without side-effects.

    Derived classes should:
        1. Implement _reset_state() method to initialise the state (usually through a seeder)
        2. Implement _advance_state() method to transition the state according to dynamics.
    """
    def __init__(self, observation_model, initial_effect_model, dynamic_effect_model):
        """
        Base Initialiser

        :param observation_model: A TransferFunction object defining the state observation
        :param initial_effect_model: A TransferFunction object defining the effect of the covariate on initialisation of the disease.
        :param dynamic_effect_model: A TransferFunction object defining the effect of the covariate on dynamics of the disease.
        """
        # Objects
        self.__mdl_obs = transfer_functions.__dict__[observation_model[0]](**observation_model[1])
        self.__mdl_eff_init = transfer_functions.__dict__[initial_effect_model[0]](**initial_effect_model[1])
        self.__mdl_eff_dyn = transfer_functions.__dict__[dynamic_effect_model[0]](**dynamic_effect_model[1])
        # States
        self._state = None
        self.__observation = None
        self.__initial_effect = None
        self.__dynamic_effect = None

    def reset(self, rng):
        # Reset Internal State
        self._reset_state(rng)

        # Update States
        self.__observation = utils.format_output(self.__mdl_obs.transform(self._state, rng))
        self.__initial_effect = utils.format_state(self.__mdl_eff_init.transform(self._state, rng))
        self.__dynamic_effect = None   # At Initialisation does not affect dynamics

        # Return self
        return self

    def advance(self, rng):
        # Advance Internal State
        self._advance_state(rng)

        # Update States
        self.__observation = utils.format_output(self.__mdl_obs.transform(self._state, rng))
        self.__initial_effect = None  # During Dynamics, initial effect is irrelevant
        self.__dynamic_effect = utils.format_state(self.__mdl_eff_dyn.transform(self._state, rng))

        # Return self
        return self

    @property
    def observation(self):
        return cp.copy(self.__observation)

    @property
    def initial_effect(self):
        return cp.copy(self.__initial_effect)

    @property
    def dynamic_effect(self):
        return cp.copy(self.__dynamic_effect)

    @property
    def state(self):
        return cp.copy(self._state)

    @abc.abstractmethod
    def _reset_state(self, rng):
        """
        Reset the State: should modify state in place, making sure it is a valid state representation

        :param rng: Random Number Generator
        :return: None
        """
        pass

    @abc.abstractmethod
    def _advance_state(self, rng):
        """
        Advance the State according to dynamics: should modify the state in place, making sure it is a valid state
          representation

        :param rng: Random Number Generator
        :return: None
        """
        pass


class CMDynamicCovariate(CauseModel):
    """
    Defines a Covariate Model that evolves in time
    """
    def __init__(self, observation_model, initial_effect_model, dynamic_effect_model, seeder, transition_model):
        """
        Initialises the Dynamic Covariate

        :param observation_model: See CauseModel.__init__
        :param initial_effect_model: See CauseModel.__init__
        :param dynamic_effect_model: See CauseModel.__init__
        :param seeder: Seeder object for initialising the covariate state
        :param transition_model: TransferFunction object for defining the state transition dynamics.
        """
        # Call Base Initialiser
        super().__init__(observation_model, initial_effect_model, dynamic_effect_model)

        # Initialise own objects
        self.__seeder = seeders.__dict__[seeder[0]](**seeder[1])
        self.__transition_model = transfer_functions.__dict__[transition_model[0]](**transition_model[1])

    def _reset_state(self, rng):
        self._state = utils.format_state(self.__seeder.seed(rng))

    def _advance_state(self, rng):
        self._state = utils.format_state(self.__transition_model.transform(self._state, rng))


class CMStaticCovariate(CMDynamicCovariate):
    """
    Defines a Covariate Model that is static over time
    """
    def __init__(self, observation_model, initial_effect_model, dynamic_effect_model, seeder):
        """
        Initialises the Static Covariate

        :param observation_model: See CauseModel.__init__
        :param initial_effect_model: See CauseModel.__init__
        :param dynamic_effect_model: See CauseModel.__init__
        :param seeder: See CMDynamicCovariate.__init__
        """
        super().__init__(observation_model, initial_effect_model, dynamic_effect_model, seeder, ('TFIdentity', {}))


class CMEventExposure(CauseModel):
    """
    Defines an instantaneous Exposure Event.

    The probability of experiencing an event follows a bernoulli distribution conditioned on not having experience
    the maximum number of events so far.
    """
    def __init__(self, observation_model, initial_effect_model, dynamic_effect_model, probability, max_events):
        """
        Initialises the Event Exposure Model

        :param observation_model: See CauseModel.__init__
        :param initial_effect_model: See CauseModel.__init__
        :param dynamic_effect_model: See CauseModel.__init__
        :param probability: Probability of experience event at each sample
        :param max_events: Maximum number of events that can be experienced
        """
        # Initialise Base Class
        super().__init__(observation_model, initial_effect_model, dynamic_effect_model)

        self.__p = probability
        self.__m = max_events
        self.__events = None

    def _reset_state(self, rng):
        self._state = 0
        self.__events = 0

    def _advance_state(self, rng):
        # Transition State
        if self.__events < self.__m:
            if rng.binomial(1, self.__p, size=None) > 0:
                self._state = 1
                self.__events += 1
            else:
                self._state = 0
        else:
            self._state = 0
