#################################################################
#                      General Conventions                      #
#  * The Disease Progression Simulator is a modular framework   #
#    for simulating time-series models in health settings.      #
#  * The core components are (nested in this order):            #
#    1. A Simulator which controls length and replicas (number  #
#       of independent observations/subjects)                   #
#    2. A Disease progression model which encapsulates a single #
#       subject                                                 #
#    3. A Disease model, Observation Model and Covariates       #
#  * State/Output variables are always assumed to be 1D Column  #
#    vectors (or scalars)                                       #
#################################################################