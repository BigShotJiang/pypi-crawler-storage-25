from .config import ConfiguConfig

__all__ = ["ConfiguConfig"]
