import json
import logging
import os
from typing import Any

import yaml

LOGGER = logging.getLogger(__name__)


class ConfiguConfig:
    """Typed access to config values from a flat YAML or JSON file.

    Services declare which keys they require. ConfiguConfig validates
    those keys exist and provides typed attribute access::

        config = ConfiguConfig.from_yaml(
            "config.yaml",
            required=["nats_url", "nats_port", "nats_subject_time"],
        )
        config.nats_url             # "nats://nats.svc.cluster.local:4222"
        config.nats_port            # 4222 (int, preserved from YAML)
        config.nats_subject_time    # "dev01.time-server"
    """

    _keys: set[str]
    _values: dict[str, Any]

    @classmethod
    def from_yaml(
        cls,
        path: str,
        required: list[str] | None = None,
        env_override: bool = True,
    ) -> "ConfiguConfig":
        with open(path) as f:
            values = yaml.safe_load(f) or {}
        return cls._build(values, required, source=path, env_override=env_override)

    @classmethod
    def from_json(
        cls,
        path: str,
        required: list[str] | None = None,
        env_override: bool = True,
    ) -> "ConfiguConfig":
        with open(path) as f:
            values = json.load(f)
        return cls._build(values, required, source=path, env_override=env_override)

    @classmethod
    def _build(
        cls,
        values: dict[str, Any],
        required: list[str] | None,
        source: str,
        env_override: bool = True,
    ) -> "ConfiguConfig":
        if env_override:
            overrides = 0
            for k in list(values.keys()):
                env_val = os.environ.get(k.upper())
                if env_val is not None:
                    values[k] = env_val
                    overrides += 1
            if overrides:
                LOGGER.info("Overrode %d config keys from environment", overrides)

        if required:
            missing = [k for k in required if k not in values]
            if missing:
                raise KeyError(f"Missing required config keys in {source}: {missing}")

        instance = cls()
        instance._keys = set(values.keys())
        instance._values = values
        for k, v in values.items():
            setattr(instance, k, v)

        LOGGER.info("Loaded %d config keys from %s", len(values), source)
        return instance

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        raise AttributeError(f"'{name}' not in config. Available: {sorted(self._keys)}")

    def get(self, key: str, default: Any = None) -> Any:
        return self._values.get(key, default)

    def keys(self) -> set[str]:
        return set(self._keys)

    def to_dict(self) -> dict[str, Any]:
        return dict(self._values)

    def to_env(self, *, uppercase: bool = True) -> dict[str, str]:
        """Return as env-var-style dict (for bridging to template-based config)."""
        return {
            (k.upper() if uppercase else k): str(v) for k, v in self._values.items()
        }
