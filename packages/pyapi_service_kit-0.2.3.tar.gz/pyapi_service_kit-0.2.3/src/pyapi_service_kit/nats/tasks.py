import asyncio
from datetime import datetime, timedelta
import logging
from typing import Any, Callable, Awaitable

import pytz

from nats.aio.client import Client as NATS

from .nats_payload import NatsPayload

LOGGER = logging.getLogger(__name__)


async def _wait_for_stop(stop_event: asyncio.Event | None) -> None:
    """Block until the stop event fires, or forever if None."""
    if stop_event is not None:
        await stop_event.wait()
    else:
        # Fallback: sleep indefinitely (cancellable via task.cancel())
        await asyncio.sleep(float("inf"))


async def check_health_task(nc: NATS, _subject: str, counter: int):
    if not nc.is_connected:
        LOGGER.warning("NATS connection lost, attempting to reconnect...")
    else:
        if counter % 10 == 0:
            LOGGER.info("NATS connection healthy")


async def subscribe_task(
    nc,
    listen_subject: str,
    cb: Callable[..., Awaitable[NatsPayload]],
    stop_event: asyncio.Event | None = None,
):
    sub = None
    try:
        sub = await nc.subscribe(listen_subject, cb=cb)
        LOGGER.info(f"[NATS Task] Subscribing to {listen_subject}")
        await _wait_for_stop(stop_event)
    except Exception as e:
        LOGGER.error(f"Error in subscription {listen_subject}: {e}")
        raise
    finally:
        if sub is not None:
            try:
                await sub.unsubscribe()
            except Exception:
                pass


async def request_reply_task(
    nc: NATS,
    api_subject: str,
    cb: Callable[..., Awaitable[Any]],
    stop_event: asyncio.Event | None = None,
):
    sub = None
    try:
        LOGGER.info(f"[NATS Task] Request-reply from {api_subject}")
        sub = await nc.subscribe(api_subject)
        while True:
            try:
                msg = await asyncio.wait_for(
                    sub.next_msg(),
                    timeout=1.0,
                )
            except asyncio.TimeoutError:
                if stop_event is not None and stop_event.is_set():
                    return
                continue

            msg.headers = msg.headers or dict()
            msg.headers["received_ts"] = datetime.now(pytz.timezone("UTC")).isoformat()
            response = await cb(msg)
            msg.headers["processed_ts"] = datetime.now(pytz.timezone("UTC")).isoformat()
            await msg.respond(response.as_bytes())
    except Exception as e:
        LOGGER.error(f"Error in request_reply task {api_subject}: {e}")
        raise
    finally:
        if sub is not None:
            try:
                await sub.unsubscribe()
            except Exception:
                pass


async def periodic_publisher_task(
    nc: NATS,
    publish_subject: str,
    timeout: timedelta,
    cb: Callable[..., Awaitable[NatsPayload]],
    *args: Any,
    stop_event: asyncio.Event | None = None,
    **kwargs: Any,
):
    counter = 0
    LOGGER.info(f"[NATS Task] Periodic publisher to {publish_subject}")
    while stop_event is None or not stop_event.is_set():
        try:
            await cb(nc, publish_subject, counter, *args, **kwargs)
            counter += 1
        except Exception as e:
            LOGGER.error(f"Error in periodic task {cb.__name__}: {e}")

        if stop_event is not None:
            try:
                await asyncio.wait_for(
                    _as_awaitable(stop_event.wait()),
                    timeout=timeout.total_seconds(),
                )
                return  # stop event fired
            except asyncio.TimeoutError:
                pass  # interval elapsed, loop again
        else:
            await asyncio.sleep(timeout.total_seconds())


async def triggered_js_publish_task(
    nc: NATS,
    listen_subject: str,
    publish_subject: str,
    cb: Callable[..., Awaitable[NatsPayload]],
    stop_event: asyncio.Event | None = None,
):
    js = nc.jetstream()

    async def message_handler(msg):
        try:
            result = await cb(msg)
            await js.publish(publish_subject, result.as_bytes())
            LOGGER.info(f"Published message to JetStream stream {publish_subject}")
        except Exception as e:
            LOGGER.error(f"Error handling message on {listen_subject}", exc_info=e)

    LOGGER.info(
        f"[NATS Task] Setup trigger for {listen_subject}, js_publish to {publish_subject}"
    )
    return await subscribe_task(
        nc, listen_subject, message_handler, stop_event=stop_event
    )


async def triggered_kv_put_task(
    nc: NATS,
    listen_subject: str,
    kv_bucket: str,
    key: str,
    cb: Callable[..., Awaitable[NatsPayload]],
    stop_event: asyncio.Event | None = None,
):
    js = nc.jetstream()

    async def message_handler(msg):
        try:
            result = await cb(msg)
            kv = await js.key_value(kv_bucket)
            await kv.put(key, result.as_bytes())
            LOGGER.info(f"Updated key-value {kv_bucket}[{key}] {str(result)}")
        except Exception as e:
            LOGGER.error(f"Error handling message on {listen_subject}", exc_info=e)

    LOGGER.info(
        f"[NATS Task] Setup trigger for {listen_subject}, kv_put to {kv_bucket}[{key}]"
    )
    return await subscribe_task(
        nc, listen_subject, message_handler, stop_event=stop_event
    )


async def once_kv_put_task(
    nc: NATS,
    kv_bucket: str,
    key: str,
    cb: Callable[..., Awaitable[NatsPayload]],
):
    js = nc.jetstream()

    try:
        result = await cb()
        kv = await js.key_value(kv_bucket)
        await kv.put(key, result.as_bytes())
        LOGGER.info(f"Updated key-value {kv_bucket}[{key}]")
    except Exception as e:
        LOGGER.error(f"Error handling message on {kv_bucket}[{key}]", exc_info=e)


async def _as_awaitable(coro):
    """Helper to make an already-started coroutine awaitable in wait_for."""
    return await coro
