"""Structured error types for backend operations."""


class BackendError(Exception):
    """Base class for backend errors."""

    def __init__(self, backend: str, detail: str):
        self.backend = backend
        self.detail = detail
        super().__init__(f"[{backend}] {detail}")


class BackendConnectionError(BackendError):
    """Failed to connect to a backend."""


class ResourceNotReadyError(BackendError):
    """A backend resource is not in the expected state."""

    def __init__(self, backend: str, resource: str, detail: str):
        self.resource = resource
        super().__init__(backend, f"{resource}: {detail}")


class DependencyMissingError(BackendError):
    """An optional dependency (sqlalchemy, boto3, etc.) is not installed."""
