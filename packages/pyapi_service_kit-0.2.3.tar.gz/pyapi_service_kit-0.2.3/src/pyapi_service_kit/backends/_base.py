"""Backend base class and shared utilities."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

LOGGER = logging.getLogger(__name__)


def _check_files(connection: dict, keys: list[str], backend_label: str) -> str | None:
    """Validate that file paths referenced in connection config exist.

    Returns an error message if any file is missing, or None if all ok.
    """
    for key in keys:
        path = connection.get(key)
        if path and not os.path.isfile(path):
            return f"file not found: {key}={path}"
    return None


@dataclass
class ConnectResult:
    """Result of a backend connection attempt."""

    ok: bool
    detail: str

    def __iter__(self):
        """Allow unpacking as (ok, detail) for backwards compatibility."""
        return iter((self.ok, self.detail))


@dataclass
class ResourceResult:
    """Result of a single resource readiness check."""

    name: str
    ready: bool
    detail: str

    def __iter__(self):
        """Allow unpacking as (name, ready, detail) for backwards compatibility."""
        return iter((self.name, self.ready, self.detail))


@dataclass
class _ResourceState:
    """Tracks readiness state of a single resource across retry rounds."""

    backend_name: str
    resource_name: str
    ready: bool = False
    last_detail: str = ""


class Backend:
    """Base class for backend readiness checks."""

    def __init__(self, name: str, backend_type: str, connection: dict):
        self.name = name
        self.backend_type = backend_type
        self._connection_config = connection
        self._connected = False

    @property
    def label(self) -> str:
        return f"{self.backend_type}:{self.name}"

    async def connect(self) -> ConnectResult:
        """Attempt to connect. Returns a ConnectResult."""
        raise NotImplementedError

    async def check_resources(self) -> list[ResourceResult]:
        """Check resources. Returns a list of ResourceResult."""
        raise NotImplementedError

    def get_client(self) -> Any:
        """Return the underlying client for use by service code."""
        raise NotImplementedError

    def resource_names(self) -> list[str]:
        """Return the list of resource names this backend checks."""
        return []
