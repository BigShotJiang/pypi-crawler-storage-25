"""CLI entry point for standalone backend readiness checks.

Usage::

    check-backend -f config.yaml
    check-backend -f config.yaml --name mariadb --name stone
    check-backend -f config.yaml --timeout 30
    check-backend -f config.yaml --once
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys

import yaml

from ._check import check_backends

LOGGER = logging.getLogger(__name__)


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="check-backend",
        description="Check that backend dependencies are ready.",
    )
    parser.add_argument(
        "-f",
        "--file",
        required=True,
        help="Path to the service config YAML file (must contain a 'backends' section).",
    )
    parser.add_argument(
        "--name",
        action="append",
        default=None,
        help="Backend name(s) to check. Can be specified multiple times. If omitted, checks all.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=None,
        help="Override max wait time in seconds (0 = forever).",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=None,
        help="Override retry interval in seconds.",
    )
    parser.add_argument(
        "--once",
        action="store_true",
        help="Check once and exit. Exit code 0 if all ready, 1 if not.",
    )
    args = parser.parse_args(argv)

    if not os.path.isfile(args.file):
        parser.error(f"Config file not found: {args.file}")

    return args


async def _async_main(args: argparse.Namespace) -> int:
    with open(args.file) as f:
        config = yaml.safe_load(f) or {}

    backends_config = config.get("backends", [])
    if not backends_config:
        LOGGER.error("No 'backends' section found in %s", args.file)
        return 1

    try:
        await check_backends(
            backends_config,
            interval=args.interval,
            timeout=args.timeout,
            names=args.name,
            once=args.once,
        )
        return 0
    except (TimeoutError, RuntimeError) as exc:
        LOGGER.error("%s", exc)
        return 1


def main(argv: list[str] | None = None) -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    args = _parse_args(argv)
    sys.exit(asyncio.run(_async_main(args)))
