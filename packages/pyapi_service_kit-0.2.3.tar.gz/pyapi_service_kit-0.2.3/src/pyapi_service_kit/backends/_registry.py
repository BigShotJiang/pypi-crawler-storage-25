"""Backends registry — holds connected clients for service code to retrieve."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._base import Backend
from ._db import DbBackend
from ._nats import NatsBackend
from ._s3 import S3Backend

if TYPE_CHECKING:
    from nats.aio.client import Client as NatsClient
    from nats.js.client import JetStreamContext
    from sqlalchemy import Engine

_DEFAULT = "default"


class Backends:
    """Registry of connected backends, returned by check_backends()."""

    def __init__(self) -> None:
        self._db: dict[str, DbBackend] = {}
        self._nats: dict[str, NatsBackend] = {}
        self._s3: dict[str, S3Backend] = {}

    def _register(self, backend: Backend) -> None:
        if isinstance(backend, DbBackend):
            self._db[backend.name] = backend
        elif isinstance(backend, NatsBackend):
            self._nats[backend.name] = backend
        elif isinstance(backend, S3Backend):
            self._s3[backend.name] = backend

    def db(self, name: str | None = None) -> Engine | None:
        """Get a SQLAlchemy Engine by backend name. None uses 'default'."""
        return self._db[name or _DEFAULT].get_client()

    def nats(
        self, name: str | None = None
    ) -> tuple[NatsClient | None, JetStreamContext | None]:
        """Get a (NatsClient, JetStreamContext) tuple by backend name. None uses 'default'."""
        return self._nats[name or _DEFAULT].get_client()

    def s3(self, name: str | None = None) -> Any:
        """Get a boto3 S3 client by backend name. None uses 'default'."""
        return self._s3[name or _DEFAULT].get_client()
