"""NATS JetStream backend."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._base import Backend, ConnectResult, ResourceResult, _check_files

if TYPE_CHECKING:
    from nats.aio.client import Client as NatsClient
    from nats.js.client import JetStreamContext


class NatsBackend(Backend):
    def __init__(
        self,
        name: str,
        connection: dict,
        streams: list[str] | None = None,
        kv: list[str] | None = None,
    ):
        super().__init__(name, "nats", connection)
        self._streams = streams or []
        self._kv = kv or []
        self._nc: NatsClient | None = None
        self._js: JetStreamContext | None = None

    async def connect(self) -> ConnectResult:
        try:
            try:
                import nats
            except ImportError:
                return ConnectResult(
                    False,
                    "nats-py not installed — install with: pip install nats-py",
                )
            import ssl

            c = self._connection_config
            options = dict(c.get("options", {}))

            file_err = _check_files(options, ["user_credentials", "tls_ca"], self.label)
            if file_err:
                return ConnectResult(False, file_err)

            servers = c.get("servers", [])

            # Process tls_ca into an SSL context
            tls_ca = options.pop("tls_ca", None)
            if tls_ca:
                ctx = ssl.create_default_context(cafile=tls_ca)
                # Workaround for CAs without key usage extension (Python 3.13+)
                ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
                options["tls"] = ctx

            self._nc = await nats.connect(servers, **options)
            self._js = self._nc.jetstream()
            self._connected = True
            return ConnectResult(True, "connected")
        except Exception as exc:
            self._connected = False
            return ConnectResult(False, str(exc))

    async def check_resources(self) -> list[ResourceResult]:
        results: list[ResourceResult] = []
        if not self._js:
            for s in self._streams:
                results.append(ResourceResult(f"stream {s}", False, "not connected"))
            for k in self._kv:
                results.append(ResourceResult(f"kv {k}", False, "not connected"))
            return results

        for stream_name in self._streams:
            try:
                await self._js.stream_info(stream_name)
                results.append(ResourceResult(f"stream {stream_name}", True, "exists"))
            except Exception as exc:
                err = str(exc)
                if "not found" in err.lower():
                    results.append(
                        ResourceResult(f"stream {stream_name}", False, "not found")
                    )
                else:
                    results.append(ResourceResult(f"stream {stream_name}", False, err))

        for kv_name in self._kv:
            try:
                await self._js.key_value(kv_name)
                results.append(ResourceResult(f"kv {kv_name}", True, "exists"))
            except Exception as exc:
                err = str(exc)
                if "not found" in err.lower():
                    results.append(ResourceResult(f"kv {kv_name}", False, "not found"))
                else:
                    results.append(ResourceResult(f"kv {kv_name}", False, err))

        return results

    def get_client(self) -> tuple[NatsClient | None, JetStreamContext | None]:
        return self._nc, self._js

    def resource_names(self) -> list[str]:
        return [f"stream {s}" for s in self._streams] + [f"kv {k}" for k in self._kv]
