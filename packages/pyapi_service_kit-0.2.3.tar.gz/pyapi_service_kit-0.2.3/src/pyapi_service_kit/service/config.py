from __future__ import annotations

from typing import Any, Iterator


class ServiceConfig:
    """Generic service configuration backed by a string-keyed dictionary.

    Services pass their own keys at construction time rather than relying on
    a library-level dataclass with hardcoded field names.  Values are
    accessible as attributes (``cfg.my_key``) or via :meth:`get`.

    Example::

        cfg = ServiceConfig(nats_subject_time="time.updates", db_table="app.users")
        assert cfg.nats_subject_time == "time.updates"
        assert cfg.get("missing") is None
    """

    def __init__(self, **kwargs: Any) -> None:
        self._data: dict[str, Any] = dict(kwargs)

    # --- attribute access ---------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        try:
            return self._data[name]
        except KeyError:
            raise AttributeError(
                f"'{type(self).__name__}' has no config key {name!r}"
            ) from None

    # --- dict-like helpers --------------------------------------------------

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def keys(self) -> list[str]:
        return list(self._data.keys())

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def __iter__(self) -> Iterator[str]:
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        items = ", ".join(f"{k}={v!r}" for k, v in self._data.items())
        return f"ServiceConfig({items})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ServiceConfig):
            return self._data == other._data
        return NotImplemented
