import pytest

from pyapi_service_kit.time.temporal_scheduler import TemporalScheduler


@pytest.fixture
def scheduler():
    s = TemporalScheduler()
    s.clear_subscribers()
    # Reset borg state for time
    s._borg.pop("now_epoch_ms", None)
    yield s
    s.clear_subscribers()


class TestTemporalScheduler:
    def test_subscribe_increases_count(self, scheduler):
        async def noop(t):
            pass

        scheduler.subscribe("sub1", noop, "1s")
        assert scheduler.get_subscriber_count() == 1

    def test_unsubscribe(self, scheduler):
        async def noop(t):
            pass

        scheduler.subscribe("sub1", noop, "1s")
        scheduler.unsubscribe("sub1")
        assert scheduler.get_subscriber_count() == 0

    def test_clear_subscribers(self, scheduler):
        async def noop(t):
            pass

        scheduler.subscribe("a", noop, "1s")
        scheduler.subscribe("b", noop, "1s")
        scheduler.clear_subscribers()
        assert scheduler.get_subscriber_count() == 0

    def test_borg_pattern_shares_state(self, scheduler):
        async def noop(t):
            pass

        scheduler.subscribe("shared", noop, "1s")
        other = TemporalScheduler()
        assert other.get_subscriber_count() == 1

    @pytest.mark.asyncio
    async def test_callback_fires(self, scheduler):
        results = []

        async def cb(t):
            results.append(t)

        scheduler.subscribe("sub1", cb, "1s")
        # next_tick starts at 0, so any time fires it
        await scheduler._check_subscribers(5000)
        assert results == [5000]

    @pytest.mark.asyncio
    async def test_callback_respects_granularity(self, scheduler):
        results = []

        async def cb(t):
            results.append(t)

        scheduler.subscribe("sub1", cb, "10s")
        await scheduler._check_subscribers(5000)  # fires (next_tick=0)
        await scheduler._check_subscribers(8000)  # does not fire (next_tick=10000)
        await scheduler._check_subscribers(10000)  # fires
        assert results == [5000, 10000]

    @pytest.mark.asyncio
    async def test_check_subscribers_none_is_noop(self, scheduler):
        results = []

        async def cb(t):
            results.append(t)

        scheduler.subscribe("sub1", cb, "1s")
        await scheduler._check_subscribers(None)
        assert results == []

    def test_calc_next_trigger_time(self, scheduler):
        assert scheduler._calc_next_trigger_time(5000, 10000) == 10000
        assert scheduler._calc_next_trigger_time(10000, 10000) == 20000
        assert scheduler._calc_next_trigger_time(15000, 10000) == 20000
