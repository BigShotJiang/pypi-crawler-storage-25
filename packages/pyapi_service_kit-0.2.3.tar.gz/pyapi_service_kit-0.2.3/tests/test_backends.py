"""Tests for pyapi_service_kit.backends."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pyapi_service_kit.backends import (
    Backends,
    ConnectResult,
    DbBackend,
    NatsBackend,
    ResourceNotReadyError,
    ResourceResult,
    S3Backend,
    check_backends,
)
from pyapi_service_kit.backends._check import _parse_backends


# ---------------------------------------------------------------------------
# DbBackend
# ---------------------------------------------------------------------------


class TestDbBackend:
    @pytest.mark.asyncio
    async def test_connect_success(self):
        backend = DbBackend(
            "testdb",
            {"hostname": "localhost", "port": 3306, "username": "u", "password": "p"},
            [],
        )
        with patch("sqlalchemy.create_engine") as mock_ce:
            mock_engine = MagicMock()
            mock_conn = MagicMock()
            mock_engine.connect.return_value.__enter__ = MagicMock(
                return_value=mock_conn
            )
            mock_engine.connect.return_value.__exit__ = MagicMock(return_value=False)
            mock_ce.return_value = mock_engine

            ok, detail = await backend.connect()
            assert ok is True
            assert "connected" in detail

    @pytest.mark.asyncio
    async def test_connect_failure(self):
        backend = DbBackend(
            "testdb",
            {"hostname": "bad", "port": 3306, "username": "u", "password": "p"},
            [],
        )
        with patch(
            "sqlalchemy.create_engine", side_effect=Exception("Connection refused")
        ):
            ok, detail = await backend.connect()
            assert ok is False
            assert "Connection refused" in detail

    @pytest.mark.asyncio
    async def test_check_resources_table_ready(self):
        backend = DbBackend("testdb", {}, [{"name": "app.users", "min_rows": 1}])
        mock_engine = MagicMock()
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_engine.connect.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.execute.return_value.scalar.return_value = 500
        backend._engine = mock_engine

        results = await backend.check_resources()
        assert len(results) == 1
        name, ready, detail = results[0]
        assert ready is True
        assert "500 rows" in detail

    @pytest.mark.asyncio
    async def test_check_resources_table_empty(self):
        backend = DbBackend("testdb", {}, [{"name": "app.users", "min_rows": 1}])
        mock_engine = MagicMock()
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_engine.connect.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.execute.return_value.scalar.return_value = 0
        backend._engine = mock_engine

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "found 0" in detail

    def test_get_client(self):
        backend = DbBackend("testdb", {}, [])
        backend._engine = "fake_engine"
        assert backend.get_client() == "fake_engine"

    def test_label(self):
        backend = DbBackend("primary", {}, [])
        assert backend.label == "db:primary"


# ---------------------------------------------------------------------------
# NatsBackend
# ---------------------------------------------------------------------------


class TestNatsBackend:
    @pytest.mark.asyncio
    async def test_check_stream_exists(self):
        backend = NatsBackend("messaging", {}, streams=["EVENTS"])
        backend._js = AsyncMock()
        backend._js.stream_info.return_value = {}

        results = await backend.check_resources()
        assert len(results) == 1
        name, ready, detail = results[0]
        assert ready is True

    @pytest.mark.asyncio
    async def test_check_stream_not_found(self):
        backend = NatsBackend("messaging", {}, streams=["EVENTS"])
        backend._js = AsyncMock()
        backend._js.stream_info.side_effect = Exception("stream not found")

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "not found" in detail

    @pytest.mark.asyncio
    async def test_check_kv_exists(self):
        backend = NatsBackend("messaging", {}, kv=["APP_STATE"])
        backend._js = AsyncMock()
        backend._js.key_value.return_value = {}

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is True

    @pytest.mark.asyncio
    async def test_check_kv_not_found(self):
        backend = NatsBackend("messaging", {}, kv=["APP_STATE"])
        backend._js = AsyncMock()
        backend._js.key_value.side_effect = Exception("bucket not found")

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "not found" in detail

    def test_get_client(self):
        backend = NatsBackend("messaging", {})
        backend._nc = "nc"
        backend._js = "js"
        assert backend.get_client() == ("nc", "js")


# ---------------------------------------------------------------------------
# S3Backend
# ---------------------------------------------------------------------------


class TestS3Backend:
    @pytest.mark.asyncio
    async def test_check_bucket_accessible(self):
        backend = S3Backend("storage", {}, buckets=["my-data"])
        backend._client = MagicMock()
        backend._client.head_bucket.return_value = {}

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is True

    @pytest.mark.asyncio
    async def test_check_bucket_not_found(self):
        backend = S3Backend("storage", {}, buckets=["my-data"])
        backend._client = MagicMock()
        backend._client.head_bucket.side_effect = Exception("Not Found")

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "not found" in detail

    @pytest.mark.asyncio
    async def test_check_bucket_access_denied(self):
        backend = S3Backend("storage", {}, buckets=["my-data"])
        backend._client = MagicMock()
        backend._client.head_bucket.side_effect = Exception(
            "InvalidAccessKeyId: bad key"
        )

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "access denied" in detail


# ---------------------------------------------------------------------------
# Config parsing
# ---------------------------------------------------------------------------


class TestParseBackends:
    def test_parse_db(self):
        config = [
            {
                "name": "primary",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": [{"name": "app.users"}],
            }
        ]
        backends = _parse_backends(config)
        assert len(backends) == 1
        assert isinstance(backends[0], DbBackend)
        assert backends[0].name == "primary"

    def test_parse_nats(self):
        config = [
            {
                "name": "messaging",
                "type": "nats",
                "connection": {"servers": ["nats://localhost:4222"]},
                "streams": ["EVENTS"],
                "kv": ["APP_STATE"],
            }
        ]
        backends = _parse_backends(config)
        assert len(backends) == 1
        assert isinstance(backends[0], NatsBackend)

    def test_parse_s3(self):
        config = [
            {
                "name": "storage",
                "type": "s3",
                "connection": {
                    "endpoint_url": "http://localhost:9000",
                    "access_key_id": "k",
                    "secret_access_key": "s",
                    "region": "us-east-1",
                },
                "buckets": ["b1"],
            }
        ]
        backends = _parse_backends(config)
        assert len(backends) == 1
        assert isinstance(backends[0], S3Backend)

    def test_parse_mixed(self):
        config = [
            {
                "name": "db1",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
            },
            {"name": "n1", "type": "nats", "connection": {"servers": []}},
            {
                "name": "s1",
                "type": "s3",
                "connection": {
                    "endpoint_url": "u",
                    "access_key_id": "k",
                    "secret_access_key": "s",
                    "region": "us-east-1",
                },
                "buckets": ["b"],
            },
        ]
        backends = _parse_backends(config)
        assert len(backends) == 3

    def test_parse_empty(self):
        assert _parse_backends([]) == []


# ---------------------------------------------------------------------------
# Backends registry
# ---------------------------------------------------------------------------


class TestBackendsRegistry:
    def test_db_accessor(self):
        registry = Backends()
        backend = DbBackend("primary", {}, [])
        backend._engine = "engine"
        registry._register(backend)
        assert registry.db("primary") == "engine"

    def test_nats_accessor(self):
        registry = Backends()
        backend = NatsBackend("messaging", {})
        backend._nc = "nc"
        backend._js = "js"
        registry._register(backend)
        assert registry.nats("messaging") == ("nc", "js")

    def test_s3_accessor(self):
        registry = Backends()
        backend = S3Backend("storage", {}, [])
        backend._client = "client"
        registry._register(backend)
        assert registry.s3("storage") == "client"

    def test_missing_key_raises(self):
        registry = Backends()
        with pytest.raises(KeyError):
            registry.db("nonexistent")


# ---------------------------------------------------------------------------
# check_backends (integration-level with mocks)
# ---------------------------------------------------------------------------


class TestCheckBackends:
    @pytest.mark.asyncio
    async def test_all_ready_immediately(self):
        config = [
            {
                "name": "testdb",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": [{"name": "app.items"}],
            },
        ]

        with (
            patch.object(
                DbBackend, "connect", return_value=ConnectResult(True, "connected")
            ),
            patch.object(
                DbBackend,
                "check_resources",
                return_value=[ResourceResult("app.items", True, "1 rows")],
            ),
        ):
            result = await check_backends(config, interval=0.01)

        assert isinstance(result, Backends)

    @pytest.mark.asyncio
    async def test_once_mode_fails(self):
        config = [
            {
                "name": "testdb",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": [{"name": "app.items", "min_rows": 1}],
            },
        ]

        with (
            patch.object(
                DbBackend, "connect", return_value=ConnectResult(True, "connected")
            ),
            patch.object(
                DbBackend,
                "check_resources",
                return_value=[
                    ResourceResult("app.items", False, "need \u22651 rows, found 0")
                ],
            ),
        ):
            with pytest.raises(ResourceNotReadyError):
                await check_backends(config, once=True)

    @pytest.mark.asyncio
    async def test_name_filter(self):
        config = [
            {
                "name": "db1",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": [{"name": "a.a"}],
            },
            {
                "name": "db2",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": [{"name": "b.b"}],
            },
        ]

        call_count = 0

        async def counting_connect(self):
            nonlocal call_count
            call_count += 1
            return ConnectResult(True, "connected")

        with (
            patch.object(DbBackend, "connect", counting_connect),
            patch.object(
                DbBackend,
                "check_resources",
                return_value=[ResourceResult("a.a", True, "ok")],
            ),
        ):
            await check_backends(config, names=["db1"], interval=0.01)

        assert call_count == 1  # only db1 was checked

    @pytest.mark.asyncio
    async def test_timeout(self):
        config = [
            {
                "name": "testdb",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": [{"name": "app.items"}],
            },
        ]

        with patch.object(
            DbBackend, "connect", return_value=ConnectResult(False, "refused")
        ):
            with pytest.raises(TimeoutError):
                await check_backends(config, timeout=0.05, interval=0.01)


# ---------------------------------------------------------------------------
# SQL injection prevention
# ---------------------------------------------------------------------------


class TestDbBackendSQLSafety:
    @pytest.mark.asyncio
    async def test_rejects_invalid_table_name(self):
        backend = DbBackend("testdb", {}, [{"name": "app; DROP TABLE users;--"}])
        mock_engine = MagicMock()
        backend._engine = mock_engine

        results = await backend.check_resources()
        assert len(results) == 1
        assert results[0].ready is False
        assert "invalid table name" in results[0].detail

    @pytest.mark.asyncio
    async def test_accepts_valid_dotted_name(self):
        backend = DbBackend("testdb", {}, [{"name": "myschema.users"}])
        mock_engine = MagicMock()
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_engine.connect.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.execute.return_value.scalar.return_value = 10
        backend._engine = mock_engine

        results = await backend.check_resources()
        assert results[0].ready is True

        # Verify the query uses backtick quoting
        call_args = mock_conn.execute.call_args[0][0]
        assert "`myschema`.`users`" in str(call_args)


# ---------------------------------------------------------------------------
# ConnectResult / ResourceResult structured types
# ---------------------------------------------------------------------------


class TestResultTypes:
    def test_connect_result_unpacking(self):
        r = ConnectResult(True, "connected")
        ok, detail = r
        assert ok is True
        assert detail == "connected"

    def test_resource_result_unpacking(self):
        r = ResourceResult("app.items", True, "500 rows")
        name, ready, detail = r
        assert name == "app.items"
        assert ready is True

    def test_resource_not_ready_error(self):
        err = ResourceNotReadyError("testdb", "app.items", "need more rows")
        assert err.backend == "testdb"
        assert err.resource == "app.items"
        assert "app.items" in str(err)
