from pyapi_service_kit.service.config import ServiceConfig


class TestServiceConfig:
    def test_empty_config(self):
        cfg = ServiceConfig()
        assert len(cfg) == 0
        assert cfg.keys() == []

    def test_attribute_access(self):
        cfg = ServiceConfig(nats_subject_time="time.updates")
        assert cfg.nats_subject_time == "time.updates"

    def test_get_with_default(self):
        cfg = ServiceConfig()
        assert cfg.get("missing") is None
        assert cfg.get("missing", "fallback") == "fallback"

    def test_get_existing(self):
        cfg = ServiceConfig(db_table="app.users")
        assert cfg.get("db_table") == "app.users"

    def test_missing_attribute_raises(self):
        cfg = ServiceConfig()
        try:
            cfg.nonexistent
            assert False, "Should have raised"
        except AttributeError:
            pass

    def test_contains(self):
        cfg = ServiceConfig(key="val")
        assert "key" in cfg
        assert "other" not in cfg

    def test_to_dict(self):
        cfg = ServiceConfig(a="1", b="2")
        assert cfg.to_dict() == {"a": "1", "b": "2"}

    def test_iteration(self):
        cfg = ServiceConfig(x="1", y="2")
        assert set(cfg) == {"x", "y"}

    def test_equality(self):
        a = ServiceConfig(x="1")
        b = ServiceConfig(x="1")
        c = ServiceConfig(x="2")
        assert a == b
        assert a != c

    def test_repr(self):
        cfg = ServiceConfig(name="test")
        assert "name='test'" in repr(cfg)

    def test_arbitrary_keys(self):
        cfg = ServiceConfig(
            nats_subject_time="time.updates",
            mariadb_table_spire_vectors="spire.vectors",
            nats_kv_api_key_vessel_vectors_latest="vessel_vectors_latest",
        )
        assert cfg.nats_subject_time == "time.updates"
        assert cfg.mariadb_table_spire_vectors == "spire.vectors"
        assert cfg.nats_kv_api_key_vessel_vectors_latest == "vessel_vectors_latest"
