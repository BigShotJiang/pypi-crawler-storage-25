"""Tests for NATS task graceful shutdown via stop_event."""

import asyncio
from datetime import timedelta
from unittest.mock import AsyncMock

import pytest

from pyapi_service_kit.nats.tasks import (
    subscribe_task,
    periodic_publisher_task,
)


class TestSubscribeTaskStopEvent:
    @pytest.mark.asyncio
    async def test_stops_on_event(self):
        nc = AsyncMock()
        sub_mock = AsyncMock()
        nc.subscribe.return_value = sub_mock

        stop = asyncio.Event()

        async def set_stop():
            await asyncio.sleep(0.05)
            stop.set()

        asyncio.get_event_loop().create_task(set_stop())
        await subscribe_task(nc, "test.subject", AsyncMock(), stop_event=stop)

        # Subscription should be cleaned up
        sub_mock.unsubscribe.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_unsubscribes_on_cancel(self):
        nc = AsyncMock()
        sub_mock = AsyncMock()
        nc.subscribe.return_value = sub_mock

        task = asyncio.create_task(subscribe_task(nc, "test.subject", AsyncMock()))
        await asyncio.sleep(0.05)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task

        sub_mock.unsubscribe.assert_awaited_once()


class TestPeriodicPublisherStopEvent:
    @pytest.mark.asyncio
    async def test_stops_on_event(self):
        nc = AsyncMock()
        call_count = 0

        async def cb(nc, subject, counter):
            nonlocal call_count
            call_count += 1

        stop = asyncio.Event()

        async def set_stop():
            await asyncio.sleep(0.15)
            stop.set()

        asyncio.get_event_loop().create_task(set_stop())

        await periodic_publisher_task(
            nc, "test.subject", timedelta(seconds=0.05), cb, stop_event=stop
        )

        # Should have run at least once before stopping
        assert call_count >= 1
