import pytest
import json
import yaml

from pyapi_service_kit.configu.config import ConfiguConfig


@pytest.fixture
def yaml_config(tmp_path):
    data = {"nats_url": "nats://localhost:4222", "nats_port": 4222, "debug": True}
    path = tmp_path / "config.yaml"
    path.write_text(yaml.dump(data))
    return str(path)


@pytest.fixture
def json_config(tmp_path):
    data = {"api_key": "secret", "timeout": 30}
    path = tmp_path / "config.json"
    path.write_text(json.dumps(data))
    return str(path)


class TestConfiguConfigYaml:
    def test_loads_values(self, yaml_config):
        cfg = ConfiguConfig.from_yaml(yaml_config)
        assert cfg.nats_url == "nats://localhost:4222"
        assert cfg.nats_port == 4222
        assert cfg.debug is True

    def test_required_keys_pass(self, yaml_config):
        cfg = ConfiguConfig.from_yaml(yaml_config, required=["nats_url", "nats_port"])
        assert cfg.nats_url == "nats://localhost:4222"

    def test_missing_required_raises(self, yaml_config):
        with pytest.raises(KeyError, match="Missing required"):
            ConfiguConfig.from_yaml(yaml_config, required=["nonexistent"])

    def test_get_with_default(self, yaml_config):
        cfg = ConfiguConfig.from_yaml(yaml_config)
        assert cfg.get("nats_url") == "nats://localhost:4222"
        assert cfg.get("missing", "fallback") == "fallback"

    def test_keys(self, yaml_config):
        cfg = ConfiguConfig.from_yaml(yaml_config)
        assert cfg.keys() == {"nats_url", "nats_port", "debug"}

    def test_to_dict(self, yaml_config):
        cfg = ConfiguConfig.from_yaml(yaml_config)
        d = cfg.to_dict()
        assert d["nats_port"] == 4222

    def test_to_env(self, yaml_config):
        cfg = ConfiguConfig.from_yaml(yaml_config)
        env = cfg.to_env()
        assert env["NATS_URL"] == "nats://localhost:4222"
        assert env["NATS_PORT"] == "4222"

    def test_to_env_no_uppercase(self, yaml_config):
        cfg = ConfiguConfig.from_yaml(yaml_config)
        env = cfg.to_env(uppercase=False)
        assert "nats_url" in env

    def test_missing_attr_raises(self, yaml_config):
        cfg = ConfiguConfig.from_yaml(yaml_config)
        with pytest.raises(AttributeError, match="not in config"):
            _ = cfg.nonexistent

    def test_env_override(self, yaml_config, monkeypatch):
        monkeypatch.setenv("NATS_URL", "nats://overridden:4222")
        cfg = ConfiguConfig.from_yaml(yaml_config)
        assert cfg.nats_url == "nats://overridden:4222"
        assert cfg.nats_port == 4222  # unchanged, no env override for this key

    def test_env_override_disabled(self, yaml_config, monkeypatch):
        monkeypatch.setenv("NATS_URL", "nats://overridden:4222")
        cfg = ConfiguConfig.from_yaml(yaml_config, env_override=False)
        assert cfg.nats_url == "nats://localhost:4222"


class TestConfiguConfigJson:
    def test_loads_json(self, json_config):
        cfg = ConfiguConfig.from_json(json_config)
        assert cfg.api_key == "secret"
        assert cfg.timeout == 30
