from __future__ import annotations

__version__ = "8.0.7"  # x-release-please-version

__api_subversion__ = "20230101"
