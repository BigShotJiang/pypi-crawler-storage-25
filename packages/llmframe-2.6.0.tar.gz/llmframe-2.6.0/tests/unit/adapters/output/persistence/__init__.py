"""Persistence adapter unit tests."""
