"""Output adapter unit tests."""
