import base64
import secrets
import urllib.parse

import pyotp

from allauth.mfa.models import Authenticator
from allauth.mfa.utils import encrypt
from django.conf import settings as django_settings
from django.db.models import Q

from .base import TwoFactorBackend


class AllauthBackend(TwoFactorBackend):
    # allauth >= 65.0

    def get_confirmed_totp_device(self, user):
        return (
            Authenticator.objects.filter(user=user, type=Authenticator.Type.TOTP)
            .exclude(data__has_key="_pending")
            .first()
        )

    def has_confirmed_totp_device(self, user) -> bool:
        # True if a confirmed device exists, or if a pending device is replacing one
        return (
            Authenticator.objects.filter(user=user, type=Authenticator.Type.TOTP)
            .filter(~Q(data__has_key="_pending") | Q(data__has_key="_prev_data"))
            .exists()
        )

    def get_pending_totp_device(self, user):
        return Authenticator.objects.filter(
            user=user, type=Authenticator.Type.TOTP, data__has_key="_pending"
        ).first()

    def create_pending_totp_device(self, user):
        secret = base64.b32encode(secrets.token_bytes(20)).decode("utf-8")
        new_data = {"secret": encrypt(secret), "_pending": True}

        # Preserve existing confirmed device so cancel can restore it
        existing = (
            Authenticator.objects.filter(user=user, type=Authenticator.Type.TOTP)
            .exclude(data__has_key="_pending")
            .first()
        )
        if existing:
            new_data["_prev_data"] = existing.data

        instance, _ = Authenticator.objects.update_or_create(
            user=user,
            type=Authenticator.Type.TOTP,
            defaults={"data": new_data},
        )
        return instance

    def confirm_device(self, user, device):
        data = dict(device.data)
        data.pop("_pending", None)
        data.pop("_prev_data", None)
        device.data = data
        device.save()

    def delete_unconfirmed_devices(self, user):
        device = Authenticator.objects.filter(
            user=user, type=Authenticator.Type.TOTP, data__has_key="_pending"
        ).first()
        if device is None:
            return
        prev_data = device.data.get("_prev_data")
        if prev_data:
            device.data = prev_data
            device.save()
        else:
            device.delete()

    def delete_all_totp_devices(self, user):
        Authenticator.objects.filter(user=user, type=Authenticator.Type.TOTP).delete()

    def get_totp_url(self, device, user) -> str:
        secret = device.data["secret"]
        issuer = getattr(django_settings, "MFA_TOTP_ISSUER", "")
        account = f"{user.username} ({user.email})" if user.email else user.username
        label = f"{issuer}:{account}" if issuer else account
        params = {"secret": secret, "algorithm": "SHA1", "digits": "6", "period": "30"}
        if issuer:
            params["issuer"] = issuer
        return f"otpauth://totp/{urllib.parse.quote(label, safe='')}?{urllib.parse.urlencode(params)}"

    def verify_totp_token(self, device, token: str) -> bool:
        return device is not None and device.wrap().validate_code(token)

    def get_totp_code(self, device) -> str:
        return pyotp.TOTP(device.data["secret"]).now()

    def get_recovery_device(self, user):
        return Authenticator.objects.filter(
            user=user, type=Authenticator.Type.RECOVERY_CODES
        ).first()

    def verify_recovery_token(self, device, token: str) -> bool:
        return device is not None and device.wrap().validate_code(token)

    def create_recovery_codes(self, user, count: int) -> list:
        Authenticator.objects.filter(
            user=user, type=Authenticator.Type.RECOVERY_CODES
        ).delete()
        instance = Authenticator.objects.create(
            user=user,
            type=Authenticator.Type.RECOVERY_CODES,
            data={"seed": encrypt(secrets.token_hex(40)), "used_mask": 0},
        )
        return instance.wrap().generate_codes()

    def delete_recovery_devices(self, user):
        Authenticator.objects.filter(
            user=user, type=Authenticator.Type.RECOVERY_CODES
        ).delete()

    def get_recovery_codes_remaining(self, user) -> int:
        device = self.get_recovery_device(user)
        if device is None:
            return 0
        return len(device.wrap().get_unused_codes())
