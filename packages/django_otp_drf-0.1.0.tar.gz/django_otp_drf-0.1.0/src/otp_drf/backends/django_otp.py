import base64
import urllib.parse

import pyotp
from django_otp.plugins.otp_static.models import StaticDevice, StaticToken
from django_otp.plugins.otp_totp.models import TOTPDevice

from .base import TwoFactorBackend


class DjangoOTPBackend(TwoFactorBackend):
    def get_confirmed_totp_device(self, user):
        return TOTPDevice.objects.filter(user=user, confirmed=True).first()

    def has_confirmed_totp_device(self, user) -> bool:
        return TOTPDevice.objects.filter(user=user, confirmed=True).exists()

    def get_pending_totp_device(self, user):
        return TOTPDevice.objects.filter(user=user, confirmed=False).first()

    def create_pending_totp_device(self, user):
        return TOTPDevice.objects.create(user=user, confirmed=False, name="default")

    def confirm_device(self, user, device):
        old = TOTPDevice.objects.filter(user=user, confirmed=True).first()
        device.confirmed = True
        device.save()
        if old is not None and old.pk != device.pk:
            old.delete()

    def delete_unconfirmed_devices(self, user):
        TOTPDevice.objects.filter(user=user, confirmed=False).delete()

    def delete_all_totp_devices(self, user):
        TOTPDevice.objects.filter(user=user).delete()

    def get_totp_url(self, device, user) -> str:
        parsed = urllib.parse.urlparse(device.config_url)
        params = urllib.parse.parse_qsl(parsed.query)
        issuer = next((v for k, v in params if k == "issuer"), "")
        account = f"{user.username} ({user.email})" if user.email else user.username
        label = f"{issuer}:{account}" if issuer else account
        return f"otpauth://totp/{urllib.parse.quote(label)}?{urllib.parse.urlencode(params)}"

    def verify_totp_token(self, device, token: str) -> bool:
        return device is not None and device.verify_token(token)

    def get_totp_code(self, device) -> str:
        return pyotp.TOTP(base64.b32encode(device.bin_key).decode()).now()

    def get_recovery_device(self, user):
        return StaticDevice.objects.filter(user=user, confirmed=True).first()

    def verify_recovery_token(self, device, token: str) -> bool:
        return device is not None and device.verify_token(token)

    def create_recovery_codes(self, user, count: int) -> list:
        StaticDevice.objects.filter(user=user).delete()
        device = StaticDevice.objects.create(user=user, confirmed=True, name="recovery")
        codes = []
        for _ in range(count):
            token = StaticToken.random_token()
            StaticToken.objects.create(device=device, token=token)
            codes.append(token)
        return codes

    def delete_recovery_devices(self, user):
        StaticDevice.objects.filter(user=user).delete()

    def get_recovery_codes_remaining(self, user) -> int:
        device = StaticDevice.objects.filter(user=user, confirmed=True).first()
        return device.token_set.count() if device is not None else 0
