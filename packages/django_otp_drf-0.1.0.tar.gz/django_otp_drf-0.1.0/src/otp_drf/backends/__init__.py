ALLAUTH_DEPENDENCIES = [
    "django.contrib.sites",
    "allauth",
    "allauth.account",
    "allauth.mfa",
]

DJANGO_OTP_DEPENDENCIES = [
    "django_otp",
    "django_otp.plugins.otp_static",
    "django_otp.plugins.otp_totp",
]
