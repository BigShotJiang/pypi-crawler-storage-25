from abc import ABC, abstractmethod


class TwoFactorBackend(ABC):
    # TOTP device operations

    @abstractmethod
    def get_confirmed_totp_device(self, user): ...

    @abstractmethod
    def has_confirmed_totp_device(self, user) -> bool: ...

    @abstractmethod
    def get_pending_totp_device(self, user): ...

    @abstractmethod
    def create_pending_totp_device(self, user): ...

    @abstractmethod
    def confirm_device(self, user, device):
        """Confirm the pending device and delete any previously confirmed one."""
        ...

    @abstractmethod
    def delete_unconfirmed_devices(self, user): ...

    @abstractmethod
    def delete_all_totp_devices(self, user): ...

    @abstractmethod
    def get_totp_url(self, device, user) -> str:
        """Return the final otpauth:// URL with issuer and account label applied."""
        ...

    @abstractmethod
    def verify_totp_token(self, device, token: str) -> bool: ...

    @abstractmethod
    def get_totp_code(self, device) -> str:
        """Return the current TOTP code for a device (used in tests)."""
        ...

    # Recovery code operations

    @abstractmethod
    def get_recovery_device(self, user): ...

    @abstractmethod
    def verify_recovery_token(self, device, token: str) -> bool: ...

    @abstractmethod
    def create_recovery_codes(self, user, count: int) -> list: ...

    @abstractmethod
    def delete_recovery_devices(self, user): ...

    @abstractmethod
    def get_recovery_codes_remaining(self, user) -> int: ...
