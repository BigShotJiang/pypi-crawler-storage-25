from django.db import models


class TwoFactorEnforcementMixin(models.Model):
    enforce_2fa = models.BooleanField(default=False)
    enforce_2fa_deadline = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True
