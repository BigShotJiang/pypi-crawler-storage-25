import base64
import io

import qrcode
import qrcode.image.svg
import structlog
from django.contrib.auth import login
from django.db import transaction
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from . import conf, signals
from .session import clear_2fa_session, get_2fa_session_user, set_2fa_session

LOGGER = structlog.get_logger(__name__)

_LoginThrottle = conf.get_login_throttle_class()
_ActionThrottle = conf.get_action_throttle_class()


def _get_pending_user(session):
    return get_2fa_session_user(session, "pending")


def _get_recovery_user(session):
    return get_2fa_session_user(session, "recovery")


def _get_2fa_user(request):
    if request.user.is_authenticated:
        return request.user
    return _get_recovery_user(request.session)


def _generate_qr_image(config_url) -> str:
    img = qrcode.make(config_url, image_factory=qrcode.image.svg.SvgPathImage)
    buffer = io.BytesIO()
    img.save(buffer)
    return "data:image/svg+xml;base64," + base64.b64encode(buffer.getvalue()).decode()


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([_LoginThrottle])
def api_2fa_verify(request):
    user = _get_pending_user(request.session)
    if user is None:
        return Response(
            {"detail": "No pending 2FA session. Please log in again."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    token = request.data.get("token", "")
    backend = conf.get_backend()
    with transaction.atomic():
        device = backend.get_confirmed_totp_device(user)
        verified = backend.verify_totp_token(device, token)
        used_recovery = False
        if not verified:
            recovery = backend.get_recovery_device(user)
            if backend.verify_recovery_token(recovery, token):
                verified = True
                used_recovery = True
        if not verified:
            LOGGER.warning(
                "user.2fa_verify_failed", user_id=user.id, username=user.username
            )
            return Response(
                {"detail": "Invalid verification code."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        auth_backend = clear_2fa_session(request.session)
        if used_recovery:
            set_2fa_session(request.session, user.pk, auth_backend, "recovery")
            detail = "Recovery code accepted. Please set up a new authenticator device."
        else:
            login(request, user, backend=auth_backend)
            detail = "Logged in successfully."

    LOGGER.info(
        "user.logged_in_2fa",
        user_id=user.id,
        username=user.username,
        used_recovery=used_recovery,
    )
    if used_recovery:
        signals.recovery_code_login.send(sender=user, request=request)

    serializer_cls = conf.get_user_serializer()
    user_data = (
        serializer_cls(user, context={"request": request}).data
        if serializer_cls
        else {"id": user.pk, "username": user.username}
    )
    extra = conf.get_extra_verify_response(user, request)
    return Response(
        {"detail": detail, "user": user_data, "used_recovery": used_recovery, **extra},
        status=status.HTTP_200_OK,
    )


@api_view(["GET"])
@permission_classes([AllowAny])
def api_2fa_status(request):
    user = _get_2fa_user(request)
    if user is None:
        return Response(
            {"detail": "Authentication required."}, status=status.HTTP_403_FORBIDDEN
        )
    backend = conf.get_backend()
    is_recovery = not request.user.is_authenticated
    is_enabled = backend.has_confirmed_totp_device(user)
    recovery_codes_remaining = 0
    if is_enabled or is_recovery:
        recovery_codes_remaining = backend.get_recovery_codes_remaining(user)
    deadline = getattr(user, "enforce_2fa_deadline", None)
    return Response(
        {
            "is_enabled": is_enabled,
            "recovery_codes_remaining": recovery_codes_remaining,
            "recovery_login": is_recovery,
            "enforce_2fa": getattr(user, "enforce_2fa", False),
            "enforce_2fa_deadline": deadline.isoformat() if deadline else None,
        }
    )


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([_LoginThrottle])
def api_2fa_setup(request):
    user = _get_2fa_user(request)
    if user is None:
        return Response(
            {"detail": "Authentication required."}, status=status.HTTP_403_FORBIDDEN
        )
    backend = conf.get_backend()
    is_recovery = not request.user.is_authenticated
    if is_recovery:
        backend.delete_all_totp_devices(user)
    else:
        backend.delete_unconfirmed_devices(user)

    device = backend.create_pending_totp_device(user)
    config_url = backend.get_totp_url(device, user)
    qr_code = _generate_qr_image(config_url)
    return Response({"config_url": config_url, "qr_code": qr_code})


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([_LoginThrottle])
def api_2fa_confirm(request):
    user = _get_2fa_user(request)
    if user is None:
        return Response(
            {"detail": "Authentication required."}, status=status.HTTP_403_FORBIDDEN
        )
    backend = conf.get_backend()
    token = request.data.get("token", "")
    device = backend.get_pending_totp_device(user)
    if device is None:
        return Response(
            {"detail": "No pending 2FA setup found."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    if not backend.verify_totp_token(device, token):
        LOGGER.warning(
            "user.2fa_confirm_failed", user_id=user.id, username=user.username
        )
        return Response(
            {"detail": "Invalid verification code."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    is_recovery = not request.user.is_authenticated
    with transaction.atomic():
        is_reset = backend.has_confirmed_totp_device(user)
        backend.confirm_device(user, device)
        recovery_device = backend.get_recovery_device(user)
        kept_codes = (
            recovery_device is not None
            and backend.get_recovery_codes_remaining(user) > 0
        )
        codes = (
            None
            if kept_codes
            else backend.create_recovery_codes(user, conf.get_recovery_code_count())
        )
        deadline = getattr(user, "enforce_2fa_deadline", None)
        if deadline is not None:
            user.enforce_2fa_deadline = None
            user.save(update_fields=["enforce_2fa_deadline"])

    if is_recovery:
        auth_backend = clear_2fa_session(request.session)
        login(request, user, backend=auth_backend)

    LOGGER.info("user.2fa_enabled", user_id=user.id, username=user.username)
    if is_reset:
        signals.two_factor_reset.send(sender=user, request=request)
    return Response(
        {
            "detail": "Two-factor authentication reset."
            if is_reset
            else "Two-factor authentication enabled.",
            "recovery_codes": codes,
        }
    )


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([_LoginThrottle])
def api_2fa_cancel_setup(request):
    user = _get_2fa_user(request)
    if user is None:
        return Response(
            {"detail": "Authentication required."}, status=status.HTTP_403_FORBIDDEN
        )
    backend = conf.get_backend()
    if not backend.has_confirmed_totp_device(user):
        if not request.user.is_authenticated:
            return Response(
                {
                    "detail": "Cannot cancel setup: two-factor authentication is not enabled."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )
        backend.delete_unconfirmed_devices(user)
        clear_2fa_session(request.session)
        return Response({"detail": "Setup cancelled.", "recovery_codes": None})

    backend.delete_unconfirmed_devices(user)
    codes = None
    if backend.get_recovery_codes_remaining(user) == 0:
        codes = backend.create_recovery_codes(user, conf.get_recovery_code_count())
    clear_2fa_session(request.session)
    return Response({"detail": "Setup cancelled.", "recovery_codes": codes})


@api_view(["POST"])
@permission_classes([IsAuthenticated])
@throttle_classes([_ActionThrottle])
def api_2fa_disable(request):
    if getattr(request.user, "enforce_2fa", False):
        return Response(
            {
                "detail": "Two-factor authentication cannot be disabled for this account."
            },
            status=status.HTTP_403_FORBIDDEN,
        )

    backend = conf.get_backend()
    token = request.data.get("token", "")
    if not backend.has_confirmed_totp_device(request.user):
        return Response(
            {"detail": "Two-factor authentication is not enabled."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    device = backend.get_confirmed_totp_device(request.user)
    recovery = backend.get_recovery_device(request.user)
    if not backend.verify_totp_token(
        device, token
    ) and not backend.verify_recovery_token(recovery, token):
        LOGGER.warning(
            "user.2fa_disable_failed",
            user_id=request.user.id,
            username=request.user.username,
        )
        return Response(
            {"detail": "Invalid verification code."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    backend.delete_all_totp_devices(request.user)
    backend.delete_recovery_devices(request.user)
    LOGGER.info(
        "user.2fa_disabled", user_id=request.user.id, username=request.user.username
    )
    signals.two_factor_disabled.send(sender=request.user, request=request)
    return Response({"detail": "Two-factor authentication disabled."})


@api_view(["POST"])
@permission_classes([IsAuthenticated])
@throttle_classes([_ActionThrottle])
def api_2fa_regenerate_recovery(request):
    backend = conf.get_backend()
    token = request.data.get("token", "")
    if not backend.has_confirmed_totp_device(request.user):
        return Response(
            {"detail": "Two-factor authentication is not enabled."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    device = backend.get_confirmed_totp_device(request.user)
    recovery = backend.get_recovery_device(request.user)
    if not backend.verify_totp_token(
        device, token
    ) and not backend.verify_recovery_token(recovery, token):
        LOGGER.warning(
            "user.2fa_regenerate_failed",
            user_id=request.user.id,
            username=request.user.username,
        )
        return Response(
            {"detail": "Invalid verification code."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    codes = backend.create_recovery_codes(request.user, conf.get_recovery_code_count())
    LOGGER.info(
        "user.2fa_recovery_regenerated",
        user_id=request.user.id,
        username=request.user.username,
    )
    signals.recovery_codes_regenerated.send(sender=request.user, request=request)
    return Response({"detail": "Recovery codes regenerated.", "recovery_codes": codes})


@api_view(["POST"])
@permission_classes([IsAuthenticated])
@throttle_classes([_ActionThrottle])
def api_2fa_reset(request):
    backend = conf.get_backend()
    token = request.data.get("token", "")
    if not backend.has_confirmed_totp_device(request.user):
        return Response(
            {"detail": "Two-factor authentication is not enabled."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    device = backend.get_confirmed_totp_device(request.user)
    recovery = backend.get_recovery_device(request.user)
    if not backend.verify_totp_token(
        device, token
    ) and not backend.verify_recovery_token(recovery, token):
        LOGGER.warning(
            "user.2fa_reset_failed",
            user_id=request.user.id,
            username=request.user.username,
        )
        return Response(
            {"detail": "Invalid verification code."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    with transaction.atomic():
        backend.delete_unconfirmed_devices(request.user)
        new_device = backend.create_pending_totp_device(request.user)

    config_url = backend.get_totp_url(new_device, request.user)
    qr_code = _generate_qr_image(config_url)
    remaining = backend.get_recovery_codes_remaining(request.user)
    LOGGER.info(
        "user.2fa_reset", user_id=request.user.id, username=request.user.username
    )
    return Response(
        {
            "config_url": config_url,
            "qr_code": qr_code,
            "recovery_codes_remaining": remaining,
        }
    )
