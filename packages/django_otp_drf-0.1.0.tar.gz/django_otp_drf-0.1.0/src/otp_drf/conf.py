import importlib

from django.conf import settings as django_settings

_backend_cache = {}


def _get(name, default=None):
    return getattr(django_settings, f"OTP_DRF_{name}", default)


def get_backend():
    path = _get("BACKEND", "otp_drf.backends.django_otp.DjangoOTPBackend")
    if path not in _backend_cache:
        if callable(path):
            _backend_cache[path] = path()
        else:
            module_path, class_name = path.rsplit(".", 1)
            cls = getattr(importlib.import_module(module_path), class_name)
            _backend_cache[path] = cls()
    return _backend_cache[path]


def get_user_serializer():
    path = _get("USER_SERIALIZER")
    if path is None:
        return None
    module_path, class_name = path.rsplit(".", 1)
    return getattr(importlib.import_module(module_path), class_name)


def get_extra_verify_response(user, request):
    hook = _get("EXTRA_VERIFY_RESPONSE")
    if hook is None:
        return {}
    if callable(hook):
        return hook(user, request)
    module_path, func_name = hook.rsplit(".", 1)
    fn = getattr(importlib.import_module(module_path), func_name)
    return fn(user, request)


def get_recovery_code_count():
    return _get("RECOVERY_CODE_COUNT", 6)


def get_pending_timeout():
    return _get("PENDING_TIMEOUT", 300)


def get_recovery_session_timeout():
    return _get("RECOVERY_SESSION_TIMEOUT", 900)


def _import_class(path):
    module_path, class_name = path.rsplit(".", 1)
    return getattr(importlib.import_module(module_path), class_name)


def get_login_throttle_class():
    path = _get("LOGIN_THROTTLE", "otp_drf.throttles.LoginRateThrottle")
    return _import_class(path) if isinstance(path, str) else path


def get_action_throttle_class():
    path = _get("ACTION_THROTTLE", "otp_drf.throttles.TwoFactorRateThrottle")
    return _import_class(path) if isinstance(path, str) else path
