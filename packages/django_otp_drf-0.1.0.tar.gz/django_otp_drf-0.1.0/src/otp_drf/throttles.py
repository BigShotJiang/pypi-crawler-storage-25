from rest_framework.throttling import AnonRateThrottle, UserRateThrottle


class LoginRateThrottle(AnonRateThrottle):
    rate = "5/minute"


class TwoFactorRateThrottle(UserRateThrottle):
    rate = "5/minute"
