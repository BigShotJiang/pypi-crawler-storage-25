from django.urls import path

from . import views

urlpatterns = [
    path("verify/", views.api_2fa_verify, name="api-2fa-verify"),
    path("status/", views.api_2fa_status, name="api-2fa-status"),
    path("setup/", views.api_2fa_setup, name="api-2fa-setup"),
    path("confirm/", views.api_2fa_confirm, name="api-2fa-confirm"),
    path("cancel-setup/", views.api_2fa_cancel_setup, name="api-2fa-cancel-setup"),
    path("disable/", views.api_2fa_disable, name="api-2fa-disable"),
    path("reset/", views.api_2fa_reset, name="api-2fa-reset"),
    path(
        "regenerate-recovery/",
        views.api_2fa_regenerate_recovery,
        name="api-2fa-regenerate-recovery",
    ),
]
