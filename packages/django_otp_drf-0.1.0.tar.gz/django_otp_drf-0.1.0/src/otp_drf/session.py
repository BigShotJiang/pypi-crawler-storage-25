import datetime as dt

from django.contrib.auth import get_user_model
from django.utils import timezone

from . import conf

SESSION_MODES = ("pending", "recovery")


def set_2fa_session(session, user_id, backend, mode):
    session["_2fa_user_id"] = user_id
    session["_2fa_backend"] = backend
    session["_2fa_at"] = timezone.now().isoformat()
    session["_2fa_mode"] = mode


def get_2fa_session_user(session, mode):
    """Return the user in the given 2FA session mode, or None if expired/missing."""
    user_id = session.get("_2fa_user_id")
    started_at = session.get("_2fa_at")
    if session.get("_2fa_mode") != mode or not user_id or not started_at:
        return None
    timeouts = {
        "pending": conf.get_pending_timeout(),
        "recovery": conf.get_recovery_session_timeout(),
    }
    elapsed = timezone.now() - dt.datetime.fromisoformat(started_at)
    if elapsed > dt.timedelta(seconds=timeouts[mode]):
        clear_2fa_session(session)
        session.save()
        return None
    User = get_user_model()
    try:
        return User.objects.get(pk=user_id)
    except User.DoesNotExist:
        return None


def clear_2fa_session(session):
    backend = session.pop("_2fa_backend", None)
    session.pop("_2fa_user_id", None)
    session.pop("_2fa_at", None)
    session.pop("_2fa_mode", None)
    return backend
