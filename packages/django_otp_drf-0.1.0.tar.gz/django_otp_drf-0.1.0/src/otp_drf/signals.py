from django.dispatch import Signal

# sender=user, kwargs: request
two_factor_disabled = Signal()
two_factor_reset = Signal()
recovery_code_login = Signal()
recovery_codes_regenerated = Signal()
