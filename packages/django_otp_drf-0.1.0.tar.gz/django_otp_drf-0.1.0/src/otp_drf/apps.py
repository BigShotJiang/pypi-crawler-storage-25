from django.apps import AppConfig


class OtpDrfConfig(AppConfig):
    name = "otp_drf"
    default_auto_field = "django.db.models.BigAutoField"
