import datetime as dt

import pytest
import time_machine

from otp_drf import conf

from .helpers import make_totp_user, set_pending_session, totp_code

pytestmark = pytest.mark.django_db


def test_verify_valid_totp_logs_in(api_client, user):
    device, _ = make_totp_user(user)
    set_pending_session(api_client, user)
    resp = api_client.post("/2fa/verify/", {"token": totp_code(device)})
    assert resp.status_code == 200
    assert resp.data["detail"] == "Logged in successfully."
    assert resp.data["used_recovery"] is False


def test_verify_valid_totp_authenticates_user(api_client, user):
    device, _ = make_totp_user(user)
    set_pending_session(api_client, user)
    api_client.post("/2fa/verify/", {"token": totp_code(device)})
    assert api_client.session.get("_auth_user_id") == str(user.pk)


def test_verify_invalid_token_returns_401(api_client, user):
    make_totp_user(user)
    set_pending_session(api_client, user)
    resp = api_client.post("/2fa/verify/", {"token": "000000"})
    assert resp.status_code == 401


def test_verify_no_pending_session_returns_400(api_client):
    resp = api_client.post("/2fa/verify/", {"token": "123456"})
    assert resp.status_code == 400


def test_verify_expired_session_returns_400(api_client, user):
    make_totp_user(user)
    set_pending_session(api_client, user)
    with time_machine.travel(dt.timedelta(seconds=301), tick=False):
        resp = api_client.post("/2fa/verify/", {"token": "123456"})
    assert resp.status_code == 400


def test_verify_deleted_user_returns_400(api_client, user):
    make_totp_user(user)
    set_pending_session(api_client, user)
    user.delete()
    resp = api_client.post("/2fa/verify/", {"token": "123456"})
    assert resp.status_code == 400


def test_verify_recovery_code_returns_200_with_flag(api_client, user):
    _, recovery_codes = make_totp_user(user)
    set_pending_session(api_client, user)
    resp = api_client.post("/2fa/verify/", {"token": recovery_codes[0]})
    assert resp.status_code == 200
    assert resp.data["used_recovery"] is True


def test_verify_recovery_code_does_not_log_in(api_client, user):
    _, recovery_codes = make_totp_user(user)
    set_pending_session(api_client, user)
    api_client.post("/2fa/verify/", {"token": recovery_codes[0]})
    assert "_auth_user_id" not in api_client.session


def test_verify_recovery_code_consumes_token(api_client, user):
    _, recovery_codes = make_totp_user(user)
    set_pending_session(api_client, user)
    api_client.post("/2fa/verify/", {"token": recovery_codes[0]})
    assert conf.get_backend().get_recovery_codes_remaining(user) == 5


def test_verify_recovery_code_sets_recovery_session(api_client, user):
    _, recovery_codes = make_totp_user(user)
    set_pending_session(api_client, user)
    api_client.post("/2fa/verify/", {"token": recovery_codes[0]})
    assert api_client.session.get("_2fa_mode") == "recovery"


def test_verify_response_includes_user_data(api_client, user):
    device, _ = make_totp_user(user)
    set_pending_session(api_client, user)
    resp = api_client.post("/2fa/verify/", {"token": totp_code(device)})
    assert resp.data["user"]["id"] == user.pk
    assert resp.data["user"]["username"] == user.username
