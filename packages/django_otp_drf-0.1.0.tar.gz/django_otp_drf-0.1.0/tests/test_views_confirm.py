import datetime as dt

import pytest
from django.utils import timezone

from otp_drf import conf

from .helpers import make_totp_user, set_recovery_session, totp_code

pytestmark = pytest.mark.django_db


def test_confirm_unauthenticated_returns_403(api_client):
    resp = api_client.post("/2fa/confirm/", {"token": "123456"})
    assert resp.status_code == 403


def test_confirm_no_pending_device_returns_400(api_client, user):
    api_client.force_login(user)
    resp = api_client.post("/2fa/confirm/", {"token": "123456"})
    assert resp.status_code == 400


def test_confirm_invalid_token_returns_400(api_client, user):
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    resp = api_client.post("/2fa/confirm/", {"token": "000000"})
    assert resp.status_code == 400


def test_confirm_enables_2fa(api_client, user):
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    device = conf.get_backend().get_pending_totp_device(user)
    resp = api_client.post("/2fa/confirm/", {"token": totp_code(device)})
    assert resp.status_code == 200
    assert resp.data["detail"] == "Two-factor authentication enabled."
    assert len(resp.data["recovery_codes"]) == 6
    assert conf.get_backend().has_confirmed_totp_device(user)


def test_confirm_generates_recovery_codes_on_first_enable(api_client, user):
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    device = conf.get_backend().get_pending_totp_device(user)
    resp = api_client.post("/2fa/confirm/", {"token": totp_code(device)})
    assert conf.get_backend().get_recovery_device(user) is not None
    assert len(resp.data["recovery_codes"]) == 6


def test_confirm_after_reset_returns_reset_detail(api_client, user):
    make_totp_user(user)
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    new_device = conf.get_backend().get_pending_totp_device(user)
    resp = api_client.post("/2fa/confirm/", {"token": totp_code(new_device)})
    assert resp.status_code == 200
    assert resp.data["detail"] == "Two-factor authentication reset."


def test_confirm_after_reset_keeps_existing_recovery_codes(api_client, user):
    make_totp_user(user)
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    new_device = conf.get_backend().get_pending_totp_device(user)
    resp = api_client.post("/2fa/confirm/", {"token": totp_code(new_device)})
    assert resp.data["recovery_codes"] is None
    assert conf.get_backend().get_recovery_codes_remaining(user) == 6


def test_confirm_clears_enforce_2fa_deadline(api_client, enforced_user):
    deadline = timezone.now() + dt.timedelta(hours=24)
    enforced_user.enforce_2fa_deadline = deadline
    enforced_user.save()
    api_client.force_login(enforced_user)
    api_client.post("/2fa/setup/")
    device = conf.get_backend().get_pending_totp_device(enforced_user)
    api_client.post("/2fa/confirm/", {"token": totp_code(device)})
    enforced_user.refresh_from_db()
    assert enforced_user.enforce_2fa_deadline is None


def test_confirm_after_recovery_login_authenticates_user(api_client, user):
    make_totp_user(user)
    set_recovery_session(api_client, user)
    api_client.post("/2fa/setup/")
    new_device = conf.get_backend().get_pending_totp_device(user)
    api_client.post("/2fa/confirm/", {"token": totp_code(new_device)})
    assert api_client.session.get("_auth_user_id") == str(user.pk)
