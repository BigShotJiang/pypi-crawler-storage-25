from django.urls import include, path

urlpatterns = [
    path("2fa/", include("otp_drf.urls")),
]
