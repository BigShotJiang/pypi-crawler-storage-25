import pytest

from otp_drf import conf

from .helpers import make_totp_user, totp_code

pytestmark = pytest.mark.django_db


def test_disable_requires_authentication(api_client, user):
    resp = api_client.post("/2fa/disable/", {"token": "123456"})
    assert resp.status_code == 403


def test_disable_not_enabled_returns_400(api_client, user):
    api_client.force_login(user)
    resp = api_client.post("/2fa/disable/", {"token": "123456"})
    assert resp.status_code == 400


def test_disable_invalid_token_returns_400(api_client, user):
    make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.post("/2fa/disable/", {"token": "000000"})
    assert resp.status_code == 400
    assert conf.get_backend().has_confirmed_totp_device(user)


def test_disable_valid_totp_removes_devices(api_client, user):
    device, _ = make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.post("/2fa/disable/", {"token": totp_code(device)})
    assert resp.status_code == 200
    backend = conf.get_backend()
    assert not backend.has_confirmed_totp_device(user)
    assert backend.get_recovery_codes_remaining(user) == 0


def test_disable_valid_recovery_code_removes_devices(api_client, user):
    _, recovery_codes = make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.post("/2fa/disable/", {"token": recovery_codes[0]})
    assert resp.status_code == 200
    assert not conf.get_backend().has_confirmed_totp_device(user)


def test_disable_blocked_when_enforce_2fa(api_client, user):
    device, _ = make_totp_user(user)
    user.enforce_2fa = True
    user.save()
    api_client.force_login(user)
    resp = api_client.post("/2fa/disable/", {"token": totp_code(device)})
    assert resp.status_code == 403
    assert conf.get_backend().has_confirmed_totp_device(user)
