import importlib.util

from otp_drf.backends import ALLAUTH_DEPENDENCIES, DJANGO_OTP_DEPENDENCIES

_has_allauth = importlib.util.find_spec("allauth") is not None
_deps = ALLAUTH_DEPENDENCIES if _has_allauth else DJANGO_OTP_DEPENDENCIES

SECRET_KEY = "test-secret-key-not-for-production"

DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}}

INSTALLED_APPS = [
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    *_deps,
    "rest_framework",
    "otp_drf",
    "tests",
]

AUTH_USER_MODEL = "tests.User"
ROOT_URLCONF = "tests.urls"

MIDDLEWARE = [
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    *(["allauth.account.middleware.AccountMiddleware"] if _has_allauth else []),
]

SESSION_ENGINE = "django.contrib.sessions.backends.db"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
MIGRATION_MODULES = {"tests": None}

SITE_ID = 1 if _has_allauth else None
MFA_TOTP_ISSUER = "Test App" if _has_allauth else None
MFA_RECOVERY_CODE_COUNT = 6 if _has_allauth else None
OTP_DRF_BACKEND = (
    "otp_drf.backends.allauth.AllauthBackend"
    if _has_allauth
    else "otp_drf.backends.django_otp.DjangoOTPBackend"
)
OTP_TOTP_ISSUER = None if _has_allauth else "Test App"
