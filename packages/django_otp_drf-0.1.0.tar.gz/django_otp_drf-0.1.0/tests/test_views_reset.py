import pytest

from otp_drf import conf

from .helpers import make_totp_user, totp_code

pytestmark = pytest.mark.django_db


def test_reset_requires_authentication(api_client):
    resp = api_client.post("/2fa/reset/", {"token": "123456"})
    assert resp.status_code == 403


def test_reset_not_enabled_returns_400(api_client, user):
    api_client.force_login(user)
    resp = api_client.post("/2fa/reset/", {"token": "123456"})
    assert resp.status_code == 400


def test_reset_invalid_token_returns_400(api_client, user):
    make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.post("/2fa/reset/", {"token": "000000"})
    assert resp.status_code == 400


def test_reset_valid_token_returns_qr_and_url(api_client, user):
    device, _ = make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.post("/2fa/reset/", {"token": totp_code(device)})
    assert resp.status_code == 200
    assert resp.data["config_url"].startswith("otpauth://totp/")
    assert resp.data["qr_code"].startswith("data:image/svg+xml;base64,")
    assert resp.data["recovery_codes_remaining"] == 6


def test_reset_creates_new_pending_device(api_client, user):
    device, _ = make_totp_user(user)
    api_client.force_login(user)
    api_client.post("/2fa/reset/", {"token": totp_code(device)})
    backend = conf.get_backend()
    assert backend.has_confirmed_totp_device(user)
    assert backend.get_pending_totp_device(user) is not None


def test_reset_valid_recovery_code_works(api_client, user):
    _, recovery_codes = make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.post("/2fa/reset/", {"token": recovery_codes[0]})
    assert resp.status_code == 200
    assert resp.data["recovery_codes_remaining"] == 5
