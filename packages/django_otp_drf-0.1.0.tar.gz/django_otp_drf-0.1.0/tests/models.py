from django.contrib.auth.models import AbstractUser

from otp_drf.models import TwoFactorEnforcementMixin


class User(TwoFactorEnforcementMixin, AbstractUser):
    class Meta:
        app_label = "tests"
