import pytest

from otp_drf import conf

from .helpers import make_totp_user, set_recovery_session

pytestmark = pytest.mark.django_db


def test_setup_unauthenticated_returns_403(api_client):
    resp = api_client.post("/2fa/setup/")
    assert resp.status_code == 403


def test_setup_returns_config_url_and_qr(api_client, user):
    api_client.force_login(user)
    resp = api_client.post("/2fa/setup/")
    assert resp.status_code == 200
    assert resp.data["config_url"].startswith("otpauth://totp/")
    assert resp.data["qr_code"].startswith("data:image/svg+xml;base64,")


def test_setup_creates_pending_device(api_client, user):
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    assert conf.get_backend().get_pending_totp_device(user) is not None


def test_setup_replaces_existing_unconfirmed(api_client, user):
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    first_device = conf.get_backend().get_pending_totp_device(user)
    api_client.post("/2fa/setup/")
    second_device = conf.get_backend().get_pending_totp_device(user)
    assert second_device is not None
    assert second_device.pk != first_device.pk


def test_setup_during_recovery_deletes_confirmed_device(api_client, user):
    make_totp_user(user)
    set_recovery_session(api_client, user)
    api_client.post("/2fa/setup/")
    backend = conf.get_backend()
    assert not backend.has_confirmed_totp_device(user)
    assert backend.get_pending_totp_device(user) is not None
