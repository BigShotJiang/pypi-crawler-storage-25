import pytest

from otp_drf import conf


@pytest.fixture(autouse=True)
def clear_backend_cache():
    conf._backend_cache.clear()
    yield
    conf._backend_cache.clear()


def test_get_backend_with_callable(settings):
    class _Backend:
        pass

    settings.OTP_DRF_BACKEND = _Backend
    assert isinstance(conf.get_backend(), _Backend)


def test_get_user_serializer_returns_none_by_default():
    assert conf.get_user_serializer() is None


def test_get_user_serializer_returns_class_when_configured(settings):
    settings.OTP_DRF_USER_SERIALIZER = "rest_framework.serializers.Serializer"
    from rest_framework.serializers import Serializer

    assert conf.get_user_serializer() is Serializer


def test_get_extra_verify_response_returns_empty_by_default():
    assert conf.get_extra_verify_response(None, None) == {}


def test_get_extra_verify_response_with_callable(settings):
    settings.OTP_DRF_EXTRA_VERIFY_RESPONSE = lambda user, req: {"ok": True}
    assert conf.get_extra_verify_response(None, None) == {"ok": True}


def test_get_extra_verify_response_with_string(settings):
    settings.OTP_DRF_EXTRA_VERIFY_RESPONSE = "tests.helpers.extra_verify_response"
    assert conf.get_extra_verify_response(None, None) == {"extra": True}
