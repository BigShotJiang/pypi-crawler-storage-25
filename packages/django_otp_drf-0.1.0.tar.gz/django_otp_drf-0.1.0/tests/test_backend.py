import importlib

import pytest

pytestmark = pytest.mark.django_db


@pytest.fixture(params=["otp", "allauth"])
def backend(request):
    is_otp = request.param == "otp"
    pytest.importorskip("django_otp" if is_otp else "allauth")
    mod = importlib.import_module(
        "otp_drf.backends.django_otp" if is_otp else "otp_drf.backends.allauth"
    )
    return (mod.DjangoOTPBackend if is_otp else mod.AllauthBackend)()


@pytest.fixture
def user_with_totp(user, backend):
    device = backend.create_pending_totp_device(user)
    backend.confirm_device(user, device)
    return user, device


@pytest.fixture
def user_with_recovery(user, backend):
    codes = backend.create_recovery_codes(user, 6)
    device = backend.get_recovery_device(user)
    return user, device, codes


def test_get_confirmed_totp_device_returns_device(backend, user_with_totp):
    user, device = user_with_totp
    assert backend.get_confirmed_totp_device(user) == device


def test_get_confirmed_totp_device_returns_none_when_absent(backend, user):
    assert backend.get_confirmed_totp_device(user) is None


def test_has_confirmed_totp_device_true(backend, user_with_totp):
    user, _ = user_with_totp
    assert backend.has_confirmed_totp_device(user) is True


def test_has_confirmed_totp_device_false(backend, user):
    assert backend.has_confirmed_totp_device(user) is False


def test_get_pending_totp_device_returns_pending(backend, user):
    pending = backend.create_pending_totp_device(user)
    assert backend.get_pending_totp_device(user) == pending


def test_get_pending_totp_device_returns_none_when_absent(backend, user):
    assert backend.get_pending_totp_device(user) is None


def test_get_pending_totp_device_returns_none_for_confirmed(backend, user_with_totp):
    user, _ = user_with_totp
    assert backend.get_pending_totp_device(user) is None


def test_create_pending_totp_device_not_confirmed(backend, user):
    backend.create_pending_totp_device(user)
    assert not backend.has_confirmed_totp_device(user)


def test_confirm_device_sets_confirmed(backend, user):
    device = backend.create_pending_totp_device(user)
    backend.confirm_device(user, device)
    assert backend.has_confirmed_totp_device(user)
    assert backend.get_pending_totp_device(user) is None


def test_confirm_device_replaces_old_confirmed(backend, user_with_totp):
    user, _ = user_with_totp
    new_device = backend.create_pending_totp_device(user)
    backend.confirm_device(user, new_device)
    assert backend.get_confirmed_totp_device(user) is not None
    assert backend.get_pending_totp_device(user) is None


def test_confirm_device_keeps_itself(backend, user):
    device = backend.create_pending_totp_device(user)
    backend.confirm_device(user, device)
    assert backend.has_confirmed_totp_device(user)


def test_delete_unconfirmed_leaves_confirmed(backend, user_with_totp):
    user, _ = user_with_totp
    backend.create_pending_totp_device(user)
    backend.delete_unconfirmed_devices(user)
    assert backend.get_confirmed_totp_device(user) is not None
    assert backend.get_pending_totp_device(user) is None


def test_delete_all_totp_devices(backend, user_with_totp):
    user, _ = user_with_totp
    backend.delete_all_totp_devices(user)
    assert not backend.has_confirmed_totp_device(user)


def test_verify_totp_token_accepts_valid(backend, user_with_totp):
    user, device = user_with_totp
    assert backend.verify_totp_token(device, backend.get_totp_code(device)) is True


def test_verify_totp_token_rejects_invalid(backend, user_with_totp):
    user, device = user_with_totp
    assert backend.verify_totp_token(device, "000000") is False


def test_verify_totp_token_returns_false_for_none(backend):
    assert backend.verify_totp_token(None, "123456") is False


def test_get_totp_url_includes_issuer_and_username(backend, user_with_totp):
    user, device = user_with_totp
    url = backend.get_totp_url(device, user)
    assert url.startswith("otpauth://totp/")
    assert "testuser" in url


def test_get_totp_url_includes_email_when_present(backend, user_with_totp):
    user, device = user_with_totp
    url = backend.get_totp_url(device, user)
    assert "testuser%40example.com" in url or "testuser@example.com" in url


def test_get_totp_url_omits_email_when_absent(backend, user):
    user.email = ""
    user.save()
    device = backend.create_pending_totp_device(user)
    backend.confirm_device(user, device)
    url = backend.get_totp_url(device, user)
    assert "testuser" in url
    assert "@" not in url


def test_get_totp_url_without_issuer(backend, user_with_totp, settings):
    settings.MFA_TOTP_ISSUER = ""
    settings.OTP_TOTP_ISSUER = ""
    user, device = user_with_totp
    url = backend.get_totp_url(device, user)
    assert url.startswith("otpauth://totp/")
    assert "issuer" not in url


def test_create_recovery_codes_returns_correct_count(backend, user):
    codes = backend.create_recovery_codes(user, 6)
    assert len(codes) == 6


def test_create_recovery_codes_replaces_existing(backend, user):
    backend.create_recovery_codes(user, 6)
    backend.create_recovery_codes(user, 6)
    assert backend.get_recovery_codes_remaining(user) == 6


def test_get_recovery_codes_remaining(backend, user):
    backend.create_recovery_codes(user, 6)
    assert backend.get_recovery_codes_remaining(user) == 6


def test_get_recovery_codes_remaining_zero_when_none(backend, user):
    assert backend.get_recovery_codes_remaining(user) == 0


def test_verify_recovery_token_accepts_valid_code(backend, user_with_recovery):
    user, device, codes = user_with_recovery
    assert backend.verify_recovery_token(device, codes[0]) is True


def test_verify_recovery_token_consumes_code(backend, user_with_recovery):
    user, device, codes = user_with_recovery
    backend.verify_recovery_token(device, codes[0])
    assert backend.get_recovery_codes_remaining(user) == 5


def test_verify_recovery_token_rejects_invalid(backend, user_with_recovery):
    user, device, _ = user_with_recovery
    assert backend.verify_recovery_token(device, "notacode") is False


def test_verify_recovery_token_returns_false_for_none(backend):
    assert backend.verify_recovery_token(None, "abc123") is False


def test_delete_recovery_devices(backend, user):
    backend.create_recovery_codes(user, 6)
    backend.delete_recovery_devices(user)
    assert backend.get_recovery_device(user) is None
