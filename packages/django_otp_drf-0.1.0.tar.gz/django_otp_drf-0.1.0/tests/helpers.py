from django.utils import timezone

from otp_drf import conf


def extra_verify_response(user, request):
    return {"extra": True}


BACKEND = "django.contrib.auth.backends.ModelBackend"


def totp_code(device):
    return conf.get_backend().get_totp_code(device)


def make_totp_user(user):
    backend = conf.get_backend()
    device = backend.create_pending_totp_device(user)
    backend.confirm_device(user, device)
    recovery_codes = backend.create_recovery_codes(user, 6)
    return device, recovery_codes


def set_pending_session(api_client, user):
    session = api_client.session
    session["_2fa_user_id"] = user.pk
    session["_2fa_backend"] = BACKEND
    session["_2fa_at"] = timezone.now().isoformat()
    session["_2fa_mode"] = "pending"
    session.save()


def set_recovery_session(api_client, user):
    session = api_client.session
    session["_2fa_user_id"] = user.pk
    session["_2fa_backend"] = BACKEND
    session["_2fa_at"] = timezone.now().isoformat()
    session["_2fa_mode"] = "recovery"
    session.save()
