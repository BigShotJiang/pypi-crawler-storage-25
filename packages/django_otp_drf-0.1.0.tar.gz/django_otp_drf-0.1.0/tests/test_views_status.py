import pytest

from .helpers import make_totp_user, set_recovery_session

pytestmark = pytest.mark.django_db


def test_status_unauthenticated_returns_403(api_client):
    resp = api_client.get("/2fa/status/")
    assert resp.status_code == 403


def test_status_enabled_user(api_client, user):
    make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.get("/2fa/status/")
    assert resp.status_code == 200
    assert resp.data["is_enabled"] is True
    assert resp.data["recovery_codes_remaining"] == 6
    assert resp.data["recovery_login"] is False


def test_status_disabled_user(api_client, user):
    api_client.force_login(user)
    resp = api_client.get("/2fa/status/")
    assert resp.status_code == 200
    assert resp.data["is_enabled"] is False
    assert resp.data["recovery_codes_remaining"] == 0


def test_status_recovery_session(api_client, user):
    make_totp_user(user)
    set_recovery_session(api_client, user)
    resp = api_client.get("/2fa/status/")
    assert resp.status_code == 200
    assert resp.data["recovery_login"] is True
    assert resp.data["recovery_codes_remaining"] == 6


def test_status_includes_enforce_2fa_fields(api_client, enforced_user):
    api_client.force_login(enforced_user)
    resp = api_client.get("/2fa/status/")
    assert resp.status_code == 200
    assert resp.data["enforce_2fa"] is True
    assert resp.data["enforce_2fa_deadline"] is None
