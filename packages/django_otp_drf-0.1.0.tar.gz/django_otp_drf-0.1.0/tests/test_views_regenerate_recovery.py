import pytest


from .helpers import make_totp_user, totp_code

pytestmark = pytest.mark.django_db


def test_regenerate_requires_authentication(api_client):
    resp = api_client.post("/2fa/regenerate-recovery/", {"token": "123456"})
    assert resp.status_code == 403


def test_regenerate_not_enabled_returns_400(api_client, user):
    api_client.force_login(user)
    resp = api_client.post("/2fa/regenerate-recovery/", {"token": "123456"})
    assert resp.status_code == 400


def test_regenerate_invalid_token_returns_400(api_client, user):
    make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.post("/2fa/regenerate-recovery/", {"token": "000000"})
    assert resp.status_code == 400


def test_regenerate_valid_totp_returns_new_codes(api_client, user):
    device, old_recovery_codes = make_totp_user(user)
    old_codes = set(old_recovery_codes)
    api_client.force_login(user)
    resp = api_client.post("/2fa/regenerate-recovery/", {"token": totp_code(device)})
    assert resp.status_code == 200
    assert len(resp.data["recovery_codes"]) == 6
    assert set(resp.data["recovery_codes"]) != old_codes


def test_regenerate_valid_recovery_code_works(api_client, user):
    _, recovery_codes = make_totp_user(user)
    api_client.force_login(user)
    resp = api_client.post("/2fa/regenerate-recovery/", {"token": recovery_codes[0]})
    assert resp.status_code == 200
    assert len(resp.data["recovery_codes"]) == 6
