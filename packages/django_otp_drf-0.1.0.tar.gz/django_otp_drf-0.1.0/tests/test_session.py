import datetime as dt

import pytest

from otp_drf.session import clear_2fa_session, get_2fa_session_user, set_2fa_session

pytestmark = pytest.mark.django_db

BACKEND = "django.contrib.auth.backends.ModelBackend"


def _make_pending(client, user, offset_seconds=0):
    session = client.session
    set_2fa_session(session, user.pk, BACKEND, "pending")
    if offset_seconds:
        at = dt.datetime.fromisoformat(session["_2fa_at"])
        session["_2fa_at"] = (at - dt.timedelta(seconds=offset_seconds)).isoformat()
    session.save()
    return session


def test_set_stores_all_keys(client, user):
    session = client.session
    set_2fa_session(session, user.pk, BACKEND, "pending")
    assert session["_2fa_user_id"] == user.pk
    assert session["_2fa_backend"] == BACKEND
    assert session["_2fa_mode"] == "pending"
    assert "_2fa_at" in session


def test_get_returns_user_for_valid_pending_session(client, user):
    _make_pending(client, user)
    assert get_2fa_session_user(client.session, "pending") == user


def test_get_returns_user_for_valid_recovery_session(client, user):
    session = client.session
    set_2fa_session(session, user.pk, BACKEND, "recovery")
    session.save()
    assert get_2fa_session_user(client.session, "recovery") == user


def test_get_returns_none_for_wrong_mode(client, user):
    _make_pending(client, user)
    assert get_2fa_session_user(client.session, "recovery") is None


def test_get_returns_none_with_no_session(client):
    assert get_2fa_session_user(client.session, "pending") is None


def test_pending_session_expires(client, user):
    _make_pending(client, user, offset_seconds=301)
    assert get_2fa_session_user(client.session, "pending") is None


def test_recovery_session_expires(client, user):
    session = client.session
    set_2fa_session(session, user.pk, BACKEND, "recovery")
    at = dt.datetime.fromisoformat(session["_2fa_at"])
    session["_2fa_at"] = (at - dt.timedelta(seconds=901)).isoformat()
    session.save()
    assert get_2fa_session_user(client.session, "recovery") is None


def test_get_returns_none_for_deleted_user(client, user):
    _make_pending(client, user)
    user.delete()
    assert get_2fa_session_user(client.session, "pending") is None


def test_expiry_clears_session_keys(client, user):
    _make_pending(client, user, offset_seconds=301)
    get_2fa_session_user(client.session, "pending")
    assert "_2fa_user_id" not in client.session


def test_clear_removes_all_keys(client, user):
    session = _make_pending(client, user)
    clear_2fa_session(session)
    assert "_2fa_user_id" not in session
    assert "_2fa_backend" not in session
    assert "_2fa_at" not in session
    assert "_2fa_mode" not in session


def test_clear_returns_backend(client, user):
    session = _make_pending(client, user)
    assert clear_2fa_session(session) == BACKEND


def test_clear_returns_none_when_no_session(client):
    assert clear_2fa_session(client.session) is None
