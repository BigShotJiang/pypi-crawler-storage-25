import pytest
from django.contrib.auth import get_user_model
from django.core.cache import cache
from rest_framework.test import APIClient


@pytest.fixture
def clear_cache():
    cache.clear()
    yield
    cache.clear()


@pytest.fixture
def api_client(clear_cache):
    return APIClient()


@pytest.fixture
def user(db):
    return get_user_model().objects.create_user(
        username="testuser",
        password="testpass123",
        email="testuser@example.com",
    )


@pytest.fixture
def enforced_user(db):
    return get_user_model().objects.create_user(
        username="enforced",
        password="testpass123",
        enforce_2fa=True,
    )
