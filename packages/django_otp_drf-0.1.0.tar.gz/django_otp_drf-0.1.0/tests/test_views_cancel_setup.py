import pytest

from otp_drf import conf

from .helpers import make_totp_user, set_recovery_session

pytestmark = pytest.mark.django_db


def test_cancel_unauthenticated_returns_403(api_client):
    resp = api_client.post("/2fa/cancel-setup/")
    assert resp.status_code == 403


def test_cancel_initial_setup_removes_pending_device(api_client, user):
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    assert conf.get_backend().get_pending_totp_device(user) is not None
    resp = api_client.post("/2fa/cancel-setup/")
    assert resp.status_code == 200
    assert conf.get_backend().get_pending_totp_device(user) is None
    assert resp.data["recovery_codes"] is None


def test_cancel_reset_removes_pending_but_keeps_confirmed(api_client, user):
    make_totp_user(user)
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    resp = api_client.post("/2fa/cancel-setup/")
    assert resp.status_code == 200
    backend = conf.get_backend()
    assert backend.get_pending_totp_device(user) is None
    assert backend.has_confirmed_totp_device(user)


def test_cancel_reset_regenerates_codes_when_depleted(api_client, user):
    _, recovery_codes = make_totp_user(user)
    backend = conf.get_backend()
    recovery_device = backend.get_recovery_device(user)
    for code in recovery_codes:
        backend.verify_recovery_token(recovery_device, code)
    api_client.force_login(user)
    api_client.post("/2fa/setup/")
    resp = api_client.post("/2fa/cancel-setup/")
    assert resp.status_code == 200
    assert len(resp.data["recovery_codes"]) == 6


def test_cancel_blocked_during_recovery_with_no_confirmed_device(api_client, user):
    make_totp_user(user)
    set_recovery_session(api_client, user)
    api_client.post("/2fa/setup/")
    assert not conf.get_backend().has_confirmed_totp_device(user)
    resp = api_client.post("/2fa/cancel-setup/")
    assert resp.status_code == 400


def test_cancel_recovery_session_clears_session(api_client, user):
    make_totp_user(user)
    set_recovery_session(api_client, user)
    api_client.post("/2fa/cancel-setup/")
    assert "_2fa_mode" not in api_client.session
