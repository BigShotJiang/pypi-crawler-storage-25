RESET = "\x1b[0m"
LIGHT_GRAY = "\x1b[38;5;250m"


class ColorScheme:
    """Color scheme with 5 intensity levels (0-4)."""

    def __init__(self, name: str, levels: list[str]):
        self.name = name
        self.levels = levels

    def get(self, level: int) -> str:
        """Return ANSI code for intensity level 0-4."""
        return self.levels[min(level, 4)]


GREEN = ColorScheme(
    "green",
    [
        "\x1b[38;5;234m",  # 0: dark grey (no commits)
        "\x1b[38;5;22m",  # 1: darker green
        "\x1b[38;5;28m",  # 2: dark green
        "\x1b[38;5;34m",  # 3: medium green
        "\x1b[38;5;40m",  # 4: bright green
    ],
)

BLUE = ColorScheme(
    "blue",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;17m",  # 1: dark blue
        "\x1b[38;5;19m",  # 2: blue
        "\x1b[38;5;21m",  # 3: bright blue
        "\x1b[38;5;33m",  # 4: brightest blue
    ],
)

ORANGE = ColorScheme(
    "orange",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;130m",  # 1: dark orange
        "\x1b[38;5;166m",  # 2: orange
        "\x1b[38;5;208m",  # 3: bright orange
        "\x1b[38;5;214m",  # 4: brightest orange
    ],
)

PURPLE = ColorScheme(
    "purple",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;54m",  # 1: dark purple
        "\x1b[38;5;92m",  # 2: purple
        "\x1b[38;5;129m",  # 3: bright purple
        "\x1b[38;5;141m",  # 4: brightest purple
    ],
)

MONO = ColorScheme(
    "mono",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;235m",  # 1: dark grey
        "\x1b[38;5;240m",  # 2: grey
        "\x1b[38;5;250m",  # 3: light grey
        "\x1b[38;5;255m",  # 4: white
    ],
)

RED = ColorScheme(
    "red",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;52m",  # 1: dark red
        "\x1b[38;5;124m",  # 2: red
        "\x1b[38;5;160m",  # 3: bright red
        "\x1b[38;5;196m",  # 4: brightest red
    ],
)

YELLOW = ColorScheme(
    "yellow",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;58m",  # 1: dark yellow
        "\x1b[38;5;100m",  # 2: olive
        "\x1b[38;5;178m",  # 3: yellow
        "\x1b[38;5;226m",  # 4: bright yellow
    ],
)

TEAL = ColorScheme(
    "teal",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;23m",  # 1: dark teal
        "\x1b[38;5;29m",  # 2: teal
        "\x1b[38;5;37m",  # 3: bright teal
        "\x1b[38;5;45m",  # 4: brightest teal
    ],
)

PINK = ColorScheme(
    "pink",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;125m",  # 1: dark pink
        "\x1b[38;5;169m",  # 2: pink
        "\x1b[38;5;183m",  # 3: bright pink
        "\x1b[38;5;219m",  # 4: brightest pink
    ],
)

AQUA = ColorScheme(
    "aqua",
    [
        "\x1b[38;5;234m",  # 0: dark grey
        "\x1b[38;5;30m",  # 1: dark aqua
        "\x1b[38;5;37m",  # 2: aqua
        "\x1b[38;5;38m",  # 3: bright aqua
        "\x1b[38;5;51m",  # 4: brightest aqua
    ],
)

COLOR_SCHEMES = {
    "green": GREEN,
    "blue": BLUE,
    "orange": ORANGE,
    "purple": PURPLE,
    "red": RED,
    "yellow": YELLOW,
    "teal": TEAL,
    "pink": PINK,
    "aqua": AQUA,
    "mono": MONO,
}


def get_color_scheme(name: str) -> ColorScheme:
    """Get color scheme by name, defaulting to green."""
    return COLOR_SCHEMES.get(name, GREEN)
