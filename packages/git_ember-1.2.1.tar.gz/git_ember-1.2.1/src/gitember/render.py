import calendar
import datetime as dt
from typing import Any, Dict, List, Optional

from gitember.colors import RESET, LIGHT_GRAY, ColorScheme


DEFAULT_THRESHOLDS = (0, 1, 3, 6, 10)


def calculate_thresholds(counts: Dict[dt.date, int], mode: str = "auto") -> tuple:
    """Calculate intensity thresholds based on scaling mode.

    Args:
        counts: Dict mapping date to commit count.
        mode: Scaling mode - "auto" or "adaptive".

    Returns:
        Tuple of threshold values.
    """
    if mode == "auto":
        max_commits = max(counts.values()) if counts else 1
        return (
            0,
            max(1, int(max_commits * 0.2)),
            max(1, int(max_commits * 0.4)),
            max(1, int(max_commits * 0.6)),
            max(1, int(max_commits * 0.8)),
        )

    if mode == "adaptive":
        sorted_values = sorted(counts.values())
        n = len(sorted_values)
        return (
            0,
            sorted_values[int(n * 0.50)] if n > 0 else 1,
            sorted_values[int(n * 0.75)] if n > 0 else 3,
            sorted_values[int(n * 0.90)] if n > 0 else 6,
            sorted_values[int(n * 0.95)] if n > 0 else 10,
        )

    return DEFAULT_THRESHOLDS


def choose_level(count: int, thresholds: tuple = None) -> int:
    """Map commit count to intensity level 0-4.

    Args:
        count: Number of commits.
        thresholds: Tuple of threshold values for each level.

    Returns:
        Intensity level (0-4), where 0 = no commits, 4 = highest activity.
    """
    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS
    if count == 0:
        return 0
    if count <= thresholds[1]:
        return 1
    if count <= thresholds[2]:
        return 2
    if count <= thresholds[3]:
        return 3
    return 4


def build_date_range(start: dt.date, end: dt.date) -> List[dt.date]:
    """Generate list of all dates from start to end inclusive.

    Args:
        start: Start date (inclusive).
        end: End date (inclusive).

    Returns:
        List of dates in range.
    """
    days: List[dt.date] = []
    cur = start
    while cur <= end:
        days.append(cur)
        cur += dt.timedelta(days=1)
    return days


def get_month_labels(
    start_date: dt.date, end_date: dt.date, week_start: str
) -> Dict[int, str]:
    """Get month abbreviations positioned at their week boundaries.

    Args:
        start_date: Start of date range.
        end_date: End of date range.
        week_start: "monday" or "sunday".

    Returns:
        Dict mapping week index to 3-letter month abbreviation.
    """
    months = {}
    all_days = build_date_range(start_date, end_date)

    if week_start == "monday":
        offset = start_date.weekday()
    else:
        offset = (start_date.weekday() + 1) % 7
    grid_start = start_date - dt.timedelta(days=offset)

    for day in all_days:
        idx = (day - grid_start).days
        week = idx // 7
        if day.day == 1:
            months[week] = calendar.month_abbr[day.month]

    return months


def render_grid(
    start_date: dt.date,
    end_date: dt.date,
    counts: Dict[dt.date, int],
    color_scheme: ColorScheme,
    week_start: str,
    border_char: str = "=",
    ascii_mode: bool = False,
    thresholds: tuple = None,
) -> str:
    """Render heatmap in grid style (horizontal squares).

    Args:
        start_date: Start of date range.
        end_date: End of date range.
        counts: Dict mapping date to commit count.
        color_scheme: Color scheme for intensity levels.
        week_start: "monday" or "sunday".
        border_char: Character for horizontal borders.
        ascii_mode: Use ASCII characters instead of Unicode blocks.
        thresholds: Custom intensity thresholds (default: (0,1,3,6,10)).

    Returns:
        Formatted string representation of heatmap.
    """
    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS
    all_days = build_date_range(start_date, end_date)

    if ascii_mode:
        block_chars = ["  ", "..", "::", "==", "##"]
    else:
        block_chars = ["  ", "░░", "▒▒", "▓▓", "██"]

    if week_start == "monday":
        offset = start_date.weekday()
    else:
        offset = (start_date.weekday() + 1) % 7
    grid_start = start_date - dt.timedelta(days=offset)

    total_days = (end_date - grid_start).days + 1
    num_weeks = (total_days + 6) // 7

    grid: List[List[int]] = [[0 for _ in range(num_weeks)] for _ in range(7)]
    for day in all_days:
        idx = (day - grid_start).days
        week = idx // 7
        weekday = day.weekday()
        count = counts.get(day, 0)
        grid[weekday][week] = choose_level(count, thresholds)

    label_days = {0: "Mon ", 2: "Wed ", 4: "Fri "}
    if week_start == "sunday":
        order = [6, 0, 1, 2, 3, 4, 5]
    else:
        order = [0, 1, 2, 3, 4, 5, 6]

    month_labels = get_month_labels(start_date, end_date, week_start)

    lines = []

    month_line = " " * 4
    for w in range(num_weeks):
        month_line += month_labels.get(w, "  ")
    lines.append(month_line)
    lines.append(border_char * len(month_line))

    for weekday in order:
        label = label_days.get(weekday, "    ")
        cells = []
        for week in range(num_weeks):
            level = grid[weekday][week]
            color = color_scheme.get(level)
            cell_char = block_chars[level]
            cells.append(f"{color}{cell_char}{RESET}")
        lines.append(f"{label} " + "".join(cells))

    lines.append(border_char * len(month_line))

    return "\n".join(lines)


def render_branch_tree(
    commits: List[Dict[str, Any]],
    default_branch: Optional[str] = None,
    selected_branch: Optional[str] = None,
    color_scheme: Optional["ColorScheme"] = None,
    ascii_mode: bool = False,
    compact: bool = False,
) -> str:
    """Render horizontal branch tree visualization.

    Args:
        commits: List of commit dicts from get_branch_tree.
        default_branch: Name of default branch (e.g., "main").
        selected_branch: Branch specified by user (for highlighting).
        color_scheme: Color scheme for branch name highlighting.
        ascii_mode: Use ASCII characters instead of Unicode.

    Returns:
        Formatted string with branch tree visualization.
    """
    if not commits:
        return ""

    node_char = "*" if ascii_mode else "•"

    lines = ["Branch Tree:"]
    branch_colors: Dict[str, str] = {}
    color_index = 2

    def get_branch_color(branch: str) -> str:
        nonlocal color_index

        if not color_scheme:
            return ""

        if selected_branch and branch == selected_branch:
            return color_scheme.get(4)

        if branch not in branch_colors:
            branch_colors[branch] = color_scheme.get(color_index)
            color_index += 1
            if color_index > 4:  # Wrap back to 2, keeping 0–1 reserved
                color_index = 2

        return branch_colors[branch]

    max_hash_len = 7
    max_branch_width = 0
    for commit in commits:
        branches = commit.get("branches", [])
        if branches:
            branch_str = ", ".join(branches)
            max_branch_width = max(max_branch_width, len(branch_str))

    has_branches = max_branch_width > 0
    if has_branches:
        separator_width = 1 + max_hash_len + 1 + 20 + 1 + max_branch_width + 1
    else:
        separator_width = 1 + max_hash_len + 1 + 35 + 1

    for commit in commits:
        graph_line = commit.get("graph_line", "*")

        if node_char != "*":
            graph_line = graph_line.replace("*", node_char)

        hash7 = commit["hash"]
        full_message = commit["message"]
        max_msg_len = 20 if compact else 35
        if len(full_message) > max_msg_len:
            message = full_message[: max_msg_len - 3] + "..."
        else:
            message = full_message + " " * (max_msg_len - len(full_message))
        branches = commit.get("branches", [])

        is_connector = not hash7 and "|" in graph_line

        branch_part = ""
        if branches:
            branch_part = " " + ", ".join(branches)

        if is_connector:
            lines.append(f"{graph_line}{' ' * separator_width}")
        else:
            sep_len = 5 if compact else 20
            sep_dashes = LIGHT_GRAY + "-" * sep_len + RESET
            branch_label = (
                LIGHT_GRAY + branch_part.strip() + RESET if branch_part else ""
            )
            separator = f" {sep_dashes} {branch_label}" if branch_part else ""
            commit_color = color_scheme.get(3) if color_scheme else ""
            lines.append(
                f"{graph_line} {commit_color}{hash7}{RESET} {message}{separator}"
            )

    return "\n".join(lines)
