"""
Voice Feature — TTS synthesis, STT transcription, voice selection.

Exposes list_voices, set_voice, speak, and transcribe tools to the agent
orchestrator. Privacy-gated: cloud providers are blocked in ephemeral/isolated
modes. Audio storage respects privacy config (none/temp/scrubbed/full).
Audio bytes are stored via the storage layer and referenced by
content_hash — raw bytes are never returned in tool results.
"""

import logging
from dataclasses import asdict
from typing import Any, AsyncIterator, Dict, Optional

from kestrel_sovereign.features.base import Feature, tool
from kestrel_sovereign.identity.identity_package import PersonalityFingerprint
from kestrel_sovereign.privacy import PrivacyConfig, get_privacy_preset
from kestrel_sovereign.tools.base import ToolCategory
from kestrel_sovereign.voice.base import VoiceConfig, VoiceInfo, TTSProvider, STTProvider, match_voice, split_sentences
from kestrel_sovereign.voice.provider_registry import VoiceProviderRegistry
from kestrel_sovereign.voice.routing import (
    InstalledProviders,
    UserVoicePreferences,
    VoiceRoute,
    VoiceRoutingContext,
    resolve as resolve_voice_route,
)
from kestrel_sovereign.voice.stream_tap import AgentStreamTap

logger = logging.getLogger(__name__)


class VoicePrivacyError(Exception):
    """Raised when a voice operation is blocked by the current privacy mode."""


class VoiceFeature(Feature):
    """Voice capabilities — TTS synthesis, STT transcription, voice selection."""

    @property
    def tool_description(self) -> str:
        return (
            "Voice capabilities — text-to-speech synthesis, speech-to-text transcription, "
            "voice selection and management for agent identity"
        )

    async def initialize(self):
        """Lazy-load VoiceProviderRegistry from agent config."""
        self._voice_registry = None
        self._voice_config = VoiceConfig()

        # Load voice config from agent identity if available
        identity = getattr(self.agent, "identity", None)
        if identity and hasattr(identity, "voice_config"):
            stored = identity.voice_config
            if isinstance(stored, dict):
                self._voice_config = VoiceConfig.from_dict(stored)
            elif isinstance(stored, VoiceConfig):
                self._voice_config = stored

    async def _ensure_registry(self) -> VoiceProviderRegistry:
        """Lazily initialize and return the voice provider registry."""
        if self._voice_registry is not None:
            return self._voice_registry

        # Pull voice config section from agent config
        agent_config = getattr(self.agent, "config", None)
        voice_section: dict = {}
        if agent_config:
            if hasattr(agent_config, "get"):
                voice_section = agent_config.get("voice", {})
            elif hasattr(agent_config, "voice"):
                voice_section = agent_config.voice or {}

        self._voice_registry = VoiceProviderRegistry(voice_section)
        await self._voice_registry.initialize()
        return self._voice_registry

    # ------------------------------------------------------------------
    # Privacy gates — delegate to PrivacyAgent (single decision point)
    # ------------------------------------------------------------------

    def _get_privacy_agent(self):
        """Get the agent's PrivacyAgent instance, or None."""
        return getattr(self.agent, "privacy_agent", None)

    def _get_privacy_mode_name(self) -> str:
        """Get the current privacy preset name (e.g. 'ephemeral', 'normal')."""
        pa = self._get_privacy_agent()
        if pa is None:
            return "normal"
        return pa.get_mode_name()

    def _cloud_allowed(self) -> bool:
        """Check whether cloud providers are allowed under current privacy mode."""
        pa = self._get_privacy_agent()
        if pa is None:
            return True
        return pa.can_use_cloud()

    def _get_audio_storage_policy(self) -> str:
        """Determine audio storage policy based on privacy config.

        Returns one of: "none", "temp", "scrubbed", "full".
        - none: Audio bytes NEVER written to disk (ephemeral).
        - temp: Audio in temp buffer, deleted on session end (isolated).
        - scrubbed: Audio not permanently stored, metadata scrubbed (anonymous).
        - full: Audio may be cached/stored normally (normal/public).
        """
        pa = self._get_privacy_agent()
        if pa is None:
            return "full"
        return pa.get_storage_policy()

    # ------------------------------------------------------------------
    # Route resolution — single source of truth (kestrel_sovereign.voice.routing)
    # ------------------------------------------------------------------

    def _get_privacy_config(self) -> PrivacyConfig:
        """Derive the current PrivacyConfig for the resolver.

        Tries, in order:
        1. ``pa.privacy_config`` or ``pa._privacy_config`` if it's a PrivacyConfig
           (the real PrivacyAgent exposes the latter; tests tend to attach the
           former directly).
        2. Synthesize from the public API (``can_use_cloud()`` + ``get_storage_policy()``)
           so the resolver works against any mock that implements the documented
           contract.
        3. Fall back to the ``normal`` preset for bare agents with no privacy
           state wired up.
        """
        pa = self._get_privacy_agent()
        if pa is None:
            return get_privacy_preset("normal")

        direct = getattr(pa, "privacy_config", None) or getattr(pa, "_privacy_config", None)
        if isinstance(direct, PrivacyConfig):
            return direct

        storage_getter = getattr(pa, "get_storage_policy", None)
        cloud_getter = getattr(pa, "can_use_cloud", None)
        if storage_getter is None or cloud_getter is None:
            return get_privacy_preset("normal")

        storage = storage_getter() or "full"
        # `shareable` is not part of the PrivacyAgent public API; default to
        # False since the resolver does not branch on it today.
        return PrivacyConfig(
            storage=storage,
            llm_location="cloud" if cloud_getter() else "local",
            shareable=False,
        )

    def _get_llm_vendor(self) -> str:
        """Return the current LLM vendor name (e.g. 'openai', 'anthropic').

        The resolver uses this to decide whether the Realtime path is an option.
        Returns an empty string when no vendor is identifiable — the resolver
        treats this as 'not OpenAI' and falls back to Pipeline.
        """
        llm_service = getattr(self.agent, "llm_service", None)
        if llm_service is None:
            return ""
        getter = getattr(llm_service, "get_current_provider_and_model", None)
        if getter is None:
            return ""
        try:
            provider, _model = getter()
        except Exception:
            return ""
        return (provider or "").lower()

    async def _resolve_route(self, overrides: Optional[UserVoicePreferences] = None) -> VoiceRoute:
        """Build a routing context from agent state and ask the resolver.

        This is the single place where voice-path rules are applied. Callers
        within this feature (and future endpoints) ask here, never hand-roll
        the privacy gate.

        ``overrides`` lets a per-call preference (e.g. \"force pipeline for
        this session\" from the voice picker) take precedence over the
        agent-persisted ``_voice_config``. None → use only the persisted
        prefs. Overrides only set fields are applied; unset fields fall back
        to the persisted values.
        """
        registry = await self._ensure_registry()
        prefs = self._voice_config
        tts_names = registry.list_tts_providers()
        stt_names = registry.list_stt_providers()
        installed = InstalledProviders(
            tts=set(tts_names),
            stt=set(stt_names),
            # Conversation providers (Realtime) are registered by a separate
            # ticket (#725); fall back to empty set if the registry doesn't
            # yet expose them.
            conversation=set(
                getattr(registry, "list_conversation_providers", lambda: [])()
            ),
            tts_local={n for n in tts_names if (p := registry.get_tts(n)) and p.is_local},
            stt_local={n for n in stt_names if (p := registry.get_stt(n)) and p.is_local},
        )
        # Overrides win when provided; else fall back to persisted config.
        ov = overrides if overrides is not None else UserVoicePreferences()
        merged = UserVoicePreferences(
            preferred_tts=ov.preferred_tts or (prefs.tts_provider or None),
            preferred_stt=ov.preferred_stt or (prefs.stt_provider or None),
            preferred_conversation=ov.preferred_conversation,
            prefer_realtime=ov.prefer_realtime,
        )
        ctx = VoiceRoutingContext(
            llm_vendor=self._get_llm_vendor(),
            privacy_config=self._get_privacy_config(),
            installed=installed,
            preferences=merged,
        )
        return resolve_voice_route(ctx)

    async def _get_tts_provider(self, overrides: Optional[UserVoicePreferences] = None) -> TTSProvider:
        """Get TTS provider for the current route.

        Delegates provider selection to the voice path resolver so privacy
        gating and fallback order live in exactly one place
        (:mod:`kestrel_sovereign.voice.routing`). Only checks the TTS channel
        — a missing STT provider does not block TTS-only callers like
        :meth:`speak`. Translates the resolver's structured output back into
        the legacy ``VoicePrivacyError`` messages callers (and existing tests)
        rely on.

        ``overrides`` flows through to ``_resolve_route`` so transport-aware
        callers (e.g. the /voice/chat WebSocket handler — which IS the
        Pipeline path by definition) can force ``prefer_realtime=False`` and
        get a Pipeline TTS provider instead of None (which the Realtime path
        legitimately returns since Realtime owns the audio I/O end-to-end).
        """
        registry = await self._ensure_registry()
        route = await self._resolve_route(overrides=overrides)
        mode_name = self._get_privacy_mode_name()

        # Preserve the "Cannot use X TTS in Y privacy mode" shape when the
        # resolver rejected a configured cloud provider under local-only mode.
        if route.blocked_tts:
            raise VoicePrivacyError(
                f"Cannot use {route.blocked_tts.title()} TTS in {mode_name} "
                f"privacy mode. Install piper-tts for local TTS, or switch to "
                f"'anonymous' or higher privacy mode."
            )

        if route.tts_provider is None:
            if mode_name in ("ephemeral", "isolated"):
                raise VoicePrivacyError(
                    f"No local TTS provider available in {mode_name} privacy "
                    f"mode. Install piper-tts for local TTS, or switch to "
                    f"'anonymous' or higher privacy mode."
                )
            raise VoicePrivacyError(
                f"No TTS provider available in {mode_name} privacy mode. "
                f"{route.reason}"
            )

        provider = registry.get_tts(route.tts_provider)
        if provider is None:
            raise VoicePrivacyError(
                f"Resolver selected TTS provider '{route.tts_provider}' but it "
                f"is not registered. {route.reason}"
            )
        return provider

    async def _get_stt_provider(self, overrides: Optional[UserVoicePreferences] = None) -> STTProvider:
        """Get STT provider for the current route. See :meth:`_get_tts_provider`.

        ``overrides`` flows through to ``_resolve_route`` so the /voice/chat
        WebSocket handler can force ``prefer_realtime=False`` — without it
        the resolver returns the Realtime route (no STT) and this raises
        "No STT provider available", which historically manifested as a
        4403 close + browser-side HTTP 403 on the WS upgrade.
        """
        registry = await self._ensure_registry()
        route = await self._resolve_route(overrides=overrides)
        mode_name = self._get_privacy_mode_name()

        if route.blocked_stt:
            raise VoicePrivacyError(
                f"Cannot use {route.blocked_stt.title()} STT in {mode_name} "
                f"privacy mode. Install faster-whisper for local STT, or switch "
                f"to 'anonymous' or higher privacy mode."
            )

        if route.stt_provider is None:
            if mode_name in ("ephemeral", "isolated"):
                raise VoicePrivacyError(
                    f"No local STT provider available in {mode_name} privacy "
                    f"mode. Install faster-whisper for local STT, or switch to "
                    f"'anonymous' or higher privacy mode."
                )
            raise VoicePrivacyError(
                f"No STT provider available in {mode_name} privacy mode. "
                f"{route.reason}"
            )

        provider = registry.get_stt(route.stt_provider)
        if provider is None:
            raise VoicePrivacyError(
                f"Resolver selected STT provider '{route.stt_provider}' but it "
                f"is not registered. {route.reason}"
            )
        return provider

    def _get_personality(self) -> PersonalityFingerprint | None:
        """Get the agent's personality fingerprint if available."""
        identity = getattr(self.agent, "identity", None)
        if identity is None:
            return None
        personality = getattr(identity, "personality", None)
        if isinstance(personality, PersonalityFingerprint):
            return personality
        if isinstance(personality, dict):
            return PersonalityFingerprint.from_dict(personality)
        return None

    def _sync_personality_from_voice(self, voice: VoiceInfo) -> None:
        """Update personality voice hints to match the selected voice metadata."""
        identity = getattr(self.agent, "identity", None)
        if identity is None:
            return
        personality = getattr(identity, "personality", None)
        if personality is None:
            return
        if isinstance(personality, dict):
            personality = PersonalityFingerprint.from_dict(personality)
            identity.personality = personality
        personality.voice_gender_preference = voice.gender
        personality.voice_age_preference = voice.age
        personality.voice_energy = voice.energy
        personality.voice_accent_preference = voice.accent

    async def _resolve_voice(self) -> tuple[TTSProvider, str]:
        """Resolve the effective TTS provider and voice_id.

        Priority:
        1. Explicit voice_config (provider + voice_id)
        2. Personality-based matching across available providers
        3. First available provider's default voice
        """
        # Priority 1: Explicit voice_config
        if self._voice_config.tts_provider and self._voice_config.tts_voice_id:
            registry = await self._ensure_registry()
            provider = registry.get_tts(self._voice_config.tts_provider)
            if provider:
                # Check availability
                try:
                    available = await provider.is_available()
                except Exception:
                    available = False
                if available:
                    return provider, self._voice_config.tts_voice_id

            # Configured provider unavailable — fall through to personality matching
            logger.info(
                "Configured voice provider '%s' unavailable, attempting personality-based matching",
                self._voice_config.tts_provider,
            )

        # Priority 2: Personality-based matching
        personality = self._get_personality()
        if personality and any([
            personality.voice_gender_preference,
            personality.voice_age_preference,
            personality.voice_energy,
            personality.voice_accent_preference,
        ]):
            registry = await self._ensure_registry()
            all_voices: list[VoiceInfo] = []
            cloud_ok = self._cloud_allowed()

            for name in registry.list_tts_providers():
                tts = registry.get_tts(name)
                if tts is None:
                    continue
                if not cloud_ok and not tts.is_local:
                    continue
                try:
                    if not await tts.is_available():
                        continue
                    voices = await tts.list_voices()
                    all_voices.extend(voices)
                except Exception:
                    continue

            matched = match_voice(personality, all_voices)
            if matched:
                tts = registry.get_tts(matched.provider)
                if tts:
                    logger.info(
                        "Personality-matched voice: %s/%s (score based on gender=%s, age=%s, energy=%s, accent=%s)",
                        matched.provider, matched.voice_id,
                        personality.voice_gender_preference,
                        personality.voice_age_preference,
                        personality.voice_energy,
                        personality.voice_accent_preference,
                    )
                    return tts, matched.voice_id

        # Priority 3: First available provider's default voice
        tts = await self._get_tts_provider()
        voices = await tts.list_voices()
        voice_id = voices[0].voice_id if voices else ""
        return tts, voice_id

    async def stream_speak(
        self,
        request_id: str,
        voice_id: str = "",
        output_format: str = "",
    ) -> AsyncIterator[bytes]:
        """Synthesize speech incrementally from an active agent stream.

        Hooks into the agent's streaming response (identified by *request_id*),
        buffers text until sentence boundaries, and yields audio chunks as each
        sentence is synthesized.

        Args:
            request_id: The agent request whose text stream to follow.
            voice_id: Override voice. Falls back to agent config then first available.
            output_format: Audio format (opus, mp3, wav, pcm). Falls back to config.

        Yields:
            Audio data chunks (bytes).
        """
        tts = await self._get_tts_provider()

        voice_id = voice_id or self._voice_config.tts_voice_id
        if not voice_id:
            voices = await tts.list_voices()
            if voices:
                voice_id = voices[0].voice_id

        output_format = output_format or self._voice_config.output_format or "opus"

        tap = AgentStreamTap.get_instance()
        if not tap.has_stream(request_id):
            raise ValueError(f"No active agent stream for request_id={request_id}")

        buffer = ""

        async for text_chunk in tap.subscribe(request_id):
            buffer += text_chunk
            sentences = split_sentences(buffer)

            if len(sentences) <= 1:
                # Not enough for a sentence boundary yet — keep buffering
                continue

            # Synthesize all complete sentences (keep the last fragment as buffer)
            to_speak = " ".join(sentences[:-1])
            buffer = sentences[-1]

            async for audio_chunk in tts.synthesize_stream(
                text=to_speak,
                voice_id=voice_id,
                model=self._voice_config.tts_model,
                output_format=output_format,
            ):
                yield audio_chunk

        # Flush any remaining buffered text
        remaining = buffer.strip()
        if remaining:
            async for audio_chunk in tts.synthesize_stream(
                text=remaining,
                voice_id=voice_id,
                model=self._voice_config.tts_model,
                output_format=output_format,
            ):
                yield audio_chunk

    def is_provider_allowed(self, provider_name: str, provider_type: str = "tts") -> bool:
        """Check if a specific provider is allowed under current privacy mode.

        Args:
            provider_name: Name of the provider (e.g., "openai", "piper").
            provider_type: "tts" or "stt".

        Returns:
            True if the provider is allowed.
        """
        if self._cloud_allowed():
            return True
        registry = getattr(self, "_voice_registry", None)
        if registry is None:
            return True
        if provider_type == "tts":
            provider = registry.get_tts(provider_name)
        else:
            provider = registry.get_stt(provider_name)
        if provider is None:
            return True
        return provider.is_local

    async def on_privacy_mode_changed(self) -> Optional[dict]:
        """React to a privacy mode change. Auto-switch voice providers if needed.

        Called by the privacy mode change endpoint. If switching to a mode that
        blocks cloud and the current voice is a cloud provider, auto-fall back to
        a local provider. If no local provider available, clear the voice config.

        Returns:
            Dict with voice_switched info, or None if no change needed.
        """
        if self._cloud_allowed():
            return None

        registry = await self._ensure_registry()
        result = {}

        # Check TTS provider
        if self._voice_config.tts_provider:
            tts = registry.get_tts(self._voice_config.tts_provider)
            if tts and not tts.is_local:
                local_tts = registry.get_local_tts()
                if local_tts:
                    old_provider = self._voice_config.tts_provider
                    self._voice_config.tts_provider = local_tts[0].name
                    self._voice_config.tts_voice_id = ""
                    result["tts_switched"] = {
                        "from": old_provider,
                        "to": local_tts[0].name,
                    }
                    logger.info("Auto-switched TTS from %s to %s due to privacy mode", old_provider, local_tts[0].name)
                else:
                    old_provider = self._voice_config.tts_provider
                    self._voice_config.tts_provider = ""
                    self._voice_config.tts_voice_id = ""
                    result["tts_switched"] = {"from": old_provider, "to": None}
                    logger.warning("No local TTS provider available; TTS disabled due to privacy mode")

        # Check STT provider
        if self._voice_config.stt_provider:
            stt = registry.get_stt(self._voice_config.stt_provider)
            if stt and not stt.is_local:
                local_stt = registry.get_local_stt()
                if local_stt:
                    old_provider = self._voice_config.stt_provider
                    self._voice_config.stt_provider = local_stt[0].name
                    result["stt_switched"] = {
                        "from": old_provider,
                        "to": local_stt[0].name,
                    }
                    logger.info("Auto-switched STT from %s to %s due to privacy mode", old_provider, local_stt[0].name)
                else:
                    old_provider = self._voice_config.stt_provider
                    self._voice_config.stt_provider = ""
                    result["stt_switched"] = {"from": old_provider, "to": None}
                    logger.warning("No local STT provider available; STT disabled due to privacy mode")

        # Persist updated config to agent identity
        if result:
            identity = getattr(self.agent, "identity", None)
            if identity and hasattr(identity, "voice_config"):
                identity.voice_config = self._voice_config.to_dict()

        return result if result else None

    @staticmethod
    def biometric_warning() -> str:
        """Warning message about voice data being biometric."""
        return (
            "WARNING: Voice data is biometric information. Enabling cloud voice providers "
            "will send voice data to third-party services. This data may be used for "
            "processing and cannot be fully recalled once transmitted."
        )

    # ------------------------------------------------------------------
    # Dynamic router
    # ------------------------------------------------------------------

    def get_router(self):
        """Return the Voice HTTP/WebSocket router for dynamic mounting.

        The core router is defined in ``endpoints/voice.py``. The Realtime
        ephemeral-token endpoint (``/voice/realtime/session``, issue #726)
        lives in a sibling module; include it here so both mount atomically
        with the feature.
        """
        from endpoints.voice import router
        from endpoints.voice_realtime import router as realtime_router

        # include_router is idempotent only if we're careful — guard against
        # double-mount when get_router is called twice for the same feature
        # instance (the include machinery doesn't dedupe path entries).
        if not getattr(self, "_realtime_mounted", False):
            router.include_router(realtime_router)
            self._realtime_mounted = True
        return router

    # ------------------------------------------------------------------
    # Tools
    # ------------------------------------------------------------------

    @tool("list_voices", "List available TTS voices, optionally filtered by provider", ToolCategory.SYSTEM)
    async def list_voices(self, provider: str = "") -> dict:
        """List available voices.

        Args:
            provider: Filter to a specific provider (e.g., "openai", "piper",
                "openai_realtime"). Empty = all TTS providers (conversation
                providers are returned only when explicitly named, since
                their voice catalogs typically overlap with sibling TTS
                providers and we don't want duplicates in the unfiltered
                view).
        """
        registry = await self._ensure_registry()
        cloud_ok = self._cloud_allowed()
        voices: list[dict] = []

        tts_names = registry.list_tts_providers()
        if provider:
            tts_names = [n for n in tts_names if n == provider]

        for name in tts_names:
            tts = registry.get_tts(name)
            if tts is None:
                continue
            if not cloud_ok and not tts.is_local:
                continue
            try:
                provider_voices = await tts.list_voices()
                for v in provider_voices:
                    voices.append(asdict(v) if isinstance(v, VoiceInfo) else v)
            except Exception as exc:
                logger.warning("Failed to list voices from %s: %s", name, exc)

        # Conversation providers own their own VoiceInfo per the ABC, so we
        # just pass through without sibling-catalog scans or fabrication.
        conv_names = (
            [n for n in registry.list_conversation_providers() if n == provider]
            if provider
            else []
        )
        for name in conv_names:
            conv = registry.get_conversation(name)
            if conv is None:
                continue
            if not cloud_ok and not getattr(conv, "is_local", False):
                continue
            try:
                for v in await conv.list_voices():
                    voices.append(asdict(v) if isinstance(v, VoiceInfo) else v)
            except Exception as exc:
                logger.warning(
                    "Failed to list voices from conversation provider %s: %s",
                    name, exc,
                )

        return {"voices": voices, "count": len(voices)}

    @tool("set_voice", "Set the agent's TTS voice for spoken responses", ToolCategory.SYSTEM)
    async def set_voice(self, voice_id: str, provider: str = "") -> dict:
        """Set the agent's voice.

        Args:
            voice_id: The voice identifier (e.g., "nova", "en_US-lessac-medium")
            provider: Provider name. If empty, auto-detect from voice_id.
        """
        registry = await self._ensure_registry()

        # Auto-detect provider if not specified
        resolved_provider = provider
        if not resolved_provider:
            for name in registry.list_tts_providers():
                tts = registry.get_tts(name)
                if tts is None:
                    continue
                try:
                    provider_voices = await tts.list_voices()
                    if any(v.voice_id == voice_id for v in provider_voices):
                        resolved_provider = name
                        break
                except Exception:
                    continue

        if not resolved_provider:
            return {"success": False, "error": f"Could not find voice '{voice_id}' in any provider."}

        # Validate provider is accessible under current privacy mode
        tts = registry.get_tts(resolved_provider)
        if tts and not self._cloud_allowed() and not tts.is_local:
            return {
                "success": False,
                "error": f"Provider '{resolved_provider}' is a cloud service blocked by current privacy mode.",
            }

        self._voice_config.tts_provider = resolved_provider
        self._voice_config.tts_voice_id = voice_id

        # Persist to agent identity if available
        identity = getattr(self.agent, "identity", None)
        if identity and hasattr(identity, "voice_config"):
            identity.voice_config = self._voice_config.to_dict()

        # Sync personality hints with selected voice metadata
        if tts:
            try:
                provider_voices = await tts.list_voices()
                for v in provider_voices:
                    if v.voice_id == voice_id:
                        self._sync_personality_from_voice(v)
                        break
            except Exception:
                pass

        return {
            "success": True,
            "voice_id": voice_id,
            "provider": resolved_provider,
        }

    @tool("speak", "Synthesize speech from text using the agent's configured voice", ToolCategory.SYSTEM)
    async def speak(self, text: str) -> dict:
        """Synthesize speech from text.

        Args:
            text: The text to speak aloud
        """
        tts, voice_id = await self._resolve_voice()
        if not voice_id:
            return {"success": False, "error": "No voices available on any TTS provider."}

        audio_bytes = await tts.synthesize(
            text=text,
            voice_id=voice_id,
            model=self._voice_config.tts_model,
            output_format=self._voice_config.output_format,
        )

        # Store audio respecting privacy policy
        storage_policy = self._get_audio_storage_policy()
        content_hash = ""

        if storage_policy == "none":
            # Ephemeral: audio bytes NEVER written to disk, served from memory only
            logger.debug("Ephemeral mode: audio bytes not persisted.")
        elif storage_policy == "temp":
            # Isolated: audio in temp buffer, deleted on session end
            storage = getattr(self.agent, "storage", None)
            if storage and hasattr(storage, "store_file"):
                ext = self._voice_config.output_format or "opus"
                content_hash = await storage.store_file(
                    audio_bytes,
                    f"speech.{ext}",
                    metadata={
                        "type": "tts_audio",
                        "format": ext,
                        "voice_id": voice_id,
                        "provider": tts.name,
                        "text_length": len(text),
                        "storage_policy": "temp",
                    },
                )
        elif storage_policy == "scrubbed":
            # Anonymous: audio not permanently stored, metadata scrubbed
            storage = getattr(self.agent, "storage", None)
            if storage and hasattr(storage, "store_file"):
                ext = self._voice_config.output_format or "opus"
                content_hash = await storage.store_file(
                    audio_bytes,
                    f"speech.{ext}",
                    metadata={
                        "type": "tts_audio",
                        "format": ext,
                        "text_length": len(text),
                        "storage_policy": "scrubbed",
                        # voice_id and provider intentionally omitted to avoid speaker identification
                    },
                )
        else:
            # Full storage (normal/public)
            storage = getattr(self.agent, "storage", None)
            if storage and hasattr(storage, "store_file"):
                ext = self._voice_config.output_format or "opus"
                content_hash = await storage.store_file(
                    audio_bytes,
                    f"speech.{ext}",
                    metadata={
                        "type": "tts_audio",
                        "format": ext,
                        "voice_id": voice_id,
                        "provider": tts.name,
                        "text_length": len(text),
                    },
                )
            else:
                logger.warning("No storage available; audio bytes not persisted.")

        return {
            "success": True,
            "content_hash": content_hash,
            "format": self._voice_config.output_format,
            "voice_id": voice_id,
            "provider": tts.name,
            "text_length": len(text),
            "audio_size": len(audio_bytes),
            "storage_policy": storage_policy,
        }

    @tool("transcribe", "Transcribe audio to text", ToolCategory.SYSTEM)
    async def transcribe(self, audio_content_hash: str) -> dict:
        """Transcribe audio file to text.

        Args:
            audio_content_hash: Content hash of audio file (retrievable via /api/files/{hash})
        """
        # Retrieve audio from storage
        storage = getattr(self.agent, "storage", None)
        if not storage or not hasattr(storage, "retrieve_file"):
            return {"success": False, "error": "Storage not available for audio retrieval."}

        audio_bytes = await storage.retrieve_file(audio_content_hash)
        if audio_bytes is None:
            return {"success": False, "error": f"Audio file not found: {audio_content_hash}"}

        # Determine audio format from metadata
        audio_format = "opus"
        if hasattr(storage, "get_file_metadata"):
            meta = await storage.get_file_metadata(audio_content_hash)
            if meta and isinstance(meta, dict):
                audio_format = meta.get("format", audio_format)

        stt = await self._get_stt_provider()
        transcript = await stt.transcribe(
            audio=audio_bytes,
            language="",
            audio_format=audio_format,
        )

        return {
            "success": True,
            "text": transcript,
            "provider": stt.name,
            "audio_content_hash": audio_content_hash,
        }
