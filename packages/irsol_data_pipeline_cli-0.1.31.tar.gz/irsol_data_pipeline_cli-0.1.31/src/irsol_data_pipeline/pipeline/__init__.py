"""Pipeline processing logic."""
