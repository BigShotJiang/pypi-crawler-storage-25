/*==============================================================================
 Copyright (c) 2025 Antares <antares0982@gmail.com>

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 *============================================================================*/

#undef SSRJSON_COMPILE_CONTEXT_W
//
#undef WRITE_BIT_SIZE
#undef _CAST_WRITER
//
#undef dst_t
//
#undef make_w_name
//
#undef unicode_buffer_reserve
#undef u64_to_unicode
#undef u32_to_unicode
#undef u16_to_unicode
#undef u8_to_unicode
#undef f64_to_unicode
#undef f32_to_unicode
#undef inf_nan_to_unicode
#undef ControlEscapeTable
//
#undef write_unicode_bool
#undef write_unicode_bool_numpy
#undef write_unicode_null
#undef write_unicode_empty_arr
#undef write_unicode_arr_begin
#undef write_unicode_arr_end
#undef write_unicode_empty_obj
#undef write_unicode_obj_begin
#undef write_unicode_obj_end
