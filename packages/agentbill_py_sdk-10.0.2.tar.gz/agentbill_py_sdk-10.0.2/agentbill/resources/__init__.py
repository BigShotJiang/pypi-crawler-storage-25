"""AgentBill Resources - Business Objects CRUD"""

from .customers import CustomersResource
from .agents import AgentsResource
from .signals_resource import SignalsResource

__all__ = ['CustomersResource', 'AgentsResource', 'SignalsResource']
