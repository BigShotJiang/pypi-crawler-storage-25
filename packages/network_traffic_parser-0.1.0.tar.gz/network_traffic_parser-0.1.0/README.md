# network_traffic_parser

Validate telecom control-plane traffic in PCAPs using **pyshark** / Wireshark dissectors: HTTP/2 service interfaces, PFCP, NGAP, Diameter, LCSAP, DNS, S1AP, and GTPv2-style filters.

## Requirements

- Python 3.9+
- [Wireshark](https://www.wireshark.org/) / **tshark** on `PATH` (used by pyshark)

## Install

From [PyPI](https://pypi.org/project/network_traffic_parser/):

```bash
pip install network_traffic_parser
```

Development (editable) install:

```bash
pip install -e ".[dev]"
```

## Command line

After install, a console script is registered:

```bash
network_traffic_parser -f capture.pcap suite.yaml MY_TESTCASE
```

Same entry point via module execution:

```bash
python -m network_traffic_parser -f capture.pcap suite.yaml MY_TESTCASE
```

Arguments after `-f` / `--file` are scanned for a `.pcap`, a `.yaml`, and the testcase name (legacy behavior).

Configure logging in your environment as usual; the CLI sets `INFO` on the root logger.

## Library usage

```python
import logging
from network_traffic_parser import TelecomPcapAnalyzer, VALIDATION_PROTOCOLS, merge_decode_as

logging.basicConfig(level=logging.INFO)

analyzer = TelecomPcapAnalyzer(
    "capture.pcap",
    decode_as={"tcp.port==9999": "http2"},
    path_contains_match=False,
    strict_protocol_validation=False,
)
result = analyzer.wireshark_parser(headers_from_yaml)
```

- **`decode_as`**: Wireshark-style map (`tcp.port==443` → `http2`, …), merged with built-in defaults.
- **`VALIDATION_PROTOCOLS`**: allowed `PROTOCOL` strings when `strict_protocol_validation=True`.
- **`Http2Parser`** is an alias for **`TelecomPcapAnalyzer`**.

## Version

`network_traffic_parser.__version__` is read from package metadata when the distribution is installed.

## Build and publish (maintainers)

```bash
python -m pip install build twine
python -m build
python -m twine upload dist/*
```

Update `Repository` / `Issues` URLs in `pyproject.toml` before publishing if you use a public git host.
