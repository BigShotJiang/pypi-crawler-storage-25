import argparse
import json
import logging

import pprint
import pyshark
import yaml

logger = logging.getLogger(__name__)

# Wireshark / pyshark short field name for the PFCP session-endpoint identifier (fixed by the dissector).
_WIRESHARK_PFCP_SESSION_ENDPOINT = "seid"


class pfcp:
	def __init__(self, pcap_path, decode_as_map):
		self._pcap_path = pcap_path
		self._decode_as = decode_as_map

	def get_filter_packet(self,filter):
		try:
			data_packet = pyshark.FileCapture(self._pcap_path, display_filter=filter, decode_as=self._decode_as)
			data_pkt = data_packet
			data_packet.close()
			return data_pkt
		except Exception as e:
			logger.error("get_filter_packet: %s", e)

	def split_json_val(self, json_string, session_endpoint_id):
		li = json_string.split(',')
		for i in range(len(li)):
			token = li[i].lower().strip()
			# YAML keyword; Wireshark display filter must keep the PFCP field name from the dissector
			if token == 'session_endpoint':
				li[i] = f"pfcp.{_WIRESHARK_PFCP_SESSION_ENDPOINT} == {session_endpoint_id}"
		fil = " and ".join(li)
		return fil

	def get_session_endpoint_id(self, filter_str):
		packet = self.get_filter_packet(filter_str)
		session_endpoint_id = ''
		packet_no = None
		for pkt in packet:
			session_endpoint_id = str(getattr(pkt.pfcp, _WIRESHARK_PFCP_SESSION_ENDPOINT))
			if session_endpoint_id:
				packet_no = str(pkt.frame_info.number)
				break
			logger.debug("session_endpoint_id candidate: %s", session_endpoint_id)
		if session_endpoint_id:
			return session_endpoint_id, packet_no
		return None



	def pfcp_parser_check(self, header, session_endpoint_id=''):
		full_header = ''
		result = []
		report_result =[]
		res =()
		count = 0
		for full_head in header['HEADER_STRING_SHOULD_CONTAIN']:
			full_head.strip()
			full_header += '/'+full_head
		split_json_fil = self.split_json_val(header['HEADER_DATA_VALIDATION'], session_endpoint_id)
		fil = split_json_fil
		logger.debug("PFCP display filter: %s", fil)
		full_header += '/' + fil
		pkt = self.get_filter_packet(fil)
		for p in pkt:
			count +=1
			packet_no = str(p.frame_info.number)
		if count >=1:
			res += (header['CALL_LEGS'],full_header,'Packet Should Exist','Packet Exist','TRUE',packet_no)
			result.append('True')
		else:
			res += (header['CALL_LEGS'],full_header,'Packet Should Exist','Packet does not Exist','FALSE','N/A')
			result.append('False')
		report_result.append(res)
		logger.debug("pfcp_parser_check report_result=%s result=%s", report_result, result)
		return report_result,result
		
if __name__ == "__main__":
	pf= pfcp('LBUCS008_smfdatatrace_SMF-10_28_10_2019_12_58.pcap')
	pf.pkt_fil()