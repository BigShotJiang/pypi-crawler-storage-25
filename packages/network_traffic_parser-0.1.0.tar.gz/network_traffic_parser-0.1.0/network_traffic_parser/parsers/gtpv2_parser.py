import itertools
import json
import logging
import pprint

import pyshark
import yaml

logger = logging.getLogger(__name__)

# class gtpv2_parser():
# 	def __init__(self,filename):
# 		self.file = filename
# 		self.decode= decode_values.Decode_Port
# 		self.g_request = {}
# 		self.g_response = {}

# 	def check_packet(self,filter):
# 		try:
# 			data_packet = pyshark.FileCapture(self.file, display_filter=filter, decode_as=self.decode)
# 			data_pkt = data_packet
# 			data_packet.close()
# 			return data_pkt
# 		except Exception as e:
# 			print("Error in check_packet: {}".format(e))

# 	def split_json_val(self,json_string):
# 		li = json_string.split(',')
# 		li = " and ".join(li)
# 		return li
	
# 	def str_to_dict(self, data_string):
# 		return dict((a.strip(), (b.strip()))
#          for a, b in (element.split('==')
#                       for element in data_string.split('and ')))

# 	def dict_check(self, value, dup_dict): # value: string and dup_dict: dict
# 		for key in dup_dict:
# 			return value in dup_dict[key]['f_teid_gre_key']

# 	def check_value(self, referecevalue):
# 		checkwiththis = ['delete' , 'update' , 'release']
# 		for checkitem in checkwiththis:
# 			if checkitem.lower() not in referecevalue.lower():
# 				return True
# 			else:
# 				return False

# 	def gtpv2_parser_check(self,header):
# 		try:
# 			full_header = ''
# 			result = []
# 			report_result =[]
# 			res =()
# 			count = 0
# 			for full_head in header['HEADER_STRING_SHOULD_CONTAIN']:
# 				full_head.strip()
# 				full_header += '/'+full_head
# 			split_json_fil = self.split_json_val(header['HEADER_DATA_VALIDATION'])
# 			fil = split_json_fil
			
# 			full_header += '/' + fil
# 			# print ('fill items: {}'.format(fil)) 
# 			# print ('full_header items: {}'.format(full_header)) 

# 			if 'request' in (header['HEADER_STRING_SHOULD_CONTAIN'][-1]).lower():
# 				pkt = self.check_packet(fil)
# 				packet_numbers = []
# 				for p in pkt:
# 					count +=1
# 					if hasattr(p.gtpv2, 'f_teid_gre_key'):
# 						# import pdb;pdb.set_trace()
# 						# self.dict_check(p.gtpv2.f_teid_gre_key, self.g_request)
# 						if len(self.g_request) == 0 or not self.dict_check(p.gtpv2.f_teid_gre_key, self.g_request):
# 							self.g_request[str(p.frame_info.number)] = self.str_to_dict(fil)
# 							self.g_request[str(p.frame_info.number)]['f_teid_gre_key'] = p.gtpv2.f_teid_gre_key #interface fteid

# 						packet_no = str(p.frame_info.number)
# 						# packet_numbers.append(packet_no)
# 						# packet_numbers_str = ", ".join(packet_numbers)
# 					else:
# 						packet_no = str(p.frame_info.number)
# 						# packet_numbers.append(packet_no)
# 						# packet_numbers_str = ", ".join(packet_numbers)				

# 			if 'response' in (header['HEADER_STRING_SHOULD_CONTAIN'][-1]).lower():
# 				# import pdb;pdb.set_trace()
# 				print ('self.g_request',self.g_request)

# 				if self.g_request and self.check_value(full_head):
# 					for verification in self.g_request:
# 						# if len(self.g_request) == 1:
# 						validate = fil + ' and (gtpv2.teid == '+self.g_request[verification]['f_teid_gre_key'] + ' or gtpv2.f_teid_gre_key == ' +self.g_request[verification]['f_teid_gre_key'] +')'
# 						# elif len(self.g_request) > 1:
# 						# 	full_header = fil + ' or (gtpv2.teid == '+self.g_request[verification]['f_teid_gre_key'] + ' or gtpv2.f_teid_gre_key == ' +self.g_request[verification]['f_teid_gre_key'] +')'
# 						full_header = '/' + full_head + '/'+ validate
# 						pkt = self.check_packet(validate)
# 						packet_numbers = []
# 						# import pdb;pdb.set_trace()
# 						for p in pkt:
# 							count +=1
# 							packet_no = str(p.frame_info.number)
# 							# packet_numbers.append(packet_no)
# 							# packet_numbers_str = ", ".join(packet_numbers)
# 				else: # to support old code
# 					pkt = self.check_packet(fil)
# 					packet_numbers = []
# 					for p in pkt:
# 							count +=1
# 							packet_no = str(p.frame_info.number)
# 							# packet_numbers.append(packet_no)
# 							# packet_numbers_str = ", ".join(packet_numbers)
				
# 			packet_numbers = []


# 			if count >=1:
# 				res += (header['CALL_LEGS'],full_header,'Packet Should Exist','Packet Exist','TRUE',packet_no)
# 				result.append('True')
# 			else:
# 				res += (header['CALL_LEGS'],full_header,'Packet Should Exist','Packet does not Exist','FALSE','N/A')
# 				result.append('False')

# 			report_result.append(res)
# 			print(report_result)
# 			print(result)
# 			return report_result,result
# 		except Exception as E:
# 			print ("Exception in gtpv2_parser_check: {}".format(str(E)))






# Commented on 11/15/2022 by Ashish. Please contact if you need any information

class gtpv2_parser():
	def __init__(self, pcap_path, decode_as_map):
		self._pcap_path = pcap_path
		self._decode_as = decode_as_map

	def check_packet(self,filter):
		try:
			data_packet = pyshark.FileCapture(self._pcap_path, display_filter=filter, decode_as=self._decode_as)
			data_pkt = data_packet
			data_packet.close()
			return data_pkt
		except Exception as e:
			logger.error("check_packet: %s", e)

	def split_json_val(self,json_string):
		li = json_string.split(',')
		li = " and ".join(li)
		return li
		
	def gtpv2_parser_check(self,header):
		try:
			full_header = ''
			result = []
			report_result =[]
			res =()
			count = 0
			for full_head in header['HEADER_STRING_SHOULD_CONTAIN']:
				full_head.strip()
				full_header += '/'+full_head
			split_json_fil = self.split_json_val(header['HEADER_DATA_VALIDATION'])
			fil = split_json_fil
			full_header += '/' + fil
			pkt = self.check_packet(fil)
			for p in pkt:
				count +=1
				packet_no = str(p.frame_info.number)
			if count >=1:
				res += (header['CALL_LEGS'],full_header,'Packet Should Exist','Packet Exist','TRUE',packet_no)
				result.append('True')
			else:
				res += (header['CALL_LEGS'],full_header,'Packet Should Exist','Packet does not Exist','FALSE','N/A')
				result.append('False')
			report_result.append(res)
			logger.debug("gtpv2_parser_check report_result=%s result=%s", report_result, result)
			return report_result,result
		except Exception:
			logger.exception("gtpv2_parser_check failed")


