import itertools
import json
import logging
import pprint

import pyshark
import yaml

logger = logging.getLogger(__name__)


class ngap_parser():
	def __init__(self, pcap_path, decode_as_map):
		self._pcap_path = pcap_path
		self._decode_as = decode_as_map

	def check_packet(self,filter):
		try:
			data_packet = pyshark.FileCapture(self._pcap_path, display_filter=filter, decode_as=self._decode_as)
			data_pkt = data_packet
			data_packet.close()
			return data_pkt
		except Exception as e:
			logger.error("check_packet: %s", e)

	def split_json_val(self,json_string):
		li = json_string.split(',')
		li = " and ".join(li)
		return li
		
	def ngap_parser_check(self,header):
		full_header = ''
		result = []
		report_result =[]
		# res =()
		count = 0
		for full_head in header['HEADER_STRING_SHOULD_CONTAIN']:
			filters = full_head.split(',')
			for fil in filters:
				res =()
				pkt = self.check_packet(fil)
				pkt.load_packets()
				if len(pkt) >= 1: 
					packet_numbers = []
					for p in pkt:
						packet_numbers.append(str(p.frame_info.number))

					packet_numbers_str = ", ".join(packet_numbers)
					# print ('packet found', 'packet_numbers: ', packet_numbers_str)

					res += (header['CALL_LEGS'],fil,'Packet Should Exist','Packet Exist','TRUE',packet_numbers_str)
					result.append('True')
				else: 
					logger.warning("NGAP: packet not found for filter")
					res += (header['CALL_LEGS'],fil,'Packet Should Exist','Packet does not Exist','FALSE','N/A')
					result.append('False')

				logger.debug("NGAP row=%s type=%s", res, type(res))
				report_result.append(res)

		logger.debug("NGAP report_result=%s result=%s", report_result, result)
		return report_result,result
