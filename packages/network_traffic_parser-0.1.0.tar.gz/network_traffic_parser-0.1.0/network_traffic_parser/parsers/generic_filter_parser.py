"""
Generic PCAP check: build a Wireshark *display filter* from the YAML case and
verify at least one packet matches. Same shape as ``dns_parser_check`` — use
this until you add a dedicated parser for a protocol.

YAML fields used (same as DNS / similar parsers):

- ``HEADER_STRING_SHOULD_CONTAIN``: fragments joined with `` and ``
- ``HEADER_DATA_VALIDATION``: optional extra fragments (joined the same way)
- ``DATA_DATA_VALIDATION``: optional; semicolon-separated pieces are appended
  to ``HEADER_STRING_SHOULD_CONTAIN`` (legacy behavior)
"""

from __future__ import annotations

import logging

import pyshark

logger = logging.getLogger(__name__)


class GenericFilterParser:
    def __init__(self, pcap_path, decode_as_map):
        self._pcap_path = pcap_path
        self._decode_as = decode_as_map

    def _capture(self, display_filter: str):
        return pyshark.FileCapture(
            self._pcap_path,
            display_filter=display_filter,
            decode_as=self._decode_as,
        )

    def filter_check(self, header: dict):
        """
        Return ``(report_result, result)`` tuples consistent with other parsers.
        """
        proto = (header.get("PROTOCOL") or "generic").strip()
        result = []
        report_result = []

        hsc = header.setdefault("HEADER_STRING_SHOULD_CONTAIN", [])
        if header.get("DATA_DATA_VALIDATION"):
            header["DATA_DATA_VALIDATION"] = header["DATA_DATA_VALIDATION"].replace("; ", ";").split(";")
            for validation in header["DATA_DATA_VALIDATION"]:
                hsc.append(validation)
            header["DATA_DATA_VALIDATION"] = []

        hda = header.get("HEADER_DATA_VALIDATION") or []
        filters = " and ".join(hsc)
        filters2 = " and ".join(hda)
        if filters2:
            filters = filters + " and " + filters2

        logger.debug("%s display filter: %s", proto, filters)
        res = ()
        pkt = self._capture(filters)
        pkt.load_packets()
        if len(pkt) >= 1:
            packet_numbers = [str(p.frame_info.number) for p in pkt]
            packet_numbers_str = ", ".join(packet_numbers)
            res += (
                header["CALL_LEGS"],
                filters,
                "Packet Should Exist",
                "Packet Exist",
                "TRUE",
                packet_numbers_str,
            )
            result.append("True")
        else:
            logger.warning("%s: packet not found for filter", proto)
            res += (
                header["CALL_LEGS"],
                filters,
                "Packet Should Exist",
                "Packet does not Exist",
                "FALSE",
                "N/A",
            )
            result.append("False")

        report_result.append(res)
        logger.debug("%s report_result=%s result=%s", proto, report_result, result)
        return report_result, result
