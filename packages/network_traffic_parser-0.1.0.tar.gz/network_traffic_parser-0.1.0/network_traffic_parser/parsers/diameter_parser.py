import itertools
import json
import logging
import pprint

import pyshark
import yaml

logger = logging.getLogger(__name__)


class diameter_parser():
	def __init__(self, pcap_path, decode_as_map):
		self._pcap_path = pcap_path
		self._decode_as = decode_as_map

	def check_packet(self,filter):
		try:
			data_packet = pyshark.FileCapture(self._pcap_path, display_filter=filter, decode_as=self._decode_as)
			data_pkt = data_packet
			data_packet.close()
			return data_pkt
		except Exception as e:
			logger.error("check_packet: %s", e)

	def split_json_val(self,json_string):
		li = json_string.split(',')
		li = " and ".join(li)
		return li
		
	def diameter_parser_check(self,header):
		full_header = ''
		result = []
		report_result =[]
		# res =()
		count = 0
		logger.debug("diameter case header=%s", header)
		if header['DATA_DATA_VALIDATION']:
			header['DATA_DATA_VALIDATION'] = header['DATA_DATA_VALIDATION'].replace('; ', ';').split(';')
			for validation in header['DATA_DATA_VALIDATION']:
				header['HEADER_STRING_SHOULD_CONTAIN'].append(validation)
			header['DATA_DATA_VALIDATION'] = []
		if header['HEADER_DATA_VALIDATION']:
			header['HEADER_DATA_VALIDATION'] = header['HEADER_DATA_VALIDATION'].replace(', ', ',').split(',')

		filters = ' and '.join(header['HEADER_STRING_SHOULD_CONTAIN'])
		filters2 = ' and '.join(header['HEADER_DATA_VALIDATION'])
		if filters2:
			filters = filters + ' and ' + filters2
		if header['HEADER_JSON_SHOULD_CONTAIN']:
			filters = filters + ' and diameter.flags.request == '
			if 'response' in header['HEADER_JSON_SHOULD_CONTAIN'].lower():
				filters = filters + '0'
			else:
				filters = filters + '1'
			header['HEADER_JSON_SHOULD_CONTAIN'] = ''
		logger.debug("Diameter display filter: %s", filters)
		res =()
		pkt = self.check_packet(filters)
		pkt.load_packets()
		if len(pkt) >= 1: 
			packet_numbers = []
			for p in pkt:
				packet_numbers.append(str(p.frame_info.number))

			packet_numbers_str = ", ".join(packet_numbers)
			# print ('packet found', 'packet_numbers: ', packet_numbers_str)

			res += (header['CALL_LEGS'],filters,'Packet Should Exist','Packet Exist','TRUE',packet_numbers_str)
			result.append('True')
		else: 
			print ('packet not found')
			res += (header['CALL_LEGS'],filters,'Packet Should Exist','Packet does not Exist','FALSE','N/A')
			result.append('False')

		logger.debug("Diameter row=%s type=%s", res, type(res))
		report_result.append(res)

		logger.debug("Diameter report_result=%s result=%s", report_result, result)
		return report_result,result

