"""
Telecom / 5G PCAP validation helpers built on pyshark (HTTP/2, PFCP, NGAP, …).
"""

from importlib.metadata import PackageNotFoundError, version

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

try:
    __version__ = version("network_traffic_parser")
except PackageNotFoundError:
    # Local checkout without installation
    __version__ = "0.0.0"

from .analyzer import TelecomPcapAnalyzer
from .decode_defaults import DEFAULT_DECODE_AS_MAP
from .protocols import (
    DECODE_AS_TARGET_PROTOCOLS,
    PROTOCOLS_GENERIC_DISPLAY_FILTER,
    VALIDATION_PROTOCOLS,
    ProtocolValidationError,
    list_validation_protocols,
    merge_decode_as,
    normalize_dispatch_protocol,
    validate_decode_as_key,
    validate_decode_as_target,
    validate_validation_protocol,
)

__version__ = "0.1.0"

# Backward-compatible name for legacy scripts
Http2Parser = TelecomPcapAnalyzer

__all__ = [
    "DECODE_AS_TARGET_PROTOCOLS",
    "DEFAULT_DECODE_AS_MAP",
    "PROTOCOLS_GENERIC_DISPLAY_FILTER",
    "Http2Parser",
    "ProtocolValidationError",
    "TelecomPcapAnalyzer",
    "VALIDATION_PROTOCOLS",
    "list_validation_protocols",
    "merge_decode_as",
    "normalize_dispatch_protocol",
    "validate_decode_as_key",
    "validate_decode_as_target",
    "validate_validation_protocol",
    "__version__",
]
