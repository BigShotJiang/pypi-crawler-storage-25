import json
import logging

import pyshark

logger = logging.getLogger(__name__)

from .protocols import (
    PROTOCOLS_GENERIC_DISPLAY_FILTER,
    merge_decode_as,
    normalize_dispatch_protocol,
    validate_validation_protocol,
)
from .parsers import (
    dns_parser,
    diameter_parser,
    generic_filter_parser,
    gtpv2_parser,
    lcsap_parser,
    ngap_parser,
    pfcp,
    s1ap_parser,
)


class TelecomPcapAnalyzer:
    def __init__(
        self,
        pcap_path,
        *,
        decode_as=None,
        path_contains_match=False,
        strict_protocol_validation=False,
    ):
        self._pcap_path = pcap_path
        self._decode_as = merge_decode_as(decode_as)
        self._gtpv2 = gtpv2_parser.gtpv2_parser(self._pcap_path, self._decode_as)
        self._pfcp = pfcp.pfcp(self._pcap_path, self._decode_as)
        self._ngap = ngap_parser.ngap_parser(self._pcap_path, self._decode_as)
        self._path_contains_match = path_contains_match
        self._strict_protocol_validation = strict_protocol_validation
        self._diameter = diameter_parser.diameter_parser(self._pcap_path, self._decode_as)
        self._lcsap = lcsap_parser.lcsap_parser(self._pcap_path, self._decode_as)
        self._dns = dns_parser.dns_parser(self._pcap_path, self._decode_as)
        self._s1ap = s1ap_parser.s1ap_parser(self._pcap_path, self._decode_as)
        self._generic_filter = generic_filter_parser.GenericFilterParser(
            self._pcap_path, self._decode_as
        )
        self._session_endpoint_id = ""

    @staticmethod
    def _normalize_stream_id(packet):
        sid = packet.http2.streamid
        return "1" if sid == "0" else sid

    def _capture(self, display_filter):
        return pyshark.FileCapture(
            self._pcap_path, display_filter=display_filter, decode_as=self._decode_as
        )

    def _first_packet(self, display_filter):
        cap = self._capture(display_filter)
        try:
            for pkt in cap:
                return pkt
            return None
        finally:
            cap.close()

    def create_header_filter(self, args, second_validation=None):
        second_validation = second_validation or {}
        try:
            parts = []
            for raw in args:
                for segment in raw.strip().split("?"):
                    if self._path_contains_match:
                        esc = segment.replace('"', '\\"')
                        parts.append(f'http2.headers.path contains "{esc}"')
                    else:
                        parts.append(f'http2.headers.path matches "{segment}"')
            header_filter = " and ".join(parts) if parts else ""
            if second_validation:
                val = second_validation["VALUE"]
                if isinstance(val, bool):
                    json_fil = str(val).lower()
                elif str(val).isdigit():
                    json_fil = f'number=="{val}"'
                else:
                    json_fil = f'string=="{val}"'
                header_filter += (
                    f' and json.key=="{second_validation["KEY"]}"'
                    f" and json.value.{json_fil}"
                )
            return header_filter
        except Exception:
            logger.exception("create_header_filter failed")

    def data_packet(self, packet):
        try:
            stream_id = self._normalize_stream_id(packet)
            flt = (
                f"http2.data.data and http2.streamid=={stream_id} "
                f"and ip.src=={packet.ip.dst} and ip.dst=={packet.ip.src} "
                f"and tcp.srcport == {packet.tcp.dstport} "
                f"and tcp.dstport == {packet.tcp.srcport} and json"
            )
            return self._first_packet(flt)
        except Exception as e:
            logger.error("data_packet: %s", e)

    def header_data_packet(self, packet):
        try:
            stream_id = self._normalize_stream_id(packet)
            flt = (
                f"http2.data.data and http2.streamid=={stream_id} "
                f"and ip.src=={packet.ip.src} and ip.dst=={packet.ip.dst} "
                f"and tcp.srcport == {packet.tcp.srcport} "
                f"and tcp.dstport == {packet.tcp.dstport} and json"
            )
            return self._first_packet(flt)
        except Exception as e:
            logger.error("header_data_packet: %s", e)

    def all_header_data_packet(self, packet):
        try:
            stream_id = self._normalize_stream_id(packet)
            flt = (
                f"http2.data.data and http2.streamid=={stream_id} "
                f"and ip.src=={packet.ip.src} and ip.dst=={packet.ip.dst} and json"
            )
            cap = self._capture(flt)
            out = cap
            cap.close()
            return out
        except Exception as e:
            logger.error("all_header_data_packet: %s", e)

    def all_data_data_packet(self, packet):
        try:
            stream_id = self._normalize_stream_id(packet)
            flt = (
                f"http2.data.data and http2.streamid=={stream_id} "
                f"and ip.src=={packet.ip.dst} and ip.dst=={packet.ip.src} and json"
            )
            cap = self._capture(flt)
            out = cap
            cap.close()
            return out
        except Exception as e:
            logger.error("all_data_data_packet: %s", e)

    def header_packet(self, filter_str):
        cap = self._capture(filter_str)
        try:
            if cap[0]:
                return cap
        except Exception:
            pass
        logger.warning("header_packet: no packet matched display filter")
        try:
            cap.close()
        except Exception:
            pass
        return None

    def data_packet_json(self, packet):
        try:
            stream_id = self._normalize_stream_id(packet)
            flt = (
                f"http2.data.data and http2.streamid=={stream_id} "
                f"and ip.src=={packet.ip.dst} and ip.dst=={packet.ip.src} and json"
            )
            cap = self._capture(flt)
            try:
                pkt = cap[0]
                data = pkt.http2.data_data.raw_value
                text_value = bytes.fromhex(data).decode("utf-8")
                return json.loads(text_value)
            finally:
                cap.close()
        except Exception as e:
            logger.error("data_packet_json: %s", e)

    def get_value_from_json(self, input_json, target_key):
        if isinstance(input_json, list):
            nested = [self.recursively_parse_json(x, target_key) for x in input_json]
            flat = [x for sub in nested for x in sub]
        else:
            flat = self.recursively_parse_json(input_json, target_key)
        return [str(x).lower().strip() for x in flat]

    def recursively_parse_json(self, search_dict, field):
        field_l = field.lower()
        fields_found = []
        for key, value in search_dict.items():
            if key.lower() == field_l:
                fields_found.append(value)
            elif isinstance(value, dict):
                fields_found.extend(self.recursively_parse_json(value, field))
            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        fields_found.extend(self.recursively_parse_json(item, field))
        return fields_found

    def valid_data(self, text_value):
        stack = []
        for i, ch in enumerate(text_value):
            if len(stack) == 0 and ch != "\n":
                stack.append(ch)
            elif ch in "{[(":
                stack.append(ch)
            elif len(stack) and (
                (ch == "}" and stack[-1] == "{")
                or (ch == "]" and stack[-1] == "[")
                or (ch == ")" and stack[-1] == "(")
            ):
                stack.pop()
            if len(stack) == 0:
                return text_value[0 : i + 1]
        return text_value

    def get_json_data(self, packet):
        if "mime_multipart_part" in packet.http2.field_names:
            data = packet.http2.mime_multipart_part.raw_value
            text_value = bytes.fromhex(data).decode("utf-8")
            text_value = "{" + text_value.split("{", 1)[1]
            return json.loads(text_value)
        data = packet.http2.data_data.raw_value
        try:
            text_value = bytes.fromhex(data).decode("utf-8")
        except Exception:
            text_value = str(bytes.fromhex(data))
            text_value = text_value.split("{", 1)
            text_value = text_value[1] if len(text_value) > 1 else text_value[0]
            text_value = "{" + text_value.rsplit("}", 1)[0] + "}"
        text_value = self.valid_data(text_value)
        return json.loads(text_value)

    def split_json_val(self, json_string):
        validation_dic = {}
        count = 1
        for part in json_string.split(","):
            if ":" not in part:
                continue
            k, v = part.split(":", 1)
            k, v = k.strip(), v.strip()
            if k in validation_dic:
                k = f"{k}_temp{count}"
                count += 1
            validation_dic[k] = v
        return validation_dic

    def second_validation(self, filter_str, second_vali_dic, request_response):
        new_filter = ""
        cap = self._capture(filter_str)
        p = cap
        cap.close()
        flag = True
        for pkt in p:
            if not flag:
                break
            if request_response == "request":
                packets = self.all_header_data_packet(pkt)
            else:
                packets = self.all_data_data_packet(pkt)
            for single in packets:
                second_val_data = self.get_json_data(single)
                matched = 0
                for key, value in second_vali_dic.items():
                    dta = self.get_value_from_json(second_val_data, key)
                    if value.lower() in dta:
                        matched += 1
                    else:
                        break
                if matched == len(second_vali_dic):
                    new_filter = f"frame.number=={single.frame_info.number}"
                    flag = False
                    break
        if not new_filter:
            logger.warning("second_validation: no matching JSON for second validation")
            return None
        return self.header_packet(new_filter)

    def remove_duplicate(self, report_result):
        report_result.sort(key=lambda x: x[3], reverse=True)
        output = []
        visited = set()
        for row in report_result:
            a, b, c, d, e, f = row
            if (b, c) not in visited:
                visited.add((b, c))
                output.append(row)
        return output

    def format_result(self, results):
        records_di = {}
        for header, expected, observed, vali in results:
            records_di.setdefault(header, []).append((expected, observed, vali))
        return records_di

    def split_di_keys(self, key):
        if "_temp" in key:
            return key.split("_")[0]
        return key

    def _run_pfcp_case(self, header):
        hsc = header.get("HEADER_STRING_SHOULD_CONTAIN") or []
        if hsc and hsc[0].lower() == "session establishment":
            session_ep = self._pfcp.get_session_endpoint_id(header["HEADER_DATA_VALIDATION"])
            if session_ep:
                self._session_endpoint_id, packet_no = session_ep
                return (
                    [
                        (
                            header["CALL_LEGS"],
                            hsc[0],
                            "Searching session endpoint ID",
                            "Found session endpoint ID",
                            "TRUE",
                            packet_no,
                        )
                    ],
                    ["True"],
                )
            logger.warning("PFCP session establishment: no session endpoint ID in capture")
            return (
                [
                    (
                        header["CALL_LEGS"],
                        hsc[0],
                        "Searching session endpoint ID",
                        "Session endpoint ID not found",
                        "FALSE",
                        "N/A",
                    )
                ],
                ["False"],
            )
        return self._pfcp.pfcp_parser_check(header, self._session_endpoint_id)

    def wireshark_parser(self, headers):
        one_pf = []
        one_result = []
        self._session_endpoint_id = ""
        for i, case in enumerate(headers):
            raw_proto = case["PROTOCOL"]
            if self._strict_protocol_validation:
                validate_validation_protocol(raw_proto)
            proto = normalize_dispatch_protocol(raw_proto)

            if proto == "http2":
                report_result, res = self.analyze_and_return_json(case, i + 1)
            elif proto == "ws-filter":
                logger.debug("ws-filter case: %s", case)
                report_result, res = self._gtpv2.gtpv2_parser_check(case)
            elif proto == "diameter":
                report_result, res = self._diameter.diameter_parser_check(case)
            elif proto in ("lcsap", "lcsap/lpp", "lcsap/lpp/lppe"):
                report_result, res = self._lcsap.lcsap_parser_check(case)
            elif proto == "ngap":
                report_result, res = self._ngap.ngap_parser_check(case)
            elif proto == "dns":
                report_result, res = self._dns.dns_parser_check(case)
            elif proto in ("s1ap", "s1ap/nas-eps"):
                report_result, res = self._s1ap.s1ap_parser_check(case)
            elif proto == "pfcp":
                report_result, res = self._run_pfcp_case(case)
            elif proto in PROTOCOLS_GENERIC_DISPLAY_FILTER:
                report_result, res = self._generic_filter.filter_check(case)
            else:
                call_legs = case.get("CALL_LEGS") or ""
                report_result = [
                    (
                        call_legs,
                        str(raw_proto),
                        "Analyzer available",
                        "No analyzer implemented for this PROTOCOL (reserved in VALIDATION_PROTOCOLS)",
                        "FALSE",
                        "N/A",
                    )
                ]
                res = ["False"]
            one_result.extend(report_result)
            one_pf.extend(res)

        final_result = [one_result]
        if "False" not in one_pf and len(one_pf) >= 1:
            final_result.append("PASS")
        else:
            final_result.append("FAIL")
        return final_result

    def _append_validation_rows(
        self,
        validation_map,
        input_data,
        call_legs,
        full_header,
        header_pkt,
        result,
        report_result,
    ):
        frame_no = str(header_pkt.frame_info.number)
        for raw_k, raw_v in validation_map.items():
            k = self.split_di_keys(raw_k).strip().lower()
            v = raw_v.strip().lower()
            res = (call_legs, full_header)
            try:
                for hdr in input_data:
                    if isinstance(hdr, str) and "pccrule" in hdr.lower():
                        logger.debug("pccrule context input_data=%s", input_data)
                        break
            except TypeError:
                pass
            values = self.get_value_from_json(input_data, k)
            if v:
                expected_output = f"{k} : {v}"
                observed_output = f"{k} : {values}"
                res += (expected_output, observed_output)
                matched = any(v in val for val in values)
                if matched:
                    result.append("True")
                    res += ("TRUE", frame_no)
                else:
                    result.append("False")
                    res += ("FALSE", frame_no)
            else:
                res += (f"KEY :{k}", str(values), "TRUE", frame_no)
            report_result.append(res)

    def analyze_and_return_json(self, headers, testcase):
        result = []
        report_result = []
        res = ()
        count_tf = {}
        report_result_list = []
        result_list = []
        full_header = "".join("/" + x for x in headers["HEADER_STRING_SHOULD_CONTAIN"])
        full_header += "/" + str(headers["HEADER_JSON_SHOULD_CONTAIN"])
        if not headers.get("CALL_LEGS"):
            headers["CALL_LEGS"] = ""
        fil = self.create_header_filter(headers["HEADER_STRING_SHOULD_CONTAIN"])
        logger.info("HTTP/2 header display filter: %s", fil)
        if headers["HEADER_DATA_VALIDATION"]:
            request_response = "request"
        else:
            request_response = "response"

        if headers["HEADER_JSON_SHOULD_CONTAIN"]:
            second_validation_dict = self.split_json_val(headers["HEADER_JSON_SHOULD_CONTAIN"])
            find_header_packet = self.second_validation(fil, second_validation_dict, request_response)
        else:
            find_header_packet = self.header_packet(fil)
        if find_header_packet is None:
            res += (headers["CALL_LEGS"], full_header, "Header Packet Should Exist", "no such header", "FALSE", "N/A")
            report_result.append(res)
            result.append("False")
            return report_result, result

        expected = None
        for header_pkt in find_header_packet:
            if headers["HEADER_DATA_VALIDATION"]:
                json_validation_header = self.split_json_val(headers["HEADER_DATA_VALIDATION"])
                expected = json_validation_header
                header_data_packet = self.header_data_packet(header_pkt)
                if not header_data_packet:
                    continue
                input_data = self.get_json_data(header_data_packet)
                self._append_validation_rows(
                    json_validation_header,
                    input_data,
                    headers["CALL_LEGS"],
                    full_header,
                    header_pkt,
                    result,
                    report_result,
                )
            elif headers["DATA_DATA_VALIDATION"]:
                json_validation_data = self.split_json_val(headers["DATA_DATA_VALIDATION"])
                expected = json_validation_data
                data_packet = self.data_packet(header_pkt)
                if not data_packet:
                    continue
                input_data = self.get_json_data(data_packet)
                self._append_validation_rows(
                    json_validation_data,
                    input_data,
                    headers["CALL_LEGS"],
                    full_header,
                    header_pkt,
                    result,
                    report_result,
                )
            elif (headers["DATA_DATA_VALIDATION"] in (None, "", {})) and (
                headers["HEADER_DATA_VALIDATION"] in (None, "", {})
            ):
                expected_output = "Header Packet Should Exist"
                res = (headers["CALL_LEGS"], full_header)
                try:
                    if header_pkt:
                        res += (expected_output, "Header Exists", "TRUE", str(header_pkt.frame_info.number))
                        result.append("True")
                except Exception:
                    res += (expected_output, "no such header", "FALSE", str(header_pkt.frame_info.number))
                    result.append("False")
                report_result.append(res)
            res = ()
            report_result, count_tf, report_result_list, result, result_list = self.check_ies(
                report_result, count_tf, report_result_list, result, result_list
            )
        if len(report_result_list) == 0:
            expected_output = ""
            if expected:
                for k, v in expected.items():
                    expected_output = f"{k} : {v}"
                    break
            report_result = [
                (headers["CALL_LEGS"], full_header, expected_output, "Packet Not Found", "FALSE", "N/A")
            ]
            return report_result, ["False"]
        return self.create_report_result(report_result_list, count_tf, result_list)

    def create_report_result(self, report_result_list, count_tf, result_list):
        max_count = 0
        index = 0
        for k, v in count_tf.items():
            if v > max_count:
                max_count = v
                index = k
        if max_count == 0:
            return report_result_list[0], result_list[0]
        return report_result_list[index], result_list[index]

    def check_ies(self, report_result, count_tf, report_result_list, result, result_list):
        count = 0
        for row in report_result:
            if len(row) >= 5 and row[4] == "TRUE":
                count += 1
        result_list.append(result)
        report_result_list.append(report_result)
        count_tf[len(report_result_list) - 1] = count
        return [], count_tf, report_result_list, [], []

    def get_header_ip_src(self, packet):
        return packet.ip.src

    def get_header_ip_dst(self, packet):
        return packet.ip.dst

    def get_stream_id(self, packet):
        return packet.http2.streamid

    def get_length(self, packet):
        return packet.http2.length

    def get_flags(self, packet):
        return packet.http2.flags

    def get_flag_end_stream(self, packet):
        return packet.http2.flags_end_stream

    def get_header_length(self, packet):
        return packet.http2.header_length

    def get_header_name(self, packet):
        return packet.http2.headers_path

    def get_header_count(self, packet):
        return packet.http2.header_count

    def get_multipart_type(self, packet):
        return packet.http2.mime_multipart_type

    def get_multipart_first_boundary(self, packet):
        return packet.http2.mime_multipart_first_boundary

    def get_mime_multipart_part(self, packet):
        return packet.http2.mime_multipart_part

    def get_mime_multipart_header_content_type(self, packet):
        return packet.http2.mime_multipart_header_content_type

    def get_mime_multipart_boundary(self, packet):
        return packet.http2.mime_multipart_boundary

    def get_mime_multipart_header_content_id(self, packet):
        return packet.http2.mime_multipart_header_content_id

    def get_mime_multipart_last_boundary(self, packet):
        return packet.http2.mime_multipart_last_boundary
