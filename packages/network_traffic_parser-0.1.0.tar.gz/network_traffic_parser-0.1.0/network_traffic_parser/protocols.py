"""
Protocol identifiers for test-case validation (YAML ``PROTOCOL`` field) and
Wireshark dissector names allowed in user ``decode_as`` maps.

**Adding a new protocol**

1. Put the label in ``VALIDATION_PROTOCOLS`` (and optionally
   ``DECODE_AS_TARGET_PROTOCOLS`` for strict decode-as checks).
2. If it is an alias of an existing handler, add it to
   ``_PROTOCOL_DISPATCH_ALIASES``.
3. If it only needs “some packet matches this display filter”, add it to
   ``PROTOCOLS_GENERIC_DISPLAY_FILTER`` (or reuse an entry that already maps
   there via aliases).
4. For custom logic, add ``network_traffic_parser/parsers/your_proto.py`` with a
   ``*_parser_check(header) -> (report_result, result)`` method, instantiate it
   in ``TelecomPcapAnalyzer.__init__``, and branch in ``wireshark_parser``.
"""

from __future__ import annotations

import re
from typing import Dict, Mapping, Optional

from .decode_defaults import DEFAULT_DECODE_AS_MAP

# Values allowed in the ``PROTOCOL`` field of each test case (case-insensitive match).
VALIDATION_PROTOCOLS: tuple[str, ...] = (
    "http2",
    "http",
    "https",
    "grpc",
    "quic",
    "tls",
    "ws-filter",
    "gtpv2",
    "gtp-c",
    "gtp-u",
    "gtp",
    "diameter",
    "diameter-sctp",
    "pfcp",
    "ngap",
    "s1ap",
    "s1ap/nas-eps",
    "lcsap",
    "lcsap/lpp",
    "lcsap/lpp/lppe",
    "dns",
    "sip",
    "radius",
    "nas-eps",
    "ngap-nas-5gs",
)

_VALIDATION_SET = {p.lower() for p in VALIDATION_PROTOCOLS}

# Typical Wireshark dissector short names for decode_as *values* (extend as needed).
DECODE_AS_TARGET_PROTOCOLS: frozenset[str] = frozenset(
    {
        "http",
        "http2",
        "tls",
        "ssl",
        "diameter",
        "dns",
        "pfcp",
        "gtp",
        "gtpv2",
        "gtpv1",
        "gtpv0",
        "ngap",
        "s1ap",
        "lcsap",
        "sip",
        "radius",
        "nas-eps",
        "json",
        "data-text-lines",
        "quic",
    }
)

_DECODE_KEY_PATTERN = re.compile(
    r"^(tcp|udp|sctp)\.port==[0-9]+$", re.IGNORECASE
)

# Map validation labels to internal dispatch keys used by the analyzer.
_PROTOCOL_DISPATCH_ALIASES: dict[str, str] = {
    "gtpv2": "ws-filter",
    "gtp-c": "ws-filter",
    "gtp": "ws-filter",
    "diameter-sctp": "diameter",
    "https": "http",
    "nas-eps": "s1ap",
    "ngap-nas-5gs": "ngap",
}

# After ``normalize_dispatch_protocol``, these use :class:`GenericFilterParser`
# (display-filter presence only). Add a dedicated parser class and branch in
# ``TelecomPcapAnalyzer.wireshark_parser`` when you need protocol-specific logic.
PROTOCOLS_GENERIC_DISPLAY_FILTER: frozenset[str] = frozenset(
    {
        "http",
        "grpc",
        "quic",
        "tls",
        "gtp-u",
        "sip",
        "radius",
    }
)


class ProtocolValidationError(ValueError):
    """Raised when ``PROTOCOL`` or ``decode_as`` entries are not allowed."""


def validate_validation_protocol(protocol: str) -> str:
    """Return normalized lowercase protocol or raise if not in ``VALIDATION_PROTOCOLS``."""
    if protocol is None or str(protocol).strip() == "":
        raise ProtocolValidationError("PROTOCOL must be a non-empty string")
    key = str(protocol).strip().lower()
    if key not in _VALIDATION_SET:
        raise ProtocolValidationError(
            f"Unknown PROTOCOL {protocol!r}. "
            f"Use one of: {', '.join(sorted(_VALIDATION_SET))}"
        )
    return key


def normalize_dispatch_protocol(protocol: str) -> str:
    """Map YAML protocol to the branch key used in ``wireshark_parser``."""
    key = str(protocol).strip().lower()
    return _PROTOCOL_DISPATCH_ALIASES.get(key, key)


def validate_decode_as_key(selector: str) -> str:
    s = str(selector).strip()
    if not _DECODE_KEY_PATTERN.match(s):
        raise ProtocolValidationError(
            f"decode_as key must look like 'tcp.port==443' or 'udp.port==8805', got {selector!r}"
        )
    return s


def validate_decode_as_target(dissector: str) -> str:
    d = str(dissector).strip()
    if d not in DECODE_AS_TARGET_PROTOCOLS:
        raise ProtocolValidationError(
            f"decode_as target {dissector!r} is not in DECODE_AS_TARGET_PROTOCOLS; "
            "extend network_traffic_parser.protocols if Wireshark uses this dissector name."
        )
    return d


def merge_decode_as(
    user_decode_as: Optional[Mapping[str, str]] = None,
    *,
    validate_keys: bool = True,
    validate_targets: bool = False,
) -> Dict[str, str]:
    """
    Merge user overrides onto :data:`DEFAULT_DECODE_AS_MAP`.

    Keys are Wireshark decode selectors (``tcp.port==8080``); values are dissector names.
    User entries replace defaults for the same key. Set ``validate_targets=True`` to
    restrict values to :data:`DECODE_AS_TARGET_PROTOCOLS`.
    """
    merged: Dict[str, str] = dict(DEFAULT_DECODE_AS_MAP)
    if not user_decode_as:
        return merged
    for raw_k, raw_v in user_decode_as.items():
        k = validate_decode_as_key(raw_k) if validate_keys else str(raw_k).strip()
        v = (
            validate_decode_as_target(raw_v)
            if validate_targets
            else str(raw_v).strip()
        )
        merged[k] = v
    return merged


def list_validation_protocols() -> tuple[str, ...]:
    """Return the canonical tuple of allowed ``PROTOCOL`` values (sorted)."""
    return tuple(sorted(VALIDATION_PROTOCOLS, key=str.lower))
