"""
Command-line interface for network_traffic_parser.

Installed as console script ``network_traffic_parser``; also runnable via
``python -m network_traffic_parser``.
"""

from __future__ import annotations

import argparse
import logging
from typing import Sequence

import yaml

from .analyzer import TelecomPcapAnalyzer

logger = logging.getLogger(__name__)


def main(argv: Sequence[str] | None = None) -> int:
    """Parse PCAP + YAML test definitions and print validation results. Returns process exit code."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s %(name)s: %(message)s",
    )
    parser = argparse.ArgumentParser(
        description="Run PCAP protocol validation from a YAML test case definition.",
        prog="network_traffic_parser",
    )
    parser.add_argument(
        "-f",
        "--file",
        help="Paths: pcap, yaml, and testcase name (same order as before)",
        nargs="+",
        required=True,
    )
    args = parser.parse_args(list(argv) if argv is not None else None)

    contains_keyword = True
    pcp = yml = testcase = None
    for argument in args.file:
        logger.info("CLI argument: %s", argument)
        if "AMF20" in argument:
            contains_keyword = True
        if ".pcap" in argument:
            pcp = argument
            logger.info("pcap file: %s", pcp)
        elif ".yaml" in argument:
            yml = argument
            logger.info("yaml file: %s", yml)
        else:
            testcase = argument.upper()

    if not yml or testcase is None or not pcp:
        logger.error("Provide a .pcap path, a .yaml path, and a testcase name via -f/--file.")
        return 1

    logger.info("yaml path: %s", yml)
    di: dict = {}
    headers = None
    try:
        with open(yml, "r", encoding="utf-8") as stream:
            di = yaml.safe_load(stream) or {}
        headers = di["Test_Cases"][testcase]
        logger.info("test case headers: %s", headers)
    except yaml.YAMLError as exc:
        logger.error("YAML error: %s", exc)
        return 1
    except KeyError as exc:
        logger.error("Missing key: %s", exc)
        return 1

    decode_from_yaml = None
    if isinstance(di, dict):
        decode_from_yaml = di.get("decode_as") or di.get("Decode_Port")

    pcap_parser = TelecomPcapAnalyzer(
        pcp,
        decode_as=decode_from_yaml,
        path_contains_match=contains_keyword,
    )
    header_filter = pcap_parser.wireshark_parser(headers)
    logger.info("wireshark_parser result: %s", header_filter)
    return 0


def run() -> None:
    """Entry point for setuptools console_scripts (raises SystemExit)."""
    raise SystemExit(main())


if __name__ == "__main__":
    run()
