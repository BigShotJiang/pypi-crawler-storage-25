"""Allow ``python -m network_traffic_parser``."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
