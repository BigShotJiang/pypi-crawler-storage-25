"""The `theme` operation."""

from typing import Annotated, Literal

from pydantic import BeforeValidator, Field, field_validator

from gitsvg.file_format.ops.framework._base import OpBase
from gitsvg.file_format.ops.framework._types import (
    HexColor,
    IdStr,
    NonEmptyStr,
    NonNegativeFloat,
)
from gitsvg.theme import BoxAnchor, Orientation, normalize_orientation
from gitsvg.theme._box_anchor import validate_box_anchor

Opacity = Annotated[float, Field(ge=0, le=1)]
"""Float in `[0, 1]` — for opacity fields where SVG semantics are bounded."""

OrientationInput = Annotated[Orientation, BeforeValidator(normalize_orientation)]
"""Annotated orientation type that normalises permissive input forms (case-insensitive, `-`/`_` interchangeable, Mermaid `TD`, CSS `ltr`/`rtl`, vernacular `top_down`/`bottom_up`) to the canonical short code before the `Literal` validator runs."""


class ThemeOp(OpBase):
    """Apply a theme patch to the diagram's accumulated theme overrides.

    Each `theme:` op contributes to a per-diagram accumulator that
    resolves to the final `Theme` at end-of-apply. Three field roles:

    - **`name`** selects the theme class the final resolution
      dispatches to. Last write wins across the apply pass — the most
      recent `name` set anywhere in the op stream picks the class.
    - **`keep_prior_overrides`** modifies the effect of `name` in the
      same op. By default (`false`) a `name` change wipes every
      previously-accumulated override (both `theme:` field overrides
      and state-derived per-branch `branch:` colour overrides) before
      this op's own explicit fields apply. Setting it to `true`
      preserves prior overrides so a chosen theme can be layered onto
      existing tweaks. The flag is only meaningful when `name` is also
      set in the same op; explicit values without `name` are rejected
      (E220) and the implicit default has no effect there.
    - **Every other field** is an explicit theme-field override; later
      writes to the same field win.

    A mixed op (`name` plus explicit fields) applies in two steps: the
    `name` switch runs first (with its conditional wipe), then the
    explicit fields override on top — so an op's own fields are never
    discarded by its own reset. An op with neither a `name`, an
    explicit field, nor a `keep_prior_overrides` value is rejected
    (E217).
    """

    op: Literal["theme"]
    name: IdStr | None = Field(
        default=None,
        description="Optional named theme; switches the resolution target. By default wipes every accumulated override before this op's own fields apply (see `keep_prior_overrides` to preserve them).",
    )
    keep_prior_overrides: bool = Field(
        default=False,
        description="When set on an op that also sets `name`, controls whether previously-accumulated overrides survive the theme switch: `false` (default) wipes both prior `theme:` field overrides and state-derived per-branch `branch:` colour overrides; `true` preserves them so this theme layers on top. Only meaningful alongside `name` — explicit values on an op without `name` are rejected (E220).",
    )

    # --- Orientation ------------------------------------
    orientation: OrientationInput | None = Field(
        default=None,
        description=(
            "Diagram orientation. Canonical short codes: `bt` (bottom-to-top, default), "
            "`tb` (top-to-bottom), `lr` (left-to-right), `rl` (right-to-left). "
            "Aliases accepted (case-insensitive, `-`/`_` interchangeable): Mermaid's `TD` (≡ `tb`), "
            "CSS-style `ltr` (≡ `lr`) and `rtl` (≡ `rl`), the four explicit `<dir>_to_<dir>` "
            "long forms (e.g. `bottom_to_top`), and the vernacular `top_down` / `bottom_up`."
        ),
    )

    # --- Spacing (px) -----------------------------------
    branch_spacing: NonNegativeFloat | None = Field(
        default=None,
        description="Pixel distance between adjacent branch-axis slots.",
    )
    commit_spacing: NonNegativeFloat | None = Field(
        default=None,
        description="Pixel distance between adjacent commit-axis slots.",
    )
    margin_left: NonNegativeFloat | None = Field(
        default=None,
        description="Pixel margin at the visually-left edge of the canvas. `null` resolves to the per-orientation default (see format spec).",
    )
    margin_right: NonNegativeFloat | None = Field(
        default=None,
        description="Pixel margin at the visually-right edge of the canvas. `null` resolves to the per-orientation default.",
    )
    margin_top: NonNegativeFloat | None = Field(
        default=None,
        description="Pixel margin at the visually-top edge of the canvas. `null` resolves to the per-orientation default.",
    )
    margin_bottom: NonNegativeFloat | None = Field(
        default=None,
        description="Pixel margin at the visually-bottom edge of the canvas. `null` resolves to the per-orientation default.",
    )

    # --- Strokes & geometry (px) ------------------------
    branch_line_width: NonNegativeFloat | None = Field(
        default=None,
        description="Stroke width of branch lines and arcs.",
    )
    commit_radius: NonNegativeFloat | None = Field(
        default=None,
        description="Radius of a commit dot.",
    )
    commit_stroke_width: NonNegativeFloat | None = Field(
        default=None,
        description="Stroke width of the white outline around a commit dot.",
    )
    highlight_radius: NonNegativeFloat | None = Field(
        default=None,
        description="Radius of a highlighted commit dot.",
    )
    arc_corner_radius_in_grid_units: NonNegativeFloat | None = Field(
        default=None,
        description="Corner radius for branch-off and merge arcs, expressed as a multiple of `min(branch_spacing, commit_spacing)`. Per-arc clamped at render time to fit the arc's segment lengths, so values larger than 1.0 produce no further effect.",
    )
    label_offset_branch_axis_in_lanes: NonNegativeFloat | None = Field(
        default=None,
        description="Offset between a commit dot and the start of its label along the branch axis, expressed as a multiple of `branch_spacing`.",
    )
    branch_guide_width: NonNegativeFloat | None = Field(
        default=None,
        description="Stroke width of the faint per-lane vertical guides.",
    )
    branch_guide_dash: NonEmptyStr | None = Field(
        default=None,
        description='SVG stroke-dasharray for the branch guides (e.g. `"4,4"`).',
    )
    guide_overshoot_in_rows: NonNegativeFloat | None = Field(
        default=None,
        description="How far each branch guide extends past the commit-axis margin edges, expressed as a multiple of `commit_spacing` (applied symmetrically at both ends).",
    )

    # --- Typography -------------------------------------
    label_font_family: NonEmptyStr | None = Field(
        default=None,
        description="Full CSS font-family chain used for all text elements.",
    )
    label_font_family_small: NonEmptyStr | None = Field(
        default=None,
        description="Compact font-family chain emitted under `--small`.",
    )
    label_font_size: NonNegativeFloat | None = Field(
        default=None,
        description="Font size for commit-message labels.",
    )
    branch_label_font_size: NonNegativeFloat | None = Field(
        default=None,
        description="Font size for branch-name pills and pull-request title pills.",
    )
    hash_font_size: NonNegativeFloat | None = Field(
        default=None,
        description="Font size for the secondary hash line on commit labels.",
    )
    branch_name_pill_offset_commit_axis_in_rows: float | None = Field(
        default=None,
        description="Branch-name pill offset along the commit axis, expressed as a signed multiple of `commit_spacing`. Positive = toward higher commit-axis index. Default is `-0.5` (pill sits below the branch's start row in bottom-to-top orientation).",
    )
    branch_name_pill_offset_branch_axis_in_lanes: float | None = Field(
        default=None,
        description="Branch-name pill offset along the branch axis, expressed as a signed multiple of `branch_spacing`. Positive = toward higher branch-axis index. Default is `0` (pill is centred on the branch lane in bottom-to-top orientation).",
    )
    pill_padding_x_in_font_sizes: NonNegativeFloat | None = Field(
        default=None,
        description="Extra pill width beyond the rendered text, expressed as a multiple of `branch_label_font_size`.",
    )
    pill_padding_y_in_font_sizes: NonNegativeFloat | None = Field(
        default=None,
        description="Extra pill height beyond the font size, expressed as a multiple of `branch_label_font_size`.",
    )
    pill_corner_radius_in_font_sizes: NonNegativeFloat | None = Field(
        default=None,
        description="Pill rounded-corner radius (`rx` / `ry`), expressed as a multiple of `branch_label_font_size`.",
    )
    label_line_padding_in_font_sizes: NonNegativeFloat | None = Field(
        default=None,
        description="Extra height per line in a multi-line commit-label stack, expressed as a multiple of `label_font_size`.",
    )

    # --- Pull-request visuals ---------------------------
    pull_request_dash: NonEmptyStr | None = Field(
        default=None,
        description='SVG stroke-dasharray for pull-request arcs (e.g. `"6,4"`).',
    )
    pull_request_pill_offset_commit_axis_in_rows: float | None = Field(
        default=None,
        description="PR title-pill offset along the commit axis, expressed as a signed multiple of `commit_spacing`. Positive = toward higher commit-axis index. Default is `+0.5` (pill sits above the source-tip commit in bottom-to-top orientation).",
    )
    pull_request_pill_offset_branch_axis_in_lanes: float | None = Field(
        default=None,
        description="PR title-pill offset along the branch axis, expressed as a signed multiple of `branch_spacing`. Positive = toward higher branch-axis index. Default is `0` (pill is centred on the source branch's lane in bottom-to-top orientation).",
    )

    # --- Label angles -----------------------------------
    branch_label_angle: float | None = Field(
        default=None,
        description="Rotation angle (degrees) for the branch-name pill, applied around the pill's world anchor point so the anchor stays pinned regardless of angle. Default is 0° across all orientations; default-current anchor positions are tuned for un-rotated text, so non-zero values render mechanically but visually optimal angle + anchor pairings arrive with named themes in a later version.",
    )
    commit_label_angle: float | None = Field(
        default=None,
        description="Rotation angle (degrees) for the commit-label stack (governs msg + hash + future tag lines together). Default is 0° across all orientations; see `branch_label_angle` for the visual-practicality caveat.",
    )
    pull_request_label_angle: float | None = Field(
        default=None,
        description="Rotation angle (degrees) for the pull-request title pill. Default is 0° across all orientations; see `branch_label_angle` for the visual-practicality caveat.",
    )

    # --- Box anchors ------------------------------------
    branch_pill_anchor: BoxAnchor | None = Field(
        default=None,
        description="Branch-name pill `(u, v)` in `[0, 1]²` — where inside the un-rotated pill rect the world anchor point sits (and equivalently where rotation pivots around). Two-element JSON array. Per-orientation defaults: `bt`/`tb` centre `[0.5, 0.5]`; `lr` right-edge `[1.0, 0.5]`; `rl` left-edge `[0.0, 0.5]`.",
    )
    pull_request_pill_anchor: BoxAnchor | None = Field(
        default=None,
        description="PR-title pill `(u, v)` in `[0, 1]²`. Two-element JSON array. Defaults to centre `[0.5, 0.5]` in every orientation.",
    )
    commit_label_anchor_before: BoxAnchor | None = Field(
        default=None,
        description="Commit-label `(u, v)` for the `before` (lower-index) side. Two-element JSON array. Per-orientation defaults: `bt`/`tb` `[1.0, 0.5]` (stack's right-middle at the world point); `lr`/`rl` `[0.5, 1.0]` (stack's bottom-middle).",
    )
    commit_label_anchor_after: BoxAnchor | None = Field(
        default=None,
        description="Commit-label `(u, v)` for the `after` (higher-index) side. Two-element JSON array. Per-orientation defaults: `bt`/`tb` `[0.0, 0.5]`; `lr`/`rl` `[0.5, 0.0]`.",
    )

    # --- Colours ----------------------------------------
    label_color: HexColor | None = Field(
        default=None,
        description="Fill colour for commit-message labels.",
    )
    hash_color: HexColor | None = Field(
        default=None,
        description="Fill colour for the secondary hash line on commit labels.",
    )
    branch_guide_color: HexColor | None = Field(
        default=None,
        description="Stroke colour for the faint per-lane vertical guides.",
    )
    commit_stroke_color: HexColor | None = Field(
        default=None,
        description="Stroke colour for the outline around commit dots. Visually separates the dot from any branch line passing through it. Default is `white` (reads as a halo on light backgrounds); dark themes typically override this to their background colour so the outline reads as a 'carved out' gap.",
    )
    branch_label_bg_opacity: Opacity | None = Field(
        default=None,
        description="Background opacity (0–1) for branch-name and PR title pills.",
    )
    background_color: HexColor | None = Field(
        default=None,
        description="Optional full-canvas background colour; unset by default (transparent SVG).",
    )
    colors: dict[IdStr, HexColor] | None = Field(
        default=None,
        description="Replacement branch-palette dict; replaces the current palette wholesale when set.",
    )

    @field_validator(
        "branch_pill_anchor",
        "pull_request_pill_anchor",
        "commit_label_anchor_before",
        "commit_label_anchor_after",
    )
    @classmethod
    def _validate_anchor_components(cls, v: BoxAnchor | None) -> BoxAnchor | None:
        """Reject `BoxAnchor` values with a component outside `[0, 1]` at parse time."""
        return validate_box_anchor(v)
