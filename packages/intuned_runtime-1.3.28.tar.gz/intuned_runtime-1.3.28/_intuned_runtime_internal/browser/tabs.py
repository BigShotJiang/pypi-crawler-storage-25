"""
Tab management utilities using CDP HTTP API.

Provides functions to interact with browser tabs via Chrome DevTools Protocol HTTP endpoints.
"""

# refer to https://chromedevtools.github.io/devtools-protocol/ for the endpoints documentation.
# this approach is simpler than using the playwright API because it doesn't require us to create a playwright context.
from typing import Any

from httpx import AsyncClient


async def get_cdp_tabs(cdp_address: str) -> list[dict[str, Any]]:
    """
    Fetch current tabs from CDP /json endpoint.

    Args:
        cdp_address: CDP address (e.g., "http://localhost:9222")

    Returns:
        List of tab info dictionaries from CDP

    Example response:
        [
            {
                "id": "1234",
                "type": "page",
                "title": "Google",
                "url": "https://google.com",
                ...
            }
        ]
    """
    async with AsyncClient(timeout=5) as client:
        response = await client.get(f"{cdp_address}/json")
        response.raise_for_status()
        tabs = response.json()
        # Filter to only page type (exclude background pages, extensions, etc.)
        return [tab for tab in tabs if tab.get("type") == "page"]
