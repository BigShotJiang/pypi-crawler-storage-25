import asyncio
import json
import logging
import os
from contextlib import asynccontextmanager
from typing import Any
from typing import TYPE_CHECKING

import anyio

from _intuned_runtime_internal.browser.extensions import build_extensions_list
from _intuned_runtime_internal.browser.extensions.intuned_extension import is_intuned_extension_enabled
from _intuned_runtime_internal.browser.extensions.intuned_extension import is_intuned_extension_loaded
from _intuned_runtime_internal.browser.extensions.intuned_extension import setup_intuned_extension
from _intuned_runtime_internal.browser.extensions.intuned_extension_server import clean_intuned_extension_server
from _intuned_runtime_internal.browser.extensions.intuned_extension_server import setup_intuned_extension_server
from _intuned_runtime_internal.env import get_user_agent_override

from .helpers import get_local_cdp_address
from .helpers import get_proxy_env
from .helpers import wait_on_cdp_address

logger = logging.getLogger(__name__)


async def get_intuned_browser_executable_path() -> str | None:
    """
    Get the Intuned Browser executable path if stealth mode with intunedBrowser type is enabled.

    Returns:
        The path to the Intuned Browser executable, or None if not applicable.
    """

    try:
        path = os.environ.get("INTUNED_STEALTH_CHROMIUM_PATH")
        if path and os.path.exists(path):
            return path
        return None
    except Exception:
        return None


if TYPE_CHECKING:
    from playwright.async_api import Playwright
    from playwright.async_api import ProxySettings
    from playwright.async_api import ViewportSize


DEFAULT_USER_PREFERENCES = {
    "plugins": {
        "always_open_pdf_externally": True,
    },
    "credentials_enable_service": False,
    "profile": {
        "password_manager_enabled": False,
    },
}


def _merge_preferences(base: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = dict(base)
    for key, override_value in overrides.items():
        base_value = result.get(key)
        if isinstance(base_value, dict) and isinstance(override_value, dict):
            result[key] = _merge_preferences(base_value, override_value)
        else:
            result[key] = override_value
    return result


def get_encrypted_profile_chrome_args(encrypted_profile: bool = False) -> list[str]:
    if encrypted_profile:
        return []
    return ["--password-store=basic"]


async def create_user_dir_with_preferences(profile_template_path: str | None = None):
    # Create a temporary directory
    playwright_temp_dir = anyio.Path(await anyio.mkdtemp(prefix="pw-"))
    user_dir = playwright_temp_dir / "userdir"
    default_dir = user_dir / "Default"
    preferences_path = default_dir / "Preferences"

    if profile_template_path and await anyio.Path(profile_template_path).exists():
        # Copy the user data dir snapshot; mutations during the run stay in user_dir
        # and are discarded when the temp dir is cleaned up.
        import shutil

        await asyncio.to_thread(
            shutil.copytree,
            profile_template_path,
            os.fspath(user_dir),
            symlinks=False,
            dirs_exist_ok=True,
        )

        await default_dir.mkdir(parents=True, exist_ok=True)

        template_preferences: dict[str, Any] = {}
        if await preferences_path.exists():
            try:
                async with await preferences_path.open("r") as f:
                    template_preferences = json.loads(await f.read())
            except Exception as err:
                logger.warning(f"Failed to parse Preferences from profile template at {preferences_path}: {err}")

        merged_preferences = _merge_preferences(template_preferences, DEFAULT_USER_PREFERENCES)
        async with await preferences_path.open("w") as f:
            await f.write(json.dumps(merged_preferences))

        return await user_dir.absolute(), await playwright_temp_dir.absolute()

    await default_dir.mkdir(parents=True, exist_ok=True)
    async with await preferences_path.open("w") as f:
        await f.write(json.dumps(DEFAULT_USER_PREFERENCES))

    return await user_dir.absolute(), await playwright_temp_dir.absolute()


@asynccontextmanager
async def launch_chromium(
    headless: bool = True,
    timeout: int | None = None,
    cdp_port: int | None = None,
    cdp_address: str | None = None,
    cdp_target_id: str | None = None,
    *,
    proxy: "ProxySettings | None" = None,
    viewport: "ViewportSize | None" = None,
    app_mode_initial_url: str | None = None,
    executable_path: os.PathLike[str] | str | None = None,
    ignore_http_errors: bool | None = None,
    profile_template_path: str | None = None,
    encrypted_profile: bool = False,
    **kwargs: Any,
):
    from playwright.async_api import async_playwright
    from playwright.async_api import Browser

    from _intuned_runtime_internal.browser.helpers import get_ignore_http_errors_from_config

    if ignore_http_errors is None:
        ignore_http_errors = get_ignore_http_errors_from_config()

    encrypted_profile_args = get_encrypted_profile_chrome_args(encrypted_profile)
    extra_args: list[str] = ["--disable-notifications", *encrypted_profile_args]

    # Add stealth mode flag if using Intuned Browser
    from _intuned_runtime_internal.run.intuned_settings import load_intuned_settings

    settings = None
    try:
        settings = await load_intuned_settings()
        if settings.stealth_mode.enabled:
            extra_args.append("--stealth-mode")
    except Exception:
        pass

    async with async_playwright() as playwright:
        if cdp_address is not None:
            if await is_intuned_extension_enabled():
                await setup_intuned_extension_server()
            browser: Browser = await playwright.chromium.connect_over_cdp(cdp_address)
            context = browser.contexts[0]
            user_preferences_dir = None
            dir_to_clean = None
        else:
            (
                user_preferences_dir,
                dir_to_clean,
            ) = await create_user_dir_with_preferences(profile_template_path)
            proxy = proxy or get_proxy_env()
            # Remove proxy from kwargs if it exists
            browser_size = settings.browser_size if settings else None
            browser_size_width = browser_size.width if browser_size else 1280
            browser_size_height = browser_size.height if browser_size else 800
            extra_args.append(f"--window-size={browser_size_width},{browser_size_height}")

            viewport = viewport or {"width": browser_size_width, "height": browser_size_height}

            if cdp_port:
                extra_args.append(f"--remote-debugging-port={cdp_port}")

            if app_mode_initial_url:
                extra_args.append(f"--app={app_mode_initial_url}")

            args_to_ignore = [
                "--disable-extensions",
                "--disable-component-extensions-with-background-pages",
                "--disable-background-networking",
                "--disable-backgrounding-occluded-windows",
                "--disable-background-timer-throttling",
            ]
            if is_intuned_extension_loaded():
                extensions_list = build_extensions_list()
                extensions = ",".join(extensions_list)
                extra_args.append("--disable-extensions-except=" + extensions)
                extra_args.append(f"--load-extension={extensions}")

            if await is_intuned_extension_enabled():
                await setup_intuned_extension()
                if proxy:
                    extra_args.append(
                        '--proxy-bypass-list="<-loopback>"'
                    )  # This is added to bypass proxy for localhost traffic because some proxy providers block localhost traffic, and localhost traffic doesn't need proxying

            if headless:
                args_to_ignore.append("--headless=old")
                extra_args.append("--headless=new")

            if settings and settings.stealth_mode.enabled:
                stealth_executable = await get_intuned_browser_executable_path()
                executable_path = stealth_executable
            elif executable_path is not None:
                executable_path = await anyio.Path(executable_path).resolve()
                if not await executable_path.exists():
                    logger.warning(f"Executable path {executable_path} does not exist. Falling back to default.")
                    executable_path = None
                else:
                    executable_path = str(executable_path)

            user_agent = get_user_agent_override()
            if headless and user_agent is None:
                user_agent = await get_chromium_headless_user_agent(
                    playwright,
                    executable_path=executable_path,
                    extra_args=encrypted_profile_args,
                )

            context = await playwright.chromium.launch_persistent_context(
                os.fspath(user_preferences_dir),
                executable_path=str(executable_path) if executable_path else None,
                headless=headless,
                viewport=viewport,
                proxy=proxy,
                ignore_default_args=args_to_ignore,
                args=extra_args,
                user_agent=user_agent,
                ignore_https_errors=ignore_http_errors,
                **kwargs,
            )

            if cdp_port:
                await wait_on_cdp_address(get_local_cdp_address(cdp_port))

        if timeout is not None:
            context.set_default_timeout(timeout * 1000)

        async def clean_up_after_close(*_: Any, **__: Any) -> None:
            await remove_dir_after_close()
            if await is_intuned_extension_enabled():
                await clean_intuned_extension_server()

        async def remove_dir_after_close(*_: Any, **__: Any) -> None:
            if not dir_to_clean:
                return
            if not await dir_to_clean.exists():
                return

            process = await asyncio.create_subprocess_exec(
                "rm",
                "-rf",
                os.fspath(dir_to_clean),  # Using subprocess to remove the directory
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await process.wait()

        context.once("close", clean_up_after_close)

        page = context.pages[0]  # Default to first page
        if cdp_address is not None and cdp_target_id is not None:
            try:
                for p in context.pages:
                    cdp = None
                    try:
                        cdp = await context.new_cdp_session(p)
                        target_info: dict[str, Any] = await cdp.send("Target.getTargetInfo")  # type: ignore

                        if target_info and target_info.get("targetInfo", {}).get("targetId") == cdp_target_id:
                            page = p  # this is our page.
                            break
                    except Exception:
                        # If we can't get target info for this page, try the next one
                        continue
                    finally:
                        if cdp is not None:
                            await cdp.detach()
            except Exception:
                # If we can't find the target, fall back to first page
                logger.warning(f"Could not find the target {cdp_target_id} in the browser. Falling back to first page.")
                pass

        yield context, page


async def dangerous_launch_chromium(
    headless: bool = True,
    timeout: int | None = None,
    cdp_url: str | None = None,
    port: int | None = None,
    ignore_http_errors: bool = False,
    profile_template_path: str | None = None,
    encrypted_profile: bool = False,
    **kwargs: Any,
):
    from playwright.async_api import async_playwright
    from playwright.async_api import Browser

    temp_dir = await anyio.gettempdir()

    extra_args = [
        "--no-first-run",
        "--disable-sync",
        "--disable-translate",
        "--disable-features=TranslateUI",
        "--disable-features=NetworkService",
        "--lang=en",
        "--disable-blink-features=AutomationControlled",
        "--disable-dev-shm-usage",
        "--disable-notifications",
        *get_encrypted_profile_chrome_args(encrypted_profile),
        f"--disk-cache-dir={temp_dir}/chrome-cache",
    ]

    # Add stealth mode flag if using Intuned Browser
    from _intuned_runtime_internal.run.intuned_settings import load_intuned_settings

    settings = None
    try:
        settings = await load_intuned_settings()
        if settings.stealth_mode.enabled:
            extra_args.append("--stealth-mode")
    except Exception:
        pass

    browser_size = settings.browser_size if settings else None
    browser_size_width = browser_size.width if browser_size else 1280
    browser_size_height = browser_size.height if browser_size else 800

    default_viewport = {"width": browser_size_width, "height": browser_size_height}

    playwright = await async_playwright().start()
    if cdp_url is not None:
        if await is_intuned_extension_enabled():
            await setup_intuned_extension_server()
        logging.info(f"Connecting to cdp: {cdp_url}")
        browser: Browser = await playwright.chromium.connect_over_cdp(cdp_url)
        browser.on("disconnected", lambda _: logging.info("Browser Session disconnected"))
        context = browser.contexts[0]
        user_preferences_dir = None
        dir_to_clean = None
    else:
        logging.info("Launching local browser")
        user_preferences_dir, dir_to_clean = await create_user_dir_with_preferences(profile_template_path)
        logging.info(f"Using user data directory: {user_preferences_dir}")
        if kwargs.get("proxy") is None:
            proxy_env = get_proxy_env()
        else:
            proxy_env = kwargs.get("proxy")
        # Remove proxy from kwargs if it exists
        kwargs.pop("proxy", None)
        viewport = kwargs.get("viewport", default_viewport)
        kwargs.pop("viewport", None)

        extra_args.append(f"--window-size={browser_size_width},{browser_size_height}")

        if headless:
            extra_args.append("--headless=new")

        if port:
            extra_args.append(f"--remote-debugging-port={port}")

        if is_intuned_extension_loaded():
            extensions_list = build_extensions_list()
            extensions = ",".join(extensions_list)
            extra_args.append("--disable-extensions-except=" + extensions)
            extra_args.append(f"--load-extension={extensions}")

        if await is_intuned_extension_enabled():
            await setup_intuned_extension()
            if proxy_env:
                extra_args.append('--proxy-bypass-list="<-loopback>"')

        context = await playwright.chromium.launch_persistent_context(
            os.fspath(user_preferences_dir),
            headless=headless,
            viewport=viewport,
            proxy=proxy_env,
            args=extra_args,
            ignore_https_errors=ignore_http_errors,
            **kwargs,
        )
        if timeout is not None:
            context.set_default_timeout(timeout * 1000)

        async def clean_up_after_close(*_: Any, **__: Any) -> None:
            await remove_dir_after_close()
            if await is_intuned_extension_enabled():
                await clean_intuned_extension_server()

        async def remove_dir_after_close(*_: Any, **__: Any) -> None:
            if not dir_to_clean:
                return
            if not await dir_to_clean.exists():
                return

            process = await asyncio.create_subprocess_exec(
                "rm",
                "-rf",
                os.fspath(dir_to_clean),  # Using subprocess to remove the directory
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await process.wait()

        context.once("close", clean_up_after_close)
    return playwright, context


async def launch_detached_chromium(
    port: int,
    headless: bool = False,
    user_data_dir: str | None = None,
) -> tuple[int, str]:
    """
    Launch Chromium as a detached subprocess that persists after the Python process exits.

    Args:
        port: The CDP port to use for remote debugging.
        headless: Whether to run in headless mode.
        user_data_dir: Optional user data directory. If not provided, a temporary one is created.

    Returns:
        A tuple of (pid, user_data_dir) for the launched browser process.
    """
    import subprocess

    from _intuned_runtime_internal.run.intuned_settings import load_intuned_settings

    chromium_executable = await get_chromium_executable_path()

    settings = None
    try:
        settings = await load_intuned_settings()
    except Exception:
        pass

    browser_size_width = settings.browser_size.width if settings else 1280
    browser_size_height = settings.browser_size.height if settings else 800

    # Create user data directory if not provided
    if user_data_dir is None:
        temp_dir = await anyio.Path(await anyio.gettempdir()).absolute()
        user_data_dir = str(temp_dir / f"intuned-browser-{port}")
        await anyio.Path(user_data_dir).mkdir(parents=True, exist_ok=True)

    # Build command line arguments
    args = [
        chromium_executable,
        # TODO: we need to use nsjail if available to spinup a sandboxed browser process
        "--no-sandbox",
        f"--remote-debugging-port={port}",
        f"--user-data-dir={user_data_dir}",
        "--no-first-run",
        "--disable-sync",
        "--disable-translate",
        "--disable-features=TranslateUI",
        "--disable-blink-features=AutomationControlled",
        "--disable-dev-shm-usage",
        "--disable-notifications",
        "--lang=en",
        f"--window-size={browser_size_width},{browser_size_height}",
    ]

    if headless:
        args.append("--headless=new")

    # Launch as detached subprocess
    # Using start_new_session=True on Unix to create a new process group
    # This ensures the browser survives after the parent Python process exits
    process = subprocess.Popen(
        args,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        start_new_session=True,  # Detach from parent process group
    )

    # Wait for CDP to be available
    cdp_address = get_local_cdp_address(port)
    await wait_on_cdp_address(cdp_address)

    return process.pid, user_data_dir


async def get_chromium_executable_path() -> str:
    """
    Find the Chromium executable path using Playwright.

    Returns:
        The path to the Chromium executable.

    Raises:
        RuntimeError: If Chromium executable cannot be found.
    """
    from playwright.async_api import async_playwright

    async with async_playwright() as playwright:
        executable_path = playwright.chromium.executable_path
        if not executable_path or not os.path.exists(executable_path):
            raise RuntimeError(
                "Could not find Chromium executable. Please ensure Playwright browsers are installed: "
                "npx playwright install chromium"
            )
        return executable_path


async def get_chromium_headless_user_agent(
    playwright: "Playwright",
    executable_path: str | None = None,
    ignore_default_args: list[str] | None = None,
    extra_args: list[str] | None = None,
    **kwargs: Any,
):
    kwargs = kwargs or {}
    browser = await playwright.chromium.launch(
        executable_path=str(executable_path) if executable_path else None,
        headless=True,
        ignore_default_args=ignore_default_args,
        args=extra_args,
        **kwargs,
    )
    try:
        ctx = await browser.new_context()
        page = await ctx.new_page()
        user_agent = await page.evaluate("() => navigator.userAgent")
        if user_agent is None or type(user_agent) is not str:
            return None

        user_agent = user_agent.replace("HeadlessChrome", "Chrome")
        return user_agent
    finally:
        await browser.close()
