import asyncio
import shutil
from contextlib import AbstractAsyncContextManager
from contextlib import asynccontextmanager
from typing import overload
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from playwright.async_api import BrowserContext
    from playwright.async_api import Page
    from playwright.async_api import ProxySettings

from _intuned_runtime_internal.env import get_browser_type

from .launch_chromium import launch_chromium


@overload
def launch_browser(
    *,
    cdp_address: str,
    cdp_target_id: str | None = None,
    ignore_http_errors: bool | None = None,
    profile_template_path: str | None = None,
    encrypted_profile: bool = False,
) -> "AbstractAsyncContextManager[tuple['BrowserContext', 'Page']]": ...


@overload
def launch_browser(
    proxy: "ProxySettings | None" = None,
    headless: bool = False,
    *,
    cdp_port: int | None = None,
    cdp_target_id: str | None = None,
    ignore_http_errors: bool | None = None,
    profile_template_path: str | None = None,
    encrypted_profile: bool = False,
) -> "AbstractAsyncContextManager[tuple['BrowserContext', 'Page']]": ...


@asynccontextmanager
async def launch_browser(
    proxy: "ProxySettings | None" = None,
    headless: bool = False,
    *,
    cdp_port: int | None = None,
    cdp_address: str | None = None,
    cdp_target_id: str | None = None,
    ignore_http_errors: bool | None = None,
    profile_template_path: str | None = None,
    encrypted_profile: bool = False,
):
    browser_type = get_browser_type()
    async with launch_chromium(
        headless=headless,
        cdp_address=cdp_address,
        cdp_port=cdp_port,
        proxy=proxy,
        executable_path=await get_browser_executable_path(browser_type) if browser_type else None,
        cdp_target_id=cdp_target_id,
        ignore_http_errors=ignore_http_errors,
        profile_template_path=profile_template_path,
        encrypted_profile=encrypted_profile,
    ) as (context, page):
        try:
            yield context, page
        finally:
            from _intuned_runtime_internal.browser.extensions.intuned_extension import is_intuned_extension_enabled
            from _intuned_runtime_internal.helpers.extensions import pause_captcha_solver

            if await is_intuned_extension_enabled():
                await pause_captcha_solver(context=context)

            await context.close()


async def get_browser_executable_path(browser_type: str) -> str | None:
    if browser_type == "brave":
        brave_path = await asyncio.to_thread(shutil.which, "brave-browser-stable")
        if brave_path is None:
            raise RuntimeError("Brave browser not found")
        return brave_path
    if browser_type in {"", "chromium"}:
        return None
    raise RuntimeError(f'Browser "{browser_type}" is not supported. Use "chromium" or "brave".')
