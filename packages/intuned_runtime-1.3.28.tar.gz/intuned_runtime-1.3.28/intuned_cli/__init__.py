#!/usr/bin/env python3

import shutil
import subprocess
import sys


def run():
    intunedctl_path = shutil.which("intunedctl")

    if not intunedctl_path:
        print(
            "Install Intuned CLI globally with `npm install -g @intuned/cli` to run this command.",
            file=sys.stderr,
        )
        sys.exit(1)

    result = subprocess.run([intunedctl_path] + sys.argv[1:])
    sys.exit(result.returncode)
