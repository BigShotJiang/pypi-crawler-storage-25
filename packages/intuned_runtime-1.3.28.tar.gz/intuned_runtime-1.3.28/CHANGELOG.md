# UNRELEASED

# 1.3.28

- add support for profile templates in Python runtime

# 1.3.26

- change default browser dimensions

# 1.3.11

- Deployment flow enhancements
