import asyncio
import os
import signal
import sys
import time
from pathlib import Path
from typing import Any
from typing import cast
from typing import Literal

from pydantic import Field
from pydantic import ValidationError

from _intuned_runtime_internal.backend_functions import get_auth_session_parameters
from _intuned_runtime_internal.context import IntunedContext
from _intuned_runtime_internal.errors.run_api_errors import ApiNotFoundError
from _intuned_runtime_internal.errors.run_api_errors import InternalInvalidInputError
from _intuned_runtime_internal.errors.run_api_errors import RunApiError
from _intuned_runtime_internal.run.run_api import import_function_from_api_dir
from _intuned_runtime_internal.run.run_api import run_api
from _intuned_runtime_internal.run.setup_context_hook import load_setup_context_hook
from _intuned_runtime_internal.types.run_types import CamelBaseModel
from _intuned_runtime_internal.types.run_types import RunApiParameters
from _intuned_runtime_internal.types.run_types import RunAutomationSuccessResult
from intuned_internal_cli.utils.wrapper import internal_cli_command

from ...utils.interface_client import InterfaceClient
from ...utils.interface_client import JSONLFileClient
from ...utils.interface_client import TCPSocketClient
from ...utils.interface_client import UnixSocketClient

throttle_time = 60


class StartMessage(CamelBaseModel):
    type: Literal["start"] = "start"
    parameters: RunApiParameters


class NextMessageParameters(CamelBaseModel):
    value: str


class NextMessage(CamelBaseModel):
    type: Literal["next"] = "next"
    parameters: NextMessageParameters


class AbortMessage(CamelBaseModel):
    type: Literal["abort"] = "abort"
    parameters: dict[str, Any] = {}


class TokenUpdateMessageParameters(CamelBaseModel):
    functionsToken: str


class TokenUpdateMessage(CamelBaseModel):
    type: Literal["tokenUpdate"] = "tokenUpdate"
    parameters: TokenUpdateMessageParameters


class PingMessage(CamelBaseModel):
    type: Literal["ping"] = "ping"
    parameters: dict[str, Any] = {}


Message = StartMessage | NextMessage | AbortMessage | TokenUpdateMessage | PingMessage


class MessageWrapper(CamelBaseModel):
    message: Message = Field(
        discriminator="type",
    )


@internal_cli_command
async def project__run_interface(
    socket_path: str,
    *,
    mode: str = "unix",
):
    """
    Runs the current project. Project must contain an "api" directory with API functions.

    Args:
        socket_path (str): Path to the socket file.
        mode (str, optional): Communication mode: unix, jsonl, or tcp. Defaults to "unix".

    """

    # create unix socket client of type socket.socket
    if not socket_path:
        raise Exception("socket_path is required")

    client: InterfaceClient | None = None
    timeout_timestamp = time.time()
    if mode == "unix":
        client = UnixSocketClient(socket_path)
    elif mode == "jsonl":
        client = JSONLFileClient(socket_path)
    elif mode == "tcp":
        host, port_str = socket_path.split(":")
        port = int(port_str)
        client = TCPSocketClient(host, port)

    if client is None:
        raise Exception(f"Invalid mode: {mode}")

    await client.connect()

    run_api_task: asyncio.Task[RunAutomationSuccessResult] | None = cast(
        asyncio.Task[RunAutomationSuccessResult] | None, None
    )

    def done(exitCode: int = 0):
        client.close()
        if os.name == "posix":
            loop.remove_signal_handler(signal.SIGTERM)
            loop.remove_signal_handler(signal.SIGINT)
        sys.exit(exitCode)

    try:

        def interrupt_signal_handler():
            async def _impl():
                if run_api_task is not None:
                    run_api_task.cancel()
                # wait for graceful exit, if not, force exit
                await asyncio.sleep(60)
                done(1)

            asyncio.create_task(_impl())

        loop = asyncio.get_event_loop()

        # check if system is unix
        if os.name == "posix":
            loop.add_signal_handler(signal.SIGTERM, interrupt_signal_handler)
            loop.add_signal_handler(signal.SIGINT, interrupt_signal_handler)
        elif os.name == "nt":
            # Windows does not support signal handlers in the same way, so we can use a different approach if needed
            pass

        messages_generator = client.receive_messages()

        async def receive_messages():
            message: Any = None
            try:
                message = await messages_generator.__anext__()
                validated_message = MessageWrapper(message=message)
                return validated_message.message
            except StopAsyncIteration:
                return None
            except ValidationError as e:
                print("Validation error", message, e)
                return InternalInvalidInputError(
                    "Invalid input", {key: str(value) for key, value in e.__dict__.items() if not key.startswith("_")}
                )

        run_api_task: asyncio.Task[RunAutomationSuccessResult] | None = cast(
            asyncio.Task[RunAutomationSuccessResult] | None, None
        )

        def import_function(file_path: str, automation_name: str | None = None):
            return import_function_from_api_dir(
                automation_function_name=automation_name, file_path=file_path, base_dir=os.getcwd()
            )

        async def handle_message(message: Message):
            nonlocal run_api_task
            if message.type == "start":

                async def extend_timeout():
                    nonlocal timeout_timestamp
                    if time.time() - timeout_timestamp < throttle_time:
                        return
                    timeout_timestamp = time.time()
                    await client.send_message({"type": "extend"})

                IntunedContext.current().functions_token = message.parameters.functions_token
                IntunedContext.current().extend_timeout = extend_timeout
                IntunedContext.current().get_auth_session_parameters = get_auth_session_parameters
                IntunedContext.current().run_context = message.parameters.context
                run_api_task = asyncio.create_task(
                    run_api(
                        message.parameters,
                        import_function=import_function,
                    ),
                )
                return

            elif message.type == "abort":
                if run_api_task is not None:
                    run_api_task.cancel()
                return
            elif message.type == "tokenUpdate":
                IntunedContext.current().functions_token = message.parameters.functionsToken
                return
            else:
                raise NotImplementedError()

        receive_messages_task = asyncio.create_task(receive_messages())

        while True:
            tasks: list[asyncio.Task[Message | RunApiError | None] | asyncio.Task[RunAutomationSuccessResult]] = [
                receive_messages_task,
            ]
            if run_api_task is not None:
                tasks.append(run_api_task)
            message_or_result, _ = await asyncio.wait(
                tasks,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if message_or_result.pop() == receive_messages_task:
                message = await receive_messages_task
                if message is None:
                    if run_api_task is not None and not run_api_task.done():
                        run_api_task.cancel()
                    break
                if isinstance(message, RunApiError):
                    await client.send_message({"type": "done", "success": False, "result": message.json})
                    break
                if message.type == "ping":
                    load_setup_context_hook(import_function=import_function)
                    api_files = await get_python_files_from_dir(Path() / "api")
                    apis = [f'api/{str(p.with_suffix("").as_posix())}' for p in [*api_files]]

                    for api in [*apis, "auth-sessions/create", "auth-sessions/check"]:
                        try:
                            import_function(api)
                        except ApiNotFoundError:
                            pass
                    await client.send_message({"type": "pong"})
                    break
                await handle_message(message)
                receive_messages_task = asyncio.create_task(receive_messages())
                continue

            if run_api_task is None:
                continue

            try:
                result = await run_api_task  # type: ignore
                await client.send_message(
                    {
                        "type": "done",
                        "success": True,
                        "result": {
                            "result": result.result,
                            "session": result.session.model_dump(by_alias=True) if result.session else None,
                            "extendedPayloads": [
                                {
                                    "api": payload.api_name,
                                    "parameters": payload.parameters,
                                }
                                for payload in result.payload_to_append
                            ]
                            if result.payload_to_append is not None
                            else None,
                        },
                    }
                )
            except RunApiError as e:
                print("Error", e)
                await client.send_message({"type": "done", "success": False, "result": e.json})
            except asyncio.CancelledError:
                await client.send_message({"type": "done", "success": False, "result": None})
            break
        done()
    except Exception:
        import traceback

        traceback.print_exc()
        done(1)


async def get_python_files_from_dir(dir: Path) -> list[Path]:
    """Get all Python files under a directory, returning relative paths."""
    python_files: list[Path] = []

    file_tree = await asyncio.to_thread(os.walk, dir)
    for root, _, files in file_tree:
        for file in files:
            if file.endswith(".py"):
                full_path = Path(root) / file
                relative_path = full_path.relative_to(dir)
                python_files.append(relative_path)
    return python_files
