## Publication Steps

source: https://packaging.python.org/en/latest/tutorials/packaging-projects

- Generate a distribution:
  - Install/Upgrade the `build` package:
    ```bash
    python -m pip install --upgrade build
    ```
  - clear the `dist/` folder if it exists:
    ```bash
    rm -rf dist
    ```
  - Build the distribution:
    ```bash
    python -m build
    ```
- Create an account and setup the tokens as described in [this step](https://packaging.python.org/en/latest/tutorials/packaging-projects/#uploading-the-distribution-archives), then publish the code:
  - Install/Upgrade the `twine` package:
    ```bash
    python -m pip install --upgrade twine
    ```
  - You can publish to the Test PyPI to test the package before publishing to the real PyPI:
    ```bash
    python -m twine upload --repository testpypi dist/*
    ```
  - Publish to the real PyPI:
    ```bash
    python -m twine upload dist/*
    ```
