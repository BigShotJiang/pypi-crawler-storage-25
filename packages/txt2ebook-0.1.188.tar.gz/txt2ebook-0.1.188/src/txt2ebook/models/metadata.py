# Copyright (c) 2021,2022,2023,2024,2025,2026 Kian-Meng Ang
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""The header of the TXT file."""

from dataclasses import dataclass, field


@dataclass
class Metadata:
    """A model representing the book's metadata."""

    title: str = field(default="")
    authors: list[str] = field(default_factory=list)
    translators: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    index: list[str] = field(default_factory=list)
    cover: str = field(default="")
