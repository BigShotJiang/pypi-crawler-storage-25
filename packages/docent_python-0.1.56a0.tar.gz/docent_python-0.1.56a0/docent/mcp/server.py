"""Docent MCP server for IDE plugins."""

import argparse
import sys
import webbrowser
from pathlib import Path
from typing import Any, cast

from mcp.server.fastmcp import FastMCP  # type: ignore[import-untyped]

from docent.sdk.client import Docent

_client: Docent | None = None
_config_file: str | Path | None = None


def get_client() -> Docent:
    global _client
    if _client is None:
        _client = Docent(config_file=_config_file, log_stream=sys.stderr)
    return _client


mcp = FastMCP("docent", json_response=True)  # type: ignore[reportUnknownVariableType]


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def get_metadata_fields(collection_id: str) -> str:
    """Get the available metadata fields for agent runs in a collection.

    These can be accessed on the metadata_json column in DQL, e.g. foo.bar can be accessed as
    `metadata_json->'foo'->>'bar'`.
    """
    client = get_client()
    try:
        fields = client.get_metadata_fields(
            collection_id, include_sample_values=True, sample_limit=10
        )

        if not fields:
            return f"No metadata fields found for collection {collection_id}"

        def _render_value(value: str) -> str:
            value = value.replace("\n", "\\n")
            if len(value) > 80:
                return value[:77] + "..."
            return value

        lines: list[str] = []
        for field in fields:
            name = str(field.get("name", "(unknown)"))
            name = name.removeprefix("metadata.")
            field_type = str(field.get("type", "str"))
            line = f"- {name} ({field_type})"

            sample_values = cast(list[dict[str, Any]], field.get("sample_values") or [])
            total_unique_values = cast(int | None, field.get("total_unique_values"))
            if sample_values:
                rendered_samples = ", ".join(
                    f"{_render_value(str(s.get('value', '')))} ({int(s.get('count', 0))} runs)"
                    for s in sample_values
                    if s.get("value") is not None
                )
                other_suffix = ""
                if total_unique_values is not None:
                    other_count = total_unique_values - len(sample_values)
                    if other_count > 0:
                        other_suffix = f" (+{other_count} other values)"
                line = f"{line}: {rendered_samples}{other_suffix}"

            lines.append(line)

        field_list = "\n".join(lines)
        return f"Metadata fields for collection {collection_id}:\n{field_list}"
    except Exception as e:
        error_msg = str(e)
        if "404" in error_msg:
            return f"Collection not found: {collection_id}"
        return f"Error fetching metadata fields: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def list_reading_presets(collection_id: str, name_filter: str | None = None) -> str:
    "List saved reading presets in a collection. Presets are reusable reading configurations (prompt template, model, output schema) that can be run via client.preset_reading(). Use name_filter to search by name substring."
    client = get_client()
    if not collection_id:
        return "Error: collection_id is required (pass explicitly or set DOCENT_COLLECTION_ID)"

    try:
        presets = client.list_reading_presets(collection_id)

        if name_filter:
            lower_filter = name_filter.lower()
            presets = [p for p in presets if lower_filter in (p.get("name") or "").lower()]

        if not presets:
            filter_msg = f" matching '{name_filter}'" if name_filter else ""
            return f"No reading presets found for collection {collection_id}{filter_msg}"

        if len(presets) <= 20:
            lines: list[str] = []
            for p in presets:
                preset_id = p.get("id", "")
                name = p.get("name") or "(unnamed)"
                version_count = len(p.get("versions") or [])

                detail_parts = [f"ID: {preset_id}", f"{version_count} version(s)"]
                try:
                    config = client.get_reading_preset_config(collection_id, preset_id)
                    reading_config = cast(dict[str, Any], config.get("reading_config") or {})
                    model = cast(dict[str, Any], reading_config.get("model") or {})
                    provider = str(model.get("provider", ""))
                    model_name = str(model.get("model_name", ""))
                    if provider and model_name:
                        detail_parts.append(f"model: {provider}/{model_name}")
                    segments = cast(list[Any], reading_config.get("prompt_template_segments") or [])
                    text_parts = [str(s) for s in segments if isinstance(s, str)]
                    if text_parts:
                        preview = " ".join(text_parts)[:120]
                        if len(" ".join(text_parts)) > 120:
                            preview += "..."
                        detail_parts.append(f'prompt: "{preview}"')
                except Exception:
                    pass

                lines.append(f"- {name} ({', '.join(detail_parts)})")

            return f"Reading presets for collection {collection_id}:\n" + "\n".join(lines)

        lines = [f"- {p.get('name') or '(unnamed)'} (ID: {p.get('id', '')})" for p in presets]
        return (
            f"Found {len(presets)} reading presets for collection {collection_id} "
            f"(showing names only; call again with name_filter to see details):\n"
            + "\n".join(lines)
        )
    except Exception as e:
        error_msg = str(e)
        if "404" in error_msg:
            return f"Collection not found: {collection_id}"
        return f"Error fetching reading presets: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def get_reading_models() -> str:
    "List the LLM models available for readings. Returns model name, provider, context window size, and whether BYOK (bring-your-own-key) is required."
    client = get_client()
    try:
        models = client.get_reading_models()
        if not models:
            return "No reading models available"

        lines: list[str] = []
        for m in models:
            provider = str(m.get("provider", ""))
            model_name = str(m.get("model_name", ""))
            context_window = m.get("context_window")
            uses_byok = m.get("uses_byok", False)
            reasoning_effort = m.get("reasoning_effort")

            parts = [f"{provider}/{model_name}"]
            if context_window is not None:
                parts.append(f"context: {int(context_window):,} tokens")
            if reasoning_effort:
                parts.append(f"reasoning: {reasoning_effort}")
            if uses_byok:
                parts.append("BYOK required")
            lines.append(f"- {' | '.join(parts)}")

        return "Available reading models:\n" + "\n".join(lines)
    except Exception as e:
        return f"Error fetching reading models: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def navigate_to(collection_id: str, path: str) -> str:
    "Open a page in the Docent dashboard in the browser. For a result set, path is `/results/<result_set_name>`"
    client = get_client()
    if not collection_id:
        return "Error: collection_id is required (pass explicitly or set DOCENT_COLLECTION_ID)"

    path = path.lstrip("/")
    url = f"{client._frontend_url}/dashboard/{collection_id}/{path}"  # type: ignore[reportPrivateUsage]

    webbrowser.open(url)
    return f"Opened {url} in browser"


def main():
    global _config_file

    parser = argparse.ArgumentParser(description="Docent MCP Server")
    parser.add_argument(
        "--config-file",
        type=str,
        help="Path to a dotenv config file with DOCENT_API_KEY, DOCENT_API_URL, etc.",
    )
    args = parser.parse_args()

    if args.config_file:
        _config_file = args.config_file

    mcp.run(transport="stdio")  # type: ignore[reportUnknownMemberType]
