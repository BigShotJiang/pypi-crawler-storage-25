"""Lazy reading API types for the Docent SDK.

Core types:
- QueryResult: lazy handle returned by client.query()
- ColumnRef: reference to a column in a QueryResult
- Reading: lazy handle returned by client.read()
- ReadingResult: lightweight result wrapper
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from docent._llm_util.providers.preference_types import ModelOption
from docent.data_models.reading import (
    AnnotatableReadingParamType,
    ParameterContextConfig,
    ReadingCacheMode,
)
from docent.sdk.llm_context import ContextItemRef

if TYPE_CHECKING:
    from docent.sdk.client import Docent


class ColumnRef:
    """Reference to a column in a QueryResult, used as a template parameter in prompts."""

    def __init__(self, query_result: QueryResult, column_name: str) -> None:
        self._query_result = query_result
        self._column_name = column_name
        self._type_annotation: AnnotatableReadingParamType | None = None

    @property
    def query_result(self) -> QueryResult:
        return self._query_result

    @property
    def column_name(self) -> str:
        return self._column_name

    @property
    def type_annotation(self) -> AnnotatableReadingParamType | None:
        return self._type_annotation

    def as_type(self, type_name: AnnotatableReadingParamType) -> ColumnRef:
        """Annotate this column reference with an explicit type (e.g. 'transcript')."""
        clone = ColumnRef(self._query_result, self._column_name)
        clone._type_annotation = type_name
        return clone

    def __repr__(self) -> str:
        base = f"ColumnRef({self._query_result!r}, {self._column_name!r})"
        if self._type_annotation:
            base = f"{base}.as_type({self._type_annotation!r})"
        return base


class QueryResult:
    """Lazy handle for a DQL query, returned by client.query().

    Attribute access returns ColumnRef objects for use in prompt templates.
    """

    def __init__(self, collection_id: str, dql: str) -> None:
        self._collection_id = collection_id
        self._dql = dql

    @property
    def collection_id(self) -> str:
        return self._collection_id

    @property
    def dql(self) -> str:
        return self._dql

    def __getattr__(self, name: str) -> ColumnRef:
        if name.startswith("_"):
            raise AttributeError(name)
        return ColumnRef(self, name)

    def __repr__(self) -> str:
        return f"QueryResult({self._collection_id!r}, {self._dql!r})"


PromptSegment = str | ColumnRef | ContextItemRef


class ReadingResult:
    """Lightweight wrapper around a single LLM result."""

    def __init__(
        self,
        *,
        output: dict[str, Any] | None,
        error: dict[str, Any] | None,
        arguments: dict[str, Any],
    ) -> None:
        self.output = output
        self.error = error
        self.arguments = arguments

    def __repr__(self) -> str:
        if self.error:
            return f"ReadingResult(error={self.error!r})"
        return f"ReadingResult(output={self.output!r})"


class Reading:
    """Lazy handle for a reading, returned by client.read().

    The reading is not submitted until flush is triggered.
    """

    def __init__(self, *, client: Docent, alias: str) -> None:
        self._client = client
        self._alias = alias
        self._reading_id: str | None = None
        self._results: list[ReadingResult] | None = None
        self._resolved = False

    @property
    def alias(self) -> str:
        return self._alias

    def __format__(self, format_spec: str) -> str:
        return f"${self._alias}"

    @property
    def id(self) -> str:
        """Force evaluation and return the real reading UUID."""
        if self._reading_id is None:
            self._client._force_flush(self)  # pyright: ignore[reportPrivateUsage]
        assert self._reading_id is not None
        return self._reading_id

    @property
    def results(self) -> list[ReadingResult]:
        """Force evaluation, block until complete, and return results."""
        if self._results is None:
            self._client._force_flush(self)  # pyright: ignore[reportPrivateUsage]
            self._client._wait_for_reading(self)  # pyright: ignore[reportPrivateUsage]
        assert self._results is not None
        return self._results

    def wait(self) -> None:
        """Force evaluation without returning results."""
        if not self._resolved:
            self._client._force_flush(self)  # pyright: ignore[reportPrivateUsage]
            self._client._wait_for_reading(self)  # pyright: ignore[reportPrivateUsage]

    def _set_reading_id(self, reading_id: str) -> None:
        self._reading_id = reading_id

    def _set_results(self, results: list[ReadingResult]) -> None:
        self._results = results
        self._resolved = True

    def __repr__(self) -> str:
        if self._reading_id:
            return f"Reading(alias={self._alias!r}, id={self._reading_id!r})"
        return f"Reading(alias={self._alias!r}, pending)"


# ── Pending entry types (internal, used by client accumulation) ─────


class _PendingReading:
    """Accumulated reading entry, not yet submitted to server."""

    def __init__(
        self,
        *,
        alias: str,
        handle: Reading,
        collection_id: str | None,
        name: str | None,
        model_json: ModelOption,
        output_schema: dict[str, Any] | None = None,
        max_new_tokens: int | None = None,
        user_metadata: dict[str, Any] | None = None,
        source_reading_preset_id: str | None,
        cache_mode: ReadingCacheMode = "reading",
        # Template path
        prompt_template_segments: list[Any] | None,
        context_config: dict[str, ParameterContextConfig] | None,
        dql_query: str | None,
        # Scripted path
        requests: list[dict[str, Any]] | None,
    ) -> None:
        self.alias = alias
        self.handle = handle
        self.collection_id = collection_id
        self.name = name
        self.model_json = model_json
        self.output_schema = output_schema
        self.max_new_tokens = max_new_tokens
        self.user_metadata = user_metadata
        self.source_reading_preset_id = source_reading_preset_id
        self.cache_mode: ReadingCacheMode = cache_mode
        self.prompt_template_segments = prompt_template_segments
        self.context_config = context_config
        self.dql_query = dql_query
        self.requests = requests


class _PendingDqlOnlyStep:
    """Accumulated dql_only entry."""

    def __init__(
        self, *, alias: str, collection_id: str | None, dql_query: str, name: str | None
    ) -> None:
        self.alias = alias
        self.collection_id = collection_id
        self.dql_query = dql_query
        self.name = name


class _PendingPresetReading:
    """Accumulated reading entry backed by a preset."""

    def __init__(
        self,
        *,
        alias: str,
        handle: Reading,
        collection_id: str | None,
        name: str | None,
        source_reading_preset_id: str,
        user_metadata: dict[str, Any] | None,
        dql_query: str | None,
        cache_mode: ReadingCacheMode = "reading",
    ) -> None:
        self.alias = alias
        self.handle = handle
        self.collection_id = collection_id
        self.name = name
        self.source_reading_preset_id = source_reading_preset_id
        self.user_metadata = user_metadata
        self.dql_query = dql_query
        self.cache_mode: ReadingCacheMode = cache_mode


class _PendingStepGroup:
    """Accumulated step-group entry."""

    def __init__(self, *, alias: str, label: str) -> None:
        self.alias = alias
        self.label = label


class _PendingEndStepGroup:
    """Marker that closes the current step-group scope."""

    def __init__(self, *, alias: str) -> None:
        self.alias = alias


class StepGroupContext:
    """Returned by ``Docent.step_group()``.

    Can be used as a plain call (group applies to everything that follows)
    or as a context manager to auto-close the group scope on exit.
    """

    def __init__(self, pending_list: list[PendingEntry], alias: str) -> None:
        self._pending_list = pending_list
        self._alias = alias

    def __enter__(self) -> StepGroupContext:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._pending_list.append(_PendingEndStepGroup(alias=self._alias))


PendingEntry = (
    _PendingReading
    | _PendingDqlOnlyStep
    | _PendingPresetReading
    | _PendingStepGroup
    | _PendingEndStepGroup
)
