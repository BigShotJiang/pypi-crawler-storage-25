"""ESP32 emitter — declarative-only MVP for v0.3.

Lowers the user's Python controllers into a `schedules[]` array the
firmware's `handlers/release.rs` understands. Only the
`@on.interval(N, UNIT)` + `self.publish(literal_topic, dict_literal)`
shape is supported today; anything else (state machines, drivers,
self.actuate, conditionals beyond `if`) raises Esp32UnsupportedError
with a precise message.

**Bundle format asymmetry.** Linux ships `bundle.tar.gz` (gzipped tar
of manifest + driver binaries + per-driver TOMLs). The cloud's MinIO
object key is hardcoded `projects/{p}/releases/{r}/bundle.tar.gz` and
service-edge proxies whatever bytes live at that path. ESP can't
support a tar+gz reader on Xtensa without dragging in flate2's
miniz_oxide backend + a tar crate, neither of which is vetted on the
xtensa-esp32-espidf target. So for v0.3.0 we cheat: this emitter
writes raw `manifest.json` bytes to a file *named* `bundle.tar.gz` so
the cloud's hardcoded object key still finds it. The chip's
`handlers/release.rs` doesn't try to untar — it just JSON-decodes
the body. Filename is a misleading lie; future v0.4.0 should either
add proper tar+gz support on the chip OR add a per-target object key
on the cloud side.
"""

from __future__ import annotations

import ast
import json
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .base import Emitter

if TYPE_CHECKING:
    from .._drivers import StagedDriver
    from ..discover import ProjectFiles
    from ..memory import MemoryEstimate


class Esp32UnsupportedError(Exception):
    """Raised when a controller uses a feature ESP32 doesn't support yet.

    Always carries a precise location (file:line) and the offending
    expression so the user can fix it without grep-spelunking. Caller
    should turn this into a CompileResult error string.
    """


# Allowed shapes inside a `self.publish(topic, dict_literal[, quality=...])`
# dict literal value. Each entry maps to a ValueDescriptor variant on
# the chip side (handlers/schedules.rs::ValueDescriptor).
_PAYLOAD_VALUE_KINDS = {
    "constant",
    "counter",
    "timestamp_unix_ms",
    "random",
    "message_field",
    "state",
}

# `self.state.<op>(...)` shapes the chip understands. Each maps to a
# `StateOp` variant in `gateway-esp/src/handlers/release.rs`.
_STATE_WRITE_OPS = {"set", "increment", "delete", "clear"}


class Esp32Emitter(Emitter):
    """Declarative-only emitter — produces schedules[]-only manifest."""

    def emit_driver_configs(self, devices: list[dict], output_dir: Path) -> list[Path]:
        # ESP doesn't run native driver subprocesses (the protocol path
        # is deferred). The validator gates protocols at compile time
        # against _capabilities.yaml's esp32 entry, so by the time we
        # get here `devices` should already be filtered to "supported".
        # Today: nothing supported, so this is a no-op.
        if devices:
            # Soft signal: if the user declared devices and validation
            # let them through, something's wrong with the capability
            # matrix. Don't fail the compile — the schedules executor
            # ignores devices anyway — but log it. Drop the warning
            # into output_dir as a marker file so the bundle inspector
            # can flag it.
            (output_dir / "esp32_unsupported_devices.txt").write_text(
                f"ESP32 emitter received {len(devices)} device(s) but declarative-only MVP "
                "ignores them. Driver protocols come in v0.4.\n"
            )
        return []

    def emit_manifest(
        self,
        project: ProjectFiles,
        devices: list[dict],
        controllers: list[dict],
        memory: MemoryEstimate,
        target: str,
        output_dir: Path,
        drivers: list[StagedDriver] | None = None,
    ) -> Path:
        """Emit ESP-specific manifest with `schedules[]` lowered from
        the user's `@on.interval` methods.

        Builds the manifest by hand instead of calling super so the
        target-locked-to-esp32 invariant is explicit and the schedules
        array is folded in at a known position. The base shape (project,
        controllers, memory) is kept so dashboard inspectors that already
        understand the linux manifest don't choke on ESP bundles.
        """
        schedules, lifecycle, mqtt_subscriptions = _lower_controllers(
            controllers, project.controller_files
        )

        manifest: dict[str, Any] = {
            "project": {
                "name": project.name,
                "version": project.version,
            },
            "target": "esp32",
            "devices": [],  # MVP: no driver protocols on ESP
            "controllers": [
                {
                    "id": c["id"],
                    "class_name": c["class_name"],
                    "triggers": c.get("triggers", []),
                }
                for c in controllers
            ],
            "memory": asdict(memory),
            "drivers": [],  # No native binaries on ESP
            "referenced_env_vars": [],  # env_vars not supported on ESP yet
            "schedules": schedules,
            "lifecycle": lifecycle,
            "mqtt_subscriptions": mqtt_subscriptions,
        }
        path = output_dir / "manifest.json"
        path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
        return path

    def emit_bundle(self, output_dir: Path) -> Path:
        """Override base.emit_bundle (which produces a real tar.gz).

        Writes `manifest.json`'s raw bytes to a file named
        `bundle.tar.gz` so the cloud's hardcoded MinIO object key path
        still resolves. The chip's release.rs JSON-decodes the body
        directly — no untar happens. See module docstring for the
        rationale + cleanup path.
        """
        manifest = output_dir / "manifest.json"
        if not manifest.exists():
            raise RuntimeError(
                "esp32 emit_bundle: manifest.json missing — emit_manifest "
                "must run before emit_bundle"
            )
        bundle = output_dir / "bundle.tar.gz"
        # Direct copy of the manifest bytes. Filename is the lie; the
        # cloud serves whatever's at this path verbatim.
        shutil.copyfile(manifest, bundle)
        return bundle


# ---------------- trigger lowering ----------------------------------

# Triggers we currently lower into the manifest. Anything else with an
# @on.<name> decorator gets refused with a clear message naming the
# unsupported trigger so the user sees the real reason at compile time
# (vs. a downstream firmware-side surprise).
_SUPPORTED_TRIGGERS = {"interval", "startup", "shutdown", "message"}


def _lower_controllers(
    controllers: list[dict],
    controller_files: list[Path],
) -> tuple[list[dict], dict[str, list[dict]], list[dict]]:
    """Walk every controller's source file and lower its triggers.

    Returns `(schedules, lifecycle, mqtt_subscriptions)`:

    - `schedules[]` — `@on.interval` methods (existing behaviour).
    - `lifecycle = {"startup": [...], "shutdown": [...]}` — `@on.startup`
      / `@on.shutdown` methods. Each entry shape:
      `{controller, method, publishes: [{topic_suffix, payload}, ...]}`.
    - `mqtt_subscriptions[]` — `@on.message(topic="...")` methods, same
      `publishes[]` shape plus the `topic_suffix` the firmware should
      subscribe to.

    Raises Esp32UnsupportedError for anything outside the supported
    shape so the user gets a clear refusal at compile time.
    """
    schedules: list[dict] = []
    lifecycle: dict[str, list[dict]] = {"startup": [], "shutdown": []}
    mqtt_subscriptions: list[dict] = []

    # Re-parse the controller files so we can walk method bodies. The
    # parser already gave us `controllers` (with id, class_name, triggers)
    # but not the method-body AST nodes. Cheap — controller files are
    # typically a handful of small files.
    by_file: dict[Path, ast.Module] = {}
    for path in controller_files:
        src = path.read_text()
        by_file[path] = ast.parse(src, filename=str(path))

    for ctrl in controllers:
        source_path = Path(ctrl.get("source_file") or "")
        if source_path not in by_file:
            continue
        tree = by_file[source_path]
        for cls in ast.walk(tree):
            if not (isinstance(cls, ast.ClassDef) and cls.name == ctrl["class_name"]):
                continue
            for member in cls.body:
                if not isinstance(member, ast.FunctionDef):
                    continue
                trigger = _on_decorator_for(member)
                if trigger is None:
                    continue
                if trigger not in _SUPPORTED_TRIGGERS:
                    raise Esp32UnsupportedError(
                        f"{source_path}:{member.lineno}: "
                        f"@on.{trigger} not supported on ESP32 yet. "
                        f"(in {ctrl['class_name']}.{member.name})"
                    )

                if trigger == "interval":
                    interval_ms = _interval_from_decorators(member, source_path)
                    # _interval_from_decorators raises rather than
                    # returning None when @on.interval is malformed, so
                    # `interval_ms is None` here only happens if the
                    # detector logic ever drifts. Defensive: skip.
                    if interval_ms is None:
                        continue
                    publish_entry = _extract_publish_single(member, source_path)
                    schedule_entry: dict[str, Any] = {
                        "id": f"{ctrl['class_name']}.{member.name}",
                        "interval_ms": interval_ms,
                        "topic_suffix": publish_entry["topic_suffix"],
                        "payload": publish_entry["payload"],
                    }
                    if "channel" in publish_entry:
                        schedule_entry["channel"] = publish_entry["channel"]
                    schedules.append(schedule_entry)
                    continue

                # startup / shutdown / message all share the same body
                # contract: a sequence of self.publish(literal, dict)
                # calls. The decorator metadata differs per kind.
                publishes = _extract_publish_calls(member, source_path)

                if trigger in ("startup", "shutdown"):
                    lifecycle[trigger].append(
                        {
                            "controller": ctrl["class_name"],
                            "method": member.name,
                            "publishes": publishes,
                        }
                    )
                    continue

                # @on.message(command="set_temperature") — preferred v0.4+ form.
                # Legacy topic= form still works (auto-derives command).
                command, topic_suffix, requires_role = _message_command_from_decorator(
                    member, source_path
                )
                entry: dict[str, Any] = {
                    "command": command,
                    "topic_suffix": topic_suffix,
                    "controller": ctrl["class_name"],
                    "method": member.name,
                    "publishes": publishes,
                }
                if requires_role is not None:
                    entry["requires_role"] = requires_role
                mqtt_subscriptions.append(entry)

    return schedules, lifecycle, mqtt_subscriptions


def _on_decorator_for(method: ast.FunctionDef) -> str | None:
    """Return the @on.<name> tag for this method, or None if none.

    A method decorated with @on.startup AND @on.interval would be a
    user error — but the parser already rejects that combo upstream, so
    here we just take the first @on decorator we see (matches the v0.3
    semantics of `_first_on_decorator_name`).
    """
    for dec in method.decorator_list:
        attr = _decorator_attr(dec)
        if attr is not None:
            return attr
    return None


def _message_command_from_decorator(
    method: ast.FunctionDef, source_path: Path
) -> tuple[str, str, str | None]:
    """Pull command/topic + role from @on.message(...).

    Returns ``(command_name, topic_suffix, requires_role)`` where:

    - ``command_name`` is the user-facing command identifier (what the
      cloud API caller specifies). Always present after v0.4.
    - ``topic_suffix`` is the MQTT topic the chip subscribes to. Derived
      as ``cmd/<command_name>`` for the new ``command=`` form. For the
      legacy ``topic=`` form, used directly so existing controllers keep
      working.
    - ``requires_role`` is the optional cloud-side authorization gate.
      ``None`` means the platform default (``viewer``).

    Three accepted forms (in priority order):

    1. ``@on.message(command="set_temperature", requires_role="operator")``
       — preferred; v0.4+. Lowers to topic_suffix=``cmd/set_temperature``.
    2. ``@on.message(topic="cmd/set_temperature")`` — legacy v0.3.x form,
       still accepted with the topic used verbatim. ``command`` is
       derived by stripping a leading ``cmd/`` prefix; if the topic
       doesn't start with ``cmd/`` we use the suffix verbatim as the
       command name (caller will have to specify the full topic-style
       name in the cloud API).
    3. ``@on.message("name")`` — single positional, treated as a command
       name (NOT as a topic — channel model says command is canonical).
       v0.4+ shape.

    See web-docs/docs/Scadable SDK/architecture/channels.md for the
    channel model rationale.
    """
    for dec in method.decorator_list:
        if not isinstance(dec, ast.Call):
            continue
        if _decorator_attr(dec) != "message":
            continue

        # Collect kwargs by name.
        kwargs: dict[str, ast.expr] = {kw.arg: kw.value for kw in dec.keywords if kw.arg}
        requires_role: str | None = None
        if "requires_role" in kwargs:
            role_val = _const_strict(kwargs["requires_role"], source_path)
            if not isinstance(role_val, str) or not role_val:
                raise Esp32UnsupportedError(
                    f"{source_path}:{dec.lineno}: @on.message requires_role= "
                    f"must be a non-empty string literal"
                )
            requires_role = role_val

        # Form 1: command= kwarg (preferred).
        if "command" in kwargs:
            command = _string_literal(kwargs["command"], source_path, "command")
            if "/" in command:
                raise Esp32UnsupportedError(
                    f"{source_path}:{dec.lineno}: @on.message command= must not "
                    f"contain '/' — commands map to topic cmd/<name> automatically"
                )
            return command, f"cmd/{command}", requires_role

        # Form 2: legacy topic= kwarg.
        if "topic" in kwargs:
            topic_suffix = _string_literal(kwargs["topic"], source_path, "topic")
            command = (
                topic_suffix[len("cmd/") :] if topic_suffix.startswith("cmd/") else topic_suffix
            )
            return command, topic_suffix, requires_role

        # Form 3: single positional, treated as command name.
        if len(dec.args) == 1:
            command = _string_literal(dec.args[0], source_path, "command")
            if "/" in command:
                # Backward-compat: if it looks like a topic (has /), treat
                # it as one — matches the v0.3 positional `@on.message("cmd/x")`.
                topic_suffix = command
                command = (
                    topic_suffix[len("cmd/") :] if topic_suffix.startswith("cmd/") else topic_suffix
                )
                return command, topic_suffix, requires_role
            return command, f"cmd/{command}", requires_role

        raise Esp32UnsupportedError(
            f"{source_path}:{dec.lineno}: @on.message requires command= "
            f"(preferred) or topic= (legacy) keyword argument, or a single "
            f"positional command name"
        )
    raise Esp32UnsupportedError(
        f"{source_path}:{method.lineno}: @on.message decorator missing on "
        f"{method.name} (internal error: lowering reached message branch)"
    )


def _decorator_attr(dec: ast.expr) -> str | None:
    """If `dec` is `@on.<name>` or `@on.<name>(...)`, return <name>."""
    if isinstance(dec, ast.Call):
        dec = dec.func
    if isinstance(dec, ast.Attribute) and isinstance(dec.value, ast.Name) and dec.value.id == "on":
        return dec.attr
    return None


_TIME_UNIT_MS = {
    "SECONDS": 1_000,
    "MINUTES": 60_000,
    "HOURS": 3_600_000,
    "MILLISECONDS": 1,
    "s": 1_000,
    "min": 60_000,
    "h": 3_600_000,
    "ms": 1,
}


def _interval_from_decorators(method: ast.FunctionDef, source_path: Path) -> int | None:
    """Return interval_ms if this method has @on.interval(value, UNIT)."""
    for dec in method.decorator_list:
        if not isinstance(dec, ast.Call):
            continue
        if _decorator_attr(dec) != "interval":
            continue
        if len(dec.args) < 1:
            raise Esp32UnsupportedError(
                f"{source_path}:{dec.lineno}: @on.interval requires (value, UNIT) args"
            )
        value = _const_strict(dec.args[0], source_path)
        unit = "SECONDS"
        if len(dec.args) >= 2:
            unit = _const_strict(dec.args[1], source_path)
            if not isinstance(unit, str):
                if isinstance(dec.args[1], ast.Name):
                    unit = dec.args[1].id
                else:
                    raise Esp32UnsupportedError(
                        f"{source_path}:{dec.args[1].lineno}: "
                        f"@on.interval unit must be a SECONDS/MINUTES/MS literal"
                    )
        if unit not in _TIME_UNIT_MS:
            raise Esp32UnsupportedError(
                f"{source_path}:{dec.lineno}: unknown interval unit {unit!r}"
            )
        if not isinstance(value, (int, float)):
            raise Esp32UnsupportedError(
                f"{source_path}:{dec.lineno}: @on.interval value must be a number literal"
            )
        return int(value * _TIME_UNIT_MS[unit])
    return None


def _const_strict(node: ast.expr, source_path: Path) -> Any:
    """Like _const but bare names are returned as their id (e.g. SECONDS)."""
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return node.id
    raise Esp32UnsupportedError(
        f"{source_path}:{node.lineno}: expected literal value, got {type(node).__name__}"
    )


def _extract_publish_single(method: ast.FunctionDef, source_path: Path) -> dict:
    """Body must be exactly one publish/send_* call. Returns the full
    entry dict (topic_suffix + payload + optional channel) — preserves
    the channel tag from send_data/send_event/send_alert verbs through
    to the schedule manifest entry.
    """
    body = list(method.body)
    # Permit a leading docstring then exactly one Expr(Call) statement.
    if (
        body
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
        and isinstance(body[0].value.value, str)
    ):
        body = body[1:]
    if len(body) != 1:
        raise Esp32UnsupportedError(
            f"{source_path}:{method.lineno}: ESP32 controller methods must contain "
            f"exactly one self.publish/send_data/send_event/send_alert(...) call "
            f"(got {len(body)} statements)"
        )
    return _extract_publish_stmt(body[0], source_path)


def _extract_publish_call(method: ast.FunctionDef, source_path: Path) -> tuple[str, dict]:
    """Legacy 2-tuple shape kept for any older callers. Prefer
    _extract_publish_single for new sites — it preserves the channel."""
    entry = _extract_publish_single(method, source_path)
    return entry["topic_suffix"], entry["payload"]


# Channel verbs map from `self.<verb>` to the manifest channel name +
# the topic-suffix prefix. publish=legacy (no channel field; raw topic).
# send_data/event/alert are v0.4: name is the second component (channel
# is derived from the verb, the user picks just `name`).
_CHANNEL_SEND_VERBS: dict[str, tuple[str, str]] = {
    # verb name → (channel name in manifest, MQTT topic prefix)
    "send_data": ("data", "data/"),
    "send_event": ("events", "event/"),
    "send_alert": ("alerts", "alert/"),
}


def _extract_publish_stmt(stmt: ast.stmt, source_path: Path) -> dict:
    """Lower a single Expr(Call) into a publish entry dict.

    Recognised shapes:
      - self.publish(topic_literal, payload_dict[, quality=...])
        → {topic_suffix, payload}                    (legacy)
      - self.send_data(name, payload_dict)
        → {topic_suffix: "data/<name>", payload, channel: "data"}
      - self.send_event(name, payload_dict)
        → {topic_suffix: "event/<name>", payload, channel: "events"}
      - self.send_alert(name, payload_dict)
        → {topic_suffix: "alert/<name>", payload, channel: "alerts"}
      - self.state.set("k", v) / .increment("k"[, n]) / .delete("k") / .clear()
        → {op, key, value?}                          (NW-E)

    Channel verbs reject names containing '/' so the user can't
    accidentally inject topic levels — pick a `name`, not a `topic`.
    See web-docs's architecture/channels.md for the rationale.
    """
    if not (isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call)):
        raise Esp32UnsupportedError(
            f"{source_path}:{getattr(stmt, 'lineno', '?')}: only a "
            f"self.publish/send_data/send_event/send_alert/self.state(...) "
            f"expression is supported"
        )
    call = stmt.value

    # `self.state.<op>(...)` — chained attribute, handled before the
    # generic `self.<method>` check below. Returns a State action dict
    # that the chip lowers to a `PublishAction::State` variant.
    state_action = _try_extract_state_call(call, source_path)
    if state_action is not None:
        return state_action

    if not (
        isinstance(call.func, ast.Attribute)
        and isinstance(call.func.value, ast.Name)
        and call.func.value.id == "self"
    ):
        raise Esp32UnsupportedError(
            f"{source_path}:{call.lineno}: only `self.<method>(...)` calls are supported"
        )
    method_name = call.func.attr

    # Channel-aware send_* verbs (v0.4).
    if method_name in _CHANNEL_SEND_VERBS:
        channel, prefix = _CHANNEL_SEND_VERBS[method_name]
        if len(call.args) < 2:
            raise Esp32UnsupportedError(
                f"{source_path}:{call.lineno}: self.{method_name} requires (name, payload_dict)"
            )
        name = _string_literal(call.args[0], source_path, "name")
        if not name:
            raise Esp32UnsupportedError(
                f"{source_path}:{call.lineno}: self.{method_name} name must be non-empty"
            )
        if "/" in name or "+" in name or "#" in name:
            raise Esp32UnsupportedError(
                f"{source_path}:{call.lineno}: self.{method_name} name must not "
                f"contain '/', '+', or '#' (channel handles topic prefix automatically)"
            )
        payload = _payload_dict(call.args[1], source_path)
        return {
            "topic_suffix": f"{prefix}{name}",
            "payload": payload,
            "channel": channel,
        }

    # Legacy publish — explicit topic, no channel field.
    if method_name != "publish":
        raise Esp32UnsupportedError(
            f"{source_path}:{call.lineno}: self.{method_name}(...) not supported "
            f"on ESP32 — supported verbs: publish, send_data, send_event, send_alert"
        )
    if len(call.args) < 2:
        raise Esp32UnsupportedError(
            f"{source_path}:{call.lineno}: self.publish requires (topic, payload_dict)"
        )
    topic_node = call.args[0]
    topic_suffix = _string_literal(topic_node, source_path, "topic")
    if topic_suffix.startswith("/"):
        raise Esp32UnsupportedError(
            f"{source_path}:{topic_node.lineno}: publish topic must not start with '/' "
            f"— it gets prepended with `{{project}}/{{gateway}}/`"
        )
    payload = _payload_dict(call.args[1], source_path)
    return {"topic_suffix": topic_suffix, "payload": payload}


def _extract_publish_calls(method: ast.FunctionDef, source_path: Path) -> list[dict]:
    """Lower a method body that's allowed to contain N self.publish() calls
    in sequence (used by lifecycle + mqtt_subscriptions handlers).

    Same restrictions as `_extract_publish_call` apply per-statement —
    every body statement must be a `self.publish(literal_topic,
    dict_literal[, quality=...])` Expr — but we accept >1 of them so a
    boot/shutdown handler can publish several status updates in order.

    A leading docstring is tolerated. Anything else (assignments,
    conditionals, loops, self.actuate, self.upload, function calls
    other than self.publish) raises Esp32UnsupportedError naming the
    offending construct so the user can fix it without grep-spelunking.

    Returns a list of `{topic_suffix, payload}` dicts in source order.
    """
    body = list(method.body)
    if (
        body
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
        and isinstance(body[0].value.value, str)
    ):
        body = body[1:]

    if not body:
        # An empty body (just a docstring or pass) is fine — emits no
        # publishes. Useful for users who want a side-effect-free
        # placeholder while wiring the trigger up.
        return []

    return _extract_actions(body, source_path)


def _extract_actions(stmts: list[ast.stmt], source_path: Path) -> list[dict]:
    """Lower a list of statements into a publish-action list.

    Each statement is either:
      - an Expr(Call) — a publish/send_* call → publish entry
      - an If — recurses into both branches → if entry with then/else

    `elif x: ...` is parsed by Python as `else: [If(test=x, ...)]` so
    nested ifs in the else branch are how elif lowers naturally — no
    special-case required.
    """
    out: list[dict] = []
    for stmt in stmts:
        if isinstance(stmt, ast.If):
            out.append(_lower_if(stmt, source_path))
        elif isinstance(stmt, ast.Expr):
            out.append(_extract_publish_stmt(stmt, source_path))
        else:
            raise Esp32UnsupportedError(
                f"{source_path}:{stmt.lineno}: only self.publish/send_*(...) "
                f"and if/elif/else are allowed in controller method bodies "
                f"(got {type(stmt).__name__})"
            )
    return out


def _lower_if(node: ast.If, source_path: Path) -> dict:
    """`if cond: ... else: ...` → ``{"if": <cond>, "then": [...], "else": [...]}``.

    Both branches are themselves action lists (recursive — supports
    nested if). Empty else (no `else:` clause in source) lowers to an
    empty list, which the chip treats as a no-op.
    """
    return {
        "if": _lower_condition(node.test, source_path),
        "then": _extract_actions(node.body, source_path),
        "else": _extract_actions(node.orelse, source_path),
    }


def _lower_condition(node: ast.expr, source_path: Path) -> dict:
    """Lower a Python boolean expression to a Condition descriptor.

    Recognised shapes (everything else is rejected at compile time):
      - ``a > b`` and friends (`<`, `>=`, `<=`, `==`, `!=`)
      - ``a and b``, ``a or b``  (BoolOp)
      - ``not a``                 (UnaryOp)
      - bare value (literal, message.field, etc.) → Truthy

    Both sides of a comparison must be valid ValueDescriptors (literal,
    counter(), random(), timestamp_unix_ms(), message_field("x"),
    or message.x sugar). No expression evaluation — the chip can't
    compute ``a + b`` because it has no Python interpreter.
    """
    # `not x`
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
        return {"kind": "not", "condition": _lower_condition(node.operand, source_path)}

    # `a and b`, `a or b` (chained: `a and b and c`)
    if isinstance(node, ast.BoolOp):
        kind = "and" if isinstance(node.op, ast.And) else "or"
        return {
            "kind": kind,
            "conditions": [_lower_condition(v, source_path) for v in node.values],
        }

    # `a == b`, `a > b`, etc. Multiple comparators (`a < b < c`) reject
    # for now — easy to add later as `(a < b) and (b < c)` lowering.
    if isinstance(node, ast.Compare):
        if len(node.ops) != 1 or len(node.comparators) != 1:
            raise Esp32UnsupportedError(
                f"{source_path}:{node.lineno}: chained comparisons "
                f"(`a < b < c`) not supported — split into `a < b and b < c`"
            )
        op_kind = _COMPARE_OP_NAMES.get(type(node.ops[0]))
        if op_kind is None:
            raise Esp32UnsupportedError(
                f"{source_path}:{node.lineno}: comparison operator "
                f"{type(node.ops[0]).__name__} not supported "
                f"(use ==, !=, <, <=, >, >=)"
            )
        return {
            "kind": "compare",
            "left": _value_descriptor(node.left, source_path),
            "op": op_kind,
            "right": _value_descriptor(node.comparators[0], source_path),
        }

    # Bare value → Truthy. Lets users write `if message.is_alarm:` etc.
    return {"kind": "truthy", "value": _value_descriptor(node, source_path)}


_COMPARE_OP_NAMES: dict[type, str] = {
    ast.Eq: "eq",
    ast.NotEq: "ne",
    ast.Lt: "lt",
    ast.LtE: "lte",
    ast.Gt: "gt",
    ast.GtE: "gte",
}


def _string_literal(node: ast.expr, source_path: Path, what: str) -> str:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    raise Esp32UnsupportedError(f"{source_path}:{node.lineno}: {what} must be a string literal")


def _try_extract_state_call(call: ast.Call, source_path: Path) -> dict | None:
    """Recognise `self.state.<op>(...)` calls and lower to a State action.

    Returns ``None`` when the call isn't a state call (caller continues
    with the regular publish-call path). Raises ``Esp32UnsupportedError``
    when the call IS a state call but the shape is wrong (unknown op,
    bad arity, non-literal key) — fail loud, never silently demote to
    a publish.

    Wire shape (matches `gateway-esp/.../release.rs::StateAction`):
      ``{"op": "set"|"increment"|"delete"|"clear", "key": "...", "value": <descriptor>?}``
    """
    func = call.func
    if not (
        isinstance(func, ast.Attribute)
        and isinstance(func.value, ast.Attribute)
        and isinstance(func.value.value, ast.Name)
        and func.value.value.id == "self"
        and func.value.attr == "state"
    ):
        return None

    op = func.attr
    if op not in _STATE_WRITE_OPS:
        raise Esp32UnsupportedError(
            f"{source_path}:{call.lineno}: self.state.{op}(...) not supported "
            f"on ESP32 — supported ops: {', '.join(sorted(_STATE_WRITE_OPS))}"
        )

    if call.keywords:
        raise Esp32UnsupportedError(
            f"{source_path}:{call.lineno}: self.state.{op}() takes positional args only"
        )

    if op == "clear":
        if call.args:
            raise Esp32UnsupportedError(
                f"{source_path}:{call.lineno}: self.state.clear() takes no arguments"
            )
        return {"op": "clear", "key": ""}

    # set/increment/delete all require a string-literal key as arg 0.
    if not call.args:
        raise Esp32UnsupportedError(
            f"{source_path}:{call.lineno}: self.state.{op}() requires a key argument"
        )
    key = _string_literal(call.args[0], source_path, f"self.state.{op} key")
    if not key:
        raise Esp32UnsupportedError(
            f"{source_path}:{call.args[0].lineno}: self.state.{op} key must be non-empty"
        )

    if op == "delete":
        if len(call.args) != 1:
            raise Esp32UnsupportedError(
                f"{source_path}:{call.lineno}: self.state.delete(key) takes exactly 1 argument"
            )
        return {"op": "delete", "key": key}

    if op == "set":
        if len(call.args) != 2:
            raise Esp32UnsupportedError(
                f"{source_path}:{call.lineno}: self.state.set(key, value) takes exactly 2 arguments"
            )
        value_desc = _value_descriptor(call.args[1], source_path)
        return {"op": "set", "key": key, "value": value_desc}

    # op == "increment"
    if len(call.args) == 1:
        # No delta given — chip defaults to 1. Omit the value field so
        # the wire shape stays minimal (chip falls back to 1.0 on None).
        return {"op": "increment", "key": key}
    if len(call.args) != 2:
        raise Esp32UnsupportedError(
            f"{source_path}:{call.lineno}: self.state.increment(key[, by]) takes 1 or 2 arguments"
        )
    delta_desc = _value_descriptor(call.args[1], source_path)
    return {"op": "increment", "key": key, "value": delta_desc}


def _payload_dict(node: ast.expr, source_path: Path) -> dict:
    """The payload dict literal: `{"name": <expr>, ...}` where each
    value is one of the supported descriptor shapes.
    """
    if not isinstance(node, ast.Dict):
        raise Esp32UnsupportedError(
            f"{source_path}:{node.lineno}: publish payload must be a {{}}-literal dict"
        )
    out: dict = {}
    for k_node, v_node in zip(node.keys, node.values, strict=True):
        if k_node is None:
            raise Esp32UnsupportedError(
                f"{source_path}:{node.lineno}: dict-spread `**...` not supported in payload"
            )
        key = _string_literal(k_node, source_path, "payload key")
        out[key] = _value_descriptor(v_node, source_path)
    return out


def _value_descriptor(node: ast.expr, source_path: Path) -> dict:
    """Lower a payload-value AST expression to a ValueDescriptor dict.

    Recognised shapes:
      - bare literal (str/int/float/bool/None) → {"kind": "constant", "value": <lit>}
      - `random(min, max)` (special name) → {"kind": "random", "min": ..., "max": ...}
      - `counter()` → {"kind": "counter"}
      - `timestamp_unix_ms()` → {"kind": "timestamp_unix_ms"}
      - `message_field("path")` → {"kind": "message_field", "path": "..."}
      - explicit dict `{"kind": "...", ...}` → passed through after validation

    Anything else (variables, complex expressions, function calls with
    state) raises Esp32UnsupportedError.
    """
    if isinstance(node, ast.Constant):
        return {"kind": "constant", "value": node.value}

    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        fn = node.func.id
        if fn == "counter" and not node.args and not node.keywords:
            return {"kind": "counter"}
        if fn == "timestamp_unix_ms" and not node.args and not node.keywords:
            return {"kind": "timestamp_unix_ms"}
        if fn == "random" and len(node.args) == 2 and not node.keywords:
            mn = _const_strict(node.args[0], source_path)
            mx = _const_strict(node.args[1], source_path)
            if not isinstance(mn, (int, float)) or not isinstance(mx, (int, float)):
                raise Esp32UnsupportedError(
                    f"{source_path}:{node.lineno}: random(min, max) requires numeric literals"
                )
            return {"kind": "random", "min": float(mn), "max": float(mx)}
        if fn == "message_field" and len(node.args) == 1 and not node.keywords:
            # message_field("path") — only meaningful inside @on.message
            # publishes. Top-level field name only; no nested-path syntax
            # yet. Outside of message dispatch the chip resolves this to
            # JSON null, so it's harmless if used in @on.interval too —
            # but we don't validate that context here (the chip's the
            # source of truth on resolution semantics).
            path = _const_strict(node.args[0], source_path)
            if not isinstance(path, str) or not path:
                raise Esp32UnsupportedError(
                    f"{source_path}:{node.lineno}: message_field() requires a non-empty string literal"
                )
            return {"kind": "message_field", "path": path}

    # `message.field_name` — Pythonic shorthand for message_field("field_name").
    # Same semantics: only meaningful inside @on.message; resolves to JSON
    # null outside that context. Lower as if the user wrote message_field().
    if (
        isinstance(node, ast.Attribute)
        and isinstance(node.value, ast.Name)
        and node.value.id == "message"
        and isinstance(node.attr, str)
        and node.attr
    ):
        return {"kind": "message_field", "path": node.attr}

    # `self.state.<key>` — read a value from the per-gateway local state
    # store. Pythonic sugar for `self.state.get("<key>")`; the underlying
    # method form is also accepted (handled by _try_extract_state_get
    # below). Resolves to JSON `null` when the key is absent, mirroring
    # how `message_field` behaves outside message dispatch.
    if (
        isinstance(node, ast.Attribute)
        and isinstance(node.value, ast.Attribute)
        and isinstance(node.value.value, ast.Name)
        and node.value.value.id == "self"
        and node.value.attr == "state"
        and isinstance(node.attr, str)
        and node.attr
    ):
        return {"kind": "state", "key": node.attr}

    # `self.state.get("key")` — explicit method form. Same lowering as
    # the `self.state.<key>` attribute sugar above. We don't validate
    # arity for `default=` — the chip always returns null for missing
    # keys, so a Python-side default never reaches it. Future SDK
    # versions can wrap this to honor `default=` at the SDK layer.
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "get"
        and isinstance(node.func.value, ast.Attribute)
        and isinstance(node.func.value.value, ast.Name)
        and node.func.value.value.id == "self"
        and node.func.value.attr == "state"
        and len(node.args) == 1
    ):
        key = _string_literal(node.args[0], source_path, "self.state.get key")
        if not key:
            raise Esp32UnsupportedError(
                f"{source_path}:{node.lineno}: self.state.get key must be non-empty"
            )
        return {"kind": "state", "key": key}

    if isinstance(node, ast.Dict):
        d: dict = {}
        for k_node, v_node in zip(node.keys, node.values, strict=True):
            if not isinstance(k_node, ast.Constant) or not isinstance(k_node.value, str):
                raise Esp32UnsupportedError(
                    f"{source_path}:{node.lineno}: descriptor dict keys must be string literals"
                )
            v = _const_strict(v_node, source_path)
            d[k_node.value] = v
        kind = d.get("kind")
        if kind not in _PAYLOAD_VALUE_KINDS:
            raise Esp32UnsupportedError(
                f"{source_path}:{node.lineno}: unknown payload value kind {kind!r}"
            )
        return d

    raise Esp32UnsupportedError(
        f"{source_path}:{node.lineno}: payload value must be a literal, "
        f"random/counter/timestamp_unix_ms() call, or {{kind:..., ...}} descriptor"
    )
