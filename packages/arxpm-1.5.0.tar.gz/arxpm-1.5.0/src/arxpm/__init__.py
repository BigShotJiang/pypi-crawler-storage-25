"""
title: arxpm package.
"""

__all__ = ["__version__"]

__version__ = "1.5.0"  # semantic-release
