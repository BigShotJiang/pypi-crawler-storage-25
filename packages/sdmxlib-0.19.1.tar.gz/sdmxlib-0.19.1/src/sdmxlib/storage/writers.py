"""Write SDMX domain objects to DuckDB relational tables.

Decomposes domain objects into the fully relational schema defined by
``storage.schema``.  No JSON blobs.  Every field queryable.

Example::

    from sdmxlib.storage import schema, writers

    conn = duckdb.connect("store.duckdb")
    cursor = schema.create_schema(conn)
    writers.put_codelist(cursor, codelist)
"""

from collections.abc import Sequence
from typing import Any

import duckdb
import pyarrow as pa

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.binding import DataflowBinding
from sdmxlib.model.category import Categorisation, CategoryScheme
from sdmxlib.model.codelist import Codelist
from sdmxlib.model.concept import ConceptScheme
from sdmxlib.model.constraint import DataConstraint
from sdmxlib.model.dataflow import Dataflow
from sdmxlib.model.datastructure import DataStructure
from sdmxlib.model.hierarchy import HierarchicalCode, Hierarchy
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.mapping import StructureSet
from sdmxlib.model.metadataflow import Metadataflow
from sdmxlib.model.metadataset import MetadataSet
from sdmxlib.model.metadatastructure import MetadataAttribute, MetadataStructure
from sdmxlib.model.organisation import AgencyScheme, DataProviderScheme
from sdmxlib.model.provision import ProvisionAgreement
from sdmxlib.model.ref import HasUrn, Ref
from sdmxlib.model.registry import artefact_urn
from sdmxlib.model.representation import Facet
from sdmxlib.model.urn import SdmxUrn

# Map Python class -> type_name string for artefact_type column
_CLASS_TO_NAME: dict[type, str] = {
    Codelist: "Codelist",
    ConceptScheme: "ConceptScheme",
    DataStructure: "DataStructure",
    Dataflow: "Dataflow",
    Hierarchy: "Hierarchy",
    DataConstraint: "DataConstraint",
    CategoryScheme: "CategoryScheme",
    Categorisation: "Categorisation",
    ProvisionAgreement: "ProvisionAgreement",
    AgencyScheme: "AgencyScheme",
    DataProviderScheme: "DataProviderScheme",
    StructureSet: "StructureSet",
    MetadataStructure: "MetadataStructure",
    Metadataflow: "Metadataflow",
    MetadataSet: "MetadataSet",
    DataflowBinding: "DataflowBinding",
}


# ── Helpers ─────────────────────────────────────────────────────────────


def _istring_to_map(s: InternationalString | None) -> dict[str, str]:
    """Convert an InternationalString to a Python dict for MAP insertion."""
    if not s:
        return {}
    return {lang: s[lang] for lang in s}


def _to_arrow_array(values: list[Any]) -> pa.Array:
    """Build a pyarrow Array from a column of Python values.

    Dict values become MAP(VARCHAR, VARCHAR); other types use pyarrow's
    default inference, which handles None, scalars, and list[str] fine.
    """
    sample = next((v for v in values if v is not None), None)
    if isinstance(sample, dict):
        return pa.array(
            [None if d is None else list(d.items()) for d in values],
            type=pa.map_(pa.string(), pa.string()),
        )
    return pa.array(values)


def _execute_bulk_insert(
    conn: duckdb.DuckDBPyConnection,
    table: str,
    cols: Sequence[str],
    rows: Sequence[Sequence[Any]],
) -> None:
    """Insert many rows via Arrow columnar ingestion.

    Avoids the multi-GB SQL parser allocation that VALUES-with-literals
    causes for large bulk inserts (issue #66).
    """
    if not rows:
        return
    columns = list(zip(*rows, strict=True))
    arrays = [_to_arrow_array(list(col)) for col in columns]
    arrow_table = pa.Table.from_arrays(arrays, names=list(cols))
    conn.register("__sdmx_bulk_insert", arrow_table)
    try:
        col_str = ", ".join(cols)
        conn.execute(f"INSERT INTO {table} ({col_str}) SELECT * FROM __sdmx_bulk_insert")
    finally:
        conn.unregister("__sdmx_bulk_insert")


# ── Spine + text + annotations helpers ──────────────────────────────────


def _put_spine(
    conn: duckdb.DuckDBPyConnection,
    urn: str,
    artefact_type: str,
    artefact: Any,
    *,
    source_registry: str | None = None,
) -> None:
    """Insert or replace a row in the artefact spine table.

    ``source_registry`` is the provenance tag for federation: ``None`` for
    untagged (locally-authored without a label), a string id for cached
    remote artefacts (``"ESTAT"``, ``"ECB"``) or local-authored ones with
    a chosen label (``"local"``).

    Issues a :class:`RuntimeWarning` when an existing row is overwritten
    with a different ``source_registry`` — one of #46's listed pitfalls
    ("identity collisions across registries"). The write proceeds
    last-write-wins; the warning surfaces the case to the caller.
    """
    if source_registry is not None:
        existing = conn.execute(
            "SELECT source_registry FROM artefact WHERE urn = ?",
            [urn],
        ).fetchone()
        if existing is not None and existing[0] is not None and existing[0] != source_registry:
            import warnings  # noqa: PLC0415

            warnings.warn(
                f"Spine row for {urn} is being overwritten: previously "
                f"source_registry={existing[0]!r}, now {source_registry!r}. "
                "Two sources publishing the same URN — last write wins.",
                RuntimeWarning,
                stacklevel=3,
            )
    conn.execute("DELETE FROM artefact WHERE urn = ?", [urn])
    conn.execute(
        """
        INSERT INTO artefact
            (urn, artefact_type, agency_id, resource_id, version, is_final,
             valid_from, valid_to, source_registry)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            urn,
            artefact_type,
            artefact.agency_id,
            artefact.id,
            artefact.version,
            getattr(artefact, "is_final", False),
            getattr(artefact, "valid_from", None),
            getattr(artefact, "valid_to", None),
            source_registry,
        ],
    )


def _put_localized_text(
    conn: duckdb.DuckDBPyConnection,
    owner_urn: str,
    field: str,
    istring: InternationalString | None,
) -> None:
    """Insert rows into localized_text for a single field."""
    if not istring:
        return
    for lang in istring:
        conn.execute(
            """
            INSERT OR REPLACE INTO localized_text (owner_urn, field, lang, text)
            VALUES (?, ?, ?, ?)
            """,
            [owner_urn, field, lang, istring[lang]],
        )


class _AnnotationBatch:
    """Accumulator for annotation + annotation_text rows.

    Collects rows across an entire artefact write and flushes them with a
    single bulk-allocated id batch. Replaces the per-annotation
    ``INSERT … RETURNING id`` roundtrip pattern that made persisting a
    78k-code codelist take ~130 s (issue #66).
    """

    __slots__ = ("ann_rows", "text_rows")

    def __init__(self) -> None:
        # Each row: [owner_urn, ordinal, annotation_id, title, annotation_type, url]
        self.ann_rows: list[list[Any]] = []
        # Each entry: (local_idx_into_ann_rows, lang, text). The local
        # index is resolved to a real annotation.id at flush time.
        self.text_rows: list[tuple[int, str, str]] = []

    def add(self, owner_urn: str, annotations: Annotations | None) -> None:
        if not annotations:
            return
        for ordinal, ann in enumerate(annotations):
            local_idx = len(self.ann_rows)
            self.ann_rows.append([owner_urn, ordinal, ann.id, ann.title, ann.type, ann.url])
            if ann.text:
                for lang in ann.text:
                    self.text_rows.append((local_idx, lang, ann.text[lang]))

    def flush(self, conn: duckdb.DuckDBPyConnection) -> None:
        if not self.ann_rows:
            return
        n = len(self.ann_rows)
        id_rows = conn.execute("SELECT nextval('annotation_id_seq') FROM range(?)", [n]).fetchall()
        ids = [r[0] for r in id_rows]

        full_ann_rows = [[ids[i], *row] for i, row in enumerate(self.ann_rows)]
        _execute_bulk_insert(
            conn,
            "annotation",
            ["id", "owner_urn", "ordinal", "annotation_id", "title", "annotation_type", "url"],
            full_ann_rows,
        )

        if self.text_rows:
            text_rows = [[ids[idx], lang, text] for idx, lang, text in self.text_rows]
            _execute_bulk_insert(
                conn,
                "annotation_text",
                ["annotation_id", "lang", "text"],
                text_rows,
            )

        self.ann_rows.clear()
        self.text_rows.clear()


def _put_annotations(
    conn: duckdb.DuckDBPyConnection,
    owner_urn: str,
    annotations: Annotations | None,
) -> None:
    """Insert annotation + annotation_text rows for one owner.

    For artefacts with many annotated child items (e.g. codelists), prefer
    building an :class:`_AnnotationBatch` directly and calling ``flush``
    once at the end of the write — that avoids per-owner roundtrips.
    """
    batch = _AnnotationBatch()
    batch.add(owner_urn, annotations)
    batch.flush(conn)


def _put_artefact_text_and_annotations(
    conn: duckdb.DuckDBPyConnection,
    urn: str,
    artefact: Any,
    batch: _AnnotationBatch | None = None,
) -> None:
    """Write localized_text and annotations for an artefact.

    If ``batch`` is provided, annotations are queued on it (caller flushes);
    otherwise they are flushed immediately.
    """
    _put_localized_text(conn, urn, "name", getattr(artefact, "name", None))
    _put_localized_text(conn, urn, "description", getattr(artefact, "description", None))
    anns = getattr(artefact, "annotations", None)
    if batch is not None:
        batch.add(urn, anns)
    else:
        _put_annotations(conn, urn, anns)


# ── Reference graph ─────────────────────────────────────────────────────


def _put_refs(
    conn: duckdb.DuckDBPyConnection,
    refs: list[tuple[str, str, str, int | None]],
) -> None:
    """Insert artefact_ref rows."""
    if not refs:
        return
    for source_urn, target_urn, role, ordinal in refs:
        conn.execute(
            """
            INSERT OR REPLACE INTO artefact_ref (source_urn, target_urn, role, ordinal)
            VALUES (?, ?, ?, ?)
            """,
            [source_urn, target_urn, role, ordinal],
        )


# ── Hierarchy precomputation ────────────────────────────────────────────


def _compute_hierarchy(
    items: list[tuple[str, str | None]],
) -> dict[str, tuple[int, list[str]]]:
    """Compute depth and ancestor_ids from (id, parent_id) pairs.

    Returns {id: (depth, ancestor_ids)} where ancestor_ids is root-first.
    """
    result: dict[str, tuple[int, list[str]]] = {}

    parent_map = dict(items)

    def walk(item_id: str) -> tuple[int, list[str]]:
        if item_id in result:
            return result[item_id]
        parent_id = parent_map.get(item_id)
        if parent_id is None:
            result[item_id] = (0, [])
        else:
            parent_depth, parent_ancestors = walk(parent_id)
            result[item_id] = (parent_depth + 1, [*parent_ancestors, parent_id])
        return result[item_id]

    for item_id, _ in items:
        walk(item_id)
    return result


# ── Item URN helpers ────────────────────────────────────────────────────


def _make_item_urn(
    artefact: Any,
    artefact_urn: str,
    item_class: str,
    item_id: str,
) -> str:
    """Build a synthetic item URN.

    E.g. urn:sdmx:org.sdmx.infomodel.codelist.Code=SDMX:CL_FREQ(1.0).A
    """
    # Replace the artefact class in the URN with the item class and append item_id
    # urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_FREQ(1.0)
    # → urn:sdmx:org.sdmx.infomodel.codelist.Code=SDMX:CL_FREQ(1.0).A
    parsed = SdmxUrn.parse(artefact_urn)
    item_urn = SdmxUrn.make(
        type(artefact),
        package=parsed.package,
        artefact_class=item_class,
        agency=parsed.agency,
        id=parsed.id,
        version=parsed.version,
        item_id=item_id,
    )
    return str(item_urn)


# ── Delete helpers ──────────────────────────────────────────────────────


def _item_owner_urn_pattern(artefact_urn: str) -> str:
    """LIKE pattern matching item URNs derived from an artefact URN.

    Item URNs (codes, concepts, DSD components, hierarchy nodes, …) reuse
    the parent artefact's ``agency:id(version)`` suffix and append
    ``.item_id``. Matching ``%=<suffix>.%`` catches them all regardless of
    package or item class.
    """
    _, _, suffix = artefact_urn.partition("=")
    return f"%={suffix}.%"


def _delete_artefact_cascade(conn: duckdb.DuckDBPyConnection, urn: str) -> None:
    """Delete all rows associated with an artefact URN across all tables."""
    p = [urn]
    # Item tables (keyed by parent URN)
    conn.execute("DELETE FROM code WHERE codelist_urn = ?", p)
    conn.execute("DELETE FROM concept WHERE scheme_urn = ?", p)
    conn.execute("DELETE FROM category WHERE scheme_urn = ?", p)
    conn.execute("DELETE FROM hierarchy_node WHERE hierarchy_urn = ?", p)
    conn.execute("DELETE FROM agency WHERE scheme_urn = ?", p)
    conn.execute("DELETE FROM data_provider WHERE scheme_urn = ?", p)
    # Contact cleanup for agencies
    conn.execute(
        "DELETE FROM agency_contact WHERE agency_urn IN (SELECT agency_urn FROM agency WHERE scheme_urn = ?)", p
    )
    # Structure tables
    conn.execute("DELETE FROM dsd_component WHERE dsd_urn = ?", p)
    conn.execute("DELETE FROM dsd_group WHERE dsd_urn = ?", p)
    conn.execute("DELETE FROM group_dimension WHERE dsd_urn = ?", p)
    # Extension tables
    conn.execute("DELETE FROM dataflow WHERE urn = ?", p)
    conn.execute("DELETE FROM provision_agreement WHERE urn = ?", p)
    conn.execute("DELETE FROM categorisation WHERE urn = ?", p)
    conn.execute("DELETE FROM hierarchy_meta WHERE urn = ?", p)
    # Constraint tables
    conn.execute("DELETE FROM region_key_value WHERE constraint_urn = ?", p)
    conn.execute("DELETE FROM cube_region WHERE constraint_urn = ?", p)
    conn.execute("DELETE FROM data_constraint WHERE urn = ?", p)
    # Mapping tables
    conn.execute("DELETE FROM code_map_entry WHERE structure_set_urn = ?", p)
    conn.execute("DELETE FROM codelist_map WHERE structure_set_urn = ?", p)
    conn.execute("DELETE FROM structure_set WHERE urn = ?", p)
    # MSD / Metadataflow / MetadataSet tables
    conn.execute("DELETE FROM metadata_attribute WHERE msd_urn = ?", p)
    conn.execute("DELETE FROM metadata_structure WHERE urn = ?", p)
    conn.execute("DELETE FROM metadataflow WHERE urn = ?", p)
    conn.execute("DELETE FROM metadata_value WHERE set_urn = ?", p)
    conn.execute("DELETE FROM metadata_target WHERE set_urn = ?", p)
    conn.execute("DELETE FROM metadata_set WHERE urn = ?", p)
    # DataflowBinding extension table
    conn.execute("DELETE FROM dataflow_binding WHERE urn = ?", p)
    # Text and annotations (use owner_urn which may be artefact or any
    # item URN derived from it — codes, concepts, DSD components, etc.).
    # Item URNs share the artefact's "agency:id(version)" suffix and append
    # ".item_id"; match both with a LIKE on the suffix so re-ingesting an
    # artefact does not leave orphan annotation rows for its child items.
    item_pattern = _item_owner_urn_pattern(urn)
    text_args = [urn, item_pattern]
    conn.execute("DELETE FROM localized_text WHERE owner_urn = ? OR owner_urn LIKE ?", text_args)
    conn.execute(
        """
        DELETE FROM annotation_text
        WHERE annotation_id IN (
            SELECT id FROM annotation WHERE owner_urn = ? OR owner_urn LIKE ?
        )
        """,
        text_args,
    )
    conn.execute("DELETE FROM annotation WHERE owner_urn = ? OR owner_urn LIKE ?", text_args)
    # Reference graph
    conn.execute("DELETE FROM artefact_ref WHERE source_urn = ?", p)


# ── Public writers ──────────────────────────────────────────────────────


def put_codelist(conn: duckdb.DuckDBPyConnection, cl: Codelist, *, source_registry: str | None = None) -> None:
    """Write a Codelist to artefact + localized_text + code tables."""
    urn = str(artefact_urn(cl))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "Codelist", cl, source_registry=source_registry)
    ann_batch = _AnnotationBatch()
    _put_artefact_text_and_annotations(conn, urn, cl, ann_batch)

    refs: list[tuple[str, str, str, int | None]] = []

    if cl.codes:
        # Compute hierarchy
        hierarchy = _compute_hierarchy([(c.id, c.parent_id) for c in cl.codes])

        all_rows: list[list[Any]] = []
        for position, code in enumerate(cl.codes):
            depth, ancestors = hierarchy.get(code.id, (0, []))
            code_urn = _make_item_urn(cl, urn, "Code", code.id)
            row: list[Any] = [
                code_urn,
                urn,
                code.id,
                code.parent_id,
                position,
                _istring_to_map(code.name),
                _istring_to_map(code.description),
                depth,
                ancestors,
            ]
            all_rows.append(row)
            ann_batch.add(code_urn, code.annotations)

        _execute_bulk_insert(
            conn,
            "code",
            [
                "code_urn",
                "codelist_urn",
                "code_id",
                "parent_id",
                "position",
                "name",
                "description",
                "depth",
                "ancestor_ids",
            ],
            all_rows,
        )

    ann_batch.flush(conn)
    _put_refs(conn, refs)


def _serialize_component(
    dsd_urn: str,
    position: int,
    comp_type: str,
    comp: Any,
    refs: list[tuple[str, str, str, int | None]],
) -> list[Any]:
    """Serialize one DSD component to a row + collect refs."""
    concept_ref = getattr(comp, "concept", None)
    concept_urn_str = str(concept_ref.urn) if isinstance(concept_ref, Ref) else None

    rep = getattr(comp, "representation", None)
    repr_kind = codelist_urn = text_type = None
    min_length = max_length = min_value = max_value = None
    decimals = pattern = is_sequence = start_value = end_value = None

    if isinstance(rep, Ref):
        repr_kind = "enumeration"
        codelist_urn = str(rep.urn)
        refs.append((dsd_urn, codelist_urn, "enumeration", position))
    elif isinstance(rep, Facet):
        repr_kind = "facet"
        text_type = str(rep.type) if rep.type is not None else None
        min_length, max_length = rep.min_length, rep.max_length
        min_value, max_value = rep.min_value, rep.max_value
        decimals, pattern, is_sequence = rep.decimals, rep.pattern, rep.is_sequence
        start_value, end_value = rep.start_value, rep.end_value

    if concept_urn_str:
        refs.append((dsd_urn, concept_urn_str, "concept_identity", position))

    usage_status = getattr(comp, "usage", None)
    attachment = getattr(comp, "attachment", None)
    attachment_str = attachment.value if attachment is not None else None

    measure_usage = None
    if comp_type == "Measure":
        usage_status = None

    return [
        dsd_urn,
        comp.id,
        comp_type,
        position,
        concept_urn_str,
        repr_kind,
        codelist_urn,
        text_type,
        min_length,
        max_length,
        min_value,
        max_value,
        decimals,
        pattern,
        is_sequence,
        start_value,
        end_value,
        usage_status,
        attachment_str,
        None,
        measure_usage,
    ]


_DSD_COMPONENT_COLS = [
    "dsd_urn",
    "component_id",
    "component_type",
    "position",
    "concept_urn",
    "repr_kind",
    "codelist_urn",
    "text_type",
    "min_length",
    "max_length",
    "min_value",
    "max_value",
    "decimals",
    "pattern",
    "is_sequence",
    "start_value",
    "end_value",
    "usage_status",
    "attachment_level",
    "attachment_group",
    "measure_usage",
]


def put_data_structure(
    conn: duckdb.DuckDBPyConnection, dsd: DataStructure, *, source_registry: str | None = None
) -> None:
    """Write a DataStructure to artefact + dsd_component + groups."""
    urn = str(artefact_urn(dsd))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "DataStructure", dsd, source_registry=source_registry)
    ann_batch = _AnnotationBatch()
    _put_artefact_text_and_annotations(conn, urn, dsd, ann_batch)

    components: list[tuple[str, Any]] = [("Dimension", dim) for dim in dsd.dimensions]
    if dsd.time_dimension is not None:
        components.append(("TimeDimension", dsd.time_dimension))
    if hasattr(dsd, "measure_dimension") and dsd.measure_dimension is not None:
        components.append(("MeasureDimension", dsd.measure_dimension))
    components.extend(("Attribute", attr) for attr in dsd.attributes)
    components.extend(("Measure", m) for m in dsd.measures)

    refs: list[tuple[str, str, str, int | None]] = []
    comp_rows: list[list[Any]] = []
    for pos, (comp_type, comp) in enumerate(components):
        comp_rows.append(_serialize_component(urn, pos, comp_type, comp, refs))
        # Component owner URN follows the same item-URN convention as Codes
        # and Concepts (`<dsd_urn-with-component-class>.<component_id>`).
        comp_urn = _make_item_urn(dsd, urn, comp_type, comp.id)
        ann_batch.add(comp_urn, getattr(comp, "annotations", None))

    if comp_rows:
        _execute_bulk_insert(conn, "dsd_component", _DSD_COMPONENT_COLS, comp_rows)
    ann_batch.flush(conn)

    if dsd.groups:
        for group in dsd.groups:
            conn.execute(
                "INSERT INTO dsd_group (dsd_urn, group_id) VALUES (?, ?)",
                [urn, group.id],
            )
            for dim_id in group.dimension_ids:
                conn.execute(
                    "INSERT INTO group_dimension (dsd_urn, group_id, dimension_id) VALUES (?, ?, ?)",
                    [urn, group.id, dim_id],
                )

    _put_refs(conn, refs)


def put_dataflow(conn: duckdb.DuckDBPyConnection, flow: Dataflow, *, source_registry: str | None = None) -> None:
    """Write a Dataflow to artefact + dataflow extension."""
    urn = str(artefact_urn(flow))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "Dataflow", flow, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, flow)

    dsd_urn = str(flow.structure.urn) if flow.structure is not None else ""
    conn.execute(
        "INSERT INTO dataflow (urn, dsd_urn) VALUES (?, ?)",
        [urn, dsd_urn],
    )

    refs: list[tuple[str, str, str, int | None]] = []
    if flow.structure is not None:
        refs.append((urn, dsd_urn, "structure", None))
    _put_refs(conn, refs)


def put_concept_scheme(
    conn: duckdb.DuckDBPyConnection, cs: ConceptScheme, *, source_registry: str | None = None
) -> None:
    """Write a ConceptScheme to artefact + concept table."""
    urn = str(artefact_urn(cs))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "ConceptScheme", cs, source_registry=source_registry)
    ann_batch = _AnnotationBatch()
    _put_artefact_text_and_annotations(conn, urn, cs, ann_batch)

    refs: list[tuple[str, str, str, int | None]] = []

    if cs.concepts:
        all_rows: list[list[Any]] = []
        for position, concept in enumerate(cs.concepts):
            concept_urn_str = _make_item_urn(cs, urn, "Concept", concept.id)

            repr_kind = None
            repr_codelist_urn = None
            repr_text_type = None
            repr_min_length = None
            repr_max_length = None

            rep = concept.core_representation
            if isinstance(rep, Ref):
                repr_kind = "enumeration"
                repr_codelist_urn = str(rep.urn)
            elif isinstance(rep, Facet):
                repr_kind = "facet"
                repr_text_type = str(rep.type) if rep.type is not None else None
                repr_min_length = rep.min_length
                repr_max_length = rep.max_length

            all_rows.append(
                [
                    concept_urn_str,
                    urn,
                    concept.id,
                    None,
                    position,
                    _istring_to_map(concept.name),
                    _istring_to_map(concept.description),
                    repr_kind,
                    repr_codelist_urn,
                    repr_text_type,
                    repr_min_length,
                    repr_max_length,
                ]
            )
            ann_batch.add(concept_urn_str, concept.annotations)

        _execute_bulk_insert(
            conn,
            "concept",
            [
                "concept_urn",
                "scheme_urn",
                "concept_id",
                "parent_id",
                "position",
                "name",
                "description",
                "repr_kind",
                "repr_codelist_urn",
                "repr_text_type",
                "repr_min_length",
                "repr_max_length",
            ],
            all_rows,
        )

    ann_batch.flush(conn)
    _put_refs(conn, refs)


def put_hierarchy(conn: duckdb.DuckDBPyConnection, h: Hierarchy, *, source_registry: str | None = None) -> None:
    """Write a Hierarchy to artefact + hierarchy_meta + hierarchy_node."""
    urn = str(artefact_urn(h))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "Hierarchy", h, source_registry=source_registry)
    ann_batch = _AnnotationBatch()
    _put_artefact_text_and_annotations(conn, urn, h, ann_batch)

    conn.execute(
        "INSERT INTO hierarchy_meta (urn, is_leveled) VALUES (?, ?)",
        [urn, h.is_leveled],
    )

    # SDMX 3.1: persist Level definitions
    if h.levels:
        level_rows: list[list[Any]] = []
        for idx, lv in enumerate(h.levels):
            level_rows.append(
                [
                    urn,
                    lv.id,
                    idx,
                    _istring_to_map(lv.name),
                    _istring_to_map(lv.description),
                ]
            )
        _execute_bulk_insert(
            conn,
            "hierarchy_level",
            ["hierarchy_urn", "level_id", "level_idx", "name", "description"],
            level_rows,
        )

    # Flatten tree into rows
    flat: list[tuple[str, str | None, HierarchicalCode]] = []
    _flatten_hcodes(h.tree, None, flat)

    if flat:
        hierarchy_items = [(node.id, parent_id) for node_id_unused, parent_id, node in flat for node in [node]]
        # Re-extract properly
        hierarchy_items = [(node.id, parent_id) for _, parent_id, node in flat]
        hierarchy_data = _compute_hierarchy(hierarchy_items)

        refs: list[tuple[str, str, str, int | None]] = []
        all_rows: list[list[Any]] = []

        for position, (_, parent_id, node) in enumerate(flat):
            node_urn = _make_item_urn(h, urn, "HierarchicalCode", node.id)
            code_urn = str(node.code.urn) if isinstance(node.code, Ref) else None
            depth, ancestors = hierarchy_data.get(node.id, (0, []))
            level_id = node.level.id if node.level is not None else None

            all_rows.append(
                [
                    node_urn,
                    urn,
                    node.id,
                    parent_id,
                    code_urn,
                    level_id,
                    _istring_to_map(node.name),
                    _istring_to_map(node.description),
                    node.valid_from,
                    node.valid_to,
                    depth,
                    ancestors,
                ]
            )

            if code_urn:
                refs.append((urn, code_urn, "code", position))

            ann_batch.add(node_urn, node.annotations)

        _execute_bulk_insert(
            conn,
            "hierarchy_node",
            [
                "node_urn",
                "hierarchy_urn",
                "node_id",
                "parent_node_id",
                "code_urn",
                "level_id",
                "name",
                "description",
                "valid_from",
                "valid_to",
                "depth",
                "ancestor_ids",
            ],
            all_rows,
        )
        _put_refs(conn, refs)

    ann_batch.flush(conn)


def _flatten_hcodes(
    nodes: Any,
    parent_id: str | None,
    result: list[tuple[str, str | None, HierarchicalCode]],
) -> None:
    """Recursively flatten HierarchicalCode tree into (id, parent_id, node) tuples."""
    for node in nodes:
        result.append((node.id, parent_id, node))
        if node.children:
            _flatten_hcodes(node.children, node.id, result)


def put_data_constraint(
    conn: duckdb.DuckDBPyConnection, cc: "DataConstraint", *, source_registry: str | None = None
) -> None:
    """Write a DataConstraint to relational tables."""
    urn = str(artefact_urn(cc))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "DataConstraint", cc, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, cc)

    conn.execute(
        "INSERT INTO data_constraint (urn, constraint_type) VALUES (?, ?)",
        [urn, cc.constraint_type],
    )

    refs: list[tuple[str, str, str, int | None]] = []
    attachment = cc.attachment
    if attachment.dataflow is not None:
        refs.append((urn, str(attachment.dataflow.urn), "attachment_dataflow", None))
    if attachment.data_structure is not None:
        refs.append((urn, str(attachment.data_structure.urn), "attachment_dsd", None))
    if attachment.provision_agreement is not None:
        refs.append((urn, str(attachment.provision_agreement.urn), "attachment_provision", None))

    for region_idx, region in enumerate(cc.regions):
        conn.execute(
            "INSERT INTO cube_region (constraint_urn, region_idx, is_included) VALUES (?, ?, ?)",
            [urn, region_idx, region.include],
        )
        rkv_rows = [[urn, region_idx, kv.dimension_id, value] for kv in region.keys for value in kv.values]
        if rkv_rows:
            _execute_bulk_insert(
                conn,
                "region_key_value",
                ["constraint_urn", "region_idx", "component_id", "value"],
                rkv_rows,
            )

    _put_refs(conn, refs)


def put_category_scheme(
    conn: duckdb.DuckDBPyConnection, cs: "CategoryScheme", *, source_registry: str | None = None
) -> None:
    """Write a CategoryScheme to artefact + category table."""
    urn = str(artefact_urn(cs))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "CategoryScheme", cs, source_registry=source_registry)
    ann_batch = _AnnotationBatch()
    _put_artefact_text_and_annotations(conn, urn, cs, ann_batch)

    # Flatten category tree
    flat: list[tuple[str, str | None, Any]] = []
    _flatten_categories(cs.categories, None, flat)

    if flat:
        hierarchy_data = _compute_hierarchy([(cat.id, parent_id) for _, parent_id, cat in flat])

        all_rows: list[list[Any]] = []
        for position, (_, parent_id, cat) in enumerate(flat):
            cat_urn = _make_item_urn(cs, urn, "Category", cat.id)
            depth, ancestors = hierarchy_data.get(cat.id, (0, []))
            all_rows.append(
                [
                    cat_urn,
                    urn,
                    cat.id,
                    parent_id,
                    position,
                    _istring_to_map(cat.name),
                    _istring_to_map(cat.description),
                    depth,
                    ancestors,
                ]
            )
            ann_batch.add(cat_urn, cat.annotations)

        _execute_bulk_insert(
            conn,
            "category",
            [
                "category_urn",
                "scheme_urn",
                "category_id",
                "parent_id",
                "position",
                "name",
                "description",
                "depth",
                "ancestor_ids",
            ],
            all_rows,
        )

    ann_batch.flush(conn)


def _flatten_categories(
    categories: Any,
    parent_id: str | None,
    result: list[tuple[str, str | None, Any]],
) -> None:
    """Recursively flatten Category tree."""
    for cat in categories:
        result.append((cat.id, parent_id, cat))
        if cat.categories:
            _flatten_categories(cat.categories, cat.id, result)


def put_categorisation(
    conn: duckdb.DuckDBPyConnection, cat: "Categorisation", *, source_registry: str | None = None
) -> None:
    """Write a Categorisation to artefact + categorisation extension."""
    urn = str(artefact_urn(cat))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "Categorisation", cat, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, cat)

    source_urn = str(cat.source.urn) if cat.source is not None else ""
    target_urn = str(cat.target.urn) if cat.target is not None else ""
    conn.execute(
        "INSERT INTO categorisation (urn, source_urn, target_urn) VALUES (?, ?, ?)",
        [urn, source_urn, target_urn],
    )

    refs: list[tuple[str, str, str, int | None]] = []
    if cat.source is not None:
        refs.append((urn, source_urn, "source", None))
    if cat.target is not None:
        refs.append((urn, target_urn, "target", None))
    _put_refs(conn, refs)


def put_provision_agreement(
    conn: duckdb.DuckDBPyConnection, pa: "ProvisionAgreement", *, source_registry: str | None = None
) -> None:
    """Write a ProvisionAgreement to artefact + provision_agreement extension."""
    urn = str(artefact_urn(pa))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "ProvisionAgreement", pa, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, pa)

    dataflow_urn = str(pa.dataflow.urn) if pa.dataflow is not None else ""
    dp_urn = str(pa.data_provider.urn) if pa.data_provider is not None else ""
    conn.execute(
        "INSERT INTO provision_agreement (urn, dataflow_urn, data_provider_urn) VALUES (?, ?, ?)",
        [urn, dataflow_urn, dp_urn],
    )

    refs: list[tuple[str, str, str, int | None]] = []
    if pa.dataflow is not None:
        refs.append((urn, dataflow_urn, "dataflow", None))
    if pa.data_provider is not None:
        refs.append((urn, dp_urn, "data_provider", None))
    _put_refs(conn, refs)


def put_agency_scheme(
    conn: duckdb.DuckDBPyConnection, ascheme: "AgencyScheme", *, source_registry: str | None = None
) -> None:
    """Write an AgencyScheme to artefact + agency + agency_contact tables."""
    urn = str(artefact_urn(ascheme))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "AgencyScheme", ascheme, source_registry=source_registry)
    ann_batch = _AnnotationBatch()
    _put_artefact_text_and_annotations(conn, urn, ascheme, ann_batch)

    if ascheme.agencies:
        all_rows: list[list[Any]] = []
        for ag in ascheme.agencies:
            ag_urn = _make_item_urn(ascheme, urn, "Agency", ag.id)
            parent_id = ag.parent.id if ag.parent is not None else None
            all_rows.append(
                [
                    ag_urn,
                    urn,
                    ag.id,
                    parent_id,
                    _istring_to_map(ag.name),
                    _istring_to_map(ag.description),
                ]
            )

            # Contacts
            for ordinal, contact in enumerate(ag.contacts):
                conn.execute(
                    """
                    INSERT INTO agency_contact
                        (agency_urn, ordinal, contact_name, department, role, phones, uris, emails)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        ag_urn,
                        ordinal,
                        _istring_to_map(contact.name),
                        _istring_to_map(contact.department),
                        _istring_to_map(contact.role),
                        list(contact.phones),
                        list(contact.uris),
                        list(contact.emails),
                    ],
                )

            ann_batch.add(ag_urn, ag.annotations)

        _execute_bulk_insert(
            conn,
            "agency",
            ["agency_urn", "scheme_urn", "agency_id", "parent_id", "name", "description"],
            all_rows,
        )

    ann_batch.flush(conn)


def put_data_provider_scheme(
    conn: duckdb.DuckDBPyConnection, dps: "DataProviderScheme", *, source_registry: str | None = None
) -> None:
    """Write a DataProviderScheme to artefact + data_provider table."""
    urn = str(artefact_urn(dps))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "DataProviderScheme", dps, source_registry=source_registry)
    ann_batch = _AnnotationBatch()
    _put_artefact_text_and_annotations(conn, urn, dps, ann_batch)

    if dps.providers:
        all_rows: list[list[Any]] = []
        for provider in dps.providers:
            p_urn = _make_item_urn(dps, urn, "DataProvider", provider.id)
            all_rows.append(
                [
                    p_urn,
                    urn,
                    provider.id,
                    _istring_to_map(provider.name),
                    _istring_to_map(provider.description),
                ]
            )
            ann_batch.add(p_urn, provider.annotations)

        _execute_bulk_insert(
            conn,
            "data_provider",
            ["provider_urn", "scheme_urn", "provider_id", "name", "description"],
            all_rows,
        )

    ann_batch.flush(conn)


def put_structure_set(
    conn: duckdb.DuckDBPyConnection, ss: "StructureSet", *, source_registry: str | None = None
) -> None:
    """Write a StructureSet to artefact + codelist_map + code_map_entry tables."""
    urn = str(artefact_urn(ss))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "StructureSet", ss, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, ss)

    conn.execute("INSERT INTO structure_set (urn) VALUES (?)", [urn])

    refs: list[tuple[str, str, str, int | None]] = []
    for cl_map in ss.codelist_maps:
        source_cl_urn = str(cl_map.source.urn) if cl_map.source is not None else ""
        target_cl_urn = str(cl_map.target.urn) if cl_map.target is not None else ""
        conn.execute(
            """
            INSERT INTO codelist_map (id, structure_set_urn, source_codelist_urn, target_codelist_urn)
            VALUES (?, ?, ?, ?)
            """,
            [cl_map.id, urn, source_cl_urn, target_cl_urn],
        )
        if cl_map.source is not None:
            refs.append((urn, source_cl_urn, "source_codelist", None))
        if cl_map.target is not None:
            refs.append((urn, target_cl_urn, "target_codelist", None))

        entry_rows = [[urn, cl_map.id, m.source_id, m.target_id] for m in cl_map.maps]
        if entry_rows:
            _execute_bulk_insert(
                conn,
                "code_map_entry",
                ["structure_set_urn", "map_id", "source_code_id", "target_code_id"],
                entry_rows,
            )

    _put_refs(conn, refs)


# ── MetadataStructure / MetadataSet writers ─────────────────────────────


def _flatten_metadata_attributes(
    attributes: Any,
    parent_id: str | None,
    result: list[tuple[str | None, MetadataAttribute]],
) -> None:
    """Flatten a MetadataAttribute tree into (parent_id, attribute) pairs."""
    for attr in attributes:
        result.append((parent_id, attr))
        if attr.children:
            _flatten_metadata_attributes(attr.children, attr.id, result)


_METADATA_ATTRIBUTE_COLS = [
    "attribute_urn",
    "msd_urn",
    "attribute_id",
    "parent_attribute_id",
    "position",
    "concept_urn",
    "repr_kind",
    "codelist_urn",
    "text_type",
    "min_length",
    "max_length",
    "min_value",
    "max_value",
    "decimals",
    "pattern",
    "is_sequence",
    "start_value",
    "end_value",
    "min_occurs",
    "max_occurs",
    "is_presentational",
    "depth",
    "ancestor_ids",
]


def put_metadata_structure(
    conn: duckdb.DuckDBPyConnection, msd: MetadataStructure, *, source_registry: str | None = None
) -> None:
    """Write a MetadataStructure to artefact + metadata_structure + metadata_attribute tables."""
    urn = str(artefact_urn(msd))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "MetadataStructure", msd, source_registry=source_registry)
    ann_batch = _AnnotationBatch()
    _put_artefact_text_and_annotations(conn, urn, msd, ann_batch)

    conn.execute("INSERT INTO metadata_structure (urn) VALUES (?)", [urn])

    refs: list[tuple[str, str, str, int | None]] = []

    flat: list[tuple[str | None, MetadataAttribute]] = []
    _flatten_metadata_attributes(msd.attributes, None, flat)

    if flat:
        hierarchy = _compute_hierarchy([(attr.id, parent_id) for parent_id, attr in flat])

        rows: list[list[Any]] = []
        for position, (parent_id, attr) in enumerate(flat):
            attr_urn = _make_item_urn(msd, urn, "MetadataAttribute", attr.id)
            depth, ancestors = hierarchy.get(attr.id, (0, []))

            concept_urn = str(attr.concept.urn) if isinstance(attr.concept, Ref) else None
            if concept_urn:
                refs.append((urn, concept_urn, "concept_identity", position))

            rep = attr.representation
            repr_kind = codelist_urn = text_type = None
            min_length = max_length = min_value = max_value = None
            decimals = pattern = is_sequence = start_value = end_value = None

            if isinstance(rep, Ref):
                repr_kind = "enumeration"
                codelist_urn = str(rep.urn)
                refs.append((urn, codelist_urn, "enumeration", position))
            elif isinstance(rep, Facet):
                repr_kind = "facet"
                text_type = str(rep.type) if rep.type is not None else None
                min_length, max_length = rep.min_length, rep.max_length
                min_value, max_value = rep.min_value, rep.max_value
                decimals, pattern, is_sequence = rep.decimals, rep.pattern, rep.is_sequence
                start_value, end_value = rep.start_value, rep.end_value

            rows.append(
                [
                    attr_urn,
                    urn,
                    attr.id,
                    parent_id,
                    position,
                    concept_urn,
                    repr_kind,
                    codelist_urn,
                    text_type,
                    min_length,
                    max_length,
                    min_value,
                    max_value,
                    decimals,
                    pattern,
                    is_sequence,
                    start_value,
                    end_value,
                    attr.min_occurs,
                    attr.max_occurs,
                    attr.is_presentational,
                    depth,
                    ancestors,
                ]
            )
            ann_batch.add(attr_urn, attr.annotations)

        _execute_bulk_insert(conn, "metadata_attribute", _METADATA_ATTRIBUTE_COLS, rows)

    ann_batch.flush(conn)
    _put_refs(conn, refs)


def _serialize_reported_value(v: Any) -> tuple[str | None, str | None, dict[str, str]]:
    """Return (value_kind, scalar_text, i18n_map) for one ReportedAttribute.value.

    None → (None, None, {})
    InternationalString → ("i18n", None, {lang: text, ...})
    str/int/float/bool → ("scalar", str(v), {})
    """
    if v is None:
        return None, None, {}
    if isinstance(v, InternationalString):
        return "i18n", None, _istring_to_map(v)
    return "scalar", str(v), {}


def _collect_reported_values(
    attributes: Any,
    prefix: str,
    set_urn: str,
    sibling_counters: dict[str, int],
    value_rows: list[list[Any]],
) -> None:
    """Walk a ReportedAttribute tree, emitting metadata_value rows.

    Repetition (multiple sibling ReportedAttributes with the same id) is
    encoded by ``sibling_index`` — counted per (parent_path, attribute_id).
    """
    for attr in attributes:
        sibling_key = f"{prefix}|{attr.id}"
        idx = sibling_counters.get(sibling_key, 0)
        sibling_counters[sibling_key] = idx + 1
        # Use bracketed sibling index in the path to keep nested children
        # under the right repeated parent unambiguously.
        path = f"{prefix}.{attr.id}" if prefix else attr.id
        if idx > 0:
            path = f"{path}[{idx}]"

        kind, scalar, i18n = _serialize_reported_value(attr.value)
        value_rows.append([set_urn, path, idx, kind, scalar, i18n])

        if attr.children:
            _collect_reported_values(attr.children, path, set_urn, sibling_counters, value_rows)


_METADATA_VALUE_COLS = [
    "set_urn",
    "attribute_path",
    "sibling_index",
    "value_kind",
    "scalar",
    "i18n",
]


def put_metadataflow(conn: duckdb.DuckDBPyConnection, mdf: Metadataflow, *, source_registry: str | None = None) -> None:
    """Write a Metadataflow to artefact + metadataflow extension."""
    urn = str(artefact_urn(mdf))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "Metadataflow", mdf, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, mdf)

    msd_urn = str(mdf.structure.urn) if mdf.structure is not None else ""
    conn.execute(
        "INSERT INTO metadataflow (urn, msd_urn) VALUES (?, ?)",
        [urn, msd_urn],
    )

    refs: list[tuple[str, str, str, int | None]] = []
    if mdf.structure is not None:
        refs.append((urn, msd_urn, "structure", None))
    _put_refs(conn, refs)


def put_metadata_set(conn: duckdb.DuckDBPyConnection, ms: MetadataSet, *, source_registry: str | None = None) -> None:
    """Write a MetadataSet plus its targets and attribute tree."""
    urn = str(artefact_urn(ms))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "MetadataSet", ms, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, ms)

    structure_urn = str(ms.structure.urn)
    structure_kind = ms.structure.urn.artefact_class
    conn.execute(
        "INSERT INTO metadata_set (urn, structure_urn, structure_kind) VALUES (?, ?, ?)",
        [urn, structure_urn, structure_kind],
    )

    refs: list[tuple[str, str, str, int | None]] = [(urn, structure_urn, "structure", None)]

    target_rows: list[list[Any]] = []
    for ordinal, target in enumerate(ms.targets):
        target_urn_str = str(target.urn)
        target_rows.append([urn, ordinal, target_urn_str])
        # One ref per (set, target) — ordinal disambiguates the artefact_ref PK
        # when a set lists the same target URN twice (rare but legal).
        refs.append((urn, target_urn_str, f"target[{ordinal}]", ordinal))

    if target_rows:
        _execute_bulk_insert(conn, "metadata_target", ["set_urn", "ordinal", "target_urn"], target_rows)

    value_rows: list[list[Any]] = []
    _collect_reported_values(ms.attributes, "", urn, {}, value_rows)
    if value_rows:
        _execute_bulk_insert(conn, "metadata_value", _METADATA_VALUE_COLS, value_rows)

    _put_refs(conn, refs)


# ── DataflowBinding writer ──────────────────────────────────────────────


def put_dataflow_binding(
    conn: duckdb.DuckDBPyConnection, binding: DataflowBinding, *, source_registry: str | None = None
) -> None:
    """Write a DataflowBinding to artefact spine + dataflow_binding tables."""
    urn = str(artefact_urn(binding))

    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, "DataflowBinding", binding, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, binding)

    conn.execute(
        """
        INSERT INTO dataflow_binding (
            urn, dataflow_urn, table_location, partition_layout,
            dimension_column_map, measure_column_map, attribute_column_map,
            structural_version, binding_source_registry,
            materialized_at, bound_at, series_attributes_location
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            urn,
            str(binding.dataflow.urn),
            binding.table_location,
            list(binding.partition_layout),
            dict(binding.dimension_column_map),
            dict(binding.measure_column_map),
            dict(binding.attribute_column_map),
            binding.structural_version,
            binding.source_registry,
            binding.materialized_at,
            binding.bound_at,
            binding.series_attributes_location,
        ],
    )

    # Reference to the bound dataflow — federation-friendly outgoing edge.
    _put_refs(conn, [(urn, str(binding.dataflow.urn), "dataflow", None)])


# ── Dispatch ────────────────────────────────────────────────────────────

_WRITER_DISPATCH: dict[type, Any] = {
    Codelist: put_codelist,
    DataStructure: put_data_structure,
    Dataflow: put_dataflow,
    ConceptScheme: put_concept_scheme,
    Hierarchy: put_hierarchy,
    DataConstraint: put_data_constraint,
    CategoryScheme: put_category_scheme,
    Categorisation: put_categorisation,
    ProvisionAgreement: put_provision_agreement,
    AgencyScheme: put_agency_scheme,
    DataProviderScheme: put_data_provider_scheme,
    StructureSet: put_structure_set,
    MetadataStructure: put_metadata_structure,
    Metadataflow: put_metadataflow,
    MetadataSet: put_metadata_set,
    DataflowBinding: put_dataflow_binding,
}


def put_artefact(conn: duckdb.DuckDBPyConnection, artefact: Any, *, source_registry: str | None = None) -> None:
    """Write any supported artefact, dispatching to the appropriate writer."""
    if not isinstance(artefact, HasUrn):
        msg = (
            f"{type(artefact).__name__} does not satisfy HasUrn — "
            "it needs sdmx_package, sdmx_class, agency_id, id, version"
        )
        raise TypeError(msg)

    writer = _WRITER_DISPATCH.get(type(artefact))
    if writer is not None:
        writer(conn, artefact, source_registry=source_registry)
        return

    type_name = _CLASS_TO_NAME.get(type(artefact))
    if type_name is None:
        msg = f"Unsupported artefact type: {type(artefact).__name__}"
        raise TypeError(msg)
    # Registered but no dedicated writer — store spine + text only
    urn = str(artefact_urn(artefact))
    _delete_artefact_cascade(conn, urn)
    _put_spine(conn, urn, type_name, artefact, source_registry=source_registry)
    _put_artefact_text_and_annotations(conn, urn, artefact)


def drop_artefact(conn: duckdb.DuckDBPyConnection, urn: str) -> bool:
    """Delete an artefact and its child rows.

    Returns True if the artefact existed and was deleted.
    """
    _delete_artefact_cascade(conn, urn)
    result = conn.execute(
        "DELETE FROM artefact WHERE urn = ? RETURNING urn",
        [urn],
    ).fetchone()
    return result is not None


def ingest_registry(
    conn: duckdb.DuckDBPyConnection,
    registry: Any,
    *,
    source_registry: str | None = None,
) -> None:
    """Bulk-import all artefacts from a Registry into DuckDB storage."""
    store: dict[str, Any] = getattr(registry, "_store", {})
    for artefact in store.values():
        put_artefact(conn, artefact, source_registry=source_registry)
