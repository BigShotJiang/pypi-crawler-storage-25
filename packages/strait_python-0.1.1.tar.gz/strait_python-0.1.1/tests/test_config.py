"""Tests for configuration loading."""

import json

import pytest

from strait._config import (
    AuthType,
    config_from_env,
    config_from_file,
    normalize_base_url,
)
from strait._errors import ValidationError


class TestNormalizeBaseUrl:
    def test_strips_trailing_slashes(self):
        assert normalize_base_url("https://api.test///") == "https://api.test"

    def test_no_trailing_slash(self):
        assert normalize_base_url("https://api.test") == "https://api.test"


class TestConfigFromEnv:
    def test_success(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://api.test")
        monkeypatch.setenv("STRAIT_API_KEY", "key-123")
        cfg = config_from_env()
        assert cfg.base_url == "https://api.test"
        assert cfg.auth.token == "key-123"
        assert cfg.auth.type == AuthType.API_KEY

    def test_missing_base_url(self, monkeypatch):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.setenv("STRAIT_API_KEY", "key")
        with pytest.raises(ValidationError, match="STRAIT_BASE_URL"):
            config_from_env()

    def test_missing_api_key(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://api.test")
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        with pytest.raises(ValidationError, match="STRAIT_API_KEY"):
            config_from_env()

    def test_custom_auth_type(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://api.test")
        monkeypatch.setenv("STRAIT_API_KEY", "key")
        monkeypatch.setenv("STRAIT_AUTH_TYPE", "bearer")
        cfg = config_from_env()
        assert cfg.auth.type == AuthType.BEARER

    def test_custom_timeout(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://api.test")
        monkeypatch.setenv("STRAIT_API_KEY", "key")
        monkeypatch.setenv("STRAIT_TIMEOUT_MS", "5000")
        cfg = config_from_env()
        assert cfg.timeout_ms == 5000

    def test_invalid_timeout(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://api.test")
        monkeypatch.setenv("STRAIT_API_KEY", "key")
        monkeypatch.setenv("STRAIT_TIMEOUT_MS", "not-a-number")
        with pytest.raises(ValidationError, match="STRAIT_TIMEOUT_MS"):
            config_from_env()

    def test_invalid_auth_type(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://api.test")
        monkeypatch.setenv("STRAIT_API_KEY", "key")
        monkeypatch.setenv("STRAIT_AUTH_TYPE", "oauth")
        with pytest.raises(ValidationError, match="STRAIT_AUTH_TYPE"):
            config_from_env()


class TestConfigFromFile:
    def test_reads_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(
            json.dumps(
                {
                    "sdk": {
                        "base_url": "https://file.test",
                        "auth_type": "apiKey",
                        "timeout_ms": 10000,
                    }
                }
            )
        )

        cfg = config_from_file(path=str(config_file))
        assert cfg.base_url == "https://file.test"
        assert cfg.timeout_ms == 10000

    def test_env_overrides_file(self, monkeypatch, tmp_path):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://env.test")
        monkeypatch.setenv("STRAIT_API_KEY", "env-key")
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"base_url": "https://file.test"}}))

        cfg = config_from_file(path=str(config_file))
        assert cfg.base_url == "https://env.test"
        assert cfg.auth.token == "env-key"

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            config_from_file(path="/nonexistent/strait.json")

    def test_invalid_json(self, tmp_path):
        config_file = tmp_path / "strait.json"
        config_file.write_text("not json")
        with pytest.raises(ValueError, match="Invalid JSON"):
            config_from_file(path=str(config_file))

    def test_search_dir(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"base_url": "https://dir.test"}}))

        cfg = config_from_file(search_dir=str(tmp_path))
        assert cfg.base_url == "https://dir.test"

    def test_missing_sdk_section_uses_defaults(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"project": {"id": "proj-1"}}))

        cfg = config_from_file(path=str(config_file))
        assert cfg.base_url == ""
        assert cfg.auth.type == AuthType.API_KEY
        assert cfg.timeout_ms == 30_000

    def test_null_sdk_section(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": None}))

        cfg = config_from_file(path=str(config_file))
        assert cfg.base_url == ""
        assert cfg.timeout_ms == 30_000

    def test_env_timeout_override_on_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.setenv("STRAIT_TIMEOUT_MS", "7000")

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"timeout_ms": 5000}}))

        cfg = config_from_file(path=str(config_file))
        assert cfg.timeout_ms == 7000

    def test_env_auth_type_override_on_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.setenv("STRAIT_AUTH_TYPE", "bearer")
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"auth_type": "apiKey"}}))

        cfg = config_from_file(path=str(config_file))
        assert cfg.auth.type == AuthType.BEARER

    def test_invalid_env_timeout_with_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.setenv("STRAIT_TIMEOUT_MS", "bad")

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {}}))

        with pytest.raises(ValidationError, match="STRAIT_TIMEOUT_MS"):
            config_from_file(path=str(config_file))

    def test_trailing_slashes_stripped_from_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"base_url": "https://api.test///"}}))

        cfg = config_from_file(path=str(config_file))
        assert cfg.base_url == "https://api.test"

    def test_invalid_auth_type_in_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"auth_type": "oauth"}}))

        with pytest.raises(ValidationError, match="auth_type"):
            config_from_file(path=str(config_file))

    def test_invalid_auth_type_in_env_override(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.delenv("STRAIT_API_KEY", raising=False)
        monkeypatch.setenv("STRAIT_AUTH_TYPE", "bogus")
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)

        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {}}))

        with pytest.raises(ValidationError, match="STRAIT_AUTH_TYPE"):
            config_from_file(path=str(config_file))
