"""Async integration tests exercising AsyncClient -> Service -> HTTP round-trip."""

import httpx
import pytest

from strait._client import AsyncClient
from strait._errors import NotFoundError, TransportError
from strait._middleware import Middleware


@pytest.fixture
def async_mock_client():
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"ok": True})

    transport = httpx.MockTransport(handler)
    http = httpx.AsyncClient(transport=transport)
    client = AsyncClient(base_url="https://api.test", api_key="key", http_client=http)
    return client, requests


class TestAsyncIntegration:
    @pytest.mark.asyncio
    async def test_jobs_list(self, async_mock_client):
        c, reqs = async_mock_client
        result = await c.jobs.list()
        assert reqs[-1].method == "GET"
        assert reqs[-1].url.path == "/v1/jobs"
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_jobs_create(self, async_mock_client):
        c, reqs = async_mock_client
        await c.jobs.create({"name": "test-job", "project_id": "p1"})
        assert reqs[-1].method == "POST"
        assert reqs[-1].url.path == "/v1/jobs"

    @pytest.mark.asyncio
    async def test_jobs_trigger(self, async_mock_client):
        c, reqs = async_mock_client
        await c.jobs.trigger("j1", {"payload": {"key": "value"}})
        assert reqs[-1].url.path == "/v1/jobs/j1/trigger"

    @pytest.mark.asyncio
    async def test_jobs_get(self, async_mock_client):
        c, reqs = async_mock_client
        await c.jobs.get("j1")
        assert reqs[-1].url.path == "/v1/jobs/j1"

    @pytest.mark.asyncio
    async def test_jobs_update(self, async_mock_client):
        c, reqs = async_mock_client
        await c.jobs.update("j1", {"name": "new"})
        assert reqs[-1].method == "PATCH"

    @pytest.mark.asyncio
    async def test_jobs_delete(self, async_mock_client):
        c, reqs = async_mock_client
        await c.jobs.delete("j1")
        assert reqs[-1].method == "DELETE"

    @pytest.mark.asyncio
    async def test_runs_get(self, async_mock_client):
        c, reqs = async_mock_client
        await c.runs.get("r1")
        assert reqs[-1].url.path == "/v1/runs/r1"

    @pytest.mark.asyncio
    async def test_runs_bulk_cancel(self, async_mock_client):
        c, reqs = async_mock_client
        await c.runs.bulk_cancel({"ids": ["r1"]})
        assert reqs[-1].url.path == "/v1/runs/bulk-cancel"

    @pytest.mark.asyncio
    async def test_workflows_trigger(self, async_mock_client):
        c, reqs = async_mock_client
        await c.workflows.trigger("wf1", {"payload": {}})
        assert reqs[-1].url.path == "/v1/workflows/wf1/trigger"

    @pytest.mark.asyncio
    async def test_workflow_runs_approve_step(self, async_mock_client):
        c, reqs = async_mock_client
        await c.workflow_runs.approve_step("wr1", "s1", {"approved": True})
        assert reqs[-1].url.path == "/v1/workflow-runs/wr1/steps/s1/approve"

    @pytest.mark.asyncio
    async def test_sdk_runs_complete(self, async_mock_client):
        c, reqs = async_mock_client
        await c.sdk_runs.complete_run("r1", {"output": "done"})
        assert reqs[-1].url.path == "/sdk/v1/runs/r1/complete"

    @pytest.mark.asyncio
    async def test_sdk_runs_checkpoint(self, async_mock_client):
        c, reqs = async_mock_client
        await c.sdk_runs.checkpoint_run("r1", {"state": {"step": 1}})
        assert reqs[-1].url.path == "/sdk/v1/runs/r1/checkpoint"

    @pytest.mark.asyncio
    async def test_sdk_runs_state_operations(self, async_mock_client):
        c, reqs = async_mock_client
        await c.sdk_runs.set_state("r1", {"key": "k", "value": "v"})
        assert reqs[-1].url.path == "/sdk/v1/runs/r1/state"
        assert reqs[-1].method == "POST"

        await c.sdk_runs.get_state("r1", "k")
        assert reqs[-1].url.path == "/sdk/v1/runs/r1/state/k"
        assert reqs[-1].method == "GET"

        await c.sdk_runs.delete_state("r1", "k")
        assert reqs[-1].url.path == "/sdk/v1/runs/r1/state/k"
        assert reqs[-1].method == "DELETE"

    @pytest.mark.asyncio
    async def test_deployments_create(self, async_mock_client):
        c, reqs = async_mock_client
        await c.deployments.create({"project_id": "p1"})
        assert reqs[-1].url.path == "/v1/deployments"

    @pytest.mark.asyncio
    async def test_health_list(self, async_mock_client):
        c, reqs = async_mock_client
        await c.health.list()
        assert reqs[-1].url.path == "/health"

    @pytest.mark.asyncio
    async def test_auth_header_sent(self, async_mock_client):
        c, reqs = async_mock_client
        await c.health.list()
        assert reqs[-1].headers["authorization"] == "Bearer key"

    @pytest.mark.asyncio
    async def test_custom_headers_merged(self):
        requests: list[httpx.Request] = []

        async def handler(request: httpx.Request) -> httpx.Response:
            requests.append(request)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        c = AsyncClient(
            base_url="https://api.test",
            api_key="key",
            default_headers={"X-Custom": "value"},
            http_client=http,
        )
        await c.health.list()
        assert requests[-1].headers["x-custom"] == "value"

    @pytest.mark.asyncio
    async def test_404_raises_not_found(self):
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, json={"message": "not found"})

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        c = AsyncClient(base_url="https://api.test", api_key="key", http_client=http)

        with pytest.raises(NotFoundError):
            await c.jobs.get("nonexistent")

    @pytest.mark.asyncio
    async def test_transport_error(self):
        async def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("connection refused")

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        c = AsyncClient(base_url="https://api.test", api_key="key", http_client=http)

        with pytest.raises(TransportError):
            await c.health.list()

    @pytest.mark.asyncio
    async def test_empty_body_returns_empty_dict(self):
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(204, text="")

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        c = AsyncClient(base_url="https://api.test", api_key="key", http_client=http)
        result = await c.runs.delete("r1")
        assert result == {}

    @pytest.mark.asyncio
    async def test_middleware_hooks(self):
        request_urls: list[str] = []
        response_statuses: list[int] = []
        errors_caught: list[BaseException] = []

        mw = Middleware(
            on_request=lambda ctx: request_urls.append(ctx.url),
            on_response=lambda ctx: response_statuses.append(ctx.status),
            on_error=lambda ctx: errors_caught.append(ctx.error),
        )

        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        c = AsyncClient(
            base_url="https://api.test",
            api_key="key",
            http_client=http,
            middleware=[mw],
        )
        await c.health.list()
        assert len(request_urls) == 1
        assert response_statuses == [200]

    @pytest.mark.asyncio
    async def test_middleware_on_error(self):
        errors_caught: list[BaseException] = []

        mw = Middleware(
            on_error=lambda ctx: errors_caught.append(ctx.error),
        )

        async def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("refused")

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        c = AsyncClient(
            base_url="https://api.test",
            api_key="key",
            http_client=http,
            middleware=[mw],
            retry=None,
        )
        with pytest.raises(TransportError):
            await c.health.list()
        assert len(errors_caught) == 1

    @pytest.mark.asyncio
    async def test_context_manager(self):
        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"ok": True})

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        async with AsyncClient(
            base_url="https://api.test",
            api_key="key",
            http_client=http,
        ) as c:
            result = await c.health.list()
            assert result == {"ok": True}
