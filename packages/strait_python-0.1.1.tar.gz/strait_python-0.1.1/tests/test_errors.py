"""Tests for the error hierarchy."""

from strait._errors import (
    ApiError,
    ConflictError,
    CostBudgetExceededError,
    DagValidationError,
    DecodeError,
    NotFoundError,
    RateLimitedError,
    StraitError,
    StraitTimeoutError,
    TransportError,
    UnauthorizedError,
    ValidationError,
    map_http_error,
)


class TestMapHttpError:
    def test_401_maps_to_unauthorized(self):
        err = map_http_error(401, "bad token")
        assert isinstance(err, UnauthorizedError)
        assert err.status == 401

    def test_403_maps_to_unauthorized(self):
        err = map_http_error(403, "forbidden")
        assert isinstance(err, UnauthorizedError)

    def test_404_maps_to_not_found(self):
        err = map_http_error(404, "not found")
        assert isinstance(err, NotFoundError)

    def test_409_maps_to_conflict(self):
        err = map_http_error(409, "conflict")
        assert isinstance(err, ConflictError)

    def test_429_maps_to_rate_limited(self):
        err = map_http_error(429, "slow down")
        assert isinstance(err, RateLimitedError)

    def test_500_maps_to_api_error(self):
        err = map_http_error(500, "internal")
        assert isinstance(err, ApiError)

    def test_empty_message_uses_status(self):
        err = map_http_error(500, "")
        assert "500" in str(err)

    def test_body_attached(self):
        err = map_http_error(404, "not found", {"detail": "gone"})
        assert isinstance(err, NotFoundError)
        assert err.body == {"detail": "gone"}


class TestErrorTypes:
    def test_all_inherit_from_strait_error(self):
        assert issubclass(TransportError, StraitError)
        assert issubclass(DecodeError, StraitError)
        assert issubclass(ValidationError, StraitError)
        assert issubclass(UnauthorizedError, StraitError)
        assert issubclass(NotFoundError, StraitError)
        assert issubclass(ConflictError, StraitError)
        assert issubclass(RateLimitedError, StraitError)
        assert issubclass(ApiError, StraitError)
        assert issubclass(StraitTimeoutError, StraitError)
        assert issubclass(DagValidationError, StraitError)
        assert issubclass(CostBudgetExceededError, StraitError)

    def test_transport_error_stores_cause(self):
        cause = RuntimeError("boom")
        err = TransportError("fail", cause=cause)
        assert err.__cause__ is cause

    def test_decode_error_stores_body(self):
        err = DecodeError("fail", body="raw")
        assert err.body == "raw"

    def test_validation_error_stores_issues(self):
        err = ValidationError("fail", issues=["a", "b"])
        assert err.issues == ["a", "b"]

    def test_timeout_error_stores_run_id(self):
        err = StraitTimeoutError("fail", run_id="r1", elapsed_ms=5000)
        assert err.run_id == "r1"
        assert err.elapsed_ms == 5000

    def test_dag_validation_error_stores_details(self):
        err = DagValidationError("fail", cycles=["a"], missing_refs=["b"])
        assert err.cycles == ["a"]
        assert err.missing_refs == ["b"]

    def test_cost_budget_exceeded_error(self):
        err = CostBudgetExceededError("fail", current_cost_microusd=100, max_cost_microusd=50)
        assert err.current_cost_microusd == 100
        assert err.max_cost_microusd == 50
