"""Tests for HTTP request execution."""

import httpx
import pytest

from strait._config import AuthMode, AuthType, Config
from strait._errors import ApiError, NotFoundError, TransportError
from strait._http import do_request, substitute_path_params


class TestSubstitutePathParams:
    def test_single_param(self):
        assert substitute_path_params("/v1/jobs/{jobID}", {"jobID": "j1"}) == "/v1/jobs/j1"

    def test_multiple_params(self):
        result = substitute_path_params(
            "/v1/jobs/{jobID}/versions/{versionID}",
            {"jobID": "j1", "versionID": "v1"},
        )
        assert result == "/v1/jobs/j1/versions/v1"

    def test_missing_param_left_as_is(self):
        result = substitute_path_params("/v1/jobs/{jobID}", {})
        assert result == "/v1/jobs/{jobID}"

    def test_no_params(self):
        assert substitute_path_params("/v1/jobs", {}) == "/v1/jobs"


class TestDoRequest:
    def _config(self) -> Config:
        return Config(
            base_url="https://api.test",
            auth=AuthMode(type=AuthType.API_KEY, token="key"),
        )

    def test_success(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"ok": True})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        result = do_request(http, self._config(), method="GET", path="/test")
        assert result == {"ok": True}

    def test_404_raises_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, json={"message": "not found"})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        with pytest.raises(NotFoundError):
            do_request(http, self._config(), method="GET", path="/test")

    def test_transport_error(self):
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("refused")

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        with pytest.raises(TransportError):
            do_request(http, self._config(), method="GET", path="/test")

    def test_empty_body_returns_empty_dict(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(204, text="")

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        result = do_request(http, self._config(), method="DELETE", path="/test")
        assert result == {}

    def test_path_params_substituted(self):
        captured_urls: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured_urls.append(str(request.url))
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        do_request(
            http,
            self._config(),
            method="GET",
            path="/v1/jobs/{jobID}",
            path_params={"jobID": "j1"},
        )
        assert "j1" in captured_urls[0]

    def test_headers_sent(self):
        captured: list[httpx.Request] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured.append(request)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        do_request(http, self._config(), method="GET", path="/test")

        req = captured[0]
        assert req.headers["authorization"] == "Bearer key"
        assert req.headers["content-type"] == "application/json"
        assert req.headers["accept"] == "application/json"

    def test_500_raises_api_error(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, json={"message": "boom"})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        with pytest.raises(ApiError) as exc_info:
            do_request(http, self._config(), method="GET", path="/test")
        assert exc_info.value.status == 500
