"""Integration tests exercising Client -> Service -> HTTP round-trip."""

import httpx
import pytest

from strait._client import Client


@pytest.fixture
def mock_client():
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"ok": True})

    transport = httpx.MockTransport(handler)
    http = httpx.Client(transport=transport)
    client = Client(base_url="https://api.test", api_key="key", http_client=http)
    return client, requests


class TestIntegration:
    def test_jobs_list(self, mock_client):
        c, reqs = mock_client
        c.jobs.list()
        assert reqs[-1].method == "GET"
        assert reqs[-1].url.path == "/v1/jobs"

    def test_jobs_create(self, mock_client):
        c, reqs = mock_client
        c.jobs.create({"name": "test-job", "project_id": "p1"})
        assert reqs[-1].method == "POST"
        assert reqs[-1].url.path == "/v1/jobs"

    def test_jobs_trigger(self, mock_client):
        c, reqs = mock_client
        c.jobs.trigger("j1", {"payload": {"key": "value"}})
        assert reqs[-1].url.path == "/v1/jobs/j1/trigger"

    def test_runs_get(self, mock_client):
        c, reqs = mock_client
        c.runs.get("r1")
        assert reqs[-1].url.path == "/v1/runs/r1"

    def test_workflows_trigger(self, mock_client):
        c, reqs = mock_client
        c.workflows.trigger("wf1", {"payload": {}})
        assert reqs[-1].url.path == "/v1/workflows/wf1/trigger"

    def test_workflow_runs_approve_step(self, mock_client):
        c, reqs = mock_client
        c.workflow_runs.approve_step("wr1", "s1", {"approved": True})
        assert reqs[-1].url.path == "/v1/workflow-runs/wr1/steps/s1/approve"

    def test_sdk_runs_complete(self, mock_client):
        c, reqs = mock_client
        c.sdk_runs.complete_run("r1", {"output": "done"})
        assert reqs[-1].url.path == "/sdk/v1/runs/r1/complete"

    def test_deployments_create(self, mock_client):
        c, reqs = mock_client
        c.deployments.create({"project_id": "p1"})
        assert reqs[-1].url.path == "/v1/deployments"

    def test_auth_header_sent(self, mock_client):
        c, reqs = mock_client
        c.health.list()
        assert reqs[-1].headers["authorization"] == "Bearer key"

    def test_custom_headers_merged(self):
        requests: list[httpx.Request] = []

        def handler(request: httpx.Request) -> httpx.Response:
            requests.append(request)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(
            base_url="https://api.test",
            api_key="key",
            default_headers={"X-Custom": "value"},
            http_client=http,
        )
        c.health.list()
        assert requests[-1].headers["x-custom"] == "value"

    def test_middleware_hooks(self):
        from strait._middleware import Middleware

        request_urls: list[str] = []
        response_statuses: list[int] = []

        mw = Middleware(
            on_request=lambda ctx: request_urls.append(ctx.url),
            on_response=lambda ctx: response_statuses.append(ctx.status),
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(
            base_url="https://api.test",
            api_key="key",
            http_client=http,
            middleware=[mw],
        )
        c.health.list()
        assert len(request_urls) == 1
        assert len(response_statuses) == 1
        assert response_statuses[0] == 200
