"""Tests for middleware hooks."""

from strait._middleware import (
    Middleware,
    MiddlewareErrorContext,
    MiddlewareRequestContext,
    MiddlewareResponseContext,
)


class TestMiddleware:
    def test_default_none_hooks(self):
        mw = Middleware()
        assert mw.on_request is None
        assert mw.on_response is None
        assert mw.on_error is None

    def test_request_context(self):
        ctx = MiddlewareRequestContext(
            method="GET",
            url="https://api.test/v1/jobs",
            headers={"Authorization": "Bearer tok"},
        )
        assert ctx.method == "GET"
        assert ctx.url == "https://api.test/v1/jobs"

    def test_response_context(self):
        ctx = MiddlewareResponseContext(
            method="GET",
            url="https://api.test",
            status=200,
            duration_ms=42,
        )
        assert ctx.status == 200
        assert ctx.duration_ms == 42

    def test_error_context(self):
        err = RuntimeError("boom")
        ctx = MiddlewareErrorContext(method="GET", url="https://api.test", error=err)
        assert ctx.error is err

    def test_hooks_callable(self):
        events: list[str] = []
        mw = Middleware(
            on_request=lambda ctx: events.append("req"),
            on_response=lambda ctx: events.append("resp"),
            on_error=lambda ctx: events.append("err"),
        )
        mw.on_request(MiddlewareRequestContext(method="GET", url="/", headers={}))
        mw.on_response(MiddlewareResponseContext(method="GET", url="/", status=200, duration_ms=1))
        mw.on_error(MiddlewareErrorContext(method="GET", url="/", error=Exception()))
        assert events == ["req", "resp", "err"]
