"""Tests for Client and AsyncClient."""

import json
from typing import Any

import httpx
import pytest

from strait import RetryPolicy
from strait._client import AsyncClient, Client
from strait._config import AuthMode, AuthType
from strait._errors import ApiError, NotFoundError, TransportError, UnauthorizedError
from strait.composition._retry import JitterStrategy

_NO_JITTER = JitterStrategy.NONE


def _no_jitter_retry(attempts: int = 3) -> RetryPolicy:
    return RetryPolicy(attempts=attempts, delay_ms=1, jitter=_NO_JITTER)


class TestClient:
    def test_inline_construction(self):
        c = Client(base_url="https://api.test", api_key="key")
        assert c.base_url == "https://api.test"

    def test_trailing_slash_stripped(self):
        c = Client(base_url="https://api.test///")
        assert c.base_url == "https://api.test"

    def test_bearer_token_auth(self):
        c = Client(base_url="https://api.test", bearer_token="tok")
        assert c._config.auth.type == AuthType.BEARER

    def test_run_token_auth(self):
        c = Client(base_url="https://api.test", run_token="rt")
        assert c._config.auth.type == AuthType.RUN_TOKEN

    def test_explicit_auth_overrides(self):
        auth = AuthMode(type=AuthType.BEARER, token="explicit")
        c = Client(base_url="https://api.test", api_key="ignored", auth=auth)
        assert c._config.auth.token == "explicit"

    def test_context_manager(self):
        with Client(base_url="https://api.test", api_key="key") as c:
            assert c.base_url == "https://api.test"

    def test_do_request_success(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"ok": True})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(base_url="https://api.test", api_key="key", http_client=http)
        result = c.do_request("GET", "/v1/test")
        assert result == {"ok": True}

    def test_do_request_empty_body(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(204, text="")

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(base_url="https://api.test", api_key="key", http_client=http)
        result = c.do_request("DELETE", "/v1/test")
        assert result == {}

    def test_do_request_401_raises_unauthorized(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(401, json={"message": "bad token"})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(base_url="https://api.test", api_key="bad", http_client=http)

        with pytest.raises(UnauthorizedError) as exc_info:
            c.do_request("GET", "/test")
        assert exc_info.value.status == 401

    def test_do_request_404_raises_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, json={"message": "not found"})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(base_url="https://api.test", api_key="key", http_client=http)

        with pytest.raises(NotFoundError):
            c.do_request("GET", "/test")

    def test_do_request_500_raises_api_error(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, json={"message": "boom"})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(base_url="https://api.test", api_key="key", http_client=http)

        with pytest.raises(ApiError) as exc_info:
            c.do_request("GET", "/test")
        assert exc_info.value.status == 500

    def test_do_request_transport_error(self):
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("connection refused")

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(base_url="https://api.test", api_key="key", http_client=http)

        with pytest.raises(TransportError):
            c.do_request("GET", "/test")

    def test_services_attached(self):
        c = Client(base_url="https://api.test", api_key="key")
        assert c.jobs is not None
        assert c.runs is not None
        assert c.workflows is not None
        assert c.workflow_runs is not None
        assert c.deployments is not None
        assert c.environments is not None
        assert c.secrets is not None
        assert c.api_keys is not None
        assert c.webhooks is not None
        assert c.event_triggers is not None
        assert c.event_sources is not None
        assert c.batch_operations is not None
        assert c.stats is not None
        assert c.analytics is not None
        assert c.log_drains is not None
        assert c.sdk_runs is not None
        assert c.rbac is not None
        assert c.job_groups is not None
        assert c.health is not None

    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://env.test")
        monkeypatch.setenv("STRAIT_API_KEY", "env-key")
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)
        c = Client.from_env()
        assert c.base_url == "https://env.test"
        assert c._config.auth.token == "env-key"
        assert c._config.auth.type == AuthType.API_KEY

    def test_from_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.setenv("STRAIT_API_KEY", "file-key")
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)
        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"base_url": "https://file.test"}}))
        c = Client.from_file(path=str(config_file))
        assert c.base_url == "https://file.test"
        assert c._config.auth.token == "file-key"

    def test_from_file_with_overrides(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.setenv("STRAIT_API_KEY", "key")
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)
        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"base_url": "https://file.test"}}))
        c = Client.from_file(path=str(config_file), timeout_ms=5000)
        assert c._config.timeout_ms == 5000

    def test_from_env_with_overrides(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://env.test")
        monkeypatch.setenv("STRAIT_API_KEY", "key")
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)
        c = Client.from_env(timeout_ms=7000)
        assert c._config.timeout_ms == 7000


class TestAsyncClient:
    def test_inline_construction(self):
        c = AsyncClient(base_url="https://api.test", api_key="key")
        assert c.base_url == "https://api.test"

    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("STRAIT_BASE_URL", "https://env.test")
        monkeypatch.setenv("STRAIT_API_KEY", "env-key")
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)
        c = AsyncClient.from_env()
        assert c.base_url == "https://env.test"
        assert c._config.auth.token == "env-key"

    def test_from_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STRAIT_BASE_URL", raising=False)
        monkeypatch.setenv("STRAIT_API_KEY", "file-key")
        monkeypatch.delenv("STRAIT_AUTH_TYPE", raising=False)
        monkeypatch.delenv("STRAIT_TIMEOUT_MS", raising=False)
        config_file = tmp_path / "strait.json"
        config_file.write_text(json.dumps({"sdk": {"base_url": "https://file.test"}}))
        c = AsyncClient.from_file(path=str(config_file))
        assert c.base_url == "https://file.test"
        assert c._config.auth.token == "file-key"

    def test_services_attached(self):
        c = AsyncClient(base_url="https://api.test", api_key="key")
        assert c.jobs is not None
        assert c.runs is not None
        assert c.workflows is not None


class TestRetrySync:
    def _build(
        self,
        responses: list[httpx.Response],
        retry: object = ...,
    ) -> tuple[Client, list[httpx.Request]]:
        seen: list[httpx.Request] = []
        idx = {"i": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            seen.append(request)
            response = responses[min(idx["i"], len(responses) - 1)]
            idx["i"] += 1
            return response

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        kwargs: dict[str, Any] = {
            "base_url": "https://api.test",
            "api_key": "k",
            "http_client": http,
        }
        if retry is not ...:
            kwargs["retry"] = retry
        return Client(**kwargs), seen

    def test_5xx_then_200_succeeds(self):
        c, seen = self._build(
            [
                httpx.Response(503, text="busy"),
                httpx.Response(200, json={"ok": True}),
            ],
            retry=_no_jitter_retry(3),
        )
        assert c.do_request("GET", "/v1/x") == {"ok": True}
        assert len(seen) == 2

    def test_all_5xx_raises(self):
        c, seen = self._build(
            [httpx.Response(500, json={"message": "boom"})],
            retry=_no_jitter_retry(2),
        )
        with pytest.raises(ApiError):
            c.do_request("GET", "/v1/x")
        assert len(seen) == 2

    def test_4xx_does_not_retry(self):
        c, seen = self._build([httpx.Response(404, json={"message": "no"})])
        with pytest.raises(NotFoundError):
            c.do_request("GET", "/v1/x")
        assert len(seen) == 1

    def test_transport_error_retried(self):
        attempts = {"i": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            attempts["i"] += 1
            if attempts["i"] < 2:
                raise httpx.ConnectError("refused")
            return httpx.Response(200, json={"ok": True})

        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        c = Client(
            base_url="https://api.test",
            api_key="k",
            http_client=http,
            retry=_no_jitter_retry(3),
        )
        assert c.do_request("GET", "/v1/x") == {"ok": True}
        assert attempts["i"] == 2

    def test_retry_none_disables(self):
        c, seen = self._build(
            [httpx.Response(503, json={"message": "busy"})],
            retry=None,
        )
        with pytest.raises(ApiError):
            c.do_request("GET", "/v1/x")
        assert len(seen) == 1


class TestRetryAsync:
    def _build(
        self,
        responses: list[httpx.Response],
        retry: object = ...,
    ) -> tuple[AsyncClient, list[httpx.Request]]:
        seen: list[httpx.Request] = []
        idx = {"i": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            seen.append(request)
            response = responses[min(idx["i"], len(responses) - 1)]
            idx["i"] += 1
            return response

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        kwargs: dict[str, Any] = {
            "base_url": "https://api.test",
            "api_key": "k",
            "http_client": http,
        }
        if retry is not ...:
            kwargs["retry"] = retry
        return AsyncClient(**kwargs), seen

    @pytest.mark.asyncio
    async def test_5xx_then_200_succeeds(self):
        c, seen = self._build(
            [
                httpx.Response(503, text="busy"),
                httpx.Response(200, json={"ok": True}),
            ],
            retry=_no_jitter_retry(3),
        )
        assert await c.do_request("GET", "/v1/x") == {"ok": True}
        assert len(seen) == 2

    @pytest.mark.asyncio
    async def test_all_5xx_raises(self):
        c, seen = self._build(
            [httpx.Response(500, json={"message": "boom"})],
            retry=_no_jitter_retry(2),
        )
        with pytest.raises(ApiError):
            await c.do_request("GET", "/v1/x")
        assert len(seen) == 2

    @pytest.mark.asyncio
    async def test_4xx_does_not_retry(self):
        c, seen = self._build([httpx.Response(404, json={"message": "no"})])
        with pytest.raises(NotFoundError):
            await c.do_request("GET", "/v1/x")
        assert len(seen) == 1

    @pytest.mark.asyncio
    async def test_transport_error_retried(self):
        attempts = {"i": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            attempts["i"] += 1
            if attempts["i"] < 2:
                raise httpx.ConnectError("refused")
            return httpx.Response(200, json={"ok": True})

        transport = httpx.MockTransport(handler)
        http = httpx.AsyncClient(transport=transport)
        c = AsyncClient(
            base_url="https://api.test",
            api_key="k",
            http_client=http,
            retry=_no_jitter_retry(3),
        )
        assert await c.do_request("GET", "/v1/x") == {"ok": True}
        assert attempts["i"] == 2

    @pytest.mark.asyncio
    async def test_retry_none_disables(self):
        c, seen = self._build(
            [httpx.Response(503, json={"message": "busy"})],
            retry=None,
        )
        with pytest.raises(ApiError):
            await c.do_request("GET", "/v1/x")
        assert len(seen) == 1
