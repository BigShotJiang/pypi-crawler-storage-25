"""Performance, cost, and reliability analytics operations."""

from __future__ import annotations

from typing import Any

from strait.operations._base import AsyncBaseService, BaseService


class AnalyticsService(BaseService):
    def get_performance(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/performance", query=query)

    def list_costs(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/costs", query=query)

    def get_costs_by_machine(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/costs/by-machine", query=query)

    def get_costs_by_trigger(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/costs/by-trigger", query=query)

    def get_costs_forecast(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/costs/forecast", query=query)

    def get_costs_top(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/costs/top", query=query)

    def list_cost_trends(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/costs/trends", query=query)

    def list_cost_insights(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/cost-insights", query=query)

    def get_compute(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/compute", query=query)

    def list_approvals(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/approvals", query=query)

    def get_events_latency(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/events/latency", query=query)

    def get_events_volume(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/events/volume", query=query)

    def get_runs_summary(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/runs/summary", query=query)

    def get_runs_timeline(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/runs/timeline", query=query)

    def get_runs_by_trigger(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/runs/by-trigger", query=query)

    def get_runs_duration_distribution(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/runs/duration-distribution", query=query)

    def list_runs_failure_reasons(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/runs/failure-reasons", query=query)

    def get_jobs_reliability(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/jobs/reliability", query=query)

    def get_jobs_top_failing(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/jobs/top-failing", query=query)

    def get_jobs_cost_ranking(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/jobs/cost-ranking", query=query)

    def get_jobs_comparison(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/jobs/comparison", query=query)

    def get_jobs_by_version(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/jobs/by-version", query=query)

    def get_job_history(
        self,
        job_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/analytics/jobs/{jobID}/history",
            path_params={"jobID": job_id},
            query=query,
        )

    def get_tags_cost(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/tags/cost", query=query)

    def get_tags_summary(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/tags/summary", query=query)

    def get_tags_top_failing(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/tags/top-failing", query=query)

    def list_webhooks_delivery_stats(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/webhooks/delivery-stats", query=query)

    def get_webhooks_endpoint_health(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/webhooks/endpoint-health", query=query)

    def get_webhooks_top_failing(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/webhooks/top-failing", query=query)

    def list_workflows_completion_rates(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/workflows/completion-rates", query=query)

    def get_workflows_summary(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request("GET", "/v1/analytics/workflows/summary", query=query)

    def list_workflow_step_durations(
        self,
        workflow_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/analytics/workflows/{workflowID}/step-durations",
            path_params={"workflowID": workflow_id},
            query=query,
        )


class AsyncAnalyticsService(AsyncBaseService):
    async def get_performance(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/performance", query=query)

    async def list_costs(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/costs", query=query)

    async def get_costs_by_machine(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/costs/by-machine", query=query)

    async def get_costs_by_trigger(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/costs/by-trigger", query=query)

    async def get_costs_forecast(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/costs/forecast", query=query)

    async def get_costs_top(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/costs/top", query=query)

    async def list_cost_trends(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/costs/trends", query=query)

    async def list_cost_insights(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/cost-insights", query=query)

    async def get_compute(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/compute", query=query)

    async def list_approvals(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/approvals", query=query)

    async def get_events_latency(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/events/latency", query=query)

    async def get_events_volume(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/events/volume", query=query)

    async def get_runs_summary(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/runs/summary", query=query)

    async def get_runs_timeline(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/runs/timeline", query=query)

    async def get_runs_by_trigger(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/runs/by-trigger", query=query)

    async def get_runs_duration_distribution(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/analytics/runs/duration-distribution",
            query=query,
        )

    async def list_runs_failure_reasons(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/runs/failure-reasons", query=query)

    async def get_jobs_reliability(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/jobs/reliability", query=query)

    async def get_jobs_top_failing(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/jobs/top-failing", query=query)

    async def get_jobs_cost_ranking(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/jobs/cost-ranking", query=query)

    async def get_jobs_comparison(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/jobs/comparison", query=query)

    async def get_jobs_by_version(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/jobs/by-version", query=query)

    async def get_job_history(
        self,
        job_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/analytics/jobs/{jobID}/history",
            path_params={"jobID": job_id},
            query=query,
        )

    async def get_tags_cost(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/tags/cost", query=query)

    async def get_tags_summary(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/tags/summary", query=query)

    async def get_tags_top_failing(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/tags/top-failing", query=query)

    async def list_webhooks_delivery_stats(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/webhooks/delivery-stats", query=query)

    async def get_webhooks_endpoint_health(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/webhooks/endpoint-health", query=query)

    async def get_webhooks_top_failing(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/webhooks/top-failing", query=query)

    async def list_workflows_completion_rates(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/analytics/workflows/completion-rates",
            query=query,
        )

    async def get_workflows_summary(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/analytics/workflows/summary", query=query)

    async def list_workflow_step_durations(
        self,
        workflow_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/analytics/workflows/{workflowID}/step-durations",
            path_params={"workflowID": workflow_id},
            query=query,
        )
