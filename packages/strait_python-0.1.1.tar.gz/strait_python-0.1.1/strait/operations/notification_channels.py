"""Notification channel management operations."""

from __future__ import annotations

from typing import Any

from strait.operations._base import AsyncBaseService, BaseService


class NotificationChannelsService(BaseService):
    def list(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/notification-channels", query=query)

    def create(self, body: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/notification-channels", body=body)

    def get(self, channel_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/notification-channels/{channelID}",
            path_params={"channelID": channel_id},
        )

    def update(self, channel_id: str, body: Any) -> dict[str, Any]:
        return self._request(
            "PATCH",
            "/v1/notification-channels/{channelID}",
            path_params={"channelID": channel_id},
            body=body,
        )

    def delete(self, channel_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            "/v1/notification-channels/{channelID}",
            path_params={"channelID": channel_id},
        )

    def list_deliveries(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/notification-deliveries", query=query)


class AsyncNotificationChannelsService(AsyncBaseService):
    async def list(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", "/v1/notification-channels", query=query)

    async def create(self, body: Any) -> dict[str, Any]:
        return await self._request("POST", "/v1/notification-channels", body=body)

    async def get(self, channel_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/notification-channels/{channelID}",
            path_params={"channelID": channel_id},
        )

    async def update(self, channel_id: str, body: Any) -> dict[str, Any]:
        return await self._request(
            "PATCH",
            "/v1/notification-channels/{channelID}",
            path_params={"channelID": channel_id},
            body=body,
        )

    async def delete(self, channel_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            "/v1/notification-channels/{channelID}",
            path_params={"channelID": channel_id},
        )

    async def list_deliveries(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", "/v1/notification-deliveries", query=query)
