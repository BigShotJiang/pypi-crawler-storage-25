"""Organization-scoped listing operations."""

from __future__ import annotations

from typing import Any

from strait.operations._base import AsyncBaseService, BaseService


class OrganizationsService(BaseService):
    def list_jobs(
        self,
        org_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/organizations/{orgID}/jobs",
            path_params={"orgID": org_id},
            query=query,
        )

    def list_runs(
        self,
        org_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/organizations/{orgID}/runs",
            path_params={"orgID": org_id},
            query=query,
        )


class AsyncOrganizationsService(AsyncBaseService):
    async def list_jobs(
        self,
        org_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/organizations/{orgID}/jobs",
            path_params={"orgID": org_id},
            query=query,
        )

    async def list_runs(
        self,
        org_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/organizations/{orgID}/runs",
            path_params={"orgID": org_id},
            query=query,
        )
