"""Region listing operations."""

from __future__ import annotations

from typing import Any

from strait.operations._base import AsyncBaseService, BaseService


class RegionsService(BaseService):
    def list(self) -> dict[str, Any]:
        return self._request("GET", "/v1/regions")


class AsyncRegionsService(AsyncBaseService):
    async def list(self) -> dict[str, Any]:
        return await self._request("GET", "/v1/regions")
