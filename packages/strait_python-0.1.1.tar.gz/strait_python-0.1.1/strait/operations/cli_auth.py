"""CLI device-code authentication operations."""

from __future__ import annotations

from typing import Any

from strait.operations._base import AsyncBaseService, BaseService


class CliAuthService(BaseService):
    def device_code(self, body: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/cli/auth/device-code", body=body)

    def token(self, body: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/cli/auth/token", body=body)

    def approve_device_code(self, body: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/cli/device-codes/approve", body=body)


class AsyncCliAuthService(AsyncBaseService):
    async def device_code(self, body: Any) -> dict[str, Any]:
        return await self._request("POST", "/v1/cli/auth/device-code", body=body)

    async def token(self, body: Any) -> dict[str, Any]:
        return await self._request("POST", "/v1/cli/auth/token", body=body)

    async def approve_device_code(self, body: Any) -> dict[str, Any]:
        return await self._request("POST", "/v1/cli/device-codes/approve", body=body)
