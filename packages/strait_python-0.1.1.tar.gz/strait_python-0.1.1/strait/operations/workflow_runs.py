"""Workflow run management operations."""

from __future__ import annotations

from typing import Any, cast

from strait._models import WorkflowRun
from strait.operations._base import AsyncBaseService, BaseService


class WorkflowRunsService(BaseService):
    def list(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/workflow-runs", query=query)

    def get(self, workflow_run_id: str) -> WorkflowRun:
        return cast(
            "WorkflowRun",
            self._request(
                "GET",
                "/v1/workflow-runs/{workflowRunID}",
                path_params={"workflowRunID": workflow_run_id},
            ),
        )

    def delete(self, workflow_run_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            "/v1/workflow-runs/{workflowRunID}",
            path_params={"workflowRunID": workflow_run_id},
        )

    def pause(self, workflow_run_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/pause",
            path_params={"workflowRunID": workflow_run_id},
        )

    def resume(self, workflow_run_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/resume",
            path_params={"workflowRunID": workflow_run_id},
        )

    def retry(self, workflow_run_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/retry",
            path_params={"workflowRunID": workflow_run_id},
        )

    def list_steps(self, workflow_run_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/workflow-runs/{workflowRunID}/steps",
            path_params={"workflowRunID": workflow_run_id},
        )

    def approve_step(
        self,
        workflow_run_id: str,
        step_id: str,
        body: Any,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/approve",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
            body=body,
        )

    def retry_step(self, workflow_run_id: str, step_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/retry",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
        )

    def skip_step(self, workflow_run_id: str, step_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/skip",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
        )

    def force_complete_step(
        self,
        workflow_run_id: str,
        step_id: str,
        body: Any,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/force-complete",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
            body=body,
        )

    def replay_subtree_step(
        self,
        workflow_run_id: str,
        step_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/replay-subtree",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
        )

    def bulk_cancel(self, body: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/workflow-runs/bulk-cancel", body=body)

    def bulk_replay(self, body: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/workflow-runs/bulk-replay", body=body)


class AsyncWorkflowRunsService(AsyncBaseService):
    async def list(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", "/v1/workflow-runs", query=query)

    async def get(self, workflow_run_id: str) -> WorkflowRun:
        return cast(
            "WorkflowRun",
            await self._request(
                "GET",
                "/v1/workflow-runs/{workflowRunID}",
                path_params={"workflowRunID": workflow_run_id},
            ),
        )

    async def delete(self, workflow_run_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            "/v1/workflow-runs/{workflowRunID}",
            path_params={"workflowRunID": workflow_run_id},
        )

    async def pause(self, workflow_run_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/pause",
            path_params={"workflowRunID": workflow_run_id},
        )

    async def resume(self, workflow_run_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/resume",
            path_params={"workflowRunID": workflow_run_id},
        )

    async def retry(self, workflow_run_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/retry",
            path_params={"workflowRunID": workflow_run_id},
        )

    async def list_steps(self, workflow_run_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/workflow-runs/{workflowRunID}/steps",
            path_params={"workflowRunID": workflow_run_id},
        )

    async def approve_step(
        self,
        workflow_run_id: str,
        step_id: str,
        body: Any,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/approve",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
            body=body,
        )

    async def retry_step(self, workflow_run_id: str, step_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/retry",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
        )

    async def skip_step(self, workflow_run_id: str, step_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/skip",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
        )

    async def force_complete_step(
        self,
        workflow_run_id: str,
        step_id: str,
        body: Any,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/force-complete",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
            body=body,
        )

    async def replay_subtree_step(
        self,
        workflow_run_id: str,
        step_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/workflow-runs/{workflowRunID}/steps/{stepID}/replay-subtree",
            path_params={"workflowRunID": workflow_run_id, "stepID": step_id},
        )

    async def bulk_cancel(self, body: Any) -> dict[str, Any]:
        return await self._request("POST", "/v1/workflow-runs/bulk-cancel", body=body)

    async def bulk_replay(self, body: Any) -> dict[str, Any]:
        return await self._request("POST", "/v1/workflow-runs/bulk-replay", body=body)
