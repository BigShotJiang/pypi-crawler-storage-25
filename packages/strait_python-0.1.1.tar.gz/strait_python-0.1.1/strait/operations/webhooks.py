"""Webhook management operations."""

from __future__ import annotations

from typing import Any

from strait.operations._base import AsyncBaseService, BaseService


class WebhooksService(BaseService):
    def list_subscriptions(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/webhooks/subscriptions", query=query)

    def create_subscription(self, body: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/webhooks/subscriptions", body=body)

    def delete_subscription(self, sub_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            "/v1/webhooks/subscriptions/{subID}",
            path_params={"subID": sub_id},
        )

    def list_deliveries(
        self,
        sub_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/webhooks/subscriptions/{subID}/deliveries",
            path_params={"subID": sub_id},
            query=query,
        )

    def get_delivery(self, sub_id: str, delivery_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/webhooks/subscriptions/{subID}/deliveries/{deliveryID}",
            path_params={"subID": sub_id, "deliveryID": delivery_id},
        )

    def retry_delivery(self, sub_id: str, delivery_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/webhooks/subscriptions/{subID}/deliveries/{deliveryID}/retry",
            path_params={"subID": sub_id, "deliveryID": delivery_id},
        )


class AsyncWebhooksService(AsyncBaseService):
    async def list_subscriptions(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/webhooks/subscriptions", query=query)

    async def create_subscription(self, body: Any) -> dict[str, Any]:
        return await self._request("POST", "/v1/webhooks/subscriptions", body=body)

    async def delete_subscription(self, sub_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            "/v1/webhooks/subscriptions/{subID}",
            path_params={"subID": sub_id},
        )

    async def list_deliveries(
        self,
        sub_id: str,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/webhooks/subscriptions/{subID}/deliveries",
            path_params={"subID": sub_id},
            query=query,
        )

    async def get_delivery(self, sub_id: str, delivery_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/webhooks/subscriptions/{subID}/deliveries/{deliveryID}",
            path_params={"subID": sub_id, "deliveryID": delivery_id},
        )

    async def retry_delivery(self, sub_id: str, delivery_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            "/v1/webhooks/subscriptions/{subID}/deliveries/{deliveryID}/retry",
            path_params={"subID": sub_id, "deliveryID": delivery_id},
        )
