"""Billing and usage operations.

Combines spending limits, project budgets, anomaly detection, cost estimates,
forecasts, and usage reporting under a single service tag.
"""

from __future__ import annotations

from typing import Any

from strait.operations._base import AsyncBaseService, BaseService


class BillingService(BaseService):
    def get_spending_limit(self) -> dict[str, Any]:
        return self._request("GET", "/v1/spending-limit")

    def upsert_spending_limit(self, body: Any) -> dict[str, Any]:
        return self._request("PUT", "/v1/spending-limit", body=body)

    def get_project_budget(self) -> dict[str, Any]:
        return self._request("GET", "/v1/project-budget")

    def upsert_project_budget(self, body: Any) -> dict[str, Any]:
        return self._request("PUT", "/v1/project-budget", body=body)

    def get_anomaly_config(self) -> dict[str, Any]:
        return self._request("GET", "/v1/anomaly-config")

    def upsert_anomaly_config(self, body: Any) -> dict[str, Any]:
        return self._request("PUT", "/v1/anomaly-config", body=body)

    def get_cost_estimate(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/cost-estimate", query=query)

    def get_downgrade_preview(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/downgrade-preview", query=query)

    def check_org_limit(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/billing/check-org-limit", query=query)

    def list_usage_anomalies(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/usage/anomalies", query=query)

    def get_current_usage(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/usage/current", query=query)

    def get_usage_forecast(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/usage/forecast", query=query)

    def get_usage_history(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/usage/history", query=query)

    def export_usage(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/usage/export", query=query)

    def list_project_costs(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/usage/projects", query=query)

    def get_email_preferences(self) -> dict[str, Any]:
        return self._request("GET", "/v1/usage/email-preferences")

    def upsert_email_preferences(self, body: Any) -> dict[str, Any]:
        return self._request("PUT", "/v1/usage/email-preferences", body=body)


class AsyncBillingService(AsyncBaseService):
    async def get_spending_limit(self) -> dict[str, Any]:
        return await self._request("GET", "/v1/spending-limit")

    async def upsert_spending_limit(self, body: Any) -> dict[str, Any]:
        return await self._request("PUT", "/v1/spending-limit", body=body)

    async def get_project_budget(self) -> dict[str, Any]:
        return await self._request("GET", "/v1/project-budget")

    async def upsert_project_budget(self, body: Any) -> dict[str, Any]:
        return await self._request("PUT", "/v1/project-budget", body=body)

    async def get_anomaly_config(self) -> dict[str, Any]:
        return await self._request("GET", "/v1/anomaly-config")

    async def upsert_anomaly_config(self, body: Any) -> dict[str, Any]:
        return await self._request("PUT", "/v1/anomaly-config", body=body)

    async def get_cost_estimate(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/cost-estimate", query=query)

    async def get_downgrade_preview(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/downgrade-preview", query=query)

    async def check_org_limit(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/billing/check-org-limit", query=query)

    async def list_usage_anomalies(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/usage/anomalies", query=query)

    async def get_current_usage(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/usage/current", query=query)

    async def get_usage_forecast(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/usage/forecast", query=query)

    async def get_usage_history(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/usage/history", query=query)

    async def export_usage(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/usage/export", query=query)

    async def list_project_costs(
        self,
        *,
        query: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._request("GET", "/v1/usage/projects", query=query)

    async def get_email_preferences(self) -> dict[str, Any]:
        return await self._request("GET", "/v1/usage/email-preferences")

    async def upsert_email_preferences(self, body: Any) -> dict[str, Any]:
        return await self._request("PUT", "/v1/usage/email-preferences", body=body)
