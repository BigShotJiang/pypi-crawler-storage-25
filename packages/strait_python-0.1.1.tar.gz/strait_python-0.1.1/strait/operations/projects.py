"""Project management operations."""

from __future__ import annotations

from typing import Any

from strait.operations._base import AsyncBaseService, BaseService


class ProjectsService(BaseService):
    def list(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/projects", query=query)

    def create(self, body: Any) -> dict[str, Any]:
        return self._request("POST", "/v1/projects", body=body)

    def get(self, project_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/projects/{projectID}",
            path_params={"projectID": project_id},
        )

    def delete(self, project_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            "/v1/projects/{projectID}",
            path_params={"projectID": project_id},
        )

    def get_settings(self, project_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/projects/{projectID}/settings",
            path_params={"projectID": project_id},
        )

    def upsert_settings(self, project_id: str, body: Any) -> dict[str, Any]:
        return self._request(
            "PUT",
            "/v1/projects/{projectID}/settings",
            path_params={"projectID": project_id},
            body=body,
        )

    def get_activity_stream(self, project_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            "/v1/projects/{projectID}/activity/stream",
            path_params={"projectID": project_id},
        )


class AsyncProjectsService(AsyncBaseService):
    async def list(self, *, query: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._request("GET", "/v1/projects", query=query)

    async def create(self, body: Any) -> dict[str, Any]:
        return await self._request("POST", "/v1/projects", body=body)

    async def get(self, project_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/projects/{projectID}",
            path_params={"projectID": project_id},
        )

    async def delete(self, project_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            "/v1/projects/{projectID}",
            path_params={"projectID": project_id},
        )

    async def get_settings(self, project_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/projects/{projectID}/settings",
            path_params={"projectID": project_id},
        )

    async def upsert_settings(self, project_id: str, body: Any) -> dict[str, Any]:
        return await self._request(
            "PUT",
            "/v1/projects/{projectID}/settings",
            path_params={"projectID": project_id},
            body=body,
        )

    async def get_activity_stream(self, project_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            "/v1/projects/{projectID}/activity/stream",
            path_params={"projectID": project_id},
        )
