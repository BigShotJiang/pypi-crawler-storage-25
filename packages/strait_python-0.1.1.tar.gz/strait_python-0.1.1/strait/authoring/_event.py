"""Event definition DSL."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass
class EventDefinition:
    key: str
    validate: Callable[[Any], Any] | None = None

    def parse(self, input: Any) -> Any:  # noqa: A002
        if self.validate is not None:
            return self.validate(input)
        return input


def define_event(
    key: str,
    validate: Callable[[Any], Any] | None = None,
) -> EventDefinition:
    return EventDefinition(key=key, validate=validate)
