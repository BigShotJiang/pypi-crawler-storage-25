"""Strait SDK Client and AsyncClient."""

from __future__ import annotations

import contextlib
import json
import time
from collections.abc import AsyncIterator, Iterator
from typing import Any, Self

import httpx

from strait._config import (
    AuthMode,
    AuthType,
    Config,
    config_from_env,
    config_from_file,
    get_authorization_header,
    normalize_base_url,
)
from strait._errors import (
    ApiError,
    DecodeError,
    RateLimitedError,
    TransportError,
    map_http_error,
)
from strait._middleware import (
    Middleware,
    MiddlewareErrorContext,
    MiddlewareRequestContext,
    MiddlewareResponseContext,
)
from strait._types import JsonDict
from strait.composition._retry import (
    JitterStrategy,
    RetryOptions,
    with_retry,
    with_retry_async,
)
from strait.operations.analytics import AnalyticsService, AsyncAnalyticsService
from strait.operations.api_keys import APIKeysService, AsyncAPIKeysService
from strait.operations.batch_operations import AsyncBatchOperationsService, BatchOperationsService
from strait.operations.billing import AsyncBillingService, BillingService
from strait.operations.cli_auth import AsyncCliAuthService, CliAuthService
from strait.operations.deployments import AsyncDeploymentsService, DeploymentsService
from strait.operations.environments import AsyncEnvironmentsService, EnvironmentsService
from strait.operations.event_sources import AsyncEventSourcesService, EventSourcesService
from strait.operations.event_triggers import AsyncEventTriggersService, EventTriggersService
from strait.operations.health import AsyncHealthService, HealthService
from strait.operations.job_groups import AsyncJobGroupsService, JobGroupsService
from strait.operations.jobs import AsyncJobsService, JobsService
from strait.operations.log_drains import AsyncLogDrainsService, LogDrainsService
from strait.operations.notification_channels import (
    AsyncNotificationChannelsService,
    NotificationChannelsService,
)
from strait.operations.organizations import AsyncOrganizationsService, OrganizationsService
from strait.operations.projects import AsyncProjectsService, ProjectsService
from strait.operations.rbac import AsyncRBACService, RBACService
from strait.operations.regions import AsyncRegionsService, RegionsService
from strait.operations.runs import AsyncRunsService, RunsService
from strait.operations.sdk_runs import AsyncSDKRunsService, SDKRunsService
from strait.operations.secrets import AsyncSecretsService, SecretsService
from strait.operations.stats import AsyncStatsService, StatsService
from strait.operations.webhooks import AsyncWebhooksService, WebhooksService
from strait.operations.workflow_runs import AsyncWorkflowRunsService, WorkflowRunsService
from strait.operations.workflows import AsyncWorkflowsService, WorkflowsService


def _default_should_retry(err: Exception, attempt: int, max_attempts: int) -> bool:
    """Retry transport failures, 429s, and 5xx responses."""
    del attempt, max_attempts
    if isinstance(err, TransportError | RateLimitedError):
        return True
    if isinstance(err, ApiError):
        return err.status >= 500
    return False


_DEFAULT_RETRY = RetryOptions(
    attempts=3,
    delay_ms=250,
    factor=2.0,
    max_delay_ms=30_000,
    jitter=JitterStrategy.FULL,
    should_retry=_default_should_retry,
)


def _resolve_auth(
    bearer_token: str | None,
    api_key: str | None,
    run_token: str | None,
    auth: AuthMode | None,
) -> AuthMode | None:
    if auth is not None:
        return auth
    if bearer_token is not None:
        return AuthMode(type=AuthType.BEARER, token=bearer_token)
    if api_key is not None:
        return AuthMode(type=AuthType.API_KEY, token=api_key)
    if run_token is not None:
        return AuthMode(type=AuthType.RUN_TOKEN, token=run_token)
    return None


class Client:
    """Synchronous Strait API client."""

    def __init__(
        self,
        *,
        base_url: str = "",
        bearer_token: str | None = None,
        api_key: str | None = None,
        run_token: str | None = None,
        auth: AuthMode | None = None,
        default_headers: dict[str, str] | None = None,
        timeout_ms: int = 30_000,
        http_client: httpx.Client | None = None,
        middleware: list[Middleware] | None = None,
        retry: RetryOptions | None = _DEFAULT_RETRY,
    ) -> None:
        resolved_auth = _resolve_auth(bearer_token, api_key, run_token, auth)
        if resolved_auth is None:
            resolved_auth = AuthMode(type=AuthType.API_KEY, token="")

        self._config = Config(
            base_url=normalize_base_url(base_url),
            auth=resolved_auth,
            default_headers=default_headers or {},
            timeout_ms=timeout_ms,
        )
        self._middleware = middleware or []
        self._owns_client = http_client is None
        self._http = http_client or httpx.Client(timeout=timeout_ms / 1000.0)
        self._retry: RetryOptions | None = retry

        self.health = HealthService(self)
        self.jobs = JobsService(self)
        self.runs = RunsService(self)
        self.workflows = WorkflowsService(self)
        self.workflow_runs = WorkflowRunsService(self)
        self.deployments = DeploymentsService(self)
        self.environments = EnvironmentsService(self)
        self.secrets = SecretsService(self)
        self.api_keys = APIKeysService(self)
        self.webhooks = WebhooksService(self)
        self.event_triggers = EventTriggersService(self)
        self.event_sources = EventSourcesService(self)
        self.batch_operations = BatchOperationsService(self)
        self.stats = StatsService(self)
        self.analytics = AnalyticsService(self)
        self.log_drains = LogDrainsService(self)
        self.sdk_runs = SDKRunsService(self)
        self.rbac = RBACService(self)
        self.job_groups = JobGroupsService(self)
        self.notification_channels = NotificationChannelsService(self)
        self.projects = ProjectsService(self)
        self.organizations = OrganizationsService(self)
        self.regions = RegionsService(self)
        self.cli_auth = CliAuthService(self)
        self.billing = BillingService(self)

    @classmethod
    def from_env(cls, **overrides: Any) -> Client:
        cfg = config_from_env()
        return cls(
            base_url=overrides.pop("base_url", cfg.base_url),
            auth=overrides.pop("auth", cfg.auth),
            timeout_ms=overrides.pop("timeout_ms", cfg.timeout_ms),
            **overrides,
        )

    @classmethod
    def from_file(
        cls,
        path: str | None = None,
        search_dir: str | None = None,
        **overrides: Any,
    ) -> Client:
        cfg = config_from_file(path=path, search_dir=search_dir)
        return cls(
            base_url=overrides.pop("base_url", cfg.base_url),
            auth=overrides.pop("auth", cfg.auth),
            timeout_ms=overrides.pop("timeout_ms", cfg.timeout_ms),
            **overrides,
        )

    @property
    def base_url(self) -> str:
        return self._config.base_url

    def do_request(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
        body: Any = None,
    ) -> JsonDict:
        url = self._config.base_url + path

        req_headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": get_authorization_header(self._config.auth),
        }
        req_headers.update(self._config.default_headers)
        if headers:
            req_headers.update(headers)

        def attempt() -> JsonDict:
            for mw in self._middleware:
                if mw.on_request:
                    mw.on_request(
                        MiddlewareRequestContext(
                            method=method,
                            url=url,
                            headers=dict(req_headers),
                        )
                    )

            start = time.monotonic()
            try:
                response = self._http.request(
                    method,
                    url,
                    params=query,
                    headers=req_headers,
                    json=body if body is not None else None,
                )
            except httpx.HTTPError as exc:
                for mw in self._middleware:
                    if mw.on_error:
                        mw.on_error(
                            MiddlewareErrorContext(
                                method=method,
                                url=url,
                                error=exc,
                            )
                        )
                raise TransportError(f"request failed: {exc}", cause=exc) from exc

            duration_ms = int((time.monotonic() - start) * 1000)
            for mw in self._middleware:
                if mw.on_response:
                    mw.on_response(
                        MiddlewareResponseContext(
                            method=method,
                            url=url,
                            status=response.status_code,
                            duration_ms=duration_ms,
                        )
                    )

            resp_body = response.text

            if response.status_code < 200 or response.status_code >= 300:
                err_body: Any = None
                with contextlib.suppress(Exception):
                    err_body = response.json()
                msg = f"HTTP {response.status_code}: {method} {path}"
                if isinstance(err_body, dict) and "message" in err_body:
                    msg = err_body["message"]
                raise map_http_error(response.status_code, msg, err_body)

            if not resp_body:
                return {}

            try:
                return response.json()  # type: ignore[no-any-return]
            except Exception as exc:
                raise DecodeError(
                    f"failed to decode response: {exc}", body=resp_body, cause=exc
                ) from exc

        if self._retry is None:
            return attempt()
        return with_retry(attempt, self._retry)

    def do_stream(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Iterator[dict[str, Any]]:
        url = self._config.base_url + path

        req_headers: dict[str, str] = {
            "Accept": "text/event-stream",
            "Authorization": get_authorization_header(self._config.auth),
        }
        req_headers.update(self._config.default_headers)
        if headers:
            req_headers.update(headers)

        for mw in self._middleware:
            if mw.on_request:
                mw.on_request(
                    MiddlewareRequestContext(
                        method=method,
                        url=url,
                        headers=dict(req_headers),
                    )
                )

        start = time.monotonic()
        try:
            stream_cm = self._http.stream(method, url, params=query, headers=req_headers)
        except httpx.HTTPError as exc:
            for mw in self._middleware:
                if mw.on_error:
                    mw.on_error(MiddlewareErrorContext(method=method, url=url, error=exc))
            raise TransportError(f"request failed: {exc}", cause=exc) from exc

        with stream_cm as response:
            duration_ms = int((time.monotonic() - start) * 1000)
            for mw in self._middleware:
                if mw.on_response:
                    mw.on_response(
                        MiddlewareResponseContext(
                            method=method,
                            url=url,
                            status=response.status_code,
                            duration_ms=duration_ms,
                        )
                    )

            if response.status_code < 200 or response.status_code >= 300:
                response.read()
                err_body: Any = None
                with contextlib.suppress(Exception):
                    err_body = response.json()
                msg = f"HTTP {response.status_code}: {method} {path}"
                if isinstance(err_body, dict) and "message" in err_body:
                    msg = err_body["message"]
                raise map_http_error(response.status_code, msg, err_body)

            for line in response.iter_lines():
                event = _parse_sse_line(line)
                if event is not None:
                    yield event

    def close(self) -> None:
        if self._owns_client:
            self._http.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class AsyncClient:
    """Asynchronous Strait API client."""

    def __init__(
        self,
        *,
        base_url: str = "",
        bearer_token: str | None = None,
        api_key: str | None = None,
        run_token: str | None = None,
        auth: AuthMode | None = None,
        default_headers: dict[str, str] | None = None,
        timeout_ms: int = 30_000,
        http_client: httpx.AsyncClient | None = None,
        middleware: list[Middleware] | None = None,
        retry: RetryOptions | None = _DEFAULT_RETRY,
    ) -> None:
        resolved_auth = _resolve_auth(bearer_token, api_key, run_token, auth)
        if resolved_auth is None:
            resolved_auth = AuthMode(type=AuthType.API_KEY, token="")

        self._config = Config(
            base_url=normalize_base_url(base_url),
            auth=resolved_auth,
            default_headers=default_headers or {},
            timeout_ms=timeout_ms,
        )
        self._middleware = middleware or []
        self._owns_client = http_client is None
        self._http = http_client or httpx.AsyncClient(timeout=timeout_ms / 1000.0)
        self._retry: RetryOptions | None = retry

        self.health = AsyncHealthService(self)
        self.jobs = AsyncJobsService(self)
        self.runs = AsyncRunsService(self)
        self.workflows = AsyncWorkflowsService(self)
        self.workflow_runs = AsyncWorkflowRunsService(self)
        self.deployments = AsyncDeploymentsService(self)
        self.environments = AsyncEnvironmentsService(self)
        self.secrets = AsyncSecretsService(self)
        self.api_keys = AsyncAPIKeysService(self)
        self.webhooks = AsyncWebhooksService(self)
        self.event_triggers = AsyncEventTriggersService(self)
        self.event_sources = AsyncEventSourcesService(self)
        self.batch_operations = AsyncBatchOperationsService(self)
        self.stats = AsyncStatsService(self)
        self.analytics = AsyncAnalyticsService(self)
        self.log_drains = AsyncLogDrainsService(self)
        self.sdk_runs = AsyncSDKRunsService(self)
        self.rbac = AsyncRBACService(self)
        self.job_groups = AsyncJobGroupsService(self)
        self.notification_channels = AsyncNotificationChannelsService(self)
        self.projects = AsyncProjectsService(self)
        self.organizations = AsyncOrganizationsService(self)
        self.regions = AsyncRegionsService(self)
        self.cli_auth = AsyncCliAuthService(self)
        self.billing = AsyncBillingService(self)

    @classmethod
    def from_env(cls, **overrides: Any) -> AsyncClient:
        cfg = config_from_env()
        return cls(
            base_url=overrides.pop("base_url", cfg.base_url),
            auth=overrides.pop("auth", cfg.auth),
            timeout_ms=overrides.pop("timeout_ms", cfg.timeout_ms),
            **overrides,
        )

    @classmethod
    def from_file(
        cls,
        path: str | None = None,
        search_dir: str | None = None,
        **overrides: Any,
    ) -> AsyncClient:
        cfg = config_from_file(path=path, search_dir=search_dir)
        return cls(
            base_url=overrides.pop("base_url", cfg.base_url),
            auth=overrides.pop("auth", cfg.auth),
            timeout_ms=overrides.pop("timeout_ms", cfg.timeout_ms),
            **overrides,
        )

    @property
    def base_url(self) -> str:
        return self._config.base_url

    async def do_request(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
        body: Any = None,
    ) -> JsonDict:
        url = self._config.base_url + path

        req_headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": get_authorization_header(self._config.auth),
        }
        req_headers.update(self._config.default_headers)
        if headers:
            req_headers.update(headers)

        async def attempt() -> JsonDict:
            for mw in self._middleware:
                if mw.on_request:
                    mw.on_request(
                        MiddlewareRequestContext(
                            method=method,
                            url=url,
                            headers=dict(req_headers),
                        )
                    )

            start = time.monotonic()
            try:
                response = await self._http.request(
                    method,
                    url,
                    params=query,
                    headers=req_headers,
                    json=body if body is not None else None,
                )
            except httpx.HTTPError as exc:
                for mw in self._middleware:
                    if mw.on_error:
                        mw.on_error(
                            MiddlewareErrorContext(
                                method=method,
                                url=url,
                                error=exc,
                            )
                        )
                raise TransportError(f"request failed: {exc}", cause=exc) from exc

            duration_ms = int((time.monotonic() - start) * 1000)
            for mw in self._middleware:
                if mw.on_response:
                    mw.on_response(
                        MiddlewareResponseContext(
                            method=method,
                            url=url,
                            status=response.status_code,
                            duration_ms=duration_ms,
                        )
                    )

            resp_body = response.text

            if response.status_code < 200 or response.status_code >= 300:
                err_body: Any = None
                with contextlib.suppress(Exception):
                    err_body = response.json()
                msg = f"HTTP {response.status_code}: {method} {path}"
                if isinstance(err_body, dict) and "message" in err_body:
                    msg = err_body["message"]
                raise map_http_error(response.status_code, msg, err_body)

            if not resp_body:
                return {}

            try:
                return response.json()  # type: ignore[no-any-return]
            except Exception as exc:
                raise DecodeError(
                    f"failed to decode response: {exc}", body=resp_body, cause=exc
                ) from exc

        if self._retry is None:
            return await attempt()
        return await with_retry_async(attempt, self._retry)  # type: ignore[arg-type]

    async def do_stream(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        url = self._config.base_url + path

        req_headers: dict[str, str] = {
            "Accept": "text/event-stream",
            "Authorization": get_authorization_header(self._config.auth),
        }
        req_headers.update(self._config.default_headers)
        if headers:
            req_headers.update(headers)

        for mw in self._middleware:
            if mw.on_request:
                mw.on_request(
                    MiddlewareRequestContext(
                        method=method,
                        url=url,
                        headers=dict(req_headers),
                    )
                )

        start = time.monotonic()
        try:
            stream_cm = self._http.stream(method, url, params=query, headers=req_headers)
        except httpx.HTTPError as exc:
            for mw in self._middleware:
                if mw.on_error:
                    mw.on_error(MiddlewareErrorContext(method=method, url=url, error=exc))
            raise TransportError(f"request failed: {exc}", cause=exc) from exc

        async with stream_cm as response:
            duration_ms = int((time.monotonic() - start) * 1000)
            for mw in self._middleware:
                if mw.on_response:
                    mw.on_response(
                        MiddlewareResponseContext(
                            method=method,
                            url=url,
                            status=response.status_code,
                            duration_ms=duration_ms,
                        )
                    )

            if response.status_code < 200 or response.status_code >= 300:
                await response.aread()
                err_body: Any = None
                with contextlib.suppress(Exception):
                    err_body = response.json()
                msg = f"HTTP {response.status_code}: {method} {path}"
                if isinstance(err_body, dict) and "message" in err_body:
                    msg = err_body["message"]
                raise map_http_error(response.status_code, msg, err_body)

            async for line in response.aiter_lines():
                event = _parse_sse_line(line)
                if event is not None:
                    yield event

    async def close(self) -> None:
        if self._owns_client:
            await self._http.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()


def _parse_sse_line(line: str) -> dict[str, Any] | None:
    """Parse a single SSE wire line.

    Returns the JSON-decoded event payload for `data:` lines, or None for
    blank lines, comments, or non-data fields (event:, id:, retry:).
    """
    if not line:
        return None
    if not line.startswith("data:"):
        return None
    payload = line[5:].lstrip()
    if not payload:
        return None
    try:
        decoded = json.loads(payload)
    except json.JSONDecodeError:
        return {"data": payload}
    if isinstance(decoded, dict):
        return decoded
    return {"data": decoded}
