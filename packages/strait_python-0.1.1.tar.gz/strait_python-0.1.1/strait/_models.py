"""TypedDict response models for the 5 core resources.

These shapes are structural (TypedDict, not dataclasses or Pydantic) so they
add type safety without changing the runtime contract: server responses
remain plain dicts and callers can keep treating them that way.

`total=False` is used throughout because the API may omit fields depending
on context, and because client code historically accessed responses with
`.get(...)` semantics. Adding a stricter surface would be a breaking change.
"""

from __future__ import annotations

from typing import Any, TypedDict


class JobVersion(TypedDict, total=False):
    id: str
    job_id: str
    version: int
    created_at: str
    config: dict[str, Any]


class Job(TypedDict, total=False):
    id: str
    slug: str
    name: str
    description: str
    project_id: str
    organization_id: str
    enabled: bool
    paused: bool
    version: int
    latest_version: JobVersion
    tags: list[str]
    created_at: str
    updated_at: str
    config: dict[str, Any]


class RunUsage(TypedDict, total=False):
    provider: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cost_microusd: int


class Run(TypedDict, total=False):
    id: str
    job_id: str
    job_slug: str
    project_id: str
    organization_id: str
    status: str
    attempt: int
    parent_run_id: str | None
    workflow_run_id: str | None
    payload: dict[str, Any]
    result: dict[str, Any]
    error: str | None
    usage: RunUsage
    cost_microusd: int
    started_at: str | None
    completed_at: str | None
    created_at: str
    updated_at: str


class WorkflowStep(TypedDict, total=False):
    id: str
    type: str
    name: str
    job_slug: str
    depends_on: list[str]
    config: dict[str, Any]


class Workflow(TypedDict, total=False):
    id: str
    slug: str
    name: str
    description: str
    project_id: str
    organization_id: str
    enabled: bool
    version: int
    steps: list[WorkflowStep]
    tags: list[str]
    created_at: str
    updated_at: str


class WorkflowRunStep(TypedDict, total=False):
    id: str
    step_id: str
    run_id: str | None
    status: str
    started_at: str | None
    completed_at: str | None


class WorkflowRun(TypedDict, total=False):
    id: str
    workflow_id: str
    workflow_slug: str
    project_id: str
    organization_id: str
    status: str
    attempt: int
    payload: dict[str, Any]
    result: dict[str, Any]
    error: str | None
    steps: list[WorkflowRunStep]
    started_at: str | None
    completed_at: str | None
    created_at: str
    updated_at: str


class Deployment(TypedDict, total=False):
    id: str
    project_id: str
    organization_id: str
    status: str
    job_count: int
    workflow_count: int
    created_by: str
    finalized_at: str | None
    created_at: str
    updated_at: str


__all__ = [
    "Deployment",
    "Job",
    "JobVersion",
    "Run",
    "RunUsage",
    "Workflow",
    "WorkflowRun",
    "WorkflowRunStep",
    "WorkflowStep",
]
