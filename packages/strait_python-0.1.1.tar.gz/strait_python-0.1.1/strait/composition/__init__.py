"""Composition helpers: Result, retry, wait, paginate, idempotency, deployments."""

from strait.composition._checkpoint_resume import with_checkpoint_resume
from strait.composition._cost_budget import (
    CostBudgetOptions,
    CostTracker,
    create_cost_tracker,
    with_cost_budget,
)
from strait.composition._deployments import (
    CreateAndFinalizeOutput,
    CreateFinalizePromoteOutput,
    create_and_finalize_deployment,
    create_finalize_promote_deployment,
)
from strait.composition._idempotency import with_idempotency, with_idempotency_header
from strait.composition._paginate import (
    PaginatedQuery,
    PaginatedResponse,
    collect_all,
    paginate,
)
from strait.composition._result import Result
from strait.composition._retry import RetryOptions, with_retry, with_retry_async
from strait.composition._trigger import trigger_and_wait, trigger_and_wait_async
from strait.composition._wait import WaitForRunOptions, wait_for_run, wait_for_run_async

__all__ = [
    "CostBudgetOptions",
    "CostTracker",
    "CreateAndFinalizeOutput",
    "CreateFinalizePromoteOutput",
    "PaginatedQuery",
    "PaginatedResponse",
    "Result",
    "RetryOptions",
    "WaitForRunOptions",
    "collect_all",
    "create_and_finalize_deployment",
    "create_cost_tracker",
    "create_finalize_promote_deployment",
    "paginate",
    "trigger_and_wait",
    "trigger_and_wait_async",
    "wait_for_run",
    "wait_for_run_async",
    "with_checkpoint_resume",
    "with_cost_budget",
    "with_idempotency",
    "with_idempotency_header",
    "with_retry",
    "with_retry_async",
]
