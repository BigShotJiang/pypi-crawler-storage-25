"""
Analytics client for query traces, metrics, and performance analysis.
"""

from typing import Optional, List, Dict, Any, TYPE_CHECKING
from datetime import datetime

from .models import (
    QueryTrace,
    QueryTraceDetails,
    MetricsSummary,
    CostBreakdown,
    PerformanceStats,
    TokenUsage,
    TimingBreakdown,
    ChunkInfo,
    TrainlyError,
)

if TYPE_CHECKING:
    from .client import TrainlyClient


class AnalyticsClient:
    """
    Client for accessing analytics, traces, and metrics.

    This client provides methods for analyzing query performance, costs,
    and system behavior.

    Example:
        >>> client = TrainlyClient(api_key="tk_...", project_id="...")
        >>> traces = client.analytics.get_query_traces(limit=10)
        >>> for trace in traces:
        ...     print(f"Query: {trace.query}, Time: {trace.total_time_ms}ms")
    """

    def __init__(self, parent_client: "TrainlyClient", limited: bool = False):
        """Initialize the analytics client with a parent client."""
        self.parent = parent_client
        self.base_url = parent_client.base_url
        self.project_id = parent_client.project_id
        self.session = parent_client.session
        self.limited = limited

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request to the analytics API."""
        url = f"{self.base_url}/{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                timeout=self.parent.timeout,
            )

            if not response.ok:
                error_data = response.json() if response.content else {}
                raise TrainlyError(
                    error_data.get("detail", f"HTTP {response.status_code}"),
                    status_code=response.status_code,
                    details=error_data,
                )

            return response.json()

        except TrainlyError:
            raise
        except Exception as e:
            raise TrainlyError(f"Request failed: {str(e)}")

    # Query Traces

    def get_query_traces(
        self,
        limit: int = 100,
        status: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> List[QueryTrace]:
        """
        Get query traces with optional filtering.

        Args:
            limit: Maximum number of traces to return.
            status: Optional filter by status ("success" or "error").
            start_date: Optional start date for filtering.
            end_date: Optional end date for filtering.

        Returns:
            List of QueryTrace objects.

        Example:
            >>> from datetime import datetime, timedelta
            >>> yesterday = datetime.now() - timedelta(days=1)
            >>> traces = client.analytics.get_query_traces(
            ...     limit=50,
            ...     status="success",
            ...     start_date=yesterday
            ... )
        """
        params = {"limit": limit}
        if status:
            params["status"] = status
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()

        response = self._make_request(
            "GET", f"v1/{self.project_id}/analytics/traces", params=params
        )

        return [self._parse_query_trace(t) for t in response["traces"]]

    def get_trace_details(self, trace_id: str) -> QueryTraceDetails:
        """
        Get detailed information about a specific query trace.

        Args:
            trace_id: ID of the trace to retrieve.

        Returns:
            QueryTraceDetails object with full trace information.

        Example:
            >>> details = client.analytics.get_trace_details(trace_id)
            >>> print(f"LLM time: {details.timing.llm_time}ms")
            >>> print(f"Chunks retrieved: {len(details.chunks)}")
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/analytics/traces/{trace_id}"
        )

        return self._parse_query_trace_details(response)

    # Metrics & Analytics

    def get_metrics_summary(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> MetricsSummary:
        """
        Get summary metrics for queries.

        Args:
            start_date: Optional start date for filtering.
            end_date: Optional end date for filtering.

        Returns:
            MetricsSummary object with aggregate statistics.
        """
        params = {}
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()

        response = self._make_request(
            "GET", f"v1/{self.project_id}/analytics/metrics", params=params
        )

        return MetricsSummary(
            total_queries=response["total_queries"],
            successful_queries=response["successful_queries"],
            failed_queries=response["failed_queries"],
            average_response_time_ms=response["average_response_time_ms"],
            total_cost=response["total_cost"],
            average_cost_per_query=response["average_cost_per_query"],
            date_range_start=datetime.fromisoformat(response["date_range_start"]),
            date_range_end=datetime.fromisoformat(response["date_range_end"]),
        )

    def export_query_logs(
        self,
        format: str = "csv",
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> str:
        """
        Export query logs to a file.

        Args:
            format: Export format ("csv", "json", or "jsonl").
            start_date: Optional start date for filtering.
            end_date: Optional end date for filtering.

        Returns:
            URL or path to the exported file.

        Example:
            >>> url = client.analytics.export_query_logs(format="csv")
            >>> print(f"Download logs from: {url}")
        """
        params = {"format": format}
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()

        response = self._make_request(
            "GET", f"v1/{self.project_id}/analytics/export", params=params
        )

        return response["download_url"]

    def get_cost_breakdown(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> CostBreakdown:
        """
        Get cost breakdown by component.

        Args:
            start_date: Optional start date for filtering.
            end_date: Optional end date for filtering.

        Returns:
            CostBreakdown object with costs by component.

        Example:
            >>> costs = client.analytics.get_cost_breakdown()
            >>> print(f"Total: ${costs.total_cost:.2f}")
            >>> print(f"LLM: ${costs.llm_cost:.2f}")
            >>> print(f"Embeddings: ${costs.embedding_cost:.2f}")
        """
        params = {}
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()

        response = self._make_request(
            "GET", f"v1/{self.project_id}/analytics/cost-breakdown", params=params
        )

        return CostBreakdown(
            total_cost=response["total_cost"],
            embedding_cost=response["embedding_cost"],
            llm_cost=response["llm_cost"],
            reranking_cost=response["reranking_cost"],
            date_range_start=datetime.fromisoformat(response["date_range_start"]),
            date_range_end=datetime.fromisoformat(response["date_range_end"]),
        )

    def get_performance_stats(self) -> PerformanceStats:
        """
        Get performance statistics.

        Returns:
            PerformanceStats object with percentile metrics.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/analytics/performance"
        )

        return PerformanceStats(
            p50_response_time_ms=response["p50_response_time_ms"],
            p95_response_time_ms=response["p95_response_time_ms"],
            p99_response_time_ms=response["p99_response_time_ms"],
            average_chunks_retrieved=response["average_chunks_retrieved"],
            average_tokens_per_query=response["average_tokens_per_query"],
        )

    # Helper Methods

    def _parse_query_trace(self, data: Dict[str, Any]) -> QueryTrace:
        """Parse a query trace from API response."""
        tokens = TokenUsage(
            prompt_tokens=data["tokens"]["prompt_tokens"],
            completion_tokens=data["tokens"]["completion_tokens"],
            total_tokens=data["tokens"]["total_tokens"],
        )

        return QueryTrace(
            trace_id=data["trace_id"],
            query=data["query"],
            response=data["response"],
            status=data["status"],
            total_time_ms=data["total_time_ms"],
            tokens=tokens,
            cost=data["cost"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
        )

    def _parse_query_trace_details(self, data: Dict[str, Any]) -> QueryTraceDetails:
        """Parse detailed query trace from API response."""
        tokens = TokenUsage(
            prompt_tokens=data["tokens"]["prompt_tokens"],
            completion_tokens=data["tokens"]["completion_tokens"],
            total_tokens=data["tokens"]["total_tokens"],
        )

        timing = TimingBreakdown(
            preprocessing_time=data["timing"]["preprocessing_time"],
            embedding_time=data["timing"]["embedding_time"],
            retrieval_time=data["timing"]["retrieval_time"],
            reranking_time=data["timing"]["reranking_time"],
            context_assembly_time=data["timing"]["context_assembly_time"],
            prompt_construction_time=data["timing"]["prompt_construction_time"],
            llm_time=data["timing"]["llm_time"],
            postprocessing_time=data["timing"]["postprocessing_time"],
            total_time=data["timing"]["total_time"],
        )

        chunks = [
            ChunkInfo(
                chunk_id=c["chunk_id"],
                score=c["score"],
                source_file=c["source_file"],
                chunk_text=c["chunk_text"],
                rank_before_rerank=c.get("rank_before_rerank"),
                rank_after_rerank=c.get("rank_after_rerank"),
            )
            for c in data["chunks"]
        ]

        return QueryTraceDetails(
            trace_id=data["trace_id"],
            query=data["query"],
            response=data["response"],
            status=data["status"],
            total_time_ms=data["total_time_ms"],
            tokens=tokens,
            cost=data["cost"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            timing=timing,
            chunks=chunks,
            full_prompt=data.get("full_prompt"),
        )
