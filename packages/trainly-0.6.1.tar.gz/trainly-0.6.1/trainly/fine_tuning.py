"""
Fine-tuning client for managing DPO preference pairs and training jobs.
"""

from typing import Optional, List, Dict, Any, TYPE_CHECKING
import time
from datetime import datetime

from .models import (
    PreferencePair,
    TrainingJob,
    PaginatedPairs,
    BatchResult,
    TrainlyError,
)

if TYPE_CHECKING:
    from .client import TrainlyClient


class FineTuningClient:
    """
    Client for managing DPO fine-tuning preference pairs and training jobs.

    This client provides methods for creating preference pairs, starting training jobs,
    and managing fine-tuned models.

    Example:
        >>> client = TrainlyClient(api_key="tk_...", project_id="...")
        >>> pair = client.fine_tuning.create_preference_pair(
        ...     input_messages=[{"role": "user", "content": "Question"}],
        ...     preferred_output="Good answer",
        ...     non_preferred_output="Bad answer"
        ... )
        >>> job = client.fine_tuning.start_training_job()
        >>> final_job = client.fine_tuning.wait_for_job(job.job_id)
        >>> client.fine_tuning.activate_model(final_job.fine_tuned_model_id)
    """

    def __init__(self, parent_client: "TrainlyClient"):
        """Initialize the fine-tuning client with a parent client."""
        self.parent = parent_client
        self.base_url = parent_client.base_url
        self.project_id = parent_client.project_id
        self.session = parent_client.session

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request to the fine-tuning API."""
        url = f"{self.base_url}/{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                timeout=self.parent.timeout,
            )

            if not response.ok:
                error_data = response.json() if response.content else {}
                raise TrainlyError(
                    error_data.get("detail", f"HTTP {response.status_code}"),
                    status_code=response.status_code,
                    details=error_data,
                )

            return response.json()

        except TrainlyError:
            raise
        except Exception as e:
            raise TrainlyError(f"Request failed: {str(e)}")

    # Preference Pair Management

    def create_preference_pair(
        self,
        input_messages: List[Dict[str, str]],
        preferred_output: str,
        non_preferred_output: str,
        source: str = "manual",
        notes: Optional[str] = None,
    ) -> PreferencePair:
        """
        Create a new preference pair for DPO training.

        Args:
            input_messages: List of messages forming the input (e.g., [{"role": "user", "content": "..."}]).
            preferred_output: The preferred/correct output.
            non_preferred_output: The non-preferred/incorrect output.
            source: Source of the pair ("manual", "ai_generated", "from_test_run", "from_query_logs").
            notes: Optional notes about this preference pair.

        Returns:
            PreferencePair object with the created pair information.

        Example:
            >>> pair = client.fine_tuning.create_preference_pair(
            ...     input_messages=[{"role": "user", "content": "What is 2+2?"}],
            ...     preferred_output="2+2 equals 4.",
            ...     non_preferred_output="2+2 equals 5.",
            ...     source="manual"
            ... )
        """
        data = {
            "input_messages": input_messages,
            "preferred_output": preferred_output,
            "non_preferred_output": non_preferred_output,
            "source": source,
        }
        if notes:
            data["notes"] = notes

        response = self._make_request(
            "POST", f"v1/{self.project_id}/fine-tuning/pairs", json_data=data
        )

        return self._parse_preference_pair(response)

    def batch_create_pairs(self, pairs: List[Dict[str, Any]]) -> BatchResult:
        """
        Create multiple preference pairs at once.

        Args:
            pairs: List of dictionaries, each containing input_messages, preferred_output, non_preferred_output, etc.

        Returns:
            BatchResult with success/failure counts.

        Example:
            >>> pairs = [
            ...     {
            ...         "input_messages": [{"role": "user", "content": "Q1"}],
            ...         "preferred_output": "A1",
            ...         "non_preferred_output": "Wrong A1"
            ...     },
            ...     {
            ...         "input_messages": [{"role": "user", "content": "Q2"}],
            ...         "preferred_output": "A2",
            ...         "non_preferred_output": "Wrong A2"
            ...     }
            ... ]
            >>> result = client.fine_tuning.batch_create_pairs(pairs)
            >>> print(f"Created {result.successful} pairs")
        """
        response = self._make_request(
            "POST", f"v1/{self.project_id}/fine-tuning/pairs/batch", json_data={"pairs": pairs}
        )

        return BatchResult(
            success=response["success"],
            total=response["total"],
            successful=response["successful"],
            failed=response["failed"],
            errors=response.get("errors"),
        )

    def update_pair(
        self,
        pair_id: str,
        preferred_output: Optional[str] = None,
        non_preferred_output: Optional[str] = None,
        status: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> PreferencePair:
        """
        Update an existing preference pair.

        Args:
            pair_id: ID of the preference pair to update.
            preferred_output: New preferred output.
            non_preferred_output: New non-preferred output.
            status: New status ("draft", "approved", "rejected").
            notes: New notes.

        Returns:
            Updated PreferencePair object.
        """
        data = {}
        if preferred_output is not None:
            data["preferred_output"] = preferred_output
        if non_preferred_output is not None:
            data["non_preferred_output"] = non_preferred_output
        if status is not None:
            data["status"] = status
        if notes is not None:
            data["notes"] = notes

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/fine-tuning/pairs/{pair_id}", json_data=data
        )

        return self._parse_preference_pair(response)

    def delete_pair(self, pair_id: str) -> bool:
        """
        Delete a preference pair.

        Args:
            pair_id: ID of the preference pair to delete.

        Returns:
            True if deletion was successful.
        """
        response = self._make_request(
            "DELETE", f"v1/{self.project_id}/fine-tuning/pairs/{pair_id}"
        )
        return response.get("success", False)

    def list_pairs(
        self,
        status: Optional[str] = None,
        page: int = 1,
        limit: int = 50,
    ) -> PaginatedPairs:
        """
        List preference pairs with optional filtering.

        Args:
            status: Optional filter by status ("draft", "approved", "rejected", "used_in_training").
            page: Page number (1-indexed).
            limit: Number of pairs per page.

        Returns:
            PaginatedPairs object with list of preference pairs.
        """
        params = {"page": page, "limit": limit}
        if status:
            params["status"] = status

        response = self._make_request(
            "GET", f"v1/{self.project_id}/fine-tuning/pairs", params=params
        )

        pairs = [self._parse_preference_pair(p) for p in response["pairs"]]

        return PaginatedPairs(
            pairs=pairs,
            total=response["total"],
            page=response["page"],
            limit=response["limit"],
            has_more=response["has_more"],
        )

    def approve_pairs(self, pair_ids: List[str]) -> BatchResult:
        """
        Approve multiple preference pairs for training.

        Args:
            pair_ids: List of preference pair IDs to approve.

        Returns:
            BatchResult with success/failure counts.
        """
        response = self._make_request(
            "POST",
            f"v1/{self.project_id}/fine-tuning/pairs/bulk-approve",
            json_data={"pair_ids": pair_ids},
        )

        return BatchResult(
            success=response["success"],
            total=response["total"],
            successful=response["successful"],
            failed=response["failed"],
            errors=response.get("errors"),
        )

    def reject_pairs(self, pair_ids: List[str]) -> BatchResult:
        """
        Reject multiple preference pairs.

        Args:
            pair_ids: List of preference pair IDs to reject.

        Returns:
            BatchResult with success/failure counts.
        """
        response = self._make_request(
            "POST",
            f"v1/{self.project_id}/fine-tuning/pairs/bulk-reject",
            json_data={"pair_ids": pair_ids},
        )

        return BatchResult(
            success=response["success"],
            total=response["total"],
            successful=response["successful"],
            failed=response["failed"],
            errors=response.get("errors"),
        )

    # Generate Training Data from Tests

    def generate_pairs_from_test_run(
        self,
        run_id: str,
        only_failed: bool = True,
        synthesize_good: bool = True,
    ) -> List[PreferencePair]:
        """
        Generate preference pairs from a test run.

        Args:
            run_id: ID of the test run to generate pairs from.
            only_failed: If True, only generate pairs from failed tests.
            synthesize_good: If True, synthesize good outputs when all outputs fail.

        Returns:
            List of generated PreferencePair objects.

        Example:
            >>> run = client.testing.run_suite(suite_id)
            >>> results = client.testing.wait_for_run(run.run_id)
            >>> pairs = client.fine_tuning.generate_pairs_from_test_run(
            ...     run_id=run.run_id,
            ...     only_failed=True
            ... )
            >>> print(f"Generated {len(pairs)} training pairs")
        """
        data = {"only_failed": only_failed, "synthesize_good": synthesize_good}

        response = self._make_request(
            "POST",
            f"v1/{self.project_id}/fine-tuning/pairs/generate-from-test-run",
            json_data={"run_id": run_id, **data},
        )

        return [self._parse_preference_pair(p) for p in response["pairs"]]

    # Training Job Management

    def start_training_job(
        self,
        base_model: str = "gpt-4o-mini",
        suffix: Optional[str] = None,
        beta: float = 0.1,
        min_approved_pairs: int = 10,
    ) -> TrainingJob:
        """
        Start a new DPO fine-tuning training job.

        Args:
            base_model: Base model to fine-tune (e.g., "gpt-4o-mini").
            suffix: Optional suffix for the fine-tuned model name.
            beta: DPO beta parameter (typically 0.1-0.5).
            min_approved_pairs: Minimum number of approved pairs required to start training.

        Returns:
            TrainingJob object with job information.

        Example:
            >>> job = client.fine_tuning.start_training_job(
            ...     base_model="gpt-4o-mini",
            ...     suffix="reliability-v1",
            ...     beta=0.1
            ... )
            >>> final_job = client.fine_tuning.wait_for_job(job.job_id)
        """
        data = {
            "base_model": base_model,
            "beta": beta,
            "min_approved_pairs": min_approved_pairs,
        }
        if suffix:
            data["suffix"] = suffix

        response = self._make_request(
            "POST", f"v1/{self.project_id}/fine-tuning/jobs", json_data=data
        )

        return self._parse_training_job(response)

    def get_job_status(self, job_id: str) -> TrainingJob:
        """
        Get the status of a training job.

        Args:
            job_id: ID of the training job.

        Returns:
            TrainingJob object with current status.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/fine-tuning/jobs/{job_id}"
        )

        return self._parse_training_job(response)

    def list_jobs(self, status: Optional[str] = None) -> List[TrainingJob]:
        """
        List all training jobs.

        Args:
            status: Optional filter by status.

        Returns:
            List of TrainingJob objects.
        """
        params = {}
        if status:
            params["status"] = status

        response = self._make_request(
            "GET", f"v1/{self.project_id}/fine-tuning/jobs", params=params
        )

        return [self._parse_training_job(j) for j in response["jobs"]]

    def cancel_job(self, job_id: str) -> bool:
        """
        Cancel a training job.

        Args:
            job_id: ID of the training job to cancel.

        Returns:
            True if cancellation was successful.
        """
        response = self._make_request(
            "POST", f"v1/{self.project_id}/fine-tuning/jobs/{job_id}/cancel"
        )
        return response.get("success", False)

    def wait_for_job(
        self, job_id: str, timeout: int = 3600, poll_interval: int = 30
    ) -> TrainingJob:
        """
        Wait for a training job to complete.

        Args:
            job_id: ID of the training job to wait for.
            timeout: Maximum time to wait in seconds (default 1 hour).
            poll_interval: Interval between status checks in seconds.

        Returns:
            TrainingJob object when job completes.

        Raises:
            TrainlyError: If timeout is reached or job fails.
        """
        start_time = time.time()

        while time.time() - start_time < timeout:
            job = self.get_job_status(job_id)

            if job.status in ["succeeded", "failed", "cancelled"]:
                if job.status == "failed":
                    raise TrainlyError(
                        f"Training job failed: {job.error or 'Unknown error'}"
                    )
                return job

            time.sleep(poll_interval)

        raise TrainlyError(
            f"Training job {job_id} did not complete within {timeout}s"
        )

    # Model Management

    def activate_model(self, model_id: str) -> bool:
        """
        Activate a fine-tuned model for use in queries.

        Args:
            model_id: ID of the fine-tuned model to activate.

        Returns:
            True if activation was successful.

        Example:
            >>> client.fine_tuning.activate_model("ft:gpt-4o-mini:...")
        """
        response = self._make_request(
            "POST",
            f"v1/{self.project_id}/fine-tuning/activate-model",
            json_data={"model_id": model_id},
        )
        return response.get("success", False)

    def deactivate_fine_tuned_model(self) -> bool:
        """
        Deactivate the currently active fine-tuned model (revert to base model).

        Returns:
            True if deactivation was successful.
        """
        response = self._make_request(
            "POST", f"v1/{self.project_id}/fine-tuning/deactivate-model"
        )
        return response.get("success", False)

    def get_active_model(self) -> Optional[str]:
        """
        Get the currently active fine-tuned model ID.

        Returns:
            Model ID string if a fine-tuned model is active, None otherwise.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/fine-tuning/active-model"
        )
        return response.get("model_id")

    # Helper Methods

    def _parse_preference_pair(self, data: Dict[str, Any]) -> PreferencePair:
        """Parse a preference pair from API response."""
        from .models import ValidationResults

        validation = None
        if data.get("validation_results"):
            v = data["validation_results"]
            validation = ValidationResults(
                preferred_passed=v["preferred_passed"],
                non_preferred_passed=v["non_preferred_passed"],
                validators_failed=v.get("validators_failed"),
            )

        return PreferencePair(
            pair_id=data["pair_id"],
            input_messages=data["input_messages"],
            preferred_output=data["preferred_output"],
            non_preferred_output=data["non_preferred_output"],
            status=data["status"],
            source=data["source"],
            validation_results=validation,
            notes=data.get("notes"),
            created_at=datetime.fromisoformat(data["created_at"])
            if data.get("created_at")
            else None,
        )

    def _parse_training_job(self, data: Dict[str, Any]) -> TrainingJob:
        """Parse a training job from API response."""
        return TrainingJob(
            job_id=data["job_id"],
            openai_job_id=data.get("openai_job_id"),
            base_model=data.get("base_model", "gpt-4o-mini"),
            fine_tuned_model_id=data.get("fine_tuned_model_id"),
            status=data.get("status", "preparing"),
            num_pairs=data.get("num_pairs", 0),
            progress=data.get("progress"),
            started_at=datetime.fromisoformat(data["started_at"])
            if data.get("started_at")
            else None,
            completed_at=datetime.fromisoformat(data["completed_at"])
            if data.get("completed_at")
            else None,
            error=data.get("error"),
            suffix=data.get("suffix"),
            beta=data.get("beta", 0.1),
        )
