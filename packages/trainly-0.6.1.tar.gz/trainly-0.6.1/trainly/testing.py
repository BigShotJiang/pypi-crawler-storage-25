"""
Testing client for managing test suites, test cases, and test execution.
"""

from typing import Optional, List, Dict, Any, TYPE_CHECKING
import time
from datetime import datetime

from .models import (
    TestSuite,
    TestCase,
    TestRun,
    TestRunResults,
    TestAnalytics,
    PaginatedSuites,
    TestAssertion,
    TrainlyError,
)

if TYPE_CHECKING:
    from .client import TrainlyClient


class TestingClient:
    """
    Client for managing test suites and test cases.

    This client provides methods for creating test suites, generating test cases,
    running tests, and analyzing results.

    Example:
        >>> client = TrainlyClient(api_key="tk_...", project_id="...")
        >>> suite = client.testing.create_suite(
        ...     name="API Tests",
        ...     description="Test suite for API reliability"
        ... )
        >>> run = client.testing.run_suite(suite.suite_id)
        >>> results = client.testing.get_run_results(run.run_id)
    """

    def __init__(self, parent_client: "TrainlyClient"):
        """Initialize the testing client with a parent client."""
        self.parent = parent_client
        self.base_url = parent_client.base_url
        self.project_id = parent_client.project_id
        self.session = parent_client.session

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request to the testing API."""
        url = f"{self.base_url}/{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                timeout=self.parent.timeout,
            )

            if not response.ok:
                error_data = response.json() if response.content else {}
                raise TrainlyError(
                    error_data.get("detail", f"HTTP {response.status_code}"),
                    status_code=response.status_code,
                    details=error_data,
                )

            return response.json()

        except TrainlyError:
            raise
        except Exception as e:
            raise TrainlyError(f"Request failed: {str(e)}")

    # Suite Management

    def create_suite(
        self,
        name: str,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        execution_mode: Optional[str] = None,
        target_endpoint: Optional[str] = None,
        target_headers: Optional[Dict[str, str]] = None,
    ) -> TestSuite:
        """
        Create a new test suite.

        Args:
            name: Name of the test suite.
            description: Optional description of the test suite.
            tags: Optional tags for organizing the test suite.
            execution_mode: "internal" (default, uses Trainly RAG) or "external"
                (calls your endpoint). When "external", tests send queries to
                your target_endpoint and evaluate the responses.
            target_endpoint: URL that Trainly will POST test queries to when
                execution_mode is "external". Your endpoint should accept
                {"query": "...", "conversation_history": [...]} and return
                {"response": "..."}.
            target_headers: Optional dict of headers to send with external
                requests (e.g., {"Authorization": "Bearer ..."}).

        Returns:
            TestSuite object with the created suite information.

        Example:
            >>> # Internal mode (default) — tests against Trainly RAG
            >>> suite = client.testing.create_suite(
            ...     name="Production Tests",
            ...     description="Tests for production reliability",
            ...     tags=["production", "critical"]
            ... )

            >>> # External mode — tests against your own AI endpoint
            >>> suite = client.testing.create_suite(
            ...     name="My API Tests",
            ...     execution_mode="external",
            ...     target_endpoint="https://api.myapp.com/ai/query",
            ...     target_headers={"Authorization": "Bearer sk-..."},
            ... )
        """
        data = {"name": name}
        if description:
            data["description"] = description
        if tags:
            data["tags"] = tags
        if execution_mode:
            data["execution_mode"] = execution_mode
        if target_endpoint:
            data["target_endpoint"] = target_endpoint
        if target_headers:
            import json as _json
            data["target_headers"] = _json.dumps(target_headers)

        response = self._make_request(
            "POST", f"v1/{self.project_id}/testing/suites", json_data=data
        )

        return TestSuite(
            suite_id=response["suite_id"],
            name=response["name"],
            description=response.get("description"),
            test_count=response.get("test_count", 0),
            tags=response.get("tags"),
            created_at=datetime.fromisoformat(response["created_at"])
            if response.get("created_at")
            else None,
        )

    def update_suite(
        self,
        suite_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> TestSuite:
        """
        Update an existing test suite.

        Args:
            suite_id: ID of the test suite to update.
            name: New name for the test suite.
            description: New description for the test suite.
            tags: New tags for the test suite.

        Returns:
            Updated TestSuite object.
        """
        data = {}
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description
        if tags is not None:
            data["tags"] = tags

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/testing/suites/{suite_id}", json_data=data
        )

        return TestSuite(
            suite_id=response["suite_id"],
            name=response["name"],
            description=response.get("description"),
            test_count=response.get("test_count", 0),
            pass_rate=response.get("pass_rate"),
            last_run_at=datetime.fromisoformat(response["last_run_at"])
            if response.get("last_run_at")
            else None,
            last_run_status=response.get("last_run_status"),
            tags=response.get("tags"),
            created_at=datetime.fromisoformat(response["created_at"])
            if response.get("created_at")
            else None,
        )

    def delete_suite(self, suite_id: str) -> bool:
        """
        Delete a test suite.

        Args:
            suite_id: ID of the test suite to delete.

        Returns:
            True if deletion was successful.
        """
        response = self._make_request(
            "DELETE", f"v1/{self.project_id}/testing/suites/{suite_id}"
        )
        return response.get("success", False)

    def list_suites(
        self,
        page: int = 1,
        limit: int = 20,
        status: Optional[str] = None,
    ) -> PaginatedSuites:
        """
        List all test suites.

        Args:
            page: Page number (1-indexed).
            limit: Number of suites per page.
            status: Optional filter by last run status.

        Returns:
            PaginatedSuites object with list of test suites.
        """
        params = {"page": page, "limit": limit}
        if status:
            params["status"] = status

        response = self._make_request(
            "GET", f"v1/{self.project_id}/testing/suites", params=params
        )

        suites = [
            TestSuite(
                suite_id=s["suite_id"],
                name=s["name"],
                description=s.get("description"),
                test_count=s.get("test_count", 0),
                pass_rate=s.get("pass_rate"),
                last_run_at=datetime.fromisoformat(s["last_run_at"])
                if s.get("last_run_at")
                else None,
                last_run_status=s.get("last_run_status"),
                tags=s.get("tags"),
                created_at=datetime.fromisoformat(s["created_at"])
                if s.get("created_at")
                else None,
            )
            for s in response["suites"]
        ]

        return PaginatedSuites(
            suites=suites,
            total=response["total"],
            page=response["page"],
            limit=response["limit"],
            has_more=response["has_more"],
        )

    def get_suite(self, suite_id: str) -> TestSuite:
        """
        Get details of a specific test suite.

        Args:
            suite_id: ID of the test suite.

        Returns:
            TestSuite object with suite details.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/testing/suites/{suite_id}"
        )

        return TestSuite(
            suite_id=response["suite_id"],
            name=response["name"],
            description=response.get("description"),
            test_count=response.get("test_count", 0),
            pass_rate=response.get("pass_rate"),
            last_run_at=datetime.fromisoformat(response["last_run_at"])
            if response.get("last_run_at")
            else None,
            last_run_status=response.get("last_run_status"),
            tags=response.get("tags"),
            created_at=datetime.fromisoformat(response["created_at"])
            if response.get("created_at")
            else None,
        )

    # Test Case Management

    def create_test_case(
        self,
        suite_id: Optional[str],
        name: str,
        query: str,
        expected_answer: str,
        category: str = "golden",
        expected_decision: str = "ANSWER",
        assertions: Optional[List[TestAssertion]] = None,
        expected_source_file: Optional[str] = None,
    ) -> TestCase:
        """
        Create a new test case.

        Args:
            suite_id: ID of the test suite (can be None for orphan test cases).
            name: Name of the test case.
            query: Query to test.
            expected_answer: Expected answer for the query.
            category: Test case category (golden, contradiction, multi_hop, etc.).
            expected_decision: Expected decision (ANSWER, NEEDS_INFO, REFUSE).
            assertions: Optional list of assertions to validate.
            expected_source_file: Optional expected source file for the answer.

        Returns:
            TestCase object with the created test case information.
        """
        data = {
            "name": name,
            "query": query,
            "expected_answer": expected_answer,
            "category": category,
            "expected_decision": expected_decision,
        }
        if suite_id:
            data["suite_id"] = suite_id
        if assertions:
            data["assertions"] = [
                {
                    "type": a.type,
                    "value": a.value,
                    "match_threshold": a.match_threshold,
                }
                for a in assertions
            ]
        if expected_source_file:
            data["expected_source_file"] = expected_source_file

        response = self._make_request(
            "POST", f"v1/{self.project_id}/testing/cases", json_data=data
        )

        return TestCase(
            case_id=response["case_id"],
            name=response["name"],
            query=response["query"],
            expected_answer=response["expected_answer"],
            category=response["category"],
            suite_id=response.get("suite_id"),
            expected_decision=response.get("expected_decision", "ANSWER"),
            expected_source_file=response.get("expected_source_file"),
            created_at=datetime.fromisoformat(response["created_at"])
            if response.get("created_at")
            else None,
        )

    def generate_test_cases(
        self,
        count_per_category: int = 3,
        scope_filters: Optional[Dict[str, Any]] = None,
    ) -> List[TestCase]:
        """
        Auto-generate test cases from the knowledge base.

        Args:
            count_per_category: Number of test cases to generate per category.
            scope_filters: Optional scope filters to narrow down document selection.

        Returns:
            List of generated TestCase objects.

        Example:
            >>> cases = client.testing.generate_test_cases(count_per_category=2)
            >>> print(f"Generated {len(cases)} test cases")
        """
        data = {"count_per_category": count_per_category}
        if scope_filters:
            data["scope_filters"] = scope_filters

        response = self._make_request(
            "POST", f"v1/{self.project_id}/testing/cases/generate", json_data=data
        )

        return [
            TestCase(
                case_id=c["case_id"],
                name=c["name"],
                query=c["query"],
                expected_answer=c["expected_answer"],
                category=c["category"],
                suite_id=c.get("suite_id"),
                expected_decision=c.get("expected_decision", "ANSWER"),
                expected_source_file=c.get("expected_source_file"),
                created_at=datetime.fromisoformat(c["created_at"])
                if c.get("created_at")
                else None,
            )
            for c in response["cases"]
        ]

    def update_test_case(
        self,
        case_id: str,
        name: Optional[str] = None,
        query: Optional[str] = None,
        expected_answer: Optional[str] = None,
        category: Optional[str] = None,
        suite_id: Optional[str] = None,
    ) -> TestCase:
        """
        Update an existing test case.

        Args:
            case_id: ID of the test case to update.
            name: New name for the test case.
            query: New query for the test case.
            expected_answer: New expected answer.
            category: New category.
            suite_id: New suite ID (can move test case to different suite).

        Returns:
            Updated TestCase object.
        """
        data = {}
        if name is not None:
            data["name"] = name
        if query is not None:
            data["query"] = query
        if expected_answer is not None:
            data["expected_answer"] = expected_answer
        if category is not None:
            data["category"] = category
        if suite_id is not None:
            data["suite_id"] = suite_id

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/testing/cases/{case_id}", json_data=data
        )

        return TestCase(
            case_id=response["case_id"],
            name=response["name"],
            query=response["query"],
            expected_answer=response["expected_answer"],
            category=response["category"],
            suite_id=response.get("suite_id"),
            expected_decision=response.get("expected_decision", "ANSWER"),
            expected_source_file=response.get("expected_source_file"),
            created_at=datetime.fromisoformat(response["created_at"])
            if response.get("created_at")
            else None,
        )

    def delete_test_case(self, case_id: str) -> bool:
        """
        Delete a test case.

        Args:
            case_id: ID of the test case to delete.

        Returns:
            True if deletion was successful.
        """
        response = self._make_request(
            "DELETE", f"v1/{self.project_id}/testing/cases/{case_id}"
        )
        return response.get("success", False)

    def list_test_cases(
        self,
        suite_id: Optional[str] = None,
        category: Optional[str] = None,
        page: int = 1,
        limit: int = 50,
    ) -> List[TestCase]:
        """
        List test cases, optionally filtered by suite or category.

        Args:
            suite_id: Optional suite ID to filter by.
            category: Optional category to filter by.
            page: Page number (1-indexed).
            limit: Number of test cases per page.

        Returns:
            List of TestCase objects.
        """
        params = {"page": page, "limit": limit}
        if suite_id:
            params["suite_id"] = suite_id
        if category:
            params["category"] = category

        response = self._make_request(
            "GET", f"v1/{self.project_id}/testing/cases", params=params
        )

        return [
            TestCase(
                case_id=c["case_id"],
                name=c["name"],
                query=c["query"],
                expected_answer=c["expected_answer"],
                category=c["category"],
                suite_id=c.get("suite_id"),
                expected_decision=c.get("expected_decision", "ANSWER"),
                expected_source_file=c.get("expected_source_file"),
                created_at=datetime.fromisoformat(c["created_at"])
                if c.get("created_at")
                else None,
            )
            for c in response["cases"]
        ]

    # Test Execution

    def run_suite(
        self,
        suite_id: str,
        parallel: bool = True,
        stop_on_failure: bool = False,
        version_id: Optional[str] = None,
    ) -> TestRun:
        """
        Run a test suite.

        Args:
            suite_id: ID of the test suite to run.
            parallel: Whether to run tests in parallel.
            stop_on_failure: Whether to stop execution on first failure.
            version_id: Optional version ID to run tests against a specific version's config.

        Returns:
            TestRun object with run information.

        Example:
            >>> run = client.testing.run_suite(suite_id, parallel=True, version_id="v1_id")
            >>> results = client.testing.wait_for_run(run.run_id)
            >>> print(f"Pass rate: {results.pass_rate:.1%}")
        """
        data: Dict[str, Any] = {"parallel": parallel, "stop_on_failure": stop_on_failure}
        if version_id is not None:
            data["version_id"] = version_id

        response = self._make_request(
            "POST", f"v1/{self.project_id}/testing/suites/{suite_id}/run", json_data=data
        )

        return TestRun(
            run_id=response["run_id"],
            suite_id=response["suite_id"],
            status=response["status"],
            started_at=datetime.fromisoformat(response["started_at"])
            if response.get("started_at")
            else None,
        )

    def get_run_results(self, run_id: str) -> TestRunResults:
        """
        Get results of a test run.

        Args:
            run_id: ID of the test run.

        Returns:
            TestRunResults object with complete results.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/testing/runs/{run_id}/results"
        )

        from .models import TestResult

        results = []
        for r in response.get("results", []):
            results.append(
                TestResult(
                    case_id=r["case_id"],
                    case_name=r["case_name"],
                    passed=r["passed"],
                    actual_answer=r["actual_answer"],
                    expected_answer=r["expected_answer"],
                    failure_reason=r.get("failure_reason"),
                    execution_time_ms=r.get("execution_time_ms"),
                    assertions_passed=r.get("assertions_passed"),
                    assertions_failed=r.get("assertions_failed"),
                )
            )

        return TestRunResults(
            run_id=response["run_id"],
            suite_id=response["suite_id"],
            status=response["status"],
            passed=response["passed"],
            failed=response["failed"],
            total=response["total"],
            pass_rate=response["pass_rate"],
            started_at=datetime.fromisoformat(response["started_at"]),
            completed_at=datetime.fromisoformat(response["completed_at"])
            if response.get("completed_at")
            else None,
            duration_ms=response.get("duration_ms"),
            results=results,
        )

    def get_run_history(self, suite_id: str, limit: int = 10) -> List[TestRun]:
        """
        Get run history for a test suite.

        Args:
            suite_id: ID of the test suite.
            limit: Maximum number of runs to return.

        Returns:
            List of TestRun objects.
        """
        params = {"limit": limit}
        response = self._make_request(
            "GET",
            f"v1/{self.project_id}/testing/suites/{suite_id}/runs",
            params=params,
        )

        return [
            TestRun(
                run_id=r["run_id"],
                suite_id=r["suite_id"],
                status=r["status"],
                started_at=datetime.fromisoformat(r["started_at"])
                if r.get("started_at")
                else None,
                completed_at=datetime.fromisoformat(r["completed_at"])
                if r.get("completed_at")
                else None,
            )
            for r in response["runs"]
        ]

    def cancel_run(self, run_id: str) -> bool:
        """
        Cancel a running test.

        Args:
            run_id: ID of the test run to cancel.

        Returns:
            True if cancellation was successful.
        """
        response = self._make_request(
            "POST", f"v1/{self.project_id}/testing/runs/{run_id}/cancel"
        )
        return response.get("success", False)

    def wait_for_run(
        self, run_id: str, timeout: int = 300, poll_interval: int = 5
    ) -> TestRunResults:
        """
        Wait for a test run to complete.

        Args:
            run_id: ID of the test run to wait for.
            timeout: Maximum time to wait in seconds.
            poll_interval: Interval between status checks in seconds.

        Returns:
            TestRunResults object when run completes.

        Raises:
            TrainlyError: If timeout is reached or run fails.
        """
        start_time = time.time()

        while time.time() - start_time < timeout:
            results = self.get_run_results(run_id)

            if results.status in ["completed", "failed", "cancelled"]:
                return results

            time.sleep(poll_interval)

        raise TrainlyError(f"Test run {run_id} did not complete within {timeout}s")

    # Analytics

    def get_suite_analytics(self, suite_id: str) -> TestAnalytics:
        """
        Get analytics for a test suite.

        Args:
            suite_id: ID of the test suite.

        Returns:
            TestAnalytics object with suite analytics.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/testing/suites/{suite_id}/analytics"
        )

        return TestAnalytics(
            suite_id=response["suite_id"],
            total_runs=response["total_runs"],
            average_pass_rate=response["average_pass_rate"],
            average_duration_ms=response["average_duration_ms"],
            total_tests=response["total_tests"],
            pass_trend=response.get("pass_trend"),
        )
