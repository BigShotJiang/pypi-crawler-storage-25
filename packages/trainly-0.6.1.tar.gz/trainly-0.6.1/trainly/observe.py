"""
Observe decorator for wrapping external AI calls with Trainly trace logging.

Usage:
    from trainly import TrainlyClient

    client = TrainlyClient(api_key="tk_...", project_id="proj_...")

    @client.observe(model="gpt-4o")
    def my_llm_call(query: str) -> str:
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": query}],
        )
        return response.choices[0].message.content

    # The decorator automatically logs input/output/latency to Trainly
    result = my_llm_call("What is the capital of France?")

    # Context manager for manual spans
    with client.observe.span("my-operation") as s:
        s.set_attribute("user_id", "u_123")
        result = do_something()
"""

import json
import time
import uuid
import inspect
import functools
import contextvars
from contextlib import contextmanager
from typing import Optional, List, Dict, Any, Callable, TYPE_CHECKING

from .models import TrainlyError

if TYPE_CHECKING:
    from .client import TrainlyClient

MODEL_PRICING = {
    "gpt-4o": {"input": 0.0025, "output": 0.01},
    "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    "gpt-4-turbo": {"input": 0.01, "output": 0.03},
    "gpt-4": {"input": 0.03, "output": 0.06},
    "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
    "claude-3-opus": {"input": 0.015, "output": 0.075},
    "claude-3-sonnet": {"input": 0.003, "output": 0.015},
    "claude-3-haiku": {"input": 0.00025, "output": 0.00125},
    "claude-3-5-sonnet": {"input": 0.003, "output": 0.015},
    "claude-3-5-haiku": {"input": 0.0008, "output": 0.004},
    "grok-2": {"input": 0.002, "output": 0.01},
}


def _calculate_cost(model, token_usage):
    """Auto-calculate cost from model name and token usage dict."""
    if not model or not token_usage:
        return None
    pricing = MODEL_PRICING.get(model, {"input": 0.001, "output": 0.002})
    inp = token_usage.get("prompt_tokens", token_usage.get("promptTokens", 0)) or 0
    out = token_usage.get("completion_tokens", token_usage.get("completionTokens", 0)) or 0
    return (inp / 1000) * pricing["input"] + (out / 1000) * pricing["output"]


class Span:
    """A manual span for tracing a block of code."""

    def __init__(self, decorator: "ObserveDecorator", name: str, **kwargs):
        self.decorator = decorator
        self.name = name
        self.kwargs = kwargs
        self._attributes: Dict[str, Any] = {}
        self._start_time: Optional[float] = None

    def set_attribute(self, key: str, value: Any) -> None:
        """Set a custom attribute on the span."""
        self._attributes[key] = value

    def __enter__(self) -> "Span":
        self._start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        latency = (time.time() - self._start_time) * 1000
        self.decorator.log(
            input=f"span:{self.name}",
            output=str(self._attributes) if self._attributes else "",
            latency_ms=latency,
            custom_attributes=self._attributes,
            status="error" if exc_type else "success",
            **self.kwargs,
        )
        return False


_span_stack: contextvars.ContextVar[list] = contextvars.ContextVar("_span_stack", default=[])
_session_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar("_session_var", default=None)


class Span:
    """Represents a single operation span in a trace."""

    def __init__(self, name: str, kind: str = "chain", parent_span_id: str | None = None):
        self.span_id = uuid.uuid4().hex[:16]
        self.parent_span_id = parent_span_id
        self.name = name
        self.kind = kind
        self.start_time = time.time() * 1000
        self.end_time: float | None = None
        self.status = "success"
        self.attributes: dict = {}
        self._input: str | None = None
        self._output: str | None = None
        self.model: str | None = None
        self.token_usage: dict | None = None
        self.cost: float | None = None

    def set_input(self, value: str):
        self._input = value

    def set_output(self, value: str):
        self._output = value

    def set_attribute(self, key: str, value):
        self.attributes[key] = value

    def set_model(self, model: str):
        self.model = model

    def set_token_usage(self, usage: dict):
        self.token_usage = usage

    def set_cost(self, cost: float):
        self.cost = cost

    def to_dict(self) -> dict:
        d: dict = {
            "spanId": self.span_id,
            "name": self.name,
            "startTime": self.start_time,
            "endTime": self.end_time or time.time() * 1000,
            "status": self.status,
            "spanKind": self.kind,
        }
        if self.parent_span_id:
            d["parentSpanId"] = self.parent_span_id
        if self.attributes:
            d["attributes"] = self.attributes
        if self._input is not None:
            d["input"] = self._input
        if self._output is not None:
            d["output"] = self._output
        if self.model:
            d["model"] = self.model
        if self.token_usage:
            d["tokenUsage"] = self.token_usage
        if self.cost is not None:
            d["cost"] = self.cost
        return d


class ObserveDecorator:
    """Creates @observe decorators and spans bound to a TrainlyClient instance."""

    def __init__(self, parent_client: "TrainlyClient"):
        self.parent = parent_client
        self.base_url = parent_client.base_url
        self.project_id = parent_client.project_id
        self.session = parent_client.session

    @staticmethod
    def get_active_session() -> Optional[str]:
        """Return the currently active session ID, or None."""
        return _session_var.get(None)

    @staticmethod
    def start_session(session_id: Optional[str] = None) -> str:
        """Set the active session ID for all subsequent @observe calls.

        Args:
            session_id: Optional explicit session ID. Auto-generates one if omitted.

        Returns:
            The session ID that was set.

        Example:
            >>> sid = client.observe.start_session()
            >>> my_step_1("hello")   # automatically tagged with sid
            >>> my_step_2("world")   # automatically tagged with sid
            >>> client.observe.end_session()
        """
        sid = session_id or f"session-{uuid.uuid4().hex[:12]}"
        _session_var.set(sid)
        return sid

    @staticmethod
    def end_session() -> None:
        """Clear the active session ID."""
        _session_var.set(None)

    @contextmanager
    def agent_session(self, session_id: Optional[str] = None):
        """Context manager that sets the active session for all @observe calls within its scope.

        Every @observe-decorated function called inside this block (even across
        different files/modules) will automatically be tagged with the same
        session_id — no need to pass it explicitly.

        Args:
            session_id: Optional explicit session ID. Auto-generates one if omitted.

        Yields:
            The session ID string.

        Example:
            >>> with client.observe.agent_session() as sid:
            ...     plan_result = plan_step(query)       # Step 1 — auto-tagged
            ...     research = research_step(plan_result) # Step 2 — auto-tagged
            ...     answer = synthesize(research)         # Step 3 — auto-tagged
            ... # session ends, subsequent traces are not tagged
        """
        sid = session_id or f"session-{uuid.uuid4().hex[:12]}"
        prev = _session_var.get(None)
        _session_var.set(sid)
        try:
            yield sid
        finally:
            _session_var.set(prev)

    @contextmanager
    def span(self, name: str, kind: str = "chain"):
        """Create a nested span within the current trace.

        Usage:
            with client.observe.span("retrieval", kind="retrieval") as s:
                docs = search(query)
                s.set_output(f"Found {len(docs)} docs")
        """
        stack = _span_stack.get([])
        parent_id = stack[-1].span_id if stack else None
        s = Span(name=name, kind=kind, parent_span_id=parent_id)
        new_stack = stack + [s]
        _span_stack.set(new_stack)
        try:
            yield s
        except Exception as e:
            s.status = "error"
            s.set_attribute("error", str(e))
            raise
        finally:
            s.end_time = time.time() * 1000
            new_stack = _span_stack.get([])
            if new_stack and new_stack[-1] is s:
                _span_stack.set(new_stack[:-1])

    def __call__(
        self,
        model: Optional[str] = None,
        tags: Optional[List[str]] = None,
        expected_output: Optional[str] = None,
        trace_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        version: Optional[str] = None,
        custom_attributes: Optional[Dict[str, Any]] = None,
        span_name: Optional[str] = None,
        capture_exceptions: bool = True,
        session_id: Optional[str] = None,
        guards=None,
        on_fail: str = "stop",
    ) -> Callable:
        """
        Decorator that wraps a function and logs its input/output as a trace.

        The decorated function should accept a string (the query/input) as its
        first positional argument and return a string (the AI response).

        Args:
            model: Optional model name to log (e.g., "gpt-4o", "claude-3-5-sonnet").
            tags: Optional tags for filtering traces.
            expected_output: Optional expected output for scoring.
            trace_id: Optional external trace ID for correlation.
            metadata: Optional arbitrary metadata dict (stored as JSON string).
            version: Optional version string to associate this trace with (e.g., "1.0.0").
            custom_attributes: Optional structured attributes for filtering/aggregation
                (e.g., reward signals, environment params, pass/fail).
            span_name: Optional name for the span. Defaults to the function name.
            capture_exceptions: Whether to capture and log exceptions. Default True.
            guards: Optional guard configuration. Can be True (use dashboard guards),
                a single Guard, or a list of Guards.
            on_fail: Default on_fail policy for guards. One of "stop", "continue",
                "retry:N", or "retry:N:continue". Default "stop".

        Returns:
            Decorated function that logs traces to Trainly.

        Example:
            >>> @client.observe(
            ...     model="gpt-4o",
            ...     tags=["production"],
            ...     span_name="chat-completion",
            ... )
            ... def my_ai_call(query: str) -> str:
            ...     return call_my_llm(query)
        """
        from .guards import Guard, GuardFailure, GuardFeedback, GuardResult, run_local_guard, _parse_on_fail

        # Normalize guards list once at decoration time
        guard_list = Guard._normalize(guards) if guards is not None else None

        def decorator(func: Callable) -> Callable:
            # Check at decoration time whether the function accepts guard_feedback
            _func_sig = inspect.signature(func)
            _accepts_guard_feedback = "guard_feedback" in _func_sig.parameters

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                # Extract the input -- first positional arg or 'query'/'input' kwarg
                # Auto-serialize dicts/lists to JSON for structured logging
                raw_input = None
                if args:
                    raw_input = args[0]
                elif "query" in kwargs:
                    raw_input = kwargs["query"]
                elif "input" in kwargs:
                    raw_input = kwargs["input"]

                if isinstance(raw_input, (dict, list)):
                    input_text = json.dumps(raw_input)
                else:
                    input_text = str(raw_input) if raw_input is not None else ""

                resolved_span_name = span_name or func.__name__

                # --- No guards: original fast path ---
                if not guard_list:
                    start_time = time.time()
                    error_msg = None
                    output_text = ""
                    status = "success"

                    _span_stack.set([])
                    try:
                        result = func(*args, **kwargs)
                        if isinstance(result, (dict, list)):
                            output_text = json.dumps(result)
                        else:
                            output_text = str(result) if result is not None else ""
                        return result
                    except Exception as e:
                        error_msg = str(e)
                        status = "error"
                        if not capture_exceptions:
                            raise
                        raise
                    finally:
                        latency_ms = (time.time() - start_time) * 1000
                        collected_spans = _span_stack.get([])
                        spans_data = [s.to_dict() for s in collected_spans] if collected_spans else None
                        _span_stack.set([])
                        try:
                            log_kwargs = {}
                            if resolved_span_name != func.__name__:
                                log_kwargs["spans"] = [{"name": resolved_span_name, "latency_ms": latency_ms}]
                            resolved_session = session_id or _session_var.get(None)
                            self._log_trace(
                                input_text=input_text,
                                output_text=output_text,
                                model=model,
                                latency_ms=latency_ms,
                                tags=tags,
                                expected_output=expected_output,
                                trace_id=trace_id or str(uuid.uuid4()),
                                status=status,
                                error=error_msg,
                                metadata=metadata,
                                version=version,
                                custom_attributes=custom_attributes,
                                session_id=resolved_session,
                                spans=spans_data,
                                **log_kwargs,
                            )
                        except Exception:
                            pass

                # --- Guards path: retry loop ---
                else:
                    # Parse the decorator-level on_fail policy
                    default_policy = _parse_on_fail(on_fail)
                    max_attempts = 1
                    if default_policy["action"] == "retry":
                        max_attempts = 1 + default_policy["max_retries"]

                    # Also check per-guard retry policies for max attempts
                    for g in guard_list:
                        if g.on_fail:
                            gp = _parse_on_fail(g.on_fail)
                            if gp["action"] == "retry":
                                per_max = 1 + gp["max_retries"]
                                if per_max > max_attempts:
                                    max_attempts = per_max

                    attempt = 0
                    last_result = None
                    last_output_text = ""
                    last_guard_feedback = None
                    guard_results_log = []
                    attempt_log = []  # Per-attempt output + guard results
                    overall_start_time = time.time()

                    while attempt < max_attempts:
                        attempt += 1
                        start_time = time.time()
                        error_msg = None
                        output_text = ""
                        status = "success"
                        result = None
                        func_raised = False

                        _span_stack.set([])
                        try:
                            # Inject guard_feedback if the function accepts it
                            if _accepts_guard_feedback and last_guard_feedback is not None:
                                call_kwargs = dict(kwargs)
                                call_kwargs["guard_feedback"] = last_guard_feedback
                                result = func(*args, **call_kwargs)
                            else:
                                result = func(*args, **kwargs)
                            if isinstance(result, (dict, list)):
                                output_text = json.dumps(result)
                            else:
                                output_text = str(result) if result is not None else ""
                        except Exception as e:
                            error_msg = str(e)
                            status = "error"
                            func_raised = True
                            raise

                        last_result = result
                        last_output_text = output_text

                        # If the function raised, skip guard evaluation
                        if func_raised:
                            break  # pragma: no cover

                        # Evaluate guards: local first, then remote
                        all_passed = True
                        failed_guard = None
                        failed_result = None

                        for g in guard_list:
                            effective_on_fail = g.on_fail or on_fail
                            effective_policy = _parse_on_fail(effective_on_fail)

                            if g.guard_type in ("custom", "cost_limit"):
                                gr = run_local_guard(
                                    g, output_text,
                                    input=input_text,
                                    metadata=metadata,
                                )
                                guard_results_log.append({
                                    "guard": g.name,
                                    "passed": gr.passed,
                                    "reason": gr.reason,
                                    "attempt": attempt,
                                })
                                if not gr.passed:
                                    all_passed = False
                                    failed_guard = g
                                    failed_result = gr
                                    break

                            elif g.guard_type == "dashboard":
                                try:
                                    eval_resp = self.parent.evaluate(
                                        input=input_text,
                                        output=output_text,
                                        model=model,
                                        metadata=metadata,
                                        tags=tags,
                                    )
                                    dashboard_passed = eval_resp.get("passed", True)
                                    guard_results_log.append({
                                        "guard": "dashboard",
                                        "passed": dashboard_passed,
                                        "results": eval_resp.get("results", []),
                                        "attempt": attempt,
                                    })
                                    if not dashboard_passed:
                                        all_passed = False
                                        # Build failure info from first failed scorer
                                        failed_scorers = [
                                            r for r in eval_resp.get("results", [])
                                            if not r.get("passed", True)
                                        ]
                                        scorer_name = failed_scorers[0]["scorer"] if failed_scorers else "dashboard"
                                        scorer_reason = failed_scorers[0].get("reason", "Dashboard guard failed") if failed_scorers else "Dashboard guard failed"
                                        failed_guard = g
                                        failed_result = GuardResult(
                                            passed=False,
                                            reason=scorer_reason,
                                        )
                                        # Override guard name for the failure
                                        failed_guard = Guard(
                                            guard_type="dashboard",
                                            name=scorer_name,
                                            on_fail=g.on_fail,
                                        )
                                        break
                                except Exception:
                                    # If evaluate call fails, treat as passed (don't block user)
                                    guard_results_log.append({
                                        "guard": "dashboard",
                                        "passed": True,
                                        "reason": "evaluate call failed, skipped",
                                        "attempt": attempt,
                                    })

                        # Log this attempt's details
                        attempt_entry = {
                            "attempt": attempt,
                            "output": output_text[:500],  # Truncate for sanity
                            "guards_passed": all_passed,
                        }
                        if not all_passed and failed_guard and failed_result:
                            attempt_entry["failed_guard"] = failed_guard.name
                            attempt_entry["failure_reason"] = failed_result.reason
                        if last_guard_feedback:
                            attempt_entry["feedback_received"] = last_guard_feedback.reason
                        attempt_log.append(attempt_entry)

                        if all_passed:
                            # All guards passed — break out of retry loop
                            break

                        # A guard failed — determine action
                        effective_on_fail = failed_guard.on_fail or on_fail
                        effective_policy = _parse_on_fail(effective_on_fail)

                        if effective_policy["action"] == "stop":
                            # Log trace before raising
                            latency_ms = (time.time() - overall_start_time) * 1000
                            merged_attrs = dict(custom_attributes or {})
                            merged_attrs["guards_enabled"] = True
                            merged_attrs["guard_attempts"] = attempt
                            merged_attrs["guards_passed"] = False
                            merged_attrs[f"guard:{failed_guard.name}"] = "fail"
                            if failed_result and failed_result.reason:
                                merged_attrs[f"guard:{failed_guard.name}:reason"] = failed_result.reason
                            try:
                                log_kwargs = {}
                                if resolved_span_name != func.__name__:
                                    log_kwargs["spans"] = [{"name": resolved_span_name, "latency_ms": latency_ms}]
                                resolved_session = session_id or _session_var.get(None)
                                self._log_trace(
                                    input_text=input_text,
                                    output_text=output_text,
                                    model=model,
                                    latency_ms=latency_ms,
                                    tags=tags,
                                    expected_output=expected_output,
                                    trace_id=trace_id or str(uuid.uuid4()),
                                    status="guard_failed",
                                    error=f"Guard '{failed_guard.name}' failed: {failed_result.reason}",
                                    metadata=metadata,
                                    version=version,
                                    custom_attributes=merged_attrs,
                                    session_id=resolved_session,
                                    **log_kwargs,
                                )
                            except Exception:
                                pass
                            raise GuardFailure(
                                guard_name=failed_guard.name,
                                reason=failed_result.reason or f"Guard '{failed_guard.name}' failed",
                                attempts=attempt,
                            )

                        elif effective_policy["action"] == "continue":
                            # Guard failed but policy says continue — return the result
                            break

                        elif effective_policy["action"] == "retry":
                            # Check if we've exhausted retries
                            retry_max = 1 + effective_policy["max_retries"]
                            if attempt >= retry_max:
                                fallback = effective_policy.get("fallback", "stop")
                                if fallback == "continue":
                                    break
                                else:
                                    # Log trace before raising
                                    latency_ms = (time.time() - overall_start_time) * 1000
                                    merged_attrs = dict(custom_attributes or {})
                                    merged_attrs["guards_enabled"] = True
                                    merged_attrs["guard_attempts"] = attempt
                                    merged_attrs["guards_passed"] = False
                                    merged_attrs[f"guard:{failed_guard.name}"] = "fail"
                                    if failed_result and failed_result.reason:
                                        merged_attrs[f"guard:{failed_guard.name}:reason"] = failed_result.reason
                                    try:
                                        log_kwargs = {}
                                        if resolved_span_name != func.__name__:
                                            log_kwargs["spans"] = [{"name": resolved_span_name, "latency_ms": latency_ms}]
                                        resolved_session = session_id or _session_var.get(None)
                                        self._log_trace(
                                            input_text=input_text,
                                            output_text=output_text,
                                            model=model,
                                            latency_ms=latency_ms,
                                            tags=tags,
                                            expected_output=expected_output,
                                            trace_id=trace_id or str(uuid.uuid4()),
                                            status="guard_failed",
                                            error=f"Guard '{failed_guard.name}' failed after {attempt} attempts",
                                            metadata=metadata,
                                            version=version,
                                            custom_attributes=merged_attrs,
                                            session_id=resolved_session,
                                            **log_kwargs,
                                        )
                                    except Exception:
                                        pass
                                    raise GuardFailure(
                                        guard_name=failed_guard.name,
                                        reason=failed_result.reason or f"Guard '{failed_guard.name}' failed",
                                        attempts=attempt,
                                    )
                            # Build feedback for the next attempt
                            last_guard_feedback = GuardFeedback(
                                guard_name=failed_guard.name,
                                reason=failed_result.reason or f"Guard '{failed_guard.name}' failed",
                                attempt=attempt,
                                max_attempts=max_attempts,
                            )

                    # Log the final trace
                    latency_ms = (time.time() - overall_start_time) * 1000

                    # Build flat guard attributes for dashboard visibility
                    merged_attrs = dict(custom_attributes or {})
                    merged_metadata = dict(metadata or {})
                    if guard_results_log:
                        # Flat attributes visible in the dashboard
                        merged_attrs["guards_enabled"] = True
                        merged_attrs["guard_attempts"] = attempt

                        # guards_passed reflects the FINAL attempt only —
                        # if retries succeeded, the guard passed overall.
                        final_attempt_results = [
                            r for r in guard_results_log if r.get("attempt") == attempt
                        ]
                        final_passed = all(r.get("passed", True) for r in final_attempt_results)
                        merged_attrs["guards_passed"] = final_passed

                        # Per-scorer results as flat keys (from final attempt only)
                        for r in final_attempt_results:
                            guard_name = r.get("guard", "unknown")
                            if guard_name == "dashboard":
                                # Expand dashboard results into individual scorer attributes
                                for scorer_result in r.get("results", []):
                                    scorer_name = scorer_result.get("scorer", "unknown")
                                    merged_attrs[f"guard:{scorer_name}"] = "pass" if scorer_result.get("passed") else "fail"
                                    if scorer_result.get("reason"):
                                        merged_attrs[f"guard:{scorer_name}:reason"] = scorer_result["reason"]
                            else:
                                merged_attrs[f"guard:{guard_name}"] = "pass" if r.get("passed") else "fail"
                                if r.get("reason"):
                                    merged_attrs[f"guard:{guard_name}:reason"] = r["reason"]

                        # Full per-attempt history in metadata for drill-down
                        merged_metadata["guard_results"] = guard_results_log
                        if len(attempt_log) > 1:
                            merged_metadata["guard_attempts_detail"] = attempt_log

                    collected_spans = _span_stack.get([])
                    spans_data = [s.to_dict() for s in collected_spans] if collected_spans else None
                    _span_stack.set([])
                    try:
                        log_kwargs = {}
                        if resolved_span_name != func.__name__:
                            log_kwargs["spans"] = [{"name": resolved_span_name, "latency_ms": latency_ms}]
                        resolved_session = session_id or _session_var.get(None)
                        self._log_trace(
                            input_text=input_text,
                            output_text=last_output_text,
                            model=model,
                            latency_ms=latency_ms,
                            tags=tags,
                            expected_output=expected_output,
                            trace_id=trace_id or str(uuid.uuid4()),
                            status=status,
                            error=error_msg,
                            metadata=merged_metadata if merged_metadata else metadata,
                            version=version,
                            custom_attributes=merged_attrs if merged_attrs else custom_attributes,
                            session_id=resolved_session,
                            spans=spans_data,
                            **log_kwargs,
                        )
                    except Exception:
                        pass

                    return last_result

            return wrapper
        return decorator

    def span(self, name: str, **kwargs) -> Span:
        """
        Create a context-managed span for manual tracing.

        Args:
            name: Name for the span.
            **kwargs: Additional keyword arguments passed to log() (e.g., model, tags).

        Returns:
            A Span context manager.

        Example:
            >>> with client.observe.span("embedding-lookup", model="text-embedding-3-small") as s:
            ...     s.set_attribute("num_results", 10)
            ...     results = search_embeddings(query)
        """
        return Span(self, name, **kwargs)

    def log(
        self,
        input: str,
        output: str,
        model: Optional[str] = None,
        latency_ms: Optional[float] = None,
        tags: Optional[List[str]] = None,
        expected_output: Optional[str] = None,
        trace_id: Optional[str] = None,
        token_usage: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        status: str = "success",
        error: Optional[str] = None,
        version: Optional[str] = None,
        custom_attributes: Optional[Dict[str, Any]] = None,
        # General-purpose fields for non-string data
        tool_calls: Optional[List[Dict[str, Any]]] = None,
        input_structured: Optional[Any] = None,
        output_structured: Optional[Any] = None,
        # New observability fields
        spans: Optional[List[Dict[str, Any]]] = None,
        cost: Optional[float] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Manually log a trace without using the decorator.

        Useful when you need more control over what gets logged.

        Args:
            input: The input query/prompt.
            output: The AI response.
            model: Model name.
            latency_ms: Latency in milliseconds.
            tags: Tags for filtering.
            expected_output: Expected output for scoring.
            trace_id: External trace ID.
            token_usage: Token usage dict with prompt_tokens, completion_tokens, total_tokens.
            metadata: Arbitrary metadata dict.
            status: Trace status - "success", "error", or "warning".
            error: Error message if status is "error".
            version: Published version string to associate with this trace.
            custom_attributes: Structured attributes for filtering (e.g., reward signals).
            tool_calls: Tool call data for agent traces.
            input_structured: Structured input data (non-string).
            output_structured: Structured output data (non-string).
            spans: Hierarchical span data for nested traces.
            cost: Estimated cost in USD for this trace.

        Returns:
            Dict with trace ID.

        Example:
            >>> client.observe.log(
            ...     input="What is AI?",
            ...     output="AI is ...",
            ...     model="gpt-4o",
            ...     status="success",
            ...     cost=0.003,
            ...     spans=[{"name": "retrieval", "latency_ms": 50}],
            ... )
        """
        resolved_session = session_id or _session_var.get(None)
        return self._log_trace(
            input_text=input,
            output_text=output,
            model=model,
            latency_ms=latency_ms,
            tags=tags,
            expected_output=expected_output,
            trace_id=trace_id or str(uuid.uuid4()),
            token_usage=token_usage,
            metadata=metadata,
            status=status,
            error=error,
            version=version,
            custom_attributes=custom_attributes,
            tool_calls=tool_calls,
            input_structured=input_structured,
            output_structured=output_structured,
            spans=spans,
            cost=cost,
            session_id=resolved_session,
        )

    def _log_trace(
        self,
        input_text: str,
        output_text: str,
        model: Optional[str] = None,
        latency_ms: Optional[float] = None,
        tags: Optional[List[str]] = None,
        expected_output: Optional[str] = None,
        trace_id: Optional[str] = None,
        token_usage: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        status: str = "success",
        error: Optional[str] = None,
        version: Optional[str] = None,
        custom_attributes: Optional[Dict[str, Any]] = None,
        tool_calls: Optional[List[Dict[str, Any]]] = None,
        input_structured: Optional[Any] = None,
        output_structured: Optional[Any] = None,
        spans: Optional[List[Dict[str, Any]]] = None,
        cost: Optional[float] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Internal method to log a trace via the API."""
        url = f"{self.base_url}/v1/{self.project_id}/traces"

        payload: Dict[str, Any] = {
            "input": input_text,
            "output": output_text,
        }
        if model is not None:
            payload["model"] = model
        if latency_ms is not None:
            payload["latency_ms"] = latency_ms
        if tags is not None:
            payload["tags"] = tags
        if expected_output is not None:
            payload["expected_output"] = expected_output
        if trace_id is not None:
            payload["trace_id"] = trace_id
        if token_usage is not None:
            payload["token_usage"] = token_usage
        if metadata is not None:
            payload["metadata"] = metadata
        if status != "success":
            payload["status"] = status
        if error is not None:
            payload["error"] = error
        if version is not None:
            payload["version"] = version
        if custom_attributes is not None:
            payload["custom_attributes"] = custom_attributes
        if tool_calls is not None:
            payload["tool_calls"] = tool_calls
        if input_structured is not None:
            payload["input_structured"] = input_structured
        if output_structured is not None:
            payload["output_structured"] = output_structured
        if spans is not None:
            payload["spans"] = spans
        if cost is not None:
            payload["cost"] = cost
        if session_id:
            payload["session_id"] = session_id

        # Auto-calculate cost if not provided
        if "cost" not in payload or payload.get("cost") is None:
            auto_cost = _calculate_cost(payload.get("model"), payload.get("token_usage"))
            if auto_cost is not None:
                payload["cost"] = auto_cost

        try:
            response = self.session.post(
                url,
                json=payload,
                timeout=self.parent.timeout,
            )
            if response.ok:
                return response.json()
            return {"error": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"error": str(e)}
