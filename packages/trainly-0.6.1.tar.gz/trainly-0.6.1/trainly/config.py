"""
Configuration client for managing RAG settings, validation policies, and chat configuration.
"""

from typing import Optional, Dict, Any, TYPE_CHECKING

from .models import (
    ChatSettings,
    RagConfig,
    ChunkingConfig,
    RetrievalConfig,
    RerankingConfig,
    ValidationPolicy,
    RepairLoopConfig,
    TrainlyError,
)

if TYPE_CHECKING:
    from .client import TrainlyClient


class ConfigClient:
    """
    Client for managing configuration settings.

    This client provides methods for updating RAG settings, validation policies,
    and other configuration options.

    Example:
        >>> client = TrainlyClient(api_key="tk_...", project_id="...")
        >>> client.config.update_reranking(enabled=True, model="cohere", top_n=5)
        >>> policy = client.config.generate_validation_policy(
        ...     task_description="Replace Stripe with Paddle"
        ... )
        >>> client.config.set_validation_policy(policy)
    """

    def __init__(self, parent_client: "TrainlyClient", readonly: bool = False):
        """Initialize the config client with a parent client."""
        self.parent = parent_client
        self.base_url = parent_client.base_url
        self.project_id = parent_client.project_id
        self.session = parent_client.session
        self.readonly = readonly

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request to the config API."""
        if self.readonly and method != "GET":
            raise TrainlyError(
                "Configuration modifications not available in current authentication mode"
            )

        url = f"{self.base_url}/{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                timeout=self.parent.timeout,
            )

            if not response.ok:
                error_data = response.json() if response.content else {}
                raise TrainlyError(
                    error_data.get("detail", f"HTTP {response.status_code}"),
                    status_code=response.status_code,
                    details=error_data,
                )

            return response.json()

        except TrainlyError:
            raise
        except Exception as e:
            raise TrainlyError(f"Request failed: {str(e)}")

    # Custom Configuration (arbitrary key-value config for any endpoint type)

    def get_custom_config(self) -> Dict[str, Any]:
        """
        Get current custom configuration.

        Returns:
            Dict with current custom config key-value pairs.

        Example:
            >>> config = client.config.get_custom_config()
            >>> print(config)  # {"reward_function": "sparse", "difficulty": 0.7}
        """
        response = self._make_request("GET", f"v1/{self.project_id}/config/custom")
        return response.get("custom_config", response.get("customConfig", {}))

    def set_custom_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Set arbitrary custom configuration on a workspace.

        This replaces the entire custom config. Use for storing any
        key-value configuration (RL environment params, agent configs,
        pipeline settings, etc.).

        Args:
            config: Dictionary of arbitrary configuration key-value pairs.

        Returns:
            Dict with the updated custom config.

        Example:
            >>> client.config.set_custom_config({
            ...     "reward_function": "sparse",
            ...     "difficulty": 0.7,
            ...     "max_steps": 1000,
            ...     "task_params": {"goal": "navigate_maze", "map_size": 10}
            ... })
        """
        response = self._make_request(
            "PUT",
            f"v1/{self.project_id}/config/custom",
            json_data={"custom_config": config},
        )
        return response.get("custom_config", response.get("customConfig", {}))

    # Chat Settings

    def get_settings(self) -> ChatSettings:
        """
        Get current chat settings.

        Returns:
            ChatSettings object with current configuration.
        """
        response = self._make_request("GET", f"v1/{self.project_id}/config/settings")

        rag = None
        if response.get("rag_config"):
            rag = self._parse_rag_config(response["rag_config"])

        validation = None
        if response.get("validation_policy"):
            validation = self._parse_validation_policy(response["validation_policy"])

        repair = None
        if response.get("repair_loop"):
            r = response["repair_loop"]
            repair = RepairLoopConfig(enabled=r["enabled"], max_retries=r.get("max_retries", 2))

        return ChatSettings(
            project_id=response.get("project_id", response.get("chat_id", "")),
            model=response.get("model"),
            temperature=response.get("temperature"),
            max_tokens=response.get("max_tokens"),
            custom_prompt=response.get("custom_prompt"),
            repair_loop=repair,
            rag_config=rag,
            validation_policy=validation,
        )

    def update_settings(
        self,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        custom_prompt: Optional[str] = None,
    ) -> ChatSettings:
        """
        Update chat settings.

        Args:
            model: LLM model to use (e.g., "gpt-4o", "gpt-4o-mini").
            temperature: Sampling temperature (0.0-1.0).
            max_tokens: Maximum tokens in response.
            custom_prompt: Custom system prompt.

        Returns:
            Updated ChatSettings object.
        """
        data = {}
        if model is not None:
            data["model"] = model
        if temperature is not None:
            data["temperature"] = temperature
        if max_tokens is not None:
            data["max_tokens"] = max_tokens
        if custom_prompt is not None:
            data["custom_prompt"] = custom_prompt

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/config/settings", json_data=data
        )

        return self._parse_chat_settings(response)

    # RAG Configuration

    def get_rag_config(self) -> RagConfig:
        """
        Get current RAG configuration.

        Returns:
            RagConfig object with chunking, retrieval, and reranking settings.
        """
        response = self._make_request("GET", f"v1/{self.project_id}/config/rag")
        return self._parse_rag_config(response)

    def update_chunking(
        self,
        strategy: str = "auto",
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[float] = None,
    ) -> RagConfig:
        """
        Update chunking strategy.

        Args:
            strategy: Chunking strategy ("auto", "fixed_size", "semantic", "sentence", "paragraph", "code", "custom").
            chunk_size: Size of chunks in tokens (100-2000).
            chunk_overlap: Overlap between chunks as fraction (0-0.5).

        Returns:
            Updated RagConfig object.
        """
        data = {"strategy": strategy}
        if chunk_size is not None:
            data["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            data["chunk_overlap"] = chunk_overlap

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/config/rag/chunking", json_data=data
        )
        return self._parse_rag_config(response)

    def update_retrieval(
        self,
        mode: str = "hybrid",
        top_k: int = 10,
        similarity_threshold: float = 0.7,
        vector_weight: Optional[float] = None,
        keyword_weight: Optional[float] = None,
    ) -> RagConfig:
        """
        Update retrieval configuration.

        Args:
            mode: Retrieval mode ("hybrid", "vector", "keyword").
            top_k: Number of results to retrieve (1-50).
            similarity_threshold: Minimum similarity score (0-1).
            vector_weight: Weight for vector search in hybrid mode (0-1).
            keyword_weight: Weight for keyword search in hybrid mode (0-1).

        Returns:
            Updated RagConfig object.
        """
        data = {
            "mode": mode,
            "top_k": top_k,
            "similarity_threshold": similarity_threshold,
        }
        if vector_weight is not None:
            data["vector_weight"] = vector_weight
        if keyword_weight is not None:
            data["keyword_weight"] = keyword_weight

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/config/rag/retrieval", json_data=data
        )
        return self._parse_rag_config(response)

    def update_reranking(
        self,
        enabled: bool,
        model: str = "cohere",
        top_n: Optional[int] = None,
    ) -> RagConfig:
        """
        Update reranking configuration.

        Args:
            enabled: Whether to enable reranking.
            model: Reranking model ("cohere", "cross_encoder", "none").
            top_n: Number of results after reranking.

        Returns:
            Updated RagConfig object.

        Example:
            >>> client.config.update_reranking(enabled=True, model="cohere", top_n=5)
        """
        data = {"enabled": enabled, "model": model}
        if top_n is not None:
            data["top_n"] = top_n

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/config/rag/reranking", json_data=data
        )
        return self._parse_rag_config(response)

    # Validation Policy

    def get_validation_policy(self) -> ValidationPolicy:
        """
        Get current validation policy.

        Returns:
            ValidationPolicy object with current rules.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/config/validation-policy"
        )
        return self._parse_validation_policy(response)

    def set_validation_policy(self, policy: Dict[str, Any]) -> ValidationPolicy:
        """
        Set validation policy.

        Args:
            policy: Validation policy configuration dictionary.

        Returns:
            Updated ValidationPolicy object.

        Example:
            >>> policy = {
            ...     "forbidden_phrases": ["confidential", "internal only"],
            ...     "required_phrases": ["Disclaimer: ..."],
            ...     "pii_detection_enabled": True,
            ...     "require_citations": True
            ... }
            >>> client.config.set_validation_policy(policy)
        """
        response = self._make_request(
            "PUT", f"v1/{self.project_id}/config/validation-policy", json_data=policy
        )
        return self._parse_validation_policy(response)

    def generate_validation_policy(
        self,
        task_description: Optional[str] = None,
        old_integration: Optional[str] = None,
        new_integration: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Auto-generate a validation policy using AI.

        Args:
            task_description: Description of the task or use case.
            old_integration: Old integration being replaced (e.g., "Stripe").
            new_integration: New integration being added (e.g., "Paddle").

        Returns:
            Generated policy dictionary.

        Example:
            >>> policy = client.config.generate_validation_policy(
            ...     task_description="Replace Stripe with Paddle for payment processing",
            ...     old_integration="Stripe",
            ...     new_integration="Paddle"
            ... )
            >>> client.config.set_validation_policy(policy)
        """
        data = {}
        if task_description:
            data["task_description"] = task_description
        if old_integration:
            data["old_integration"] = old_integration
        if new_integration:
            data["new_integration"] = new_integration

        response = self._make_request(
            "POST", f"v1/{self.project_id}/config/validation-policy/generate", json_data=data
        )
        return response["policy"]

    # Repair Loop & Deployment Gating

    def configure_repair_loop(self, enabled: bool, max_retries: int = 2) -> RepairLoopConfig:
        """
        Configure the repair loop (auto-remediation on validation failure).

        Args:
            enabled: Whether to enable the repair loop.
            max_retries: Maximum number of retry attempts.

        Returns:
            RepairLoopConfig object.
        """
        data = {"enabled": enabled, "max_retries": max_retries}

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/config/repair-loop", json_data=data
        )
        return RepairLoopConfig(
            enabled=response["enabled"], max_retries=response["max_retries"]
        )

    def set_minimum_reliability_score(self, score: float) -> bool:
        """
        Set minimum reliability score for deployment gating.

        Args:
            score: Minimum score (0-100) required for publishing.

        Returns:
            True if update was successful.
        """
        data = {"minimum_reliability_score": score}

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/config/deployment-gating", json_data=data
        )
        return response.get("success", False)

    def enable_deployment_gating(self, enabled: bool) -> bool:
        """
        Enable or disable deployment gating.

        Args:
            enabled: Whether to enable deployment gating.

        Returns:
            True if update was successful.
        """
        data = {"deployment_gating_enabled": enabled}

        response = self._make_request(
            "PUT", f"v1/{self.project_id}/config/deployment-gating", json_data=data
        )
        return response.get("success", False)

    # Helper Methods

    def _parse_chat_settings(self, data: Dict[str, Any]) -> ChatSettings:
        """Parse chat settings from API response."""
        rag = None
        if data.get("rag_config"):
            rag = self._parse_rag_config(data["rag_config"])

        validation = None
        if data.get("validation_policy"):
            validation = self._parse_validation_policy(data["validation_policy"])

        repair = None
        if data.get("repair_loop"):
            r = data["repair_loop"]
            repair = RepairLoopConfig(enabled=r["enabled"], max_retries=r.get("max_retries", 2))

        return ChatSettings(
            project_id=data.get("project_id", data.get("chat_id", "")),
            model=data.get("model"),
            temperature=data.get("temperature"),
            max_tokens=data.get("max_tokens"),
            custom_prompt=data.get("custom_prompt"),
            repair_loop=repair,
            rag_config=rag,
            validation_policy=validation,
        )

    def _parse_rag_config(self, data: Dict[str, Any]) -> RagConfig:
        """Parse RAG config from API response."""
        chunking = ChunkingConfig(
            strategy=data["chunking"]["strategy"],
            chunk_size=data["chunking"].get("chunk_size"),
            chunk_overlap=data["chunking"].get("chunk_overlap"),
            max_chunk_size=data["chunking"].get("max_chunk_size"),
        )

        retrieval = RetrievalConfig(
            mode=data["retrieval"]["mode"],
            vector_weight=data["retrieval"].get("vector_weight"),
            keyword_weight=data["retrieval"].get("keyword_weight"),
            top_k=data["retrieval"].get("top_k", 10),
            similarity_threshold=data["retrieval"].get("similarity_threshold", 0.7),
        )

        reranking = RerankingConfig(
            enabled=data["reranking"]["enabled"],
            model=data["reranking"]["model"],
            top_n=data["reranking"].get("top_n"),
        )

        return RagConfig(chunking=chunking, retrieval=retrieval, reranking=reranking)

    def _parse_validation_policy(self, data: Dict[str, Any]) -> ValidationPolicy:
        """Parse validation policy from API response."""
        return ValidationPolicy(
            forbidden_phrases=data.get("forbidden_phrases"),
            required_phrases=data.get("required_phrases"),
            pii_detection_enabled=data.get("pii_detection_enabled", False),
            banned_packages=data.get("banned_packages"),
            required_packages=data.get("required_packages"),
            require_error_handling=data.get("require_error_handling", False),
            max_response_length=data.get("max_response_length"),
            require_citations=data.get("require_citations", False),
        )
