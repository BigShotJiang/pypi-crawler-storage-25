"""
Guardrails for Trainly SDK.

Guards validate agent outputs and enforce rules defined in the dashboard
or in code. They can stop, retry, or continue when checks fail.
"""

import re
import inspect
from typing import Optional, Callable, List, Dict, Any, Union


class GuardResult:
    """Result of a guard evaluation."""

    __slots__ = ("passed", "reason")

    def __init__(self, passed: bool, reason: Optional[str] = None):
        self.passed = passed
        self.reason = reason


class GuardFeedback:
    """Feedback from a failed guard, passed to functions on retry.

    When a guard fails and the on_fail policy triggers a retry, this object
    is injected into the function's ``guard_feedback`` keyword argument so
    the function can adjust its behaviour (e.g. modify the prompt).

    The ``__str__`` method returns the failure reason, so it can be
    interpolated directly into prompt strings.
    """

    __slots__ = ("guard_name", "reason", "attempt", "max_attempts")

    def __init__(
        self,
        guard_name: str,
        reason: str,
        attempt: int,
        max_attempts: int,
    ):
        self.guard_name = guard_name
        self.reason = reason
        self.attempt = attempt
        self.max_attempts = max_attempts

    def __str__(self) -> str:
        return self.reason

    def __repr__(self) -> str:
        return (
            f"GuardFeedback(guard_name={self.guard_name!r}, "
            f"reason={self.reason!r}, "
            f"attempt={self.attempt}/{self.max_attempts})"
        )


class GuardFailure(Exception):
    """Raised when a guard fails and the on_fail policy is 'stop'."""

    def __init__(
        self,
        guard_name: str,
        reason: str,
        trace_id: Optional[str] = None,
        attempts: int = 1,
    ):
        self.guard_name = guard_name
        self.reason = reason
        self.trace_id = trace_id
        self.attempts = attempts
        super().__init__(f"Guard '{guard_name}' failed: {reason}")


def _parse_on_fail(on_fail: str) -> dict:
    """Parse on_fail string into structured config.

    Returns dict with keys:
        action: "stop" | "retry" | "continue"
        max_retries: int (only if action == "retry")
        fallback: "stop" | "continue" (only if action == "retry")
    """
    if on_fail == "stop":
        return {"action": "stop"}
    if on_fail == "continue":
        return {"action": "continue"}
    match = re.match(r"^retry:(\d+)(?::(continue))?$", on_fail)
    if match:
        return {
            "action": "retry",
            "max_retries": int(match.group(1)),
            "fallback": match.group(2) or "stop",
        }
    raise ValueError(
        f"Invalid on_fail policy: {on_fail!r}. "
        f"Expected 'stop', 'continue', 'retry:N', or 'retry:N:continue'"
    )


class Guard:
    """Represents a single guardrail check.

    Create guards using the factory methods:
        Guard.dashboard()      — use dashboard-defined scorers
        Guard.cost_limit(0.50) — enforce cost threshold
        Guard.custom(fn)       — user-defined validation function
    """

    def __init__(
        self,
        guard_type: str,
        name: str,
        config: Optional[Dict[str, Any]] = None,
        on_fail: Optional[str] = None,
    ):
        self.guard_type = guard_type
        self.name = name
        self.config = config or {}
        self.on_fail = on_fail

    @classmethod
    def dashboard(cls, on_fail: Optional[str] = None) -> "Guard":
        """Use scorers enabled for real-time evaluation in the dashboard."""
        return cls(guard_type="dashboard", name="dashboard", on_fail=on_fail)

    @classmethod
    def cost_limit(cls, max_usd: float, on_fail: Optional[str] = None) -> "Guard":
        """Enforce a cumulative cost threshold (evaluated locally)."""
        return cls(
            guard_type="cost_limit",
            name="cost_limit",
            config={"max_usd": max_usd},
            on_fail=on_fail,
        )

    @classmethod
    def custom(
        cls,
        fn: Callable,
        name: Optional[str] = None,
        on_fail: Optional[str] = None,
    ) -> "Guard":
        """User-defined validation function.

        The function receives output as the first argument. It can optionally
        accept keyword arguments: input, metadata, context.

        It should return True (pass), False (fail), or a GuardResult.
        """
        guard_name = name or fn.__name__
        return cls(
            guard_type="custom",
            name=guard_name,
            config={"fn": fn},
            on_fail=on_fail,
        )

    @staticmethod
    def _normalize(
        guards: Union[bool, "Guard", List["Guard"]],
    ) -> List["Guard"]:
        """Normalize the guards parameter from @observe into a list."""
        if guards is True:
            return [Guard.dashboard()]
        if isinstance(guards, Guard):
            return [guards]
        if isinstance(guards, list):
            for g in guards:
                if not isinstance(g, Guard):
                    raise TypeError(
                        f"Every item in guards list must be a Guard, got {type(g)}"
                    )
            return guards
        raise TypeError(
            f"guards must be True, a Guard, or a list of Guards, got {type(guards)}"
        )


def run_local_guard(guard: Guard, output: str, **context) -> GuardResult:
    """Execute a local guard (cost_limit or custom) and return a GuardResult."""
    if guard.guard_type == "cost_limit":
        max_usd = guard.config["max_usd"]
        current_cost = context.get("cost", 0.0) or 0.0
        if current_cost >= max_usd:
            return GuardResult(
                passed=False,
                reason=f"Cost ${current_cost:.4f} exceeds limit ${max_usd:.2f}",
            )
        return GuardResult(passed=True)

    if guard.guard_type == "custom":
        fn = guard.config["fn"]
        sig = inspect.signature(fn)
        params = set(sig.parameters.keys())
        kwargs = {}
        for key in ("input", "metadata", "context"):
            if key in params and key in context:
                kwargs[key] = context[key]

        result = fn(output, **kwargs)
        if isinstance(result, GuardResult):
            return result
        if isinstance(result, bool):
            return GuardResult(
                passed=result,
                reason=None if result else f"Guard '{guard.name}' returned False",
            )
        raise TypeError(
            f"Custom guard '{guard.name}' must return bool or GuardResult, got {type(result)}"
        )

    raise ValueError(f"Cannot run guard type '{guard.guard_type}' locally")
