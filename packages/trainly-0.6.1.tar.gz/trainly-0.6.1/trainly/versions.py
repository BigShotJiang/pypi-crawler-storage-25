"""
Versions client for publishing and managing configuration versions.
"""

from typing import Optional, List, Dict, Any, TYPE_CHECKING
from datetime import datetime

from .models import (
    PublishedVersion,
    VersionDiff,
    FileSnapshot,
    TrainlyError,
)

if TYPE_CHECKING:
    from .client import TrainlyClient


class VersionsClient:
    """
    Client for managing configuration versions and publishing.

    This client provides methods for publishing settings, rolling back to
    previous versions, and comparing version differences.

    Example:
        >>> client = TrainlyClient(api_key="tk_...", project_id="...")
        >>> version = client.versions.publish(
        ...     version="1.0.0",
        ...     description="Initial production release"
        ... )
        >>> versions = client.versions.list_versions()
        >>> client.versions.rollback(version_id=previous_version_id)
    """

    def __init__(self, parent_client: "TrainlyClient"):
        """Initialize the versions client with a parent client."""
        self.parent = parent_client
        self.base_url = parent_client.base_url
        self.project_id = parent_client.project_id
        self.session = parent_client.session

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request to the versions API."""
        url = f"{self.base_url}/{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                timeout=self.parent.timeout,
            )

            if not response.ok:
                error_data = response.json() if response.content else {}
                raise TrainlyError(
                    error_data.get("detail", f"HTTP {response.status_code}"),
                    status_code=response.status_code,
                    details=error_data,
                )

            return response.json()

        except TrainlyError:
            raise
        except Exception as e:
            raise TrainlyError(f"Request failed: {str(e)}")

    # Publishing

    def publish(
        self,
        version: str,
        description: Optional[str] = None,
        custom_config: Optional[Dict[str, Any]] = None,
    ) -> PublishedVersion:
        """
        Publish current settings as a new version.

        Args:
            version: Version identifier (e.g., "1.0.0", "v2.1", "prod-2024-01").
            description: Optional description of this version.
            custom_config: Optional arbitrary configuration to snapshot with this version
                (e.g., RL environment params, agent configs, pipeline settings).

        Returns:
            PublishedVersion object with published version information.

        Example:
            >>> version = client.versions.publish(
            ...     version="1.0.0",
            ...     description="Baseline sparse reward config",
            ...     custom_config={"reward_function": "sparse", "difficulty": 0.7}
            ... )
        """
        data: Dict[str, Any] = {"version": version}
        if description:
            data["description"] = description
        if custom_config is not None:
            data["custom_config"] = custom_config

        response = self._make_request(
            "POST", f"v1/{self.project_id}/versions/publish", json_data=data
        )

        # The publish endpoint returns a minimal response (version, version_id, versionNumber).
        # Build a PublishedVersion from what we have.
        return PublishedVersion(
            version_id=response.get("version_id") or response.get("versionId", ""),
            version=response.get("version", version),
            status=response.get("status", "active"),
            description=description,
            custom_config_snapshot=custom_config,
        )

    def publish_patch(
        self,
        description: Optional[str] = None,
        custom_config: Optional[Dict[str, Any]] = None,
    ) -> PublishedVersion:
        """
        Bump the patch version and publish (e.g., 1.0.0 → 1.0.1).

        Queries the current highest version and increments the patch number.
        If no versions exist, publishes as 1.0.0.

        Args:
            description: Optional description of this version.
            custom_config: Optional arbitrary configuration to snapshot.

        Returns:
            PublishedVersion object with published version information.

        Example:
            >>> version = client.versions.publish_patch(
            ...     description="Fix reward scaling bug"
            ... )
            >>> print(version.version)  # "1.0.1"
        """
        major, minor, patch = self._get_highest_semver()
        return self.publish(f"{major}.{minor}.{patch + 1}", description, custom_config)

    def publish_minor(
        self,
        description: Optional[str] = None,
        custom_config: Optional[Dict[str, Any]] = None,
    ) -> PublishedVersion:
        """
        Bump the minor version and publish (e.g., 1.0.0 → 1.1.0).

        Queries the current highest version and increments the minor number.
        If no versions exist, publishes as 1.0.0.

        Args:
            description: Optional description of this version.
            custom_config: Optional arbitrary configuration to snapshot.

        Returns:
            PublishedVersion object with published version information.

        Example:
            >>> version = client.versions.publish_minor(
            ...     description="Add dense reward shaping"
            ... )
            >>> print(version.version)  # "1.1.0"
        """
        major, minor, _patch = self._get_highest_semver()
        return self.publish(f"{major}.{minor + 1}.0", description, custom_config)

    def publish_major(
        self,
        description: Optional[str] = None,
        custom_config: Optional[Dict[str, Any]] = None,
    ) -> PublishedVersion:
        """
        Bump the major version and publish (e.g., 1.2.3 → 2.0.0).

        Queries the current highest version and increments the major number.
        If no versions exist, publishes as 1.0.0.

        Args:
            description: Optional description of this version.
            custom_config: Optional arbitrary configuration to snapshot.

        Returns:
            PublishedVersion object with published version information.

        Example:
            >>> version = client.versions.publish_major(
            ...     description="New environment architecture"
            ... )
            >>> print(version.version)  # "2.0.0"
        """
        major, _minor, _patch = self._get_highest_semver()
        return self.publish(f"{major + 1}.0.0", description, custom_config)

    def _get_highest_semver(self) -> tuple:
        """
        Get the highest semver (major, minor, patch) from existing versions.
        Returns (0, 0, -1) if no versions exist (so patch bump yields 1.0.0).
        """
        import re
        versions = self.list_versions(limit=100)
        best = (0, 0, -1)
        for v in versions:
            match = re.match(r"^v?(\d+)\.(\d+)\.(\d+)", v.version)
            if match:
                parsed = (int(match.group(1)), int(match.group(2)), int(match.group(3)))
                if parsed > best:
                    best = parsed
        return best

    def list_versions(self, page: int = 1, limit: int = 20) -> List[PublishedVersion]:
        """
        List all published versions.

        Args:
            page: Page number (1-indexed).
            limit: Number of versions per page.

        Returns:
            List of PublishedVersion objects.
        """
        params = {"page": page, "limit": limit}

        response = self._make_request(
            "GET", f"v1/{self.project_id}/versions", params=params
        )

        # API may return a list directly or {"versions": [...]}
        items = response if isinstance(response, list) else response.get("versions", [])
        return [self._parse_published_version(v) for v in items]

    def get_version(self, version_id: str) -> PublishedVersion:
        """
        Get details of a specific published version.

        Args:
            version_id: ID of the version to retrieve.

        Returns:
            PublishedVersion object with version details.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/versions/{version_id}"
        )

        return self._parse_published_version(response)

    # Rollback

    def rollback(self, version_id: str) -> bool:
        """
        Rollback to a previous published version.

        Args:
            version_id: ID of the version to rollback to.

        Returns:
            True if rollback was successful.

        Example:
            >>> versions = client.versions.list_versions()
            >>> previous_version = versions[1]  # Get second most recent
            >>> success = client.versions.rollback(previous_version.version_id)
            >>> if success:
            ...     print(f"Rolled back to version {previous_version.version}")
        """
        response = self._make_request(
            "POST", f"v1/{self.project_id}/versions/{version_id}/rollback"
        )

        return response.get("success", False)

    def compare_versions(self, version_a: str, version_b: str) -> VersionDiff:
        """
        Compare two versions to see what changed.

        Args:
            version_a: First version ID to compare.
            version_b: Second version ID to compare.

        Returns:
            VersionDiff object with differences between versions.

        Example:
            >>> diff = client.versions.compare_versions(v1_id, v2_id)
            >>> print(f"Settings changed: {', '.join(diff.settings_changed)}")
            >>> print(f"Files added: {len(diff.files_added)}")
            >>> print(f"Files removed: {len(diff.files_removed)}")
        """
        params = {"version_a": version_a, "version_b": version_b}

        response = self._make_request(
            "GET", f"v1/{self.project_id}/versions/compare", params=params
        )

        return VersionDiff(
            version_a=response["version_a"],
            version_b=response["version_b"],
            settings_changed=response["settings_changed"],
            files_added=response["files_added"],
            files_removed=response["files_removed"],
            files_modified=response["files_modified"],
        )

    # Status

    def get_unpublished_changes(self) -> bool:
        """
        Check if there are unpublished changes.

        Returns:
            True if there are changes that haven't been published.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/versions/unpublished-changes"
        )

        return response.get("has_changes", False)

    def get_active_version(self) -> Optional[PublishedVersion]:
        """
        Get the currently active published version.

        Returns:
            PublishedVersion object if a version is active, None otherwise.
        """
        response = self._make_request(
            "GET", f"v1/{self.project_id}/versions/active"
        )

        if response.get("version"):
            return self._parse_published_version(response["version"])

        return None

    # Helper Methods

    def _parse_published_version(self, data: Dict[str, Any]) -> PublishedVersion:
        """Parse a published version from API response."""
        file_snapshots = None
        raw_snapshots = data.get("file_snapshots") or data.get("fileSnapshots")
        if raw_snapshots:
            file_snapshots = [
                FileSnapshot(
                    file_id=f.get("file_id") or f.get("fileId", ""),
                    filename=f.get("filename") or f.get("fileName", ""),
                    size_bytes=f.get("size_bytes") or f.get("fileSize", 0),
                    chunk_count=f.get("chunk_count") or f.get("neo4jChunkCount", 0),
                )
                for f in raw_snapshots
            ]

        # Handle both snake_case and camelCase field names from API
        version_id = data.get("version_id") or data.get("versionId") or data.get("_id", "")
        published_at_raw = data.get("published_at") or data.get("publishedAt")

        return PublishedVersion(
            version_id=version_id,
            version=data.get("version", ""),
            status=data.get("status", "unknown"),
            description=data.get("description"),
            settings_snapshot=data.get("settings_snapshot") or data.get("settingsSnapshot"),
            custom_config_snapshot=data.get("custom_config_snapshot") or data.get("customConfigSnapshot"),
            file_snapshots=file_snapshots,
            total_files=data.get("total_files") or data.get("totalFiles", 0),
            published_at=datetime.fromtimestamp(published_at_raw / 1000)
            if isinstance(published_at_raw, (int, float))
            else datetime.fromisoformat(published_at_raw) if isinstance(published_at_raw, str)
            else None,
            published_by=data.get("published_by") or data.get("userId"),
        )
