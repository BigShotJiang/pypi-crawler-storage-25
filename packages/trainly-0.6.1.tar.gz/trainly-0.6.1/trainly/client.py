"""
Main Trainly client for API key authentication and AI observability.
"""

import os
import json
import time
import warnings
from typing import Optional, Dict, Any, List, Iterator
from pathlib import Path
import requests

from .models import (
    QueryResponse,
    ChunkScore,
    Usage,
    UploadResult,
    FileListResult,
    FileDeleteResult,
    BulkUploadResult,
    BulkUploadFileResult,
    FileInfo,
    TrainlyError,
    StreamChunk,
    ToolDefinition,
    ToolCall,
    InvokeResult,
    InvokeValidation,
    ValidationOutcome,
)

from .prompt import Prompt


class TrainlyClient:
    """
    Trainly client for API key authentication and AI observability.

    This client is for straightforward use cases where you have a Trainly API key
    and want to observe AI calls in a specific project.

    Example:
        >>> from trainly import TrainlyClient
        >>> client = TrainlyClient(
        ...     api_key="tk_your_api_key",
        ...     project_id="proj_abc123"
        ... )
        >>> @client.observe(model="gpt-4o")
        ... def my_ai_call(query: str) -> str:
        ...     return call_my_llm(query)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        project_id: Optional[str] = None,
        chat_id: Optional[str] = None,
        base_url: str = "https://api.trainlyai.com",
        timeout: int = 30,
        max_retries: int = 3,
    ):
        """
        Initialize the Trainly client.

        Args:
            api_key: Trainly API key (starts with 'tk_'). Can also be set via TRAINLY_API_KEY env var.
            project_id: Project ID to observe. Can also be set via TRAINLY_PROJECT_ID env var.
            chat_id: Deprecated alias for project_id. Use project_id instead.
            base_url: Base URL for the Trainly API.
            timeout: Request timeout in seconds.
            max_retries: Maximum number of retries for failed requests.
        """
        self.api_key = api_key or os.getenv("TRAINLY_API_KEY")

        # Handle project_id / chat_id (deprecated alias)
        if chat_id is not None and project_id is None:
            warnings.warn(
                "chat_id is deprecated, use project_id instead. "
                "chat_id will be removed in a future version.",
                DeprecationWarning,
                stacklevel=2,
            )
            self.project_id = chat_id
        else:
            self.project_id = project_id or os.getenv("TRAINLY_PROJECT_ID") or os.getenv("TRAINLY_CHAT_ID")

        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

        if not self.api_key:
            raise TrainlyError("API key is required. Provide it via api_key parameter or TRAINLY_API_KEY environment variable.")

        if not self.project_id:
            raise TrainlyError("Project ID is required. Provide it via project_id parameter or TRAINLY_PROJECT_ID environment variable.")

        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        })

        # Initialize sub-clients for advanced features
        self._init_sub_clients()

    def _init_sub_clients(self):
        """Initialize specialized sub-clients based on authentication mode."""
        from .testing import TestingClient
        from .fine_tuning import FineTuningClient
        from .config import ConfigClient
        from .analytics import AnalyticsClient
        from .versions import VersionsClient
        from .observe import ObserveDecorator

        # API key mode has full access to all features
        self.testing = TestingClient(self)
        self.fine_tuning = FineTuningClient(self)
        self.config = ConfigClient(self)
        self.analytics = AnalyticsClient(self)
        self.versions = VersionsClient(self)
        self.observe = ObserveDecorator(self)

    def query(
        self,
        question: str,
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 1000,
        include_context: bool = True,
        scope_filters: Optional[Dict[str, Any]] = None,
    ) -> QueryResponse:
        """
        Deprecated: Query the knowledge base with a question.

        This is a legacy RAG method. For new projects, use client.observe to trace
        your own AI calls, or client.invoke for general-purpose invocation.

        Args:
            question: The question to ask.
            model: The LLM model to use (e.g., 'gpt-4o', 'gpt-4o-mini').
            temperature: Sampling temperature (0.0 to 1.0).
            max_tokens: Maximum tokens in the response.
            include_context: Whether to include context chunks in the response.
            scope_filters: Optional filters to narrow down the search scope.

        Returns:
            QueryResponse containing the answer and context.
        """
        warnings.warn(
            "query() is a legacy RAG method and is deprecated. "
            "Use client.observe to trace AI calls or client.invoke for general-purpose invocation.",
            DeprecationWarning,
            stacklevel=2,
        )
        url = f"{self.base_url}/v1/{self.project_id}/answer_question"

        payload = {
            "question": question,
            "model": model,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if scope_filters:
            payload["scope_filters"] = scope_filters

        response = self._request_with_retry("POST", url, json=payload)
        data = response.json()

        # Parse context chunks
        context = []
        if include_context and "context" in data:
            for chunk_data in data["context"]:
                context.append(ChunkScore(
                    chunk_text=chunk_data.get("chunk_text", ""),
                    score=chunk_data.get("score", 0.0),
                    source=chunk_data.get("source", ""),
                    page=chunk_data.get("page"),
                    metadata=chunk_data.get("metadata"),
                ))

        # Parse usage if available
        usage = None
        if "usage" in data:
            usage_data = data["usage"]
            usage = Usage(
                prompt_tokens=usage_data.get("prompt_tokens", 0),
                completion_tokens=usage_data.get("completion_tokens", 0),
                total_tokens=usage_data.get("total_tokens", 0),
            )

        return QueryResponse(
            answer=data.get("answer", ""),
            context=context,
            usage=usage,
            model=data.get("model"),
        )

    def query_stream(
        self,
        question: str,
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 1000,
        scope_filters: Optional[Dict[str, Any]] = None,
    ) -> Iterator[StreamChunk]:
        """
        Query the knowledge base with streaming response.

        Args:
            question: The question to ask.
            model: The LLM model to use.
            temperature: Sampling temperature.
            max_tokens: Maximum tokens in the response.
            scope_filters: Optional filters to narrow down the search scope.

        Yields:
            StreamChunk objects containing content, context, or end markers.

        Example:
            >>> for chunk in client.query_stream("Explain the methodology"):
            ...     if chunk.is_content:
            ...         print(chunk.data, end="", flush=True)
            ...     elif chunk.is_end:
            ...         print("\\nStream complete!")
        """
        url = f"{self.base_url}/v1/{self.project_id}/answer_question_stream"

        payload = {
            "question": question,
            "model": model,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if scope_filters:
            payload["scope_filters"] = scope_filters

        response = self._request_with_retry("POST", url, json=payload, stream=True)

        for line in response.iter_lines():
            if line:
                line_str = line.decode("utf-8")
                if line_str.startswith("data: "):
                    data_str = line_str[6:]
                    if data_str == "[DONE]":
                        yield StreamChunk(type="end", data=None)
                        break

                    try:
                        data = json.loads(data_str)
                        chunk_type = data.get("type", "content")

                        if chunk_type == "content":
                            yield StreamChunk(type="content", data=data.get("data", ""))
                        elif chunk_type == "context":
                            context = []
                            for chunk_data in data.get("data", []):
                                context.append(ChunkScore(
                                    chunk_text=chunk_data.get("chunk_text", ""),
                                    score=chunk_data.get("score", 0.0),
                                    source=chunk_data.get("source", ""),
                                    page=chunk_data.get("page"),
                                ))
                            yield StreamChunk(type="context", data=context)
                        elif chunk_type == "error":
                            yield StreamChunk(type="error", data=data.get("data", ""))
                    except json.JSONDecodeError:
                        continue

    def upload_file(
        self,
        file_path: str,
        scope_values: Optional[Dict[str, Any]] = None,
        wait: bool = True,
        poll_interval: float = 1.0,
        timeout: float = 300.0,
    ) -> UploadResult:
        """
        Deprecated: Upload a file to the project knowledge base.

        This is a legacy RAG method. For new projects, use client.observe to trace
        your own AI calls instead of uploading documents for RAG.

        Args:
            file_path: Path to the file to upload.
            scope_values: Optional custom scope values for filtering.
            wait: If True, block until file processing is complete. Default: True.
            poll_interval: Seconds between status checks when waiting. Default: 1.0.
            timeout: Maximum seconds to wait for processing. Default: 300.0 (5 minutes).

        Returns:
            UploadResult with upload details.
        """
        warnings.warn(
            "upload_file() is a legacy RAG method and is deprecated. "
            "Use client.observe to trace AI calls instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        file_path_obj = Path(file_path)
        if not file_path_obj.exists():
            raise TrainlyError(f"File not found: {file_path}")

        url = f"{self.base_url}/v1/{self.project_id}/upload_with_scopes"

        try:
            with open(file_path, "rb") as f:
                files = {"file": (file_path_obj.name, f)}
                data = {}

                # Always send scope_values, default to empty dict if not provided
                data["scope_values"] = json.dumps(scope_values) if scope_values else "{}"

                # Remove Content-Type header for multipart/form-data
                headers = {"Authorization": f"Bearer {self.api_key}"}

                response = requests.post(
                    url,
                    files=files,
                    data=data,
                    headers=headers,
                    timeout=self.timeout,
                )
                response.raise_for_status()
                result_data = response.json()

                file_id = result_data.get("file_id")
                status = result_data.get("status", "processing")

                if not wait:
                    return UploadResult(
                        success=True,
                        filename=result_data.get("filename", file_path_obj.name),
                        file_id=file_id,
                        size_bytes=result_data.get("size_bytes", file_path_obj.stat().st_size),
                        message=result_data.get("message", "File upload initiated"),
                        processing_status=status,
                    )

                # Poll until ready
                return self.wait_for_file(file_id, poll_interval=poll_interval, timeout=timeout)

        except requests.exceptions.HTTPError as e:
            self._handle_http_error(e)
        except requests.exceptions.RequestException as e:
            raise TrainlyError(f"Upload failed: {str(e)}")
        except IOError as e:
            raise TrainlyError(f"File read error: {str(e)}")

    def wait_for_file(
        self,
        file_id: str,
        poll_interval: float = 1.0,
        timeout: float = 300.0,
    ) -> UploadResult:
        """
        Wait for a file to finish processing.

        Args:
            file_id: The file ID returned from upload_file.
            poll_interval: Seconds between status checks. Default: 1.0.
            timeout: Maximum seconds to wait. Default: 300.0 (5 minutes).

        Returns:
            UploadResult with upload details.

        Raises:
            TrainlyError: If processing fails or times out.
        """
        url = f"{self.base_url}/v1/{self.project_id}/files/{file_id}/status"
        start_time = time.time()

        while True:
            response = self._request_with_retry("GET", url)
            status_data = response.json()

            status = status_data.get("status")

            if status == "ready":
                # Small delay to ensure chunks are fully indexed and queryable in Neo4j
                time.sleep(0.2)
                return UploadResult(
                    success=True,
                    filename=status_data.get("filename", "Unknown"),
                    file_id=file_id,
                    size_bytes=status_data.get("size_bytes", 0),
                    message="File processed successfully",
                    processing_status="completed",
                )

            if status == "failed":
                error_msg = status_data.get("error", "Unknown error")
                raise TrainlyError(f"File processing failed for {file_id}: {error_msg}")

            # Check timeout
            if time.time() - start_time > timeout:
                raise TrainlyError(f"Timed out waiting for file {file_id} to be ready after {timeout} seconds")

            # Still processing, wait and poll again
            time.sleep(poll_interval)

    def list_files(self) -> FileListResult:
        """
        List all files in the knowledge base.

        Returns:
            FileListResult with list of files and metadata.

        Example:
            >>> files = client.list_files()
            >>> print(f"Total files: {files.total_files}")
            >>> for file in files.files:
            ...     print(f"{file.filename}: {file.size_bytes} bytes")
        """
        url = f"{self.base_url}/v1/{self.project_id}/files"

        response = self._request_with_retry("GET", url)
        data = response.json()

        files = []
        for file_data in data.get("files", []):
            files.append(FileInfo(
                file_id=file_data["file_id"],
                filename=file_data["filename"],
                upload_date=file_data["upload_date"],
                size_bytes=file_data["size_bytes"],
                chunk_count=file_data["chunk_count"],
            ))

        return FileListResult(
            success=data.get("success", True),
            files=files,
            total_files=data.get("total_files", len(files)),
            total_size_bytes=data.get("total_size_bytes", 0),
        )

    def delete_file(self, file_id: str) -> FileDeleteResult:
        """
        Delete a file from the knowledge base.

        Args:
            file_id: The ID of the file to delete.

        Returns:
            FileDeleteResult with deletion details.

        Example:
            >>> result = client.delete_file("v1_user_xyz_document.pdf_1609459200")
            >>> print(f"Deleted {result.filename}")
            >>> print(f"Freed {result.size_bytes_freed} bytes")
        """
        if not file_id:
            raise TrainlyError("File ID is required")

        url = f"{self.base_url}/v1/{self.project_id}/files/{file_id}"

        response = self._request_with_retry("DELETE", url)
        data = response.json()

        return FileDeleteResult(
            success=data.get("success", True),
            message=data.get("message", "File deleted successfully"),
            file_id=data.get("file_id", file_id),
            filename=data.get("filename", ""),
            chunks_deleted=data.get("chunks_deleted", 0),
            size_bytes_freed=data.get("size_bytes_freed", 0),
        )

    def invoke(
        self,
        input: Any,
        tools: Optional[List[ToolDefinition]] = None,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> InvokeResult:
        """
        General-purpose invocation for any AI endpoint type.

        Unlike query() which assumes RAG Q&A, invoke() accepts arbitrary
        JSON input and returns arbitrary JSON output. Works with any endpoint type:
        rag_qa, chatbot, code_gen, agent, or custom.

        Args:
            input: Arbitrary input (string, dict, list, etc.)
            tools: Optional tool definitions for agent-type endpoints.
            model: Override the model for this invocation.
            temperature: Override the temperature.
            max_tokens: Override max tokens.
            metadata: Optional metadata to attach to the trace.

        Returns:
            InvokeResult with output, tool_calls, validation, and trace info.

        Example:
            >>> result = client.invoke("Hello, how are you?")
            >>> print(result.output)

            >>> # Agent with tools
            >>> result = client.invoke(
            ...     {"messages": [{"role": "user", "content": "Search for news"}]},
            ...     tools=[ToolDefinition(name="search", description="Search the web")],
            ... )
            >>> print(result.tool_calls)
        """
        url = f"{self.base_url}/v1/{self.project_id}/invoke"

        payload: Dict[str, Any] = {"input": input}
        if tools:
            payload["tools"] = [
                {"name": t.name, "description": t.description, "parameters": t.parameters}
                for t in tools
            ]
        if model is not None:
            payload["model"] = model
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if metadata is not None:
            payload["metadata"] = metadata

        response = self._request_with_retry("POST", url, json=payload)
        data = response.json()

        # Parse tool calls
        tool_calls = None
        if data.get("tool_calls"):
            tool_calls = [
                ToolCall(
                    tool_name=tc.get("tool_name", ""),
                    tool_input=tc.get("tool_input"),
                    tool_output=tc.get("tool_output"),
                    duration_ms=tc.get("duration_ms"),
                    status=tc.get("status"),
                    error=tc.get("error"),
                )
                for tc in data["tool_calls"]
            ]

        # Parse validation
        validation = None
        if data.get("validation"):
            v = data["validation"]
            outcomes = None
            if v.get("outcomes"):
                outcomes = [
                    ValidationOutcome(
                        validator=o.get("validator", ""),
                        result=o.get("result", ""),
                        message=o.get("message", ""),
                        details=o.get("details"),
                    )
                    for o in v["outcomes"]
                ]
            validation = InvokeValidation(
                passed=v.get("passed", False),
                pass_count=v.get("passCount", 0),
                fail_count=v.get("failCount", 0),
                warn_count=v.get("warnCount", 0),
                failure_reasons=v.get("failureReasons"),
                outcomes=outcomes,
            )

        return InvokeResult(
            output=data.get("output"),
            tool_calls=tool_calls,
            latency_ms=data.get("latency_ms"),
            trace_id=data.get("trace_id"),
            model=data.get("model"),
            validation=validation,
        )

    def generate_policy(
        self,
        task_description: Optional[str] = None,
        old_integration: Optional[str] = None,
        new_integration: Optional[str] = None,
        model: str = "gpt-4o-mini",
    ) -> Dict[str, Any]:
        """
        Dynamically generate a validation policy for the knowledge base.

        Use this when you don't know the constraints in advance — for example,
        swapping any integration for any other, or generating policies from
        plain-English descriptions.

        Two modes:
          1. **Swap mode**: provide old_integration + new_integration
             e.g., generate_policy(old_integration="Stripe", new_integration="Paddle")
          2. **Freeform mode**: provide a task_description
             e.g., generate_policy(task_description="Replace SendGrid with Resend in a Node.js app")

        Args:
            task_description: Natural language description of the task.
            old_integration: Name of the integration being removed.
            new_integration: Name of the replacement integration.
            model: LLM model to use for policy generation.

        Returns:
            Dict containing the generated validation policy. Save this to the
            chat's validationPolicy to enforce it on all subsequent queries.

        Example:
            >>> # Swap mode
            >>> policy = client.generate_policy(
            ...     old_integration="Stripe",
            ...     new_integration="Paddle"
            ... )
            >>> print(policy)
            {'bannedPackages': ['stripe'], 'requiredPackages': ['@paddle/paddle-node-sdk'], ...}
            >>>
            >>> # Freeform mode
            >>> policy = client.generate_policy(
            ...     task_description="Migrate from REST to GraphQL using Apollo"
            ... )
        """
        url = f"{self.base_url}/generate_validation_policy"
        payload: Dict[str, Any] = {"model": model}

        if old_integration and new_integration:
            payload["old_integration"] = old_integration
            payload["new_integration"] = new_integration
        elif task_description:
            payload["task_description"] = task_description
        else:
            raise TrainlyError(
                "Provide either (old_integration + new_integration) or task_description"
            )

        response = self._request_with_retry("POST", url, json=payload)
        data = response.json()
        return data.get("policy", {})

    def score(self, trace_id: str, name: str, value: float, comment: str = None):
        """Add a score to a trace (e.g., user feedback, evaluation result).

        Args:
            trace_id: The trace ID to score
            name: Score name (e.g., "user-feedback", "accuracy")
            value: Numeric score value (0-1 for normalized, 0/1 for thumbs)
            comment: Optional comment explaining the score
        """
        payload = {"name": name, "value": value}
        if comment:
            payload["comment"] = comment
        response = self.session.post(
            f"{self.base_url}/v1/{self.project_id}/traces/{trace_id}/scores",
            json=payload,
            timeout=self.timeout,
        )
        response.raise_for_status()

    def get_prompt(
        self,
        slug: str,
        version: Optional[int] = None,
    ) -> "Prompt":
        """
        Fetch a versioned prompt template from the registry.

        Args:
            slug: The prompt slug identifier.
            version: Optional specific version number. Fetches latest if omitted.

        Returns:
            Prompt object with template content and metadata.

        Example:
            >>> prompt = client.get_prompt("summarize-doc")
            >>> rendered = prompt.build(document="Hello world", style="concise")
            >>> print(rendered)
        """
        url = f"{self.base_url}/v1/{self.project_id}/prompts/{slug}"
        params = {}
        if version is not None:
            params["version"] = version

        response = self._request_with_retry("GET", url, params=params)
        data = response.json()

        return Prompt(
            slug=data.get("slug", slug),
            name=data.get("name", ""),
            content=data.get("content", ""),
            variables=data.get("variables", []),
            version=data.get("version", 1),
            model=data.get("model"),
            temperature=data.get("temperature"),
            max_tokens=data.get("max_tokens"),
        )

    def score_with_judge(
        self,
        scorer_slug: str,
        trace_id: Optional[str] = None,
        input: Optional[str] = None,
        output: Optional[str] = None,
        expected_output: Optional[str] = None,
    ) -> dict:
        """
        Run an LLM judge scorer against a trace or supplied input/output.

        Args:
            scorer_slug: The slug of the scorer to run.
            trace_id: Optional trace ID to score (pulls input/output from the trace).
            input: Optional input text to score.
            output: Optional output text to score.
            expected_output: Optional expected output for comparison.

        Returns:
            Dict with "score" (float) and "reasoning" (str).

        Example:
            >>> result = client.score_with_judge(
            ...     "helpfulness",
            ...     input="What is Python?",
            ...     output="Python is a programming language.",
            ... )
            >>> print(f"Score: {result['score']}, Reasoning: {result['reasoning']}")
        """
        url = f"{self.base_url}/v1/{self.project_id}/scorers/{scorer_slug}/run"

        payload: Dict[str, Any] = {}
        if trace_id is not None:
            payload["trace_id"] = trace_id
        if input is not None:
            payload["input"] = input
        if output is not None:
            payload["output"] = output
        if expected_output is not None:
            payload["expected_output"] = expected_output

        response = self._request_with_retry("POST", url, json=payload)
        return response.json()

    def evaluate(
        self,
        input: str,
        output: str,
        model: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Evaluate an output against real-time enabled scorers.

        Calls the backend evaluate endpoint which runs all eval rules
        that have realtime_enabled=True for this project.

        Args:
            input: The input that produced the output.
            output: The output to evaluate.
            model: Optional model name for context.
            metadata: Optional metadata for context.
            tags: Optional tags for filtering which rules apply.

        Returns:
            Dict with 'passed' (bool) and 'results' (list of scorer results).
        """
        url = f"{self.base_url}/v1/{self.project_id}/evaluate"
        payload: Dict[str, Any] = {"input": input, "output": output}
        if model is not None:
            payload["model"] = model
        if metadata is not None:
            payload["metadata"] = metadata
        if tags is not None:
            payload["tags"] = tags
        response = self._request_with_retry("POST", url, json=payload)
        return response.json()

    def _request_with_retry(
        self,
        method: str,
        url: str,
        **kwargs,
    ) -> requests.Response:
        """
        Make an HTTP request with retry logic for transient failures.
        Retries on 429 (rate limit) and 5xx (server errors) with exponential backoff.
        """
        last_error = None
        for attempt in range(self.max_retries):
            try:
                kwargs.setdefault("timeout", self.timeout)
                response = self.session.request(method, url, **kwargs)
                # Retry on rate limit or server errors
                if response.status_code == 429 or response.status_code >= 500:
                    if attempt < self.max_retries - 1:
                        retry_after = response.headers.get("Retry-After")
                        wait_time = float(retry_after) if retry_after else (2 ** attempt)
                        time.sleep(wait_time)
                        continue
                response.raise_for_status()
                return response
            except requests.exceptions.ConnectionError as e:
                last_error = e
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                raise TrainlyError(f"Connection failed after {self.max_retries} attempts: {e}")
            except requests.exceptions.HTTPError as e:
                # Non-retryable HTTP error (4xx except 429)
                self._handle_http_error(e)

        # Should not reach here, but just in case
        if last_error:
            raise TrainlyError(f"Request failed after {self.max_retries} retries: {last_error}")

    def _handle_http_error(self, error: requests.exceptions.HTTPError) -> None:
        """Handle HTTP errors and raise appropriate TrainlyError."""
        status_code = error.response.status_code

        try:
            error_data = error.response.json()
            message = error_data.get("detail", str(error))
            details = error_data
        except (json.JSONDecodeError, AttributeError):
            message = str(error)
            details = {}

        raise TrainlyError(message, status_code=status_code, details=details)

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.session.close()

    def close(self):
        """Close the HTTP session."""
        self.session.close()

