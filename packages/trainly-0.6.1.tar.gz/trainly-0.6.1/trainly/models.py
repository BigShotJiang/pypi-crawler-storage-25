"""
Type definitions and response models for Trainly SDK
"""

from typing import List, Optional, Dict, Any, Union
from dataclasses import dataclass
from datetime import datetime


@dataclass
class ChunkScore:
    """Represents a chunk of text from the knowledge base with relevance score."""

    chunk_text: str
    score: float
    source: str
    page: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class Usage:
    """Token usage information for the query."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class QueryResponse:
    """Response from a query to the knowledge base."""

    answer: str
    context: List[ChunkScore]
    usage: Optional[Usage] = None
    model: Optional[str] = None

    def __str__(self) -> str:
        return f"QueryResponse(answer='{self.answer[:100]}...', context={len(self.context)} chunks)"


@dataclass
class UploadResult:
    """Result of uploading a file to the knowledge base."""

    success: bool
    filename: str
    file_id: Optional[str] = None
    size_bytes: int = 0
    message: Optional[str] = None
    processing_status: Optional[str] = None


@dataclass
class FileInfo:
    """Information about a file in the knowledge base."""

    file_id: str
    filename: str
    upload_date: str  # Unix timestamp as string
    size_bytes: int
    chunk_count: int

    @property
    def upload_datetime(self) -> datetime:
        """Convert upload_date timestamp to datetime object."""
        return datetime.fromtimestamp(int(self.upload_date) / 1000)


@dataclass
class FileListResult:
    """Result of listing files in the knowledge base."""

    success: bool
    files: List[FileInfo]
    total_files: int
    total_size_bytes: int


@dataclass
class FileDeleteResult:
    """Result of deleting a file from the knowledge base."""

    success: bool
    message: str
    file_id: str
    filename: str
    chunks_deleted: int
    size_bytes_freed: int


@dataclass
class BulkUploadFileResult:
    """Result of a single file in a bulk upload operation."""

    filename: str
    success: bool
    error: Optional[str]
    file_id: Optional[str]
    size_bytes: int
    processing_status: str
    message: Optional[str] = None


@dataclass
class BulkUploadResult:
    """Result of a bulk upload operation."""

    success: bool
    total_files: int
    successful_uploads: int
    failed_uploads: int
    total_size_bytes: int
    project_id: str
    user_id: str
    results: List[BulkUploadFileResult]
    message: str


@dataclass
class StreamChunk:
    """A chunk of data from a streaming response."""

    type: str  # 'content', 'context', 'end', 'error'
    data: Union[str, List[ChunkScore], None]

    @property
    def is_content(self) -> bool:
        """Check if this is a content chunk."""
        return self.type == "content"

    @property
    def is_context(self) -> bool:
        """Check if this is a context chunk."""
        return self.type == "context"

    @property
    def is_end(self) -> bool:
        """Check if this is the end of the stream."""
        return self.type == "end"

    @property
    def is_error(self) -> bool:
        """Check if this is an error chunk."""
        return self.type == "error"


class TrainlyError(Exception):
    """Base exception for Trainly SDK errors."""

    def __init__(self, message: str, status_code: Optional[int] = None, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.status_code = status_code
        self.details = details or {}

    def __str__(self) -> str:
        if self.status_code:
            return f"TrainlyError ({self.status_code}): {super().__str__()}"
        return f"TrainlyError: {super().__str__()}"


# Testing Framework Models

@dataclass
class TestAssertion:
    """Test assertion configuration."""

    type: str  # "contains" | "exact" | "regex" | "semantic" | "negative"
    value: str
    match_threshold: Optional[float] = None  # For semantic matching (0-100)


@dataclass
class TestResult:
    """Result of a single test case execution."""

    case_id: str
    case_name: str
    passed: bool
    actual_answer: str
    expected_answer: str
    failure_reason: Optional[str] = None
    execution_time_ms: Optional[float] = None
    assertions_passed: Optional[int] = None
    assertions_failed: Optional[int] = None


@dataclass
class TestCase:
    """Represents a test case."""

    case_id: str
    name: str
    query: str
    expected_answer: str
    category: str  # "golden" | "contradiction" | ... or any custom category
    suite_id: Optional[str] = None
    expected_decision: str = "ANSWER"  # "ANSWER" | "NEEDS_INFO" | "REFUSE"
    assertions: Optional[List[TestAssertion]] = None
    expected_source_file: Optional[str] = None
    last_result: Optional[TestResult] = None
    created_at: Optional[datetime] = None
    # Generalized input/output for non-RAG endpoints
    input: Optional[Any] = None  # Arbitrary JSON input
    expected_output: Optional[Any] = None  # Arbitrary JSON expected output
    custom_assertion: Optional[str] = None  # Expression: "output.status == 'approved'"
    endpoint_type: Optional[str] = None  # Override parent chat's endpoint type


@dataclass
class TestSuite:
    """Represents a test suite containing multiple test cases."""

    suite_id: str
    name: str
    description: Optional[str] = None
    test_count: int = 0
    pass_rate: Optional[float] = None
    last_run_at: Optional[datetime] = None
    last_run_status: Optional[str] = None  # "passed" | "failed" | "partial" | "running"
    tags: Optional[List[str]] = None
    execution_mode: Optional[str] = None  # "internal" | "external"
    target_endpoint: Optional[str] = None  # URL for external mode
    created_at: Optional[datetime] = None


@dataclass
class PaginatedSuites:
    """Paginated list of test suites."""

    suites: List[TestSuite]
    total: int
    page: int
    limit: int
    has_more: bool


@dataclass
class TestRun:
    """Represents a test suite execution run."""

    run_id: str
    suite_id: str
    status: str  # "pending" | "running" | "completed" | "failed" | "cancelled"
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


@dataclass
class TestRunResults:
    """Complete results of a test suite run."""

    run_id: str
    suite_id: str
    status: str  # "running" | "completed" | "failed" | "cancelled"
    passed: int
    failed: int
    total: int
    pass_rate: float
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_ms: Optional[float] = None
    results: List[TestResult] = None


@dataclass
class TestAnalytics:
    """Analytics data for a test suite."""

    suite_id: str
    total_runs: int
    average_pass_rate: float
    average_duration_ms: float
    total_tests: int
    pass_trend: Optional[List[float]] = None  # Last N pass rates


# Fine-Tuning Models

@dataclass
class ValidationResults:
    """Validation results for a preference pair output."""

    preferred_passed: bool
    non_preferred_passed: bool
    validators_failed: Optional[List[str]] = None


@dataclass
class PreferencePair:
    """DPO preference pair for fine-tuning."""

    pair_id: str
    input_messages: List[Dict[str, str]]
    preferred_output: str
    non_preferred_output: str
    status: str  # "draft" | "approved" | "rejected" | "used_in_training"
    source: str  # "manual" | "ai_generated" | "from_test_run" | "from_query_logs"
    validation_results: Optional[ValidationResults] = None
    notes: Optional[str] = None
    created_at: Optional[datetime] = None


@dataclass
class PaginatedPairs:
    """Paginated list of preference pairs."""

    pairs: List[PreferencePair]
    total: int
    page: int
    limit: int
    has_more: bool


@dataclass
class BatchResult:
    """Result of a batch operation."""

    success: bool
    total: int
    successful: int
    failed: int
    errors: Optional[List[str]] = None


@dataclass
class TrainingJob:
    """DPO fine-tuning training job."""

    job_id: str
    openai_job_id: Optional[str] = None
    base_model: str = "gpt-4o-mini"
    fine_tuned_model_id: Optional[str] = None
    status: str = "preparing"  # "preparing" | "uploading" | "queued" | "running" | "succeeded" | "failed" | "cancelled"
    num_pairs: int = 0
    progress: Optional[float] = None  # 0-100
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    suffix: Optional[str] = None
    beta: float = 0.1


# Configuration Models

@dataclass
class ChunkingConfig:
    """Chunking strategy configuration."""

    strategy: str  # "auto" | "fixed_size" | "semantic" | "sentence" | "paragraph" | "code" | "custom"
    chunk_size: Optional[int] = None
    chunk_overlap: Optional[float] = None
    max_chunk_size: Optional[int] = None


@dataclass
class RetrievalConfig:
    """Retrieval configuration."""

    mode: str  # "hybrid" | "vector" | "keyword"
    vector_weight: Optional[float] = None
    keyword_weight: Optional[float] = None
    top_k: int = 10
    similarity_threshold: float = 0.7


@dataclass
class RerankingConfig:
    """Reranking configuration."""

    enabled: bool
    model: str  # "cohere" | "cross_encoder" | "none"
    top_n: Optional[int] = None


@dataclass
class RagConfig:
    """Complete RAG configuration."""

    chunking: ChunkingConfig
    retrieval: RetrievalConfig
    reranking: RerankingConfig


@dataclass
class ValidationPolicy:
    """Response validation policy configuration."""

    forbidden_phrases: Optional[List[str]] = None
    required_phrases: Optional[List[str]] = None
    pii_detection_enabled: bool = False
    banned_packages: Optional[List[str]] = None
    required_packages: Optional[List[str]] = None
    require_error_handling: bool = False
    max_response_length: Optional[int] = None
    require_citations: bool = False


@dataclass
class RepairLoopConfig:
    """Repair loop configuration."""

    enabled: bool
    max_retries: int = 2


@dataclass
class ChatSettings:
    """Chat/knowledge base settings."""

    project_id: str
    model: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    custom_prompt: Optional[str] = None
    repair_loop: Optional[RepairLoopConfig] = None
    rag_config: Optional[RagConfig] = None
    validation_policy: Optional[ValidationPolicy] = None


# Analytics Models

@dataclass
class TokenUsage:
    """Token usage for a query."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class TimingBreakdown:
    """Detailed timing breakdown for a query."""

    total_time: float
    preprocessing_time: Optional[float] = None
    embedding_time: Optional[float] = None  # RAG only
    retrieval_time: Optional[float] = None  # RAG only
    reranking_time: Optional[float] = None  # RAG only
    context_assembly_time: Optional[float] = None
    prompt_construction_time: Optional[float] = None
    llm_time: Optional[float] = None
    postprocessing_time: Optional[float] = None


@dataclass
class ChunkInfo:
    """Information about a retrieved chunk."""

    chunk_id: str
    score: float
    source_file: str
    chunk_text: str
    rank_before_rerank: Optional[int] = None
    rank_after_rerank: Optional[int] = None


@dataclass
class QueryTrace:
    """Basic query trace information."""

    trace_id: str
    query: str
    response: str
    status: str  # "success" | "error"
    total_time_ms: float
    tokens: TokenUsage
    cost: float
    timestamp: datetime


@dataclass
class QueryTraceDetails:
    """Detailed query trace information."""

    trace_id: str
    query: str
    response: str
    status: str
    total_time_ms: float
    tokens: TokenUsage
    cost: float
    timestamp: datetime
    timing: TimingBreakdown
    chunks: List[ChunkInfo]
    full_prompt: Optional[str] = None


@dataclass
class MetricsSummary:
    """Summary metrics for queries."""

    total_queries: int
    successful_queries: int
    failed_queries: int
    average_response_time_ms: float
    total_cost: float
    average_cost_per_query: float
    date_range_start: datetime
    date_range_end: datetime


@dataclass
class CostBreakdown:
    """Cost breakdown by component."""

    total_cost: float
    embedding_cost: float
    llm_cost: float
    reranking_cost: float
    date_range_start: datetime
    date_range_end: datetime


@dataclass
class PerformanceStats:
    """Performance statistics."""

    p50_response_time_ms: float
    p95_response_time_ms: float
    p99_response_time_ms: float
    average_chunks_retrieved: float
    average_tokens_per_query: float


# Version Management Models

@dataclass
class FileSnapshot:
    """Snapshot of a file in a published version."""

    file_id: str
    filename: str
    size_bytes: int
    chunk_count: int


@dataclass
class PublishedVersion:
    """Published version of settings and data."""

    version_id: str
    version: str
    status: str  # "active" | "superseded" | "corrupted"
    description: Optional[str] = None
    settings_snapshot: Optional[Dict[str, Any]] = None
    custom_config_snapshot: Optional[Dict[str, Any]] = None  # Arbitrary config (RL environments, agent configs, etc.)
    file_snapshots: Optional[List[FileSnapshot]] = None
    total_files: int = 0
    published_at: Optional[datetime] = None
    published_by: Optional[str] = None


@dataclass
class VersionDiff:
    """Difference between two versions."""

    version_a: str
    version_b: str
    settings_changed: List[str]
    custom_config_changed: Optional[Dict[str, Any]] = None  # Keys that differ in custom config
    files_added: Optional[List[str]] = None
    files_removed: Optional[List[str]] = None
    files_modified: Optional[List[str]] = None


# =============================================================================
# General-Purpose Invoke & Agent/Tool-Use Models
# =============================================================================

@dataclass
class ToolDefinition:
    """Definition of a tool that the AI model can call."""

    name: str
    description: str
    parameters: Optional[Dict[str, Any]] = None  # JSON Schema


@dataclass
class ToolCall:
    """Record of a tool call made by the AI model."""

    tool_name: str
    tool_input: Any
    tool_output: Optional[Any] = None
    duration_ms: Optional[float] = None
    status: Optional[str] = None  # "success" | "error" | "pending"
    error: Optional[str] = None


@dataclass
class ValidationOutcome:
    """Result of a single validation check."""

    validator: str
    result: str  # "pass" | "fail" | "warn"
    message: str
    details: Optional[Dict[str, Any]] = None


@dataclass
class InvokeValidation:
    """Validation results from invoke endpoint."""

    passed: bool
    pass_count: int = 0
    fail_count: int = 0
    warn_count: int = 0
    failure_reasons: Optional[List[str]] = None
    outcomes: Optional[List[ValidationOutcome]] = None


@dataclass
class InvokeResult:
    """Result from the general-purpose invoke endpoint."""

    output: Any  # Arbitrary JSON output
    tool_calls: Optional[List[ToolCall]] = None
    latency_ms: Optional[float] = None
    trace_id: Optional[str] = None
    model: Optional[str] = None
    validation: Optional[InvokeValidation] = None

    def __str__(self) -> str:
        output_preview = str(self.output)[:100]
        return f"InvokeResult(output='{output_preview}...', latency={self.latency_ms}ms)"

