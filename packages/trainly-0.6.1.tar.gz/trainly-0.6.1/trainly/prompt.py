from dataclasses import dataclass
from typing import Optional, List


@dataclass
class Prompt:
    """A versioned prompt template fetched from Trainly."""
    slug: str
    name: str
    content: str
    variables: List[str]
    version: int
    model: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None

    def build(self, **kwargs: str) -> str:
        """Render the template by substituting {{variable}} placeholders.

        Raises ValueError if required variables are missing.
        """
        missing = [v for v in self.variables if v not in kwargs]
        if missing:
            raise ValueError(f"Missing required variables: {', '.join(missing)}")

        result = self.content
        for key, value in kwargs.items():
            result = result.replace(f"{{{{{key}}}}}", str(value))
        return result
