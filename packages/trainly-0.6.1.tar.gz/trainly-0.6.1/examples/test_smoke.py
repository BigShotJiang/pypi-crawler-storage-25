"""
Quick Smoke Test (Section: Quick Smoke Test — 5-minute check)

Runs through the critical SDK paths in one script:
1. Send trace via @observe decorator → trace appears in explorer
2. Manual log with full metadata
3. Session tracking (2 traces in same session)
4. Error trace

Usage:
    export TRAINLY_API_KEY=tk_...
    export TRAINLY_PROJECT_ID=proj_...
    export OPENAI_API_KEY=sk_...
    python test_smoke.py
"""
import os
import uuid
import openai
from trainly import TrainlyClient

client = TrainlyClient(
    api_key=os.environ["TRAINLY_API_KEY"],
    project_id=os.environ["TRAINLY_PROJECT_ID"],
)

SESSION = f"smoke_{uuid.uuid4().hex[:8]}"


@client.observe(model="gpt-4o-mini", tags=["smoke-test"], session_id=SESSION)
def ask(query: str) -> str:
    response = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": query}],
    )
    return response.choices[0].message.content


@client.observe(model="gpt-4o-mini", tags=["smoke-test", "error"])
def ask_broken(query: str) -> str:
    raise RuntimeError("Intentional smoke test failure")


def main():
    print(f"Smoke test session: {SESSION}\n")

    # 1. @observe decorator
    print("1. @observe decorator call...")
    answer = ask("What is 2+2?")
    print(f"   OK — {answer[:60]}\n")

    # 2. Manual log
    print("2. Manual log...")
    client.observe.log(
        input="Smoke test manual log",
        output="This was logged manually.",
        model="gpt-4o-mini",
        tags=["smoke-test", "manual"],
        session_id=SESSION,
        token_usage={"prompt_tokens": 5, "completion_tokens": 8, "total_tokens": 13},
    )
    print("   OK\n")

    # 3. Second call in same session
    print("3. Session continuity...")
    answer2 = ask("Follow up: what is 3+3?")
    print(f"   OK — {answer2[:60]}\n")

    # 4. Error trace
    print("4. Error trace...")
    try:
        ask_broken("This should fail")
    except RuntimeError:
        print("   OK — error captured\n")

    print("=" * 50)
    print("Smoke test complete!")
    print(f"Check Trace Explorer for 4 traces.")
    print(f"Filter by session '{SESSION}' to see 3 grouped traces.")


if __name__ == "__main__":
    main()
