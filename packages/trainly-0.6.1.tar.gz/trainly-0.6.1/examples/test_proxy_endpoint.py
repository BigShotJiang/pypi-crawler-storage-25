"""
Feature Parity Test: Section 9 — Proxy (OpenAI-Compatible)

Verifies:
- 9.1 Basic proxy returns valid OpenAI-format response + trace logged
- 9.2 Streaming proxy returns SSE stream + trace logged
- 9.3 Multi-provider routing (OpenAI vs Anthropic)
- 9.4 Authentication (valid/invalid/missing keys)

Usage:
    export TRAINLY_API_KEY=tk_...
    export TRAINLY_PROJECT_KEY=<your project key>
    export PROXY_BASE_URL=https://your-domain.com  (or http://localhost:8000)
    python test_proxy_endpoint.py
"""
import os
import json
import requests

API_KEY = os.environ["TRAINLY_API_KEY"]
PROJECT_KEY = os.environ.get("TRAINLY_PROJECT_KEY", "your_project_key")
BASE_URL = os.environ.get("PROXY_BASE_URL", "http://localhost:8000")
PROXY_URL = f"{BASE_URL}/v1/proxy/{PROJECT_KEY}/chat/completions"


def test_basic_proxy():
    """9.1 — Non-streaming proxy request."""
    print("=== 9.1 Basic Proxy ===")
    resp = requests.post(
        PROXY_URL,
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
        },
        json={
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "Say hello in one word."}],
        },
    )
    print(f"Status: {resp.status_code}")
    if resp.ok:
        data = resp.json()
        print(f"Model: {data.get('model')}")
        print(f"Content: {data['choices'][0]['message']['content']}")
        print(f"Usage: {data.get('usage')}")
    else:
        print(f"Error: {resp.text}")
    print()


def test_streaming_proxy():
    """9.2 — Streaming proxy request (SSE)."""
    print("=== 9.2 Streaming Proxy ===")
    resp = requests.post(
        PROXY_URL,
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
        },
        json={
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "Count from 1 to 5."}],
            "stream": True,
        },
        stream=True,
    )
    print(f"Status: {resp.status_code}")
    print(f"Content-Type: {resp.headers.get('content-type')}")

    full_content = ""
    for line in resp.iter_lines(decode_unicode=True):
        if line.startswith("data: "):
            payload = line[6:]
            if payload == "[DONE]":
                print("\n[DONE] received")
                break
            chunk = json.loads(payload)
            delta = chunk["choices"][0].get("delta", {})
            content = delta.get("content", "")
            full_content += content
            print(content, end="", flush=True)

    print(f"\nFull streamed response: {full_content}\n")


def test_multi_provider():
    """9.3 — Route to different providers by model name."""
    print("=== 9.3 Multi-Provider Routing ===")

    for model in ["gpt-4o", "claude-3-5-sonnet-20241022"]:
        print(f"Testing model: {model}")
        resp = requests.post(
            PROXY_URL,
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": "Say hi."}],
            },
        )
        print(f"  Status: {resp.status_code}")
        if resp.ok:
            print(f"  Response: {resp.json()['choices'][0]['message']['content'][:80]}")
        else:
            print(f"  Error: {resp.text[:200]}")
    print()


def test_auth():
    """9.4 — Proxy authentication checks."""
    print("=== 9.4 Authentication ===")
    payload = {
        "model": "gpt-4o",
        "messages": [{"role": "user", "content": "test"}],
    }

    # Valid key
    resp = requests.post(
        PROXY_URL,
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
        json=payload,
    )
    print(f"Valid key:   {resp.status_code} (expect 200)")

    # Invalid key
    resp = requests.post(
        PROXY_URL,
        headers={"Authorization": "Bearer tk_invalid_key", "Content-Type": "application/json"},
        json=payload,
    )
    print(f"Invalid key: {resp.status_code} (expect 401)")

    # Missing header
    resp = requests.post(
        PROXY_URL,
        headers={"Content-Type": "application/json"},
        json=payload,
    )
    print(f"No auth:     {resp.status_code} (expect 401)")
    print()


if __name__ == "__main__":
    test_basic_proxy()
    test_streaming_proxy()
    test_multi_provider()
    test_auth()
    print("Done! Check Trace Explorer for auto-logged proxy traces.")
