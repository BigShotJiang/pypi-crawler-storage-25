"""
Feature Parity Test: Manual Logging + Scoring

Covers miscellaneous trace ingestion scenarios:
- Manual trace logging with full metadata
- Logging traces with different statuses (success, error, warning)
- Adding scores to traces (for scorer integration testing, Section 5)
- Prompt registry fetching (Section 4.2)
"""
import os
import time
from trainly import TrainlyClient

client = TrainlyClient(
    api_key=os.environ["TRAINLY_API_KEY"],
    project_id=os.environ["TRAINLY_PROJECT_ID"],
)


def test_manual_log_success():
    """Log a successful trace with full metadata."""
    print("=== Manual log: success ===")
    client.observe.log(
        input="What is the meaning of life?",
        output="The meaning of life is a philosophical question with many perspectives.",
        model="gpt-4o",
        latency_ms=320,
        tags=["test", "manual-log"],
        token_usage={
            "prompt_tokens": 12,
            "completion_tokens": 18,
            "total_tokens": 30,
        },
        metadata={"source": "manual_test", "environment": "testing"},
        status="success",
        version="1.0.0",
        custom_attributes={"category": "philosophy", "difficulty": "hard"},
    )
    print("Success trace logged.\n")


def test_manual_log_error():
    """Log an error trace."""
    print("=== Manual log: error ===")
    client.observe.log(
        input="Translate this to French: Hello world",
        output="",
        model="gpt-4o",
        latency_ms=5200,
        tags=["test", "manual-log", "error"],
        status="error",
        error="TimeoutError: Request timed out after 5000ms",
        metadata={"retry_count": 3},
    )
    print("Error trace logged.\n")


def test_manual_log_with_tool_calls():
    """Log a trace from an agent with tool calls."""
    print("=== Manual log: agent with tool calls ===")
    client.observe.log(
        input="What's the weather in San Francisco?",
        output="The current weather in San Francisco is 65°F and partly cloudy.",
        model="gpt-4o",
        tags=["test", "agent", "tool-calls"],
        token_usage={"prompt_tokens": 45, "completion_tokens": 30, "total_tokens": 75},
        tool_calls=[
            {
                "name": "get_weather",
                "arguments": {"city": "San Francisco", "units": "fahrenheit"},
                "result": '{"temp": 65, "condition": "partly cloudy"}',
            }
        ],
        metadata={"agent_type": "weather_assistant"},
    )
    print("Agent trace with tool calls logged.\n")


def test_score_trace():
    """Score a trace (for scorer integration, Section 5)."""
    print("=== Score a trace ===")
    # First, log a trace we can score
    client.observe.log(
        input="Explain quantum computing simply.",
        output="Quantum computing uses qubits that can be 0 and 1 at the same time.",
        model="gpt-4o",
        tags=["test", "scoring"],
        metadata={"score_test": True},
    )
    print("Trace logged for scoring. Use the UI to run a scorer on it.\n")


def test_prompt_registry():
    """Fetch a prompt from the registry (Section 4.2)."""
    print("=== Prompt Registry ===")
    try:
        prompt = client.get_prompt("my-prompt-slug")
        print(f"Prompt content: {prompt}")
    except Exception as e:
        print(f"Expected if no prompt exists yet: {e}")

    try:
        prompt_v2 = client.get_prompt("my-prompt-slug", version=2)
        print(f"Prompt v2: {prompt_v2}")
    except Exception as e:
        print(f"Expected if no v2 exists: {e}")
    print()


if __name__ == "__main__":
    test_manual_log_success()
    test_manual_log_error()
    test_manual_log_with_tool_calls()
    test_score_trace()
    test_prompt_registry()
    print("All manual logging tests done! Check Trace Explorer.")
