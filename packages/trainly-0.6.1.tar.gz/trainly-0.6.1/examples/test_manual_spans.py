"""
Feature Parity Test: Section 8.2 — Manual Spans

Verifies:
- Span appears as child of parent trace
- Span has correct name and duration
- Custom attributes visible in trace detail
- Nested spans (span within span) create correct hierarchy
"""
import os
import time
import openai
from trainly import TrainlyClient

client = TrainlyClient(
    api_key=os.environ["TRAINLY_API_KEY"],
    project_id=os.environ["TRAINLY_PROJECT_ID"],
)


# --- 8.2.1 Single span with custom attributes ---
@client.observe(model="gpt-4o", tags=["test", "spans"])
def search_and_answer(query: str) -> str:
    # Retrieval span
    with client.observe.span("document-retrieval") as span:
        span.set_attribute("search_engine", "vector_db")
        span.set_attribute("top_k", 5)
        time.sleep(0.2)  # simulate retrieval latency
        docs = ["Doc about AI observability", "Doc about tracing systems"]
        span.set_output(f"Retrieved {len(docs)} documents")

    # LLM call span
    with client.observe.span("llm-generation") as span:
        span.set_model("gpt-4o")
        context = "\n".join(docs)
        prompt = f"Context: {context}\n\nQuestion: {query}"
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
        )
        answer = response.choices[0].message.content
        span.set_output(answer)
        span.set_attribute("context_length", len(context))

    return answer


# --- 8.2.2 Nested spans (span within span) ---
@client.observe(model="gpt-4o-mini", tags=["test", "nested-spans"])
def pipeline_with_nested_spans(query: str) -> str:
    with client.observe.span("preprocessing") as outer:
        outer.set_attribute("step", "preprocess")

        with client.observe.span("tokenization") as inner:
            inner.set_attribute("tokenizer", "tiktoken")
            time.sleep(0.05)
            tokens = query.split()
            inner.set_output(f"Tokenized into {len(tokens)} tokens")

        with client.observe.span("embedding") as inner:
            inner.set_attribute("model", "text-embedding-3-small")
            time.sleep(0.1)
            inner.set_output("Generated embedding vector [768 dims]")

        outer.set_output("Preprocessing complete")

    with client.observe.span("generation") as gen:
        response = openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": query}],
        )
        answer = response.choices[0].message.content
        gen.set_output(answer)

    return answer


if __name__ == "__main__":
    print("=== 8.2.1 Single-level spans ===")
    result = search_and_answer("What is AI observability?")
    print(f"Response: {result}\n")

    print("=== 8.2.2 Nested spans ===")
    result = pipeline_with_nested_spans("How does tracing work?")
    print(f"Response: {result}\n")

    print("Done! Check Trace Explorer for span waterfall visualization.")
