"""
Generate traces with subtle anomalies to test detection quality.

Anomaly types:
1. Gradual quality degradation — responses get progressively shorter/lazier over time
2. Quiet hallucination — confident but wrong answers on factual questions
3. Latency creep — certain query types slowly get slower
4. Cost anomaly — one model is 10x more expensive for equivalent tasks
5. Session-level: agent gets stuck in a loop on certain inputs
"""
import os
import sys
import json
import time
import random
import requests

API_KEY = os.environ.get("TRAINLY_API_KEY", "tk_mmscjuwk_qdl47emibq9")
PROJECT_ID = os.environ.get("TRAINLY_PROJECT_ID", "chat_mm9yt1da_3l8pob3y")
BACKEND_URL = os.environ.get("BACKEND_URL", "http://localhost:8000")

def log_trace(trace: dict):
    resp = requests.post(
        f"{BACKEND_URL}/v1/{PROJECT_ID}/traces",
        json=trace,
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
    )
    if resp.status_code != 200:
        print(f"  ERROR: {resp.status_code} {resp.text[:200]}")
    return resp

def log_batch(traces: list):
    resp = requests.post(
        f"{BACKEND_URL}/v1/{PROJECT_ID}/traces/batch",
        json={"traces": traces},
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
    )
    if resp.status_code != 200:
        print(f"  BATCH ERROR: {resp.status_code} {resp.text[:200]}")
    return resp


# --- Anomaly 1: Gradual quality degradation ---
# Early responses are detailed, later ones get lazy ("I don't know", short answers)
def generate_quality_degradation():
    print("Generating quality degradation traces...")
    good_responses = [
        "Machine learning is a subset of artificial intelligence that enables systems to learn and improve from experience without being explicitly programmed. It works by training algorithms on large datasets to identify patterns, make predictions, and adapt over time. Common approaches include supervised learning, unsupervised learning, and reinforcement learning.",
        "Neural networks are computing systems inspired by biological neural networks in the brain. They consist of interconnected nodes (neurons) organized in layers — an input layer, one or more hidden layers, and an output layer. Each connection has a weight that adjusts during training, allowing the network to learn complex patterns.",
        "Transfer learning is a technique where a model trained on one task is repurposed for a different but related task. For example, a model trained on ImageNet can be fine-tuned for medical image classification. This dramatically reduces training time and data requirements, making it practical to build powerful models with limited labeled data.",
    ]
    degraded_responses = [
        "It's basically AI stuff.",
        "I think so.",
        "Yes.",
        "Not sure, maybe look it up?",
        "That's a good question.",
        "Hmm.",
    ]
    questions = [
        "Explain machine learning in detail",
        "How do neural networks work?",
        "What is transfer learning and why is it useful?",
        "Describe gradient descent optimization",
        "What are transformers in NLP?",
        "Explain backpropagation step by step",
        "What is the difference between CNN and RNN?",
        "How does attention mechanism work?",
    ]

    traces = []
    for i in range(40):
        q = random.choice(questions)
        if i < 15:
            resp = random.choice(good_responses)
            latency = random.randint(800, 1500)
        else:
            resp = random.choice(degraded_responses)
            latency = random.randint(100, 300)
        traces.append({
            "input": q,
            "output": resp,
            "model": "gpt-4o",
            "latency_ms": latency,
            "token_usage": {"prompt_tokens": len(q.split()) * 2, "completion_tokens": len(resp.split()) * 2, "total_tokens": (len(q.split()) + len(resp.split())) * 2},
            "tags": ["ml-tutor", "quality-test"],
            "status": "success",
        })

    log_batch(traces)
    print(f"  Logged {len(traces)} traces (15 good → 25 degraded)")


# --- Anomaly 2: Quiet hallucination ---
# Confident but factually wrong answers mixed in with correct ones
def generate_hallucinations():
    print("Generating hallucination traces...")
    factual_pairs = [
        ("What year was the Eiffel Tower built?", "The Eiffel Tower was completed in 1889 for the World's Fair in Paris."),
        ("Who wrote Romeo and Juliet?", "Romeo and Juliet was written by William Shakespeare around 1594-1596."),
        ("What is the speed of light?", "The speed of light in a vacuum is approximately 299,792,458 meters per second."),
        ("What is the capital of Australia?", "The capital of Australia is Canberra, which became the capital in 1927."),
        ("Who painted the Mona Lisa?", "The Mona Lisa was painted by Leonardo da Vinci, completed around 1517."),
    ]
    hallucinated_pairs = [
        ("What year did the first moon landing happen?", "The first moon landing occurred in 1972 when Neil Armstrong and Buzz Aldrin landed on the lunar surface during the Apollo 15 mission."),
        ("Who invented the telephone?", "The telephone was invented by Thomas Edison in 1882 at his laboratory in Menlo Park, New Jersey."),
        ("What is the largest organ in the human body?", "The largest organ in the human body is the liver, which weighs approximately 8 pounds in an adult."),
        ("How many planets are in our solar system?", "There are 11 planets in our solar system, including the recently discovered Planet X beyond Neptune's orbit."),
        ("What temperature does water boil at?", "Water boils at 110 degrees Celsius at standard atmospheric pressure, though this can vary with altitude."),
        ("Who was the first president of the United States?", "The first president of the United States was Benjamin Franklin, who served from 1789 to 1797."),
        ("What is the chemical symbol for gold?", "The chemical symbol for gold is Gd, derived from its Latin name 'Goldium'."),
    ]

    traces = []
    for _ in range(20):
        q, a = random.choice(factual_pairs)
        traces.append({
            "input": q, "output": a, "model": "gpt-4o-mini",
            "latency_ms": random.randint(400, 800),
            "tags": ["factual-qa", "knowledge-base"],
            "status": "success",
        })
    for _ in range(15):
        q, a = random.choice(hallucinated_pairs)
        traces.append({
            "input": q, "output": a, "model": "gpt-4o-mini",
            "latency_ms": random.randint(400, 800),
            "tags": ["factual-qa", "knowledge-base"],
            "status": "success",
        })

    random.shuffle(traces)
    log_batch(traces)
    print(f"  Logged {len(traces)} traces (20 correct + 15 hallucinated)")


# --- Anomaly 3: Latency creep on specific query type ---
def generate_latency_creep():
    print("Generating latency creep traces...")
    traces = []

    fast_queries = [
        ("Summarize this text: The cat sat on the mat.", "A cat is sitting on a mat."),
        ("Translate to French: Hello world", "Bonjour le monde"),
        ("What is 2+2?", "4"),
    ]
    slow_queries = [
        ("Analyze this legal contract clause and identify potential risks: The party of the first part hereby agrees...", "This clause contains several risk factors including unlimited liability exposure, ambiguous termination conditions, and a non-standard indemnification structure that could expose the signing party to significant financial risk."),
        ("Review this code for security vulnerabilities: function authenticate(user, pass) { return db.query('SELECT * FROM users WHERE name=' + user) }", "Critical SQL injection vulnerability detected. The code concatenates user input directly into the SQL query without parameterization. An attacker could input malicious SQL to bypass authentication or extract database contents."),
        ("Generate a comprehensive market analysis for the electric vehicle industry in Southeast Asia", "The Southeast Asian EV market is projected to grow at 35% CAGR through 2030, driven by government subsidies in Thailand and Indonesia, rising middle-class purchasing power, and infrastructure investments from Chinese manufacturers."),
    ]

    for i in range(30):
        if random.random() < 0.6:
            q, a = random.choice(fast_queries)
            latency = random.randint(200, 500)
        else:
            q, a = random.choice(slow_queries)
            latency = random.randint(3000, 8000) + (i * 100)  # gets slower over time
        traces.append({
            "input": q, "output": a, "model": "gpt-4o",
            "latency_ms": latency,
            "tags": ["analysis", "production"],
            "status": "success",
        })

    log_batch(traces)
    print(f"  Logged {len(traces)} traces (fast simple queries + slow creeping analysis queries)")


# --- Anomaly 4: Cost anomaly ---
def generate_cost_anomaly():
    print("Generating cost anomaly traces...")
    traces = []

    for _ in range(25):
        traces.append({
            "input": "Classify this support ticket: My order hasn't arrived",
            "output": "Category: Shipping/Delivery, Priority: Medium, Sentiment: Negative",
            "model": "gpt-4o-mini",
            "latency_ms": random.randint(300, 600),
            "token_usage": {"prompt_tokens": 40, "completion_tokens": 20, "total_tokens": 60},
            "cost": 0.00003,
            "tags": ["ticket-classifier", "support"],
            "status": "success",
        })

    for _ in range(10):
        traces.append({
            "input": "Classify this support ticket: I want a refund",
            "output": "Category: Billing/Refund, Priority: High, Sentiment: Negative",
            "model": "gpt-4o",
            "latency_ms": random.randint(1500, 3000),
            "token_usage": {"prompt_tokens": 800, "completion_tokens": 400, "total_tokens": 1200},
            "cost": 0.015,
            "tags": ["ticket-classifier", "support"],
            "status": "success",
        })

    random.shuffle(traces)
    log_batch(traces)
    print(f"  Logged {len(traces)} traces (25 cheap mini + 10 expensive 4o doing the same task)")


# --- Anomaly 5: Agent loop (session-level) ---
def generate_agent_loops():
    print("Generating agent session traces with loops...")

    for session_num in range(8):
        session_id = f"agent_loop_test_{session_num}_{int(time.time())}"
        is_looping = session_num >= 4

        traces = []
        if is_looping:
            traces.append({
                "input": "Find the quarterly revenue for Acme Corp",
                "output": "Let me search for that information.",
                "model": "gpt-4o", "latency_ms": 500, "session_id": session_id,
                "tags": ["agent", "research"], "status": "success",
                "spans": [
                    {"name": "plan", "startTime": time.time()*1000, "endTime": time.time()*1000+200, "status": "success", "spanKind": "chain", "input": "Find quarterly revenue for Acme Corp", "output": "I'll search the database"},
                    {"name": "search_db", "startTime": time.time()*1000+200, "endTime": time.time()*1000+800, "status": "error", "spanKind": "tool", "input": "SELECT revenue FROM financials WHERE company='Acme'", "output": "", "attributes": {"error": "Table 'financials' not found"}},
                ],
            })
            for retry in range(4):
                traces.append({
                    "input": f"Retry search attempt {retry+1}",
                    "output": "Let me try a different approach.",
                    "model": "gpt-4o", "latency_ms": 500 + retry * 200, "session_id": session_id,
                    "tags": ["agent", "research"], "status": "error" if retry < 3 else "success",
                    "error": "Search failed, retrying" if retry < 3 else None,
                    "spans": [
                        {"name": "search_db", "startTime": time.time()*1000, "endTime": time.time()*1000+500, "status": "error", "spanKind": "tool", "input": f"Retry query attempt {retry+1}", "output": "", "attributes": {"error": "Table 'financials' not found"}},
                        {"name": "search_db", "startTime": time.time()*1000+500, "endTime": time.time()*1000+900, "status": "error", "spanKind": "tool", "input": f"Alternative query {retry+1}", "output": "", "attributes": {"error": "Connection timeout"}},
                    ],
                })
        else:
            traces.append({
                "input": "What is the weather in San Francisco?",
                "output": "The current weather in San Francisco is 62°F with partly cloudy skies.",
                "model": "gpt-4o", "latency_ms": 800, "session_id": session_id,
                "tags": ["agent", "weather"], "status": "success",
                "spans": [
                    {"name": "plan", "startTime": time.time()*1000, "endTime": time.time()*1000+150, "status": "success", "spanKind": "chain"},
                    {"name": "weather_api", "startTime": time.time()*1000+150, "endTime": time.time()*1000+600, "status": "success", "spanKind": "tool"},
                    {"name": "format_response", "startTime": time.time()*1000+600, "endTime": time.time()*1000+800, "status": "success", "spanKind": "chain"},
                ],
            })

        for t in traces:
            log_trace(t)
            time.sleep(0.1)

    print(f"  Logged 8 agent sessions (4 normal + 4 with retry loops)")


if __name__ == "__main__":
    print(f"Backend: {BACKEND_URL}")
    print(f"Project: {PROJECT_ID}\n")

    generate_quality_degradation()
    generate_hallucinations()
    generate_latency_creep()
    generate_cost_anomaly()
    generate_agent_loops()

    print(f"\nDone! Logged ~170 traces with 5 types of subtle anomalies.")
    print("Run detection to see what gets caught.")
