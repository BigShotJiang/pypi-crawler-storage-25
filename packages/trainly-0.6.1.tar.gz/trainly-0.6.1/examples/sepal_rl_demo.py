"""
Trainly SDK Demo — RL Environment Versioning & Observability

This script demonstrates how an RL team (like Sepal AI) can use Trainly to:
  1. Store and version arbitrary environment configs
  2. Trace agent runs with custom attributes (reward, steps, success)
  3. Compare performance across config versions
  4. Run regression tests when environment params change

Usage:
    export TRAINLY_API_KEY="tk_..."
    export TRAINLY_CHAT_ID="chat_..."
    python examples/sepal_rl_demo.py
"""

import json
import time
import random
from trainly import TrainlyClient

# ─────────────────────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────────────────────

client = TrainlyClient(
    api_key="tk_mlo8pm2i_8hf3n1hv08a",
    project_id="j578sm608bp70fpsjjfva0r2jh8154yk",
    base_url="https://api.trainlyai.com",
)

print("=" * 60)
print("  Trainly SDK — RL Environment Versioning Demo")
print("=" * 60)


# ─────────────────────────────────────────────────────────────
# Step 1: Define an RL Environment Config
# ─────────────────────────────────────────────────────────────

print("\n📦 Step 1: Store environment config\n")

env_config_v1 = {
    "environment": "maze_navigation",
    "state_space": {"type": "grid", "size": 10, "observable_radius": 3},
    "action_space": ["up", "down", "left", "right"],
    "reward_function": "sparse",           # +1 at goal, 0 elsewhere
    "discount_factor": 0.99,
    "max_steps": 500,
    "termination": {"on_goal": True, "on_timeout": True},
    "difficulty": 0.5,
    "wall_density": 0.3,
    "expert_data": {
        "source": "human_annotators",
        "num_demonstrations": 50,
        "quality_threshold": 0.8,
    },
}

client.config.set_custom_config(env_config_v1)
print(f"  Stored config: {env_config_v1['environment']}")
print(f"  Reward function: {env_config_v1['reward_function']}")
print(f"  Difficulty: {env_config_v1['difficulty']}")


# ─────────────────────────────────────────────────────────────
# Step 2: Publish with auto-versioning (publish_major)
# ─────────────────────────────────────────────────────────────

print("\n🏷️  Step 2: Publish new major version\n")

v1 = client.versions.publish_major(
    description="Baseline: sparse reward, 10x10 grid, 0.5 difficulty",
    custom_config=env_config_v1,
)
print(f"  Published version: {v1.version}")
print(f"  Version ID: {v1.version_id}")


# ─────────────────────────────────────────────────────────────
# Step 3: Run agent episodes and trace with @observe
# ─────────────────────────────────────────────────────────────

print(f"\n🔍 Step 3: Trace agent runs against {v1.version}\n")


def simulate_episode(difficulty: float) -> dict:
    """Simulate an RL episode (replace with real agent in production)."""
    success = random.random() > difficulty
    steps = random.randint(20, 500)
    reward = 1.0 if success else round(random.uniform(-0.5, 0.3), 3)
    exploration_rate = round(random.uniform(0.05, 0.4), 3)
    avg_q_value = round(random.uniform(0.2, 0.95), 3)
    entropy = round(random.uniform(0.1, 2.0), 3)
    wall_collisions = random.randint(0, 30)
    goal_distance_final = 0 if success else round(random.uniform(0.1, 5.0), 2)
    return {
        "reward": reward,
        "steps": steps,
        "success": success,
        "exploration_rate": exploration_rate,
        "avg_q_value": avg_q_value,
        "entropy": entropy,
        "wall_collisions": wall_collisions,
        "goal_distance_final": goal_distance_final,
    }


# Use the observe decorator to automatically trace each episode.
# The decorator auto-serializes dict input/output to JSON — no manual
# json.dumps/json.loads needed. Functions work naturally with dicts.
@client.observe(
    model="ppo-v2",
    tags=["rl", "maze", "baseline"],
    version=v1.version,
)
def run_episode(task_params: dict) -> dict:
    """Run a single RL episode. Takes and returns dicts natively."""
    return simulate_episode(task_params["difficulty"])


# Run 5 traced episodes
v1_results = []
for i in range(5):
    result = run_episode({
        "environment": "maze_navigation",
        "episode": i + 1,
        "difficulty": 0.5,
        "grid_size": 10,
        "observable_radius": 3,
        "reward_function": "sparse",
        "max_steps": 500,
        "wall_density": 0.3,
        "agent": "ppo-v2",
    })
    v1_results.append(result)
    status = "✅" if result["success"] else "❌"
    print(f"  Episode {i+1}: {status}  reward={result['reward']:.3f}  steps={result['steps']}  q={result['avg_q_value']:.3f}")

v1_success_rate = sum(1 for r in v1_results if r["success"]) / len(v1_results)
print(f"\n  {v1.version} success rate: {v1_success_rate:.0%}")


# ─────────────────────────────────────────────────────────────
# Step 4: Manually log traces with richer attributes
# ─────────────────────────────────────────────────────────────

print("\n📊 Step 4: Log traces with custom attributes\n")

# You can also log traces manually for more control
client.observe.log(
    input="maze_eval_batch_001",
    output=json.dumps({
        "mean_reward": sum(r["reward"] for r in v1_results) / len(v1_results),
        "success_rate": v1_success_rate,
        "mean_steps": sum(r["steps"] for r in v1_results) / len(v1_results),
        "mean_q_value": sum(r["avg_q_value"] for r in v1_results) / len(v1_results),
        "mean_entropy": sum(r["entropy"] for r in v1_results) / len(v1_results),
        "mean_wall_collisions": sum(r["wall_collisions"] for r in v1_results) / len(v1_results),
    }),
    model="ppo-v2",
    version=v1.version,
    tags=["rl", "maze", "eval"],
    custom_attributes={
        "mean_reward": sum(r["reward"] for r in v1_results) / len(v1_results),
        "success_rate": v1_success_rate,
        "num_episodes": len(v1_results),
        "environment": "maze_navigation",
        "mean_q_value": sum(r["avg_q_value"] for r in v1_results) / len(v1_results),
        "mean_entropy": sum(r["entropy"] for r in v1_results) / len(v1_results),
    },
)
print("  Logged evaluation trace with custom attributes")


# ─────────────────────────────────────────────────────────────
# Step 5: Tweak the config and publish minor version bump
# ─────────────────────────────────────────────────────────────

print("\n🔧 Step 5: Update config → dense reward + higher difficulty\n")

env_config_v2 = {
    **env_config_v1,
    "reward_function": "dense",            # distance-based shaping
    "difficulty": 0.7,
    "wall_density": 0.4,
    "max_steps": 300,                      # tighter timeout
    "reward_shaping": {
        "goal_reward": 10.0,
        "step_penalty": -0.01,
        "wall_penalty": -0.5,
        "proximity_bonus": True,
    },
}

client.config.set_custom_config(env_config_v2)

# publish_minor auto-bumps: e.g. 2.0.0 → 2.1.0
v2 = client.versions.publish_minor(
    description="Dense reward shaping, difficulty 0.7, tighter timeout",
    custom_config=env_config_v2,
)
print(f"  Published version: {v2.version}")
print(f"  Changes: reward={env_config_v2['reward_function']}, "
      f"difficulty={env_config_v2['difficulty']}, "
      f"max_steps={env_config_v2['max_steps']}")


# ─────────────────────────────────────────────────────────────
# Step 6: Run agent on new config and trace
# ─────────────────────────────────────────────────────────────

print(f"\n🔍 Step 6: Trace agent runs against {v2.version}\n")


@client.observe(
    model="ppo-v2",
    tags=["rl", "maze", "dense-reward"],
    version=v2.version,
)
def run_episode_v2(task_params: dict) -> dict:
    return simulate_episode(task_params["difficulty"])


v2_results = []
for i in range(5):
    result = run_episode_v2({
        "environment": "maze_navigation",
        "episode": i + 1,
        "difficulty": 0.7,
        "grid_size": 10,
        "observable_radius": 3,
        "reward_function": "dense",
        "max_steps": 300,
        "wall_density": 0.4,
        "agent": "ppo-v2",
        "reward_shaping": {
            "goal_reward": 10.0,
            "step_penalty": -0.01,
            "wall_penalty": -0.5,
        },
    })
    v2_results.append(result)
    status = "✅" if result["success"] else "❌"
    print(f"  Episode {i+1}: {status}  reward={result['reward']:.3f}  steps={result['steps']}  q={result['avg_q_value']:.3f}")

v2_success_rate = sum(1 for r in v2_results if r["success"]) / len(v2_results)
print(f"\n  {v2.version} success rate: {v2_success_rate:.0%}")


# ─────────────────────────────────────────────────────────────
# Step 7: Compare versions
# ─────────────────────────────────────────────────────────────

print("\n📈 Step 7: Compare version performance\n")

print(f"  {'Metric':<20} {v1.version:>10} {v2.version:>10}")
print(f"  {'─'*20} {'─'*10} {'─'*10}")
print(f"  {'Success Rate':<20} {v1_success_rate:>9.0%} {v2_success_rate:>9.0%}")
print(f"  {'Mean Reward':<20} "
      f"{sum(r['reward'] for r in v1_results)/len(v1_results):>10.3f} "
      f"{sum(r['reward'] for r in v2_results)/len(v2_results):>10.3f}")
print(f"  {'Mean Steps':<20} "
      f"{sum(r['steps'] for r in v1_results)/len(v1_results):>10.1f} "
      f"{sum(r['steps'] for r in v2_results)/len(v2_results):>10.1f}")
print(f"  {'Mean Q-Value':<20} "
      f"{sum(r['avg_q_value'] for r in v1_results)/len(v1_results):>10.3f} "
      f"{sum(r['avg_q_value'] for r in v2_results)/len(v2_results):>10.3f}")
print(f"  {'Mean Entropy':<20} "
      f"{sum(r['entropy'] for r in v1_results)/len(v1_results):>10.3f} "
      f"{sum(r['entropy'] for r in v2_results)/len(v2_results):>10.3f}")
print(f"  {'Reward Function':<20} {'sparse':>10} {'dense':>10}")
print(f"  {'Difficulty':<20} {'0.5':>10} {'0.7':>10}")

# Config diff is visible in the dashboard — expand any version to see
# what changed vs the previous version (added/removed/changed keys)
print(f"\n  Config diffs visible in dashboard (expand version to see changes)")


# ─────────────────────────────────────────────────────────────
# Step 8: Rollback to v1 if v2 regressed
# ─────────────────────────────────────────────────────────────

print("\n⏪ Step 8: Rollback capability\n")

if v2_success_rate < v1_success_rate:
    print(f"  {v2.version} regressed ({v2_success_rate:.0%} < {v1_success_rate:.0%})")
    print(f"  Rolling back to {v1.version}...")
    try:
        client.versions.rollback(v1.version_id)
        restored = client.config.get_custom_config()
        print(f"  Restored config: reward={restored.get('reward_function')}, "
              f"difficulty={restored.get('difficulty')}")
    except Exception as e:
        print(f"  Rollback via API: {e}")
        # Rollback also available in dashboard with one click
        print(f"  (Rollback available via dashboard UI)")
else:
    print(f"  {v2.version} maintained or improved ({v2_success_rate:.0%} >= {v1_success_rate:.0%})")
    print(f"  Keeping {v2.version} as active config")


# ─────────────────────────────────────────────────────────────
# Step 9: List all versions
# ─────────────────────────────────────────────────────────────

print("\n📋 Step 9: Version history\n")

versions = client.versions.list_versions()
for v in versions:
    print(f"  {v.version:<10} {v.status:<12} {v.description or ''}")


# ─────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("  What just happened:")
print("=" * 60)
print("""
  1. Stored an arbitrary RL environment config (state space,
     reward function, difficulty, expert data params)
  2. Published with publish_major() — auto-incremented version
  3. Traced agent episodes with the @observe decorator —
     each run logged with reward, steps, and version tag
  4. Changed the config (dense reward, harder difficulty)
  5. Published with publish_minor() — auto-bumped minor version
  6. Compared performance across versions
  7. Rolled back when v2 regressed

  Version bumping methods:
    publish_major()  →  1.0.0 → 2.0.0
    publish_minor()  →  2.0.0 → 2.1.0
    publish_patch()  →  2.1.0 → 2.1.1

  All configs, traces, and versions are visible in the
  Trainly dashboard — filterable by version, with config
  diffs between any two snapshots.

  No custom infrastructure required. 5 minutes to integrate.
""")
