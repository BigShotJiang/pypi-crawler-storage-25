"""
Feature Parity Test: Section 8.3 — Async Support

Verifies:
- Async functions are traced correctly
- Trace appears in explorer with correct timing
- No duplicate traces from async execution
"""
import os
import asyncio
import openai
from trainly import TrainlyClient

client = TrainlyClient(
    api_key=os.environ["TRAINLY_API_KEY"],
    project_id=os.environ["TRAINLY_PROJECT_ID"],
)

aclient = openai.AsyncOpenAI()


# --- 8.3.1 Basic async function ---
@client.observe(model="gpt-4o", tags=["test", "async"])
async def async_call(query: str) -> str:
    response = await aclient.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": query}],
    )
    return response.choices[0].message.content


# --- 8.3.2 Multiple concurrent async calls ---
@client.observe(model="gpt-4o-mini", tags=["test", "async", "concurrent"])
async def async_mini_call(query: str) -> str:
    response = await aclient.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": query}],
    )
    return response.choices[0].message.content


async def main():
    print("=== 8.3.1 Single async call ===")
    result = await async_call("What is async tracing?")
    print(f"Response: {result}\n")

    print("=== 8.3.2 Concurrent async calls (should produce 3 distinct traces) ===")
    results = await asyncio.gather(
        async_mini_call("Question 1: What is latency?"),
        async_mini_call("Question 2: What is throughput?"),
        async_mini_call("Question 3: What is observability?"),
    )
    for i, r in enumerate(results, 1):
        print(f"Response {i}: {r[:80]}...\n")

    print("Done! Check Trace Explorer for 4 traces (1 async + 3 concurrent).")
    print("Verify: no duplicates, timing is correct for each.")


if __name__ == "__main__":
    asyncio.run(main())
