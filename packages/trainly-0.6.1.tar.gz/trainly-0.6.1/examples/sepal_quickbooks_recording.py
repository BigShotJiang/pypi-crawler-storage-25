"""
Trainly × Sepal AI — QuickBooks agent evaluation.

Evaluates an AI accounting agent on 8 QuickBooks tasks,
scores each on accuracy / financial correctness / compliance,
then publishes an improved version and compares.

Usage:
    python examples/sepal_quickbooks_recording.py
"""

import json
import random
from trainly import TrainlyClient

EVAL_TASKS = [
    {"id": "TASK-001", "type": "create_invoice",    "desc": "Create invoice: Summit Healthcare, 20hrs × $200"},
    {"id": "TASK-002", "type": "categorize_expense", "desc": "Categorize: AWS charge $2,847.33"},
    {"id": "TASK-003", "type": "reconcile_payment",  "desc": "Reconcile: Acme Corp ACH $4,500 → INV-1041"},
    {"id": "TASK-004", "type": "aging_report",       "desc": "Generate AR aging summary as of today"},
    {"id": "TASK-005", "type": "journal_entry",      "desc": "Record monthly depreciation $1,200"},
    {"id": "TASK-006", "type": "categorize_expense", "desc": "Categorize: United Airlines $487.20"},
    {"id": "TASK-007", "type": "vendor_bill",        "desc": "Vendor bill: Baker McKenzie retainer $5,000"},
    {"id": "TASK-008", "type": "reconcile_payment",  "desc": "Reconcile: Stripe payout $1,842.50 (no invoice)"},
]

def simulate_scores(error_rate: float):
    acc = 1.0 if random.random() > error_rate else round(random.uniform(0.4, 0.8), 2)
    fin = 1.0 if random.random() > (error_rate * 0.7) else round(random.uniform(0.5, 0.9), 2)
    comp = 1.0 if random.random() > error_rate else round(random.uniform(0.0, 0.8), 2)
    overall = round(acc * 0.35 + 1.0 * 0.20 + fin * 0.30 + comp * 0.15, 2)
    passed = overall >= 0.80 and fin >= 0.75
    return acc, fin, comp, overall, passed


client = TrainlyClient(
    api_key="tk_mlo8pm2i_8hf3n1hv08a",
    project_id="j578sm608bp70fpsjjfva0r2jh8154yk",
    base_url="https://api.trainlyai.com",
)


# ── Observe decorator: this is the entire integration ──

@client.observe(model="gpt-4o", tags=["quickbooks", "eval"])
def evaluate_task(task_input: dict) -> dict:
    """Run agent on a QuickBooks task and return scores."""
    acc, fin, comp, overall, passed = simulate_scores(task_input["error_rate"])
    return {
        "task_id": task_input["id"],
        "task_type": task_input["type"],
        "accuracy": acc,
        "financial_correctness": fin,
        "compliance": comp,
        "overall_score": overall,
        "passed": passed,
    }


def run_eval(version, error_rate, label):
    random.seed(42 if "baseline" in label else 7)
    results = []

    print(f"\n  {label} ({version})")
    print(f"  {'─' * 72}")
    print(f"  {'TASK':<10} {'TYPE':<24} {'ACC':>5} {'FIN':>5} {'COMP':>5} {'SCORE':>6}  RESULT")

    for task in EVAL_TASKS:
        r = evaluate_task({**task, "error_rate": error_rate, "version": version})
        results.append(r)

        tag = "\033[32mPASS\033[0m" if r["passed"] else "\033[31mFAIL\033[0m"
        print(f"  {r['task_id']:<10} {r['task_type']:<24} "
              f"{r['accuracy']:>5.2f} {r['financial_correctness']:>5.2f} "
              f"{r['compliance']:>5.2f} {r['overall_score']:>6.2f}  {tag}")

        client.observe.log(
            input=json.dumps({"task": task["id"], "type": task["type"], "desc": task["desc"]}),
            output=json.dumps(r),
            model="gpt-4o",
            version=version,
            tags=["quickbooks", "eval", task["type"]],
            custom_attributes=r,
        )

    p = sum(1 for r in results if r["passed"])
    avg = sum(r["overall_score"] for r in results) / len(results)
    print(f"  → {p}/{len(results)} passed, avg score {avg:.2f}")
    return results


# ── Run ──

# v1: baseline
agent_v1 = {"agent": "qb-accounting-agent", "model": "gpt-4o", "temperature": 0.1, "tools": 6, "prompt_version": "baseline"}
client.config.set_custom_config(agent_v1)
v1 = client.versions.publish_major(description="Baseline: gpt-4o, 6 tools, temp 0.1", custom_config=agent_v1)
r1 = run_eval(v1.version, error_rate=0.20, label="Baseline")

# v2: improved
agent_v2 = {"agent": "qb-accounting-agent", "model": "gpt-4o", "temperature": 0.0, "tools": 9, "prompt_version": "cot-v2", "guardrails": True}
client.config.set_custom_config(agent_v2)
v2 = client.versions.publish_minor(description="CoT prompting, guardrails, 9 tools", custom_config=agent_v2)
r2 = run_eval(v2.version, error_rate=0.08, label="Improved (CoT + guardrails)")

# Summary
p1 = sum(1 for r in r1 if r["passed"])
p2 = sum(1 for r in r2 if r["passed"])
a1 = sum(r["overall_score"] for r in r1) / len(r1)
a2 = sum(r["overall_score"] for r in r2) / len(r2)

print(f"\n  {v1.version} → {v2.version}:  {p1}/8 → {p2}/8 passed,  avg {a1:.2f} → {a2:.2f}")
print(f"  {'✓ Deployed' if p2 >= p1 else '✗ Rolled back'} — traces in Trainly dashboard\n")
