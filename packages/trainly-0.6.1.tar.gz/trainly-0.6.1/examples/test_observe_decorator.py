"""
Feature Parity Test: Section 8.1 — @observe Decorator

Verifies:
- Function executes normally (decorator doesn't break it)
- Trace appears in Trace Explorer within seconds
- Trace shows correct: input, output, model, latency
- Token count is accurate (prompt + completion)
- Cost is calculated based on model pricing
- Tags appear on trace
- Error in function → trace shows error status with message
"""
import os
import openai
from trainly import TrainlyClient

client = TrainlyClient(
    api_key=os.environ["TRAINLY_API_KEY"],
    project_id=os.environ["TRAINLY_PROJECT_ID"],
)


# --- 8.1.1 Basic decorated function ---
@client.observe(model="gpt-4o", tags=["test", "basic"])
def basic_call(query: str) -> str:
    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": query}],
    )
    return response.choices[0].message.content


# --- 8.1.2 With metadata and custom attributes ---
@client.observe(
    model="gpt-4o-mini",
    tags=["test", "metadata"],
    metadata={"environment": "testing", "test_id": "8.1.2"},
    custom_attributes={"user_tier": "pro", "feature_flag": "v2"},
)
def call_with_metadata(query: str) -> str:
    response = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": query}],
    )
    return response.choices[0].message.content


# --- 8.1.3 Error handling — trace should show error status ---
@client.observe(model="gpt-4o", tags=["test", "error"])
def call_that_errors(query: str) -> str:
    raise ValueError(f"Simulated failure for: {query}")


if __name__ == "__main__":
    print("=== 8.1.1 Basic @observe call ===")
    result = basic_call("Explain AI observability in one sentence.")
    print(f"Response: {result}\n")

    print("=== 8.1.2 With metadata + custom attributes ===")
    result = call_with_metadata("What is tracing?")
    print(f"Response: {result}\n")

    print("=== 8.1.3 Error trace ===")
    try:
        call_that_errors("This should fail")
    except ValueError as e:
        print(f"Caught expected error: {e}\n")

    print("Done! Check Trace Explorer for 3 traces (2 success, 1 error).")
