"""
Trainly Quickstart: Observe your AI pipeline

This example shows how to add tracing to any AI function in 3 lines.
"""
from trainly import TrainlyClient
import openai

client = TrainlyClient(api_key="tk_...", project_id="proj_...")

@client.observe(model="gpt-4o", tags=["quickstart"])
def ask_ai(question: str) -> str:
    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": question}],
    )
    return response.choices[0].message.content

answer = ask_ai("What is observability?")
print(answer)
