"""
Feature Parity Test: Section 3 — Online Evaluation System

Tests eval rules by sending traces that should trigger scoring.
Run this AFTER creating eval rules in the UI.

Covers:
- 3.2 Automatic Scoring (send traces, verify scores appear)
- 3.3 Sampling (send many traces, verify ~sample_rate% scored)
- 3.4 Tag Filtering (send traces with different tags)
- 3.5 Threshold Alerts (send traces likely to trigger high scores)
"""
import os
import time
from trainly import TrainlyClient

client = TrainlyClient(
    api_key=os.environ["TRAINLY_API_KEY"],
    project_id=os.environ["TRAINLY_PROJECT_ID"],
)


def test_automatic_scoring():
    """3.2 — Send a trace that should get auto-scored.

    Prerequisites:
        Create an eval rule in the UI with 100% sampling and no tag filter.
    """
    print("=== 3.2 Automatic Scoring ===")
    client.observe.log(
        input="What year did the first iPhone come out?",
        output="The first iPhone was released in 2007 by Apple Inc.",
        model="gpt-4o",
        tags=["test", "eval"],
        token_usage={"prompt_tokens": 15, "completion_tokens": 20, "total_tokens": 35},
    )
    print("Trace sent. Wait 10-30s, then check for score badges in Trace Explorer.\n")


def test_sampling():
    """3.3 — Send 20 traces to verify sampling rate.

    Prerequisites:
        Create an eval rule with 50% sample rate.
    """
    print("=== 3.3 Sampling (20 traces) ===")
    batch_tag = f"sampling-test-{int(time.time())}"
    for i in range(20):
        client.observe.log(
            input=f"Sampling test query #{i + 1}",
            output=f"This is response #{i + 1} for sampling verification.",
            model="gpt-4o-mini",
            tags=["test", "sampling", batch_tag],
            token_usage={"prompt_tokens": 10, "completion_tokens": 15, "total_tokens": 25},
        )
    print(f"20 traces sent with tag '{batch_tag}'.")
    print("With 50% sample rate, expect ~10 to be scored.\n")


def test_tag_filtering():
    """3.4 — Send traces with different tags to verify tag-based eval rules.

    Prerequisites:
        Create an eval rule with tag filter ["production"].
    """
    print("=== 3.4 Tag Filtering ===")

    # Should be scored (matches "production" tag)
    client.observe.log(
        input="Production query: What is machine learning?",
        output="Machine learning is a subset of AI that learns from data.",
        model="gpt-4o",
        tags=["production"],
        metadata={"test": "tag_filter", "expected": "scored"},
    )
    print("Sent trace with tag 'production' — should be scored")

    # Should NOT be scored (no matching tag)
    client.observe.log(
        input="Staging query: What is deep learning?",
        output="Deep learning uses neural networks with many layers.",
        model="gpt-4o",
        tags=["staging"],
        metadata={"test": "tag_filter", "expected": "not_scored"},
    )
    print("Sent trace with tag 'staging' — should NOT be scored")

    # Should be scored (has "production" among other tags)
    client.observe.log(
        input="Multi-tag query: What is NLP?",
        output="NLP is natural language processing.",
        model="gpt-4o",
        tags=["production", "v2"],
        metadata={"test": "tag_filter", "expected": "scored"},
    )
    print("Sent trace with tags ['production', 'v2'] — should be scored")

    # Should NOT be scored (no tags at all)
    client.observe.log(
        input="No-tag query: What is AI?",
        output="AI is artificial intelligence.",
        model="gpt-4o",
        metadata={"test": "tag_filter", "expected": "not_scored"},
    )
    print("Sent trace with no tags — should NOT be scored\n")


def test_threshold_alerts():
    """3.5 — Send traces designed to trigger high hallucination scores.

    Prerequisites:
        Create an eval rule with threshold: hallucination > 0.5 (1h window).
    """
    print("=== 3.5 Threshold Alerts (hallucination-prone traces) ===")

    hallucination_pairs = [
        (
            "What is the capital of France?",
            "The capital of France is Berlin, which was founded in 1823 by Napoleon.",
        ),
        (
            "Who wrote Romeo and Juliet?",
            "Romeo and Juliet was written by Charles Dickens in 1920.",
        ),
        (
            "What is the speed of light?",
            "The speed of light is approximately 500 miles per hour.",
        ),
        (
            "When did World War II end?",
            "World War II ended in 1962 after the Treaty of Mars was signed.",
        ),
        (
            "What is water made of?",
            "Water is composed of carbon dioxide and nitrogen molecules.",
        ),
    ]

    for query, answer in hallucination_pairs:
        client.observe.log(
            input=query,
            output=answer,
            model="gpt-4o",
            tags=["test", "hallucination-test"],
            metadata={"test": "threshold_alert", "intentionally_wrong": True},
        )

    print(f"Sent {len(hallucination_pairs)} intentionally hallucinated traces.")
    print("If hallucination scorer is configured, these should trigger high scores.")
    print("If threshold alert is set (hallucination > 0.5), alert should fire.\n")


if __name__ == "__main__":
    test_automatic_scoring()
    test_sampling()
    test_tag_filtering()
    test_threshold_alerts()
    print("All eval test traces sent! Check the UI for results.")
