"""
Feature Parity Test: Section 8.5 — Session Tracking

Verifies:
- Both traces appear with same session_id
- Session grouping in explorer shows them together
- Traces within session are ordered chronologically
"""
import os
import uuid
import time
import openai
from trainly import TrainlyClient

client = TrainlyClient(
    api_key=os.environ["TRAINLY_API_KEY"],
    project_id=os.environ["TRAINLY_PROJECT_ID"],
)

SESSION_ID = f"session_{uuid.uuid4().hex[:12]}"


# --- Multi-step conversation with shared session ---
@client.observe(model="gpt-4o", tags=["test", "session"], session_id=SESSION_ID)
def conversation_step(messages: list) -> str:
    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=messages,
    )
    return response.choices[0].message.content


def main():
    print(f"Session ID: {SESSION_ID}\n")

    # Step 1: Initial question
    print("=== Step 1: Initial question ===")
    messages = [{"role": "user", "content": "What is LLM observability?"}]
    answer1 = conversation_step(messages)
    print(f"Response: {answer1[:100]}...\n")
    time.sleep(1)  # small gap to verify chronological ordering

    # Step 2: Follow-up
    print("=== Step 2: Follow-up question ===")
    messages.append({"role": "assistant", "content": answer1})
    messages.append({"role": "user", "content": "How does tracing help with that?"})
    answer2 = conversation_step(messages)
    print(f"Response: {answer2[:100]}...\n")
    time.sleep(1)

    # Step 3: Another follow-up
    print("=== Step 3: Another follow-up ===")
    messages.append({"role": "assistant", "content": answer2})
    messages.append({"role": "user", "content": "What metrics should I track?"})
    answer3 = conversation_step(messages)
    print(f"Response: {answer3[:100]}...\n")

    print(f"Done! Check Trace Explorer:")
    print(f"  1. Filter by session ID: '{SESSION_ID}'")
    print(f"  2. Verify 3 traces are grouped together")
    print(f"  3. Verify chronological order (Step 1 → 2 → 3)")


if __name__ == "__main__":
    main()
