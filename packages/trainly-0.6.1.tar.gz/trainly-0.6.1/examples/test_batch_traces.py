"""
Feature Parity Test: Section 8.4 — Batch Traces

Verifies:
- Send 100+ traces in rapid succession
- All traces eventually appear in explorer
- No traces lost or duplicated
- Order is roughly preserved
"""
import os
import time
from trainly import TrainlyClient

client = TrainlyClient(
    api_key=os.environ["TRAINLY_API_KEY"],
    project_id=os.environ["TRAINLY_PROJECT_ID"],
)

BATCH_SIZE = 100
BATCH_TAG = f"batch-{int(time.time())}"


def main():
    print(f"Sending {BATCH_SIZE} traces with tag '{BATCH_TAG}'...")
    print("(Using manual logging to avoid hitting OpenAI rate limits)\n")

    start = time.time()

    for i in range(BATCH_SIZE):
        client.observe.log(
            input=f"Batch query #{i + 1}: What is item {i + 1}?",
            output=f"This is the answer to question {i + 1}. It covers topic {i + 1} in detail.",
            model="gpt-4o-mini",
            tags=["test", "batch", BATCH_TAG],
            metadata={"batch_index": i, "batch_id": BATCH_TAG},
            token_usage={
                "prompt_tokens": 20 + i,
                "completion_tokens": 50 + i,
                "total_tokens": 70 + (2 * i),
            },
            latency_ms=100 + (i * 5),
        )

        if (i + 1) % 25 == 0:
            print(f"  Sent {i + 1}/{BATCH_SIZE} traces")

    elapsed = time.time() - start
    print(f"\nAll {BATCH_SIZE} traces sent in {elapsed:.1f}s")
    print(f"\nVerification steps:")
    print(f"  1. Go to Trace Explorer")
    print(f"  2. Filter by tag: '{BATCH_TAG}'")
    print(f"  3. Confirm exactly {BATCH_SIZE} traces appear")
    print(f"  4. Check that batch_index metadata goes from 0 to {BATCH_SIZE - 1}")
    print(f"  5. Verify no duplicates (each index appears once)")


if __name__ == "__main__":
    main()
