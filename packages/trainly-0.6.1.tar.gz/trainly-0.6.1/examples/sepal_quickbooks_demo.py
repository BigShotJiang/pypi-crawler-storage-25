"""
Trainly SDK Demo — QuickBooks AI Agent Evaluation & Observability

Simulates how Sepal AI would evaluate an AI agent that automates
accounting tasks in QuickBooks. The agent is scored on accuracy,
completeness, financial correctness, and compliance across tasks like:

  - Invoice creation
  - Expense categorization
  - Bank reconciliation
  - Payment application
  - Journal entries
  - Aging report generation

Each task attempt is traced through Trainly with rich custom attributes,
enabling version-over-version comparison when the agent's prompts,
model, or tool config changes.

Usage:
    export TRAINLY_API_KEY="tk_..."
    export TRAINLY_CHAT_ID="chat_..."
    python examples/sepal_quickbooks_demo.py
"""

import json
import time
import random
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field, asdict

from trainly import TrainlyClient


# ═════════════════════════════════════════════════════════════
# Mock QuickBooks Environment
# ═════════════════════════════════════════════════════════════

CHART_OF_ACCOUNTS = {
    "1000": {"name": "Checking Account", "type": "Bank", "balance": 48_250.00},
    "1100": {"name": "Accounts Receivable", "type": "Accounts Receivable", "balance": 15_800.00},
    "1200": {"name": "Inventory Asset", "type": "Other Current Asset", "balance": 22_400.00},
    "2000": {"name": "Accounts Payable", "type": "Accounts Payable", "balance": 8_900.00},
    "2100": {"name": "Credit Card Payable", "type": "Credit Card", "balance": 3_450.00},
    "4000": {"name": "Sales Revenue", "type": "Income", "balance": 142_000.00},
    "4100": {"name": "Consulting Revenue", "type": "Income", "balance": 38_500.00},
    "5000": {"name": "Cost of Goods Sold", "type": "Cost of Goods Sold", "balance": 67_200.00},
    "6100": {"name": "Rent Expense", "type": "Expense", "balance": 18_000.00},
    "6200": {"name": "Office Supplies", "type": "Expense", "balance": 2_340.00},
    "6300": {"name": "Software Subscriptions", "type": "Expense", "balance": 4_800.00},
    "6400": {"name": "Travel & Entertainment", "type": "Expense", "balance": 6_150.00},
    "6500": {"name": "Professional Services", "type": "Expense", "balance": 12_000.00},
    "6600": {"name": "Utilities", "type": "Expense", "balance": 3_200.00},
    "6700": {"name": "Insurance", "type": "Expense", "balance": 5_400.00},
    "6800": {"name": "Payroll Expense", "type": "Expense", "balance": 96_000.00},
}

CUSTOMERS = {
    "CUST-001": {"name": "Acme Corp", "email": "billing@acme.com", "balance": 4_500.00, "terms": "Net 30"},
    "CUST-002": {"name": "TechStart Inc", "email": "ap@techstart.io", "balance": 2_800.00, "terms": "Net 15"},
    "CUST-003": {"name": "Global Retail LLC", "email": "accounts@globalretail.com", "balance": 8_500.00, "terms": "Net 45"},
    "CUST-004": {"name": "Summit Healthcare", "email": "finance@summithc.org", "balance": 0.00, "terms": "Net 30"},
    "CUST-005": {"name": "Precision Mfg Co", "email": "pay@precisionmfg.com", "balance": 12_350.00, "terms": "Net 60"},
}

VENDORS = {
    "VEND-001": {"name": "AWS", "category": "Software Subscriptions", "account": "6300"},
    "VEND-002": {"name": "WeWork", "category": "Rent Expense", "account": "6100"},
    "VEND-003": {"name": "Staples", "category": "Office Supplies", "account": "6200"},
    "VEND-004": {"name": "United Airlines", "category": "Travel & Entertainment", "account": "6400"},
    "VEND-005": {"name": "Baker & McKenzie LLP", "category": "Professional Services", "account": "6500"},
}

OPEN_INVOICES = [
    {"id": "INV-1041", "customer": "CUST-001", "amount": 4_500.00, "due": "2026-03-15", "status": "overdue", "line_items": [
        {"description": "Consulting — Feb 2026", "quantity": 30, "rate": 150.00}
    ]},
    {"id": "INV-1042", "customer": "CUST-002", "amount": 2_800.00, "due": "2026-03-20", "status": "open", "line_items": [
        {"description": "Software license (annual)", "quantity": 1, "rate": 2_800.00}
    ]},
    {"id": "INV-1043", "customer": "CUST-003", "amount": 8_500.00, "due": "2026-04-10", "status": "open", "line_items": [
        {"description": "Implementation services", "quantity": 40, "rate": 175.00},
        {"description": "Training (2 days)", "quantity": 2, "rate": 750.00},
    ]},
    {"id": "INV-1044", "customer": "CUST-005", "amount": 12_350.00, "due": "2026-05-01", "status": "open", "line_items": [
        {"description": "Custom integration build", "quantity": 1, "rate": 12_350.00}
    ]},
]

BANK_TRANSACTIONS = [
    {"id": "BT-5001", "date": "2026-03-08", "description": "AMZN MKTP US*2K7X9 AMZN.COM/BILL", "amount": -149.99, "matched": False},
    {"id": "BT-5002", "date": "2026-03-07", "description": "ACH DEPOSIT ACME CORP", "amount": 4_500.00, "matched": False},
    {"id": "BT-5003", "date": "2026-03-06", "description": "WEWORK 425 PARK AVE", "amount": -3_000.00, "matched": False},
    {"id": "BT-5004", "date": "2026-03-05", "description": "UNITED 016-2847561832", "amount": -487.20, "matched": False},
    {"id": "BT-5005", "date": "2026-03-04", "description": "STRIPE TRANSFER", "amount": 1_842.50, "matched": False},
    {"id": "BT-5006", "date": "2026-03-03", "description": "AWS *2K8FJKD2 aws.amazon.com", "amount": -2_847.33, "matched": False},
]

EXPECTED_CATEGORIZATIONS = {
    "BT-5001": {"account": "6200", "vendor": "Amazon/Staples", "memo": "Office supplies"},
    "BT-5002": {"account": "1100", "customer": "CUST-001", "memo": "Payment on INV-1041"},
    "BT-5003": {"account": "6100", "vendor": "VEND-002", "memo": "March rent"},
    "BT-5004": {"account": "6400", "vendor": "VEND-004", "memo": "Business travel"},
    "BT-5005": {"account": "4000", "customer": None, "memo": "Stripe payout"},
    "BT-5006": {"account": "6300", "vendor": "VEND-001", "memo": "AWS monthly"},
}


# ═════════════════════════════════════════════════════════════
# Task Definitions — what we ask the agent to do
# ═════════════════════════════════════════════════════════════

@dataclass
class TaskResult:
    task_id: str
    task_type: str
    description: str
    agent_output: Dict[str, Any]
    expected_output: Dict[str, Any]
    scores: Dict[str, float]
    overall_score: float
    passed: bool
    errors: List[str] = field(default_factory=list)
    latency_ms: float = 0.0


EVAL_TASKS = [
    {
        "task_id": "TASK-001",
        "type": "create_invoice",
        "description": "Create an invoice for Summit Healthcare for 20 hours of consulting at $200/hr, Net 30 terms",
        "input": {
            "action": "create_invoice",
            "customer_id": "CUST-004",
            "line_items": [{"description": "Consulting services — March 2026", "quantity": 20, "rate": 200.00}],
            "terms": "Net 30",
            "memo": "Per SOW-2026-004 Section 3.1",
        },
        "expected": {
            "customer_id": "CUST-004",
            "customer_name": "Summit Healthcare",
            "total": 4_000.00,
            "line_items": [{"description": "Consulting services — March 2026", "quantity": 20, "rate": 200.00, "amount": 4_000.00}],
            "terms": "Net 30",
            "due_date_offset_days": 30,
            "debit_account": "1100",
            "credit_account": "4100",
        },
    },
    {
        "task_id": "TASK-002",
        "type": "categorize_expense",
        "description": "Categorize bank transaction BT-5006 (AWS charge of $2,847.33)",
        "input": {
            "action": "categorize_transaction",
            "transaction_id": "BT-5006",
            "transaction": BANK_TRANSACTIONS[5],
        },
        "expected": {
            "account_code": "6300",
            "account_name": "Software Subscriptions",
            "vendor": "AWS",
            "amount": 2_847.33,
            "tax_deductible": True,
            "category": "Software Subscriptions",
        },
    },
    {
        "task_id": "TASK-003",
        "type": "reconcile_payment",
        "description": "Reconcile incoming ACH from Acme Corp ($4,500) against open invoices",
        "input": {
            "action": "reconcile_payment",
            "transaction_id": "BT-5002",
            "transaction": BANK_TRANSACTIONS[1],
        },
        "expected": {
            "matched_invoice": "INV-1041",
            "customer_id": "CUST-001",
            "customer_name": "Acme Corp",
            "amount": 4_500.00,
            "fully_applied": True,
            "remaining_balance": 0.00,
            "debit_account": "1000",
            "credit_account": "1100",
        },
    },
    {
        "task_id": "TASK-004",
        "type": "aging_report",
        "description": "Generate an accounts receivable aging summary as of 2026-03-11",
        "input": {
            "action": "generate_aging_report",
            "report_type": "accounts_receivable",
            "as_of_date": "2026-03-11",
        },
        "expected": {
            "total_receivable": 28_150.00,
            "current": 23_650.00,
            "overdue_1_30": 4_500.00,
            "overdue_31_60": 0.00,
            "overdue_61_90": 0.00,
            "overdue_90_plus": 0.00,
            "num_customers_with_balance": 4,
        },
    },
    {
        "task_id": "TASK-005",
        "type": "create_journal_entry",
        "description": "Record monthly depreciation of $1,200 for office equipment",
        "input": {
            "action": "create_journal_entry",
            "memo": "Monthly depreciation — office equipment — March 2026",
            "lines": [
                {"account": "Depreciation Expense", "debit": 1_200.00, "credit": 0.00},
                {"account": "Accumulated Depreciation", "debit": 0.00, "credit": 1_200.00},
            ],
        },
        "expected": {
            "total_debits": 1_200.00,
            "total_credits": 1_200.00,
            "balanced": True,
            "num_lines": 2,
            "memo": "Monthly depreciation — office equipment — March 2026",
        },
    },
    {
        "task_id": "TASK-006",
        "type": "categorize_expense",
        "description": "Categorize bank transaction BT-5004 (United Airlines charge of $487.20)",
        "input": {
            "action": "categorize_transaction",
            "transaction_id": "BT-5004",
            "transaction": BANK_TRANSACTIONS[3],
        },
        "expected": {
            "account_code": "6400",
            "account_name": "Travel & Entertainment",
            "vendor": "United Airlines",
            "amount": 487.20,
            "tax_deductible": True,
            "category": "Travel & Entertainment",
        },
    },
    {
        "task_id": "TASK-007",
        "type": "vendor_bill",
        "description": "Create a vendor bill for Baker & McKenzie legal retainer — $5,000/month",
        "input": {
            "action": "create_vendor_bill",
            "vendor_id": "VEND-005",
            "line_items": [{"description": "Legal retainer — March 2026", "amount": 5_000.00}],
            "due_date": "2026-04-10",
        },
        "expected": {
            "vendor_id": "VEND-005",
            "vendor_name": "Baker & McKenzie LLP",
            "total": 5_000.00,
            "expense_account": "6500",
            "debit_account": "6500",
            "credit_account": "2000",
            "due_date": "2026-04-10",
        },
    },
    {
        "task_id": "TASK-008",
        "type": "reconcile_payment",
        "description": "Reconcile Stripe payout ($1,842.50) — identify as revenue, no matching invoice",
        "input": {
            "action": "reconcile_payment",
            "transaction_id": "BT-5005",
            "transaction": BANK_TRANSACTIONS[4],
        },
        "expected": {
            "matched_invoice": None,
            "amount": 1_842.50,
            "classification": "revenue",
            "debit_account": "1000",
            "credit_account": "4000",
            "requires_review": True,
            "reason": "No matching invoice — Stripe payout needs manual line-item breakdown",
        },
    },
]


# ═════════════════════════════════════════════════════════════
# Simulated Agent — mimics an LLM-based accounting agent
# ═════════════════════════════════════════════════════════════

def simulate_agent_v1(task: Dict[str, Any], error_rate: float = 0.15) -> Dict[str, Any]:
    """
    V1 agent: rule-based with moderate accuracy.
    Simulates realistic mistakes an early-stage agent would make.
    """
    expected = task["expected"]
    task_type = task["type"]
    output = {}

    if task_type == "create_invoice":
        correct_total = random.random() > error_rate
        total = expected["total"] if correct_total else expected["total"] * random.choice([0.9, 1.1, 0.5])
        output = {
            "customer_id": expected["customer_id"],
            "customer_name": expected["customer_name"],
            "total": round(total, 2),
            "line_items": expected["line_items"] if correct_total else [
                {**expected["line_items"][0], "amount": round(total, 2)}
            ],
            "terms": expected["terms"] if random.random() > error_rate else "Net 15",
            "due_date_offset_days": expected["due_date_offset_days"],
            "debit_account": expected["debit_account"],
            "credit_account": expected["credit_account"] if random.random() > error_rate else "4000",
        }

    elif task_type == "categorize_expense":
        correct_account = random.random() > error_rate
        output = {
            "account_code": expected["account_code"] if correct_account else random.choice(["6200", "6400", "6600"]),
            "account_name": expected["account_name"] if correct_account else "Miscellaneous",
            "vendor": expected["vendor"] if random.random() > (error_rate * 0.5) else "Unknown Vendor",
            "amount": expected["amount"],
            "tax_deductible": expected["tax_deductible"] if random.random() > error_rate else False,
            "category": expected["category"] if correct_account else "Uncategorized",
        }

    elif task_type == "reconcile_payment":
        correct_match = random.random() > error_rate
        if expected.get("matched_invoice"):
            output = {
                "matched_invoice": expected["matched_invoice"] if correct_match else "INV-1042",
                "customer_id": expected["customer_id"] if correct_match else "CUST-002",
                "customer_name": expected["customer_name"] if correct_match else "TechStart Inc",
                "amount": expected["amount"],
                "fully_applied": expected["fully_applied"] if correct_match else False,
                "remaining_balance": expected["remaining_balance"] if correct_match else 500.00,
                "debit_account": expected["debit_account"],
                "credit_account": expected["credit_account"],
            }
        else:
            output = {
                "matched_invoice": None,
                "amount": expected["amount"],
                "classification": expected["classification"] if random.random() > error_rate else "other_income",
                "debit_account": expected["debit_account"],
                "credit_account": expected["credit_account"] if random.random() > error_rate else "4100",
                "requires_review": expected.get("requires_review", False) if random.random() > error_rate else False,
                "reason": expected.get("reason", "") if random.random() > (error_rate * 2) else "",
            }

    elif task_type == "aging_report":
        drift = 1.0 if random.random() > error_rate else random.uniform(0.85, 1.15)
        output = {
            "total_receivable": round(expected["total_receivable"] * drift, 2),
            "current": round(expected["current"] * drift, 2),
            "overdue_1_30": round(expected["overdue_1_30"] * drift, 2),
            "overdue_31_60": expected["overdue_31_60"],
            "overdue_61_90": expected["overdue_61_90"],
            "overdue_90_plus": expected["overdue_90_plus"],
            "num_customers_with_balance": expected["num_customers_with_balance"] if random.random() > error_rate else 3,
        }

    elif task_type == "create_journal_entry":
        balanced = random.random() > (error_rate * 0.5)
        output = {
            "total_debits": expected["total_debits"],
            "total_credits": expected["total_credits"] if balanced else expected["total_credits"] - 100,
            "balanced": balanced,
            "num_lines": expected["num_lines"],
            "memo": expected["memo"] if random.random() > error_rate else "Depreciation",
        }

    elif task_type == "vendor_bill":
        correct_account = random.random() > error_rate
        output = {
            "vendor_id": expected["vendor_id"],
            "vendor_name": expected["vendor_name"],
            "total": expected["total"] if random.random() > error_rate else expected["total"] + 500,
            "expense_account": expected["expense_account"] if correct_account else "6200",
            "debit_account": expected["debit_account"] if correct_account else "6200",
            "credit_account": expected["credit_account"],
            "due_date": expected["due_date"] if random.random() > error_rate else "2026-03-30",
        }

    return output


def simulate_agent_v2(task: Dict[str, Any], error_rate: float = 0.05) -> Dict[str, Any]:
    """
    V2 agent: improved prompts + tool use, lower error rate.
    """
    return simulate_agent_v1(task, error_rate=error_rate)


# ═════════════════════════════════════════════════════════════
# Scoring Engine
# ═════════════════════════════════════════════════════════════

def score_task(task: Dict[str, Any], agent_output: Dict[str, Any]) -> TaskResult:
    """Score an agent's output against the expected result."""
    expected = task["expected"]
    task_type = task["type"]
    scores = {}
    errors = []

    # --- Accuracy: did the agent pick the right entities / accounts? ---
    accuracy_checks = []
    key_fields = {
        "create_invoice": ["customer_id", "terms", "debit_account", "credit_account"],
        "categorize_expense": ["account_code", "vendor", "category"],
        "reconcile_payment": ["matched_invoice", "customer_id", "debit_account", "credit_account"],
        "aging_report": ["num_customers_with_balance"],
        "create_journal_entry": ["balanced", "num_lines"],
        "vendor_bill": ["vendor_id", "expense_account", "debit_account", "credit_account"],
    }
    for field_name in key_fields.get(task_type, []):
        exp_val = expected.get(field_name)
        act_val = agent_output.get(field_name)
        match = (exp_val == act_val)
        accuracy_checks.append(match)
        if not match:
            errors.append(f"{field_name}: expected={exp_val}, got={act_val}")

    scores["accuracy"] = sum(accuracy_checks) / max(len(accuracy_checks), 1)

    # --- Completeness: did the agent fill all required fields? ---
    required_fields = list(expected.keys())
    present = sum(1 for f in required_fields if f in agent_output and agent_output[f] is not None and agent_output[f] != "")
    scores["completeness"] = present / max(len(required_fields), 1)
    missing = [f for f in required_fields if f not in agent_output or agent_output[f] is None or agent_output[f] == ""]
    if missing:
        errors.append(f"missing fields: {missing}")

    # --- Financial correctness: amounts, balancing, totals ---
    fin_checks = []
    if "total" in expected:
        fin_checks.append(abs(agent_output.get("total", 0) - expected["total"]) < 0.01)
    if "amount" in expected:
        fin_checks.append(abs(agent_output.get("amount", 0) - expected["amount"]) < 0.01)
    if "balanced" in expected:
        fin_checks.append(agent_output.get("balanced") == expected["balanced"])
    if "total_debits" in expected and "total_credits" in expected:
        debits = agent_output.get("total_debits", 0)
        credits = agent_output.get("total_credits", 0)
        fin_checks.append(abs(debits - credits) < 0.01)
    if "total_receivable" in expected:
        tolerance = expected["total_receivable"] * 0.02
        fin_checks.append(abs(agent_output.get("total_receivable", 0) - expected["total_receivable"]) < tolerance)
    if "remaining_balance" in expected:
        fin_checks.append(agent_output.get("remaining_balance") == expected["remaining_balance"])

    scores["financial_correctness"] = sum(fin_checks) / max(len(fin_checks), 1) if fin_checks else 1.0

    # --- Compliance: proper account types, review flags, memos ---
    compliance_checks = []
    if task_type == "create_journal_entry":
        compliance_checks.append(agent_output.get("balanced", False) is True)
        compliance_checks.append(bool(agent_output.get("memo")))
    if task_type == "reconcile_payment" and expected.get("requires_review"):
        compliance_checks.append(agent_output.get("requires_review", False) is True)
        compliance_checks.append(bool(agent_output.get("reason")))
    if task_type == "categorize_expense":
        compliance_checks.append(agent_output.get("tax_deductible") == expected.get("tax_deductible"))
    if task_type in ("create_invoice", "vendor_bill"):
        compliance_checks.append(agent_output.get("debit_account") != agent_output.get("credit_account"))

    scores["compliance"] = sum(compliance_checks) / max(len(compliance_checks), 1) if compliance_checks else 1.0

    overall = (
        scores["accuracy"] * 0.35
        + scores["completeness"] * 0.20
        + scores["financial_correctness"] * 0.30
        + scores["compliance"] * 0.15
    )
    passed = overall >= 0.80 and scores["financial_correctness"] >= 0.75

    return TaskResult(
        task_id=task["task_id"],
        task_type=task_type,
        description=task["description"],
        agent_output=agent_output,
        expected_output=expected,
        scores=scores,
        overall_score=round(overall, 4),
        passed=passed,
        errors=errors,
    )


# ═════════════════════════════════════════════════════════════
# Main Demo
# ═════════════════════════════════════════════════════════════

client = TrainlyClient(
    api_key="tk_mlo8pm2i_8hf3n1hv08a",
    project_id="j578sm608bp70fpsjjfva0r2jh8154yk",
    base_url="https://api.trainlyai.com",
)

print("=" * 64)
print("  Trainly SDK — QuickBooks Agent Evaluation Demo")
print("  Sepal AI × Trainly")
print("=" * 64)


# ─────────────────────────────────────────────────────────────
# Step 1: Store agent config (prompt, model, tools)
# ─────────────────────────────────────────────────────────────

print("\n[1] Store agent configuration\n")

agent_config_v1 = {
    "agent_name": "qb-accounting-agent",
    "model": "gpt-4o",
    "temperature": 0.1,
    "system_prompt": "You are an expert QuickBooks accountant. Given a task, "
                     "return structured JSON with the correct accounts, amounts, "
                     "and classifications. Follow GAAP principles.",
    "tools": [
        "quickbooks.create_invoice",
        "quickbooks.categorize_transaction",
        "quickbooks.reconcile",
        "quickbooks.create_journal_entry",
        "quickbooks.create_vendor_bill",
        "quickbooks.generate_report",
    ],
    "eval_settings": {
        "pass_threshold": 0.80,
        "financial_correctness_floor": 0.75,
        "tasks_per_run": len(EVAL_TASKS),
    },
    "quickbooks_env": {
        "company": "Sepal AI Demo Co.",
        "fiscal_year_start": "2026-01-01",
        "accounting_method": "accrual",
        "num_accounts": len(CHART_OF_ACCOUNTS),
        "num_customers": len(CUSTOMERS),
        "num_vendors": len(VENDORS),
    },
}

client.config.set_custom_config(agent_config_v1)
print(f"  Agent: {agent_config_v1['agent_name']}")
print(f"  Model: {agent_config_v1['model']}  temp={agent_config_v1['temperature']}")
print(f"  Tools: {len(agent_config_v1['tools'])} QuickBooks actions")
print(f"  Pass threshold: {agent_config_v1['eval_settings']['pass_threshold']:.0%}")


# ─────────────────────────────────────────────────────────────
# Step 2: Publish v1
# ─────────────────────────────────────────────────────────────

print("\n[2] Publish agent version\n")

v1 = client.versions.publish_major(
    description="Baseline: gpt-4o, basic system prompt, 6 QB tools",
    custom_config=agent_config_v1,
)
print(f"  Published: {v1.version}")
print(f"  Version ID: {v1.version_id}")


# ─────────────────────────────────────────────────────────────
# Step 3: Run evaluation — agent v1
# ─────────────────────────────────────────────────────────────

print(f"\n[3] Evaluate agent against {len(EVAL_TASKS)} QuickBooks tasks ({v1.version})\n")


@client.observe(
    model="gpt-4o",
    tags=["quickbooks", "eval", "baseline"],
    version=v1.version,
)
def evaluate_task(task_input: dict) -> dict:
    """Run agent on a single accounting task and return scored result."""
    task = task_input["task"]
    agent_fn = simulate_agent_v1
    start = time.time()
    agent_output = agent_fn(task)
    latency = (time.time() - start) * 1000
    result = score_task(task, agent_output)
    result.latency_ms = latency
    return asdict(result)


v1_results: List[TaskResult] = []
for task in EVAL_TASKS:
    raw = evaluate_task({"task": task, "version": v1.version})
    result = TaskResult(**{k: raw[k] for k in TaskResult.__dataclass_fields__})
    v1_results.append(result)

    icon = "PASS" if result.passed else "FAIL"
    print(f"  [{icon}] {result.task_id} {result.task_type:<22} "
          f"score={result.overall_score:.2f}  "
          f"acc={result.scores['accuracy']:.2f}  "
          f"fin={result.scores['financial_correctness']:.2f}  "
          f"comp={result.scores['compliance']:.2f}")
    if result.errors:
        for err in result.errors[:2]:
            print(f"         ^ {err}")

v1_pass_rate = sum(1 for r in v1_results if r.passed) / len(v1_results)
v1_avg_score = sum(r.overall_score for r in v1_results) / len(v1_results)
v1_avg_accuracy = sum(r.scores["accuracy"] for r in v1_results) / len(v1_results)
v1_avg_financial = sum(r.scores["financial_correctness"] for r in v1_results) / len(v1_results)

print(f"\n  {v1.version} Summary:")
print(f"    Pass rate:             {v1_pass_rate:.0%}")
print(f"    Avg overall score:     {v1_avg_score:.3f}")
print(f"    Avg accuracy:          {v1_avg_accuracy:.3f}")
print(f"    Avg financial correct: {v1_avg_financial:.3f}")


# ─────────────────────────────────────────────────────────────
# Step 4: Log aggregate evaluation trace
# ─────────────────────────────────────────────────────────────

print("\n[4] Log evaluation summary to Trainly\n")

scores_by_type = {}
for r in v1_results:
    scores_by_type.setdefault(r.task_type, []).append(r.overall_score)

client.observe.log(
    input=json.dumps({"eval_run": "quickbooks_baseline", "version": v1.version, "num_tasks": len(EVAL_TASKS)}),
    output=json.dumps({
        "pass_rate": v1_pass_rate,
        "avg_score": v1_avg_score,
        "avg_accuracy": v1_avg_accuracy,
        "avg_financial_correctness": v1_avg_financial,
        "scores_by_task_type": {k: round(sum(v) / len(v), 3) for k, v in scores_by_type.items()},
        "failed_tasks": [r.task_id for r in v1_results if not r.passed],
    }),
    model="gpt-4o",
    version=v1.version,
    tags=["quickbooks", "eval", "summary"],
    custom_attributes={
        "pass_rate": v1_pass_rate,
        "avg_score": round(v1_avg_score, 4),
        "avg_accuracy": round(v1_avg_accuracy, 4),
        "avg_financial_correctness": round(v1_avg_financial, 4),
        "total_tasks": len(EVAL_TASKS),
        "passed_tasks": sum(1 for r in v1_results if r.passed),
        "failed_tasks": sum(1 for r in v1_results if not r.passed),
        "task_types_tested": list(scores_by_type.keys()),
        "environment": "quickbooks_sandbox",
    },
)
print("  Logged evaluation summary with custom attributes")


# ─────────────────────────────────────────────────────────────
# Step 5: Improve agent — new prompt + chain-of-thought
# ─────────────────────────────────────────────────────────────

print("\n[5] Upgrade agent: improved prompt + CoT + few-shot examples\n")

agent_config_v2 = {
    **agent_config_v1,
    "model": "gpt-4o",
    "temperature": 0.0,
    "system_prompt": (
        "You are a CPA-level QuickBooks automation agent. For every task:\n"
        "1. Identify the transaction type and affected accounts\n"
        "2. Verify debits = credits for any journal impact\n"
        "3. Check customer/vendor exists before referencing\n"
        "4. Flag anything that needs human review\n"
        "5. Return structured JSON matching the expected schema exactly\n"
        "Always follow GAAP. When uncertain, flag for review rather than guess."
    ),
    "few_shot_examples": True,
    "chain_of_thought": True,
    "tools": agent_config_v1["tools"] + [
        "quickbooks.validate_entry",
        "quickbooks.lookup_customer",
        "quickbooks.lookup_vendor",
    ],
    "guardrails": {
        "require_balanced_entries": True,
        "require_review_flag_on_ambiguous": True,
        "max_amount_without_approval": 10_000.00,
    },
}

client.config.set_custom_config(agent_config_v2)

v2 = client.versions.publish_minor(
    description="Improved: CoT prompting, few-shot, validation guardrails, 9 tools",
    custom_config=agent_config_v2,
)

print(f"  Published: {v2.version}")
print(f"  Changes: temp 0.1→0.0, CoT enabled, +3 validation tools, guardrails added")


# ─────────────────────────────────────────────────────────────
# Step 6: Re-evaluate with improved agent
# ─────────────────────────────────────────────────────────────

print(f"\n[6] Re-evaluate agent on same tasks ({v2.version})\n")


@client.observe(
    model="gpt-4o",
    tags=["quickbooks", "eval", "improved"],
    version=v2.version,
)
def evaluate_task_v2(task_input: dict) -> dict:
    task = task_input["task"]
    start = time.time()
    agent_output = simulate_agent_v2(task)
    latency = (time.time() - start) * 1000
    result = score_task(task, agent_output)
    result.latency_ms = latency
    return asdict(result)


v2_results: List[TaskResult] = []
for task in EVAL_TASKS:
    raw = evaluate_task_v2({"task": task, "version": v2.version})
    result = TaskResult(**{k: raw[k] for k in TaskResult.__dataclass_fields__})
    v2_results.append(result)

    icon = "PASS" if result.passed else "FAIL"
    print(f"  [{icon}] {result.task_id} {result.task_type:<22} "
          f"score={result.overall_score:.2f}  "
          f"acc={result.scores['accuracy']:.2f}  "
          f"fin={result.scores['financial_correctness']:.2f}  "
          f"comp={result.scores['compliance']:.2f}")
    if result.errors:
        for err in result.errors[:2]:
            print(f"         ^ {err}")

v2_pass_rate = sum(1 for r in v2_results if r.passed) / len(v2_results)
v2_avg_score = sum(r.overall_score for r in v2_results) / len(v2_results)
v2_avg_accuracy = sum(r.scores["accuracy"] for r in v2_results) / len(v2_results)
v2_avg_financial = sum(r.scores["financial_correctness"] for r in v2_results) / len(v2_results)

print(f"\n  {v2.version} Summary:")
print(f"    Pass rate:             {v2_pass_rate:.0%}")
print(f"    Avg overall score:     {v2_avg_score:.3f}")
print(f"    Avg accuracy:          {v2_avg_accuracy:.3f}")
print(f"    Avg financial correct: {v2_avg_financial:.3f}")

client.observe.log(
    input=json.dumps({"eval_run": "quickbooks_improved", "version": v2.version, "num_tasks": len(EVAL_TASKS)}),
    output=json.dumps({
        "pass_rate": v2_pass_rate,
        "avg_score": v2_avg_score,
        "avg_accuracy": v2_avg_accuracy,
        "avg_financial_correctness": v2_avg_financial,
    }),
    model="gpt-4o",
    version=v2.version,
    tags=["quickbooks", "eval", "summary"],
    custom_attributes={
        "pass_rate": v2_pass_rate,
        "avg_score": round(v2_avg_score, 4),
        "avg_accuracy": round(v2_avg_accuracy, 4),
        "avg_financial_correctness": round(v2_avg_financial, 4),
        "total_tasks": len(EVAL_TASKS),
        "passed_tasks": sum(1 for r in v2_results if r.passed),
        "failed_tasks": sum(1 for r in v2_results if not r.passed),
        "environment": "quickbooks_sandbox",
    },
)


# ─────────────────────────────────────────────────────────────
# Step 7: Side-by-side comparison
# ─────────────────────────────────────────────────────────────

print(f"\n[7] Version comparison: {v1.version} vs {v2.version}\n")

header = f"  {'Metric':<28} {v1.version:>10} {v2.version:>10}  {'Delta':>8}"
print(header)
print(f"  {'─' * 28} {'─' * 10} {'─' * 10}  {'─' * 8}")

def fmt_delta(old, new):
    d = new - old
    sign = "+" if d > 0 else ""
    return f"{sign}{d:.1%}" if abs(d) > 0.001 else "—"

rows = [
    ("Pass Rate", v1_pass_rate, v2_pass_rate),
    ("Avg Overall Score", v1_avg_score, v2_avg_score),
    ("Avg Accuracy", v1_avg_accuracy, v2_avg_accuracy),
    ("Avg Financial Correctness", v1_avg_financial, v2_avg_financial),
]
for label, old, new in rows:
    print(f"  {label:<28} {old:>9.1%} {new:>9.1%}  {fmt_delta(old, new):>8}")

v1_types = {}
v2_types = {}
for r in v1_results:
    v1_types.setdefault(r.task_type, []).append(r.overall_score)
for r in v2_results:
    v2_types.setdefault(r.task_type, []).append(r.overall_score)

print(f"\n  {'Task Type':<28} {v1.version:>10} {v2.version:>10}")
print(f"  {'─' * 28} {'─' * 10} {'─' * 10}")
for tt in sorted(set(list(v1_types.keys()) + list(v2_types.keys()))):
    s1 = sum(v1_types.get(tt, [0])) / max(len(v1_types.get(tt, [1])), 1)
    s2 = sum(v2_types.get(tt, [0])) / max(len(v2_types.get(tt, [1])), 1)
    print(f"  {tt:<28} {s1:>9.3f} {s2:>9.3f}")


# ─────────────────────────────────────────────────────────────
# Step 8: Regression gate
# ─────────────────────────────────────────────────────────────

print(f"\n[8] Deployment gate\n")

if v2_pass_rate >= v1_pass_rate and v2_avg_financial >= 0.75:
    print(f"  APPROVED — {v2.version} meets deployment criteria")
    print(f"    Pass rate:  {v2_pass_rate:.0%} >= {v1_pass_rate:.0%} (baseline)")
    print(f"    Financial:  {v2_avg_financial:.1%} >= 75% (floor)")
    print(f"  Agent config {v2.version} is now active")
else:
    print(f"  BLOCKED — {v2.version} regressed, rolling back to {v1.version}")
    try:
        client.versions.rollback(v1.version_id)
        print(f"  Rolled back to {v1.version}")
    except Exception:
        print(f"  (Rollback available in dashboard)")


# ─────────────────────────────────────────────────────────────
# Step 9: Version history
# ─────────────────────────────────────────────────────────────

print(f"\n[9] Version history\n")

versions = client.versions.list_versions()
for v in versions:
    print(f"  {v.version:<10} {v.status:<12} {v.description or ''}")


# ─────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 64)
print("  What this demo showed:")
print("=" * 64)
print("""
  A QuickBooks AI agent was evaluated on 8 real accounting tasks:
    - Invoice creation        - Expense categorization
    - Bank reconciliation     - Aging reports
    - Journal entries         - Vendor bills

  Each task was scored on 4 dimensions:
    - Accuracy (35%)          — correct accounts, entities, classifications
    - Completeness (20%)      — all required fields present
    - Financial correctness (30%) — amounts balance, totals match
    - Compliance (15%)        — GAAP rules, review flags, audit trail

  Trainly provided:
    1. Config versioning — agent prompt, model, tools stored per version
    2. @observe tracing  — every task attempt logged with full scoring
    3. Custom attributes — pass_rate, accuracy, financial_correctness
                           filterable in the dashboard
    4. Version comparison — side-by-side perf across agent versions
    5. Deployment gating — block releases that regress on key metrics

  This is the workflow for evaluating any AI agent on any SaaS
  environment — swap QuickBooks for Salesforce, Stripe, or HubSpot.
  Same pattern: define tasks, score outputs, version configs, gate deploys.
""")
