# fasr-asr-qwen3

基于 `qwen-asr` 的 Qwen3 语音识别模型插件，为 fasr 提供无时间戳 ASR 能力。

## 安装

```bash
pip install fasr-asr-qwen3
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `qwen3_0.6b` | `Qwen3_06BForASR` | `Qwen/Qwen3-ASR-0.6B` | Qwen3 小模型，当前不返回时间戳 |
| `qwen3_1.7b` | `Qwen3_17BForASR` | `Qwen/Qwen3-ASR-1.7B` | Qwen3 大模型，当前不返回时间戳 |

## 使用方式

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="fsmn")
    .add_pipe("recognizer", model="qwen3_1.7b")  # 或 qwen3_0.6b
    .add_pipe("sentencizer", model="ct_transformer")
)
```

## `from_checkpoint` 参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint_dir` | `str \| Path \| None` | `None`（自动下载） | 模型权重目录 |
| `device_map` | `str \| None` | `"auto"` | 设备映射，例如 `"cuda:0"` |
| `dtype` | `str \| torch.dtype \| None` | `"bfloat16"` | 推理精度，支持 `bfloat16/fp16/fp32` |
| `max_inference_batch_size` | `int` | `32` | 推理批次上限，避免 OOM |
| `max_new_tokens` | `int` | `1024` | 最大生成 token 数 |

其余 `**kwargs` 会透传到 `Qwen3ASRModel.from_pretrained(...)`。

## 输出说明

- 当前模型不返回词级/字级时间戳。
- fasr 中会把整段识别文本作为一个 `AudioToken` 返回。
