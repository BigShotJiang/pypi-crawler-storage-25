from __future__ import annotations

import json
from pathlib import Path


def test_plugin_manifests_reference_existing_repo_files() -> None:
    repo_root = Path(__file__).resolve().parents[1]

    codex_plugin_root = repo_root / "plugins" / "grados"
    codex_plugin = json.loads(
        (codex_plugin_root / ".codex-plugin" / "plugin.json").read_text(encoding="utf-8")
    )
    claude_plugin = json.loads((repo_root / ".claude-plugin" / "plugin.json").read_text(encoding="utf-8"))
    claude_marketplace = json.loads((repo_root / ".claude-plugin" / "marketplace.json").read_text(encoding="utf-8"))
    codex_marketplace = json.loads((repo_root / ".agents" / "plugins" / "marketplace.json").read_text(encoding="utf-8"))
    codex_plugin_mcp = json.loads((codex_plugin_root / "plugin.mcp.json").read_text(encoding="utf-8"))
    plugin_mcp = json.loads((repo_root / "plugin.mcp.json").read_text(encoding="utf-8"))
    repo_mcp = json.loads((repo_root / ".mcp.json").read_text(encoding="utf-8"))

    assert codex_plugin["name"] == "grados"
    assert codex_plugin["skills"] == "./skills/"
    assert codex_plugin["mcpServers"] == "./plugin.mcp.json"
    assert "evidence-grounded writing" in codex_plugin["description"]
    assert "manuscripts" in codex_plugin["interface"]["longDescription"]
    assert any("experiment or simulation protocol" in prompt for prompt in codex_plugin["interface"]["defaultPrompt"])
    assert (codex_plugin_root / codex_plugin["skills"][2:] / "grados" / "SKILL.md").is_file()
    assert (codex_plugin_root / codex_plugin["mcpServers"][2:]).is_file()

    assert claude_plugin["name"] == "grados"
    assert claude_plugin["mcpServers"] == "./plugin.mcp.json"

    assert claude_marketplace["name"] == "grados-plugins"
    assert claude_marketplace["plugins"][0]["name"] == "grados"
    assert claude_marketplace["plugins"][0]["source"] == "./"

    assert codex_marketplace["name"] == "grados-plugins"
    assert codex_marketplace["interface"]["displayName"] == "GRaDOS Plugins"
    assert codex_marketplace["plugins"][0]["name"] == "grados"
    assert codex_marketplace["plugins"][0]["source"]["source"] == "local"
    assert codex_marketplace["plugins"][0]["source"]["path"] == "./plugins/grados"
    bundled_plugin_root = repo_root / codex_marketplace["plugins"][0]["source"]["path"][2:]
    assert (bundled_plugin_root / ".codex-plugin" / "plugin.json").is_file()
    assert (bundled_plugin_root / "plugin.mcp.json").is_file()

    assert codex_plugin_mcp == plugin_mcp
    assert plugin_mcp["mcpServers"]["grados"]["args"] == ["grados"]
    assert repo_mcp["mcpServers"]["grados"]["args"] == ["grados"]

    canonical_skill_root = repo_root / "skills" / "grados"
    bundled_skill_root = codex_plugin_root / "skills" / "grados"
    mirrored_files = [
        "SKILL.md",
        "agents/openai.yaml",
        "references/external_synthesis.md",
        "references/indepth.md",
        "references/paper_writing.md",
        "references/tools.md",
        "references/writing_profiles/experimental_protocol.md",
        "references/writing_profiles/experiment_report.md",
        "references/writing_profiles/literature_review.md",
        "references/writing_profiles/manuscript.md",
        "references/domain_profiles/mechanics_elastic_metamaterials.md",
    ]
    for relative_path in mirrored_files:
        assert (
            (bundled_skill_root / relative_path).read_text(encoding="utf-8")
            == (canonical_skill_root / relative_path).read_text(encoding="utf-8")
        )

    tools_reference = (canonical_skill_root / "references" / "tools.md").read_text(encoding="utf-8")
    skill_text = (canonical_skill_root / "SKILL.md").read_text(encoding="utf-8")
    paper_writing_reference = (
        canonical_skill_root / "references" / "paper_writing.md"
    ).read_text(encoding="utf-8")
    external_synthesis_reference = (
        canonical_skill_root / "references" / "external_synthesis.md"
    ).read_text(encoding="utf-8")
    assert "`codex` is a disabled-by-default fetch-strategy entry" in tools_reference
    assert "ChatGPT Pro" not in skill_text
    assert "references/paper_writing.md" in skill_text
    assert "experimental protocols, research reports, manuscripts" in skill_text
    assert "references/external_synthesis.md" in skill_text
    assert "grados external-synthesis is-enabled --quiet" in skill_text
    assert "uvx grados external-synthesis is-enabled --quiet" in skill_text
    assert "grados external-synthesis status --json" not in skill_text
    assert "grados external-synthesis status --json" not in external_synthesis_reference
    assert "same `GRADOS_HOME` as the active server" in skill_text
    assert "exits with code 0" in external_synthesis_reference
    assert "`grados:run_external_synthesis`" in tools_reference
    assert "GRaDOS-validated Pro model route" in external_synthesis_reference
    assert "Pro Extended thinking route" in external_synthesis_reference
    assert "GRaDOS-native ChatGPT Pro browser mode" in external_synthesis_reference
    assert "private ChatGPT profile" in external_synthesis_reference
    assert 'kind="external_synthesis_packet"' in external_synthesis_reference
    assert "`run_external_synthesis`" in external_synthesis_reference
    assert "`save_external_synthesis_result`" in external_synthesis_reference
    assert "`audit_external_synthesis_result`" in external_synthesis_reference
    assert "PDF acquisition" in external_synthesis_reference
    assert "writing_profiles/experimental_protocol.md" in paper_writing_reference
    assert "writing_profiles/literature_review.md" in paper_writing_reference
    assert "writing_profiles/experiment_report.md" in paper_writing_reference
    assert "writing_profiles/manuscript.md" in paper_writing_reference
    assert "domain_profiles/mechanics_elastic_metamaterials.md" in paper_writing_reference
    assert "`validate_claim_matrix`" in paper_writing_reference
    assert "`prepare_claim_evidence_pack`" in paper_writing_reference
    assert "Docling -> MinerU -> PyMuPDF" in tools_reference
    assert "TDM -> OA -> Sci-Hub -> Headless" not in tools_reference
    assert "PyMuPDF -> Marker -> Docling" not in tools_reference
