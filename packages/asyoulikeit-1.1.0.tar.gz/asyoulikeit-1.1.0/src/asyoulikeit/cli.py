"""Report output decorator for Click commands.

Provides the :func:`report_output` decorator for commands that produce
formatted report output with support for multiple reports, format selection
(display/TSV/JSON), and column filtering.
"""

import functools
import os
import sys
from collections.abc import Container, Mapping
from dataclasses import replace
from types import EllipsisType
from typing import Callable, Iterable, Optional, Union

import click
from click_option_group import OptionGroup

from asyoulikeit.exceptions import ReportDeclarationError
from asyoulikeit.formatter import describe_formatter, formatter_names, format_as
from asyoulikeit.scalar_data import ScalarContent
from asyoulikeit.tabular_data import DetailLevel, Report, Reports, TableContent
from asyoulikeit.tree_data import TreeContent


# Environment variable consulted when ``--as`` is not given on the
# command line. Takes precedence over the TTY-based default so that
# test harnesses (where stdout is a captured buffer with isatty() ==
# False) can force a chosen format without touching every test, and
# so that users can set a default in their shell rc-file.
FORMAT_ENV_VAR = "ASYOULIKEIT_FORMAT"


class _UniversalContainer(Container):
    """A container that contains everything.

    This container responds True to all containment checks (`x in container`).
    Used in @report_output to represent "show all reports by default".

    Implements the collections.abc.Container protocol.
    """
    def __contains__(self, item):
        """Return True for all containment checks."""
        return True

    def __repr__(self):
        return "ALL_REPORTS"

    def __bool__(self):
        """Container is always truthy."""
        return True


# Module-level constant for "show all reports"
ALL_REPORTS = _UniversalContainer()

# Option group for tabulated output formatting options
REPORT_OUTPUT_GROUP = OptionGroup('Report Output Options')


def _warn(message: str) -> None:
    """Emit a warning to stderr in a distinctive color."""
    click.secho(message, fg="magenta", err=True)


def _validate_reports_declaration(
    reports: Mapping[Union[str, EllipsisType], str],
) -> None:
    """Validate the shape of a ``reports=`` mapping at decoration time.

    Each key must be either a valid Python identifier (same contract
    :class:`~asyoulikeit.Reports` enforces on construction) or
    ``Ellipsis`` (the "dynamic slot" sentinel). Anything else — a
    non-identifier string, an integer, a tuple — raises
    :exc:`~asyoulikeit.ReportDeclarationError` so the problem surfaces
    at import time, not on first invocation.
    """
    if not isinstance(reports, Mapping):
        raise ReportDeclarationError(
            f"reports= must be a mapping of name → description, not "
            f"{type(reports).__name__}"
        )
    for key, description in reports.items():
        if key is Ellipsis:
            continue
        if not isinstance(key, str):
            raise ReportDeclarationError(
                f"reports= keys must be strings or Ellipsis; got "
                f"{type(key).__name__} ({key!r})"
            )
        if not key.isidentifier():
            raise ReportDeclarationError(
                f"reports= key {key!r} must be a valid Python identifier "
                "(alphanumeric + underscore, not starting with digit). "
                "Use hyphens on the CLI (--report my-report) and identifiers "
                "here (reports={'my_report': ...}); asyoulikeit maps between "
                "the two automatically."
            )
        if not isinstance(description, str):
            raise ReportDeclarationError(
                f"reports={{{key!r}: ...}} description must be a string, "
                f"not {type(description).__name__}"
            )


def _validate_default_reports_against_declaration(
    default_reports, declared_static: frozenset[str]
) -> None:
    """Cross-check ``default_reports`` against the ``reports=`` declaration.

    Only runs when both are given explicitly and ``default_reports`` is
    an iterable of names (not ``ALL_REPORTS`` / ``None``). Catches the
    silent-typo case where ``default_reports=["summaryy"]`` would
    previously have produced an empty default set at runtime with no
    diagnostic.
    """
    if default_reports is ALL_REPORTS or default_reports is None:
        return
    missing = [
        name for name in default_reports if name not in declared_static
    ]
    if missing:
        raise ReportDeclarationError(
            f"default_reports entries not in the reports= declaration: "
            f"{', '.join(repr(n) for n in missing)}. Declared: "
            f"{', '.join(repr(n) for n in sorted(declared_static)) or '(none static)'}."
        )


def _normalise_report_arg(_ctx, _param, value):
    """Rewrite hyphens to underscores on ``--report`` values.

    CLI convention prefers ``--report monthly-sales``; Python identifiers
    forbid hyphens, so :class:`~asyoulikeit.Reports` keys come out as
    ``monthly_sales``. This callback normalises at the flag boundary so
    users get the CLI convention they expect and handlers keep clean
    identifiers. Applies unconditionally — even without a ``reports=``
    declaration — because a user typing a hyphenated name is always
    trying to reach the equivalent identifier.
    """
    if value is None:
        return value
    # ``multiple=True`` gives us a tuple; the option also accepts None.
    return tuple(v.replace("-", "_") for v in value)


def _build_reports_epilog(
    reports: Mapping[Union[str, EllipsisType], str],
) -> str:
    """Render the ``reports=`` declaration as a "Produces reports:" epilog.

    Static names first (sorted), then ``<dynamic>`` at the end if the
    declaration includes an ``Ellipsis`` slot. Column-aligned for
    readability in ``--help`` output.

    The leading ``\\b`` is Click's no-rewrap marker: without it, Click's
    help formatter collapses the multi-line table into a single flowed
    paragraph. Every rendered line in the block needs the marker at the
    start of its paragraph; a single block at the top suffices because
    we only emit one newline between entries (Click treats consecutive
    \\n-separated lines within the same paragraph as the one to preserve).
    """
    static_names = sorted(k for k in reports.keys() if isinstance(k, str))
    has_dynamic = Ellipsis in reports.keys()
    labels = static_names + (["<dynamic>"] if has_dynamic else [])
    name_width = max(len(label) for label in labels) if labels else 0
    # The "\b" tells Click not to rewrap the block when rendering --help.
    lines = ["\b", "Produces reports:"]
    for name in static_names:
        lines.append(f"  {name.ljust(name_width)}  {reports[name]}")
    if has_dynamic:
        lines.append(f"  {'<dynamic>'.ljust(name_width)}  {reports[Ellipsis]}")
    return "\n".join(lines)


class _ReportChoice(click.Choice):
    """``click.Choice`` variant that accepts hyphen-for-underscore aliases.

    Lets users type ``--report monthly-sales`` even when the declared
    name is ``monthly_sales``. Without this, ``click.Choice`` rejects
    the hyphenated form at parse time (before any callback runs).
    Normalising inside :meth:`convert` means the Choice matches either
    form and always returns the canonical identifier.
    """

    def convert(self, value, param, ctx):
        return super().convert(value.replace("-", "_"), param, ctx)


def _check_drift(
    reports_returned: Reports,
    declaration: Mapping[Union[str, EllipsisType], str],
    command_name: str,
) -> None:
    """Hard-fail if the handler returned a name not in the declaration.

    When a ``reports=`` declaration is present, every returned key must
    either match a declared static name or be admitted by the
    ``Ellipsis`` slot. Undeclared names raise — the refactor-renamed-
    a-report-and-nobody-noticed failure mode was the motivating bug
    behind the declaration feature.
    """
    declared_static = {k for k in declaration.keys() if isinstance(k, str)}
    accepts_dynamic = Ellipsis in declaration.keys()
    undeclared = [
        name for name in reports_returned.keys()
        if name not in declared_static
    ]
    if not undeclared:
        return
    if accepts_dynamic:
        return
    raise ReportDeclarationError(
        f"Command {command_name!r} returned undeclared "
        f"report{'s' if len(undeclared) > 1 else ''}: "
        f"{', '.join(repr(n) for n in undeclared)}. "
        f"Declared: {', '.join(repr(n) for n in sorted(declared_static)) or '(none static)'}. "
        "Add the name(s) to reports={...} or declare reports={..., Ellipsis: \"…\"} "
        "to accept dynamic names."
    )


def report_output(
    func: Callable = None,
    /,
    *,
    default_reports: Union[None, Iterable[str], _UniversalContainer] = ALL_REPORTS,
    reports: Optional[Mapping[Union[str, EllipsisType], str]] = None,
) -> Callable:
    """Decorator factory for commands that return tabular output.

    ``reports=`` is **required**: every ``@report_output`` command must
    declare which report names it produces, as a mapping of ``{name:
    description}``. Use ``Ellipsis`` as a key to declare "this command
    also produces dynamically-named reports" (e.g. one report per input
    file), or pass an empty dict for an action command that returns
    ``None``. There is no back-compat fallback; the declaration lets
    the library validate ``--report`` values, generate help, run drift
    detection, and power the sibling introspection commands.

    The decorated function should return:

    - :class:`Reports` — one or more named reports (each key must be
      declared in ``reports=`` or admitted by an ``Ellipsis`` slot).
    - ``None`` — silent success (nothing displayed).

    Args:
        func: The function to decorate (when used without parentheses
            a ``reports=`` kwarg must be supplied — otherwise the
            decoration raises :exc:`ReportDeclarationError`).
        default_reports: Which reports to show by default when no
            ``--report`` flags are specified. ``ALL_REPORTS`` (the
            default) shows every report; ``None`` shows nothing (silent
            action command); an iterable of names restricts the default
            to those names. Entries that aren't in ``reports=`` raise
            at decoration time.
        reports: Mapping of ``{name: description}`` declaring the
            report names this command produces. Keys must be valid
            Python identifiers; ``Ellipsis`` as a key declares the
            "dynamic slot" (names known only at runtime). The
            declaration drives decoration-time validation,
            ``--help`` generation, parse-time ``click.Choice`` on
            ``--report`` when fully static, and runtime drift detection
            at the return boundary — undeclared names (and no
            ``Ellipsis`` slot admitting them) raise
            :exc:`ReportDeclarationError`.

    Adds these CLI options:

    - ``--as`` — output format (display / tsv / json). Defaults to
      ``display`` for terminals, ``tsv`` for pipes.
    - ``--detailed`` / ``--essential`` — column inclusion override.
    - ``--header`` / ``--no-header`` — header override.
    - ``--report`` — filter which reports to display. Hyphens
      normalise to underscores (``--report monthly-sales`` resolves
      to ``monthly_sales``).
    - ``--no-reports`` — suppress all report rendering while still
      running the handler (useful for action commands whose reports
      are incidental confirmation).
    - ``--all-reports`` — render every report the handler returns,
      regardless of ``default_reports`` (useful for opting into the
      full picture on a command that's normally silent or narrow).

    The three selection flags (``--report``, ``--no-reports``,
    ``--all-reports``) are mutually exclusive — pick at most one.

    Header behaviour is format-specific: TSV prefixes the first header
    cell with ``#``, display omits title/caption when headers are off,
    JSON ignores the flag.

    Examples:
        ``@report_output(reports={"users": "The system's users."})`` — one static report.

        ``@report_output(reports={"overall": "…", Ellipsis: "…"})`` — mixed static + dynamic.

        ``@report_output(reports={Ellipsis: "One per input file."})`` — purely dynamic.

        ``@report_output(reports={}, default_reports=None)`` — silent action command.
    """
    # Decorator factory pattern: if called with parentheses, func is None.
    if func is None:
        return functools.partial(
            report_output,
            default_reports=default_reports,
            reports=reports,
        )

    # reports= is mandatory. The bare @report_output form (no
    # parentheses, no kwargs) reaches this branch with reports=None;
    # catch it here with a clear message rather than at first
    # invocation.
    if reports is None:
        raise ReportDeclarationError(
            f"@report_output requires a reports= declaration. "
            f"For command {func.__name__!r}, pass one of:\n"
            "  reports={'my_report': 'description'}          # one static report\n"
            "  reports={Ellipsis: 'One report per input.'}   # dynamic names\n"
            "  reports={}                                    # action command returning None"
        )

    _validate_reports_declaration(reports)
    declared_static = frozenset(
        k for k in reports.keys() if isinstance(k, str)
    )
    _validate_default_reports_against_declaration(
        default_reports, declared_static
    )
    accepts_dynamic_reports = Ellipsis in reports.keys()

    # Normalize to Container at decoration time for efficient runtime checking
    if default_reports is ALL_REPORTS:
        # Universal container - contains everything
        processed_default_reports = ALL_REPORTS
    elif default_reports is None:
        # Empty container - contains nothing (silent by default)
        processed_default_reports = frozenset()
    else:
        # Specific reports - frozenset of names
        processed_default_reports = frozenset(default_reports)

    def set_smart_default(ctx, param, value):
        """Resolve ``--as`` with this precedence, highest first:

        1. An explicit ``--as`` value on the command line.
        2. The ``ASYOULIKEIT_FORMAT`` environment variable.
        3. A TTY-sensing default: ``display`` when stdout is a terminal,
           ``tsv`` when it is a pipe.
        """
        if value is not None:
            return value
        env_value = os.environ.get(FORMAT_ENV_VAR)
        if env_value:
            valid = formatter_names()
            # Case-insensitive match, to mirror click.Choice(case_sensitive=False)
            # on the --as option itself.
            for name in valid:
                if name.lower() == env_value.lower():
                    return name
            raise click.BadParameter(
                f"{FORMAT_ENV_VAR}={env_value!r} is not a known format. "
                f"Available: {', '.join(sorted(valid))}.",
                ctx=ctx,
                param=param,
            )
        return "display" if sys.stdout.isatty() else "tsv"

    def map_detail_level(ctx, param, value):
        """Map tri-state boolean to DetailLevel enum."""
        if value is None:
            return DetailLevel.AUTO
        elif value:
            return DetailLevel.DETAILED
        else:
            return DetailLevel.ESSENTIAL

    # Build the --report option type. When the declaration is fully
    # static (no Ellipsis), use click.Choice so typos fail at parse
    # with a clean error listing valid names. A declaration with an
    # Ellipsis slot keeps the option un-Choiced so runtime-resolved
    # names pass through; an empty declaration (action command) also
    # stays un-Choiced since there are no valid values to enumerate.
    if not accepts_dynamic_reports and declared_static:
        report_type = _ReportChoice(sorted(declared_static))
        report_help = (
            "Report name(s) to display (can be specified multiple times). "
            "Shows all if omitted. Valid values: "
            f"{', '.join(sorted(declared_static))}."
        )
    else:
        report_type = None
        report_help = (
            "Report name(s) to display (can be specified multiple times). "
            "Shows all if omitted. Hyphens are normalised to underscores."
        )

    # Apply option group for tabulated output formatting
    decorated = REPORT_OUTPUT_GROUP.option(
        "--no-reports",
        "no_reports",
        is_flag=True,
        default=False,
        help="Suppress all report output. The handler still runs (useful "
             "for action commands whose reports are incidental); only "
             "rendering is skipped. Mutually exclusive with --report and "
             "--all-reports.",
    )(
        REPORT_OUTPUT_GROUP.option(
            "--all-reports",
            "all_reports",
            is_flag=True,
            default=False,
            help="Render every report the handler returns, regardless of "
                 "the command's default_reports. Useful for commands whose "
                 "default is a subset (or silent) but where you want the "
                 "full picture this time. Mutually exclusive with --report "
                 "and --no-reports.",
        )(
        REPORT_OUTPUT_GROUP.option(
            "--report",
            multiple=True,
            type=report_type,
            callback=_normalise_report_arg,
            help=report_help,
        )(
            REPORT_OUTPUT_GROUP.option(
                "--header/--no-header",
                "header",
                default=None,  # None means use report's default
                help="Include column headers in output. Overrides each report's default. "
                     "Format-specific: TSV prefixes first cell with '#', "
                     "display omits headers/title/caption, JSON ignores this flag.",
            )(
                REPORT_OUTPUT_GROUP.option(
                    "--detailed/--essential",
                    "detail_level",
                    default=None,
                    callback=map_detail_level,
                    help="Include detailed columns or only essential columns. "
                         "Auto-detects based on output format if not specified."
                )(
                    REPORT_OUTPUT_GROUP.option(
                        "--as",
                        "as_format",
                        type=click.Choice(formatter_names(), case_sensitive=False),
                        default=None,
                        callback=set_smart_default,
                        help="Output format for tabular data. Defaults to 'display' for terminals, 'tsv' for pipes.",
                    )(func)
                )
            )
        )
        )
    )

    # Wrap to consume format parameters and handle output
    @functools.wraps(decorated)
    def wrapper(
        *args, as_format, detail_level, header, report, no_reports,
        all_reports, **kwargs,
    ):
        # --report, --no-reports, and --all-reports are three different
        # ways to override the command's default report-selection
        # policy, and any combination of them is incoherent. Fail at
        # the boundary so the handler doesn't run with a contradictory
        # request.
        selection_flags_set = sum([bool(report), bool(no_reports), bool(all_reports)])
        if selection_flags_set > 1:
            raise click.UsageError(
                "--report, --no-reports, and --all-reports are mutually "
                "exclusive: pick at most one."
            )

        # Call handler without format parameters. This runs even when
        # --no-reports is set — the point of the flag is to let action
        # commands do their work without printing confirmation reports.
        result = func(*args, **kwargs)

        # Format and display if data returned
        if result is not None:
            # Result must be a Reports object
            if not isinstance(result, Reports):
                raise TypeError(
                    f"Command decorated with @report_output must return Reports or None, "
                    f"not {type(result).__name__}"
                )

            # Drift detection: any returned name that isn't in the
            # declared static set (and isn't admitted by an Ellipsis
            # slot) is a hard failure. Runs even under --no-reports so
            # a buggy return still surfaces in development.
            _check_drift(
                result,
                reports,
                command_name=(func.__name__ or "<anonymous>").replace("_", "-"),
            )

            # Rendering suppressed — we validated the shape but emit
            # nothing. Handler side effects have already happened.
            if no_reports:
                return

            # Determine which reports to show. Precedence, highest first:
            #   --report X (subset by name, any order)
            #   --all-reports (override default to include everything)
            #   default_reports (the per-command default set at decoration)
            if report:
                report_names_to_show = report
            elif all_reports:
                # Show every report the handler returned, regardless of
                # the command's default_reports policy — the flag's
                # whole purpose is to override it.
                report_names_to_show = list(result.keys())
            else:
                # Filter by containment check - works for all three cases:
                # - ALL_REPORTS (universal container): all names pass
                # - frozenset(): no names pass (silent)
                # - frozenset({...}): only specified names pass
                report_names_to_show = [
                    name for name in result.keys()
                    if name in processed_default_reports
                ]

            # Early exit if nothing to show
            if not report_names_to_show:
                if report:
                    # User explicitly requested reports that don't exist
                    _warn(
                        f"No reports matched the requested names: {', '.join(report)}. "
                        f"Available: {', '.join(result.keys())}"
                    )
                # Silent exit (no output)
                return

            # Filter to the selected report names (only include names that actually exist)
            filtered_dict = {name: result[name] for name in report_names_to_show if name in result}

            # Check if user requested reports that don't exist
            if report:
                requested_names = set(report)
                available_names = set(result.keys())
                missing_names = requested_names - available_names
                if missing_names:
                    _warn(
                        f"Report{'s' if len(missing_names) > 1 else ''} not available: {', '.join(sorted(missing_names))}. "
                        f"Available: {', '.join(sorted(available_names))}"
                    )

            # If nothing to show after filtering, exit silently
            if not filtered_dict:
                return

            reports_to_format = Reports(filtered_dict)

            # Apply CLI overrides to report preferences if flags were explicitly set
            if detail_level != DetailLevel.AUTO or header is not None:
                # Override each report's preferences with CLI flags
                overridden_dict = {}
                for name, rep in reports_to_format.items():
                    # Build kwargs for replace() based on which flags were set
                    overrides = {}
                    if detail_level != DetailLevel.AUTO:
                        overrides['detail_level'] = detail_level
                    if header is not None:
                        overrides['header'] = header

                    # Use dataclasses.replace to create modified Report
                    overridden_dict[name] = replace(rep, **overrides) if overrides else rep

                reports_to_format = Reports(overridden_dict)

            # Format and output
            output = format_as(reports_to_format, as_format)
            click.echo(output)

    # Attach the declaration to the wrapper so the introspection
    # factories can read it via a well-known attribute name once Click
    # wraps the function as a Command.
    wrapper._asyoulikeit_reports = reports

    # Extend the docstring with the "Produces reports:" section so it
    # appears in Click's --help output. Click only reads its `epilog`
    # from the @click.command() kwarg, which we can't set from inside
    # this decorator — the docstring is the one surface we can influence
    # that Click actually renders. Commands with reports={} (action
    # commands) get no block since there's nothing to list.
    if reports:
        epilog = _build_reports_epilog(reports)
        existing_doc = (wrapper.__doc__ or "").rstrip()
        wrapper.__doc__ = (
            f"{existing_doc}\n\n{epilog}\n" if existing_doc else f"{epilog}\n"
        )

    return wrapper


def list_formatters_command() -> click.Command:
    """Return a Click command that lists the available report-output formatters.

    The returned command is decorated with :func:`report_output` — so it
    inherits ``--as / --report / --header / --detailed`` and renders
    identically to any other asyoulikeit command. Its payload is a
    two-column :class:`~asyoulikeit.TableContent` (``Name``,
    ``Description``) with one row per registered formatter. The
    description is the formatter class's one-line summary (first
    non-empty line of its docstring).

    The host CLI adds it to its group under whatever name it prefers::

        cli.add_command(list_formatters_command(), name="list-formatters")

    Because ``formatter_names()`` is evaluated at factory-call time (not
    at import time), any formatter that was registered via entry point
    before the factory is called will appear in the listing and in
    ``--as``'s choices.
    """
    @click.command()
    @report_output(reports={
        "formatters": "Registered report-output formatters with one-line descriptions.",
    })
    def list_formatters():
        """List the available report output formatters."""
        table = (
            TableContent(title="Formatters for use with --as")
            .add_column("name", "Name")
            .add_column("description", "Description")
        )
        for name in sorted(formatter_names()):
            table.add_row(
                name=name,
                description=describe_formatter(name, single_line=True),
            )
        return Reports(formatters=Report(data=table))
    return list_formatters


def describe_formatter_command() -> click.Command:
    """Return a Click command that prints one formatter's full description.

    The returned command is decorated with :func:`report_output` and
    takes a single positional ``NAME`` argument restricted (via
    ``click.Choice``) to the set of currently-registered formatters.
    The payload is a :class:`~asyoulikeit.ScalarContent` whose
    ``value`` is the full cleaned docstring and whose ``title`` is the
    formatter name — so ``--as tsv`` yields the bare description
    (pipe-friendly), ``--as json`` yields
    ``{"metadata": {"title": "<name>"}, "value": "<desc>"}``, and
    ``--as display`` yields ``<name>: <desc>``.

    The host adds it under whatever name suits its CLI::

        cli.add_command(describe_formatter_command(), name="describe-formatter")
    """
    @click.command()
    @click.argument(
        "name",
        type=click.Choice(formatter_names(), case_sensitive=False),
    )
    @report_output(reports={
        "formatter": "The full description of one registered formatter.",
    })
    def describe(name: str):
        """Describe a specific report output formatter."""
        return Reports(formatter=Report(data=ScalarContent(
            value=describe_formatter(name),
            title=name,
        )))
    return describe


# -- report introspection (issue #7) ------------------------------------------

def _walk_commands(group: click.Group, prefix: tuple = ()) -> Iterable[tuple]:
    """Yield ``(path_tuple, name, click.Command)`` for every leaf command under ``group``.

    Walks nested :class:`click.Group` instances recursively. Skips the
    introspection commands themselves (``list-reports`` /
    ``describe-report``) so they don't appear in their own listings —
    self-description is noise, not signal.
    """
    for name, cmd in group.commands.items():
        if isinstance(cmd, click.Group):
            yield from _walk_commands(cmd, prefix + (name,))
            continue
        if getattr(cmd.callback, "_asyoulikeit_introspection", False):
            continue
        yield prefix + (name,), name, cmd


def _declared_reports(cmd: click.Command) -> Optional[Mapping]:
    """Return the ``reports=`` declaration on ``cmd``, or ``None`` if none.

    Commands decorated with :func:`report_output` carry their declaration
    (if any) on the wrapper via ``_asyoulikeit_reports``. A command that
    wasn't decorated at all, or was decorated without ``reports=``,
    yields ``None`` — treated as "no declared reports" by the
    introspection commands.
    """
    callback = getattr(cmd, "callback", None)
    return getattr(callback, "_asyoulikeit_reports", None)


def list_reports_command() -> click.Command:
    """Return a Click command that lists declared reports across the CLI.

    Mirrors :func:`list_formatters_command`: the returned command is
    itself decorated with ``@report_output``, so it inherits
    ``--as / --report / --header / --detailed`` and renders in any
    format. The payload is a :class:`~asyoulikeit.TreeContent` with one
    root node per ``@report_output`` command discovered under the root
    Click group and children for each declared report (name +
    description). Because ``reports=`` is required on every
    ``@report_output`` command, every discovered report-output command
    shows its declared names; a group may also contain plain
    ``@click.command`` commands that aren't asyoulikeit-aware, and
    those surface with a single ``<not a report-output command>``
    marker child. Action commands declared with ``reports={}`` show
    ``<no reports>``.

    The host CLI adds it under whatever name suits it::

        cli.add_command(list_reports_command(), name="list-reports")

    Usage::

        mytool list-reports                # every command + its reports
        mytool list-reports video-audit    # one command only

    The command walks ``click.get_current_context().find_root()`` at
    invoke time, so it sees every command the host has added before
    invocation — no per-command wiring required.
    """
    @click.command()
    @click.argument("command", required=False)
    @report_output(reports={
        "reports": "Hierarchical listing of CLI commands and their declared reports.",
    })
    def list_reports(command: Optional[str]) -> Reports:
        """List every ``@report_output`` command in this CLI with its declared reports."""
        root = click.get_current_context().find_root().command
        if not isinstance(root, click.Group):
            # This is a wiring mistake by the CLI author, not something
            # an end user can fix — raise a real exception so the
            # traceback surfaces during development, instead of Click's
            # polite UsageError banner.
            raise TypeError(
                "list_reports_command() must be attached to a click.Group; "
                f"got {type(root).__name__}. Use cli.add_command(list_reports_command(), "
                "name='list-reports') where cli is a @click.group()."
            )

        tree = (
            TreeContent(
                title="Reports",
                description="Commands and the reports they produce.",
            )
            .add_column("name", "Name", header=True)
            .add_column("description", "Description")
        )

        for path, _leaf_name, cmd in _walk_commands(root):
            display_name = " ".join(path)
            if command is not None and display_name != command:
                continue
            short_help = (cmd.get_short_help_str() or "").strip() or "(no description)"
            root_node = tree.add_root(name=display_name, description=short_help)
            declaration = _declared_reports(cmd)
            if declaration is None:
                # Command wasn't decorated with @report_output at all
                # (e.g. a plain @click.command that the host added to
                # the same group). Surface it so authors can see which
                # of their commands sit outside asyoulikeit.
                root_node.add_child(
                    name="<not a report-output command>",
                    description="(command is not decorated with @report_output)",
                )
                continue
            if not declaration:
                root_node.add_child(
                    name="<no reports>",
                    description="(action command — returns None)",
                )
                continue
            static_names = sorted(
                k for k in declaration.keys() if isinstance(k, str)
            )
            for rep_name in static_names:
                root_node.add_child(name=rep_name, description=declaration[rep_name])
            if Ellipsis in declaration.keys():
                root_node.add_child(name="<dynamic>", description=declaration[Ellipsis])

        if command is not None and not list(tree.roots):
            raise click.UsageError(
                f"No command named {command!r} in this CLI."
            )

        return Reports(reports=Report(data=tree))

    # Mark the callback (not the Command) so _walk_commands can skip
    # this command when it's listing reports — we check the attribute
    # at cmd.callback to stay consistent with how _declared_reports
    # reads _asyoulikeit_reports from the callback.
    list_reports.callback._asyoulikeit_introspection = True
    return list_reports


def describe_report_command() -> click.Command:
    """Return a Click command that prints one declared report's description.

    Takes two positionals — ``<command>`` and ``<report>`` — and surfaces
    the description the command declared for that report via
    ``reports={...}``. Payload is a :class:`~asyoulikeit.ScalarContent`
    whose ``title`` is ``command.report`` and whose ``value`` is the
    declared description, so ``--as tsv`` yields the bare text (pipe-
    friendly), ``--as json`` gives ``metadata.title`` + ``value``, and
    ``--as display`` yields ``command.report: <description>``.

    An ``<dynamic>`` report name works: it surfaces the description
    attached to the ``Ellipsis`` slot of the command's declaration.

    The host CLI adds it under whatever name it prefers::

        cli.add_command(describe_report_command(), name="describe-report")
    """
    # ``report`` as a positional-argument name would collide with the
    # ``--report`` option that ``@report_output`` adds: Click raises
    # "Value must be an iterable" when the option parser finds two
    # sinks claiming the name. ``report_name`` keeps them distinct.
    @click.command()
    @click.argument("command")
    @click.argument("report_name", metavar="REPORT")
    @report_output(reports={
        "description": "The declared description of one report.",
    })
    def describe_report(command: str, report_name: str) -> Reports:
        """Describe a specific declared report."""
        root = click.get_current_context().find_root().command
        if not isinstance(root, click.Group):
            # Wiring mistake by the CLI author — see list_reports_command().
            raise TypeError(
                "describe_report_command() must be attached to a click.Group; "
                f"got {type(root).__name__}. Use cli.add_command(describe_report_command(), "
                "name='describe-report') where cli is a @click.group()."
            )

        # Find the target command by its displayed path.
        target = None
        for path, _leaf_name, cmd in _walk_commands(root):
            if " ".join(path) == command:
                target = cmd
                break
        if target is None:
            raise click.UsageError(f"No command named {command!r} in this CLI.")

        declaration = _declared_reports(target)
        if declaration is None:
            raise click.UsageError(
                f"Command {command!r} has no reports= declaration."
            )

        # Normalise the user-supplied report name: hyphens → underscores,
        # and the literal "<dynamic>" resolves to the Ellipsis slot.
        lookup_name = report_name.replace("-", "_")
        if lookup_name == "_dynamic_" or report_name == "<dynamic>":
            if Ellipsis not in declaration.keys():
                raise click.UsageError(
                    f"Command {command!r} has no dynamic (Ellipsis) report slot."
                )
            description = declaration[Ellipsis]
            title = f"{command}.<dynamic>"
        else:
            if lookup_name not in declaration.keys():
                declared = ", ".join(
                    repr(k) for k in sorted(
                        k for k in declaration.keys() if isinstance(k, str)
                    )
                ) or "(none static)"
                raise click.UsageError(
                    f"Command {command!r} does not declare a report named "
                    f"{report_name!r}. Declared: {declared}"
                    f"{'; <dynamic>' if Ellipsis in declaration.keys() else ''}."
                )
            description = declaration[lookup_name]
            title = f"{command}.{lookup_name}"

        return Reports(description=Report(data=ScalarContent(
            value=description,
            title=title,
        )))

    describe_report.callback._asyoulikeit_introspection = True
    return describe_report
