import numpy as np

import hll_rust_py


def test_extend_and_count():
    hll = hll_rust_py.PyHLL()
    hll.extend(np.arange(10000, dtype=np.uint64) // 3)

    estimate = hll.count()
    expected = 3334

    assert  0.99 * expected <= estimate <= 1.01 * expected


def test_extend_twice_and_count():
    hll = hll_rust_py.PyHLL()
    hll.extend(np.arange(10000, dtype=np.uint64) // 3)
    hll.extend(123456789 + np.arange(10000, dtype=np.uint64) // 3)

    estimate = hll.count()
    expected = 2 * 3334

    assert 0.99 * expected <= estimate <= 1.01 * expected
