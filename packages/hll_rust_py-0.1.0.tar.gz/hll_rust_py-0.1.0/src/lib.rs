use hyperloglockless::HyperLogLog;
use numpy::PyReadonlyArray1;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyModule;

#[pyclass]
struct PyHLL {
    hll: HyperLogLog,
}

impl PyHLL {
    fn extend_slice(&mut self, values: &[u64]) {
        self.hll.extend(values.iter().copied());
    }
}

#[pymethods]
impl PyHLL {
    #[new]
    #[pyo3(signature = (precision=16))]
    fn new(precision: usize) -> PyResult<Self> {
        let precision = u8::try_from(precision)
            .map_err(|_| PyValueError::new_err("precision must fit in u8 (0..=255)"))?;
        Ok(Self {
            hll: HyperLogLog::new(precision),
        })
    }

    fn insert(&mut self, value: u64) {
        self.hll.insert(&value);
    }

    fn extend<'py>(&mut self, arr: PyReadonlyArray1<'py, u64>) -> PyResult<()> {
        let slice = arr
            .as_slice()
            .map_err(|_| PyValueError::new_err("extend expects a contiguous np.uint64 array"))?;
        self.extend_slice(slice);
        Ok(())
    }

    fn count(&self) -> usize {
        self.hll.count()
    }
}

#[pymodule]
fn hll_rust_py(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyHLL>()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::PyHLL;

    #[test]
    fn add_and_count_single_value() {
        let mut hll = PyHLL::new(16).unwrap();
        hll.insert(42);
        hll.insert(42);
        let estimate = hll.count();
        assert!(estimate == 1);
    }

    #[test]
    fn extend_counts_unique_values() {
        let mut hll = PyHLL::new(16).unwrap();
        let values: Vec<u64> = (0..1_000).collect();
        hll.extend_slice(&values);
        let estimate = hll.count();
        assert!(estimate >= 990 && estimate <= 1010);
    }
}
