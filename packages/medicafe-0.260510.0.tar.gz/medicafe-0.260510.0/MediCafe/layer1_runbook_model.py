# -*- coding: utf-8 -*-
"""Shared Layer 1 embedded runbook decision model.

This module is intentionally pure and XP-compatible. It does not launch
subprocesses or send bundles; callers use the returned action/status to choose
an existing remediation path.
"""
from __future__ import print_function

import hashlib


RUNBOOK_STATUS_NO_ACTION = "no_action"
RUNBOOK_STATUS_ACTION_READY = "action_ready"
RUNBOOK_STATUS_OBSERVE = "observe"

RUNBOOK_KEY_NONE = ""
RUNBOOK_KEY_PHASE_C_MANIFEST_PENDING = "phase_c_manifest_pending"
RUNBOOK_KEY_PHASE_C_INGEST_FAILURE = "phase_c_ingest_failure"
RUNBOOK_KEY_PHASE_D_DAT_SMOKE_NEEDED = "phase_d_dat_smoke_needed"
RUNBOOK_KEY_PHASE_D_DAT_QA_FULL_BLOCK_CURRENT = "phase_d_dat_qa_full_block_current"
RUNBOOK_KEY_PHASE_D_DAT_QA_FULL_BLOCK_STALE = "phase_d_dat_qa_full_block_stale_diagnostics"
RUNBOOK_KEY_PHASE_D_INVALID_EXTERNAL_ID = "phase_d_invalid_external_patient_id_pressure"
RUNBOOK_KEY_LAYER1_HISTORICAL_DEBUG_ONLY = "layer1_historical_debug_only"
RUNBOOK_KEY_LAYER1_READY_PARTIAL_DAT_ONLY = "layer1_ready_partial_dat_only"

ACTION_NONE = ""
ACTION_RESOLVE_LAYER1_UPSTREAM = "resolve_layer1_upstream_blocker"
ACTION_PHASE_D_DAT_SMOKE = "phase_d_dat_smoke"
ACTION_REVIEW_DAT_QA_FULL_BLOCK = "review_dat_qa_full_block"
ACTION_PHASE_D_DAT_VERIFICATION_RERUN = "phase_d_dat_verification_rerun"
ACTION_SEND_BUNDLE = "send_bundle"

EVIDENCE_STATUS_STALE_DAT_RESOLUTION = "stale_pre_resolution_diagnostics"
EVIDENCE_STATUS_CURRENT_DAT_RESOLUTION = "current_resolution_diagnostics_present"


def _safe_str(value):
    if value is None:
        return ""
    return str(value).strip()


def _safe_int(value, default=0):
    try:
        if value is None or value == "":
            return default
        return int(value)
    except Exception:
        return default


def _dict(value):
    return value if isinstance(value, dict) else {}


def _first_str(*values):
    for value in values:
        text = _safe_str(value)
        if text:
            return text
    return ""


def _dat_telemetry_from_state(diagnostics_state):
    st = _dict(diagnostics_state)
    tel = st.get("last_phase_d_dat_telemetry")
    return tel if isinstance(tel, dict) else {}


def _dat_full_block(diagnostics_state, phase_d_remediation):
    rem = _dict(phase_d_remediation)
    issue = _safe_str(rem.get("issue_code")).upper()
    status = _safe_str(rem.get("status")).lower()
    if issue == "PHASE_D_DAT_QA_FULL_BLOCK" and status in ("", "active", "blocked"):
        return True
    tel = _dat_telemetry_from_state(diagnostics_state)
    selected = _safe_int(tel.get("dat_selected_count"), 0)
    qa_pass = _safe_int(tel.get("dat_qa_pass_count"), 0)
    qa_reject = _safe_int(tel.get("dat_qa_reject_count"), 0)
    return bool(selected > 0 and qa_pass == 0 and qa_reject > 0)


def _invalid_external_pressure(diagnostics_state, phase_d_remediation):
    rem = _dict(phase_d_remediation)
    for key in ("invalid_external_id_count", "invalid_external_patient_id_count"):
        n = _safe_int(rem.get(key), 0)
        if n > 0:
            return n
    st = _dict(diagnostics_state)
    counts = st.get("last_phase_d_constraint_skip_counts")
    if isinstance(counts, dict):
        n2 = _safe_int(counts.get("patient_invalid_external_id"), 0)
        if n2 > 0:
            return n2
    join = st.get("last_phase_d_dat_csv_join_telemetry")
    if isinstance(join, dict):
        return _safe_int(join.get("invalid_external_id_join_block_count"), 0)
    return 0


def _fingerprint(parts):
    joined = "|".join([_safe_str(p) for p in parts])
    try:
        return hashlib.sha1(joined.encode("utf-8")).hexdigest()
    except Exception:
        return hashlib.sha1(joined).hexdigest()


def _base_decision(layer1_model, diagnostics_state, run_cursor, evidence_scope, app_version):
    lm = _dict(layer1_model)
    st = _dict(diagnostics_state)
    cr = _dict(run_cursor)
    scope = _dict(evidence_scope)
    phase_d_run = _first_str(
        scope.get("phase_d_artifact_run_id"),
        lm.get("layer1_current_run_id"),
        st.get("last_phase_d_run_id"),
        cr.get("last_phase_d_run_id"),
    )
    anchor_run = _first_str(
        scope.get("anchor_run_id"),
        st.get("last_shadow_pipeline_run_id"),
        cr.get("last_shadow_pipeline_run_id"),
        phase_d_run,
    )
    rem = st.get("phase_d_remediation")
    if not isinstance(rem, dict):
        rem = cr.get("phase_d_remediation")
    rem = _dict(rem)
    issue = _first_str(rem.get("issue_code"), scope.get("issue_code"))
    evidence_status = _safe_str(scope.get("dat_payer_resolution_evidence_status"))
    return lm, st, cr, scope, rem, {
        "layer1_runbook_key": RUNBOOK_KEY_NONE,
        "layer1_runbook_status": RUNBOOK_STATUS_NO_ACTION,
        "layer1_runbook_action_kind": ACTION_NONE,
        "layer1_runbook_target_anchor_run_id": anchor_run,
        "layer1_runbook_target_phase_d_run_id": phase_d_run,
        "layer1_runbook_issue_code": issue,
        "layer1_runbook_evidence_status": evidence_status,
        "layer1_runbook_blocker_class": "",
        "layer1_runbook_reason_lines": [],
        "layer1_runbook_loop_policy": "fingerprint_suppressed_until_context_changes",
        "layer1_runbook_fingerprint": "",
    }


def build_layer1_runbook_model(layer1_model=None, diagnostics_state=None, run_cursor=None,
                               evidence_scope=None, app_version=""):
    """Return a normalized Layer 1 runbook decision for existing automation tools."""
    lm, st, cr, scope, rem, out = _base_decision(
        layer1_model, diagnostics_state, run_cursor, evidence_scope, app_version)
    l1_status = _safe_str(lm.get("layer1_readiness_status"))
    l1_blocker = _safe_str(lm.get("layer1_current_blocker"))
    blocked_at = _safe_str(lm.get("layer1_blocked_at_phase")).upper()
    data_status = _safe_str(lm.get("layer1_data_status"))
    evidence_status = _safe_str(out.get("layer1_runbook_evidence_status"))
    full_block = _dat_full_block(st, rem)
    invalid_pressure = _invalid_external_pressure(st, rem)

    if evidence_status == EVIDENCE_STATUS_STALE_DAT_RESOLUTION and full_block:
        out["layer1_runbook_key"] = RUNBOOK_KEY_PHASE_D_DAT_QA_FULL_BLOCK_STALE
        out["layer1_runbook_status"] = RUNBOOK_STATUS_ACTION_READY
        out["layer1_runbook_action_kind"] = ACTION_PHASE_D_DAT_VERIFICATION_RERUN
        out["layer1_runbook_blocker_class"] = "phase_d_dat_qa_full_block_stale_diagnostics"
        out["layer1_runbook_reason_lines"] = [
            "DAT QA full-block evidence predates current payer-resolution diagnostics.",
            "Run focused Phase D DAT verification before promoting the old reject mix as current guidance.",
        ]
    elif bool(lm.get("historical_layer1_debug_only")):
        out["layer1_runbook_key"] = RUNBOOK_KEY_LAYER1_HISTORICAL_DEBUG_ONLY
        out["layer1_runbook_status"] = RUNBOOK_STATUS_ACTION_READY
        out["layer1_runbook_action_kind"] = ACTION_PHASE_D_DAT_VERIFICATION_RERUN
        out["layer1_runbook_blocker_class"] = "layer1_historical_debug_only"
        out["layer1_runbook_reason_lines"] = [
            "Layer 1 debug evidence is not aligned to the current Phase D run.",
            "Refresh Phase D DAT verification so the operator pack uses current Layer 1 evidence.",
        ]
    elif blocked_at == "C" or l1_blocker.startswith("phase_c_"):
        out["layer1_runbook_key"] = (
            RUNBOOK_KEY_PHASE_C_MANIFEST_PENDING
            if "manifest" in l1_blocker else RUNBOOK_KEY_PHASE_C_INGEST_FAILURE)
        out["layer1_runbook_status"] = RUNBOOK_STATUS_ACTION_READY
        out["layer1_runbook_action_kind"] = ACTION_RESOLVE_LAYER1_UPSTREAM
        out["layer1_runbook_blocker_class"] = l1_blocker
        out["layer1_runbook_reason_lines"] = [
            _first_str(lm.get("next_operator_action"), "Resolve Phase C before Layer 1 diagnosis.")
        ]
    elif _safe_int(lm.get("phase_d_selected_rows"), 0) == 0 and l1_blocker == "phase_d_zero_selection":
        out["layer1_runbook_key"] = RUNBOOK_KEY_PHASE_D_DAT_SMOKE_NEEDED
        out["layer1_runbook_status"] = RUNBOOK_STATUS_ACTION_READY
        out["layer1_runbook_action_kind"] = ACTION_PHASE_D_DAT_SMOKE
        out["layer1_runbook_blocker_class"] = l1_blocker
        out["layer1_runbook_reason_lines"] = [
            "DAT was discovered but Phase D selected zero DAT rows; run DAT smoke for focused lane verification."
        ]
    elif full_block:
        out["layer1_runbook_key"] = RUNBOOK_KEY_PHASE_D_DAT_QA_FULL_BLOCK_CURRENT
        out["layer1_runbook_status"] = RUNBOOK_STATUS_ACTION_READY
        out["layer1_runbook_action_kind"] = ACTION_REVIEW_DAT_QA_FULL_BLOCK
        out["layer1_runbook_blocker_class"] = "phase_d_dat_qa_full_block"
        out["layer1_runbook_reason_lines"] = [
            "Phase D selected DAT rows, but DAT QA pass count is zero.",
        ]
    elif invalid_pressure > 0:
        out["layer1_runbook_key"] = RUNBOOK_KEY_PHASE_D_INVALID_EXTERNAL_ID
        out["layer1_runbook_status"] = RUNBOOK_STATUS_OBSERVE
        out["layer1_runbook_action_kind"] = ACTION_SEND_BUNDLE
        out["layer1_runbook_issue_code"] = _first_str(
            out.get("layer1_runbook_issue_code"), "PHASE_D_INVALID_EXTERNAL_ID_ELEVATED")
        out["layer1_runbook_blocker_class"] = "invalid_external_patient_id"
        out["layer1_runbook_reason_lines"] = [
            "Phase D still has invalid external patient ID pressure ({0}).".format(invalid_pressure)
        ]
    elif l1_status == "evaluated_ok" and data_status:
        out["layer1_runbook_key"] = RUNBOOK_KEY_LAYER1_READY_PARTIAL_DAT_ONLY
        out["layer1_runbook_status"] = RUNBOOK_STATUS_OBSERVE
        out["layer1_runbook_action_kind"] = ACTION_SEND_BUNDLE
        out["layer1_runbook_blocker_class"] = data_status
        out["layer1_runbook_reason_lines"] = [
            "Layer 1 evaluated; continue tracking data status {0}.".format(data_status)
        ]

    out["layer1_runbook_fingerprint"] = _fingerprint([
        out.get("layer1_runbook_key"),
        out.get("layer1_runbook_target_anchor_run_id"),
        out.get("layer1_runbook_target_phase_d_run_id"),
        st.get("last_manifest_sha256") or cr.get("last_manifest_sha256"),
        app_version,
        out.get("layer1_runbook_evidence_status"),
        out.get("layer1_runbook_issue_code"),
    ])
    return out


def shallow_layer1_runbook_meta(model):
    """Return support-bundle meta keys for a runbook decision."""
    m = _dict(model)
    keys = (
        "layer1_runbook_key",
        "layer1_runbook_status",
        "layer1_runbook_action_kind",
        "layer1_runbook_target_anchor_run_id",
        "layer1_runbook_target_phase_d_run_id",
        "layer1_runbook_issue_code",
        "layer1_runbook_evidence_status",
        "layer1_runbook_blocker_class",
        "layer1_runbook_fingerprint",
        "layer1_runbook_loop_policy",
    )
    out = {}
    for key in keys:
        out[key] = m.get(key, "")
    return out


def format_layer1_runbook_lines(model):
    """Render compact System Health Pack lines."""
    m = _dict(model)
    lines = [
        " - layer1_runbook_key={0}".format(_safe_str(m.get("layer1_runbook_key")) or "-"),
        " - layer1_runbook_status={0}".format(_safe_str(m.get("layer1_runbook_status")) or RUNBOOK_STATUS_NO_ACTION),
        " - layer1_runbook_action_kind={0}".format(_safe_str(m.get("layer1_runbook_action_kind")) or "-"),
        " - layer1_runbook_target_phase_d_run_id={0}".format(
            _safe_str(m.get("layer1_runbook_target_phase_d_run_id")) or "-"),
        " - layer1_runbook_evidence_status={0}".format(
            _safe_str(m.get("layer1_runbook_evidence_status")) or "-"),
    ]
    reasons = m.get("layer1_runbook_reason_lines")
    if isinstance(reasons, list):
        for line in reasons[:3]:
            text = _safe_str(line)
            if text:
                lines.append(" - layer1_runbook_reason={0}".format(text))
    return lines
