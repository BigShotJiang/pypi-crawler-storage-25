#!/usr/bin/env python
from __future__ import print_function

import os
import sys
import unittest
from io import StringIO

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


class SubmitSelectorTests(unittest.TestCase):
    def _rows(self, count=3):
        rows = []
        for i in range(count):
            rows.append({
                'patient_name': 'Patient {}'.format(i + 1),
                'patient_id': 'CH{:03d}'.format(i + 1),
                'payer_id': 'PAY{}'.format((i % 2) + 1),
                'dos': '2026-05-{:02d}'.format((i % 9) + 1),
                'first_seen_str': '2026-05-{:02d} 08:00'.format((i % 9) + 1),
                'latest_seen_str': '2026-05-{:02d} 09:00'.format((i % 9) + 1),
                'claim_key': 'ck-{}'.format(i + 1),
                'family_key': 'ch{:03d}|pay{}|2026-05-{:02d}'.format(
                    i + 1, (i % 2) + 1, (i % 9) + 1
                ),
            })
        return rows

    def test_selector_refresh_action(self):
        from MediLink import MediLink_UI as ui

        with patch.object(ui, 'get_user_choice', side_effect=['refresh']):
            result = ui.select_patients_from_consolidated_menu(self._rows(2), fallback_file_list=['a.dat'])
        self.assertEqual(result.get('action'), 'refresh')

    def test_selector_legacy_action_when_fallback_present(self):
        from MediLink import MediLink_UI as ui

        with patch.object(ui, 'get_user_choice', side_effect=['legacy']):
            result = ui.select_patients_from_consolidated_menu(self._rows(2), fallback_file_list=['a.dat'])
        self.assertEqual(result.get('action'), 'legacy')

    def test_selector_page_select_returns_selected_rows(self):
        from MediLink import MediLink_UI as ui

        rows = self._rows(3)
        # move to next page (page size 12 default; use filter to keep stable path via direct select)
        # choose row #1 from current page and confirm
        with patch.object(ui, 'get_user_choice', side_effect=['select']):
            with patch('builtins.input', side_effect=['1', 'y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('action'), 'selected')
        self.assertEqual(len(result.get('selected_rows') or []), 1)
        # Default sort is latest-first; row 1 maps to newest candidate.
        self.assertEqual(result['selected_rows'][0].get('claim_key'), 'ck-3')

    def test_selector_bare_row_number_selects_patient(self):
        from MediLink import MediLink_UI as ui

        rows = self._rows(3)
        with patch.object(ui, 'get_user_choice', side_effect=['1']):
            with patch('builtins.input', side_effect=['y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('action'), 'selected')
        self.assertEqual(len(result.get('selected_rows') or []), 1)
        self.assertEqual(result['selected_rows'][0].get('claim_key'), 'ck-3')

    def test_selector_bare_range_selects_page_rows(self):
        from MediLink import MediLink_UI as ui

        rows = self._rows(4)
        with patch.object(ui, 'get_user_choice', side_effect=['1-2']):
            with patch('builtins.input', side_effect=['y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('action'), 'selected')
        self.assertEqual(len(result.get('selected_rows') or []), 2)
        self.assertEqual(
            [r.get('claim_key') for r in result['selected_rows']],
            ['ck-4', 'ck-3']
        )

    def test_selector_normalizes_existing_endpoint_preview(self):
        from MediLink import MediLink_UI as ui

        row = self._rows(1)[0]
        row['suggested_endpoint'] = 'UHCAPI'
        norm = ui._normalize_submission_candidate_row(row)
        self.assertEqual(norm.get('_display_endpoint'), 'UHCAPI')

    def test_selector_endpoint_preview_uses_crosswalk_legacy_endpoint(self):
        from MediLink import MediLink_UI as ui

        row = self._rows(1)[0]
        row['payer_id'] = '87726'
        norm = ui._normalize_submission_candidate_row(
            row,
            config=None,
            crosswalk={'payer_id': {'87726': {'endpoint': 'OPTUMAI'}}},
        )
        self.assertEqual(norm.get('_display_endpoint'), 'OPTUMAI')

    def test_selector_table_shows_endpoint_column(self):
        from MediLink import MediLink_UI as ui

        fake_fin = {'remaining_amount_display': '$ 42.00', 'it_code_display': '12'}

        def _fake_get_patient_financial_display(*_a, **_k):
            return fake_fin

        with patch.object(ui, 'get_patient_financial_display', _fake_get_patient_financial_display):
            rows = [ui._normalize_submission_candidate_row(
                dict(
                    self._rows(1)[0],
                    suggested_endpoint='UHCAPI',
                    patid='CH001',
                ),
                config={'MediLink_Config': {'local_storage_path': '.'}},
                financial_display_for_compact=True,
            )]
        buf = StringIO()
        with patch('sys.stdout', buf):
            ui._print_consolidated_candidates_table(
                rows,
                title='Current Medisoft export',
                preamble_kind='current_export',
            )
        out = buf.getvalue()
        self.assertIn('Endpoint', out)
        self.assertIn('UHCAPI', out)
        self.assertIn('Rem Amt', out)
        self.assertIn('$ 42.00', out)

    def test_selector_compact_broad_preamble_shows_date_column(self):
        from MediLink import MediLink_UI as ui

        rows = [ui._normalize_submission_candidate_row(dict(
            self._rows(1)[0],
            suggested_endpoint='UHCAPI',
        ))]
        buf = StringIO()
        with patch('sys.stdout', buf):
            ui._print_consolidated_candidates_table(
                rows,
                title='Recent claim activity',
                preamble_kind='broad',
            )
        out = buf.getvalue()
        self.assertIn('Date', out)
        self.assertNotIn('Rem Amt', out)

    def test_is_current_export_submit_preamble(self):
        from MediLink import MediLink_UI as ui

        self.assertTrue(ui._is_current_export_submit_preamble('current_export'))
        self.assertTrue(ui._is_current_export_submit_preamble('current_export_enriched'))
        self.assertFalse(ui._is_current_export_submit_preamble('broad'))
        self.assertFalse(ui._is_current_export_submit_preamble(''))

    def test_submission_financial_patient_id_prefers_patid(self):
        from MediLink import MediLink_UI as ui

        self.assertEqual(
            ui._submission_financial_patient_id({'patid': 'P1', 'patient_id': 'P2'}),
            'P1',
        )
        self.assertEqual(
            ui._submission_financial_patient_id({'patient_id': 'P2'}),
            'P2',
        )

    def test_menu_hint_current_export_mentions_file_activity_date(self):
        from MediLink import MediLink_UI as ui

        buf = StringIO()
        with patch('sys.stdout', buf):
            with patch.object(ui, 'get_user_choice', side_effect=['help', '0']):
                ui.select_patients_from_consolidated_menu(
                    self._rows(1),
                    preamble_kind='current_export',
                )
        self.assertIn('file-activity date', buf.getvalue())

    def test_menu_hint_broad_uses_plain_date_filter_label(self):
        from MediLink import MediLink_UI as ui

        buf = StringIO()
        with patch('sys.stdout', buf):
            with patch.object(ui, 'get_user_choice', side_effect=['help', '0']):
                ui.select_patients_from_consolidated_menu(
                    self._rows(1),
                    preamble_kind='broad',
                )
        out = buf.getvalue()
        self.assertIn('fdate: date', out)
        self.assertNotIn('file-activity date', out)

    def test_selector_hides_shortcut_help_until_requested(self):
        from MediLink import MediLink_UI as ui

        buf = StringIO()
        with patch('sys.stdout', buf):
            with patch.object(ui, 'get_user_choice', side_effect=['0']):
                ui.select_patients_from_consolidated_menu(self._rows(1))
        out = buf.getvalue()
        self.assertIn('Press Enter to choose ALL patients', out)
        self.assertIn('Type help for more choices', out)
        self.assertNotIn('More choices:', out)
        self.assertNotIn('fdate:', out)

    def test_selector_table_shows_enriched_current_export_fields(self):
        from MediLink import MediLink_UI as ui

        rows = [ui._normalize_submission_candidate_row(dict(
            self._rows(1)[0],
            suggested_endpoint='UHCAPI',
            insurance_type='12',
            insurance_type_source='API',
            primary_procedure_code='66984',
            amount='123.45',
            duplicate_candidate=True,
        ))]
        rows[0]['_clm_state'] = 'Not Sent'
        rows[0]['_submit_advisory'] = 'No local submit'
        buf = StringIO()
        with patch('sys.stdout', buf):
            ui._print_consolidated_candidates_table(
                rows,
                title='Current Medisoft export',
                compact_mode=False,
                preamble_kind='current_export_enriched',
            )
        out = buf.getvalue()
        self.assertIn('Endpoint', out)
        self.assertIn('Ins', out)
        self.assertIn('Proc', out)
        self.assertIn('Dup', out)
        self.assertIn('UHCAPI', out)
        self.assertIn('66984', out)

    def test_selector_returns_parsed_payload_for_bare_row_selection(self):
        from MediLink import MediLink_UI as ui

        payload = {'patient_id': 'CH003', 'patient_name': 'Patient 3'}
        rows = self._rows(3)
        rows[2]['_parsed_patient_data'] = payload
        with patch.object(ui, 'get_user_choice', side_effect=['1']):
            with patch('builtins.input', side_effect=['y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('selected_patient_data'), [payload])

    def test_selector_all_returns_parsed_payloads(self):
        from MediLink import MediLink_UI as ui

        payload1 = {'patient_id': 'CH001'}
        payload2 = {'patient_id': 'CH002'}
        rows = self._rows(2)
        rows[0]['_parsed_patient_data'] = payload1
        rows[1]['_parsed_patient_data'] = payload2
        with patch.object(ui, 'get_user_choice', side_effect=['all']):
            with patch('builtins.input', side_effect=['y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('selected_patient_data'), [payload2, payload1])

    def test_selector_enter_defaults_to_all_filtered_rows(self):
        from MediLink import MediLink_UI as ui

        rows = self._rows(2)
        with patch.object(ui, 'get_user_choice', side_effect=['']):
            with patch('builtins.input', side_effect=['y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('action'), 'selected')
        self.assertEqual(
            [r.get('claim_key') for r in result.get('selected_rows') or []],
            ['ck-2', 'ck-1']
        )

    def test_selector_toggle_view_then_cancel(self):
        from MediLink import MediLink_UI as ui

        with patch.object(ui, 'get_user_choice', side_effect=['view', 'cancel']):
            result = ui.select_patients_from_consolidated_menu(self._rows(2), fallback_file_list=None)
        self.assertEqual(result.get('action'), 'cancel')

    def test_selector_uses_claim_key_patient_id_when_identity_sparse(self):
        from MediLink import MediLink_UI as ui

        rows = [{
            'claim_key': 'CH900|PAY1|2026-06-01|svc',
            'dos': '2026-06-01',
            'payer_id': 'PAY1',
            'first_seen_str': '2026-06-01 08:00',
            'latest_seen_str': '2026-06-01 08:00',
        }]
        with patch.object(ui, 'get_user_choice', side_effect=['select']):
            with patch('builtins.input', side_effect=['1', 'y']):
                result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=None)
        self.assertEqual(result.get('action'), 'selected')
        selected = result.get('selected_rows')[0]
        self.assertEqual(selected.get('_display_patient_id'), 'CH900')
        self.assertNotEqual(selected.get('_display_patient_name').lower(), 'unknown')

    def test_selector_falls_back_when_all_rows_non_actionable(self):
        from MediLink import MediLink_UI as ui

        rows = [{
            'dos': '',
            'payer_id': '',
            'first_seen_str': '',
            'latest_seen_str': '',
            'patient_name': '',
            'patient_id': '',
            'member_id': '',
            'claim_key': '',
        }]
        result = ui.select_patients_from_consolidated_menu(rows, fallback_file_list=['legacy.dat'])
        self.assertEqual(result.get('action'), 'legacy_unusable')

    def test_selector_broad_activity_action(self):
        from MediLink import MediLink_UI as ui

        with patch.object(ui, 'get_user_choice', side_effect=['broad']):
            result = ui.select_patients_from_consolidated_menu(
                self._rows(2),
                fallback_file_list=None,
                allow_broad_activity=True,
                broad_activity_available=True,
            )
        self.assertEqual(result.get('action'), 'broad_activity')

    def test_selector_final_rem_requires_confirm(self):
        from MediLink import MediLink_UI as ui

        def _attach_final(rows, config=None):
            for r in rows:
                r['_clm_state'] = 'Final'
                r['_clm_detail'] = 'Paid'
                r['_submit_advisory'] = 'Override'
            return rows

        with patch.object(ui, '_attach_lifecycle_fields_to_rows', side_effect=_attach_final):
            with patch.object(ui, 'get_user_choice', side_effect=['select']):
                with patch('builtins.input', side_effect=['1', 'y', 'CONFIRM']):
                    result = ui.select_patients_from_consolidated_menu(
                        self._rows(1),
                        config={'MediLink_Config': {}},
                    )
        self.assertEqual(result.get('action'), 'selected')

    def test_selector_declined_final_override_then_cancel(self):
        from MediLink import MediLink_UI as ui

        def _attach_final(rows, config=None):
            for r in rows:
                r['_clm_state'] = 'Final'
                r['_clm_detail'] = ''
                r['_submit_advisory'] = 'Override'
            return rows

        with patch.object(ui, '_attach_lifecycle_fields_to_rows', side_effect=_attach_final):
            with patch.object(ui, 'get_user_choice', side_effect=['select', 'cancel']):
                with patch('builtins.input', side_effect=['1', 'y', 'no']):
                    result = ui.select_patients_from_consolidated_menu(
                        self._rows(1),
                        config={'MediLink_Config': {}},
                    )
        self.assertEqual(result.get('action'), 'cancel')

    def test_lifecycle_context_built_once_per_menu(self):
        from MediLink import MediLink_UI as ui

        with patch('MediCafe.claim_lifecycle_display.build_claim_lifecycle_context') as mctx:
            with patch('MediCafe.claim_lifecycle_display.get_claim_lifecycle_display_for_row') as mrow:
                mrow.return_value = {'claim_state_display': 'Submitted', 'claim_substatus_display': 'x'}
                with patch.object(ui, 'get_user_choice', side_effect=['cancel']):
                    ui.select_patients_from_consolidated_menu(
                        self._rows(3),
                        config={'MediLink_Config': {}},
                    )
                self.assertEqual(mctx.call_count, 1)
                self.assertEqual(mrow.call_count, 3)


if __name__ == '__main__':
    unittest.main()

