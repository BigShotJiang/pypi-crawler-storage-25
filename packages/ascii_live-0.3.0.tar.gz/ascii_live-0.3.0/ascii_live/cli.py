import argparse
import sys
import os
from .downloader import get_video_source, extract_audio, is_url
from .player import play

def main():
    parser = argparse.ArgumentParser(
        description="ASCII Live: Play YouTube videos or local files in your terminal as ASCII art.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ascii-live "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  ascii-live my_video.mp4 --no-audio
  ascii-live "URL" --fps 15 --bw
  ascii-live "URL" --size 80x40
        """
    )

    parser.add_argument("path", nargs='?', help="YouTube URL or local video file path")
    parser.add_argument("--no-audio", action="store_true", help="Play video only, skip audio extraction/playback")
    parser.add_argument("--fps", type=float, help="Override video frame rate (defaults to video FPS)")
    parser.add_argument("--quality", choices=['worst', 'best'], default='worst', help="Download quality (worst/best, default: worst)")
    parser.add_argument("--size", help="Manual terminal size in chars (e.g. 120x40)")
    parser.add_argument("--bw", action="store_true", help="Play in monochrome (black & white) mode")
    parser.add_argument("--contri", action="store_true", help="Display proof of work / developer name")

    args = parser.parse_args()

    if args.contri:
        print("\n🌟 Developer / Proof of Work:")
        print("   Bhavya sharma")
        print("\nThank you for using ASCII Live!\n")
        sys.exit(0)

    if not args.path:
        parser.print_help()
        sys.exit(1)

    # Parse manual size if provided
    manual_size = None
    if args.size:
        try:
            w, h = map(int, args.size.lower().split('x'))
            manual_size = (w, h)
        except:
            print(f"Error: Invalid size format '{args.size}'. Use WxH (e.g., 80x40).")
            sys.exit(1)

    print(f"\n[ascii-live] Preparing source: {args.path}")
    
    video_path = get_video_source(args.path, args.quality)
    if not video_path:
        sys.exit(1)

    audio_path = None
    if not args.no_audio:
        audio_path = extract_audio(video_path)

    try:
        play(
            video_path=video_path,
            audio_path=audio_path,
            fps_override=args.fps,
            bw=args.bw,
            manual_size=manual_size
        )
    finally:
        # Cleanup temporary files if they were downloaded
        if is_url(args.path):
            for f in [video_path, audio_path]:
                if f and os.path.exists(f) and "ascii_live_" in f:
                    try:
                        os.remove(f)
                    except:
                        pass

if __name__ == "__main__":
    main()
