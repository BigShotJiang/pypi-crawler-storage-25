import os
import sys
import tempfile
import subprocess
import yt_dlp

def is_url(path):
    """Check if the path is a URL."""
    return path.startswith(('http://', 'https://', 'www.'))

def download_video(url, quality='worst'):
    """Download video from YouTube using yt_dlp."""
    temp_dir = tempfile.gettempdir()
    temp_video = os.path.join(temp_dir, "ascii_live_video.mp4")

    if os.path.exists(temp_video):
        try:
            os.remove(temp_video)
        except:
            pass

    # Basic quality selection
    fmt = 'worstvideo[ext=mp4]+bestaudio[ext=m4a]/worst[ext=mp4]/best'
    if quality == 'best':
        fmt = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'

    ydl_opts = {
        'format': fmt,
        'outtmpl': temp_video,
        'quiet': True,
        'no_warnings': True,
        'merge_output_format': 'mp4',
        'extractor_args': {'youtube': ['player_client=ios,tv', 'player_skip=webpage']}
    }

    print(f"  Downloading video ({quality})...")
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
    except Exception as e:
        print(f"Error downloading video: {e}")
        return None

    return temp_video

def extract_audio(video_path):
    """Extract audio track from the video file to a WAV temp file."""
    temp_dir = tempfile.gettempdir()
    temp_audio = os.path.join(temp_dir, "ascii_live_audio.wav")

    if os.path.exists(temp_audio):
        try:
            os.remove(temp_audio)
        except:
            pass

    # Check if ffmpeg is available
    try:
        subprocess.run(['ffmpeg', '-version'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        print("\n[!] Warning: 'ffmpeg' not found. Audio extraction skipped.")
        print("    Please install ffmpeg to enable audio playback.")
        return None

    result = subprocess.run(
        ['ffmpeg', '-y', '-i', video_path, '-vn',
         '-acodec', 'pcm_s16le', '-ar', '44100', '-ac', '2',
         temp_audio],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    
    if result.returncode != 0:
        return None
    return temp_audio

def get_video_source(path, quality='worst'):
    """Detect if path is URL or local file and return the video path."""
    if is_url(path):
        return download_video(path, quality)
    else:
        if os.path.exists(path):
            return path
        else:
            print(f"Error: File or URL not found: {path}")
            return None
