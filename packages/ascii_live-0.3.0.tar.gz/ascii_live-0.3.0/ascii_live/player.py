import cv2
import pygame
import time
import os
import sys
from .renderer import get_terminal_size, frame_to_ascii, draw_status_bar

def read_key():
    """Non-blocking key read."""
    if os.name == 'nt':
        import msvcrt
        if msvcrt.kbhit():
            ch = msvcrt.getch()
            if ch in (b'\xe0', b'\x00'):
                ch2 = msvcrt.getch()
                if ch2 == b'M': return 'RIGHT'
                if ch2 == b'K': return 'LEFT'
                return None
            key = ch.decode('utf-8', errors='ignore').lower()
            if key == ' ': return 'SPACE'
            if key == 'q': return 'QUIT'
        return None
    else:
        import select, tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            r, _, _ = select.select([sys.stdin], [], [], 0)
            if r:
                ch = sys.stdin.read(1)
                if ch == '\x1b':
                    r2, _, _ = select.select([sys.stdin], [], [], 0.05)
                    if r2:
                        seq = sys.stdin.read(2)
                        if seq == '[C': return 'RIGHT'
                        if seq == '[D': return 'LEFT'
                elif ch == ' ': return 'SPACE'
                elif ch.lower() == 'q': return 'QUIT'
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return None

def play(video_path, audio_path=None, fps_override=None, bw=False, manual_size=None):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Could not open video file {video_path}")
        return

    fps = fps_override if fps_override else (cap.get(cv2.CAP_PROP_FPS) or 30)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    frame_dur = 1.0 / fps
    seek_frames = int(fps * 10)

    has_audio = audio_path is not None and os.path.exists(audio_path)
    if has_audio:
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
        pygame.mixer.music.load(audio_path)
        pygame.mixer.music.play()

    if os.name == 'nt':
        os.system('color')
    os.system('cls' if os.name == 'nt' else 'clear')
    sys.stdout.write('\033[?25l')
    sys.stdout.flush()

    playback_start = time.time()
    frame_number = 0
    paused = False
    pause_time = 0.0
    pause_start = 0.0
    audio_seek_base = 0.0
    render_state = {'prev_quant': None}
    SYNC_THRESHOLD = 0.5

    try:
        while True:
            key = read_key()
            if key == 'QUIT':
                break
            elif key == 'SPACE':
                if not paused:
                    paused = True
                    pause_start = time.time()
                    if has_audio: pygame.mixer.music.pause()
                else:
                    paused = False
                    pause_time += time.time() - pause_start
                    if has_audio: pygame.mixer.music.unpause()
            elif key in ('LEFT', 'RIGHT') and not paused:
                delta = seek_frames if key == 'RIGHT' else -seek_frames
                frame_number = max(0, min(total_frames - 1, frame_number + delta))
                cap.set(cv2.CAP_PROP_POS_FRAMES, frame_number)
                playback_start = time.time() - frame_number * frame_dur + pause_time
                if has_audio:
                    seek_sec = frame_number / fps
                    audio_seek_base = seek_sec
                    pygame.mixer.music.play(start=seek_sec)

            if paused:
                if manual_size:
                    term_cols, term_rows = manual_size
                else:
                    term_cols, term_rows = get_terminal_size()
                draw_status_bar(term_cols, term_rows, frame_number, total_frames, fps, paused)
                sys.stdout.flush()
                time.sleep(0.05)
                continue

            if has_audio:
                audio_ms = pygame.mixer.music.get_pos()
                if audio_ms >= 0:
                    true_audio_sec = audio_seek_base + audio_ms / 1000.0
                    video_sec = frame_number / fps
                    drift = true_audio_sec - video_sec
                    if drift > SYNC_THRESHOLD:
                        target_frame = int(true_audio_sec * fps)
                        skip = target_frame - frame_number
                        if skip > 0:
                            for _ in range(skip): cap.grab()
                            frame_number = target_frame

            now = time.time() - playback_start + pause_time
            target = frame_number * frame_dur
            if now > target + frame_dur:
                skip = min(int((now - target) / frame_dur), 2)
                for _ in range(skip): cap.grab()
                frame_number += skip

            ret, frame = cap.read()
            if not ret: break

            if manual_size:
                term_cols, term_rows = manual_size
            else:
                new_size = get_terminal_size()
                term_cols, term_rows = new_size
                if new_size != render_state.get('last_size'):
                    render_state['prev_quant'] = None
                    render_state['last_size'] = new_size

            ascii_frame = frame_to_ascii(frame, term_cols, term_rows - 1, render_state, bw=bw)
            sys.stdout.buffer.write(ascii_frame.encode('utf-8', errors='replace'))
            sys.stdout.buffer.flush()
            draw_status_bar(term_cols, term_rows, frame_number, total_frames, fps, paused)
            sys.stdout.flush()

            frame_number += 1
            next_time = playback_start - pause_time + frame_number * frame_dur
            sleep_time = next_time - time.time()
            if sleep_time > 0: time.sleep(sleep_time)

    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write('\033[?25h')
        sys.stdout.flush()
        cap.release()
        if has_audio:
            pygame.mixer.music.stop()
            pygame.mixer.quit()
        os.system('cls' if os.name == 'nt' else 'clear')
        print("Playback stopped.")
