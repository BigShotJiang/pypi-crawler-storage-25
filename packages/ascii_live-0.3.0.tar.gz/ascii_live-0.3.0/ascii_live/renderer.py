import cv2
import numpy as np
import os
import sys

HALF_BLOCK = "▀"
RESET = "\033[0m"

def get_terminal_size():
    """Return (width, height) of the terminal in characters."""
    try:
        size = os.get_terminal_size()
        return size.columns, size.lines
    except:
        return 120, 40

def frame_to_ascii(frame, term_cols, term_rows, render_state, bw=False):
    """
    Optimized half-block renderer with support for color and B&W.
    """
    pixel_h = term_rows * 2
    pixel_w = term_cols

    # Prevent division by zero or invalid sizes
    if pixel_h <= 0 or pixel_w <= 0:
        return ""

    resized = cv2.resize(frame, (pixel_w, pixel_h), interpolation=cv2.INTER_NEAREST)

    if bw:
        # Grayscale mode using standard ASCII characters or intensity-based grey blocks
        gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
        chars = "@%#*+=-:. "
        
        # Simple character-based renderer (not half-block)
        # However, for consistency with half-block layout, let's use grayscale blocks
        quant = (gray.astype(np.uint16) >> 3 << 3).astype(np.uint8)
        
        # We still use half-block but with grayscale fg/bg
        top_gray = quant[0::2]
        bot_gray = quant[1::2]
        
        nrows = pixel_h // 2
        out_parts = []
        
        for row in range(nrows):
            out_parts.append(f"\033[{row + 1};1H")
            tr_row = top_gray[row]
            br_row = bot_gray[row]
            
            cur_fg = -1
            cur_bg = -1
            cells = []
            for c in range(pixel_w):
                fg = tr_row[c]
                bg = br_row[c]
                code = ""
                if fg != cur_fg:
                    code = f"\033[38;2;{fg};{fg};{fg}m"
                    cur_fg = fg
                if bg != cur_bg:
                    code += f"\033[48;2;{bg};{bg};{bg}m"
                    cur_bg = bg
                cells.append(code + HALF_BLOCK)
            out_parts.append("".join(cells) + RESET)
            
        return "".join(out_parts)

    else:
        # ── Color Mode ─────────────────────────────────────────────────────────────
        # Quantize to multiples of 8 (>>3 <<3)
        quant = (resized.astype(np.uint16) >> 3 << 3).astype(np.uint8)

        # Delta detection
        prev = render_state.get('prev_quant')
        if prev is not None and prev.shape == quant.shape:
            diff = quant != prev
            top_diff = diff[0::2].any(axis=(1, 2))
            bot_diff = diff[1::2].any(axis=(1, 2))
            row_changed = (top_diff | bot_diff).tolist()
        else:
            nrows = pixel_h // 2
            row_changed = [True] * nrows

        render_state['prev_quant'] = quant

        b = quant[:, :, 0]; g = quant[:, :, 1]; r = quant[:, :, 2]
        top_r = r[0::2].tolist(); top_g = g[0::2].tolist(); top_b = b[0::2].tolist()
        bot_r = r[1::2].tolist(); bot_g = g[1::2].tolist(); bot_b = b[1::2].tolist()

        nrows = len(top_r)
        out_parts = []

        for row in range(nrows):
            if not row_changed[row]:
                continue

            out_parts.append(f"\033[{row + 1};1H")

            tr_row = top_r[row]; tg_row = top_g[row]; tb_row = top_b[row]
            br_row = bot_r[row]; bg_row = bot_g[row]; bb_row = bot_b[row]

            cur_fg = (-1, -1, -1)
            cur_bg = (-1, -1, -1)
            cells = []
            for c in range(pixel_w):
                fg = (tr_row[c], tg_row[c], tb_row[c])
                bg = (br_row[c], bg_row[c], bb_row[c])
                code = ""
                if fg != cur_fg:
                    code = f"\033[38;2;{fg[0]};{fg[1]};{fg[2]}m"
                    cur_fg = fg
                if bg != cur_bg:
                    code += f"\033[48;2;{bg[0]};{bg[1]};{bg[2]}m"
                    cur_bg = bg
                cells.append(code + HALF_BLOCK)

            out_parts.append("".join(cells) + RESET)

        return "".join(out_parts)

def fmt_time(seconds):
    """Format seconds as M:SS."""
    s = int(seconds)
    return f"{s // 60}:{s % 60:02d}"

def draw_status_bar(term_cols, term_rows, frame_number, total_frames, fps, paused):
    """Draw a controls bar on the very last row of the terminal."""
    current = frame_number / fps if fps else 0
    total = total_frames / fps if fps else 0
    pct = frame_number / total_frames if total_frames else 0

    label_left = f" {fmt_time(current)}/{fmt_time(total)} "
    hint = " [Space] Play/Pause  [←] -10s  [→] +10s  [Q] Quit "
    state_badge = " ⏸ PAUSED " if paused else " ▶ PLAYING "

    bar_width = max(term_cols - len(label_left) - len(hint) - len(state_badge) - 2, 4)
    filled = int(pct * bar_width)
    bar = "█" * filled + "░" * (bar_width - filled)
    line = f"{state_badge}{label_left}[{bar}]{hint}"
    line = line[:term_cols].ljust(term_cols)

    bar_ansi = f"\033[{term_rows};1H\033[48;2;30;30;30m\033[38;2;200;200;200m{line}{RESET}"
    sys.stdout.write(bar_ansi)
