# 🎬 ASCII Live

**Play YouTube videos and local files directly in your terminal as high-fidelity ASCII art.**

Experience video playback like never before, rendered in real-time using ANSI escape codes and half-block characters for a surprisingly detailed "pixelated" look.

---

## ✨ Features

- 📺 **YouTube Support**: Play any YouTube video by simply providing the URL.
- 📁 **Local Files**: Play MP4, MKV, AVI, and other local video formats.
- 🔊 **Audio Sync**: Real-time synchronization between ASCII video and audio tracks.
- ⚙️ **Highly Flexible**:
  - `--no-audio`: For silent playback.
  - `--fps`: Override default frame rates.
  - `--quality`: Choose between performance or detail.
  - `--bw`: Sleek monochrome mode.
  - `--size`: Manual resolution overrides.
- ⌨️ **Interactive Controls**:
  - `[Space]` Play/Pause
  - `[←] [→]` Seek 10s back/forward
  - `[Q]` Quit

---

## 🚀 Installation

### Prerequisites
- **Python 3.8+**
- **ffmpeg** (Required for audio extraction)
  - Windows: `choco install ffmpeg` or download from [ffmpeg.org](https://ffmpeg.org/)
  - Linux: `sudo apt install ffmpeg`
  - macOS: `brew install ffmpeg`

### Install from PyPI
```bash
pip install ascii-live
```

---

## 📖 Usage

### Play a YouTube Video
```bash
ascii-live "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
```

### Play a Local File
```bash
ascii-live movie.mp4
```

### Options
```bash
# Play without audio
ascii-live "URL" --no-audio

# Force a specific resolution
ascii-live "URL" --size 80x40

# Play in Black & White
ascii-live "URL" --bw

# Set a custom FPS
ascii-live "URL" --fps 15
```

---

## 🛠️ How it Works
ASCII Live uses **OpenCV** to decode video frames, **yt-dlp** for stream handling, and **Pygame** for high-performance audio playback. The renderer uses a custom-built ANSI half-block algorithm that packs two vertical "pixels" into a single character cell, effectively doubling the vertical resolution.

---

## 📄 License
Licensed under the **Apache License 2.0**. See the [LICENSE](LICENSE) file for details.
