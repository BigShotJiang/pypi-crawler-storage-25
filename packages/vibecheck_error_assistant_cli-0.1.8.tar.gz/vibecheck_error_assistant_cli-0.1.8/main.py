import argparse
import getpass
import os
import re
import shlex
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence, TypedDict

from dotenv import load_dotenv
from openai import OpenAI, RateLimitError
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table
from rich.spinner import Spinner


console = Console()
GLOBAL_CONFIG_DIR = Path.home() / ".config" / "vibecheck"
GLOBAL_ENV_FILE = GLOBAL_CONFIG_DIR / ".env"


class ProviderPreset(TypedDict):
    label: str
    description: str
    base_url: str
    models: list[str]
    token_label: str


PROVIDER_PRESETS: dict[str, ProviderPreset] = {
    "github": {
        "label": "GitHub Models",
        "description": "Best for the current release if you already have a GitHub token.",
        "base_url": "https://models.inference.ai.azure.com",
        "models": [
            "gpt-4o-mini",
            "gpt-4.1-mini",
            "codestral-25.01",
            "meta-llama-3.1-8b-instruct",
            "phi-4",
            "deepseek-r1-0528",
            "o3-mini",
        ],
        "token_label": "GitHub token",
    }
}


@dataclass(frozen=True)
class Settings:
    provider: str
    api_key: str
    endpoint: str
    model_tiers: list[str]
    max_error_chars: int
    ai_timeout_seconds: int


def _write_global_env(provider: str, api_key: str) -> None:
    preset = PROVIDER_PRESETS[provider]
    GLOBAL_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    env_content = "\n".join(
        [
            "# VibeCheck global configuration",
            f"VIBECHECK_PROVIDER={provider}",
            f"VIBECHECK_API_KEY={api_key}",
            f"VIBECHECK_BASE_URL={preset['base_url']}",
            f"VIBECHECK_MODELS={','.join(preset['models'])}",
            "VIBECHECK_MAX_ERROR_CHARS=5000",
            "VIBECHECK_AI_TIMEOUT_SECONDS=45",
            "",
        ]
    )
    GLOBAL_ENV_FILE.write_text(env_content, encoding="utf-8")
    try:
        os.chmod(GLOBAL_ENV_FILE, 0o600)
    except OSError:
        pass


def _infer_provider(provider: str, endpoint: str) -> str:
    return "github"


def _global_env_exists() -> bool:
    return GLOBAL_ENV_FILE.exists()


def run_setup_wizard(force: bool = False) -> Settings:
    console.print(
        Panel(
            "[bold cyan]VibeCheck setup[/bold cyan]\n"
            "VibeCheck uses GitHub Models for AI explanations.\n"
            "The config is stored in a hidden file under ~/.config/vibecheck/.",
            title="First-Time Setup",
            border_style="cyan",
        )
    )

    if force and _global_env_exists():
        if not Confirm.ask("Overwrite existing global VibeCheck config?", default=False):
            raise SystemExit(0)

    provider = "github"
    preset = PROVIDER_PRESETS[provider]

    console.print(
        Panel(
            f"[bold]{preset['label']}[/bold]\n\n"
            f"Paste your {preset['token_label']} below.\n"
            "It will be stored in a global config file for this machine only.",
            title="Token Setup",
            border_style="green",
        )
    )

    api_key = ""
    while not api_key:
        api_key = getpass.getpass(f"Enter your {preset['token_label']}: ").strip()
        if not api_key:
            console.print("[red]Token cannot be empty.[/red]")

    _write_global_env(provider, api_key)
    settings = load_settings(allow_setup=False)
    if settings is None:
        raise SystemExit(1)

    console.print(
        Panel(
            f"[bold green]Saved![/bold green]\n\n"
            f"Provider: {settings.provider}\n"
            f"Config: {GLOBAL_ENV_FILE}\n\n"
            "You can now run VibeCheck in any project without re-entering the token.",
            title="Setup Complete",
            border_style="green",
        )
    )
    return settings


def load_settings(allow_setup: bool = True) -> Settings | None:
    load_dotenv()
    if GLOBAL_ENV_FILE.exists():
        load_dotenv(GLOBAL_ENV_FILE, override=False)

    provider = os.getenv("VIBECHECK_PROVIDER", "").strip().lower()
    endpoint = os.getenv("VIBECHECK_BASE_URL", os.getenv("VIBECHECK_ENDPOINT", "")).strip()
    api_key = os.getenv("VIBECHECK_API_KEY", os.getenv("VIBECHECK_GITHUB_TOKEN", "")).strip()
    provider = _infer_provider(provider, endpoint)

    preset = PROVIDER_PRESETS.get(provider, PROVIDER_PRESETS["github"])
    if not endpoint:
        endpoint = preset["base_url"]

    tiers_raw = os.getenv("VIBECHECK_MODELS", "")
    model_tiers = [m.strip() for m in tiers_raw.split(",") if m.strip()] if tiers_raw else list(preset["models"])

    max_error_chars = int(os.getenv("VIBECHECK_MAX_ERROR_CHARS", "5000"))
    ai_timeout_seconds = int(os.getenv("VIBECHECK_AI_TIMEOUT_SECONDS", "45"))

    if not api_key and allow_setup and sys.stdin.isatty():
        return run_setup_wizard(force=False)

    if not api_key:
        return None

    return Settings(
        provider=provider,
        api_key=api_key,
        endpoint=endpoint,
        model_tiers=model_tiers,
        max_error_chars=max_error_chars,
        ai_timeout_seconds=ai_timeout_seconds,
    )


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="vibecheck",
        description="Run a command and translate failures into beginner-friendly guidance.",
    )
    parser.add_argument(
        "--print-raw-error",
        action="store_true",
        help="Show raw stderr in addition to AI guidance.",
    )
    parser.add_argument(
        "--level",
        choices=["beginner", "intermediate", "advanced"],
        default="beginner",
        help="Explanation depth for the user. Default is beginner.",
    )
    parser.add_argument(
        "command",
        nargs="*",
        help="Command to run. Example: vibecheck python buggy.py",
    )
    args, unknown = parser.parse_known_args(argv)
    args.command = args.command + unknown
    return args


def normalize_command(command: Sequence[str]) -> list[str]:
    normalized = list(command)
    if normalized and normalized[0] == "--":
        normalized = normalized[1:]

    # Auto-detect runner if the first word is a known file type
    if normalized:
        target = normalized[0]
        path = Path(target)
        
        # Only inject the runner if the target actually exists as a file
        if path.is_file():
            ext = path.suffix.lower()
            runners = {
                ".py": ["python"],
                ".js": ["node"],
                ".jsx": ["node"],
                ".ts": ["npx", "ts-node"],
                ".tsx": ["npx", "ts-node"],
                ".mjs": ["node"],
                ".cjs": ["node"],
                ".rb": ["ruby"],
                ".go": ["go", "run"],
                ".sh": ["bash"],
                ".php": ["php"],
                ".pl": ["perl"],
                ".java": ["java"],
            }
            if ext in runners:
                # Prepend the appropriate runner to the command list
                normalized = runners[ext] + normalized

    return normalized


def run_target_command(command: Sequence[str]) -> subprocess.CompletedProcess[str]:
    # We capture ONLY stderr so that stdout prints live to the terminal.
    # This prevents hanging on interactive programs or inputs!
    return subprocess.run(command, stderr=subprocess.PIPE, text=True)


def extract_line_hint(error_text: str) -> str:
    line_matches = re.findall(r"line\s+(\d+)", error_text, flags=re.IGNORECASE)
    if not line_matches:
        return "No specific line found in traceback."
    return f"Likely line mentioned by runtime: {line_matches[-1]}"


def build_prompt(error_text: str, line_hint: str, level: str) -> str:
    # 1. The Core Identity (The Role)
    base_identity = (
        "You are 'VibeGuard,' an elite coding mentor known for extreme patience and clarity. "
        "Your goal is to turn a frustrating error into a 'lightbulb moment.' "
        "Since your users may not be native English speakers, use 'Global English': "
        "avoid slang, avoid complex metaphors, and use clear, literal instructions.\n\n"
    )

    level_rules = {
        "beginner": (
            "### ROLE: THE PATIENT EXPLORER\n"
            "1. **Tone**: Warm, encouraging, and highly detailed. Use simple, high-frequency English words.\n"
            "2. **The 'Why'**: Do not just fix the code. Explain the 'Logic of the Universe.' "
            "If it is a TypeError, explain that Python is like a chef who was given a 'shoe' when they asked for an 'onion.'\n"
            "3. **Vocabulary Breakdown**: Identify every technical word in the error (e.g., 'Attribute', 'Iteration', 'Literal') "
            "and define it using a real-world object analogy.\n"
            "4. **Step-by-Step Recovery**: Break the fix into 'Small Steps.' Step 1: Look here. Step 2: Change this. Step 3: Run again.\n"
            "5. **Visual Representation**: Use simple ASCII art or spacing to show where the error is pointing."
        ),
        "intermediate": (
            "### ROLE: THE EFFICIENT COACH\n"
            "1. **Tone**: Professional and direct. Assume they know the basics (loops, variables) but missed a logic connection.\n"
            "2. **Root Cause**: Explain the architectural reason for the error. Did they break a 'contract' of the function?\n"
            "3. **Best Practices**: Briefly mention a 'cleaner' way to write this to avoid the error in the future.\n"
            "4. **The Fix**: Provide the code block clearly."
        ),
        "advanced": (
            "### ROLE: THE SENIOR ARCHITECT\n"
            "1. **Tone**: Minimalist. Use technical shorthand.\n"
            "2. **Insight**: Focus on memory, performance, or library-specific quirks.\n"
            "3. **The Fix**: Provide a 'one-liner' or a diff format fix."
        ),
    }

    # Constructing the Final Mega-Prompt
    chosen_role = level_rules.get(level, level_rules["beginner"])

    full_prompt = (
        f"{base_identity}"
        f"{chosen_role}\n\n"
        f"--- THE TASK ---\n"
        f"The user received this error message: '{error_text}'\n"
        f"The error seems to be near: {line_hint}\n\n"
        "Structure your response exactly like this:\n"
        "1. **The Vibe Check**: A 1-sentence supportive opening.\n"
        "2. **The Simple Translation**: Translate the computer-speak into 'Human-speak'.\n"
        "3. **Word Bank**: Define technical terms found in the error.\n"
        "4. **The Deep Dive**: Detailed explanation of the mistake.\n"
        "5. **The Repair**: Clear code fix with comments.\n"
        "6. **Pro-Tip**: How to never see this error again."
    )

    return full_prompt


def ask_ai_for_explanation(client: OpenAI, settings: Settings, error_text: str, level: str) -> tuple[str, str]:
    line_hint = extract_line_hint(error_text)
    prompt = build_prompt(error_text, line_hint, level)

    with Live(Spinner("dots", text="[bold yellow]Analyzing failure...[/bold yellow]"), refresh_per_second=12) as live:
        for model_name in settings.model_tiers:
            try:
                live.update(Spinner("dots", text=f"[bold cyan]Trying {model_name}[/bold cyan]"))
                response = client.chat.completions.create(
                    model=model_name,
                    temperature=0.1,
                    timeout=settings.ai_timeout_seconds,
                    messages=[
                        {
                            "role": "system",
                            "content": "You explain programming errors clearly for beginners.",
                        },
                        {"role": "user", "content": prompt},
                    ],
                )
                text = response.choices[0].message.content or "No explanation returned by model."
                return text, model_name
            except RateLimitError:
                continue
            except Exception:
                continue

    return "Unable to get an AI explanation right now. Please retry shortly.", "no-model"


def display_vibe_panel(ai_text: str, model_used: str) -> None:
    panel = Panel(
        Markdown(ai_text),
        title=f"[bold red]VibeCheck Report ({model_used})[/bold red]",
        border_style="bright_magenta",
        padding=(1, 2),
    )
    console.print()
    console.print(panel)
    console.print()


def ensure_settings() -> Settings:
    settings = load_settings(allow_setup=True)
    if settings is not None:
        return settings

    console.print(
        Panel(
            "VibeCheck is not configured yet.\n\n"
            f"Run [bold]vibecheck setup[/bold] or create {GLOBAL_ENV_FILE}.",
            title="Configuration Required",
            border_style="red",
        )
    )
    raise SystemExit(2)


def run_with_vibecheck(command: Sequence[str], settings: Settings, level: str, print_raw_error: bool) -> int:
    console.print(f"[bold green]Running:[/bold green] {' '.join(command)}")
    
    try:
        proc = run_target_command(command)
    except FileNotFoundError:
        # Create a mock failed process so the AI can explain the missing command!
        error_msg = f"System Error: Command not found. You tried to execute '{command[0]}', but it is a document file (like .html/.css) instead of an executable program, or the required command prefix is missing."
        proc = subprocess.CompletedProcess(args=command, returncode=127, stdout="", stderr=error_msg)
    except PermissionError:
        error_msg = f"System Error: Permission denied. The file '{command[0]}' is not marked as executable on your operating system."
        proc = subprocess.CompletedProcess(args=command, returncode=126, stdout="", stderr=error_msg)

    if proc.returncode == 0:
        console.print()
        console.print(Panel(
            "✨ [bold green]Code executed perfectly![/bold green] ✨\n"
            "No errors were found in your code. Keep going, your vibes are immaculate!",
            title="[bold green]Success[/bold green]",
            border_style="green"
        ))
        return 0

    error_text = (proc.stderr or "").strip() or f"Command failed with exit code {proc.returncode} and no stderr output."

    if print_raw_error:
        console.print(Panel(error_text, title="Raw stderr", border_style="yellow"))

    trimmed_error = error_text[: settings.max_error_chars]
    client = OpenAI(base_url=settings.endpoint, api_key=settings.api_key)
    explanation, model_used = ask_ai_for_explanation(client, settings, trimmed_error, level)
    display_vibe_panel(explanation, model_used)

    return proc.returncode


def main(argv: Sequence[str]) -> int:
    args = parse_args(argv)
    command = normalize_command(args.command)

    if command and command[0] in {"setup", "configure"} and len(command) == 1:
        run_setup_wizard(force=True)
        return 0

    if not command:
        console.print("[red]Error: No command provided to run.[/red]\n"
                      "Example usage: [cyan]vibecheck script.py[/cyan]")
        return 1

    settings = ensure_settings()

    return run_with_vibecheck(
        command,
        settings=settings,
        level=args.level,
        print_raw_error=args.print_raw_error,
    )


def cli() -> None:
    raise SystemExit(main(sys.argv[1:]))


if __name__ == "__main__":
    cli()