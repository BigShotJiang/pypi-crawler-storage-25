# Everything_GetResultListRequestFlags

Source: https://www.voidtools.com

# Everything_GetResultListRequestFlags

The **Everything_GetResultListRequestFlags** function returns the flags of available result data.

## Syntax

```
DWORD Everything_GetResultListRequestFlags(void);
```

## Return Value

Returns zero or more of the following request flags:

```
EVERYTHING_REQUEST_FILE_NAME                            (0x00000001)
EVERYTHING_REQUEST_PATH                                 (0x00000002)
EVERYTHING_REQUEST_FULL_PATH_AND_FILE_NAME              (0x00000004)
EVERYTHING_REQUEST_EXTENSION                            (0x00000008)
EVERYTHING_REQUEST_SIZE                                 (0x00000010)
EVERYTHING_REQUEST_DATE_CREATED                         (0x00000020)
EVERYTHING_REQUEST_DATE_MODIFIED                        (0x00000040)
EVERYTHING_REQUEST_DATE_ACCESSED                        (0x00000080)
EVERYTHING_REQUEST_ATTRIBUTES                           (0x00000100)
EVERYTHING_REQUEST_FILE_LIST_FILE_NAME                  (0x00000200)
EVERYTHING_REQUEST_RUN_COUNT                            (0x00000400)
EVERYTHING_REQUEST_DATE_RUN                             (0x00000800)
EVERYTHING_REQUEST_DATE_RECENTLY_CHANGED                (0x00001000)
EVERYTHING_REQUEST_HIGHLIGHTED_FILE_NAME                (0x00002000)
EVERYTHING_REQUEST_HIGHLIGHTED_PATH                     (0x00004000)
EVERYTHING_REQUEST_HIGHLIGHTED_FULL_PATH_AND_FILE_NAME  (0x00008000)
```

## Remarks

The requested result data may differ to the desired result data specified in [Everything_SetRequestFlags](/support/everything/sdk/everything_setrequestflags).

## Example

```
DWORD dwRequestFlags = Everything_GetResultListRequestFlags();
```

## See Also

- [Everything_SetRequestFlags](/support/everything/sdk/everything_setrequestflags)

- [Everything_Query](/support/everything/sdk/everything_query)
