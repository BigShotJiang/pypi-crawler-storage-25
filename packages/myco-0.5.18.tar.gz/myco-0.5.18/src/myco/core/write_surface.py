"""Write-surface policy + guarded-write helper.

Governing doctrine: ``docs/architecture/L1_CONTRACT/protocol.md`` R6
("Write only to paths in ``_canon.yaml::system.write_surface.allowed``")
and ``docs/architecture/L2_DOCTRINE/homeostasis.md`` § "Safe-fix
discipline" rule 4 ("Bounded"). This module is the mechanical
enforcement of both — every verb that mutates substrate content
routes its path through :func:`check_write_allowed` or
:func:`guarded_write`.

v0.5.8 upgraded R6 (the "write only to allowed surface" hard-contract
rule) from "checked by `immune --fix`" to "enforced on every
kernel-side write". Previously every verb that mutated the substrate
(`eat`, `sporulate`, `ramify`, `fruit`, `molt`, `propagate`,
`germinate`, `boot_brief.patch_entry_point`) wrote bytes directly with
no check against `canon.system.write_surface.allowed`. The audit
classified this as a P0 trust-boundary break.

This module is the chokepoint every kernel write now routes through:

    from myco.core.write_surface import guarded_write
    guarded_write(ctx, path, content)

The helper:

1. Resolves ``path`` to a substrate-relative POSIX string.
2. Matches that path against ``ctx.substrate.canon.system.write_surface.allowed``
   using glob semantics.
3. If allowed, delegates to :func:`myco.core.io_atomic.atomic_utf8_write`
   for the actual write (atomic + UTF-8 + LF-normalised).
4. If disallowed, either raises :class:`WriteSurfaceViolation` OR, when
   the ``MYCO_ALLOW_UNSAFE_WRITE=1`` environment variable is set, logs
   the bypass and proceeds.

The bypass is intentional — certain workflows (test tmp dirs, scripted
ingest) need write access outside the declared surface. The env var
makes it explicit; v0.5.10+ appends each bypassed write to
``.myco_state/unsafe_writes.log`` so a future SE-class dimension can
surface bypass frequency to immune without any per-call overhead.

The helper imports ``ctx`` lazily (by type-name) to avoid a
core→runtime circular import. Callers pass a ``MycoContext`` instance.
"""

from __future__ import annotations

import fnmatch
import os
from pathlib import Path
from typing import TYPE_CHECKING

from .errors import MycoError
from .io_atomic import atomic_utf8_write

if TYPE_CHECKING:
    from .context import MycoContext

__all__ = [
    "WriteSurfaceViolation",
    "UNSAFE_WRITE_ENV",
    "is_path_allowed",
    "guarded_write",
    "check_write_allowed",
    "unsafe_bypass_enabled",
]


#: Environment variable that, when set to "1" / "true" / "yes" / "on",
#: allows :func:`guarded_write` to proceed on a disallowed path. Used
#: by test fixtures (conftest sets this at session scope) and by
#: users who knowingly need to write outside the surface.
UNSAFE_WRITE_ENV = "MYCO_ALLOW_UNSAFE_WRITE"


class WriteSurfaceViolation(MycoError):
    """Raised when a kernel write targets a path outside
    ``_canon.yaml::system.write_surface.allowed`` and the unsafe-write
    bypass is not set.

    Exit code 3 inherited from :class:`MycoError`. Caller-friendly
    message names the path and the surface it violated.
    """


def unsafe_bypass_enabled() -> bool:
    """Return True if ``MYCO_ALLOW_UNSAFE_WRITE`` is set to a truthy
    value (``"1"`` / ``"true"`` / ``"yes"`` / ``"on"``).

    v0.5.8 promoted this from a private helper so verbs that use
    ``os.open(O_EXCL)`` or other bespoke write paths (``eat``'s
    collision-retry loop is the canonical case) can reproduce the
    same bypass semantics ``guarded_write`` uses without reimplementing
    the env-var parsing.
    """
    value = os.environ.get(UNSAFE_WRITE_ENV, "").strip().lower()
    return value in {"1", "true", "yes", "on"}


# Backward-compat alias; v0.5.8 kept the underscored name live because
# it was referenced by :func:`guarded_write` below.
_unsafe_bypass_enabled = unsafe_bypass_enabled


def check_write_allowed(
    ctx: MycoContext,
    path: Path,
    *,
    verb: str,
) -> None:
    """Raise :class:`WriteSurfaceViolation` if ``path`` is not in the
    substrate's declared write surface AND the unsafe-write bypass is
    not set.

    Public helper for verbs that do their own file I/O (e.g. ``eat``'s
    ``O_EXCL`` collision loop) but still want the write-surface + env-
    bypass semantics ``guarded_write`` provides.

    Args:
        ctx: the substrate context whose canon declares the surface.
        path: the target path (will be resolved + matched).
        verb: caller verb name surfaced in the error message, e.g.
            ``"eat"``. Purely diagnostic.
    """
    allowed, rel = is_path_allowed(path, ctx)
    if allowed:
        return
    if unsafe_bypass_enabled():
        return
    surface_list: list[str] = []
    system = ctx.substrate.canon.system or {}
    surface_map = system.get("write_surface") or {}
    if isinstance(surface_map, dict):
        raw_allowed = surface_map.get("allowed")
        if isinstance(raw_allowed, list):
            surface_list = [str(p) for p in raw_allowed]
    raise WriteSurfaceViolation(
        f"{verb}: target {rel if rel is not None else path} is not "
        f"matched by any pattern in "
        f"canon.system.write_surface.allowed = {surface_list}. "
        f"Add a covering pattern, or set "
        f"{UNSAFE_WRITE_ENV}=1 in the environment to override."
    )


def _normalise_to_substrate_relative(path: Path, substrate_root: Path) -> str | None:
    """Return ``path`` as a POSIX substrate-relative string, or None
    if ``path`` escapes ``substrate_root``.

    Matches the pattern used elsewhere in the kernel (``graph._rel``).
    The relative path uses ``/`` separators regardless of platform so
    the glob match is portable.
    """
    try:
        # Prefer resolve() so that symlinks that cross into / out of
        # the substrate surface to their real destination before the
        # glob check. This is a security property: an attacker-
        # planted symlink at `notes/evil → /etc/passwd` would pass
        # a naive basename-based check but fail resolve-then-match.
        resolved = path.resolve()
        rel = resolved.relative_to(substrate_root.resolve())
    except (ValueError, OSError):
        return None
    return str(rel).replace(os.sep, "/")


def is_path_allowed(
    path: Path,
    ctx: MycoContext,
) -> tuple[bool, str | None]:
    """Check whether ``path`` falls within the substrate's declared
    write surface.

    Returns ``(True, rel)`` when allowed (``rel`` is the
    substrate-relative POSIX string that matched a rule) or
    ``(False, rel_or_None)`` when not. The second element is the
    relative path if it could be computed, or None if ``path`` escapes
    the substrate root entirely (still disallowed).

    The canon's ``system.write_surface.allowed`` is read as a list of
    fnmatch-style globs. A path is allowed when ANY glob matches.

    Missing-canon case: if the canon cannot be read or the
    ``write_surface.allowed`` list is absent/empty, returns ``(False,
    rel)`` — the default is strict, matching R6's "any other path is
    substrate pollution".
    """
    substrate_root = ctx.substrate.root
    rel = _normalise_to_substrate_relative(path, substrate_root)
    if rel is None:
        return (False, None)

    # ``canon.system`` is a ``Mapping[str, Any]`` so we dig through
    # dict-level keys rather than attribute access. ``write_surface``
    # may be absent (pre-v0.5.0 canons), an empty dict, or a mapping
    # with ``allowed`` being a list of fnmatch globs.
    system = ctx.substrate.canon.system or {}
    surface = system.get("write_surface") or {}
    allowed_raw = surface.get("allowed") if isinstance(surface, dict) else None
    if not isinstance(allowed_raw, list):
        return (False, rel)
    patterns: list[str] = [str(p) for p in allowed_raw]

    for pattern in patterns:
        # fnmatch.fnmatch is case-insensitive on Windows; we want
        # case-sensitive matching because substrate paths are
        # case-sensitive on POSIX (the write surface is a substrate
        # contract, not a filesystem one). Use fnmatchcase explicitly.
        if fnmatch.fnmatchcase(rel, pattern):
            return (True, rel)

    return (False, rel)


def guarded_write(
    ctx: MycoContext,
    path: Path,
    content: str,
    *,
    newline: str | None = "\n",
    encoding: str = "utf-8",
    make_parents: bool = True,
) -> str:
    """Write ``content`` to ``path`` iff ``path`` is within the
    substrate's write surface.

    On success, returns the substrate-relative POSIX path for the
    caller to log / surface in Result payloads. On disallowed path,
    raises :class:`WriteSurfaceViolation` unless ``MYCO_ALLOW_UNSAFE_WRITE``
    is set, in which case the bypass is taken and the write proceeds.

    All actual bytes are written via :func:`atomic_utf8_write` so the
    write is atomic + UTF-8 + LF-normalised regardless of platform.
    """
    allowed, rel = is_path_allowed(path, ctx)
    if not allowed:
        if _unsafe_bypass_enabled():
            # v0.5.10: caller has explicitly opted in. Log the bypass
            # to ``.myco_state/unsafe_writes.log`` (best-effort
            # append; silent on failure so logging never blocks the
            # actual write) so a future SE-class dimension can count
            # bypass frequency without per-call overhead.
            _log_unsafe_bypass(ctx, rel if rel is not None else str(path))
        else:
            surface_list: list[str] = []
            system = ctx.substrate.canon.system or {}
            surface_map = system.get("write_surface") or {}
            if isinstance(surface_map, dict):
                raw_allowed = surface_map.get("allowed")
                if isinstance(raw_allowed, list):
                    surface_list = [str(p) for p in raw_allowed]
            raise WriteSurfaceViolation(
                f"refusing to write outside allowed surface: "
                f"{rel if rel is not None else path} is not matched "
                f"by any pattern in "
                f"canon.system.write_surface.allowed = {surface_list}. "
                f"To override explicitly, set "
                f"{UNSAFE_WRITE_ENV}=1 in the environment."
            )

    atomic_utf8_write(
        path,
        content,
        newline=newline,
        encoding=encoding,
        make_parents=make_parents,
    )
    return rel if rel is not None else str(path)


def _log_unsafe_bypass(ctx: MycoContext, target_rel_or_abs: str) -> None:
    """Append a one-line record to ``.myco_state/unsafe_writes.log``.

    v0.5.10: the log is a best-effort audit trail. Any failure
    (missing state dir, permission denied, full disk) is swallowed
    silently — the log must never block the actual write. A future
    SE-class dimension can count entries to surface bypass frequency
    to ``myco immune``.

    Format: ``<ISO-8601 UTC> <target>`` newline-terminated.
    """
    try:
        from datetime import datetime, timezone

        log_path = ctx.substrate.root / ".myco_state" / "unsafe_writes.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        line = f"{stamp} {target_rel_or_abs}\n"
        with open(log_path, "a", encoding="utf-8", newline="\n") as fh:
            fh.write(line)
    except OSError:
        # Best-effort; swallow any filesystem failure.
        pass
