from setuptools import setup, find_packages

setup(
    name="int-dynamic-engine", # ලයිබ්‍රරියේ පොදු නම
    version="0.1.0", # ප්‍රථම සංස්කරණය
    packages=find_packages(),
    description="A hybrid global memory engine from INT Language",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Nikila Udana",
    author_email="your_email@example.com",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires='>=3.6',
)