class INTEngine:
    def __init__(self):
        self.global_memory = {}
        self.current_variable = None

    def __call__(self, var_name):
        self.current_variable = var_name
        if var_name not in self.global_memory:
            self.global_memory[var_name] = None
        return self

    def set_value(self, value):
        if self.current_variable:
            self.global_memory[self.current_variable] = value

    def set_input(self, prompt_text):
        if self.current_variable:
            self.global_memory[self.current_variable] = input(prompt_text)

    def get_value(self, var_name):
        return self.global_memory.get(var_name, "Not Found")