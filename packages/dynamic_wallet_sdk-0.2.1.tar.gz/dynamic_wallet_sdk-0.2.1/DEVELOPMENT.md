# Development Guide

This guide covers setting up a local development environment, building the native extension, and running tests.

**See also:** [ARCHITECTURE.md](ARCHITECTURE.md) — internals deep-dive | [DEMO_GUIDE.md](DEMO_GUIDE.md) — build a working demo in minutes

## Prerequisites

- **Python 3.11+**
- **Rust toolchain** — install via [rustup](https://rustup.rs/)
- **MPC registry access** — the native MPC crate is hosted on a private Cargo registry (token in 1Password)
- **Dynamic environment ID + API key** — from the [Dynamic dashboard](https://app.dynamic.xyz/)

## Setup

### 1. Clone and navigate

```bash
cd python/
```

### 2. Create a virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Configure the private Cargo registry

The native extension depends on an internal MPC crate hosted on a private Cargo registry.

**`.cargo/config.toml`** (already present in the repo) configures the registry URL.

Add credentials to your global Cargo config:

```bash
cat >> ~/.cargo/credentials.toml << 'EOF'
[registries.dynamic-mpc]
token = "Bearer <YOUR_MPC_REGISTRY_TOKEN>"
EOF
```

The registry token is stored in 1Password. Ask a team member if you don't have access.

### 4. Install Python dependencies

```bash
pip install -e ".[dev]"
```

This installs:

| Dependency                 | Purpose                                                                       |
| -------------------------- | ----------------------------------------------------------------------------- |
| `httpx`                    | Async HTTP client for Dynamic API + SSE streaming                             |
| `cryptography`             | AES-256-GCM encryption, PBKDF2 key derivation, RSA-OAEP for delegated signing |
| `eth-account`              | EIP-712 typed data encoding                                                   |
| `eth-hash[pycryptodome]`   | Keccak-256 hashing for EVM address derivation and EIP-191                     |
| `base58`                   | Solana address encoding                                                       |
| `solders`                  | Solana primitives                                                             |
| `pytest`, `pytest-asyncio` | Testing                                                                       |
| `respx`                    | HTTP mocking for tests                                                        |
| `maturin`                  | Rust-to-Python build tool                                                     |

### 5. Build the native extension

```bash
maturin develop
```

This compiles the Rust code in `src/` and installs the resulting `dynamic_wallet_mpc` native module into your venv. The first build downloads and compiles dependencies, which takes a few minutes. Subsequent builds are incremental (~2-5s).

To verify the build succeeded:

```bash
python -c "from dynamic_wallet_mpc import PyEcdsa, PyEd25519; print('Native module loaded')"
```

## Running Tests

```bash
pytest
```

All tests run in ~2 seconds. The test suite covers:

- `test_encryption.py` — AES-256-GCM encrypt/decrypt round-trips, v1/v2 compatibility, wrong-password detection
- `test_evm_utils.py` — EVM address derivation from public keys, EIP-191 message formatting, EIP-55 checksum encoding, ECDSA signature serialization
- `test_svm_utils.py` — Solana address derivation (base58), hex round-trips, message formatting
- `test_sse.py` — SSE event stream parsing, error events, edge cases
- `test_wallet_client.py` — Wallet client initialization, authentication flow (mocked), wallet map operations, address normalization

Tests don't call any live relay or Dynamic API — they exercise the pure Python logic. The native module is imported only for type checks.

## Project Structure

```
python/
├── .cargo/config.toml              # Private MPC registry URL
├── Cargo.toml                      # Rust crate config: MPC library + pyo3 + tokio
├── pyproject.toml                  # Python package config (maturin build backend)
│
├── src/                            # Rust native extension (PyO3)
│   ├── lib.rs                      # #[pymodule] entry point, tokio runtime init
│   ├── ecdsa.rs                    # PyEcdsa — ECDSA MPC operations
│   ├── ed25519.rs                  # PyEd25519 — standard Ed25519 MPC operations
│   ├── exportable_ed25519.rs       # PyExportableEd25519 — ExportableEd25519 (used for SVM)
│   ├── types.rs                    # Python-visible types (PyInitKeygenResult, PyMessageHash, etc.)
│   ├── error.rs                    # MPCError Python exception
│   └── unsafesend.rs               # SendFuture wrapper for !Send FFI futures
│
├── dynamic_wallet_sdk/             # Pure Python SDK
│   ├── __init__.py                 # Public API re-exports
│   ├── constants.py                # URLs, headers, enums (Environment, ChainType, BackupLocation)
│   ├── mpc_config.py               # TSS schemes, chain configs, derivation paths
│   ├── exceptions.py               # Error hierarchy (DynamicSDKError, AuthenticationError, etc.)
│   │
│   ├── api/
│   │   ├── client.py               # BaseClient: dual httpx clients (API + Evervault relay)
│   │   ├── dynamic_api.py          # All Dynamic API endpoints (SSE + REST)
│   │   └── sse.py                  # SSE event stream parser
│   │
│   ├── crypto/
│   │   └── encryption.py           # AES-256-GCM + PBKDF2 key share backup encryption
│   │
│   ├── mpc/
│   │   ├── signer.py               # get_mpc_signer() factory — returns PyEcdsa or PyExportableEd25519
│   │   └── types.py                # ServerKeyShare, WalletProperties dataclasses
│   │
│   ├── wallet_client.py            # DynamicWalletClient — orchestrates keygen, sign, refresh, export, import, backup
│   │
│   ├── evm/
│   │   ├── client.py               # DynamicEvmWalletClient — EIP-191/712 signing, tx signing
│   │   └── utils.py                # EVM address derivation, message formatting, signature serialization
│   │
│   ├── svm/
│   │   ├── client.py               # DynamicSvmWalletClient — Solana message/tx signing
│   │   └── utils.py                # Solana address derivation, message formatting
│   │
│   └── delegated/
│       ├── client.py               # Delegated signing — factory + sign with delegated key shares
│       └── decrypt.py              # RSA-OAEP + AES-GCM webhook decryption
│
└── tests/
    ├── conftest.py                 # Shared fixtures
    ├── test_encryption.py
    ├── test_evm_utils.py
    ├── test_svm_utils.py
    ├── test_sse.py
    └── test_wallet_client.py
```

## Build Commands

| Command                           | Description                                              |
| --------------------------------- | -------------------------------------------------------- |
| `maturin develop`                 | Build native extension in dev mode and install into venv |
| `maturin develop --release`       | Build with optimizations                                 |
| `maturin build --release`         | Build a distributable wheel in `python/target/wheels/`   |
| `pytest`                          | Run all tests                                            |
| `pytest -v`                       | Run tests with verbose output                            |
| `pytest tests/test_encryption.py` | Run a specific test file                                 |

## Troubleshooting

### `cargo` not found

Install the Rust toolchain:

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source ~/.cargo/env
```

### Registry authentication failure

If you see `authenticated registries require a credential-provider to be available`:

1. Verify `~/.cargo/credentials.toml` has the `[registries.dynamic-mpc]` section with your registry token
2. Verify `.cargo/config.toml` has `global-credential-providers = ["cargo:token"]`

### `maturin develop` fails with compilation errors

Make sure you're using a compatible Rust version (1.75+). Update with:

```bash
rustup update stable
```

### ImportError for `dynamic_wallet_mpc`

The native module wasn't built or the venv isn't activated. Run:

```bash
source .venv/bin/activate
maturin develop
```

### Slow encryption tests

PBKDF2 with 1M iterations takes ~1-2 seconds per encrypt/decrypt. This is by design.
