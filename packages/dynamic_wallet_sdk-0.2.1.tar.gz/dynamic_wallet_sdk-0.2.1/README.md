# Dynamic Wallet SDK for Python

A Python SDK for [Dynamic](https://www.dynamic.xyz/)'s MPC (Multi-Party Computation) wallet infrastructure. Create, sign with, and manage non-custodial wallets from Python — no browser required.

## Installation

```bash
pip install dynamic-wallet-sdk
```

Pre-built wheels are provided for Linux (x86_64, ARM64) and macOS (x86_64, Apple Silicon). No Rust toolchain required.

## Requirements

- Python 3.11+
- A Dynamic environment ID and API token — from the [Dynamic dashboard](https://app.dynamic.xyz/)

## Quick Start

### EVM Wallet

```python
import asyncio
from dynamic_wallet_sdk.evm.client import DynamicEvmWalletClient

async def main():
    async with DynamicEvmWalletClient("your-environment-id") as client:
        await client.authenticate_api_token("your-api-token")

        # Create wallet (MPC keygen)
        address = await client.create_wallet_account(password="backup-password")
        print(f"Created EVM wallet: {address}")

        # Sign a message (EIP-191)
        signature = await client.sign_message(message="Hello, Dynamic!", address=address)
        print(f"Signature: {signature}")

        # Sign EIP-712 typed data
        typed_data = {
            "types": {...},
            "primaryType": "...",
            "domain": {...},
            "message": {...},
        }
        sig = await client.sign_typed_data(address, typed_data)

asyncio.run(main())
```

### Solana (SVM) Wallet

```python
import asyncio
from dynamic_wallet_sdk.svm.client import DynamicSvmWalletClient

async def main():
    async with DynamicSvmWalletClient("your-environment-id") as client:
        await client.authenticate_api_token("your-api-token")

        address = await client.create_wallet_account(password="backup-password")
        print(f"Created Solana wallet: {address}")

        signature = await client.sign_message(message="Hello from Solana!", address=address)
        print(f"Signature (base58): {signature}")

asyncio.run(main())
```

### Delegated Signing

For server-side signing where key shares are held by your server:

```python
from dynamic_wallet_sdk.delegated.client import (
    create_delegated_evm_client,
    delegated_sign_message,
)
from dynamic_wallet_sdk.delegated.decrypt import decrypt_delegated_webhook_data

# 1. Decrypt the webhook payload you received from Dynamic
decrypted = decrypt_delegated_webhook_data(
    private_key_pem=rsa_private_key,
    encrypted_delegated_key_share=webhook["encryptedDelegatedShare"],
    encrypted_wallet_api_key=webhook["encryptedWalletApiKey"],
)

# 2. Create a client and sign
client = await create_delegated_evm_client("env-id", "api-key")
sig = await delegated_sign_message(
    client,
    wallet_id="wallet-id",
    wallet_api_key=decrypted.decrypted_wallet_api_key,
    key_share=decrypted.decrypted_delegated_share["secretShare"],
    message="0x...",
    chain_name="EVM",
    is_formatted=True,
)
```

## Key Concepts

### Key Backup and Recovery

Pass a `password` to `create_wallet_account()` to encrypt and back up key shares with Dynamic at keygen time. Recover them later with:

```python
shares = await client.recover_key_shares(address, password="backup-password")
```

Key shares are encrypted with AES-256-GCM using a PBKDF2-derived key (SHA-256, 1M iterations).

### Threshold Signature Schemes

The SDK supports three TSS configurations:

| Scheme          | Parties | Threshold | Client Shares | Server Shares |
| --------------- | ------- | --------- | ------------- | ------------- |
| `TWO_OF_TWO`    | 2       | 2         | 1             | 1             |
| `TWO_OF_THREE`  | 3       | 2         | 2             | 1             |
| `THREE_OF_FIVE` | 5       | 3         | 3             | 2             |

### Chain Support

| Chain        | Algorithm | Client Class             |
| ------------ | --------- | ------------------------ |
| EVM          | ECDSA     | `DynamicEvmWalletClient` |
| SVM (Solana) | Ed25519   | `DynamicSvmWalletClient` |

## Links

- [Dynamic Dashboard](https://app.dynamic.xyz/)
- [Dynamic Docs](https://docs.dynamic.xyz/)
