"""Server-Sent Events (SSE) parsing and streaming.

Ported from packages/core/src/eventStream/utils.ts.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

import httpx

from dynamic_wallet_sdk.exceptions import DynamicSDKError, SSEError, SSETimeoutError

_log = logging.getLogger("dynamic_wallet_sdk.sse")


def _raise_for_status(resp: httpx.Response) -> None:
    try:
        resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        body = ""
        try:
            body = exc.response.text[:500]
        except Exception:
            pass
        raise DynamicSDKError(
            f"API request failed: {exc.response.status_code} {exc.request.url} — {body}"
        ) from exc


@dataclass
class SSEEvent:
    type: str
    data: Any


def _parse_block(block: str) -> SSEEvent | None:
    """Parse a single SSE event block (lines between blank separators)."""
    current_type: str | None = None
    current_data: str | None = None
    for line in block.split("\n"):
        if line.startswith("event:"):
            current_type = line[6:].strip()
        elif line.startswith("data:"):
            current_data = line[5:].strip()
        elif current_data is not None:
            current_data += line  # multi-line data continuation
    if not (current_type and current_data):
        return None
    try:
        return SSEEvent(type=current_type, data=json.loads(current_data))
    except json.JSONDecodeError:
        return SSEEvent(type=current_type, data=current_data)


def parse_sse_events(text: str) -> list[SSEEvent]:
    """Parse raw SSE text into structured events.

    SSE format:
        event: {type}
        data: {json}
        <blank line>

    Events are delimited by double newlines. Splitting on '\\n\\n' avoids
    treating a trailing newline on a data line as a premature event separator.
    Only blocks that are properly terminated by a blank line are emitted —
    an incomplete block at the end of the buffer is held until more data arrives.
    """
    blocks = text.split("\n\n")
    # If text doesn't end with \n\n the last block is incomplete (still buffering)
    complete_blocks = blocks if text.endswith("\n\n") else blocks[:-1]
    events: list[SSEEvent] = []
    for block in complete_blocks:
        block = block.strip()
        if not block:
            continue
        event = _parse_block(block)
        if event:
            events.append(event)
    return events


def _clear_buffer(buffer: str) -> str:
    last = buffer.rfind("\n\n")
    return buffer[last + 2 :] if last >= 0 else buffer


def _extract_error(event: SSEEvent) -> str:
    return (
        event.data.get("error", "Unknown error")
        if isinstance(event.data, dict)
        else str(event.data)
    )


async def _do_stream(
    client: httpx.AsyncClient,
    url: str,
    body: dict | None,
    request_headers: dict[str, str],
    success_event: str,
) -> Any:
    """Inner streaming loop for stream_sse_request."""
    buffer = ""
    async with client.stream("POST", url, json=body, headers=request_headers) as response:
        _raise_for_status(response)
        async for line in response.aiter_lines():
            buffer += line + "\n"
            for event in parse_sse_events(buffer):
                if event.type == success_event:
                    return event.data
                if event.type == "error":
                    raise SSEError(_extract_error(event))
            buffer = _clear_buffer(buffer)
    raise SSEError("Stream ended without success event")


_SSE_REQUEST_TIMEOUT = 30.0
_SSE_CALLBACK_TIMEOUT = 60.0


async def stream_sse_request(
    client: httpx.AsyncClient,
    url: str,
    body: dict | None,
    success_event: str,
    headers: dict[str, str] | None = None,
) -> Any:
    """POST to an SSE endpoint and wait for a success event.

    Times out after 30 seconds. Wrap the call with asyncio.timeout() for a
    custom deadline.

    Args:
        client: httpx async client.
        url: The endpoint URL.
        body: JSON body for the POST.
        success_event: The event type that signals success.
        headers: Additional headers.

    Returns:
        The parsed data from the success event.

    Raises:
        SSETimeoutError: If the 30-second timeout expires before a success event.
        SSEError: If an error event is received.
    """
    request_headers: dict[str, str] = {
        "Accept": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }
    if headers:
        request_headers.update(headers)

    try:
        async with asyncio.timeout(_SSE_REQUEST_TIMEOUT):
            return await _do_stream(client, url, body, request_headers, success_event)
    except asyncio.TimeoutError:
        raise SSETimeoutError(
            f"SSE request to {url} timed out after {_SSE_REQUEST_TIMEOUT}s"
        ) from None


async def _sse_reader(
    response: httpx.Response,
    queue: asyncio.Queue[SSEEvent | None],
) -> None:
    """Read SSE lines from a response and push parsed events onto a queue."""
    buffer = ""
    try:
        async for line in response.aiter_lines():
            buffer += line + "\n"
            events = parse_sse_events(buffer)
            for event in events:
                _log.debug("SSE event: type=%s", event.type)
                await queue.put(event)
            if events:
                buffer = _clear_buffer(buffer)
    finally:
        await queue.put(None)  # Signal end of stream


async def _wait_for_trigger(
    queue: asyncio.Queue[SSEEvent | None],
    trigger_event: str,
) -> Any:
    """Phase 1: Drain the queue until the trigger event arrives."""
    while True:
        event = await queue.get()
        if event is None:
            raise SSEError(f"Stream ended without {trigger_event}")
        if event.type == trigger_event:
            return event.data
        if event.type == "error":
            raise SSEError(_extract_error(event))


async def _watch_for_terminal_event(
    queue: asyncio.Queue[SSEEvent | None],
) -> SSEEvent | None:
    """Drain the queue until an error or ceremony_complete event (or end of stream)."""
    while True:
        ev = await queue.get()
        if ev is None:
            return None
        if ev.type in ("error", "ceremony_complete"):
            return ev


async def _await_ceremony_complete(
    queue: asyncio.Queue[SSEEvent | None],
    mpc_result: Any,
) -> tuple[Any, dict | None]:
    """Phase 3: Brief wait for ceremony_complete after MPC finishes."""
    try:
        while True:
            async with asyncio.timeout(10.0):
                event = await queue.get()
            if event is None:
                break
            if event.type == "ceremony_complete":
                return mpc_result, event.data
            if event.type == "error":
                raise SSEError(_extract_error(event))
    except asyncio.TimeoutError:
        pass
    return mpc_result, None


async def _handle_error_watch_first(
    mpc_task: asyncio.Task,
    error_watch: asyncio.Task,
) -> tuple[Any, dict | None]:
    """Handle the case where an error/ceremony event arrived before MPC completed."""
    mpc_task.cancel()
    with contextlib.suppress(asyncio.CancelledError, Exception):
        await mpc_task
    ev = error_watch.result()
    if ev and ev.type == "error":
        raise SSEError(_extract_error(ev))
    if ev and ev.type == "ceremony_complete":
        raise SSEError("ceremony_complete before MPC finished")
    raise SSEError("Stream ended during MPC")


async def _run_mpc_phase(
    queue: asyncio.Queue[SSEEvent | None],
    mpc_callback: Callable[[dict], Awaitable[Any]],
    trigger_data: Any,
) -> tuple[Any, dict | None]:
    """Phase 2+3: Run MPC callback while watching the event stream for errors."""
    mpc_task = asyncio.create_task(mpc_callback(trigger_data))
    error_watch = asyncio.create_task(_watch_for_terminal_event(queue))

    done, _ = await asyncio.wait([mpc_task, error_watch], return_when=asyncio.FIRST_COMPLETED)

    if mpc_task not in done:
        return await _handle_error_watch_first(mpc_task, error_watch)

    try:
        mpc_result = mpc_task.result()
    except Exception:
        error_watch.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await error_watch
        raise
    _log.debug("MPC callback completed")

    if error_watch in done:
        ev = error_watch.result()
        if ev and ev.type == "error":
            raise SSEError(_extract_error(ev))
        if ev and ev.type == "ceremony_complete":
            return mpc_result, ev.data
    else:
        error_watch.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await error_watch

    return await _await_ceremony_complete(queue, mpc_result)


async def _do_stream_with_callback(
    client: httpx.AsyncClient,
    url: str,
    body: dict | None,
    request_headers: dict[str, str],
    trigger_event: str,
    mpc_callback: Callable[[dict], Awaitable[Any]],
) -> tuple[Any, dict | None]:
    """Inner streaming loop for stream_sse_with_callback."""
    async with client.stream("POST", url, json=body, headers=request_headers) as response:
        _raise_for_status(response)
        queue: asyncio.Queue[SSEEvent | None] = asyncio.Queue()
        reader_task = asyncio.create_task(_sse_reader(response, queue))
        try:
            trigger_data = await _wait_for_trigger(queue, trigger_event)
            _log.debug("Trigger event received, starting MPC callback")
            return await _run_mpc_phase(queue, mpc_callback, trigger_data)
        finally:
            reader_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await reader_task


async def stream_sse_with_callback(
    client: httpx.AsyncClient,
    url: str,
    body: dict | None,
    trigger_event: str,
    mpc_callback: Callable[[dict], Awaitable[Any]],
    headers: dict[str, str] | None = None,
) -> tuple[Any, dict | None]:
    """SSE flow that keeps the stream open during an MPC callback.

    The server sends a trigger event (e.g. keygen_complete or room_created),
    the callback runs MPC while the stream stays open, then optionally waits
    for ceremony_complete.

    Times out after 60 seconds. Wrap the call with asyncio.timeout() for a
    custom deadline.

    IMPORTANT: The SSE stream is read concurrently with the MPC callback.
    The server (Node.js) may need to write status events to the stream
    before it can join the MPC relay room. If we block reading, the server's
    writes can stall due to TCP backpressure, causing a deadlock.

    Args:
        client: httpx async client.
        url: The SSE endpoint URL.
        body: JSON body for the POST.
        trigger_event: The event type that triggers the MPC callback.
        mpc_callback: Async function called with the trigger event data.
        headers: Additional headers.

    Returns:
        Tuple of (mpc_callback_result, ceremony_complete_data or None).
    """
    request_headers: dict[str, str] = {
        "Accept": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }
    if headers:
        request_headers.update(headers)

    try:
        async with asyncio.timeout(_SSE_CALLBACK_TIMEOUT):
            return await _do_stream_with_callback(
                client, url, body, request_headers, trigger_event, mpc_callback
            )
    except asyncio.TimeoutError:
        raise SSETimeoutError(
            f"SSE request to {url} timed out after {_SSE_CALLBACK_TIMEOUT}s"
        ) from None


# Convenience aliases
stream_sse_keygen = stream_sse_with_callback
