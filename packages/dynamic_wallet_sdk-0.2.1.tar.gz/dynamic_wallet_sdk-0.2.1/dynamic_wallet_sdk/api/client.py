"""Base HTTP client for Dynamic API.

Ported from packages/core/src/api/client.ts.
"""

from __future__ import annotations

import uuid

import httpx

from dynamic_wallet_sdk.exceptions import DynamicSDKError
from dynamic_wallet_sdk.constants import (
    DYNAMIC_AUTH_BASE_API_URL_MAP,
    DYNAMIC_AUTH_PROD_BASE_API_URL,
    DYNAMIC_CLIENT_RELAY_API_KEY_MAP,
    DYNAMIC_CLIENT_RELAY_APP_ID_MAP,
    DYNAMIC_KEYSHARES_RELAY_MAP,
    DYNAMIC_REQUEST_ID_HEADER,
    RELAY_API_KEY_HEADER,
    RELAY_APP_ID_HEADER,
    SDK_VERSION,
    Environment,
    detect_environment,
)


def _make_request_id() -> str:
    return uuid.uuid4().hex


class BaseClient:
    """Base HTTP client with two httpx clients: API + relay."""

    def __init__(
        self,
        *,
        environment_id: str,
        auth_token: str = "",
        base_api_url: str | None = None,
        base_keyshares_relay_url: str | None = None,
    ) -> None:
        self.environment_id = environment_id

        # Detect environment
        if base_api_url:
            self._base_api_url = base_api_url.rstrip("/")
            self._environment = detect_environment(base_api_url)
        else:
            self._environment = Environment.PRODUCTION
            self._base_api_url = DYNAMIC_AUTH_BASE_API_URL_MAP[self._environment]

        # API client
        self.api_client = httpx.AsyncClient(
            base_url=self._base_api_url,
            headers={
                "Content-Type": "application/json",
                "x-dyn-wallet-sdk-version": SDK_VERSION,
            },
            timeout=60.0,
        )

        # Auth token
        self._auth_token = auth_token
        if auth_token:
            self.api_client.headers["Authorization"] = f"Bearer {auth_token}"

        # Relay client (Evervault keyshares relay)
        if base_keyshares_relay_url:
            relay_base = base_keyshares_relay_url.rstrip("/")
        else:
            relay_base = DYNAMIC_KEYSHARES_RELAY_MAP.get(
                self._environment,
                DYNAMIC_KEYSHARES_RELAY_MAP[Environment.PREPROD],
            )

        relay_headers: dict[str, str] = {
            "Content-Type": "application/json",
            "x-dyn-wallet-sdk-version": SDK_VERSION,
        }
        if auth_token:
            relay_headers["Authorization"] = f"Bearer {auth_token}"

        app_id = DYNAMIC_CLIENT_RELAY_APP_ID_MAP.get(self._environment)
        api_key = DYNAMIC_CLIENT_RELAY_API_KEY_MAP.get(self._environment)
        if app_id:
            relay_headers[RELAY_APP_ID_HEADER] = app_id
        if api_key:
            relay_headers[RELAY_API_KEY_HEADER] = api_key

        self.relay_client = httpx.AsyncClient(
            base_url=relay_base,
            headers=relay_headers,
            timeout=60.0,
        )

    @staticmethod
    def _raise_for_status(resp: httpx.Response) -> None:
        """Raise a DynamicSDKError if the response indicates an HTTP error."""
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            body = ""
            try:
                body = exc.response.text[:500]
            except Exception:
                pass
            raise DynamicSDKError(
                f"API request failed: {exc.response.status_code} {exc.request.url} — {body}"
            ) from exc

    def set_auth_token(self, token: str) -> None:
        """Update the authorization token on both clients."""
        self._auth_token = token
        self.api_client.headers["Authorization"] = f"Bearer {token}"
        self.relay_client.headers["Authorization"] = f"Bearer {token}"

    async def close(self) -> None:
        await self.api_client.aclose()
        await self.relay_client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
