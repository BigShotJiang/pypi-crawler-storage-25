"""Dynamic API endpoints.

Ported from packages/core/src/api/api.ts.
"""

from __future__ import annotations

import uuid
from collections.abc import Awaitable, Callable
from typing import Any

from dynamic_wallet_sdk.api.client import BaseClient
from dynamic_wallet_sdk.api.sse import (
    stream_sse_keygen,
    stream_sse_request,
    stream_sse_with_callback,
)
from dynamic_wallet_sdk.constants import (
    DYNAMIC_ELEVATED_ACCESS_TOKEN_HEADER,
    DYNAMIC_MFA_TOKEN_HEADER,
    DYNAMIC_REQUEST_ID_HEADER,
    DYNAMIC_TRACE_ELAPSED_TIME_HEADER,
    DYNAMIC_TRACE_ID_HEADER,
    BackupLocation,
)
from dynamic_wallet_sdk.mpc_config import ThresholdSignatureScheme


def _request_id() -> str:
    return uuid.uuid4().hex


def _trace_headers(
    request_id: str | None = None,
    trace_id: str | None = None,
    mfa_token: str | None = None,
    elevated_access_token: str | None = None,
) -> dict[str, str]:
    headers: dict[str, str] = {}
    headers[DYNAMIC_REQUEST_ID_HEADER] = request_id or _request_id()
    if trace_id:
        headers[DYNAMIC_TRACE_ID_HEADER] = trace_id
    if mfa_token:
        headers[DYNAMIC_MFA_TOKEN_HEADER] = mfa_token
    if elevated_access_token:
        headers[DYNAMIC_ELEVATED_ACCESS_TOKEN_HEADER] = elevated_access_token
    return headers


class DynamicApiClient(BaseClient):
    """All Dynamic WaaS API endpoints."""

    # --- Authentication ---

    async def authenticate_api_token(self, environment_id: str) -> dict:
        """Exchange API token for JWT. POST /api/v0/environments/{env}/waas/authenticate."""
        resp = await self.api_client.post(
            f"/api/v0/environments/{environment_id}/waas/authenticate",
            headers={DYNAMIC_REQUEST_ID_HEADER: _request_id()},
        )
        self._raise_for_status(resp)
        return resp.json()

    # --- User ---

    async def get_user(self, request_id: str | None = None) -> dict:
        resp = await self.api_client.get(
            f"/api/v0/sdk/{self.environment_id}/users",
            headers=_trace_headers(request_id),
        )
        self._raise_for_status(resp)
        return resp.json()

    async def refresh_user(self) -> dict:
        resp = await self.api_client.post(
            f"/api/v0/sdk/{self.environment_id}/refresh",
            headers=_trace_headers(),
        )
        self._raise_for_status(resp)
        return resp.json()

    async def get_environment_settings(self) -> dict:
        resp = await self.api_client.get(
            f"/api/v0/sdk/{self.environment_id}/settings",
            headers=_trace_headers(),
        )
        self._raise_for_status(resp)
        return resp.json()

    # --- Wallet creation (SSE) ---

    async def create_wallet_account(
        self,
        *,
        chain_name: str,
        client_keygen_ids: list[str],
        threshold_signature_scheme: ThresholdSignatureScheme,
        skip_lock: bool = False,
        address_type: str | None = None,
        request_id: str | None = None,
    ) -> dict:
        """POST /api/v0/sdk/{env}/waas/create → SSE keygen_complete."""
        body: dict[str, Any] = {
            "chain": chain_name,
            "clientKeygenIds": client_keygen_ids,
            "thresholdSignatureScheme": threshold_signature_scheme.value,
        }
        if skip_lock:
            body["skipLock"] = True
        if address_type:
            body["addressType"] = address_type

        return await stream_sse_request(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/create",
            body=body,
            success_event="keygen_complete",
            headers=_trace_headers(request_id),
        )

    async def create_wallet_keygen(
        self,
        *,
        chain_name: str,
        client_keygen_ids: list[str],
        threshold_signature_scheme: ThresholdSignatureScheme,
        mpc_callback: Callable[..., Awaitable[Any]],
        skip_lock: bool = False,
        address_type: str | None = None,
        request_id: str | None = None,
    ) -> tuple[Any, dict | None]:
        """Keygen with SSE stream held open during MPC.

        Returns (mpc_callback_result, ceremony_complete_data).
        """
        body: dict[str, Any] = {
            "chain": chain_name,
            "clientKeygenIds": client_keygen_ids,
            "thresholdSignatureScheme": threshold_signature_scheme.value,
        }
        if skip_lock:
            body["skipLock"] = True
        if address_type:
            body["addressType"] = address_type

        return await stream_sse_keygen(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/create",
            body=body,
            trigger_event="keygen_complete",
            mpc_callback=mpc_callback,
            headers=_trace_headers(request_id),
        )

    async def import_private_key_keygen(
        self,
        *,
        chain_name: str,
        client_keygen_ids: list[str],
        threshold_signature_scheme: ThresholdSignatureScheme,
        mpc_callback: Callable[..., Awaitable[Any]],
        address_type: str | None = None,
        legacy_wallet_id: str | None = None,
        request_id: str | None = None,
    ) -> tuple[Any, dict | None]:
        """Import with SSE stream held open during MPC.

        Returns (mpc_callback_result, ceremony_complete_data).
        """
        body: dict[str, Any] = {
            "chain": chain_name,
            "clientKeygenIds": client_keygen_ids,
            "thresholdSignatureScheme": threshold_signature_scheme.value,
        }
        if address_type:
            body["addressType"] = address_type
        if legacy_wallet_id:
            body["legacyWalletId"] = legacy_wallet_id

        return await stream_sse_keygen(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/privateKey/import",
            body=body,
            trigger_event="keygen_complete",
            mpc_callback=mpc_callback,
            headers=_trace_headers(request_id),
        )

    # --- Signing (SSE) ---

    async def sign_message(
        self,
        *,
        wallet_id: str,
        message: str,
        is_formatted: bool = False,
        context: dict | None = None,
        room_id: str | None = None,
        mfa_token: str | None = None,
        request_id: str | None = None,
    ) -> dict:
        """POST /api/v0/sdk/{env}/waas/{wallet}/signMessage → SSE room_created."""
        body: dict[str, Any] = {
            "message": message,
            "isFormatted": is_formatted,
        }
        if context:
            body["context"] = context
        if room_id:
            body["roomId"] = room_id

        return await stream_sse_request(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/signMessage",
            body=body,
            success_event="room_created",
            headers=_trace_headers(request_id, mfa_token=mfa_token),
        )

    async def sign_message_with_callback(
        self,
        *,
        wallet_id: str,
        message: str,
        mpc_callback: Callable[..., Awaitable[Any]],
        is_formatted: bool = False,
        context: dict | None = None,
        room_id: str | None = None,
        mfa_token: str | None = None,
        request_id: str | None = None,
    ) -> tuple[Any, dict | None]:
        """Sign with SSE stream held open during MPC.

        Returns (mpc_callback_result, ceremony_complete_data or None).
        """
        body: dict[str, Any] = {
            "message": message,
            "isFormatted": is_formatted,
        }
        if context:
            body["context"] = context
        if room_id:
            body["roomId"] = room_id

        return await stream_sse_with_callback(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/signMessage",
            body=body,
            trigger_event="room_created",
            mpc_callback=mpc_callback,
            headers=_trace_headers(request_id, mfa_token=mfa_token),
        )

    # --- Refresh (SSE) ---

    async def refresh_wallet_account_shares(
        self,
        *,
        wallet_id: str,
        mfa_token: str | None = None,
        request_id: str | None = None,
    ) -> dict:
        """POST /api/v0/sdk/{env}/waas/{wallet}/refresh → SSE room_created."""
        return await stream_sse_request(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/refresh",
            body=None,
            success_event="room_created",
            headers=_trace_headers(request_id, mfa_token=mfa_token),
        )

    # --- Reshare (SSE) ---

    async def reshare(
        self,
        *,
        wallet_id: str,
        client_keygen_ids: list[str],
        old_threshold_signature_scheme: ThresholdSignatureScheme,
        new_threshold_signature_scheme: ThresholdSignatureScheme,
        delegate_to_project_environment: bool | None = None,
        revoke_delegation: bool | None = None,
        mfa_token: str | None = None,
        request_id: str | None = None,
    ) -> dict:
        body: dict[str, Any] = {
            "clientKeygenIds": client_keygen_ids,
            "oldThresholdSignatureScheme": old_threshold_signature_scheme.value,
            "newThresholdSignatureScheme": new_threshold_signature_scheme.value,
        }
        if delegate_to_project_environment is not None:
            body["delegateToProjectEnvironment"] = delegate_to_project_environment
        if revoke_delegation is not None:
            body["revokeDelegation"] = revoke_delegation

        return await stream_sse_request(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/reshare",
            body=body,
            success_event="room_created",
            headers=_trace_headers(request_id, mfa_token=mfa_token),
        )

    # --- Export (SSE) ---

    async def export_key(
        self,
        *,
        wallet_id: str,
        export_id: str,
        address_type: str | None = None,
        mfa_token: str | None = None,
        elevated_access_token: str | None = None,
        request_id: str | None = None,
    ) -> dict:
        body: dict[str, Any] = {"exportId": export_id}
        if address_type:
            body["addressType"] = address_type

        return await stream_sse_request(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/privateKey/export",
            body=body,
            success_event="room_created",
            headers=_trace_headers(
                request_id,
                mfa_token=mfa_token,
                elevated_access_token=elevated_access_token,
            ),
        )

    # --- Import (SSE) ---

    async def import_private_key(
        self,
        *,
        chain_name: str,
        client_keygen_ids: list[str],
        threshold_signature_scheme: ThresholdSignatureScheme,
        address_type: str | None = None,
        legacy_wallet_id: str | None = None,
        request_id: str | None = None,
    ) -> dict:
        body: dict[str, Any] = {
            "chain": chain_name,
            "clientKeygenIds": client_keygen_ids,
            "thresholdSignatureScheme": threshold_signature_scheme.value,
        }
        if address_type:
            body["addressType"] = address_type
        if legacy_wallet_id:
            body["legacyWalletId"] = legacy_wallet_id

        return await stream_sse_request(
            client=self.api_client,
            url=f"/api/v0/sdk/{self.environment_id}/waas/privateKey/import",
            body=body,
            success_event="keygen_complete",
            headers=_trace_headers(request_id),
        )

    # --- Wallet lookup ---

    async def get_waas_wallet_by_id(self, wallet_id: str) -> dict:
        resp = await self.api_client.get(
            f"/api/v0/environments/{self.environment_id}/waas/{wallet_id}",
            headers=_trace_headers(),
        )
        self._raise_for_status(resp)
        return resp.json()

    async def get_waas_wallet_by_address(self, wallet_address: str) -> dict:
        resp = await self.api_client.get(
            f"/api/v0/sdk/{self.environment_id}/waas/byWalletAddress/{wallet_address}",
            headers=_trace_headers(),
        )
        self._raise_for_status(resp)
        return resp.json()

    # --- Backup operations ---

    async def get_backup_relay_token(self) -> str:
        resp = await self.api_client.get(
            f"/api/v0/sdk/{self.environment_id}/waas/keyShares/backup/token",
            headers=_trace_headers(),
        )
        self._raise_for_status(resp)
        return resp.json()["token"]

    async def store_encrypted_backup(
        self,
        *,
        wallet_id: str,
        encrypted_key_shares: list[str],
        password_encrypted: bool,
        encryption_version: str | None = None,
        request_id: str | None = None,
    ) -> dict:
        """Store encrypted backup via relay client (Evervault)."""
        body: dict[str, Any] = {
            "encryptedAccountCredentials": encrypted_key_shares,
            "passwordEncrypted": password_encrypted,
        }
        if encryption_version:
            body["encryptionVersion"] = encryption_version

        resp = await self.relay_client.post(
            f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/keyShares/backup",
            json=body,
            headers=_trace_headers(request_id),
        )
        self._raise_for_status(resp)
        return resp.json()

    async def recover_encrypted_backup(
        self,
        *,
        wallet_id: str,
        key_share_ids: list[str] | None = None,
        mfa_token: str | None = None,
        request_id: str | None = None,
    ) -> dict:
        """Recover encrypted backup via relay client (Evervault)."""
        body = {"keyShareIds": key_share_ids} if key_share_ids else None
        resp = await self.relay_client.post(
            f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/keyShares/recover",
            json=body,
            headers=_trace_headers(request_id, mfa_token=mfa_token),
        )
        self._raise_for_status(resp)
        return resp.json()

    async def mark_key_shares_as_backed_up(
        self,
        *,
        wallet_id: str,
        locations: list[dict],
        request_id: str | None = None,
    ) -> dict:
        resp = await self.api_client.post(
            f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/keyShares/backup/locations",
            json={"locations": locations},
            headers=_trace_headers(request_id),
        )
        self._raise_for_status(resp)
        return resp.json()

    # --- Delegated access ---

    async def get_delegated_encryption_key(self) -> dict:
        resp = await self.api_client.get(
            f"/api/v0/sdk/{self.environment_id}/waas/delegatedAccess/encryptionPublicKey",
            headers=_trace_headers(),
        )
        self._raise_for_status(resp)
        return resp.json()

    async def publish_delegated_key_share(
        self,
        *,
        wallet_id: str,
        encrypted_key_share: dict,
        request_id: str | None = None,
    ) -> dict:
        resp = await self.api_client.post(
            f"/api/v0/sdk/{self.environment_id}/waas/{wallet_id}/delegatedAccess/delivery",
            json={"encryptedDelegatedShare": encrypted_key_share},
            headers=_trace_headers(request_id),
        )
        self._raise_for_status(resp)
        return resp.json()

    async def delegated_sign_message(
        self,
        *,
        wallet_id: str,
        message: str,
        is_formatted: bool = False,
        context: dict | None = None,
        request_id: str | None = None,
        wallet_api_key: str | None = None,
    ) -> dict:
        """POST /api/v0/environments/{env}/waas/{wallet}/delegatedAccess/signMessage → SSE."""
        body: dict[str, Any] = {
            "message": message,
            "isFormatted": is_formatted,
        }
        if context:
            body["context"] = context

        headers = _trace_headers(request_id)
        if wallet_api_key:
            headers["x-dyn-wallet-api-key"] = wallet_api_key

        return await stream_sse_request(
            client=self.api_client,
            url=f"/api/v0/environments/{self.environment_id}/waas/{wallet_id}/delegatedAccess/signMessage",
            body=body,
            success_event="room_created",
            headers=headers,
        )
