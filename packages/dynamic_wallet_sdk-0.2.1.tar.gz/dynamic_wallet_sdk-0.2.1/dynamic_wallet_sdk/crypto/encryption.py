"""AES-256-GCM encryption with PBKDF2 key derivation.

Ported from packages/node/src/backup/encryption.ts.
"""

from __future__ import annotations

import base64
import os
from dataclasses import dataclass
from typing import Final

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

ENCRYPTION_VERSION_LEGACY: Final = "v1"
ENCRYPTION_VERSION_CURRENT: Final = "v2"

PBKDF2_ITERATIONS_V1: Final = 100_000
PBKDF2_ITERATIONS_V2: Final = 1_000_000

ENCRYPTION_VERSIONS: Final = {
    ENCRYPTION_VERSION_LEGACY: {
        "version": ENCRYPTION_VERSION_LEGACY,
        "algorithm": "AES-GCM",
        "key_derivation": "PBKDF2",
        "iterations": PBKDF2_ITERATIONS_V1,
        "hash_algorithm": "SHA-256",
        "algorithm_length": 256,
    },
    ENCRYPTION_VERSION_CURRENT: {
        "version": ENCRYPTION_VERSION_CURRENT,
        "algorithm": "AES-GCM",
        "key_derivation": "PBKDF2",
        "iterations": PBKDF2_ITERATIONS_V2,
        "hash_algorithm": "SHA-256",
        "algorithm_length": 256,
    },
}


@dataclass
class EncryptedData:
    salt: str  # base64
    iv: str  # base64
    cipher: str  # base64
    version: str


def _ensure_base64_padding(data: str) -> str:
    """Ensure proper base64 padding."""
    missing = len(data) % 4
    if missing:
        data += "=" * (4 - missing)
    return data


def _derive_key(password: str, salt: bytes, iterations: int) -> bytes:
    """Derive AES-256 key from password using PBKDF2."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # 256 bits
        salt=salt,
        iterations=iterations,
    )
    return kdf.derive(password.encode("utf-8"))


def encrypt_data(
    data: str,
    password: str,
    version: str = ENCRYPTION_VERSION_CURRENT,
) -> EncryptedData:
    """Encrypt data using AES-256-GCM with PBKDF2 key derivation.

    Args:
        data: The plaintext string to encrypt.
        password: The password for key derivation.
        version: Encryption version ("v1" or "v2").

    Returns:
        EncryptedData with base64-encoded salt, iv, and cipher.
    """
    config = ENCRYPTION_VERSIONS.get(version)
    if not config:
        raise ValueError(f"Unsupported encryption version: {version}")

    salt = os.urandom(16)
    iv = os.urandom(12)  # AES-GCM uses 12-byte nonce

    key = _derive_key(password, salt, config["iterations"])
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(iv, data.encode("utf-8"), None)

    return EncryptedData(
        salt=base64.b64encode(salt).decode("ascii"),
        iv=base64.b64encode(iv).decode("ascii"),
        cipher=base64.b64encode(ciphertext).decode("ascii"),
        version=version,
    )


def decrypt_data(
    data: EncryptedData | dict,
    password: str,
) -> str:
    """Decrypt data encrypted with encrypt_data.

    Args:
        data: EncryptedData or dict with salt, iv, cipher, and optional version.
        password: The password used for encryption.

    Returns:
        The decrypted plaintext string.
    """
    if isinstance(data, dict):
        salt_b64 = data["salt"]
        iv_b64 = data["iv"]
        cipher_b64 = data["cipher"]
        version = data.get("version")
    else:
        salt_b64 = data.salt
        iv_b64 = data.iv
        cipher_b64 = data.cipher
        version = data.version

    salt = base64.b64decode(_ensure_base64_padding(salt_b64))
    iv = base64.b64decode(_ensure_base64_padding(iv_b64))
    ciphertext = base64.b64decode(_ensure_base64_padding(cipher_b64))

    if version and version in ENCRYPTION_VERSIONS:
        config = ENCRYPTION_VERSIONS[version]
    else:
        # Fallback to legacy for backward compatibility
        config = ENCRYPTION_VERSIONS[ENCRYPTION_VERSION_LEGACY]

    key = _derive_key(password, salt, config["iterations"])
    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(iv, ciphertext, None)

    return plaintext.decode("utf-8")


def get_encryption_metadata(version: str) -> dict:
    """Get encryption metadata for a specific version."""
    config = ENCRYPTION_VERSIONS.get(version)
    if not config:
        raise ValueError(f"Unsupported encryption version: {version}")
    return {
        "algorithm": config["algorithm"],
        "keyDerivation": config["key_derivation"],
        "iterations": config["iterations"],
        "hashAlgorithm": config["hash_algorithm"],
        "algorithmLength": config["algorithm_length"],
    }
