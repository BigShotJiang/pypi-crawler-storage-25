"""Base wallet client orchestrating MPC operations.

This is the core of the SDK. DynamicWalletClient manages the full lifecycle:
  auth → keygen → sign → refresh → export → import → backup → recovery

Chain-specific clients (DynamicEvmWalletClient, DynamicSvmWalletClient) extend
this class and handle chain-level encoding before delegating here.

Architecture overview: see python/ARCHITECTURE.md
Ported from packages/node/src/client.ts.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import uuid
from typing import Any

from dynamic_wallet_sdk.api.dynamic_api import DynamicApiClient
from dynamic_wallet_sdk.constants import (
    MPC_RELAY_URL_MAP,
    BackupLocation,
    Environment,
    detect_environment,
)
from dynamic_wallet_sdk.crypto.encryption import (
    ENCRYPTION_VERSION_CURRENT,
    decrypt_data,
    encrypt_data,
)
from dynamic_wallet_sdk.exceptions import (
    AuthenticationError,
    DynamicSDKError,
    SSEError,
    WalletNotFoundError,
)
from dynamic_wallet_sdk.mpc.signer import get_mpc_signer
from dynamic_wallet_sdk.mpc.types import (
    BackupLocationInfo,
    KeyShareBackupInfo,
    ServerKeyShare,
    WalletProperties,
)
from dynamic_wallet_sdk.mpc_config import (
    MPC_CHAIN_CONFIG,
    MPC_CONFIG,
    SigningAlgorithm,
    ThresholdSignatureScheme,
)

logger = logging.getLogger("dynamic_wallet_sdk")


class DynamicWalletClient:
    """Base MPC wallet client with keygen, sign, refresh, export, import, and backup.

    Subclass this for each chain (see DynamicEvmWalletClient, DynamicSvmWalletClient).
    Do NOT call the Dynamic API or MPC relay directly from subclasses — use the
    methods on this class. Subclasses only handle chain-specific message formatting.

    The wallet map (_wallet_map) holds all in-memory wallet state. Access it only
    through get_wallet_from_map() and update_wallet_in_map() so that address
    normalization is applied consistently.
    """

    def __init__(
        self,
        environment_id: str,
        *,
        base_api_url: str | None = None,
        base_mpc_relay_url: str | None = None,
        debug: bool = False,
    ) -> None:
        self.environment_id = environment_id
        self.debug = debug

        if debug:
            logging.basicConfig(level=logging.DEBUG)

        self._base_api_url = base_api_url
        env = detect_environment(base_api_url or "")
        self._base_mpc_relay_url = base_mpc_relay_url or MPC_RELAY_URL_MAP.get(
            env, MPC_RELAY_URL_MAP[Environment.PRODUCTION]
        )

        self._api_client = DynamicApiClient(
            environment_id=environment_id,
            base_api_url=base_api_url,
        )

        self._wallet_map: dict[str, WalletProperties] = {}
        self._is_authenticated = False

    # -------------------------------------------------------------------------
    # Address normalization + wallet map access
    # -------------------------------------------------------------------------
    # EVM addresses are case-insensitive hex strings (0x...). Solana addresses
    # are base58 and case-sensitive. We normalize EVM to lowercase so that
    # get_wallet_from_map("0xAbCd") and get_wallet_from_map("0xabcd") both hit
    # the same entry.

    def _normalize_address(self, address: str) -> str:
        """Normalize address for map lookups (lowercase for EVM, identity otherwise)."""
        return address.lower() if address.startswith("0x") else address

    def get_wallet_from_map(self, account_address: str) -> WalletProperties:
        key = self._normalize_address(account_address)
        wp = self._wallet_map.get(key)
        if wp is None:
            raise WalletNotFoundError(f"Wallet not found for address: {account_address}")
        return wp

    def update_wallet_in_map(self, account_address: str, **updates: Any) -> None:
        key = self._normalize_address(account_address)
        wp = self._wallet_map.get(key)
        if wp is None:
            raise WalletNotFoundError(f"Wallet not found for address: {account_address}")
        for k, v in updates.items():
            if hasattr(wp, k):
                setattr(wp, k, v)

    def _init_wallet_entry(
        self,
        *,
        account_address: str,
        wallet_id: str,
        chain_name: str,
        external_server_key_shares: list[ServerKeyShare],
        threshold_signature_scheme: ThresholdSignatureScheme,
        derivation_path: list[int] | None = None,
        address_type: str | None = None,
    ) -> None:
        key = self._normalize_address(account_address)
        self._wallet_map[key] = WalletProperties(
            chain_name=chain_name,
            wallet_id=wallet_id,
            account_address=account_address,
            external_server_key_shares=external_server_key_shares,
            threshold_signature_scheme=threshold_signature_scheme,
            derivation_path=derivation_path,
            address_type=address_type,
        )

    # -------------------------------------------------------------------------
    # Authentication
    # -------------------------------------------------------------------------

    async def authenticate_api_token(self, auth_token: str) -> None:
        """Exchange an API token for a JWT and authenticate the client.

        The API token (dyn_...) is exchanged for a short-lived JWT. All
        subsequent API calls use the JWT in the Authorization header. A fresh
        DynamicApiClient is swapped in after authentication so the old token
        is not retained.
        """
        tmp_client = DynamicApiClient(
            environment_id=self.environment_id,
            auth_token=auth_token,
            base_api_url=self._base_api_url,
        )
        try:
            data = await tmp_client.authenticate_api_token(self.environment_id)
            jwt_token = data["encodedJwts"]["minifiedJwt"]
        except Exception as e:
            raise AuthenticationError(f"Authentication failed: {e}") from e
        finally:
            await tmp_client.close()

        await self._api_client.close()
        self._api_client = DynamicApiClient(
            environment_id=self.environment_id,
            auth_token=jwt_token,
            base_api_url=self._base_api_url,
        )
        self._is_authenticated = True

    def _ensure_authenticated(self) -> None:
        if not self._is_authenticated:
            raise AuthenticationError(
                "Client must be authenticated before making API calls. "
                "Call authenticate_api_token first."
            )

    # -------------------------------------------------------------------------
    # MPC Keygen Orchestration
    #
    # Keygen is a 3-phase flow:
    #   Phase 1 (sync):  client calls init_keygen() locally → gets (keygen_id, keygen_secret)
    #   Phase 2 (async): server opens an SSE stream; on keygen_complete event, client
    #                    joins the MPC relay room and runs the MPC ceremony
    #   Phase 3 (sync):  client calls derive_pubkey() to get the wallet address
    #
    # The SSE stream stays open across the MPC ceremony so the server can send
    # ceremony_complete with the walletId after the relay finishes.
    #
    # For ECDSA chains: MPC uses standard keygen()
    # For SVM (ExportableEd25519): server calls sampleKey, client calls receiveKey
    # -------------------------------------------------------------------------

    def _external_server_init_keygen(
        self,
        chain_name: str,
        threshold_signature_scheme: ThresholdSignatureScheme,
    ) -> list[dict]:
        """Init keygen for each client party share (synchronous, no network I/O).

        Returns a list of {keygen_id, keygen_secret} dicts — one per client share.
        For TWO_OF_TWO this is always a single-element list (one client share, one
        server share). keygen_ids are sent to the server so it knows who to expect
        in the MPC room; keygen_secrets are used locally to run the MPC ceremony.
        """
        signer = get_mpc_signer(chain_name, self._base_mpc_relay_url)
        client_threshold = MPC_CONFIG[threshold_signature_scheme].client_threshold
        results = []
        for _ in range(client_threshold):
            init = signer.init_keygen()
            results.append({
                "keygen_id": init.keygen_id,
                "keygen_secret": init.keygen_secret,  # bytes (Vec<u8>)
            })
        return results

    async def _external_server_keygen(
        self,
        *,
        chain_name: str,
        room_id: str,
        dynamic_server_keygen_ids: list[str],
        external_init_results: list[dict],
        threshold_signature_scheme: ThresholdSignatureScheme,
    ) -> list[Any]:
        """Run MPC keygen for each client party share (connects to the MPC relay).

        Called as the MPC callback inside the SSE stream, after the server sends
        keygen_complete with the roomId and serverKeygenIds.

        dynamic_server_keygen_ids: keygen IDs from the Dynamic server parties.
        external_init_results: output from _external_server_init_keygen() — each entry
            is one client share that needs to participate in the ceremony.

        Returns a list of keygen results (one per client share), each having a
        .secret_share and (for ECDSA) .pubkey_uncompressed / .pubkey_compressed.
        """
        signer = get_mpc_signer(chain_name, self._base_mpc_relay_url)
        config = MPC_CONFIG[threshold_signature_scheme]

        chain_config = MPC_CHAIN_CONFIG.get(chain_name)
        if chain_config is None:
            raise DynamicSDKError(f"Unsupported chain: {chain_name!r}")
        is_ed25519 = chain_config.signing_algorithm == SigningAlgorithm.ED25519

        async def _run_one(current_init: dict) -> Any:
            other_ext_ids = [
                r["keygen_id"]
                for r in external_init_results
                if r["keygen_id"] != current_init["keygen_id"]
            ]
            all_other_ids = dynamic_server_keygen_ids + other_ext_ids

            if is_ed25519:
                # ExportableEd25519 uses receiveKey (server uses sampleKey)
                return await signer.receive_key(
                    room_id,
                    config.number_of_parties,
                    config.threshold,
                    current_init["keygen_secret"],  # bytes
                    all_other_ids,
                )
            else:
                # ECDSA uses standard keygen
                return await signer.keygen(
                    room_id,
                    config.number_of_parties,
                    config.threshold,
                    current_init["keygen_secret"],  # bytes
                    all_other_ids,
                )

        return list(await asyncio.gather(*[_run_one(init) for init in external_init_results]))

    async def keygen(
        self,
        chain_name: str,
        threshold_signature_scheme: ThresholdSignatureScheme,
        skip_lock: bool = False,
    ) -> dict:
        """Full keygen flow: init → server SSE → MPC keygen → derive pubkey.

        The SSE stream is held open during MPC keygen so the server can deliver
        ceremony_complete (which carries walletId) after the relay ceremony ends.

        Flow:
          1. init_keygen (sync): generate client-side keygen_id + keygen_secret
          2. POST /waas/create: open SSE stream, server starts its own keygen
          3. On keygen_complete: join relay room and run MPC ceremony concurrently
          4. ceremony_complete arrives: extract walletId
          5. derive_pubkey (sync): derive wallet address from secret_share

        Returns:
            Dict with 'raw_public_key', 'external_server_key_shares', and 'wallet_id'.
            Callers (chain-specific clients) convert raw_public_key to an address
            using chain-appropriate encoding (keccak256 for EVM, base58 for SVM).
        """
        self._ensure_authenticated()

        # 1. Client init keygen (synchronous)
        ext_init_results = self._external_server_init_keygen(
            chain_name, threshold_signature_scheme
        )
        ext_keygen_ids = [r["keygen_id"] for r in ext_init_results]

        # 2. MPC callback: runs inside the SSE stream after keygen_complete
        async def _mpc_keygen(keygen_data: dict) -> list:
            return await self._external_server_keygen(
                chain_name=chain_name,
                room_id=keygen_data["roomId"],
                dynamic_server_keygen_ids=keygen_data["serverKeygenIds"],
                external_init_results=ext_init_results,
                threshold_signature_scheme=threshold_signature_scheme,
            )

        # 3. SSE stream: keygen_complete → MPC → ceremony_complete
        keygen_results, ceremony_data = await self._api_client.create_wallet_keygen(
            chain_name=chain_name,
            client_keygen_ids=ext_keygen_ids,
            threshold_signature_scheme=threshold_signature_scheme,
            mpc_callback=_mpc_keygen,
            skip_lock=skip_lock,
        )

        # 4. Derive public key from first result (synchronous)
        first_result = keygen_results[0]
        chain_config = MPC_CHAIN_CONFIG.get(chain_name)
        if chain_config is None:
            raise DynamicSDKError(f"Unsupported chain: {chain_name!r}")
        signer = get_mpc_signer(chain_name, self._base_mpc_relay_url)
        deriv_path = chain_config.derivation_path
        raw_pubkey = signer.derive_pubkey(first_result.secret_share, deriv_path)

        # Convert keygen results to ServerKeyShare objects
        key_shares = [
            ServerKeyShare(
                key_share_id=ext_keygen_ids[i],
                secret_share=kr.secret_share,
            )
            for i, kr in enumerate(keygen_results)
        ]

        wallet_id = ceremony_data.get("walletId") if ceremony_data else None

        return {
            "raw_public_key": raw_pubkey,
            "external_server_key_shares": key_shares,
            "wallet_id": wallet_id,
        }

    # -------------------------------------------------------------------------
    # MPC Sign Orchestration
    #
    # Signing mirrors the keygen flow but is simpler — there's no "init" step.
    # The server opens an SSE stream, sends room_created with a roomId, and the
    # client joins the MPC relay room and signs the message.
    #
    # The message passed to the relay is always pre-hashed (is_formatted=True on the
    # client side). The server may receive a different (unformatted) version of
    # the message for its own signing half.
    #
    # Signing retries up to 3× on transient SSE stream closures.
    # -------------------------------------------------------------------------

    async def _external_server_sign(
        self,
        *,
        chain_name: str,
        room_id: str,
        key_share: str,
        message: str,
        derivation_path: list[int] | None = None,
    ) -> Any:
        """Run MPC sign operation on the Dynamic relay.

        Called as the MPC callback inside the SSE stream, after room_created.

        message: hex-encoded message for MPC signing. For ECDSA this is a 32-byte
            hash (64 hex chars). For Ed25519 this is the raw UTF-8 message as hex.
        derivation_path: BIP-32 path for ECDSA. Ignored for Ed25519 (no derivation).

        Returns PyEcdsaSignature (r, s, v, der) for ECDSA, or raw bytes for Ed25519.
        """
        chain_config = MPC_CHAIN_CONFIG.get(chain_name)
        if chain_config is None:
            raise DynamicSDKError(f"Unsupported chain: {chain_name!r}")
        signer = get_mpc_signer(chain_name, self._base_mpc_relay_url)
        path = derivation_path or chain_config.derivation_path

        if chain_config.signing_algorithm == SigningAlgorithm.ED25519:
            # Ed25519 sign takes message as bytes + derivation_path
            msg_bytes = bytes.fromhex(message) if isinstance(message, str) else message
            return await signer.sign(room_id, key_share, msg_bytes, path)
        else:
            from dynamic_wallet_mpc import PyMessageHash

            msg_hash = PyMessageHash(message)
            return await signer.sign(room_id, key_share, msg_hash, path)

    async def _sign_mpc_message(
        self,
        *,
        wallet_id: str,
        message: str,
        chain_name: str,
        key_share: str,
        derivation_path: list[int] | None = None,
        is_formatted: bool = False,
        server_message: str | None = None,
        server_is_formatted: bool | None = None,
        context: dict | None = None,
        mfa_token: str | None = None,
    ) -> Any:
        """Full sign flow: SSE stream kept open during MPC sign.

        The client and server sign different representations of the same message:
        - message / is_formatted: what the client (this SDK) passes to the MPC relay
        - server_message / server_is_formatted: what goes in the API request body

        When server_message is None, message is used for both sides.
        When server_is_formatted is None, is_formatted is used for both sides.

        isFormatted semantics (confusing but important):
          True  → "this message is already hashed/formatted, pass it straight to the relay"
          False → "apply chain-specific formatting before passing to the relay"

        For EVM:
          - message = keccak256(EIP-191 prefixed message), is_formatted=True
          - server_message = EIP-191 prefixed hex, server_is_formatted=False
        For SVM:
          - message = UTF-8 hex of raw message, is_formatted=False (same for server)

        Retries up to 3× on transient "Stream ended during MPC" errors (server-side
        SSE stream closure before the relay join completes).

        Returns:
            PyEcdsaSignature for ECDSA chains, or bytes for Ed25519 (SVM).
        """
        self._ensure_authenticated()

        async def _mpc_sign(room_data: dict) -> Any:
            return await self._external_server_sign(
                chain_name=chain_name,
                room_id=room_data["roomId"],
                key_share=key_share,
                message=message,
                derivation_path=derivation_path,
            )

        _retries = 3
        for _attempt in range(_retries):
            try:
                sign_result, _ceremony_data = await self._api_client.sign_message_with_callback(
                    wallet_id=wallet_id,
                    message=server_message if server_message is not None else message,
                    mpc_callback=_mpc_sign,
                    is_formatted=server_is_formatted if server_is_formatted is not None else is_formatted,
                    context=context,
                    mfa_token=mfa_token,
                )
                return sign_result
            except SSEError as exc:
                if _attempt < _retries - 1 and "Stream ended during MPC" in str(exc):
                    logger.warning("Sign attempt %d failed (%s), retrying...", _attempt + 1, exc)
                    await asyncio.sleep(1)
                    continue
                raise

    # -------------------------------------------------------------------------
    # Refresh
    # -------------------------------------------------------------------------

    async def refresh_wallet(
        self,
        *,
        wallet_id: str,
        chain_name: str,
        key_share: str,
        mfa_token: str | None = None,
    ) -> Any:
        """Refresh key shares without changing the public key."""
        self._ensure_authenticated()

        server_resp = await self._api_client.refresh_wallet_account_shares(
            wallet_id=wallet_id,
            mfa_token=mfa_token,
        )
        room_id = server_resp["roomId"]

        signer = get_mpc_signer(chain_name, self._base_mpc_relay_url)
        return await signer.refresh(room_id, key_share)

    # -------------------------------------------------------------------------
    # Export / Import
    # -------------------------------------------------------------------------

    async def _export_private_key_mpc(
        self,
        *,
        wallet_id: str,
        chain_name: str,
        key_share: str,
        mfa_token: str | None = None,
        elevated_access_token: str | None = None,
    ) -> str | None:
        """Export the full private key by combining shares.

        Returns:
            The xpriv string (for the exporter), or None for other parties.
        """
        self._ensure_authenticated()

        signer = get_mpc_signer(chain_name, self._base_mpc_relay_url)
        export_id = signer.export_id(key_share)  # synchronous

        server_resp = await self._api_client.export_key(
            wallet_id=wallet_id,
            export_id=export_id,
            mfa_token=mfa_token,
            elevated_access_token=elevated_access_token,
        )
        room_id = server_resp["roomId"]

        return await signer.export_full_private_key(room_id, key_share, export_id)

    async def _import_private_key_mpc(
        self,
        *,
        chain_name: str,
        private_key: str,
        threshold_signature_scheme: ThresholdSignatureScheme,
    ) -> dict:
        """Import an existing private key via MPC key sharing.

        Args:
            private_key: Hex-encoded private key bytes.

        Returns:
            Dict with 'raw_public_key', 'external_server_key_shares', and 'wallet_id'.
        """
        self._ensure_authenticated()

        signer = get_mpc_signer(chain_name, self._base_mpc_relay_url)
        ext_init_results = self._external_server_init_keygen(
            chain_name, threshold_signature_scheme
        )
        ext_keygen_ids = [r["keygen_id"] for r in ext_init_results]
        config = MPC_CONFIG[threshold_signature_scheme]

        chain_config = MPC_CHAIN_CONFIG.get(chain_name)
        if chain_config is None:
            raise DynamicSDKError(f"Unsupported chain: {chain_name!r}")
        is_ed25519 = chain_config.signing_algorithm == SigningAlgorithm.ED25519
        pk_bytes = bytes.fromhex(private_key) if isinstance(private_key, str) else private_key

        async def _mpc_import(keygen_data: dict) -> list:
            room_id = keygen_data["roomId"]
            server_keygen_ids = keygen_data["serverKeygenIds"]

            async def _run_one(i: int, current_init: dict) -> Any:
                other_ext_ids = [
                    r["keygen_id"]
                    for r in ext_init_results
                    if r["keygen_id"] != current_init["keygen_id"]
                ]
                all_other_ids = server_keygen_ids + other_ext_ids
                if i == 0:
                    if is_ed25519:
                        return await signer.import_private_key_importer(
                            room_id,
                            config.threshold,
                            pk_bytes,
                            False,
                            current_init["keygen_secret"],
                            all_other_ids,
                        )
                    return await signer.import_private_key_importer(
                        room_id,
                        config.threshold,
                        pk_bytes,
                        current_init["keygen_secret"],
                        all_other_ids,
                    )
                return await signer.import_private_key_recipient(
                    room_id,
                    config.threshold,
                    current_init["keygen_secret"],
                    all_other_ids,
                )

            return list(await asyncio.gather(*[_run_one(i, init) for i, init in enumerate(ext_init_results)]))

        import_results, ceremony_data = await self._api_client.import_private_key_keygen(
            chain_name=chain_name,
            client_keygen_ids=ext_keygen_ids,
            threshold_signature_scheme=threshold_signature_scheme,
            mpc_callback=_mpc_import,
        )

        # Derive public key (synchronous)
        first_result = import_results[0]
        raw_pubkey = signer.derive_pubkey(first_result.secret_share, chain_config.derivation_path)

        key_shares = [
            ServerKeyShare(
                key_share_id=ext_keygen_ids[i],
                secret_share=kr.secret_share,
            )
            for i, kr in enumerate(import_results)
        ]

        wallet_id = ceremony_data.get("walletId") if ceremony_data else None

        return {
            "raw_public_key": raw_pubkey,
            "external_server_key_shares": key_shares,
            "wallet_id": wallet_id,
        }

    # -------------------------------------------------------------------------
    # Backup and Recovery
    #
    # Key shares are encrypted client-side before being sent to Dynamic's servers.
    # The encryption uses AES-256-GCM with a PBKDF2-derived key (1M iterations).
    # The password is never sent to Dynamic — only the encrypted ciphertext is stored.
    #
    # backup_key_shares() is ALWAYS called after keygen, even without a real password.
    # This is because the Dynamic server marks shares as "pending" until
    # POST /keyShares/backup/locations is called. Signing fails on pending shares.
    # When no user password is provided, the environment_id is used as the password
    # (the backup won't be recoverable by password, but the shares become active).
    #
    # The server-assigned keyShareIds returned by the backup endpoint are stored
    # locally and later used as the request body for recovery.
    # -------------------------------------------------------------------------

    async def backup_key_shares(
        self,
        account_address: str,
        password: str,
    ) -> None:
        """Encrypt key shares with password and store via Dynamic's backup service.

        Steps:
          1. AES-256-GCM encrypt each secret_share with the password
          2. POST encrypted blobs to the relay endpoint (Evervault-proxied)
          3. Server returns keyShareIds (server-assigned UUIDs for the stored blobs)
          4. POST to /keyShares/backup/locations — this is what activates the shares
          5. Store keyShareIds locally for later use in recover_key_shares()

        The keygenId sent in step 4 is the MPC export_id of the first key share —
        it's a stable identifier derived from the secret_share itself.
        """
        self._ensure_authenticated()
        wp = self.get_wallet_from_map(account_address)

        chain_name = wp.chain_name
        signer = get_mpc_signer(chain_name, self._base_mpc_relay_url)

        encrypted_shares = []
        for ks in wp.external_server_key_shares:
            key_share_json = json.dumps({
                "keyShareId": ks.key_share_id,
                "secretShare": ks.secret_share,
            })
            enc = encrypt_data(key_share_json, password)
            enc_json = json.dumps({
                "salt": enc.salt,
                "iv": enc.iv,
                "cipher": enc.cipher,
                "version": enc.version,
            })
            encrypted_shares.append(base64.b64encode(enc_json.encode()).decode())

        # store_encrypted_backup returns server-assigned keyShareIds
        backup_data = await self._api_client.store_encrypted_backup(
            wallet_id=wp.wallet_id,
            encrypted_key_shares=encrypted_shares,
            password_encrypted=bool(password) and password != self.environment_id,
            encryption_version=ENCRYPTION_VERSION_CURRENT,
        )
        server_key_share_ids = backup_data.get("keyShareIds", [])

        # Compute keygenId (MPC export_id) for the first key share
        keygen_id = signer.export_id(wp.external_server_key_shares[0].secret_share)

        # Build locations using server-assigned IDs (not client keygen IDs)
        locations = []
        for i, ks in enumerate(wp.external_server_key_shares):
            loc: dict = {
                "location": BackupLocation.DYNAMIC.value,
                "passwordEncrypted": True,
                "keygenId": keygen_id,
            }
            if i < len(server_key_share_ids):
                loc["externalKeyShareId"] = server_key_share_ids[i]
            locations.append(loc)

        await self._api_client.mark_key_shares_as_backed_up(
            wallet_id=wp.wallet_id,
            locations=locations,
        )

        wp.external_server_key_shares_backup_info.password_encrypted = True
        wp.external_server_key_shares_backup_info.backups[BackupLocation.DYNAMIC.value] = [
            BackupLocationInfo(location=BackupLocation.DYNAMIC, key_share_id=kid)
            for kid in server_key_share_ids
        ]

    async def recover_key_shares(
        self,
        account_address: str,
        password: str,
        mfa_token: str | None = None,
        key_share_ids: list[str] | None = None,
    ) -> list[ServerKeyShare]:
        """Recover and decrypt key shares from Dynamic's backup service.

        key_share_ids: server-assigned UUIDs from the backup response. If not
            provided, the IDs stored in external_server_key_shares_backup_info
            are used (populated by backup_key_shares() after keygen).

        The encrypted blobs returned by the server use field name
        "encryptedAccountCredential". The fallback chain also checks
        "encryptedSecret" and "secret" for older backup formats.

        Raises DynamicSDKError if the server returns blobs but none decrypt
        successfully (wrong password, corrupted data, or wrong key_share_ids).
        """
        self._ensure_authenticated()
        wp = self.get_wallet_from_map(account_address)

        # Use stored backup IDs if not explicitly provided (TS SDK always passes them)
        if key_share_ids is None:
            dynamic_backups = wp.external_server_key_shares_backup_info.backups.get(
                BackupLocation.DYNAMIC.value, []
            )
            if dynamic_backups:
                key_share_ids = [b.key_share_id for b in dynamic_backups]

        data = await self._api_client.recover_encrypted_backup(
            wallet_id=wp.wallet_id,
            key_share_ids=key_share_ids,
            mfa_token=mfa_token,
        )

        recovered = []
        for ks_data in data.get("keyShares", []):
            encrypted_str = ks_data.get("encryptedAccountCredential") or ks_data.get("encryptedSecret") or ks_data.get("secret")
            if not encrypted_str:
                continue
            # Server stores the credential base64-encoded (see backup_key_shares)
            enc_json = base64.b64decode(encrypted_str).decode() if isinstance(encrypted_str, str) else encrypted_str
            enc_dict = json.loads(enc_json) if isinstance(enc_json, str) else enc_json
            decrypted = decrypt_data(enc_dict, password)
            # decrypted is JSON: {"keyShareId": ..., "secretShare": ...}
            decrypted_obj = json.loads(decrypted)
            recovered.append(
                ServerKeyShare(
                    key_share_id=decrypted_obj.get("keyShareId") or ks_data.get("id", ""),
                    secret_share=decrypted_obj["secretShare"],
                )
            )

        if not recovered:
            raise DynamicSDKError(
                f"Key share recovery for {account_address} returned no shares. "
                "Check that the password is correct and the backup exists."
            )

        # Update wallet map
        wp.external_server_key_shares = recovered
        return recovered

    # -------------------------------------------------------------------------
    # Wallet retrieval from server
    # -------------------------------------------------------------------------

    async def get_wallets_from_user(self) -> dict[str, WalletProperties]:
        """Fetch user's wallets from API and populate wallet map."""
        self._ensure_authenticated()
        user_data = await self._api_client.get_user()
        wallets = {}

        for vc in user_data.get("verifiedCredentials", []):
            if vc.get("walletName") != "dynamicwaas":
                continue

            wallet_props = vc.get("walletProperties") or {}
            address = vc.get("address", "")
            wallet_id = vc.get("walletId") or vc.get("id", "")
            chain = vc.get("chain", "EVM")
            tss_str = wallet_props.get("thresholdSignatureScheme", "TWO_OF_TWO")
            tss = ThresholdSignatureScheme(tss_str)
            deriv = wallet_props.get("derivationPath")
            derivation_path = json.loads(deriv) if deriv else None

            wp = WalletProperties(
                chain_name=chain,
                wallet_id=wallet_id,
                account_address=address,
                threshold_signature_scheme=tss,
                derivation_path=derivation_path,
            )

            key = self._normalize_address(address)
            self._wallet_map[key] = wp
            wallets[key] = wp

        return wallets

    # --- Cleanup ---

    async def close(self) -> None:
        await self._api_client.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
