"""Delegated signing client.

Ported from packages/node/src/delegatedClient/.
"""

from __future__ import annotations

from typing import Any

from dynamic_wallet_sdk.api.dynamic_api import DynamicApiClient
from dynamic_wallet_sdk.evm.client import DynamicEvmWalletClient
from dynamic_wallet_sdk.evm.utils import format_evm_message, serialize_ecdsa_signature
from dynamic_wallet_sdk.mpc.signer import get_mpc_signer
from dynamic_wallet_sdk.mpc_config import MPC_CHAIN_CONFIG, SigningAlgorithm
from dynamic_wallet_sdk.svm.client import DynamicSvmWalletClient
from dynamic_wallet_sdk.svm.utils import format_ed25519_message


async def create_delegated_evm_client(
    environment_id: str,
    api_key: str,
    *,
    base_api_url: str | None = None,
    base_mpc_relay_url: str | None = None,
    debug: bool = False,
) -> DynamicEvmWalletClient:
    """Create an authenticated EVM wallet client for delegated signing."""
    client = DynamicEvmWalletClient(
        environment_id,
        base_api_url=base_api_url,
        base_mpc_relay_url=base_mpc_relay_url,
        debug=debug,
    )
    await client.authenticate_api_token(api_key)
    return client


async def create_delegated_svm_client(
    environment_id: str,
    api_key: str,
    *,
    base_api_url: str | None = None,
    base_mpc_relay_url: str | None = None,
    debug: bool = False,
) -> DynamicSvmWalletClient:
    """Create an authenticated SVM wallet client for delegated signing."""
    client = DynamicSvmWalletClient(
        environment_id,
        base_api_url=base_api_url,
        base_mpc_relay_url=base_mpc_relay_url,
        debug=debug,
    )
    await client.authenticate_api_token(api_key)
    return client


async def delegated_sign_message(
    client: DynamicEvmWalletClient | DynamicSvmWalletClient,
    *,
    wallet_id: str,
    wallet_api_key: str,
    key_share: str,
    message: str,
    chain_name: str,
    is_formatted: bool = False,
    context: dict | None = None,
    base_mpc_relay_url: str | None = None,
) -> Any:
    """Sign a message using delegated key share.

    This calls the delegated sign API endpoint with the wallet-specific API key,
    then performs the MPC signing ceremony with the provided key share.

    Args:
        client: An authenticated wallet client.
        wallet_id: The wallet ID.
        wallet_api_key: The wallet-specific API key (from delegated webhook).
        key_share: The decrypted delegated key share.
        message: The message to sign.
        chain_name: The chain name (EVM, SVM, etc.).
        is_formatted: Whether the message is already formatted/hashed.
        context: Optional signing context.
        base_mpc_relay_url: Optional MPC relay URL override.

    Returns:
        The signature (format depends on chain).
    """
    # Call delegated sign endpoint (SSE) to get room.
    # wallet_api_key is passed as a per-request header to avoid mutating
    # the shared httpx client headers (which would cause a race condition
    # under concurrent calls).
    server_resp = await client._api_client.delegated_sign_message(
        wallet_id=wallet_id,
        message=message,
        is_formatted=is_formatted,
        context=context,
        wallet_api_key=wallet_api_key,
    )
    room_id = server_resp["roomId"]

    # Perform MPC signing
    relay_url = base_mpc_relay_url or client._base_mpc_relay_url
    signer = get_mpc_signer(chain_name, relay_url)
    chain_config = MPC_CHAIN_CONFIG.get(chain_name)

    path = chain_config.derivation_path if chain_config else [44, 60, 0, 0, 0]

    if chain_config and chain_config.signing_algorithm == SigningAlgorithm.ED25519:
        # For Ed25519, the MPC signer expects raw bytes of the message.
        # If is_formatted=True, the caller has already hex-encoded the message.
        # If is_formatted=False, the message is plain text that needs hex encoding.
        if is_formatted:
            msg_hex = message if isinstance(message, str) else message.hex()
        else:
            msg_hex = format_ed25519_message(message)
        msg_bytes = bytes.fromhex(msg_hex)
        return await signer.sign(room_id, key_share, msg_bytes, path)
    else:
        from dynamic_wallet_mpc import PyMessageHash

        msg_hash = PyMessageHash(message)
        return await signer.sign(room_id, key_share, msg_hash, path)
