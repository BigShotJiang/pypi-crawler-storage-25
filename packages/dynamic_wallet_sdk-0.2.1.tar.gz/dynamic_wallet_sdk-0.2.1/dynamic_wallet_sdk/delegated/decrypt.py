"""Decrypt delegated webhook data.

Ported from packages/node/src/delegatedClient/ decrypt logic.
Encryption scheme: RSA-OAEP for key encryption + AES-256-GCM for data.
"""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass

from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.serialization import load_pem_private_key


@dataclass
class DecryptedDelegatedData:
    decrypted_delegated_share: dict
    decrypted_wallet_api_key: str


def _base64url_decode(data: str) -> bytes:
    """Decode base64url without padding."""
    # Add padding if needed
    padding = 4 - len(data) % 4
    if padding != 4:
        data += "=" * padding
    return base64.urlsafe_b64decode(data)


def _decrypt_envelope(
    private_key_pem: str,
    envelope: dict,
) -> bytes:
    """Decrypt a JWE-like envelope using RSA-OAEP + AES-256-GCM.

    Envelope format: { alg, iv, ct, tag, ek }
    All values are base64url-encoded (no padding).
    """
    private_key = load_pem_private_key(private_key_pem.encode(), password=None)

    ek = _base64url_decode(envelope["ek"])
    iv = _base64url_decode(envelope["iv"])
    ct = _base64url_decode(envelope["ct"])
    tag = _base64url_decode(envelope["tag"])

    # Decrypt the AES key with RSA-OAEP
    aes_key = private_key.decrypt(
        ek,
        asym_padding.OAEP(
            mgf=asym_padding.MGF1(algorithm=SHA256()),
            algorithm=SHA256(),
            label=None,
        ),
    )

    # Decrypt the ciphertext with AES-GCM
    aesgcm = AESGCM(aes_key)
    # AES-GCM ciphertext + tag concatenated
    plaintext = aesgcm.decrypt(iv, ct + tag, None)

    return plaintext


def decrypt_delegated_webhook_data(
    private_key_pem: str,
    encrypted_delegated_key_share: dict,
    encrypted_wallet_api_key: dict,
) -> DecryptedDelegatedData:
    """Decrypt delegated webhook data (key share + API key).

    Args:
        private_key_pem: RSA private key in PEM format.
        encrypted_delegated_key_share: Encrypted envelope for the delegated key share.
        encrypted_wallet_api_key: Encrypted envelope for the wallet API key.

    Returns:
        DecryptedDelegatedData with decrypted share and API key.
    """
    share_bytes = _decrypt_envelope(private_key_pem, encrypted_delegated_key_share)
    api_key_bytes = _decrypt_envelope(private_key_pem, encrypted_wallet_api_key)

    return DecryptedDelegatedData(
        decrypted_delegated_share=json.loads(share_bytes.decode("utf-8")),
        decrypted_wallet_api_key=api_key_bytes.decode("utf-8"),
    )
