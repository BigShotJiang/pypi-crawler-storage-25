"""Error hierarchy for the Dynamic Wallet SDK."""

from __future__ import annotations


class DynamicSDKError(Exception):
    """Base exception for all SDK errors."""


class AuthenticationError(DynamicSDKError):
    """Raised when API authentication fails."""


class EncryptionError(DynamicSDKError):
    """Raised when encryption or decryption fails."""


class SSETimeoutError(DynamicSDKError):
    """Raised when an SSE event stream times out."""


class SSEError(DynamicSDKError):
    """Raised when an error event is received from an SSE stream."""


class WalletNotFoundError(DynamicSDKError):
    """Raised when a wallet is not found in the wallet map."""


class MPCError(DynamicSDKError):
    """Raised when an MPC operation fails."""
