"""SVM (Solana) wallet client.

Ported from packages/svm/src/svm/client.ts.
"""

from __future__ import annotations

import base58

from dynamic_wallet_sdk.exceptions import DynamicSDKError
from dynamic_wallet_sdk.mpc.types import ServerKeyShare
from dynamic_wallet_sdk.mpc_config import MPC_CHAIN_CONFIG, ThresholdSignatureScheme
from dynamic_wallet_sdk.svm.utils import derive_solana_address, format_ed25519_message
from dynamic_wallet_sdk.wallet_client import DynamicWalletClient


class DynamicSvmWalletClient(DynamicWalletClient):
    """Solana-specific wallet client using Ed25519."""

    async def create_wallet_account(
        self,
        threshold_signature_scheme: ThresholdSignatureScheme = ThresholdSignatureScheme.TWO_OF_TWO,
        password: str | None = None,
    ) -> str:
        """Create a Solana wallet account.

        Returns:
            Base58-encoded Solana address.
        """
        result = await self.keygen("SVM", threshold_signature_scheme)

        raw_pk = result["raw_public_key"]
        if isinstance(raw_pk, str):
            pk_bytes = bytes.fromhex(raw_pk)
        elif isinstance(raw_pk, (bytes, bytearray)):
            pk_bytes = bytes(raw_pk)
        else:
            pk_bytes = bytes(raw_pk)

        address = derive_solana_address(pk_bytes)
        wallet_id = result["wallet_id"]
        key_shares = result["external_server_key_shares"]

        chain_config = MPC_CHAIN_CONFIG["SVM"]
        self._init_wallet_entry(
            account_address=address,
            wallet_id=wallet_id,
            chain_name="SVM",
            external_server_key_shares=key_shares,
            threshold_signature_scheme=threshold_signature_scheme,
            derivation_path=chain_config.derivation_path,
        )

        await self.backup_key_shares(address, password or self.environment_id)

        return address

    async def sign_message(
        self,
        message: str,
        address: str,
        password: str | None = None,
        key_shares: list[ServerKeyShare] | None = None,
        mfa_token: str | None = None,
    ) -> str:
        """Sign a message with Ed25519.

        Args:
            message: The message to sign.
            address: The Solana wallet address.
            password: Optional password to recover key shares.
            key_shares: Optional pre-loaded key shares.
            mfa_token: Optional MFA token.

        Returns:
            Base58-encoded signature.
        """
        wp = self.get_wallet_from_map(address)
        shares = key_shares or wp.external_server_key_shares
        if not shares and password:
            shares = await self.recover_key_shares(address, password, mfa_token)
        if not shares:
            raise DynamicSDKError(
                f"No key shares available for {address}. "
                "Pass a password to recover from backup."
            )

        msg_hex = format_ed25519_message(message)

        sig_bytes = await super()._sign_mpc_message(
            wallet_id=wp.wallet_id,
            message=msg_hex,
            chain_name="SVM",
            key_share=shares[0].secret_share,
            is_formatted=False,
            mfa_token=mfa_token,
        )

        if isinstance(sig_bytes, (bytes, bytearray, list)):
            return base58.b58encode(bytes(sig_bytes)).decode("ascii")
        return str(sig_bytes)

    async def sign_transaction(
        self,
        address: str,
        tx_bytes: bytes,
        password: str | None = None,
        key_shares: list[ServerKeyShare] | None = None,
        mfa_token: str | None = None,
    ) -> str:
        """Sign a Solana transaction.

        Args:
            address: The Solana wallet address.
            tx_bytes: Serialized transaction bytes.
            password: Optional password to recover key shares.
            key_shares: Optional pre-loaded key shares.
            mfa_token: Optional MFA token.

        Returns:
            Hex-encoded signature.
        """
        wp = self.get_wallet_from_map(address)
        shares = key_shares or wp.external_server_key_shares
        if not shares and password:
            shares = await self.recover_key_shares(address, password, mfa_token)
        if not shares:
            raise DynamicSDKError(
                f"No key shares available for {address}. "
                "Pass a password to recover from backup."
            )

        msg_hex = tx_bytes.hex()

        sig_bytes = await super()._sign_mpc_message(
            wallet_id=wp.wallet_id,
            message=msg_hex,
            chain_name="SVM",
            key_share=shares[0].secret_share,
            is_formatted=False,
            context={"type": "svmTransaction"},
            mfa_token=mfa_token,
        )

        if isinstance(sig_bytes, (bytes, bytearray, list)):
            return bytes(sig_bytes).hex()
        return str(sig_bytes)

    async def export_private_key(
        self,
        address: str,
        password: str | None = None,
        mfa_token: str | None = None,
        elevated_access_token: str | None = None,
    ) -> str | None:
        """Export the full Solana private key."""
        wp = self.get_wallet_from_map(address)
        shares = wp.external_server_key_shares
        if not shares and password:
            shares = await self.recover_key_shares(address, password, mfa_token)
        if not shares:
            raise DynamicSDKError(
                f"No key shares available for {address}. "
                "Pass a password to recover from backup."
            )

        return await super()._export_private_key_mpc(
            wallet_id=wp.wallet_id,
            chain_name="SVM",
            key_share=shares[0].secret_share,
            mfa_token=mfa_token,
            elevated_access_token=elevated_access_token,
        )

    async def import_private_key(
        self,
        private_key: str,
        threshold_signature_scheme: ThresholdSignatureScheme = ThresholdSignatureScheme.TWO_OF_TWO,
        password: str | None = None,
    ) -> str:
        """Import an existing Solana private key.

        Args:
            private_key: Hex-encoded 32-byte Ed25519 private key.
            threshold_signature_scheme: TSS scheme to use.
            password: Optional password for backup.

        Returns:
            The derived Solana address.
        """
        result = await super()._import_private_key_mpc(
            chain_name="SVM",
            private_key=private_key,
            threshold_signature_scheme=threshold_signature_scheme,
        )

        raw_pk = result["raw_public_key"]
        if isinstance(raw_pk, str):
            pk_bytes = bytes.fromhex(raw_pk)
        elif isinstance(raw_pk, (bytes, bytearray)):
            pk_bytes = bytes(raw_pk)
        else:
            pk_bytes = bytes(raw_pk)

        address = derive_solana_address(pk_bytes)
        wallet_id = result["wallet_id"]
        key_shares = result["external_server_key_shares"]

        chain_config = MPC_CHAIN_CONFIG["SVM"]
        self._init_wallet_entry(
            account_address=address,
            wallet_id=wallet_id,
            chain_name="SVM",
            external_server_key_shares=key_shares,
            threshold_signature_scheme=threshold_signature_scheme,
            derivation_path=chain_config.derivation_path,
        )

        await self.backup_key_shares(address, password or self.environment_id)

        return address
