"""Solana/SVM utilities: address derivation and message formatting.

Ported from packages/svm/src/svm/client.ts.
"""

from __future__ import annotations

import base58


def derive_solana_address(raw_pubkey: bytes) -> str:
    """Derive Solana address from raw 32-byte Ed25519 public key.

    Args:
        raw_pubkey: 32-byte Ed25519 public key (or hex string of it).

    Returns:
        Base58-encoded Solana address.
    """
    if isinstance(raw_pubkey, str):
        raw_pubkey = bytes.fromhex(raw_pubkey)
    return base58.b58encode(raw_pubkey).decode("ascii")


def format_ed25519_message(message: str) -> str:
    """Format a message for Ed25519 signing (UTF-8 encode to hex).

    For Solana, messages are passed as hex strings to the MPC signer.
    No prefix is added (unlike EVM's EIP-191). All messages are treated
    as plain text (UTF-8 encoded), matching the TS SDK's TextEncoder.encode().

    Returns:
        Hex-encoded message string (no 0x prefix).
    """
    return message.encode("utf-8").hex()
