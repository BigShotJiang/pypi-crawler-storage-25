"""MPC configuration ported from packages/core/src/mpc/constants.ts."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Final


class SigningAlgorithm(str, Enum):
    ECDSA = "ECDSA"
    ED25519 = "ED25519"
    BIP340 = "BIP340"


class ThresholdSignatureScheme(str, Enum):
    TWO_OF_TWO = "TWO_OF_TWO"
    TWO_OF_THREE = "TWO_OF_THREE"
    THREE_OF_FIVE = "THREE_OF_FIVE"


@dataclass(frozen=True)
class MPCSchemeConfig:
    number_of_parties: int
    threshold: int
    client_threshold: int
    dynamic_server_threshold: int


MPC_CONFIG: Final[dict[ThresholdSignatureScheme, MPCSchemeConfig]] = {
    ThresholdSignatureScheme.TWO_OF_TWO: MPCSchemeConfig(
        number_of_parties=2, threshold=2, client_threshold=1, dynamic_server_threshold=1
    ),
    ThresholdSignatureScheme.TWO_OF_THREE: MPCSchemeConfig(
        number_of_parties=3, threshold=2, client_threshold=2, dynamic_server_threshold=1
    ),
    ThresholdSignatureScheme.THREE_OF_FIVE: MPCSchemeConfig(
        number_of_parties=5, threshold=3, client_threshold=3, dynamic_server_threshold=2
    ),
}


@dataclass(frozen=True)
class ChainConfig:
    derivation_path: list[int]
    signing_algorithm: SigningAlgorithm


MPC_CHAIN_CONFIG: Final[dict[str, ChainConfig]] = {
    "EVM": ChainConfig(
        derivation_path=[44, 60, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.ECDSA,
    ),
    "SVM": ChainConfig(
        derivation_path=[44, 501, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.ED25519,
    ),
    "COSMOS": ChainConfig(
        derivation_path=[44, 118, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.ED25519,
    ),
    "FLOW": ChainConfig(
        derivation_path=[44, 539, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.ED25519,
    ),
    "SUI": ChainConfig(
        derivation_path=[44, 784, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.ED25519,
    ),
    "TON": ChainConfig(
        derivation_path=[44, 607, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.ED25519,
    ),
    "STELLAR": ChainConfig(
        derivation_path=[44, 148, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.ED25519,
    ),
}

BITCOIN_ADDRESS_TYPE_CONFIG: Final[dict[str, ChainConfig]] = {
    "taproot": ChainConfig(
        derivation_path=[86, 0, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.BIP340,
    ),
    "native_segwit": ChainConfig(
        derivation_path=[84, 0, 0, 0, 0],
        signing_algorithm=SigningAlgorithm.ECDSA,
    ),
}
