"""Type aliases for MPC wallet data."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from dynamic_wallet_sdk.constants import BackupLocation
from dynamic_wallet_sdk.mpc_config import ThresholdSignatureScheme


@dataclass
class ServerKeyShare:
    key_share_id: str
    secret_share: str
    pub_key: str | None = None


@dataclass
class BackupLocationInfo:
    location: BackupLocation
    key_share_id: str


@dataclass
class KeyShareBackupInfo:
    password_encrypted: bool = False
    backups: dict[str, list[BackupLocationInfo]] = field(default_factory=dict)


@dataclass
class WalletProperties:
    chain_name: str
    wallet_id: str
    account_address: str
    external_server_key_shares: list[ServerKeyShare] = field(default_factory=list)
    threshold_signature_scheme: ThresholdSignatureScheme = (
        ThresholdSignatureScheme.TWO_OF_TWO
    )
    derivation_path: list[int] | None = None
    address_type: str | None = None  # For BTC: 'taproot' or 'native_segwit'
    external_server_key_shares_backup_info: KeyShareBackupInfo = field(
        default_factory=KeyShareBackupInfo
    )
