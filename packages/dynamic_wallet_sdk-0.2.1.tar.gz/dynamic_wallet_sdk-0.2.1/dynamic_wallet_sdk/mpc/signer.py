"""MPC signer factory — returns the correct MPC class for a chain."""

from __future__ import annotations

from dynamic_wallet_sdk.mpc_config import MPC_CHAIN_CONFIG, SigningAlgorithm

# Import types lazily from the Rust native module
_ECDSA_CLS = None
_ED25519_CLS = None


def _load_ecdsa():
    global _ECDSA_CLS
    if _ECDSA_CLS is None:
        from dynamic_wallet_mpc import PyEcdsa

        _ECDSA_CLS = PyEcdsa
    return _ECDSA_CLS


def _load_ed25519():
    global _ED25519_CLS
    if _ED25519_CLS is None:
        from dynamic_wallet_mpc import PyExportableEd25519

        _ED25519_CLS = PyExportableEd25519
    return _ED25519_CLS


def get_mpc_signer(chain_name: str, host_url: str):
    """Create the appropriate MPC signer for a chain.

    Args:
        chain_name: One of the supported chain names (EVM, SVM, etc.).
        host_url: MPC relay host URL.

    Returns:
        An instance of PyEcdsa or PyExportableEd25519.
    """
    config = MPC_CHAIN_CONFIG.get(chain_name)
    if config is None:
        raise ValueError(f"Unsupported chain: {chain_name}")

    if config.signing_algorithm == SigningAlgorithm.ECDSA:
        cls = _load_ecdsa()
        return cls(host_url)
    elif config.signing_algorithm == SigningAlgorithm.ED25519:
        cls = _load_ed25519()
        return cls(host_url)
    else:
        raise ValueError(
            f"Unsupported signing algorithm: {config.signing_algorithm}"
        )
