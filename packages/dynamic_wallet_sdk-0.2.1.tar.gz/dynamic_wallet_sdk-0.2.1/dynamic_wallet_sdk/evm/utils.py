"""EVM utilities: address derivation, EIP-191, EIP-712, signature serialization.

Ported from packages/evm/src/utils.ts and packages/evm/src/client/client.ts.
"""

from __future__ import annotations

from eth_hash.auto import keccak


def derive_evm_address(uncompressed_pubkey: bytes) -> str:
    """Derive EIP-55 checksummed Ethereum address from uncompressed public key.

    Args:
        uncompressed_pubkey: 65-byte SEC1 uncompressed key (0x04 || x || y)
            or 64-byte raw (x || y).

    Returns:
        Checksummed address string like "0xAbC...".
    """
    # Strip 0x04 prefix if present
    raw = uncompressed_pubkey[1:] if len(uncompressed_pubkey) == 65 else uncompressed_pubkey
    hashed = keccak(raw)
    addr_bytes = hashed[-20:]
    return _to_checksum_address(addr_bytes)


def _to_checksum_address(addr_bytes: bytes) -> str:
    """EIP-55 checksum encoding."""
    hex_addr = addr_bytes.hex()
    hash_hex = keccak(hex_addr.encode("ascii")).hex()
    checksummed = "0x"
    for i, c in enumerate(hex_addr):
        if c in "0123456789":
            checksummed += c
        elif int(hash_hex[i], 16) >= 8:
            checksummed += c.upper()
        else:
            checksummed += c.lower()
    return checksummed


def evm_prefix_message(message: str) -> str:
    """Apply EIP-191 prefix and return as 0x-prefixed hex string (no hash).

    This matches the TS SDK's ``formatEVMMessage`` in ``packages/evm/src/utils.ts``.
    The result is sent to the server API.

    Returns:
        Hex string with 0x prefix: ``"0x" + hex(prefix) + hex(message)``.
    """
    msg_bytes = message.encode("utf-8")

    prefix = f"\x19Ethereum Signed Message:\n{len(msg_bytes)}".encode("utf-8")
    full = prefix + msg_bytes
    return "0x" + full.hex()


def format_evm_message(message: str) -> str:
    """Apply EIP-191 prefix and return keccak256 hash as hex.

    This matches the browser-side ``formatEvmMessage`` that hashes the
    prefixed message for MPC signing.

    Returns:
        64-char hex string (no 0x prefix) suitable for PyMessageHash.
    """
    prefixed_hex = evm_prefix_message(message)
    msg_bytes = bytes.fromhex(prefixed_hex[2:])
    return keccak(msg_bytes).hex()


def hash_typed_data(typed_data: dict) -> str:
    """Hash EIP-712 typed data and return keccak256 as hex (no 0x prefix).

    The EIP-712 encoding is: keccak256(\x19 + version + header + body).
    Mirrors viem's hashTypedData used in the TS SDK.
    """
    from eth_account.messages import encode_typed_data

    msg = encode_typed_data(full_message=typed_data)
    full_encoding = b"\x19" + msg.version + msg.header + msg.body
    return keccak(full_encoding).hex()


def serialize_ecdsa_signature(r: bytes, s: bytes, v: int) -> str:
    """Serialize an ECDSA signature to a 0x-prefixed hex string.

    Returns:
        "0x" + r(32 bytes) + s(32 bytes) + v(1 byte) as hex.
    """
    r_hex = r.hex().zfill(64)
    s_hex = s.hex().zfill(64)
    v_hex = format(v, "02x")
    return f"0x{r_hex}{s_hex}{v_hex}"
