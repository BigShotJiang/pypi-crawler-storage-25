"""EVM wallet client.

Ported from packages/evm/src/client/client.ts.
"""

from __future__ import annotations

import json
from typing import Any

from dynamic_wallet_sdk.constants import BackupLocation
from dynamic_wallet_sdk.evm.utils import (
    derive_evm_address,
    evm_prefix_message,
    format_evm_message,
    hash_typed_data,
    serialize_ecdsa_signature,
)
from dynamic_wallet_sdk.exceptions import DynamicSDKError
from dynamic_wallet_sdk.mpc.types import ServerKeyShare
from dynamic_wallet_sdk.mpc_config import MPC_CHAIN_CONFIG, ThresholdSignatureScheme
from dynamic_wallet_sdk.wallet_client import DynamicWalletClient


def _parse_tx_data(raw: object) -> bytes:
    """Convert tx data field to bytes, raising DynamicSDKError for invalid hex."""
    if isinstance(raw, str):
        hex_str = raw[2:] if raw.startswith("0x") else raw
        try:
            return bytes.fromhex(hex_str)
        except ValueError as exc:
            raise DynamicSDKError(f"Invalid hex in transaction data field: {raw!r}") from exc
    if raw is None:
        return b""
    return bytes(raw)  # type: ignore[arg-type]


def _parse_tx_to(raw: object) -> bytes | None:
    """Convert tx to field to bytes (eth_account requires bytes, not hex string)."""
    if isinstance(raw, str):
        to_hex = raw[2:] if raw.startswith("0x") else raw
        return bytes.fromhex(to_hex)
    if raw is None:
        return None
    return bytes(raw)  # type: ignore[arg-type]


class DynamicEvmWalletClient(DynamicWalletClient):
    """EVM-specific wallet client with EIP-191/712 signing."""

    async def create_wallet_account(
        self,
        threshold_signature_scheme: ThresholdSignatureScheme = ThresholdSignatureScheme.TWO_OF_TWO,
        password: str | None = None,
    ) -> str:
        """Create an EVM wallet account.

        Returns:
            The checksummed EVM address.
        """
        result = await self.keygen("EVM", threshold_signature_scheme)

        # Derive EVM address from public key
        # ECDSA derive_pubkey returns (uncompressed, compressed) tuple
        raw_pk = result["raw_public_key"]
        if isinstance(raw_pk, tuple):
            pk_bytes = bytes(raw_pk[0])  # uncompressed
        elif isinstance(raw_pk, (bytes, bytearray)):
            pk_bytes = bytes(raw_pk)
        else:
            pk_bytes = bytes.fromhex(str(raw_pk))

        address = derive_evm_address(pk_bytes)
        wallet_id = result["wallet_id"]
        key_shares = result["external_server_key_shares"]

        chain_config = MPC_CHAIN_CONFIG["EVM"]
        self._init_wallet_entry(
            account_address=address,
            wallet_id=wallet_id,
            chain_name="EVM",
            external_server_key_shares=key_shares,
            threshold_signature_scheme=threshold_signature_scheme,
            derivation_path=chain_config.derivation_path,
        )

        # Always backup key shares after keygen (matches TS SDK behavior).
        # Server key shares start as "pending" and only become "active"
        # after /backup/locations is called. Signing requires "active" shares.
        await self.backup_key_shares(address, password or self.environment_id)

        return address

    async def sign_message(
        self,
        message: str,
        address: str,
        password: str | None = None,
        key_shares: list[ServerKeyShare] | None = None,
        mfa_token: str | None = None,
    ) -> str:
        """Sign a message with EIP-191 prefix.

        Args:
            message: The message string to sign.
            address: The wallet address.
            password: Optional password to recover key shares.
            key_shares: Optional pre-loaded key shares.
            mfa_token: Optional MFA token.

        Returns:
            Hex-encoded ECDSA signature.
        """
        wp = self.get_wallet_from_map(address)
        shares = key_shares or wp.external_server_key_shares
        if not shares and password:
            shares = await self.recover_key_shares(address, password, mfa_token)
        if not shares:
            raise DynamicSDKError(
                f"No key shares available for {address}. "
                "Pass a password to recover from backup."
            )

        # EVM-prefixed hex for the server (matches TS formatEVMMessage)
        prefixed_hex = evm_prefix_message(message)
        # Keccak256 hash of the prefixed message for MPC signing
        msg_hash_hex = format_evm_message(message)

        chain_config = MPC_CHAIN_CONFIG["EVM"]
        sig = await super()._sign_mpc_message(
            wallet_id=wp.wallet_id,
            message=msg_hash_hex,
            chain_name="EVM",
            key_share=shares[0].secret_share,
            derivation_path=chain_config.derivation_path,
            is_formatted=True,
            server_message=prefixed_hex,  # EVM-prefixed hex to server
            server_is_formatted=False,
            context={"evmMessage": message},
            mfa_token=mfa_token,
        )

        return serialize_ecdsa_signature(bytes(sig.r), bytes(sig.s), sig.v)

    async def sign_typed_data(
        self,
        address: str,
        typed_data: dict,
        password: str | None = None,
        key_shares: list[ServerKeyShare] | None = None,
        mfa_token: str | None = None,
    ) -> str:
        """Sign EIP-712 typed data.

        Returns:
            Hex-encoded ECDSA signature.
        """
        wp = self.get_wallet_from_map(address)
        shares = key_shares or wp.external_server_key_shares
        if not shares and password:
            shares = await self.recover_key_shares(address, password, mfa_token)
        if not shares:
            raise DynamicSDKError(
                f"No key shares available for {address}. "
                "Pass a password to recover from backup."
            )

        msg_hash_hex = hash_typed_data(typed_data)

        chain_config = MPC_CHAIN_CONFIG["EVM"]
        sig = await super()._sign_mpc_message(
            wallet_id=wp.wallet_id,
            message=msg_hash_hex,
            chain_name="EVM",
            key_share=shares[0].secret_share,
            derivation_path=chain_config.derivation_path,
            is_formatted=True,
            context={"evmTypedData": typed_data},
            mfa_token=mfa_token,
        )

        return serialize_ecdsa_signature(bytes(sig.r), bytes(sig.s), sig.v)

    async def sign_transaction(
        self,
        address: str,
        tx: dict,
        password: str | None = None,
        key_shares: list[ServerKeyShare] | None = None,
        mfa_token: str | None = None,
    ) -> str:
        """Sign an EVM transaction.

        Args:
            address: The wallet address.
            tx: Transaction dict (to, value, nonce, gas, etc.).
            password: Optional password to recover key shares.
            key_shares: Optional pre-loaded key shares.
            mfa_token: Optional MFA token.

        Returns:
            Hex-encoded signed transaction.
        """
        import rlp
        from eth_account._utils.legacy_transactions import serializable_unsigned_transaction_from_dict
        from eth_hash.auto import keccak as _keccak

        wp = self.get_wallet_from_map(address)
        shares = key_shares or wp.external_server_key_shares
        if not shares and password:
            shares = await self.recover_key_shares(address, password, mfa_token)
        if not shares:
            raise DynamicSDKError(
                f"No key shares available for {address}. "
                "Pass a password to recover from backup."
            )

        tx_for_encode = {
            "to": _parse_tx_to(tx.get("to")),
            "value": tx.get("value", 0),
            "gas": tx.get("gas", 21000),
            "gasPrice": tx.get("gasPrice", tx.get("maxFeePerGas", 0)),
            "nonce": tx.get("nonce", 0),
            "chainId": tx.get("chainId", 1),
            "data": _parse_tx_data(tx.get("data")),
        }
        unsigned_tx = serializable_unsigned_transaction_from_dict(tx_for_encode)
        raw_bytes = rlp.encode(unsigned_tx)
        raw_hex = "0x" + raw_bytes.hex()
        msg_hash_hex = _keccak(raw_bytes).hex()

        chain_config = MPC_CHAIN_CONFIG["EVM"]
        sig = await super()._sign_mpc_message(
            wallet_id=wp.wallet_id,
            message=msg_hash_hex,
            chain_name="EVM",
            key_share=shares[0].secret_share,
            derivation_path=chain_config.derivation_path,
            is_formatted=True,
            server_message=raw_hex,
            server_is_formatted=False,
            mfa_token=mfa_token,
        )

        return serialize_ecdsa_signature(bytes(sig.r), bytes(sig.s), sig.v)

    async def export_private_key(
        self,
        address: str,
        password: str | None = None,
        mfa_token: str | None = None,
        elevated_access_token: str | None = None,
    ) -> str | None:
        """Export the full EVM private key."""
        wp = self.get_wallet_from_map(address)
        shares = wp.external_server_key_shares
        if not shares and password:
            shares = await self.recover_key_shares(address, password, mfa_token)
        if not shares:
            raise DynamicSDKError(
                f"No key shares available for {address}. "
                "Pass a password to recover from backup."
            )

        return await super()._export_private_key_mpc(
            wallet_id=wp.wallet_id,
            chain_name="EVM",
            key_share=shares[0].secret_share,
            mfa_token=mfa_token,
            elevated_access_token=elevated_access_token,
        )

    async def import_private_key(
        self,
        private_key: str,
        threshold_signature_scheme: ThresholdSignatureScheme = ThresholdSignatureScheme.TWO_OF_TWO,
        password: str | None = None,
    ) -> str:
        """Import an existing EVM private key.

        Returns:
            The derived EVM address.
        """
        result = await super()._import_private_key_mpc(
            chain_name="EVM",
            private_key=private_key,
            threshold_signature_scheme=threshold_signature_scheme,
        )

        raw_pk = result["raw_public_key"]
        if isinstance(raw_pk, tuple):
            pk_bytes = bytes(raw_pk[0])  # uncompressed
        elif isinstance(raw_pk, (bytes, bytearray)):
            pk_bytes = bytes(raw_pk)
        else:
            pk_bytes = bytes.fromhex(str(raw_pk))

        address = derive_evm_address(pk_bytes)
        wallet_id = result["wallet_id"]
        key_shares = result["external_server_key_shares"]

        chain_config = MPC_CHAIN_CONFIG["EVM"]
        self._init_wallet_entry(
            account_address=address,
            wallet_id=wallet_id,
            chain_name="EVM",
            external_server_key_shares=key_shares,
            threshold_signature_scheme=threshold_signature_scheme,
            derivation_path=chain_config.derivation_path,
        )

        await self.backup_key_shares(address, password or self.environment_id)

        return address
