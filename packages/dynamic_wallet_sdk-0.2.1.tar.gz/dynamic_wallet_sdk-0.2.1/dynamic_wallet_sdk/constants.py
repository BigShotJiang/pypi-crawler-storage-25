"""Constants ported from packages/core/src/constants.ts."""

from __future__ import annotations

from enum import Enum
from typing import Final


class Environment(str, Enum):
    DEVELOPMENT = "development"
    PREPROD = "preprod"
    PRODUCTION = "production"


# Dynamic Auth base API URLs
DYNAMIC_AUTH_PROD_BASE_API_URL: Final = "https://app.dynamicauth.com"
DYNAMIC_AUTH_PREPROD_BASE_API_URL: Final = "https://app.dynamic-preprod.xyz"
DYNAMIC_AUTH_DEV_BASE_API_URL: Final = "http://localhost:4200"

DYNAMIC_AUTH_BASE_API_URL_MAP: Final = {
    Environment.PRODUCTION: DYNAMIC_AUTH_PROD_BASE_API_URL,
    Environment.PREPROD: DYNAMIC_AUTH_PREPROD_BASE_API_URL,
    Environment.DEVELOPMENT: DYNAMIC_AUTH_DEV_BASE_API_URL,
}

# Evervault keyshares relay URLs
DYNAMIC_KEYSHARES_RELAY_PROD_BASE_API_URL: Final = (
    "https://waas-keyshares-relay.dynamicauth.com"
)
DYNAMIC_KEYSHARES_RELAY_PREPROD_BASE_API_URL: Final = (
    "https://waas-keyshares-relay.dynamic-preprod.xyz"
)

DYNAMIC_KEYSHARES_RELAY_MAP: Final = {
    Environment.PRODUCTION: DYNAMIC_KEYSHARES_RELAY_PROD_BASE_API_URL,
    Environment.PREPROD: DYNAMIC_KEYSHARES_RELAY_PREPROD_BASE_API_URL,
    Environment.DEVELOPMENT: DYNAMIC_KEYSHARES_RELAY_PREPROD_BASE_API_URL,
}

# MPC relay URLs (where MPC operations are performed)
MPC_RELAY_PROD_API_URL: Final = "relay.dynamicauth.com"
MPC_RELAY_PREPROD_API_URL: Final = "relay.dynamic-preprod.xyz"
MPC_RELAY_DEV_API_URL: Final = "http://localhost:4200"

MPC_RELAY_URL_MAP: Final = {
    Environment.PRODUCTION: MPC_RELAY_PROD_API_URL,
    Environment.PREPROD: MPC_RELAY_PREPROD_API_URL,
    Environment.DEVELOPMENT: MPC_RELAY_DEV_API_URL,
}

# Request headers
DYNAMIC_REQUEST_ID_HEADER: Final = "x-dyn-request-id"
DYNAMIC_CLIENT_SESSION_SIGNATURE: Final = "x-dyn-client-session-signature"
DYNAMIC_MFA_TOKEN_HEADER: Final = "x-mfa-auth-token"
DYNAMIC_ELEVATED_ACCESS_TOKEN_HEADER: Final = "x-dyn-elevated-access-token"
DYNAMIC_FORWARD_MPC_HEADER: Final = "x-forward-mpc-client"
DYNAMIC_TRACE_ID_HEADER: Final = "x-dyn-trace-id"
DYNAMIC_TRACE_ELAPSED_TIME_HEADER: Final = "x-dyn-trace-elapsed-time"

# Evervault relay headers
RELAY_APP_ID_HEADER: Final = "X-Evervault-App-Id"
RELAY_API_KEY_HEADER: Final = "X-Evervault-Api-Key"

PROD_RELAY_APP_ID: Final = "app_6e12fc400995"
PREPROD_RELAY_APP_ID: Final = "app_32d15525a875"

DYNAMIC_CLIENT_RELAY_APP_ID_MAP: Final = {
    Environment.PRODUCTION: PROD_RELAY_APP_ID,
    Environment.PREPROD: PREPROD_RELAY_APP_ID,
    Environment.DEVELOPMENT: None,
}

PROD_RELAY_API_KEY: Final = (
    "ev:key:1:7kRuVm1sE1J5FjGz2ijufy0IkATzrBKEvde0IMLW1dt3xbFcdTdOKHO0vNnJeAjAD:YmAPOP:Jh7DdD"
)
PREPROD_RELAY_API_KEY: Final = (
    "ev:key:1:7j2jIPMzlcKlpDz1RTV6Vadsm8sgmj1VHZzJXqW9ie1dgmyzKmccEGI8BBWU0PaXv:XfF7Ri:ivvRp1"
)

DYNAMIC_CLIENT_RELAY_API_KEY_MAP: Final = {
    Environment.PRODUCTION: PROD_RELAY_API_KEY,
    Environment.PREPROD: PREPROD_RELAY_API_KEY,
    Environment.DEVELOPMENT: None,
}


class ChainType(str, Enum):
    EVM = "EVM"
    SVM = "SVM"
    COSMOS = "COSMOS"
    BTC = "BTC"
    FLOW = "FLOW"
    SUI = "SUI"
    TON = "TON"


class WalletOperation(str, Enum):
    REACH_THRESHOLD = "REACH_THRESHOLD"
    REACH_ALL_PARTIES = "REACH_ALL_PARTIES"
    SIGN_MESSAGE = "SIGN_MESSAGE"
    SIGN_TRANSACTION = "SIGN_TRANSACTION"
    REFRESH = "REFRESH"
    RESHARE = "RESHARE"
    EXPORT_PRIVATE_KEY = "EXPORT_PRIVATE_KEY"
    NO_OPERATION = "NO_OPERATION"
    RECOVER = "RECOVER"


class BackupLocation(str, Enum):
    DYNAMIC = "dynamic"
    GOOGLE_DRIVE = "googleDrive"
    ICLOUD = "iCloud"
    USER = "user"
    EXTERNAL = "external"
    DELEGATED = "delegated"


DELEGATED_SHARE_COUNT: Final = 1

SDK_VERSION: Final = "python-0.1.0"


def detect_environment(base_url: str) -> Environment:
    """Detect environment from base URL."""
    if not base_url:
        return Environment.PRODUCTION
    if "localhost" in base_url:
        return Environment.DEVELOPMENT
    if "dynamic-preprod" in base_url:
        return Environment.PREPROD
    return Environment.PRODUCTION
