# Demo Guide — Dynamic Python MPC Wallet SDK

This guide is written for AI agents and developers who want to quickly build a working
demo app against the Dynamic Python SDK.

> **No Rust required for SDK consumers.** If you install from PyPI, the compiled native
> extension is bundled in the wheel — `pip install dynamic-wallet-sdk` is all you need.
> The Rust/maturin setup below is only for contributors building from source in this repo.

A complete reference demo lives at `apps/python-demo/` in this repo.

---

## 1. What you need

| Credential | Where to get it | Env var |
|---|---|---|
| Environment ID | Dynamic dashboard → Settings → General | `DYNAMIC_ENV_ID` |
| API token | Dynamic dashboard → Settings → API | `DYNAMIC_API_TOKEN` |
| Base API URL | `https://app.dynamicauth.com` (prod) or `https://app.dynamic-preprod.xyz` (preprod) | `DYNAMIC_BASE_API_URL` |
| Backup password | Any string you choose | `BACKUP_PASSWORD` (optional) |

The SDK ships its own relay URL constants — you do **not** configure the MPC relay URL yourself.

---

## 2. Project layout

```
my-demo/
├── .env               # credentials (never commit)
├── .env.example       # template to commit
├── demo.py            # your demo script
└── pyproject.toml     # dependencies
```

---

## 3. pyproject.toml

If consuming the SDK from PyPI:

```toml
[project]
name = "my-dynamic-demo"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "dynamic-wallet-sdk>=0.1.0",
    "python-dotenv>=1.0",
    "pynacl>=1.5",      # only needed for SVM signature verification
    "eth-account>=0.13", # only needed for EVM signature verification
]
```

If consuming the SDK from source (local development in this repo):

```toml
[project]
name = "my-dynamic-demo"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "dynamic-wallet-sdk @ file:///${PROJECT_ROOT}/python",
    "python-dotenv>=1.0",
    "pynacl>=1.5",
]

[tool.uv.sources]
dynamic-wallet-sdk = { path = "../../python", editable = true }
```

---

## 4. Setup

### From PyPI (SDK consumers — no Rust needed)
```bash
python -m venv .venv
source .venv/bin/activate
pip install dynamic-wallet-sdk python-dotenv pynacl
```

### From source (SDK contributors — requires Rust)
The SDK has a Rust extension that must be compiled first:

```bash
# 1. Add MPC registry credentials to Cargo (one-time setup)
cat >> ~/.cargo/credentials.toml << 'EOF'
[registries.dynamic-mpc]
token = "Bearer <YOUR_MPC_REGISTRY_TOKEN>"
EOF

# 2. Build the Rust extension into the python/ venv
cd python
python -m venv .venv
source .venv/bin/activate
pip install maturin
maturin develop --release

# 3. Install remaining Python dependencies
pip install -e ".[dev]"
```

> **Note:** `maturin develop` compiles the Rust extension and installs it into the active
> venv. You must re-run it after any changes to `python/src/`.

---

## 5. .env file

```bash
DYNAMIC_BASE_API_URL=https://app.dynamic-preprod.xyz
DYNAMIC_ENV_ID=your-environment-id
DYNAMIC_API_TOKEN=your-api-token
BACKUP_PASSWORD=optional-backup-password
```

---

## 6. Core usage patterns

### EVM wallet (ECDSA / secp256k1)

```python
import asyncio
import os
from dotenv import load_dotenv
from dynamic_wallet_sdk.evm.client import DynamicEvmWalletClient
from eth_account import Account
from eth_account.messages import encode_defunct

load_dotenv()

async def main():
    async with DynamicEvmWalletClient(
        os.environ["DYNAMIC_ENV_ID"],
        base_api_url=os.environ.get("DYNAMIC_BASE_API_URL", "https://app.dynamicauth.com"),
    ) as client:
        # 1. Authenticate — exchange API token for a JWT
        await client.authenticate_api_token(os.environ["DYNAMIC_API_TOKEN"])

        # 2. Create wallet (runs MPC keygen — takes ~5 seconds)
        # Pass password= to encrypt and back up key shares during keygen
        address = await client.create_wallet_account(password="my-backup-password")
        print(f"EVM address: {address}")   # 0x-prefixed checksummed address

        # Brief pause for server-side wallet registration
        await asyncio.sleep(2)

        # 3. Sign a message (EIP-191 personal_sign)
        message = "Hello from Dynamic!"
        signature = await client.sign_message(message=message, address=address)
        print(f"Signature: {signature}")   # 0x-prefixed 65-byte hex

        # 4. Verify locally
        msg_obj = encode_defunct(text=message)
        recovered = Account.recover_message(msg_obj, signature=signature)
        assert recovered.lower() == address.lower(), "Signature mismatch!"
        print("Signature verified ✓")

        # 5. Sign a transaction (legacy format)
        tx = {
            "to": "0x000000000000000000000000000000000000dEaD",
            "value": 0,
            "nonce": 0,
            "gas": 21000,
            "gasPrice": 20_000_000_000,
            "chainId": 1,
            "data": "0x",
        }
        tx_sig = await client.sign_transaction(address=address, tx=tx)
        # tx_sig is a 0x-prefixed 65-byte hex string (r+s+v)

        # 6. Sign EIP-712 typed data
        typed_data = {
            "types": {
                "EIP712Domain": [
                    {"name": "name", "type": "string"},
                    {"name": "version", "type": "string"},
                    {"name": "chainId", "type": "uint256"},
                ],
                "Message": [{"name": "content", "type": "string"}],
            },
            "primaryType": "Message",
            "domain": {"name": "MyApp", "version": "1", "chainId": 1},
            "message": {"content": "EIP-712 test"},
        }
        typed_sig = await client.sign_typed_data(address, typed_data)

asyncio.run(main())
```

### Solana wallet (Ed25519)

```python
import asyncio
import os
import base58
import nacl.signing
from dotenv import load_dotenv
from dynamic_wallet_sdk.svm.client import DynamicSvmWalletClient

load_dotenv()

async def main():
    async with DynamicSvmWalletClient(
        os.environ["DYNAMIC_ENV_ID"],
        base_api_url=os.environ.get("DYNAMIC_BASE_API_URL", "https://app.dynamicauth.com"),
    ) as client:
        # 1. Authenticate
        await client.authenticate_api_token(os.environ["DYNAMIC_API_TOKEN"])

        # 2. Create wallet (Ed25519 MPC keygen)
        address = await client.create_wallet_account(password="my-backup-password")
        print(f"Solana address: {address}")   # base58-encoded 32-byte public key

        # 3. Sign a message (raw UTF-8 bytes, no prefixing)
        message = "Hello from Dynamic!"
        signature = await client.sign_message(message=message, address=address)
        print(f"Signature: {signature}")     # base58-encoded 64-byte signature

        # 4. Verify locally (Ed25519)
        pubkey_bytes = base58.b58decode(address)
        sig_bytes = base58.b58decode(signature)
        verify_key = nacl.signing.VerifyKey(pubkey_bytes)
        verify_key.verify(message.encode(), sig_bytes)   # raises BadSignatureError if wrong
        print("Signature verified ✓")

        # 5. Sign a transaction (raw serialized bytes)
        tx_bytes = bytes(64)   # replace with real serialized Solana tx bytes
        tx_sig_hex = await client.sign_transaction(address=address, tx_bytes=tx_bytes)
        # tx_sig_hex is a hex string of the 64-byte Ed25519 signature

asyncio.run(main())
```

### Backup and recovery

```python
# Backup happens automatically at keygen time when password= is passed:
address = await client.create_wallet_account(password="my-backup-password")

# To recover key shares (e.g., after losing them):
recovered_shares = await client.recover_key_shares(address, password="my-backup-password")
# Key shares are restored in-memory; signing works again immediately
```

---

## 7. Return types quick reference

| Method | EVM return | SVM return |
|---|---|---|
| `create_wallet_account()` | `str` — checksummed `0x` address | `str` — base58 address |
| `sign_message()` | `str` — `0x` 65-byte hex (r+s+v) | `str` — base58 64-byte sig |
| `sign_transaction()` | `str` — `0x` 65-byte hex | `str` — hex 64-byte sig |
| `sign_typed_data()` | `str` — `0x` 65-byte hex | N/A |
| `export_private_key()` | `str` — `0x` 32-byte hex scalar | `str` — hex 32-byte scalar |
| `recover_key_shares()` | `list[ServerKeyShare]` | `list[ServerKeyShare]` |

---

## 8. Error handling

```python
from dynamic_wallet_sdk.exceptions import DynamicSDKError, AuthenticationError, SSETimeoutError

try:
    address = await client.create_wallet_account()
except AuthenticationError:
    # Token expired or invalid — re-authenticate
    pass
except SSETimeoutError:
    # MPC ceremony timed out — retry
    pass
except DynamicSDKError as e:
    # All other SDK errors (API errors, missing key shares, unsupported chain, etc.)
    print(f"SDK error: {e}")
```

---

## 9. Common pitfalls

**`create_wallet_account()` succeeds but signing fails immediately**
Add `await asyncio.sleep(2)` after keygen. The Dynamic server needs ~1-2 seconds to
register the new wallet before it can participate in signing.

**`No key shares available for <address>`**
The wallet exists but key shares aren't in memory. Either:
- You forgot to call `create_wallet_account()` first, or
- The process restarted and shares were lost (call `recover_key_shares(address, password=...)`)

**`Unsupported chain` error**
The chain name passed to the client must match a key in `MPC_CHAIN_CONFIG` (see
`python/dynamic_wallet_sdk/mpc_config.py`). EVM clients use `"EVM"`, SVM uses `"SVM"`.
You don't set this directly — it's wired inside `DynamicEvmWalletClient` /
`DynamicSvmWalletClient`.

**`maturin develop` fails: registry auth error**
Your `~/.cargo/credentials.toml` is missing the `[registries.dynamic-mpc]` section.
See step 4 above.

**SVM signature verification fails**
SVM signs raw UTF-8 bytes with no prefix. Do not apply `encode_defunct` or any EIP-191
wrapping. Use `nacl.signing.VerifyKey` directly.

**EVM address case mismatch during verification**
`Account.recover_message()` returns a checksummed address. Always compare with `.lower()`.

---

## 10. Running the reference demo

```bash
cd apps/python-demo
cp .env.example .env
# fill in .env with your credentials

# Install (SDK must already be built — see step 4)
pip install -e .

# Run all demos
python demo.py --all

# Run specific demos
python demo.py --evm
python demo.py --svm
python demo.py --evm --backup    # includes backup/recovery round-trip
python demo.py --native          # native module sanity check only (no credentials needed)
```
