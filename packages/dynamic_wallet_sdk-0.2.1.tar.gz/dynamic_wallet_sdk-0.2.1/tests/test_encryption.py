"""Tests for AES-256-GCM encryption with PBKDF2 (crypto/encryption.py).

Two encryption versions are tested:
  v1 (ENCRYPTION_VERSION_LEGACY): 100K PBKDF2 iterations — legacy, still decryptable
  v2 (ENCRYPTION_VERSION_CURRENT): 1M PBKDF2 iterations — current default

Both versions use AES-256-GCM with a random 16-byte salt and 12-byte IV.
The version is stored in the encrypted blob so decrypt_data() can auto-detect.
Missing version fields fall back to v1 for backward compatibility.

Note: these tests are intentionally slow if run with v2 (1M iterations ≈ 1s each).
The sample_password fixture uses a short password which is fine for testing.
"""

import pytest

from dynamic_wallet_sdk.crypto.encryption import (
    ENCRYPTION_VERSION_CURRENT,
    ENCRYPTION_VERSION_LEGACY,
    EncryptedData,
    decrypt_data,
    encrypt_data,
    get_encryption_metadata,
)


class TestEncryptData:
    def test_round_trip_v2(self, sample_password):
        plaintext = "my-secret-key-share-data"
        encrypted = encrypt_data(plaintext, sample_password)

        assert encrypted.version == ENCRYPTION_VERSION_CURRENT
        assert encrypted.salt
        assert encrypted.iv
        assert encrypted.cipher

        decrypted = decrypt_data(encrypted, sample_password)
        assert decrypted == plaintext

    def test_round_trip_v1(self, sample_password):
        plaintext = "legacy-key-share"
        encrypted = encrypt_data(plaintext, sample_password, version=ENCRYPTION_VERSION_LEGACY)

        assert encrypted.version == ENCRYPTION_VERSION_LEGACY
        decrypted = decrypt_data(encrypted, sample_password)
        assert decrypted == plaintext

    def test_wrong_password_fails(self, sample_password):
        plaintext = "secret-data"
        encrypted = encrypt_data(plaintext, sample_password)

        with pytest.raises(Exception):
            decrypt_data(encrypted, "wrong-password")

    def test_decrypt_from_dict(self, sample_password):
        plaintext = "dict-test"
        encrypted = encrypt_data(plaintext, sample_password)

        data_dict = {
            "salt": encrypted.salt,
            "iv": encrypted.iv,
            "cipher": encrypted.cipher,
            "version": encrypted.version,
        }
        decrypted = decrypt_data(data_dict, sample_password)
        assert decrypted == plaintext

    def test_decrypt_legacy_fallback(self, sample_password):
        """When version is missing, should fall back to v1 iterations."""
        plaintext = "fallback-test"
        encrypted = encrypt_data(plaintext, sample_password, version=ENCRYPTION_VERSION_LEGACY)

        # Remove version to test fallback
        data_dict = {
            "salt": encrypted.salt,
            "iv": encrypted.iv,
            "cipher": encrypted.cipher,
        }
        decrypted = decrypt_data(data_dict, sample_password)
        assert decrypted == plaintext

    def test_invalid_version_raises(self, sample_password):
        with pytest.raises(ValueError, match="Unsupported"):
            encrypt_data("data", sample_password, version="v99")

    def test_different_encryptions_produce_different_output(self, sample_password):
        plaintext = "same-data"
        enc1 = encrypt_data(plaintext, sample_password)
        enc2 = encrypt_data(plaintext, sample_password)

        # Different random salt/iv should produce different ciphertext
        assert enc1.cipher != enc2.cipher

    def test_unicode_data(self, sample_password):
        plaintext = "Hello \u00e9\u00e8\u00ea\u00eb \U0001f30d"
        encrypted = encrypt_data(plaintext, sample_password)
        decrypted = decrypt_data(encrypted, sample_password)
        assert decrypted == plaintext


class TestEncryptionMetadata:
    def test_v2_metadata(self):
        meta = get_encryption_metadata(ENCRYPTION_VERSION_CURRENT)
        assert meta["algorithm"] == "AES-GCM"
        assert meta["keyDerivation"] == "PBKDF2"
        assert meta["iterations"] == 1_000_000
        assert meta["hashAlgorithm"] == "SHA-256"
        assert meta["algorithmLength"] == 256

    def test_v1_metadata(self):
        meta = get_encryption_metadata(ENCRYPTION_VERSION_LEGACY)
        assert meta["iterations"] == 100_000

    def test_invalid_version(self):
        with pytest.raises(ValueError):
            get_encryption_metadata("v99")
