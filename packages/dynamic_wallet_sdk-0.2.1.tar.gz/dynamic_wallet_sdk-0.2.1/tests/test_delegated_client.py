"""Tests for delegated signing client."""

from __future__ import annotations

import dynamic_wallet_mpc
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dynamic_wallet_sdk.delegated.client import (
    create_delegated_evm_client,
    create_delegated_svm_client,
    delegated_sign_message,
)
from dynamic_wallet_sdk.evm.client import DynamicEvmWalletClient
from dynamic_wallet_sdk.mpc_config import SigningAlgorithm
from dynamic_wallet_sdk.svm.client import DynamicSvmWalletClient

_ENV = "env_delegated_test"
_API_KEY = "dyn_test_key"
_WALLET_ID = "wallet-del-1"
_WALLET_API_KEY = "wallet-api-key-123"
_KEY_SHARE = "delegated-key-share"
_ROOM_ID = "room-abc-123"


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------


class TestCreateDelegatedEvmClient:
    async def test_creates_authenticated_evm_client(self):
        with patch.object(
            DynamicEvmWalletClient,
            "authenticate_api_token",
            new_callable=AsyncMock,
        ) as mock_auth:
            client = await create_delegated_evm_client(_ENV, _API_KEY)

        assert isinstance(client, DynamicEvmWalletClient)
        mock_auth.assert_awaited_once_with(_API_KEY)

    async def test_passes_options_to_client(self):
        with patch.object(
            DynamicEvmWalletClient,
            "authenticate_api_token",
            new_callable=AsyncMock,
        ):
            client = await create_delegated_evm_client(
                _ENV,
                _API_KEY,
                base_api_url="https://custom.api",
                debug=True,
            )

        assert client.debug is True
        assert client._base_api_url == "https://custom.api"


class TestCreateDelegatedSvmClient:
    async def test_creates_authenticated_svm_client(self):
        with patch.object(
            DynamicSvmWalletClient,
            "authenticate_api_token",
            new_callable=AsyncMock,
        ) as mock_auth:
            client = await create_delegated_svm_client(_ENV, _API_KEY)

        assert isinstance(client, DynamicSvmWalletClient)
        mock_auth.assert_awaited_once_with(_API_KEY)

    async def test_passes_options_to_client(self):
        with patch.object(
            DynamicSvmWalletClient,
            "authenticate_api_token",
            new_callable=AsyncMock,
        ):
            client = await create_delegated_svm_client(
                _ENV,
                _API_KEY,
                base_mpc_relay_url="relay.custom.xyz",
            )

        assert client._base_mpc_relay_url == "relay.custom.xyz"


# ---------------------------------------------------------------------------
# delegated_sign_message — ECDSA (EVM)
# ---------------------------------------------------------------------------


def _make_evm_client() -> DynamicEvmWalletClient:
    c = DynamicEvmWalletClient(_ENV)
    c._is_authenticated = True
    c._api_client.delegated_sign_message = AsyncMock(return_value={"roomId": _ROOM_ID})
    return c


def _make_svm_client() -> DynamicSvmWalletClient:
    c = DynamicSvmWalletClient(_ENV)
    c._is_authenticated = True
    c._api_client.delegated_sign_message = AsyncMock(return_value={"roomId": _ROOM_ID})
    return c


class TestDelegatedSignMessageEcdsa:
    async def test_sign_calls_api_with_wallet_api_key(self):
        client = _make_evm_client()
        mock_sig = MagicMock()

        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=mock_sig)

        with patch("dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer):
            with patch.object(dynamic_wallet_mpc, "PyMessageHash", MagicMock()):
                result = await delegated_sign_message(
                    client,
                    wallet_id=_WALLET_ID,
                    wallet_api_key=_WALLET_API_KEY,
                    key_share=_KEY_SHARE,
                    message="a" * 64,
                    chain_name="EVM",
                    is_formatted=True,
                )

        client._api_client.delegated_sign_message.assert_awaited_once()
        call_kwargs = client._api_client.delegated_sign_message.call_args.kwargs
        assert call_kwargs["wallet_api_key"] == _WALLET_API_KEY
        assert call_kwargs["wallet_id"] == _WALLET_ID
        assert result == mock_sig

    async def test_sign_does_not_mutate_shared_headers(self):
        """Verify wallet_api_key is NOT set on shared client headers."""
        client = _make_evm_client()
        initial_headers = dict(client._api_client.api_client.headers)

        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=MagicMock())

        with patch("dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer):
            with patch.object(dynamic_wallet_mpc, "PyMessageHash", MagicMock()):
                await delegated_sign_message(
                    client,
                    wallet_id=_WALLET_ID,
                    wallet_api_key=_WALLET_API_KEY,
                    key_share=_KEY_SHARE,
                    message="a" * 64,
                    chain_name="EVM",
                    is_formatted=True,
                )

        # Shared headers should not have the wallet API key
        assert "x-dyn-wallet-api-key" not in client._api_client.api_client.headers

    async def test_sign_with_context(self):
        client = _make_evm_client()
        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=MagicMock())

        with patch("dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer):
            with patch.object(dynamic_wallet_mpc, "PyMessageHash", MagicMock()):
                await delegated_sign_message(
                    client,
                    wallet_id=_WALLET_ID,
                    wallet_api_key=_WALLET_API_KEY,
                    key_share=_KEY_SHARE,
                    message="a" * 64,
                    chain_name="EVM",
                    is_formatted=True,
                    context={"evmMessage": "hello"},
                )

        call_kwargs = client._api_client.delegated_sign_message.call_args.kwargs
        assert call_kwargs["context"] == {"evmMessage": "hello"}

    async def test_sign_with_relay_url_override(self):
        client = _make_evm_client()
        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=MagicMock())

        with patch(
            "dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer
        ) as mock_get_signer:
            with patch.object(dynamic_wallet_mpc, "PyMessageHash", MagicMock()):
                await delegated_sign_message(
                    client,
                    wallet_id=_WALLET_ID,
                    wallet_api_key=_WALLET_API_KEY,
                    key_share=_KEY_SHARE,
                    message="a" * 64,
                    chain_name="EVM",
                    base_mpc_relay_url="custom-relay.xyz",
                )

        mock_get_signer.assert_called_once_with("EVM", "custom-relay.xyz")

    async def test_sign_unknown_chain_uses_default_path(self):
        """Unknown chain falls back to default derivation path."""
        client = _make_evm_client()
        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=MagicMock())

        with patch("dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer):
            with patch.object(dynamic_wallet_mpc, "PyMessageHash", MagicMock()):
                await delegated_sign_message(
                    client,
                    wallet_id=_WALLET_ID,
                    wallet_api_key=_WALLET_API_KEY,
                    key_share=_KEY_SHARE,
                    message="a" * 64,
                    chain_name="UNKNOWN_CHAIN",
                )

        # Should not raise; signer.sign should be called
        mock_signer.sign.assert_awaited_once()


# ---------------------------------------------------------------------------
# delegated_sign_message — Ed25519 (SVM)
# ---------------------------------------------------------------------------


class TestDelegatedSignMessageEd25519:
    async def test_sign_with_is_formatted_true(self):
        """is_formatted=True: message is already hex, use as-is."""
        client = _make_svm_client()
        msg_hex = "deadbeef" * 8  # 64 hex chars = 32 bytes
        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=bytes(64))

        with patch("dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer):
            result = await delegated_sign_message(
                client,
                wallet_id=_WALLET_ID,
                wallet_api_key=_WALLET_API_KEY,
                key_share=_KEY_SHARE,
                message=msg_hex,
                chain_name="SVM",
                is_formatted=True,
            )

        mock_signer.sign.assert_awaited_once()
        sig_call_args = mock_signer.sign.call_args[0]
        # Second arg is key_share, third is msg_bytes
        assert sig_call_args[2] == bytes.fromhex(msg_hex)

    async def test_sign_with_is_formatted_false_plain_text(self):
        """is_formatted=False: plain text message is UTF-8 hex-encoded."""
        client = _make_svm_client()
        plain_msg = "Hello Solana"
        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=bytes(64))

        with patch("dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer):
            result = await delegated_sign_message(
                client,
                wallet_id=_WALLET_ID,
                wallet_api_key=_WALLET_API_KEY,
                key_share=_KEY_SHARE,
                message=plain_msg,
                chain_name="SVM",
                is_formatted=False,
            )

        mock_signer.sign.assert_awaited_once()
        sig_call_args = mock_signer.sign.call_args[0]
        expected_bytes = plain_msg.encode("utf-8")
        assert sig_call_args[2] == expected_bytes

    async def test_sign_with_is_formatted_false_0x_prefix_is_plain_text(self):
        """is_formatted=False with 0x prefix: treated as plain text (UTF-8 encoded)."""
        client = _make_svm_client()
        hex_msg = "0xdeadbeef"
        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=bytes(64))

        with patch("dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer):
            await delegated_sign_message(
                client,
                wallet_id=_WALLET_ID,
                wallet_api_key=_WALLET_API_KEY,
                key_share=_KEY_SHARE,
                message=hex_msg,
                chain_name="SVM",
                is_formatted=False,
            )

        mock_signer.sign.assert_awaited_once()
        sig_call_args = mock_signer.sign.call_args[0]
        # format_ed25519_message always UTF-8 encodes — "0xdeadbeef" is literal text
        expected_bytes = "0xdeadbeef".encode("utf-8")
        assert sig_call_args[2] == expected_bytes

    async def test_sign_passes_wallet_api_key_to_api(self):
        client = _make_svm_client()
        mock_signer = MagicMock()
        mock_signer.sign = AsyncMock(return_value=bytes(64))

        with patch("dynamic_wallet_sdk.delegated.client.get_mpc_signer", return_value=mock_signer):
            await delegated_sign_message(
                client,
                wallet_id=_WALLET_ID,
                wallet_api_key=_WALLET_API_KEY,
                key_share=_KEY_SHARE,
                message="deadbeef" * 8,
                chain_name="SVM",
                is_formatted=True,
            )

        call_kwargs = client._api_client.delegated_sign_message.call_args.kwargs
        assert call_kwargs["wallet_api_key"] == _WALLET_API_KEY
