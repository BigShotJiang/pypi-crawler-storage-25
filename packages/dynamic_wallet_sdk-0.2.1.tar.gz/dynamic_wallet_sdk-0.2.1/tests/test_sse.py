"""Tests for SSE event parsing and streaming helpers.

SSE wire format recap:
    event: <type>\\n
    data: <json>\\n
    \\n                  ← blank line marks end of event

An event without a data field is silently dropped by parse_sse_events().
Incomplete events (no trailing \\n\\n) are held in the caller's buffer.
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from dynamic_wallet_sdk.api.sse import (
    SSEEvent,
    _await_ceremony_complete,
    _clear_buffer,
    _do_stream,
    _do_stream_with_callback,
    _handle_error_watch_first,
    _parse_block,
    _raise_for_status,
    _run_mpc_phase,
    _sse_reader,
    _wait_for_trigger,
    _watch_for_terminal_event,
    parse_sse_events,
    stream_sse_request,
    stream_sse_with_callback,
)
from dynamic_wallet_sdk.exceptions import DynamicSDKError, SSEError, SSETimeoutError


class TestParseSSEEvents:
    def test_single_event(self):
        text = "event: keygen_complete\ndata: {\"roomId\": \"abc\"}\n\n"
        events = parse_sse_events(text)
        assert len(events) == 1
        assert events[0].type == "keygen_complete"
        assert events[0].data == {"roomId": "abc"}

    def test_multiple_events(self):
        text = (
            "event: room_created\ndata: {\"roomId\": \"r1\"}\n\n"
            "event: ceremony_complete\ndata: {\"status\": \"ok\"}\n\n"
        )
        events = parse_sse_events(text)
        assert len(events) == 2
        assert events[0].type == "room_created"
        assert events[1].type == "ceremony_complete"

    def test_error_event(self):
        text = 'event: error\ndata: {"error": "something went wrong"}\n\n'
        events = parse_sse_events(text)
        assert len(events) == 1
        assert events[0].type == "error"
        assert events[0].data["error"] == "something went wrong"

    def test_keygen_complete_with_ids(self):
        text = (
            'event: keygen_complete\n'
            'data: {"roomId": "uuid-123", "walletId": "w1", "serverKeygenIds": ["id1", "id2"]}\n'
            '\n'
        )
        events = parse_sse_events(text)
        assert len(events) == 1
        assert events[0].data["serverKeygenIds"] == ["id1", "id2"]

    def test_empty_input(self):
        assert parse_sse_events("") == []

    def test_incomplete_event_ignored(self):
        # No blank line terminator
        text = "event: partial\ndata: {}"
        events = parse_sse_events(text)
        assert len(events) == 0

    def test_event_with_only_type_no_data(self):
        text = "event: ping\n\n"
        events = parse_sse_events(text)
        assert len(events) == 0  # No data field, so not emitted

    def test_whitespace_trimming(self):
        text = "event:  keygen_complete  \ndata:  {\"ok\": true}  \n\n"
        events = parse_sse_events(text)
        assert len(events) == 1
        assert events[0].type == "keygen_complete"
        assert events[0].data == {"ok": True}


# ---------------------------------------------------------------------------
# _parse_block edge cases
# ---------------------------------------------------------------------------


class TestParseBlock:
    def test_non_json_data_returned_as_string(self):
        event = _parse_block("event: ping\ndata: plain text")
        assert event is not None
        assert event.type == "ping"
        assert event.data == "plain text"

    def test_multi_line_data_concatenated(self):
        # A continuation line (no "data:" prefix) is appended to current_data
        event = _parse_block("event: msg\ndata: hello\nworld")
        assert event is not None
        assert event.type == "msg"
        assert "world" in event.data  # concatenated

    def test_missing_type_returns_none(self):
        assert _parse_block("data: {\"a\": 1}") is None

    def test_missing_data_returns_none(self):
        assert _parse_block("event: ping") is None

    def test_valid_json_parsed(self):
        event = _parse_block('event: done\ndata: {"x": 42}')
        assert event is not None
        assert event.data == {"x": 42}


# ---------------------------------------------------------------------------
# _raise_for_status
# ---------------------------------------------------------------------------


class TestRaiseForStatus:
    def test_ok_response_does_not_raise(self):
        req = httpx.Request("POST", "https://example.com")
        resp = httpx.Response(200, request=req)
        _raise_for_status(resp)  # must not raise

    def test_4xx_raises_dynamic_sdk_error(self):
        req = httpx.Request("POST", "https://api.example.com/endpoint")
        resp = httpx.Response(401, request=req, content=b"Unauthorized")
        with pytest.raises(DynamicSDKError, match="401"):
            _raise_for_status(resp)

    def test_5xx_raises_dynamic_sdk_error(self):
        req = httpx.Request("POST", "https://api.example.com/endpoint")
        resp = httpx.Response(500, request=req, content=b"Internal Server Error")
        with pytest.raises(DynamicSDKError, match="500"):
            _raise_for_status(resp)


# ---------------------------------------------------------------------------
# Queue-based helpers (no HTTP required)
# ---------------------------------------------------------------------------


class TestWaitForTrigger:
    async def test_returns_data_on_trigger_event(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="status", data={}))
        await q.put(SSEEvent(type="keygen_complete", data={"roomId": "r1"}))
        result = await _wait_for_trigger(q, "keygen_complete")
        assert result == {"roomId": "r1"}

    async def test_raises_sse_error_on_error_event_dict(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="error", data={"error": "ceremony failed"}))
        with pytest.raises(SSEError, match="ceremony failed"):
            await _wait_for_trigger(q, "keygen_complete")

    async def test_raises_sse_error_on_error_event_string(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="error", data="plain error string"))
        with pytest.raises(SSEError, match="plain error string"):
            await _wait_for_trigger(q, "keygen_complete")

    async def test_raises_on_stream_end(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(None)
        with pytest.raises(SSEError, match="ended"):
            await _wait_for_trigger(q, "keygen_complete")


class TestWatchForTerminalEvent:
    async def test_returns_error_event(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="status", data={}))
        await q.put(SSEEvent(type="error", data={"error": "fail"}))
        result = await _watch_for_terminal_event(q)
        assert result is not None
        assert result.type == "error"

    async def test_returns_ceremony_complete(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="ceremony_complete", data={"walletId": "w1"}))
        result = await _watch_for_terminal_event(q)
        assert result is not None
        assert result.type == "ceremony_complete"

    async def test_returns_none_on_stream_end(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(None)
        result = await _watch_for_terminal_event(q)
        assert result is None


class TestAwaitCeremonyComplete:
    async def test_returns_mpc_result_and_ceremony_data(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="ceremony_complete", data={"walletId": "w1"}))
        mpc, ceremony = await _await_ceremony_complete(q, "key_share_data")
        assert mpc == "key_share_data"
        assert ceremony == {"walletId": "w1"}

    async def test_returns_none_ceremony_on_stream_end(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(None)
        mpc, ceremony = await _await_ceremony_complete(q, "result")
        assert mpc == "result"
        assert ceremony is None

    async def test_raises_on_error_during_wait(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="error", data={"error": "post-mpc failure"}))
        with pytest.raises(SSEError, match="post-mpc failure"):
            await _await_ceremony_complete(q, "result")

    async def test_timeout_returns_none_ceremony(self):
        q: asyncio.Queue = asyncio.Queue()
        # Simulate timeout by making the context manager raise immediately
        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def instant_timeout(_delay):
            raise asyncio.TimeoutError()
            yield  # pragma: no cover

        with patch("dynamic_wallet_sdk.api.sse.asyncio.timeout", instant_timeout):
            mpc, ceremony = await _await_ceremony_complete(q, "result")
        assert mpc == "result"
        assert ceremony is None


# ---------------------------------------------------------------------------
# stream_sse_request — success and timeout paths
# ---------------------------------------------------------------------------


class TestStreamSseRequest:
    async def test_success_returns_event_data(self):
        client = MagicMock(spec=httpx.AsyncClient)
        expected = {"walletId": "w1"}
        with patch("dynamic_wallet_sdk.api.sse._do_stream", new=AsyncMock(return_value=expected)):
            result = await stream_sse_request(client, "https://x.com/api", {}, "success")
        assert result == expected

    async def test_timeout_raises_sse_timeout_error(self):
        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def instant_timeout(_delay):
            raise asyncio.TimeoutError()
            yield  # pragma: no cover

        client = MagicMock(spec=httpx.AsyncClient)
        with patch("dynamic_wallet_sdk.api.sse.asyncio.timeout", instant_timeout):
            with pytest.raises(SSETimeoutError, match="timed out"):
                await stream_sse_request(client, "https://x.com/api", {}, "success")

    async def test_passes_extra_headers(self):
        client = MagicMock(spec=httpx.AsyncClient)
        captured: dict = {}

        async def capture(_client, _url, _body, headers, _event):
            captured.update(headers)
            return {}

        with patch("dynamic_wallet_sdk.api.sse._do_stream", new=capture):
            await stream_sse_request(
                client, "https://x.com/api", {}, "success",
                headers={"x-custom": "value"},
            )
        assert captured.get("x-custom") == "value"


# ---------------------------------------------------------------------------
# _clear_buffer
# ---------------------------------------------------------------------------


class TestClearBuffer:
    def test_returns_text_after_last_double_newline(self):
        buf = "event: a\ndata: {}\n\nremainder"
        assert _clear_buffer(buf) == "remainder"

    def test_returns_full_buffer_when_no_separator(self):
        buf = "no separator here"
        assert _clear_buffer(buf) == buf

    def test_empty_string(self):
        assert _clear_buffer("") == ""


# ---------------------------------------------------------------------------
# _raise_for_status — text-access failure branch
# ---------------------------------------------------------------------------


class TestRaiseForStatusTextFails:
    def test_body_still_raises_when_text_raises(self):
        """Lines 30-31: exc.response.text raises — must still raise DynamicSDKError."""
        import httpx

        req = httpx.Request("POST", "https://api.example.com/")
        # Build a real HTTPStatusError but swap response.text for a property that raises
        real_resp = httpx.Response(500, request=req, content=b"err")

        class BadTextResponse(httpx.Response):
            @property
            def text(self):
                raise RuntimeError("cannot decode")

        bad_resp = BadTextResponse(500, request=req)
        exc = httpx.HTTPStatusError("500", request=req, response=bad_resp)

        # Patch raise_for_status so our BadTextResponse exception is used
        with patch.object(bad_resp, "raise_for_status", side_effect=exc):
            with pytest.raises(DynamicSDKError, match="500"):
                _raise_for_status(bad_resp)


# ---------------------------------------------------------------------------
# _do_stream — inner streaming loop
# ---------------------------------------------------------------------------


class _StreamCM:
    """Minimal async context manager wrapping a mock response."""

    def __init__(self, response):
        self._response = response

    async def __aenter__(self):
        return self._response

    async def __aexit__(self, *args):
        pass


def _make_mock_response(lines):
    async def _aiter():
        for line in lines:
            yield line

    resp = MagicMock()
    resp.status_code = 200
    resp.raise_for_status = MagicMock()
    resp.aiter_lines = _aiter
    return resp


class TestDoStream:
    async def test_returns_on_success_event(self):
        resp = _make_mock_response([
            "event: done", "data: {\"roomId\": \"r1\"}", "",
        ])
        client = MagicMock()
        client.stream = MagicMock(return_value=_StreamCM(resp))

        result = await _do_stream(client, "https://x.com", {}, {}, "done")
        assert result == {"roomId": "r1"}

    async def test_raises_on_error_event(self):
        resp = _make_mock_response([
            "event: error", "data: {\"error\": \"bad\"}", "",
        ])
        client = MagicMock()
        client.stream = MagicMock(return_value=_StreamCM(resp))

        with pytest.raises(SSEError, match="bad"):
            await _do_stream(client, "https://x.com", {}, {}, "done")

    async def test_raises_when_stream_ends_without_success(self):
        resp = _make_mock_response([
            "event: other", "data: {}", "",
        ])
        client = MagicMock()
        client.stream = MagicMock(return_value=_StreamCM(resp))

        with pytest.raises(SSEError, match="ended"):
            await _do_stream(client, "https://x.com", {}, {}, "done")


# ---------------------------------------------------------------------------
# _sse_reader
# ---------------------------------------------------------------------------


class TestSseReader:
    async def test_pushes_events_and_sentinel(self):
        resp = _make_mock_response([
            "event: keygen_complete", "data: {\"roomId\": \"r1\"}", "",
        ])
        queue: asyncio.Queue = asyncio.Queue()
        await _sse_reader(resp, queue)

        event = await queue.get()
        assert event is not None
        assert event.type == "keygen_complete"
        sentinel = await queue.get()
        assert sentinel is None

    async def test_sentinel_sent_even_when_no_events(self):
        resp = _make_mock_response([""])
        queue: asyncio.Queue = asyncio.Queue()
        await _sse_reader(resp, queue)
        sentinel = await queue.get()
        assert sentinel is None

    async def test_sentinel_sent_on_exception(self):
        async def _bad_iter():
            raise RuntimeError("stream broke")
            yield  # pragma: no cover

        resp = MagicMock()
        resp.aiter_lines = _bad_iter

        queue: asyncio.Queue = asyncio.Queue()
        with pytest.raises(RuntimeError):
            await _sse_reader(resp, queue)

        sentinel = await queue.get()
        assert sentinel is None


# ---------------------------------------------------------------------------
# _handle_error_watch_first
# ---------------------------------------------------------------------------


class TestHandleErrorWatchFirst:
    async def test_raises_on_error_event(self):
        async def _slow():
            await asyncio.sleep(100)

        mpc_task = asyncio.create_task(_slow())

        async def _error():
            return SSEEvent(type="error", data={"error": "bad thing"})

        error_watch = asyncio.create_task(_error())
        await asyncio.sleep(0)  # let error_watch finish

        with pytest.raises(SSEError, match="bad thing"):
            await _handle_error_watch_first(mpc_task, error_watch)

    async def test_raises_on_ceremony_complete_before_mpc(self):
        async def _slow():
            await asyncio.sleep(100)

        mpc_task = asyncio.create_task(_slow())

        async def _ceremony():
            return SSEEvent(type="ceremony_complete", data={})

        error_watch = asyncio.create_task(_ceremony())
        await asyncio.sleep(0)

        with pytest.raises(SSEError, match="ceremony_complete before MPC"):
            await _handle_error_watch_first(mpc_task, error_watch)

    async def test_raises_on_stream_end(self):
        async def _slow():
            await asyncio.sleep(100)

        mpc_task = asyncio.create_task(_slow())

        async def _none():
            return None

        error_watch = asyncio.create_task(_none())
        await asyncio.sleep(0)

        with pytest.raises(SSEError, match="Stream ended during MPC"):
            await _handle_error_watch_first(mpc_task, error_watch)


# ---------------------------------------------------------------------------
# _run_mpc_phase
# ---------------------------------------------------------------------------


class TestRunMpcPhase:
    async def test_error_watch_first_raises_sse_error(self):
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="error", data={"error": "server blew up"}))

        block = asyncio.Event()

        async def slow_mpc(_):
            await block.wait()  # blocks until cancelled
            return "never"  # pragma: no cover

        with pytest.raises(SSEError, match="server blew up"):
            await _run_mpc_phase(q, slow_mpc, {})

    async def test_mpc_raises_propagates_exception(self):
        q: asyncio.Queue = asyncio.Queue()

        async def failing_mpc(_):
            raise ValueError("mpc failed hard")

        with pytest.raises(ValueError, match="mpc failed hard"):
            await _run_mpc_phase(q, failing_mpc, {})

    async def test_mpc_completes_first_no_ceremony(self):
        from contextlib import asynccontextmanager

        q: asyncio.Queue = asyncio.Queue()

        async def fast_mpc(_):
            return "mpc_result"

        @asynccontextmanager
        async def instant_timeout(_delay):
            raise asyncio.TimeoutError()
            yield  # pragma: no cover

        with patch("dynamic_wallet_sdk.api.sse.asyncio.timeout", instant_timeout):
            mpc_r, ceremony = await _run_mpc_phase(q, fast_mpc, {})

        assert mpc_r == "mpc_result"
        assert ceremony is None

    async def test_both_complete_simultaneously_with_error(self):
        # Both tasks complete in the same asyncio tick: fast mpc + error in queue.
        # This covers the `if error_watch in done: ... if ev.type == "error":` branch.
        q: asyncio.Queue = asyncio.Queue()
        await q.put(SSEEvent(type="error", data={"error": "concurrent error"}))

        async def fast_mpc(_):
            return "result"

        with pytest.raises(SSEError, match="concurrent error"):
            await _run_mpc_phase(q, fast_mpc, {})


# ---------------------------------------------------------------------------
# _do_stream_with_callback
# ---------------------------------------------------------------------------


class TestDoStreamWithCallback:
    async def test_returns_mpc_and_ceremony_data(self):
        resp = _make_mock_response([
            "event: keygen_complete", "data: {\"roomId\": \"r1\", \"serverKeygenIds\": [\"s1\"]}", "",
            "event: ceremony_complete", "data: {\"walletId\": \"w1\"}", "",
        ])
        client = MagicMock()
        client.stream = MagicMock(return_value=_StreamCM(resp))

        cb = AsyncMock(return_value="mpc_result")

        mpc_r, ceremony = await _do_stream_with_callback(
            client, "https://x.com", {}, {}, "keygen_complete", cb
        )
        assert mpc_r == "mpc_result"
        cb.assert_awaited_once()

    async def test_raises_on_error_event(self):
        resp = _make_mock_response([
            "event: error", "data: {\"error\": \"service down\"}", "",
        ])
        client = MagicMock()
        client.stream = MagicMock(return_value=_StreamCM(resp))

        cb = AsyncMock(return_value="result")

        with pytest.raises(SSEError, match="service down"):
            await _do_stream_with_callback(
                client, "https://x.com", {}, {}, "keygen_complete", cb
            )


# ---------------------------------------------------------------------------
# stream_sse_with_callback
# ---------------------------------------------------------------------------


class TestStreamSseWithCallback:
    async def test_success_returns_result(self):
        cb = AsyncMock(return_value="mpc")
        with patch(
            "dynamic_wallet_sdk.api.sse._do_stream_with_callback",
            new=AsyncMock(return_value=("mpc", {"walletId": "w1"})),
        ):
            result = await stream_sse_with_callback(
                MagicMock(spec=httpx.AsyncClient),
                "https://x.com/api",
                {},
                "keygen_complete",
                cb,
            )
        assert result == ("mpc", {"walletId": "w1"})

    async def test_timeout_raises_sse_timeout_error(self):
        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def instant_timeout(_delay):
            raise asyncio.TimeoutError()
            yield  # pragma: no cover

        cb = AsyncMock()
        with patch("dynamic_wallet_sdk.api.sse.asyncio.timeout", instant_timeout):
            with pytest.raises(SSETimeoutError, match="timed out"):
                await stream_sse_with_callback(
                    MagicMock(spec=httpx.AsyncClient),
                    "https://x.com/api",
                    {},
                    "keygen_complete",
                    cb,
                )

    async def test_passes_extra_headers(self):
        captured: dict = {}

        async def capture(_client, _url, _body, headers, _event, _cb):
            captured.update(headers)
            return ("result", None)

        with patch("dynamic_wallet_sdk.api.sse._do_stream_with_callback", new=capture):
            await stream_sse_with_callback(
                MagicMock(spec=httpx.AsyncClient),
                "https://x.com/api",
                {},
                "keygen_complete",
                AsyncMock(),
                headers={"x-foo": "bar"},
            )
        assert captured.get("x-foo") == "bar"
