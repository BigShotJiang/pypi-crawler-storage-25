"""Shared pytest fixtures for all test modules.

Unit test fixtures (no credentials required):
  - sample_password: a test password string for encryption tests
  - sample_environment_id: a fake env ID for wallet client unit tests

End-to-end test fixtures (require DYNAMIC_ENV_ID + DYNAMIC_API_TOKEN env vars):
  - preprod_env_id: from DYNAMIC_ENV_ID env var
  - preprod_api_token: from DYNAMIC_API_TOKEN env var
  - preprod_base_url: from DYNAMIC_BASE_API_URL (defaults to preprod)

Run unit tests only (no credentials needed):
    pytest tests/ --ignore=tests/test_e2e_preprod.py

Run e2e tests:
    DYNAMIC_ENV_ID=<id> DYNAMIC_API_TOKEN=<token> pytest tests/test_e2e_preprod.py -v -s
"""

import os

import pytest


@pytest.fixture
def sample_password():
    return "test-password-123"


@pytest.fixture
def sample_environment_id():
    return "env_test_12345"


# -- Preprod E2E fixtures --


@pytest.fixture
def preprod_env_id():
    return os.environ.get("DYNAMIC_ENV_ID", "")


@pytest.fixture
def preprod_api_token():
    return os.environ.get("DYNAMIC_API_TOKEN", "")


@pytest.fixture
def preprod_base_url():
    return os.environ.get(
        "DYNAMIC_BASE_API_URL", "https://app.dynamic-preprod.xyz"
    )
