"""Tests for DynamicSvmWalletClient."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dynamic_wallet_sdk.exceptions import DynamicSDKError
from dynamic_wallet_sdk.mpc.types import ServerKeyShare
from dynamic_wallet_sdk.mpc_config import ThresholdSignatureScheme
from dynamic_wallet_sdk.svm.client import DynamicSvmWalletClient
from dynamic_wallet_sdk.wallet_client import DynamicWalletClient

_ENV = "env_svm_test"
_TSS = ThresholdSignatureScheme.TWO_OF_TWO
# Valid 32-byte Ed25519 public key (base58-encoded as Solana address)
_PK_BYTES = bytes(range(32))
import base58 as _base58
_ADDR = _base58.b58encode(_PK_BYTES).decode("ascii")
_WALLET_ID = "wallet-svm-1"
_SECRET = "svm-secret-share"


def _authenticated_client() -> DynamicSvmWalletClient:
    c = DynamicSvmWalletClient(_ENV)
    c._is_authenticated = True
    return c


def _client_with_wallet(address: str = _ADDR) -> DynamicSvmWalletClient:
    c = _authenticated_client()
    ks = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
    c._init_wallet_entry(
        account_address=address,
        wallet_id=_WALLET_ID,
        chain_name="SVM",
        external_server_key_shares=[ks],
        threshold_signature_scheme=_TSS,
        derivation_path=[44, 501, 0, 0, 0],
    )
    return c


# ---------------------------------------------------------------------------
# create_wallet_account
# ---------------------------------------------------------------------------


class TestCreateWalletAccount:
    async def test_creates_and_returns_address(self):
        c = _authenticated_client()
        pk_bytes = bytes(range(32))
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": pk_bytes,
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        address = await c.create_wallet_account()
        # Solana addresses are base58, not hex
        assert not address.startswith("0x")
        assert len(address) > 0
        c.backup_key_shares.assert_awaited_once()

    async def test_creates_with_hex_str_pubkey(self):
        c = _authenticated_client()
        pk_hex = "00" * 32
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": pk_hex,
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        address = await c.create_wallet_account()
        assert len(address) > 0

    async def test_uses_password_for_backup(self):
        c = _authenticated_client()
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": bytes(32),
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        await c.create_wallet_account(password="my-pass")
        assert c.backup_key_shares.call_args[0][1] == "my-pass"

    async def test_falls_back_to_env_id(self):
        c = _authenticated_client()
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": bytes(32),
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        await c.create_wallet_account()
        assert c.backup_key_shares.call_args[0][1] == _ENV


# ---------------------------------------------------------------------------
# sign_message
# ---------------------------------------------------------------------------


class TestSignMessage:
    async def test_sign_with_stored_shares_returns_base58(self):
        c = _client_with_wallet()
        sig_bytes = bytes(64)

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=sig_bytes)):
            result = await c.sign_message("Hello Solana", _ADDR)
        assert isinstance(result, str)
        assert len(result) > 0

    async def test_sign_recovers_shares_with_password(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="SVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        mock_share = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        c.recover_key_shares = AsyncMock(return_value=[mock_share])

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=bytes(64))):
            result = await c.sign_message("Hello", _ADDR, password="pass")
        c.recover_key_shares.assert_awaited_once()
        assert isinstance(result, str)

    async def test_sign_raises_without_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="SVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )

        with pytest.raises(DynamicSDKError, match="No key shares"):
            await c.sign_message("Hello", _ADDR)

    async def test_sign_with_explicit_key_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="SVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        shares = [ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)]

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=bytes(64))):
            result = await c.sign_message("Hello", _ADDR, key_shares=shares)
        assert isinstance(result, str)

    async def test_sign_non_bytes_result(self):
        c = _client_with_wallet()

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value="non-bytes-sig")):
            result = await c.sign_message("Hello", _ADDR)
        assert result == "non-bytes-sig"


# ---------------------------------------------------------------------------
# sign_transaction
# ---------------------------------------------------------------------------


class TestSignTransaction:
    async def test_sign_transaction_success(self):
        c = _client_with_wallet()

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=bytes(64))):
            result = await c.sign_transaction(_ADDR, bytes(100))
        assert isinstance(result, str)
        assert len(result) == 128  # 64 bytes * 2

    async def test_sign_transaction_recovers_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="SVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        mock_share = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        c.recover_key_shares = AsyncMock(return_value=[mock_share])

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=bytes(64))):
            result = await c.sign_transaction(_ADDR, bytes(10), password="pass")
        assert isinstance(result, str)

    async def test_sign_transaction_raises_without_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="SVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )

        with pytest.raises(DynamicSDKError, match="No key shares"):
            await c.sign_transaction(_ADDR, bytes(10))

    async def test_sign_transaction_non_bytes_result(self):
        c = _client_with_wallet()

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value="non-bytes")):
            result = await c.sign_transaction(_ADDR, bytes(10))
        assert result == "non-bytes"


# ---------------------------------------------------------------------------
# export_private_key
# ---------------------------------------------------------------------------


class TestExportPrivateKey:
    async def test_export_success(self):
        c = _client_with_wallet()

        with patch.object(DynamicWalletClient, "_export_private_key_mpc", new=AsyncMock(return_value="solana-xpriv")):
            result = await c.export_private_key(_ADDR)
        assert result == "solana-xpriv"

    async def test_export_recovers_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="SVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        mock_share = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        c.recover_key_shares = AsyncMock(return_value=[mock_share])

        with patch.object(DynamicWalletClient, "_export_private_key_mpc", new=AsyncMock(return_value="xpriv")):
            result = await c.export_private_key(_ADDR, password="pass")
        assert result == "xpriv"

    async def test_export_raises_without_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="SVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )

        with pytest.raises(DynamicSDKError, match="No key shares"):
            await c.export_private_key(_ADDR)

    async def test_export_passes_tokens(self):
        c = _client_with_wallet()
        mock_export = AsyncMock(return_value="xpriv")

        with patch.object(DynamicWalletClient, "_export_private_key_mpc", new=mock_export):
            await c.export_private_key(_ADDR, mfa_token="mfa", elevated_access_token="eat")
        assert mock_export.call_args.kwargs["mfa_token"] == "mfa"
        assert mock_export.call_args.kwargs["elevated_access_token"] == "eat"


# ---------------------------------------------------------------------------
# import_private_key
# ---------------------------------------------------------------------------


class TestImportPrivateKey:
    def _mock_result(self, pk):
        mock_ks = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        return {"raw_public_key": pk, "wallet_id": _WALLET_ID, "external_server_key_shares": [mock_ks]}

    async def test_import_success(self):
        c = _authenticated_client()
        c.backup_key_shares = AsyncMock()

        with patch.object(DynamicWalletClient, "_import_private_key_mpc", new=AsyncMock(return_value=self._mock_result(bytes(32)))):
            address = await c.import_private_key("deadbeef" * 8)
        assert not address.startswith("0x")
        c.backup_key_shares.assert_awaited_once()

    async def test_import_with_hex_pubkey(self):
        c = _authenticated_client()
        c.backup_key_shares = AsyncMock()

        with patch.object(DynamicWalletClient, "_import_private_key_mpc", new=AsyncMock(return_value=self._mock_result("00" * 32))):
            address = await c.import_private_key("deadbeef" * 8)
        assert len(address) > 0

    async def test_import_with_bytearray_pubkey(self):
        c = _authenticated_client()
        c.backup_key_shares = AsyncMock()

        with patch.object(DynamicWalletClient, "_import_private_key_mpc", new=AsyncMock(return_value=self._mock_result(bytearray(32)))):
            address = await c.import_private_key("deadbeef" * 8)
        assert len(address) > 0

    async def test_import_with_password(self):
        c = _authenticated_client()
        c.backup_key_shares = AsyncMock()

        with patch.object(DynamicWalletClient, "_import_private_key_mpc", new=AsyncMock(return_value=self._mock_result(bytes(32)))):
            await c.import_private_key("deadbeef" * 8, password="my-pass")
        assert c.backup_key_shares.call_args[0][1] == "my-pass"
