"""Tests for SVM (Solana) utility functions (svm/utils.py).

Solana addresses are simply base58-encoded 32-byte Ed25519 public keys.
There is no hashing or checksum — the address IS the public key.

Coverage:
  TestDeriveSolanaAddress — base58 encoding of raw 32-byte pubkey; round-trip
  TestFormatEd25519Message — pass-through of hex strings; UTF-8 encode non-hex
"""

import pytest

from dynamic_wallet_sdk.svm.utils import derive_solana_address, format_ed25519_message


class TestDeriveSolanaAddress:
    def test_known_pubkey(self):
        """32-byte Ed25519 pubkey should base58 encode to a valid Solana address."""
        # Known 32-byte pubkey
        pubkey = bytes(range(32))
        address = derive_solana_address(pubkey)
        assert isinstance(address, str)
        assert len(address) > 0
        # Should be valid base58
        import base58

        decoded = base58.b58decode(address)
        assert decoded == pubkey

    def test_all_zeros(self):
        pubkey = bytes(32)
        address = derive_solana_address(pubkey)
        assert isinstance(address, str)

    def test_hex_string_input(self):
        """Should accept hex string pubkey."""
        hex_key = "00" * 32
        address = derive_solana_address(hex_key)
        assert isinstance(address, str)

    def test_round_trip(self):
        """base58_decode(derive_solana_address(pk)) == pk."""
        import base58

        pubkey = bytes(range(32))
        address = derive_solana_address(pubkey)
        recovered = base58.b58decode(address)
        assert recovered == pubkey


class TestFormatEd25519Message:
    def test_string_to_hex(self):
        result = format_ed25519_message("Hello")
        assert result == "48656c6c6f"  # "Hello" in hex

    def test_hex_looking_string_is_utf8_encoded(self):
        # Strings that look like hex are treated as plain text and UTF-8 encoded,
        # matching the TS SDK which always does TextEncoder.encode(message).
        result = format_ed25519_message("deadbeef")
        assert result == "deadbeef".encode("utf-8").hex()

    def test_0x_prefix_is_utf8_encoded(self):
        # "0x..." strings are treated as plain text (not pre-encoded hex).
        # A user passing "0xdeadbeef" as a text message gets UTF-8 encoding,
        # not silent hex decode. Use is_formatted=True for pre-encoded hex.
        result = format_ed25519_message("0xdeadbeef")
        assert result == "0xdeadbeef".encode("utf-8").hex()

    def test_non_hex_string(self):
        result = format_ed25519_message("not hex data!")
        # Should be hex-encoded UTF-8
        assert result == "not hex data!".encode("utf-8").hex()
