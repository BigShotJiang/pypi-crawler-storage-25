"""Tests for EVM utility functions (evm/utils.py).

Tests use known cryptographic test vectors where possible so failures indicate
a real regression in the hash/encoding logic, not just a change in behavior.

Coverage:
  TestDeriveEvmAddress    — keccak256(pubkey[1:])[-20:] + EIP-55 checksum
  TestFormatEvmMessage    — EIP-191 prefix + keccak256 → 32-byte hash hex
  TestSerializeEcdsaSignature — r || s || v → 0x-prefixed 65-byte hex string

Not tested here (requires live MPC relay):
  - hash_typed_data (EIP-712) — logic is simple delegation to eth_account
  - evm_prefix_message — light string manipulation, covered implicitly by format tests
"""

import pytest

from dynamic_wallet_sdk.evm.utils import (
    derive_evm_address,
    format_evm_message,
    serialize_ecdsa_signature,
)


class TestDeriveEvmAddress:
    def test_known_pubkey(self):
        """Test EVM address derivation against a known test vector.

        Public key (uncompressed, 65 bytes with 0x04 prefix):
        Ethereum address derivation: keccak256(pubkey[1:])[-20:]
        """
        # Well-known test vector from Ethereum
        # Private key: 0x0000000000000000000000000000000000000000000000000000000000000001
        # Public key (uncompressed):
        pubkey_hex = (
            "04"
            "79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798"
            "483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8"
        )
        pubkey = bytes.fromhex(pubkey_hex)
        address = derive_evm_address(pubkey)

        # Known Ethereum address for private key 1
        assert address.lower() == "0x7e5f4552091a69125d5dfcb7b8c2659029395bdf"
        # Should be checksummed
        assert address.startswith("0x")
        assert len(address) == 42

    def test_64_byte_pubkey(self):
        """Should work with 64-byte raw key (no 0x04 prefix)."""
        pubkey_hex = (
            "79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798"
            "483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8"
        )
        pubkey = bytes.fromhex(pubkey_hex)
        address = derive_evm_address(pubkey)
        assert address.lower() == "0x7e5f4552091a69125d5dfcb7b8c2659029395bdf"

    def test_checksum_encoding(self):
        """Address should have mixed-case EIP-55 checksum."""
        pubkey_hex = (
            "04"
            "79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798"
            "483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8"
        )
        pubkey = bytes.fromhex(pubkey_hex)
        address = derive_evm_address(pubkey)
        # EIP-55 checksum should make it not all lowercase or all uppercase
        hex_part = address[2:]
        assert hex_part != hex_part.lower() or hex_part != hex_part.upper()


class TestFormatEvmMessage:
    def test_string_message(self):
        """EIP-191 prefix should be applied and keccak256 hashed."""
        result = format_evm_message("Hello World")
        assert isinstance(result, str)
        assert len(result) == 64  # 32 bytes as hex

    def test_hex_message(self):
        result = format_evm_message("0xdeadbeef")
        assert len(result) == 64

    def test_different_messages_different_hashes(self):
        h1 = format_evm_message("message1")
        h2 = format_evm_message("message2")
        assert h1 != h2


class TestSerializeEcdsaSignature:
    def test_basic_serialization(self):
        r = bytes(32)  # 32 zero bytes
        s = bytes(32)
        v = 27

        result = serialize_ecdsa_signature(r, s, v)
        assert result.startswith("0x")
        # 0x + 64 (r) + 64 (s) + 2 (v) = 132 chars
        assert len(result) == 132

    def test_with_real_values(self):
        r = bytes.fromhex("a" * 64)
        s = bytes.fromhex("b" * 64)
        v = 28

        result = serialize_ecdsa_signature(r, s, v)
        assert "a" * 64 in result
        assert "b" * 64 in result
        assert result.endswith("1c")  # 28 = 0x1c
