"""Tests for DynamicWalletClient — the core orchestration base class.

These are unit tests; no MPC relay or Dynamic API is called. Network calls are
mocked with unittest.mock.

Coverage:
  TestDynamicWalletClient   — initialization, wallet map CRUD, address normalization
  TestWalletClientAuth      — authenticate_api_token() success and failure paths
  TestWalletClientContextManager — async context manager (__aenter__ / __aexit__)

What's NOT tested here (covered by test_e2e_preprod.py):
  - keygen(), sign_message(), backup_key_shares(), recover_key_shares()
  These require real MPC relay connections and cannot be meaningfully mocked
  without recreating the entire MPC ceremony protocol.
"""

from __future__ import annotations

import base64
import json
import logging
from dataclasses import dataclass
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dynamic_wallet_sdk.constants import BackupLocation, Environment
from dynamic_wallet_sdk.crypto.encryption import EncryptedData, encrypt_data
from dynamic_wallet_sdk.exceptions import AuthenticationError, DynamicSDKError, WalletNotFoundError
from dynamic_wallet_sdk.mpc.types import (
    BackupLocationInfo,
    KeyShareBackupInfo,
    ServerKeyShare,
    WalletProperties,
)
from dynamic_wallet_sdk.mpc_config import ThresholdSignatureScheme
from dynamic_wallet_sdk.wallet_client import DynamicWalletClient


class TestDynamicWalletClient:
    def test_init(self, sample_environment_id):
        client = DynamicWalletClient(sample_environment_id)
        assert client.environment_id == sample_environment_id
        assert client._is_authenticated is False

    def test_ensure_authenticated_raises(self, sample_environment_id):
        client = DynamicWalletClient(sample_environment_id)
        with pytest.raises(AuthenticationError, match="must be authenticated"):
            client._ensure_authenticated()

    def test_wallet_map_operations(self, sample_environment_id):
        client = DynamicWalletClient(sample_environment_id)

        # Init wallet entry
        client._init_wallet_entry(
            account_address="0xAbCdEf1234567890AbCdEf1234567890AbCdEf12",
            wallet_id="w1",
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
            derivation_path=[44, 60, 0, 0, 0],
        )

        # Should find with case-insensitive lookup
        wp = client.get_wallet_from_map("0xabcdef1234567890abcdef1234567890abcdef12")
        assert wp.wallet_id == "w1"
        assert wp.chain_name == "EVM"

        # Update
        client.update_wallet_in_map(
            "0xAbCdEf1234567890AbCdEf1234567890AbCdEf12",
            wallet_id="w2",
        )
        wp = client.get_wallet_from_map("0xabcdef1234567890abcdef1234567890abcdef12")
        assert wp.wallet_id == "w2"

    def test_wallet_not_found(self, sample_environment_id):
        client = DynamicWalletClient(sample_environment_id)
        with pytest.raises(WalletNotFoundError):
            client.get_wallet_from_map("0xnonexistent")

    def test_normalize_evm_address(self, sample_environment_id):
        client = DynamicWalletClient(sample_environment_id)
        assert client._normalize_address("0xAbCd") == "0xabcd"

    def test_normalize_solana_address(self, sample_environment_id):
        client = DynamicWalletClient(sample_environment_id)
        # Solana addresses don't start with 0x
        assert client._normalize_address("SoLaNaAddr123") == "SoLaNaAddr123"


class TestWalletClientAuth:
    @pytest.mark.asyncio
    async def test_authenticate_success(self, sample_environment_id):
        client = DynamicWalletClient(sample_environment_id)

        mock_response = {
            "encodedJwts": {"minifiedJwt": "jwt-token-123"}
        }

        with patch.object(
            client._api_client.__class__,
            "authenticate_api_token",
            new_callable=AsyncMock,
            return_value=mock_response,
        ):
            # Also need to mock the close on temporary client
            with patch(
                "dynamic_wallet_sdk.wallet_client.DynamicApiClient"
            ) as MockApi:
                mock_instance = AsyncMock()
                mock_instance.authenticate_api_token = AsyncMock(
                    return_value=mock_response
                )
                mock_instance.close = AsyncMock()
                MockApi.return_value = mock_instance

                await client.authenticate_api_token("test-api-key")
                assert client._is_authenticated is True

    @pytest.mark.asyncio
    async def test_authenticate_failure(self, sample_environment_id):
        client = DynamicWalletClient(sample_environment_id)

        with patch(
            "dynamic_wallet_sdk.wallet_client.DynamicApiClient"
        ) as MockApi:
            mock_instance = AsyncMock()
            mock_instance.authenticate_api_token = AsyncMock(
                side_effect=Exception("Auth failed")
            )
            mock_instance.close = AsyncMock()
            MockApi.return_value = mock_instance

            with pytest.raises(AuthenticationError, match="Authentication failed"):
                await client.authenticate_api_token("bad-key")


class TestWalletClientContextManager:
    @pytest.mark.asyncio
    async def test_async_context_manager(self, sample_environment_id):
        async with DynamicWalletClient(sample_environment_id) as client:
            assert client.environment_id == sample_environment_id


# ---------------------------------------------------------------------------
# Additional init / map edge cases
# ---------------------------------------------------------------------------


class TestWalletClientInit:
    def test_debug_mode_sets_logging(self, sample_environment_id):
        # Line 81: if debug: logging.basicConfig(level=logging.DEBUG)
        with patch("dynamic_wallet_sdk.wallet_client.logging.basicConfig") as mock_basicConfig:
            client = DynamicWalletClient(sample_environment_id, debug=True)
        assert client.debug is True
        mock_basicConfig.assert_called_once_with(level=logging.DEBUG)

    def test_update_wallet_in_map_not_found(self, sample_environment_id):
        # Line 120: WalletNotFoundError from update_wallet_in_map
        client = DynamicWalletClient(sample_environment_id)
        with pytest.raises(WalletNotFoundError):
            client.update_wallet_in_map("0xdeadbeef", wallet_id="new")


# ---------------------------------------------------------------------------
# MPC signer orchestration — mocked
# ---------------------------------------------------------------------------

_ENV = "env_test_abc"
_CHAIN = "EVM"
_TSS = ThresholdSignatureScheme.TWO_OF_TWO


def _make_client(env=_ENV):
    return DynamicWalletClient(env)


def _authenticated_client(env=_ENV):
    c = DynamicWalletClient(env)
    c._is_authenticated = True
    return c


def _mock_init_result():
    return MagicMock(keygen_id="kid-1", keygen_secret=b"secret")


class TestExternalServerInitKeygen:
    async def test_returns_list_of_init_dicts(self):
        c = _authenticated_client()
        mock_signer = MagicMock()
        mock_signer.init_keygen.return_value = _mock_init_result()

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            results = c._external_server_init_keygen(_CHAIN, _TSS)

        assert len(results) == 1
        assert results[0]["keygen_id"] == "kid-1"
        assert results[0]["keygen_secret"] == b"secret"

    async def test_unsupported_chain_raises(self):
        c = _authenticated_client()
        mock_signer = MagicMock()
        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            # get_mpc_signer itself would raise, but let's test the config lookup path
            with patch("dynamic_wallet_sdk.wallet_client.MPC_CONFIG", {_TSS: MagicMock(client_threshold=1)}):
                mock_signer.init_keygen.return_value = _mock_init_result()
                results = c._external_server_init_keygen(_CHAIN, _TSS)
                assert len(results) == 1


class TestExternalServerKeygen:
    async def test_ecdsa_keygen_concurrent(self):
        c = _authenticated_client()
        mock_signer = MagicMock()
        mock_keygen_result = MagicMock(secret_share="share1")
        mock_signer.keygen = AsyncMock(return_value=mock_keygen_result)

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            results = await c._external_server_keygen(
                chain_name=_CHAIN,
                room_id="room-1",
                dynamic_server_keygen_ids=["srv-1"],
                external_init_results=[{"keygen_id": "kid-1", "keygen_secret": b"sec"}],
                threshold_signature_scheme=_TSS,
            )

        assert len(results) == 1
        assert results[0].secret_share == "share1"

    async def test_unsupported_chain_raises(self):
        c = _authenticated_client()
        mock_signer = MagicMock()
        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            with pytest.raises(DynamicSDKError, match="Unsupported chain"):
                await c._external_server_keygen(
                    chain_name="UNSUPPORTED_CHAIN",
                    room_id="r",
                    dynamic_server_keygen_ids=[],
                    external_init_results=[{"keygen_id": "k", "keygen_secret": b"s"}],
                    threshold_signature_scheme=_TSS,
                )


class TestKeygen:
    async def test_full_keygen_returns_expected_keys(self):
        c = _authenticated_client()
        mock_signer = MagicMock()
        mock_signer.init_keygen.return_value = _mock_init_result()
        mock_signer.derive_pubkey.return_value = b"\x04" + b"\xab" * 64

        mock_kr = MagicMock(secret_share="share-data")

        c._api_client.create_wallet_keygen = AsyncMock(
            return_value=([mock_kr], {"walletId": "wallet-123"})
        )

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            result = await c.keygen(_CHAIN, _TSS)

        assert "raw_public_key" in result
        assert "external_server_key_shares" in result
        assert result["wallet_id"] == "wallet-123"
        assert len(result["external_server_key_shares"]) == 1

    async def test_keygen_no_ceremony_data(self):
        c = _authenticated_client()
        mock_signer = MagicMock()
        mock_signer.init_keygen.return_value = _mock_init_result()
        mock_signer.derive_pubkey.return_value = b"\x04" + b"\x00" * 64

        mock_kr = MagicMock(secret_share="share-data")
        c._api_client.create_wallet_keygen = AsyncMock(return_value=([mock_kr], None))

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            result = await c.keygen(_CHAIN, _TSS)

        assert result["wallet_id"] is None

    async def test_keygen_requires_auth(self):
        c = _make_client()
        with pytest.raises(AuthenticationError):
            await c.keygen(_CHAIN, _TSS)


class TestSignMessage:
    async def test_sign_delegates_to_api_client(self):
        c = _authenticated_client()
        c._api_client.sign_message_with_callback = AsyncMock(return_value=("0xsig", None))

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=MagicMock()):
            result = await c._sign_mpc_message(
                wallet_id="w1",
                message="0xdeadbeef",
                chain_name=_CHAIN,
                key_share="share",
            )
        assert result == "0xsig"

    async def test_sign_retries_on_stream_ended(self):
        from dynamic_wallet_sdk.exceptions import SSEError

        c = _authenticated_client()
        call_count = {"n": 0}

        async def flaky(*args, **kwargs):
            call_count["n"] += 1
            if call_count["n"] < 2:
                raise SSEError("Stream ended during MPC")
            return ("0xsig", None)

        c._api_client.sign_message_with_callback = flaky

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=MagicMock()):
            with patch("dynamic_wallet_sdk.wallet_client.asyncio.sleep", new=AsyncMock()):
                result = await c._sign_mpc_message(
                    wallet_id="w1",
                    message="0xdeadbeef",
                    chain_name=_CHAIN,
                    key_share="share",
                )
        assert result == "0xsig"
        assert call_count["n"] == 2

    async def test_sign_raises_after_max_retries(self):
        from dynamic_wallet_sdk.exceptions import SSEError

        c = _authenticated_client()
        c._api_client.sign_message_with_callback = AsyncMock(
            side_effect=SSEError("Stream ended during MPC")
        )

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=MagicMock()):
            with patch("dynamic_wallet_sdk.wallet_client.asyncio.sleep", new=AsyncMock()):
                with pytest.raises(SSEError, match="Stream ended"):
                    await c._sign_mpc_message(
                        wallet_id="w1",
                        message="0xdeadbeef",
                        chain_name=_CHAIN,
                        key_share="share",
                    )

    async def test_sign_requires_auth(self):
        c = _make_client()
        with pytest.raises(AuthenticationError):
            await c._sign_mpc_message(
                wallet_id="w1", message="m", chain_name=_CHAIN, key_share="s"
            )


class TestRefreshWallet:
    async def test_refresh_calls_api_and_signer(self):
        c = _authenticated_client()
        c._api_client.refresh_wallet_account_shares = AsyncMock(
            return_value={"roomId": "r1"}
        )
        mock_signer = MagicMock()
        mock_signer.refresh = AsyncMock(return_value="refreshed")

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            result = await c.refresh_wallet(
                wallet_id="w1", chain_name=_CHAIN, key_share="share"
            )

        assert result == "refreshed"

    async def test_refresh_requires_auth(self):
        c = _make_client()
        with pytest.raises(AuthenticationError):
            await c.refresh_wallet(wallet_id="w1", chain_name=_CHAIN, key_share="s")


class TestExportPrivateKey:
    async def test_export_calls_api_and_signer(self):
        c = _authenticated_client()
        c._api_client.export_key = AsyncMock(return_value={"roomId": "r1"})

        mock_signer = MagicMock()
        mock_signer.export_id.return_value = "exp-1"
        mock_signer.export_full_private_key = AsyncMock(return_value="xpriv-data")

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            result = await c._export_private_key_mpc(
                wallet_id="w1", chain_name=_CHAIN, key_share="share"
            )

        assert result == "xpriv-data"

    async def test_export_requires_auth(self):
        c = _make_client()
        with pytest.raises(AuthenticationError):
            await c._export_private_key_mpc(wallet_id="w1", chain_name=_CHAIN, key_share="s")


class TestImportPrivateKey:
    async def test_import_returns_expected_keys(self):
        c = _authenticated_client()
        mock_signer = MagicMock()
        mock_signer.init_keygen.return_value = _mock_init_result()
        mock_signer.derive_pubkey.return_value = b"\x04" + b"\xcd" * 64

        mock_ir = MagicMock(secret_share="imported-share")
        c._api_client.import_private_key_keygen = AsyncMock(
            return_value=([mock_ir], {"walletId": "imported-wallet"})
        )

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            result = await c._import_private_key_mpc(
                chain_name=_CHAIN,
                private_key="deadbeef" * 8,
                threshold_signature_scheme=_TSS,
            )

        assert result["wallet_id"] == "imported-wallet"
        assert len(result["external_server_key_shares"]) == 1

    async def test_import_requires_auth(self):
        c = _make_client()
        with pytest.raises(AuthenticationError):
            await c._import_private_key_mpc(
                chain_name=_CHAIN,
                private_key="deadbeef" * 8,
                threshold_signature_scheme=_TSS,
            )


# ---------------------------------------------------------------------------
# backup_key_shares
# ---------------------------------------------------------------------------


def _wallet_with_shares(env_id=_ENV, address="0xabc") -> tuple[DynamicWalletClient, str]:
    c = _authenticated_client(env_id)
    ks = ServerKeyShare(key_share_id="ks-1", secret_share="secret-share-data")
    c._init_wallet_entry(
        account_address=address,
        wallet_id="wallet-1",
        chain_name=_CHAIN,
        external_server_key_shares=[ks],
        threshold_signature_scheme=_TSS,
    )
    return c, address


class TestBackupKeyShares:
    async def test_backup_encrypts_and_marks_shares(self):
        c, addr = _wallet_with_shares()
        mock_signer = MagicMock()
        mock_signer.export_id.return_value = "exp-id-1"

        c._api_client.store_encrypted_backup = AsyncMock(
            return_value={"keyShareIds": ["srv-ks-1"]}
        )
        c._api_client.mark_key_shares_as_backed_up = AsyncMock(return_value={"ok": True})

        with patch("dynamic_wallet_sdk.wallet_client.get_mpc_signer", return_value=mock_signer):
            await c.backup_key_shares(addr, "test-password")

        c._api_client.store_encrypted_backup.assert_awaited_once()
        c._api_client.mark_key_shares_as_backed_up.assert_awaited_once()

        wp = c.get_wallet_from_map(addr)
        assert wp.external_server_key_shares_backup_info.password_encrypted is True
        backups = wp.external_server_key_shares_backup_info.backups.get("dynamic", [])
        assert len(backups) == 1
        assert backups[0].key_share_id == "srv-ks-1"

    async def test_backup_requires_auth(self):
        c = _make_client()
        c._init_wallet_entry(
            account_address="0xabc",
            wallet_id="w1",
            chain_name=_CHAIN,
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        with pytest.raises(AuthenticationError):
            await c.backup_key_shares("0xabc", "pass")


# ---------------------------------------------------------------------------
# recover_key_shares
# ---------------------------------------------------------------------------


class TestRecoverKeyShares:
    async def _setup_encrypted_share(self, password: str) -> tuple[DynamicWalletClient, str, str]:
        """Return (client, address, base64_encrypted_blob)."""
        c, addr = _wallet_with_shares()
        ks = c.get_wallet_from_map(addr).external_server_key_shares[0]

        key_share_json = json.dumps({
            "keyShareId": ks.key_share_id,
            "secretShare": ks.secret_share,
        })
        enc = encrypt_data(key_share_json, password)
        enc_json = json.dumps({
            "salt": enc.salt, "iv": enc.iv,
            "cipher": enc.cipher, "version": enc.version,
        })
        blob = base64.b64encode(enc_json.encode()).decode()
        return c, addr, blob

    async def test_recover_decrypts_key_shares(self):
        password = "recovery-pass"
        c, addr, blob = await self._setup_encrypted_share(password)

        c._api_client.recover_encrypted_backup = AsyncMock(return_value={
            "keyShares": [{"encryptedAccountCredential": blob, "id": "ks-1"}]
        })

        recovered = await c.recover_key_shares(addr, password)

        assert len(recovered) == 1
        assert recovered[0].secret_share == "secret-share-data"

    async def test_recover_raises_when_no_shares(self):
        c, addr = _wallet_with_shares()
        c._api_client.recover_encrypted_backup = AsyncMock(
            return_value={"keyShares": []}
        )

        with pytest.raises(DynamicSDKError, match="no shares"):
            await c.recover_key_shares(addr, "any-pass")

    async def test_recover_uses_stored_backup_ids(self):
        password = "test-pass"
        c, addr, blob = await self._setup_encrypted_share(password)

        wp = c.get_wallet_from_map(addr)
        wp.external_server_key_shares_backup_info.backups["dynamic"] = [
            BackupLocationInfo(location=BackupLocation.DYNAMIC, key_share_id="stored-id")
        ]

        c._api_client.recover_encrypted_backup = AsyncMock(return_value={
            "keyShares": [{"encryptedAccountCredential": blob}]
        })

        recovered = await c.recover_key_shares(addr, password)
        # Verify the stored ID was passed to the API
        call_kwargs = c._api_client.recover_encrypted_backup.call_args.kwargs
        assert call_kwargs["key_share_ids"] == ["stored-id"]
        assert len(recovered) == 1

    async def test_recover_requires_auth(self):
        c = _make_client()
        c._init_wallet_entry(
            account_address="0xabc",
            wallet_id="w1",
            chain_name=_CHAIN,
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        with pytest.raises(AuthenticationError):
            await c.recover_key_shares("0xabc", "pass")


# ---------------------------------------------------------------------------
# get_wallets_from_user
# ---------------------------------------------------------------------------


class TestGetWalletsFromUser:
    async def test_populates_wallet_map(self):
        c = _authenticated_client()
        c._api_client.get_user = AsyncMock(return_value={
            "verifiedCredentials": [
                {
                    "walletName": "dynamicwaas",
                    "address": "0xabc",
                    "walletId": "w1",
                    "chain": "EVM",
                    "walletProperties": {
                        "thresholdSignatureScheme": "TWO_OF_TWO",
                        "derivationPath": None,
                    },
                }
            ]
        })

        wallets = await c.get_wallets_from_user()
        assert len(wallets) == 1
        wp = c.get_wallet_from_map("0xabc")
        assert wp.wallet_id == "w1"
        assert wp.chain_name == "EVM"

    async def test_skips_non_dynamicwaas_credentials(self):
        c = _authenticated_client()
        c._api_client.get_user = AsyncMock(return_value={
            "verifiedCredentials": [
                {"walletName": "other", "address": "0xabc", "walletId": "w1", "chain": "EVM"},
                {
                    "walletName": "dynamicwaas",
                    "address": "0xdef",
                    "walletId": "w2",
                    "chain": "EVM",
                    "walletProperties": {"thresholdSignatureScheme": "TWO_OF_TWO"},
                },
            ]
        })

        wallets = await c.get_wallets_from_user()
        assert len(wallets) == 1
        assert "0xdef" in wallets

    async def test_handles_derivation_path_json(self):
        c = _authenticated_client()
        c._api_client.get_user = AsyncMock(return_value={
            "verifiedCredentials": [
                {
                    "walletName": "dynamicwaas",
                    "address": "0xaaa",
                    "walletId": "w1",
                    "chain": "EVM",
                    "walletProperties": {
                        "thresholdSignatureScheme": "TWO_OF_TWO",
                        "derivationPath": "[44, 60, 0, 0, 0]",
                    },
                }
            ]
        })

        wallets = await c.get_wallets_from_user()
        wp = wallets.get("0xaaa")
        assert wp.derivation_path == [44, 60, 0, 0, 0]

    async def test_requires_auth(self):
        c = _make_client()
        with pytest.raises(AuthenticationError):
            await c.get_wallets_from_user()
