"""Tests for BaseClient (api/client.py) and DynamicApiClient (api/dynamic_api.py).

All HTTP calls are mocked — no network connections are made.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from dynamic_wallet_sdk.api.client import BaseClient
from dynamic_wallet_sdk.api.dynamic_api import DynamicApiClient, _request_id, _trace_headers
from dynamic_wallet_sdk.constants import (
    DYNAMIC_ELEVATED_ACCESS_TOKEN_HEADER,
    DYNAMIC_MFA_TOKEN_HEADER,
    DYNAMIC_REQUEST_ID_HEADER,
    DYNAMIC_TRACE_ID_HEADER,
    Environment,
)
from dynamic_wallet_sdk.exceptions import DynamicSDKError
from dynamic_wallet_sdk.mpc_config import ThresholdSignatureScheme

ENV_ID = "env_test_abc123"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ok_response(data: dict, status: int = 200) -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.json.return_value = data
    resp.raise_for_status = MagicMock()
    resp.status_code = status
    resp.text = ""
    return resp


def _error_response(status: int, body: bytes = b"error") -> httpx.Response:
    req = httpx.Request("POST", "https://api.example.com/path")
    return httpx.Response(status, request=req, content=body)


# ---------------------------------------------------------------------------
# BaseClient
# ---------------------------------------------------------------------------


class TestBaseClient:
    def test_init_defaults_to_production(self):
        client = BaseClient(environment_id=ENV_ID)
        assert client.environment_id == ENV_ID
        assert client._environment == Environment.PRODUCTION

    def test_init_with_explicit_base_api_url(self):
        client = BaseClient(
            environment_id=ENV_ID,
            base_api_url="https://app.preprod.dynamic.xyz",
        )
        assert "preprod" in client._base_api_url

    def test_init_with_auth_token_sets_headers(self):
        client = BaseClient(environment_id=ENV_ID, auth_token="my-token")
        assert client.api_client.headers.get("Authorization") == "Bearer my-token"
        assert client.relay_client.headers.get("Authorization") == "Bearer my-token"

    def test_set_auth_token_updates_both_clients(self):
        client = BaseClient(environment_id=ENV_ID)
        client.set_auth_token("updated-token")
        assert client.api_client.headers.get("Authorization") == "Bearer updated-token"
        assert client.relay_client.headers.get("Authorization") == "Bearer updated-token"
        assert client._auth_token == "updated-token"

    def test_raise_for_status_passes_on_2xx(self):
        req = httpx.Request("GET", "https://example.com")
        resp = httpx.Response(200, request=req)
        BaseClient._raise_for_status(resp)  # must not raise

    def test_raise_for_status_raises_on_4xx(self):
        resp = _error_response(401, b"Unauthorized")
        with pytest.raises(DynamicSDKError, match="401"):
            BaseClient._raise_for_status(resp)

    def test_raise_for_status_raises_on_5xx(self):
        resp = _error_response(500, b"Internal Server Error")
        with pytest.raises(DynamicSDKError, match="500"):
            BaseClient._raise_for_status(resp)

    async def test_close_does_not_raise(self):
        client = BaseClient(environment_id=ENV_ID)
        await client.close()

    async def test_async_context_manager(self):
        client = BaseClient(environment_id=ENV_ID)
        async with client as c:
            assert c is client


# ---------------------------------------------------------------------------
# _trace_headers / _request_id
# ---------------------------------------------------------------------------


class TestHelpers:
    def test_request_id_returns_hex_string(self):
        rid = _request_id()
        assert isinstance(rid, str)
        assert len(rid) == 32

    def test_trace_headers_always_has_request_id(self):
        headers = _trace_headers()
        assert DYNAMIC_REQUEST_ID_HEADER in headers

    def test_trace_headers_with_custom_request_id(self):
        headers = _trace_headers(request_id="my-id")
        assert headers[DYNAMIC_REQUEST_ID_HEADER] == "my-id"

    def test_trace_headers_with_trace_id(self):
        headers = _trace_headers(trace_id="trace-xyz")
        assert headers[DYNAMIC_TRACE_ID_HEADER] == "trace-xyz"

    def test_trace_headers_with_mfa_token(self):
        headers = _trace_headers(mfa_token="mfa-abc")
        assert headers[DYNAMIC_MFA_TOKEN_HEADER] == "mfa-abc"

    def test_trace_headers_with_elevated_access_token(self):
        headers = _trace_headers(elevated_access_token="eat-tok")
        assert headers[DYNAMIC_ELEVATED_ACCESS_TOKEN_HEADER] == "eat-tok"

    def test_trace_headers_omits_optional_when_none(self):
        headers = _trace_headers()
        assert DYNAMIC_TRACE_ID_HEADER not in headers
        assert DYNAMIC_MFA_TOKEN_HEADER not in headers


# ---------------------------------------------------------------------------
# DynamicApiClient — plain HTTP methods
# ---------------------------------------------------------------------------


class TestDynamicApiClientHttp:
    def _client(self) -> DynamicApiClient:
        return DynamicApiClient(environment_id=ENV_ID, auth_token="tok")

    async def test_authenticate_api_token(self):
        c = self._client()
        c.api_client.post = AsyncMock(return_value=_ok_response({"jwt": "tok123"}))
        result = await c.authenticate_api_token(ENV_ID)
        assert result == {"jwt": "tok123"}

    async def test_get_user(self):
        c = self._client()
        c.api_client.get = AsyncMock(return_value=_ok_response({"id": "u1"}))
        result = await c.get_user()
        assert result["id"] == "u1"

    async def test_get_user_with_request_id(self):
        c = self._client()
        c.api_client.get = AsyncMock(return_value=_ok_response({"id": "u1"}))
        result = await c.get_user(request_id="req-123")
        assert result["id"] == "u1"

    async def test_refresh_user(self):
        c = self._client()
        c.api_client.post = AsyncMock(return_value=_ok_response({"jwt": "new"}))
        result = await c.refresh_user()
        assert result["jwt"] == "new"

    async def test_get_environment_settings(self):
        c = self._client()
        c.api_client.get = AsyncMock(return_value=_ok_response({"chains": ["EVM"]}))
        result = await c.get_environment_settings()
        assert "chains" in result

    async def test_get_waas_wallet_by_id(self):
        c = self._client()
        c.api_client.get = AsyncMock(return_value=_ok_response({"walletId": "w1"}))
        result = await c.get_waas_wallet_by_id("w1")
        assert result["walletId"] == "w1"

    async def test_get_waas_wallet_by_address(self):
        c = self._client()
        c.api_client.get = AsyncMock(return_value=_ok_response({"address": "0xabc"}))
        result = await c.get_waas_wallet_by_address("0xabc")
        assert result["address"] == "0xabc"

    async def test_get_backup_relay_token(self):
        c = self._client()
        c.api_client.get = AsyncMock(return_value=_ok_response({"token": "relay-tok"}))
        result = await c.get_backup_relay_token()
        assert result == "relay-tok"

    async def test_store_encrypted_backup(self):
        c = self._client()
        c.relay_client.post = AsyncMock(return_value=_ok_response({"keyShareIds": ["s1"]}))
        result = await c.store_encrypted_backup(
            wallet_id="w1",
            encrypted_key_shares=["enc1"],
            password_encrypted=True,
            encryption_version="v2",
        )
        assert result["keyShareIds"] == ["s1"]

    async def test_store_encrypted_backup_no_version(self):
        c = self._client()
        c.relay_client.post = AsyncMock(return_value=_ok_response({"keyShareIds": ["s1"]}))
        await c.store_encrypted_backup(
            wallet_id="w1",
            encrypted_key_shares=["enc1"],
            password_encrypted=True,
        )

    async def test_recover_encrypted_backup_with_ids(self):
        c = self._client()
        c.relay_client.post = AsyncMock(return_value=_ok_response({"keyShares": []}))
        result = await c.recover_encrypted_backup(wallet_id="w1", key_share_ids=["s1"])
        assert "keyShares" in result

    async def test_recover_encrypted_backup_no_ids(self):
        c = self._client()
        c.relay_client.post = AsyncMock(return_value=_ok_response({"keyShares": []}))
        result = await c.recover_encrypted_backup(wallet_id="w1", mfa_token="mfa")
        assert "keyShares" in result

    async def test_mark_key_shares_as_backed_up(self):
        c = self._client()
        c.api_client.post = AsyncMock(return_value=_ok_response({"ok": True}))
        result = await c.mark_key_shares_as_backed_up(wallet_id="w1", locations=[{"loc": "dynamic"}])
        assert result["ok"] is True

    async def test_get_delegated_encryption_key(self):
        c = self._client()
        c.api_client.get = AsyncMock(return_value=_ok_response({"publicKey": "pk123"}))
        result = await c.get_delegated_encryption_key()
        assert result["publicKey"] == "pk123"

    async def test_publish_delegated_key_share(self):
        c = self._client()
        c.api_client.post = AsyncMock(return_value=_ok_response({"ok": True}))
        result = await c.publish_delegated_key_share(
            wallet_id="w1",
            encrypted_key_share={"cipher": "abc"},
        )
        assert result["ok"] is True

    async def test_http_error_propagated_as_sdk_error(self):
        c = self._client()
        c.api_client.get = AsyncMock(return_value=_error_response(403, b"Forbidden"))
        with pytest.raises(DynamicSDKError, match="403"):
            await c.get_user()


# ---------------------------------------------------------------------------
# DynamicApiClient — SSE-based methods (stream_sse_request mocked)
# ---------------------------------------------------------------------------

_SSE_MODULE = "dynamic_wallet_sdk.api.dynamic_api"


class TestDynamicApiClientSse:
    def _client(self) -> DynamicApiClient:
        return DynamicApiClient(environment_id=ENV_ID, auth_token="tok")

    async def test_create_wallet_account(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={"roomId": "r1"})):
            result = await c.create_wallet_account(
                chain_name="EVM",
                client_keygen_ids=["k1"],
                threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
            )
        assert result["roomId"] == "r1"

    async def test_create_wallet_account_with_options(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={})):
            await c.create_wallet_account(
                chain_name="EVM",
                client_keygen_ids=["k1"],
                threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
                skip_lock=True,
                address_type="taproot",
            )

    async def test_create_wallet_keygen(self):
        c = self._client()
        cb = AsyncMock(return_value="mpc")
        with patch(f"{_SSE_MODULE}.stream_sse_keygen", new=AsyncMock(return_value=("mpc", {"walletId": "w1"}))):
            result = await c.create_wallet_keygen(
                chain_name="EVM",
                client_keygen_ids=["k1"],
                threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
                mpc_callback=cb,
                skip_lock=True,
                address_type="taproot",
            )
        assert result == ("mpc", {"walletId": "w1"})

    async def test_import_private_key_keygen(self):
        c = self._client()
        cb = AsyncMock(return_value="import")
        with patch(f"{_SSE_MODULE}.stream_sse_keygen", new=AsyncMock(return_value=("import", None))):
            result = await c.import_private_key_keygen(
                chain_name="EVM",
                client_keygen_ids=["k1"],
                threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
                mpc_callback=cb,
                address_type="native_segwit",
                legacy_wallet_id="old-w",
            )
        assert result == ("import", None)

    async def test_sign_message(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={"roomId": "r1"})):
            result = await c.sign_message(wallet_id="w1", message="hello")
        assert result["roomId"] == "r1"

    async def test_sign_message_all_options(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={})):
            await c.sign_message(
                wallet_id="w1",
                message="hello",
                is_formatted=True,
                context={"chain": "EVM"},
                room_id="r1",
                mfa_token="mfa",
            )

    async def test_sign_message_with_callback(self):
        c = self._client()
        cb = AsyncMock(return_value="sig")
        with patch(f"{_SSE_MODULE}.stream_sse_with_callback", new=AsyncMock(return_value=("sig", None))):
            result = await c.sign_message_with_callback(
                wallet_id="w1",
                message="hello",
                mpc_callback=cb,
                context={"chain": "EVM"},
                room_id="r1",
                mfa_token="mfa",
            )
        assert result == ("sig", None)

    async def test_refresh_wallet_account_shares(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={"roomId": "r1"})):
            result = await c.refresh_wallet_account_shares(wallet_id="w1", mfa_token="mfa")
        assert result["roomId"] == "r1"

    async def test_reshare(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={"roomId": "r1"})):
            result = await c.reshare(
                wallet_id="w1",
                client_keygen_ids=["k1"],
                old_threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
                new_threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_THREE,
                delegate_to_project_environment=True,
                revoke_delegation=False,
            )
        assert result["roomId"] == "r1"

    async def test_reshare_minimal(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={})):
            await c.reshare(
                wallet_id="w1",
                client_keygen_ids=["k1"],
                old_threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
                new_threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
            )

    async def test_export_key(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={"roomId": "r1"})):
            result = await c.export_key(
                wallet_id="w1",
                export_id="exp1",
                address_type="taproot",
                mfa_token="mfa",
                elevated_access_token="eat",
            )
        assert result["roomId"] == "r1"

    async def test_import_private_key(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={"roomId": "r1"})):
            result = await c.import_private_key(
                chain_name="EVM",
                client_keygen_ids=["k1"],
                threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
                address_type="native_segwit",
                legacy_wallet_id="old-w",
            )
        assert result["roomId"] == "r1"

    async def test_delegated_sign_message(self):
        c = self._client()
        with patch(f"{_SSE_MODULE}.stream_sse_request", new=AsyncMock(return_value={"roomId": "r1"})):
            result = await c.delegated_sign_message(
                wallet_id="w1",
                message="hello",
                is_formatted=True,
                context={"chain": "EVM"},
            )
        assert result["roomId"] == "r1"
