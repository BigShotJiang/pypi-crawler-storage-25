"""Tests for DynamicEvmWalletClient."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dynamic_wallet_sdk.evm.client import DynamicEvmWalletClient
from dynamic_wallet_sdk.exceptions import DynamicSDKError, WalletNotFoundError
from dynamic_wallet_sdk.mpc.types import ServerKeyShare
from dynamic_wallet_sdk.mpc_config import ThresholdSignatureScheme
from dynamic_wallet_sdk.wallet_client import DynamicWalletClient

_ENV = "env_evm_test"
_TSS = ThresholdSignatureScheme.TWO_OF_TWO
_ADDR = "0xabcdef1234567890abcdef1234567890abcdef12"
_WALLET_ID = "wallet-evm-1"
_SECRET = "secret-share-data"


def _client() -> DynamicEvmWalletClient:
    return DynamicEvmWalletClient(_ENV)


def _authenticated_client() -> DynamicEvmWalletClient:
    c = DynamicEvmWalletClient(_ENV)
    c._is_authenticated = True
    return c


def _client_with_wallet(
    address: str = _ADDR,
    secret: str = _SECRET,
) -> DynamicEvmWalletClient:
    c = _authenticated_client()
    ks = ServerKeyShare(key_share_id="ks-1", secret_share=secret)
    c._init_wallet_entry(
        account_address=address,
        wallet_id=_WALLET_ID,
        chain_name="EVM",
        external_server_key_shares=[ks],
        threshold_signature_scheme=_TSS,
        derivation_path=[44, 60, 0, 0, 0],
    )
    return c


# ---------------------------------------------------------------------------
# create_wallet_account
# ---------------------------------------------------------------------------


class TestCreateWalletAccount:
    async def test_creates_and_returns_address(self):
        c = _authenticated_client()
        uncompressed_pk = b"\x04" + b"\xab" * 64
        mock_kr = MagicMock(secret_share=_SECRET)
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": (uncompressed_pk, b""),
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        address = await c.create_wallet_account()

        assert address.startswith("0x")
        assert len(address) == 42
        c.backup_key_shares.assert_awaited_once()

    async def test_creates_with_raw_bytes_pubkey(self):
        c = _authenticated_client()
        uncompressed_pk = b"\x04" + b"\xab" * 64
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": uncompressed_pk,
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        address = await c.create_wallet_account()
        assert address.startswith("0x")

    async def test_creates_with_hex_str_pubkey(self):
        c = _authenticated_client()
        uncompressed_pk = "04" + "ab" * 64
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": uncompressed_pk,
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        address = await c.create_wallet_account()
        assert address.startswith("0x")

    async def test_uses_password_for_backup(self):
        c = _authenticated_client()
        uncompressed_pk = b"\x04" + b"\xab" * 64
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": uncompressed_pk,
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        await c.create_wallet_account(password="my-password")
        call_args = c.backup_key_shares.call_args
        assert call_args[0][1] == "my-password"

    async def test_falls_back_to_env_id_for_backup(self):
        c = _authenticated_client()
        uncompressed_pk = b"\x04" + b"\xab" * 64
        mock_ks = ServerKeyShare(key_share_id="kid-1", secret_share=_SECRET)

        c.keygen = AsyncMock(return_value={
            "raw_public_key": uncompressed_pk,
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        })
        c.backup_key_shares = AsyncMock()

        await c.create_wallet_account()
        call_args = c.backup_key_shares.call_args
        assert call_args[0][1] == _ENV


# ---------------------------------------------------------------------------
# sign_message
# ---------------------------------------------------------------------------


class TestSignMessage:
    async def test_sign_with_stored_shares(self):
        c = _client_with_wallet()
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
            result = await c.sign_message("Hello World", _ADDR)

        assert result.startswith("0x")
        assert len(result) == 132  # 0x + 64r + 64s + 2v

    async def test_sign_recovers_shares_with_password(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        mock_share = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        c.recover_key_shares = AsyncMock(return_value=[mock_share])
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=28)

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
            result = await c.sign_message("Hello", _ADDR, password="pass")

        c.recover_key_shares.assert_awaited_once()
        assert result.startswith("0x")

    async def test_sign_raises_without_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )

        with pytest.raises(DynamicSDKError, match="No key shares"):
            await c.sign_message("Hello", _ADDR)

    async def test_sign_with_explicit_key_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        shares = [ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)]
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
            result = await c.sign_message("Hello", _ADDR, key_shares=shares)
        assert result.startswith("0x")

    async def test_sign_with_mfa_token(self):
        c = _client_with_wallet()
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)
        mock_sign = AsyncMock(return_value=mock_sig)

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=mock_sign):
            await c.sign_message("Hello", _ADDR, mfa_token="mfa-123")
        assert mock_sign.call_args.kwargs["mfa_token"] == "mfa-123"


# ---------------------------------------------------------------------------
# sign_typed_data
# ---------------------------------------------------------------------------


class TestSignTypedData:
    async def test_sign_typed_data_success(self):
        c = _client_with_wallet()
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)

        with patch("dynamic_wallet_sdk.evm.client.hash_typed_data", return_value="a" * 64):
            with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
                result = await c.sign_typed_data(_ADDR, {})

        assert result.startswith("0x")
        assert len(result) == 132

    async def test_sign_typed_data_recovers_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        mock_share = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        c.recover_key_shares = AsyncMock(return_value=[mock_share])
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=28)

        with patch("dynamic_wallet_sdk.evm.client.hash_typed_data", return_value="a" * 64):
            with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
                result = await c.sign_typed_data(_ADDR, {}, password="pass")

        assert result.startswith("0x")

    async def test_sign_typed_data_raises_without_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )

        with pytest.raises(DynamicSDKError, match="No key shares"):
            await c.sign_typed_data(_ADDR, {})


# ---------------------------------------------------------------------------
# sign_transaction
# ---------------------------------------------------------------------------


class TestSignTransaction:
    def _make_tx(self) -> dict:
        return {
            "to": "0xAbCdEf1234567890AbCdEf1234567890AbCdEf12",
            "value": 1000,
            "gas": 21000,
            "gasPrice": 20_000_000_000,
            "nonce": 5,
            "chainId": 1,
            "data": "0x",
        }

    async def test_sign_transaction_success(self):
        c = _client_with_wallet()
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
            result = await c.sign_transaction(_ADDR, self._make_tx())
        assert result.startswith("0x")

    async def test_sign_transaction_with_bytes_data(self):
        c = _client_with_wallet()
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)

        tx = self._make_tx()
        tx["data"] = b"\xde\xad\xbe\xef"
        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
            result = await c.sign_transaction(_ADDR, tx)
        assert result.startswith("0x")

    async def test_sign_transaction_invalid_hex_data_raises(self):
        c = _client_with_wallet()

        tx = self._make_tx()
        tx["data"] = "0xGGGG"  # invalid hex

        with pytest.raises(DynamicSDKError, match="Invalid hex"):
            await c.sign_transaction(_ADDR, tx)

    async def test_sign_transaction_recovers_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        mock_share = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        c.recover_key_shares = AsyncMock(return_value=[mock_share])
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)

        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
            result = await c.sign_transaction(_ADDR, self._make_tx(), password="pass")
        assert result.startswith("0x")

    async def test_sign_transaction_raises_without_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )

        with pytest.raises(DynamicSDKError, match="No key shares"):
            await c.sign_transaction(_ADDR, self._make_tx())

    async def test_sign_transaction_uses_max_fee_per_gas(self):
        c = _client_with_wallet()
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)

        tx = self._make_tx()
        del tx["gasPrice"]
        tx["maxFeePerGas"] = 30_000_000_000
        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
            result = await c.sign_transaction(_ADDR, tx)
        assert result.startswith("0x")

    async def test_sign_transaction_with_none_data(self):
        c = _client_with_wallet()
        mock_sig = MagicMock(r=b"\xaa" * 32, s=b"\xbb" * 32, v=27)

        tx = self._make_tx()
        tx["data"] = None
        with patch.object(DynamicWalletClient, "_sign_mpc_message", new=AsyncMock(return_value=mock_sig)):
            result = await c.sign_transaction(_ADDR, tx)
        assert result.startswith("0x")


# ---------------------------------------------------------------------------
# export_private_key
# ---------------------------------------------------------------------------


class TestExportPrivateKey:
    async def test_export_success(self):
        c = _client_with_wallet()

        with patch.object(DynamicWalletClient, "_export_private_key_mpc", new=AsyncMock(return_value="xpriv-data")):
            result = await c.export_private_key(_ADDR)
        assert result == "xpriv-data"

    async def test_export_recovers_shares_with_password(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )
        mock_share = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        c.recover_key_shares = AsyncMock(return_value=[mock_share])

        with patch.object(DynamicWalletClient, "_export_private_key_mpc", new=AsyncMock(return_value="xpriv-data")):
            result = await c.export_private_key(_ADDR, password="pass")
        assert result == "xpriv-data"

    async def test_export_raises_without_shares(self):
        c = _authenticated_client()
        c._init_wallet_entry(
            account_address=_ADDR,
            wallet_id=_WALLET_ID,
            chain_name="EVM",
            external_server_key_shares=[],
            threshold_signature_scheme=_TSS,
        )

        with pytest.raises(DynamicSDKError, match="No key shares"):
            await c.export_private_key(_ADDR)

    async def test_export_passes_mfa_and_elevated_token(self):
        c = _client_with_wallet()
        mock_export = AsyncMock(return_value="xpriv")

        with patch.object(DynamicWalletClient, "_export_private_key_mpc", new=mock_export):
            await c.export_private_key(_ADDR, mfa_token="mfa", elevated_access_token="eat")
        assert mock_export.call_args.kwargs["mfa_token"] == "mfa"
        assert mock_export.call_args.kwargs["elevated_access_token"] == "eat"


# ---------------------------------------------------------------------------
# import_private_key
# ---------------------------------------------------------------------------


class TestImportPrivateKey:
    def _mock_import_result(self, pk_bytes):
        mock_ks = ServerKeyShare(key_share_id="ks-1", secret_share=_SECRET)
        return {
            "raw_public_key": pk_bytes,
            "wallet_id": _WALLET_ID,
            "external_server_key_shares": [mock_ks],
        }

    async def test_import_success(self):
        c = _authenticated_client()
        c.backup_key_shares = AsyncMock()
        uncompressed_pk = b"\x04" + b"\xab" * 64

        with patch.object(DynamicWalletClient, "_import_private_key_mpc", new=AsyncMock(return_value=self._mock_import_result(uncompressed_pk))):
            address = await c.import_private_key("deadbeef" * 8)
        assert address.startswith("0x")
        c.backup_key_shares.assert_awaited_once()

    async def test_import_with_password(self):
        c = _authenticated_client()
        c.backup_key_shares = AsyncMock()
        uncompressed_pk = b"\x04" + b"\xab" * 64

        with patch.object(DynamicWalletClient, "_import_private_key_mpc", new=AsyncMock(return_value=self._mock_import_result(uncompressed_pk))):
            await c.import_private_key("deadbeef" * 8, password="my-pass")
        assert c.backup_key_shares.call_args[0][1] == "my-pass"

    async def test_import_with_hex_str_pubkey(self):
        c = _authenticated_client()
        c.backup_key_shares = AsyncMock()
        hex_pk = "04" + "ab" * 64

        with patch.object(DynamicWalletClient, "_import_private_key_mpc", new=AsyncMock(return_value=self._mock_import_result(hex_pk))):
            address = await c.import_private_key("deadbeef" * 8)
        assert address.startswith("0x")

    async def test_import_with_tuple_pubkey(self):
        c = _authenticated_client()
        c.backup_key_shares = AsyncMock()
        uncompressed_pk = b"\x04" + b"\xab" * 64
        tuple_pk = (uncompressed_pk, b"\x02" + b"\xab" * 32)

        with patch.object(DynamicWalletClient, "_import_private_key_mpc", new=AsyncMock(return_value=self._mock_import_result(tuple_pk))):
            address = await c.import_private_key("deadbeef" * 8)
        assert address.startswith("0x")
