"""End-to-end integration tests against Dynamic preprod.

Run with:
    DYNAMIC_ENV_ID=<env-id> DYNAMIC_API_TOKEN=<token> pytest tests/test_e2e_preprod.py -v -s

These tests perform real MPC operations against the preprod relay.
They are skipped when credentials are not set.
"""

from __future__ import annotations

import os

import pytest

DYNAMIC_ENV_ID = os.environ.get("DYNAMIC_ENV_ID", "")
DYNAMIC_API_TOKEN = os.environ.get("DYNAMIC_API_TOKEN", "")
DYNAMIC_BASE_API_URL = os.environ.get(
    "DYNAMIC_BASE_API_URL", "https://app.dynamic-preprod.xyz"
)

skip_no_creds = pytest.mark.skipif(
    not DYNAMIC_ENV_ID or not DYNAMIC_API_TOKEN,
    reason="DYNAMIC_ENV_ID and DYNAMIC_API_TOKEN env vars required",
)


@skip_no_creds
class TestEvmE2E:
    @pytest.mark.asyncio
    async def test_create_wallet_and_sign(self):
        from dynamic_wallet_sdk.evm.client import DynamicEvmWalletClient

        async with DynamicEvmWalletClient(
            DYNAMIC_ENV_ID,
            base_api_url=DYNAMIC_BASE_API_URL,
        ) as client:
            # 1. Authenticate
            print("\n[EVM] Authenticating...")
            await client.authenticate_api_token(DYNAMIC_API_TOKEN)
            print("[EVM] Authenticated successfully")

            # 2. Create wallet (keygen)
            print("[EVM] Creating wallet (MPC keygen)...")
            address = await client.create_wallet_account()
            print(f"[EVM] Wallet created: {address}")

            assert address.startswith("0x")
            assert len(address) == 42

            # 3. Sign a message (brief pause for server to finalize wallet)
            import asyncio
            await asyncio.sleep(2)
            wp = client.get_wallet_from_map(address)
            print(f"[EVM] Wallet ID: {wp.wallet_id}")
            message = "Hello from Python SDK e2e test"
            print(f"[EVM] Signing message: {message!r}")
            signature = await client.sign_message(
                message=message,
                address=address,
            )
            print(f"[EVM] Signature: {signature[:20]}...{signature[-8:]}")

            assert signature.startswith("0x")
            assert len(signature) == 132  # 0x + 64 (r) + 64 (s) + 2 (v)

            # 4. Verify signature recovers to the correct address
            from eth_account.messages import encode_defunct
            from eth_account import Account

            msg = encode_defunct(text=message)
            recovered = Account.recover_message(msg, signature=signature)
            print(f"[EVM] Recovered address: {recovered}")
            assert recovered.lower() == address.lower()
            print("[EVM] Signature verification PASSED")


@skip_no_creds
class TestSvmE2E:
    @pytest.mark.asyncio
    async def test_create_wallet_and_sign(self):
        from dynamic_wallet_sdk.svm.client import DynamicSvmWalletClient

        async with DynamicSvmWalletClient(
            DYNAMIC_ENV_ID,
            base_api_url=DYNAMIC_BASE_API_URL,
        ) as client:
            # 1. Authenticate
            print("\n[SVM] Authenticating...")
            await client.authenticate_api_token(DYNAMIC_API_TOKEN)
            print("[SVM] Authenticated successfully")

            # 2. Create wallet (keygen)
            print("[SVM] Creating wallet (MPC keygen)...")
            address = await client.create_wallet_account()
            print(f"[SVM] Wallet created: {address}")

            # Solana addresses are base58, typically 32-44 chars
            assert len(address) >= 32
            assert len(address) <= 44

            # 3. Sign a message
            message = "Hello from Python SDK e2e test"
            print(f"[SVM] Signing message: {message!r}")
            signature = await client.sign_message(
                message=message,
                address=address,
            )
            print(f"[SVM] Signature: {signature[:20]}...")

            # Ed25519 signature is 64 bytes, base58-encoded
            import base58
            sig_bytes = base58.b58decode(signature)
            assert len(sig_bytes) == 64, f"Expected 64-byte sig, got {len(sig_bytes)}"

            # 4. Verify signature with the public key
            import nacl.signing

            pubkey_bytes = base58.b58decode(address)
            verify_key = nacl.signing.VerifyKey(pubkey_bytes)
            msg_bytes = message.encode("utf-8")
            try:
                verify_key.verify(msg_bytes, sig_bytes)
                print("[SVM] Signature verification PASSED")
            except nacl.exceptions.BadSignatureError:
                pytest.fail("Ed25519 signature verification failed")


@skip_no_creds
class TestNativeModuleSanity:
    """Quick sanity check that the native module works before full e2e."""

    def test_ecdsa_init_keygen(self):
        from dynamic_wallet_mpc import PyEcdsa

        ecdsa = PyEcdsa("https://relay.dynamic-preprod.xyz")
        init = ecdsa.init_keygen()
        assert isinstance(init.keygen_id, str)
        assert len(init.keygen_id) > 0
        assert len(init.keygen_secret) == 32
        print(f"\n[Native] ECDSA init_keygen OK: id={init.keygen_id[:16]}...")

    def test_ed25519_init_keygen(self):
        from dynamic_wallet_mpc import PyEd25519

        ed = PyEd25519("https://relay.dynamic-preprod.xyz")
        init = ed.init_keygen()
        assert isinstance(init.keygen_id, str)
        assert len(init.keygen_id) > 0
        assert len(init.keygen_secret) == 32
        print(f"\n[Native] Ed25519 init_keygen OK: id={init.keygen_id[:16]}...")

    def test_message_hash(self):
        from dynamic_wallet_mpc import PyMessageHash

        h = PyMessageHash.keccak256(b"hello")
        assert h.to_hex() == "1c8aff950685c2ed4bc3174f3472287b56d9517b9c948127319a09a7a36deac8"
        print(f"\n[Native] MessageHash OK: {h.to_hex()[:16]}...")
