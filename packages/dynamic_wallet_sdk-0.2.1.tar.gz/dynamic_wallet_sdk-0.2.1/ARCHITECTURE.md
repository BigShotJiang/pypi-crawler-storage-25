# Dynamic Python SDK — Architecture Reference

This document is the primary reference for developers (and AI assistants) working on this SDK. It explains **why** the code is structured the way it is, how the MPC ceremony protocol works end-to-end, and where to find the right file for any given concern.

> **Want to build a demo app?** See [DEMO_GUIDE.md](DEMO_GUIDE.md) for step-by-step instructions with complete code examples.

---

## Table of Contents

1. [What This SDK Does](#1-what-this-sdk-does)
2. [Layer Architecture](#2-layer-architecture)
3. [MPC Protocol Primer](#3-mpc-protocol-primer)
4. [Ceremony Flows](#4-ceremony-flows)
   - [Keygen (wallet creation)](#keygen-wallet-creation)
   - [Sign (message/transaction signing)](#sign-messagetransaction-signing)
   - [Backup and Recovery](#backup-and-recovery)
5. [Chain-Specific Differences](#5-chain-specific-differences)
6. [SSE Stream Protocol](#6-sse-stream-protocol)
7. [Rust Native Extension](#7-rust-native-extension)
8. [Key Data Structures](#8-key-data-structures)
9. [Error Handling](#9-error-handling)
10. [File Map — Where to Find Things](#10-file-map--where-to-find-things)
11. [Adding a New Chain](#11-adding-a-new-chain)
12. [Common Pitfalls](#12-common-pitfalls)

---

## 1. What This SDK Does

This SDK lets a Python server create and control MPC (Multi-Party Computation) wallets on behalf of users. The key property of MPC wallets is that **the private key never exists in full on any single machine** — it is split into shares held by different parties, and signing requires a threshold of those parties to cooperate.

Concretely, with the default 2-of-2 scheme:

- **Party 1**: Dynamic MPC relay (Dynamic's MPC infrastructure, two separate nodes)
- **Party 2**: This Python SDK (the customer's server)

Both parties must participate in every keygen and sign operation. If the SDK's key share is lost, it can be recovered from an encrypted backup stored on Dynamic's servers (password-protected with AES-256-GCM + PBKDF2).

---

## 2. Layer Architecture

```
┌──────────────────────────────────────────────────────────┐
│                  Public API (user code)                  │
│   DynamicEvmWalletClient  /  DynamicSvmWalletClient      │
│   evm/client.py           /  svm/client.py               │
│   Chain-specific signing: EIP-191, EIP-712, Ed25519      │
└────────────────────────┬─────────────────────────────────┘
                         │  extends
┌────────────────────────▼─────────────────────────────────┐
│              Core Orchestration                          │
│   wallet_client.py — DynamicWalletClient                 │
│   Owns: auth, keygen, sign, refresh, export, backup      │
│   Coordinates: API client ↔ MPC signer ↔ crypto layer   │
└──────────┬────────────────────────┬──────────────────────┘
           │                        │
  ┌────────▼──────────┐   ┌────────▼──────────┐   ┌──────────────────┐
  │   API Layer       │   │   MPC Signer      │   │  Crypto Layer    │
  │   api/            │   │   mpc/signer.py   │   │  crypto/         │
  │   ├─ client.py    │   │   Factory that    │   │  encryption.py   │
  │   ├─ dynamic_api  │   │   returns PyEcdsa │   │  AES-256-GCM     │
  │   │   .py         │   │   or              │   │  PBKDF2 key      │
  │   └─ sse.py       │   │   PyExportable    │   │  derivation      │
  │   REST + SSE      │   │   Ed25519         │   │  v1/v2 versions  │
  └────────┬──────────┘   └────────┬──────────┘   └──────────────────┘
           │                       │
           │              ┌────────▼──────────────────────────┐
           │              │  Rust Native Extension             │
           │              │  dynamic_wallet_mpc (.so/.pyd)     │
           │              │  src/ecdsa.rs                      │
           │              │  src/exportable_ed25519.rs         │
           │              │  src/ed25519.rs  (not used for SVM)│
           │              │  src/types.rs                      │
           │              └────────┬──────────────────────────┘
           │                       │  network calls (HTTPS)
           ▼                       ▼
    Dynamic API            Dynamic MPC Relay
    (REST + SSE)           (two separate nodes per ceremony)
```

**Key rule:** Chain-specific clients (`evm/client.py`, `svm/client.py`) handle chain-level encoding and then delegate to `wallet_client.py` for everything that touches the network or MPC relay. They never call the API directly.

---

## 3. MPC Protocol Primer

### What is a "ceremony"?

Every keygen and sign operation is a **ceremony** — a multi-round cryptographic protocol where multiple parties exchange messages through a shared **room** on the Dynamic MPC relay. The room is identified by a UUID (`roomId`). All parties must join the same room and complete their rounds in order for the ceremony to succeed.

### Threshold Signature Schemes (TSS)

| Scheme               | Parties | Threshold | Client Shares | Server Shares |
| -------------------- | ------- | --------- | ------------- | ------------- |
| TWO_OF_TWO (default) | 2       | 2         | 1             | 1             |
| TWO_OF_THREE         | 3       | 2         | 2             | 1             |
| THREE_OF_FIVE        | 5       | 3         | 3             | 2             |

With TWO_OF_TWO: the client holds one key share, Dynamic holds one. Both must sign.

### Key Share Lifecycle

```
keygen() → ServerKeyShare(key_share_id, secret_share)
             │
             ├─ secret_share: opaque base58 string (ECDSA) or base58 (ExportableEd25519)
             │  Stored in memory in WalletProperties.external_server_key_shares
             │
             └─ Backup: encrypt_data(secret_share, password) → store via Evervault relay
                         │
                         └─ Recovery: fetch encrypted blob → decrypt_data(blob, password)
                                       → restore into WalletProperties.external_server_key_shares
```

The `secret_share` is the SDK's half of the key. It must be present to sign. If lost, recover it with the backup password.

---

## 4. Ceremony Flows

### Keygen (wallet creation)

This is the most complex flow. Study this before modifying keygen-related code.

```
Client                    Dynamic API               Dynamic MPC Relay
  │                           │                         │
  │  1. init_keygen()         │                         │
  │  (sync, local only)       │                         │
  │  → keygen_id, secret      │                         │
  │                           │                         │
  │  2. POST /waas/create     │                         │
  │  {chain, clientKeygenIds, │                         │
  │   thresholdSignatureScheme}                         │
  │  ─────────────────────────►                         │
  │                           │                         │
  │  SSE stream opens ─────────────────────────────────►│
  │                           │  Server runs its own    │
  │                           │  keygen internally      │
  │                           │                         │
  │  3. event: keygen_complete│                         │
  │  {roomId, serverKeygenIds}│                         │
  │  ◄─────────────────────────                         │
  │                           │                         │
  │  4. join room + run MPC ──────────────────────────► │
  │  keygen(roomId, n, t,     │                         │
  │  keygen_secret,           │                         │
  │  serverKeygenIds)         │                         │
  │                           │                         │
  │  5. ceremony_complete ◄──────────────────────────── │
  │  {walletId}               │                         │
  │                           │                         │
  │  6. derive_pubkey()       │                         │
  │  (sync, local only)       │                         │
  │  → address                │                         │
  │                           │                         │
  │  7. backup_key_shares()   │                         │
  │  (always called after     │                         │
  │  keygen to activate       │                         │
  │  server shares)           │                         │
```

**Critical detail**: The Dynamic server marks key shares as "pending" until `POST /keyShares/backup/locations` is called. Signing will fail with 400 if backup is not called. This is why `backup_key_shares()` is called unconditionally after keygen in both `evm/client.py` and `svm/client.py` — even if you don't want password-based backup, it still calls with `self.environment_id` as the "password" to activate the shares.

**Code path**:

```
DynamicEvmWalletClient.create_wallet_account()     # evm/client.py
  └─ DynamicWalletClient.keygen()                  # wallet_client.py
       ├─ _external_server_init_keygen()            # sync: creates keygen_id + secret
       ├─ api_client.create_wallet_keygen()         # opens SSE stream
       │    └─ stream_sse_keygen()                  # sse.py: waits for keygen_complete,
       │         └─ _mpc_keygen() callback          # runs MPC while stream is held open
       │              └─ _external_server_keygen()  # calls signer.keygen() or receive_key()
       ├─ signer.derive_pubkey()                    # sync: derive address from secret_share
       └─ returns {raw_public_key, external_server_key_shares, wallet_id}
  └─ _init_wallet_entry()                          # stores in wallet map
  └─ backup_key_shares()                           # activates shares on server
```

### Sign (message/transaction signing)

```
Client                    Dynamic API               Dynamic MPC Relay
  │                           │                         │
  │  1. POST /waas/{id}/      │                         │
  │     signMessage           │                         │
  │  {message, isFormatted,   │                         │
  │   context?}               │                         │
  │  ─────────────────────────►                         │
  │                           │                         │
  │  SSE stream opens                                   │
  │                           │                         │
  │  2. event: room_created   │                         │
  │  {roomId, serverKeygenIds}│                         │
  │  ◄─────────────────────────                         │
  │                           │                         │
  │  3. join room + sign ─────────────────────────────► │
  │  sign(roomId, secret_share,                         │
  │  msg_hash, derivation_path)                         │
  │                           │                         │
  │  4. ceremony_complete ◄──────────────────────────── │
  │  (or stream closes)       │                         │
  │                           │                         │
  │  returns signature        │                         │
```

**`isFormatted` flag** — this controls whether the Dynamic server applies additional formatting to the message before passing it to the MPC relay:

- `isFormatted: true` → server passes message as-is to the relay (message is already a hash)
- `isFormatted: false` → server applies chain-specific formatting (EIP-191 prefix, etc.)

**Message encoding per chain**:

- **EVM message signing**: client passes keccak256 hash with `is_formatted=True`; server gets EIP-191 prefixed hex with `server_is_formatted=False`
- **EVM transaction signing**: client signs keccak256(RLP-encoded tx) with `is_formatted=True`; server gets raw RLP hex with `server_is_formatted=False`
- **EVM typed data (EIP-712)**: client passes EIP-712 hash with `is_formatted=True`; no separate server message
- **SVM**: client passes UTF-8 hex of message with `is_formatted=False` for both

**Retry logic**: Signing retries up to 3× with 1s backoff on `SSEError("Stream ended during MPC")` — this is a transient server-side stream closure that happens occasionally under load.

**Code path**:

```
DynamicEvmWalletClient.sign_message()              # evm/client.py: formats message
  └─ DynamicWalletClient.sign_message()            # wallet_client.py: orchestrates
       ├─ api_client.sign_message_with_callback()  # opens SSE stream
       │    └─ stream_sse_with_callback()          # sse.py: waits for room_created,
       │         └─ _mpc_sign() callback           # runs sign while stream held open
       │              └─ _external_server_sign()   # calls signer.sign()
       └─ returns raw signature (EcdsaSignature or bytes)
  └─ serialize_ecdsa_signature()                   # evm/utils.py: r,s,v → 0x hex
```

### Backup and Recovery

**Backup** (`backup_key_shares`):

1. For each key share in memory: `encrypt_data(secret_share, password)` → AES-256-GCM
2. POST encrypted blobs to `relay_client` (Evervault-proxied endpoint)
3. Server returns `keyShareIds` (server-assigned UUIDs for the stored blobs)
4. POST to `/keyShares/backup/locations` to mark shares as "active" (required for signing)
5. Store `keyShareIds` in `WalletProperties.external_server_key_shares_backup_info` for use during recovery

**Recovery** (`recover_key_shares`):

1. Look up stored `keyShareIds` from `external_server_key_shares_backup_info`
2. POST `{keyShareIds}` to relay endpoint
3. Server returns encrypted blobs
4. `decrypt_data(blob, password)` → restore `secret_share` strings
5. Repopulate `wp.external_server_key_shares`

**Encryption details** (`crypto/encryption.py`):

- v1: PBKDF2-SHA256, 100K iterations (legacy, still decryptable)
- v2: PBKDF2-SHA256, 1M iterations (current, ~1-2 seconds intentionally)
- Random 16-byte salt + 12-byte IV per encryption
- All values base64-encoded in the stored JSON blob

---

## 5. Chain-Specific Differences

### ECDSA vs ExportableEd25519

There are two completely different MPC protocols used:

|                      | ECDSA                                                 | ExportableEd25519                             |
| -------------------- | ----------------------------------------------------- | --------------------------------------------- |
| **Chains**           | EVM                                                   | SVM (Solana), COSMOS, SUI, TON, STELLAR, FLOW |
| **Rust class**       | `PyEcdsa`                                             | `PyExportableEd25519`                         |
| **Keygen method**    | `keygen()`                                            | `receive_key()` (server calls `sampleKey`)    |
| **Derivation**       | BIP-32 path supported                                 | No derivation path (ignored)                  |
| **Pubkey output**    | 65-byte uncompressed (with 0x04 prefix)               | 32-byte raw Ed25519 pubkey                    |
| **Signature output** | `PyEcdsaSignature` (r, s, v)                          | 64-byte raw bytes                             |
| **Address format**   | Keccak256 hash of pubkey → 20 bytes → EIP-55 checksum | Base58 of raw pubkey                          |

**Why ExportableEd25519 instead of the regular Ed25519 class?**

The Dynamic server uses a different protocol for Solana (`sampleKey`/`receiveKey`) to enable key export functionality. The MPC native library does not expose this as a high-level Rust type, so `exportable_ed25519.rs` calls the C FFI layer directly. The regular `PyEd25519` class in `ed25519.rs` exists for completeness but is **not used for any active chain** in this SDK.

### EVM Message Formatting

Three distinct signing types, each with different hash inputs:

```python
# 1. EIP-191 message signing
prefixed = f"\x19Ethereum Signed Message:\n{len(msg)}{msg}"
hash = keccak256(prefixed)

# 2. EIP-712 typed data
hash = keccak256("\x19\x01" + domain_separator + struct_hash)

# 3. Transaction signing
hash = keccak256(rlp_encode(unsigned_tx))
```

See `evm/utils.py` for implementations.

---

## 6. SSE Stream Protocol

The Dynamic API uses Server-Sent Events (SSE) to coordinate MPC ceremonies. The stream carries named events with JSON data payloads.

### Event types

| Event               | Direction     | Payload                     | Meaning                                              |
| ------------------- | ------------- | --------------------------- | ---------------------------------------------------- |
| `keygen_complete`   | server→client | `{roomId, serverKeygenIds}` | MPC room is ready; client should join and run keygen |
| `room_created`      | server→client | `{roomId}`                  | Sign/refresh room ready; client should join          |
| `ceremony_complete` | server→client | `{walletId?}`               | MPC finished successfully                            |
| `error`             | server→client | `{error: string}`           | Server-side failure; raises `SSEError`               |

### Stream-and-callback pattern

The SDK keeps the SSE stream **open** during the MPC ceremony. This is critical — the stream must stay open until `ceremony_complete` is received. Three functions in `sse.py` implement different patterns:

- `stream_sse_request()` — fire-and-wait: just waits for one event, stream closes after
- `stream_sse_keygen()` — used for keygen: stream stays open, triggers MPC callback on `keygen_complete`, waits for `ceremony_complete`
- `stream_sse_with_callback()` — used for signing: same as keygen but for sign rooms

### Parsing

`parse_sse_events(text)` in `sse.py` parses raw SSE wire format into `SSEEvent` dataclasses. Events are delimited by blank lines (`\n\n`). Incomplete events (no trailing blank line) are buffered.

---

## 7. Rust Native Extension

The `dynamic_wallet_mpc` module is built from `python/src/` using [maturin](https://github.com/PyO3/maturin) (PyO3 + Rust). It provides low-level MPC operations.

### Build

```bash
cd python
maturin develop          # dev build, installs in current venv
maturin build --release  # release wheel
```

Requires the MPC registry token set in `~/.cargo/credentials.toml` to access the private crate registry. See the Registry authentication failure section of README.md.

### Module structure

```
src/
├── lib.rs              # #[pymodule] entry; initializes tokio runtime
├── types.rs            # Python-visible data types (PyInitKeygenResult, etc.)
├── error.rs            # MPCError exception type
├── unsafesend.rs       # SendFuture: wraps !Send FFI futures for tokio
├── ecdsa.rs            # PyEcdsa: ECDSA MPC operations
├── ed25519.rs          # PyEd25519: standard Ed25519 MPC operations (not used for SVM)
└── exportable_ed25519.rs  # PyExportableEd25519: calls C FFI directly
```

### Async pattern

Each async method follows this pattern:

```rust
pub fn method_name<'py>(&self, py: Python<'py>, ...) -> PyResult<Bound<'py, PyAny>> {
    let inner = self.inner.clone();  // clone to move into async block
    pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
        let result = inner.operation(...).await.map_err(to_py_err)?;
        Ok(convert_to_python_type(result))
    }))
}
```

`SendFuture` is needed because the MPC library's FFI futures contain raw pointer types that are `!Send`. The safety invariant is that all raw pointer references live entirely within the synchronous FFI call inside the async block.

### ExportableEd25519 C FFI

`exportable_ed25519.rs` is the most complex file. Key things to know:

1. **Why direct C FFI?** The MPC native library exposes `Ed25519` but not `ExportableEd25519` as a high-level Rust type. We call the lower-level C symbols directly from the static library.

2. **Callback pattern**: The C SDK is callback-based. Each async operation takes a function pointer + `*mut c_void` context. We create a `tokio::sync::oneshot::channel`, box the sender as the context pointer, and resolve the future in the callback.

3. **`ffi_double_call!` / `ffi_single_call!` macros**: DRY wrappers for the channel setup + FFI call + error handling pattern. `double_call` is for operations returning (pubkey, secret_share); `single_call` for single string outputs.

4. **String encoding**: The C SDK encodes keygen secrets as 64-char hex (not raw bytes); pubkeys and signatures as hex strings. These are decoded back to `Vec<u8>` before returning to Python.

---

## 8. Key Data Structures

### WalletProperties (`mpc/types.py`)

The in-memory representation of a wallet. Stored in `DynamicWalletClient._wallet_map` keyed by normalized address.

```python
WalletProperties(
    chain_name="EVM",
    wallet_id="uuid-from-dynamic",     # server-assigned, needed for API calls
    account_address="0xAbCd...",        # checksummed for EVM, base58 for SVM
    external_server_key_shares=[        # the client's MPC key shares
        ServerKeyShare(
            key_share_id="...",         # client's keygen_id (used as lookup key)
            secret_share="base58...",   # the actual secret material — treat like a private key
        )
    ],
    threshold_signature_scheme=ThresholdSignatureScheme.TWO_OF_TWO,
    derivation_path=[44, 60, 0, 0, 0], # BIP-44 path (EVM) or None (SVM)
    external_server_key_shares_backup_info=KeyShareBackupInfo(
        password_encrypted=True,
        backups={
            "dynamic": [BackupLocationInfo(location=..., key_share_id="server-uuid")]
        }
    )
)
```

**Address normalization**: EVM addresses are stored lowercase in the map for case-insensitive lookups. Use `get_wallet_from_map(address)` and `update_wallet_in_map(address, ...)` — never access `_wallet_map` directly from subclasses.

### ChainConfig (`mpc_config.py`)

```python
ChainConfig(
    signing_algorithm=SigningAlgorithm.ECDSA,   # determines which Rust class to use
    derivation_path=[44, 60, 0, 0, 0],          # BIP-44 derivation path
)
```

`MPC_CHAIN_CONFIG` is the authoritative map from chain name strings ("EVM", "SVM", ...) to `ChainConfig`. `mpc/signer.py` uses the `signing_algorithm` to decide which Rust class to instantiate.

---

## 9. Error Handling

All SDK errors inherit from `DynamicSDKError` (`exceptions.py`):

| Exception             | When raised                                           |
| --------------------- | ----------------------------------------------------- |
| `AuthenticationError` | JWT exchange fails; unauthenticated API call          |
| `WalletNotFoundError` | Address not in wallet map                             |
| `DynamicSDKError`     | No key shares; unsupported chain; empty recovery      |
| `SSEError`            | Server sends `event: error`; stream ends unexpectedly |
| `SSETimeoutError`     | No expected event within 30s                          |
| `EncryptionError`     | AES-GCM decrypt fails (wrong password)                |
| `MPCError`            | MPC operation fails in Rust layer                     |

HTTP errors from `httpx` are wrapped in `DynamicSDKError` with the status code, URL, and response body (first 500 chars) via `_raise_for_status()` in `api/client.py`.

---

## 10. File Map — Where to Find Things

| If you need to...                        | Look in                                                                    |
| ---------------------------------------- | -------------------------------------------------------------------------- |
| Add a new chain                          | `mpc_config.py` (add ChainConfig) + new `chain/client.py`                  |
| Change signing message format for EVM    | `evm/utils.py`                                                             |
| Change the SSE event handling / timeouts | `api/sse.py`                                                               |
| Add a new API endpoint                   | `api/dynamic_api.py`                                                       |
| Change backup encryption                 | `crypto/encryption.py`                                                     |
| Change error types                       | `exceptions.py`                                                            |
| Change MPC relay URLs                    | `constants.py`                                                             |
| Fix keygen ceremony                      | `wallet_client.py` → `keygen()` + `_external_server_keygen()`              |
| Fix signing ceremony                     | `wallet_client.py` → `sign_message()` + `_external_server_sign()`          |
| Fix backup/recovery                      | `wallet_client.py` → `backup_key_shares()` / `recover_key_shares()`        |
| Fix Rust ECDSA operations                | `src/ecdsa.rs`                                                             |
| Fix Rust Ed25519/SVM operations          | `src/exportable_ed25519.rs`                                                |
| Change Python↔Rust data types            | `src/types.rs`                                                             |
| Run unit tests                           | `tests/test_*.py` (no credentials needed)                                  |
| Run end-to-end tests                     | `tests/test_e2e_preprod.py` (needs `DYNAMIC_ENV_ID` + `DYNAMIC_API_TOKEN`) |

---

## 11. Adding a New Chain

1. **`mpc_config.py`**: Add a `ChainConfig` entry to `MPC_CHAIN_CONFIG`:

   ```python
   "MYCHAIN": ChainConfig(
       signing_algorithm=SigningAlgorithm.ECDSA,
       derivation_path=[44, 9999, 0, 0, 0],
   )
   ```

2. **`mychain/utils.py`**: Implement address derivation from public key bytes and any chain-specific message formatting.

3. **`mychain/client.py`**: Create `DynamicMychainWalletClient(DynamicWalletClient)` with:

   - `create_wallet_account()` — calls `self.keygen("MYCHAIN", ...)`, derives address, calls `_init_wallet_entry()`, calls `backup_key_shares()`
   - `sign_message()` — formats message, calls `super().sign_message(...)`
   - Any other chain-specific operations

4. **`__init__.py`**: Export the new client.

5. **Tests**: Add `tests/test_mychain_utils.py` for address/message formatting, and a test class in `tests/test_e2e_preprod.py`.

---

## 12. Common Pitfalls

### "Key share loss" after clear

The demo deliberately clears `wp.external_server_key_shares = []` to simulate loss. If you see signing fail with `DynamicSDKError("No key shares available...")`, the key shares were cleared and need recovery.

### Backup must be called to activate shares

After keygen, shares are in "pending" state on the server. `backup_key_shares()` MUST be called to post to `/keyShares/backup/locations` — this is what flips shares to "active". Both EVM and SVM clients always call this unconditionally after keygen.

### EVM address normalization

EVM addresses in the wallet map are stored lowercase. Always use `get_wallet_from_map(address)` which calls `_normalize_address()`. Never key `_wallet_map[address]` directly.

### ExportableEd25519 vs Ed25519

For SVM (Solana), the signer is `PyExportableEd25519`, not `PyEd25519`. They have different keygen methods (`receive_key` vs `keygen`). `mpc/signer.py` handles this automatically based on `chain_config.signing_algorithm`.

### `isFormatted` semantics

This flag has inverted intuition: `isFormatted=True` means "I've already formatted/hashed this, don't touch it". It does NOT mean "this is a formatted string". When in doubt: pre-hash on the client and pass `is_formatted=True`.

### SSE stream must stay open during MPC

The SSE connection cannot be closed before `ceremony_complete`. The `stream_sse_keygen` and `stream_sse_with_callback` functions keep the connection alive using an async task queue (`asyncio.Queue`). Do not add any `await` between stream open and MPC completion outside of these functions.

### Rust rebuild required after `.rs` changes

```bash
cd python && maturin develop
```

Python changes take effect immediately; Rust changes require a rebuild.
