/// PyExportableEd25519 — Python bindings for the ExportableEd25519 MPC protocol.
///
/// The Dynamic server uses ExportableEd25519 (sampleKey/receiveKey protocol) for
/// Solana (Ed25519) keygen, which differs from the standard FROST keygen used by
/// regular Ed25519. This module calls the C FFI layer directly since the MPC native
/// library does not expose ExportableEd25519 as a high-level Rust type.
///
/// Wire encoding conventions (matching MPC library internals):
///   - keygen_init_keypair → 64-char hex string of 32 raw bytes
///   - pubkey output → 64-char hex string (32 bytes), decoded to Vec<u8>
///   - secret_share → opaque base58 string (passed through as-is)
///   - signature output → 128-char hex string (64 bytes), decoded to Vec<u8>
///   - keygen IDs → base58 strings (passed through as-is)
use std::ffi::c_void;
use std::num::NonZeroU16;

use pyo3::prelude::*;
use sodot_mpc::ed25519::Ed25519;

use crate::types::{PyEd25519KeygenResult, PyInitKeygenResult};
use crate::unsafesend::SendFuture;

// ---------------------------------------------------------------------------
// C FFI type declarations — must match the MPC executor C header exactly
// ---------------------------------------------------------------------------

#[repr(C)]
#[derive(Clone, Copy)]
struct FfiConstStr {
    ptr: *const u8,
    len: usize,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct FfiRoom {
    uuid: FfiConstStr,
    host_url: FfiConstStr,
}

#[repr(C)]
struct FfiHeapString {
    ptr: *mut u8,
    len: usize,
}

impl FfiHeapString {
    const NULL: Self = Self { ptr: std::ptr::null_mut(), len: 0 };

    /// Read the string content without consuming; caller must call `sodot_dealloc_heap_string`.
    unsafe fn as_str(&self) -> &str {
        if self.ptr.is_null() {
            return "";
        }
        let bytes = std::slice::from_raw_parts(self.ptr, self.len);
        std::str::from_utf8_unchecked(bytes)
    }
}

#[repr(C)]
struct FfiResult {
    err_str: FfiHeapString,
    error_code: i32,
}

impl FfiResult {
    fn is_ok(&self) -> bool {
        self.error_code == 0
    }
}

#[repr(C)]
struct FfiConstSliceConstStr {
    ptr: *const FfiConstStr,
    len: usize,
}

// ---------------------------------------------------------------------------
// Extern C declarations for the functions we need
// ---------------------------------------------------------------------------

unsafe extern "C" {
    fn sodot_dealloc_heap_string(s: FfiHeapString);

    fn sodot_exportable_ed25519_receive_key(
        room: FfiRoom,
        num_parties: u16,
        threshold: u16,
        keygen_init_keypair: FfiConstStr,
        keygen_ids: FfiConstSliceConstStr,
        callback: Option<
            unsafe extern "C" fn(
                extra: *mut c_void,
                result: FfiResult,
                shared_pubkey: FfiConstStr,
                secret_share: FfiConstStr,
            ),
        >,
        extra: *mut c_void,
    ) -> FfiResult;

    fn sodot_exportable_ed25519_sign(
        room: FfiRoom,
        secret_share: FfiConstStr,
        msg_hex: FfiConstStr,
        callback: Option<
            unsafe extern "C" fn(
                extra: *mut c_void,
                result: FfiResult,
                signature: FfiConstStr,
            ),
        >,
        extra: *mut c_void,
    ) -> FfiResult;

    fn sodot_exportable_ed25519_get_pubkey(
        secret_share: FfiConstStr,
        pubkey_out: *mut FfiHeapString,
    ) -> FfiResult;

    fn sodot_exportable_ed25519_get_export_id(
        secret_share: FfiConstStr,
        export_id_out: *mut FfiHeapString,
    ) -> FfiResult;

    fn sodot_exportable_ed25519_refresh(
        room: FfiRoom,
        secret_share: FfiConstStr,
        callback: Option<
            unsafe extern "C" fn(
                extra: *mut c_void,
                result: FfiResult,
                shared_pubkey: FfiConstStr,
                secret_share: FfiConstStr,
            ),
        >,
        extra: *mut c_void,
    ) -> FfiResult;

    fn sodot_exportable_ed25519_export_full_private_key(
        room: FfiRoom,
        secret_share: FfiConstStr,
        export_to: FfiConstStr,
        callback: Option<
            unsafe extern "C" fn(
                extra: *mut c_void,
                result: FfiResult,
                private_key: FfiConstStr,
            ),
        >,
        extra: *mut c_void,
    ) -> FfiResult;

    fn sodot_exportable_ed25519_import_private_key_recipient(
        room: FfiRoom,
        threshold: u16,
        keygen_init_keypair: FfiConstStr,
        keygen_ids: FfiConstSliceConstStr,
        callback: Option<
            unsafe extern "C" fn(
                extra: *mut c_void,
                result: FfiResult,
                shared_pubkey: FfiConstStr,
                secret_share: FfiConstStr,
            ),
        >,
        extra: *mut c_void,
    ) -> FfiResult;

    fn sodot_exportable_ed25519_import_private_key_importer(
        room: FfiRoom,
        threshold: u16,
        private_key_bytes: FfiConstStr,
        keygen_init_keypair: FfiConstStr,
        keygen_ids: FfiConstSliceConstStr,
        callback: Option<
            unsafe extern "C" fn(
                extra: *mut c_void,
                result: FfiResult,
                shared_pubkey: FfiConstStr,
                secret_share: FfiConstStr,
            ),
        >,
        extra: *mut c_void,
    ) -> FfiResult;
}

// ---------------------------------------------------------------------------
// Async callback channels
// ---------------------------------------------------------------------------

type DoubleSender = tokio::sync::oneshot::Sender<Result<(String, String), String>>;
type SingleSender = tokio::sync::oneshot::Sender<Result<String, String>>;

/// FFI callback for operations that return two strings (pubkey + secret_share).
unsafe extern "C" fn double_cb(
    extra: *mut c_void,
    result: FfiResult,
    str1: FfiConstStr,
    str2: FfiConstStr,
) {
    let tx = unsafe { Box::from_raw(extra as *mut DoubleSender) };
    if result.is_ok() {
        let s1 = copy_ffi_str(str1);
        let s2 = copy_ffi_str(str2);
        let _ = tx.send(Ok((s1, s2)));
    } else {
        let msg = ffi_err_msg(&result);
        unsafe { sodot_dealloc_heap_string(result.err_str) };
        let _ = tx.send(Err(msg));
    }
}

/// FFI callback for operations that return one string.
unsafe extern "C" fn single_cb(
    extra: *mut c_void,
    result: FfiResult,
    str1: FfiConstStr,
) {
    let tx = unsafe { Box::from_raw(extra as *mut SingleSender) };
    if result.is_ok() {
        let s1 = copy_ffi_str(str1);
        let _ = tx.send(Ok(s1));
    } else {
        let msg = ffi_err_msg(&result);
        unsafe { sodot_dealloc_heap_string(result.err_str) };
        let _ = tx.send(Err(msg));
    }
}

/// Copy a `FfiConstStr` to an owned `String` before the pointer is invalidated.
unsafe fn copy_ffi_str(s: FfiConstStr) -> String {
    if s.ptr.is_null() || s.len == 0 {
        return String::new();
    }
    let bytes = std::slice::from_raw_parts(s.ptr, s.len);
    std::str::from_utf8_unchecked(bytes).to_owned()
}

fn ffi_err_msg(result: &FfiResult) -> String {
    let detail = unsafe { result.err_str.as_str() };
    if detail.is_empty() {
        format!("MPC error {}", result.error_code)
    } else {
        format!("MPC error {}: {}", result.error_code, detail)
    }
}

// ---------------------------------------------------------------------------
// Helper macros for the repetitive FFI setup pattern
// ---------------------------------------------------------------------------

/// Call a "double-output" async FFI function and await the result.
///
/// Handles channel setup, error propagation, and decoding of the two output strings.
/// Returns (pubkey_hex, secret_share_str).
macro_rules! ffi_double_call {
    ($fn:ident, $room:expr, $($args:expr),+ $(,)?) => {{
        let (tx, rx) = tokio::sync::oneshot::channel::<Result<(String, String), String>>();
        let sender = Box::into_raw(Box::new(tx));

        let result = unsafe {
            $fn($room, $($args,)+ Some(double_cb), sender as *mut c_void)
        };

        if !result.is_ok() {
            let msg = ffi_err_msg(&result);
            unsafe { sodot_dealloc_heap_string(result.err_str) };
            let _ = unsafe { Box::from_raw(sender) };
            return Err(pyo3::exceptions::PyRuntimeError::new_err(
                format!(concat!(stringify!($fn), " failed (sync): {}"), msg)
            ));
        }

        rx.await
            .map_err(|_| pyo3::exceptions::PyRuntimeError::new_err(
                concat!(stringify!($fn), " channel dropped")
            ))?
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(
                format!(concat!(stringify!($fn), " failed: {}"), e)
            ))?
    }};
}

macro_rules! ffi_single_call {
    ($fn:ident, $room:expr, $($args:expr),+ $(,)?) => {{
        let (tx, rx) = tokio::sync::oneshot::channel::<Result<String, String>>();
        let sender = Box::into_raw(Box::new(tx));

        let result = unsafe {
            $fn($room, $($args,)+ Some(single_cb), sender as *mut c_void)
        };

        if !result.is_ok() {
            let msg = ffi_err_msg(&result);
            unsafe { sodot_dealloc_heap_string(result.err_str) };
            let _ = unsafe { Box::from_raw(sender) };
            return Err(pyo3::exceptions::PyRuntimeError::new_err(
                format!(concat!(stringify!($fn), " failed (sync): {}"), msg)
            ));
        }

        rx.await
            .map_err(|_| pyo3::exceptions::PyRuntimeError::new_err(
                concat!(stringify!($fn), " channel dropped")
            ))?
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(
                format!(concat!(stringify!($fn), " failed: {}"), e)
            ))?
    }};
}

// ---------------------------------------------------------------------------
// Helper: build room + keygen ids from owned Strings
// ---------------------------------------------------------------------------

/// Decode a pubkey returned as a hex string from the C FFI.
fn decode_pubkey_hex(hex_str: &str) -> PyResult<Vec<u8>> {
    hex::decode(hex_str).map_err(|e| {
        pyo3::exceptions::PyRuntimeError::new_err(format!("pubkey hex decode: {e}"))
    })
}

/// Decode a signature returned as a hex string from the C FFI.
fn decode_sig_hex(hex_str: &str) -> PyResult<Vec<u8>> {
    hex::decode(hex_str).map_err(|e| {
        pyo3::exceptions::PyRuntimeError::new_err(format!("signature hex decode: {e}"))
    })
}

// ---------------------------------------------------------------------------
// PyExportableEd25519
// ---------------------------------------------------------------------------

/// Python wrapper for the ExportableEd25519 MPC protocol.
///
/// Used for Solana (SVM) wallets. The server calls `sampleKey` and the
/// client calls `receiveKey` (this class).
#[pyclass(name = "PyExportableEd25519")]
pub struct PyExportableEd25519 {
    // Reused only for init_keygen and create_room (same underlying C calls as Ed25519)
    inner: Ed25519,
    host_url: String,
}

#[pymethods]
impl PyExportableEd25519 {
    #[new]
    pub fn new(host_url: String) -> Self {
        let inner = Ed25519::new(host_url.clone());
        Self { inner, host_url }
    }

    /// Shared with regular Ed25519 — uses the MPC init_keygen primitive.
    pub fn init_keygen(&self) -> PyResult<PyInitKeygenResult> {
        let (keygen_id, keygen_private_key) = self.inner.init_keygen().map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("init_keygen failed: {e}"))
        })?;
        Ok(PyInitKeygenResult {
            keygen_id: keygen_id.as_str().to_string(),
            keygen_secret: keygen_private_key.as_bytes().to_vec(),
        })
    }

    /// Shared with regular Ed25519 — uses `sodot_create_room`.
    pub fn create_room<'py>(
        &self,
        py: Python<'py>,
        n: u16,
        api_key: String,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(
            py,
            SendFuture(async move {
                let n = NonZeroU16::new(n).ok_or_else(|| {
                    pyo3::exceptions::PyValueError::new_err("n must be > 0")
                })?;
                let room = inner.create_room(n, &api_key).await.map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!("create_room failed: {e}"))
                })?;
                Ok(room.as_str().to_string())
            }),
        )
    }

    /// Client-side key generation for ExportableEd25519.
    /// The server calls sampleKey; this client calls receiveKey.
    ///
    /// keygen_secret: 32 raw bytes from init_keygen
    /// keygen_ids: base58 IDs from all other parties
    pub fn receive_key<'py>(
        &self,
        py: Python<'py>,
        room_uuid: String,
        n: u16,
        t: u16,
        keygen_secret: Vec<u8>,
        keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let host_url = self.host_url.clone();

        pyo3_async_runtimes::tokio::future_into_py(
            py,
            SendFuture(async move {
                let n = NonZeroU16::new(n)
                    .ok_or_else(|| pyo3::exceptions::PyValueError::new_err("n must be > 0"))?;
                let t = NonZeroU16::new(t)
                    .ok_or_else(|| pyo3::exceptions::PyValueError::new_err("t must be > 0"))?;
                let secret_bytes: [u8; 32] =
                    keygen_secret.try_into().map_err(|_| {
                        pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes")
                    })?;
                // C SDK expects keygen_init_keypair as 64-char hex string
                let kpk_hex = hex::encode(&secret_bytes);

                // All owned Strings — live across await point safely
                let uuid_str = room_uuid;
                let host_str = host_url;
                let id_strings = keygen_ids;

                // --- synchronous FFI region: no await here ---
                let (pubkey_hex, secret_str) = {
                    let kpk_bytes = kpk_hex.as_bytes();
                    let uuid_bytes = uuid_str.as_bytes();
                    let host_bytes = host_str.as_bytes();
                    let id_byte_vecs: Vec<Vec<u8>> =
                        id_strings.iter().map(|s| s.as_bytes().to_vec()).collect();
                    let ffi_ids: Vec<FfiConstStr> = id_byte_vecs
                        .iter()
                        .map(|v| FfiConstStr { ptr: v.as_ptr(), len: v.len() })
                        .collect();

                    let room = FfiRoom {
                        uuid: FfiConstStr { ptr: uuid_bytes.as_ptr(), len: uuid_bytes.len() },
                        host_url: FfiConstStr { ptr: host_bytes.as_ptr(), len: host_bytes.len() },
                    };
                    let kpk_ffi = FfiConstStr { ptr: kpk_bytes.as_ptr(), len: kpk_bytes.len() };
                    let ids_slice = FfiConstSliceConstStr {
                        ptr: ffi_ids.as_ptr(),
                        len: ffi_ids.len(),
                    };

                    // The C SDK copies all string data during this call.
                    ffi_double_call!(
                        sodot_exportable_ed25519_receive_key,
                        room,
                        n.get(),
                        t.get(),
                        kpk_ffi,
                        ids_slice,
                    )
                    // All raw pointer locals dropped here (before await in macro)
                };
                // Only Send data (Strings) lives past this point

                let pubkey_bytes = decode_pubkey_hex(&pubkey_hex)?;
                Ok(PyEd25519KeygenResult { pubkey: pubkey_bytes, secret_share: secret_str })
            }),
        )
    }

    /// Sign a message using ExportableEd25519.
    ///
    /// message: raw bytes of the message to sign (will be hex-encoded for C SDK)
    /// _derivation_path: accepted for API compatibility, ignored (no derivation support)
    pub fn sign<'py>(
        &self,
        py: Python<'py>,
        room_uuid: String,
        secret_share: String,
        message: Vec<u8>,
        _derivation_path: Vec<u32>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let host_url = self.host_url.clone();

        pyo3_async_runtimes::tokio::future_into_py(
            py,
            SendFuture(async move {
                // ExportableEd25519 sign takes msg_hex (no derivation path)
                let msg_hex = hex::encode(&message);

                let uuid_str = room_uuid;
                let host_str = host_url;
                let share_str = secret_share;

                let sig_hex = {
                    let uuid_bytes = uuid_str.as_bytes();
                    let host_bytes = host_str.as_bytes();
                    let share_bytes = share_str.as_bytes();
                    let msg_bytes = msg_hex.as_bytes();

                    let room = FfiRoom {
                        uuid: FfiConstStr { ptr: uuid_bytes.as_ptr(), len: uuid_bytes.len() },
                        host_url: FfiConstStr { ptr: host_bytes.as_ptr(), len: host_bytes.len() },
                    };

                    ffi_single_call!(
                        sodot_exportable_ed25519_sign,
                        room,
                        FfiConstStr { ptr: share_bytes.as_ptr(), len: share_bytes.len() },
                        FfiConstStr { ptr: msg_bytes.as_ptr(), len: msg_bytes.len() },
                    )
                };

                decode_sig_hex(&sig_hex)
            }),
        )
    }

    /// Get the public key for a secret share (synchronous).
    /// _derivation_path: accepted for API compatibility, ignored.
    pub fn derive_pubkey(
        &self,
        secret_share: String,
        _derivation_path: Vec<u32>,
    ) -> PyResult<Vec<u8>> {
        let share_bytes = secret_share.as_bytes();
        let share_ffi = FfiConstStr { ptr: share_bytes.as_ptr(), len: share_bytes.len() };
        let mut pubkey_out = FfiHeapString::NULL;

        let result = unsafe {
            sodot_exportable_ed25519_get_pubkey(share_ffi, &mut pubkey_out)
        };

        if !result.is_ok() {
            let msg = ffi_err_msg(&result);
            unsafe { sodot_dealloc_heap_string(result.err_str) };
            return Err(pyo3::exceptions::PyRuntimeError::new_err(format!(
                "get_pubkey failed: {msg}"
            )));
        }

        let pubkey_hex = unsafe { pubkey_out.as_str() }.to_owned();
        unsafe { sodot_dealloc_heap_string(pubkey_out) };

        decode_pubkey_hex(&pubkey_hex)
    }

    /// Get the export ID for a key share (synchronous).
    pub fn export_id(&self, secret_share: String) -> PyResult<String> {
        let share_bytes = secret_share.as_bytes();
        let share_ffi = FfiConstStr { ptr: share_bytes.as_ptr(), len: share_bytes.len() };
        let mut id_out = FfiHeapString::NULL;

        let result = unsafe {
            sodot_exportable_ed25519_get_export_id(share_ffi, &mut id_out)
        };

        if !result.is_ok() {
            let msg = ffi_err_msg(&result);
            unsafe { sodot_dealloc_heap_string(result.err_str) };
            return Err(pyo3::exceptions::PyRuntimeError::new_err(format!(
                "export_id failed: {msg}"
            )));
        }

        let id_str = unsafe { id_out.as_str() }.to_owned();
        unsafe { sodot_dealloc_heap_string(id_out) };
        Ok(id_str)
    }

    /// Refresh key shares without changing the public key.
    pub fn refresh<'py>(
        &self,
        py: Python<'py>,
        room_uuid: String,
        secret_share: String,
    ) -> PyResult<Bound<'py, PyAny>> {
        let host_url = self.host_url.clone();

        pyo3_async_runtimes::tokio::future_into_py(
            py,
            SendFuture(async move {
                let uuid_str = room_uuid;
                let host_str = host_url;
                let share_str = secret_share;

                let (pubkey_hex, new_share) = {
                    let uuid_bytes = uuid_str.as_bytes();
                    let host_bytes = host_str.as_bytes();
                    let share_bytes = share_str.as_bytes();

                    let room = FfiRoom {
                        uuid: FfiConstStr { ptr: uuid_bytes.as_ptr(), len: uuid_bytes.len() },
                        host_url: FfiConstStr { ptr: host_bytes.as_ptr(), len: host_bytes.len() },
                    };

                    ffi_double_call!(
                        sodot_exportable_ed25519_refresh,
                        room,
                        FfiConstStr { ptr: share_bytes.as_ptr(), len: share_bytes.len() },
                    )
                };

                let pubkey_bytes = decode_pubkey_hex(&pubkey_hex)?;
                Ok(PyEd25519KeygenResult { pubkey: pubkey_bytes, secret_share: new_share })
            }),
        )
    }

    /// Export the full private key. Exporter receives a hex string; others get None.
    pub fn export_full_private_key<'py>(
        &self,
        py: Python<'py>,
        room_uuid: String,
        secret_share: String,
        export_to: String,
    ) -> PyResult<Bound<'py, PyAny>> {
        let host_url = self.host_url.clone();

        pyo3_async_runtimes::tokio::future_into_py(
            py,
            SendFuture(async move {
                let uuid_str = room_uuid;
                let host_str = host_url;
                let share_str = secret_share;
                let export_str = export_to;

                let key_str = {
                    let uuid_bytes = uuid_str.as_bytes();
                    let host_bytes = host_str.as_bytes();
                    let share_bytes = share_str.as_bytes();
                    let export_bytes = export_str.as_bytes();

                    let room = FfiRoom {
                        uuid: FfiConstStr { ptr: uuid_bytes.as_ptr(), len: uuid_bytes.len() },
                        host_url: FfiConstStr { ptr: host_bytes.as_ptr(), len: host_bytes.len() },
                    };

                    ffi_single_call!(
                        sodot_exportable_ed25519_export_full_private_key,
                        room,
                        FfiConstStr { ptr: share_bytes.as_ptr(), len: share_bytes.len() },
                        FfiConstStr { ptr: export_bytes.as_ptr(), len: export_bytes.len() },
                    )
                };

                // Empty string → this party is not the exporter
                if key_str.is_empty() {
                    Ok(None::<String>)
                } else {
                    Ok(Some(key_str))
                }
            }),
        )
    }

    /// Import a private key — recipient side (no private key, receives a share).
    pub fn import_private_key_recipient<'py>(
        &self,
        py: Python<'py>,
        room_uuid: String,
        threshold: u16,
        keygen_secret: Vec<u8>,
        keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let host_url = self.host_url.clone();

        pyo3_async_runtimes::tokio::future_into_py(
            py,
            SendFuture(async move {
                let secret_bytes: [u8; 32] = keygen_secret.try_into().map_err(|_| {
                    pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes")
                })?;
                let kpk_hex = hex::encode(&secret_bytes);

                let uuid_str = room_uuid;
                let host_str = host_url;
                let id_strings = keygen_ids;

                let (pubkey_hex, secret_str) = {
                    let uuid_bytes = uuid_str.as_bytes();
                    let host_bytes = host_str.as_bytes();
                    let kpk_bytes = kpk_hex.as_bytes();
                    let id_byte_vecs: Vec<Vec<u8>> =
                        id_strings.iter().map(|s| s.as_bytes().to_vec()).collect();
                    let ffi_ids: Vec<FfiConstStr> = id_byte_vecs
                        .iter()
                        .map(|v| FfiConstStr { ptr: v.as_ptr(), len: v.len() })
                        .collect();

                    let room = FfiRoom {
                        uuid: FfiConstStr { ptr: uuid_bytes.as_ptr(), len: uuid_bytes.len() },
                        host_url: FfiConstStr { ptr: host_bytes.as_ptr(), len: host_bytes.len() },
                    };

                    ffi_double_call!(
                        sodot_exportable_ed25519_import_private_key_recipient,
                        room,
                        threshold,
                        FfiConstStr { ptr: kpk_bytes.as_ptr(), len: kpk_bytes.len() },
                        FfiConstSliceConstStr { ptr: ffi_ids.as_ptr(), len: ffi_ids.len() },
                    )
                };

                let pubkey_bytes = decode_pubkey_hex(&pubkey_hex)?;
                Ok(PyEd25519KeygenResult { pubkey: pubkey_bytes, secret_share: secret_str })
            }),
        )
    }

    /// Import a private key — importer side (holds the private key).
    ///
    /// private_key: 32 raw bytes of the Ed25519 private key
    /// _is_raw: accepted for API compatibility (ExportableEd25519 always uses raw/hex encoding)
    pub fn import_private_key_importer<'py>(
        &self,
        py: Python<'py>,
        room_uuid: String,
        threshold: u16,
        private_key: Vec<u8>,
        _is_raw: bool,
        keygen_secret: Vec<u8>,
        keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let host_url = self.host_url.clone();

        pyo3_async_runtimes::tokio::future_into_py(
            py,
            SendFuture(async move {
                let secret_bytes: [u8; 32] = keygen_secret.try_into().map_err(|_| {
                    pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes")
                })?;
                let kpk_hex = hex::encode(&secret_bytes);
                // C SDK takes private_key_bytes as hex string
                let private_key_bytes: [u8; 32] = private_key.try_into().map_err(|_| {
                    pyo3::exceptions::PyValueError::new_err("private_key must be 32 bytes")
                })?;
                let pk_hex = hex::encode(&private_key_bytes);

                let uuid_str = room_uuid;
                let host_str = host_url;
                let id_strings = keygen_ids;

                let (pubkey_hex, secret_str) = {
                    let uuid_bytes = uuid_str.as_bytes();
                    let host_bytes = host_str.as_bytes();
                    let kpk_bytes = kpk_hex.as_bytes();
                    let pk_bytes = pk_hex.as_bytes();
                    let id_byte_vecs: Vec<Vec<u8>> =
                        id_strings.iter().map(|s| s.as_bytes().to_vec()).collect();
                    let ffi_ids: Vec<FfiConstStr> = id_byte_vecs
                        .iter()
                        .map(|v| FfiConstStr { ptr: v.as_ptr(), len: v.len() })
                        .collect();

                    let room = FfiRoom {
                        uuid: FfiConstStr { ptr: uuid_bytes.as_ptr(), len: uuid_bytes.len() },
                        host_url: FfiConstStr { ptr: host_bytes.as_ptr(), len: host_bytes.len() },
                    };

                    ffi_double_call!(
                        sodot_exportable_ed25519_import_private_key_importer,
                        room,
                        threshold,
                        FfiConstStr { ptr: pk_bytes.as_ptr(), len: pk_bytes.len() },
                        FfiConstStr { ptr: kpk_bytes.as_ptr(), len: kpk_bytes.len() },
                        FfiConstSliceConstStr { ptr: ffi_ids.as_ptr(), len: ffi_ids.len() },
                    )
                };

                let pubkey_bytes = decode_pubkey_hex(&pubkey_hex)?;
                Ok(PyEd25519KeygenResult { pubkey: pubkey_bytes, secret_share: secret_str })
            }),
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ffi_err_msg_code_only() {
        let result = FfiResult { err_str: FfiHeapString::NULL, error_code: 42 };
        assert_eq!(ffi_err_msg(&result), "MPC error 42");
    }

    #[test]
    fn test_ffi_err_msg_with_detail() {
        let msg = b"key share not found";
        let result = FfiResult {
            err_str: FfiHeapString { ptr: msg.as_ptr() as *mut u8, len: msg.len() },
            error_code: 7,
        };
        assert_eq!(ffi_err_msg(&result), "MPC error 7: key share not found");
    }
}
