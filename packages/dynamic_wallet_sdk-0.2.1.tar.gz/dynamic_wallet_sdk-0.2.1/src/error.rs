//! MPCError — Python exception for MPC operation failures.
//!
//! Raised when a native MPC operation returns a non-zero error code or when
//! the internal tokio channel drops unexpectedly. Maps to `dynamic_wallet_mpc.MPCError`
//! on the Python side. Catch this alongside `DynamicSDKError` from the Python layer.

use pyo3::create_exception;
use pyo3::exceptions::PyException;

create_exception!(dynamic_wallet_mpc, MPCError, PyException);

pub fn to_py_err(e: impl std::fmt::Display) -> pyo3::PyErr {
    MPCError::new_err(e.to_string())
}
