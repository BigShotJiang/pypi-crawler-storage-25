use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll};

/// Wrapper to mark a future as Send.
///
/// SAFETY: The MPC library's async FFI operations use raw pointers internally (ConstStr, ConstSlice)
/// that point to data owned within the future itself. The underlying C operations are thread-safe.
/// The raw pointers don't escape the future, so this is safe to send across threads.
pub struct SendFuture<F>(pub F);

// SAFETY: see above
unsafe impl<F> Send for SendFuture<F> {}

impl<F: Future> Future for SendFuture<F> {
    type Output = F::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        // SAFETY: We never move out of the inner future.
        let inner = unsafe { self.map_unchecked_mut(|s| &mut s.0) };
        inner.poll(cx)
    }
}
