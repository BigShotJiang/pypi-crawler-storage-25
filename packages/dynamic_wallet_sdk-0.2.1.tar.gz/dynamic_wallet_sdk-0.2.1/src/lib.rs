//! dynamic_wallet_mpc — Native extension entry point.
//!
//! This file declares the `dynamic_wallet_mpc` Python module and performs
//! one-time initialization of the shared tokio runtime.
//!
//! ## Module contents
//!
//! - `MPCError`: Python exception for MPC operation failures
//! - `PyInitKeygenResult`: Output of `init_keygen()` — (keygen_id, keygen_secret)
//! - `PyMessageHash`: 32-byte hash used as ECDSA sign input; constructors for SHA-256 and Keccak-256
//! - `PyEcdsaKeygenResult`: ECDSA keygen output — (pubkey_uncompressed, pubkey_compressed, secret_share)
//! - `PyEcdsaSignature`: ECDSA signature — (r, s, v, der)
//! - `PyEd25519KeygenResult`: Ed25519 keygen output — (pubkey, secret_share)
//! - `PyEcdsa`: ECDSA MPC operations (EVM and other secp256k1 chains)
//! - `PyEd25519`: Standard Ed25519 MPC operations (not used for SVM in production)
//! - `PyExportableEd25519`: ExportableEd25519 MPC operations (used for SVM / Solana)
//!
//! ## Tokio runtime
//!
//! A single multi-threaded tokio runtime is initialized once and leaked as
//! `&'static Runtime`. This is intentional: the runtime must outlive all Python
//! objects that hold async tasks, and Python's module lifetime is effectively
//! static. pyo3_async_runtimes requires a `&'static` runtime handle.

mod ecdsa;
mod ed25519;
mod exportable_ed25519;
mod error;
mod types;
mod unsafesend;

use pyo3::prelude::*;

#[pymodule]
fn dynamic_wallet_mpc(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Initialize shared tokio runtime for all async operations.
    // Box::leak gives us a &'static Runtime, required by pyo3_async_runtimes.
    let runtime = Box::leak(Box::new(
        tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .expect("Failed to build tokio runtime"),
    ));
    let _ = pyo3_async_runtimes::tokio::init_with_runtime(runtime);

    // Register exception
    m.add("MPCError", m.py().get_type_bound::<error::MPCError>())?;

    // Register shared types
    m.add_class::<types::PyInitKeygenResult>()?;
    m.add_class::<types::PyMessageHash>()?;

    // Register ECDSA types
    m.add_class::<types::PyEcdsaKeygenResult>()?;
    m.add_class::<types::PyEcdsaSignature>()?;

    // Register Ed25519 types
    m.add_class::<types::PyEd25519KeygenResult>()?;

    // Register MPC classes
    m.add_class::<ecdsa::PyEcdsa>()?;
    m.add_class::<ed25519::PyEd25519>()?;
    m.add_class::<exportable_ed25519::PyExportableEd25519>()?;

    Ok(())
}
