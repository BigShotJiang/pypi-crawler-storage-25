//! Python-visible data types shared across ECDSA and Ed25519 MPC operations.
//!
//! All types here are `#[pyclass]` and exposed to Python via `lib.rs`.
//!
//! ## Type hierarchy
//!
//! **Shared**
//! - `PyInitKeygenResult` — output of `init_keygen()` for any algorithm.
//!   Contains `keygen_id` (a stable party identifier, base58) and
//!   `keygen_secret` (32 raw bytes used as entropy for the MPC ceremony).
//!
//! **ECDSA (secp256k1 — EVM, COSMOS, SUI, etc.)**
//! - `PyEcdsaKeygenResult` — public key (uncompressed 65 bytes + compressed 33 bytes) and `secret_share`
//! - `PyEcdsaSignature` — DER + raw (r, s, v) components
//! - `PyMessageHash` — 32-byte hash input for ECDSA signing; has `sha256()` and `keccak256()` constructors
//!
//! **Ed25519 (SVM / Solana via ExportableEd25519)**
//! - `PyEd25519KeygenResult` — 32-byte raw public key and `secret_share`

use pyo3::prelude::*;
use pyo3::types::PyBytes;

// --- Shared init keygen result (same structure for both ECDSA and Ed25519) ---

#[pyclass(name = "PyInitKeygenResult")]
#[derive(Clone)]
pub struct PyInitKeygenResult {
    #[pyo3(get)]
    pub keygen_id: String,
    #[pyo3(get)]
    pub keygen_secret: Vec<u8>,
}

#[pymethods]
impl PyInitKeygenResult {
    #[new]
    pub fn new(keygen_id: String, keygen_secret: Vec<u8>) -> Self {
        Self {
            keygen_id,
            keygen_secret,
        }
    }

    pub fn keygen_secret_hex(&self) -> String {
        hex::encode(&self.keygen_secret)
    }
}

// --- ECDSA Types ---

#[pyclass(name = "PyEcdsaKeygenResult")]
#[derive(Clone)]
pub struct PyEcdsaKeygenResult {
    #[pyo3(get)]
    pub pubkey_uncompressed: Vec<u8>,
    #[pyo3(get)]
    pub pubkey_compressed: Vec<u8>,
    #[pyo3(get)]
    pub secret_share: String,
}

#[pyclass(name = "PyEcdsaSignature")]
#[derive(Clone)]
pub struct PyEcdsaSignature {
    #[pyo3(get)]
    pub r: Vec<u8>,
    #[pyo3(get)]
    pub s: Vec<u8>,
    #[pyo3(get)]
    pub v: u8,
    #[pyo3(get)]
    pub der: Vec<u8>,
}

// --- Ed25519 Types ---

#[pyclass(name = "PyEd25519KeygenResult")]
#[derive(Clone)]
pub struct PyEd25519KeygenResult {
    #[pyo3(get)]
    pub pubkey: Vec<u8>,
    #[pyo3(get)]
    pub secret_share: String,
}

// --- MessageHash (for ECDSA signing) ---

#[pyclass(name = "PyMessageHash")]
#[derive(Clone)]
pub struct PyMessageHash {
    pub hash: [u8; 32],
}

#[pymethods]
impl PyMessageHash {
    /// Create from a 64-char hex string (32 bytes).
    #[new]
    pub fn new(hex_str: &str) -> PyResult<Self> {
        let bytes = hex::decode(hex_str)
            .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
        let hash: [u8; 32] = bytes
            .try_into()
            .map_err(|_| pyo3::exceptions::PyValueError::new_err("MessageHash must be exactly 32 bytes"))?;
        Ok(Self { hash })
    }

    #[staticmethod]
    pub fn sha256(data: &[u8]) -> Self {
        use sha2::Digest;
        let result = sha2::Sha256::digest(data);
        Self {
            hash: result.into(),
        }
    }

    #[staticmethod]
    pub fn keccak256(data: &[u8]) -> Self {
        use sha3::Digest;
        let result = sha3::Keccak256::digest(data);
        Self {
            hash: result.into(),
        }
    }

    pub fn to_hex(&self) -> String {
        hex::encode(self.hash)
    }

    pub fn as_bytes<'py>(&self, py: Python<'py>) -> Bound<'py, PyBytes> {
        PyBytes::new_bound(py, &self.hash)
    }
}
