//! PyEcdsa — Python bindings for ECDSA MPC operations.
//!
//! PyEcdsa — Python bindings for ECDSA MPC operations.
//!
//! Exposes keygen, signing, refresh, export, and import operations as awaitable
//! Python coroutines backed by the native MPC library.
//!
//! ## Usage
//!
//! Used for EVM and other secp256k1 chains (COSMOS, SUI, TON, STELLAR).
//! `mpc/signer.py` instantiates this class when `chain_config.signing_algorithm == ECDSA`.
//!
//! ## Async pattern
//!
//! Every async method clones `self.inner` (cheap — it holds only a URL string),
//! then uses `pyo3_async_runtimes::tokio::future_into_py` with a `SendFuture`
//! wrapper. The `SendFuture` is needed because the MPC library's internal futures
//! are `!Send` (they hold raw pointer references). See `unsafesend.rs`.
//!
//! ## Key types
//!
//! - `keygen_id`: base58 string — stable party ID used to identify this share in a room
//! - `keygen_secret`: `[u8; 32]` — entropy used during MPC ceremony; never reused
//! - `secret_share`: opaque base58 string — the client's MPC key share; treat like a private key
//! - `room_uuid`: UUID string assigned by the Dynamic MPC relay for a ceremony
//! - `derivation_path`: BIP-32 path as `Vec<u32>` (e.g., `[44, 60, 0, 0, 0]` for EVM)

use std::num::NonZeroU16;

use pyo3::prelude::*;
use sodot_mpc::ecdsa::{Ecdsa, MessageHash};
use sodot_mpc::{KeygenId, KeygenPrivateKey, RoomUUID, SecretShare};

use crate::error::to_py_err;
use crate::types::{PyEcdsaKeygenResult, PyEcdsaSignature, PyInitKeygenResult, PyMessageHash};
use crate::unsafesend::SendFuture;

#[pyclass(name = "PyEcdsa")]
pub struct PyEcdsa {
    inner: Ecdsa,
}

#[pymethods]
impl PyEcdsa {
    #[new]
    pub fn new(host_url: String) -> Self {
        Self {
            inner: Ecdsa::new(host_url),
        }
    }

    pub fn init_keygen(&self) -> PyResult<PyInitKeygenResult> {
        let (keygen_id, keygen_private_key) = self.inner.init_keygen().map_err(to_py_err)?;
        Ok(PyInitKeygenResult {
            keygen_id: keygen_id.as_str().to_string(),
            keygen_secret: keygen_private_key.as_bytes().to_vec(),
        })
    }

    pub fn create_room<'py>(&self, py: Python<'py>, n: u16, api_key: String) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let n = NonZeroU16::new(n).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("n must be > 0"))?;
            let room = inner.create_room(n, &api_key).await.map_err(to_py_err)?;
            Ok(room.as_str().to_string())
        }))
    }

    pub fn keygen<'py>(
        &self, py: Python<'py>, room_uuid: String, n: u16, t: u16,
        keygen_secret: Vec<u8>, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let n = NonZeroU16::new(n).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("n must be > 0"))?;
            let t = NonZeroU16::new(t).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("t must be > 0"))?;
            let secret_bytes: [u8; 32] = keygen_secret.try_into()
                .map_err(|_| pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes"))?;
            let private_key = KeygenPrivateKey::new(secret_bytes);
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();

            let (pubkey, secret_share) = inner.keygen(&room, n, t, &private_key, &ids).await.map_err(to_py_err)?;
            Ok(PyEcdsaKeygenResult {
                pubkey_uncompressed: pubkey.uncompressed().to_vec(),
                pubkey_compressed: pubkey.compressed().to_vec(),
                secret_share: secret_share.as_str().to_string(),
            })
        }))
    }

    pub fn sign<'py>(
        &self, py: Python<'py>, room_uuid: String, secret_share: String,
        msg_hash: PyMessageHash, derivation_path: Vec<u32>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let share: SecretShare<Ecdsa> = secret_share.into();
            let hash = MessageHash::from_hash(msg_hash.hash);
            let sig = inner.sign(&room, &share, &hash, &derivation_path).await.map_err(to_py_err)?;
            Ok(PyEcdsaSignature {
                r: sig.r().to_vec(),
                s: sig.s().to_vec(),
                v: sig.v(),
                der: sig.der().to_vec(),
            })
        }))
    }

    pub fn derive_pubkey(&self, secret_share: String, derivation_path: Vec<u32>) -> PyResult<(Vec<u8>, Vec<u8>)> {
        let share: SecretShare<Ecdsa> = secret_share.into();
        let pubkey = self.inner.derive_pubkey(&share, &derivation_path).map_err(to_py_err)?;
        Ok((pubkey.uncompressed().to_vec(), pubkey.compressed().to_vec()))
    }

    pub fn refresh<'py>(&self, py: Python<'py>, room_uuid: String, secret_share: String) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let share: SecretShare<Ecdsa> = secret_share.into();
            let (pubkey, new_share) = inner.refresh(&room, &share).await.map_err(to_py_err)?;
            Ok(PyEcdsaKeygenResult {
                pubkey_uncompressed: pubkey.uncompressed().to_vec(),
                pubkey_compressed: pubkey.compressed().to_vec(),
                secret_share: new_share.as_str().to_string(),
            })
        }))
    }

    pub fn export_id(&self, secret_share: String) -> PyResult<String> {
        let share: SecretShare<Ecdsa> = secret_share.into();
        let id = self.inner.export_id(&share).map_err(to_py_err)?;
        Ok(id.as_str().to_string())
    }

    pub fn export_full_private_key<'py>(
        &self, py: Python<'py>, room_uuid: String, secret_share: String, export_to: String,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let share: SecretShare<Ecdsa> = secret_share.into();
            let export_id = KeygenId::new(export_to);
            let result = inner.export_full_private_key(&room, &share, &export_id).await.map_err(to_py_err)?;
            Ok(result.map(|xpriv| xpriv.as_str().to_string()))
        }))
    }

    pub fn derive_private_key_from_xpriv(&self, xpriv: String, derivation_path: Vec<u32>) -> PyResult<Vec<u8>> {
        let xpriv_key = xpriv.into();
        let result = self.inner.derive_private_key_from_xpriv(&xpriv_key, &derivation_path).map_err(to_py_err)?;
        Ok(result.to_vec())
    }

    pub fn import_private_key_importer<'py>(
        &self, py: Python<'py>, room_uuid: String, threshold: u16,
        private_key: Vec<u8>, keygen_secret: Vec<u8>, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let t = NonZeroU16::new(threshold).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("threshold must be > 0"))?;
            let pk: [u8; 32] = private_key.try_into().map_err(|_| pyo3::exceptions::PyValueError::new_err("private_key must be 32 bytes"))?;
            let secret_bytes: [u8; 32] = keygen_secret.try_into().map_err(|_| pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes"))?;
            let kpk = KeygenPrivateKey::new(secret_bytes);
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();
            let (pubkey, secret_share) = inner.import_private_key_importer(&room, t, &pk, &kpk, &ids).await.map_err(to_py_err)?;
            Ok(PyEcdsaKeygenResult {
                pubkey_uncompressed: pubkey.uncompressed().to_vec(),
                pubkey_compressed: pubkey.compressed().to_vec(),
                secret_share: secret_share.as_str().to_string(),
            })
        }))
    }

    pub fn import_private_key_recipient<'py>(
        &self, py: Python<'py>, room_uuid: String, threshold: u16,
        keygen_secret: Vec<u8>, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let t = NonZeroU16::new(threshold).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("threshold must be > 0"))?;
            let secret_bytes: [u8; 32] = keygen_secret.try_into().map_err(|_| pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes"))?;
            let kpk = KeygenPrivateKey::new(secret_bytes);
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();
            let (pubkey, secret_share) = inner.import_private_key_recipient(&room, t, &kpk, &ids).await.map_err(to_py_err)?;
            Ok(PyEcdsaKeygenResult {
                pubkey_uncompressed: pubkey.uncompressed().to_vec(),
                pubkey_compressed: pubkey.compressed().to_vec(),
                secret_share: secret_share.as_str().to_string(),
            })
        }))
    }

    pub fn reshare_new_party<'py>(
        &self, py: Python<'py>, room_uuid: String, new_threshold: u16,
        keygen_secret: Vec<u8>, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let t = NonZeroU16::new(new_threshold).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("threshold must be > 0"))?;
            let secret_bytes: [u8; 32] = keygen_secret.try_into().map_err(|_| pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes"))?;
            let kpk = KeygenPrivateKey::new(secret_bytes);
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();
            let (pubkey, secret_share) = inner.reshare_new_party(&room, t, &kpk, &ids).await.map_err(to_py_err)?;
            Ok(PyEcdsaKeygenResult {
                pubkey_uncompressed: pubkey.uncompressed().to_vec(),
                pubkey_compressed: pubkey.compressed().to_vec(),
                secret_share: secret_share.as_str().to_string(),
            })
        }))
    }

    pub fn reshare_remaining_party<'py>(
        &self, py: Python<'py>, room_uuid: String, new_threshold: u16,
        secret_share: String, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let t = NonZeroU16::new(new_threshold).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("threshold must be > 0"))?;
            let share: SecretShare<Ecdsa> = secret_share.into();
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();
            let (pubkey, new_share) = inner.reshare_remaining_party(&room, t, &share, &ids).await.map_err(to_py_err)?;
            Ok(PyEcdsaKeygenResult {
                pubkey_uncompressed: pubkey.uncompressed().to_vec(),
                pubkey_compressed: pubkey.compressed().to_vec(),
                secret_share: new_share.as_str().to_string(),
            })
        }))
    }
}
