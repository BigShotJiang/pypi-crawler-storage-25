//! PyEd25519 — Python bindings for standard Ed25519 MPC operations.
//!
//! Wraps the native MPC library's Ed25519 type. The API mirrors `PyEcdsa` but for Ed25519.
//!
//! ## Important: this class is NOT used for SVM (Solana) in production
//!
//! The Dynamic server uses the ExportableEd25519 protocol (`sampleKey`/`receiveKey`)
//! for Solana wallets, which requires `PyExportableEd25519` (see `exportable_ed25519.rs`).
//! `PyEd25519` is available for completeness and native module sanity checks, but
//! `mpc/signer.py` always returns `PyExportableEd25519` for SVM chains.
//!
//! ## Differences from PyEcdsa
//!
//! - `sign()` takes raw `Vec<u8>` message (not a `PyMessageHash`)
//! - `derive_pubkey()` returns `Vec<u8>` (32 bytes, not a tuple)
//! - Signatures are raw 64-byte `Vec<u8>` (not PyEcdsaSignature)
//! - `import_private_key_importer()` takes an extra `is_raw: bool` flag to select
//!   between `FullPrivateKey::Raw` and `FullPrivateKey::RFC8032` encoding

use std::num::NonZeroU16;

use pyo3::prelude::*;
use sodot_mpc::ed25519::Ed25519;
use sodot_mpc::{KeygenId, KeygenPrivateKey, RoomUUID, SecretShare};

use crate::error::to_py_err;
use crate::types::{PyEd25519KeygenResult, PyInitKeygenResult};
use crate::unsafesend::SendFuture;

#[pyclass(name = "PyEd25519")]
pub struct PyEd25519 {
    inner: Ed25519,
}

#[pymethods]
impl PyEd25519 {
    #[new]
    pub fn new(host_url: String) -> Self {
        Self {
            inner: Ed25519::new(host_url),
        }
    }

    pub fn init_keygen(&self) -> PyResult<PyInitKeygenResult> {
        let (keygen_id, keygen_private_key) = self.inner.init_keygen().map_err(to_py_err)?;
        Ok(PyInitKeygenResult {
            keygen_id: keygen_id.as_str().to_string(),
            keygen_secret: keygen_private_key.as_bytes().to_vec(),
        })
    }

    pub fn create_room<'py>(&self, py: Python<'py>, n: u16, api_key: String) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let n = NonZeroU16::new(n).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("n must be > 0"))?;
            let room = inner.create_room(n, &api_key).await.map_err(to_py_err)?;
            Ok(room.as_str().to_string())
        }))
    }

    pub fn keygen<'py>(
        &self, py: Python<'py>, room_uuid: String, n: u16, t: u16,
        keygen_secret: Vec<u8>, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let n = NonZeroU16::new(n).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("n must be > 0"))?;
            let t = NonZeroU16::new(t).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("t must be > 0"))?;
            let secret_bytes: [u8; 32] = keygen_secret.try_into()
                .map_err(|_| pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes"))?;
            let private_key = KeygenPrivateKey::new(secret_bytes);
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();

            let (pubkey, secret_share) = inner.keygen(&room, n, t, &private_key, &ids).await.map_err(to_py_err)?;
            Ok(PyEd25519KeygenResult {
                pubkey: pubkey.as_bytes().to_vec(),
                secret_share: secret_share.as_str().to_string(),
            })
        }))
    }

    pub fn sign<'py>(
        &self, py: Python<'py>, room_uuid: String, secret_share: String,
        message: Vec<u8>, derivation_path: Vec<u32>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let share: SecretShare<Ed25519> = secret_share.into();
            let sig = inner.sign(&room, &share, &message, &derivation_path).await.map_err(to_py_err)?;
            Ok(sig.to_vec())
        }))
    }

    pub fn derive_pubkey(&self, secret_share: String, derivation_path: Vec<u32>) -> PyResult<Vec<u8>> {
        let share: SecretShare<Ed25519> = secret_share.into();
        let pubkey = self.inner.derive_pubkey(&share, &derivation_path).map_err(to_py_err)?;
        Ok(pubkey.as_bytes().to_vec())
    }

    pub fn refresh<'py>(&self, py: Python<'py>, room_uuid: String, secret_share: String) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let share: SecretShare<Ed25519> = secret_share.into();
            let (pubkey, new_share) = inner.refresh(&room, &share).await.map_err(to_py_err)?;
            Ok(PyEd25519KeygenResult {
                pubkey: pubkey.as_bytes().to_vec(),
                secret_share: new_share.as_str().to_string(),
            })
        }))
    }

    pub fn export_id(&self, secret_share: String) -> PyResult<String> {
        let share: SecretShare<Ed25519> = secret_share.into();
        let id = self.inner.export_id(&share).map_err(to_py_err)?;
        Ok(id.as_str().to_string())
    }

    pub fn export_full_private_key<'py>(
        &self, py: Python<'py>, room_uuid: String, secret_share: String, export_to: String,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let share: SecretShare<Ed25519> = secret_share.into();
            let export_id = KeygenId::new(export_to);
            let result = inner.export_full_private_key(&room, &share, &export_id).await.map_err(to_py_err)?;
            Ok(result.map(|spriv| spriv.as_str().to_string()))
        }))
    }

    pub fn import_private_key_importer<'py>(
        &self, py: Python<'py>, room_uuid: String, threshold: u16,
        private_key: Vec<u8>, is_raw: bool, keygen_secret: Vec<u8>, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let t = NonZeroU16::new(threshold).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("threshold must be > 0"))?;
            let pk: [u8; 32] = private_key.try_into().map_err(|_| pyo3::exceptions::PyValueError::new_err("private_key must be 32 bytes"))?;
            let full_pk = if is_raw {
                sodot_mpc::ed25519::FullPrivateKey::Raw(pk)
            } else {
                sodot_mpc::ed25519::FullPrivateKey::RFC8032(pk)
            };
            let secret_bytes: [u8; 32] = keygen_secret.try_into().map_err(|_| pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes"))?;
            let kpk = KeygenPrivateKey::new(secret_bytes);
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();
            let (pubkey, secret_share) = inner.import_private_key_importer(&room, t, full_pk, &kpk, &ids).await.map_err(to_py_err)?;
            Ok(PyEd25519KeygenResult {
                pubkey: pubkey.as_bytes().to_vec(),
                secret_share: secret_share.as_str().to_string(),
            })
        }))
    }

    pub fn import_private_key_recipient<'py>(
        &self, py: Python<'py>, room_uuid: String, threshold: u16,
        keygen_secret: Vec<u8>, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let t = NonZeroU16::new(threshold).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("threshold must be > 0"))?;
            let secret_bytes: [u8; 32] = keygen_secret.try_into().map_err(|_| pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes"))?;
            let kpk = KeygenPrivateKey::new(secret_bytes);
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();
            let (pubkey, secret_share) = inner.import_private_key_recipient(&room, t, &kpk, &ids).await.map_err(to_py_err)?;
            Ok(PyEd25519KeygenResult {
                pubkey: pubkey.as_bytes().to_vec(),
                secret_share: secret_share.as_str().to_string(),
            })
        }))
    }

    pub fn reshare_new_party<'py>(
        &self, py: Python<'py>, room_uuid: String, new_threshold: u16,
        keygen_secret: Vec<u8>, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let t = NonZeroU16::new(new_threshold).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("threshold must be > 0"))?;
            let secret_bytes: [u8; 32] = keygen_secret.try_into().map_err(|_| pyo3::exceptions::PyValueError::new_err("keygen_secret must be 32 bytes"))?;
            let kpk = KeygenPrivateKey::new(secret_bytes);
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();
            let (pubkey, secret_share) = inner.reshare_new_party(&room, t, &kpk, &ids).await.map_err(to_py_err)?;
            Ok(PyEd25519KeygenResult {
                pubkey: pubkey.as_bytes().to_vec(),
                secret_share: secret_share.as_str().to_string(),
            })
        }))
    }

    pub fn reshare_remaining_party<'py>(
        &self, py: Python<'py>, room_uuid: String, new_threshold: u16,
        secret_share: String, keygen_ids: Vec<String>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let inner = self.inner.clone();
        pyo3_async_runtimes::tokio::future_into_py(py, SendFuture(async move {
            let room = RoomUUID::new(room_uuid);
            let t = NonZeroU16::new(new_threshold).ok_or_else(|| pyo3::exceptions::PyValueError::new_err("threshold must be > 0"))?;
            let share: SecretShare<Ed25519> = secret_share.into();
            let ids: Vec<KeygenId> = keygen_ids.into_iter().map(KeygenId::new).collect();
            let (pubkey, new_share) = inner.reshare_remaining_party(&room, t, &share, &ids).await.map_err(to_py_err)?;
            Ok(PyEd25519KeygenResult {
                pubkey: pubkey.as_bytes().to_vec(),
                secret_share: new_share.as_str().to_string(),
            })
        }))
    }
}
