"""
Python AST Parser for CodeGraph AI
Extracts functions, classes, imports, and call graphs from Python files.
"""
from __future__ import annotations

import ast
from typing import Optional
from pathlib import Path
from dataclasses import dataclass, field


@dataclass
class ParsedFile:
    filepath: str
    functions: list[str] = field(default_factory=list)            # top-level only
    classes: list[str] = field(default_factory=list)
    methods: list[tuple[str, str]] = field(default_factory=list)  # (class_name, method_name)
    imports: list[str] = field(default_factory=list)
    calls: list[tuple[str, str]] = field(default_factory=list)    # (caller, callee)
    strings: dict[str, list[str]] = field(default_factory=list)   # func_name -> list of strings
    errors: list[str] = field(default_factory=list)


class PythonParser:
    """
    Parses a Python file using the built-in ast module.
    Extracts structural information for graph construction.
    """

    def parse_file(self, filepath: str) -> ParsedFile:
        result = ParsedFile(filepath=filepath, strings={})
        source = self._read_file(filepath, result)

        if source is None:
            return result

        tree = self._parse_source(source, filepath, result)

        if tree is None:
            return result

        self._extract_imports(tree, result)
        self._extract_functions_and_calls(tree, result)
        self._extract_classes(tree, result)

        return result

    # -------------------------
    # Private helpers
    # -------------------------

    def _read_file(self, filepath: str, result: ParsedFile) -> Optional[str]:
        try:
            return Path(filepath).read_text(encoding="utf-8")
        except FileNotFoundError:
            result.errors.append(f"File not found: {filepath}")
            return None
        except Exception as e:
            result.errors.append(f"Could not read file: {e}")
            return None

    def _parse_source(self, source: str, filepath: str, result: ParsedFile) -> Optional[ast.AST]:
        try:
            return ast.parse(source, filename=filepath)
        except SyntaxError as e:
            result.errors.append(f"Syntax error: {e}")
            return None

    def _extract_imports(self, tree: ast.AST, result: ParsedFile):
        for node in ast.walk(tree):
            # e.g. import os, import sys
            if isinstance(node, ast.Import):
                for alias in node.names:
                    result.imports.append(alias.name)

            # e.g. from pathlib import Path
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    result.imports.append(f"{module}.{alias.name}")

    def _extract_functions_and_calls(self, tree: ast.AST, result: ParsedFile):
        # Collect method names per class first
        class_method_names: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        class_method_names.add(item.name)

        # Walk top-level for standalone functions
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                result.functions.append(node.name)
                self._extract_calls_in_func(node, node.name, result)
                self._extract_strings_in_func(node, node.name, result)

            elif isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        result.methods.append((node.name, item.name))
                        self._extract_calls_in_func(item, item.name, result)
                        self._extract_strings_in_func(item, item.name, result)

    def _extract_calls_in_func(self, func_node: ast.AST, func_name: str, result: ParsedFile):
        for child in ast.walk(func_node):
            if isinstance(child, ast.Call):
                callee = self._resolve_call_name(child)
                if callee:
                    result.calls.append((func_name, callee))

    def _extract_strings_in_func(self, func_node: ast.AST, func_name: str, result: ParsedFile):
        if func_name not in result.strings:
            result.strings[func_name] = []
        
        for child in ast.walk(func_node):
            # Python 3.8+ handles strings as ast.Constant
            if isinstance(child, ast.Constant) and isinstance(child.value, str):
                result.strings[func_name].append(child.value)

    def _extract_classes(self, tree: ast.AST, result: ParsedFile):
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                result.classes.append(node.name)

    def _resolve_call_name(self, call_node: ast.Call) -> Optional[str]:
        """Extract the name of a function being called."""
        func = call_node.func

        if isinstance(func, ast.Name):
            return func.id  # e.g. print(...)

        if isinstance(func, ast.Attribute):
            return func.attr  # e.g. self.login() → login

        return None