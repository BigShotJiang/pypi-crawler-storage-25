"""
Database Parser for CodeGraph AI
Extracts metadata from SQLite databases.
"""
import sqlite3
from pathlib import Path

class DatabaseParser:
    """
    Parses SQLite files to extract table names.
    """
    
    def parse(self, filepath: str) -> dict:
        metadata = {"tables": []}
        try:
            conn = sqlite3.connect(filepath)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in cursor.fetchall()]
            metadata["tables"] = tables
            conn.close()
        except Exception as e:
            metadata["error"] = str(e)
            
        return metadata
