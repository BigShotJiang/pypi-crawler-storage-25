"""
Image Parser for CodeGraph AI
Extracts text from images using pytesseract (OCR).
"""
import pytesseract
from PIL import Image
from pathlib import Path

class ImageParser:
    """
    Parses Image files to extract text via OCR.
    """
    
    def parse(self, filepath: str) -> dict:
        """
        Attempts OCR on the image. Falls back gracefully if OCR is unavailable.
        """
        metadata = {
            "text": ""
        }
        
        try:
            # Check if tesseract is installed
            # (In a real system we'd handle TesseractNotFoundError specifically)
            img = Image.open(filepath)
            ocr_text = pytesseract.image_to_string(img)
            
            # Limit the text length
            if len(ocr_text) > 500:
                ocr_text = ocr_text[:500] + "..."
            
            metadata["text"] = ocr_text.strip()
            
        except Exception as e:
            # If tesseract is not found or fails, we still return success with empty text
            # as requested in the requirements (handle failure gracefully)
            metadata["error"] = f"OCR failed or not available: {str(e)}"
            
        return metadata
