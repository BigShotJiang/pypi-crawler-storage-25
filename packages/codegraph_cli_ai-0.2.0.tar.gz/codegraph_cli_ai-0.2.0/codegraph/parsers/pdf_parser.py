"""
PDF Parser for CodeGraph AI
Extracts text and metadata from PDF files using pypdf.
"""
from pathlib import Path
from pypdf import PdfReader

class PDFParser:
    """
    Parses PDF files to extract basic text preview and page count.
    """
    
    def parse(self, filepath: str) -> dict:
        """
        Extracts metadata from the first few pages of a PDF.
        """
        metadata = {
            "num_pages": 0,
            "text_preview": ""
        }
        
        try:
            reader = PdfReader(filepath)
            metadata["num_pages"] = len(reader.pages)
            
            # Extract text from first 2 pages as a preview
            preview_text = []
            for i in range(min(2, len(reader.pages))):
                text = reader.pages[i].extract_text()
                if text:
                    preview_text.append(text.strip())
            
            # Limit the preview length to avoid huge tooltips
            full_preview = "\n---\n".join(preview_text)
            if len(full_preview) > 500:
                full_preview = full_preview[:500] + "..."
            
            metadata["text_preview"] = full_preview
            
        except Exception as e:
            metadata["error"] = str(e)
            
        return metadata
