"""
MultiModal Parser for CodeGraph AI
Extracts metadata from non-code assets like CSV, JSON, SQLite, PDF, and Images.
"""
import json
import csv
import sqlite3
from pathlib import Path
from dataclasses import dataclass, field

from codegraph.parsers.pdf_parser import PDFParser
from codegraph.parsers.image_parser import ImageParser
from codegraph.parsers.database_parser import DatabaseParser


@dataclass
class ParsedAsset:
    filepath: str
    kind: str  # "dataset" | "database" | "document" | "image"
    metadata: dict = field(default_factory=dict)


class MultiModalParser:
    """
    Parses non-Python files (CSV, JSON, SQLite, PDF, Image) to extract metadata.
    """

    def __init__(self):
        self.pdf_parser = PDFParser()
        self.image_parser = ImageParser()
        self.database_parser = DatabaseParser()

    def parse(self, filepath: str) -> ParsedAsset:
        path = Path(filepath)
        suffix = path.suffix.lower()

        if suffix == ".csv":
            return self._parse_csv(path)
        elif suffix == ".json":
            return self._parse_json(path)
        elif suffix in (".db", ".sqlite"):
            return self._parse_sqlite(path)
        elif suffix == ".pdf":
            return self._parse_pdf(path)
        elif suffix in (".png", ".jpg", ".jpeg"):
            return self._parse_image(path)
        else:
            return ParsedAsset(filepath=str(path), kind="unknown")

    def _parse_csv(self, path: Path) -> ParsedAsset:
        metadata = {"columns": []}
        try:
            with path.open("r", encoding="utf-8") as f:
                reader = csv.reader(f)
                header = next(reader, [])
                metadata["columns"] = header
        except Exception as e:
            metadata["error"] = str(e)
        
        return ParsedAsset(filepath=str(path), kind="dataset", metadata=metadata)

    def _parse_json(self, path: Path) -> ParsedAsset:
        metadata = {"keys": []}
        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    metadata["keys"] = list(data.keys())
                elif isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
                    metadata["keys"] = list(data[0].keys())
        except Exception as e:
            metadata["error"] = str(e)
            
        return ParsedAsset(filepath=str(path), kind="dataset", metadata=metadata)

    def _parse_sqlite(self, path: Path) -> ParsedAsset:
        metadata = self.database_parser.parse(str(path))
        return ParsedAsset(filepath=str(path), kind="database", metadata=metadata)

    def _parse_pdf(self, path: Path) -> ParsedAsset:
        metadata = self.pdf_parser.parse(str(path))
        return ParsedAsset(filepath=str(path), kind="document", metadata=metadata)

    def _parse_image(self, path: Path) -> ParsedAsset:
        metadata = self.image_parser.parse(str(path))
        return ParsedAsset(filepath=str(path), kind="image", metadata=metadata)
