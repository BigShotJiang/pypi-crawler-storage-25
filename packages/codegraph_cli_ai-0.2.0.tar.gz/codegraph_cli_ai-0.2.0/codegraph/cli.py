"""
CodeGraph AI - CLI Entry Point
"""

import json
import typer
import webbrowser
import networkx as nx
from pathlib import Path
from typing import Optional
from codegraph.parsers.python_parser import PythonParser
from codegraph.parsers.multimodal_parser import MultiModalParser
from codegraph.graph.builder import GraphBuilder

app = typer.Typer()


@app.callback()
def main():
    """CodeGraph AI - Understand your codebase using graphs and AI."""
    pass


IGNORE_DIRS = {
    "venv", ".venv", "env", "bin", "Scripts",
    ".git", "__pycache__", "node_modules", ".codegraph"
}
IGNORE_FILES = {"graph.json", ".DS_Store"}
IGNORE_EXTENSIONS = {".pyc", ".log", ".pyo", ".pyd"}


def is_virtualenv(path: Path) -> bool:
    """Detect if a directory is a virtual environment based on its structure."""
    return (
        (path / "pyvenv.cfg").exists()
        or (path / "bin" / "python").exists()
        or (path / "Scripts" / "python.exe").exists()
    )


@app.command()
def index(
    path: str = typer.Argument(".", help="Path to the repo or folder to index")
):
    """Scan a directory, parse all Python files, and save the knowledge graph."""
    root = Path(path).resolve()

    if not root.exists():
        typer.echo(f"[error] Path does not exist: {root}", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Indexing: {root}\n")
    
    # Phase A: Identify top-level custom virtualenvs
    venv_dirs = set()
    for item in root.iterdir():
        if item.is_dir() and is_virtualenv(item):
            venv_dirs.add(item)

    # Phase B: Filtered Scan
    all_files = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
            
        # 1. Skip if any parent directory is in IGNORE_DIRS
        if any(part in IGNORE_DIRS for part in p.parts):
            continue
            
        # 2. Skip if inside a detected custom venv
        if any(v_dir in p.parents for v_dir in venv_dirs):
            continue
            
        # 3. Skip if filename is ignored
        if p.name in IGNORE_FILES:
            continue
            
        # 4. Skip if extension is ignored
        if p.suffix.lower() in IGNORE_EXTENSIONS:
            continue
            
        all_files.append(p)

    py_files = [f for f in all_files if f.suffix == ".py"]
    asset_exts = {
        ".csv", ".json", ".db", ".sqlite",
        ".pdf",
        ".png", ".jpg", ".jpeg"
    }
    asset_files = [f for f in all_files if f.suffix.lower() in asset_exts]

    if not py_files and not asset_files:
        typer.echo("No supported files found (everything might be ignored).")
        raise typer.Exit()

    typer.echo(f"Found {len(py_files)} Python file(s) and {len(asset_files)} asset(s)\n")

    # Step 1 — Parse
    py_parser = PythonParser()
    mm_parser = MultiModalParser()
    
    parsed_files = []
    parsed_assets = []
    failed_files = []

    # Parse Python files
    for filepath in py_files:
        result = py_parser.parse_file(str(filepath))
        if result.errors:
            failed_files.append((str(filepath), result.errors))
        else:
            typer.echo(f"  ✔ [code]  {filepath.relative_to(root)}")
            parsed_files.append(result)

    # Parse assets
    for filepath in asset_files:
        try:
            asset = mm_parser.parse(str(filepath))
            typer.echo(f"  ✔ [asset] {filepath.relative_to(root)}")
            parsed_assets.append(asset)
        except Exception as e:
            failed_files.append((str(filepath), [str(e)]))

    # Step 2 — Build graph
    typer.echo("\nBuilding graph...")
    builder = GraphBuilder()
    builder.build(parsed_files, parsed_assets)
    summary = builder.summary()

    # Step 3 — Save to .codegraph/graph.json
    output_dir = root / ".codegraph"
    output_dir.mkdir(exist_ok=True)
    output_file = output_dir / "graph.json"
    with output_file.open("w", encoding="utf-8") as fp:
        json.dump(builder.to_dict(), fp, indent=2)

    # Step 4 — Summary
    typer.echo("\n" + "=" * 50)
    typer.echo("Index complete")
    typer.echo(f"  Graph saved   : {output_file}")
    typer.echo(f"  Files parsed  : {len(parsed_files)}")
    typer.echo(f"  Graph nodes   : {summary['total_nodes']}")
    typer.echo(f"  Graph edges   : {summary['total_edges']}")
    typer.echo("\n  Node breakdown:")
    for kind, count in summary["nodes_by_kind"].items():
        typer.echo(f"    {kind:<12}: {count}")
    typer.echo("\n  Edge breakdown:")
    for rel, count in summary["edges_by_relation"].items():
        typer.echo(f"    {rel:<12}: {count}")

    if failed_files:
        typer.echo(f"\n  Failed files  : {len(failed_files)}")
        for fp, errors in failed_files:
            typer.echo(f"    {fp}: {errors}")


@app.command()
def plot(
    hide_external: bool = typer.Option(False, "--hide-external", help="Hide external/stdlib nodes"),
    level: Optional[str] = typer.Option(None, "--level", help="Show only: file, function, class, method"),
    focus: Optional[str] = typer.Option(None, "--focus", help="Focus on a specific file (e.g. cli.py)"),
    edge_type: Optional[str] = typer.Option(None, "--edge-type", help="Filter edges: calls, imports, contains, all"),
):
    """Visualize the knowledge graph as a premium interactive HTML file."""
    root = Path(".").resolve()
    graph_file = root / ".codegraph" / "graph.json"

    if not graph_file.exists():
        typer.echo("[error] No graph found. Run 'codegraph index' first.", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Loading graph from {graph_file}...")
    with graph_file.open("r", encoding="utf-8") as f:
        data = json.load(f)

    # Build NetworkX graph
    G = nx.DiGraph()
    for node in data.get("nodes", []):
        G.add_node(node["id"], **{k: v for k, v in node.items() if k != "id"})
    for edge in data.get("edges", []):
        G.add_edge(edge["source"], edge["target"], **{k: v for k, v in edge.items() if k not in ["source", "target"]})

    # --- Apply filters ---

    # 1. Hide external nodes
    if hide_external:
        remove = [n for n, d in G.nodes(data=True) if d.get("external", False)]
        G.remove_nodes_from(remove)

    # 2. Filter by level (node kind)
    if level:
        allowed = set(level.split(","))
        remove = [n for n, d in G.nodes(data=True) if d.get("kind") not in allowed]
        G.remove_nodes_from(remove)

    # 3. Focus on a specific file — keep only that file + its direct neighbors
    if focus:
        focus_id = f"file:{focus}"
        if focus_id in G:
            keep = {focus_id} | set(G.successors(focus_id)) | set(G.predecessors(focus_id))
            remove = [n for n in G.nodes if n not in keep]
            G.remove_nodes_from(remove)
        else:
            typer.echo(f"[warn] File '{focus}' not found in graph. Showing full graph.")

    # 4. Filter edge types
    if edge_type and edge_type != "all":
        allowed_edges = set(edge_type.split(","))
        remove_edges = [(s, t) for s, t, d in G.edges(data=True) if d.get("relation") not in allowed_edges]
        G.remove_edges_from(remove_edges)
        # Remove orphan nodes after edge removal
        G.remove_nodes_from(list(nx.isolates(G)))

    typer.echo(f"Rendering {G.number_of_nodes()} nodes, {G.number_of_edges()} edges...")

    # --- Build HTML visualization ---
    html = _build_premium_html(G)

    output_path = root / "graph.html"
    output_path.write_text(html, encoding="utf-8")

    typer.echo(f"Saved to: {output_path}")
    typer.echo("Opening in browser...")
    webbrowser.open(f"file://{output_path.resolve()}")


def _build_premium_html(G: nx.DiGraph) -> str:
    """Generate a self-contained premium HTML visualization using vis.js."""

    # --- Node styling ---
    STYLES = {
        "file":     {"color": "#4A90E2", "shape": "diamond", "size": 28, "font_color": "#ffffff"},
        "class":    {"color": "#F5A623", "shape": "hexagon", "size": 24, "font_color": "#ffffff"},
        "function": {"color": "#50C878", "shape": "dot",     "size": 16, "font_color": "#ffffff"},
        "method":   {"color": "#7ED6A8", "shape": "dot",     "size": 14, "font_color": "#ffffff"},
        "module":   {"color": "#B0BEC5", "shape": "box",     "size": 14, "font_color": "#ffffff"},
        "dataset":  {"color": "#FFD700", "shape": "diamond", "size": 22, "font_color": "#ffffff"},
        "database": {"color": "#FF69B4", "shape": "database", "size": 24, "font_color": "#ffffff"},
        "document": {"color": "#9B59B6", "shape": "diamond", "size": 24, "font_color": "#ffffff"},
        "image":    {"color": "#5DADE2", "shape": "diamond", "size": 24, "font_color": "#ffffff"},
    }

    EDGE_COLORS = {
        "contains":   "#4A90E2",
        "calls":      "#50C878",
        "imports":    "#B0BEC5",
        "defined_in": "#E8E8E8",
        "uses":       "#FFD700",
        "references": "#9B59B6",
    }

    nodes_js = []
    for node_id, attrs in G.nodes(data=True):
        kind = attrs.get("kind", "function")
        label = attrs.get("label", node_id)
        external = attrs.get("external", False)
        style = STYLES.get(kind, STYLES["function"])

        color = "#CFD8DC" if external else style["color"]
        font_color = "#B0BEC5" if external else style["font_color"]
        size = max(style["size"] - 4, 10) if external else style["size"]

        # Tooltip
        tooltip_parts = [f"<b>{label}</b>", f"Kind: {kind}"]
        if attrs.get("filename"):
            tooltip_parts.append(f"File: {attrs['filename']}")
        elif attrs.get("file"):
            tooltip_parts.append(f"File: {attrs['file'].replace('file:', '')}")
        if attrs.get("cls"):
            tooltip_parts.append(f"Class: {attrs['cls']}")
        
        # MultiModal Metadata for tooltips
        metadata = attrs.get("metadata", {})
        if kind == "dataset":
            if "columns" in metadata: tooltip_parts.append(f"Columns: {', '.join(metadata['columns'])}")
            if "keys" in metadata: tooltip_parts.append(f"Keys: {', '.join(metadata['keys'])}")
        elif kind == "database":
            if "tables" in metadata: tooltip_parts.append(f"Tables: {', '.join(metadata['tables'])}")
        elif kind == "document":
            if "num_pages" in metadata: tooltip_parts.append(f"Pages: {metadata['num_pages']}")
            if "text_preview" in metadata: tooltip_parts.append(f"<br>Preview: <i>{metadata['text_preview']}</i>")
        elif kind == "image":
            if "text" in metadata and metadata["text"]: tooltip_parts.append(f"<br>OCR Text: <i>{metadata['text']}</i>")
        
        # Add metadata for datasets/databases
        metadata = attrs.get("metadata", {})
        if metadata:
            if "columns" in metadata:
                cols = ", ".join(metadata["columns"][:5])
                if len(metadata["columns"]) > 5: cols += "..."
                tooltip_parts.append(f"Columns: {cols}")
            if "tables" in metadata:
                tbls = ", ".join(metadata["tables"])
                tooltip_parts.append(f"Tables: {tbls}")
            if "keys" in metadata:
                keys = ", ".join(metadata["keys"][:5])
                if len(metadata["keys"]) > 5: keys += "..."
                tooltip_parts.append(f"Keys: {keys}")

        if external:
            tooltip_parts.append("<i>external</i>")
        tooltip = "<br>".join(tooltip_parts)

        nodes_js.append(f"""{{
            id: {json.dumps(node_id)},
            label: {json.dumps(label)},
            title: {json.dumps(tooltip)},
            color: {{
                background: {json.dumps(color)},
                border: {json.dumps(_darken(color))},
                highlight: {{ background: "#FFE082", border: "#FFA000" }},
                hover: {{ background: "#E3F2FD", border: "#1E88E5" }}
            }},
            shape: {json.dumps(style["shape"])},
            size: {size},
            font: {{ color: {json.dumps(font_color)}, size: 13, face: "Inter, system-ui, sans-serif" }},
            borderWidth: 1.5,
            shadow: {{ enabled: true, color: "rgba(0,0,0,0.12)", size: 8, x: 2, y: 2 }}
        }}""")

    edges_js = []
    for src, dst, attrs in G.edges(data=True):
        relation = attrs.get("relation", "")
        color = EDGE_COLORS.get(relation, "#BDBDBD")
        dashed = relation in ("defined_in", "imports")

        edges_js.append(f"""{{
            from: {json.dumps(src)},
            to: {json.dumps(dst)},
            label: {json.dumps(relation)},
            color: {{ color: {json.dumps(color)}, opacity: 0.7 }},
            dashes: {"true" if dashed else "false"},
            width: {"1" if dashed else "1.5"},
            font: {{ color: "#9E9E9E", size: 10, face: "Inter, system-ui, sans-serif", align: "middle" }},
            arrows: {{ to: {{ enabled: true, scaleFactor: 0.6 }} }},
            smooth: {{ type: "curvedCW", roundness: 0.2 }}
        }}""")

    nodes_json = "[\n" + ",\n".join(nodes_js) + "\n]"
    edges_json = "[\n" + ",\n".join(edges_js) + "\n]"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CodeGraph AI</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ 
    font-family: 'Inter', system-ui, sans-serif; 
    background: #0F1117; 
    color: #E0E0E0; 
    height: 100vh; 
    display: flex; 
    flex-direction: column;
    overflow: hidden;
  }}

  /* Background effect */
  #graph-container::before {{
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background-image: radial-gradient(circle at 2px 2px, rgba(255,255,255,0.03) 1px, transparent 0);
    background-size: 32px 32px;
    pointer-events: none;
    z-index: 0;
  }}

  #graph-container::after {{
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: radial-gradient(circle at center, transparent 0%, rgba(15,17,23,0.4) 100%);
    pointer-events: none;
    z-index: 1;
  }}

  /* Header */
  #header {{
    display: flex; align-items: center; justify-content: space-between;
    padding: 16px 24px;
    background: rgba(26, 29, 39, 0.8);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid rgba(255,255,255,0.05);
    flex-shrink: 0;
    z-index: 10;
  }}
  #header h1 {{ font-size: 18px; font-weight: 600; color: #fff; letter-spacing: -0.01em; }}
  #header h1 span {{ color: #4A90E2; }}
  #stats {{ display: flex; gap: 20px; font-size: 13px; color: #78909C; }}
  #stats b {{ color: #ffffff; }}

  /* Legend */
  #legend {{
    display: flex; gap: 16px; align-items: center;
    padding: 10px 24px;
    background: rgba(26, 29, 39, 0.6);
    backdrop-filter: blur(8px);
    border-bottom: 1px solid rgba(255,255,255,0.05);
    flex-shrink: 0;
    flex-wrap: wrap;
    z-index: 10;
  }}
  .legend-item {{ display: flex; align-items: center; gap: 8px; font-size: 12px; color: #B0BEC5; font-weight: 500; }}
  .legend-dot {{ width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }}

  /* Graph */
  #graph-container {{ flex: 1; position: relative; background: #0F1117; }}
  #graph {{ position: absolute; top: 0; left: 0; right: 0; bottom: 0; z-index: 2; }}

  /* Tooltip override */
  .vis-tooltip {{
    background: #1E2130 !important;
    border: 1px solid #2A2D3A !important;
    color: #E0E0E0 !important;
    font-size: 13px !important;
    border-radius: 8px !important;
    padding: 10px 14px !important;
    box-shadow: 0 8px 24px rgba(0,0,0,0.5) !important;
    backdrop-filter: blur(4px);
  }}
</style>
</head>
<body>

<div id="header">
  <h1>Code<span>Graph</span> AI</h1>
  <div id="stats">
    <span>Nodes: <b id="node-count">-</b></span>
    <span>Edges: <b id="edge-count">-</b></span>
  </div>
</div>

<div id="legend">
  <span style="font-size:11px; color:#546E7A; font-weight: 700; margin-right:4px; letter-spacing: 0.05em;">NODES</span>
  <div class="legend-item"><div class="legend-dot" style="background:#4A90E2;border-radius:2px;transform:rotate(45deg)"></div>File</div>
  <div class="legend-item"><div class="legend-dot" style="background:#F5A623"></div>Class</div>
  <div class="legend-item"><div class="legend-dot" style="background:#50C878"></div>Function</div>
  <div class="legend-item"><div class="legend-dot" style="background:#7ED6A8"></div>Method</div>
  <div class="legend-item"><div class="legend-dot" style="background:#B0BEC5;border-radius:2px"></div>Module</div>
  <div class="legend-item"><div class="legend-dot" style="background:#FFD700;clip-path:polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)"></div>Dataset</div>
  <div class="legend-item"><div class="legend-dot" style="background:#FF69B4;border-radius:2px"></div>Database</div>
  <div class="legend-item"><div class="legend-dot" style="background:#9B59B6;clip-path:polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)"></div>Document</div>
  <div class="legend-item"><div class="legend-dot" style="background:#5DADE2;clip-path:polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)"></div>Image</div>
  <span style="font-size:11px; color:#546E7A; font-weight: 700; margin-left:12px; margin-right:4px; letter-spacing: 0.05em;">EDGES</span>
  <div class="legend-item"><div style="width:20px;height:2px;background:#4A90E2;opacity:0.6"></div>contains</div>
  <div class="legend-item"><div style="width:20px;height:2px;background:#50C878;opacity:0.6"></div>calls</div>
  <div class="legend-item"><div style="width:20px;height:1px;background:#B0BEC5;border-top:1px dashed #B0BEC5"></div>imports</div>
  <div class="legend-item"><div style="width:20px;height:2px;background:#FFD700;opacity:0.6"></div>uses</div>
</div>

<div id="graph-container">
  <div id="graph"></div>
</div>

<script>
const nodesRaw = {nodes_json};
nodesRaw.forEach(node => {{
  if (node.title) {{
    const div = document.createElement("div");
    div.innerHTML = node.title;
    node.title = div;
  }}
}});

const nodes = new vis.DataSet(nodesRaw);
const edges = new vis.DataSet({edges_json});

document.getElementById("node-count").textContent = nodes.length;
document.getElementById("edge-count").textContent = edges.length;

const container = document.getElementById("graph");
const options = {{
  physics: {{
    enabled: true,
    solver: "forceAtlas2Based",
    forceAtlas2Based: {{
      gravitationalConstant: -60,
      centralGravity: 0.005,
      springLength: 180,
      springConstant: 0.04,
      damping: 0.4,
      avoidOverlap: 0.8
    }},
    maxVelocity: 50,
    minVelocity: 0.5,
    timestep: 0.3,
    stabilization: {{ iterations: 200, updateInterval: 25 }}
  }},
  interaction: {{
    hover: true,
    tooltipDelay: 150,
    navigationButtons: true,
    keyboard: true,
    zoomView: true,
    hideEdgesOnDrag: false,
    hideNodesOnDrag: false
  }},
  edges: {{
    smooth: {{ type: "curvedCW", roundness: 0.15 }},
    font: {{ strokeWidth: 2, strokeColor: "#0F1117", size: 11 }}
  }},
  nodes: {{
    font: {{
      size: 14,
      face: "'Inter', system-ui, sans-serif",
      strokeWidth: 3,
      strokeColor: "#0F1117",
      color: "#ffffff"
    }},
    shadow: {{
      enabled: true,
      color: "rgba(0,0,0,0.3)",
      size: 10,
      x: 0,
      y: 0
    }}
  }}
}};

const network = new vis.Network(container, {{ nodes, edges }}, options);
network.once("stabilized", () => {{
  network.setOptions({{ physics: {{ enabled: false }} }});
}});
</script>
</body>
</html>"""


def _darken(hex_color: str) -> str:
    """Darken a hex color by ~15% for border contrast."""
    try:
        h = hex_color.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        r, g, b = max(0, r - 35), max(0, g - 35), max(0, b - 35)
        return f"#{r:02x}{g:02x}{b:02x}"
    except Exception:
        return hex_color


@app.command()
def ask(query: str = typer.Argument(..., help="Question about your codebase")):
    """Ask a question about your codebase (coming soon)."""
    typer.echo(f"ask: coming soon — query was: {query}")


@app.command()
def explain(file: str = typer.Argument(..., help="File to explain")):
    """Get an AI-generated explanation of a file (coming soon)."""
    typer.echo(f"explain: coming soon — file was: {file}")


@app.command()
def audit():
    """Audit the codebase for missing docs, unused code, hidden deps (coming soon)."""
    typer.echo("audit: coming soon")


if __name__ == "__main__":
    app()