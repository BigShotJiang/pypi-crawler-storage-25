"""
Graph Builder for CodeGraph AI

Node types:
  - file       : a .py file
  - function   : top-level function
  - class      : a class
  - method     : a method belonging to a class
  - module     : an imported module/package

Edge types:
  - contains   : file → function, file → class, class → method
  - calls      : function/method → function/method
  - imports    : file → module
  - defined_in : function/method → file
"""

import builtins
import networkx as nx
from pathlib import Path
from codegraph.parsers.python_parser import ParsedFile
from codegraph.parsers.multimodal_parser import ParsedAsset


BUILTIN_FUNCTIONS = set(dir(builtins))


class GraphBuilder:
    def __init__(self):
        self.graph = nx.DiGraph()
        self._function_to_file: dict[str, str] = {}
        self._assets: list[ParsedAsset] = []
        self._parsed_files: list[ParsedFile] = []

    def add_file(self, parsed: ParsedFile) -> None:
        self._parsed_files.append(parsed)
        file_id = self._file_node_id(parsed.filepath)
        filename = Path(parsed.filepath).name

        self._add_node(file_id, kind="file", label=filename, external=False)

        for cls in parsed.classes:
            cls_id = f"class:{file_id}:{cls}"
            self._add_node(cls_id, kind="class", label=cls, external=False, file=file_id)
            self._add_edge(file_id, cls_id, relation="contains")

        for func in parsed.functions:
            func_id = f"func:{file_id}:{func}"
            self._add_node(func_id, kind="function", label=func, external=False, file=file_id)
            self._add_edge(file_id, func_id, relation="contains")
            self._add_edge(func_id, file_id, relation="defined_in")
            self._function_to_file[func] = file_id

        for cls_name, method_name in parsed.methods:
            cls_id = f"class:{file_id}:{cls_name}"
            method_id = f"func:{file_id}:{method_name}"
            self._add_node(method_id, kind="method", label=method_name, external=False, file=file_id, cls=cls_name)
            self._add_edge(cls_id, method_id, relation="contains")
            self._add_edge(method_id, file_id, relation="defined_in")
            self._function_to_file[method_name] = file_id

        for imp in parsed.imports:
            mod_id = f"module:{imp}"
            self._add_node(mod_id, kind="module", label=imp, external=True)
            self._add_edge(file_id, mod_id, relation="imports")

        for caller, callee in parsed.calls:
            if callee in BUILTIN_FUNCTIONS:
                continue
            
            # Use file context for caller
            caller_id = f"func:{file_id}:{caller}"
            
            # Resolve callee ID using global map or default to external
            target_file_id = self._function_to_file.get(callee)
            if target_file_id:
                callee_id = f"func:{target_file_id}:{callee}"
            else:
                callee_id = f"func:external:{callee}"
                if not self.graph.has_node(callee_id):
                    self._add_node(callee_id, kind="function", label=callee, external=True)
            
            self._add_edge(caller_id, callee_id, relation="calls")

    def add_asset(self, asset: ParsedAsset) -> None:
        self._assets.append(asset)
        filename = Path(asset.filepath).name
        node_id = f"{asset.kind}:{filename}"
        
        self._add_node(
            node_id, 
            kind=asset.kind, 
            label=filename, 
            filename=filename, # keep raw filename for linking
            external=False, 
            metadata=asset.metadata
        )

    def link_code_to_assets(self) -> None:
        """
        Connect code nodes to assets if the filename appears in:
        - function name
        - call list
        - string usage
        """
        for node_id, data in list(self.graph.nodes(data=True)):
            if data.get("kind") not in ("function", "method"):
                continue
            
            # Get function metadata from parsed files
            func_name = data.get("label")
            file_id = data.get("file")
            
            # Find the parsed file this function belongs to
            parsed = next((p for p in self._parsed_files if self._file_node_id(p.filepath) == file_id), None)
            if not parsed:
                continue

            # Check each asset
            for asset in self._assets:
                asset_filename = Path(asset.filepath).name
                asset_id = f"{asset.kind}:{asset_filename}"
                relation = "uses" if asset.kind in ("dataset", "database") else "references"
                
                # Check 1: function name
                if asset_filename in func_name:
                    self._add_edge(node_id, asset_id, relation=relation)
                    continue
                
                # Check 2: call list for this function
                calls = [c[1] for c in parsed.calls if c[0] == func_name]
                if any(asset_filename in callee for callee in calls):
                    self._add_edge(node_id, asset_id, relation=relation)
                    continue
                
                # Check 3: string usage
                strings = parsed.strings.get(func_name, [])
                if any(asset_filename in s for s in strings):
                    self._add_edge(node_id, asset_id, relation=relation)
                    continue

    def build(self, parsed_files: list[ParsedFile], assets: list[ParsedAsset] = None) -> nx.DiGraph:
        # First pass: add all files to populate function-to-file map
        for parsed in parsed_files:
            if not parsed.errors:
                self.add_file(parsed)
        
        # Second pass: add assets
        if assets:
            for asset in assets:
                self.add_asset(asset)
        
        # Third pass: link code to assets
        self.link_code_to_assets()
        
        return self.graph

    def summary(self) -> dict:
        nodes_by_kind = {}
        for _, data in self.graph.nodes(data=True):
            kind = data.get("kind", "unknown")
            nodes_by_kind[kind] = nodes_by_kind.get(kind, 0) + 1

        edges_by_relation = {}
        for _, _, data in self.graph.edges(data=True):
            rel = data.get("relation", "unknown")
            edges_by_relation[rel] = edges_by_relation.get(rel, 0) + 1

        return {
            "total_nodes": self.graph.number_of_nodes(),
            "total_edges": self.graph.number_of_edges(),
            "nodes_by_kind": nodes_by_kind,
            "edges_by_relation": edges_by_relation,
        }

    def to_dict(self) -> dict:
        return {
            "nodes": [{"id": node, **data} for node, data in self.graph.nodes(data=True)],
            "edges": [{"source": src, "target": dst, **data} for src, dst, data in self.graph.edges(data=True)],
        }

    def _file_node_id(self, filepath: str) -> str:
        return f"file:{Path(filepath).name}"

    def _add_node(self, node_id: str, **attrs) -> None:
        if not self.graph.has_node(node_id):
            self.graph.add_node(node_id, **attrs)

    def _add_edge(self, src: str, dst: str, **attrs) -> None:
        self.graph.add_edge(src, dst, **attrs)