# CodeGraph AI

**CodeGraph AI** is a CLI tool that analyzes your Python codebase and visualizes it as an interactive knowledge graph.

It helps developers understand:

* Code structure
* Function call relationships
* File dependencies
* Overall architecture

---

## Features

* AST-based parsing of Python code
* Function call graph generation
* Dependency graph (imports)
* Interactive visualization in browser
* Focus on specific files
* Hide external libraries (stdlib & third-party)
* Fast CLI-based workflow

---

## Installation

```bash
pip install codegraph-ai
```

---

## Quick Start

```bash
codegraph index
codegraph plot
```

---

## Commands

### 1. Index your codebase

Scan and build the graph:

```bash
codegraph index
```

Index a specific folder:

```bash
codegraph index path/to/your/project
```

---

### 2. Visualize the graph

```bash
codegraph plot
```

This opens an interactive graph in your browser.

---

## Advanced Usage

### Hide external libraries

Removes standard library and third-party dependencies from the graph:

```bash
codegraph plot --hide-external
```

---

### Focus on a specific file

Shows only a file and its direct relationships:

```bash
codegraph plot --focus cli.py
```

---

### Filter by node type

Show only certain types of nodes:

```bash
codegraph plot --level file
codegraph plot --level function
codegraph plot --level class
```

---

### Filter by edge type

Show only specific relationships:

```bash
codegraph plot --edge-type calls
codegraph plot --edge-type imports
codegraph plot --edge-type contains
codegraph plot --edge-type all
```

---

### Combine filters

```bash
codegraph plot --focus cli.py --hide-external --edge-type calls
```

---

## How It Works

1. Parses Python files using AST
2. Extracts:

   * Functions
   * Classes
   * Imports
   * Function calls
3. Builds a directed knowledge graph
4. Renders it as an interactive visualization

---

## Graph Semantics

### Node Types

| Type     | Description         |
| -------- | ------------------- |
| File     | Python file         |
| Function | Function or method  |
| Class    | Class definition    |
| Module   | External dependency |

---

### Edge Types

| Relation   | Meaning                         |
| ---------- | ------------------------------- |
| contains   | File/Class contains function    |
| calls      | Function calls another function |
| imports    | File imports module             |
| defined_in | Function belongs to file        |

---

## Output Files

After indexing:

```
.codegraph/graph.json
```

After visualization:

```
graph.html
```

---

## Example Workflow

```bash
codegraph index
codegraph plot --hide-external
```

---

## Use Cases

* Understand large codebases quickly
* Visualize architecture
* Debug dependencies
* Explore function interactions
* Prepare for refactoring

---

## Author

Aditya Jogdand

---

## License

MIT License
