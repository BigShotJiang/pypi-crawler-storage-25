# %%
import os
import json
import duckdb
from pathlib import Path
import typer
from loguru import logger
from single_cell_metabolomics.config import write_error_sentinel


# %%
class BasicStatsExecutor:
    def __init__(
            self,
            matrix_data_path: str,
            matrix_row_path: str,
            matrix_column_path: str,
            metadata_path: str,
        ):
        self.matrix_data_path = matrix_data_path
        self.matrix_row_path = matrix_row_path
        self.matrix_column_path = matrix_column_path
        self.metadata_path = metadata_path
        self.has_metadata = bool(metadata_path)

        self.conn = duckdb.connect(database=":memory:")
        self.conn.read_parquet(matrix_data_path).create('matrix_data')
        self.conn.read_csv(matrix_row_path, sep='\t').create('matrix_row')
        self.conn.read_csv(matrix_column_path, sep='\t').create('matrix_column')
        if self.has_metadata:
            self.conn.read_csv(metadata_path).create('metadata')

    def close(self) -> None:
        self.conn.close()

    def compute_stats(self) -> dict:
        """Compute all basic statistics from the matrix."""
        # Counts
        sample_count = int(self.conn.sql(
            'SELECT COUNT(DISTINCT col) FROM matrix_data'
        ).fetchone()[0])
        feature_count = int(self.conn.sql(
            'SELECT COUNT(DISTINCT row) FROM matrix_data'
        ).fetchone()[0])
        # NA = null or zero intensity
        na_count = int(self.conn.sql(
            'SELECT COUNT(*) FROM matrix_data WHERE value IS NULL OR value = 0'
        ).fetchone()[0])
        total_cells = sample_count * feature_count
        na_pct = round(na_count / total_cells * 100, 4) if total_cells > 0 else 0.0

        # Intensity summary (non-NA values only)
        intensity = self.conn.sql(
            'SELECT AVG(value), MEDIAN(value), MIN(value), MAX(value) '
            'FROM matrix_data WHERE value IS NOT NULL AND value != 0'
        ).fetchone()
        mean_intensity   = round(float(intensity[0]), 6) if intensity[0] is not None else 0.0
        median_intensity = round(float(intensity[1]), 6) if intensity[1] is not None else 0.0
        min_intensity    = round(float(intensity[2]), 6) if intensity[2] is not None else 0.0
        max_intensity    = round(float(intensity[3]), 6) if intensity[3] is not None else 0.0

        # Features per sample distribution
        features_per_sample = [
            int(row[0]) for row in self.conn.sql(
                'SELECT COUNT(DISTINCT row) FROM matrix_data '
                'WHERE value IS NOT NULL AND value != 0 '
                'GROUP BY col'
            ).fetchall()
        ]

        # Samples per feature distribution
        samples_per_feature = [
            int(row[0]) for row in self.conn.sql(
                'SELECT COUNT(DISTINCT col) FROM matrix_data '
                'WHERE value IS NOT NULL AND value != 0 '
                'GROUP BY row'
            ).fetchall()
        ]

        # Metadata summary — auto-detect categorical columns (≤ 100 unique values)
        metadata_summary = {}
        if self.has_metadata:
            columns = self.conn.sql('DESCRIBE metadata').fetchall()
            for col_info in columns:
                col_name = col_info[0]
                col_type = col_info[1].upper()
                # Skip obvious numeric types
                if any(t in col_type for t in ('INTEGER', 'BIGINT', 'DOUBLE', 'FLOAT', 'DECIMAL')):
                    continue
                unique_count = self.conn.sql(
                    f'SELECT COUNT(DISTINCT "{col_name}") FROM metadata'
                ).fetchone()[0]
                if unique_count <= 100:
                    rows = self.conn.sql(
                        f'SELECT "{col_name}", COUNT(*) FROM metadata GROUP BY "{col_name}"'
                    ).fetchall()
                    metadata_summary[col_name] = {str(r[0]): r[1] for r in rows}

        return {
            'counts': {
                'sample_count': sample_count,
                'feature_count': feature_count,
                'na_count': na_count,
                'na_pct': na_pct,
            },
            'intensity': {
                'mean': mean_intensity,
                'median': median_intensity,
                'min': min_intensity,
                'max': max_intensity,
            },
            'distributions': {
                'features_per_sample': features_per_sample,
                'samples_per_feature': samples_per_feature,
            },
            'metadata_summary': metadata_summary,
        }

    def emit_sentinel(
            self,
            serial_number: str,
            dataset_uid: int,
            analysis_id: int,
            storage_path: str,
            row_path: str,
            column_path: str,
            stats: dict,
        ) -> None:
        """Write basic_statistics_metadata.json and print sentinel to stdout."""
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(storage_path),
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path),
            **stats,
            'status': 'completed',
        }
        # Write to file (service reads this after Nextflow exits)
        metadata_path = Path('basic_statistics_metadata.json')
        metadata_path.write_text(json.dumps(sentinel, indent=2))
        logger.info(f"Wrote sentinel to {metadata_path.resolve()}")
        # Print to stdout for debugging (not parsed by service — Nextflow captures stdout)
        print(f'__BASIC_STATISTICS_METADATA_START__{json.dumps(sentinel)}__BASIC_STATISTICS_METADATA_END__')


# %%
app = typer.Typer(add_completion=False)

# %%
@app.command()
def basic_stats(
    serial_number: str = '',
    dataset_uid: int = 0,
    # --- analysis ID (required for sentinel) ---
    analysis_id: int = typer.Option(..., help="Analysis ID (100 for Single Cell, 200 for LCM)"),
    # --- input paths (infrastructure, not parameters) ---
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    metadata_path: str = '',
):
    """Compute basic statistics for the raw metabolomics matrix: counts, intensity summary, distributions, and metadata column breakdown."""
    try:
        executor = BasicStatsExecutor(
            matrix_data_path=parquet_path,
            matrix_row_path=row_path,
            matrix_column_path=column_path,
            metadata_path=metadata_path,
        )
        stats = executor.compute_stats()
        executor.emit_sentinel(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            storage_path=parquet_path,
            row_path=row_path,
            column_path=column_path,
            stats=stats,
        )
        executor.close()
        logger.success("Basic statistics complete.")
    except Exception as e:
        write_error_sentinel("basic_statistics_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise


# %%
@app.callback()
def callback():
    pass

# %%
if __name__ == '__main__':
    app()
