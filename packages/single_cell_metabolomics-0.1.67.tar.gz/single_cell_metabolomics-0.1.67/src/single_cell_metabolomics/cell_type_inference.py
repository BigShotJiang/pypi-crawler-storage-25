import os
import json
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from pathlib import Path
import typer
from loguru import logger
from single_cell_metabolomics.config import load_coo_parquet, write_error_sentinel


class CellTypeInferenceExecutor:
    """Infer cell types for SC cells by correlating against LCM reference profiles."""

    def __init__(
        self,
        sc_matrix_path: str,
        sc_row_path: str,
        sc_column_path: str,
        lcm_matrix_path: str,
        lcm_row_path: str,
        lcm_column_path: str,
        lcm_metadata_path: str,
    ):
        # Load SC matrix (sparse triplet → dense)
        self.sc_matrix, self.sc_samples, self.sc_features = load_coo_parquet(
            sc_matrix_path, sc_row_path, sc_column_path,
        )
        logger.info(f'SC matrix: {len(self.sc_samples)} cells × {len(self.sc_features)} features')

        # Load LCM matrix
        self.lcm_matrix, self.lcm_samples, self.lcm_features = load_coo_parquet(
            lcm_matrix_path, lcm_row_path, lcm_column_path,
        )
        logger.info(f'LCM matrix: {len(self.lcm_samples)} samples × {len(self.lcm_features)} features')

        # Load LCM metadata
        if lcm_metadata_path and os.path.exists(lcm_metadata_path):
            self.lcm_metadata = pd.read_csv(lcm_metadata_path, index_col=0)
        else:
            raise ValueError('LCM metadata is required for cell type inference')

    def build_lcm_reference(self, cell_type_column: str) -> tuple:
        """Build mean expression profiles per cell type from LCM data.

        Returns:
            cell_types: list of cell type names
            ref_profiles: numpy array (n_cell_types × n_common_features)
            common_features: list of feature names shared between SC and LCM
        """
        if cell_type_column not in self.lcm_metadata.columns:
            raise ValueError(
                f"Column '{cell_type_column}' not found in LCM metadata. "
                f"Available: {list(self.lcm_metadata.columns)}"
            )

        # Find common features between SC and LCM
        sc_feat_set = set(self.sc_features)
        lcm_feat_set = set(self.lcm_features)
        common = sorted(sc_feat_set & lcm_feat_set)
        if len(common) == 0:
            raise ValueError('No common features between SC and LCM datasets')
        logger.info(f'Common features: {len(common)} (SC: {len(self.sc_features)}, LCM: {len(self.lcm_features)})')

        # Build indices for common features
        sc_feat_idx = [self.sc_features.index(f) for f in common]
        lcm_feat_idx = [self.lcm_features.index(f) for f in common]

        # Get cell type labels per LCM sample
        labels = []
        for sample in self.lcm_samples:
            if sample in self.lcm_metadata.index:
                labels.append(str(self.lcm_metadata.loc[sample, cell_type_column]))
            else:
                labels.append('unknown')

        cell_types = sorted(set(labels) - {'unknown'})
        if len(cell_types) == 0:
            raise ValueError('No valid cell type labels found in LCM metadata')

        # Compute mean expression per cell type (on common features)
        lcm_common = self.lcm_matrix[:, lcm_feat_idx]
        ref_profiles = np.zeros((len(cell_types), len(common)))
        for i, ct in enumerate(cell_types):
            mask = [j for j, l in enumerate(labels) if l == ct]
            if mask:
                ref_profiles[i] = np.mean(lcm_common[mask], axis=0)

        logger.info(f'Cell types: {cell_types} (from {len(self.lcm_samples)} LCM samples)')

        # Store SC common-feature matrix for correlation
        self._sc_common = self.sc_matrix[:, sc_feat_idx]
        self._common_features = common

        return cell_types, ref_profiles

    def compute_correlations(
        self, cell_types: list, ref_profiles: np.ndarray, method: str = 'Pearson'
    ) -> np.ndarray:
        """Compute correlation between each SC cell and each LCM cell-type profile.

        Returns:
            corr_matrix: numpy array (n_sc_cells × n_cell_types)
        """
        from scipy import stats
        from sklearn.metrics.pairwise import cosine_similarity

        n_cells = self._sc_common.shape[0]
        n_types = len(cell_types)
        corr_matrix = np.zeros((n_cells, n_types))

        if method == 'Cosine':
            corr_matrix = cosine_similarity(self._sc_common, ref_profiles)
        else:
            for i in range(n_cells):
                cell_expr = self._sc_common[i]
                for j in range(n_types):
                    ref_expr = ref_profiles[j]
                    if method == 'Pearson':
                        r, _ = stats.pearsonr(cell_expr, ref_expr)
                    elif method == 'Spearman':
                        r, _ = stats.spearmanr(cell_expr, ref_expr)
                    else:
                        raise ValueError(f'Unknown correlation method: {method}')
                    corr_matrix[i, j] = r if np.isfinite(r) else 0.0

        logger.info(f'Computed {method} correlation: {n_cells} cells × {n_types} types')
        return corr_matrix

    def assign_cell_types(
        self, cell_types: list, corr_matrix: np.ndarray
    ) -> tuple:
        """Assign inferred cell type per cell (highest correlation).

        Returns:
            inferred_types: list of cell type strings
            best_scores: list of best correlation values
        """
        best_idx = np.argmax(corr_matrix, axis=1)
        inferred_types = [cell_types[i] for i in best_idx]
        best_scores = corr_matrix[np.arange(corr_matrix.shape[0]), best_idx].tolist()
        return inferred_types, best_scores

    def build_cluster_composition(
        self, cluster_labels: dict, inferred_types: list
    ) -> dict:
        """Build per-cluster cell type composition for pie charts.

        Args:
            cluster_labels: dict mapping cell_name → cluster_id
            inferred_types: list of inferred types (aligned with self.sc_samples)

        Returns:
            dict: cluster_id → {cell_type: count}
        """
        composition = {}
        for i, cell_name in enumerate(self.sc_samples):
            cluster = str(cluster_labels.get(cell_name, 'unknown'))
            cell_type = inferred_types[i]
            if cluster not in composition:
                composition[cluster] = {}
            composition[cluster][cell_type] = composition[cluster].get(cell_type, 0) + 1
        return composition


app = typer.Typer(add_completion=False)


@app.command()
def infer(
    serial_number: str = '',
    dataset_uid: int = 0,
    analysis_id: int = typer.Option(109, help='109 (Cell Type Inference)'),
    sc_parquet_path: str = typer.Option(..., help='SC normalized matrix parquet'),
    sc_row_path: str = typer.Option(..., help='SC row feature names TSV'),
    sc_column_path: str = typer.Option(..., help='SC column sample names TSV'),
    sc_cluster_path: str = typer.Option('', help='SC cluster labels parquet'),
    sc_embedding_path: str = typer.Option('', help='SC DR embedding parquet'),
    lcm_parquet_path: str = typer.Option(..., help='LCM normalized matrix parquet'),
    lcm_row_path: str = typer.Option(..., help='LCM row feature names TSV'),
    lcm_column_path: str = typer.Option(..., help='LCM column sample names TSV'),
    lcm_metadata_path: str = typer.Option(..., help='LCM metadata CSV'),
    lcm_cell_type_column: str = typer.Option(..., help='Metadata column with cell type labels'),
    correlation_method: str = typer.Option('Pearson', help='Pearson, Spearman, or Cosine'),
    output_parquet: str = typer.Option('cell_type_inference.parquet', help='Output parquet'),
    output_sentinel: str = typer.Option('cell_type_inference_metadata.json', help='Output sentinel'),
):
    """Infer cell types for SC cells by correlating against LCM reference profiles."""
    try:
        # 1. Load data
        executor = CellTypeInferenceExecutor(
            sc_matrix_path=sc_parquet_path,
            sc_row_path=sc_row_path,
            sc_column_path=sc_column_path,
            lcm_matrix_path=lcm_parquet_path,
            lcm_row_path=lcm_row_path,
            lcm_column_path=lcm_column_path,
            lcm_metadata_path=lcm_metadata_path,
        )

        # 2. Build LCM reference profiles
        cell_types, ref_profiles = executor.build_lcm_reference(lcm_cell_type_column)

        # 3. Compute per-cell correlations
        corr_matrix = executor.compute_correlations(cell_types, ref_profiles, correlation_method)

        # 4. Assign cell types
        inferred_types, best_scores = executor.assign_cell_types(cell_types, corr_matrix)

        # 5. Load cluster labels
        cluster_labels = {}
        if sc_cluster_path and os.path.exists(sc_cluster_path):
            cluster_df = pd.read_parquet(sc_cluster_path)
            # Cluster parquet has cell_name + cluster columns
            if 'cell_name' in cluster_df.columns:
                label_col = [c for c in cluster_df.columns if c != 'cell_name'][0]
                cluster_labels = dict(zip(
                    cluster_df['cell_name'].astype(str),
                    cluster_df[label_col].astype(str)
                ))
            elif len(cluster_df.columns) >= 2:
                cluster_labels = dict(zip(
                    cluster_df.iloc[:, 0].astype(str),
                    cluster_df.iloc[:, 1].astype(str)
                ))

        # 6. Build cluster composition
        cluster_composition = executor.build_cluster_composition(cluster_labels, inferred_types)

        # 7. Load DR embedding for scatter plots
        embedding = []
        if sc_embedding_path and os.path.exists(sc_embedding_path):
            emb_df = pd.read_parquet(sc_embedding_path)
            if 'component_1' in emb_df.columns and 'component_2' in emb_df.columns:
                embedding = [[float(r['component_1']), float(r['component_2'])] for _, r in emb_df.iterrows()]

        # 8. Build inference table for sentinel
        inference_table = []
        for i, cell_name in enumerate(executor.sc_samples):
            scores_dict = {ct: round(float(corr_matrix[i, j]), 4) for j, ct in enumerate(cell_types)}
            inference_table.append({
                'cell_name': cell_name,
                'inferred_type': inferred_types[i],
                'best_score': round(best_scores[i], 4),
                'scores': scores_dict,
            })

        # 9. Build summary
        from collections import Counter
        type_counts = dict(Counter(inferred_types))
        summary = {
            'total_cells': len(executor.sc_samples),
            'cell_type_counts': type_counts,
            'n_cell_types': len(cell_types),
        }

        # 10. Write output parquet
        out_data = {
            'cell_name': executor.sc_samples,
            'inferred_type': inferred_types,
            'best_score': best_scores,
        }
        for j, ct in enumerate(cell_types):
            out_data[f'{ct}_corr'] = corr_matrix[:, j].tolist()
        pd.DataFrame(out_data).to_parquet(output_parquet, index=False)
        logger.info(f'Wrote inference parquet to {output_parquet}')

        # 11. Build per-cell-type correlation arrays for scatter plots
        per_type_correlations = {}
        for j, ct in enumerate(cell_types):
            per_type_correlations[ct] = corr_matrix[:, j].tolist()

        # 12. Write sentinel
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(output_parquet),
            'row_path': os.path.abspath(sc_row_path),
            'column_path': os.path.abspath(sc_column_path),
            'correlation_method': correlation_method,
            'cell_types': cell_types,
            'inference_table': inference_table,
            'cluster_composition': cluster_composition,
            'embedding': embedding,
            'cell_names': executor.sc_samples,
            'inferred_types': inferred_types,
            'per_type_correlations': per_type_correlations,
            'summary': summary,
            'status': 'completed',
        }

        metadata_file = Path(output_sentinel)
        metadata_file.write_text(json.dumps(sentinel, indent=2))
        logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
        print(
            f'__CELL_TYPE_INFERENCE_METADATA_START__{json.dumps(sentinel)}'
            f'__CELL_TYPE_INFERENCE_METADATA_END__'
        )
        logger.success(
            f'Cell type inference complete: {len(executor.sc_samples)} cells, '
            f'{len(cell_types)} types ({", ".join(cell_types)})'
        )
    except Exception as e:
        write_error_sentinel("cell_type_inference_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
