import json
import os
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path
import typer
from loguru import logger
from single_cell_metabolomics.config import load_coo_parquet, write_error_sentinel, intersect_metadata

app = typer.Typer(add_completion=False)


class BatchCorrectionExecutor:
    def __init__(
        self,
        matrix_data_path: str,
        matrix_row_path: str,
        matrix_column_path: str,
        metadata_path: str,
    ):
        import anndata as ad

        X, self.sample_names, self.feature_names = load_coo_parquet(
            matrix_data_path, matrix_row_path, matrix_column_path,
        )
        self.adata = ad.AnnData(
            X=X,
            obs=pd.DataFrame(index=self.sample_names),
            var=pd.DataFrame(index=self.feature_names),
        )

        self.metadata_df = None
        if metadata_path and os.path.exists(metadata_path):
            self.metadata_df = pd.read_csv(metadata_path, index_col=0)

        # Intersect matrix samples with metadata rows
        self.sample_names, self.metadata_df, X_subset = intersect_metadata(
            self.sample_names, self.metadata_df, self.adata.X,
        )
        if X_subset is not None:
            self.adata = ad.AnnData(
                X=X_subset,
                obs=pd.DataFrame(index=self.sample_names),
                var=pd.DataFrame(index=self.feature_names),
            )

        # Fixed downsampled cell indices — same for before/after PCA to ensure fair comparison
        rng = np.random.default_rng(42)
        n_cells = min(1000, self.adata.n_obs)
        self._cell_idx = sorted(rng.choice(self.adata.n_obs, n_cells, replace=False).tolist())
        self._cell_names = [self.sample_names[i] for i in self._cell_idx]

        # Populated by compute_pca_before / compute_pca_after
        self._pca_before: list = []
        self._pca_after: list = []
        self._pca_variance_ratio_before: list = []
        self._pca_variance_ratio_after: list = []

    def _get_labels(self, column: str) -> list:
        """Return per-cell labels for the fixed sampled cells from a metadata column."""
        if not column or self.metadata_df is None or column not in self.metadata_df.columns:
            return [None] * len(self._cell_names)
        return [
            str(self.metadata_df.loc[name, column])
            if name in self.metadata_df.index else None
            for name in self._cell_names
        ]

    def _pca_points_and_variance(self, X_sub: np.ndarray) -> tuple[list, list]:
        """Run PCA on a (n_cells × n_vars) dense array; return [[pc1,pc2],...] and variance ratios."""
        import scanpy as sc
        import anndata as ad

        adata_sub = ad.AnnData(X=X_sub.astype(np.float64))
        n_comps = min(2, adata_sub.n_obs - 1, adata_sub.n_vars - 1)
        sc.pp.pca(adata_sub, n_comps=max(n_comps, 2))

        pc1 = adata_sub.obsm['X_pca'][:, 0].tolist()
        pc2 = adata_sub.obsm['X_pca'][:, 1].tolist()
        variance_ratio = adata_sub.uns['pca']['variance_ratio'][:2].tolist()
        points = [[x, y] for x, y in zip(pc1, pc2)]
        return points, variance_ratio

    def compute_pca_before(self) -> None:
        """Capture PCA of the normalized (pre-correction) matrix on fixed sampled cells."""
        X_sub = self.adata.X[self._cell_idx, :]
        self._pca_before, self._pca_variance_ratio_before = self._pca_points_and_variance(X_sub)

    def correct_combat(self, batch_column: str, parametric: bool = True) -> None:
        """Apply ComBat batch correction directly to the expression matrix.

        Note: scanpy's combat() always uses parametric empirical Bayes estimation.
        The ``parametric`` flag is accepted for API compatibility but non-parametric
        mode is not supported by the underlying scanpy implementation.
        """
        import scanpy as sc

        if self.metadata_df is None or batch_column not in self.metadata_df.columns:
            raise ValueError(f"Batch column '{batch_column}' not found in metadata")

        if not parametric:
            logger.warning(
                "scanpy's ComBat implementation only supports parametric mode; "
                "ignoring combat_mode='non-parametric' and proceeding with parametric estimation."
            )

        batch_series = self.metadata_df[batch_column].reindex(self.sample_names)
        self.adata.obs['batch'] = batch_series.values
        sc.pp.combat(self.adata, key='batch')

    def correct_harmony(self, batch_column: str, theta: float = 2.0) -> None:
        """Apply Harmony batch correction: correct PCA embedding, reconstruct expression matrix."""
        import harmonypy
        import scanpy as sc

        if self.metadata_df is None or batch_column not in self.metadata_df.columns:
            raise ValueError(f"Batch column '{batch_column}' not found in metadata")

        batch_series = self.metadata_df[batch_column].reindex(self.sample_names)
        self.adata.obs['batch'] = batch_series.values

        # PCA before harmony (operates on the embedding)
        n_comps = min(50, self.adata.n_vars - 1, self.adata.n_obs - 1)
        mean = np.mean(self.adata.X, axis=0)
        sc.pp.pca(self.adata, n_comps=n_comps)

        # Run Harmony to correct the PCA embedding
        meta = pd.DataFrame({'batch': self.adata.obs['batch'].values})
        harmony_out = harmonypy.run_harmony(
            self.adata.obsm['X_pca'],
            meta,
            'batch',
            theta=theta,
            random_state=42,
        )
        Z_corr_T = harmony_out.Z_corr.T  # (n_obs, n_comps)
        pca_loadings = self.adata.varm['PCs'][:, :n_comps]  # (n_vars, n_comps)

        # Reconstruct expression: X ≈ Z_harmony @ PCs^T + mean
        self.adata.X = Z_corr_T @ pca_loadings.T + mean

    def correct_limma(self, batch_column: str, covariates_column: str = '') -> None:
        """Apply limma-style batch correction: OLS fit on batch design, subtract batch effect."""
        if self.metadata_df is None or batch_column not in self.metadata_df.columns:
            raise ValueError(f"Batch column '{batch_column}' not found in metadata")

        batch_series = self.metadata_df[batch_column].reindex(self.sample_names)
        batch_values = batch_series.fillna('unknown').astype(str).values

        # One-hot encode batch categories
        batch_categories = np.unique(batch_values)
        n_obs = len(batch_values)
        n_batch = len(batch_categories)
        batch_matrix = np.zeros((n_obs, n_batch))
        for i, cat in enumerate(batch_categories):
            batch_matrix[:, i] = (batch_values == cat).astype(float)

        # Optionally add covariate column
        design = batch_matrix
        if covariates_column and self.metadata_df is not None and covariates_column in self.metadata_df.columns:
            cov_vals = (
                self.metadata_df[covariates_column]
                .reindex(self.sample_names)
                .fillna(0)
                .values
                .reshape(-1, 1)
                .astype(float)
            )
            design = np.hstack([batch_matrix, cov_vals])

        X = self.adata.X
        grand_mean = np.mean(X, axis=0)

        # Solve X ~ design; extract batch coefficient block
        coef, _, _, _ = np.linalg.lstsq(design, X, rcond=None)
        batch_effect = batch_matrix @ coef[:n_batch, :]

        # Remove batch effect, restore grand mean so absolute scale is preserved
        self.adata.X = X - batch_effect + grand_mean

    def compute_pca_after(self) -> None:
        """Capture PCA of the corrected matrix on the same fixed sampled cells."""
        X_sub = self.adata.X[self._cell_idx, :]
        self._pca_after, self._pca_variance_ratio_after = self._pca_points_and_variance(X_sub)

    def write_corrected_parquet(self, output_path: str) -> None:
        X = self.adata.X
        # Batch-corrected values can be negative → use np.isfinite to keep all real values
        rows_idx, cols_idx = np.where(np.isfinite(X))
        out_df = pd.DataFrame({
            'row': [self.feature_names[c] for c in cols_idx],
            'col': [self.sample_names[r] for r in rows_idx],
            'value': X[rows_idx, cols_idx].astype(np.float64),
        })
        pq.write_table(
            pa.Table.from_pandas(out_df, preserve_index=False),
            output_path,
        )
        logger.info(f'Wrote corrected parquet to {output_path}')

    def write_tsv_files(self, row_path: str, column_path: str) -> None:
        pd.Series(self.feature_names).to_csv(row_path, sep='\t', index=False, header=False)
        pd.Series(self.sample_names).to_csv(column_path, sep='\t', index=False, header=False)
        logger.info(f'Wrote row TSV to {row_path}, column TSV to {column_path}')

    def emit_sentinel(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        row_path: str,
        column_path: str,
        batch_column: str,
        bio_color_label: str,
    ) -> None:
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(storage_path),
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path),
            'pca_before': self._pca_before,
            'pca_after': self._pca_after,
            'pca_variance_ratio_before': self._pca_variance_ratio_before,
            'pca_variance_ratio_after': self._pca_variance_ratio_after,
            'batch_labels': self._get_labels(batch_column),
            'bio_labels': self._get_labels(bio_color_label),
            'status': 'completed',
        }
        metadata_file = Path('batch_correction_metadata.json')
        metadata_file.write_text(json.dumps(sentinel, indent=2))
        logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
        print(
            f'__BATCH_CORRECTION_METADATA_START__{json.dumps(sentinel)}'
            f'__BATCH_CORRECTION_METADATA_END__'
        )


@app.command()
def batch_correct(
    serial_number: str = '',
    dataset_uid: int = 0,
    # --- input paths (infrastructure, not parameters) ---
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    metadata_path: str = '',
    # --- analysis ID (required for sentinel) ---
    analysis_id: int = typer.Option(..., help="Analysis ID (103 for SC, 203 for LCM)"),
    # --- analysis parameters (match analysisParameterConfig.js parameterName in snake_case) ---
    batch_correction_method: str = 'ComBat',
    batch_column: str = '',
    combat_mode: str = 'parametric',
    theta: float = 2.0,
    covariates_column: str = '',
    bio_color_label: str = '',
    # --- output paths ---
    output_parquet_path: str = 'batch_corrected.parquet',
    output_row_path: str = 'row_feature_names.tsv',
    output_column_path: str = 'column_sample_names.tsv',
):
    """Apply batch correction (ComBat, Harmony, or limma) to a normalized single-cell metabolomics matrix."""
    try:
        executor = BatchCorrectionExecutor(
            matrix_data_path=parquet_path,
            matrix_row_path=row_path,
            matrix_column_path=column_path,
            metadata_path=metadata_path,
        )

        executor.compute_pca_before()

        if batch_correction_method == 'ComBat':
            executor.correct_combat(
                batch_column=batch_column,
                parametric=(combat_mode == 'parametric'),
            )
        elif batch_correction_method == 'Harmony':
            executor.correct_harmony(batch_column=batch_column, theta=theta)
        elif batch_correction_method == 'limma':
            executor.correct_limma(
                batch_column=batch_column,
                covariates_column=covariates_column,
            )
        else:
            raise ValueError(f"Unknown batch correction method: '{batch_correction_method}'")

        executor.compute_pca_after()
        executor.write_corrected_parquet(output_parquet_path)
        executor.write_tsv_files(output_row_path, output_column_path)

        executor.emit_sentinel(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            storage_path=output_parquet_path,
            row_path=output_row_path,
            column_path=output_column_path,
            batch_column=batch_column,
            bio_color_label=bio_color_label,
        )
        logger.success('Batch correction complete.')
    except Exception as e:
        write_error_sentinel("batch_correction_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
