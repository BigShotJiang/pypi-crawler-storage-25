import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import typer
from loguru import logger
from single_cell_metabolomics.config import load_coo_parquet, write_error_sentinel, intersect_metadata

app = typer.Typer(add_completion=False)


class DifferentialAbundanceExecutor:
    def __init__(
        self,
        parquet_path: str,
        row_path: str,
        column_path: str,
        metadata_path: str,
        cluster_labels_path: str,
    ):
        # Load intensity matrix
        self.X, self.sample_names, self.feature_names = load_coo_parquet(
            parquet_path, row_path, column_path,
        )

        # Load metadata
        self.metadata_df = None
        if metadata_path and os.path.exists(metadata_path):
            self.metadata_df = pd.read_csv(metadata_path, index_col=0)

        # Intersect matrix samples with metadata rows
        self.sample_names, self.metadata_df, self.X = intersect_metadata(
            self.sample_names, self.metadata_df, self.X,
        )

        # Load cluster labels
        self.cluster_labels = None
        if cluster_labels_path and os.path.exists(cluster_labels_path):
            cl_df = pd.read_parquet(cluster_labels_path)
            cl_map = dict(zip(cl_df['cell_name'], cl_df['cluster']))
            self.cluster_labels = [cl_map.get(name, 'unknown') for name in self.sample_names]

    def _resolve_group_labels(self, group_by: str) -> pd.Series:
        """Return a Series of group labels aligned to self.sample_names."""
        if group_by == 'cluster':
            if self.cluster_labels is None:
                raise ValueError(
                    "cluster_labels_path not provided or missing, but group_by='cluster'"
                )
            return pd.Series(self.cluster_labels, name='cluster')
        else:
            if self.metadata_df is None or group_by not in self.metadata_df.columns:
                raise ValueError(
                    f"group_by column '{group_by}' not found in metadata"
                )
            return self.metadata_df.reindex(self.sample_names)[group_by].astype(str)

    def run_rank_genes_groups(
        self, test_method: str, group_by: str, reference: str
    ) -> tuple[list, dict]:
        """Run scanpy rank_genes_groups for wilcoxon / t-test / logreg."""
        import anndata as ad
        import scanpy as sc

        labels = self._resolve_group_labels(group_by)
        adata = ad.AnnData(X=self.X.astype(np.float32))
        adata.obs['group'] = labels.values
        adata.var_names = [str(f) for f in self.feature_names]

        groups_list = sorted(adata.obs['group'].unique().tolist())

        sc.tl.rank_genes_groups(
            adata,
            groupby='group',
            method=test_method,
            reference=reference,
        )

        results_by_group = {}
        for g in groups_list:
            df = sc.get.rank_genes_groups_df(adata, group=g)
            # Sort by abs(scores) descending
            df = df.iloc[df['scores'].abs().argsort()[::-1].values]
            results_by_group[str(g)] = {
                'names': df['names'].tolist(),
                'scores': [float(v) for v in df['scores']],
                'logfoldchanges': [float(v) for v in df['logfoldchanges']],
                'pvals': [float(v) for v in df['pvals']],
                'pvals_adj': [float(v) for v in df['pvals_adj']],
            }

        return [str(g) for g in groups_list], results_by_group

    def run_anova(self, group_by: str) -> tuple[list, dict]:
        """Run one-way ANOVA (scipy) per feature with BH FDR correction."""
        from scipy.stats import f_oneway
        from statsmodels.stats.multitest import multipletests

        labels = self._resolve_group_labels(group_by)
        label_arr = np.array(labels.values)
        groups_list = sorted(np.unique(label_arr).tolist())

        n_features = self.X.shape[1]
        f_stats = np.zeros(n_features)
        p_vals = np.zeros(n_features)

        for j in range(n_features):
            groups_data = [self.X[label_arr == g, j] for g in groups_list]
            result = f_oneway(*groups_data)
            f_stats[j] = result.statistic if not np.isnan(result.statistic) else 0.0
            p_vals[j] = result.pvalue if not np.isnan(result.pvalue) else 1.0

        _, p_adj, _, _ = multipletests(p_vals, method='fdr_bh')

        # Sort by F-statistic descending
        order = np.argsort(f_stats)[::-1]
        feature_names_sorted = [str(self.feature_names[i]) for i in order]

        results_by_group = {
            'ANOVA': {
                'names': feature_names_sorted,
                'scores': f_stats[order].tolist(),
                'logfoldchanges': None,
                'pvals': p_vals[order].tolist(),
                'pvals_adj': p_adj[order].tolist(),
            }
        }

        return ['ANOVA'], results_by_group

    def write_output_files(
        self,
        results_by_group: dict,
        output_parquet_path: str,
        output_row_path: str,
        output_column_path: str,
    ) -> None:
        """Write results parquet and row/column TSV files."""
        rows = []
        for g, data in results_by_group.items():
            names = data['names']
            scores = data['scores']
            logfcs = data['logfoldchanges']
            pvals = data['pvals']
            pvals_adj = data['pvals_adj']
            for i, name in enumerate(names):
                rows.append({
                    'group': g,
                    'name': name,
                    'score': scores[i],
                    'logfoldchange': logfcs[i] if logfcs is not None else None,
                    'pval': pvals[i],
                    'pval_adj': pvals_adj[i],
                })

        out_df = pd.DataFrame(rows)
        pq.write_table(
            pa.Table.from_pandas(out_df, preserve_index=False),
            output_parquet_path,
        )

        pd.Series(self.feature_names).to_csv(output_row_path, sep='\t', index=False, header=False)
        pd.Series(self.sample_names).to_csv(output_column_path, sep='\t', index=False, header=False)
        logger.info(f'Wrote output parquet to {output_parquet_path}')

    def emit_sentinel(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        output_parquet_path: str,
        output_row_path: str,
        output_column_path: str,
        test_method: str,
        group_by: str,
        reference: str,
        groups_list: list,
        results_by_group: dict,
        n_top_features: int,
    ) -> None:
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(output_parquet_path),
            'row_path': os.path.abspath(output_row_path),
            'column_path': os.path.abspath(output_column_path),
            'status': 'completed',
            'test_method': test_method,
            'group_by': group_by,
            'reference': reference,
            'groups': groups_list,
            'results_by_group': results_by_group,
            'n_top_features': n_top_features,
        }
        metadata_file = Path('differential_abundance_metadata.json')
        metadata_file.write_text(json.dumps(sentinel, indent=2))
        logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
        print(
            f'__DIFF_ABUNDANCE_METADATA_START__{json.dumps(sentinel)}'
            f'__DIFF_ABUNDANCE_METADATA_END__'
        )


@app.command()
def analyze(
    serial_number: str = '',
    dataset_uid: int = 0,
    # --- input paths (infrastructure, not parameters) ---
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    metadata_path: str = '',
    cluster_labels_path: str = '',
    # --- analysis ID (required for sentinel) ---
    analysis_id: int = typer.Option(..., help='Analysis ID (107 for SC differential abundance)'),
    # --- analysis parameters ---
    test_method: str = 'wilcoxon',
    group_by: str = 'cluster',
    reference: str = 'rest',
    n_top_features: int = 50,
    # --- output paths ---
    output_parquet_path: str = 'differential_abundance.parquet',
    output_row_path: str = 'row_feature_names.tsv',
    output_column_path: str = 'column_sample_names.tsv',
):
    """Run differential abundance analysis on a single-cell metabolomics matrix."""
    try:
        logger.info(
            f'differential_abundance analyze: serial={serial_number} dataset={dataset_uid} '
            f'method={test_method} group_by={group_by} reference={reference} '
            f'n_top_features={n_top_features}'
        )

        executor = DifferentialAbundanceExecutor(
            parquet_path=parquet_path,
            row_path=row_path,
            column_path=column_path,
            metadata_path=metadata_path,
            cluster_labels_path=cluster_labels_path,
        )

        if test_method == 'ANOVA':
            groups_list, results_by_group = executor.run_anova(group_by=group_by)
        else:
            groups_list, results_by_group = executor.run_rank_genes_groups(
                test_method=test_method,
                group_by=group_by,
                reference=reference,
            )

        executor.write_output_files(
            results_by_group=results_by_group,
            output_parquet_path=output_parquet_path,
            output_row_path=output_row_path,
            output_column_path=output_column_path,
        )

        executor.emit_sentinel(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            output_parquet_path=output_parquet_path,
            output_row_path=output_row_path,
            output_column_path=output_column_path,
            test_method=test_method,
            group_by=group_by,
            reference=reference,
            groups_list=groups_list,
            results_by_group=results_by_group,
            n_top_features=n_top_features,
        )
        logger.success('Differential abundance analysis complete.')
    except Exception as e:
        write_error_sentinel("differential_abundance_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
