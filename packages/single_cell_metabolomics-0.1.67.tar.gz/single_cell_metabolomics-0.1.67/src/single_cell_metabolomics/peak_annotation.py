import os
import json
import numpy as np
import pandas as pd
from pathlib import Path
import typer
from loguru import logger
from single_cell_metabolomics.config import write_error_sentinel


def match_peaks(
    features_df: pd.DataFrame,
    dda_df: pd.DataFrame,
    tolerance_unit: str,
    tolerance_value: float,
    keep_best_only: bool,
    score_threshold: float,
) -> pd.DataFrame:
    """Match features to DDA/DIA compound identities by m/z + mode.

    Args:
        features_df: DataFrame with columns: mode, mass, index
        dda_df: DataFrame with columns: compound_name, precursor_mz, mode
        tolerance_unit: 'ppm' or 'Da'
        tolerance_value: matching tolerance
        keep_best_only: if True, keep only best-scoring match per feature (ties kept)
        score_threshold: minimum similarity score (0-1) to include

    Returns:
        DataFrame with columns: mode, mass, index, compound_name, score, delta_mz
        One row per match (features with no match get one row with null compound_name)
    """
    results = []

    for _, feat in features_df.iterrows():
        feat_mode = str(feat['mode']).strip().lower()
        feat_mass = float(feat['mass'])
        feat_index = int(feat['index'])

        # Filter DDA by matching mode
        dda_mode_match = dda_df[dda_df['mode'].str.strip().str.lower() == feat_mode]

        matches = []
        for _, compound in dda_mode_match.iterrows():
            compound_mz = float(compound['precursor_mz'])
            delta = abs(feat_mass - compound_mz)

            # Check tolerance
            if tolerance_unit == 'ppm':
                delta_units = (delta / compound_mz) * 1e6 if compound_mz > 0 else float('inf')
                within = delta_units < tolerance_value
            else:  # Da
                delta_units = delta
                within = delta < tolerance_value

            if not within:
                continue

            # Compute score: 1 - (delta_in_units / tolerance)
            score = 1.0 - (delta_units / tolerance_value)
            score = max(0.0, min(1.0, score))

            if score < score_threshold:
                continue

            matches.append({
                'mode': feat['mode'],
                'mass': feat_mass,
                'index': feat_index,
                'compound_name': str(compound['compound_name']),
                'score': round(score, 6),
                'delta_mz': round(delta, 6),
            })

        if not matches:
            results.append({
                'mode': feat['mode'],
                'mass': feat_mass,
                'index': feat_index,
                'compound_name': None,
                'score': None,
                'delta_mz': None,
            })
        else:
            if keep_best_only:
                max_score = max(m['score'] for m in matches)
                matches = [m for m in matches if m['score'] == max_score]
            results.extend(matches)

    return pd.DataFrame(results)


def build_enriched_row_tsv(
    features_df: pd.DataFrame,
    annotation_df: pd.DataFrame,
) -> pd.DataFrame:
    """Build enriched row TSV with compound_name column.

    Multiple matches per feature are joined with ';'.
    Unannotated features get empty string.
    """
    # Group compound names by feature index
    name_map = {}
    for _, row in annotation_df.iterrows():
        idx = int(row['index'])
        name = row['compound_name']
        if name is not None and pd.notna(name):
            name_map.setdefault(idx, []).append(str(name))

    enriched = features_df.copy()
    enriched['compound_name'] = enriched['index'].apply(
        lambda i: ';'.join(name_map.get(int(i), []))
    )
    return enriched


app = typer.Typer(add_completion=False)


@app.command()
def annotate(
    serial_number: str = '',
    dataset_uid: int = 0,
    analysis_id: int = typer.Option(..., help='108 (Single Cell) or 207 (LCM)'),
    row_path: str = typer.Option(..., help='Path to row_feature_names.tsv'),
    column_path: str = typer.Option('', help='Path to column_sample_names.tsv (passed through)'),
    dda_table_path: str = typer.Option(..., help='Path to user-uploaded DDA/DIA table (CSV/TSV)'),
    tolerance_unit: str = typer.Option('ppm', help='ppm or Da'),
    tolerance_value: float = typer.Option(10.0, help='m/z matching tolerance'),
    keep_best_only: bool = typer.Option(True, help='Keep only best-scoring match per feature'),
    score_threshold: float = typer.Option(0.0, help='Minimum similarity score (0-1)'),
    output_row_path: str = typer.Option('annotated_row_feature_names.tsv', help='Output enriched row TSV'),
    output_sentinel: str = typer.Option('peak_annotation_metadata.json', help='Output sentinel JSON'),
):
    """Annotate features (peaks) by matching m/z against a DDA/DIA identification table."""
    try:
        # 1. Load feature list
        features_df = pd.read_csv(row_path, sep='\t')
        logger.info(f'Loaded {len(features_df)} features from {row_path}')

        # 2. Load DDA/DIA table (detect format by extension)
        if dda_table_path.lower().endswith('.tsv'):
            dda_df = pd.read_csv(dda_table_path, sep='\t')
        else:
            dda_df = pd.read_csv(dda_table_path)

        # Validate required columns
        required_cols = {'compound_name', 'precursor_mz', 'mode'}
        missing = required_cols - set(dda_df.columns)
        if missing:
            raise ValueError(
                f"DDA/DIA table missing required columns: {missing}. "
                f"Required: compound_name, precursor_mz, mode"
            )
        logger.info(f'Loaded {len(dda_df)} DDA entries from {dda_table_path}')

        # 3. Match peaks
        annotation_df = match_peaks(
            features_df=features_df,
            dda_df=dda_df,
            tolerance_unit=tolerance_unit,
            tolerance_value=tolerance_value,
            keep_best_only=keep_best_only,
            score_threshold=score_threshold,
        )

        # 4. Build enriched row TSV
        enriched_df = build_enriched_row_tsv(features_df, annotation_df)
        enriched_df.to_csv(output_row_path, sep='\t', index=False)
        logger.info(f'Wrote enriched row TSV to {output_row_path}')

        # 5. Compute summary
        total_features = len(features_df)
        annotated_indices = set(
            int(row['index']) for _, row in annotation_df.iterrows()
            if row['compound_name'] is not None and pd.notna(row['compound_name'])
        )
        annotated_features = len(annotated_indices)
        annotation_rate = round(annotated_features / total_features, 4) if total_features > 0 else 0.0

        # 6. Build annotation table for sentinel
        annotation_table = []
        for _, row in annotation_df.iterrows():
            annotation_table.append({
                'mode': row['mode'],
                'mass': row['mass'],
                'compound_name': row['compound_name'] if pd.notna(row['compound_name']) else None,
                'score': float(row['score']) if pd.notna(row['score']) else None,
                'delta_mz': float(row['delta_mz']) if pd.notna(row['delta_mz']) else None,
            })

        # 7. Write sentinel
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(output_row_path),
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path) if column_path else '',
            'annotation_table': annotation_table,
            'summary': {
                'total_features': total_features,
                'annotated_features': annotated_features,
                'annotation_rate': annotation_rate,
            },
            'status': 'completed',
        }

        metadata_file = Path(output_sentinel)
        metadata_file.write_text(json.dumps(sentinel, indent=2))
        logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
        print(
            f'__PEAK_ANNOTATION_METADATA_START__{json.dumps(sentinel)}'
            f'__PEAK_ANNOTATION_METADATA_END__'
        )
        logger.success(f'Peak annotation complete: {annotated_features}/{total_features} features annotated ({annotation_rate*100:.1f}%)')
    except Exception as e:
        write_error_sentinel("peak_annotation_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
