"""Tests for the merge_datasets CLI command."""
import pandas as pd
import numpy as np
from pathlib import Path
from scipy import sparse
from single_cell_metabolomics.merge_datasets import merge_datasets_impl


def _write_test_dataset(tmp_path, name, n_samples, n_features, extra_meta_cols=None):
    """Helper: create a parquet + row/col TSV + metadata CSV for one dataset."""
    ds_dir = tmp_path / name
    ds_dir.mkdir()

    # Sparse matrix parquet
    mat = sparse.random(n_features, n_samples, density=0.3, format='coo', random_state=42)
    df = pd.DataFrame({'row': mat.row, 'col': mat.col, 'data': mat.data})
    parquet_path = ds_dir / f'{name}_sparse_matrix.parquet'
    df.to_parquet(parquet_path)

    # Row features
    row_df = pd.DataFrame({
        'mode': ['positive'] * n_features,
        'mass': np.round(np.linspace(100, 500, n_features), 4),
        'index': range(n_features),
    })
    row_path = ds_dir / 'row_feature_names.tsv'
    row_df.to_csv(row_path, sep='\t', index=False)

    # Column samples
    col_df = pd.DataFrame({
        'sample': [f'{name}_sample_{i}' for i in range(n_samples)],
        'index': range(n_samples),
    })
    col_path = ds_dir / 'column_sample_names.tsv'
    col_df.to_csv(col_path, sep='\t', index=False)

    # Metadata
    meta = {
        'base_name': [f'{name}_raw_{i}' for i in range(n_samples)],
        'sample_id': [f'{name}_sample_{i}' for i in range(n_samples)],
    }
    if extra_meta_cols:
        for col_name, values in extra_meta_cols.items():
            meta[col_name] = values
    meta_df = pd.DataFrame(meta)
    meta_path = ds_dir / 'metadata.csv'
    meta_df.to_csv(meta_path, index=False)

    return {
        'parquet': str(parquet_path),
        'row': str(row_path),
        'column': str(col_path),
        'metadata': str(meta_path),
    }


def test_merge_two_datasets_basic(tmp_path):
    """Merge two datasets: combined output has correct dimensions and dataset_id column."""
    ds1 = _write_test_dataset(tmp_path, 'batch1', n_samples=5, n_features=10)
    ds2 = _write_test_dataset(tmp_path, 'batch2', n_samples=3, n_features=10)

    out_dir = tmp_path / 'merged'
    out_dir.mkdir()

    result = merge_datasets_impl(
        parquet_paths=[ds1['parquet'], ds2['parquet']],
        row_paths=[ds1['row'], ds2['row']],
        column_paths=[ds1['column'], ds2['column']],
        metadata_paths=[ds1['metadata'], ds2['metadata']],
        dataset_names=['batch1', 'batch2'],
        output_dir=str(out_dir),
        serial_number='TEST001',
        dataset_uid=99,
    )

    assert result['sample_number'] == 8  # 5 + 3
    assert result['feature_number'] == 10
    assert result['status'] == 'completed'

    # Check merged metadata has dataset_id column
    merged_meta = pd.read_csv(out_dir / 'metadata.csv')
    assert 'dataset_id' in merged_meta.columns
    assert set(merged_meta['dataset_id']) == {'batch1', 'batch2'}
    assert len(merged_meta) == 8

    # Check column_sample_names.tsv
    col_df = pd.read_csv(out_dir / 'column_sample_names.tsv', sep='\t')
    assert len(col_df) == 8

    # Check row_feature_names.tsv
    row_df = pd.read_csv(out_dir / 'row_feature_names.tsv', sep='\t')
    assert len(row_df) == 10


def test_merge_metadata_union_join(tmp_path):
    """Extra metadata columns are union-joined; missing values filled with NA."""
    ds1 = _write_test_dataset(
        tmp_path, 'ds1', n_samples=3, n_features=5,
        extra_meta_cols={'batch': ['A', 'A', 'B']},
    )
    ds2 = _write_test_dataset(
        tmp_path, 'ds2', n_samples=2, n_features=5,
        extra_meta_cols={'treatment': ['control', 'treated']},
    )

    out_dir = tmp_path / 'merged'
    out_dir.mkdir()

    merge_datasets_impl(
        parquet_paths=[ds1['parquet'], ds2['parquet']],
        row_paths=[ds1['row'], ds2['row']],
        column_paths=[ds1['column'], ds2['column']],
        metadata_paths=[ds1['metadata'], ds2['metadata']],
        dataset_names=['ds1', 'ds2'],
        output_dir=str(out_dir),
        serial_number='TEST002',
        dataset_uid=100,
    )

    merged_meta = pd.read_csv(out_dir / 'metadata.csv')
    assert 'batch' in merged_meta.columns
    assert 'treatment' in merged_meta.columns
    # ds2 rows should have NaN for 'batch'
    ds2_rows = merged_meta[merged_meta['dataset_id'] == 'ds2']
    assert ds2_rows['batch'].isna().all()
    # ds1 rows should have NaN for 'treatment'
    ds1_rows = merged_meta[merged_meta['dataset_id'] == 'ds1']
    assert ds1_rows['treatment'].isna().all()


def test_merge_feature_union(tmp_path):
    """When datasets have different features, the merged output contains the union."""
    ds1 = _write_test_dataset(tmp_path, 'ds1', n_samples=3, n_features=5)
    ds2 = _write_test_dataset(tmp_path, 'ds2', n_samples=2, n_features=8)

    out_dir = tmp_path / 'merged'
    out_dir.mkdir()

    result = merge_datasets_impl(
        parquet_paths=[ds1['parquet'], ds2['parquet']],
        row_paths=[ds1['row'], ds2['row']],
        column_paths=[ds1['column'], ds2['column']],
        metadata_paths=[ds1['metadata'], ds2['metadata']],
        dataset_names=['ds1', 'ds2'],
        output_dir=str(out_dir),
        serial_number='TEST003',
        dataset_uid=101,
    )

    row_df = pd.read_csv(out_dir / 'row_feature_names.tsv', sep='\t')
    assert result['feature_number'] == len(row_df)
    assert result['sample_number'] == 5  # 3 + 2
