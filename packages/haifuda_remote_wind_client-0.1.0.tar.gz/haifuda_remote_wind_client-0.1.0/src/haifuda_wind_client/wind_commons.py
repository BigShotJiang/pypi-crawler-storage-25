from enum import Enum


class NDFrameType(Enum):
    DATAFRAME = "df"  # pd.Dataframe
    SERIES = "sr"  # pd.Series
    NA = "na"  # 无效
