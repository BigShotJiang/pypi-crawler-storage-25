"""rpc调用万德的客户端"""

import hashlib
import traceback
from typing import List, Optional, Union

import pandas as pd

from datetime import datetime

import requests

from .wind_beans import LoginException, LoginRequest, LoginResponse, UnsupportedException, WindData, WindRequest, \
    WindResponse
from .wind_commons import NDFrameType
from .wind_data_coder import decode_ndframe_data, decode_wind_data, decode_wind_time


class RemoteWindClient(object):
    """
    Wind客户端
    使用: 
        from wind_client import WindClient
        w = WindClient(server='localhost:5000')
        data = w.wsd("000001.SZ", "close", "2024-01-01", "2024-03-01")
    """

    def __init__(self, server_url: str = 'localhost:5000', timeout: int = 30, version: str = "v1"):
        self._server_url = server_url
        self._version = version
        self._timeout: int = timeout
        self._connected: bool = False
        self._token: str = ""
        # 用户名
        self._username: str = ""
        # 密码
        self._password: str = ""

    def start(self):
        """模拟原生start方法，实际需要去登录"""
        try:
            login_req = LoginRequest()
            if self._username is None:
                raise LoginException("用户名为空！")
            if self._password is None:
                raise LoginException("密码为空！")
            login_req.token = self._token
            login_req.username = self._username
            login_req.password = hashlib.md5(self._password.encode(encoding="utf-8")).hexdigest()
            raw_response = requests.post(
                f"{self._server_url}/wind/{self._version}/login",
                data=login_req.model_dump_json(),
                headers={"Content-Type": "application/json"},
                timeout=self._timeout
            )
            login_response = LoginResponse.model_validate(raw_response.json())
            if login_response.token is not None and login_response.token != "":
                self._connected = True
                self._token = login_response.token
            else:
                raise LoginException(f"{login_response.msg}")
        except LoginException as e:
            print(f"登录异常:{e}")
            raise e
        except Exception as e:
            print(f"Connection failed: {e}")
            raise e

    def isconnected(self):
        return self._connected

    def is_login(self):
        """是否登录"""
        if self._token is None or self._token == "":
            return False
        return True

    def close(self):
        self.channel.close()
        self._connected = False

    def remote_call(self,
                    method: str,
                    codes: Union[str, List[str]] = None,
                    fields: Union[str, List[str]] = None,
                    begin_time: Union[str, datetime] = None,
                    end_time: Union[str, datetime] = None,
                    options: Optional[dict] = None,
                    **kwargs) -> WindData | tuple[int, pd.DataFrame]:

        # 标准化参数
        if isinstance(codes, str):
            codes = codes.split(',') if ',' in codes else [codes]
        if isinstance(fields, str):
            fields = fields.split(',') if ',' in fields else [fields]

        # 解析 options 中的参数
        opt_dict = self._parse_options(options)
        # 处理usedf和usedfdt
        usedf = kwargs.get('usedf', False)
        usedfdt = kwargs.get('usedfdt', False)
        # tdayscount日期偏移函数
        offset = kwargs.get("offset", 0)
        # wset获取数据集
        tablename = kwargs.get("tablename", "")
        # wgel获取数据集"""
        funcname = kwargs.get("funcname", "")
        windid = kwargs.get("windid", "")
        # # wnq订阅实时新闻
        # # wner智能api
        # # wsq获取实时数据
        # # tdq获取实时数据
        # # bbq获取实时债券数据
        # func = kwargs.get("func", "")
        """bbq获取实时债券数据"""
        input = kwargs.get("input", "")
        """wnq新闻内容"""
        id = kwargs.get("id", "")
        """weqs获取条件选股的结果"""
        filtername = kwargs.get("filtername", "")
        """资产类别标识"""
        sec_type = kwargs.get("sec_type", "")
        # 格式兼容
        if begin_time is not None:
            if isinstance(begin_time, datetime):
                begin_time = datetime.strftime(begin_time, "%Y-%m-%d %H:%M:%S")
        if end_time is not None:
            if isinstance(end_time, datetime):
                end_time = datetime.strftime(end_time, "%Y-%m-%d %H:%M:%S")
        headers = {"Content-Type": "application/json"}
        headers['Authorization'] = f'Bearer {self._token}'
        # 构建 gRPC 请求
        request = WindRequest(
            method=method or "",
            codes=codes or [],
            fields=fields or [],
            begin_time=begin_time or "",
            end_time=end_time or "",
            options=opt_dict or {},
            usedf=usedf or False,
            usedfdt=usedfdt or False,
            offset=offset or 0,
            tablename=tablename or "",
            funcname=funcname or "",
            windid=windid or "",
            # func=func or "",
            input=input or "",
            id=id or "",
            filtername=filtername or "",
            sec_type=sec_type or ""
        )

        try:
            raw_response = requests.post(
                f"{self._server_url}/wind/{self._version}/execute",
                data=request.model_dump_json(),
                headers=headers,
                timeout=self._timeout
            )
            response = WindResponse.model_validate(raw_response.json())
            wd = self.get_winddata_by_windresponse(response)
            if wd.IsNDFrame == NDFrameType.DATAFRAME.value or wd.IsNDFrame == NDFrameType.SERIES.value:
                return wd.ErrorCode, wd.NDFrameData
            else:
                return wd
        except grpc.RpcError as e:
            # print(f"gRPC Error: {e.code()} - {e.details()}")
            # return WindData(WindResponse(error_code=-1, error_msg=str(e.details())))
            return self.get_winddata_by_windresponse(WindResponse(error_code=-1, error_msg=str(e)))

    def _parse_options(self, options: Optional[str]) -> dict:
        """解析 Wind 风格 options 字符串"""
        result = {}
        if not options:
            return result
        if isinstance(options, str) and options == "":
            return result
        for pair in options.split(';'):
            if '=' in pair:
                k, v = pair.split('=', 1)
                k, v = k.strip(), v.strip()
                result[k] = v
        return result

    def get_winddata_by_windresponse(self, response_data: WindResponse = None):
        """RPC返回转换成类似WindData的结构"""
        winddata = WindData()
        winddata.ErrorCode = response_data.error_code
        if winddata.ErrorCode is None:
            winddata.ErrorCode = -1
        winddata.StateCode = response_data.state_code
        if winddata.StateCode is None:
            winddata.StateCode = -1
        winddata.RequestID = response_data.request_id
        if winddata.RequestID is None:
            winddata.RequestID = -1
        winddata.Codes = response_data.codes
        if winddata.Codes is None:
            winddata.Codes = []
        else:
            winddata.Codes = list(winddata.Codes)
        winddata.Fields = response_data.fields
        if winddata.Fields is None:
            winddata.Fields = []
        else:
            winddata.Fields = list(winddata.Fields)

        WindData.Times = decode_wind_time(response_data.times)
        if WindData.Times is None:
            WindData.Times = []
        else:
            winddata.Times = list(winddata.Times)

        # 根据参数构建不同的返回格式
        # print(response_data.ndframe_type)
        if response_data.ndframe_type == NDFrameType.DATAFRAME.value or response_data.ndframe_type == NDFrameType.SERIES.value:
            # 服务端已返回 DataFrame 结构，需要重建
            ndframe_payload = response_data.ndframe_payload
            ndframe_data = decode_ndframe_data(ndframe_payload)
            if ndframe_data is not None:
                winddata.NDFrameData = ndframe_data
            if winddata.NDFrameData is None:
                if response_data.ndframe_type == NDFrameType.DATAFRAME.value:
                    winddata.NDFrameData = pd.DataFrame()
                elif response_data.ndframe_type == NDFrameType.SERIES.value:
                    winddata.NDFrameData = pd.Series()
            winddata.IsNDFrame = response_data.ndframe_type
        else:
            # 原生列表格式，与原 Wind API 完全一致
            data_bytes = response_data.data
            winddata.Data = decode_wind_data(data_bytes)
            winddata.IsNDFrame = NDFrameType.NA.value
            if winddata.Data is None:
                winddata.Data = []
        return winddata

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, value):
        self._username = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        self._password = value


class CompatibleClient(object):
    """兼容原生WindPy接口的客户端"""

    def __init__(self, server: str = 'http://localhost:5000', timeout: int = 30):
        self.w = RemoteWindClient(server, timeout)
        # 用户名
        self._username: str = ""
        # 密码
        self._password: str = ""

    def start(self):
        """模拟原生start方法，实际只是检查连接"""
        self.w.username = self.username
        self.w.password = self.password
        self.w.start()

    def isconnected(self):
        return self.w.isconnected()

    def close(self):
        self.w.close()

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, value):
        self._username = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        self._password = value

    # ========== 兼容原生Wind API ==========
    # 兼容WindPy的主要接口
    def wsd(self, codes, fields, beginTime=None, endTime=None, options=None, **kwargs):
        """wsd获取日期序列"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('wsd', codes, fields, beginTime, endTime, options, **kwargs)

    def wst(self, codes, fields, beginTime=None, endTime=None, options=None, **kwargs):
        """wst获取日内跳价"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('wst', codes, fields, beginTime, endTime, options, **kwargs)

    def wsi(self, codes, fields, beginTime=None, endTime=None, options=None, **kwargs):
        """wsi获取分钟序列"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('wsi', codes, fields, beginTime, endTime, options, **kwargs)

    def tdays(self, beginTime=None, endTime=None, options=None, **kwargs):
        """tdays特定交易日函数"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('tdays', None, None, beginTime, endTime, options, **kwargs)

    def tdayscount(self, beginTime=None, endTime=None, options=None, **kwargs):
        """tdayscount交易日统计"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('tdayscount', None, None, beginTime, endTime, options, **kwargs)

    def tdaysoffset(self, offset, beginTime=None, options=None, **kwargs):
        """tdayscount日期偏移函数"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        kwargs["offset"] = offset
        return self.w.remote_call('tdaysoffset', None, None, beginTime, None, options, **kwargs)

    def wset(self, tablename, options=None, **kwargs):
        """wset获取数据集"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        kwargs["tablename"] = tablename
        return self.w.remote_call('wset', None, None, None, None, options, **kwargs)

    def wgel(self, funcname, windid, options=None, **kwargs):
        """wgel获取数据集"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        kwargs["funcname"] = funcname
        kwargs["windid"] = windid
        return self.w.remote_call('wgel', None, None, None, None, options, **kwargs)

    def wnd(self, codes, beginTime=None, endTime=None, options=None, **kwargs):
        """wnd获取历史新闻"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('wnd', codes, None, beginTime, endTime, options, **kwargs)

    def wnq(self, codes, options=None, func=None, **kwargs):
        """wnq订阅实时新闻"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        wd = self.w.remote_call('wnq', codes, None, None, None, options, **kwargs)
        try:
            if func is not None and callable(func):
                func(wd)
        except Exception as e:
            traceback.print_exc()
        return wd

    def wnc(self, id, options=None, **kwargs):
        """wnq新闻内容"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        kwargs["id"] = id
        return self.w.remote_call('wnc', None, None, None, None, options, **kwargs)

    def wai(self, func, input, options=None, **kwargs):
        """wner智能api"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        kwargs["input"] = input
        wd = self.w.remote_call('wai', None, None, None, None, options, **kwargs)
        try:
            if func is not None and callable(func):
                func(wd)
        except Exception as e:
            traceback.print_exc()
        return wd

    def weqs(self, filtername, options=None, **kwargs):
        """weqs获取条件选股的结果"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        kwargs["filtername"] = filtername
        return self.w.remote_call('weqs', None, None, None, None, options, **kwargs)

    def wpf(self, productname, tablename, options=None, **kwargs):
        """wpf资管函数"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持wpf函数！")

    def wupf(self, PortfolioName, TradeDate, WindCode, Quantity, CostPrice, options=None, **kwargs):
        """wpf资管函数"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持wupf函数！")

    def wpd(self, PortfolioName, fields, beginTime=None, endTime=None, options=None, **kwargs):
        """wpd资管函数"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持wpd函数！")

    def wps(self, PortfolioName, fields, options=None, **kwargs):
        """wps资管函数"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持wps函数！")

    def wsq(self, codes, fields, options=None, func=None, **kwargs):
        """wsq获取实时数据"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        wd = self.w.remote_call('wsq', codes, fields, None, None, options, **kwargs)
        try:
            if func is not None and callable(func):
                func(wd)
        except Exception as e:
            traceback.print_exc()
        return wd

    def tdq(self, codes, fields, options=None, func=None, **kwargs):
        """tdq获取实时数据"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        wd = self.w.remote_call('tdq', codes, fields, None, None, options, **kwargs)
        try:
            if func is not None and callable(func):
                func(wd)
        except Exception as e:
            traceback.print_exc()
        return wd

    def bbq(self, codes, fields, options=None, func=None, **kwargs):
        """bbq获取实时债券数据"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        wd = self.w.remote_call('bbq', codes, fields, None, None, options, **kwargs)
        try:
            if func is not None and callable(func):
                func(wd)
        except Exception as e:
            traceback.print_exc()
        return wd

    def wss(self, codes, fields, options=None, **kwargs):
        """wss获取快照数据"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('wss', codes, fields, None, None, options, **kwargs)

    def htocode(self, codes, sec_type, options=None, **kwargs):
        """将交易代码转换为带市场后缀的标准 Wind 代码"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        kwargs["sec_type"] = sec_type  # 资产类别标识
        return self.w.remote_call('htocode', codes, None, None, None, options, **kwargs)

    def readdata(self, reqid, isdata=1):
        """readdata读取订阅id为reqid的数据"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持readdata函数！")

    def readanydata(self):
        """readdata读取任何订阅的数据"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持readanydata函数！")

    def tlogon(self, BrokerID, DepartmentID, LogonAccount, Password, AccountType, options=None, func=None, **kwargs):
        """登录"""
        self.start()
        try:
            if func is not None and callable(func):
                func()
        except Exception as e:
            traceback.print_exc()

    def tlogout(self, LogonID=None, options=None, **kwargs):
        """登出"""
        self.close()

    def torder(self, SecurityCode, TradeSide, OrderPrice, OrderVolume, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持readanydata函数！")

    def toperate(self, SecurityCode, OperateType, OrderVolume, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持readanydata函数！")

    def tcancel(self, OrderNumber, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持readanydata函数！")

    def tquery(self, qrycode, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持readanydata函数！")

    def tmonitor(self, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持readanydata函数！")

    def getversion(self):
        return "haifuda v1"

    def bktstart(self, StrategyName, StartDate, EndDate, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktstart函数！")

    def bktquery(self, qrycode, qrytime, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktquery函数！")

    def bktorder(self, TradeTime, SecurityCode, TradeSide, TradeVol, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktorder函数！")

    def bktstatus(self, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktstatus函数！")

    def bktend(self, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktend函数！")

    def bktsummary(self, BktID, View, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktsummary函数！")

    def bktdelete(self, BktID, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktdelete函数！")

    def bktstrategy(self, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktstrategy函数！")

    def bktfocus(self, StrategyID, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktfocus函数！")

    def bktshare(self, StrategyID, options=None, **kwargs):
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持bktshare函数！")

    def edb(self, codes, beginTime=None, endTime=None, options=None, **kwargs):
        """edb获取"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('edb', codes, None, beginTime, endTime, options, **kwargs)

    def wappAuth(self, appKey, appSecret, options=None, **kwargs):
        """appAuth"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持wappAuth函数！")

    def wappMessage(self, type_id, message, options=None, **kwargs):
        """wappMessage"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        raise UnsupportedException("不支持wappMessage函数！")

    def wses(self, codes, fields, beginTime=None, endTime=None, options=None, **kwargs):
        """wses获取日期序列"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('wses', codes, fields, beginTime, endTime, options, **kwargs)

    def wsee(self, codes, fields, options=None, **kwargs):
        """wsee获取快照数据"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('wsee', codes, fields, None, None, options, **kwargs)

    def wsed(self, codes, fields, options=None, **kwargs):
        """wsed获取快照数据"""
        if not self.w.is_login():
            raise LoginException("请先登录！")
        return self.w.remote_call('wsed', codes, fields, None, None, options, **kwargs)
