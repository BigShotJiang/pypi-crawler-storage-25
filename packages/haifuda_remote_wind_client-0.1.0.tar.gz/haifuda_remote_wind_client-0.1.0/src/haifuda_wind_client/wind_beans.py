"""万德远程调用通用实体"""

from typing import Dict, List, Optional

from pydantic import BaseModel
from .wind_commons import NDFrameType


class UnsupportedException(Exception):
    """不支持的函数"""
    pass


class LoginException(Exception):
    """登录信息异常"""
    pass

class WindData(object):
    """
        兼容原生WindPy的数据结构
        用途：为了方便客户使用，本类用来把api返回来的C语言数据转换成python能认的数据，从而为用户后面转换成numpy提供方便
             本类包含.ErrorCode 即命令错误代码，0表示正确；
                  对于数据接口还有：  .Codes 命令返回的代码； .Fields命令返回的指标；.Times命令返回的时间；.Data命令返回的数据
                  对于交易接口还有：  .Fields命令返回的指标；.Data命令返回的数据
    """

    def __init__(self):
        self.ErrorCode = 0
        self.StateCode = 0
        self.RequestID = 0
        self.Codes = list()  # list( string)
        self.Fields = list()  # list( string)
        self.Times = list()  # list( time)
        self.Data = list()  # list( list1,list2,list3,list4)
        self.NDFrameData = None  # Dataframe or Series
        self.IsNDFrame = NDFrameType.NA.value  # na 非 df 是 Dataframe sr 是 Series
        self.asDate = False
        self.datatype = 0  # 0-->DataAPI output, 1-->tradeAPI output

    def __str__(self):
        def str1D(v1d):
            if (not (isinstance(v1d, list))):
                return str(v1d)

            outLen = len(v1d)
            if (outLen == 0):
                return '[]'
            outdot = 0
            outx = ''
            outr = '['
            if outLen > 10:
                outLen = 10
                outdot = 1

            for x in v1d[0:outLen]:
                try:
                    outr = outr + outx + str(x)
                    outx = ','
                except UnicodeEncodeError:
                    outr = outr + outx + repr(x)
                    outx = ','

            if outdot > 0:
                outr = outr + outx + '...'
            outr = outr + ']'
            return outr

        def str2D(v2d):
            # v2d = str(v2d_in)
            outLen = len(v2d)
            if (outLen == 0):
                return '[]'
            outdot = 0
            outx = ''
            outr = '['
            if outLen > 10:
                outLen = 10
                outdot = 1

            for x in v2d[0:outLen]:
                outr = outr + outx + str1D(x)
                outx = ','

            if outdot > 0:
                outr = outr + outx + '...'
            outr = outr + ']'
            return outr

        a = ".ErrorCode=%d" % self.ErrorCode
        if (self.datatype == 0):
            if (self.StateCode != 0): a = a + "\n.StateCode=%d" % self.StateCode
            if (self.RequestID != 0): a = a + "\n.RequestID=%d" % self.RequestID
            if (len(self.Codes) != 0): a = a + "\n.Codes=" + str1D(self.Codes)
            if (len(self.Fields) != 0): a = a + "\n.Fields=" + str1D(self.Fields)
            if (len(self.Times) != 0):
                if (self.asDate):
                    a = a + "\n.Times=" + str1D([format(x, '%Y%m%d') for x in self.Times])
                else:
                    a = a + "\n.Times=" + str1D([format(x, '%Y%m%d %H:%M:%S') for x in self.Times])
        else:
            a = a + "\n.Fields=" + str1D(self.Fields)

        a = a + "\n.Data=" + str2D(self.Data)
        return a

class WindRequest(BaseModel):
    """
        远程调用请求实体
    """
    # wsd/wss/wsi/edb等
    method: Optional[str]=None
    # 股票代码/指标代码
    codes: Optional[List[str]]=None
    # 字段名
    fields: Optional[List[str]]=None
    # 开始时间
    begin_time: Optional[str]=None
    # 结束时间
    end_time: Optional[str]=None
    # 其他参数
    options: Optional[Dict[str, str]]= {}
    # 是否返回 DataFrame 格式
    usedf: Optional[bool]=None
    # 是否使用日期时间索引
    usedfdt: Optional[bool]=None
    # tdayscount日期偏移
    offset: Optional[int]=0
    # wset数据集
    tablename: Optional[str]=None
    # wgel数据集
    funcname: Optional[str]=None
    # wgel万德id
    windid: Optional[str]=None
    # bbq获取实时债券数据 的 input
    input: Optional[str]=None
    # wnq新闻内容id
    id: Optional[str]=None
    # weqs获取条件选股的过滤条件
    filtername: Optional[str]=None
    # htocode资产类别标识
    sec_type: Optional[str]=None

class WindResponse(BaseModel):
    """
        远程调用返回实体
    """
    # 错误编码
    error_code: Optional[int] = -1
    # 状态编码
    state_code: Optional[int] = -1
    # wind请求id
    request_id: Optional[int] = -1
    # 编码清单
    codes: Optional[List[str]] = []
    # 字段
    fields: Optional[List[str]] = []
    # 二维数组格式
    data: Optional[str] = None
    # 时间序列
    times: Optional[str]=  None
    # 错误信息
    error_msg: Optional[str] = None
    # DataFrame/Series pickle gzip压缩后的数据
    ndframe_payload: Optional[str] = None
    # na 非 df 是 Dataframe sr 是 Series
    ndframe_type: Optional[str] = NDFrameType.NA.value

class LoginRequest(BaseModel):
    """
        登录请求实体
    """
    # 验证信息
    token: Optional[str]= None
    # 用户名
    username: str= None
    # 密码
    password: str= None

class LoginResponse(BaseModel):
    """
        登录返回实体
    """
    # 验证信息
    token: Optional[str]= None
    # 错误信息
    msg: Optional[str] =None


    
