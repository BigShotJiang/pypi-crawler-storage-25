import gzip
import io
import pickle
from typing import Any, List

import pandas as pd


def decode_ndframe_data(ndframe_payload: str) -> pd.DataFrame | pd.Series:
    """
    将 Pickle格式bytes 转换为DataFrame和Series


    Args:
        data: Pickle格式bytes

    Returns:
        pd.DataFrame 、 pd.Series
    """
    if ndframe_payload is None or ndframe_payload=="":
        return None
    ndframe_payload_bytes = bytes.fromhex(ndframe_payload)
    buffer = io.BytesIO(ndframe_payload_bytes)
    if len(ndframe_payload) > 0:
        return pd.read_pickle(filepath_or_buffer=buffer, compression="gzip")
    buffer.close()
    buffer = None
    return None


def decode_wind_data(encoded_bytes_str: str) -> List[List[Any]]:
    """
    解码字符串为 WindData.Data 格式，Pickle编码格式gzip解压缩

    Args:
        encoded_str: encode_wind_data 生成的字符串

    Returns:
        还原后的二维列表，结构与原始 WindData.Data 一致
    """
    if encoded_bytes_str is None or encoded_bytes_str == "":
        return None
    encoded_bytes = bytes.fromhex(encoded_bytes_str)
    if not isinstance(encoded_bytes, bytes):
        raise TypeError("输入必须是字节类型")
    if len(encoded_bytes) > 0:
        # 解压缩
        decompressed = gzip.decompress(encoded_bytes)
        return pickle.loads(decompressed)
    return None

def decode_wind_time(encoded_bytes_str: str) -> List[Any]:
    """
    解码字符串为 WindData.Time 格式，Pickle编码格式gzip解压缩

    Args:
        encoded_str: encode_wind_Time 生成的字符串

    Returns:
        还原后的一维列表，结构与原始 WindData.Time 一致
    """
    if encoded_bytes_str is None or encoded_bytes_str == "":
        return None
    encoded_bytes = bytes.fromhex(encoded_bytes_str)
    if not isinstance(encoded_bytes, bytes):
        raise TypeError("输入必须是字节类型")
    if len(encoded_bytes) > 0:
        # 解压缩
        decompressed = gzip.decompress(encoded_bytes)
        return pickle.loads(decompressed)
    return None
