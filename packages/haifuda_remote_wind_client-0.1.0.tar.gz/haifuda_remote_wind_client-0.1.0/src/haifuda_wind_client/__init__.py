from .wind_client import CompatibleClient

__version__ = "0.1.0"
__all__ = ["CompatibleClient"]