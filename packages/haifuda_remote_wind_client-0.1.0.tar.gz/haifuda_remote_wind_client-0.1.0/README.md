# 海富达远端调用万德
# 用法与万德基本一致
# 初始化方法如下
w = CompatibleClient("https://grpcwind.htlfund.com", 1000 * 60)