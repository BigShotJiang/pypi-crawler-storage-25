# zeno-provider-claude

`Provider` adapter over `claude_agent_sdk.ClaudeSDKClient`. Behaviour is gatekept by characterization tests under `tests/` — when the in-core implementation moved here, those tests pinned byte-for-byte equivalence.

## Dispatch contract

The provider lives in `src/zeno/providers/claude_sdk/`. The handler responsible for dispatching a turn:

1. Resolves the SDK session id via the optional `session_lookup(user_id, channel, thread_key) -> sdk_session_id | None`. Populates `ClaudeAgentOptions.resume` when a session exists.
2. Translates `Agent` configuration into `ClaudeAgentOptions` via `agent_to_claude_options(...)`.
3. Constructs `ClaudeSDKClient(...)` **inside** the bound `Ctx` scope — this is the ContextVar-propagation invariant. Constructing outside the bound scope breaks `current_ctx()` lookups in tool handlers.
4. Streams assistant text chunks through `ctx.stream(...)`.
5. Bridges SDK tool-use hooks to `ToolCallStarted` / `ToolCallCompleted` trace events via `build_hooks(tracer, ...)`.

## What this provider does NOT touch

`ctx.memory.conversation` — the Agent SDK owns its own session history. Non-Claude providers extract state from this store; here it would be redundant and potentially conflicting.

## Capability flags

`Capabilities(supports_sub_agents=True, supports_built_in_tools=True, supports_permission_mode=True, supports_streaming=True)`. If you add a new capability gate to the `Provider` Protocol in `zeno-core`, decide explicitly whether Claude supports it and update this struct.

## Dependencies

- `claude-agent-sdk>=0.1.10,<0.2` — pre-1.0 cap per root `AGENTS.md` § Dependency policy. When `claude-agent-sdk` cuts a breaking minor, this is the package that absorbs the migration.
- `zeno-core` (lockstep version).

## Testing

Characterization tests live under `tests/`. They assert that the provider's behaviour matches the in-core rc1 implementation. Don't loosen them without an explicit migration note in the PR description.
