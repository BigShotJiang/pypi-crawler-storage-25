"""`ClaudeSDKProvider` — Zeno `Provider` adapter over `claude_agent_sdk.ClaudeSDKClient`.

Behaviour preserved byte-for-byte from the in-core implementation that
shipped in `zeno-core` rc1; the characterization tests under
`packages/zeno-provider-claude/tests/` are the gatekeeper.

What this provider owns:
  - `agent_to_claude_options(...)` translation into `ClaudeAgentOptions`
  - optional `session_lookup(user_id, channel, thread_key) -> sdk_session_id`
    for SDK resume
  - `ClaudeSDKClient(...)` construction **inside** the bound Ctx scope so
    tool ContextVars propagate (the invariant called out in `ZenoApp`)
  - streaming assistant text chunks through `ctx.stream(...)`
  - hook-bridge wiring via `build_hooks(tracer, ...)` so SDK tool-use hooks
    surface as `ToolCallStarted` / `ToolCallCompleted` trace events

What this provider intentionally does NOT touch:
  - `ctx.memory.conversation` — the Agent SDK owns its own session history.
    Non-Claude providers that extract state from this store have zero
    effect here.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

from claude_agent_sdk import ClaudeSDKClient
from zeno.context import current_ctx
from zeno.providers.claude_sdk._hooks import build_hooks
from zeno.providers.claude_sdk._options import agent_to_claude_options
from zeno.providers.protocol import Capabilities

_log = logging.getLogger("zeno.providers.claude_sdk")

if TYPE_CHECKING:
    from zeno.agent import Agent
    from zeno.channels.messages import IncomingMessage
    from zeno.context import Ctx


# Session lookup keyed the same way the v0.2 `ZenoApp` did — `(user_id,
# channel, thread_key) -> sdk_session_id | None`. The handler calls this
# before translating options so `ClaudeAgentOptions.resume` gets populated
# when a previous session exists.
SessionLookup = Callable[[str, str, str | None], Awaitable[str | None]]


_CAPABILITIES = Capabilities(
    supports_sub_agents=True,
    supports_built_in_tools=True,
    supports_permission_mode=True,
    supports_streaming=True,
)


class ClaudeSDKProvider:
    """`Provider` adapter over `claude_agent_sdk.ClaudeSDKClient`.

    Constructor arguments:
      - ``session_lookup``: optional async callable used to resolve the SDK
        session id to resume per turn. When ``None``, every turn starts a
        fresh SDK session.
      - ``mcp_server_key``: MCP server name used when translating tools;
        defaults to ``"zeno_app"`` (matches the v0.2 example-chat value).
    """

    def __init__(
        self,
        *,
        session_lookup: SessionLookup | None = None,
        mcp_server_key: str = "zeno_app",
    ) -> None:
        self._session_lookup = session_lookup
        self._mcp_server_key = mcp_server_key

    @property
    def capabilities(self) -> Capabilities:
        return _CAPABILITIES

    async def start(self) -> None:
        # Warn loudly at startup rather than fail opaquely on the first turn.
        # The Claude Agent SDK accepts auth via either `ANTHROPIC_API_KEY` or
        # the `claude` CLI's stored OAuth credentials, so we only check the
        # env var and surface a hint covering both paths — no hard failure
        # to avoid false-positiving users who have run `claude login`.
        if not os.environ.get("ANTHROPIC_API_KEY"):
            _log.warning(
                "ClaudeSDKProvider: ANTHROPIC_API_KEY is not set. The Claude "
                "Agent SDK will fall back to the `claude` CLI's stored OAuth "
                "credentials; if you have not run `claude login`, the first "
                "turn will fail. Obtain a key at "
                "https://console.anthropic.com/settings/keys"
            )

    async def stop(self) -> None:  # pragma: no cover — v0.3.0 no-op
        return None

    async def run_turn(
        self,
        *,
        agent: Agent,
        ctx: Ctx,
        msg: IncomingMessage,
    ) -> None:
        """Run one turn through `ClaudeSDKClient`, preserving rc1 behaviour.

        The client is constructed **inside this coroutine** (and therefore
        inside ``bind_ctx`` from the turn worker) so every tool invoked by
        the SDK observes the current `Ctx` via `current_ctx()`. Constructing
        outside would capture the wrong ContextVar snapshot and cause tool
        handlers to raise `LookupError`.
        """
        session_id = await self._resolve_session_id(ctx, msg)
        system_prompt_override = ctx.state.get("composed_prompt")
        options = agent_to_claude_options(
            agent,
            mcp_server_key=self._mcp_server_key,
            session_id=session_id,
            system_prompt_override=system_prompt_override,
        )
        if ctx.tracer is not None:
            options.hooks = build_hooks(  # type: ignore[assignment]
                ctx.tracer,
                turn_id_provider=lambda: current_ctx().turn_id,
                user_id_provider=lambda: current_ctx().user_id,
                session_id_provider=lambda: current_ctx().session_id,
            )
        async with ClaudeSDKClient(options=options) as client:
            await client.query(msg.text)
            async for chunk in client.receive_response():
                # Real SDK chunks: AssistantMessage(content=[TextBlock(text=...),
                # ThinkingBlock(thinking=...), ...]). Earlier rc-series releases
                # also accepted top-level `.text` on chunks; keep that path so
                # callers can still substitute simple fakes in tests.
                text = getattr(chunk, "text", None)
                if text:
                    await ctx.stream(text)
                    continue
                content = getattr(chunk, "content", None)
                if isinstance(content, list):
                    for block in content:
                        block_text = getattr(block, "text", None)
                        if block_text:
                            await ctx.stream(block_text)
        await ctx.finalize()

    async def _resolve_session_id(self, ctx: Ctx, msg: IncomingMessage) -> str | None:
        if self._session_lookup is None:
            return None
        return await self._session_lookup(msg.user_id, ctx.channel, msg.thread_key)
