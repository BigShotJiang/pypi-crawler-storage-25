# CommitmentPrepaymentType

The prepayment type of the commitment.

## Enum

* `NOTPREPAID` (value: `'NotPrepaid'`)

* `FULLYPREPAID` (value: `'FullyPrepaid'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


