# BillingDocumentItemProcessingType


## Enum

* `CHARGE` (value: `'Charge'`)

* `DISCOUNT` (value: `'Discount'`)

* `PREPAYMENT` (value: `'Prepayment'`)

* `TAX` (value: `'Tax'`)

* `ROUNDING` (value: `'Rounding'`)

* `SURCHARGE` (value: `'Surcharge'`)

* `COMMITMENTTRUEUP` (value: `'CommitmentTrueUp'`)

* `PREPAYMENTBILLING` (value: `'PrepaymentBilling'`)

* `PREPAYMENTAPPLICATION` (value: `'PrepaymentApplication'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


