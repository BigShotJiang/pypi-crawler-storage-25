# Exceptions

::: yukka.exceptions
