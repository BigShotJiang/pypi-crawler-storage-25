# Sentiment

::: yukka.sentiment
