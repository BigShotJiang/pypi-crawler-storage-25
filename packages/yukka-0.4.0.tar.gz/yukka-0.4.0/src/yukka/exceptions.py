"""YUKKA API exceptions."""


class ExpiredToken(ValueError):
    """Raised when JWT token has expired and cannot be renewed."""

    pass


class TrialModeError(Exception):
    """Raised when trial mode constraints are violated (entity not allowed, date out of range, or auth required)."""

    pass
