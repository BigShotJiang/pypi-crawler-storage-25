"""Sentiment logic — SentimentMixin for YukkaClient."""

from __future__ import annotations

import io
from typing import TYPE_CHECKING

import polars as pl

from .utils import IntoDateTime

if TYPE_CHECKING:
    from httpx import Client
    from yarl import URL


class SentimentMixin:
    """Mixin providing sentiment-related methods for YukkaClient."""

    if TYPE_CHECKING:
        _client: Client
        _data_api_url: URL
        _auth_headers: dict[str, str]

        def _build_time_range(self, date_from: IntoDateTime, date_to: IntoDateTime) -> dict[str, str]:
            """Build the time range dict for API requests."""
            ...

        def _validate_trial(self, entities: list[str], date_from: IntoDateTime, date_to: IntoDateTime) -> None:
            """Validate trial mode constraints."""
            ...

    def sentiment(
        self, entities: list[str], date_from: IntoDateTime, date_to: IntoDateTime, batch_size: int = 50
    ) -> pl.DataFrame:
        """Fetch sentiment counts for entities over a time range.

        Args:
            entities: List of entity IDs in format "type:alpha_id" (e.g., "company:bmw")
            date_from: Start date
            date_to: End date
            batch_size: Number of entities per API request (default 50)

        Returns:
            DataFrame with columns: date, entity, positive, neutral, negative

        Raises:
            httpx.HTTPStatusError: If API request fails
            TrialModeError: If trial mode constraints are violated
        """
        self._validate_trial(entities, date_from, date_to)

        if len(entities) == 0:
            return pl.DataFrame()

        all_dfs: list[pl.DataFrame] = []

        # Batch entities to avoid API limits
        for i in range(0, len(entities), batch_size):
            batch = entities[i : i + batch_size]
            print(f"Fetching sentiment for batch {i // batch_size + 1} ({len(batch)} entities)...")

            data: list[bytes] = []
            with self._client.stream(
                "POST",
                str(self._data_api_url / "api" / "exports" / "sentiment_matches"),
                json={
                    "time_range": self._build_time_range(date_from, date_to),
                    "sentiment_filter": {"entities": batch},
                    "language_filter": ["en", "de"],
                },
                headers=self._auth_headers,
            ) as resp:
                resp.raise_for_status()
                for chunk in resp.iter_bytes(chunk_size=10_000):
                    data.append(chunk)

            df = pl.read_parquet(io.BytesIO(b"".join(data)))
            all_dfs.append(df)

        # Combine all batches
        df = pl.concat(all_dfs)

        # Pivot the data: one row per date/entity with positive, neutral, negative columns
        pivoted = df.with_columns(
            pl.from_epoch(pl.col("publish_time"), time_unit="d").alias("date"),
            pl.col("entity_compound_key").cast(pl.Utf8).alias("entity"),
        ).pivot(on="sentiment", index=["date", "entity"], values="count()", aggregate_function="sum")

        # Rename only columns that exist (a sentiment category may be absent if no data for it)
        rename_map = {
            k: v for k, v in {"1": "positive", "0": "neutral", "-1": "negative"}.items() if k in pivoted.columns
        }
        pivoted = pivoted.rename(rename_map)

        # Fill missing sentiment columns with zeros
        for col in ["positive", "neutral", "negative"]:
            if col not in pivoted.columns:
                pivoted = pivoted.with_columns(pl.lit(0).cast(pl.UInt64).alias(col))

        return pivoted.select(["date", "entity", "positive", "neutral", "negative"]).sort("date", "entity")
