"""Equity index universes and constituent loaders."""

from dataclasses import dataclass
from enum import Enum

import polars as pl

from .config import load_master


def _universe(index_name: str) -> pl.DataFrame:
    """Filter the master constituents file to a single index and clean up columns.

    Args:
        index_name: Index identifier as stored in the master file (e.g., "STOXX600").

    Returns:
        Cleaned DataFrame of index constituents with null-yukka_id rows removed.
    """
    df = load_master().filter(pl.col("index") == index_name)

    from_date = df.select(pl.col("start_date").min()).item()
    to_date = df.select(pl.col("end_date").max()).item()

    drop_cols = [
        col
        for col in df.columns
        if any(keyword in col.lower() for keyword in ["interval", "obser", "org_permid", "index"])
    ]
    df = df.drop(drop_cols)

    excluded = df.filter(pl.col("yukka_id").is_null())
    df = df.filter(pl.col("yukka_id").is_not_null())
    if len(excluded) > 0:
        names = excluded["name"].to_list()
        print(
            f"Removed {len(excluded)} companies from the list that are not in the Yukka ontology. These include:\n"
            + "\n".join(f"  - {n}" for n in names)
        )

    print(f"List of {index_name} constituents from {from_date} to {to_date}")
    return df


@dataclass(frozen=True)
class Asset:
    """Simple dataclass for asset metadata."""

    name: str
    isin: str
    yukka_id: str
    ric: str


class Index(Enum):
    """Supported equity indexes."""

    FTSE100 = "FTSE100"
    STOXX600 = "STOXX600"
    SP500 = "SP500"
    NASDAQ100 = "NASDAQ100"

    def __init__(self, index_name: str):
        """Load and cache the index DataFrame."""
        self._frame = _universe(index_name)

    @property
    def frame(self) -> pl.DataFrame:
        """Return the DataFrame for this index."""
        return self._frame

    @property
    def assets(self) -> list[Asset]:
        """Load assets for this index."""
        return [
            Asset(**row)
            for row in self._frame.select("name", "isin", "yukka_id", "ric")
            .unique(subset=["isin"])
            .iter_rows(named=True)
        ]

    @property
    def membership_intervals(self) -> pl.DataFrame:
        """Return membership intervals for this index."""
        return self._frame.select(
            pl.col("ric"),
            pl.col("start_date").cast(pl.Date),
            pl.col("end_date").cast(pl.Date),
        )

    @classmethod
    def all_membership_intervals(cls) -> pl.DataFrame:
        """Return membership intervals across all indexes."""
        frames = [member.membership_intervals for member in cls]
        return pl.concat(frames)
