"""Pre-validated equity index universes."""

from yukka.data.index import Asset, Index

__all__ = ["Asset", "Index"]
