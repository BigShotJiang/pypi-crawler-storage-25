"""Shared filesystem paths for the data package."""

from pathlib import Path

import polars as pl

MASTER_FILE = Path(__file__).parent / "master_constituents.parquet"


def load_master() -> pl.DataFrame:
    """Load the master constituents Parquet file."""
    return pl.read_parquet(MASTER_FILE).rename({"constituent_ric": "ric", "constituent_name": "name"})
