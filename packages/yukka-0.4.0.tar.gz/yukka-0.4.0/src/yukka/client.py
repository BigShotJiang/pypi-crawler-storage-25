"""YukkaAPI (ABC) + YukkaClient (live) + DummyClient (offline) + Session.

This module implements the abstract API pattern where strategy/analysis code depends on
an abstract interface, not on HTTP calls or specific infrastructure.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import date
from typing import TYPE_CHECKING, Self

import polars as pl
from httpx import Client
from yarl import URL

from .auth import Token
from .events import EventsMixin
from .exceptions import TrialModeError
from .models import EventsFrame
from .sentiment import SentimentMixin
from .utils import (
    DATA_API_URL,
    DATE_FORMATTER,
    METADATA_API_URL,
    TRIAL_DATE_FROM,
    TRIAL_DATE_TO,
    TRIAL_ENTITIES,
    IntoDateTime,
    to_datetime,
)

if TYPE_CHECKING:
    from .entities import Asset, EntityResolver


class YukkaAPI(ABC):
    """Abstract interface for YUKKA data access.

    Defines WHAT data is available without specifying HOW it's retrieved.
    Client code writes against this interface, not specific implementations.
    """

    @abstractmethod
    def sentiment(self, entities: list[str], date_from: IntoDateTime, date_to: IntoDateTime) -> pl.DataFrame:
        """Fetch sentiment scores for entities over a time range.

        Args:
            entities: List of entity IDs
            date_from: Start date
            date_to: End date

        Returns:
            DataFrame with sentiment scores
        """
        pass

    @abstractmethod
    def events(self, entities: list[str], date_from: IntoDateTime, date_to: IntoDateTime) -> EventsFrame:
        """Fetch events for entities over a time range.

        Args:
            entities: List of entity IDs
            date_from: Start date
            date_to: End date

        Returns:
            EventsFrame wrapping the raw DataFrame. Call .map() for translated columns.
        """
        pass


@dataclass
class YukkaClient(SentimentMixin, EventsMixin, YukkaAPI):
    """Live implementation of YukkaAPI wrapping the three YUKKA APIs.

    This client makes actual HTTP requests to YUKKA's APIs and requires authentication.
    Can be used as a context manager for automatic resource cleanup.

    Example:
        >>> with YukkaClient.from_token("eyJ...") as client:  # doctest: +SKIP
        ...     df = client.sentiment(["company:bmw"], "2026-01-01", "2026-01-07")
    """

    _token: Token | None
    _client: Client
    _data_api_url: URL
    _metadata_api_url: URL
    _event_names: dict[str, str] = field(default_factory=dict, repr=False)
    _event_participant_roles: dict[tuple[str, str], str] = field(default_factory=dict, repr=False)

    @classmethod
    def from_token(cls, token: str) -> YukkaClient:
        """Create a YukkaClient from an existing JWT token.

        Args:
            token: JWT token string

        Returns:
            YukkaClient instance

        Example:
            >>> client = YukkaClient.from_token("eyJ...")  # doctest: +SKIP
            >>> df = client.sentiment(["company:bmw"], "2026-01-01", "2026-01-07")  # doctest: +SKIP
        """
        client = Client(timeout=None)  # nosec B113
        return cls(
            _token=Token.from_token(token),
            _client=client,
            _data_api_url=DATA_API_URL,
            _metadata_api_url=METADATA_API_URL,
        )

    @classmethod
    def from_trial(cls) -> YukkaClient:
        """Create a YukkaClient in trial mode (no authentication).

        Returns:
            YukkaClient instance with no token
        """
        client = Client(timeout=None)  # nosec B113
        return cls(
            _token=None,
            _client=client,
            _data_api_url=DATA_API_URL,
            _metadata_api_url=METADATA_API_URL,
        )

    @property
    def _auth_headers(self) -> dict[str, str]:
        """Get authorization headers with current JWT token."""
        if self._token is None:
            return {}
        return {"Authorization": f"Bearer {self._token.get()}"}

    def _validate_trial(self, entities: list[str], date_from: IntoDateTime, date_to: IntoDateTime) -> None:
        """Validate trial mode constraints. No-op when authenticated."""
        if self._token is not None:
            return

        trial_suffix = "You are using a limited trial token. Contact YUKKA Lab (info@yukkalab.com) to get full access."

        invalid = [e for e in entities if e not in TRIAL_ENTITIES]
        if invalid:
            allowed = ", ".join(sorted(TRIAL_ENTITIES))
            raise TrialModeError(
                f"Trial mode: entities not allowed: {invalid}. Allowed trial entities: {allowed}. {trial_suffix}"
            )

        df = to_datetime(date_from).date()
        dt = to_datetime(date_to).date()
        if df < TRIAL_DATE_FROM or dt > TRIAL_DATE_TO:
            raise TrialModeError(
                f"Trial mode: date range {df} to {dt} is outside the allowed trial range "
                f"{TRIAL_DATE_FROM} to {TRIAL_DATE_TO}. "
                f"{trial_suffix}"
            )

    def _build_time_range(self, date_from: IntoDateTime, date_to: IntoDateTime) -> dict[str, str]:
        """Build time range dict for API requests.

        Args:
            date_from: Start date
            date_to: End date

        Returns:
            Dict with date_from and date_to formatted as strings
        """
        return {
            "date_from": to_datetime(date_from).strftime(DATE_FORMATTER),
            "date_to": to_datetime(date_to).strftime(DATE_FORMATTER),
        }

    def close(self) -> None:
        """Close the HTTP client and release resources."""
        self._client.close()

    def __enter__(self) -> Self:
        """Enter the context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit the context manager and close the client."""
        self.close()


@dataclass
class Session:
    """High-level session for working with YUKKA APIs.

    Session provides a convenient interface that:
    - Auto-loads token from environment variables
    - Activates entity resolution automatically inside the context manager
    - Accepts Asset objects in API methods
    - Can be used as a context manager for automatic resource cleanup

    Example:
        >>> with Session() as session:  # doctest: +SKIP
        ...     bmw = Asset.from_isin("DE0005190003")
        ...     df = session.sentiment([bmw], date_from="2026-01-01")
    """

    _client: YukkaClient = field(repr=False)
    _resolver: EntityResolver | None = field(repr=False)

    def __init__(self, token: str | None = None):
        """Create a new Session.

        Token is resolved in this order:
        1. Explicit token parameter
        2. YUKKA_TOKEN environment variable
        3. Trial mode (no token — limited entities and date range)

        Args:
            token: Optional JWT token
        """
        from .entities import EntityResolver

        # Resolve token
        if token:
            self._client = YukkaClient.from_token(token)
        elif os.environ.get("YUKKA_TOKEN"):
            self._client = YukkaClient.from_token(os.environ["YUKKA_TOKEN"])
        else:
            self._client = YukkaClient.from_trial()
            self._resolver = None
            return

        client_token = self._client._token
        if client_token is None:  # unreachable: both branches above use from_token
            msg = "Token should not be None here"
            raise RuntimeError(msg)
        self._resolver = EntityResolver(
            _client=self._client._client,
            _token_getter=client_token.get,
        )

    @property
    def today(self) -> date:
        """Return today's date."""
        return date.today()

    @property
    def resolver(self) -> EntityResolver:
        """Return the entity resolver for converting ISINs/RICs to YUKKA IDs.

        Raises:
            TrialModeError: If in trial mode (no token)
        """
        if self._resolver is None:
            raise TrialModeError(
                "Entity resolution is not available in trial mode. "
                "Use Asset.from_yukka_id() or Asset.from_ric() instead. "
                "You are using a limited trial token. "
                "Contact YUKKA Lab (info@yukkalab.com) to get full access."
            )
        return self._resolver

    def sentiment(
        self,
        assets: Asset | list[Asset],
        date_from: IntoDateTime,
        date_to: IntoDateTime | None = None,
        batch_size: int = 50,
    ) -> pl.DataFrame:
        """Fetch sentiment scores for assets over a time range.

        Args:
            assets: Single Asset or list of Assets
            date_from: Start date
            date_to: End date (defaults to today)
            batch_size: Number of entities per API request (default 50)

        Returns:
            DataFrame with sentiment scores

        Example:
            >>> session = Session()  # doctest: +SKIP
            >>> bmw = Asset.from_yukka_id("company:bmw")  # doctest: +SKIP
            >>> df = session.sentiment(bmw, date_from="2026-01-01")  # doctest: +SKIP
        """
        from .entities import Asset

        if date_to is None:
            date_to = self.today

        # Normalize to list
        if isinstance(assets, Asset):
            assets = [assets]

        # Extract yukka_ids from assets
        entities = [asset.yukka_id for asset in assets]

        return self._client.sentiment(entities, date_from, date_to, batch_size)

    def events(
        self,
        assets: Asset | list[Asset],
        date_from: IntoDateTime,
        date_to: IntoDateTime | None = None,
        batch_size: int = 50,
    ) -> EventsFrame:
        """Fetch events for assets over a time range.

        Args:
            assets: Single Asset or list of Assets
            date_from: Start date
            date_to: End date (defaults to today)
            batch_size: Number of entities per API request (default 50)

        Returns:
            EventsFrame wrapping the raw DataFrame. Call .map() for translated columns.
        """
        from .entities import Asset

        if date_to is None:
            date_to = self.today

        if isinstance(assets, Asset):
            assets = [assets]

        entities = [asset.yukka_id for asset in assets]

        return self._client.events(entities, date_from, date_to, batch_size)

    def close(self) -> None:
        """Close the session and release resources."""
        self._client.close()

    def __enter__(self) -> Self:
        """Enter the context manager and activate the resolver for this session."""
        if self._resolver is not None:
            from .entities import _active_resolver

            self._resolver_token = _active_resolver.set(self._resolver)
        else:
            self._resolver_token = None
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit the context manager, deactivate the resolver, and close the session."""
        if self._resolver_token is not None:
            from .entities import _active_resolver

            _active_resolver.reset(self._resolver_token)
        self.close()
