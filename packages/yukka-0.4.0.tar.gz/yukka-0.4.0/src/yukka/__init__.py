"""YUKKA Python Package - A Python wrapper around YUKKA Lab's APIs.

This package provides a clean interface to YUKKA's three APIs:
- Quant API: Stock prices, volume, market cap, BullBearScore
- Metadata API: Entity resolution (ISIN/FIGI/name → yukka entity ID)
- Data/News API: Sentiment scores, news volume, events, Risk scores, ESG scores

Example using Session (recommended):
    >>> from yukka import Session, Asset  # doctest: +SKIP
    >>> with Session() as session:  # doctest: +SKIP
    ...     bmw = Asset.from_isin("DE0005190003")
    ...     df = session.sentiment(bmw, date_from="2026-01-01")

Example using YukkaClient directly:
    >>> from yukka import YukkaClient  # doctest: +SKIP
    >>> with YukkaClient.from_token("eyJ...") as client:  # doctest: +SKIP
    ...     df = client.sentiment(["company:bmw"], "2026-01-01", "2026-01-07")
"""

from importlib.metadata import PackageNotFoundError, version

from .client import Session, YukkaAPI, YukkaClient
from .entities import Asset, EntityResolver
from .exceptions import TrialModeError

try:
    __version__ = version("yukka")
except PackageNotFoundError:
    __version__ = "0.0.0+dev"

__all__ = [
    "Asset",
    "EntityResolver",
    "Session",
    "TrialModeError",
    "YukkaAPI",
    "YukkaClient",
]
