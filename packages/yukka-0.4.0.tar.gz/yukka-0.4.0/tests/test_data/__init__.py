"""Tests for yukka.data package."""
