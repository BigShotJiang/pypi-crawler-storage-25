"""Tests for yukka.data.index — Asset dataclass and Index enum."""

import polars as pl
import pytest

from yukka.data.index import Asset, Index


class TestAsset:
    """Tests for the Asset frozen dataclass."""

    def test_fields_are_set(self):
        """Asset fields should be accessible by name."""
        a = Asset(name="ACME", isin="US0000000001", yukka_id="company:acme", ric="ACME.L")
        assert a.name == "ACME"
        assert a.isin == "US0000000001"
        assert a.yukka_id == "company:acme"
        assert a.ric == "ACME.L"

    def test_frozen_raises_on_mutation(self):
        """Assigning to a field on a frozen dataclass should raise FrozenInstanceError."""
        a = Asset(name="ACME", isin="US0000000001", yukka_id="company:acme", ric="ACME.L")
        with pytest.raises(AttributeError):
            a.name = "other"  # type: ignore[misc]

    def test_equality(self):
        """Two Assets with the same fields should compare equal."""
        a = Asset(name="ACME", isin="US0000000001", yukka_id="company:acme", ric="ACME.L")
        b = Asset(name="ACME", isin="US0000000001", yukka_id="company:acme", ric="ACME.L")
        assert a == b

    def test_inequality(self):
        """Assets with differing fields should not compare equal."""
        a = Asset(name="ACME", isin="US0000000001", yukka_id="company:acme", ric="ACME.L")
        b = Asset(name="OTHER", isin="US0000000001", yukka_id="company:acme", ric="ACME.L")
        assert a != b


class TestIndex:
    """Tests for the Index enum."""

    def test_all_members_exist(self):
        """All four index members should be present."""
        names = {m.name for m in Index}
        assert names == {"FTSE100", "STOXX600", "SP500", "NASDAQ100"}

    def test_frame_non_empty(self):
        """Every index frame should be a non-empty DataFrame."""
        for member in Index:
            df = member.frame
            assert isinstance(df, pl.DataFrame)
            assert len(df) > 0, f"{member.name} frame is empty"

    def test_frame_has_expected_columns(self):
        """Every index frame should contain isin, yukka_id, start_date and end_date columns."""
        for member in Index:
            cols = member.frame.columns
            assert "isin" in cols
            assert "yukka_id" in cols
            assert "start_date" in cols
            assert "end_date" in cols

    def test_frame_no_null_yukka_id(self):
        """Every index frame should have no null yukka_id values."""
        for member in Index:
            assert member.frame["yukka_id"].null_count() == 0, f"{member.name} has null yukka_ids"

    def test_frame_internal_columns_dropped(self):
        """interval, obser, org_permid, and index columns should be removed."""
        for member in Index:
            for col in member.frame.columns:
                assert not any(kw in col.lower() for kw in ["interval", "obser", "org_permid", "index"]), (
                    f"{member.name}: column {col!r} should have been dropped"
                )

    def test_frame_has_multi_interval_companies(self):
        """Every index should have at least one company with more than one membership interval."""
        for member in Index:
            df = member.frame
            dupes = df.group_by("isin").agg(pl.len().alias("n")).filter(pl.col("n") > 1)
            assert len(dupes) > 0, f"{member.name} should have companies with multiple intervals"

    def test_assets_returns_list_of_asset(self):
        """Assets property should return a non-empty list of Asset instances."""
        assets = Index.STOXX600.assets
        assert isinstance(assets, list)
        assert len(assets) > 0
        assert all(isinstance(a, Asset) for a in assets)

    def test_assets_fields_are_non_empty(self):
        """Every Asset returned by assets should have non-empty string fields."""
        for asset in Index.FTSE100.assets:
            assert asset.name
            assert asset.isin
            assert asset.yukka_id
            assert asset.ric

    def test_assets_yukka_id_format(self):
        """yukka_id values should follow the type:alpha_id format."""
        for asset in Index.SP500.assets:
            assert ":" in asset.yukka_id, f"Invalid yukka_id format: {asset.yukka_id!r}"

    def test_membership_intervals_schema(self):
        """membership_intervals should have ric (Utf8), start_date and end_date (Date) columns."""
        df = Index.NASDAQ100.membership_intervals
        assert isinstance(df, pl.DataFrame)
        assert set(df.columns) == {"ric", "start_date", "end_date"}
        assert df.schema["start_date"] == pl.Date
        assert df.schema["end_date"] == pl.Date

    def test_membership_intervals_non_empty(self):
        """membership_intervals should have at least one row per index."""
        for member in Index:
            assert len(member.membership_intervals) > 0, f"{member.name} membership_intervals is empty"

    def test_all_membership_intervals_covers_all_indexes(self):
        """all_membership_intervals should include rows from every index member."""
        combined = Index.all_membership_intervals()
        assert isinstance(combined, pl.DataFrame)
        individual_total = sum(len(m.membership_intervals) for m in Index)
        assert len(combined) == individual_total

    def test_all_membership_intervals_schema(self):
        """all_membership_intervals should have the same schema as individual membership_intervals."""
        combined = Index.all_membership_intervals()
        assert set(combined.columns) == {"ric", "start_date", "end_date"}
        assert combined.schema["start_date"] == pl.Date
        assert combined.schema["end_date"] == pl.Date
