"""Integration tests for trial mode — hits real APIs without a token.

Run with: pytest -m integration
"""

import os
from unittest.mock import patch

import polars as pl
import pytest

from yukka.client import Session
from yukka.entities import Asset
from yukka.exceptions import TrialModeError
from yukka.models import EventsFrame

pytestmark = pytest.mark.integration


@pytest.fixture
def trial_session():
    """Create a trial-mode Session (no token)."""
    with patch.dict(os.environ, {}, clear=True):
        if "YUKKA_TOKEN" in os.environ:
            del os.environ["YUKKA_TOKEN"]
        with Session() as session:
            yield session


class TestTrialSentiment:
    """Integration tests for sentiment in trial mode."""

    def test_trial_sentiment_returns_data(self, trial_session):
        """Trial entity + valid dates should return sentiment data."""
        asset = Asset.from_yukka_id("company:apple")
        df = trial_session.sentiment(asset, "2020-01-01", "2020-01-31")

        assert isinstance(df, pl.DataFrame)
        assert len(df) > 0
        assert "date" in df.columns
        assert "entity" in df.columns

    def test_trial_sentiment_rejects_non_trial_entity(self, trial_session):
        """Non-trial entity should raise TrialModeError before hitting API."""
        asset = Asset.from_yukka_id("company:bmw")
        with pytest.raises(TrialModeError, match="not allowed"):
            trial_session.sentiment(asset, "2020-01-01", "2020-01-31")

    def test_trial_sentiment_rejects_out_of_range_dates(self, trial_session):
        """Out-of-range dates should raise TrialModeError before hitting API."""
        asset = Asset.from_yukka_id("company:apple")
        with pytest.raises(TrialModeError, match="outside the allowed trial range"):
            trial_session.sentiment(asset, "2025-01-01", "2025-06-01")


class TestTrialEvents:
    """Integration tests for events in trial mode."""

    def test_trial_events_returns_data(self, trial_session):
        """Trial entity + valid dates should return events data."""
        asset = Asset.from_yukka_id("company:apple")
        result = trial_session.events(asset, "2020-01-01", "2020-01-31")

        assert isinstance(result, EventsFrame)
        assert len(result) > 0

    def test_trial_events_rejects_non_trial_entity(self, trial_session):
        """Non-trial entity should raise TrialModeError before hitting API."""
        asset = Asset.from_yukka_id("company:bmw")
        with pytest.raises(TrialModeError, match="not allowed"):
            trial_session.events(asset, "2020-01-01", "2020-01-31")

    def test_trial_events_rejects_out_of_range_dates(self, trial_session):
        """Out-of-range dates should raise TrialModeError before hitting API."""
        asset = Asset.from_yukka_id("company:apple")
        with pytest.raises(TrialModeError, match="outside the allowed trial range"):
            trial_session.events(asset, "2025-01-01", "2025-06-01")
