"""Reusable audio transcription helpers.

Wraps the same strategy chain used by ``transcribe_audio.py`` (custom command,
OpenAI Whisper API, local whisper CLI, whisper.cpp) but exposes it as an
importable async function suitable for in-process use.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

_SYGEN_HOME = Path(
    os.environ.get("SYGEN_HOME", str(Path.home() / ".sygen"))
).expanduser()


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def _load_transcription_config() -> dict[str, str | None]:
    config_path = _SYGEN_HOME / "config" / "config.json"
    defaults: dict[str, str | None] = {"language": "auto", "model": "small", "command": None}
    if not config_path.exists():
        return defaults
    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
        section = data.get("transcription", {})
        return {
            "language": section.get("language", defaults["language"]),
            "model": section.get("model", defaults["model"]),
            "command": section.get("command", defaults["command"]),
        }
    except (json.JSONDecodeError, OSError):
        return defaults


# ---------------------------------------------------------------------------
# Strategies (synchronous – run via asyncio.to_thread)
# ---------------------------------------------------------------------------

def _transcribe_custom(path: Path, cfg: dict[str, str | None]) -> dict[str, str | None]:
    command = cfg.get("command")
    if not command:
        return {"error": "no custom command configured"}
    try:
        result = subprocess.run(
            [command, str(path)],
            capture_output=True,
            text=True,
            timeout=300,
            check=False,
            env={
                **os.environ,
                "TRANSCRIPTION_LANGUAGE": cfg["language"] or "auto",
                "TRANSCRIPTION_MODEL": cfg["model"] or "small",
            },
        )
    except FileNotFoundError:
        return {"error": f"custom transcription command not found: {command}"}
    except subprocess.TimeoutExpired:
        return {"error": f"custom command timed out: {command}"}

    if result.returncode != 0:
        return {"error": f"custom command failed (exit {result.returncode})"}

    transcript = result.stdout.strip()
    return {"transcript": transcript} if transcript else {"error": "empty output"}


def _transcribe_openai(path: Path, cfg: dict[str, str | None]) -> dict[str, str | None]:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        return {"error": "OPENAI_API_KEY not set"}
    try:
        from openai import OpenAI  # type: ignore[import-untyped]
    except ImportError:
        return {"error": "openai package not installed"}

    client = OpenAI(api_key=api_key)
    try:
        with path.open("rb") as f:
            kwargs: dict = {"model": "whisper-1", "file": f, "response_format": "verbose_json"}
            lang = cfg["language"]
            if lang and lang != "auto":
                kwargs["language"] = lang
            result = client.audio.transcriptions.create(**kwargs)
    except Exception as exc:
        return {"error": f"OpenAI API error: {exc}"}
    return {"transcript": result.text}


def _transcribe_local_whisper(path: Path, cfg: dict[str, str | None]) -> dict[str, str | None]:
    whisper_bin = shutil.which("whisper")
    if not whisper_bin:
        return {"error": "whisper CLI not found"}
    out_dir = path.parent
    cmd = [whisper_bin, str(path), "--model", cfg["model"] or "small",
           "--output_format", "json", "--output_dir", str(out_dir)]
    lang = cfg["language"]
    if lang and lang != "auto":
        cmd += ["--language", lang]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300, check=False)
    except subprocess.TimeoutExpired:
        return {"error": "whisper timed out"}
    if result.returncode != 0:
        return {"error": f"whisper failed: {result.stderr[:500]}"}
    json_out = out_dir / f"{path.stem}.json"
    if json_out.exists():
        try:
            data = json.loads(json_out.read_text())
        except (json.JSONDecodeError, OSError):
            json_out.unlink(missing_ok=True)
            return {"error": "Failed to parse whisper JSON output"}
        json_out.unlink(missing_ok=True)
        return {"transcript": data.get("text", "")}
    return {"transcript": result.stdout.strip()}


def _transcribe_whisper_cpp(path: Path, cfg: dict[str, str | None]) -> dict[str, str | None]:
    whisper_cli = shutil.which("whisper-cli")
    if not whisper_cli:
        return {"error": "whisper-cli not found"}
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return {"error": "ffmpeg not found"}
    model_name = f"ggml-{cfg['model'] or 'small'}.bin"
    model_path = Path.home() / ".local/share/whisper-cpp/models" / model_name
    if not model_path.exists():
        return {"error": f"whisper-cpp model not found: {model_path}"}
    wav_path = path.with_suffix(".temp.wav")
    try:
        subprocess.run(
            [ffmpeg, "-y", "-i", str(path), "-ar", "16000", "-ac", "1",
             "-c:a", "pcm_s16le", str(wav_path)],
            capture_output=True, text=True, check=True,
        )
    except subprocess.CalledProcessError:
        return {"error": "ffmpeg conversion failed"}
    cmd = [whisper_cli, "-m", str(model_path), "-f", str(wav_path), "--no-timestamps"]
    lang = cfg["language"]
    if lang and lang != "auto":
        cmd += ["-l", lang]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300, check=False)
    except subprocess.TimeoutExpired:
        wav_path.unlink(missing_ok=True)
        return {"error": "whisper-cli timed out"}
    wav_path.unlink(missing_ok=True)
    if result.returncode != 0:
        return {"error": f"whisper-cli failed: {result.stderr[:500]}"}
    return {"transcript": result.stdout.strip()}


# ---------------------------------------------------------------------------
# Sync entry point (called in a thread)
# ---------------------------------------------------------------------------

def _transcribe_sync(path: Path) -> str | None:
    """Try all transcription strategies, return transcript or *None*."""
    cfg = _load_transcription_config()
    strategies = []
    if cfg.get("command"):
        strategies.append(_transcribe_custom)
    strategies += [_transcribe_openai, _transcribe_local_whisper, _transcribe_whisper_cpp]

    errors: list[str] = []
    for strategy in strategies:
        result = strategy(path, cfg)
        if "transcript" in result and result["transcript"]:
            return result["transcript"]
        errors.append(result.get("error", "unknown"))

    logger.warning("All transcription strategies failed: %s", errors)
    return None


# ---------------------------------------------------------------------------
# Public async API
# ---------------------------------------------------------------------------

async def transcribe_file(path: Path, *, timeout: float = 30) -> str | None:
    """Transcribe an audio file asynchronously.

    Returns the transcript text, or *None* if all strategies fail or the
    *timeout* (seconds) is exceeded.
    """
    try:
        return await asyncio.wait_for(
            asyncio.to_thread(_transcribe_sync, path),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        logger.warning("Transcription timed out after %.0fs for %s", timeout, path)
        return None
    except Exception:
        logger.exception("Transcription failed for %s", path)
        return None
