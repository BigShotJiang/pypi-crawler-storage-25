# LLM project setup

[![doctest](https://github.com/Jogo2002/LLM_lab/actions/workflows/tests.yml/badge.svg)](https://github.com/Jogo2002/LLM_lab/actions/workflows/tests.yml)
[![integration-test](https://github.com/Jogo2002/LLM_lab/actions/workflows/integration-test.yml/badge.svg)](https://github.com/Jogo2002/LLM_lab/actions/workflows/integration-test.yml)

A command-line chat application built in Python that uses the Groq API to send prompts and display responses in an interactive REPL. The project is packaged so it can be tested with GitHub Actions and installed from PyPI as a command-line tool.

## PyPI

https://pypi.org/project/LLM-Lab-Setup/

## Installation

```bash
pip install LLM-Lab-Setup