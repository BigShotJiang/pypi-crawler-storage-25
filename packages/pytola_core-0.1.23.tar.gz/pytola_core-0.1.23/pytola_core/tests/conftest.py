"""Pytest configuration for pytola-core tests."""

import logging

import pytest

from pytola_core.patterns.registry import Registry


@pytest.fixture(autouse=True)
def _clear_registries():
    """Clear all registries before and after each test automatically.

    This fixture is auto-used by all tests to ensure clean state between tests.
    It runs once per test function, clearing registries both before and after.
    """
    Registry.clear_all()
    yield
    Registry.clear_all()


@pytest.fixture(autouse=True)
def _enable_log_propagation(caplog: pytest.LogCaptureFixture):
    """Enable log propagation for caplog to work properly.

    The logger module sets propagate=False which prevents caplog from
    capturing logs. This fixture temporarily enables propagation during tests.
    """
    # Get the logger instance used in the code
    log = logging.getLogger("pytola")
    original_propagate = log.propagate

    # Enable propagation so caplog can capture logs
    log.propagate = True

    yield

    # Restore original setting
    log.propagate = original_propagate
