from __future__ import annotations

import asyncio
import importlib
import inspect
import logging
import random
import time
from typing import Any

from vikhry.runtime import VU, bind_steps, resolve_every_delay
from vikhry.runtime.metrics import emit_metric, exception_fields, metric_scope
from vikhry.runtime.strategy import SequentialWeightedStrategy, StepStrategy
from vikhry.worker.redis_repo.state_repo import WorkerStateRepository
from vikhry.worker.services.metrics import WorkerMetricsPublisher
from vikhry.worker.services.resources import WorkerVUResources

logger = logging.getLogger(__name__)

DEFAULT_SCENARIO_IMPORT = "vikhry.runtime.defaults:IdleVU"


class WorkerVURuntime:
    def __init__(
        self,
        state_repo: WorkerStateRepository,
        *,
        worker_id: str,
        vu_type: type[VU],
        http_base_url: str = "",
        metric_id: str | None = None,
        idle_sleep_s: float = 0.05,
        startup_jitter_s: float = 0.005,
    ) -> None:
        self._state_repo = state_repo
        self._worker_id = worker_id
        self._vu_type = vu_type
        self._http_base_url = http_base_url
        self._metric_id = metric_id or f"worker:{worker_id}"
        self._idle_sleep_s = max(0.01, idle_sleep_s)
        self._startup_jitter_s = max(0.0, startup_jitter_s)
        self._metrics = WorkerMetricsPublisher(
            state_repo,
            worker_id=self._worker_id,
            metric_id=self._metric_id,
        )

    async def run_user(
        self,
        user_id: str,
        init_params: dict[str, Any] | None = None,
    ) -> None:
        if self._startup_jitter_s > 0:
            startup_rng = random.Random(f"{self._worker_id}:{user_id}:startup_jitter")
            jitter_delay_s = startup_rng.uniform(0.0, self._startup_jitter_s)
            if jitter_delay_s > 0:
                await asyncio.sleep(jitter_delay_s)

        resources = WorkerVUResources(self._state_repo)
        vu = self._vu_type(
            user_id=user_id,
            worker_id=self._worker_id,
            resources=resources,
            http_base_url=self._http_base_url,
        )
        init_kwargs = dict(init_params or {})
        user_metric_emitter = self._metrics.bind_user(user_id)

        completed_steps: set[str] = set()
        next_allowed_at: dict[str, float] = {}
        rng = random.Random(f"{self._worker_id}:{user_id}")
        steps = bind_steps(vu)
        step_strategy = _resolve_step_strategy(vu.step_strategy)
        user_is_active = False

        try:
            with metric_scope(emitter=user_metric_emitter):
                try:
                    with metric_scope(stage="on_init"):
                        if init_kwargs:
                            await vu.on_init(**init_kwargs)
                        else:
                            await vu.on_init()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    await self._emit_lifecycle_failure(stage="on_init", error=exc)
                    raise
                vu.ensure_http_client()
                try:
                    with metric_scope(stage="on_start"):
                        await vu.on_start()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    await self._emit_lifecycle_failure(stage="on_start", error=exc)
                    raise
                await self._state_repo.add_worker_active_user(self._worker_id, user_id)
                user_is_active = True
                while True:
                    now = time.monotonic()
                    selection = step_strategy.select(
                        steps=steps,
                        completed_steps=completed_steps,
                        next_allowed_at=next_allowed_at,
                        now=now,
                        rng=rng,
                    )

                    if not selection.steps:
                        if selection.nearest_ready_at is None:
                            await asyncio.sleep(self._idle_sleep_s)
                        else:
                            await asyncio.sleep(
                                max(self._idle_sleep_s, selection.nearest_ready_at - now)
                            )
                        continue

                    if len(selection.steps) == 1:
                        await self._execute_step(
                            user_id=user_id,
                            completed_steps=completed_steps,
                            next_allowed_at=next_allowed_at,
                            bound_step=selection.steps[0],
                        )
                        continue

                    await asyncio.gather(
                        *(
                            self._execute_step(
                                user_id=user_id,
                                completed_steps=completed_steps,
                                next_allowed_at=next_allowed_at,
                                bound_step=bound_step,
                            )
                            for bound_step in selection.steps
                        )
                    )
        except asyncio.CancelledError:
            raise
        finally:
            try:
                if user_is_active:
                    await self._state_repo.remove_worker_active_user(self._worker_id, user_id)
                await vu.on_stop()
            finally:
                await vu.close()

    async def _execute_step(
        self,
        *,
        user_id: str,
        completed_steps: set[str],
        next_allowed_at: dict[str, float],
        bound_step: Any,
    ) -> None:
        spec = bound_step.spec
        started_at = time.perf_counter()
        error_type: str | None = None
        error_message: str | None = None
        traceback: str | None = None
        success = False
        cancelled = False

        with metric_scope(step=spec.step_name):
            try:
                if spec.timeout is None:
                    await bound_step.call()
                else:
                    async with asyncio.timeout(spec.timeout):
                        await bound_step.call()
                success = True
                completed_steps.add(spec.step_name)
            except asyncio.CancelledError:
                cancelled = True
                raise
            except Exception as exc:  # noqa: BLE001
                error_payload = exception_fields(exc)
                error_type = error_payload["error_type"]
                error_message = error_payload["error_message"]
                traceback = error_payload["traceback"]
                logger.exception(
                    "VU step raised exception (worker_id=%s, user_id=%s, step=%s)",
                    self._worker_id,
                    user_id,
                    spec.step_name,
                )
            finally:
                elapsed_ms = round((time.perf_counter() - started_at) * 1000, 3)
                try:
                    every_delay = resolve_every_delay(spec.every_s)
                except Exception:  # noqa: BLE001
                    logger.warning(
                        "invalid every_s for step, fallback to immediate scheduling "
                        "(worker_id=%s, step=%s)",
                        self._worker_id,
                        spec.step_name,
                        exc_info=True,
                    )
                    every_delay = 0.0
                next_allowed_at[spec.step_name] = (
                    time.monotonic() + every_delay if every_delay > 0 else 0.0
                )
                if not cancelled:
                    await emit_metric(
                        name=spec.step_name,
                        status=success,
                        time=elapsed_ms,
                        source="step",
                        stage="execute",
                        result_code="STEP_OK" if success else "STEP_EXCEPTION",
                        result_category="ok" if success else "exception",
                        fatal=False,
                        error_type=error_type,
                        error_message=error_message,
                        traceback=traceback,
                    )

    async def _emit_lifecycle_failure(self, *, stage: str, error: Exception) -> None:
        payload = exception_fields(error)
        logger.exception(
            "VU lifecycle hook failed (worker_id=%s, stage=%s)",
            self._worker_id,
            stage,
        )
        await emit_metric(
            name=f"lifecycle/{stage}",
            step=stage,
            status=False,
            time=0.0,
            source="lifecycle",
            stage=stage,
            result_code="LIFECYCLE_EXCEPTION",
            result_category="exception",
            fatal=True,
            error_type=payload["error_type"],
            error_message=payload["error_message"],
            traceback=payload["traceback"],
        )


def _resolve_step_strategy(candidate: object) -> StepStrategy[Any]:
    if candidate is None:
        return SequentialWeightedStrategy()
    if isinstance(candidate, type):
        candidate = candidate()
    if not isinstance(candidate, StepStrategy):
        raise TypeError("VU step_strategy must implement select(...)")
    return candidate


def load_vu_type(import_path: str) -> type[VU]:
    normalized = (import_path or "").strip()
    if not normalized:
        normalized = DEFAULT_SCENARIO_IMPORT

    module_name, sep, attr_name = normalized.partition(":")
    if not sep or not module_name or not attr_name:
        raise ValueError(
            "scenario import path must use format `module.path:ClassName`"
        )

    module = importlib.import_module(module_name)
    candidate = getattr(module, attr_name, None)
    if candidate is None:
        raise ValueError(f"scenario class `{attr_name}` not found in module `{module_name}`")
    if not inspect.isclass(candidate):
        raise ValueError(f"scenario target `{normalized}` must be a class")
    if not issubclass(candidate, VU):
        raise ValueError(f"scenario class `{normalized}` must inherit from VU")
    return candidate
