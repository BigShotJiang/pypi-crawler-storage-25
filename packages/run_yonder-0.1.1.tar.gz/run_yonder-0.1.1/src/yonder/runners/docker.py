from __future__ import annotations

import base64
import hashlib
import logging
import os
import sys
import tempfile
import uuid
from threading import RLock
from typing import Callable, Iterable, List, Mapping, Optional, Tuple, Union

from .base import Runner

_log = logging.getLogger("yonder.runners.docker")


def _resolve_auto_source_path() -> str:
    """Resolve ``source_path="auto"`` to the directory of the caller's file.

    Walks up the call stack and returns ``dirname(__file__)`` of the first
    frame whose ``__file__`` is *not* inside the yonder package itself —
    that way subclasses of :class:`DockerRunner` that ``super().__init__(
    source_path="auto")`` still resolve to the *user's* file, not the
    subclass's.

    Raises :class:`ValueError` if no usable frame is found (REPL/Jupyter
    contexts where ``__file__`` isn't defined).
    """
    yonder_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    frame = sys._getframe(1)
    while frame is not None:
        fname = frame.f_globals.get("__file__")
        if fname:
            abs_fname = os.path.abspath(fname)
            if not abs_fname.startswith(yonder_root + os.sep):
                return os.path.dirname(abs_fname)
        frame = frame.f_back
    raise ValueError(
        "source_path='auto' could not find a caller with __file__ "
        "(REPL or notebook context); pass an explicit path instead."
    )


def _bootstrap_with_payload(payload: bytes, mode: str = "cloudpickle") -> str:
    """Build a self-contained `python -c` script with the payload inlined.

    docker-py 7.x has rough edges feeding stdin to exec sessions over the
    hijacked HTTP socket, so we sidestep stdin entirely by embedding the
    payload as a base64 literal in the command itself. The bootstrap
    decodes it, runs the function, and writes the result envelope to
    stdout — which `exec_run`/`container.logs` capture cleanly.

    ``mode`` selects which bootstrap to emit:

    - ``"cloudpickle"`` — the payload is a cloudpickled ``{"func", "args",
      "kwargs"}`` dict. The container unpickles it (requires cloudpickle
      installed there) and calls the function.
    - ``"reference"`` — the payload is a stdlib-pickled ``{"module",
      "qualname", "args", "kwargs"}`` dict. The container imports the
      module under its own Python, resolves the function by qualname, and
      calls it. No cloudpickle required; bytecode never crosses the wire.
      A small ``yonder`` shim module is installed if yonder isn't on the
      container's path, so user code using ``@yonder(...)`` imports
      cleanly without yonder being baked in.
    """
    encoded = base64.b64encode(payload).decode("ascii")
    if mode == "reference":
        return (
            "import base64, importlib, pickle, sys, types\n"
            # Install a yonder shim if no real yonder is importable in the
            # container, OR if `import yonder` resolves to something that
            # doesn't expose a callable `yonder` decorator (e.g. an
            # accidental namespace package shadowing the name). The shim
            # returns the function unchanged so user modules using
            # @yonder(...) still import cleanly.
            "_install_shim = False\n"
            "try:\n"
            "    import yonder as _y\n"
            "    if not callable(getattr(_y, 'yonder', None)):\n"
            "        _install_shim = True\n"
            "except ImportError:\n"
            "    _install_shim = True\n"
            "if _install_shim:\n"
            "    _shim = types.ModuleType('yonder')\n"
            "    def _noop(*a, **kw):\n"
            "        def _d(f):\n"
            "            return f\n"
            "        return _d\n"
            "    _shim.yonder = _noop\n"
            "    sys.modules['yonder'] = _shim\n"
            f"_p = pickle.loads(base64.b64decode({encoded!r}))\n"
            "_mod = importlib.import_module(_p['module'])\n"
            "_obj = _mod\n"
            "for _part in _p['qualname'].split('.'):\n"
            "    _obj = getattr(_obj, _part)\n"
            # If the resolved attribute is a yonder-decorated wrapper,
            # unwrap to the inner function to avoid recursing through the
            # runner dispatcher inside the container.
            "_inner = getattr(_obj, '__yonder_inner__', _obj)\n"
            "try:\n"
            "    _v = _inner(*_p['args'], **_p['kwargs'])\n"
            "    _e = {'status': 'ok', 'value': _v}\n"
            "except BaseException as _exc:\n"
            "    _e = {'status': 'err', 'exception': _exc}\n"
            "sys.stdout.buffer.write(pickle.dumps(_e))\n"
        )
    return (
        "import base64, sys\n"
        "import cloudpickle\n"
        f"_p = cloudpickle.loads(base64.b64decode({encoded!r}))\n"
        "try:\n"
        "    _v = _p['func'](*_p['args'], **_p['kwargs'])\n"
        "    _e = {'status': 'ok', 'value': _v}\n"
        "except BaseException as _exc:\n"
        "    _e = {'status': 'err', 'exception': _exc}\n"
        "sys.stdout.buffer.write(cloudpickle.dumps(_e))\n"
    )


class DockerRunner(Runner):
    """A Runner backed by the Docker SDK for Python (``docker-py``).

    Specify the runtime one of three ways (exactly one is required):

    - ``image="repo/name:tag"`` — pull/use an existing image. yonder creates
      and manages the container.
    - ``dockerfile="path/to/Dockerfile"`` — build an image locally first.
      Context defaults to the Dockerfile's parent; override with
      ``build_context=``. Pass ``build_args={}`` for ARGs.
    - ``container="name-or-id"`` — attach to a container you manage outside
      yonder. yonder will ``start()`` it if it's stopped but will never
      remove it on ``close()``. ``env``/``mounts``/``build_args``/
      ``on_demand`` are properties of the existing container and may not
      be set in this mode.

    Two execution modes (image/dockerfile only):

    - ``on_demand=False`` (default): a long-lived container is created lazily
      on the first call (or eagerly via :meth:`start`) and reused. Call
      :meth:`close` (or use the runner as a context manager) to remove it.
    - ``on_demand=True``: a fresh container is started for every call and
      removed after — no shared state between calls.

    Requires the ``docker`` package: ``pip install 'yonder[docker]'``.
    """

    def __init__(
        self,
        image: Optional[str] = None,
        dockerfile: Optional[str] = None,
        container: Optional[str] = None,
        build_context: Optional[str] = None,
        build_args: Optional[Mapping[str, str]] = None,
        env: Optional[Mapping[str, str]] = None,
        mounts: Optional[Mapping[str, str]] = None,
        on_demand: bool = False,
        name: Optional[str] = None,
        inject_cloudpickle: bool = False,
        when: Optional[Callable[[], bool]] = None,
        mode: str = "cloudpickle",
        source_path: Optional[Union[str, Iterable[str]]] = None,
        client=None,
    ):
        try:
            import docker  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "DockerRunner requires the docker SDK. "
                "Install with: pip install 'yonder[docker]'"
            ) from exc

        sources = (image, dockerfile, container)
        if sum(s is not None for s in sources) != 1:
            raise TypeError(
                "DockerRunner requires exactly one of "
                "`image=`, `dockerfile=`, or `container=`"
            )

        if mode not in ("cloudpickle", "reference"):
            raise ValueError(
                f"mode must be 'cloudpickle' or 'reference', got {mode!r}"
            )

        self._client = client
        self._container = None
        self._lock = RLock()
        self._python_version_checked = False
        self.when = when
        self.mode = mode

        if container is not None:
            if env or mounts or build_args or build_context or source_path:
                raise TypeError(
                    "`container=` attaches to an existing container; "
                    "env/mounts/build_args/build_context/source_path are "
                    "properties of that container and must not be set here"
                )
            if on_demand:
                raise TypeError(
                    "`container=` cannot be combined with on_demand=True"
                )
            if inject_cloudpickle:
                raise TypeError(
                    "`inject_cloudpickle` is not supported with `container=`; "
                    "ensure cloudpickle is already installed in that container"
                )
            self._mode = "attach"
            self.container_ref: Optional[str] = container
            # Use the existing container's name as the runner name.
            self.name = name or container
            self.dockerfile = None
            self.build_context = None
            self.build_args = {}
            self.env = {}
            self.mounts = {}
            self.on_demand = False
            self.inject_cloudpickle = False
            self._inject_base: Optional[str] = None
            self.image = ""  # not applicable; populated on attach
            self._image_ready = True
            self._owned = False  # we did not create this container
        else:
            if inject_cloudpickle and dockerfile is not None:
                raise TypeError(
                    "`inject_cloudpickle` is not supported with `dockerfile=`; "
                    "add `RUN pip install cloudpickle` to your Dockerfile instead"
                )
            self._mode = "build" if dockerfile is not None else "image"
            self.container_ref = None
            self.name = name or f"yonder-{uuid.uuid4().hex[:8]}"
            self.dockerfile = dockerfile
            self.build_context = build_context
            self.build_args = dict(build_args or {})
            self.env = dict(env or {})
            self.mounts = dict(mounts or {})
            self.on_demand = on_demand
            self.inject_cloudpickle = inject_cloudpickle
            self._apply_source_path(source_path)
            # For image mode with injection, derive a tag from a hash of the
            # base image so re-runs hit the docker layer cache without
            # accumulating orphan tags.
            if inject_cloudpickle:
                self._inject_base = image
                digest = hashlib.sha256(image.encode("utf-8")).hexdigest()[:12]
                self.image = f"yonder-cloudpickle:{digest}"
                self._image_ready = False
            else:
                self._inject_base = None
                # For dockerfile builds, image is a generated tag populated
                # by `_ensure_image_built`. For image mode, use the
                # user-supplied tag.
                self.image = image if image is not None else f"{self.name}:latest"
                self._image_ready = image is not None and dockerfile is None
            self._owned = True

    @property
    def client(self):
        if self._client is None:
            import docker

            self._client = docker.from_env()
        return self._client

    def start(self) -> None:
        """Bring the runner to "available": build/pull the image, and for
        persistent runners, create and start the container."""
        # Fail fast if the daemon isn't reachable, instead of hanging
        # inside a build/pull request.
        self.client.ping()
        self._ensure_image_built()
        if not self.on_demand:
            self._ensure_container_started()
        self._check_python_version()

    def run(self, payload: bytes) -> bytes:
        self._ensure_image_built()
        if self.on_demand:
            self._check_python_version()
            return self._run_oneshot(payload)
        self._ensure_container_started()
        self._check_python_version()
        return self._exec_in_persistent(payload)

    def close(self) -> None:
        with self._lock:
            container = self._container
            self._container = None
        if container is None:
            return
        if not self._owned:
            # We attached to a container we didn't create; never remove it.
            _log.info("detaching from container %s", self.name)
            return
        _log.info("removing container %s", self.name)
        try:
            container.remove(force=True)
        except Exception:
            # Cleanup is best-effort; the container may already be gone.
            pass

    def _ensure_image_built(self) -> None:
        with self._lock:
            if self._image_ready:
                return
            if self.inject_cloudpickle:
                self._build_injected_image()
            elif self.dockerfile is not None:
                self._build_from_dockerfile()
            else:
                self._ensure_image_present()
            self._image_ready = True

    def _build_from_dockerfile(self) -> None:
        dockerfile_path = os.path.abspath(self.dockerfile)
        context = os.path.abspath(
            self.build_context or os.path.dirname(dockerfile_path) or "."
        )
        try:
            rel_dockerfile = os.path.relpath(dockerfile_path, context)
        except ValueError:
            rel_dockerfile = dockerfile_path
        _log.info(
            "building image %s from %s (context=%s)",
            self.image, dockerfile_path, context,
        )
        self._run_build(
            path=context,
            dockerfile=rel_dockerfile,
            tag=self.image,
            buildargs=self.build_args,
        )

    def _build_injected_image(self) -> None:
        """Build a derived image: FROM <base> + RUN pip install cloudpickle.

        Tag is derived from a hash of the base image so identical base ->
        identical tag, which lets the Docker layer cache make this cheap
        across re-runs.
        """
        with tempfile.TemporaryDirectory(prefix="yonder-inject-") as tmpdir:
            dockerfile_path = os.path.join(tmpdir, "Dockerfile")
            with open(dockerfile_path, "w") as f:
                f.write(f"FROM {self._inject_base}\n")
                f.write("RUN pip install --no-cache-dir cloudpickle\n")
            _log.info(
                "injecting cloudpickle: FROM %s -> %s",
                self._inject_base, self.image,
            )
            self._run_build(
                path=tmpdir,
                dockerfile="Dockerfile",
                tag=self.image,
                buildargs={},
            )

    def _run_build(self, *, path: str, dockerfile: str, tag: str, buildargs: Mapping[str, str]) -> None:
        """Drive ``client.api.build`` and stream output to the logger."""
        stream = self.client.api.build(
            path=path,
            dockerfile=dockerfile,
            tag=tag,
            buildargs=dict(buildargs),
            rm=True,
            decode=True,
        )
        image_id: Optional[str] = None
        for chunk in stream:
            if "error" in chunk:
                raise RuntimeError(f"docker build failed: {chunk['error'].rstrip()}")
            if "stream" in chunk:
                line = chunk["stream"].rstrip()
                if line:
                    _log.info("build: %s", line)
            if "aux" in chunk and isinstance(chunk["aux"], dict):
                image_id = chunk["aux"].get("ID") or image_id
        _log.info("built image %s (%s)", tag, image_id or "id-unknown")

    def _ensure_image_present(self) -> None:
        import docker.errors

        try:
            self.client.images.get(self.image)
            return
        except docker.errors.ImageNotFound:
            pass
        _log.info("pulling image %s", self.image)
        for chunk in self.client.api.pull(self.image, stream=True, decode=True):
            status = chunk.get("status")
            if not status:
                continue
            cid = chunk.get("id")
            prefix = f"[{cid}] " if cid else ""
            _log.debug("pull: %s%s", prefix, status)

    def _ensure_container_started(self) -> None:
        with self._lock:
            if self._container is not None:
                return
            if self._mode == "attach":
                self._container = self._attach_to_existing()
            else:
                _log.info(
                    "starting persistent container %s (image=%s)", self.name, self.image
                )
                self._container = self.client.containers.run(
                    self.image,
                    command=["sleep", "infinity"],
                    name=self.name,
                    detach=True,
                    environment=self.env,
                    volumes=self._volumes_dict(),
                )

    def _attach_to_existing(self):
        import docker.errors

        try:
            container = self.client.containers.get(self.container_ref)
        except docker.errors.NotFound as exc:
            raise RuntimeError(
                f"DockerRunner: container {self.container_ref!r} not found"
            ) from exc
        container.reload()
        if container.status != "running":
            _log.info(
                "starting existing container %s (was %s)",
                container.name, container.status,
            )
            container.start()
            container.reload()
        # Record the image so logs/error messages stay informative.
        image_tags = getattr(container.image, "tags", None) or [container.image.id]
        self.image = image_tags[0]
        _log.info("attached to container %s (image=%s)", container.name, self.image)
        return container

    def _exec_in_persistent(self, payload: bytes) -> bytes:
        _log.debug("exec in container %s (%d bytes)", self.name, len(payload))
        result = self._container.exec_run(
            ["python", "-c", _bootstrap_with_payload(payload, self.mode)],
            stdout=True,
            stderr=True,
            demux=True,
        )
        stdout, stderr = result.output
        _check_envelope(stdout or b"", stderr or b"", result.exit_code)
        return stdout

    def _run_oneshot(self, payload: bytes) -> bytes:
        _log.debug("running one-shot container from image %s", self.image)
        client = self.client
        container = client.containers.create(
            self.image,
            command=["python", "-c", _bootstrap_with_payload(payload, self.mode)],
            environment=self.env,
            volumes=self._volumes_dict(),
        )
        try:
            container.start()
            exit_status = container.wait()
            stdout = container.logs(stdout=True, stderr=False)
            stderr = container.logs(stdout=False, stderr=True)
            _check_envelope(stdout, stderr, exit_status.get("StatusCode"))
            return stdout
        finally:
            try:
                container.remove(force=True)
            except Exception:
                pass

    def _volumes_dict(self) -> dict:
        return {
            host: {"bind": ctr, "mode": "rw"}
            for host, ctr in self.mounts.items()
        }

    def translate_host_path(self, path: str) -> str:
        """Translate a host path to its in-container path using ``mounts``.

        Walks ``self.mounts`` (``{host_root: container_root}``) and rewrites
        ``path`` to the equivalent location inside the container. Raises
        :class:`ValueError` if no mount covers the path.
        """
        if not self.mounts:
            raise ValueError(
                f"HostPath({path!r}) cannot be translated: this runner has "
                f"no mounts. Pass `mounts=` (or `source_path=`) to the "
                f"DockerRunner so the path is reachable inside the container."
            )
        abs_path = os.path.abspath(path)
        for host_root, container_root in self.mounts.items():
            host_abs = os.path.abspath(host_root)
            if abs_path == host_abs:
                return container_root
            if abs_path.startswith(host_abs + os.sep):
                rel = os.path.relpath(abs_path, host_abs)
                return os.path.join(container_root, rel)
        raise ValueError(
            f"HostPath({path!r}) is not covered by any mount on this "
            f"runner. Mounts: {dict(self.mounts)}"
        )

    def _apply_source_path(self, source_path) -> None:
        """Mount one or more host directories into the container and add
        them to PYTHONPATH. No-op when ``source_path`` is None.

        ``source_path="auto"`` (or ``"auto"`` as an entry in a list)
        resolves to the directory of the file that constructed the
        runner — useful to drop the ``HERE = os.path.dirname(__file__)``
        boilerplate.

        Each entry is mounted at ``/workspace/<basename>``; conflicts on
        the basename are disambiguated with an index. PYTHONPATH is built
        from the resulting in-container paths (existing PYTHONPATH from
        ``env=`` is preserved and appended after the new entries).
        """
        if source_path is None:
            return
        # Translate "auto" sentinels to the caller's __file__ directory.
        if source_path == "auto":
            source_path = _resolve_auto_source_path()
        elif isinstance(source_path, (list, tuple)):
            source_path = [
                _resolve_auto_source_path() if p == "auto" else p
                for p in source_path
            ]
        if isinstance(source_path, (str, bytes, os.PathLike)):
            paths: List[str] = [os.fspath(source_path)]
        else:
            paths = [os.fspath(p) for p in source_path]

        seen: dict = {}
        container_paths: List[str] = []
        for p in paths:
            abs_host = os.path.abspath(p)
            base = os.path.basename(abs_host.rstrip("/")) or "root"
            target = f"/workspace/{base}"
            if target in seen:
                target = f"/workspace/{base}-{len(seen)}"
            seen[target] = abs_host
            self.mounts[abs_host] = target
            container_paths.append(target)

        existing = self.env.get("PYTHONPATH")
        if existing:
            self.env["PYTHONPATH"] = ":".join(container_paths + [existing])
        else:
            self.env["PYTHONPATH"] = ":".join(container_paths)

    def _check_python_version(self) -> None:
        # cloudpickle ships function bytecode, which the CPython unmarshaller
        # rejects across minor versions ("code() takes at most 16 arguments
        # (18 given)" and friends). Catch the mismatch up front so the user
        # sees an actionable error instead of a stack trace from the
        # bootstrap. Reference mode imports the user's module under the
        # container's Python, so version skew is harmless and the check
        # is skipped.
        if self._python_version_checked:
            return
        if self.mode == "reference":
            self._python_version_checked = True
            return
        container_version = self._probe_container_python_version()
        host_version = (sys.version_info.major, sys.version_info.minor)
        if container_version != host_version:
            host_str = f"{host_version[0]}.{host_version[1]}"
            ctr_str = f"{container_version[0]}.{container_version[1]}"
            target = self.container_ref or self.image
            raise RuntimeError(
                f"Python minor version mismatch: container ({target}) runs"
                f"Python {ctr_str}, host runs Python {host_str}. cloudpickle"
                f"pickles function bytecode, which is not portable across"
                f"CPython minor versions.\n"
                f" Possible fixes:\n"
                f"   - Run your script in a Python {ctr_str} virtualenv on the host, so the bytecode is compatible with the container's Python.\n"
                f"   - Use/build an image whose Python matches your host version (currently {host_str}).\n"
                f"   - Switch the runner's mode to 'reference', which is portable across python versions\n"
            )
        self._python_version_checked = True

    def _probe_container_python_version(self) -> Tuple[int, int]:
        snippet = (
            "import sys; "
            "print(sys.version_info.major, sys.version_info.minor)"
        )
        stdout: bytes
        stderr: bytes
        if self._container is not None:
            # persistent / attached — exec in the running container
            result = self._container.exec_run(
                ["python", "-c", snippet],
                stdout=True,
                stderr=True,
                demux=True,
            )
            out, err = result.output
            stdout = out or b""
            stderr = err or b""
        else:
            # on-demand — spin up a one-shot probe container
            container = self.client.containers.create(
                self.image,
                command=["python", "-c", snippet],
            )
            try:
                container.start()
                container.wait()
                stdout = container.logs(stdout=True, stderr=False)
                stderr = container.logs(stdout=False, stderr=True)
            finally:
                try:
                    container.remove(force=True)
                except Exception:
                    pass

        text = stdout.decode("utf-8", "replace").strip()
        parts = text.split()
        if len(parts) != 2:
            err_text = stderr.decode("utf-8", "replace").strip() or "<no stderr>"
            raise RuntimeError(
                "could not probe container Python version "
                f"(stdout={text!r}, stderr={err_text})"
            )
        _log.debug("container python version: %s", text)
        return (int(parts[0]), int(parts[1]))


def _check_envelope(stdout: bytes, stderr: bytes, exit_code: Optional[int]) -> None:
    if not stdout:
        msg = stderr.decode("utf-8", "replace").strip() or "<no stderr>"
        raise RuntimeError(
            f"yonder runner returned no stdout (exit_code={exit_code}). stderr:\n{msg}"
        )
