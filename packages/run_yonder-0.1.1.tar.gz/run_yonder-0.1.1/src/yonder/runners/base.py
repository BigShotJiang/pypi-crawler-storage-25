from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable, Optional


class Runner(ABC):
    """A self-contained execution target for a yonder-decorated function.

    Concrete runners hold their own configuration (image, env, mounts, etc.)
    and expose a single :meth:`run` method that takes a cloudpickled payload
    of the form ``{"func": ..., "args": (...), "kwargs": {...}}`` and returns
    the cloudpickled envelope produced by the in-container bootstrap.

    :meth:`start` and :meth:`close` are optional lifecycle hooks; the default
    implementations are no-ops, which is correct for stateless / on-demand
    runners. Long-lived runners override them to manage their container.

    ``when`` is an optional zero-arg predicate stored on the runner itself.
    If set and it returns ``False``, the decorator skips this runner and
    runs the function locally — independent of any ``when=`` passed to the
    ``@yonder`` decorator. It composes with the decorator's predicate as
    AND: the runner is used only when both return ``True``.

    ``mode`` selects the transport. ``"cloudpickle"`` (default) ships the
    function as bytecode via cloudpickle; the host and container Pythons
    must match minor versions. ``"reference"`` ships the function as
    ``(module, qualname, args, kwargs)`` and lets the container import
    its own copy — bytecode never crosses the wire and host/container
    Python versions can differ. Reference mode requires the function to
    be defined at module scope in a non-``__main__`` module.
    """

    when: Optional[Callable[[], bool]] = None
    mode: str = "cloudpickle"

    @abstractmethod
    def run(self, payload: bytes) -> bytes: ...

    def translate_host_path(self, path: str) -> str:
        """Translate a host-side path to its equivalent inside the runner.

        Called by the decorator on every :class:`yonder.HostPath` it finds
        in a call's args/kwargs before dispatching. Default implementation
        raises — subclasses that mount host paths into the runner (e.g.
        :class:`yonder.DockerRunner`) should override.

        Should raise :class:`ValueError` if no mount on this runner covers
        ``path``.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support HostPath translation. "
            f"Pass the in-runner path directly instead."
        )

    def start(self) -> None:
        """Optional eager initialization. Default no-op."""

    def close(self) -> None:
        """Optional cleanup. Default no-op."""

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
