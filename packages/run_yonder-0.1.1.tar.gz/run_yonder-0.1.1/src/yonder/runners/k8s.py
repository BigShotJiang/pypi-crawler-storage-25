from __future__ import annotations

import base64
import logging
import uuid
from threading import RLock
from typing import Optional

from .base import Runner

_log = logging.getLogger("yonder.runners.k8s")


def _bootstrap_with_payload(payload: bytes) -> str:
    """Build a self-contained ``python -c`` script with the payload inlined.

    Kubernetes pod exec streams data over a WebSocket with channel framing,
    and the kubernetes Python client returns stdout/stderr as text by default.
    To survive any text-mode coercion and channel quirks, the envelope is
    base64-encoded on the pod side before it hits stdout; the runner
    base64-decodes it back.
    """
    encoded = base64.b64encode(payload).decode("ascii")
    return (
        "import base64, sys\n"
        "import cloudpickle\n"
        f"_p = cloudpickle.loads(base64.b64decode({encoded!r}))\n"
        "try:\n"
        "    _v = _p['func'](*_p['args'], **_p['kwargs'])\n"
        "    _e = {'status': 'ok', 'value': _v}\n"
        "except BaseException as _exc:\n"
        "    _e = {'status': 'err', 'exception': _exc}\n"
        "sys.stdout.write(base64.b64encode(cloudpickle.dumps(_e)).decode('ascii'))\n"
    )


class K8sRunner(Runner):
    """A Runner that execs Python inside an existing Kubernetes pod.

    Specify the target pod one of two ways (exactly one is required):

    - ``pod="pod-name"`` — attach to a specific pod by name.
    - ``selector="key=value,key2=value2"`` — a Kubernetes label selector.
      The first Running pod that matches is used. Resolution is lazy —
      it happens on the first call (or eagerly via :meth:`start`).

    Other options:

    - ``namespace`` — pod namespace (default ``"default"``).
    - ``container`` — container within the pod (default: the pod's first
      container).
    - ``kubeconfig`` — path to a kubeconfig file. If omitted, standard
      KUBECONFIG / ``~/.kube/config`` discovery is used; failing that, the
      in-cluster service-account config is loaded.
    - ``context`` — kubeconfig context name.
    - ``name`` — runner name (auto-derived from pod/selector if omitted).
    - ``api_client`` — a pre-built ``kubernetes.client.ApiClient``. When
      provided, ``kubeconfig`` and ``context`` are ignored.

    The pod is treated like an externally-managed container — yonder never
    creates or removes it. :meth:`close` is a no-op.

    Requires the ``kubernetes`` package: ``pip install 'yonder[k8s]'``.
    The target container must have ``python`` on ``PATH`` and
    ``cloudpickle`` installed.
    """

    def __init__(
        self,
        pod: Optional[str] = None,
        selector: Optional[str] = None,
        namespace: str = "default",
        container: Optional[str] = None,
        kubeconfig: Optional[str] = None,
        context: Optional[str] = None,
        name: Optional[str] = None,
        api_client=None,
    ):
        try:
            import kubernetes  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "K8sRunner requires the kubernetes client. "
                "Install with: pip install 'yonder[k8s]'"
            ) from exc

        if sum(s is not None for s in (pod, selector)) != 1:
            raise TypeError(
                "K8sRunner requires exactly one of `pod=` or `selector=`"
            )

        self.pod = pod
        self.selector = selector
        self.namespace = namespace
        self.container = container
        self.kubeconfig = kubeconfig
        self.context = context
        self._api_client = api_client
        self._core_v1 = None
        self._lock = RLock()
        self._resolved_pod: Optional[str] = pod
        self._resolved_container: Optional[str] = container

        if name is not None:
            self.name = name
        elif pod is not None:
            self.name = pod
        else:
            self.name = f"yonder-k8s-{uuid.uuid4().hex[:8]}"

    @property
    def core_v1(self):
        if self._core_v1 is None:
            from kubernetes import client, config

            if self._api_client is None:
                try:
                    config.load_kube_config(
                        config_file=self.kubeconfig, context=self.context
                    )
                except Exception:
                    config.load_incluster_config()
                self._api_client = client.ApiClient()
            self._core_v1 = client.CoreV1Api(self._api_client)
        return self._core_v1

    def start(self) -> None:
        """Resolve the target pod/container eagerly."""
        with self._lock:
            self._ensure_target_resolved()

    def run(self, payload: bytes) -> bytes:
        with self._lock:
            self._ensure_target_resolved()
            pod = self._resolved_pod
            ctr = self._resolved_container

        from kubernetes.client.rest import ApiException
        from kubernetes.stream import stream

        bootstrap = _bootstrap_with_payload(payload)
        _log.debug(
            "exec in pod %s/%s container=%s (%d bytes)",
            self.namespace, pod, ctr, len(payload),
        )
        kwargs = dict(
            name=pod,
            namespace=self.namespace,
            command=["python", "-c", bootstrap],
            stderr=True,
            stdin=False,
            stdout=True,
            tty=False,
            _preload_content=False,
        )
        if ctr is not None:
            kwargs["container"] = ctr

        try:
            ws = stream(self.core_v1.connect_get_namespaced_pod_exec, **kwargs)
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: pod exec failed for {self.namespace}/{pod}: {exc}"
            ) from exc

        stdout_chunks = []
        stderr_chunks = []
        try:
            while ws.is_open():
                ws.update(timeout=1)
                if ws.peek_stdout():
                    stdout_chunks.append(ws.read_stdout())
                if ws.peek_stderr():
                    stderr_chunks.append(ws.read_stderr())
            # Drain anything buffered after the channel closed.
            if ws.peek_stdout():
                stdout_chunks.append(ws.read_stdout())
            if ws.peek_stderr():
                stderr_chunks.append(ws.read_stderr())
        finally:
            ws.close()

        stdout = "".join(stdout_chunks).strip()
        stderr = "".join(stderr_chunks)

        if not stdout:
            msg = stderr.strip() or "<no stderr>"
            raise RuntimeError(
                f"yonder runner returned no stdout from pod "
                f"{self.namespace}/{pod}. stderr:\n{msg}"
            )
        try:
            return base64.b64decode(stdout)
        except Exception as exc:
            raise RuntimeError(
                f"K8sRunner: failed to decode envelope from pod "
                f"{self.namespace}/{pod}: {exc}\n"
                f"raw stdout (truncated): {stdout[:200]!r}\n"
                f"stderr: {stderr.strip() or '<no stderr>'}"
            ) from exc

    def close(self) -> None:
        # Pods are externally managed; nothing to clean up.
        _log.info("detaching from pod %s/%s", self.namespace, self._resolved_pod or self.pod or self.selector)

    def _ensure_target_resolved(self) -> None:
        if self._resolved_pod is not None and self._resolved_container is not None:
            return

        pod_obj = None
        if self._resolved_pod is None:
            pod_obj = self._find_pod_by_selector()
            self._resolved_pod = pod_obj.metadata.name

        if self._resolved_container is None:
            if pod_obj is None:
                pod_obj = self._read_pod(self._resolved_pod)
            containers = pod_obj.spec.containers or []
            if not containers:
                raise RuntimeError(
                    f"K8sRunner: pod {self.namespace}/{self._resolved_pod} "
                    f"has no containers"
                )
            self._resolved_container = containers[0].name

        _log.info(
            "K8sRunner %r targeting pod %s/%s (container=%s)",
            self.name, self.namespace, self._resolved_pod, self._resolved_container,
        )

    def _find_pod_by_selector(self):
        from kubernetes.client.rest import ApiException

        try:
            pods = self.core_v1.list_namespaced_pod(
                namespace=self.namespace,
                label_selector=self.selector,
            )
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: failed to list pods with selector "
                f"{self.selector!r} in namespace {self.namespace!r}: {exc}"
            ) from exc

        running = [
            p for p in pods.items
            if p.status and p.status.phase == "Running"
        ]
        if not running:
            raise RuntimeError(
                f"K8sRunner: no Running pods match selector "
                f"{self.selector!r} in namespace {self.namespace!r}"
            )
        return running[0]

    def _read_pod(self, pod_name: str):
        from kubernetes.client.rest import ApiException

        try:
            return self.core_v1.read_namespaced_pod(
                name=pod_name, namespace=self.namespace,
            )
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: pod {self.namespace}/{pod_name} not found: {exc}"
            ) from exc
