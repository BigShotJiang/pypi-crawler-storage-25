"""yonder — run Python functions on registered container runners."""

from .decorator import yonder
from .paths import HostPath
from .runners.base import Runner
from .runners.docker import DockerRunner
from .runners.k8s import K8sRunner
from .session import (
    YonderSession,
    closeAll,
    get,
    getSession,
    register,
    setLogLevel,
    wait,
)

__all__ = [
    "yonder",
    "register",
    "get",
    "wait",
    "closeAll",
    "setLogLevel",
    "getSession",
    "YonderSession",
    "Runner",
    "DockerRunner",
    "K8sRunner",
    "HostPath",
]

__version__ = "0.1.0"
