from __future__ import annotations

import logging
import sys
from concurrent.futures import ThreadPoolExecutor
from threading import RLock
from typing import Dict, List, Mapping, Optional, Union

from .runners.base import Runner

LogLevel = Union[int, str]

_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def _configure_logging(level: LogLevel) -> None:
    """Attach (or replace) yonder's stderr handler and set the level.

    Idempotent: re-calling swaps out the previous yonder handler so the
    formatter and level reflect the latest configuration.
    """
    logger = logging.getLogger("yonder")
    for h in list(logger.handlers):
        if getattr(h, "_yonder_handler", False):
            logger.removeHandler(h)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT))
    handler._yonder_handler = True  # marker so we can find/replace it later
    logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False  # avoid double output via the root logger


class YonderSession:
    """A process-wide collection of named :class:`Runner` instances.

    Populate it with :meth:`register`, then call :meth:`wait` to bring every
    runner to "available" (image built/pulled, persistent containers started)
    before you begin invoking decorated functions.

    Pass ``log_level`` (e.g. ``"INFO"``, ``"DEBUG"``, ``logging.WARNING``) to
    enable formatted yonder logging on stderr. Logging can also be toggled
    later via :meth:`set_log_level` or the module-level
    :func:`yonder.setLogLevel`.
    """

    def __init__(self, log_level: Optional[LogLevel] = None) -> None:
        self._runners: Dict[str, Runner] = {}
        self._lock = RLock()
        self._log = logging.getLogger("yonder.session")
        if log_level is not None:
            _configure_logging(log_level)

    def set_log_level(self, level: LogLevel) -> None:
        _configure_logging(level)

    def register(self, runners: Mapping[str, Runner]) -> None:
        with self._lock:
            for name, runner in runners.items():
                if not isinstance(runner, Runner):
                    raise TypeError(
                        f"register({name!r}=...): expected Runner, "
                        f"got {type(runner).__name__}"
                    )
                self._runners[name] = runner
                self._log.info("registered runner %r (%s)", name, type(runner).__name__)

    def get(self, name: str) -> Runner:
        runner = self._runners.get(name)
        if runner is None:
            raise KeyError(
                f"yonder runner {name!r} is not registered; "
                f"call yonder.register({{'{name}': MyRunner(...)}}) first"
            )
        return runner

    def names(self) -> List[str]:
        return list(self._runners)

    def wait(self, parallel: bool = True) -> None:
        """Block until every registered runner is available.

        Calls :meth:`Runner.start` on each registered runner. With
        ``parallel=True`` (default) image builds/pulls and container starts
        happen concurrently across runners; with ``parallel=False`` they run
        sequentially in registration order.

        If any runner's ``start()`` raises, :meth:`wait` re-raises after the
        other in-flight starts complete.
        """
        runners = list(self._runners.values())
        if not runners:
            return
        self._log.info("waiting for %d runner(s) to become available", len(runners))
        if parallel and len(runners) > 1:
            with ThreadPoolExecutor(max_workers=len(runners)) as ex:
                futures = [ex.submit(r.start) for r in runners]
                first_exc: BaseException | None = None
                for f in futures:
                    try:
                        f.result()
                    except BaseException as exc:  # noqa: BLE001
                        if first_exc is None:
                            first_exc = exc
                if first_exc is not None:
                    raise first_exc
        else:
            for r in runners:
                r.start()
        self._log.info("all runners available")

    def closeAll(self) -> None:
        with self._lock:
            runners = list(self._runners.values())
            self._runners.clear()
        if runners:
            self._log.info("closing %d runner(s)", len(runners))
        for runner in runners:
            runner.close()


_session = YonderSession()


def register(runners: Mapping[str, Runner]) -> None:
    _session.register(runners)


def get(name: str) -> Runner:
    return _session.get(name)


def wait(parallel: bool = True) -> None:
    _session.wait(parallel=parallel)


def closeAll() -> None:
    _session.closeAll()


def setLogLevel(level: LogLevel) -> None:
    """Enable formatted yonder logging on stderr at ``level``."""
    _configure_logging(level)


def getSession() -> YonderSession:
    return _session
