from __future__ import annotations

import functools
import pickle

import cloudpickle

from .paths import translate as _translate_host_paths
from .session import get as _get_runner

_DOCS_BASE = "https://jason-berger.gitlab.io/yonder"
_REF_MODE_DOCS = f"{_DOCS_BASE}/pages/runners.html#runner-modes"
_REF_MODE_EXAMPLE = f"{_DOCS_BASE}/pages/examples.html#rdkit-example"


def yonder(runner: str):
    """Decorator: run the wrapped function on a registered runner.

    ``runner`` is the name previously registered via :func:`yonder.register`.

    Whether a call dispatches to the runner or runs locally is controlled
    by the runner's own ``when`` predicate (see :class:`~yonder.Runner`).
    If the runner has no ``when``, every call dispatches.

    Transport is selected by the runner via its ``mode`` attribute. With
    ``mode="cloudpickle"`` (the default), the function is shipped as
    bytecode via cloudpickle and host/container Python minor versions must
    match. With ``mode="reference"``, the function is shipped as
    ``(module, qualname, args, kwargs)`` and the container imports the
    module under its own Python; the function must be defined at module
    scope in a non-``__main__`` module.
    """

    def decorate(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            runner_obj = _get_runner(runner)
            runner_when = getattr(runner_obj, "when", None)
            if runner_when is not None and not runner_when():
                # Local dispatch: HostPath instances pass through unchanged
                # (they're str subclasses, so open(p)/Path(p)/etc. all work).
                return func(*args, **kwargs)

            # Remote dispatch: rewrite any HostPath in args/kwargs to its
            # in-runner equivalent before serializing.
            args = tuple(
                _translate_host_paths(a, runner_obj.translate_host_path)
                for a in args
            )
            kwargs = {
                k: _translate_host_paths(v, runner_obj.translate_host_path)
                for k, v in kwargs.items()
            }

            mode = getattr(runner_obj, "mode", "cloudpickle")
            if mode == "reference":
                _validate_reference(func)
                payload = pickle.dumps(
                    {
                        "module": func.__module__,
                        "qualname": func.__qualname__,
                        "args": args,
                        "kwargs": kwargs,
                    }
                )
                result_bytes = runner_obj.run(payload)
                envelope = pickle.loads(result_bytes)
            else:
                payload = cloudpickle.dumps(
                    {"func": func, "args": args, "kwargs": kwargs}
                )
                result_bytes = runner_obj.run(payload)
                envelope = cloudpickle.loads(result_bytes)

            if envelope["status"] == "ok":
                return envelope["value"]
            raise envelope["exception"]

        wrapper.__yonder__ = True
        wrapper.__yonder_runner__ = runner
        # Reference-mode bootstrap reads this to skip the wrapper and call
        # the original function inside the container.
        wrapper.__yonder_inner__ = func
        return wrapper

    return decorate


def _validate_reference(func) -> None:
    if func.__qualname__ != func.__name__:
        raise TypeError(
            f"reference-mode runners require module-scope functions, but "
            f"`{func.__qualname__}` is defined inside another scope. Move "
            f"the function to the top of a module file (e.g. tasks.py) and "
            f"import it where you need it.\n"
            f"  docs:    {_REF_MODE_DOCS}\n"
            f"  example: {_REF_MODE_EXAMPLE}"
        )
    if func.__module__ == "__main__":
        raise TypeError(
            f"reference-mode runners cannot ship `{func.__name__}` because "
            f"it is defined in the same script you're running "
            f"(module `__main__`). The container would have to re-execute "
            f"your script to import it, which loops back through this code "
            f"and recurses. Move `{func.__name__}` into a separate "
            f"importable module (e.g. tasks.py) and import it from your "
            f"script — see the rdkit example below.\n"
            f"  docs:    {_REF_MODE_DOCS}\n"
            f"  example: {_REF_MODE_EXAMPLE}"
        )
