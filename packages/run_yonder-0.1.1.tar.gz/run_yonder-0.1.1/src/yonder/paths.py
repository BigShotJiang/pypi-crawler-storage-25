"""Path translation between host and runner filesystems.

Users wrap a host-side filesystem path in :class:`HostPath` to tell the
decorator "translate this against the runner's mount table when this
call dispatches remotely; pass it through unchanged when it runs
locally." ``HostPath`` is a ``str`` subclass, so a ``HostPath`` always
works anywhere a path string works — ``open(p)``, ``pathlib.Path(p)``,
``os.path.join(p, ...)`` — without unwrapping.
"""
from __future__ import annotations

import os
from typing import Any, Callable


class HostPath(str):
    """A host-filesystem path that yonder should translate to its
    in-runner equivalent when a call dispatches remotely.

    Inherits from :class:`str`, so it can be used anywhere a path string
    can::

        runner = DockerRunner(image="...", mounts={"/home/jason/data": "/data"})

        @yonder(runner="r")
        def process(path: str) -> str:
            return open(path).read()

        process(HostPath("/home/jason/data/file.txt"))
        # remote dispatch: decorator rewrites to "/data/file.txt"
        # local dispatch (runner.when() returned False): passes through as
        # "/home/jason/data/file.txt"

    If no mount on the resolved runner covers the path, translation
    raises :class:`ValueError` before any payload is shipped.
    """

    def __new__(cls, value):
        return super().__new__(cls, os.fspath(value))

    def __repr__(self) -> str:  # pragma: no cover
        return f"HostPath({str.__repr__(self)})"


def translate(value: Any, translate_fn: Callable[[str], str]) -> Any:
    """Walk ``value`` and apply ``translate_fn`` to every :class:`HostPath`
    found inside it.

    Recurses into ``list``, ``tuple``, and ``dict`` so wrapping a path
    inside an ordinary container still gets translated. Other types pass
    through unchanged — this is opt-in via ``HostPath``, not a blanket
    string-rewriter.
    """
    if isinstance(value, HostPath):
        return translate_fn(value)
    if isinstance(value, list):
        return [translate(v, translate_fn) for v in value]
    if isinstance(value, tuple):
        return tuple(translate(v, translate_fn) for v in value)
    if isinstance(value, dict):
        return {k: translate(v, translate_fn) for k, v in value.items()}
    return value
