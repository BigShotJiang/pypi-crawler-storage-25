# STARTHERE — mgf-alembic

> **Sibling library in the Magogi Foundation federation.**
> See [README.md](README.md) for what this library does; see
> [PUBLIC_API.md](PUBLIC_API.md) for the surface; see
> [mgf-common/FEDERATION.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEDERATION.md)
> for the federation contract.

`mgf-alembic` is async-aware Alembic env.py helper — one-call configure_env replaces ~40 lines of boilerplate.

---

## For consumers (using this library)

1. **Pin** in your `pyproject.toml`:
   ```toml
   dependencies = ["mgf-alembic>=X.Y,<X.$((Y+1))"]
   ```
   See [CHANGELOG.md](CHANGELOG.md) for the current minor.
2. **Install:** `uv add mgf-alembic` (or `pip install mgf-alembic`).
3. **Read** [PUBLIC_API.md](PUBLIC_API.md) for the stable surface.
4. **Bootstrap your app** with mgf-common first — see
   [mgf-common/STARTHERE.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/STARTHERE.md).
5. **Adopt the federation contract** — file your
   `MGF_STANDARDS_CONFORMANCE.md` per
   [DOC-15](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md).
6. **Run** `mgf-common catch-up` periodically to verify
   federation drift; see [FEDERATION.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEDERATION.md) §6.

---

## For contributors

See [CONTRIBUTING.md](CONTRIBUTING.md). Standards are inherited
from [mgf-common](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/).

---

## Quick links

| Resource | Where |
|---|---|
| Library purpose | [README.md](README.md) |
| Stable surface | [PUBLIC_API.md](PUBLIC_API.md) |
| Release notes | [CHANGELOG.md](CHANGELOG.md) |
| Who depends on me | [USERS.md](USERS.md) |
| Conformance ledger | [docs/inprogress/MGF_STANDARDS_CONFORMANCE.md](docs/inprogress/MGF_STANDARDS_CONFORMANCE.md) |
| Federation contract | [mgf-common/FEDERATION.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEDERATION.md) |
| Cross-project standards | [mgf-common/docs/standards/](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/) |
