# `docs/inprogress/` — the maintainer's workspace

**Per `DOC-02` + `DOC-11`** in `mgf-common`'s [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md):
this directory is the **workspace** where the maintainer's
internal-posture docs live while they're active. It is **not a
graveyard** — closed trackers SHOULD move to `docs/archive/<year>/`
within one release cycle.

## What goes here

- **Living priority trackers** (per `DOC-06`): one per concern area.
  Each follows the §1..§6 canonical shape.
- **One-shot audit passes**. Finite scope; move to archive when
  complete.

## What does NOT go here

- **Consumer-reported papercuts** — `mgf-alembic` has no
  consumer-facing `FEEDBACK.md` of its own; consumer signal lands
  in [`mgf-common/FEEDBACK.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEEDBACK.md)
  under a `[mgf-alembic]` prefix.
- **Per-release breaking-change guides** — those go to
  `docs/cutover/`.
- **Permanent rules / standards** — those live in
  `mgf-common/docs/standards/` (this sibling inherits them).

## Index

| File | Status | What |
|---|---|---|
| [`RELIABILITY_AND_ACCURACY.md`](RELIABILITY_AND_ACCURACY.md) | v0.1 — active | RA-* items: asyncio.run from running event loop, metadata mutation side-effect, postgresql+psycopg dual-mode URL routing, async-prefix list maintainability, transactional-DDL opt-out. |
| [`SECURITY_HARDENING.md`](SECURITY_HARDENING.md) | v0.1 — active | SH-* items: DB URL credential redaction (twin mgf-sqlalchemy SH-02), offline-mode secret-bearing DDL warning, migration audit trail (SC-17), include_object callback trust contract, sibling SBOM + vuln-scan. |
| [`PERFORMANCE_AND_CAPACITY.md`](PERFORMANCE_AND_CAPACITY.md) | v0.1 — active | PC-* items: configure_env Python overhead, asyncio.run startup cost, autogenerate cost on large schemas, offline-mode SQL throughput, engine NullPool documentation. |
