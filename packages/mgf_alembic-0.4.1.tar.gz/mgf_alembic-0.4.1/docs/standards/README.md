# Engineering Standards

This folder is **NOT a duplicate** of `mgf-common/docs/standards/`.
The cross-project engineering standards live in `mgf-common`.
This project depends on those — pinned via
`mgf-common>=0.33,<0.34`. Read them directly at
[`mgf-common/docs/standards/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/).

**Project shape:** **Federation sibling** of `mgf-common`
(per [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) §2.0).

**Conformance target:** L2. Inherited via the `mgf-common>=0.33,<0.34`
dependency.

---

## What lives in mgf-common (do not duplicate here)

The full standards set in `mgf-common/docs/standards/`:

- [`DESIGN_PRINCIPLES.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DESIGN_PRINCIPLES.md) — DP-01..DP-13
- [`ERROR_HANDLING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/ERROR_HANDLING.md) — EH-01..EH-13
- [`LOGGING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/LOGGING.md) — LG-01..LG-17
- [`CONFIGURATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/CONFIGURATION.md) — CF-01..CF-12
- [`SECURITY_STANDARD.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/SECURITY_STANDARD.md) — SC-01..SC-18
- [`TESTING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/TESTING.md) — TS-01..TS-21
- [`API_DESIGN.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/API_DESIGN.md) — AP-01..AP-15
- [`RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md) — REL-01..REL-09
- [`WORKFLOWS.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/WORKFLOWS.md) — WF-01..WF-12
- [`SCOPE.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/SCOPE.md)
- [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) — DOC-01..DOC-12
- [`OPERABILITY.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/OPERABILITY.md) — OP-01..OP-12
- [`DEPLOYMENT.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DEPLOYMENT.md) — DEP-01..DEP-11

---

## Project-specific standards

None. `mgf-alembic` is a single-purpose helper (`configure_env`
replaces the async-alembic env.py boilerplate); its public
surface (see [`PUBLIC_API.md`](../../PUBLIC_API.md)) is one
name. The whole library's job is to bridge `alembic` into the
federation's logging / naming-convention conventions.

The migration-discipline pattern (backup-before-upgrade,
backward-compatible schema windows for DEP-06 reversibility)
is consumer-side runbook content — see
[`mgf-common/docs/standards/DEPLOYMENT.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DEPLOYMENT.md) §4.6 + the
[`OPERABILITY.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/OPERABILITY.md) §2.12
backup-restore-drill rule.
