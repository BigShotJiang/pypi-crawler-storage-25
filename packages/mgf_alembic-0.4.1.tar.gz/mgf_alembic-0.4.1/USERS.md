# USERS — who depends on mgf-alembic

> **Purpose:** mgf-alembic's user roll. Lists every consumer project and
> federation sibling that imports `mgf.alembic.*`.
> **Maintained by:** the mgf-common owner (Bassam — mgf-common owns the
> federation per the one-big-library mindset).
> **Per standard DOC-16** (v2.9): every `mgf-*` library MUST maintain a
> `USERS.md` at repo root.

Last verified: 2026-05-18 (post-mgf-alembic v0.4.0 release).

---

## §1 Consumer projects (external users)

| Project          | Location                                     | Import sites | Status                                    | Surfaces used                            |
|------------------|----------------------------------------------|-------------:|-------------------------------------------|------------------------------------------|
| **PlasmaMapper** | `/home/bassam/PycharmProjects/PlasmaMapper`  | 1            | Active — multi-tenant FastAPI SaaS         | `import_versioned_models` (single use)  |

**Single-consumer reality.** mgf-alembic is currently a one-consumer
library. The v0.4.0 drift detector (`detect_drift(...)`) was shipped
ahead of broad adoption based on the shape PlasmaMapper would need;
the user count will grow when other federation consumers adopt Alembic.

---

## §2 Federation siblings (`mgf-*` libraries)

No siblings depend on mgf-alembic today. mgf-fastapi remains
Alembic-agnostic (consumers wire it up); mgf-django uses Django's own
migration system.

---

## §3 What a "user" change MUST trigger

See [`../mgf_common/USERS.md`](../mgf_common/USERS.md) §3 — the same
process applies. Single-consumer status today means breaking changes
need only check PlasmaMapper.

---

## §4 How this list is maintained

```sh
for proj in VManager inthewords PlasmaMapper iosRecovery; do
  grep -rE "(from|import) +mgf\.alembic" "/home/bassam/PycharmProjects/$proj" \
    --include='*.py' | wc -l
done
```

Re-run before each MINOR release. Update this table when the count moves.
