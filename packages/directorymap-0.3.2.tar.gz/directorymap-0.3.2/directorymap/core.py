from pathlib import Path
from datetime import datetime
import fnmatch
import json
import hashlib
import difflib

# ---------------- paths ----------------

def tool_dir(root: Path):
    d = root / ".directorymap"
    d.mkdir(exist_ok=True)
    return d


def config_path(root: Path):
    return tool_dir(root) / "config"


def structure_path(root: Path):
    return tool_dir(root) / "structure.ini"
# ---------------- ignore ----------------

def load_ignore_file(root: Path):
    ignore = set()
    patterns = []
    limits = {}  # pattern -> max count

    file = config_path(root)

    if not file.exists():
        return ignore, patterns, limits

    for line in file.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        # Check if line has a count limit (e.g., "*.jpeg 5")
        parts = line.split()
        pattern = parts[0]
        limit = None
        
        if len(parts) > 1:
            try:
                limit = int(parts[1])
            except ValueError:
                limit = None

        if "*" in pattern or "?" in pattern:
            patterns.append(pattern)
            if limit is not None:
                limits[pattern] = limit
        else:
            ignore.add(pattern)

    return ignore, patterns, limits


def allowed(p, ignore, patterns, limits, pattern_counts):
    if p.name in ignore:
        return False
    for pat in patterns:
        if fnmatch.fnmatch(p.name, pat):
            # If this pattern has a limit, check if we've hit it
            if pat in limits:
                current_count = pattern_counts.get(pat, 0)
                if current_count >= limits[pat]:
                    return False
            else:
                # No limit specified, so exclude this pattern entirely
                return False
    return True


# ---------------- tree build ----------------

def build_tree_data(root: Path, ignore, patterns, limits):
    stats = {"files": 0, "folders": 0, "size": 0, "largest": ("", 0)}
    pattern_counts = {}  # Track counts for limited patterns

    def walk(path):
        node = {}

        for p in sorted(path.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
            if not allowed(p, ignore, patterns, limits, pattern_counts):
                continue

            if p.is_dir():
                stats["folders"] += 1
                node[p.name] = walk(p)
            else:
                size = p.stat().st_size
                stats["files"] += 1
                stats["size"] += size

                if size > stats["largest"][1]:
                    stats["largest"] = (str(p), size)

                # Increment count for patterns that match this file
                for pat in patterns:
                    if pat in limits and fnmatch.fnmatch(p.name, pat):
                        pattern_counts[pat] = pattern_counts.get(pat, 0) + 1

                node[p.name] = size

        return node

    return walk(root), stats


# ---------------- formatting ----------------

def format_text(root: Path, data, show_size=False):
    lines = [root.name + "/"]

    def walk(node, prefix=""):
        items = list(node.items())

        for i, (name, value) in enumerate(items):
            connector = "└─ " if i == len(items) - 1 else "├─ "

            if isinstance(value, dict):
                lines.append(prefix + connector + name + "/")
                walk(value, prefix + ("   " if i == len(items) - 1 else "│  "))
            else:
                size = f" ({value/1024:.2f} KB)" if show_size else ""
                lines.append(prefix + connector + name + size)

    walk(data)
    return "\n".join(lines)


def format_json(data):
    return json.dumps(data, indent=2)


# ---------------- public API ----------------

def generate_structure(root_path=".", show_size=False, fmt="text"):
    root = Path(root_path).resolve()

    ignore, patterns, limits = load_ignore_file(root)
    data, _ = build_tree_data(root, ignore, patterns, limits)

    content = format_json(data) if fmt == "json" else format_text(root, data, show_size)

    out = structure_path(root)
    out.write_text(f"; Generated {datetime.now().isoformat()}\n\n{content}")

    return out, content


def compute_hash(text):
    return hashlib.sha256(text.encode()).hexdigest()


def diff_structure(root_path="."):
    root = Path(root_path)

    old_file = structure_path(root)
    old = old_file.read_text().splitlines() if old_file.exists() else []

    _, new_text = generate_structure(root)
    new = new_text.splitlines()

    return "\n".join(difflib.unified_diff(old, new, lineterm=""))


def stats(root_path="."):
    root = Path(root_path)

    ignore, patterns, limits = load_ignore_file(root)
    _, s = build_tree_data(root, ignore, patterns, limits)

    return {
        "files": s["files"],
        "folders": s["folders"],
        "total_size_kb": round(s["size"] / 1024, 2),
        "largest_file": s["largest"][0],
        "largest_size_kb": round(s["largest"][1] / 1024, 2),
    }
