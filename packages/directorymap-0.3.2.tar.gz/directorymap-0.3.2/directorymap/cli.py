import argparse
import time
from pathlib import Path

from .core import (
    tool_dir,
    config_path,
    generate_structure,
    diff_structure,
    stats,
    compute_hash
)


TEMPLATE = """# Ignore rules
.directorymap
node_modules
.git
__pycache__
.DS_Store
*.log
*.tmp

# Pattern-based rules with optional limits
# Use "pattern limit" to allow max N files of that type
# Examples:
# *.jpeg 5       - allow max 5 jpeg files
# *.png          - ignore all png files
"""


def cmd_init():
    root = Path(".").resolve()
    d = tool_dir(root)

    cfg = config_path(root)
    if not cfg.exists():
        cfg.write_text(TEMPLATE)
        print("Created .directorymap/config")

    out, _ = generate_structure()
    print(f"Structure written to {out}")


def cmd_build(args):
    out, _ = generate_structure(show_size=args.size, fmt=args.format)
    print(f"Structure written to {out}")


def cmd_diff():
    print(diff_structure())


def cmd_stats():
    s = stats()
    for k, v in s.items():
        print(f"{k}: {v}")


def cmd_hash():
    _, text = generate_structure()
    print(compute_hash(text))


def cmd_watch(args):
    print("Watching for changes (Ctrl+C to stop)")
    last_hash = None

    try:
        while True:
            _, text = generate_structure(show_size=args.size, fmt=args.format)
            h = compute_hash(text)

            if h != last_hash:
                print("Updated structure.ini")
                last_hash = h

            time.sleep(2)
    except KeyboardInterrupt:
        print("Stopped watching.")


def main():
    parser = argparse.ArgumentParser(prog="directorymap")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("init")

    build = sub.add_parser("build")
    build.add_argument("--size", action="store_true")
    build.add_argument("--format", choices=["text", "json"], default="text")

    sub.add_parser("diff")
    sub.add_parser("stats")
    sub.add_parser("hash")

    watch = sub.add_parser("watch")
    watch.add_argument("--size", action="store_true")
    watch.add_argument("--format", choices=["text", "json"], default="text")

    args = parser.parse_args()

    {
        "init": cmd_init,
        "build": lambda: cmd_build(args),
        "diff": cmd_diff,
        "stats": cmd_stats,
        "hash": cmd_hash,
        "watch": lambda: cmd_watch(args)
    }.get(args.cmd, parser.print_help)()
