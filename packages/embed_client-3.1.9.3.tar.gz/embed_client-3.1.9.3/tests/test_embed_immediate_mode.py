"""
Tests for immediate JSON-RPC embed result (no queue job_id).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest
from unittest.mock import AsyncMock, patch

from embed_client.embedding_client import EmbeddingClient


@pytest.mark.asyncio
async def test_embed_wait_false_immediate_payload() -> None:
    """When server returns full data without job_id, embed returns business payload."""
    client = EmbeddingClient(protocol="http", host="localhost", port=8001)

    async def fake_jsonrpc(method: str, params: dict) -> dict:
        assert method == "embed"
        return {
            "result": {
                "success": True,
                "data": {
                    "results": [{"body": "t", "embedding": [0.1, 0.2]}],
                    "embeddings": [[0.1, 0.2]],
                    "model": "m",
                },
            }
        }

    with patch.object(
        client.client,
        "jsonrpc_call",
        new=AsyncMock(side_effect=fake_jsonrpc),
    ):
        out = await client.embed(["t"], wait=False)

    assert "job_id" not in out
    assert "results" in out


@pytest.mark.asyncio
async def test_embed_wait_false_queued_job_id() -> None:
    """When server returns job_id without full results, embed returns queue metadata."""
    client = EmbeddingClient(protocol="http", host="localhost", port=8001)

    async def fake_jsonrpc(method: str, params: dict) -> dict:
        assert method == "embed"
        return {
            "result": {
                "success": True,
                "data": {
                    "job_id": "job-123",
                    "status": "pending",
                    "message": "accepted",
                },
            }
        }

    with patch.object(
        client.client,
        "jsonrpc_call",
        new=AsyncMock(side_effect=fake_jsonrpc),
    ):
        out = await client.embed(["t"], wait=False)

    assert out["job_id"] == "job-123"
    assert out["status"] == "pending"


@pytest.mark.asyncio
async def test_embed_wait_false_queued_after_timeout_flag() -> None:
    """Server sync-cap fallback (adapter >=8.10) exposes queued_after_timeout."""
    client = EmbeddingClient(protocol="http", host="localhost", port=8001)

    async def fake_jsonrpc(method: str, params: dict) -> dict:
        assert method == "embed"
        return {
            "result": {
                "success": True,
                "data": {
                    "job_id": "job-fallback",
                    "status": "pending",
                    "message": "exceeded sync timeout, track via queue_get_job_status",
                    "queued_after_timeout": True,
                },
            }
        }

    with patch.object(
        client.client,
        "jsonrpc_call",
        new=AsyncMock(side_effect=fake_jsonrpc),
    ):
        out = await client.embed(["t"], wait=False)

    assert out["job_id"] == "job-fallback"
    assert out["queued_after_timeout"] is True


@pytest.mark.asyncio
async def test_embed_wait_false_queued_after_timeout_on_result_root() -> None:
    """Accept queued_after_timeout next to job_id when not duplicated under data."""
    client = EmbeddingClient(protocol="http", host="localhost", port=8001)

    async def fake_jsonrpc(method: str, params: dict) -> dict:
        assert method == "embed"
        return {
            "result": {
                "success": True,
                "queued_after_timeout": True,
                "data": {"job_id": "job-root", "status": "pending"},
            }
        }

    with patch.object(
        client.client,
        "jsonrpc_call",
        new=AsyncMock(side_effect=fake_jsonrpc),
    ):
        out = await client.embed(["t"], wait=False)

    assert out["job_id"] == "job-root"
    assert out["queued_after_timeout"] is True
