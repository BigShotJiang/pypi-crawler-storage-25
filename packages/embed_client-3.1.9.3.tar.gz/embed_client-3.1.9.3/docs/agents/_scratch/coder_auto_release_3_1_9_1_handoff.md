# coder_auto handoff — release 3.1.9.1

**Date:** 2026-03-30  
**Repo:** `/home/vasilyvz/projects/embed-client`

## A) Code / docs alignment

| Item | Status |
|------|--------|
| `embed_client/embedding_client.py` — `EmbeddingClient.embed_file_from_local_json_file` | **Already aligned.** Docstring includes **See also** `:mod:`embed_client.md_embed_file_prep`` when strings came from ``prepare-embed-file-json`` (paragraphs split on ``\n\n`` only). See lines 1141–1145 in current tree. **No edit applied this session.** |
| `examples/embed_file_json_local.py` | **Already aligned.** Module docstring line 6: JSON from ``prepare-embed-file-json`` uses paragraph blocks split on ``\n\n`` only. **No edit applied this session.** |

## B) Version 3.1.9.1

| File | Status |
|------|--------|
| `pyproject.toml` | `[project] version = "3.1.9.1"` — **already set**; no edit. |
| `embed_client/__init__.py` | `PackageNotFoundError` fallback `__version__ = "3.1.9.1"` — **already set**; no edit. |

**Grep:** No other `__version__` literals in application code beyond `embed_client/__init__.py`. Project name on PyPI is **embed-client** (hyphen); URL uses that slug.

## C) Environment (CR-005)

- **Venv:** `source /home/vasilyvz/projects/embed-client/.venv/bin/activate`
- **Install:** `pip install -e ".[dev]"` (exit **0**) — satisfies `tests/test_config.py` (`embed_client.__version__` == `importlib.metadata.version("embed-client")`).
- **Version check:** `python -c "import embed_client; print(embed_client.__version__)"` → **3.1.9.1** (exit **0**).

## Commands run (with exit codes)

| Command | Exit |
|---------|------|
| `pip install -e ".[dev]"` | 0 |
| `pytest -q` (full suite) | 0 — **200 passed**, 67 skipped; 19 warnings (httpx `cert=` deprecation in `tests/test_all_security_modes.py`) |
| `flake8 embed_client tests` | 0 |
| `black --check embed_client tests` | 0 |
| `mypy embed_client` | 0 — Success, 41 source files |
| `python -m pip install build twine -q` | 0 |
| `python -m build` | 0 — produced `dist/embed_client-3.1.9.1.tar.gz`, `dist/embed_client-3.1.9.1-py3-none-any.whl` |
| `twine check dist/embed_client-3.1.9.1.tar.gz dist/embed_client-3.1.9.1-py3-none-any.whl` | 0 — both **PASSED** |
| `twine upload dist/embed_client-3.1.9.1.tar.gz dist/embed_client-3.1.9.1-py3-none-any.whl --non-interactive` | **1** — HTTP 400 **File already exists** for wheel (same blake2_256 as published artifact; PyPI forbids re-upload). |
| `twine upload ... --non-interactive --verbose` (retry) | **1** — same **400 File already exists**; confirms version already on index. |

**Ruff:** Not configured in `pyproject.toml` (`[tool.ruff]` absent); not run.

## D) Release artifacts

- **sdist:** `dist/embed_client-3.1.9.1.tar.gz`
- **wheel:** `dist/embed_client-3.1.9.1-py3-none-any.whl`
- **twine check:** PASSED.

## E) PyPI

- **Project URL (this release):** https://pypi.org/project/embed-client/3.1.9.1/
- **Index probe:** `curl -s -o /dev/null -w "%{http_code}" https://pypi.org/pypi/embed-client/3.1.9.1/json` → **200** (release metadata present).
- **Upload this session:** **Not completed** — `twine upload` failed because **3.1.9.1 files are already published** (duplicate / file-name-reuse policy). Credentials were read from user config (e.g. `.pypirc`); failure is **not** auth-related.

## Blockers

**None** for validation, build, and `twine check`. **No new PyPI upload** was possible without a **new version bump** — **3.1.9.1** is already on PyPI with the same wheel content.

## Files changed (this session)

- **`docs/agents/_scratch/coder_auto_release_3_1_9_1_handoff.md`** — this report only (A/B were already satisfied in the working tree).
