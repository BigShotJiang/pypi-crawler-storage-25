# tester_auto verdict — release 3.1.9.1

**Date:** 2026-03-30  
**Repo:** `/home/vasilyvz/projects/embed-client`  
**Role:** Independent re-validation after doc + release work (see `docs/agents/_scratch/coder_auto_release_3_1_9_1_handoff.md`).

## Verdict: **PASS**

## Version check (3.1.9.1)

| Source | Value |
|--------|--------|
| `pyproject.toml` `[project] version` | `3.1.9.1` |
| `embed_client.__init__.py` fallback (`PackageNotFoundError`) | `3.1.9.1` |
| Runtime `python -c "import embed_client; print(embed_client.__version__)"` | `3.1.9.1` |
| `importlib.metadata.version("embed-client")` (editable install) | `3.1.9.1` |

## Commands executed

| # | Command | Exit |
|---|---------|------|
| 1 | `source .venv/bin/activate && python -c "import embed_client; print(embed_client.__version__)"` | 0 |
| 2 | `python -c "import importlib.metadata as m; print(m.version('embed-client'))"` | 0 |
| 3 | `pytest -q` | 0 |
| 4 | `pytest -q tests/test_md_embed_file_prep.py tests/test_cli_embed_file_json.py tests/test_embed_file_output_validate.py -v` | 0 |

## Counts

### Full suite (`pytest -q`)

- **200 passed**, **67 skipped**
- **19 warnings** — all from `tests/test_all_security_modes.py`: `httpx` `DeprecationWarning` for `cert=...` (suggests `verify=<ssl_context>` with `.load_cert_chain()`)

### Focused modules (md embed prep, embed-file JSON CLI, embed_file output validate)

- **24 passed** (0 failed, 0 skipped in this run)
- Files: `tests/test_md_embed_file_prep.py`, `tests/test_cli_embed_file_json.py`, `tests/test_embed_file_output_validate.py`

## Caveats

- Warnings are **non-fatal**; suite still green.
- `pytest-xdist` is active (workers); line noise may include “bringing up nodes...”.
- Environment: venv at `.venv/bin/activate`, project root as cwd.

## Conclusion

Automated tests and version strings are consistent with **3.1.9.1**. No failures observed in this run.
