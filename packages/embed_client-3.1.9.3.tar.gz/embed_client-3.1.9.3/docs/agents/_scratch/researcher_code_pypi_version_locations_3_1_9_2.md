# PyPI release: where the version is set (embed-client)

**Research date:** 2026-03-30  
**Current canonical version in tree:** `3.1.9.1`  
**Target bump example:** `3.1.9.2`

## Single source of truth (must edit for a new PyPI release)

| Location | Role |
|----------|------|
| `pyproject.toml` L7 | `[project] version = "3.1.9.1"` — **authoritative** for setuptools / sdist / wheel metadata and PyPI. |
| `embed_client/__init__.py` L26–30 | Runtime `__version__`: normally `importlib.metadata.version("embed-client")`; on `PackageNotFoundError` uses **fallback literal** `"3.1.9.1"` — **must match** `pyproject.toml` (editable sandboxes / tests without install metadata). |

**Dynamic version:** **None.** `pyproject.toml` has no `[project] dynamic = ["version"]`, no `setuptools-scm`, no `[tool.setuptools.dynamic]`. Version is a **static string** in `[project]`.

## Enforced consistency (no literal to bump)

| Location | Role |
|----------|------|
| `tests/test_config.py` L17–18 | `assert __version__ == pkg_version("embed-client")` — after bump + reinstall, passes if metadata matches. |

## Not duplicated for package version

- **`embed_client/constants.py`** — no package version.
- **`embed_client/cli.py` / `cli_core.py`** — no `--version` / `version=` argparse (CLI does not surface `embed_client.__version__`).
- **`README.md` / `CONFIGURATION.md`** — no pinned `3.1.x` release string found in main docs.
- **CI:** no `.github/workflows/*.yml` in this repo; no workflow pinning the library version.
- **Build artifacts:** `python -m build` produces `dist/embed_client-<version>.*` from `pyproject.toml` automatically — **no extra file** to edit for filenames.

## Historical / non-canonical mentions (optional cleanup)

- `docs/agents/_scratch/*` and `.agent-tactical-debug/*` contain old release notes (e.g. `3.1.9.1`); **not** required for PyPI mechanics.
- `docs/ai_reports/*.md`, `docs/specs/.../rv05-*.md` describe **process** (compare `pyproject` vs `__version__`), not a third version constant.
- `RELEASE_NOTES_3.1.7.7.md` — historical; not the current bump target.

## Recommendations for bumping to `3.1.9.2`

1. Set `version = "3.1.9.2"` in `pyproject.toml` (`[project]`).
2. Set fallback `__version__ = "3.1.9.2"` in `embed_client/__init__.py` (except-branch only; keep in lockstep with step 1).
3. Reinstall editable package (`pip install -e ".[dev]"` or equivalent) so `importlib.metadata.version("embed-client")` reflects the new version; run `pytest tests/test_config.py::test_embed_client_version_matches_package_metadata`.
4. Run `python -m build` and `twine check dist/*`; upload new `embed_client-3.1.9.2*` artifacts (names follow pyproject automatically).
5. **Optional hardening:** add `parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")` (or equivalent) to `embed_client/cli.py` if CLI `--version` is desired — would read from `embed_client.__version__`, still **one** runtime string path after install.

## Snippets (reference)

```7:7:pyproject.toml
version = "3.1.9.1"
```

```26:30:embed_client/__init__.py
try:
    __version__ = version("embed-client")
except PackageNotFoundError:
    # Editable checkout without install metadata (e.g. some unit-test sandboxes).
    __version__ = "3.1.9.1"
```
