# coder_auto handoff: release 3.1.9.2 (PyPI)

## Files changed

- `pyproject.toml` — `version = "3.1.9.2"`
- `embed_client/__init__.py` — `PackageNotFoundError` fallback `__version__ = "3.1.9.2"`

## Commands run (repo root, venv: `source .venv/bin/activate`)

1. `rm -rf dist/`
2. `python -m build`

   - Artifacts: `dist/embed_client-3.1.9.2-py3-none-any.whl`, `dist/embed_client-3.1.9.2.tar.gz`

3. `twine check dist/*`

   - `Checking dist/embed_client-3.1.9.2-py3-none-any.whl: PASSED`
   - `Checking dist/embed_client-3.1.9.2.tar.gz: PASSED`

4. `twine upload dist/*`

## Twine upload summary

- Target: `https://upload.pypi.org/legacy/`
- Uploaded: `embed_client-3.1.9.2-py3-none-any.whl`, `embed_client-3.1.9.2.tar.gz`
- Exit code: 0

## PyPI result

**Success.** Version URL: https://pypi.org/project/embed-client/3.1.9.2/

## Blockers

None.
