from setuptools import setup, find_packages

setup(
    name="jingle-algos",  
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "ajay": ["*.c"],   # include all .c files
    },
    description="Ajay's Algorithms CLI tool (Python + C source viewer)",
    author="Ajay",
    python_requires=">=3.6",
    entry_points={
        'console_scripts': [
            'ajay=ajay.__main__:main'
        ]
    }
)