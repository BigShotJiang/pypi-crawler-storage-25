"""
ug-address — Uganda cascading address selector SDK for Python.

District → County/Division → Sub-county → Parish → Village

Usage:
    from ug_address import UgAddress

    addr = UgAddress()
    print(addr.get_districts())

    addr.select_district('32')       # Kampala
    addr.select_county('69')         # Kampala Central Division
    addr.select_subcounty('453')
    addr.select_parish('2025')
    addr.select_village('12931')

    print(addr.get_formatted_address())
    print(addr.get_selection())
"""

from ug_address._core import UgAddress

__all__ = ['UgAddress']
__version__ = '1.0.0'