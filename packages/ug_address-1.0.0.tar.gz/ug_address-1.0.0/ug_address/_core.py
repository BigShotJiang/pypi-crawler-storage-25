from __future__ import annotations
from typing import Callable, Dict, List, Optional
from ug_address._data import _load


class UgAddress:
    """
    Cascading Uganda address selector.

    Mirrors the JavaScript ug-address library API using Python conventions
    (snake_case methods, callbacks via on_* methods).
    """

    def __init__(self) -> None:
        data = _load()
        self._districts:   List[dict] = data['districts']
        self._counties:    List[dict] = data['counties']
        self._subcounties: List[dict] = data['subcounties']
        self._parishes:    List[dict] = data['parishes']
        self._villages:    List[dict] = data['villages']

        self._state: Dict[str, Optional[str]] = {
            'district_id':   None,
            'county_id':     None,
            'subcounty_id':  None,
            'parish_id':     None,
            'village_id':    None,
        }

        self._listeners: Dict[str, List[Callable]] = {
            'district_change':   [],
            'county_change':     [],
            'subcounty_change':  [],
            'parish_change':     [],
            'village_change':    [],
        }

    # ── Data getters ──────────────────────────────────────────────────────────

    def get_districts(self) -> List[dict]:
        """Return all districts sorted alphabetically."""
        return sorted(self._districts, key=lambda x: x['name'])

    def get_counties(self, district_id: Optional[str] = None) -> List[dict]:
        """Return counties/divisions for the given or currently selected district."""
        did = str(district_id) if district_id is not None else self._state['district_id']
        if not did:
            return []
        return sorted(
            [c for c in self._counties if c['district'] == did],
            key=lambda x: x['name']
        )

    def get_subcounties(self, county_id: Optional[str] = None) -> List[dict]:
        """Return sub-counties for the given or currently selected county."""
        cid = str(county_id) if county_id is not None else self._state['county_id']
        if not cid:
            return []
        return sorted(
            [s for s in self._subcounties if s['county'] == cid],
            key=lambda x: x['name']
        )

    def get_parishes(self, subcounty_id: Optional[str] = None) -> List[dict]:
        """Return parishes for the given or currently selected sub-county."""
        sid = str(subcounty_id) if subcounty_id is not None else self._state['subcounty_id']
        if not sid:
            return []
        return sorted(
            [p for p in self._parishes if p['subcounty'] == sid],
            key=lambda x: x['name']
        )

    def get_villages(self, parish_id: Optional[str] = None) -> List[dict]:
        """Return villages for the given or currently selected parish."""
        pid = str(parish_id) if parish_id is not None else self._state['parish_id']
        if not pid:
            return []
        return sorted(
            [v for v in self._villages if v['parish'] == pid],
            key=lambda x: x['name']
        )

    # ── Selection methods ─────────────────────────────────────────────────────

    def select_district(self, district_id: str) -> 'UgAddress':
        """Select a district and reset all downstream selections."""
        self._state = {
            'district_id':  str(district_id),
            'county_id':    None,
            'subcounty_id': None,
            'parish_id':    None,
            'village_id':   None,
        }
        self._emit('district_change', {
            'district_id': self._state['district_id'],
            'counties': self.get_counties(),
        })
        return self

    def select_county(self, county_id: str) -> 'UgAddress':
        """Select a county/division and reset all downstream selections."""
        self._state.update({'county_id': str(county_id), 'subcounty_id': None, 'parish_id': None, 'village_id': None})
        self._emit('county_change', {
            'county_id': self._state['county_id'],
            'subcounties': self.get_subcounties(),
        })
        return self

    def select_subcounty(self, subcounty_id: str) -> 'UgAddress':
        """Select a sub-county and reset all downstream selections."""
        self._state.update({'subcounty_id': str(subcounty_id), 'parish_id': None, 'village_id': None})
        self._emit('subcounty_change', {
            'subcounty_id': self._state['subcounty_id'],
            'parishes': self.get_parishes(),
        })
        return self

    def select_parish(self, parish_id: str) -> 'UgAddress':
        """Select a parish and reset village selection."""
        self._state.update({'parish_id': str(parish_id), 'village_id': None})
        self._emit('parish_change', {
            'parish_id': self._state['parish_id'],
            'villages': self.get_villages(),
        })
        return self

    def select_village(self, village_id: str) -> 'UgAddress':
        """Select a village."""
        self._state['village_id'] = str(village_id)
        self._emit('village_change', {'village_id': self._state['village_id']})
        return self

    # ── Reading the selection ─────────────────────────────────────────────────

    def get_selection(self) -> Dict[str, Optional[dict]]:
        """
        Return the full current selection.
        Each level is either a dict { id, name } or None if not selected.
        """
        return {
            'district':  self._find(self._districts,   self._state['district_id']),
            'county':    self._find(self._counties,     self._state['county_id']),
            'subcounty': self._find(self._subcounties,  self._state['subcounty_id']),
            'parish':    self._find(self._parishes,     self._state['parish_id']),
            'village':   self._find(self._villages,     self._state['village_id']),
        }

    def get_formatted_address(self) -> str:
        """
        Return a human-readable address string for the current selection.
        Only includes levels that have been selected.

        Example: "Church Zone, Bukesa, Kampala Central, Kampala Central Division, Kampala"
        """
        sel = self.get_selection()
        parts = [sel['village'], sel['parish'], sel['subcounty'], sel['county'], sel['district']]
        return ', '.join(
            self._title_case(p['name']) for p in parts if p is not None
        )

    def reset(self) -> 'UgAddress':
        """Clear all selections."""
        self._state = {
            'district_id':  None,
            'county_id':    None,
            'subcounty_id': None,
            'parish_id':    None,
            'village_id':   None,
        }
        return self

    # ── Event listeners ───────────────────────────────────────────────────────

    def on_district_change(self, fn: Callable) -> 'UgAddress':
        """Register a callback for when a district is selected.
        Callback receives: { district_id, counties }
        """
        return self._on('district_change', fn)

    def on_county_change(self, fn: Callable) -> 'UgAddress':
        """Register a callback for when a county is selected.
        Callback receives: { county_id, subcounties }
        """
        return self._on('county_change', fn)

    def on_subcounty_change(self, fn: Callable) -> 'UgAddress':
        """Register a callback for when a sub-county is selected.
        Callback receives: { subcounty_id, parishes }
        """
        return self._on('subcounty_change', fn)

    def on_parish_change(self, fn: Callable) -> 'UgAddress':
        """Register a callback for when a parish is selected.
        Callback receives: { parish_id, villages }
        """
        return self._on('parish_change', fn)

    def on_village_change(self, fn: Callable) -> 'UgAddress':
        """Register a callback for when a village is selected.
        Callback receives: { village_id }
        """
        return self._on('village_change', fn)

    def off(self, event: str, fn: Callable) -> 'UgAddress':
        """Remove a previously registered listener."""
        if event in self._listeners:
            self._listeners[event] = [f for f in self._listeners[event] if f is not fn]
        return self

    # ── Direct lookup helpers ─────────────────────────────────────────────────

    def find_district(self, id: str) -> Optional[dict]:
        return self._find(self._districts, id)

    def find_county(self, id: str) -> Optional[dict]:
        return self._find(self._counties, id)

    def find_subcounty(self, id: str) -> Optional[dict]:
        return self._find(self._subcounties, id)

    def find_parish(self, id: str) -> Optional[dict]:
        return self._find(self._parishes, id)

    def find_village(self, id: str) -> Optional[dict]:
        return self._find(self._villages, id)

    # ── Internals ─────────────────────────────────────────────────────────────

    def _on(self, event: str, fn: Callable) -> 'UgAddress':
        self._listeners[event].append(fn)
        return self

    def _emit(self, event: str, payload: dict) -> None:
        for fn in self._listeners.get(event, []):
            fn(payload)

    def _find(self, collection: List[dict], id: Optional[str]) -> Optional[dict]:
        if not id:
            return None
        sid = str(id)
        return next((item for item in collection if item['id'] == sid), None)

    @staticmethod
    def _title_case(s: str) -> str:
        return s.title()

    def __repr__(self) -> str:
        sel = self.get_selection()
        parts = [v['name'] for v in sel.values() if v]
        return f"UgAddress({', '.join(parts) if parts else 'no selection'})"