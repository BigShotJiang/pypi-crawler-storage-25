"""浏览器工具 — 完整实现

功能：
1. 网页浏览（GET 请求 + HTML 解析提取正文）
2. 截图功能（subprocess 调 Chrome/Edge headless --screenshot）
3. 表单填写模拟
4. JavaScript 执行（通过 headless 浏览器）
5. 页面元素提取（CSS selector）
6. 安全沙箱（URL 白名单、超时、大小限制）
7. 浏览历史管理

不依赖 playwright/selenium，用 urllib + subprocess 调系统浏览器 headless 模式。
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
from urllib.parse import urljoin, urlparse

from ..skills.base import Skill

logger = logging.getLogger(__name__)

# ─── 常量 ─────────────────────────────────────────────────────────────

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

# 默认安全配置
DEFAULT_TIMEOUT = 15          # 请求超时（秒）
MAX_RESPONSE_SIZE = 5_000_000  # 最大响应体大小 5MB
MAX_OUTPUT_CHARS = 8000       # 返回给 agent 的最大字符数
MAX_HISTORY = 50              # 最大历史记录数

# 默认 URL 黑名单模式（安全沙箱）
_BLOCKED_URL_PATTERNS = [
    re.compile(r"^file://", re.I),
    re.compile(r"^data:", re.I),
    re.compile(r"^javascript:", re.I),
    re.compile(r"localhost", re.I),
    re.compile(r"127\.0\.0\.1"),
    re.compile(r"0\.0\.0\.0"),
    re.compile(r"169\.254\.\d+\.\d+"),     # 链路本地
    re.compile(r"10\.\d+\.\d+\.\d+"),      # 内网
    re.compile(r"192\.168\.\d+\.\d+"),      # 内网
    re.compile(r"172\.(1[6-9]|2\d|3[01])\.\d+\.\d+"),  # 内网
]

# ─── HTML 解析器 ──────────────────────────────────────────────────────


class _TextExtractor(HTMLParser):
    """从 HTML 提取纯文本，去除 script/style"""

    _SKIP_TAGS = {"script", "style", "noscript", "svg", "head"}

    def __init__(self) -> None:
        super().__init__()
        self._pieces: List[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag.lower() in self._SKIP_TAGS:
            self._skip_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in self._SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)

    def handle_data(self, data: str) -> None:
        if self._skip_depth == 0:
            stripped = data.strip()
            if stripped:
                self._pieces.append(stripped)

    def get_text(self) -> str:
        return "\n".join(self._pieces)


class _LinkExtractor(HTMLParser):
    """从 HTML 提取所有 <a> 链接"""

    def __init__(self, base_url: str = "") -> None:
        super().__init__()
        self._base_url = base_url
        self.links: List[Dict[str, str]] = []
        self._current_href: Optional[str] = None
        self._current_text_pieces: List[str] = []
        self._in_a = False

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag.lower() == "a":
            self._in_a = True
            href = dict(attrs).get("href", "")
            if href and self._base_url:
                href = urljoin(self._base_url, href)
            self._current_href = href
            self._current_text_pieces = []

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._in_a:
            self._in_a = False
            if self._current_href:
                self.links.append({
                    "href": self._current_href,
                    "text": "".join(self._current_text_pieces).strip(),
                })

    def handle_data(self, data: str) -> None:
        if self._in_a:
            self._current_text_pieces.append(data)


class _SelectorExtractor(HTMLParser):
    """简易 CSS 选择器提取器（支持 tag、.class、#id）"""

    def __init__(self, selector: str) -> None:
        super().__init__()
        self._selector = selector.strip()
        self._match_tag: Optional[str] = None
        self._match_class: Optional[str] = None
        self._match_id: Optional[str] = None
        self._parse_selector()
        self._depth = 0        # 匹配元素的嵌套深度
        self._capturing = False
        self._pieces: List[str] = []
        self._skip_depth = 0   # script/style 跳过

    _SKIP_TAGS = {"script", "style", "noscript"}

    def _parse_selector(self) -> None:
        """解析简易 CSS 选择器"""
        sel = self._selector
        if sel.startswith("#"):
            self._match_id = sel[1:]
        elif sel.startswith("."):
            self._match_class = sel[1:]
        else:
            # tag.class 或 tag#id 或纯 tag
            m = re.match(r"^(\w+)(?:\.(\w[\w-]*))?(?:#(\w[\w-]*))?$", sel)
            if m:
                self._match_tag = m.group(1).lower()
                if m.group(2):
                    self._match_class = m.group(2)
                if m.group(3):
                    self._match_id = m.group(3)
            else:
                self._match_tag = sel.lower()

    def _matches(self, tag: str, attrs: list) -> bool:
        attr_dict = dict(attrs)
        if self._match_tag and tag.lower() != self._match_tag:
            return False
        if self._match_id and attr_dict.get("id", "") != self._match_id:
            return False
        if self._match_class:
            classes = attr_dict.get("class", "").split()
            if self._match_class not in classes:
                return False
        return True

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if self._capturing:
            self._depth += 1
        elif self._matches(tag, attrs):
            self._capturing = True
            self._depth = 1

        if tag.lower() in self._SKIP_TAGS:
            self._skip_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in self._SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)
        if self._capturing:
            self._depth -= 1
            if self._depth <= 0:
                self._capturing = False

    def handle_data(self, data: str) -> None:
        if self._capturing and self._skip_depth == 0:
            stripped = data.strip()
            if stripped:
                self._pieces.append(stripped)

    def get_text(self) -> str:
        return "\n".join(self._pieces)


class _FormExtractor(HTMLParser):
    """提取 HTML 表单信息"""

    def __init__(self) -> None:
        super().__init__()
        self.forms: List[Dict[str, Any]] = []
        self._current_form: Optional[Dict[str, Any]] = None

    def handle_starttag(self, tag: str, attrs: list) -> None:
        attr_dict = dict(attrs)
        if tag.lower() == "form":
            self._current_form = {
                "action": attr_dict.get("action", ""),
                "method": attr_dict.get("method", "GET").upper(),
                "fields": [],
            }
        elif tag.lower() == "input" and self._current_form is not None:
            self._current_form["fields"].append({
                "name": attr_dict.get("name", ""),
                "type": attr_dict.get("type", "text"),
                "value": attr_dict.get("value", ""),
            })
        elif tag.lower() == "textarea" and self._current_form is not None:
            self._current_form["fields"].append({
                "name": attr_dict.get("name", ""),
                "type": "textarea",
                "value": "",
            })
        elif tag.lower() == "select" and self._current_form is not None:
            self._current_form["fields"].append({
                "name": attr_dict.get("name", ""),
                "type": "select",
                "value": "",
            })

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "form" and self._current_form is not None:
            self.forms.append(self._current_form)
            self._current_form = None


# ─── 安全沙箱 ─────────────────────────────────────────────────────────


@dataclass
class BrowserSandbox:
    """浏览器安全沙箱配置"""

    # URL 白名单（正则列表，为空则允许所有非黑名单 URL）
    url_whitelist: List[str] = field(default_factory=list)
    # 额外黑名单模式
    url_blacklist: List[str] = field(default_factory=list)
    # 请求超时
    timeout: int = DEFAULT_TIMEOUT
    # 最大响应大小
    max_response_size: int = MAX_RESPONSE_SIZE
    # 是否允许截图
    allow_screenshot: bool = True
    # 是否允许 JavaScript 执行
    allow_js: bool = True

    def check_url(self, url: str) -> Optional[str]:
        """检查 URL 安全性，返回错误信息或 None（安全）"""
        # 内置黑名单
        for pattern in _BLOCKED_URL_PATTERNS:
            if pattern.search(url):
                return f"URL 被安全策略阻止: 匹配黑名单规则 [{pattern.pattern}]"

        # 额外黑名单
        for pat_str in self.url_blacklist:
            if re.search(pat_str, url, re.I):
                return f"URL 被自定义黑名单阻止: [{pat_str}]"

        # 白名单检查（如果配置了白名单，URL 必须匹配其中一个）
        if self.url_whitelist:
            matched = False
            for pat_str in self.url_whitelist:
                if re.search(pat_str, url, re.I):
                    matched = True
                    break
            if not matched:
                return "URL 不在白名单中"

        # 检查协议
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return f"不支持的协议: {parsed.scheme}"

        return None


# ─── 浏览历史 ─────────────────────────────────────────────────────────


@dataclass
class HistoryEntry:
    """浏览历史条目"""
    url: str
    title: str
    timestamp: float
    status_code: int = 200


class BrowsingHistory:
    """浏览历史管理器"""

    def __init__(self, max_entries: int = MAX_HISTORY) -> None:
        self._entries: List[HistoryEntry] = []
        self._max = max_entries

    def add(self, url: str, title: str = "", status_code: int = 200) -> None:
        """添加历史记录"""
        entry = HistoryEntry(
            url=url,
            title=title or url,
            timestamp=time.time(),
            status_code=status_code,
        )
        self._entries.append(entry)
        # 超限时移除最早的
        if len(self._entries) > self._max:
            self._entries = self._entries[-self._max:]

    def recent(self, n: int = 10) -> List[Dict[str, Any]]:
        """获取最近 n 条记录"""
        entries = self._entries[-n:]
        return [
            {
                "url": e.url,
                "title": e.title,
                "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(e.timestamp)),
                "status": e.status_code,
            }
            for e in reversed(entries)
        ]

    def search(self, keyword: str) -> List[Dict[str, Any]]:
        """搜索历史记录"""
        kw = keyword.lower()
        results = []
        for e in reversed(self._entries):
            if kw in e.url.lower() or kw in e.title.lower():
                results.append({
                    "url": e.url,
                    "title": e.title,
                    "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(e.timestamp)),
                })
            if len(results) >= 20:
                break
        return results

    def clear(self) -> int:
        """清空历史，返回清理的条数"""
        count = len(self._entries)
        self._entries.clear()
        return count

    @property
    def count(self) -> int:
        return len(self._entries)


# ─── 浏览器工具核心 ───────────────────────────────────────────────────


class BrowserToolCore:
    """浏览器工具核心实现

    纯标准库实现，不依赖 playwright/selenium/httpx。
    使用 urllib 发送请求 + HTMLParser 解析 + subprocess 调 headless 浏览器截图。
    """

    def __init__(
        self,
        sandbox: Optional[BrowserSandbox] = None,
        history: Optional[BrowsingHistory] = None,
    ) -> None:
        self._sandbox = sandbox or BrowserSandbox()
        self._history = history or BrowsingHistory()
        self._last_html: str = ""
        self._last_url: str = ""
        self._last_status: int = 0

    @property
    def history(self) -> BrowsingHistory:
        return self._history

    @property
    def sandbox(self) -> BrowserSandbox:
        return self._sandbox

    @property
    def last_url(self) -> str:
        return self._last_url

    # ─── 网页浏览 ────────────────────────────────────────────

    def navigate(self, url: str) -> Dict[str, Any]:
        """GET 请求 + HTML 解析提取正文

        Returns:
            {"ok": bool, "text": str, "title": str, "url": str, "status": int, "error": str}
        """
        # 安全检查
        err = self._sandbox.check_url(url)
        if err:
            return {"ok": False, "text": "", "title": "", "url": url, "status": 0, "error": err}

        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": DEFAULT_UA,
                "Accept": "text/html,application/xhtml+xml,*/*",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            })
            resp = urllib.request.urlopen(req, timeout=self._sandbox.timeout)
            status = resp.getcode() or 200

            # 读取并限制大小
            data = resp.read(self._sandbox.max_response_size)
            # 检测编码
            charset = "utf-8"
            ct = resp.headers.get("Content-Type", "")
            m = re.search(r"charset=([^\s;]+)", ct, re.I)
            if m:
                charset = m.group(1)

            html = data.decode(charset, errors="replace")
            self._last_html = html
            self._last_url = url
            self._last_status = status

            # 提取标题
            title = self._extract_title(html)
            # 提取正文
            text = self._html_to_text(html)

            self._history.add(url, title, status)
            return {"ok": True, "text": text, "title": title, "url": url, "status": status, "error": ""}

        except urllib.error.HTTPError as e:
            return {"ok": False, "text": "", "title": "", "url": url, "status": e.code, "error": str(e)}
        except urllib.error.URLError as e:
            return {"ok": False, "text": "", "title": "", "url": url, "status": 0, "error": str(e.reason)}
        except Exception as e:
            return {"ok": False, "text": "", "title": "", "url": url, "status": 0, "error": str(e)}

    # ─── 截图功能 ────────────────────────────────────────────

    def screenshot(self, url: str, output_path: Optional[str] = None) -> Dict[str, Any]:
        """通过 subprocess 调 Chrome/Edge headless 截图

        Returns:
            {"ok": bool, "path": str, "size": int, "error": str}
        """
        if not self._sandbox.allow_screenshot:
            return {"ok": False, "path": "", "size": 0, "error": "截图功能已被安全策略禁用"}

        err = self._sandbox.check_url(url)
        if err:
            return {"ok": False, "path": "", "size": 0, "error": err}

        # 查找浏览器
        browser_path = self._find_browser()
        if not browser_path:
            return {"ok": False, "path": "", "size": 0, "error": "未找到 Chrome/Edge 浏览器"}

        # 准备输出路径
        if not output_path:
            output_path = os.path.join(tempfile.gettempdir(), f"screenshot_{hashlib.md5(url.encode()).hexdigest()[:8]}.png")

        try:
            cmd = [
                browser_path,
                "--headless",
                "--disable-gpu",
                "--no-sandbox",
                "--disable-software-rasterizer",
                f"--screenshot={output_path}",
                "--window-size=1280,960",
                "--hide-scrollbars",
                url,
            ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=self._sandbox.timeout + 10,
                text=True,
            )

            if os.path.exists(output_path):
                size = os.path.getsize(output_path)
                return {"ok": True, "path": output_path, "size": size, "error": ""}
            else:
                stderr = result.stderr[:500] if result.stderr else "未知错误"
                return {"ok": False, "path": "", "size": 0, "error": f"截图文件未生成: {stderr}"}

        except subprocess.TimeoutExpired:
            return {"ok": False, "path": "", "size": 0, "error": f"截图超时 ({self._sandbox.timeout + 10}s)"}
        except Exception as e:
            return {"ok": False, "path": "", "size": 0, "error": str(e)}

    # ─── 表单提取 ────────────────────────────────────────────

    def extract_forms(self, html: Optional[str] = None) -> List[Dict[str, Any]]:
        """提取页面中的表单信息"""
        html = html or self._last_html
        if not html:
            return []
        parser = _FormExtractor()
        parser.feed(html)
        return parser.forms

    # ─── 表单提交模拟 ────────────────────────────────────────

    def submit_form(
        self,
        action_url: str,
        fields: Dict[str, str],
        method: str = "POST",
    ) -> Dict[str, Any]:
        """模拟表单提交

        Args:
            action_url: 表单 action URL
            fields: 字段名->值 映射
            method: HTTP 方法

        Returns:
            {"ok": bool, "text": str, "status": int, "error": str}
        """
        # 解析相对 URL
        if not action_url.startswith("http") and self._last_url:
            action_url = urljoin(self._last_url, action_url)

        err = self._sandbox.check_url(action_url)
        if err:
            return {"ok": False, "text": "", "status": 0, "error": err}

        try:
            import urllib.parse as up
            encoded = up.urlencode(fields).encode("utf-8")

            if method.upper() == "GET":
                full_url = f"{action_url}?{encoded.decode()}"
                req = urllib.request.Request(full_url, headers={"User-Agent": DEFAULT_UA})
            else:
                req = urllib.request.Request(
                    action_url,
                    data=encoded,
                    headers={
                        "User-Agent": DEFAULT_UA,
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                )

            resp = urllib.request.urlopen(req, timeout=self._sandbox.timeout)
            status = resp.getcode() or 200
            data = resp.read(self._sandbox.max_response_size)
            html = data.decode("utf-8", errors="replace")
            self._last_html = html
            self._last_url = action_url
            text = self._html_to_text(html)
            return {"ok": True, "text": text, "status": status, "error": ""}

        except Exception as e:
            return {"ok": False, "text": "", "status": 0, "error": str(e)}

    # ─── JavaScript 执行 ─────────────────────────────────────

    def execute_js(self, url: str, script: str) -> Dict[str, Any]:
        """通过 headless 浏览器执行 JavaScript

        将 script 包装为 console.log 输出，通过 --dump-dom 或 --print-to-pdf 间接获取结果。
        实际上用 --headless --dump-dom 带注入脚本的 data: URL。

        Returns:
            {"ok": bool, "output": str, "error": str}
        """
        if not self._sandbox.allow_js:
            return {"ok": False, "output": "", "error": "JavaScript 执行已被安全策略禁用"}

        browser_path = self._find_browser()
        if not browser_path:
            return {"ok": False, "output": "", "error": "未找到 Chrome/Edge 浏览器"}

        # 构造一个在页面加载后执行脚本并输出结果的 HTML
        # 使用临时 HTML 文件
        wrapper_html = f"""<!DOCTYPE html>
<html><body>
<script>
try {{
    var __result = (function() {{ {script} }})();
    document.title = JSON.stringify(__result);
}} catch(e) {{
    document.title = "ERROR:" + e.message;
}}
</script>
<div id="__result__"></div>
</body></html>"""

        tmp_html = os.path.join(tempfile.gettempdir(), f"js_exec_{int(time.time())}.html")
        try:
            with open(tmp_html, "w", encoding="utf-8") as f:
                f.write(wrapper_html)

            cmd = [
                browser_path,
                "--headless",
                "--disable-gpu",
                "--no-sandbox",
                "--dump-dom",
                f"file://{tmp_html}",
            ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=self._sandbox.timeout,
                text=True,
            )

            output = result.stdout
            # 尝试从 <title> 提取结果
            m = re.search(r"<title>(.*?)</title>", output, re.S)
            if m:
                title_val = m.group(1)
                if title_val.startswith("ERROR:"):
                    return {"ok": False, "output": "", "error": title_val}
                return {"ok": True, "output": title_val, "error": ""}

            return {"ok": True, "output": output[:2000], "error": ""}

        except subprocess.TimeoutExpired:
            return {"ok": False, "output": "", "error": "JavaScript 执行超时"}
        except Exception as e:
            return {"ok": False, "output": "", "error": str(e)}
        finally:
            try:
                os.unlink(tmp_html)
            except OSError:
                pass

    # ─── 页面元素提取 ────────────────────────────────────────

    def extract_text(self, selector: str = "body", html: Optional[str] = None) -> str:
        """按 CSS 选择器提取文本（支持 tag / .class / #id）"""
        html = html or self._last_html
        if not html:
            return ""
        if selector == "body":
            return self._html_to_text(html)
        parser = _SelectorExtractor(selector)
        parser.feed(html)
        return parser.get_text()

    def extract_links(self, html: Optional[str] = None) -> List[Dict[str, str]]:
        """提取页面所有链接"""
        html = html or self._last_html
        if not html:
            return []
        parser = _LinkExtractor(self._last_url)
        parser.feed(html)
        return parser.links

    # ─── 工具方法 ────────────────────────────────────────────

    @staticmethod
    def _html_to_text(html: str) -> str:
        """HTML 转纯文本"""
        parser = _TextExtractor()
        parser.feed(html)
        return parser.get_text()

    @staticmethod
    def _extract_title(html: str) -> str:
        """提取 HTML <title>"""
        m = re.search(r"<title[^>]*>(.*?)</title>", html, re.S | re.I)
        return m.group(1).strip() if m else ""

    @staticmethod
    def _find_browser() -> Optional[str]:
        """查找系统中的 Chrome 或 Edge 浏览器路径"""
        # 常见路径
        candidates = [
            # Windows Chrome
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            # Windows Edge
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            # Linux
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
            # macOS
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ]

        for path in candidates:
            if os.path.isfile(path):
                return path

        # 尝试 PATH 中查找
        for name in ("chrome", "google-chrome", "chromium", "msedge"):
            found = shutil.which(name)
            if found:
                return found

        return None


# ─── Skill 工厂 ───────────────────────────────────────────────────────


def create_browser_skill(
    sandbox: Optional[BrowserSandbox] = None,
) -> Skill:
    """创建浏览器技能实例（完整版）"""
    core = BrowserToolCore(sandbox=sandbox)

    async def _execute(arguments: dict) -> str:
        action = arguments.get("action", "")
        url = arguments.get("url", "")
        selector = arguments.get("selector", "")
        value = arguments.get("value", "")
        method = arguments.get("method", "POST")
        script = arguments.get("script", "")
        keyword = arguments.get("keyword", "")

        if action == "navigate":
            if not url:
                return "错误：navigate 动作需要提供 url 参数"
            result = core.navigate(url)
            if not result["ok"]:
                return f"导航失败: {result['error']}"
            text = result["text"]
            title = result["title"]
            header = f"📄 {title}\n🔗 {url}\n状态: {result['status']}\n\n"
            return (header + text)[:MAX_OUTPUT_CHARS]

        elif action == "screenshot":
            if not url:
                return "错误：screenshot 动作需要提供 url 参数"
            result = core.screenshot(url)
            if not result["ok"]:
                return f"截图失败: {result['error']}"
            return f"✅ 截图已保存: {result['path']} ({result['size']} bytes)"

        elif action == "extract_text":
            text = core.extract_text(selector or "body")
            return text[:MAX_OUTPUT_CHARS] if text else "未提取到文本"

        elif action == "extract_links":
            links = core.extract_links()
            return json.dumps(links[:100], ensure_ascii=False, indent=2)

        elif action == "extract_forms":
            forms = core.extract_forms()
            if not forms:
                return "页面中未找到表单"
            return json.dumps(forms, ensure_ascii=False, indent=2)

        elif action == "submit_form":
            if not url:
                return "错误：submit_form 动作需要提供 url（action URL）"
            # value 作为 JSON 格式的字段映射
            try:
                fields = json.loads(value) if value else {}
            except json.JSONDecodeError:
                return "错误：value 应为 JSON 格式的字段映射，如 {\"name\": \"test\"}"
            result = core.submit_form(url, fields, method)
            if not result["ok"]:
                return f"表单提交失败: {result['error']}"
            return f"✅ 提交成功 (状态: {result['status']})\n\n{result['text'][:MAX_OUTPUT_CHARS]}"

        elif action == "execute_js":
            if not script:
                return "错误：execute_js 动作需要提供 script 参数"
            result = core.execute_js(url or "about:blank", script)
            if not result["ok"]:
                return f"JavaScript 执行失败: {result['error']}"
            return f"✅ 执行结果:\n{result['output']}"

        elif action == "history":
            entries = core.history.recent(10)
            if not entries:
                return "暂无浏览历史"
            return json.dumps(entries, ensure_ascii=False, indent=2)

        elif action == "history_search":
            if not keyword:
                return "错误：history_search 需要提供 keyword 参数"
            entries = core.history.search(keyword)
            if not entries:
                return f"未找到包含 '{keyword}' 的历史记录"
            return json.dumps(entries, ensure_ascii=False, indent=2)

        elif action == "history_clear":
            count = core.history.clear()
            return f"✅ 已清除 {count} 条历史记录"

        else:
            return f"未知动作: {action}。支持的动作: navigate, screenshot, extract_text, extract_links, extract_forms, submit_form, execute_js, history, history_search, history_clear"

    return Skill(
        name="browser",
        description="浏览器自动化：导航网页、截图、表单提交、JS 执行、元素提取、历史管理",
        triggers=["打开网页", "浏览", "网站", "登录", "表单", "截图"],
        parameters={
            "action": {
                "type": "string",
                "enum": [
                    "navigate", "screenshot", "extract_text", "extract_links",
                    "extract_forms", "submit_form", "execute_js",
                    "history", "history_search", "history_clear",
                ],
                "description": "浏览器动作",
                "required": True,
            },
            "url": {"type": "string", "description": "目标 URL"},
            "selector": {"type": "string", "description": "CSS 选择器（extract_text 时使用）"},
            "value": {"type": "string", "description": "值（fill/submit_form 时为 JSON 字段映射）"},
            "method": {"type": "string", "description": "HTTP 方法（submit_form 时使用，默认 POST）"},
            "script": {"type": "string", "description": "JavaScript 代码（execute_js 时使用）"},
            "keyword": {"type": "string", "description": "搜索关键词（history_search 时使用）"},
        },
        execute_fn=_execute,
    )


# 便捷别名 — 保持向后兼容
BrowserTool = create_browser_skill
