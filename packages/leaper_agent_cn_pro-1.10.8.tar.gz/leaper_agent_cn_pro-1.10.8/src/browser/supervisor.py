"""浏览器进程生命周期管理器（Supervisor）

功能：
1. 浏览器进程生命周期管理
2. 并发限制
3. 超时自动终止
4. 资源清理

通过 subprocess 管理 headless 浏览器进程，
不依赖 playwright/selenium。
"""
from __future__ import annotations

import logging
import os
import signal
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class BrowserProcess:
    """浏览器进程记录"""
    pid: int
    process: subprocess.Popen
    url: str
    created_at: float
    timeout: float
    temp_files: List[str] = field(default_factory=list)
    description: str = ""

    @property
    def alive(self) -> bool:
        """进程是否仍在运行"""
        return self.process.poll() is None

    @property
    def elapsed(self) -> float:
        """已运行时间（秒）"""
        return time.time() - self.created_at

    @property
    def timed_out(self) -> bool:
        """是否已超时"""
        return self.elapsed > self.timeout


class BrowserSupervisor:
    """浏览器进程生命周期管理器

    管理通过 subprocess 启动的 headless 浏览器进程。
    提供并发限制、超时自动终止、资源清理等功能。

    示例::

        supervisor = BrowserSupervisor(max_concurrent=3, default_timeout=30)
        proc = supervisor.launch("https://example.com")
        # ... 使用进程 ...
        supervisor.terminate(proc.pid)
        supervisor.cleanup()
    """

    def __init__(
        self,
        max_concurrent: int = 3,
        default_timeout: float = 30.0,
        browser_path: Optional[str] = None,
    ) -> None:
        """初始化管理器

        Args:
            max_concurrent: 最大并发浏览器进程数
            default_timeout: 默认超时时间（秒）
            browser_path: 浏览器可执行文件路径（自动检测）
        """
        self._max_concurrent = max_concurrent
        self._default_timeout = default_timeout
        self._browser_path = browser_path
        self._processes: Dict[int, BrowserProcess] = {}
        self._lock = threading.Lock()
        self._cleanup_timer: Optional[threading.Timer] = None
        self._running = False

    @property
    def active_count(self) -> int:
        """当前活跃的浏览器进程数"""
        with self._lock:
            return sum(1 for p in self._processes.values() if p.alive)

    @property
    def total_count(self) -> int:
        """总进程记录数（含已退出的）"""
        return len(self._processes)

    def start(self) -> None:
        """启动 supervisor（开始定期清理超时进程）"""
        self._running = True
        self._schedule_cleanup()
        logger.info("BrowserSupervisor 已启动 (max_concurrent=%d)", self._max_concurrent)

    def stop(self) -> None:
        """停止 supervisor 并终止所有进程"""
        self._running = False
        if self._cleanup_timer:
            self._cleanup_timer.cancel()
            self._cleanup_timer = None
        self.terminate_all()
        logger.info("BrowserSupervisor 已停止")

    def launch(
        self,
        url: str,
        args: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        description: str = "",
    ) -> BrowserProcess:
        """启动一个 headless 浏览器进程

        Args:
            url: 目标 URL
            args: 额外浏览器命令行参数
            timeout: 超时时间（秒），None 使用默认值
            description: 进程描述

        Returns:
            BrowserProcess 记录

        Raises:
            RuntimeError: 并发数超限或未找到浏览器
        """
        # 并发检查
        if self.active_count >= self._max_concurrent:
            # 先尝试清理超时的
            self._reap_timed_out()
            if self.active_count >= self._max_concurrent:
                raise RuntimeError(
                    f"浏览器并发数已达上限 ({self._max_concurrent})。"
                    "请等待现有进程完成或手动终止。"
                )

        browser = self._browser_path or self._find_browser()
        if not browser:
            raise RuntimeError("未找到 Chrome/Edge 浏览器，无法启动进程")

        cmd = [
            browser,
            "--headless",
            "--disable-gpu",
            "--no-sandbox",
            "--disable-software-rasterizer",
        ]
        if args:
            cmd.extend(args)
        cmd.append(url)

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
        except Exception as e:
            raise RuntimeError(f"启动浏览器进程失败: {e}")

        record = BrowserProcess(
            pid=proc.pid,
            process=proc,
            url=url,
            created_at=time.time(),
            timeout=timeout or self._default_timeout,
            description=description,
        )

        with self._lock:
            self._processes[proc.pid] = record

        logger.info("浏览器进程已启动: pid=%d, url=%s", proc.pid, url[:80])
        return record

    def terminate(self, pid: int) -> bool:
        """终止指定进程

        Args:
            pid: 进程 PID

        Returns:
            是否成功终止
        """
        with self._lock:
            record = self._processes.get(pid)

        if not record:
            logger.warning("进程 %d 不在管理列表中", pid)
            return False

        if not record.alive:
            return True  # 已退出

        try:
            record.process.terminate()
            try:
                record.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                record.process.kill()
                record.process.wait(timeout=3)
            logger.info("浏览器进程已终止: pid=%d", pid)
            return True
        except Exception as e:
            logger.error("终止进程 %d 失败: %s", pid, e)
            return False

    def terminate_all(self) -> int:
        """终止所有活跃进程

        Returns:
            终止的进程数
        """
        count = 0
        with self._lock:
            pids = list(self._processes.keys())

        for pid in pids:
            if self.terminate(pid):
                count += 1

        return count

    def get_status(self, pid: int) -> Optional[Dict[str, Any]]:
        """获取进程状态"""
        with self._lock:
            record = self._processes.get(pid)

        if not record:
            return None

        return {
            "pid": record.pid,
            "url": record.url,
            "alive": record.alive,
            "elapsed": round(record.elapsed, 1),
            "timeout": record.timeout,
            "timed_out": record.timed_out,
            "description": record.description,
        }

    def list_processes(self) -> List[Dict[str, Any]]:
        """列出所有进程"""
        with self._lock:
            records = list(self._processes.values())

        return [
            {
                "pid": r.pid,
                "url": r.url,
                "alive": r.alive,
                "elapsed": round(r.elapsed, 1),
                "timed_out": r.timed_out,
                "description": r.description,
            }
            for r in records
        ]

    def cleanup(self) -> int:
        """清理已退出的进程记录和临时文件

        Returns:
            清理的记录数
        """
        to_remove = []
        with self._lock:
            for pid, record in self._processes.items():
                if not record.alive:
                    to_remove.append(pid)

        for pid in to_remove:
            with self._lock:
                record = self._processes.pop(pid, None)
            if record:
                self._cleanup_temp_files(record)

        if to_remove:
            logger.debug("已清理 %d 个已退出的浏览器进程记录", len(to_remove))

        return len(to_remove)

    # ─── 内部方法 ────────────────────────────────────────────

    def _reap_timed_out(self) -> int:
        """终止所有超时的进程"""
        timed_out = []
        with self._lock:
            for pid, record in self._processes.items():
                if record.alive and record.timed_out:
                    timed_out.append(pid)

        count = 0
        for pid in timed_out:
            logger.warning("浏览器进程 %d 超时，自动终止", pid)
            if self.terminate(pid):
                count += 1

        return count

    def _cleanup_temp_files(self, record: BrowserProcess) -> None:
        """清理进程关联的临时文件"""
        for path in record.temp_files:
            try:
                if os.path.isfile(path):
                    os.unlink(path)
            except OSError as e:
                logger.debug("清理临时文件失败 %s: %s", path, e)

    def _schedule_cleanup(self) -> None:
        """定期清理任务"""
        if not self._running:
            return

        self._reap_timed_out()
        self.cleanup()

        # 每 10 秒检查一次
        self._cleanup_timer = threading.Timer(10.0, self._schedule_cleanup)
        self._cleanup_timer.daemon = True
        self._cleanup_timer.start()

    @staticmethod
    def _find_browser() -> Optional[str]:
        """查找系统浏览器"""
        import shutil

        candidates = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        ]

        for path in candidates:
            if os.path.isfile(path):
                return path

        for name in ("chrome", "google-chrome", "chromium", "msedge"):
            found = shutil.which(name)
            if found:
                return found

        return None
