"""Skill Hub — 技能发现 + 管理 + 搜索 + 安装

功能：
1. list_available() — 列出所有可用技能（bundled + 用户安装）
2. install(skill_name, source) — 从本地/URL 安装技能到 workspace
3. uninstall(skill_name) — 卸载技能
4. search(query) — 搜索匹配的技能
5. get_info(skill_name) — 获取技能详情

技能目录结构：
- bundled: src/skills/bundled/{name}/SKILL.md + script.py
- 用户: ~/.leaper-cn/skills/{name}/SKILL.md + script.py
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Union

logger = logging.getLogger(__name__)

# 默认用户技能目录
_DEFAULT_USER_SKILLS_DIR = os.path.join(
    os.path.expanduser("~"), ".leaper-cn", "skills"
)


@dataclass
class SkillInfo:
    """Skill 元信息"""
    name: str
    version: str = "0.0.1"
    description: str = ""
    source: str = ""           # 来源（git URL 或本地路径）
    installed_at: float = 0.0
    updated_at: float = 0.0
    tags: List[str] = field(default_factory=list)
    is_bundled: bool = False   # 是否为内置技能
    has_script: bool = False   # 是否有 script.py
    skill_md_path: str = ""    # SKILL.md 路径

    def to_dict(self) -> dict:
        """序列化为字典"""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "source": self.source,
            "installed_at": self.installed_at,
            "updated_at": self.updated_at,
            "tags": self.tags,
            "is_bundled": self.is_bundled,
            "has_script": self.has_script,
            "skill_md_path": self.skill_md_path,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SkillInfo":
        """从字典恢复"""
        valid_fields = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in valid_fields})


def _parse_skill_md(skill_md_path: Path) -> Dict[str, str]:
    """解析 SKILL.md，提取元信息

    支持的格式：
    - 第一行 # 标题 → name
    - 第一段非标题文本 → description
    - tags: xxx, yyy → tags
    - version: x.y.z → version

    Args:
        skill_md_path: SKILL.md 文件路径

    Returns:
        解析出的元信息字典
    """
    result: Dict[str, str] = {}
    try:
        text = skill_md_path.read_text(encoding="utf-8")
    except Exception:
        return result

    lines = text.splitlines()
    for line in lines:
        stripped = line.strip()
        # 标题
        if stripped.startswith("# ") and "name" not in result:
            result["name"] = stripped[2:].strip()
            continue
        # version
        m = re.match(r'^[Vv]ersion:\s*(.+)', stripped)
        if m:
            result["version"] = m.group(1).strip()
            continue
        # tags
        m = re.match(r'^[Tt]ags?:\s*(.+)', stripped)
        if m:
            result["tags"] = m.group(1).strip()
            continue
        # 第一段非空非标题文本 → description
        if stripped and not stripped.startswith("#") and "description" not in result:
            result["description"] = stripped[:200]

    return result


def _scan_skill_dir(skill_dir: Path, is_bundled: bool = False) -> List[SkillInfo]:
    """扫描技能目录，返回发现的技能列表

    Args:
        skill_dir: 技能根目录（下面每个子目录是一个技能）
        is_bundled: 是否标记为内置技能

    Returns:
        SkillInfo 列表
    """
    skills: List[SkillInfo] = []
    if not skill_dir.exists():
        return skills

    for sub in sorted(skill_dir.iterdir()):
        if not sub.is_dir() or sub.name.startswith((".", "_")):
            continue
        skill_md = sub / "SKILL.md"
        if not skill_md.exists():
            continue

        # 解析 SKILL.md
        meta = _parse_skill_md(skill_md)

        # 检查 script.py
        has_script = (sub / "script.py").exists()

        # 读取 version.txt
        version = meta.get("version", "0.0.1")
        version_file = sub / "version.txt"
        if version_file.exists():
            try:
                version = version_file.read_text(encoding="utf-8").strip()
            except Exception:
                pass

        # 解析 tags
        tags_str = meta.get("tags", "")
        tags = [t.strip() for t in tags_str.split(",") if t.strip()] if tags_str else []

        info = SkillInfo(
            name=sub.name,
            version=version,
            description=meta.get("description", ""),
            source="bundled" if is_bundled else str(sub),
            is_bundled=is_bundled,
            has_script=has_script,
            skill_md_path=str(skill_md),
            tags=tags,
        )
        skills.append(info)

    return skills


class SkillHub:
    """Skill 仓库管理器

    管理本地 Skill 的搜索、安装、卸载和更新。
    支持 bundled（内置）和用户安装两种来源。
    """

    def __init__(
        self,
        skills_dir: str,
        bundled_dir: Optional[str] = None,
        registry_file: Optional[str] = None,
    ):
        """
        Args:
            skills_dir: 用户 Skill 存储目录
            bundled_dir: 内置 Skill 目录（可选）
            registry_file: Skill 注册表文件路径（JSON）
        """
        self._skills_dir = Path(skills_dir)
        self._skills_dir.mkdir(parents=True, exist_ok=True)
        self._bundled_dir = Path(bundled_dir) if bundled_dir else None
        self._registry_file = Path(registry_file or (self._skills_dir / ".registry.json"))
        self._registry: Dict[str, SkillInfo] = {}
        self._load_registry()

    def _load_registry(self) -> None:
        """加载注册表"""
        if self._registry_file.exists():
            try:
                data = json.loads(self._registry_file.read_text(encoding="utf-8"))
                for name, info in data.items():
                    self._registry[name] = SkillInfo.from_dict(info)
            except (json.JSONDecodeError, KeyError):
                self._registry = {}

    def _save_registry(self) -> None:
        """保存注册表"""
        data = {name: info.to_dict() for name, info in self._registry.items()}
        self._registry_file.parent.mkdir(parents=True, exist_ok=True)
        self._registry_file.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # ── 核心 API ────────────────────────────────────────

    def list_available(self) -> List[SkillInfo]:
        """列出所有可用技能（bundled + 用户安装）

        Returns:
            合并后的 SkillInfo 列表，bundled 在前
        """
        result: List[SkillInfo] = []

        # 1. 扫描 bundled 目录
        if self._bundled_dir:
            bundled = _scan_skill_dir(self._bundled_dir, is_bundled=True)
            result.extend(bundled)

        # 2. 用户安装的技能（从注册表）
        for info in self._registry.values():
            # 避免与 bundled 重名
            if not any(s.name == info.name for s in result):
                result.append(info)

        # 3. 扫描用户目录中未在注册表的技能
        user_scanned = _scan_skill_dir(self._skills_dir, is_bundled=False)
        for info in user_scanned:
            if not any(s.name == info.name for s in result):
                result.append(info)

        return result

    def install(self, skill_name: str, source: str) -> SkillInfo:
        """安装技能

        Args:
            skill_name: 技能名称
            source: 来源路径（本地目录）

        Returns:
            安装后的 SkillInfo

        Raises:
            FileNotFoundError: 来源不存在
            ValueError: 来源不是有效技能目录
        """
        return self.install_skill(skill_name, source)

    def uninstall(self, skill_name: str) -> None:
        """卸载技能

        Args:
            skill_name: 技能名称

        Raises:
            KeyError: 技能未安装
            ValueError: 不能卸载内置技能
        """
        # 检查是否为 bundled
        if self._bundled_dir:
            bundled_path = self._bundled_dir / skill_name
            if bundled_path.exists():
                raise ValueError(f"不能卸载内置技能: {skill_name}")

        self.uninstall_skill(skill_name)

    def search(self, query: str) -> List[SkillInfo]:
        """搜索匹配的技能（搜索所有可用技能）

        在名称、描述、标签中匹配关键词。

        Args:
            query: 搜索关键词

        Returns:
            匹配的 SkillInfo 列表
        """
        query_lower = query.lower()
        results: List[SkillInfo] = []

        for info in self.list_available():
            if (
                query_lower in info.name.lower()
                or query_lower in info.description.lower()
                or any(query_lower in t.lower() for t in info.tags)
            ):
                results.append(info)

        return results

    def get_info(self, skill_name: str) -> Optional[SkillInfo]:
        """获取技能详情

        先查注册表，再查 bundled，再扫描目录。

        Args:
            skill_name: 技能名称

        Returns:
            SkillInfo 或 None
        """
        # 注册表
        if skill_name in self._registry:
            return self._registry[skill_name]

        # bundled
        if self._bundled_dir:
            bundled_path = self._bundled_dir / skill_name
            if bundled_path.exists() and (bundled_path / "SKILL.md").exists():
                scanned = _scan_skill_dir(self._bundled_dir, is_bundled=True)
                for info in scanned:
                    if info.name == skill_name:
                        return info

        # 用户目录直接扫描
        user_path = self._skills_dir / skill_name
        if user_path.exists() and (user_path / "SKILL.md").exists():
            scanned = _scan_skill_dir(self._skills_dir, is_bundled=False)
            for info in scanned:
                if info.name == skill_name:
                    return info

        return None

    # ── 原有 API（保持兼容） ────────────────────────────

    def search_skills(self, query: str) -> List[SkillInfo]:
        """搜索已安装的 Skill（兼容旧 API）"""
        return self.search(query)

    def install_skill(self, name: str, source: str) -> SkillInfo:
        """安装 Skill

        source 支持：
        - 本地路径（复制到 skills_dir）

        Args:
            name: 技能名称
            source: 来源目录路径

        Returns:
            安装后的 SkillInfo

        Raises:
            FileNotFoundError: 来源不存在
            ValueError: 来源不是有效目录或缺少 SKILL.md
        """
        source_path = Path(source)
        if not source_path.exists():
            raise FileNotFoundError(f"Skill 来源不存在: {source}")
        if not source_path.is_dir():
            raise ValueError(f"Skill 来源必须是目录: {source}")

        # 检查 SKILL.md 是否存在
        skill_md = source_path / "SKILL.md"
        if not skill_md.exists():
            raise ValueError(f"Skill 目录缺少 SKILL.md: {source}")

        # 复制到 skills_dir
        dest = self._skills_dir / name
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(source_path, dest)

        # 解析元信息
        meta = _parse_skill_md(skill_md)

        # 读取版本
        version = meta.get("version", "0.0.1")
        version_file = dest / "version.txt"
        if version_file.exists():
            version = version_file.read_text(encoding="utf-8").strip()

        # 描述
        description = meta.get("description", "")

        # tags
        tags_str = meta.get("tags", "")
        tags = [t.strip() for t in tags_str.split(",") if t.strip()] if tags_str else []

        # 注册
        now = time.time()
        info = SkillInfo(
            name=name,
            version=version,
            description=description,
            source=str(source),
            installed_at=now,
            updated_at=now,
            tags=tags,
            has_script=(dest / "script.py").exists(),
            skill_md_path=str(dest / "SKILL.md"),
        )
        self._registry[name] = info
        self._save_registry()

        logger.info("技能已安装: %s (v%s) from %s", name, version, source)
        return info

    def uninstall_skill(self, name: str) -> None:
        """卸载 Skill"""
        if name not in self._registry:
            raise KeyError(f"Skill 未安装: {name}")

        dest = self._skills_dir / name
        if dest.exists():
            shutil.rmtree(dest)

        del self._registry[name]
        self._save_registry()
        logger.info("技能已卸载: %s", name)

    def update_skill(self, name: str) -> None:
        """更新 Skill（从原始来源重新安装）"""
        if name not in self._registry:
            raise KeyError(f"Skill 未安装: {name}")
        source = self._registry[name].source
        if not source or source == "bundled":
            raise ValueError(f"Skill 缺少来源信息或为内置技能: {name}")
        self.install_skill(name, source)

    def list_skills(self) -> List[SkillInfo]:
        """列出所有已安装的 Skill（兼容旧 API）"""
        return list(self._registry.values())

    def get_skill(self, name: str) -> Optional[SkillInfo]:
        """获取指定 Skill 信息（兼容旧 API）"""
        return self._registry.get(name)
