"""技能加载器 — 从目录扫描并解析 SKILL.md

支持两种格式：
1. 纯 Markdown（现有格式）
2. 带 YAML frontmatter 的 Markdown（AgentSkills 规范）

同时提供 discover_skills() 函数用于多目录自动发现和注册。
"""
from __future__ import annotations

import logging
import os
import re
import shutil
import sys
from pathlib import Path
from typing import Optional

from .base import Skill

logger = logging.getLogger(__name__)

# YAML frontmatter 支持的字段
_FRONTMATTER_FIELDS = {
    "name", "description", "version", "author",
    "triggers", "inputs", "outputs", "gates",
}


def _parse_yaml_frontmatter(content: str) -> tuple[dict, str]:
    """解析 YAML frontmatter，返回 (metadata_dict, remaining_content)

    使用正则解析，不依赖外部 yaml 库（兼容标准库）。
    如果有 PyYAML 可用则优先使用。
    """
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", content, re.DOTALL)
    if not m:
        return {}, content

    frontmatter_text = m.group(1)
    remaining = content[m.end():]

    # 尝试用 PyYAML 解析
    try:
        import yaml
        metadata = yaml.safe_load(frontmatter_text) or {}
        if isinstance(metadata, dict):
            return metadata, remaining
    except ImportError:
        pass
    except Exception:
        pass

    # 回退：用正则解析简单 YAML（key: value 格式）
    metadata: dict = {}
    current_key: Optional[str] = None
    current_list: Optional[list] = None

    for line in frontmatter_text.split("\n"):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        # 列表项（缩进的 - value）
        list_match = re.match(r"^\s+-\s+(.+)$", line)
        if list_match and current_key is not None:
            if current_list is None:
                current_list = []
                metadata[current_key] = current_list
            current_list.append(list_match.group(1).strip().strip('"').strip("'"))
            continue

        # key: value
        kv_match = re.match(r"^(\w+)\s*:\s*(.*)$", line)
        if kv_match:
            current_key = kv_match.group(1)
            value = kv_match.group(2).strip().strip('"').strip("'")
            current_list = None

            if not value:
                # 可能是列表的开始
                continue

            # 内联列表 [a, b, c]
            inline_list = re.match(r"^\[(.+)\]$", value)
            if inline_list:
                items = [v.strip().strip('"').strip("'") for v in inline_list.group(1).split(",")]
                metadata[current_key] = items
            else:
                metadata[current_key] = value
            continue

    return metadata, remaining


def _check_skill_gates(gates: dict) -> tuple[bool, str]:
    """检查 skill 的 gating 条件

    Args:
        gates: gating 配置字典

    Returns:
        (passed, reason) — passed=False 时 reason 说明原因
    """
    if not gates or not isinstance(gates, dict):
        return True, ""

    # 检查环境变量
    requires_env = gates.get("requires_env", [])
    if isinstance(requires_env, list):
        for env_var in requires_env:
            if not os.environ.get(str(env_var)):
                return False, f"缺少环境变量: {env_var}"

    # 检查可执行文件
    requires_bin = gates.get("requires_bin", [])
    if isinstance(requires_bin, list):
        for bin_name in requires_bin:
            if shutil.which(str(bin_name)) is None:
                return False, f"缺少可执行文件: {bin_name}"

    # 检查平台
    platforms = gates.get("platforms", [])
    if isinstance(platforms, list) and platforms:
        current_platform = sys.platform
        # 规范化平台名
        platform_map = {"linux": "linux", "darwin": "darwin", "win32": "win32", "windows": "win32"}
        allowed = {platform_map.get(p, p) for p in platforms}
        if current_platform not in allowed:
            return False, f"平台不支持: 当前 {current_platform}，要求 {platforms}"

    return True, ""


def discover_skills(skill_dirs: list[str]) -> list[Skill]:
    """从多个目录自动发现和加载 skills

    扫描每个目录下的子目录，查找 SKILL.md 文件并解析。
    支持 gating 条件过滤。

    Args:
        skill_dirs: 技能搜索目录列表

    Returns:
        加载成功的 Skill 列表
    """
    loader = SkillLoader()
    all_skills: list[Skill] = []
    seen_names: set[str] = set()

    for skill_dir in skill_dirs:
        skills = loader.load_from_directory(skill_dir)
        for skill in skills:
            if skill.name not in seen_names:
                all_skills.append(skill)
                seen_names.add(skill.name)
            else:
                logger.debug("跳过重复技能: %s (来自 %s)", skill.name, skill_dir)

    logger.info("自动发现 %d 个技能（扫描 %d 个目录）", len(all_skills), len(skill_dirs))
    return all_skills


class SkillLoader:
    """从目录加载 Skill"""

    def load_from_directory(self, skill_dir: str) -> list[Skill]:
        """扫描目录，读取每个 SKILL.md 文件解析为 Skill 对象

        支持 YAML frontmatter 中的 gates 条件过滤。
        """
        skills: list[Skill] = []
        base = Path(skill_dir)
        if not base.exists():
            return skills

        for child in base.iterdir():
            if not child.is_dir():
                continue
            skill_md = child / "SKILL.md"
            if not skill_md.exists():
                continue
            try:
                content = skill_md.read_text(encoding="utf-8")
                skill = self.parse_skill_md(content)
                # 设置脚本路径
                script_file = child / "script.py"
                if script_file.exists():
                    skill.script_path = str(script_file)

                # 检查 gating 条件
                gates = getattr(skill, "_gates", None)
                if gates:
                    passed, reason = _check_skill_gates(gates)
                    if not passed:
                        logger.info("技能 %s 因 gate 条件跳过: %s", skill.name, reason)
                        continue

                skills.append(skill)
            except Exception as e:
                logger.debug("解析技能失败 %s: %s", child.name, e)
                continue

        return skills

    def parse_skill_md(self, content: str) -> Skill:
        """解析 SKILL.md 文件为 Skill 对象

        支持两种格式：
        1. 纯 Markdown（现有）
        2. 带 YAML frontmatter 的 Markdown（AgentSkills 规范）

        YAML frontmatter 示例：
        ```
        ---
        name: my-skill
        description: 技能描述
        version: 1.0.0
        author: Ray
        triggers:
          - keyword1
        gates:
          requires_env: ["API_KEY"]
          requires_bin: ["ffmpeg"]
          platforms: ["linux", "darwin"]
        ---
        ```
        """
        # 先尝试解析 YAML frontmatter
        frontmatter, md_content = _parse_yaml_frontmatter(content)

        # 从 frontmatter 提取字段
        fm_name = frontmatter.get("name", "")
        fm_description = frontmatter.get("description", "")
        fm_version = frontmatter.get("version", "1.0.0")
        fm_author = frontmatter.get("author", "")
        fm_triggers = frontmatter.get("triggers", [])
        fm_inputs = frontmatter.get("inputs", {})
        fm_outputs = frontmatter.get("outputs", {})
        fm_gates = frontmatter.get("gates", {})

        if isinstance(fm_triggers, str):
            fm_triggers = [fm_triggers]

        lines = md_content.strip().split("\n")

        name = fm_name
        description = fm_description
        triggers: list[str] = list(fm_triggers) if isinstance(fm_triggers, list) else []
        parameters: dict = fm_inputs if isinstance(fm_inputs, dict) else {}
        version = str(fm_version) if fm_version else "1.0.0"
        author = fm_author

        section = ""
        for line in lines:
            stripped = line.strip()

            # 标题 = 技能名
            if stripped.startswith("# ") and not stripped.startswith("## "):
                name = stripped[2:].strip()
                continue

            # 描述（blockquote）
            if stripped.startswith("> ") and not description:
                description = stripped[2:].strip()
                continue

            # 段落标题
            if stripped.startswith("## "):
                section = stripped[3:].strip().lower()
                continue

            # Triggers 段
            if section == "triggers" and stripped.startswith("- "):
                triggers.append(stripped[2:].strip())
                continue

            # Parameters 段（Markdown 表格）
            if section == "parameters" and stripped.startswith("|"):
                # 跳过表头和分隔行
                if "---" in stripped or "Name" in stripped:
                    continue
                cols = [c.strip() for c in stripped.split("|")[1:-1]]
                if len(cols) >= 4:
                    p_name, p_type, p_required, p_desc = cols[0], cols[1], cols[2], cols[3]
                    parameters[p_name] = {
                        "type": p_type,
                        "description": p_desc,
                    }
                    if p_required.lower() in ("yes", "true", "1"):
                        parameters[p_name]["required"] = True
                continue

            # Version
            if section == "version" and stripped:
                version = stripped
                continue

            # Author
            if section == "author" and stripped:
                author = stripped
                continue

        skill = Skill(
            name=name or "unknown",
            description=description or name,
            version=version,
            author=author,
            triggers=triggers,
            parameters=parameters,
        )
        # 存储 frontmatter 中的额外元数据
        skill._gates = fm_gates  # type: ignore[attr-defined]
        skill._outputs = fm_outputs  # type: ignore[attr-defined]
        skill._frontmatter = frontmatter  # type: ignore[attr-defined]
        return skill
