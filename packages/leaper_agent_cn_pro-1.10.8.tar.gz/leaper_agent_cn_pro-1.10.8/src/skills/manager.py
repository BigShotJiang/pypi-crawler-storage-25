"""技能管理器 — 统一管理所有技能的加载、查找、执行

升级功能：
1. 技能动态加载与执行
2. 技能参数验证
3. 技能执行沙箱（超时 + 资源限制）
4. 技能版本管理
5. 技能依赖解析
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union

from .base import Skill
from .loader import SkillLoader

logger = logging.getLogger(__name__)


# ============================================================================
# 参数验证器
# ============================================================================

class ParameterValidator:
    """技能参数验证器（基于 JSON Schema 子集）"""

    @staticmethod
    def validate(params: Dict[str, Any], schema: Dict[str, Any]) -> Tuple[bool, str]:
        """验证参数是否符合 schema

        Args:
            params: 用户传入的参数
            schema: 技能定义的 parameters schema

        Returns:
            (valid, error_message)
        """
        # 检查必填参数
        for name, prop in schema.items():
            if isinstance(prop, dict) and prop.get("required", False):
                if name not in params:
                    return False, f"缺少必填参数: {name}"

        # 类型检查
        type_map = {
            "string": str,
            "integer": int,
            "number": (int, float),
            "boolean": bool,
            "array": list,
            "object": dict,
        }

        for name, value in params.items():
            if name not in schema:
                continue  # 允许额外参数
            prop = schema[name]
            if not isinstance(prop, dict):
                continue
            expected_type = prop.get("type", "")
            py_type = type_map.get(expected_type)
            if py_type and not isinstance(value, py_type):
                return False, f"参数 {name} 类型错误: 期望 {expected_type}，实际 {type(value).__name__}"

            # enum 检查
            if "enum" in prop and value not in prop["enum"]:
                return False, f"参数 {name} 值不在允许范围: {prop['enum']}"

        return True, ""


# ============================================================================
# 版本比较
# ============================================================================

def parse_version(version: str) -> Tuple[int, ...]:
    """解析语义版本号为元组"""
    parts = re.findall(r"\d+", version)
    return tuple(int(p) for p in parts) if parts else (0,)


def version_satisfies(current: str, required: str) -> bool:
    """检查当前版本是否满足要求（>=）"""
    return parse_version(current) >= parse_version(required)


# ============================================================================
# 依赖解析器
# ============================================================================

class DependencyResolver:
    """技能依赖解析器 — 拓扑排序"""

    @staticmethod
    def resolve(
        skills: Dict[str, Skill],
        dependencies: Dict[str, List[str]],
    ) -> Tuple[List[str], List[str]]:
        """解析依赖顺序

        Args:
            skills: 已注册的技能字典 {name: Skill}
            dependencies: 技能依赖关系 {skill_name: [dep1, dep2]}

        Returns:
            (ordered_names, missing_deps)
        """
        missing: List[str] = []
        # 检查缺失依赖
        for name, deps in dependencies.items():
            for dep in deps:
                if dep not in skills:
                    missing.append(f"{name} → {dep}")

        if missing:
            return [], missing

        # 拓扑排序（Kahn 算法）
        in_degree: Dict[str, int] = {name: 0 for name in skills}
        for name, deps in dependencies.items():
            in_degree.setdefault(name, 0)
            for dep in deps:
                in_degree[name] = in_degree.get(name, 0) + 1

        queue: List[str] = [n for n, d in in_degree.items() if d == 0]
        ordered: List[str] = []

        adj: Dict[str, List[str]] = {}
        for name, deps in dependencies.items():
            for dep in deps:
                adj.setdefault(dep, []).append(name)

        while queue:
            node = queue.pop(0)
            ordered.append(node)
            for neighbor in adj.get(node, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # 补充没有依赖关系的技能
        for name in skills:
            if name not in ordered:
                ordered.append(name)

        return ordered, []


# ============================================================================
# SkillManager 主类
# ============================================================================

class SkillManager:
    """技能管理器

    升级功能：
    - 参数验证
    - 版本管理
    - 依赖解析
    - 执行沙箱（超时保护）
    - 动态加载/卸载
    """

    def __init__(
        self,
        skill_dirs: Optional[List[str]] = None,
        sandbox_timeout: int = 30,
    ):
        """
        Args:
            skill_dirs: 技能搜索目录列表
            sandbox_timeout: 技能执行超时（秒）
        """
        self._loader = SkillLoader()
        self._skills: Dict[str, Skill] = {}
        self._versions: Dict[str, str] = {}          # {name: version}
        self._dependencies: Dict[str, List[str]] = {}  # {name: [dep1, dep2]}
        self._sandbox_timeout = sandbox_timeout
        self._validator = ParameterValidator()
        self._resolver = DependencyResolver()

        if skill_dirs is None:
            skill_dirs = [
                str(Path.home() / ".leaper-cn" / "skills"),
                str(Path(__file__).parent.parent / "templates" / "workshop" / "skills"),
            ]

        for d in skill_dirs:
            self.load_directory(d)

    # ------------------------------------------------------------------
    # 加载与注册
    # ------------------------------------------------------------------

    def load_directory(self, directory: str) -> int:
        """从目录加载技能，返回加载数量"""
        count = 0
        for skill in self._loader.load_from_directory(directory):
            self._register_internal(skill)
            count += 1
        return count

    def register(self, skill: Skill, dependencies: Optional[List[str]] = None) -> None:
        """手动注册一个 skill

        Args:
            skill: 技能实例
            dependencies: 依赖的其他技能名称列表
        """
        self._register_internal(skill, dependencies)

    def _register_internal(self, skill: Skill, dependencies: Optional[List[str]] = None) -> None:
        """内部注册"""
        self._skills[skill.name] = skill
        self._versions[skill.name] = skill.version
        if dependencies:
            self._dependencies[skill.name] = dependencies
        logger.debug(f"已注册技能: {skill.name} v{skill.version}")

    def unregister(self, name: str) -> bool:
        """卸载技能"""
        if name in self._skills:
            del self._skills[name]
            self._versions.pop(name, None)
            self._dependencies.pop(name, None)
            return True
        return False

    def reload(self, name: str) -> bool:
        """重新加载指定技能（从其原始目录）"""
        skill = self._skills.get(name)
        if not skill or not skill.script_path:
            return False
        skill_dir = str(Path(skill.script_path).parent.parent)
        self.unregister(name)
        loaded = self.load_directory(skill_dir)
        return loaded > 0

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------

    def get_all_skills(self) -> List[Skill]:
        """获取所有可用技能"""
        return list(self._skills.values())

    def get_skill(self, name: str) -> Optional[Skill]:
        """按名称获取技能"""
        return self._skills.get(name)

    def find_skill(self, query: str) -> Optional[Skill]:
        """根据用户输入匹配最相关的 skill（trigger 关键词匹配）"""
        query_lower = query.lower()

        # 精确名称匹配
        if query_lower in self._skills:
            return self._skills[query_lower]

        # trigger 关键词匹配
        best: Optional[Skill] = None
        best_score = 0
        for skill in self._skills.values():
            for trigger in skill.triggers:
                if trigger.lower() in query_lower:
                    score = len(trigger)
                    if score > best_score:
                        best = skill
                        best_score = score
        return best

    def get_version(self, name: str) -> Optional[str]:
        """获取技能版本"""
        return self._versions.get(name)

    def to_tool_defs(self) -> List[dict]:
        """将所有 skill 转为 tool_defs 格式"""
        return [s.to_tool_def() for s in self._skills.values()]

    # ------------------------------------------------------------------
    # 执行（带验证和沙箱）
    # ------------------------------------------------------------------

    async def execute_skill(
        self,
        name: str,
        arguments: dict,
        validate: bool = True,
        timeout: Optional[int] = None,
    ) -> str:
        """执行指定 skill

        Args:
            name: 技能名称
            arguments: 参数字典
            validate: 是否进行参数验证
            timeout: 超时秒数（覆盖默认值）

        Returns:
            执行结果字符串
        """
        skill = self._skills.get(name)
        if not skill:
            return f"技能 {name} 不存在"

        # 参数验证
        if validate and skill.parameters:
            valid, error = self._validator.validate(arguments, skill.parameters)
            if not valid:
                return f"参数验证失败: {error}"

        # 依赖检查
        deps = self._dependencies.get(name, [])
        for dep in deps:
            if dep not in self._skills:
                return f"缺少依赖技能: {dep}"

        # 沙箱执行（超时保护）
        exec_timeout = timeout or self._sandbox_timeout
        try:
            result = await asyncio.wait_for(
                skill.execute(arguments),
                timeout=exec_timeout,
            )
            return result
        except asyncio.TimeoutError:
            return f"技能 {name} 执行超时（{exec_timeout}s）"
        except Exception as e:
            logger.error(f"技能 {name} 执行异常: {e}")
            return f"技能 {name} 执行异常: {e}"

    # ------------------------------------------------------------------
    # 版本与依赖
    # ------------------------------------------------------------------

    def check_dependencies(self) -> Dict[str, Any]:
        """检查所有技能的依赖状态"""
        ordered, missing = self._resolver.resolve(self._skills, self._dependencies)
        return {
            "total_skills": len(self._skills),
            "load_order": ordered,
            "missing_dependencies": missing,
            "healthy": len(missing) == 0,
        }

    def list_versions(self) -> Dict[str, str]:
        """列出所有技能版本"""
        return dict(self._versions)
