"""自动技能创建器 — 从对话模式中学习新技能"""
from __future__ import annotations

import re
from collections import Counter
from pathlib import Path

from .base import Skill


class SkillCreator:
    """自动技能创建器：从对话中学习新技能"""

    def __init__(self, brain=None, skill_dir: str = ""):
        self.brain = brain
        self.skill_dir = skill_dir or str(Path.home() / ".leaper-cn" / "skills")

    async def should_create_skill(self, conversation: list[dict]) -> bool:
        """判断对话中是否有值得提取为 skill 的模式
        条件：用户多次执行类似操作（>3次）且操作可以参数化
        """
        # 提取用户消息中的 tool_call 模式
        tool_calls = []
        for msg in conversation:
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                for tc in msg["tool_calls"]:
                    tool_calls.append(tc["function"]["name"])

        # 同一个工具被调用超过 3 次 → 可能值得封装
        counts = Counter(tool_calls)
        return any(c >= 3 for c in counts.values())

    async def extract_skill(self, conversation: list[dict]) -> Skill | None:
        """从对话模式中提取 skill 定义（不调 LLM，用规则）"""
        # 找出重复最多的 tool_call 模式
        tool_calls: list[dict] = []
        for msg in conversation:
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                for tc in msg["tool_calls"]:
                    tool_calls.append(tc["function"])

        if not tool_calls:
            return None

        counts = Counter(tc["name"] for tc in tool_calls)
        most_common_name, count = counts.most_common(1)[0]
        if count < 3:
            return None

        # 提取该工具的常见参数模式
        params: dict = {}
        for tc in tool_calls:
            if tc["name"] == most_common_name:
                args = tc.get("arguments", {})
                if isinstance(args, str):
                    import json
                    try:
                        args = json.loads(args)
                    except Exception:
                        continue
                for k, v in args.items():
                    if k not in params:
                        params[k] = {"type": type(v).__name__, "description": k}

        return Skill(
            name=f"auto-{most_common_name}",
            description=f"自动提取的 {most_common_name} 组合技能",
            triggers=[most_common_name],
            parameters=params,
        )

    async def save_skill(self, skill: Skill) -> str:
        """保存为 SKILL.md + script.py 到 skill_dir"""
        skill_path = Path(self.skill_dir) / skill.name
        skill_path.mkdir(parents=True, exist_ok=True)

        # 生成 SKILL.md
        md_lines = [
            f"# {skill.name}",
            f"> {skill.description}",
            "",
            "## Triggers",
        ]
        for t in skill.triggers:
            md_lines.append(f"- {t}")

        if skill.parameters:
            md_lines.append("")
            md_lines.append("## Parameters")
            md_lines.append("| Name | Type | Required | Description |")
            md_lines.append("|------|------|----------|-------------|")
            for k, v in skill.parameters.items():
                req = "yes" if v.get("required") else "no"
                md_lines.append(f"| {k} | {v.get('type', 'string')} | {req} | {v.get('description', '')} |")

        md_lines.append("")
        md_lines.append("## Script")
        md_lines.append("script.py")

        (skill_path / "SKILL.md").write_text("\n".join(md_lines), encoding="utf-8")

        # 生成 script.py 模板
        script = '''"""自动生成的技能脚本"""
import json
import sys

def main():
    args = json.loads(sys.stdin.read())
    # 注意：技能逻辑需要用户在生成后手动实现，此处仅生成模板框架
    print(json.dumps({"result": "ok", "args": args}, ensure_ascii=False))

if __name__ == "__main__":
    main()
'''
        (skill_path / "script.py").write_text(script, encoding="utf-8")

        return str(skill_path)
