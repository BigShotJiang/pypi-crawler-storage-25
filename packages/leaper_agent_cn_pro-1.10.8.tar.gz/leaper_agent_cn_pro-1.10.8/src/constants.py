"""常量管理 - 集中管理所有常量值"""

from __future__ import annotations

# 版本号
VERSION = "1.8.1"
VERSION_CODENAME = "龙腾"  # Dragon Ascends

# 默认配置值
DEFAULT_MODEL = "qwen-plus"
DEFAULT_TEMPERATURE = 0.7
DEFAULT_MAX_TOKENS = 4096
DEFAULT_TIMEOUT = 30  # 秒
DEFAULT_RETRIES = 3
DEFAULT_RETRY_DELAY = 1.0  # 秒

# Token 限制
MAX_CONTEXT_TOKENS = 128_000
MAX_OUTPUT_TOKENS = 8_192
TOKEN_RESERVE = 1_000  # 预留 token 数
CHARS_PER_TOKEN_CN = 1.5  # 中文字符约 1.5 char/token
CHARS_PER_TOKEN_EN = 4.0  # 英文约 4 char/token

# 超时设置（秒）
API_TIMEOUT = 60
TOOL_TIMEOUT = 30
SANDBOX_TIMEOUT = 30
SKILL_LOAD_TIMEOUT = 10
STATE_SAVE_INTERVAL = 300  # 5 分钟
STATE_SAVE_OPS_THRESHOLD = 100  # 每 100 次操作

# 文件大小限制
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
MAX_LOG_FILE_SIZE = 50 * 1024 * 1024  # 50MB
LOG_BACKUP_COUNT = 7  # 日志保留天数
MAX_UPLOAD_SIZE = 20 * 1024 * 1024  # 20MB

# 路径相关
STATE_FILE = ".state.json"
LOG_DIR = "logs"
SKILLS_DIR = "skills"
CACHE_DIR = ".cache"

# 敏感路径黑名单（安全检查用）
SENSITIVE_PATHS = [
    "/etc/shadow",
    "/etc/passwd",
    "/etc/sudoers",
    "/.ssh/",
    "/id_rsa",
    "/id_ed25519",
    "/.env",
    "/.aws/credentials",
    "/.kube/config",
    "/api_key",
    "/secret",
    "/.git/config",
]

# 危险域名黑名单
DANGEROUS_DOMAINS = [
    "metadata.google.internal",
    "169.254.169.254",  # AWS/GCP metadata
    "metadata.internal",
]

# 正则模式
import re

RE_CHINESE = re.compile(r"[\u4e00-\u9fff]")
RE_DURATION = re.compile(r"^(\d+)\s*([smhd])$", re.IGNORECASE)
RE_DANGEROUS_CMD = re.compile(
    r"\b(rm\s+-rf|del\s+/[sfq]|format\s+[a-z]:|shutdown|reboot|mkfs)\b",
    re.IGNORECASE,
)
RE_INTERNAL_IP = re.compile(
    r"^(127\.|10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|0\.|localhost|::1|\[::1\])"
)

# Skill 相关
SKILL_MANIFEST_FILE = "SKILL.md"
SKILL_VERSION_FILE = "version.txt"
SKILL_MAX_SCRIPT_SIZE = 1 * 1024 * 1024  # 1MB

# 支持的国产模型前缀
SUPPORTED_MODEL_PREFIXES = [
    "qwen",
    "glm",
    "deepseek",
    "baichuan",
    "spark",
    "ernie",
    "moonshot",
    "yi-",
    "abab",
    "hunyuan",
]
