"""模板部署器 — 将角色/行业模板部署到 workspace"""
import shutil
from pathlib import Path
from importlib import resources


class TemplateDeployer:
    """模板部署器"""

    def __init__(self, base_dir: Path | None = None):
        # 模板源目录：包内 templates/ 或自定义路径
        if base_dir:
            self.template_dir = base_dir
        else:
            self.template_dir = Path(__file__).parent / "workshop" / "templates"

    def deploy(
        self,
        role: str,
        industry: str | None = None,
        agent_name: str | None = None,
        user_info: dict | None = None,
    ) -> Path:
        """
        部署模板到 workspace:
        1. 复制通用角色模板 (templates/{role}/)
        2. 覆盖行业变体（如果有）
        3. 复制 _common/ 共享文件
        4. 复制 L1 行业 Skill
        5. 填充 USER.md 用户信息

        返回 workspace 路径
        """
        name = agent_name or f"{role}-agent"
        workspace = Path.home() / ".leaper-cn" / "workspaces" / name
        workspace.mkdir(parents=True, exist_ok=True)

        # 1. 确定模板目录：优先行业特化 ({role}-{industry})，fallback 通用 ({role})
        if industry:
            industry_dir = self.template_dir / f"{role}-{industry}"
            if industry_dir.exists():
                role_dir = industry_dir
            else:
                role_dir = self.template_dir / role
        else:
            role_dir = self.template_dir / role
        if role_dir.exists():
            self._copy_tree(role_dir, workspace)

        # 2. 行业变体覆盖（旧格式兼容：{role}/_{industry}）
        if industry:
            variant_dir = self.template_dir / role / f"_{industry}"
            if variant_dir.exists():
                self._copy_tree(variant_dir, workspace)

        # 3. 通用共享文件
        common_dir = self.template_dir / "_common"
        if common_dir.exists():
            self._copy_tree(common_dir, workspace)

        # 4. 行业 Skill（L1-industry）
        if industry:
            # 新结构：skills/L1-industry/{industry}/
            skill_dir = self.template_dir.parent / "skills" / "L1-industry" / industry
            if not skill_dir.exists():
                # fallback 旧结构
                skill_dir = self.template_dir / "_skills" / industry
            if skill_dir.exists():
                target = workspace / "skills" / industry
                target.mkdir(parents=True, exist_ok=True)
                self._copy_tree(skill_dir, target)

        # 5. 填充 USER.md
        if user_info:
            user_md = workspace / "USER.md"
            lines = ["# USER.md\n"]
            for key, val in user_info.items():
                lines.append(f"- **{key}:** {val}")
            user_md.write_text("\n".join(lines), encoding="utf-8")

        return workspace

    async def import_brain_seeds(self, workspace: Path, agent_id: str, industry: str = "", role: str = "") -> int:
        """将 workspace/brain-seeds/ 下的 .md 文件灌入 brain.db"""
        seeds_dir = workspace / "brain-seeds"
        if not seeds_dir.exists():
            return 0

        from ..brain.engine import LeaperBrain

        brain_db = workspace / "brain.db"
        brain = LeaperBrain(str(brain_db), agent_id)
        await brain.initialize()

        if role and industry:
            ns = f"desk/{role}/{industry}"
        elif role:
            ns = f"desk/{role}"
        else:
            ns = ""
        count = 0
        for seed_file in sorted(seeds_dir.glob("*.md")):
            content = seed_file.read_text(encoding="utf-8")
            category = seed_file.stem
            await brain.store_entry(
                entry_type="seed",
                content=content,
                category=f"industry-seed:{category}",
                confidence=0.95,
                namespace=ns,
                metadata={"source": f"brain-seeds/{seed_file.name}", "type": "industry-knowledge"},
            )
            count += 1

        await brain.close()
        return count

    @staticmethod
    def _copy_tree(src: Path, dst: Path) -> None:
        """递归复制目录内容（忽略以 _ 开头的子目录，跳过部署无关文件）"""
        SKIP_FILES = {"template.yaml"}
        for item in src.iterdir():
            if item.name.startswith("_"):
                continue
            if item.name in SKIP_FILES:
                continue
            target = dst / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)
