# 模板部署设计 — 从 leaper-templates 仓库 → 用户 workspace

## 目标

用户选择行业+角色后，系统把模板文件铺到 workspace，Agent 直接可用。

## 部署结构（用户 workspace 最终形态）

```
~/.leaper/workspaces/{agent-name}/
├── SOUL.md          ← 从 templates/{role} 或 templates/{role}-{industry} 复制
├── EGO.md           ← 同上
├── IDENTITY.md      ← 同上（用户可编辑公司名等）
├── AGENTS.md        ← 同上
├── USER.md          ← 同上（用户填写自己信息）
├── MEMORY.md        ← 初始为空模板
├── ONBOARDING.md    ← 从通用 CXO 的 ONBOARDING 复制
├── LIFECYCLE.md     ← 从 _common/LIFECYCLE.md 复制
├── TRIGGERS.md      ← 从 _common/TRIGGERS.md 复制
├── _common/         ← 从 _common/ 整体复制
│   ├── PREAMBLE.md
│   ├── ROLE-TYPES.md
│   └── SELF-CHECK.md
└── skills/          ← 从 skills/ 复制对应行业
    └── {industry}/
        └── SKILL.md
```

## 部署逻辑

```typescript
interface TemplateDeployOptions {
  role: string;        // e.g. "cto"
  industry?: string;   // e.g. "finance"（可选，不填用通用版）
  agentName: string;   // e.g. "my-cto"
  userInfo?: {         // 可选预填
    name?: string;
    company?: string;
    industry?: string;
  };
}

function deployTemplate(opts: TemplateDeployOptions): string {
  const workspaceDir = `~/.leaper/workspaces/${opts.agentName}`;
  
  // 1. 确定模板来源
  const templateDir = opts.industry 
    ? `templates/${opts.role}-${opts.industry}`   // 行业版优先
    : `templates/${opts.role}`;                   // 通用版兜底
  
  // 2. 复制角色文件
  copy(templateDir + '/SOUL.md', workspaceDir + '/SOUL.md');
  copy(templateDir + '/EGO.md', workspaceDir + '/EGO.md');
  copy(templateDir + '/IDENTITY.md', workspaceDir + '/IDENTITY.md');
  copy(templateDir + '/AGENTS.md', workspaceDir + '/AGENTS.md');
  // USER.md 和 MEMORY.md 用通用版的空模板
  copy(`templates/${opts.role}/USER.md`, workspaceDir + '/USER.md');
  copy(`templates/${opts.role}/MEMORY.md`, workspaceDir + '/MEMORY.md');
  
  // 3. 复制 ONBOARDING（从通用版取，行业版没有）
  copy(`templates/${opts.role}/ONBOARDING.md`, workspaceDir + '/ONBOARDING.md');
  
  // 4. 复制 _common 共享文件
  copyDir('templates/_common', workspaceDir + '/_common');
  // 同时把 LIFECYCLE 和 TRIGGERS 放到 workspace 根目录（prompt-builder 会读）
  copy('templates/_common/LIFECYCLE.md', workspaceDir + '/LIFECYCLE.md');
  copy('templates/_common/TRIGGERS.md', workspaceDir + '/TRIGGERS.md');
  
  // 5. 复制行业 Skill
  if (opts.industry) {
    copyDir(`skills/L1-industry/${opts.industry}`, workspaceDir + '/skills/' + opts.industry);
  }
  
  // 6. 如果有用户信息，预填 USER.md 和 IDENTITY.md
  if (opts.userInfo) {
    fillUserInfo(workspaceDir, opts.userInfo);
  }
  
  return workspaceDir;
}
```

## 行业变体 vs 通用版的文件差异

| 文件 | 通用版 | 行业变体 |
|------|--------|---------|
| SOUL.md | 通用性格 | 加入行业术语/场景 |
| EGO.md | 通用工位 | 加入行业特定工位 |
| IDENTITY.md | 通用身份 | 加入行业标签 |
| AGENTS.md | 通用协作 | 同（不变） |
| MEMORY.md | 空 | 空 |
| ONBOARDING.md | ✅ 有 | ❌ 没有（继承通用版） |
| USER.md | 空模板 | 无（继承通用版） |

## 优先级合并规则

当行业版和通用版都有同名文件时：**行业版优先**。
当行业版没有某文件时：**从通用版继承**。

这保证了：
- 行业版可以只覆盖需要差异化的文件
- 通用版的 ONBOARDING/USER 自动继承
- _common/ 对所有变体生效
