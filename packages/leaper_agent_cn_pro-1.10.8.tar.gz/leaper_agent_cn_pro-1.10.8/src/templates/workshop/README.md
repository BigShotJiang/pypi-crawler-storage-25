# Leaper Templates

Private template repository for Leaper Agent.

## Usage

```bash
leaper create ceo-coach --bot-token YOUR_TOKEN
```

Templates are fetched automatically by the `leaper` CLI.
