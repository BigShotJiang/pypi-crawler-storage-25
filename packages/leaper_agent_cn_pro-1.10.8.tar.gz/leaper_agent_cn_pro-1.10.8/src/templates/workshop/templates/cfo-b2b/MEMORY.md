# MEMORY — CFO B2B/SaaS 财务知识库

> 由 Leaper Brain 在对话过程中自动更新。B2B/SaaS 行业 CFO 专属财务知识。

### ARR 与 MRR 的计算与跟踪

ARR（Annual Recurring Revenue）= 当前 MRR × 12。MRR 的四个组成部分：新增 MRR（新客户）、扩展 MRR（增购/升级）、收缩 MRR（降级）、流失 MRR（取消）。Net New MRR = 新增 + 扩展 - 收缩 - 流失。投资人最关注 Net New MRR 的月度趋势和 ARR 的 YoY 增长率。ARR $1M 是 A 轮门槛，$10M 是 B 轮门槛（硅谷标准）。

### NRR（净收入留存率）深度解析

NRR = (期初 ARR + 扩展 - 收缩 - 流失) / 期初 ARR。优秀 SaaS 公司 NRR >120%（Snowflake 158%、Datadog 130%+）。NRR >100% 意味着即使不获新客，收入也在增长。提升 NRR 的三条路径：①按用量计费（usage grows with customer）；②交叉销售新模块；③按席位计费 + 客户组织自然增长。NRR <90% 是红灯，说明产品价值有问题。

### Churn Rate 的多维分析

Logo Churn（客户数流失率）和 Revenue Churn（收入流失率）要分开看。月度 Logo Churn <2%（年化 <22%）是 SMB 底线，<1%（年化 <11%）是 Mid-Market 目标，<0.5%（年化 <6%）是 Enterprise 标杆。Gross Revenue Churn（不含扩展）vs Net Revenue Churn（含扩展），后者可以是负数（好事）。按 Cohort 分析 Churn 才有意义，不要只看整体平均。

### LTV/CAC 比值与回本周期

LTV = ARPA × Gross Margin / Churn Rate。CAC = (Sales + Marketing 成本) / 新增客户数。LTV/CAC >3 是健康底线，>5 说明可以加大投入，<3 要优化获客效率或提升留存。CAC Payback（回本周期）= CAC / (ARPA × Gross Margin)。SMB <12 个月，Mid-Market <18 个月，Enterprise <24 个月。关注 Blended CAC 和 Fully-loaded CAC 的差异。

### ASC 606 收入确认规则

SaaS 收入确认的五步模型：①识别合同；②识别履约义务；③确定交易价格；④分配交易价格；⑤确认收入（随时间或时点）。SaaS 订阅通常按时间均摊确认（Ratable Recognition）。实施服务如果是独立履约义务，可以按完工百分比确认。多年期合同要考虑重大融资成分。预收款记 Deferred Revenue（合同负债），这是 SaaS 资产负债表的特色。

### 订阅制财务建模方法

SaaS 财务模型的核心驱动因子：新客户数 × ACV × 留存率 × 扩展率。建模步骤：①Cohort-based 收入预测（每批客户独立建模）；②成本分为 COGS（托管成本、客户成功）和 OpEx（研发、销售、行政）；③关键假设：logo churn、NRR、新客增长率、ACV 变化趋势。用 Monthly Cohort Model 更准确，Annual Model 适合做长期预测。

### 客户分层定价策略

B2B SaaS 典型三层定价：Free/Starter（获客漏斗入口，<$50/月）、Professional（主力收入，$50-500/月）、Enterprise（高利润，>$500/月，需销售介入）。定价维度：按席位（Seat-based）、按用量（Usage-based）、按功能（Feature-based）或混合。年付 vs 月付：年付给 15-20% 折扣，锁定现金流。每年调价 5-10% 是行业惯例。

### SaaS 毛利率分析

SaaS 毛利率 = (订阅收入 - COGS) / 订阅收入。COGS 包括：云基础设施成本（AWS/Azure/阿里云）、客户支持人力、第三方软件许可、数据中心费用。优秀 SaaS 毛利率 >75%，合格线 >65%。提升路径：①优化云成本（Reserved Instance、Spot 实例）；②自动化客服（Chatbot 替代人工）；③减少第三方依赖。专业服务（实施/定制开发）的毛利率通常只有 20-40%，要单独核算。

### Rule of 40 与效率评分

Rule of 40 = 收入增长率 + 利润率（通常用 FCF Margin 或 EBITDA Margin）。>40% 是优秀，>60% 是顶级（如 Veeva、Datadog）。不同阶段侧重不同：早期增长率 >80% 但亏损 -40% = Rule of 40；成熟期增长率 20% + 利润率 25% = Rule of 45。投资人用 Rule of 40 横向比较 SaaS 公司效率。Bessemer 提出 Rule of X（增长率权重更高）。

### Burn Multiple 与资金效率

Burn Multiple = Net Burn / Net New ARR。<1x 是极好（每烧 1 元带来 >1 元 ARR），1-2x 是好，2-3x 是可接受（早期），>3x 要警惕。Burn Multiple 是 David Sacks 提出的 SaaS 效率指标，比 CAC Payback 更简单直观。优化路径：提高 ACV（同样获客成本但更高合同额）、提升销售效率（减少 Sales Cycle）、控制人头增长。

### 现金流管理与 Runway

SaaS 公司的 Cash Runway = 可用现金 / 月度净烧钱。健康 Runway >18 个月，<12 个月要立即启动融资。年付预收款改善现金流：$1M ARR 全年付 → 提前收到 $1M 现金。管理重点：①DSO（应收账款天数）控制在 45 天内；②供应商账期拉长到 60 天；③云成本是最大可控变量。季度末现金流预测很重要。

### Magic Number 与销售效率

Magic Number = 本季度 Net New ARR / 上季度 Sales & Marketing 支出。>1.0 说明获客效率好，可以加大投入；0.5-1.0 需要优化；<0.5 要停下来找问题。按销售团队/渠道/客户分层拆解 Magic Number 才有意义。Enterprise 团队 Magic Number 通常低于 SMB（长销售周期），但 LTV 更高。季度波动大时看滚动 4 季度平均。

### Deferred Revenue 与 Billings

Billings = 收入 + Δ Deferred Revenue。Billings 反映合同签约节奏，收入反映交付节奏。Billings 增长快于收入增长，说明签约势头好（好信号）。Remaining Performance Obligations (RPO) 是未来要确认的收入总额，类似 Backlog。cRPO（Current RPO，未来 12 个月）是更实用的前瞻指标。

### 研发投入与资本化

SaaS 公司研发支出占收入的比例：早期 30-50%，成长期 20-30%，成熟期 15-20%。ASC 350-40 允许将内部使用软件的开发阶段支出资本化（初始项目阶段和运维阶段费用化）。资本化降低当期费用、提高利润，但影响现金流报表。投资人通常更关注未资本化的研发投入，因为资本化可以被操纵。

### 单位经济模型（Unit Economics）

每个客户的经济模型：①获客成本 CAC（全包：销售、营销、SDR、活动）；②首年收入 ACV；③服务成本（Onboarding + CSM + Support）；④毛利贡献 = ACV × Gross Margin - Service Cost；⑤LTV（全生命周期贡献）= 毛利贡献 / Annual Churn Rate。按客户分层（SMB/Mid/Enterprise）分别计算 Unit Economics，不要只看 Blended。

### 融资估值与 SaaS Multiples

SaaS 估值常用 EV/Revenue 或 EV/ARR。2024-2025 年市场 Multiples：高增长（>40% YoY）= 10-15x ARR，中等增长（20-40%）= 5-10x ARR，低增长（<20%）= 3-5x ARR。影响因素：NRR、毛利率、Rule of 40、TAM 大小、市场地位。中国 SaaS 估值通常是美国的 40-60%。一级市场比二级市场有溢价。

### 销售佣金与 ASC 606 下的处理

销售佣金在 ASC 606 下作为合同取得成本（Contract Acquisition Cost），需要资本化并在预期客户生命周期内摊销（通常 3-5 年）。这改变了 P&L 的时间分布——首年费用降低，但 Balance Sheet 多了一个资产项。佣金结构：新签 10-15% ACV，续约 3-5% ACV，扩展 5-8% ACV。加速器（Accelerator）在超额完成时佣金比例上浮。

### 云成本优化（FinOps）

云成本通常占 SaaS COGS 的 40-60%。FinOps 三步走：①Inform（按租户/功能/团队拆分成本归属）；②Optimize（RI/Savings Plan 锁定 1-3 年，省 30-50%；Spot 实例用于弹性负载；右Sizing 调整实例规格）；③Operate（每月成本审查会，设预算告警）。Per-customer Gross Margin 要追踪——有些大客户可能是赔钱的。

### FP&A（财务计划与分析）

SaaS FP&A 的核心输出：①月度 Flash Report（实际 vs 预算 vs 预测）；②季度 Board Deck（KPI 仪表盘 + 关键洞察）；③年度 Budget + 3 年 Plan。关键分析维度：按产品线、按客户分层、按地区、按销售团队。Scenario Analysis（Best / Base / Worst）在不确定环境下特别重要。FP&A 工具：Mosaic / Pigment / 传统 Excel。

### 税务与跨境收入

SaaS 跨境销售涉及：①增值税/GST（各国税率不同，>$10K 收入门槛需注册）；②Transfer Pricing（关联交易定价，需符合独立交易原则）；③Withholding Tax（预扣税，部分国家对软件许可费征收 10-25%）；④常设机构风险（远程员工可能触发）。建议 >$1M 海外收入后找四大做税务架构规划。中国企业出海常见架构：HK 控股 + 新加坡运营主体。

### 财务系统与自动化

SaaS 财务系统栈：①ERP（NetSuite / Sage Intacct / 用友）；②计费（Stripe Billing / Chargebee / Zuora）；③费控（Brex / Ramp / 分贝通）；④FP&A（Mosaic / Anaplan / Excel）。收入确认自动化是重点——手工确认容易出错且审计风险高。数据流：CRM（签约）→ Billing（开票）→ ERP（确认收入）→ FP&A（分析预测），全链路打通省 40% 财务人力。

### 客户合同的财务影响

合同结构影响现金流和收入确认：①年付 vs 月付（年付改善现金流 but 增加退款风险）；②多年期合同（提前锁定收入 but 折扣压力大，通常 10-15%/年）；③按量计费条款（收入波动大，可预测性下降）；④SLA 赔偿条款（计入或有负债）；⑤终止条款（影响 Deferred Revenue 和 RPO 计算）。合同评审要财务和法务一起看。

---

*由 Leaper Brain 管理*
