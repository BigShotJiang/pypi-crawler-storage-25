# MEMORY — CCO B2B/SaaS知识库

> 由 Leaper Brain 在对话过程中自动更新。B2B/SaaS 行业 CCO 专属知识。

### B2B 白皮书（Whitepaper）创作方法论

白皮书是 B2B 内容营销的核心武器，MOFU 阶段最强 Lead Magnet。结构模板：① 封面（标题 + 摘要 + 公司 Logo）；② 行业背景与趋势（为什么现在很重要，2-3 页）；③ 核心挑战分析（3-5 个痛点，每个 1 页，配数据和引用）；④ 解决路径与最佳实践（方法论框架，不直接推产品）；⑤ 案例佐证（1-2 个客户故事，量化结果）；⑥ 行动建议 + 软性产品植入（最后 1 页）；⑦ 关于我们（半页）。篇幅：10-25 页。选题原则：解决 ICP 决策者的认知问题，不是推销。好标题示例："2025年制造业数字化转型的5大陷阱与破局之道"。一篇优质白皮书的生命周期 6-12 个月。

### 客户案例（Case Study）写作框架

客户案例是 BOFU 阶段最强转化内容。黄金结构 SCSR：**Situation**（客户背景：行业、规模、业务场景）→ **Challenge**（具体痛点：量化问题，如"每月人工处理 3000 张发票，错误率 15%"）→ **Solution**（如何使用产品解决，聚焦 2-3 个关键功能）→ **Result**（量化成果："处理时间降低 85%，错误率降至 0.5%，年节省人力成本 200 万"）。加分项：① 客户决策者原话（Quote）；② Before/After 对比图；③ 实施时间线；④ 未来计划。产出形式：长版 PDF（gated，3-5 页）+ 短版网页（ungated，1 页）+ Sales One-pager（给销售用）+ 社交摘要（LinkedIn/公众号）。每个垂直行业至少 2-3 个案例。

### Webinar 内容策划

Webinar 是 B2B 内容的瑞士军刀——获客、教育、转化三合一。类型分类：① **Thought Leadership**——邀请行业专家/分析师对谈，吸引高管受众，TOFU；② **Product Deep Dive**——产品功能演示 + 使用技巧，MOFU/BOFU；③ **Customer Story**——请客户现身说法分享成果，最强转化力，BOFU；④ **Workshop/Hands-on**——实操培训，适合技术受众。内容设计：30 分钟主题内容 + 15 分钟 Q&A。开场不要自我介绍超过 2 分钟——观众来听干货不是听你公司介绍。每次 Webinar 结尾设清晰 CTA（申请 Demo/下载报告/加入社区）。录播内容剪辑后作为 Evergreen Content 持续获客。

### 技术博客内容策略

技术博客是建立专家形象和 SEO 获客的长期资产。内容类型：① **How-to Guide**——解决具体技术问题，SEO 关键词丰富，长尾流量（如"如何用 Python 实现 XX"）；② **Architecture/Design**——系统架构解析、设计决策分享，吸引技术决策者；③ **Benchmark/Comparison**——性能对比、工具对比，高搜索量和转化率；④ **Engineering Culture**——团队实践、工作方式分享，employer branding + 技术社区口碑；⑤ **Product Changelog**——新功能发布、改进记录，SEO + 现有客户 engagement。发布节奏：每周 1-2 篇。写作标准：标题有关键词、有代码示例或截图、可操作性强。参考标杆：Stripe Blog、Datadog Blog、Cloudflare Blog。

### 思想领导力（Thought Leadership）内容

Thought Leadership 是 B2B 品牌的最高段位内容。目标不是卖产品，而是让客户认为"这个公司最懂我的行业"。形式：① CEO/CTO 署名文章（行业趋势预判、战略观点）；② 行业研究报告（数据驱动的原创洞察）；③ 媒体专栏/受访（Forbes/TechCrunch/36氪 专栏）；④ 大会演讲（Keynote/Panel）；⑤ Podcast 出镜/自制 Podcast。内容原则：要有独特观点和数据支撑，不能是行业共识的重复。"2025 年 AI 会改变一切"不是 Thought Leadership，"AI 在 B2B 定价中的 3 个反直觉应用"才是。衡量指标：媒体转载量、社交互动（LinkedIn 尤其重要）、Inbound 质量提升。

### 客户成功故事（Customer Story）挖掘

客户成功故事是最稀缺也最有价值的内容资产。挖掘流程：① **识别候选人**——NPS > 8、续约/扩展的客户、CSM 推荐的"爱用户"；② **获取许可**——通过 CSM 或 Account Manager 引荐，说明曝光价值（"帮你在行业峰会上展示"）；③ **访谈**——30-45 分钟结构化访谈（用 SCSR 框架引导），提前发问题清单，录音/录像（许可后）；④ **创作**——初稿 → 客户审核 → 法务审核（双方）→ 发布；⑤ **复用**——案例 PDF + 网页 + 视频 + 社交摘要 + 销售 Deck 嵌入 + 行业活动引用。常见障碍：客户法务不允许。对策：匿名案例（"某 Top 5 银行"）+ 重点展示数据结果而非客户名字。

### 行业分析报告制作

自制行业报告是最强的 MOFU 内容 + Thought Leadership 载体。制作流程：① **选题调研**——客户关心的行业趋势/痛点，用 Sales Team 和 CSM 反馈确定；② **数据收集**——自有产品数据（脱敏后的使用趋势）+ 第三方调研（问卷 200+ 企业）+ 公开数据（Gartner/IDC/Statista）；③ **分析与写作**——找到 2-3 个"非共识"洞察，这是报告的价值核心；④ **设计**——专业排版，配图表，16-30 页；⑤ **联合发布**——和行业协会/咨询公司/媒体联合出品，扩大分发 + 增加权威性；⑥ **推广**——Landing Page gating + LinkedIn Ads + 邮件推送 + PR + 峰会发布。一份优质行业报告能获取 500-2000 个 MQL。

### 销售赋能内容（Sales Enablement Content）

销售赋能内容直接影响 Win Rate。必备清单：① **Sales Deck**——15-20 页标准演示，按 Situation→Problem→Solution→Proof→Call to Action 结构；② **Battle Cards**——每个主要竞品一张，1 页，包含：我们赢的场景、他们赢的场景、关键 Objection Handling、客户转化案例、定价对比。每季度更新；③ **ROI Calculator**——让客户输入自己的数据，自动算出使用产品的预期回报（Excel/在线工具）；④ **One-pager / Solution Brief**——按行业/用例的一页概览，Quick Leave Behind；⑤ **FAQ / Objection Handling Guide**——Top 20 客户常见质疑和标准回答；⑥ **Demo Script**——标准化 Demo 流程和话术。销售赋能内容的反馈闭环：每月收集 AE 反馈，迭代更新。

### 内容复用与分发矩阵

一篇内容多次复用，最大化 ROI。复用链条示例（以白皮书为起点）：白皮书 → 3-5 篇博客文章（拆分章节深入展开）→ 1 场 Webinar（基于白皮书核心观点）→ 10 条 LinkedIn 帖子（每个核心数据/观点一条）→ 1 个 Infographic（数据可视化）→ 1 个 Sales One-pager（核心发现摘要）→ 1 封 Email Newsletter → Webinar 录播剪辑成 3-5 个短视频。分发渠道矩阵：Owned（官网/博客/邮件/产品内）、Earned（媒体转载/客户分享/社区讨论）、Paid（LinkedIn Ads/Google Ads/Sponsored Content）。每篇核心内容至少在 5 个渠道分发。

### 内容日历（Content Calendar）管理

B2B 内容日历是内容运营的核心工具。结构：① 时间维度——按月/周规划，标注发布日期、渠道、负责人；② 话题支柱——3-5 个 Pillar Topics 轮转覆盖；③ 漏斗阶段——标注每篇内容属于 TOFU/MOFU/BOFU，保持 40/35/25 比例；④ 内容形式——博客/白皮书/案例/Webinar/视频/社交等多形式搭配；⑤ 关联活动——内容和产品发布、行业活动、促销活动对齐。节奏建议：每月 4 篇博客 + 1 个 Webinar + 持续社交 + 每季度 1 篇大件内容（白皮书/报告/案例集）。工具：Notion、Asana、Monday.com、CoSchedule。每月初 Review 上月内容表现，调整下月计划。

### 内容效果衡量指标

B2B 内容 KPI 分三层：**Engagement Metrics**——页面浏览量、平均阅读时间、跳出率、社交互动（LinkedIn Impressions/Engagement Rate）；**Lead Metrics**——下载量、表单提交、Webinar 注册/出席、MQL 贡献数量；**Revenue Metrics**——Content-influenced Pipeline（内容触达过的 Opportunity 价值）、Content-sourced Revenue（由内容直接产生的线索最终成交金额）、CAC by Content Channel。内容 ROI 计算：Content Revenue / Content Cost（含人力+工具+分发）。基准：好的 B2B 内容团队 1:5 ROI（投入 1 元产出 5 元 Pipeline）。Attribution 挑战：用 Multi-touch Attribution，不要只看 Last Touch。

### SEO 内容策略

B2B SEO 内容是获客成本最低的长期渠道。策略：① **关键词研究**——用 Ahrefs/SEMrush 找高意图关键词（"XX软件""XX对比""XX替代方案""如何XX"），按搜索量和竞争度排序；② **Pillar-Cluster 模型**——每个核心话题写一个 3000-5000 字的 Pillar Page，围绕它写 10-20 篇 1500-2000 字的 Cluster 文章，内链互联；③ **内容更新**——每 6 个月 review 并更新老文章（Google 偏爱新鲜内容），更新日期标注；④ **竞品 SEO 分析**——分析竞品的 Top Pages 和关键词策略，找 Content Gap；⑤ **Programmatic SEO**——利用产品数据自动生成页面（集成目录、模板库、对比页）。B2B SEO 见效周期 6-12 个月，但一旦建立优势，获客成本趋近于零。

### 客户社区内容运营

Customer Community 是内容 + 客户成功的交叉点。平台选择：Discourse（技术社区标杆）、Slack/Discord（即时互动）、微信群（中国市场）、Circle（SaaS 社区专用）。内容运营策略：① 每周发起讨论话题（Best Practice/Tips & Tricks/行业趋势）；② 鼓励客户分享使用经验（UGC，User Generated Content），突出贡献者给 Badge/特权；③ 产品团队定期参与回答问题（AMA/Office Hours）；④ 社区内容精选整理成博客/FAQ（内容复用）。社区价值：降低 Support 工单量（Peer-to-Peer 解答）、增强客户粘性、产品反馈金矿、口碑传播。衡量：MAU、帖子数、回复率、Support Ticket Deflection Rate。

### 视频内容策略

B2B 视频内容类型：① **产品 Demo 视频**（2-5 分钟，按功能/场景分集，放官网和 YouTube）；② **客户故事视频**（3-5 分钟，最有感染力的 BOFU 内容）；③ **Webinar 录播剪辑**（从 1 小时 Webinar 剪出 3-5 个 3-5 分钟精华片段）；④ **创始人/专家短视频**（1-3 分钟，LinkedIn/YouTube Shorts，Thought Leadership）；⑤ **Tutorial/How-to**（5-15 分钟，产品教程，降低 Support 负担）。制作原则：前 5 秒抓注意力、配字幕（很多人静音看）、结尾有 CTA。分发：YouTube（SEO）+ LinkedIn（B2B 受众）+ 官网嵌入 + 邮件签名。衡量：播放量、完播率、CTA 点击率。

### 品牌声音（Brand Voice）指南

B2B Brand Voice 定义了所有内容的语调和个性。框架：① **Voice Attributes**——定义 3-5 个形容词（如"专业但不枯燥、权威但不高傲、友好但不随意"）；② **Tone Spectrum**——不同场景的语调调整（Marketing = 稍轻松、Support = 同理心、Legal = 正式、Social = 对话感）；③ **Do's & Don'ts**——用什么词（"解决方案"vs"产品"、"Partner"vs"供应商"）、不用什么词（避免内部术语、避免过度承诺）；④ **Writing Guidelines**——句子简短（< 25 词）、用主动语态、具体而非抽象、数据优先。Brand Voice Guide 是内容团队的圣经，新成员入职必读。每年 review 一次，保持品牌进化的一致性。

### AI 辅助内容创作

AI 在 B2B 内容创作中的最佳实践：① **Research & Outline**——用 AI 快速调研行业数据、生成内容大纲和初稿框架，效率提升 50%；② **First Draft**——AI 生成初稿，人工编辑优化（AI 出 80%，人工打磨 20% 的 tone/depth/accuracy）；③ **SEO Optimization**——AI 辅助关键词分析、Meta Description 生成、内链建议；④ **Content Repurposing**——AI 把长内容自动拆分为社交帖子/邮件摘要/视频脚本；⑤ **Translation/Localization**——AI 翻译 + Native Speaker Review。注意：AI 生成的 B2B 内容必须经过 Subject Matter Expert（SME）审核——事实准确性和行业深度是 AI 最容易出错的地方。Google 不惩罚 AI 内容，但惩罚低质量内容。

### 内容团队搭建

B2B SaaS 内容团队配置（按公司阶段）：**$1-5M ARR**——1 个 Content Lead（全栈写手，管外部 freelancer）；**$5-15M ARR**——Content Lead + 1 Writer + 1 Designer + Freelancer Pool；**$15-50M ARR**——Content Director + 2-3 Writers（按行业/话题分工）+ 1 Video + 1 Designer + Content Ops；**$50M+**——Editor-in-Chief + 编辑团队 + 行业专家顾问。外包 vs 自建：行业深度内容必须自建或用行业专家 Freelancer（通用写手写不出 B2B 深度），设计和视频制作可外包。内容团队的 OKR 示例：O = 通过内容驱动 30% 的 Pipeline；KR1 = 每月产出 8 篇博客 + 1 个 Webinar + 1 篇大件内容；KR2 = Content-sourced MQL 每月 100 个；KR3 = Organic Traffic 增长 20% QoQ。

---

*由 Leaper Brain 管理*
