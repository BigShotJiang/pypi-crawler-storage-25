MarTech 深度知识
**slug**: adtech-cto-martech
**category**: industry-deep-dive

### MarTech（营销科技）架构详解

**核心系统栈：**
```
数据采集(SDK/API) → CDP(统一画像) → MA(自动化引擎) → 触达(短信/邮件/Push/企微)
                         ↕                    ↕
                   Analytics(分析)      Content(内容管理)
```

**技术选型建议：**
- CDP：Segment 开源版/自研（数据层）+ 标签引擎（计算层）
- MA 引擎：事件驱动工作流（类似 Temporal/Airflow）
- 实时计算：Flink + Redis（实时标签）
- 数据库：PostgreSQL（主数据）+ ClickHouse（分析）+ Redis（实时状态）
- 消息触达：多通道适配层（统一 API → 短信/邮件/Push/企微/Webhook）

**关键架构决策：**
1. **ID 打通**：手机号/设备ID/Cookie/UnionID 多维 ID-Mapping
2. **实时 vs 批量**：T+0 实时标签（高成本高价值）vs T+1 批量计算（低成本覆盖广）
3. **多租户**：每个客户数据完全隔离（SaaS 模式刚需）
4. **工作流引擎**：低代码可视化编排 vs 代码定义——前者易用后者灵活

**中国市场特殊：**
- MA 触达必须走企微+小程序，邮件在中国几乎无效
- CDP 要对接微信生态（UnionID/OpenID 体系复杂）
- 个保法要求用户授权链路完整，"静默采集"时代结束

**常见坑：**
- ID-Mapping 准确率不够 → 同一用户被识别为多人，画像碎片化
- MA 工作流死循环（触发条件设置不当）
- 数据延迟导致"实时营销"其实延迟 30 分钟