SEM/SEO 深度知识
**slug**: adtech-cto-sem-seo
**category**: industry-deep-dive

### 搜索营销技术架构

**SEM 自动化系统：**
- 关键词管理：百万级关键词 → 自动出价 + 否定词管理
- 着陆页优化：动态着陆页（根据搜索词/地域/设备变化）
- 质量分优化：广告文案与着陆页相关性、CTR 历史

**SEO 技术栈：**
- 爬虫系统：监控自己和竞品排名变化
- 内容引擎：AI 生成 SEO 友好内容 + 内链自动构建
- 技术 SEO：Core Web Vitals 优化、结构化数据、国际化 hreflang