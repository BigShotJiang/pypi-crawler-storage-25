Creative Tech 深度知识
**slug**: adtech-cto-creative-tech
**category**: industry-deep-dive

### Creative Tech / AIGC 素材架构

**核心能力：**
- DCO（Dynamic Creative Optimization）：根据用户画像实时组装素材
- AIGC 生成：文案/图片/视频自动生成
- A/B 测试：多版本素材自动分流 + 置信度判断 + 自动胜出

**技术栈：**
- 文案生成：LLM（DeepSeek/GPT-4）+ 行业 fine-tune
- 图片生成：Stable Diffusion / Midjourney API + 品牌元素约束
- 视频生成：模板引擎 + AI 配音 + 自动剪辑
- 审核：AI 预审（违规/竞品/敏感词）+ 人工终审

**ROI：**
- AIGC 素材产出效率：10x（100 条/天 vs 10 条/天）
- 人力节省：设计团队从 20 人 → 5 人 + AI
- 创意疲劳周期：从 7 天延长到 3 天（更多变体）