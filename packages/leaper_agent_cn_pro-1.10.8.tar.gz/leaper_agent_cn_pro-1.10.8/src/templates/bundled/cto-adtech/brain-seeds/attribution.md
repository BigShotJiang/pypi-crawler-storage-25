Attribution 深度知识
**slug**: adtech-cto-attribution
**category**: industry-deep-dive

### 归因系统架构详解

**归因模型演进：**
| 模型 | 准确度 | 复杂度 | 适用场景 |
|------|--------|--------|---------|
| Last Click | 低 | 低 | 效果广告初期 |
| Multi-Touch (MTA) | 中 | 中 | 多触点精细归因 |
| MMM (Media Mix Model) | 中-高 | 高 | 宏观预算分配 |
| Incrementality | 高 | 高 | 因果推断/真实增量 |

**iOS ATT 后的归因方案矩阵：**
- SKAN 4.0：Apple 官方，粗粒度但可靠
- 概率性归因：设备指纹+IP+时间窗，准确率 60-70%
- MMM：月度/周度粒度，看趋势不看个体
- 自归因网络 (SRN)：Meta/Google 自己报数据

**技术要点：**
- 归因窗口选择：信息流 1 天/搜索 7 天/品牌 30 天
- 反作弊与归因交叉：先过滤作弊再归因
- 跨设备归因：同一用户手机+电脑行为关联