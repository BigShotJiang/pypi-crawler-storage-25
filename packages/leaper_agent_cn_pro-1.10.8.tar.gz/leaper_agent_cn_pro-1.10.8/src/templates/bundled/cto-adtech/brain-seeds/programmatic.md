Programmatic 深度知识
**slug**: adtech-cto-programmatic
**category**: industry-deep-dive

### Programmatic（程序化广告）架构详解

**核心系统栈：**
```
Ad Request → Bidder(竞价引擎) → Ad Server(广告投放) → Tracker(追踪归因)
                ↕                       ↕
          DMP/CDP(数据)          Creative Server(素材)
```

**技术选型建议：**
- 竞价引擎：C++/Rust（极限性能）或 Go（开发效率）
- 特征存储：Redis Cluster（热特征）+ RocksDB（冷特征）
- 实时计算：Flink（状态计算）+ Kafka（消息队列）
- 模型推理：TensorRT/ONNX Runtime（GPU）或 自研轻量引擎（CPU）
- 日志收集：Kafka → ClickHouse（OLAP分析）

**关键架构决策：**
1. **多层缓存**：L1 本地缓存（LRU）→ L2 Redis → L3 数据库
2. **预算控制**：Pacing 算法（匀速消耗 vs 加速消耗）需要分布式计数器
3. **流量分层**：高价值流量走重模型，低价值走轻规则
4. **A/B 实验**：流量桶分配 + 指标自动化检测 + 自动止损

**中国市场特殊：**
- 开放 RTB 只占 20%，巨量/腾讯/快手 是闭环不开放竞价
- 真正需要自建竞价引擎的场景：自有流量变现、独立 DSP、出海
- 国内更多是"API 对接 + 智能出价"模式，不是经典 RTB

**常见坑：**
- Budget Pacing 不准 → 要么超投要么跑不出去
- 频次控制跨媒体不生效（各平台数据不互通）
- 模型特征穿越（用了未来数据训练）