"""Leaper Agent CN - 面向中国大模型生态的 AI Agent 框架"""

from src.agent.loop import AgentLoop
from src.config import LeaperConfig
from src.templates.deployer import TemplateDeployer

# 版本号统一：与 pyproject.toml / constants.py 保持一致
try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("leaper-agent-cn")
except Exception:
    __version__ = "1.8.1"

__all__ = ["AgentLoop", "LeaperConfig", "TemplateDeployer", "__version__"]
