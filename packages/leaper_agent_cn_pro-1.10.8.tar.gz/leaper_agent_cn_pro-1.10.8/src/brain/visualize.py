"""
记忆可视化导出

P3-3: 生成自包含的 HTML 文件，用 vis.js 渲染 Entity Graph
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .engine import LeaperBrain


async def export_knowledge_graph_html(brain: "LeaperBrain", output_path: str) -> str:
    """生成一个自包含的 HTML 文件，可视化 Entity Graph。

    节点 = 实体，边 = 关系，颜色按实体类型区分。
    点击节点显示关联的 entries。
    返回输出文件路径。
    """
    db = brain.db

    # 读取实体
    async with db.execute("SELECT id, name, entity_type, mention_count FROM entities") as cur:
        entity_rows = await cur.fetchall()

    # 读取关系
    async with db.execute(
        "SELECT source_entity_id, target_entity_id, relation_type, confidence FROM relations WHERE valid_to IS NULL"
    ) as cur:
        relation_rows = await cur.fetchall()

    # 读取 entry-entity 关联
    async with db.execute(
        "SELECT ee.entity_id, e.content FROM entry_entities ee "
        "JOIN entries e ON e.id = ee.entry_id WHERE e.status = 'active'"
    ) as cur:
        link_rows = await cur.fetchall()

    # 构建数据
    type_colors = {
        "person": "#e74c3c",
        "organization": "#3498db",
        "technology": "#2ecc71",
        "product": "#f39c12",
        "location": "#9b59b6",
        "concept": "#1abc9c",
    }

    nodes = []
    for r in entity_rows:
        row = dict(r)
        etype = row.get("entity_type", "concept")
        color = type_colors.get(etype, "#95a5a6")
        size = min(10 + (row.get("mention_count", 1) or 1) * 3, 40)
        nodes.append({
            "id": row["id"],
            "label": row["name"],
            "color": color,
            "size": size,
            "title": f"{row['name']} ({etype})",
            "group": etype,
        })

    edges = []
    for r in relation_rows:
        row = dict(r)
        edges.append({
            "from": row["source_entity_id"],
            "to": row["target_entity_id"],
            "label": row["relation_type"],
            "arrows": "to",
        })

    # entity_id → entries content
    entity_entries: dict[str, list[str]] = {}
    for r in link_rows:
        row = dict(r)
        eid = row["entity_id"]
        content = row["content"][:200] if row["content"] else ""
        if eid not in entity_entries:
            entity_entries[eid] = []
        if len(entity_entries[eid]) < 5:
            entity_entries[eid].append(content)

    html = _HTML_TEMPLATE.replace("__NODES__", json.dumps(nodes, ensure_ascii=False))
    html = html.replace("__EDGES__", json.dumps(edges, ensure_ascii=False))
    html = html.replace("__ENTITY_ENTRIES__", json.dumps(entity_entries, ensure_ascii=False))

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return output_path


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<title>DeepBrain Knowledge Graph</title>
<script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
<style>
  body { margin: 0; font-family: sans-serif; background: #1a1a2e; color: #eee; }
  #graph { width: 100%; height: 80vh; border-bottom: 1px solid #333; }
  #info { padding: 16px; max-height: 20vh; overflow-y: auto; }
  #info h3 { margin: 0 0 8px; }
  #info ul { margin: 0; padding-left: 20px; }
</style>
</head>
<body>
<div id="graph"></div>
<div id="info"><h3>点击节点查看关联记忆</h3></div>
<script>
var nodes = new vis.DataSet(__NODES__);
var edges = new vis.DataSet(__EDGES__);
var entityEntries = __ENTITY_ENTRIES__;
var container = document.getElementById("graph");
var data = { nodes: nodes, edges: edges };
var options = {
  physics: { solver: "forceAtlas2Based", forceAtlas2Based: { gravitationalConstant: -50 } },
  interaction: { hover: true },
  edges: { font: { size: 10, color: "#aaa" }, color: { color: "#555" } },
};
var network = new vis.Network(container, data, options);
network.on("click", function(params) {
  var info = document.getElementById("info");
  if (params.nodes.length > 0) {
    var nodeId = params.nodes[0];
    var node = nodes.get(nodeId);
    var entries = entityEntries[nodeId] || [];
    var html = "<h3>" + node.label + "</h3>";
    if (entries.length) {
      html += "<ul>" + entries.map(function(e) { return "<li>" + e + "</li>"; }).join("") + "</ul>";
    } else {
      html += "<p>无关联记忆</p>";
    }
    info.innerHTML = html;
  }
});
</script>
</body>
</html>"""
