"""
MEMORY.md 自动策展

P2-3: 从高置信、高频条目中生成人类可读的 MEMORY.md
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .engine import LeaperBrain


async def generate_memory_md(brain: "LeaperBrain", workspace_dir: str) -> str:
    """从 entries 中筛选高质量条目，生成 MEMORY.md。

    筛选条件：confidence >= 0.7 且 access_count >= 2
    按 category 分组输出。
    返回生成的文件路径。
    """
    db = brain.db
    async with db.execute(
        "SELECT content, category, confidence, access_count FROM entries "
        "WHERE agent_id = ? AND status = 'active' AND confidence >= 0.7 AND access_count >= 2 "
        "ORDER BY confidence DESC, access_count DESC",
        (brain.agent_id,),
    ) as cur:
        rows = await cur.fetchall()

    # 按 category 分组
    groups: dict[str, list[str]] = {}
    for r in rows:
        row = dict(r)
        cat = row["category"] or "general"
        # 映射为中文标题
        cat_name = _CATEGORY_NAMES.get(cat, cat.capitalize())
        if cat_name not in groups:
            groups[cat_name] = []
        content = row["content"].replace("\n", " ").strip()
        if len(content) > 200:
            content = content[:197] + "..."
        groups[cat_name].append(content)

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines = [
        "# MEMORY.md — 自动策展的长期记忆\n",
        f"> 上次更新: {now}\n",
    ]

    if not groups:
        lines.append("\n_暂无达标条目（需 confidence ≥ 0.7 且 access_count ≥ 2）_\n")
    else:
        for cat_name, items in groups.items():
            lines.append(f"\n## {cat_name}\n")
            for item in items:
                lines.append(f"- {item}\n")

    output_path = os.path.join(workspace_dir, "MEMORY.md")
    with open(output_path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    return output_path


_CATEGORY_NAMES = {
    "fact": "事实",
    "preference": "偏好",
    "skill": "技能",
    "event": "事件",
    "tech": "技术",
    "product": "产品",
    "business": "商业",
    "strategy": "战略",
    "people": "团队",
    "general": "通用",
}
