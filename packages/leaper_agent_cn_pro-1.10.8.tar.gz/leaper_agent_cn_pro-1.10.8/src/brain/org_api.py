"""远端组织知识 API 客户端 — Phase 3"""
import json
import urllib.request
import urllib.error
import urllib.parse
import os
from typing import Optional
from datetime import datetime, timezone


class OrgAPIClient:
    """组织知识 API 客户端

    对接远端服务：
    - GET  /api/org/knowledge       — 查询
    - POST /api/org/knowledge       — 创建
    - PUT  /api/org/knowledge/{id}  — 更新
    - DELETE /api/org/knowledge/{id} — 删除
    - GET  /api/org/knowledge/sync  — 增量同步
    """

    def __init__(self, endpoint: str = "", api_key: str = ""):
        self.endpoint = endpoint or os.environ.get("LEAPER_ORG_API", "")
        self.api_key = api_key or os.environ.get("LEAPER_ORG_API_KEY", "")
        self._timeout = 10

    @property
    def is_configured(self) -> bool:
        return bool(self.endpoint and self.api_key)

    def _request(self, method: str, path: str, body: dict = None) -> dict:
        """发起 HTTP 请求"""
        url = f"{self.endpoint.rstrip('/')}{path}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        data = json.dumps(body).encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace") if e.fp else ""
            return {"error": True, "status": e.code, "message": error_body}
        except Exception as e:
            return {"error": True, "message": str(e)}

    def query(self, org_id: str, query: str = "", namespace: str = "", limit: int = 10) -> list[dict]:
        """查询组织知识"""
        params = f"?org_id={org_id}&limit={limit}"
        if query:
            params += f"&q={urllib.parse.quote(query)}"
        if namespace:
            params += f"&namespace={urllib.parse.quote(namespace)}"
        result = self._request("GET", f"/api/org/knowledge{params}")
        if result.get("error"):
            return []
        return result.get("data", result.get("entries", []))

    def create(self, org_id: str, content: str, namespace: str = "org/shared",
               category: str = "", metadata: dict = None) -> dict:
        """创建组织知识条目"""
        body = {
            "org_id": org_id,
            "content": content,
            "namespace": namespace,
            "category": category,
            "metadata": metadata or {},
        }
        return self._request("POST", "/api/org/knowledge", body)

    def update(self, entry_id: str, content: str = None, namespace: str = None,
               category: str = None, status: str = None) -> dict:
        """更新组织知识条目"""
        body = {"id": entry_id}
        if content is not None: body["content"] = content
        if namespace is not None: body["namespace"] = namespace
        if category is not None: body["category"] = category
        if status is not None: body["status"] = status
        return self._request("PUT", f"/api/org/knowledge/{entry_id}", body)

    def delete(self, entry_id: str) -> dict:
        """删除组织知识条目"""
        return self._request("DELETE", f"/api/org/knowledge/{entry_id}")

    def sync(self, org_id: str, since: str = "", etag: str = "") -> dict:
        """增量同步 — 获取自 since 以来的变更"""
        params = f"?org_id={org_id}"
        if since:
            params += f"&since={urllib.parse.quote(since)}"
        result = self._request("GET", f"/api/org/knowledge/sync{params}")
        if result.get("error"):
            return {"entries": [], "etag": etag}
        return {
            "entries": result.get("data", result.get("entries", [])),
            "etag": result.get("etag", ""),
            "server_time": result.get("server_time", ""),
        }
