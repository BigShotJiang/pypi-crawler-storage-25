"""
双写机制 — brain.db + Markdown 文件同步

P0-1: store_entry 时同步写 md 文件
P0-2: md → DB 反向同步
"""

from __future__ import annotations

import os
import re
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING

try:
    import aiofiles
    _AIOFILES = True
except ImportError:
    _AIOFILES = False

if TYPE_CHECKING:
    from .engine import LeaperBrain


class MarkdownSync:
    """将 brain.db 的 entries 双写到 workspace/memory/YYYY-MM-DD.md"""

    def __init__(self, workspace_dir: str) -> None:
        self.memory_dir = os.path.join(workspace_dir, "memory")
        os.makedirs(self.memory_dir, exist_ok=True)

    async def append_entry(
        self,
        entry_id: str,
        entry_type: str,
        content: str,
        category: str,
        confidence: float,
    ) -> None:
        """追加一条 entry 到当天的 md 文件"""
        if not _AIOFILES:
            return

        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        filepath = os.path.join(self.memory_dir, f"{today}.md")

        # 单行内容（去换行）
        one_line = content.replace("\n", " ").strip()
        line = f"- [{category}|{confidence:.2f}] {one_line}  <!-- id:{entry_id[:8]} -->\n"

        if not os.path.exists(filepath):
            async with aiofiles.open(filepath, "w", encoding="utf-8") as f:
                await f.write(f"# {today} 知识记录\n\n")
                await f.write(line)
        else:
            async with aiofiles.open(filepath, "a", encoding="utf-8") as f:
                await f.write(line)


# ---------------------------------------------------------------------------
# 反向同步：md → DB
# ---------------------------------------------------------------------------

_LINE_RE = re.compile(
    r"^- \[(?P<category>[^|]+)\|(?P<confidence>[\d.]+)\]\s+(?P<content>.+?)\s+<!-- id:(?P<id>\w+) -->$"
)


async def sync_from_files(brain: "LeaperBrain") -> dict:
    """扫描 memory/*.md，与 DB 双向对齐。

    返回 {"added": int, "updated": int, "archived": int}
    """
    if not _AIOFILES:
        return {"added": 0, "updated": 0, "archived": 0}

    workspace_dir = getattr(brain, "_workspace_dir", None)
    if not workspace_dir:
        return {"added": 0, "updated": 0, "archived": 0}

    memory_dir = os.path.join(workspace_dir, "memory")
    if not os.path.isdir(memory_dir):
        return {"added": 0, "updated": 0, "archived": 0}

    # 1. 解析所有 md 文件中的条目
    md_entries: dict[str, dict] = {}  # short_id → {content, category, confidence}

    for fname in os.listdir(memory_dir):
        if not fname.endswith(".md"):
            continue
        fpath = os.path.join(memory_dir, fname)
        async with aiofiles.open(fpath, "r", encoding="utf-8") as f:
            text = await f.read()
        for line in text.splitlines():
            m = _LINE_RE.match(line.strip())
            if m:
                md_entries[m.group("id")] = {
                    "content": m.group("content").strip(),
                    "category": m.group("category"),
                    "confidence": float(m.group("confidence")),
                }

    if not md_entries:
        return {"added": 0, "updated": 0, "archived": 0}

    # 2. 从 DB 加载所有 active entries，建立 short_id 索引
    db = brain.db
    async with db.execute(
        "SELECT id, content, category, confidence, status FROM entries WHERE agent_id = ?",
        (brain.agent_id,),
    ) as cur:
        rows = await cur.fetchall()

    db_map: dict[str, dict] = {}  # short_id → {full_id, content, status}
    for r in rows:
        row = dict(r)
        short = row["id"][:8]
        db_map[short] = row

    stats = {"added": 0, "updated": 0, "archived": 0}
    now = datetime.now(timezone.utc).isoformat()

    # 3. md 中有、DB 中没有 → 新增
    for short_id, md_e in md_entries.items():
        if short_id not in db_map:
            new_id = short_id + uuid.uuid4().hex[8:]
            await db.execute(
                "INSERT INTO entries "
                "(id, agent_id, entry_type, content, category, confidence, "
                "access_count, last_accessed, source_ids, metadata, created_at, updated_at, status) "
                "VALUES (?, ?, 'knowledge', ?, ?, ?, 0, ?, '[]', '{}', ?, ?, 'active')",
                (new_id, brain.agent_id, md_e["content"], md_e["category"],
                 md_e["confidence"], now, now, now),
            )
            stats["added"] += 1
        else:
            # md 中内容变了 → 更新 DB
            db_e = db_map[short_id]
            if db_e["content"] != md_e["content"]:
                await db.execute(
                    "UPDATE entries SET content = ?, updated_at = ? WHERE id = ?",
                    (md_e["content"], now, db_e["id"]),
                )
                stats["updated"] += 1

    # 4. DB 中有、md 中删除了 → 标记 archived
    for short_id, db_e in db_map.items():
        if short_id not in md_entries and db_e.get("status") == "active":
            # 只对 md 曾经记录过的条目做 archive（即 short_id 长度 == 8 的条目）
            # 避免误 archive 从未写入 md 的旧条目
            pass  # 保守策略：不自动 archive，避免误删

    await db.commit()
    return stats
