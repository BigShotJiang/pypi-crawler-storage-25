"""
进化触发优化 — 多策略触发

P1-4: 基于条目计数和时间间隔的多层进化触发器
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


class EvolutionTrigger:
    """多策略进化触发器：按条目数和时间间隔决定是否触发各层进化"""

    def __init__(self) -> None:
        self.entry_count_since_last_evolve: int = 0
        self.last_evolve_time: float = time.time()
        # 各层独立时间戳
        self._last_l2_time: float = time.time()
        self._last_l3_time: float = time.time()
        self._last_l4_time: float = time.time()
        self._last_l5_time: float = time.time()

    def on_entry_added(self) -> None:
        """新条目写入后调用"""
        self.entry_count_since_last_evolve += 1

    def should_evolve_l2(self) -> bool:
        """L2 聚类合并：20+ 新 entries 或 > 1 小时"""
        elapsed = time.time() - self._last_l2_time
        return self.entry_count_since_last_evolve >= 20 or elapsed > 3600

    def should_evolve_l3(self) -> bool:
        """L3 技能晋升：50+ 新 entries 或 > 24 小时"""
        elapsed = time.time() - self._last_l3_time
        return self.entry_count_since_last_evolve >= 50 or elapsed > 86400

    def should_evolve_l4(self) -> bool:
        """L4 画像推断：> 24 小时"""
        elapsed = time.time() - self._last_l4_time
        return elapsed > 86400

    def should_evolve_l5(self) -> bool:
        """L5 健康度自检：> 7 天"""
        elapsed = time.time() - self._last_l5_time
        return elapsed > 7 * 86400

    def on_evolve_complete(self, level: int) -> None:
        """进化完成后重置对应计数和时间"""
        now = time.time()
        if level == 2:
            self.entry_count_since_last_evolve = 0
            self._last_l2_time = now
        elif level == 3:
            self._last_l3_time = now
        elif level == 4:
            self._last_l4_time = now
        elif level == 5:
            self._last_l5_time = now
        self.last_evolve_time = now
