"""DeskContext - 四层知识架构的命名空间上下文"""
from dataclasses import dataclass


@dataclass
class DeskContext:
    org_id: str = ""
    office_id: str = ""
    role: str = ""
    industry: str = ""
    agent_id: str = ""

    @property
    def readable_namespaces(self) -> list[str]:
        ns = ["office/shared", "office/prefs"]
        if self.role:
            ns.append(f"desk/{self.role}")
            if self.industry:
                ns.append(f"desk/{self.role}/{self.industry}")
        if self.agent_id:
            ns.append(f"agent/{self.agent_id}")
        return ns

    @property
    def writable_namespaces(self) -> list[str]:
        ns = []
        if self.role:
            ns.append(f"desk/{self.role}")
            if self.industry:
                ns.append(f"desk/{self.role}/{self.industry}")
        if self.agent_id:
            ns.append(f"agent/{self.agent_id}")
        return ns
