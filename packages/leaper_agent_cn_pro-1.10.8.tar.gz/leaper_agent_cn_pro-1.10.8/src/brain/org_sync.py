"""L1 组织层知识同步 — 本地 cache.db + 远端 API"""
import aiosqlite
import os
import json
from datetime import datetime, timezone
from pathlib import Path

CACHE_SCHEMA = """
CREATE TABLE IF NOT EXISTS org_entries (
    id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    namespace TEXT NOT NULL DEFAULT 'org/shared',
    content TEXT NOT NULL,
    category TEXT DEFAULT '',
    confidence REAL DEFAULT 0.9,
    metadata TEXT DEFAULT '{}',
    status TEXT DEFAULT 'active',
    remote_updated_at TEXT,
    cached_at TEXT DEFAULT (datetime('now')),
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_org_ns ON org_entries(namespace);
CREATE INDEX IF NOT EXISTS idx_org_status ON org_entries(status);

CREATE TABLE IF NOT EXISTS sync_meta (
    org_id TEXT PRIMARY KEY,
    last_sync_at TEXT,
    sync_interval_ms INTEGER DEFAULT 3600000,
    etag TEXT
);
"""


class OrgSyncManager:
    def __init__(self, cache_dir: str = ""):
        if not cache_dir:
            cache_dir = str(Path.home() / ".leaper-cn" / "org")
        self.cache_dir = cache_dir
        self.cache_db_path = os.path.join(cache_dir, "cache.db")
        self._db = None
        self._api_endpoint = os.environ.get("LEAPER_ORG_API", "")
        self._api_key = os.environ.get("LEAPER_ORG_API_KEY", "")

    async def initialize(self):
        os.makedirs(self.cache_dir, exist_ok=True)
        self._db = await aiosqlite.connect(self.cache_db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.execute("PRAGMA busy_timeout=5000")
        await self._db.executescript(CACHE_SCHEMA)
        await self._db.commit()

    async def close(self):
        if self._db:
            await self._db.close()
            self._db = None

    async def recall(self, query: str, org_id: str = "", limit: int = 3) -> list[dict]:
        """从本地缓存召回组织知识"""
        if not self._db:
            return []
        # 关键词搜索
        tokens = [t.strip() for t in query.lower().split() if len(t.strip()) > 1]
        if not tokens:
            return []

        conditions = " OR ".join(["LOWER(content) LIKE ?" for _ in tokens])
        params = [f"%{t}%" for t in tokens]

        where = f"({conditions}) AND status = 'active'"
        if org_id:
            where = f"org_id = ? AND {where}"
            params = [org_id] + params

        sql = f"SELECT * FROM org_entries WHERE {where} ORDER BY cached_at DESC LIMIT ?"
        params.append(limit)

        async with self._db.execute(sql, params) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def store_org_entry(self, content: str, org_id: str, namespace: str = "org/shared",
                              category: str = "", entry_id: str = "") -> str:
        """存储组织知识到本地缓存"""
        if not self._db:
            raise RuntimeError("OrgSyncManager not initialized")
        import uuid
        eid = entry_id or str(uuid.uuid4())
        await self._db.execute(
            "INSERT OR REPLACE INTO org_entries (id, org_id, namespace, content, category, cached_at) VALUES (?,?,?,?,?,?)",
            (eid, org_id, namespace, content, category, datetime.now(timezone.utc).isoformat())
        )
        await self._db.commit()
        return eid

    async def sync_if_needed(self, org_id: str) -> bool:
        """检查并执行增量同步（需要远端 API）"""
        if not self._api_endpoint:
            return False  # 没配 API，跳过
        # TODO: Phase 3 实现远端 API 同步
        return False

    async def import_file(self, filepath: str, org_id: str, namespace: str = "org/shared") -> int:
        """从本地文件导入组织知识"""
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {filepath}")

        content = path.read_text(encoding="utf-8")
        # 按段落拆分
        paragraphs = [p.strip() for p in content.split("\n\n") if p.strip() and len(p.strip()) > 20]
        count = 0
        for para in paragraphs:
            await self.store_org_entry(
                content=para,
                org_id=org_id,
                namespace=namespace,
                category=path.stem,
            )
            count += 1
        return count

    @property
    def is_available(self) -> bool:
        return self._db is not None
