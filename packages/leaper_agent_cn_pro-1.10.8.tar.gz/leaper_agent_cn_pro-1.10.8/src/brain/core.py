"""LeaperBrain 核心 — 记忆存储与检索（占位实现）"""


class LeaperBrain:
    """记忆大脑，提供 recall / extract_and_learn 接口"""

    def __init__(self, enabled: bool = True, db_path: str = ""):
        self.enabled = enabled
        self.db_path = db_path

    async def recall(self, query: str, user_id: str = "default", top_k: int = 5) -> list[str]:
        """检索相关记忆片段

        注意：占位实现，返回空列表。完整实现见 brain/engine.py 的 LeaperBrain，
        需要 aiosqlite 支持。此类仅用于无 DB 场景的 graceful fallback。
        """
        return []

    async def extract_and_learn(self, user_msg: str, reply: str, user_id: str = "default") -> None:
        """从对话中提取知识并学习（异步，不阻塞主流程）

        注意：占位实现，不执行任何操作。完整实现见 brain/engine.py 的 LeaperBrain。
        """
        pass
