"""
LeaperBrain - DeepBrain Memory Engine for Leaper Agent v2.0

Async SQLite-backed knowledge store with 4-Gate extraction and BM25+MMR recall.
"""

from __future__ import annotations

import json
import math
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any

import aiosqlite

try:
    import numpy as np
    _NUMPY_AVAILABLE = True
except ImportError:
    _NUMPY_AVAILABLE = False

from .desk_context import DeskContext

TZ_UTC = timezone.utc


# ---------------------------------------------------------------------------
# Tokenisation helpers
# ---------------------------------------------------------------------------

_EN_WORD_RE = re.compile(r"[a-zA-Z0-9]+")
_ZH_CHAR_RE = re.compile(r"[\u4e00-\u9fff]")
_STOPWORDS = frozenset(
    {"the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
     "have", "has", "had", "do", "does", "did", "will", "would", "shall",
     "should", "may", "might", "must", "can", "could", "of", "in", "to",
     "for", "with", "on", "at", "from", "by", "as", "it", "its", "this",
     "that", "and", "or", "but", "not", "no", "if", "so", "up", "out",
     "about", "into", "over", "after", "than", "也", "的", "了", "在",
     "是", "我", "有", "和", "就", "不", "人", "都", "一", "一个",
     "上", "这", "他", "她", "它", "们", "个", "中", "大", "为"}
)


def tokenize(text: str) -> list[str]:
    """Extract keywords: English words (lowered) + Chinese char bigrams."""
    tokens: list[str] = []
    # English words
    for m in _EN_WORD_RE.finditer(text):
        w = m.group().lower()
        if w not in _STOPWORDS and len(w) > 1:
            tokens.append(w)
    # Chinese bigrams
    chars = [c for c in text if _ZH_CHAR_RE.match(c)]
    for i in range(len(chars) - 1):
        bg = chars[i] + chars[i + 1]
        if bg not in _STOPWORDS:
            tokens.append(bg)
    # single Chinese chars that didn't form bigrams (for short text)
    if len(chars) == 1 and chars[0] not in _STOPWORDS:
        tokens.append(chars[0])
    return tokens


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


# ---------------------------------------------------------------------------
# Entity Extraction (lightweight, no external deps)
# ---------------------------------------------------------------------------

_ENTITY_PATTERNS = [
    # CamelCase or PascalCase (e.g., LangGraph, CrewAI, DeepBrain)
    re.compile(r"\b([A-Z][a-z]+(?:[A-Z][a-z]*)+)\b"),
    # ALL CAPS acronyms 2-6 chars (e.g., API, SDK, MRD)
    re.compile(r"\b([A-Z]{2,6})\b"),
    # Chinese proper nouns preceded by markers (rough heuristic)
    re.compile(r"(?:叫|是|用|即|如|：)([^\s，。、]{2,6})"),
    # @-mentions or quoted names
    re.compile(r"[「\"']([^「\"']{2,20})[」\"']"),
]


def extract_entities(text: str) -> set[str]:
    """Extract lightweight named entities from text for retrieval boosting."""
    entities: set[str] = set()
    for pat in _ENTITY_PATTERNS:
        for m in pat.finditer(text):
            ent = m.group(1) if pat.groups else m.group(0)
            # Filter out common English words that happen to be uppercase
            if ent.isupper() and len(ent) <= 1:
                continue
            entities.add(ent.lower())
    return entities


def _now_iso() -> str:
    return datetime.now(TZ_UTC).isoformat()


def _ngrams(tokens: list[str], n: int) -> set[str]:
    """Generate n-grams from an ordered token list."""
    if len(tokens) < n:
        return set()
    return {" ".join(tokens[i : i + n]) for i in range(len(tokens) - n + 1)}


def _cosine_sim(a: Any, b: Any) -> float:
    """Cosine similarity between two numpy float32 arrays."""
    norm_a = float(np.linalg.norm(a))
    norm_b = float(np.linalg.norm(b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))


def _fetch_embedding_sync(text: str, model: str, endpoint: str) -> list[float] | None:
    """Call Ollama embedding API synchronously. Returns None on any failure."""
    import urllib.request
    try:
        payload = json.dumps({"model": model, "input": text}).encode("utf-8")
        req = urllib.request.Request(
            endpoint, data=payload, method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
        vecs = data.get("embeddings", [])
        if vecs and isinstance(vecs[0], list) and vecs[0]:
            return vecs[0]
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# 4-Gate Knowledge Filters
# ---------------------------------------------------------------------------

def relevance_gate(content: str, context: str) -> float:
    """Score 0-1: how relevant content is to the conversation context."""
    c_tok = set(tokenize(content))
    x_tok = set(tokenize(context))
    if not c_tok:
        return 0.0
    overlap = len(c_tok & x_tok)
    # At least some overlap means relevant
    ratio = overlap / max(len(c_tok), 1)
    # Boost if content is substantial
    length_bonus = min(len(content) / 200, 0.3)
    return min(ratio + length_bonus, 1.0)


def novelty_gate(content: str, existing_entries: list[dict]) -> float:
    """Score 0-1: how novel this content is vs existing knowledge."""
    if not existing_entries:
        return 1.0
    c_tok = set(tokenize(content))
    max_sim = 0.0
    for entry in existing_entries:
        e_tok = set(tokenize(entry.get("content", "")))
        sim = _jaccard(c_tok, e_tok)
        if sim > max_sim:
            max_sim = sim
    return 1.0 - max_sim


def confidence_gate(content: str) -> float:
    """Score 0-1: heuristic confidence based on content quality signals."""
    score = 0.5
    # Longer, more detailed content = higher confidence
    if len(content) > 100:
        score += 0.15
    if len(content) > 300:
        score += 0.1
    # Contains numbers / data points
    if re.search(r"\d+", content):
        score += 0.1
    # Hedging language lowers confidence
    hedges = ["maybe", "perhaps", "might", "不确定", "可能", "也许", "似乎"]
    if any(h in content.lower() for h in hedges):
        score -= 0.15
    # Assertion keywords boost
    assertions = ["确认", "confirmed", "verified", "实测", "proven"]
    if any(a in content.lower() for a in assertions):
        score += 0.15
    return max(0.1, min(score, 1.0))


def consistency_gate(content: str, existing_entries: list[dict]) -> float:
    """Score 0-1: does content conflict with existing knowledge?
    1.0 = fully consistent, 0.0 = strong contradiction detected."""
    if not existing_entries:
        return 1.0
    c_tok = set(tokenize(content))
    # Simple heuristic: check for negation patterns against similar entries
    negation_words = {"not", "no", "never", "don't", "doesn't", "didn't",
                      "won't", "不", "没", "未", "非", "无", "别"}
    c_has_neg = bool(negation_words & set(content.lower().split()))
    for entry in existing_entries:
        e_tok = set(tokenize(entry.get("content", "")))
        sim = _jaccard(c_tok, e_tok)
        if sim < 0.3:
            continue
        # High similarity + different negation polarity = possible conflict
        e_has_neg = bool(negation_words & set(entry.get("content", "").lower().split()))
        if sim > 0.5 and c_has_neg != e_has_neg:
            return max(0.2, 1.0 - sim)
    return 1.0


# ---------------------------------------------------------------------------
# LeaperBrain
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS entries (
    id TEXT PRIMARY KEY,
    agent_id TEXT,
    entry_type TEXT,
    content TEXT,
    category TEXT,
    confidence REAL DEFAULT 0.8,
    access_count INTEGER DEFAULT 0,
    last_accessed TEXT,
    source_ids TEXT,
    metadata TEXT,
    created_at TEXT,
    updated_at TEXT,
    status TEXT DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    agent_id TEXT,
    session_id TEXT,
    role TEXT,
    content TEXT,
    tool_calls TEXT,
    tool_call_id TEXT,
    tool_name TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS profiles (
    id TEXT PRIMARY KEY,
    agent_id TEXT,
    dimension TEXT,
    key TEXT,
    value TEXT,
    confidence REAL DEFAULT 0.8,
    evidence_ids TEXT,
    updated_at TEXT,
    UNIQUE(agent_id, dimension, key)
);

CREATE TABLE IF NOT EXISTS meta (
    id TEXT PRIMARY KEY,
    agent_id TEXT,
    metric TEXT,
    value TEXT,
    computed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_entries_agent ON entries(agent_id);
CREATE INDEX IF NOT EXISTS idx_entries_type ON entries(entry_type);
CREATE INDEX IF NOT EXISTS idx_entries_status ON entries(status);
CREATE INDEX IF NOT EXISTS idx_entries_category ON entries(category);
CREATE INDEX IF NOT EXISTS idx_messages_agent ON messages(agent_id);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id);
CREATE INDEX IF NOT EXISTS idx_profiles_agent ON profiles(agent_id);
CREATE INDEX IF NOT EXISTS idx_profiles_dimension ON profiles(dimension);
CREATE INDEX IF NOT EXISTS idx_meta_agent ON meta(agent_id);

CREATE TABLE IF NOT EXISTS transitions (
    id TEXT PRIMARY KEY,
    agent_id TEXT,
    entry_id_old TEXT,
    entry_id_new TEXT,
    category TEXT,
    old_content TEXT,
    new_content TEXT,
    transition_type TEXT DEFAULT 'update',
    created_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_transitions_agent ON transitions(agent_id);
CREATE INDEX IF NOT EXISTS idx_transitions_category ON transitions(category);

CREATE TABLE IF NOT EXISTS embeddings (
    entry_id TEXT PRIMARY KEY,
    vector BLOB
);
"""

# Minimum gate thresholds for knowledge extraction
_GATE_THRESHOLDS = {
    "relevance": 0.15,
    "novelty": 0.25,
    "confidence": 0.3,
    "consistency": 0.3,
}


@dataclass
class RecallConfig:
    """搜索配置化参数（P3-2）"""
    vector_weight: float = 1.0
    text_weight: float = 1.0
    rrf_k: int = 60
    mmr_lambda: float = 0.8
    half_life_days: int = 30
    entity_boost: float = 0.3
    neighbor_expansion: bool = True


class LeaperBrain:
    """Async knowledge engine backed by SQLite via aiosqlite."""

    def __init__(
        self,
        db_path: str,
        agent_id: str,
        embedding_model: str = "nomic-embed-text",
        embedding_endpoint: str = "http://localhost:11434/api/embed",
        workspace_dir: str | None = None,
        embedding_providers: list | None = None,
    ) -> None:
        self.db_path = db_path
        self.agent_id = agent_id
        self.embedding_model = embedding_model
        self.embedding_endpoint = embedding_endpoint
        self._workspace_dir = workspace_dir
        self._db: aiosqlite.Connection | None = None
        self._entity_graph: Any | None = None
        self._entity_extractor: Any | None = None
        self._md_sync: Any | None = None
        # Embedding chain（P1-1）
        self._embedding_chain: Any | None = None
        if embedding_providers is not None:
            from .embedding_provider import EmbeddingChain
            self._embedding_chain = EmbeddingChain(embedding_providers)
        # 初始化 md 同步（P0-1）
        if workspace_dir:
            from .sync import MarkdownSync
            self._md_sync = MarkdownSync(workspace_dir)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def initialize(self) -> None:
        """Open DB and create tables + indexes."""
        self._db = await aiosqlite.connect(self.db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.execute("PRAGMA busy_timeout=5000")
        await self._db.executescript(_SCHEMA_SQL)
        await self._db.commit()
        # 迁移：为旧 messages 表添加 tool 相关字段
        await self._migrate_messages_table()
        # 迁移：为 entries 表添加 namespace 列
        await self._migrate_entries_table()
        # 迁移：创建 embeddings_v2 表
        await self._migrate_embeddings_v2()
        # Initialize Entity Graph (CN-exclusive)
        try:
            from ..memory.entity_graph import EntityGraph
            from ..memory.entity_extractor import EntityExtractor
            self._entity_graph = EntityGraph(self._db)
            await self._entity_graph.initialize()
            self._entity_extractor = EntityExtractor(llm_fn=None)
        except Exception:
            self._entity_graph = None
            self._entity_extractor = None
        # 默认 embedding chain（P1-1）
        if self._embedding_chain is None:
            try:
                import os
                from .embedding_provider import OllamaProvider, APIProvider, KeywordFallbackProvider, EmbeddingChain
                providers: list = [OllamaProvider(self.embedding_model, self.embedding_endpoint)]
                # DeepSeek Embedding API（云端语义搜索）
                ds_key = os.environ.get("DEEPSEEK_API_KEY", "sk-5411c0d36dd94839836a96076645d2db")
                if ds_key:
                    providers.append(APIProvider(
                        endpoint="https://api.deepseek.com/v1/embeddings",
                        api_key=ds_key,
                        model="text-embedding-3",
                    ))
                providers.append(KeywordFallbackProvider())
                self._embedding_chain = EmbeddingChain(providers)
            except Exception:
                pass
        # md → DB 反向同步（P0-2）
        if self._workspace_dir:
            try:
                from .sync import sync_from_files
                await sync_from_files(self)
            except Exception:
                pass

    async def _migrate_messages_table(self) -> None:
        """为旧数据库添加 tool_calls/tool_call_id/tool_name 字段（幂等）"""
        try:
            async with self._db.execute("PRAGMA table_info(messages)") as cur:
                columns = {row[1] for row in await cur.fetchall()}
            if "tool_calls" not in columns:
                await self._db.execute("ALTER TABLE messages ADD COLUMN tool_calls TEXT")
            if "tool_call_id" not in columns:
                await self._db.execute("ALTER TABLE messages ADD COLUMN tool_call_id TEXT")
            if "tool_name" not in columns:
                await self._db.execute("ALTER TABLE messages ADD COLUMN tool_name TEXT")
            await self._db.commit()
        except Exception:
            pass  # 已有字段或其他问题，忽略

    async def _migrate_entries_table(self) -> None:
        """给 entries 表添加 namespace 列（如果不存在）"""
        try:
            async with self._db.execute("PRAGMA table_info(entries)") as cur:
                cols = {row[1] for row in await cur.fetchall()}
            if "namespace" not in cols:
                await self._db.execute("ALTER TABLE entries ADD COLUMN namespace TEXT DEFAULT ''")
                await self._db.commit()
        except Exception:
            pass

    async def _migrate_embeddings_v2(self) -> None:
        """创建 embeddings_v2 表并迁移旧数据"""
        try:
            # 检查 embeddings_v2 是否已存在
            async with self._db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='embeddings_v2'"
            ) as cur:
                exists = await cur.fetchone()
            if exists:
                return
            # 创建 v2 表
            await self._db.execute("""
                CREATE TABLE IF NOT EXISTS embeddings_v2 (
                    entry_id TEXT PRIMARY KEY,
                    model TEXT DEFAULT 'unknown',
                    dim INTEGER DEFAULT 0,
                    vector BLOB,
                    created_at TEXT
                )
            """)
            # 迁移旧数据
            async with self._db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='embeddings'"
            ) as cur:
                old_exists = await cur.fetchone()
            if old_exists:
                now = _now_iso()
                await self._db.execute(
                    "INSERT OR IGNORE INTO embeddings_v2 (entry_id, model, dim, vector, created_at) "
                    "SELECT entry_id, 'unknown', 0, vector, ? FROM embeddings",
                    (now,),
                )
            await self._db.commit()
        except Exception:
            pass

    async def close(self) -> None:
        if self._db:
            await self._db.close()
            self._db = None

    # ------------------------------------------------------------------
    # Entity Graph public API
    # ------------------------------------------------------------------

    async def get_entity(self, name: str) -> dict | None:
        """Get entity by name. Returns None if graph not available."""
        if not self._entity_graph:
            return None
        return await self._entity_graph.get_entity(name)

    async def get_relations(self, entity_id: str) -> list[dict]:
        """Get relations for an entity."""
        if not self._entity_graph:
            return []
        return await self._entity_graph.get_relations(entity_id)

    async def get_entity_graph(self, query: str, hops: int = 2) -> list[str]:
        """Get entry IDs reachable from entities mentioned in query."""
        if not self._entity_graph or not self._entity_extractor:
            return []
        ext_result = await self._entity_extractor.extract(query)
        entity_names = [e.name for e in ext_result.entities]
        if not entity_names:
            return []
        return await self._entity_graph.traverse(entity_names, hops=hops)

    @property
    def db(self) -> aiosqlite.Connection:
        if self._db is None:
            raise RuntimeError("LeaperBrain not initialized. Call initialize() first.")
        return self._db

    # ------------------------------------------------------------------
    # Messages
    # ------------------------------------------------------------------

    async def store_message(self, session_id: str, role: str, content: str) -> str:
        msg_id = uuid.uuid4().hex
        now = _now_iso()
        await self.db.execute(
            "INSERT INTO messages (id, agent_id, session_id, role, content, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (msg_id, self.agent_id, session_id, role, content, now),
        )
        await self.db.commit()
        return msg_id

    async def get_messages(self, session_id: str, limit: int = 10) -> list[dict]:
        """Get recent messages for a session, newest first."""
        async with self.db.execute(
            "SELECT role, content, created_at FROM messages "
            "WHERE agent_id = ? AND session_id = ? "
            "ORDER BY created_at DESC LIMIT ?",
            (self.agent_id, session_id, limit),
        ) as cur:
            rows = await cur.fetchall()
        return [{"role": r[0], "content": r[1], "created_at": r[2]} for r in rows]

    # ------------------------------------------------------------------
    # Entries CRUD
    # ------------------------------------------------------------------

    async def store_entry(
        self,
        entry_type: str,
        content: str,
        category: str = "",
        confidence: float = 0.8,
        source_ids: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        namespace: str = "",
        desk_context: DeskContext | None = None,
    ) -> str:
        # desk_context: 自动填 namespace 和写权限检查
        if desk_context is not None:
            if not namespace and desk_context.agent_id:
                namespace = f"agent/{desk_context.agent_id}"
            if namespace and namespace not in desk_context.writable_namespaces:
                raise ValueError(f"Namespace '{namespace}' not in writable namespaces: {desk_context.writable_namespaces}")
        entry_id = uuid.uuid4().hex
        now = _now_iso()
        await self.db.execute(
            "INSERT INTO entries "
            "(id, agent_id, entry_type, content, category, confidence, "
            "access_count, last_accessed, source_ids, metadata, created_at, updated_at, status, namespace) "
            "VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, 'active', ?)",
            (
                entry_id,
                self.agent_id,
                entry_type,
                content,
                category,
                confidence,
                now,
                json.dumps(source_ids or [], ensure_ascii=False),
                json.dumps(metadata or {}, ensure_ascii=False),
                now,
                now,
                namespace,
            ),
        )
        await self.db.commit()
        await self._compute_and_store_embedding(entry_id, content)
        # 双写 md 文件（P0-1）
        if self._md_sync:
            try:
                await self._md_sync.append_entry(entry_id, entry_type, content, category, confidence)
            except Exception:
                pass
        return entry_id

    async def get_entries(
        self,
        agent_id: str | None = None,
        entry_type: str | None = None,
        status: str = "active",
        limit: int = 50,
    ) -> list[dict]:
        clauses = ["status = ?"]
        params: list[Any] = [status]
        aid = agent_id or self.agent_id
        clauses.append("agent_id = ?")
        params.append(aid)
        if entry_type:
            clauses.append("entry_type = ?")
            params.append(entry_type)
        params.append(limit)
        sql = (
            "SELECT * FROM entries WHERE "
            + " AND ".join(clauses)
            + " ORDER BY updated_at DESC LIMIT ?"
        )
        async with self.db.execute(sql, params) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def update_entry_status(self, entry_id: str, status: str) -> None:
        await self.db.execute(
            "UPDATE entries SET status = ?, updated_at = ? WHERE id = ?",
            (status, _now_iso(), entry_id),
        )
        await self.db.commit()

    async def update_entry(self, entry_id: str, **kwargs) -> None:
        """Update arbitrary fields on an entry (confidence, category, etc.)."""
        allowed = {"confidence", "category", "content", "status", "entry_type"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return
        updates["updated_at"] = _now_iso()
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [entry_id]
        await self.db.execute(f"UPDATE entries SET {set_clause} WHERE id = ?", values)
        await self.db.commit()

    # ------------------------------------------------------------------
    # Temporal Transitions
    # ------------------------------------------------------------------

    async def record_transition(
        self,
        old_entry: dict,
        new_entry: dict,
        transition_type: str = "update",
    ) -> str:
        """Record a knowledge transition (fact changed over time).

        Inspired by Zep's temporal knowledge graph — tracks what was true
        before and what replaced it, enabling temporal reasoning queries.
        """
        trans_id = uuid.uuid4().hex
        now = _now_iso()
        await self.db.execute(
            "INSERT INTO transitions "
            "(id, agent_id, entry_id_old, entry_id_new, category, "
            "old_content, new_content, transition_type, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                trans_id,
                self.agent_id,
                old_entry.get("id", ""),
                new_entry.get("id", ""),
                old_entry.get("category", new_entry.get("category", "")),
                old_entry.get("content", ""),
                new_entry.get("content", ""),
                transition_type,
                now,
            ),
        )
        await self.db.commit()
        return trans_id

    async def get_transitions(
        self, category: str | None = None, limit: int = 20
    ) -> list[dict]:
        """Retrieve recent transitions, optionally filtered by category."""
        clauses = ["agent_id = ?"]
        params: list[Any] = [self.agent_id]
        if category:
            clauses.append("category = ?")
            params.append(category)
        params.append(limit)
        sql = (
            "SELECT * FROM transitions WHERE "
            + " AND ".join(clauses)
            + " ORDER BY created_at DESC LIMIT ?"
        )
        async with self.db.execute(sql, params) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def _compute_and_store_embedding(self, entry_id: str, content: str) -> None:
        """Compute embedding via chain (or legacy Ollama) and persist. Silent on failure."""
        if not _NUMPY_AVAILABLE:
            return
        try:
            embed_result = None
            model_id = "unknown"
            dim = 0
            if self._embedding_chain:
                embed_result = await self._embedding_chain.embed(content)
                if embed_result is not None:
                    vec = embed_result.vector
                    model_id = embed_result.model
                    dim = embed_result.dim
                else:
                    vec = None
            else:
                import asyncio
                vec = await asyncio.get_running_loop().run_in_executor(
                    None, _fetch_embedding_sync, content, self.embedding_model, self.embedding_endpoint
                )
                if vec is not None:
                    dim = len(vec)
            if vec is None:
                return
            arr = np.array(vec, dtype=np.float32)
            now = _now_iso()
            # Write to legacy embeddings table for backward compat
            await self.db.execute(
                "INSERT OR REPLACE INTO embeddings (entry_id, vector) VALUES (?, ?)",
                (entry_id, arr.tobytes()),
            )
            # Write to embeddings_v2 with model/dim info
            try:
                await self.db.execute(
                    "INSERT OR REPLACE INTO embeddings_v2 (entry_id, model, dim, vector, created_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (entry_id, model_id, dim, arr.tobytes(), now),
                )
            except Exception:
                pass  # v2 table may not exist yet
            await self.db.commit()
        except Exception:
            pass

    async def increment_access(self, entry_id: str) -> None:
        now = _now_iso()
        await self.db.execute(
            "UPDATE entries SET access_count = access_count + 1, last_accessed = ?, updated_at = ? WHERE id = ?",
            (now, now, entry_id),
        )
        await self.db.commit()

    async def share_entry(self, entry_id: str, target_agent_id: str) -> str:
        """复制 entry 到另一个 agent（P2-2 跨 Agent 记忆共享）"""
        async with self.db.execute(
            "SELECT * FROM entries WHERE id = ?", (entry_id,)
        ) as cur:
            row = await cur.fetchone()
        if not row:
            raise ValueError(f"Entry {entry_id} not found")
        entry = dict(row)
        new_id = uuid.uuid4().hex
        now = _now_iso()
        await self.db.execute(
            "INSERT INTO entries "
            "(id, agent_id, entry_type, content, category, confidence, "
            "access_count, last_accessed, source_ids, metadata, created_at, updated_at, status) "
            "VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, 'active')",
            (
                new_id, target_agent_id, entry["entry_type"], entry["content"],
                entry["category"], entry["confidence"], now,
                entry["source_ids"], entry["metadata"], now, now,
            ),
        )
        await self.db.commit()
        return new_id

    # ------------------------------------------------------------------
    # Knowledge Extraction (4-Gate)
    # ------------------------------------------------------------------

    async def extract_and_learn(self, user_msg: str, assistant_msg: str) -> None:
        """从 user/assistant 消息对中提取知识并存储（loop.py 调用入口）"""
        # Try to include recent history for correction detection
        conversation = []
        try:
            # Get recent messages from the most recent session
            async with self.db.execute(
                "SELECT role, content FROM messages WHERE agent_id = ? "
                "ORDER BY created_at DESC LIMIT 6",
                (self.agent_id,),
            ) as cur:
                rows = await cur.fetchall()
            if rows:
                # rows are newest-first; skip the 2 we're about to add, reverse rest
                history = [{"role": r[0], "content": r[1]} for r in rows[2:]]
                conversation.extend(reversed(history))
        except Exception:
            pass
        conversation.append({"role": "user", "content": user_msg})
        conversation.append({"role": "assistant", "content": assistant_msg})
        await self.extract_knowledge(conversation)

    async def extract_knowledge(self, conversation: list[dict], namespace: str = "") -> list[dict]:
        """Extract knowledge entries from a conversation using 4-Gate filtering.

        Each dict in conversation: {"role": str, "content": str}
        Returns list of extracted knowledge dicts that passed all gates.
        """
        if not conversation:
            return []

        # Build context from full conversation
        context = " ".join(msg.get("content", "") for msg in conversation)

        # Get existing entries for novelty/consistency checks
        existing = await self.get_entries(limit=200)

        # Extract candidate knowledge from assistant messages
        # (user messages provide context, assistant messages contain knowledge)
        candidates: list[dict] = []
        for msg in conversation:
            content = msg.get("content", "")
            if not content or len(content.strip()) < 20:
                continue
            # Split long messages into paragraphs as candidates
            paragraphs = [p.strip() for p in content.split("\n\n") if len(p.strip()) >= 20]
            if not paragraphs:
                paragraphs = [content]
            for para in paragraphs:
                candidates.append({
                    "content": para,
                    "role": msg.get("role", "unknown"),
                })

        extracted: list[dict] = []
        for cand in candidates:
            content = cand["content"]

            # Run 4 gates
            rel = relevance_gate(content, context)
            nov = novelty_gate(content, existing)
            conf = confidence_gate(content)
            cons = consistency_gate(content, existing)

            # All gates must pass thresholds
            if (
                rel < _GATE_THRESHOLDS["relevance"]
                or nov < _GATE_THRESHOLDS["novelty"]
                or conf < _GATE_THRESHOLDS["confidence"]
                or cons < _GATE_THRESHOLDS["consistency"]
            ):
                continue

            # Composite confidence
            composite = (rel * 0.2 + nov * 0.3 + conf * 0.3 + cons * 0.2)

            # Categorize
            category = _categorize(content)

            entry_id = await self.store_entry(
                entry_type="knowledge",
                content=content,
                category=category,
                confidence=composite,
                source_ids=[],
                namespace=namespace,
                metadata={
                    "gates": {
                        "relevance": round(rel, 3),
                        "novelty": round(nov, 3),
                        "confidence": round(conf, 3),
                        "consistency": round(cons, 3),
                    },
                    "source_role": cand["role"],
                },
            )
            # Entity Graph integration: extract and link entities
            if self._entity_graph and self._entity_extractor:
                try:
                    ext_result = await self._entity_extractor.extract(content)
                    entity_id_map: dict[str, str] = {}
                    for ent in ext_result.entities:
                        ent_id = await self._entity_graph.upsert_entity(
                            name=ent.name,
                            entity_type=ent.entity_type,
                            attributes=ent.attributes,
                        )
                        entity_id_map[ent.name.lower()] = ent_id
                        await self._entity_graph.link_entry_entity(entry_id, ent_id, role="mention")
                    for rel in ext_result.relations:
                        src_id = entity_id_map.get(rel.source.lower())
                        tgt_id = entity_id_map.get(rel.target.lower())
                        if src_id and tgt_id:
                            await self._entity_graph.add_relation(
                                source_entity_id=src_id,
                                target_entity_id=tgt_id,
                                relation_type=rel.relation_type,
                                evidence_entry_ids=[entry_id],
                            )
                except Exception:
                    pass  # graceful degradation

            extracted.append({
                "id": entry_id,
                "content": content,
                "category": category,
                "confidence": round(composite, 3),
                "gates": {
                    "relevance": round(rel, 3),
                    "novelty": round(nov, 3),
                    "confidence": round(conf, 3),
                    "consistency": round(cons, 3),
                },
            })

        # --- Correction/Reinforcement detection (P0 from DeerFlow analysis) ---
        try:
            from .correction import detect_correction, detect_reinforcement, get_correction_context

            _corr = detect_correction(conversation)
            _reinf = detect_reinforcement(conversation)
            if _corr:
                ctx = get_correction_context(conversation)
                if ctx:
                    correction_meta = {"source_error": ctx["source_error"]}
                    correction_id = await self.store_entry(
                        entry_type="correction",
                        content=ctx["correction"][:500],
                        category="correction",
                        confidence=0.95,
                        namespace=namespace,
                        metadata=correction_meta,
                    )
                    extracted.append({
                        "id": correction_id,
                        "content": ctx["correction"][:500],
                        "category": "correction",
                        "confidence": 0.95,
                        "gates": {"correction_detected": True},
                    })
            elif _reinf:
                # Boost confidence of entries extracted from this conversation
                for entry in extracted:
                    if entry.get("confidence", 0) < 0.9:
                        new_conf = min(entry["confidence"] + 0.1, 0.95)
                        await self.update_entry(entry["id"], confidence=new_conf)
                        entry["confidence"] = new_conf
        except Exception:
            pass  # correction detection is enhancement, don't break core flow

        return extracted

    # ------------------------------------------------------------------
    # Recall (RRF: keyword + embedding, neighbor expansion, MMR)
    # ------------------------------------------------------------------

    async def recall(self, query: str, limit: int = 5, namespaces: list[str] | None = None, config: RecallConfig | None = None, desk_context: DeskContext | None = None) -> list[dict]:
        """Retrieve relevant entries using RRF(keyword+embedding) + neighbor expansion + MMR.

        Args:
            namespaces: 联查多个 agent_id 的 entries（P2-2）
            config: 搜索配置（P3-2），默认 RecallConfig()
            desk_context: 四层命名空间上下文（P1），优先于 namespaces
        """
        import asyncio as _asyncio

        if config is None:
            config = RecallConfig()

        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        # 确定查询范围（namespace 感知）
        if desk_context is not None:
            # 四层命名空间：查 readable_namespaces
            readable_ns = desk_context.readable_namespaces
            ns_ph = ",".join("?" * len(readable_ns))
            where_clause = f"(namespace IN ({ns_ph}) OR (namespace = '' AND agent_id = ?)) AND status = 'active'"
            query_params = list(readable_ns) + [self.agent_id]
        elif namespaces:
            # 指定查询范围：同时匹配 agent_id 和 namespace 列
            all_ns = list(namespaces)
            ns_ph = ",".join("?" * len(all_ns))
            where_clause = f"(agent_id IN ({ns_ph}) OR namespace IN ({ns_ph})) AND status = 'active'"
            query_params = all_ns + all_ns
        else:
            # 默认：自己的 agent_id + org/shared namespace
            where_clause = "(agent_id = ? OR namespace = 'org/shared') AND status = 'active'"
            query_params = [self.agent_id]

        # Fetch active entries with rowid for neighbor expansion
        async with self.db.execute(
            f"SELECT rowid, * FROM entries WHERE {where_clause} ORDER BY rowid",
            query_params,
        ) as cur:
            rows = await cur.fetchall()

        if not rows:
            return []

        entries = [dict(r) for r in rows]
        rowid_to_idx: dict[int, int] = {e["rowid"]: i for i, e in enumerate(entries)}
        n_docs = len(entries)
        now = datetime.now(TZ_UTC)

        # Precompute per-entry token lists/sets and document frequencies
        df: dict[str, int] = {}
        entry_tok_lists: list[list[str]] = []
        entry_tok_sets: list[set[str]] = []
        for e in entries:
            toks = tokenize(e["content"])
            entry_tok_lists.append(toks)
            tok_set = set(toks)
            entry_tok_sets.append(tok_set)
            for t in tok_set:
                df[t] = df.get(t, 0) + 1

        # --- Keyword ranking (BM25 + bigram/trigram bonus + time decay + entity boost) ---
        query_bigrams = _ngrams(query_tokens, 2)
        query_trigrams = _ngrams(query_tokens, 3)
        query_entities = extract_entities(query)

        kw_scored: list[tuple[float, int]] = []
        for idx, e in enumerate(entries):
            tok_set = entry_tok_sets[idx]
            if not tok_set:
                continue
            score = 0.0
            for qt in query_tokens:
                if qt in tok_set:
                    idf = math.log((n_docs + 1) / (df.get(qt, 0) + 1)) + 1.0
                    score += idf

            if score <= 0:
                continue

            # Bigram / trigram overlap bonus
            if query_bigrams:
                score += len(query_bigrams & _ngrams(entry_tok_lists[idx], 2)) * 0.5
            if query_trigrams:
                score += len(query_trigrams & _ngrams(entry_tok_lists[idx], 3)) * 1.0

            # Time decay (half-life 30 days)
            last_acc = e.get("last_accessed") or e.get("created_at") or ""
            try:
                la_dt = datetime.fromisoformat(last_acc)
                if la_dt.tzinfo is None:
                    la_dt = la_dt.replace(tzinfo=TZ_UTC)
                days = max((now - la_dt).total_seconds() / 86400, 0)
            except (ValueError, TypeError):
                days = 90
            score *= math.exp(-0.693 * days / config.half_life_days)

            # Entity linking boost
            entry_entities = extract_entities(e["content"])
            entity_overlap = query_entities & entry_entities
            if entity_overlap:
                score *= 1.0 + config.entity_boost * min(len(entity_overlap), 3)

            # Access count boost
            ac = e.get("access_count", 0) or 0
            score *= 1.0 + 0.1 * math.log1p(ac)

            kw_scored.append((score, idx))

        kw_scored.sort(key=lambda x: x[0], reverse=True)
        kw_rank: dict[int, int] = {idx: rank for rank, (_, idx) in enumerate(kw_scored)}

        # --- Embedding ranking (cosine similarity via Ollama, optional) ---
        emb_rank: dict[int, int] = {}
        if _NUMPY_AVAILABLE:
            try:
                vec_list = None
                if self._embedding_chain:
                    _embed_result = await self._embedding_chain.embed(query)
                    vec_list = _embed_result.vector if _embed_result else None
                else:
                    vec_list = await _asyncio.get_running_loop().run_in_executor(
                        None, _fetch_embedding_sync, query, self.embedding_model, self.embedding_endpoint
                    )
                if vec_list:
                    q_vec = np.array(vec_list, dtype=np.float32)
                    async with self.db.execute(
                        "SELECT e.entry_id, e.vector FROM embeddings e "
                        "INNER JOIN entries en ON en.id = e.entry_id "
                        "WHERE en.agent_id = ? AND en.status = 'active'",
                        (self.agent_id,),
                    ) as cur:
                        emb_rows = await cur.fetchall()

                    entry_id_to_idx = {e["id"]: i for i, e in enumerate(entries)}
                    emb_sims: list[tuple[float, int]] = []
                    for emb_row in emb_rows:
                        eid, vec_blob = emb_row[0], emb_row[1]
                        if eid not in entry_id_to_idx or not vec_blob:
                            continue
                        try:
                            vec = np.frombuffer(vec_blob, dtype=np.float32)
                            emb_sims.append((_cosine_sim(q_vec, vec), entry_id_to_idx[eid]))
                        except Exception:
                            continue
                    emb_sims.sort(key=lambda x: x[0], reverse=True)
                    emb_rank = {idx: rank for rank, (_, idx) in enumerate(emb_sims)}
            except Exception:
                pass

        # --- RRF fusion (K=config.rrf_k): score = 1/(K+kw_rank) + 1/(K+emb_rank) ---
        K = config.rrf_k
        rrf_candidates: set[int] = {idx for _, idx in kw_scored}
        if emb_rank:
            rrf_candidates.update(emb_rank.keys())

        rrf_scored: list[tuple[float, int]] = []
        for idx in rrf_candidates:
            kw_r = kw_rank.get(idx, n_docs)
            score = 1.0 / (K + kw_r + 1)
            if emb_rank:
                emb_r = emb_rank.get(idx, n_docs)
                score += 1.0 / (K + emb_r + 1)
            rrf_scored.append((score, idx))

        rrf_scored.sort(key=lambda x: x[0], reverse=True)

        # --- Neighbor expansion: include rowid +/-1 for top candidates ---
        if config.neighbor_expansion:
            top_set: set[int] = {idx for _, idx in rrf_scored[: limit * 2]}
            neighbor_extras: list[tuple[float, int]] = []
            for idx in list(top_set):
                rid = entries[idx]["rowid"]
                for neighbor_rid in (rid - 1, rid + 1):
                    nb_idx = rowid_to_idx.get(neighbor_rid)
                    if nb_idx is not None and nb_idx not in top_set:
                        top_set.add(nb_idx)
                        neighbor_extras.append((1e-6, nb_idx))

            all_candidates = rrf_scored + neighbor_extras
        else:
            all_candidates = rrf_scored
        all_candidates.sort(key=lambda x: x[0], reverse=True)

        # --- MMR deduplication ---
        selected: list[dict] = []
        selected_tok_sets: list[set[str]] = []

        for score, idx in all_candidates:
            if len(selected) >= limit:
                break
            toks = entry_tok_sets[idx]
            if any(_jaccard(toks, s) > config.mmr_lambda for s in selected_tok_sets):
                continue

            entry = entries[idx]
            await self.increment_access(entry["id"])
            selected.append({
                "id": entry["id"],
                "content": entry["content"],
                "entry_type": entry["entry_type"],
                "category": entry["category"],
                "confidence": entry["confidence"],
                "namespace": entry.get("namespace", ""),
                "score": round(score, 4),
                "access_count": (entry.get("access_count", 0) or 0) + 1,
            })
            selected_tok_sets.append(toks)

        # --- Entity Graph augmentation ---
        if self._entity_graph and selected:
            try:
                selected = await self._graph_augmented_recall(
                    query, selected, entries, entry_tok_sets, limit
                )
            except Exception:
                pass

        # --- L1 组织层知识召回 ---
        if desk_context and desk_context.org_id:
            try:
                from .org_sync import OrgSyncManager
                org_mgr = OrgSyncManager()
                await org_mgr.initialize()
                org_results = await org_mgr.recall(query, desk_context.org_id, limit=2)
                await org_mgr.close()
                if org_results:
                    for r in org_results:
                        selected.append({
                            "id": r.get("id", ""),
                            "content": r.get("content", ""),
                            "category": r.get("category", ""),
                            "namespace": r.get("namespace", "org/shared"),
                            "confidence": r.get("confidence", 0.9),
                            "source": "org_cache",
                            "score": 0.5,
                            "entry_type": "fact",
                            "access_count": 0,
                        })
            except Exception:
                pass  # org cache 失败不影响主流程

        return selected

    async def _graph_augmented_recall(
        self,
        query: str,
        bm25_results: list[dict],
        all_entries: list[dict],
        entry_tokens: list[set[str]],
        limit: int,
    ) -> list[dict]:
        """Add graph traversal as third signal, fuse with RRF."""
        # Extract entity names from query
        from ..memory.entity_extractor import EntityExtractor
        extractor = self._entity_extractor or EntityExtractor(llm_fn=None)
        ext_result = await extractor.extract(query)
        entity_names = [e.name for e in ext_result.entities]

        if not entity_names:
            return bm25_results

        # Graph traversal: get related entry IDs
        graph_entry_ids = await self._entity_graph.traverse(entity_names, hops=2)
        if not graph_entry_ids:
            return bm25_results

        # Build entry lookup
        entry_by_id = {e["id"]: e for e in all_entries}

        # RRF fusion: combine BM25 ranks with graph ranks
        k = 60  # RRF constant
        # BM25 rank scores
        rrf_scores: dict[str, float] = {}
        for rank, item in enumerate(bm25_results):
            rrf_scores[item["id"]] = 1.0 / (k + rank + 1)

        # Graph rank scores (order = proximity)
        for rank, eid in enumerate(graph_entry_ids):
            if eid in entry_by_id:
                rrf_scores[eid] = rrf_scores.get(eid, 0) + 0.5 / (k + rank + 1)

        # Sort by RRF score
        sorted_ids = sorted(rrf_scores.keys(), key=lambda x: rrf_scores[x], reverse=True)

        # Rebuild results
        final: list[dict] = []
        for eid in sorted_ids[:limit]:
            # Prefer existing result dict if available
            existing = next((r for r in bm25_results if r["id"] == eid), None)
            if existing:
                existing["score"] = round(rrf_scores[eid], 4)
                final.append(existing)
            elif eid in entry_by_id:
                e = entry_by_id[eid]
                final.append({
                    "id": e["id"],
                    "content": e["content"],
                    "entry_type": e["entry_type"],
                    "category": e["category"],
                    "confidence": e["confidence"],
                    "score": round(rrf_scores[eid], 4),
                    "access_count": e.get("access_count", 0) or 0,
                })

        return final if final else bm25_results


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "tech": ["api", "sdk", "code", "bug", "deploy", "server", "database",
             "架构", "技术", "部署", "代码", "接口", "数据库", "模型"],
    "product": ["feature", "ux", "ui", "user", "产品", "功能", "用户",
                "需求", "设计", "体验", "交互"],
    "business": ["revenue", "cost", "customer", "market", "收入", "成本",
                 "客户", "市场", "商业", "融资", "营收"],
    "strategy": ["plan", "roadmap", "vision", "goal", "战略", "规划",
                 "目标", "方向", "路线图"],
    "people": ["team", "hire", "culture", "团队", "招聘", "管理", "人才"],
}


def _categorize(content: str) -> str:
    lower = content.lower()
    scores: dict[str, int] = {}
    for cat, keywords in _CATEGORY_KEYWORDS.items():
        scores[cat] = sum(1 for kw in keywords if kw in lower)
    if not scores or max(scores.values()) == 0:
        return "general"
    return max(scores, key=lambda k: scores[k])
