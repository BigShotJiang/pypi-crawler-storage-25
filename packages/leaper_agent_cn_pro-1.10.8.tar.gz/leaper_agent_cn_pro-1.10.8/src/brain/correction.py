"""Correction & Reinforcement Detection for DeepBrain.

Detects when a user corrects an agent's mistake or reinforces correct behavior.
Inspired by DeerFlow's correction detection, adapted for Chinese + English.
"""

from __future__ import annotations

import re

# --- Correction signals ---
# User explicitly says the agent is wrong
CORRECTION_PATTERNS_ZH = [
    r"不对[，。！]?", r"错了[，。！]?", r"不是这样", r"你搞错了", r"你理解错了",
    r"应该是", r"不应该", r"纠正一下", r"更正", r"改一下",
    r"不是.*而是", r"你说的.*不对", r"这个不对", r"搞反了",
    r"别这样", r"不要这样", r"不是这个意思",
    r"我不是", r"其实是", r"准确地?说",
    r"你.*偏了", r"说得?不对",
]

CORRECTION_PATTERNS_EN = [
    r"that'?s (?:not |in)?correct", r"that'?s wrong", r"no[,.]?\s*(?:it|that|the)",
    r"actually[,.]?\s*(?:it|the|I)", r"you(?:'re| are) (?:wrong|mistaken|confused)",
    r"I (?:meant|said|asked)", r"let me correct", r"correction:",
    r"not (?:what I|like that)", r"you misunderstood", r"that'?s not what",
    r"wrong[.!]", r"incorrect[.!]",
]

# --- Reinforcement signals ---
# User explicitly confirms the agent is right
REINFORCEMENT_PATTERNS_ZH = [
    r"对[的了！]", r"没错", r"正确", r"就是这[样个]", r"很好",
    r"完美", r"太好了", r"非常好", r"很棒", r"不错",
    r"你说得?对", r"理解正确", r"嗯嗯", r"好的好的",
]

REINFORCEMENT_PATTERNS_EN = [
    r"(?:that'?s |it'?s )?(?:correct|right|exactly|perfect|great)[.!]?",
    r"yes[,.]?\s*(?:that|exactly|correct|right|perfect)",
    r"well done", r"good (?:job|work|point)", r"nailed it",
    r"you(?:'re| are) right", r"that'?s what I (?:meant|wanted)",
]

_correction_re = re.compile(
    "|".join(CORRECTION_PATTERNS_ZH + CORRECTION_PATTERNS_EN),
    re.IGNORECASE,
)

_reinforcement_re = re.compile(
    "|".join(REINFORCEMENT_PATTERNS_ZH + REINFORCEMENT_PATTERNS_EN),
    re.IGNORECASE,
)


def detect_correction(conversation: list[dict]) -> bool:
    """Check if user messages contain correction signals (explicit or implicit)."""
    for i, msg in enumerate(conversation):
        if msg.get("role") != "user":
            continue
        content = msg.get("content", "")
        # Explicit correction patterns
        if _correction_re.search(content):
            return True
        # Implicit correction: user asserts something that contradicts
        # the previous assistant message (e.g., assistant says "你是务实的",
        # user says "我是天马行空的")
        if i > 0 and conversation[i - 1].get("role") == "assistant":
            prev = conversation[i - 1].get("content", "")
            if _detect_implicit_correction(content, prev):
                return True
    return False


def _detect_implicit_correction(user_msg: str, assistant_msg: str) -> bool:
    """Detect implicit correction by checking if user contradicts assistant's characterization."""
    # Pattern: assistant says "你是X的" and user says "我是Y的" where X != Y
    import re as _re
    # Extract what assistant characterized the user as
    assistant_claims = _re.findall(r"你是[^，。！？\n]{1,10}的", assistant_msg)
    if not assistant_claims:
        return False
    # Check if user makes a counter-claim about themselves
    user_claims = _re.findall(r"我是[^，。！？\n]{1,10}的", user_msg)
    if not user_claims:
        return False
    # If assistant said "你是X" and user said "我是Y" with different X/Y, it's a correction
    for ac in assistant_claims:
        a_attr = ac[2:-1]  # strip "你是" and "的"
        for uc in user_claims:
            u_attr = uc[2:-1]  # strip "我是" and "的"
            if a_attr != u_attr:
                return True
    return False


def detect_reinforcement(conversation: list[dict]) -> bool:
    """Check if user messages contain reinforcement signals."""
    for msg in conversation:
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if _reinforcement_re.search(content):
                return True
    return False


def get_correction_context(conversation: list[dict]) -> dict | None:
    """Extract the correction context: what was wrong + what is correct.

    Returns dict with 'source_error' and 'correction' if found, else None.
    """
    for i, msg in enumerate(conversation):
        if msg.get("role") != "user":
            continue
        content = msg.get("content", "")
        if not _correction_re.search(content):
            continue

        # The previous assistant message is likely what was wrong
        source_error = ""
        for j in range(i - 1, -1, -1):
            if conversation[j].get("role") == "assistant":
                source_error = conversation[j].get("content", "")[:200]
                break

        return {
            "source_error": source_error,
            "correction": content,
        }
    return None
