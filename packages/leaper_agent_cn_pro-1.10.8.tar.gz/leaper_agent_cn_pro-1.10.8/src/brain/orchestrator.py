"""
LeaperOrchestrator - Main orchestrator tying all Leaper subsystems together.
Does NOT call the LLM directly; provides context and processes results.
"""

from __future__ import annotations

import os
from typing import Any

from .engine import LeaperBrain
from .evolution import LeaperEvolution
from .profile import LeaperProfile
from .meta import LeaperMeta
from .triggers import EvolutionTrigger
from .session_index import SessionIndex
from ..agent.prompt_builder import LeaperPromptBuilder
from ..agent.queue_manager import LeaperQueueManager
from ..agent.session_manager import LeaperSessionManager


class LeaperOrchestrator:
    """
    Main orchestrator for the Leaper agent system.

    Responsibilities:
    - Initialize all subsystems (brain, evolution, profile, meta, prompt, queue, session)
    - Handle incoming messages: build context + prompt for external LLM
    - Process responses: store, extract knowledge, trigger evolution
    - Does NOT call the LLM (that's Hermes's job)
    """

    def __init__(self, agent_id: str, db_path: str, workspace_dir: str) -> None:
        self.agent_id = agent_id
        self.db_path = db_path
        self.workspace_dir = workspace_dir

        # Subsystems (initialized in initialize())
        self.brain: LeaperBrain | None = None
        self.evolution: LeaperEvolution | None = None
        self.profile: LeaperProfile | None = None
        self.meta: LeaperMeta | None = None
        self.prompt_builder: LeaperPromptBuilder | None = None
        self.queue: LeaperQueueManager | None = None
        self.session_manager: LeaperSessionManager | None = None
        self.trigger: EvolutionTrigger = EvolutionTrigger()
        self.session_index: SessionIndex | None = None
        self._initialized = False

    async def initialize(self) -> None:
        """Create and initialize all subsystems."""
        if self._initialized:
            return

        # Ensure workspace exists
        os.makedirs(self.workspace_dir, exist_ok=True)

        # Core brain（传入 workspace_dir 以启用双写）
        self.brain = LeaperBrain(
            db_path=self.db_path,
            agent_id=self.agent_id,
            workspace_dir=self.workspace_dir,
        )
        await self.brain.initialize()

        # Knowledge evolution
        self.evolution = LeaperEvolution(brain=self.brain)

        # Profile system
        self.profile = LeaperProfile(brain=self.brain)

        # Meta/health assessment
        self.meta = LeaperMeta(brain=self.brain)

        # Prompt builder
        self.prompt_builder = LeaperPromptBuilder(
            workspace_dir=self.workspace_dir,
            brain=self.brain,
        )

        # Message queue
        self.queue = LeaperQueueManager()

        # Session manager
        sessions_dir = os.path.join(os.path.dirname(self.db_path), "sessions")
        self.session_manager = LeaperSessionManager(sessions_dir=sessions_dir)

        # Session index（P3-1）
        self.session_index = SessionIndex(self.brain)

        self._initialized = True

    def _check_initialized(self) -> None:
        if not self._initialized:
            raise RuntimeError("Orchestrator not initialized. Call initialize() first.")

    async def handle_message(self, session_id: str, user_message: str) -> str:
        """
        Full agent loop for an incoming message.

        Flow: queue → recall → prompt → return prompt string.
        The actual LLM call is external (Hermes). This returns the assembled prompt/context.
        """
        self._check_initialized()

        # 1. Enqueue message
        await self.queue.enqueue(session_id=session_id, message=user_message)

        # 2. Recall relevant knowledge
        recalled = await self.brain.recall(query=user_message, limit=5)

        # 3. Build prompt with context
        prompt = await self.prompt_builder.build(query=user_message, session_id=session_id)

        # 4. Append recalled memories to prompt
        if recalled:
            memory_block = "\n\n## 相关记忆\n"
            for entry in recalled:
                memory_block += f"- [{entry.get('category', 'general')}] {entry['content'][:200]}\n"
            prompt += memory_block

        return prompt

    async def on_response(self, session_id: str, user_msg: str, assistant_msg: str) -> None:
        """Post-response processing (向后兼容，内部调用 on_turn_end)."""
        await self.on_turn_end(session_id, user_msg, assistant_msg)

    async def on_turn_start(self, turn_number: int, message: str) -> None:
        """每轮开始预热（P1-3）：预加载相关记忆"""
        self._check_initialized()
        # 预热：提前 recall 填充缓存
        await self.brain.recall(query=message, limit=3)

    async def on_turn_end(self, session_id: str, user_msg: str, assistant_msg: str) -> None:
        """每轮结束处理（P1-3）：存消息 + 提取知识 + 触发进化"""
        self._check_initialized()

        # Store messages
        await self.brain.store_message(session_id=session_id, role="user", content=user_msg)
        await self.brain.store_message(session_id=session_id, role="assistant", content=assistant_msg)

        # Build conversation with recent history for correction detection
        # Include previous assistant message so correction patterns like
        # "不对，应该是..." can reference what was wrong
        conversation = []
        try:
            recent = await self.brain.get_messages(session_id=session_id, limit=6)
            # recent is newest-first; reverse to chronological, exclude the 2 we just stored
            for msg in reversed(recent[2:]):
                conversation.append({"role": msg.get("role", ""), "content": msg.get("content", "")})
        except Exception:
            pass
        conversation.append({"role": "user", "content": user_msg})
        conversation.append({"role": "assistant", "content": assistant_msg})
        extracted = await self.brain.extract_knowledge(conversation, namespace=f"agent/{self.agent_id}")

        # 触发器（P1-4）
        for _ in extracted:
            self.trigger.on_entry_added()

        # 按需触发进化
        if self.trigger.should_evolve_l2():
            await self.evolution.evolve_l2_consolidate()
            self.trigger.on_evolve_complete(2)

        if self.trigger.should_evolve_l3():
            await self.evolution.evolve_l3_skill()
            self.trigger.on_evolve_complete(3)

        if self.trigger.should_evolve_l4():
            await self.evolution.evolve_l4_profile("default")
            self.trigger.on_evolve_complete(4)

        if self.trigger.should_evolve_l5():
            l5 = await self.evolution.evolve_l5_meta()
            self.trigger.on_evolve_complete(5)
            # L5 时自动策展 MEMORY.md（P2-3）
            try:
                from .curated_memory import generate_memory_md
                await generate_memory_md(self.brain, self.workspace_dir)
            except Exception:
                pass

    async def on_pre_compress(self, messages: list[dict]) -> str:
        """压缩前 Memory Flush（P1-2）：从即将被压缩的消息中提取知识。

        返回已保存记忆的简短摘要。
        """
        self._check_initialized()

        # 从即将被压缩的消息中提取知识
        extracted = await self.brain.extract_knowledge(messages, namespace=f"agent/{self.agent_id}")

        # 触发 L2 聚类防碎片
        if extracted:
            await self.evolution.evolve_l2_consolidate()

        summary_parts = [f"[{e['category']}] {e['content'][:60]}..." for e in extracted[:5]]
        return f"已保存 {len(extracted)} 条记忆" + (": " + "; ".join(summary_parts) if summary_parts else "")

    async def on_session_end(self, session_id: str, messages: list[dict] | None = None) -> None:
        """会话结束：触发完整进化 + session 索引（P1-3, P3-1）"""
        self._check_initialized()

        # Session memory 索引（P3-1）
        if messages and self.session_index:
            await self.session_index.index_session(session_id, messages)

        # Run full evolution cycle
        await self.evolution.run_full_evolution()

        # Update profile from new entries
        await self.profile.infer_from_entries(agent_id=self.agent_id)

        # L5 完成后自动策展（P2-3）
        try:
            from .curated_memory import generate_memory_md
            await generate_memory_md(self.brain, self.workspace_dir)
        except Exception:
            pass

    async def shutdown(self) -> None:
        """Gracefully shut down all subsystems."""
        if self.brain:
            await self.brain.close()

        self._initialized = False
        self.brain = None
        self.evolution = None
        self.profile = None
        self.meta = None
        self.prompt_builder = None
        self.queue = None
        self.session_manager = None
