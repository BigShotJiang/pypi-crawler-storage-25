"""
Session Memory 索引

P3-1: 会话消息切片存储与搜索
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from .engine import tokenize, _jaccard

if TYPE_CHECKING:
    from .engine import LeaperBrain


class SessionIndex:
    """将会话消息索引为 entry，支持历史会话搜索"""

    def __init__(self, brain: "LeaperBrain") -> None:
        self.brain = brain

    async def index_session(self, session_id: str, messages: list[dict]) -> int:
        """将会话消息切片，存入 entries 表（entry_type='session_memory'）

        返回索引的条目数。
        """
        if not messages:
            return 0

        count = 0
        # 每 2-4 条消息为一个切片
        chunk_size = 3
        for i in range(0, len(messages), chunk_size):
            chunk = messages[i : i + chunk_size]
            content_parts = []
            for msg in chunk:
                role = msg.get("role", "unknown")
                text = msg.get("content", "").strip()
                if text:
                    content_parts.append(f"[{role}] {text}")

            if not content_parts:
                continue

            combined = "\n".join(content_parts)
            # 截断过长内容
            if len(combined) > 500:
                combined = combined[:500] + "..."

            await self.brain.store_entry(
                entry_type="session_memory",
                content=combined,
                category="session",
                confidence=0.6,
                metadata={"session_id": session_id, "chunk_index": i // chunk_size},
            )
            count += 1

        return count

    async def search_sessions(self, query: str, limit: int = 5) -> list[dict]:
        """搜索历史会话片段，返回最相关的条目"""
        db = self.brain.db
        async with db.execute(
            "SELECT id, content, category, confidence, metadata, created_at "
            "FROM entries WHERE agent_id = ? AND entry_type = 'session_memory' AND status = 'active' "
            "ORDER BY created_at DESC LIMIT 200",
            (self.brain.agent_id,),
        ) as cur:
            rows = await cur.fetchall()

        if not rows:
            return []

        query_tokens = set(tokenize(query))
        if not query_tokens:
            return []

        scored = []
        for r in rows:
            row = dict(r)
            entry_tokens = set(tokenize(row["content"]))
            sim = _jaccard(query_tokens, entry_tokens)
            if sim > 0:
                scored.append((sim, row))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [row for _, row in scored[:limit]]
