"""
Embedding Provider 抽象 + Fallback Chain

P1-1: 可插拔的 embedding 提供者，支持 Ollama / HTTP API / 关键词降级
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from .engine import tokenize


@dataclass
class EmbedResult:
    """Embedding 结果，包含向量、模型标识和维度"""
    vector: list[float]
    model: str
    dim: int


class EmbeddingProvider(ABC):
    """Embedding 提供者抽象基类"""

    @property
    @abstractmethod
    def model_id(self) -> str:
        """返回此 provider 的模型标识"""
        ...

    @abstractmethod
    async def embed(self, text: str) -> list[float] | None:
        """计算文本的 embedding 向量，失败返回 None"""
        ...

    @abstractmethod
    async def is_available(self) -> bool:
        """检查提供者是否可用"""
        ...


class OllamaProvider(EmbeddingProvider):
    """通过 Ollama 本地服务计算 embedding"""

    def __init__(
        self,
        model: str = "nomic-embed-text",
        endpoint: str = "http://localhost:11434/api/embed",
    ) -> None:
        self.model = model
        self.endpoint = endpoint

    @property
    def model_id(self) -> str:
        return f"ollama:{self.model}"

    async def embed(self, text: str) -> list[float] | None:
        import asyncio
        import urllib.request
        try:
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, self._sync_embed, text)
        except Exception:
            return None

    def _sync_embed(self, text: str) -> list[float] | None:
        import urllib.request
        try:
            payload = json.dumps({"model": self.model, "input": text}).encode("utf-8")
            req = urllib.request.Request(
                self.endpoint, data=payload, method="POST",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
            vecs = data.get("embeddings", [])
            if vecs and isinstance(vecs[0], list) and vecs[0]:
                return vecs[0]
        except Exception:
            pass
        return None

    async def is_available(self) -> bool:
        import urllib.request
        try:
            req = urllib.request.Request(
                self.endpoint.replace("/api/embed", "/api/tags"),
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=2) as resp:
                return resp.status == 200
        except Exception:
            return False


class APIProvider(EmbeddingProvider):
    """通过外部 HTTP API 计算 embedding（DeepSeek/智谱/Gemini 等）"""

    def __init__(
        self,
        endpoint: str,
        api_key: str,
        model: str = "text-embedding-3-small",
    ) -> None:
        self.endpoint = endpoint
        self.api_key = api_key
        self.model = model

    @property
    def model_id(self) -> str:
        return self.model

    async def embed(self, text: str) -> list[float] | None:
        import asyncio
        try:
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, self._sync_embed, text)
        except Exception:
            return None

    def _sync_embed(self, text: str) -> list[float] | None:
        import urllib.request
        try:
            payload = json.dumps({
                "model": self.model,
                "input": text,
            }).encode("utf-8")
            req = urllib.request.Request(
                self.endpoint, data=payload, method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.api_key}",
                },
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            # OpenAI-compatible format
            if "data" in data and data["data"]:
                return data["data"][0].get("embedding", [])
            # Ollama-compatible format
            vecs = data.get("embeddings", [])
            if vecs and isinstance(vecs[0], list):
                return vecs[0]
        except Exception:
            pass
        return None

    async def is_available(self) -> bool:
        return bool(self.api_key and self.endpoint)


class KeywordFallbackProvider(EmbeddingProvider):
    """无外部服务时的降级方案：tokenize → hash 到 128 维伪向量"""

    DIM = 128

    @property
    def model_id(self) -> str:
        return "keyword"

    async def embed(self, text: str) -> list[float] | None:
        tokens = tokenize(text)
        if not tokens:
            return [0.0] * self.DIM
        vec = [0.0] * self.DIM
        for token in tokens:
            h = int(hashlib.md5(token.encode()).hexdigest(), 16)
            for i in range(self.DIM):
                # 确定性散列到各维度
                bit = (h >> (i % 128)) & 1
                vec[i] += 1.0 if bit else -1.0
        # L2 归一化
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        return [x / norm for x in vec]

    async def is_available(self) -> bool:
        return True  # 始终可用


class EmbeddingChain:
    """按序尝试多个 provider，第一个成功的返回"""

    def __init__(self, providers: list[EmbeddingProvider]) -> None:
        self.providers = providers

    async def embed(self, text: str) -> EmbedResult | None:
        for provider in self.providers:
            try:
                result = await provider.embed(text)
                if result is not None:
                    return EmbedResult(
                        vector=result,
                        model=provider.model_id,
                        dim=len(result),
                    )
            except Exception:
                continue
        return None

    async def first_available(self) -> EmbeddingProvider | None:
        for p in self.providers:
            if await p.is_available():
                return p
        return None
