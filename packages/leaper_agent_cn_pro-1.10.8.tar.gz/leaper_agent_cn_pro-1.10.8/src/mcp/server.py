"""MCP Server — 将 Agent 能力暴露为 MCP 服务

功能：
1. 将 Tool 注册为 MCP tool
2. Resource 暴露
3. Prompt 模板暴露
4. stdio 传输（JSON-RPC 2.0）
5. 服务生命周期管理
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from typing import Any, Callable, Dict, List, Optional, Union

logger = logging.getLogger(__name__)

# MCP 协议版本
MCP_VERSION = "2024-11-05"


class MCPResource:
    """MCP 资源定义"""
    def __init__(self, uri: str, name: str, description: str = "",
                 mime_type: str = "text/plain",
                 reader: Optional[Callable[[], str]] = None):
        self.uri = uri
        self.name = name
        self.description = description
        self.mime_type = mime_type
        self._reader = reader

    async def read(self) -> str:
        """读取资源内容"""
        if self._reader:
            result = self._reader()
            if asyncio.iscoroutine(result):
                return await result
            return result
        return ""

    def to_dict(self) -> dict:
        return {
            "uri": self.uri,
            "name": self.name,
            "description": self.description,
            "mimeType": self.mime_type,
        }


class MCPPrompt:
    """MCP Prompt 模板"""
    def __init__(self, name: str, description: str = "",
                 arguments: Optional[List[Dict[str, Any]]] = None,
                 template: str = ""):
        self.name = name
        self.description = description
        self.arguments = arguments or []
        self.template = template

    def render(self, args: Dict[str, str]) -> List[Dict[str, str]]:
        """渲染 prompt 模板"""
        content = self.template
        for key, value in args.items():
            content = content.replace(f"{{{key}}}", value)
        return [{"role": "user", "content": content}]

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "arguments": self.arguments,
        }


class MCPServer:
    """MCP 服务端 — stdio 传输

    将 Agent 的工具、资源和 prompt 模板暴露为 MCP 服务，
    通过 stdin/stdout 的 JSON-RPC 2.0 协议通信。
    """

    def __init__(self, name: str = "leaper-agent", version: str = "1.0.0"):
        self._name = name
        self._version = version
        self._tools: Dict[str, Dict[str, Any]] = {}  # name -> {schema, handler}
        self._resources: Dict[str, MCPResource] = {}  # uri -> resource
        self._prompts: Dict[str, MCPPrompt] = {}  # name -> prompt
        self._running = False
        self._handlers: Dict[str, Callable] = {}
        self._setup_handlers()

    def _setup_handlers(self):
        """注册 JSON-RPC 方法处理器"""
        self._handlers = {
            "initialize": self._handle_initialize,
            "initialized": self._handle_initialized,
            "tools/list": self._handle_tools_list,
            "tools/call": self._handle_tools_call,
            "resources/list": self._handle_resources_list,
            "resources/read": self._handle_resources_read,
            "prompts/list": self._handle_prompts_list,
            "prompts/get": self._handle_prompts_get,
            "ping": self._handle_ping,
        }

    # --- 注册 API ---

    def register_tool(self, name: str, description: str, schema: dict,
                      handler: Callable) -> None:
        """注册工具"""
        self._tools[name] = {
            "name": name,
            "description": description,
            "inputSchema": schema,
            "handler": handler,
        }

    def register_tool_from_object(self, tool: Any) -> None:
        """从 Tool 对象注册（需要 name, description, parameters, execute 属性）"""
        self.register_tool(
            name=tool.name,
            description=tool.description,
            schema=tool.parameters,
            handler=tool.execute,
        )

    def register_resource(self, resource: MCPResource) -> None:
        """注册资源"""
        self._resources[resource.uri] = resource

    def register_prompt(self, prompt: MCPPrompt) -> None:
        """注册 prompt 模板"""
        self._prompts[prompt.name] = prompt

    # --- 生命周期 ---

    async def start(self) -> None:
        """启动 MCP 服务（stdio 模式）"""
        self._running = True
        logger.info(f"MCP Server '{self._name}' v{self._version} starting (stdio)")
        try:
            await self._stdio_loop()
        except asyncio.CancelledError:
            pass
        finally:
            self._running = False

    async def stop(self) -> None:
        """停止服务"""
        self._running = False

    @property
    def is_running(self) -> bool:
        return self._running

    # --- stdio 传输 ---

    async def _stdio_loop(self) -> None:
        """主循环：从 stdin 读 JSON-RPC 请求，写响应到 stdout"""
        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        await asyncio.get_event_loop().connect_read_pipe(lambda: protocol, sys.stdin)

        while self._running:
            try:
                line = await reader.readline()
                if not line:
                    break
                line_str = line.decode("utf-8").strip()
                if not line_str:
                    continue
                request = json.loads(line_str)
                response = await self._dispatch(request)
                if response is not None:
                    self._write_response(response)
            except json.JSONDecodeError as e:
                self._write_response(self._error_response(None, -32700, f"解析错误: {e}"))
            except Exception as e:
                logger.error(f"MCP Server error: {e}")

    def _write_response(self, response: dict) -> None:
        """写 JSON-RPC 响应到 stdout"""
        line = json.dumps(response, ensure_ascii=False) + "\n"
        sys.stdout.write(line)
        sys.stdout.flush()

    async def handle_message(self, message: str) -> Optional[str]:
        """处理单条消息（用于测试或嵌入模式）"""
        try:
            request = json.loads(message)
            response = await self._dispatch(request)
            if response:
                return json.dumps(response, ensure_ascii=False)
            return None
        except json.JSONDecodeError:
            return json.dumps(self._error_response(None, -32700, "解析错误"))

    # --- JSON-RPC 分发 ---

    async def _dispatch(self, request: dict) -> Optional[dict]:
        """分发 JSON-RPC 请求"""
        method = request.get("method", "")
        req_id = request.get("id")
        params = request.get("params", {})

        handler = self._handlers.get(method)
        if not handler:
            if req_id is not None:
                return self._error_response(req_id, -32601, f"未知方法: {method}")
            return None  # 通知消息不需要响应

        try:
            result = await handler(params)
            if req_id is not None:
                return {"jsonrpc": "2.0", "id": req_id, "result": result}
            return None
        except Exception as e:
            if req_id is not None:
                return self._error_response(req_id, -32603, str(e))
            return None

    # --- 方法处理器 ---

    async def _handle_initialize(self, params: dict) -> dict:
        return {
            "protocolVersion": MCP_VERSION,
            "capabilities": {
                "tools": {"listChanged": False},
                "resources": {"subscribe": False, "listChanged": False},
                "prompts": {"listChanged": False},
            },
            "serverInfo": {
                "name": self._name,
                "version": self._version,
            },
        }

    async def _handle_initialized(self, params: dict) -> dict:
        return {}

    async def _handle_tools_list(self, params: dict) -> dict:
        tools = []
        for info in self._tools.values():
            tools.append({
                "name": info["name"],
                "description": info["description"],
                "inputSchema": info["inputSchema"],
            })
        return {"tools": tools}

    async def _handle_tools_call(self, params: dict) -> dict:
        name = params.get("name", "")
        arguments = params.get("arguments", {})

        tool = self._tools.get(name)
        if not tool:
            return {
                "content": [{"type": "text", "text": f"工具不存在: {name}"}],
                "isError": True,
            }

        try:
            handler = tool["handler"]
            result = handler(arguments)
            if asyncio.iscoroutine(result):
                result = await result
            text = result if isinstance(result, str) else json.dumps(result, ensure_ascii=False)
            return {"content": [{"type": "text", "text": text}], "isError": False}
        except Exception as e:
            return {"content": [{"type": "text", "text": f"执行错误: {e}"}], "isError": True}

    async def _handle_resources_list(self, params: dict) -> dict:
        return {"resources": [r.to_dict() for r in self._resources.values()]}

    async def _handle_resources_read(self, params: dict) -> dict:
        uri = params.get("uri", "")
        resource = self._resources.get(uri)
        if not resource:
            raise ValueError(f"资源不存在: {uri}")
        content = await resource.read()
        return {
            "contents": [{
                "uri": uri,
                "mimeType": resource.mime_type,
                "text": content,
            }],
        }

    async def _handle_prompts_list(self, params: dict) -> dict:
        return {"prompts": [p.to_dict() for p in self._prompts.values()]}

    async def _handle_prompts_get(self, params: dict) -> dict:
        name = params.get("name", "")
        prompt = self._prompts.get(name)
        if not prompt:
            raise ValueError(f"Prompt 不存在: {name}")
        args = params.get("arguments", {})
        messages = prompt.render(args)
        return {"description": prompt.description, "messages": messages}

    async def _handle_ping(self, params: dict) -> dict:
        return {}

    # --- 工具方法 ---

    @staticmethod
    def _error_response(req_id: Any, code: int, message: str) -> dict:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": code, "message": message},
        }
