"""MCP (Model Context Protocol) 模块 — 客户端 + 服务端"""
from .client import MCPClient
from .manager import MCPManager
from .server import MCPServer, MCPResource, MCPPrompt

__all__ = ["MCPClient", "MCPManager", "MCPServer", "MCPResource", "MCPPrompt"]
