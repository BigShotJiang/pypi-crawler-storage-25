"""内置定时调度器 — 零外部依赖，自研 cron 解析

支持三种调度方式：
- cron: 标准 cron 表达式 (* * * * *)
- interval: 每 N 分钟/小时执行
- at: 一次性定时执行

增强功能：
- 任务持久化到 .scheduler/jobs.json
- 执行历史记录
- 失败重试（最多 3 次）
"""

import asyncio
import json
import logging
import re
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Union

logger = logging.getLogger(__name__)


@dataclass
class JobRun:
    """任务执行记录"""
    job_id: str
    run_id: str
    started_at: str
    finished_at: Optional[str] = None
    status: Literal["success", "failed", "running"] = "running"
    error: Optional[str] = None
    attempt: int = 1

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "JobRun":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class Job:
    """定时任务"""
    id: str
    name: str
    cron_expr: str          # 标准 cron 表达式 (min hour dom mon dow)
    agent_id: str
    payload: str            # 要执行的指令
    enabled: bool = True
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    schedule_type: Literal["cron", "interval", "at"] = "cron"
    interval_minutes: Optional[int] = None   # interval 模式用
    at_time: Optional[datetime] = None       # at 模式用
    max_retries: int = 3                  # 最大重试次数
    retry_count: int = 0                  # 当前重试次数
    session_mode: Literal["main", "isolated"] = "main"  # 会话模式

    def to_dict(self) -> dict:
        d = asdict(self)
        d["last_run"] = self.last_run.isoformat() if self.last_run else None
        d["next_run"] = self.next_run.isoformat() if self.next_run else None
        d["at_time"] = self.at_time.isoformat() if self.at_time else None
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Job":
        lr = d.get("last_run")
        nr = d.get("next_run")
        at = d.get("at_time")
        return cls(
            id=d["id"], name=d["name"], cron_expr=d.get("cron_expr", ""),
            agent_id=d.get("agent_id", ""), payload=d.get("payload", ""),
            enabled=d.get("enabled", True),
            last_run=datetime.fromisoformat(lr) if lr else None,
            next_run=datetime.fromisoformat(nr) if nr else None,
            schedule_type=d.get("schedule_type", "cron"),
            interval_minutes=d.get("interval_minutes"),
            at_time=datetime.fromisoformat(at) if at else None,
            max_retries=d.get("max_retries", 3),
            retry_count=d.get("retry_count", 0),
            session_mode=d.get("session_mode", "main"),
        )


# ---------- cron 解析工具 ----------

def _parse_cron_field(field_str: str, min_val: int, max_val: int) -> set[int]:
    """解析单个 cron 字段，返回匹配的整数集合
    
    支持: *, */N, N, N-M, N-M/S, 逗号分隔
    """
    result: set[int] = set()
    for part in field_str.split(","):
        part = part.strip()
        # */N
        step_match = re.match(r"\*/(\d+)$", part)
        if step_match:
            step = int(step_match.group(1))
            result.update(range(min_val, max_val + 1, step))
            continue
        # N-M/S
        range_step = re.match(r"(\d+)-(\d+)/(\d+)$", part)
        if range_step:
            lo, hi, step = int(range_step.group(1)), int(range_step.group(2)), int(range_step.group(3))
            result.update(range(lo, hi + 1, step))
            continue
        # N-M
        range_match = re.match(r"(\d+)-(\d+)$", part)
        if range_match:
            lo, hi = int(range_match.group(1)), int(range_match.group(2))
            result.update(range(lo, hi + 1))
            continue
        # *
        if part == "*":
            result.update(range(min_val, max_val + 1))
            continue
        # 纯数字
        if part.isdigit():
            result.add(int(part))
            continue
        raise ValueError(f"无法解析 cron 字段: {part}")
    return result


def parse_cron(expr: str) -> tuple[set[int], set[int], set[int], set[int], set[int]]:
    """解析完整 cron 表达式，返回 (minutes, hours, doms, months, dows)"""
    parts = expr.strip().split()
    if len(parts) != 5:
        raise ValueError(f"cron 表达式需要 5 个字段，实际 {len(parts)}: {expr}")
    minutes = _parse_cron_field(parts[0], 0, 59)
    hours = _parse_cron_field(parts[1], 0, 23)
    doms = _parse_cron_field(parts[2], 1, 31)
    months = _parse_cron_field(parts[3], 1, 12)
    dows = _parse_cron_field(parts[4], 0, 6)
    return minutes, hours, doms, months, dows


def cron_matches(expr: str, dt: datetime) -> bool:
    """检查给定时间是否匹配 cron 表达式"""
    minutes, hours, doms, months, dows = parse_cron(expr)
    return (
        dt.minute in minutes
        and dt.hour in hours
        and dt.day in doms
        and dt.month in months
        and dt.weekday() in _convert_dow(dows)
    )


def _convert_dow(dows: set[int]) -> set[int]:
    """cron dow (0=Sunday) → Python weekday (0=Monday)"""
    mapping = {0: 6, 1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5}
    return {mapping.get(d, d) for d in dows}


def calculate_next_run(cron_expr: str, after: Optional[datetime] = None) -> datetime:
    """计算下次执行时间（暴力向前搜索，最多搜 366 天）"""
    if after is None:
        after = datetime.now()
    # 从下一分钟开始搜索
    candidate = after.replace(second=0, microsecond=0) + timedelta(minutes=1)
    minutes, hours, doms, months, dows = parse_cron(cron_expr)
    py_dows = _convert_dow(dows)
    
    for _ in range(366 * 24 * 60):  # 最多搜一年
        if (candidate.minute in minutes
                and candidate.hour in hours
                and candidate.day in doms
                and candidate.month in months
                and candidate.weekday() in py_dows):
            return candidate
        candidate += timedelta(minutes=1)
    raise ValueError(f"未能在一年内找到匹配时间: {cron_expr}")


# ---------- 自然语言解析 ----------

# 中文→cron 的模式映射
_NL_PATTERNS: list[tuple[str, str]] = [
    (r"每(\d+)分钟", "*/\\1 * * * *"),
    (r"每小时", "0 * * * *"),
    (r"每天早上(\d+)点", "0 \\1 * * *"),
    (r"每天上午(\d+)点", "0 \\1 * * *"),
    (r"每天下午(\d+)点", None),  # 特殊处理
    (r"每天晚上(\d+)点", None),  # 特殊处理
    (r"每天(\d+)点", "0 \\1 * * *"),
    (r"每周一上午(\d+)点", "0 \\1 * * 1"),
    (r"每周一(\d+)点", "0 \\1 * * 1"),
    (r"每周二(\d+)点", "0 \\1 * * 2"),
    (r"每周三(\d+)点", "0 \\1 * * 3"),
    (r"每周四(\d+)点", "0 \\1 * * 4"),
    (r"每周五(\d+)点", "0 \\1 * * 5"),
    (r"每周六(\d+)点", "0 \\1 * * 6"),
    (r"每周日(\d+)点", "0 \\1 * * 0"),
    (r"每月(\d+)号", "0 9 \\1 * *"),
    (r"工作日下午(\d+)点", None),  # 特殊处理
    (r"工作日(\d+)点", "0 \\1 * * 1-5"),
]


def parse_natural_language(text: str) -> Optional[str]:
    """自然语言 → cron 表达式"""
    text = text.strip()
    text_lower = text.lower()

    # --- English patterns ---

    # every N minutes / every N min
    m = re.search(r"every\s+(\d+)\s*min(?:ute)?s?", text_lower)
    if m:
        return f"*/{m.group(1)} * * * *"

    # every hour
    if "every hour" in text_lower:
        return "0 * * * *"

    # every day atNam/Npm
    m = re.search(r"every\s+day\s+at\s+(\d+)\s*(am|pm)?", text_lower)
    if m:
        hour = int(m.group(1))
        if m.group(2) == "pm" and hour < 12:
            hour += 12
        return f"0 {hour} * * *"

    # --- Chinese patterns ---
    
    # 每N分钟
    m = re.search(r"每(\d+)分钟", text)
    if m:
        return f"*/{m.group(1)} * * * *"
    
    if "每小时" in text:
        return "0 * * * *"
    
    # 工作日下午N点
    m = re.search(r"工作日下午(\d+)点", text)
    if m:
        hour = int(m.group(1)) + 12
        return f"0 {hour} * * 1-5"
    
    # 工作日N点
    m = re.search(r"工作日(\d+)点", text)
    if m:
        return f"0 {m.group(1)} * * 1-5"
    
    # 每天下午N点
    m = re.search(r"每天下午(\d+)点", text)
    if m:
        hour = int(m.group(1)) + 12
        return f"0 {hour} * * *"
    
    # 每天晚上N点
    m = re.search(r"每天晚上(\d+)点", text)
    if m:
        hour = int(m.group(1)) + 12
        return f"0 {hour} * * *"
    
    # 每天早上/上午/N点
    m = re.search(r"每天(?:早上|上午)?(\d+)点", text)
    if m:
        return f"0 {m.group(1)} * * *"
    
    # 每周X N点
    dow_map = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "日": 0, "天": 0}
    m = re.search(r"每周([\u4e00-\u9fa5])(?:上午|下午|晚上)?(\d+)点", text)
    if m:
        dow = dow_map.get(m.group(1))
        hour = int(m.group(2))
        if dow is not None:
            if "下午" in text or "晚上" in text:
                hour += 12
            return f"0 {hour} * * {dow}"
    
    # 每月N号
    m = re.search(r"每月(\d+)号", text)
    if m:
        return f"0 9 {m.group(1)} * *"
    
    return None


# ---------- Scheduler ----------

class Scheduler:
    """内置定时调度器

    支持三种调度方式：
    - cron: 标准 cron 表达式
    - interval: 每 N 分钟执行
    - at: 一次性定时执行

    持久化到 .scheduler/jobs.json，并记录执行历史。
    """

    BRAIN_KEY = "scheduler_jobs"

    def __init__(self, brain=None, multi_agent_manager=None, persist_dir: Optional[str] = None):
        self._brain = brain
        self._multi_agent = multi_agent_manager
        self._jobs: list[Job] = []
        self._runs: list[JobRun] = []  # 执行历史
        self._running = False
        self._task: asyncio.Task | None = None
        # 文件持久化目录
        self._persist_dir = Path(persist_dir) if persist_dir else None

    # --- 公开 API ---

    async def start(self):
        """启动调度循环"""
        self._load_jobs()
        self._running = True
        self._task = asyncio.create_task(self._loop())

    async def stop(self):
        """停止调度"""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    def add_job(self, name: str, schedule: str, action: str,
                agent_id: str = "", schedule_type: str = "cron") -> Job:
        """添加定时任务

        Args:
            name: 任务名称
            schedule: 调度表达式（cron 表达式 / interval 分钟数 / ISO 时间）
            action: 要执行的指令（payload）
            agent_id: 目标 agent
            schedule_type: cron / interval / at

        Returns:
            Job 实例
        """
        job = Job(
            id=uuid.uuid4().hex[:8],
            name=name,
            cron_expr="",
            agent_id=agent_id,
            payload=action,
            schedule_type=schedule_type,
        )

        if schedule_type == "cron":
            parse_cron(schedule)  # 验证
            job.cron_expr = schedule
            job.next_run = calculate_next_run(schedule)
        elif schedule_type == "interval":
            minutes = int(schedule)
            job.interval_minutes = minutes
            job.cron_expr = f"*/{minutes} * * * *" if minutes < 60 else ""
            job.next_run = datetime.now() + timedelta(minutes=minutes)
        elif schedule_type == "at":
            at_time = datetime.fromisoformat(schedule)
            job.at_time = at_time
            job.next_run = at_time
        else:
            raise ValueError(f"不支持的 schedule_type: {schedule_type}")

        self._jobs.append(job)
        self._persist_jobs()
        return job

    def pause_job(self, job_id: str) -> bool:
        """暂停任务"""
        for j in self._jobs:
            if j.id == job_id:
                j.enabled = False
                self._persist_jobs()
                return True
        return False

    def resume_job(self, job_id: str) -> bool:
        """恢复任务"""
        for j in self._jobs:
            if j.id == job_id:
                j.enabled = True
                # 重新计算下次执行时间
                if j.schedule_type == "cron" and j.cron_expr:
                    j.next_run = calculate_next_run(j.cron_expr)
                elif j.schedule_type == "interval" and j.interval_minutes:
                    j.next_run = datetime.now() + timedelta(minutes=j.interval_minutes)
                self._persist_jobs()
                return True
        return False

    def get_job(self, job_id: str) -> Optional[Job]:
        """根据 ID 获取任务"""
        for j in self._jobs:
            if j.id == job_id:
                return j
        return None

    def update_job(self, job_id: str, **kwargs) -> bool:
        """更新任务属性"""
        job = self.get_job(job_id)
        if not job:
            return False
        for k, v in kwargs.items():
            if hasattr(job, k):
                setattr(job, k, v)
        # 如果更新了 cron 表达式，重新计算下次执行时间
        if "cron_expr" in kwargs and job.schedule_type == "cron":
            parse_cron(kwargs["cron_expr"])  # 验证
            job.next_run = calculate_next_run(kwargs["cron_expr"])
        self._persist_jobs()
        return True

    def remove_job(self, job_id: str) -> bool:
        """删除任务"""
        before = len(self._jobs)
        self._jobs = [j for j in self._jobs if j.id != job_id]
        if len(self._jobs) < before:
            self._persist_jobs()
            return True
        return False

    def list_jobs(self) -> list[Job]:
        """列出所有任务"""
        return list(self._jobs)

    def get_job_runs(self, job_id: str) -> list[JobRun]:
        """获取任务执行历史"""
        return [r for r in self._runs if r.job_id == job_id]

    def parse_natural_language(self, text: str) -> str | None:
        """自然语言 → cron 表达式（委托给模块函数）"""
        return parse_natural_language(text)

    def _calculate_next_run(self, cron_expr: str) -> datetime:
        return calculate_next_run(cron_expr)

    # --- 内部 ---

    async def _loop(self):
        """每分钟检查一次"""
        while self._running:
            now = datetime.now().replace(second=0, microsecond=0)
            for job in self._jobs:
                if not job.enabled:
                    continue
                should_run = False
                if job.schedule_type == "cron" and job.cron_expr:
                    should_run = cron_matches(job.cron_expr, now)
                elif job.schedule_type == "interval" and job.next_run:
                    should_run = now >= job.next_run
                elif job.schedule_type == "at" and job.at_time:
                    should_run = now >= job.at_time and job.last_run is None

                if should_run:
                    asyncio.create_task(self._execute_job(job))
                    job.last_run = now
                    if job.schedule_type == "cron" and job.cron_expr:
                        job.next_run = calculate_next_run(job.cron_expr, now)
                    elif job.schedule_type == "interval" and job.interval_minutes:
                        job.next_run = now + timedelta(minutes=job.interval_minutes)
                    elif job.schedule_type == "at":
                        job.enabled = False  # 一次性任务执行后禁用

            self._persist_jobs()
            await asyncio.sleep(60)

    async def _execute_job(self, job: Job):
        """执行任务，支持失败重试和 session 隔离"""
        run = JobRun(
            job_id=job.id,
            run_id=uuid.uuid4().hex[:8],
            started_at=datetime.now().isoformat(),
            attempt=job.retry_count + 1,
        )

        try:
            if self._multi_agent:
                # 根据 session_mode 决定是否使用隔离 session
                extra_kwargs: dict = {}
                if job.session_mode == "isolated":
                    extra_kwargs["session_id"] = f"isolated:cron:{job.id}:{run.run_id}"

                await self._multi_agent.route_message(
                    agent_id=job.agent_id,
                    message=job.payload,
                    **extra_kwargs,
                )
            run.status = "success"
            run.finished_at = datetime.now().isoformat()
            job.retry_count = 0  # 重置重试计数
        except Exception as e:
            run.status = "failed"
            run.error = str(e)
            run.finished_at = datetime.now().isoformat()
            # 重试逻辑
            job.retry_count += 1
            if job.retry_count < job.max_retries:
                # 下次重试：指数退避（1分钟 → 2分钟 → 4分钟）
                delay = 2 ** (job.retry_count - 1)
                job.next_run = datetime.now() + timedelta(minutes=delay)
            else:
                job.retry_count = 0  # 重置

        self._runs.append(run)
        # 只保留最近 100 条记录
        if len(self._runs) > 100:
            self._runs = self._runs[-100:]
        self._persist_jobs()

    def _persist_jobs(self):
        """持久化任务到文件和 brain db"""
        # 文件持久化
        if self._persist_dir:
            self._persist_to_file()

        # brain db 持久化（兼容旧逻辑）
        if not self._brain:
            return
        data = json.dumps([j.to_dict() for j in self._jobs], ensure_ascii=False)
        try:
            if hasattr(self._brain, "db_path") and self._brain.db_path:
                import sqlite3
                conn = sqlite3.connect(self._brain.db_path)
                conn.execute(
                    "CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)"
                )
                conn.execute(
                    "INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)",
                    (self.BRAIN_KEY, data),
                )
                conn.commit()
                conn.close()
        except Exception:
            pass

    def _persist_to_file(self):
        """持久化到 .scheduler/jobs.json"""
        if not self._persist_dir:
            return
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        jobs_file = self._persist_dir / "jobs.json"
        runs_file = self._persist_dir / "runs.json"
        try:
            with open(jobs_file, "w", encoding="utf-8") as f:
                json.dump([j.to_dict() for j in self._jobs], f, ensure_ascii=False, indent=2)
            with open(runs_file, "w", encoding="utf-8") as f:
                json.dump([r.to_dict() for r in self._runs], f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _load_jobs(self):
        """加载 jobs（优先从文件，其次从 brain db）"""
        # 从文件加载
        if self._persist_dir:
            jobs_file = self._persist_dir / "jobs.json"
            runs_file = self._persist_dir / "runs.json"
            try:
                if jobs_file.exists():
                    with open(jobs_file, "r", encoding="utf-8") as f:
                        self._jobs = [Job.from_dict(d) for d in json.load(f)]
                if runs_file.exists():
                    with open(runs_file, "r", encoding="utf-8") as f:
                        self._runs = [JobRun.from_dict(d) for d in json.load(f)]
                    return
            except Exception:
                pass

        # 从 brain db 加载
        if not self._brain:
            return
        try:
            if hasattr(self._brain, "db_path") and self._brain.db_path:
                import sqlite3
                conn = sqlite3.connect(self._brain.db_path)
                conn.execute(
                    "CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)"
                )
                row = conn.execute(
                    "SELECT value FROM kv WHERE key = ?", (self.BRAIN_KEY,)
                ).fetchone()
                conn.close()
                if row:
                    self._jobs = [Job.from_dict(d) for d in json.loads(row[0])]
        except Exception:
            pass
