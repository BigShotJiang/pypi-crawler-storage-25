"""任务定义与持久化存储

提供：
- JobDefinition: 带标签、描述的高级任务定义
- JobStore: JSON/SQLite 双模式持久化
"""

from __future__ import annotations

import json
import logging
import sqlite3
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class JobDefinition:
    """高级任务定义 — 比 Job 更丰富的元数据"""
    id: str
    name: str
    description: str = ""
    cron_expr: str = ""
    payload: str = ""
    agent_id: str = ""
    tags: List[str] = field(default_factory=list)
    category: str = "general"  # general / monitor / report / cleanup
    timeout_seconds: int = 300
    enabled: bool = True
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "JobDefinition":
        valid_keys = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in d.items() if k in valid_keys})


class JobStore:
    """任务持久化存储 — 支持 JSON 文件和 SQLite

    Args:
        path: 存储路径（.json 用文件，.db/.sqlite 用 SQLite）
    """

    def __init__(self, path: str):
        self._path = Path(path)
        self._use_sqlite = self._path.suffix in (".db", ".sqlite")
        if self._use_sqlite:
            self._init_sqlite()

    def _init_sqlite(self):
        """初始化 SQLite 表"""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                data TEXT NOT NULL,
                created_at TEXT,
                updated_at TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS job_runs (
                run_id TEXT PRIMARY KEY,
                job_id TEXT NOT NULL,
                started_at TEXT,
                finished_at TEXT,
                status TEXT,
                error TEXT,
                attempt INTEGER DEFAULT 1
            )
        """)
        conn.commit()
        conn.close()

    def save(self, job: JobDefinition) -> None:
        """保存任务"""
        now = datetime.now().isoformat()
        if not job.created_at:
            job.created_at = now
        job.updated_at = now

        if self._use_sqlite:
            conn = sqlite3.connect(str(self._path))
            conn.execute(
                "INSERT OR REPLACE INTO jobs (id, name, data, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (job.id, job.name, json.dumps(job.to_dict(), ensure_ascii=False), job.created_at, job.updated_at),
            )
            conn.commit()
            conn.close()
        else:
            jobs = self._load_all_json()
            jobs = [j for j in jobs if j["id"] != job.id]
            jobs.append(job.to_dict())
            self._save_all_json(jobs)

    def load(self, job_id: str) -> Optional[JobDefinition]:
        """加载单个任务"""
        if self._use_sqlite:
            conn = sqlite3.connect(str(self._path))
            row = conn.execute("SELECT data FROM jobs WHERE id = ?", (job_id,)).fetchone()
            conn.close()
            if row:
                return JobDefinition.from_dict(json.loads(row[0]))
            return None
        else:
            for j in self._load_all_json():
                if j["id"] == job_id:
                    return JobDefinition.from_dict(j)
            return None

    def load_all(self) -> List[JobDefinition]:
        """加载所有任务"""
        if self._use_sqlite:
            conn = sqlite3.connect(str(self._path))
            rows = conn.execute("SELECT data FROM jobs").fetchall()
            conn.close()
            return [JobDefinition.from_dict(json.loads(r[0])) for r in rows]
        else:
            return [JobDefinition.from_dict(j) for j in self._load_all_json()]

    def delete(self, job_id: str) -> bool:
        """删除任务"""
        if self._use_sqlite:
            conn = sqlite3.connect(str(self._path))
            cursor = conn.execute("DELETE FROM jobs WHERE id = ?", (job_id,))
            conn.commit()
            deleted = cursor.rowcount > 0
            conn.close()
            return deleted
        else:
            jobs = self._load_all_json()
            new_jobs = [j for j in jobs if j["id"] != job_id]
            if len(new_jobs) < len(jobs):
                self._save_all_json(new_jobs)
                return True
            return False

    def find_by_tag(self, tag: str) -> List[JobDefinition]:
        """按标签查找任务"""
        return [j for j in self.load_all() if tag in j.tags]

    def find_by_category(self, category: str) -> List[JobDefinition]:
        """按分类查找任务"""
        return [j for j in self.load_all() if j.category == category]

    # --- JSON 文件操作 ---

    def _load_all_json(self) -> List[dict]:
        if not self._path.exists():
            return []
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return []

    def _save_all_json(self, jobs: List[dict]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(jobs, f, ensure_ascii=False, indent=2)
