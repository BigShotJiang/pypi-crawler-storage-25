"""智谱 GLM Provider - 需要 JWT 签名认证"""
import asyncio
import json
import time
import hashlib
import hmac
import base64
from typing import AsyncGenerator, Union

import httpx

from .base import LLMProvider, Message, ToolFunction, Response, StreamChunk, Usage


class ZhipuProvider(LLMProvider):
    """智谱 GLM-4 系列，JWT token 认证"""

    BASE_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
    MODELS = ["glm-4-flash", "glm-4-plus", "glm-4"]

    def __init__(self, config: Union[dict, str] = "", model: str = "glm-4-flash", max_retries: int = 3,
                 api_key: str = "", **kwargs):
        """config 可以是 dict 或 str(api_key)，也兼容旧版关键字参数。api_key 格式: {id}.{secret}"""
        if isinstance(config, dict):
            api_key = config.get("api_key", api_key)
            model = config.get("model", model)
        elif config:
            api_key = config
        self.api_key = api_key
        self.model = model
        self.max_retries = max_retries
        # 解析 api_key
        parts = api_key.split(".")
        if len(parts) != 2:
            raise ValueError("智谱 api_key 格式应为 {id}.{secret}")
        self._key_id = parts[0]
        self._key_secret = parts[1]

    def _generate_token(self) -> str:
        """生成 JWT token（HS256 签名）"""
        # Header
        header = {"alg": "HS256", "sign_type": "SIGN"}
        # Payload
        now = int(time.time() * 1000)
        payload = {
            "api_key": self._key_id,
            "exp": now + 3600 * 1000,  # 1小时过期
            "timestamp": now,
        }

        def _b64url(data: bytes) -> str:
            return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

        header_b64 = _b64url(json.dumps(header, separators=(",", ":")).encode())
        payload_b64 = _b64url(json.dumps(payload, separators=(",", ":")).encode())
        signing_input = f"{header_b64}.{payload_b64}"
        signature = hmac.new(
            self._key_secret.encode("utf-8"), signing_input.encode("utf-8"), hashlib.sha256
        ).digest()
        sig_b64 = _b64url(signature)
        return f"{header_b64}.{payload_b64}.{sig_b64}"

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self._generate_token()}",
            "Content-Type": "application/json",
        }

    def _build_messages(self, messages: list[Message]) -> list[dict]:
        result = []
        for msg in messages:
            d: dict = {"role": msg.role}
            if msg.content is not None:
                d["content"] = msg.content
            if msg.tool_calls is not None:
                d["tool_calls"] = msg.tool_calls
            if msg.tool_call_id is not None:
                d["tool_call_id"] = msg.tool_call_id
            if msg.name is not None:
                d["name"] = msg.name
            result.append(d)
        return result

    def _build_tools(self, tools: list | None) -> list[dict] | None:
        """构建 OpenAI 格式的 tools 参数，兼容 dict 和 ToolFunction"""
        if not tools:
            return None
        result = []
        for td in tools:
            if isinstance(td, dict):
                if "type" in td and "function" in td:
                    result.append(td)
                elif "name" in td:
                    result.append({
                        "type": "function",
                        "function": {
                            "name": td["name"],
                            "description": td.get("description", ""),
                            "parameters": td.get("parameters", {"type": "object", "properties": {}}),
                        }
                    })
                else:
                    result.append(td)
            else:
                result.append({
                    "type": "function",
                    "function": {
                        "name": td.name,
                        "description": td.description,
                        "parameters": td.parameters,
                    },
                })
        return result

    def _build_body(
        self,
        messages: list[Message],
        tools: list[ToolFunction] | None,
        temperature: float,
        max_tokens: int,
        stream: bool = False,
    ) -> dict:
        body: dict = {
            "model": self.model,
            "messages": self._build_messages(messages),
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        built_tools = self._build_tools(tools)
        if built_tools:
            body["tools"] = built_tools
        return body

    async def _request_with_retry(self, client: httpx.AsyncClient, body: dict) -> httpx.Response:
        for attempt in range(self.max_retries):
            resp = await client.post(self.BASE_URL, json=body, headers=self._headers(), timeout=120)
            if resp.status_code == 429:
                retry_after = float(resp.headers.get("Retry-After", str(2 ** attempt)))
                await asyncio.sleep(retry_after)
                continue
            resp.raise_for_status()
            return resp
        raise httpx.HTTPStatusError("重试次数耗尽", request=resp.request, response=resp)

    def _parse_response(self, data: dict) -> Response:
        choice = data["choices"][0]
        message = choice["message"]
        tool_calls = message.get("tool_calls")
        finish_reason = choice.get("finish_reason", "stop")
        if finish_reason == "tool_calls":
            fr = "tool_calls"
        elif finish_reason == "length":
            fr = "length"
        else:
            fr = "stop"
        usage = None
        if "usage" in data:
            u = data["usage"]
            usage = Usage(prompt_tokens=u["prompt_tokens"], completion_tokens=u["completion_tokens"])
        return Response(content=message.get("content"), tool_calls=tool_calls, finish_reason=fr, usage=usage)

    async def chat(
        self,
        messages: list[Message],
        tools: list[ToolFunction] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> Response:
        body = self._build_body(messages, tools, temperature, max_tokens, stream=False)
        async with httpx.AsyncClient() as client:
            resp = await self._request_with_retry(client, body)
            return self._parse_response(resp.json())

    async def chat_stream(
        self,
        messages: list[Message],
        tools: list[ToolFunction] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> AsyncGenerator[StreamChunk, None]:
        body = self._build_body(messages, tools, temperature, max_tokens, stream=True)
        async with httpx.AsyncClient() as client:
            async with client.stream(
                "POST", self.BASE_URL, json=body, headers=self._headers(), timeout=120
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:]
                    if payload.strip() == "[DONE]":
                        yield StreamChunk(type="done")
                        return
                    data = json.loads(payload)
                    delta = data["choices"][0].get("delta", {})
                    finish_reason = data["choices"][0].get("finish_reason")

                    if "tool_calls" in delta:
                        for tc in delta["tool_calls"]:
                            if tc.get("function", {}).get("name"):
                                yield StreamChunk(type="tool_call_start", tool_call=tc)
                            elif tc.get("function", {}).get("arguments"):
                                yield StreamChunk(type="tool_call_delta", tool_call=tc)
                    elif delta.get("content"):
                        yield StreamChunk(type="token", content=delta["content"])

                    if finish_reason:
                        yield StreamChunk(type="done", finish_reason=finish_reason)
                        return
