"""LLM Providers - 国产大模型统一接口"""
from .base import LLMProvider, Message, ToolFunction, Response, StreamChunk, Usage
from .deepseek import DeepSeekProvider
from .qwen import QwenProvider
from .zhipu import ZhipuProvider
from .moonshot import MoonshotProvider

__all__ = [
    "LLMProvider", "Message", "ToolFunction", "Response", "StreamChunk", "Usage",
    "DeepSeekProvider", "QwenProvider", "ZhipuProvider", "MoonshotProvider",
    "create_provider",
]

# Provider 注册表
_PROVIDERS: dict[str, type[LLMProvider]] = {
    "deepseek": DeepSeekProvider,
    "qwen": QwenProvider,
    "zhipu": ZhipuProvider,
    "moonshot": MoonshotProvider,
}


def create_provider(name: str, config: dict) -> LLMProvider:
    """工厂函数：根据名称和配置创建 provider 实例

    Args:
        name: provider 名称 (deepseek/qwen/zhipu/moonshot)
        config: 配置字典，至少包含 api_key，可选 model 等参数

    Returns:
        LLMProvider 实例
    """
    if name not in _PROVIDERS:
        raise ValueError(f"未知 provider: {name}，可选: {list(_PROVIDERS.keys())}")
    cls = _PROVIDERS[name]
    return cls(config=config)
