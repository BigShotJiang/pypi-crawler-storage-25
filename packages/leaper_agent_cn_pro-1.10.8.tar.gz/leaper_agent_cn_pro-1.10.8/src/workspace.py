"""WorkspaceManager — Workspace 生命周期管理

管理 Agent workspace 的创建、验证、列表、初始化和迁移。
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Workspace 标准文件
STANDARD_FILES = [
    "MEMORY.md",
    "SOUL.md",
    "AGENTS.md",
    "USER.md",
]

# 可选文件
OPTIONAL_FILES = [
    "TOOLS.md",
    "IDENTITY.md",
    ".env",
]

WORKSPACE_VERSION = "1.0.0"


@dataclass
class WorkspaceInfo:
    """Workspace 信息"""
    name: str
    path: str
    version: str = ""
    created_at: float = 0.0
    files: int = 0
    valid: bool = True
    issues: List[str] = None

    def __post_init__(self):
        if self.issues is None:
            self.issues = []

    def to_dict(self) -> dict:
        return asdict(self)


# 模板定义
_TEMPLATES: Dict[str, Dict[str, str]] = {
    "default": {
        "SOUL.md": "# SOUL.md\n\n## 我是谁\n\n请定义你的 Agent 身份。\n",
        "MEMORY.md": "# MEMORY.md\n\n## 记忆\n\n这里记录 Agent 的长期记忆。\n",
        "AGENTS.md": "# AGENTS.md\n\n## 工作规则\n\n定义 Agent 的工作流程和规则。\n",
        "USER.md": "# USER.md\n\n- **Name:** 用户\n- **Timezone:** GMT+8\n",
    },
    "cto": {
        "SOUL.md": "# SOUL.md - CTO\n\n## 我是谁\n\n我是 CTO 技术顾问。\n\n## 核心职责\n1. 技术战略\n2. 方案评估\n3. 趋势分析\n",
        "MEMORY.md": "# MEMORY.md\n\n## 技术记忆\n\n记录技术决策和架构演进。\n",
        "AGENTS.md": "# AGENTS.md\n\n## 工作规则\n\n从 CTO 角度提供技术建议。\n",
        "USER.md": "# USER.md\n\n- **Name:** CEO\n- **Timezone:** GMT+8\n",
    },
}


class WorkspaceManager:
    """Workspace 生命周期管理器

    用法：
        manager = WorkspaceManager("~/.leaper-cn/workspaces")
        path = manager.create("my-agent", template="cto")
        issues = manager.validate(path)
        workspaces = manager.list_workspaces()
    """

    def __init__(self, base_dir: Optional[str] = None) -> None:
        """初始化

        Args:
            base_dir: workspace 根目录，默认 ~/.leaper-cn/workspaces
        """
        if base_dir is None:
            base_dir = os.path.expanduser("~/.leaper-cn/workspaces")
        self._base_dir = Path(base_dir)
        self._base_dir.mkdir(parents=True, exist_ok=True)

    @property
    def base_dir(self) -> str:
        return str(self._base_dir)

    def create(self, name: str, template: Optional[str] = None, path: Optional[str] = None) -> str:
        """创建 workspace

        Args:
            name: workspace 名称
            template: 模板名称
            path: 自定义路径（默认在 base_dir 下创建）

        Returns:
            workspace 路径

        Raises:
            FileExistsError: workspace 已存在
        """
        if path:
            ws_path = Path(path)
        else:
            ws_path = self._base_dir / name

        if ws_path.exists() and any(ws_path.iterdir()):
            raise FileExistsError(f"Workspace 已存在: {ws_path}")

        ws_path.mkdir(parents=True, exist_ok=True)

        # 初始化文件
        self.init_files(str(ws_path), template=template)

        # 写入 workspace 元数据
        meta = {
            "name": name,
            "version": WORKSPACE_VERSION,
            "created_at": time.time(),
            "template": template or "default",
        }
        meta_path = ws_path / ".workspace.json"
        meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

        logger.info(f"已创建 workspace: {ws_path}")
        return str(ws_path)

    def delete(self, path: str) -> None:
        """删除 workspace

        Args:
            path: workspace 路径
        """
        ws_path = Path(path)
        if ws_path.exists():
            shutil.rmtree(ws_path)
            logger.info(f"已删除 workspace: {ws_path}")

    def list_workspaces(self) -> List[WorkspaceInfo]:
        """列出所有 workspace"""
        result = []
        if not self._base_dir.exists():
            return result

        for item in sorted(self._base_dir.iterdir()):
            if item.is_dir():
                info = self.get_info(str(item))
                result.append(info)

        return result

    def validate(self, path: str) -> List[str]:
        """验证 workspace 完整性

        Args:
            path: workspace 路径

        Returns:
            问题列表（空列表表示无问题）
        """
        issues = []
        ws_path = Path(path)

        if not ws_path.exists():
            return [f"路径不存在: {path}"]

        if not ws_path.is_dir():
            return [f"不是目录: {path}"]

        # 检查标准文件
        for f in STANDARD_FILES:
            if not (ws_path / f).exists():
                issues.append(f"缺少标准文件: {f}")

        # 检查元数据
        meta_path = ws_path / ".workspace.json"
        if not meta_path.exists():
            issues.append("缺少元数据文件: .workspace.json")

        return issues

    def get_info(self, path: str) -> WorkspaceInfo:
        """获取 workspace 信息

        Args:
            path: workspace 路径

        Returns:
            WorkspaceInfo
        """
        ws_path = Path(path)
        name = ws_path.name

        # 读取元数据
        meta_path = ws_path / ".workspace.json"
        version = ""
        created_at = 0.0
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                name = meta.get("name", name)
                version = meta.get("version", "")
                created_at = meta.get("created_at", 0.0)
            except Exception:
                pass

        # 统计文件数
        file_count = sum(1 for _ in ws_path.rglob("*") if _.is_file()) if ws_path.exists() else 0

        # 验证
        issues = self.validate(path) if ws_path.exists() else ["路径不存在"]

        return WorkspaceInfo(
            name=name,
            path=str(ws_path),
            version=version,
            created_at=created_at,
            files=file_count,
            valid=len(issues) == 0,
            issues=issues,
        )

    def init_files(self, path: str, template: Optional[str] = None) -> None:
        """初始化 workspace 文件

        优先从 bundled-templates 目录复制真实模板文件，
        找不到时回退到内置的 _TEMPLATES 字典。

        Args:
            path: workspace 路径
            template: 模板名称
        """
        ws_path = Path(path)
        ws_path.mkdir(parents=True, exist_ok=True)

        tmpl_name = template or "default"

        # 尝试从 bundled 目录复制
        bundled_dir = Path(__file__).parent / "templates" / "workshop" / "templates" / tmpl_name
        common_dir = Path(__file__).parent / "templates" / "workshop" / "templates" / "_common"

        if bundled_dir.is_dir():
            # 先复制 _common 文件
            if common_dir.is_dir():
                for f in common_dir.iterdir():
                    if f.is_file() and not (ws_path / f.name).exists():
                        shutil.copy2(str(f), str(ws_path / f.name))
            # 再复制模板文件（覆盖 _common 同名文件）
            for f in bundled_dir.iterdir():
                if f.is_file() and not (ws_path / f.name).exists():
                    shutil.copy2(str(f), str(ws_path / f.name))
            logger.info(f"从 bundled 模板 '{tmpl_name}' 初始化 workspace: {path}")
        else:
            # 回退到内置字典
            tmpl = _TEMPLATES.get(tmpl_name, _TEMPLATES["default"])
            for filename, content in tmpl.items():
                file_path = ws_path / filename
                if not file_path.exists():
                    file_path.write_text(content, encoding="utf-8")

    def migrate(self, path: str, from_version: str, to_version: str) -> List[str]:
        """版本迁移

        Args:
            path: workspace 路径
            from_version: 原版本
            to_version: 目标版本

        Returns:
            迁移操作日志
        """
        ws_path = Path(path)
        logs = []

        # 确保元数据存在
        meta_path = ws_path / ".workspace.json"
        if meta_path.exists():
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        else:
            meta = {"name": ws_path.name, "version": from_version}
            logs.append("创建缺失的元数据文件")

        # 确保标准文件存在
        for f in STANDARD_FILES:
            fp = ws_path / f
            if not fp.exists():
                default_content = _TEMPLATES["default"].get(f, f"# {f}\n")
                fp.write_text(default_content, encoding="utf-8")
                logs.append(f"补充标准文件: {f}")

        # 更新版本号
        meta["version"] = to_version
        meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        logs.append(f"版本号更新: {from_version} → {to_version}")

        return logs
