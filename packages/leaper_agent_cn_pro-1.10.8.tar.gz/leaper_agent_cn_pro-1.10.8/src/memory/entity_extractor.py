"""Entity Extractor — LLM mode + Rule fallback for entity/relation extraction.

CN-exclusive: not part of open-source OPC DeepBrain.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine, Optional


@dataclass
class ExtractedEntity:
    name: str
    entity_type: str  # person/company/project/concept/technology/url
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass
class ExtractedRelation:
    source: str  # entity name
    target: str  # entity name
    relation_type: str  # works_at/uses/created/depends_on/related_to


@dataclass
class ExtractionResult:
    entities: list[ExtractedEntity] = field(default_factory=list)
    relations: list[ExtractedRelation] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Rule-based extraction (fallback)
# ---------------------------------------------------------------------------

# @mentions
_MENTION_RE = re.compile(r"@(\w{2,30})")
# URLs
_URL_RE = re.compile(r"https?://[^\s<>\"'）】\]]+")
# Package names (npm-style or python-style)
_PACKAGE_RE = re.compile(r"\b([a-z][a-z0-9\-_]{2,30}(?:/[a-z][a-z0-9\-_]{1,30})?)\b")
# CamelCase / PascalCase names (e.g., LangGraph, DeepBrain, OpenClaw)
_CAMEL_RE = re.compile(r"\b([A-Z][a-z]+(?:[A-Z][a-z]*)+)\b")
# ALL-CAPS acronyms (2-6 chars)
_ACRONYM_RE = re.compile(r"\b([A-Z]{2,6})\b")
# Chinese person names (2-4 chars preceded by name markers)
_CN_PERSON_RE = re.compile(r"(?:叫|是|给|找|问|跟|和|与|@)([\u4e00-\u9fff]{2,3})")
# Quoted names
_QUOTED_RE = re.compile(r"[「\"'《]([^「\"'》]{2,20})[」\"'》]")


def _extract_rules(text: str) -> ExtractionResult:
    """Rule-based entity extraction — no LLM needed."""
    entities: dict[str, ExtractedEntity] = {}

    # @mentions → person
    for m in _MENTION_RE.finditer(text):
        name = m.group(1)
        entities[name.lower()] = ExtractedEntity(name=name, entity_type="person")

    # URLs → url
    for m in _URL_RE.finditer(text):
        url = m.group(0).rstrip(".,;:)")
        entities[url] = ExtractedEntity(name=url, entity_type="url")

    # CamelCase → project/technology
    for m in _CAMEL_RE.finditer(text):
        name = m.group(1)
        entities[name.lower()] = ExtractedEntity(name=name, entity_type="technology")

    # Acronyms → technology (filter common English words)
    _common_acronyms_skip = {"THE", "AND", "BUT", "FOR", "NOT", "ARE", "WAS", "HAS", "HAD"}
    for m in _ACRONYM_RE.finditer(text):
        acr = m.group(1)
        if acr not in _common_acronyms_skip:
            entities[acr.lower()] = ExtractedEntity(name=acr, entity_type="technology")

    # Chinese person names
    for m in _CN_PERSON_RE.finditer(text):
        name = m.group(1)
        if len(name) >= 2:
            entities[name] = ExtractedEntity(name=name, entity_type="person")

    # Quoted names → concept
    for m in _QUOTED_RE.finditer(text):
        name = m.group(1)
        if name.lower() not in entities:
            entities[name.lower()] = ExtractedEntity(name=name, entity_type="concept")

    return ExtractionResult(entities=list(entities.values()))


# ---------------------------------------------------------------------------
# LLM-based extraction
# ---------------------------------------------------------------------------

_LLM_PROMPT = """Extract entities and relationships from the following text.

Return JSON:
{
  "entities": [{"name": "...", "type": "person|company|project|concept|technology|url"}],
  "relations": [{"source": "...", "target": "...", "type": "works_at|uses|created|depends_on|related_to"}]
}

Only extract clearly stated facts. Be concise.

Text:
"""


async def _extract_llm(
    text: str,
    llm_fn: Callable[[str], Coroutine[Any, Any, str]],
) -> ExtractionResult:
    """LLM-based entity extraction."""
    prompt = _LLM_PROMPT + text[:2000]  # truncate to avoid token overflow
    try:
        response = await llm_fn(prompt)
        # Parse JSON from response
        # Try to find JSON block
        json_match = re.search(r"\{[\s\S]*\}", response)
        if not json_match:
            return ExtractionResult()
        data = json.loads(json_match.group(0))

        entities = [
            ExtractedEntity(
                name=e.get("name", ""),
                entity_type=e.get("type", "concept"),
            )
            for e in data.get("entities", [])
            if e.get("name")
        ]
        relations = [
            ExtractedRelation(
                source=r.get("source", ""),
                target=r.get("target", ""),
                relation_type=r.get("type", "related_to"),
            )
            for r in data.get("relations", [])
            if r.get("source") and r.get("target")
        ]
        return ExtractionResult(entities=entities, relations=relations)
    except (json.JSONDecodeError, KeyError, TypeError):
        # Fallback to rules on any LLM parse error
        return _extract_rules(text)


# ---------------------------------------------------------------------------
# EntityExtractor — unified interface
# ---------------------------------------------------------------------------

# Type alias for LLM function
LLMFunction = Callable[[str], Coroutine[Any, Any, str]]


class EntityExtractor:
    """Extract entities and relations — LLM mode with rule fallback."""

    def __init__(self, llm_fn: Optional[LLMFunction] = None) -> None:
        """
        Args:
            llm_fn: Async function that takes a prompt string and returns LLM response.
                    If None, uses rule-based extraction only.
        """
        self._llm_fn = llm_fn

    async def extract(self, text: str) -> ExtractionResult:
        """Extract entities and relations from text.

        Uses LLM if available, falls back to rules.
        """
        if not text or len(text.strip()) < 10:
            return ExtractionResult()

        if self._llm_fn is not None:
            try:
                result = await _extract_llm(text, self._llm_fn)
                # If LLM returned something, use it; otherwise fall back
                if result.entities:
                    return result
            except Exception:
                pass

        # Fallback: rule-based
        return _extract_rules(text)
