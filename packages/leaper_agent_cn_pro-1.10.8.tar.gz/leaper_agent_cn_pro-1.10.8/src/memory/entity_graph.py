"""Entity Graph — Pure SQLite entity-relationship graph for DeepBrain.

Provides Entity/Relation CRUD, temporal validity, and graph traversal.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

import sqlite3

import aiosqlite

_TZ_UTC = timezone.utc

ENTITY_GRAPH_SCHEMA = """
CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    attributes TEXT DEFAULT '{}',
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    mention_count INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS relations (
    id TEXT PRIMARY KEY,
    source_entity_id TEXT NOT NULL,
    target_entity_id TEXT NOT NULL,
    relation_type TEXT NOT NULL,
    confidence REAL DEFAULT 0.8,
    valid_from TEXT,
    valid_to TEXT,
    evidence_entry_ids TEXT DEFAULT '[]',
    created_at TEXT NOT NULL,
    FOREIGN KEY (source_entity_id) REFERENCES entities(id),
    FOREIGN KEY (target_entity_id) REFERENCES entities(id)
);

CREATE TABLE IF NOT EXISTS entry_entities (
    entry_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    role TEXT DEFAULT 'mention',
    PRIMARY KEY (entry_id, entity_id)
);

CREATE INDEX IF NOT EXISTS idx_entities_name ON entities(name);
CREATE INDEX IF NOT EXISTS idx_entities_type ON entities(entity_type);
CREATE INDEX IF NOT EXISTS idx_relations_source ON relations(source_entity_id);
CREATE INDEX IF NOT EXISTS idx_relations_target ON relations(target_entity_id);
CREATE INDEX IF NOT EXISTS idx_relations_type ON relations(relation_type);
CREATE INDEX IF NOT EXISTS idx_entry_entities_entry ON entry_entities(entry_id);
CREATE INDEX IF NOT EXISTS idx_entry_entities_entity ON entry_entities(entity_id);
"""


def _now_iso() -> str:
    return datetime.now(_TZ_UTC).isoformat()


class EntityGraph:
    """Pure-SQLite entity-relationship graph."""

    def __init__(self, db: aiosqlite.Connection) -> None:
        self._db = db

    async def initialize(self) -> None:
        """Create graph tables if not exist."""
        self._db.row_factory = sqlite3.Row
        await self._db.executescript(ENTITY_GRAPH_SCHEMA)
        await self._db.commit()

    # ------------------------------------------------------------------
    # Entity CRUD
    # ------------------------------------------------------------------

    async def upsert_entity(
        self,
        name: str,
        entity_type: str,
        attributes: Optional[dict[str, Any]] = None,
    ) -> str:
        """Insert or update entity by name (case-insensitive merge)."""
        normalized = name.strip().lower()
        async with self._db.execute(
            "SELECT id, mention_count FROM entities WHERE lower(name) = ?",
            (normalized,),
        ) as cur:
            row = await cur.fetchone()

        now = _now_iso()
        if row:
            eid = row[0] if isinstance(row, (list, tuple)) else row["id"]
            count = (row[1] if isinstance(row, (list, tuple)) else row["mention_count"]) or 1
            await self._db.execute(
                "UPDATE entities SET last_seen = ?, mention_count = ?, "
                "attributes = COALESCE(?, attributes) WHERE id = ?",
                (now, count + 1, json.dumps(attributes or {}, ensure_ascii=False), eid),
            )
            await self._db.commit()
            return eid
        else:
            eid = uuid.uuid4().hex[:12]
            await self._db.execute(
                "INSERT INTO entities (id, name, entity_type, attributes, first_seen, last_seen, mention_count) "
                "VALUES (?, ?, ?, ?, ?, ?, 1)",
                (eid, name.strip(), entity_type, json.dumps(attributes or {}, ensure_ascii=False), now, now),
            )
            await self._db.commit()
            return eid

    async def get_entity(self, name: str) -> Optional[dict]:
        """Get entity by name."""
        async with self._db.execute(
            "SELECT * FROM entities WHERE lower(name) = ?",
            (name.strip().lower(),),
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    async def get_entity_by_id(self, entity_id: str) -> Optional[dict]:
        async with self._db.execute(
            "SELECT * FROM entities WHERE id = ?", (entity_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    # ------------------------------------------------------------------
    # Relation CRUD
    # ------------------------------------------------------------------

    async def add_relation(
        self,
        source_entity_id: str,
        target_entity_id: str,
        relation_type: str,
        confidence: float = 0.8,
        valid_from: Optional[str] = None,
        valid_to: Optional[str] = None,
        evidence_entry_ids: Optional[list[str]] = None,
    ) -> str:
        """Add a relation between two entities."""
        # Check for existing active relation of same type
        async with self._db.execute(
            "SELECT id FROM relations WHERE source_entity_id = ? AND target_entity_id = ? "
            "AND relation_type = ? AND valid_to IS NULL",
            (source_entity_id, target_entity_id, relation_type),
        ) as cur:
            existing = await cur.fetchone()

        if existing:
            rid = existing[0] if isinstance(existing, (list, tuple)) else existing["id"]
            return rid

        rid = uuid.uuid4().hex[:12]
        now = _now_iso()
        await self._db.execute(
            "INSERT INTO relations (id, source_entity_id, target_entity_id, relation_type, "
            "confidence, valid_from, valid_to, evidence_entry_ids, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                rid,
                source_entity_id,
                target_entity_id,
                relation_type,
                confidence,
                valid_from or now,
                valid_to,
                json.dumps(evidence_entry_ids or [], ensure_ascii=False),
                now,
            ),
        )
        await self._db.commit()
        return rid

    async def expire_relation(self, relation_id: str) -> None:
        """Mark a relation as expired (set valid_to = now)."""
        await self._db.execute(
            "UPDATE relations SET valid_to = ? WHERE id = ?",
            (_now_iso(), relation_id),
        )
        await self._db.commit()

    async def get_relations(
        self,
        entity_id: str,
        active_only: bool = True,
    ) -> list[dict]:
        """Get all relations involving an entity."""
        clause = " AND valid_to IS NULL" if active_only else ""
        sql = (
            f"SELECT * FROM relations WHERE "
            f"(source_entity_id = ? OR target_entity_id = ?){clause}"
        )
        async with self._db.execute(sql, (entity_id, entity_id)) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Entry-Entity linking
    # ------------------------------------------------------------------

    async def link_entry_entity(
        self, entry_id: str, entity_id: str, role: str = "mention"
    ) -> None:
        """Link a knowledge entry to an entity."""
        await self._db.execute(
            "INSERT OR IGNORE INTO entry_entities (entry_id, entity_id, role) VALUES (?, ?, ?)",
            (entry_id, entity_id, role),
        )
        await self._db.commit()

    async def get_entries_for_entity(self, entity_id: str) -> list[str]:
        """Get all entry IDs linked to an entity."""
        async with self._db.execute(
            "SELECT entry_id FROM entry_entities WHERE entity_id = ?",
            (entity_id,),
        ) as cur:
            rows = await cur.fetchall()
        return [r[0] if isinstance(r, (list, tuple)) else r["entry_id"] for r in rows]

    # ------------------------------------------------------------------
    # 传递性推理（P2-1）
    # ------------------------------------------------------------------

    _TRANSITIVE_TYPES = frozenset({"part_of", "belongs_to", "reports_to", "subclass_of"})

    async def infer_relations(self) -> int:
        """传递性推理：A→B(rel), B→C(rel) ⇒ A→C(rel)，标记 inferred=True。

        返回新推导的关系数。
        """
        # 先确保 relations 表有 inferred 列
        try:
            await self._db.execute(
                "ALTER TABLE relations ADD COLUMN inferred INTEGER DEFAULT 0"
            )
            await self._db.commit()
        except Exception:
            pass  # 列已存在

        count = 0
        for rel_type in self._TRANSITIVE_TYPES:
            # 找 2-hop 路径：A→B→C，且 A→C 不存在
            sql = """
                SELECT r1.source_entity_id AS a, r2.target_entity_id AS c
                FROM relations r1
                JOIN relations r2 ON r1.target_entity_id = r2.source_entity_id
                WHERE r1.relation_type = ? AND r2.relation_type = ?
                  AND r1.valid_to IS NULL AND r2.valid_to IS NULL
                  AND NOT EXISTS (
                    SELECT 1 FROM relations r3
                    WHERE r3.source_entity_id = r1.source_entity_id
                      AND r3.target_entity_id = r2.target_entity_id
                      AND r3.relation_type = ?
                      AND r3.valid_to IS NULL
                  )
            """
            async with self._db.execute(sql, (rel_type, rel_type, rel_type)) as cur:
                pairs = await cur.fetchall()

            for pair in pairs:
                a = pair[0] if isinstance(pair, (list, tuple)) else pair["a"]
                c = pair[1] if isinstance(pair, (list, tuple)) else pair["c"]
                if a == c:
                    continue
                rid = uuid.uuid4().hex[:12]
                now = _now_iso()
                await self._db.execute(
                    "INSERT INTO relations (id, source_entity_id, target_entity_id, relation_type, "
                    "confidence, valid_from, evidence_entry_ids, created_at, inferred) "
                    "VALUES (?, ?, ?, ?, 0.6, ?, '[]', ?, 1)",
                    (rid, a, c, rel_type, now, now),
                )
                count += 1

        if count:
            await self._db.commit()
        return count

    async def query_path(
        self, entity_a: str, entity_b: str, max_hops: int = 3
    ) -> list[dict] | None:
        """BFS 查找两个实体间的最短路径。

        返回路径上的 [{"entity": name, "relation": type}, ...] 或 None。
        """
        ent_a = await self.get_entity(entity_a)
        ent_b = await self.get_entity(entity_b)
        if not ent_a or not ent_b:
            return None

        start_id = ent_a["id"]
        end_id = ent_b["id"]

        # BFS
        from collections import deque
        queue: deque[list[tuple[str, str | None]]] = deque()  # path = [(entity_id, relation_type)]
        queue.append([(start_id, None)])
        visited = {start_id}

        while queue:
            path = queue.popleft()
            if len(path) - 1 > max_hops:
                break
            current = path[-1][0]
            if current == end_id:
                # 构建结果
                result = []
                for eid, rel in path:
                    ent = await self.get_entity_by_id(eid)
                    result.append({
                        "entity": ent["name"] if ent else eid,
                        "relation": rel,
                    })
                return result

            rels = await self.get_relations(current, active_only=True)
            for rel in rels:
                src = rel["source_entity_id"]
                tgt = rel["target_entity_id"]
                neighbor = tgt if src == current else src
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(path + [(neighbor, rel["relation_type"])])

    # ------------------------------------------------------------------
    # Graph Traversal
    # ------------------------------------------------------------------

    async def traverse(
        self,
        entity_names: list[str],
        hops: int = 2,
        active_only: bool = True,
    ) -> list[str]:
        """BFS traversal from seed entities, return linked entry_ids.

        Returns entry IDs reachable within `hops` from any seed entity.
        """
        # Resolve entity names to IDs
        seed_ids: set[str] = set()
        for name in entity_names:
            ent = await self.get_entity(name)
            if ent:
                seed_ids.add(ent["id"])

        if not seed_ids:
            return []

        visited: set[str] = set()
        frontier = seed_ids.copy()

        for _ in range(hops):
            next_frontier: set[str] = set()
            for eid in frontier:
                if eid in visited:
                    continue
                visited.add(eid)
                rels = await self.get_relations(eid, active_only=active_only)
                for rel in rels:
                    src = rel["source_entity_id"]
                    tgt = rel["target_entity_id"]
                    neighbor = tgt if src == eid else src
                    if neighbor not in visited:
                        next_frontier.add(neighbor)
            frontier = next_frontier

        visited.update(frontier)

        # Collect all entry IDs linked to visited entities
        entry_ids: list[str] = []
        seen_entries: set[str] = set()
        for eid in visited:
            eids = await self.get_entries_for_entity(eid)
            for e in eids:
                if e not in seen_entries:
                    seen_entries.add(e)
                    entry_ids.append(e)

        return entry_ids
