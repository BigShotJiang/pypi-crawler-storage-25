"""chat / run / serve / console 命令"""
import asyncio
import sys
from pathlib import Path
from typing import Optional

import click
from rich.prompt import Prompt
from rich.panel import Panel

from . import console, PROVIDER_DEFAULTS
from ..config import LeaperConfig, DEFAULT_CONFIG_PATH


@click.command()
@click.argument("agent_arg", required=False, default=None)
@click.option("--workspace", "-w", default=None, help="工作区目录")
@click.option("--agent", "-a", "agent_name", default=None, help="指定 Agent 名称")
@click.option("--toolset", "-t", default="standard", help="工具集 (minimal/standard/full/safe/coding/research)")
def chat(agent_arg: Optional[str], workspace: Optional[str], agent_name: Optional[str], toolset: str):
    """启动 CLI 对话模式"""
    from . import init

    # 支持 positional agent 参数：leaper-cn chat my-agent
    agent_name = agent_name or agent_arg

    # 加载配置
    cfg = LeaperConfig.load()
    if not cfg.provider.api_key:
        console.print("[yellow]⚠️  未找到配置，启动初始化向导...[/yellow]\n")
        from click.testing import CliRunner
        # 直接调用 init
        ctx = click.Context(init)
        ctx.invoke(init)
        cfg = LeaperConfig.load()
        if not cfg.provider.api_key:
            console.print("[red]❌ 初始化未完成，退出[/red]")
            raise SystemExit(1)

    # 如果指定了 --agent，用 MultiAgentManager 找到 workspace
    if agent_name:
        from ..agent.multi import MultiAgentManager
        config_dir = str(Path(DEFAULT_CONFIG_PATH).parent)
        manager = MultiAgentManager(config_dir=config_dir)
        try:
            agent_info = manager._agent_configs[agent_name]
            ws_dir = agent_info["workspace"]
        except KeyError:
            console.print(f"[red]❌ Agent 不存在: {agent_name}[/red]")
            raise SystemExit(1)
    else:
        ws_dir = workspace or cfg.agent.workspace

    # 验证工作区存在，必要时回退到配置中的默认工作区
    if not ws_dir or not Path(ws_dir).expanduser().exists():
        ws_dir = cfg.agent.workspace
    if not ws_dir or not Path(ws_dir).expanduser().exists():
        console.print("[red]❌ 未找到 Agent 工作区。请先运行: leaper-cn create[/red]")
        raise SystemExit(1)

    console.print(Panel("💬 Leaper Agent CN — 对话模式", style="bold blue"))
    console.print(f"[dim]模型: {cfg.provider.model} | Provider: {cfg.provider.name}[/dim]")
    console.print("[dim]输入 /quit 退出，Ctrl+C 中断[/dim]\n")

    try:
        asyncio.run(_chat_loop(cfg, ws_dir, toolset))
    except KeyboardInterrupt:
        console.print("\n[dim]👋 再见！[/dim]")


async def _chat_loop(cfg: LeaperConfig, workspace_dir: str, toolset: str = "standard"):
    """对话主循环"""
    from ..providers import create_provider
    from ..brain.engine import LeaperBrain
    from ..agent.loop import AgentLoop

    # 创建 provider
    try:
        provider = create_provider(cfg.provider.name, {
            "api_key": cfg.provider.api_key,
            "model": cfg.provider.model,
        })
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        return

    # 创建 Brain
    brain = None
    if cfg.brain.enabled:
        try:
            db_path = cfg.brain.db_path if cfg.brain.db_path != ":memory:" else ":memory:"
            brain = LeaperBrain(db_path=db_path, agent_id=cfg.agent.name or "leaper-agent")
            await brain.initialize()
        except Exception:
            brain = None  # graceful fallback

    # 加载 system prompt（按顺序加载 workspace 下全部 .md 文件）
    system_prompt = ""
    ws_path = Path(workspace_dir).expanduser()
    _PROMPT_FILES = [
        "PREAMBLE.md", "IDENTITY.md", "SOUL.md", "EGO.md", "USER.md",
        "AGENTS.md", "MEMORY.md", "ROLE-TYPES.md", "SELF-CHECK.md",
        "LIFECYCLE.md", "TRIGGERS.md", "ONBOARDING.md",
    ]
    prompt_parts = []
    for fname in _PROMPT_FILES:
        fpath = ws_path / fname
        if fpath.exists():
            content = fpath.read_text(encoding="utf-8")
            prompt_parts.append(f"## {fname}\n{content}")
    if prompt_parts:
        system_prompt = "\n\n---\n\n".join(prompt_parts)

    # 尝试读取 workspace 的 config.yaml 覆盖
    ws_config_file = ws_path / "config.yaml"
    if ws_config_file.exists():
        import yaml as _ws_yaml
        try:
            with open(ws_config_file, "r", encoding="utf-8") as f:
                ws_cfg = _ws_yaml.safe_load(f) or {}
            # 只覆盖 brain 和 evolution 配置（provider 由全局管理）
            if "brain" in ws_cfg:
                for k, v in ws_cfg["brain"].items():
                    if hasattr(cfg.brain, k):
                        setattr(cfg.brain, k, v)
        except Exception:
            pass  # workspace config 解析失败不影响启动

    # 加载 toolset 中的工具
    try:
        from ..tools import get_tools_dict
        from ..tools.toolsets import get_toolset
        allowed = get_toolset(toolset)
        all_tools = get_tools_dict()
        tools_dict = {name: tool for name, tool in all_tools.items() if name in allowed}
    except Exception:
        tools_dict = {}

    # 创建 AgentLoop
    loop = AgentLoop(
        provider=provider,
        brain=brain,
        tools=tools_dict,
        system_prompt=system_prompt,
        workspace_dir=str(ws_path),
    )

    # REPL
    while True:
        try:
            user_input = Prompt.ask("[bold blue]你[/bold blue]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]👋 再见！[/dim]")
            break

        if user_input.strip() in ("/quit", "/exit", "exit", "quit"):
            console.print("[dim]👋 再见！[/dim]")
            break

        # /context 诊断命令
        if user_input.strip() in ("/context", "/context detail"):
            _show_context_detail(loop, system_prompt)
            continue

        if not user_input.strip():
            continue

        try:
            reply = await loop.chat(user_input)
            console.print(f"[bold green]AI[/bold green]> {reply}\n")
        except Exception as e:
            error_msg = str(e)
            if "401" in error_msg or "Unauthorized" in error_msg or "invalid" in error_msg.lower():
                console.print("[red]❌ API 密钥验证失败，请检查配置中的 api_key[/red]\n")
            elif "timeout" in error_msg.lower() or "connect" in error_msg.lower():
                console.print("[red]❌ 网络连接失败，请检查网络或 API 地址[/red]\n")
            else:
                console.print(f"[red]❌ 请求失败: {error_msg}[/red]\n")

    # 退出时关闭 brain 连接，避免 aiosqlite event loop closed 报错
    if brain:
        try:
            await brain.close()
        except Exception:
            pass


def _show_context_detail(loop, system_prompt: str):
    """显示当前 context window 的组成"""
    from ..agent.session import _estimate_tokens

    sys_tokens = _estimate_tokens(system_prompt)

    # 获取对话历史 token
    history = getattr(loop, "_history", []) or getattr(loop, "messages", [])
    history_tokens = sum(_estimate_tokens(m.get("content", "") or "") for m in history)
    msg_count = len(history)

    # 获取 memory context tokens（如有）
    memory_ctx = getattr(loop, "_memory_context", "") or ""
    memory_tokens = _estimate_tokens(memory_ctx)

    max_tokens = getattr(loop, "max_tokens", 128000) or 128000
    total = sys_tokens + memory_tokens + history_tokens
    available = max(0, max_tokens - total)

    console.print(Panel("📊 Context Window 组成", style="bold cyan"))
    console.print(f"  System prompt:       {sys_tokens:>6} tokens")
    console.print(f"  Memory context:      {memory_tokens:>6} tokens")
    console.print(f"  Conversation history: {history_tokens:>6} tokens ({msg_count} messages)")
    console.print(f"  Available budget:    {available:>6} tokens")
    console.print(f"  Total:               {total:>6} / {max_tokens} tokens")
    console.print()


@click.command()
@click.option("--channel", "-c", default=None, help="指定渠道 (feishu/dingtalk)")
@click.option("--host", default=None, help="绑定地址")
@click.option("--port", "-p", default=None, type=int, help="端口号")
def run(channel: Optional[str], host: Optional[str], port: Optional[int]):
    """启动渠道网关服务"""
    cfg = LeaperConfig.load()
    if not cfg.provider.api_key:
        console.print("[red]❌ 未找到配置，请先运行 leaper-cn init[/red]")
        raise SystemExit(1)

    from ..gateway import Gateway

    # 构建 gateway config
    gw_config: dict = {
        "host": host or "0.0.0.0",
        "port": port or 8080,
        "channels": {},
    }

    # 从 channel config 或命令行参数决定渠道
    ch_type = channel or cfg.channel.type
    if ch_type and ch_type != "cli":
        gw_config["channels"][ch_type] = cfg.channel.extra

    console.print(Panel(f"🚀 启动网关服务", style="bold green"))
    console.print(f"[dim]地址: {gw_config['host']}:{gw_config['port']}[/dim]")
    if gw_config["channels"]:
        console.print(f"[dim]渠道: {', '.join(gw_config['channels'].keys())}[/dim]")
    else:
        console.print("[yellow]⚠️  未配置渠道，仅健康检查端点可用[/yellow]")
    console.print("[dim]Ctrl+C 停止服务[/dim]\n")

    try:
        gateway = Gateway(gw_config)
        gateway.setup_from_config()
        gateway.run()
    except KeyboardInterrupt:
        console.print("\n[dim]🛑 服务已停止[/dim]")
    except Exception as e:
        console.print(f"[red]❌ 网关启动失败: {e}[/red]")
        raise SystemExit(1)


@click.command()
@click.option("--port", default=8765, help="服务端口")
@click.option("--brain", default=None, help="brain.db 路径")
def console_cmd(port: int, brain: Optional[str]):
    """启动 Brain Console 知识库可视化 Web UI"""
    from ..console import create_console_app

    if brain is None:
        brain = str(Path.home() / ".leaper-cn" / "brain.db")

    brain_path = Path(brain)
    if not brain_path.exists():
        console.print(f"[red]✗ 数据库不存在: {brain_path}[/red]")
        raise SystemExit(1)

    async def _run():
        runner = await create_console_app(str(brain_path), port=port)
        try:
            while True:
                await asyncio.sleep(3600)
        except (KeyboardInterrupt, asyncio.CancelledError):
            await runner.cleanup()

    console.print(f"[bold green]🧠 Brain Console[/bold green] → http://127.0.0.1:{port}")
    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[dim]已关闭[/dim]")


@click.command()
@click.option("--host", default="0.0.0.0", help="绑定地址")
@click.option("--port", "-p", default=8080, type=int, help="端口号")
@click.option("--toolset", "-t", default="standard", help="工具集")
@click.option("--agent", "-a", "agent_name", default=None, help="指定 Agent 名称")
def serve(host: str, port: int, toolset: str, agent_name: Optional[str]):
    """使用 AgentRunner 启动网关服务"""
    cfg = LeaperConfig.load()
    if not cfg.provider.api_key:
        console.print("[red]❌ 未找到配置，请先运行 leaper-cn init[/red]")
        raise SystemExit(1)

    ws_dir = cfg.agent.workspace
    if agent_name:
        from ..agent.multi import MultiAgentManager
        config_dir = str(Path(DEFAULT_CONFIG_PATH).parent)
        manager = MultiAgentManager(config_dir=config_dir)
        try:
            ws_dir = manager._agent_configs[agent_name]["workspace"]
        except KeyError:
            console.print(f"[red]❌ Agent 不存在: {agent_name}[/red]")
            raise SystemExit(1)

    console.print(Panel(f"🚀 AgentRunner Gateway 模式", style="bold green"))
    console.print(f"[dim]地址: {host}:{port} | 工具集: {toolset}[/dim]")

    async def _serve():
        from ..agent.runner import AgentRunner
        runner = AgentRunner(config=cfg, workspace_dir=ws_dir)
        await runner.initialize(toolset=toolset)
        await runner.run_gateway({"host": host, "port": port})

    try:
        asyncio.run(_serve())
    except KeyboardInterrupt:
        console.print("\n[dim]🛑 服务已停止[/dim]")
