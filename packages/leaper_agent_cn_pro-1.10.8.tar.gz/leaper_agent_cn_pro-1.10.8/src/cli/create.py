"""create 命令 — 创建 Agent / Office"""
import asyncio
import sys
from pathlib import Path
from typing import Optional

import click
from rich.prompt import Prompt
from rich.panel import Panel

from . import console, INDUSTRIES, INDUSTRY_MAP, TEMPLATE_ROLES, PROVIDER_DEFAULTS, resolve_industry
from ..config import LeaperConfig, DEFAULT_CONFIG_PATH


@click.command()
@click.argument("name", required=False, default=None)
@click.option("--name", "-n", "opt_name", default=None, help="Agent 名称")
@click.option("--template", "-t", "template", default=None, help="角色模板 (cto/cpo/cfo/cmo/coo/cso/cco/chro/clo/ceo-coach)")
@click.option("--industry", "industry_opt", default=None, help="行业名称 (如 AI, 互联网) 或编号，省略时交互选择")
def create(name: Optional[str], opt_name: Optional[str], template: Optional[str], industry_opt: Optional[str]):
    """交互式创建 Agent

    支持: leaper-cn create / leaper-cn create my-agent --template cto / leaper-cn create --name my-agent --template cto
    """
    from ..templates.deployer import TemplateDeployer

    console.print(Panel("🤖 创建新 Agent", style="bold green"))

    # Resolve role from --template or interactive
    role = template
    if role:
        if role not in TEMPLATE_ROLES:
            console.print(f"[red]❌ 无效模板: {role}[/red]")
            console.print(f"[dim]可选: {', '.join(TEMPLATE_ROLES)}[/dim]")
            raise SystemExit(1)
    else:
        # 1. 选角色
        console.print("\n[bold]可选角色：[/bold]")
        for i, r in enumerate(TEMPLATE_ROLES, 1):
            console.print(f"  {i}. {r}")
        role_idx = Prompt.ask(
            "\n选择角色编号",
            default="1",
        )
        try:
            role = TEMPLATE_ROLES[int(role_idx) - 1]
        except (ValueError, IndexError):
            console.print("[red]❌ 无效的角色编号[/red]")
            raise SystemExit(1)

    # Resolve agent name: positional arg > --name > interactive
    agent_name = name or opt_name
    if not agent_name:
        agent_name = Prompt.ask("输入 Agent 名字", default=f"my-{role}")

    # 3. 选行业（可跳过）— industry 统一用英文 code 传给 deployer
    industry = None
    if industry_opt is not None:
        cn_name, en_code = resolve_industry(industry_opt)
        if en_code:
            industry = en_code
            console.print(f"[dim]行业: {cn_name} ({en_code})[/dim]")
        else:
            console.print(f"[yellow]⚠️ 未知行业: {industry_opt}，跳过行业选择[/yellow]")
    elif sys.stdin.isatty():
        console.print("\n[bold]可选行业（回车跳过）：[/bold]")
        for i, (cn, en) in enumerate(INDUSTRY_MAP, 1):
            console.print(f"  {i}. {cn} ({en})")
        industry_idx = Prompt.ask("\n选择行业编号", default="")
        if industry_idx.strip():
            cn_name, en_code = resolve_industry(industry_idx)
            if en_code:
                industry = en_code
            else:
                console.print("[yellow]⚠️ 无效编号，跳过行业选择[/yellow]")

    # 4. 用户信息
    user_name = Prompt.ask("你的名字（回车跳过）", default="")
    company_name = Prompt.ask("公司名称（回车跳过）", default="")
    user_info = {}
    if user_name.strip():
        user_info["Name"] = user_name.strip()
    if company_name.strip():
        user_info["Company"] = company_name.strip()

    # 5. 选 provider
    provider_name = Prompt.ask(
        "选择 LLM Provider",
        choices=["deepseek", "qwen", "zhipu", "moonshot"],
        default="deepseek",
    )

    # 4. 检查是否有配置，没有则要求输入 API key
    cfg = LeaperConfig.load()
    if not cfg.provider.api_key:
        api_key = Prompt.ask("输入 API Key", password=True)
        if not api_key.strip():
            console.print("[red]❌ API Key 不能为空[/red]")
            raise SystemExit(1)
        defaults = PROVIDER_DEFAULTS[provider_name]
        cfg.provider.name = provider_name
        cfg.provider.api_key = api_key.strip()
        cfg.provider.base_url = defaults["base_url"]
        cfg.provider.model = defaults["model"]
        cfg.save()
        console.print(f"[dim]配置已保存到 {DEFAULT_CONFIG_PATH}[/dim]")

    # 部署模板
    deployer = TemplateDeployer()
    workspace = deployer.deploy(
        role=role,
        agent_name=agent_name,
        industry=industry,
        user_info=user_info or None,
    )

    # 将 provider 配置写入工作区 config.yaml（修复 #init-bug: 模板注释导致认证失败）
    workspace_config = workspace / "config.yaml"
    if workspace_config.exists():
        import yaml
        try:
            wc = yaml.safe_load(workspace_config.read_text(encoding="utf-8")) or {}
        except Exception:
            wc = {}
        wc["provider"] = {
            "name": cfg.provider.name,
            "model": cfg.provider.model,
            "api_key": cfg.provider.api_key,
            "base_url": cfg.provider.base_url,
        }
        workspace_config.write_text(
            yaml.dump(wc, allow_unicode=True, default_flow_style=False),
            encoding="utf-8",
        )

    # 更新配置
    cfg.agent.name = agent_name
    cfg.agent.role = role
    cfg.agent.industry = industry or ""
    cfg.agent.workspace = str(workspace)
    cfg.save()

    # 灌入 Brain Seeds
    import asyncio

    try:
        seed_count = asyncio.run(deployer.import_brain_seeds(workspace, agent_name or role, industry=industry or ""))
        if seed_count > 0:
            console.print(f"  ✅ 预灌 {seed_count} 条行业知识到 Brain")
    except Exception as e:
        console.print(f"  [yellow]⚠️ Brain Seeds 灌入跳过: {e}[/yellow]")

    console.print(f"\n[green]✅ Agent 已创建: {workspace}[/green]")
    console.print(f"\n[bold]启动对话：[/bold]")
    console.print(f"  leaper-cn chat --agent {agent_name}")


@click.command()
def agents():
    """列出所有已创建的 Agent"""
    from ..agent.multi import MultiAgentManager

    cfg = LeaperConfig.load()
    config_dir = str(Path(DEFAULT_CONFIG_PATH).parent)
    manager = MultiAgentManager(config_dir=config_dir)
    agent_list = manager.list_agents()

    if not agent_list:
        console.print("[yellow]未发现任何 Agent，请先运行 leaper-cn create[/yellow]")
        return

    console.print(f"[bold]已创建的 Agent ({len(agent_list)} 个)：[/bold]\n")
    default_name = manager.get_default_agent()
    for a in agent_list:
        marker = " ⭐" if a["name"] == default_name else ""
        console.print(f"  • [bold]{a['name']}[/bold] (role: {a['role']}){marker}")
        console.print(f"    workspace: {a['workspace']}")


# --- Office 管理 ---

CXO_ROLES = ["ceo-coach", "cto", "cpo", "cfo", "cmo", "coo", "chro"]


@click.group("office")
def office_group():
    """🏢 Office 管理"""
    pass


@office_group.command("create")
@click.option("--industry", "industry_opt", default=None, help="行业名称或编号")
@click.option("--name", "office_name", default=None, help="Office 名称")
@click.option("--user-id", "user_id", default=None, help="用户 ID（默认用当前用户名）")
def office_create(industry_opt: str | None, office_name: str | None, user_id: str | None):
    """创建 Office（含 7 个 CXO Desk + 组织知识库）"""
    import os
    import uuid

    console.print(Panel("🏢 创建 Office", style="bold green"))

    # Resolve user_id
    if not user_id:
        user_id = os.environ.get("USER") or os.environ.get("USERNAME") or "default"

    # Resolve industry
    industry = None
    if industry_opt:
        cn_name, en_code = resolve_industry(industry_opt)
        if en_code:
            industry = en_code
            console.print(f"[dim]行业: {cn_name} ({en_code})[/dim]")
        else:
            console.print(f"[yellow]⚠️ 未知行业: {industry_opt}[/yellow]")
    elif sys.stdin.isatty():
        console.print("\n[bold]可选行业（回车跳过）：[/bold]")
        for i, (cn, en) in enumerate(INDUSTRY_MAP, 1):
            console.print(f"  {i}. {cn} ({en})")
        idx = Prompt.ask("\n选择行业编号", default="")
        if idx.strip():
            cn_name, en_code = resolve_industry(idx)
            if en_code:
                industry = en_code

    # Office 目录
    office_id = office_name or f"office-{user_id}"
    office_dir = Path.home() / ".leaper-cn" / "offices" / user_id
    office_dir.mkdir(parents=True, exist_ok=True)

    # 创建 brain.db（WAL 模式）
    import sqlite3
    brain_db_path = office_dir / "brain.db"
    conn = sqlite3.connect(str(brain_db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.close()
    console.print(f"  ✅ brain.db 已创建 (WAL 模式): {brain_db_path}")

    # 初始化 org cache.db
    async def _init_org():
        from ..brain.org_sync import OrgSyncManager
        org_dir = str(office_dir / "org")
        mgr = OrgSyncManager(cache_dir=org_dir)
        await mgr.initialize()
        await mgr.close()
        return org_dir

    org_dir = asyncio.run(_init_org())
    console.print(f"  ✅ org cache.db 已创建: {org_dir}")

    # 为 7 个 CXO 角色创建 Desk 目录
    desks_dir = office_dir / "desks"
    for role in CXO_ROLES:
        desk_dir = desks_dir / role
        desk_dir.mkdir(parents=True, exist_ok=True)
        # 创建基本 workspace 文件
        soul_file = desk_dir / "SOUL.md"
        if not soul_file.exists():
            soul_file.write_text(
                f"# {role.upper()} Desk\n\nRole: {role}\nIndustry: {industry or 'general'}\n",
                encoding="utf-8",
            )
    console.print(f"  ✅ 已创建 {len(CXO_ROLES)} 个 CXO Desk")

    # 写 office meta
    import json
    meta = {
        "office_id": office_id,
        "user_id": user_id,
        "industry": industry or "",
        "roles": CXO_ROLES,
        "created_at": datetime_now_iso(),
    }
    (office_dir / "office.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    console.print(f"\n[green]✅ Office 已创建: {office_dir}[/green]")
    console.print(f"  包含 {len(CXO_ROLES)} 个 Desk: {', '.join(CXO_ROLES)}")


def datetime_now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
