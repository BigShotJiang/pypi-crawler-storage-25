"""CLI 入口 — leaper-cn 命令行工具

拆分自原 src/cli.py，保持 entry point `src.cli:main` 不变。
"""
import os
os.environ.setdefault("PYTHONUTF8", "1")

import io
import sys


def _ensure_utf8_stdio():
    """Fix Windows terminals (cp1252 etc.) crashing on emoji output."""
    if sys.platform != "win32":
        return
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name)
        if (
            hasattr(stream, "buffer")
            and not isinstance(stream, io.TextIOWrapper)
            or (isinstance(stream, io.TextIOWrapper) and stream.encoding and stream.encoding.lower().replace("-", "") != "utf8")
        ):
            try:
                setattr(
                    sys,
                    name,
                    io.TextIOWrapper(stream.buffer, encoding="utf-8", errors="replace", line_buffering=stream.line_buffering),
                )
            except Exception:
                pass  # pytest capture or frozen env — skip

_ensure_utf8_stdio()

import click
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel

from ..config import LeaperConfig, DEFAULT_CONFIG_PATH

console = Console()

# Provider 默认模型映射
PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
    "deepseek": {"base_url": "https://api.deepseek.com/v1", "model": "deepseek-chat"},
    "qwen": {"base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1", "model": "qwen-max"},
    "zhipu": {"base_url": "https://open.bigmodel.cn/api/paas/v4", "model": "glm-4-flash"},
    "moonshot": {"base_url": "https://api.moonshot.cn/v1", "model": "moonshot-v1-8k"},
}

# 行业列表 — (中文显示名, 英文模板目录名)
INDUSTRY_MAP = [
    ("金融", "finance"),
    ("电商", "ecom"),
    ("教育科技", "edu"),
    ("医疗健康", "health"),
    ("汽车", "auto"),
    ("广告技术", "adtech"),
    ("农业", "agri"),
    ("企业服务(B2B)", "b2b"),
    ("建筑工程", "construction"),
    ("消费品", "consumer"),
    ("新能源", "energy"),
    ("健身运动", "fitness"),
    ("人力资源", "hr"),
    ("投资", "invest"),
    ("法律", "legal"),
    ("物流", "logistics"),
    ("文娱传媒", "media"),
    ("制造业", "mfg"),
    ("房地产", "realestate"),
    ("旅游", "travel"),
]

# 向后兼容：中文列表
INDUSTRIES = [name for name, _ in INDUSTRY_MAP]

# 英文→中文 / 中文→英文 双向映射
_INDUSTRY_CN_TO_EN = {name: code for name, code in INDUSTRY_MAP}
_INDUSTRY_EN_TO_CN = {code: name for name, code in INDUSTRY_MAP}

def resolve_industry(raw: str) -> tuple[str | None, str | None]:
    """解析行业输入，返回 (中文名, 英文code)。支持中文名、英文code、编号。"""
    if not raw or not raw.strip():
        return None, None
    raw = raw.strip()
    # 英文 code
    if raw in _INDUSTRY_EN_TO_CN:
        return _INDUSTRY_EN_TO_CN[raw], raw
    # 中文名
    if raw in _INDUSTRY_CN_TO_EN:
        return raw, _INDUSTRY_CN_TO_EN[raw]
    # 编号
    try:
        idx = int(raw) - 1
        if 0 <= idx < len(INDUSTRY_MAP):
            return INDUSTRY_MAP[idx]
    except ValueError:
        pass
    return None, None

# 模板角色列表
TEMPLATE_ROLES = ["cto", "cpo", "cfo", "cmo", "coo", "cso", "cco", "chro", "clo", "ceo-coach"]


@click.group()
@click.version_option(package_name="leaper-agent-cn")
def main():
    """Leaper Agent CN — 面向中国市场的自进化 AI Agent 框架"""
    _ensure_utf8_stdio()


@main.command()
def version():
    """显示版本"""
    from .. import __version__
    console.print(f"[bold]leaper-agent-cn[/bold] v{__version__}")


@main.command()
def init():
    """交互式初始化配置"""
    console.print(Panel("🚀 Leaper Agent CN 初始化配置", style="bold green"))

    provider_name = Prompt.ask(
        "选择 LLM Provider",
        choices=["deepseek", "qwen", "zhipu", "moonshot"],
        default="deepseek",
    )
    api_key = Prompt.ask("输入 API Key", password=True)

    if not api_key.strip():
        console.print("[red]❌ API Key 不能为空[/red]")
        raise SystemExit(1)

    defaults = PROVIDER_DEFAULTS[provider_name]
    model = Prompt.ask("模型名称", default=defaults["model"])

    cfg = LeaperConfig()
    cfg.provider.name = provider_name
    cfg.provider.api_key = api_key.strip()
    cfg.provider.base_url = defaults["base_url"]
    cfg.provider.model = model
    cfg.save()

    console.print(f"\n[green]✅ 配置已保存到 {DEFAULT_CONFIG_PATH}[/green]")


# 注册子模块的命令
from .create import create, agents, office_group  # noqa: E402
from .chat import chat, run, serve, console_cmd  # noqa: E402
from .doctor import doctor, status, upgrade  # noqa: E402
from .config_cmd import config_cmd, skills, schedule  # noqa: E402
from .brain_cmd import brain_group  # noqa: E402

main.add_command(create)
main.add_command(agents)
main.add_command(chat)
main.add_command(run)
main.add_command(serve)
main.add_command(console_cmd, "console")
main.add_command(doctor)
main.add_command(status)
main.add_command(upgrade)
main.add_command(config_cmd, "config")
main.add_command(brain_group, "brain")
main.add_command(office_group, "office")
main.add_command(skills)
main.add_command(schedule)


if __name__ == "__main__":
    main()
