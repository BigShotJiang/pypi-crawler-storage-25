"""Brain CLI — DeepBrain 知识库管理命令

leaper-cn brain stats    — 统计
leaper-cn brain search   — 关键词搜索
leaper-cn brain query    — 语义召回（recall）
leaper-cn brain import   — 导入知识文件
leaper-cn brain export   — 导出 JSON
leaper-cn brain clear    — 清空
leaper-cn brain entities — 实体图谱
"""

import asyncio
import json
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from ..config import LeaperConfig

console = Console()


def _get_db_path() -> Path:
    cfg = LeaperConfig.load()
    return Path(cfg.brain.db_path).expanduser()


def _check_db(db_path: Path) -> bool:
    if not db_path.exists():
        console.print("[yellow]brain.db 不存在，暂无记忆[/yellow]")
        return False
    return True


@click.group("brain")
def brain_group():
    """🧠 DeepBrain 知识库管理"""
    pass


@brain_group.command("stats")
def brain_stats():
    """显示知识库统计"""
    db_path = _get_db_path()
    if not _check_db(db_path):
        return

    import sqlite3
    conn = sqlite3.connect(str(db_path))

    # entries 统计
    try:
        entries_count = conn.execute("SELECT COUNT(*) FROM entries").fetchone()[0]
    except Exception:
        entries_count = 0

    # messages 统计
    try:
        messages_count = conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    except Exception:
        messages_count = 0

    # entities 统计
    try:
        entities_count = conn.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
    except Exception:
        entities_count = 0

    # relations 统计
    try:
        relations_count = conn.execute("SELECT COUNT(*) FROM relations").fetchone()[0]
    except Exception:
        relations_count = 0

    # embeddings 统计
    try:
        embeddings_count = conn.execute("SELECT COUNT(*) FROM embeddings").fetchone()[0]
    except Exception:
        embeddings_count = 0

    # 按 category 分组
    try:
        categories = conn.execute(
            "SELECT category, COUNT(*) FROM entries GROUP BY category ORDER BY COUNT(*) DESC"
        ).fetchall()
    except Exception:
        categories = []

    # 文件大小
    size_bytes = db_path.stat().st_size
    if size_bytes < 1024:
        size_str = f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        size_str = f"{size_bytes / 1024:.1f} KB"
    else:
        size_str = f"{size_bytes / (1024 * 1024):.1f} MB"

    conn.close()

    console.print("[bold]🧠 DeepBrain 统计[/bold]\n")
    console.print(f"  知识条目:  {entries_count}")
    console.print(f"  对话消息:  {messages_count}")
    console.print(f"  实体:      {entities_count}")
    console.print(f"  关系:      {relations_count}")
    console.print(f"  向量:      {embeddings_count}")
    console.print(f"  数据库大小: {size_str}")
    console.print(f"  路径:      {db_path}")

    if categories:
        console.print("\n  [bold]按类别：[/bold]")
        for cat, count in categories:
            console.print(f"    {cat or '(未分类)'}: {count} 条")


@brain_group.command("search")
@click.argument("query")
@click.option("--limit", "-n", default=10, help="返回条数")
def brain_search(query: str, limit: int):
    """关键词搜索知识"""
    db_path = _get_db_path()
    if not _check_db(db_path):
        return

    import sqlite3
    conn = sqlite3.connect(str(db_path))

    rows = conn.execute(
        "SELECT content, category, confidence, created_at FROM entries "
        "WHERE content LIKE ? ORDER BY confidence DESC LIMIT ?",
        (f"%{query}%", limit),
    ).fetchall()
    conn.close()

    if not rows:
        console.print(f"[yellow]未找到包含 '{query}' 的知识[/yellow]")
        return

    table = Table(title=f"搜索结果 ({len(rows)} 条)")
    table.add_column("内容", max_width=60)
    table.add_column("类别", width=12)
    table.add_column("置信度", width=8)
    table.add_column("时间", width=16)

    for content, category, confidence, created_at in rows:
        preview = content[:80] + "..." if len(content) > 80 else content
        table.add_row(
            preview,
            category or "-",
            f"{confidence:.2f}" if confidence else "-",
            (created_at or "")[:16],
        )

    console.print(table)


@brain_group.command("query")
@click.argument("question")
@click.option("--limit", "-n", default=5, help="返回条数")
@click.option("--db", "db_override", default=None, help="指定 brain.db 路径")
def brain_query(question: str, limit: int, db_override: str | None):
    """语义召回（recall）"""
    db_path = Path(db_override).expanduser() if db_override else _get_db_path()
    if not _check_db(db_path):
        return

    async def _query():
        from ..brain.engine import LeaperBrain

        brain = LeaperBrain(db_path=str(db_path), agent_id="cli")
        await brain.initialize()

        results = await brain.recall(question, limit=limit)
        await brain.close()
        return results

    results = asyncio.run(_query())

    if not results:
        console.print(f"[yellow]未找到与 '{question}' 相关的知识[/yellow]")
        return

    table = Table(title=f"召回结果 ({len(results)} 条)")
    table.add_column("内容", max_width=60)
    table.add_column("类别", width=12)
    table.add_column("相关度", width=8)

    for r in results:
        content = r.get("content", "")
        preview = content[:80] + "..." if len(content) > 80 else content
        table.add_row(
            preview,
            r.get("category", "-"),
            f"{r.get('score', 0):.3f}",
        )

    console.print(table)


@brain_group.command("import")
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--category", "-c", default="imported", help="知识类别")
@click.option("--entry-type", "-t", default="fact", help="条目类型: fact/preference/decision/insight")
@click.option("--confidence", default=0.8, help="置信度 (0-1)")
@click.option("--split/--no-split", default=True, help="按段落拆分")
@click.option("--namespace", "-n", default="", help="知识 namespace（如 industry/adtech, org/shared）")
@click.option("--db", "db_override", default=None, help="指定 brain.db 路径")
def brain_import(file_path: str, category: str, entry_type: str, confidence: float, split: bool, namespace: str, db_override: str | None):
    """导入知识文件到 DeepBrain

    支持 .md / .txt / .json 格式。
    默认按空行拆分段落，每段作为一条知识。
    """
    db_path = Path(db_override).expanduser() if db_override else _get_db_path()
    fp = Path(file_path)

    # 读取文件
    if fp.suffix == ".json":
        with open(fp, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            chunks = [item.get("content", str(item)) if isinstance(item, dict) else str(item) for item in data]
        else:
            chunks = [json.dumps(data, ensure_ascii=False)]
    else:
        with open(fp, "r", encoding="utf-8") as f:
            text = f.read()

        if split:
            # 按空行拆分段落
            raw_chunks = text.split("\n\n")
            chunks = [c.strip() for c in raw_chunks if c.strip() and len(c.strip()) > 10]
        else:
            chunks = [text.strip()]

    if not chunks:
        console.print("[yellow]文件内容为空或无有效段落[/yellow]")
        return

    async def _import():
        from ..brain.engine import LeaperBrain

        brain = LeaperBrain(db_path=str(db_path), agent_id="cli")
        await brain.initialize()

        imported = 0
        for chunk in chunks:
            try:
                await brain.store_entry(
                    entry_type=entry_type,
                    content=chunk,
                    category=category,
                    confidence=confidence,
                    namespace=namespace,
                )
                imported += 1
            except Exception as e:
                console.print(f"[red]跳过: {str(e)[:50]}[/red]")

        await brain.close()
        return imported

    imported = asyncio.run(_import())
    console.print(f"[green]✅ 成功导入 {imported}/{len(chunks)} 条知识到 {db_path}[/green]")


@brain_group.command("export")
@click.option("--output", "-o", default="brain_export.json", help="导出文件路径")
@click.option("--format", "fmt", type=click.Choice(["json", "md"]), default="json", help="导出格式")
def brain_export(output: str, fmt: str):
    """导出知识库"""
    db_path = _get_db_path()
    if not _check_db(db_path):
        return

    import sqlite3
    conn = sqlite3.connect(str(db_path))

    try:
        rows = conn.execute(
            "SELECT id, entry_type, content, category, confidence, status, created_at FROM entries"
        ).fetchall()
    except Exception:
        rows = []

    conn.close()

    if not rows:
        console.print("[yellow]知识库为空[/yellow]")
        return

    if fmt == "json":
        data = [
            {
                "id": r[0], "type": r[1], "content": r[2],
                "category": r[3], "confidence": r[4],
                "status": r[5], "created_at": r[6],
            }
            for r in rows
        ]
        with open(output, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    else:
        with open(output, "w", encoding="utf-8") as f:
            f.write("# DeepBrain Knowledge Export\n\n")
            for r in rows:
                f.write(f"## [{r[3] or 'uncategorized'}] {r[2][:50]}\n\n")
                f.write(f"{r[2]}\n\n")
                f.write(f"- Type: {r[1]}, Confidence: {r[4]}, Created: {r[6]}\n\n---\n\n")

    console.print(f"[green]✅ 已导出 {len(rows)} 条知识到 {output}[/green]")


@brain_group.command("entities")
@click.option("--limit", "-n", default=20, help="返回条数")
def brain_entities(limit: int):
    """查看实体图谱"""
    db_path = _get_db_path()
    if not _check_db(db_path):
        return

    import sqlite3
    conn = sqlite3.connect(str(db_path))

    # 实体
    try:
        entities = conn.execute(
            "SELECT id, name, entity_type, created_at FROM entities ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    except Exception:
        entities = []
        console.print("[yellow]entities 表不存在[/yellow]")
        conn.close()
        return

    if not entities:
        console.print("[yellow]暂无实体[/yellow]")
        conn.close()
        return

    table = Table(title=f"实体 ({len(entities)} 条)")
    table.add_column("名称", max_width=30)
    table.add_column("类型", width=15)
    table.add_column("ID", width=14)

    for eid, name, etype, created_at in entities:
        table.add_row(name or "-", etype or "-", eid[:12] + "..")

    console.print(table)

    # 关系
    try:
        relations = conn.execute(
            "SELECT e1.name, r.relation_type, e2.name "
            "FROM relations r "
            "JOIN entities e1 ON r.source_entity_id = e1.id "
            "JOIN entities e2 ON r.target_entity_id = e2.id "
            "LIMIT ?",
            (limit,),
        ).fetchall()
    except Exception:
        relations = []

    if relations:
        console.print()
        rel_table = Table(title=f"关系 ({len(relations)} 条)")
        rel_table.add_column("源", max_width=20)
        rel_table.add_column("关系", width=15)
        rel_table.add_column("目标", max_width=20)

        for src, rel, tgt in relations:
            rel_table.add_row(src or "-", rel or "-", tgt or "-")

        console.print(rel_table)

    conn.close()


@brain_group.command("clear")
@click.option("--yes", is_flag=True, help="跳过确认")
def brain_clear(yes: bool):
    """清空知识库（需确认）"""
    db_path = _get_db_path()
    if not _check_db(db_path):
        return

    if not yes:
        from rich.prompt import Prompt
        confirm = Prompt.ask("确认清空所有知识？此操作不可逆", choices=["yes", "no"], default="no")
        if confirm != "yes":
            console.print("[dim]已取消[/dim]")
            return

    import sqlite3
    conn = sqlite3.connect(str(db_path))

    tables = ["entries", "messages", "embeddings", "entities", "relations", "transitions", "profiles", "meta"]
    cleared = 0
    for t in tables:
        try:
            conn.execute(f"DELETE FROM {t}")
            cleared += 1
        except Exception:
            pass

    conn.commit()
    conn.close()
    console.print(f"[green]✅ 已清空 {cleared} 个表[/green]")


@brain_group.command("share")
@click.argument("entry_id")
@click.option("--to", "target_ns", required=True, help="目标 namespace（如 org/shared, role/cto）")
@click.option("--db", "db_override", default=None, help="指定 brain.db 路径")
def brain_share(entry_id: str, target_ns: str, db_override: str | None):
    """分享知识条目到指定 namespace"""
    db_path = Path(db_override).expanduser() if db_override else _get_db_path()
    if not _check_db(db_path):
        return

    import sqlite3
    conn = sqlite3.connect(str(db_path))

    # 查找条目
    row = conn.execute("SELECT id, content, category FROM entries WHERE id = ?", (entry_id,)).fetchone()
    if not row:
        # 尝试前缀匹配
        row = conn.execute(
            "SELECT id, content, category FROM entries WHERE id LIKE ? LIMIT 1",
            (f"{entry_id}%",),
        ).fetchone()
    if not row:
        console.print(f"[red]未找到条目: {entry_id}[/red]")
        conn.close()
        return

    # 更新 namespace
    conn.execute("UPDATE entries SET namespace = ? WHERE id = ?", (target_ns, row[0]))
    conn.commit()
    conn.close()

    preview = row[1][:60] + "..." if len(row[1]) > 60 else row[1]
    console.print(f"[green]✅ 已分享到 {target_ns}: {preview}[/green]")


@brain_group.command("org-import")
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--org-id", required=True, help="组织 ID")
@click.option("--namespace", "-n", default="org/shared", help="知识 namespace")
def brain_org_import(file_path: str, org_id: str, namespace: str):
    """导入文件到组织知识缓存"""

    async def _import():
        from ..brain.org_sync import OrgSyncManager
        mgr = OrgSyncManager()
        await mgr.initialize()
        count = await mgr.import_file(file_path, org_id=org_id, namespace=namespace)
        await mgr.close()
        return count

    count = asyncio.run(_import())
    console.print(f"[green]✅ 已导入 {count} 条组织知识 (org_id={org_id}, ns={namespace})[/green]")
