"""doctor / status / upgrade 命令 — 深度环境诊断"""
from __future__ import annotations

import os
import platform
import sqlite3
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import List, Optional, Tuple

import click
from rich.table import Table

from . import console
from ..config import LeaperConfig, DEFAULT_CONFIG_PATH, validate_config


# ── 诊断结果数据结构 ──────────────────────────────────────────────────


class DiagResult:
    """单项诊断结果"""
    __slots__ = ("label", "passed", "detail", "fix")

    def __init__(self, label: str, passed: bool, detail: str = "", fix: str = ""):
        self.label = label
        self.passed = passed
        self.detail = detail
        self.fix = fix  # 修复建议


class DiagCategory:
    """诊断分类"""

    def __init__(self, name: str, icon: str = "🔍"):
        self.name = name
        self.icon = icon
        self.results: List[DiagResult] = []

    def add(self, label: str, passed: bool, detail: str = "", fix: str = "") -> DiagResult:
        r = DiagResult(label, passed, detail, fix)
        self.results.append(r)
        return r

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed_count(self) -> int:
        return sum(1 for r in self.results if r.passed)

    @property
    def all_passed(self) -> bool:
        return all(r.passed for r in self.results)


# ── 各项检查函数 ──────────────────────────────────────────────────────


def _check_python_version(cat: DiagCategory) -> None:
    """Python 版本兼容性检查"""
    ver = sys.version_info
    ver_str = f"{ver.major}.{ver.minor}.{ver.micro}"

    # 最低要求 3.10
    ok_310 = ver >= (3, 10)
    cat.add(
        "Python >= 3.10",
        ok_310,
        ver_str,
        fix="" if ok_310 else "请升级 Python 到 3.10+: https://www.python.org/downloads/",
    )

    # 推荐 3.11+（性能提升 10-60%）
    ok_311 = ver >= (3, 11)
    cat.add(
        "Python >= 3.11 (推荐)",
        ok_311,
        ver_str,
        fix="" if ok_311 else "建议升级到 3.11+ 获得更好性能",
    )

    # 检查 64 位
    is_64 = sys.maxsize > 2**32
    cat.add(
        "64 位 Python",
        is_64,
        platform.architecture()[0],
        fix="" if is_64 else "建议使用 64 位 Python 以支持大内存",
    )


def _check_dependencies(cat: DiagCategory) -> None:
    """依赖库版本检查"""
    required_packages = [
        ("click", "8.0"),
        ("rich", "12.0"),
        ("yaml", "5.0"),        # PyYAML
        ("aiohttp", None),      # 可选
        ("httpx", None),        # 可选
        ("aiosqlite", None),    # 可选（brain 异步模式）
    ]

    for pkg_name, min_ver in required_packages:
        try:
            mod = __import__(pkg_name)
            ver = getattr(mod, "__version__", getattr(mod, "VERSION", "unknown"))
            if min_ver and ver != "unknown":
                # 简单版本比较
                try:
                    actual_parts = [int(x) for x in str(ver).split(".")[:2]]
                    min_parts = [int(x) for x in min_ver.split(".")[:2]]
                    ok = actual_parts >= min_parts
                except (ValueError, IndexError):
                    ok = True  # 无法解析时认为通过
            else:
                ok = True
            cat.add(
                f"依赖: {pkg_name}",
                ok,
                f"v{ver}" if ver != "unknown" else "已安装",
                fix="" if ok else f"请升级: pip install '{pkg_name}>={min_ver}'",
            )
        except ImportError:
            is_required = min_ver is not None
            cat.add(
                f"依赖: {pkg_name}",
                not is_required,
                "未安装" + ("（可选）" if not is_required else ""),
                fix=f"pip install {pkg_name}" if is_required else "",
            )


def _check_system_resources(cat: DiagCategory) -> None:
    """系统资源检查（CPU/RAM/Disk），纯标准库实现"""
    # CPU 核心数
    cpu_count = os.cpu_count() or 0
    cat.add(
        "CPU 核心数",
        cpu_count >= 2,
        f"{cpu_count} 核",
        fix="" if cpu_count >= 2 else "建议使用 2 核以上的机器",
    )

    # 内存检查（跨平台）
    mem_total_mb = _get_memory_mb()
    if mem_total_mb > 0:
        ok = mem_total_mb >= 512
        cat.add(
            "系统内存",
            ok,
            f"{mem_total_mb} MB",
            fix="" if ok else "建议至少 512MB 内存",
        )
    else:
        cat.add("系统内存", True, "无法检测（跳过）")

    # 磁盘空间
    disk_free_mb = _get_disk_free_mb()
    if disk_free_mb > 0:
        ok = disk_free_mb >= 100
        cat.add(
            "磁盘可用空间",
            ok,
            f"{disk_free_mb} MB",
            fix="" if ok else "磁盘空间不足 100MB，请清理空间",
        )
    else:
        cat.add("磁盘可用空间", True, "无法检测（跳过）")


def _get_memory_mb() -> int:
    """获取系统总内存（MB），失败返回 0"""
    try:
        if sys.platform == "win32":
            import ctypes
            kernel32 = ctypes.windll.kernel32
            c_ulong = ctypes.c_ulonglong
            # GlobalMemoryStatusEx
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", c_ulong),
                    ("ullAvailPhys", c_ulong),
                    ("ullTotalPageFile", c_ulong),
                    ("ullAvailPageFile", c_ulong),
                    ("ullTotalVirtual", c_ulong),
                    ("ullAvailVirtual", c_ulong),
                    ("ullAvailExtendedVirtual", c_ulong),
                ]
            stat = MEMORYSTATUSEX()
            stat.dwLength = ctypes.sizeof(stat)
            kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
            return int(stat.ullTotalPhys / 1024 / 1024)
        else:
            # Linux / macOS
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        return int(line.split()[1]) // 1024  # KB -> MB
            # macOS fallback
            import subprocess
            out = subprocess.check_output(["sysctl", "-n", "hw.memsize"], timeout=5)
            return int(out.strip()) // 1024 // 1024
    except Exception:
        return 0


def _get_disk_free_mb() -> int:
    """获取当前目录所在磁盘可用空间（MB），失败返回 0"""
    try:
        stat = os.statvfs(".") if hasattr(os, "statvfs") else None
        if stat:
            return int(stat.f_bavail * stat.f_frsize / 1024 / 1024)
        # Windows fallback
        import shutil
        total, used, free = shutil.disk_usage(".")
        return int(free / 1024 / 1024)
    except Exception:
        return 0


def _check_network(cat: DiagCategory, cfg: LeaperConfig) -> None:
    """网络连通性检查 — ping 各 provider API endpoint"""
    endpoints = {
        "DeepSeek": "https://api.deepseek.com",
        "通义千问": "https://dashscope.aliyuncs.com",
        "智谱 AI": "https://open.bigmodel.cn",
        "月之暗面": "https://api.moonshot.cn",
    }

    # 加上用户配置的 base_url
    if cfg.provider.base_url:
        url = cfg.provider.base_url.rstrip("/")
        endpoints[f"当前 Provider ({cfg.provider.name})"] = url

    for name, url in endpoints.items():
        ok, detail = _ping_url(url)
        cat.add(
            f"网络: {name}",
            ok,
            detail,
            fix="" if ok else f"检查网络连接或防火墙设置，确保可以访问 {url}",
        )

    # Ollama embedding 服务检查
    ollama_ok, ollama_detail = _ping_url("http://localhost:11434")
    cat.add(
        "Embedding: Ollama",
        True,  # Ollama 是可选的，不通过也不报错
        ollama_detail if ollama_ok else f"未运行（可选）",
    )


def _ping_url(url: str) -> Tuple[bool, str]:
    """ping 一个 URL，返回 (是否通, 详情)"""
    try:
        start = time.time()
        req = urllib.request.Request(url, method="HEAD")
        req.add_header("User-Agent", "leaper-cn-doctor/1.0")
        urllib.request.urlopen(req, timeout=5)
        elapsed = int((time.time() - start) * 1000)
        return True, f"{elapsed}ms"
    except urllib.error.HTTPError as e:
        # HTTP 错误也说明网络通
        return True, f"HTTP {e.code}"
    except urllib.error.URLError as e:
        return False, f"连接失败: {e.reason}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _check_workspace(cat: DiagCategory, cfg: LeaperConfig) -> None:
    """工作区完整性验证"""
    ws_path = Path(cfg.agent.workspace).expanduser()

    # 目录存在
    cat.add(
        "工作区目录",
        ws_path.exists(),
        str(ws_path),
        fix="" if ws_path.exists() else f"创建目录: mkdir -p {ws_path}",
    )

    if not ws_path.exists():
        return

    # 可写
    writable = os.access(str(ws_path), os.W_OK)
    cat.add(
        "工作区可写",
        writable,
        "可写" if writable else "只读",
        fix="" if writable else f"修改权限: chmod 755 {ws_path}",
    )

    # 必要子目录检查
    expected_subdirs = ["logs", "skills", ".cache"]
    for subdir in expected_subdirs:
        sub = ws_path / subdir
        exists = sub.exists()
        cat.add(
            f"子目录: {subdir}/",
            exists,
            "存在" if exists else "不存在",
            fix="" if exists else f"将在首次使用时自动创建",
        )

    # 核心文件完整性检查
    core_files = ["SOUL.md", "AGENTS.md", "USER.md", "MEMORY.md"]
    for fname in core_files:
        fpath = ws_path / fname
        exists = fpath.exists()
        cat.add(
            f"文件: {fname}",
            exists,
            "存在" if exists else "缺失",
            fix="" if exists else f"创建文件: touch {ws_path / fname}",
        )


def _check_brain_db(cat: DiagCategory, cfg: LeaperConfig) -> None:
    """brain.db 健康检查"""
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        cat.add(
            "brain.db",
            True,
            "不存在（首次 chat 时自动创建）",
        )
        return

    # 可读写
    rw = os.access(str(db_path), os.R_OK | os.W_OK)
    cat.add(
        "brain.db 权限",
        rw,
        "可读写" if rw else "权限不足",
        fix="" if rw else f"修改权限: chmod 644 {db_path}",
    )

    # SQLite 完整性检查
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.execute("PRAGMA integrity_check")
        result = cursor.fetchone()[0]
        ok = result == "ok"
        cat.add(
            "brain.db 完整性",
            ok,
            result,
            fix="" if ok else "数据库损坏，备份后删除重建: mv brain.db brain.db.bak",
        )

        # 记忆条数
        try:
            cursor = conn.execute("SELECT COUNT(*) FROM memories")
            count = cursor.fetchone()[0]
            cat.add("brain.db 记忆条数", True, f"{count} 条")
        except sqlite3.OperationalError:
            cat.add("brain.db 记忆表", False, "memories 表不存在",
                     fix="数据库结构异常，重新初始化: 删除 brain.db 重启应用")

        # 数据库文件大小
        size_mb = db_path.stat().st_size / 1024 / 1024
        ok = size_mb < 500
        cat.add(
            "brain.db 大小",
            ok,
            f"{size_mb:.1f} MB",
            fix="" if ok else "数据库过大，建议运行 VACUUM 或清理旧记忆",
        )

        # Schema 版本检查
        try:
            cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = {row[0] for row in cursor.fetchall()}
            expected_tables = {"memories"}
            has_core = expected_tables.issubset(tables)
            cat.add(
                "brain.db schema",
                has_core,
                f"表: {', '.join(sorted(tables))}" if tables else "无表",
                fix="" if has_core else "数据库缺少核心表，需重新初始化",
            )
        except sqlite3.Error:
            pass

        conn.close()
    except sqlite3.Error as e:
        cat.add("brain.db 连接", False, str(e),
                 fix="数据库文件损坏，备份后删除重建")


def _check_config(cat: DiagCategory, cfg: LeaperConfig) -> None:
    """配置文件验证"""
    # 配置文件存在
    cfg_exists = DEFAULT_CONFIG_PATH.exists()
    cat.add(
        "配置文件",
        cfg_exists,
        str(DEFAULT_CONFIG_PATH),
        fix="" if cfg_exists else "运行 leaper-cn init 创建配置",
    )

    # API Key
    has_key = bool(cfg.provider.api_key)
    masked = cfg._mask(cfg.provider.api_key) if has_key else "未设置"
    cat.add(
        "API Key",
        has_key,
        masked,
        fix="" if has_key else "运行 leaper-cn init 或编辑 leaper.yaml 设置 api_key",
    )

    # base_url 格式
    base_url = cfg.provider.base_url
    url_ok = base_url.startswith("http://") or base_url.startswith("https://")
    cat.add(
        "base_url 格式",
        url_ok,
        base_url or "未设置",
        fix="" if url_ok else "base_url 必须以 http:// 或 https:// 开头",
    )

    # validate_config
    issues = validate_config(cfg)
    cat.add(
        "配置完整性",
        len(issues) == 0,
        "; ".join(issues) if issues else "全部通过",
        fix="; ".join(issues) if issues else "",
    )

    # brain 开启状态
    cat.add("Brain 记忆功能", cfg.brain.enabled, "已启用" if cfg.brain.enabled else "已禁用")


# ── 输出格式化 ────────────────────────────────────────────────────────


def _render_category(cat: DiagCategory) -> None:
    """渲染一个诊断分类"""
    console.print(f"\n[bold]{cat.icon} {cat.name}[/bold]")

    for r in cat.results:
        icon = "✅" if r.passed else "❌"
        msg = f"  {icon} {r.label}"
        if r.detail:
            style = "dim" if r.passed else "yellow"
            msg += f"  [{style}]{r.detail}[/{style}]"
        console.print(msg)
        if not r.passed and r.fix:
            console.print(f"     💡 [cyan]{r.fix}[/cyan]")


def _render_summary_table(categories: List[DiagCategory]) -> None:
    """渲染汇总表格"""
    table = Table(title="诊断汇总", show_header=True)
    table.add_column("类别", style="bold")
    table.add_column("通过", justify="center")
    table.add_column("总计", justify="center")
    table.add_column("状态", justify="center")

    total_passed = 0
    total_all = 0

    for cat in categories:
        total_passed += cat.passed_count
        total_all += cat.total
        status = "[green]✅ 全部通过[/green]" if cat.all_passed else "[yellow]⚠️ 有问题[/yellow]"
        table.add_row(f"{cat.icon} {cat.name}", str(cat.passed_count), str(cat.total), status)

    table.add_row(
        "[bold]总计[/bold]",
        f"[bold]{total_passed}[/bold]",
        f"[bold]{total_all}[/bold]",
        "[green]✅[/green]" if total_passed == total_all else "[yellow]⚠️[/yellow]",
    )

    console.print()
    console.print(table)


# ── CLI 命令 ──────────────────────────────────────────────────────────


@click.command()
@click.option("--verbose", "-v", is_flag=True, help="显示详细信息")
@click.option("--fix", is_flag=True, help="自动修复可修复的问题")
def doctor(verbose: bool = False, fix: bool = False):
    """深度诊断运行环境，检查配置、依赖、网络、数据库"""
    console.print("[bold]🩺 Leaper Agent CN 深度环境诊断[/bold]")
    console.print(f"[dim]平台: {platform.system()} {platform.release()} | "
                  f"Python: {platform.python_version()} | "
                  f"时间: {time.strftime('%Y-%m-%d %H:%M:%S')}[/dim]")

    # 加载配置
    cfg_exists = DEFAULT_CONFIG_PATH.exists()
    cfg = LeaperConfig.load() if cfg_exists else LeaperConfig()

    categories: List[DiagCategory] = []

    # 1. Python 环境
    cat_py = DiagCategory("Python 环境", "🐍")
    _check_python_version(cat_py)
    categories.append(cat_py)

    # 2. 依赖库
    cat_dep = DiagCategory("依赖库", "📦")
    _check_dependencies(cat_dep)
    categories.append(cat_dep)

    # 3. 系统资源
    cat_sys = DiagCategory("系统资源", "💻")
    _check_system_resources(cat_sys)
    categories.append(cat_sys)

    # 4. 配置文件
    cat_cfg = DiagCategory("配置", "⚙️")
    _check_config(cat_cfg, cfg)
    categories.append(cat_cfg)

    # 5. 工作区
    cat_ws = DiagCategory("工作区", "📁")
    _check_workspace(cat_ws, cfg)
    categories.append(cat_ws)

    # 6. brain.db
    cat_db = DiagCategory("Brain 数据库", "🧠")
    _check_brain_db(cat_db, cfg)
    categories.append(cat_db)

    # 7. 网络连通性
    cat_net = DiagCategory("网络连通性", "🌐")
    _check_network(cat_net, cfg)
    categories.append(cat_net)

    # 渲染结果
    for cat in categories:
        _render_category(cat)

    # 汇总表格
    _render_summary_table(categories)

    # 自动修复
    if fix:
        _auto_fix(categories, cfg)

    # 最终结论
    total_p = sum(c.passed_count for c in categories)
    total_a = sum(c.total for c in categories)
    if total_p == total_a:
        console.print("\n[green bold]✅ 环境正常，所有检查通过！[/green bold]")
    else:
        failed = total_a - total_p
        console.print(f"\n[yellow bold]⚠️ {failed} 项检查未通过，请根据 💡 提示修复[/yellow bold]")


def _auto_fix(categories: List[DiagCategory], cfg: LeaperConfig) -> None:
    """自动修复可修复的问题"""
    console.print("\n[bold]🔧 自动修复[/bold]")
    fixed = 0

    # 创建工作区目录
    ws_path = Path(cfg.agent.workspace).expanduser()
    if not ws_path.exists():
        try:
            ws_path.mkdir(parents=True, exist_ok=True)
            console.print(f"  ✅ 创建工作区目录: {ws_path}")
            fixed += 1
        except OSError as e:
            console.print(f"  ❌ 无法创建工作区: {e}")

    # 创建子目录
    for subdir in ["logs", "skills", ".cache"]:
        sub = ws_path / subdir
        if not sub.exists():
            try:
                sub.mkdir(parents=True, exist_ok=True)
                console.print(f"  ✅ 创建子目录: {subdir}/")
                fixed += 1
            except OSError:
                pass

    # VACUUM brain.db
    db_path = Path(cfg.brain.db_path).expanduser()
    if db_path.exists():
        try:
            size_before = db_path.stat().st_size
            conn = sqlite3.connect(str(db_path))
            conn.execute("VACUUM")
            conn.close()
            size_after = db_path.stat().st_size
            if size_after < size_before:
                saved = (size_before - size_after) / 1024
                console.print(f"  ✅ brain.db VACUUM 完成，节省 {saved:.0f} KB")
                fixed += 1
        except Exception:
            pass

    if fixed == 0:
        console.print("  [dim]没有可自动修复的项目[/dim]")
    else:
        console.print(f"  [green]修复了 {fixed} 项[/green]")


@click.command()
def status():
    """显示当前 agent 状态"""
    from .. import __version__

    cfg = LeaperConfig.load()
    ws_path = Path(cfg.agent.workspace).expanduser()
    db_path = Path(cfg.brain.db_path).expanduser()

    console.print("[bold]📊 Agent 状态[/bold]\n")
    console.print(f"  版本:      v{__version__}")
    console.print(f"  Agent:     {cfg.agent.name} ({cfg.agent.role})")
    console.print(f"  行业:      {cfg.agent.industry or '(未设置)'}")
    console.print(f"  Provider:  {cfg.provider.name}")
    console.print(f"  模型:      {cfg.provider.model}")
    console.print(f"  配置文件:  {DEFAULT_CONFIG_PATH}")
    console.print(f"  Workspace: {ws_path}")

    # brain.db 记忆条数
    if db_path.exists():
        try:
            conn = sqlite3.connect(str(db_path))
            cur = conn.execute("SELECT COUNT(*) FROM memories")
            count = cur.fetchone()[0]
            conn.close()
            console.print(f"  记忆条数:  {count}")
        except Exception:
            console.print(f"  记忆条数:  (读取失败)")
    else:
        console.print(f"  记忆条数:  0 (数据库未创建)")


@click.command()
def upgrade():
    """检查并升级到最新版本"""
    from .. import __version__
    import subprocess

    console.print(f"[dim]当前版本: v{__version__}[/dim]")
    console.print("[dim]正在检查更新...[/dim]")

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--dry-run", "leaper-agent-cn"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if "already satisfied" in result.stdout.lower() or "already up-to-date" in result.stdout.lower():
            console.print(f"[green]✅ 已是最新版本 v{__version__}[/green]")
        else:
            console.print("[yellow]发现新版本，正在升级...[/yellow]")
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", "leaper-agent-cn"],
                timeout=60,
            )
            console.print("[green]✅ 升级完成[/green]")
    except subprocess.TimeoutExpired:
        console.print("[red]❌ 检查更新超时[/red]")
    except Exception as e:
        console.print(f"[red]❌ 升级失败: {e}[/red]")
