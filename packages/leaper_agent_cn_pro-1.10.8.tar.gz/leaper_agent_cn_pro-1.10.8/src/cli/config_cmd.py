"""config / brain / skills / schedule 命令"""
import json
from pathlib import Path
from typing import Optional

import click
from rich.prompt import Prompt

from . import console
from ..config import LeaperConfig, DEFAULT_CONFIG_PATH


@click.command("config")
@click.argument("key", required=False, default=None)
@click.argument("value", required=False, default=None)
def config_cmd(key: Optional[str], value: Optional[str]):
    """查看或修改配置（支持 dot notation）"""
    cfg = LeaperConfig.load()

    if key is None:
        # 显示全部配置（脱敏）
        console.print("[bold]⚙️ 当前配置[/bold]\n")
        for k, v in cfg.to_display_dict().items():
            console.print(f"  {k} = {v}")
        return

    if value is None:
        # 读取单个配置
        val = cfg.get_nested(key)
        if val is None:
            console.print(f"[red]❌ 未知的配置项: {key}[/red]")
        else:
            # 脱敏输出 api_key
            if "key" in key.lower() or "secret" in key.lower() or "token" in key.lower():
                console.print(f"{key} = {cfg._mask(str(val))}")
            else:
                console.print(f"{key} = {val}")
        return

    # 设置配置
    ok = cfg.set_nested(key, value)
    if ok:
        cfg.save()
        console.print(f"[green]✅ {key} = {value}[/green]")
    else:
        console.print(f"[red]❌ 无法设置: {key}[/red]")


@click.group()
def brain():
    """记忆库管理"""
    pass


@brain.command("stats")
def brain_stats():
    """显示记忆库统计"""
    cfg = LeaperConfig.load()
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        console.print("[yellow]brain.db 不存在，暂无记忆[/yellow]")
        return

    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))

        total = conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]

        # 尝试按 tier 统计
        try:
            tiers = conn.execute(
                "SELECT tier, COUNT(*) FROM memories GROUP BY tier ORDER BY tier"
            ).fetchall()
        except Exception:
            tiers = []

        # 文件大小
        size_bytes = db_path.stat().st_size
        if size_bytes < 1024:
            size_str = f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            size_str = f"{size_bytes / 1024:.1f} KB"
        else:
            size_str = f"{size_bytes / (1024*1024):.1f} MB"

        conn.close()

        console.print("[bold]🧠 记忆库统计[/bold]\n")
        console.print(f"  总记忆数:  {total}")
        console.print(f"  数据库大小: {size_str}")
        console.print(f"  路径:      {db_path}")
        if tiers:
            console.print("\n  [bold]按层级：[/bold]")
            for tier, count in tiers:
                console.print(f"    L{tier}: {count} 条")
    except Exception as e:
        console.print(f"[red]❌ 读取失败: {e}[/red]")


@brain.command("search")
@click.argument("query")
def brain_search(query: str):
    """搜索记忆"""
    cfg = LeaperConfig.load()
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        console.print("[yellow]brain.db 不存在[/yellow]")
        return

    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))
        # 简单 LIKE 搜索
        rows = conn.execute(
            "SELECT content, created_at FROM memories WHERE content LIKE ? LIMIT 10",
            (f"%{query}%",),
        ).fetchall()
        conn.close()

        if not rows:
            console.print(f"[yellow]未找到包含 '{query}' 的记忆[/yellow]")
            return

        console.print(f"[bold]搜索结果 ({len(rows)} 条)：[/bold]\n")
        for content, created_at in rows:
            preview = content[:100] + "..." if len(content) > 100 else content
            console.print(f"  • {preview}")
            if created_at:
                console.print(f"    [dim]{created_at}[/dim]")
    except Exception as e:
        console.print(f"[red]❌ 搜索失败: {e}[/red]")


@brain.command("export")
@click.option("--output", "-o", default="brain_export.json", help="导出文件路径")
def brain_export(output: str):
    """导出记忆为 JSON"""
    cfg = LeaperConfig.load()
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        console.print("[yellow]brain.db 不存在[/yellow]")
        return

    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))
        rows = conn.execute("SELECT * FROM memories").fetchall()
        cols = [desc[0] for desc in conn.execute("SELECT * FROM memories LIMIT 0").description]
        conn.close()

        data = [dict(zip(cols, row)) for row in rows]
        with open(output, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)

        console.print(f"[green]✅ 已导出 {len(data)} 条记忆到 {output}[/green]")
    except Exception as e:
        console.print(f"[red]❌ 导出失败: {e}[/red]")


@brain.command("clear")
def brain_clear():
    """清空记忆库（需确认）"""
    cfg = LeaperConfig.load()
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        console.print("[yellow]brain.db 不存在[/yellow]")
        return

    confirm = Prompt.ask("确认清空所有记忆？此操作不可逆", choices=["yes", "no"], default="no")
    if confirm != "yes":
        console.print("[dim]已取消[/dim]")
        return

    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))
        conn.execute("DELETE FROM memories")
        conn.commit()
        conn.close()
        console.print("[green]✅ 记忆库已清空[/green]")
    except Exception as e:
        console.print(f"[red]❌ 清空失败: {e}[/red]")


# ---------- skills ----------

@click.group()
def skills():
    """技能管理"""
    pass


@skills.command("list")
def skills_list():
    """列出所有可用技能"""
    from ..skills import SkillManager

    manager = SkillManager()
    all_skills = manager.get_all_skills()

    if not all_skills:
        console.print("[yellow]未发现任何技能[/yellow]")
        return

    console.print(f"[bold]可用技能 ({len(all_skills)} 个)：[/bold]\n")
    for s in all_skills:
        triggers = ", ".join(s.triggers[:3]) if s.triggers else ""
        console.print(f"  • [bold]{s.name}[/bold] — {s.description}")
        if triggers:
            console.print(f"    触发词: {triggers}")


@skills.command("install")
@click.argument("path")
def skills_install(path: str):
    """从目录安装 skill"""
    from ..skills import SkillLoader
    import shutil

    src = Path(path).resolve()
    if not (src / "SKILL.md").exists():
        console.print(f"[red]❌ {path} 中未找到 SKILL.md[/red]")
        raise SystemExit(1)

    dest = Path.home() / ".leaper-cn" / "skills" / src.name
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copytree(str(src), str(dest), dirs_exist_ok=True)
    console.print(f"[green]✅ 技能已安装到 {dest}[/green]")


@skills.command("create")
def skills_create():
    """交互式创建新 skill"""
    name = Prompt.ask("技能名称")
    description = Prompt.ask("描述")
    triggers = Prompt.ask("触发词（逗号分隔）", default="")

    skill_dir = Path.home() / ".leaper-cn" / "skills" / name
    skill_dir.mkdir(parents=True, exist_ok=True)

    md = f"# {name}\n> {description}\n\n## Triggers\n"
    for t in triggers.split(","):
        t = t.strip()
        if t:
            md += f"- {t}\n"
    md += "\n## Parameters\n| Name | Type | Required | Description |\n|------|------|----------|-------------|\n"
    md += "\n## Script\nscript.py\n"

    (skill_dir / "SKILL.md").write_text(md, encoding="utf-8")
    (skill_dir / "script.py").write_text(
        '"""技能脚本"""\nimport json, sys\n\ndef main():\n    args = json.loads(sys.stdin.read())\n    print(json.dumps({"result": "TODO"}, ensure_ascii=False))\n\nif __name__ == "__main__":\n    main()\n',
        encoding="utf-8",
    )
    console.print(f"[green]✅ 技能已创建: {skill_dir}[/green]")


# ---------- schedule ----------

@click.group()
def schedule():
    """定时任务管理"""
    pass


@schedule.command("add")
@click.argument("description")
@click.option("--agent", "-a", default="default", help="目标 Agent ID")
@click.option("--cron", "-c", default=None, help="cron 表达式（留空则从描述解析）")
def schedule_add(description: str, agent: str, cron: Optional[str]):
    """添加定时任务（支持自然语言）

    例: leaper-cn schedule add "每天早上8点发日报" --agent ceo-coach
    """
    from ..scheduler.engine import Scheduler, parse_natural_language

    cron_expr = cron
    if not cron_expr:
        cron_expr = parse_natural_language(description)
        if not cron_expr:
            console.print("[red]❌ 无法从描述解析 cron 表达式，请用 --cron 手动指定[/red]")
            raise SystemExit(1)
        console.print(f"[dim]解析 cron: {cron_expr}[/dim]")

    s = Scheduler()
    job = s.add_job(name=description, cron_expr=cron_expr, agent_id=agent, payload=description)
    console.print("[green]✅ 已添加任务[/green]")
    console.print(f"  ID: {job.id}")
    console.print(f"  名称: {job.name}")
    console.print(f"  Cron: {job.cron_expr}")
    console.print(f"  Agent: {job.agent_id}")
    if job.next_run:
        console.print(f"  下次执行: {job.next_run}")


@schedule.command("list")
def schedule_list():
    """列出所有定时任务"""
    from ..scheduler.engine import Scheduler

    s = Scheduler()
    s._load_jobs()
    jobs = s.list_jobs()
    if not jobs:
        console.print("[dim]暂无定时任务[/dim]")
        return
    for j in jobs:
        status = "✅" if j.enabled else "⏸️"
        console.print(f"  {status} [{j.id}] {j.name}  cron={j.cron_expr}  agent={j.agent_id}")


@schedule.command("remove")
@click.argument("job_id")
def schedule_remove(job_id: str):
    """删除定时任务"""
    from ..scheduler.engine import Scheduler

    s = Scheduler()
    s._load_jobs()
    if s.remove_job(job_id):
        console.print(f"[green]✅ 已删除任务 {job_id}[/green]")
    else:
        console.print(f"[red]❌ 未找到任务 {job_id}[/red]")
