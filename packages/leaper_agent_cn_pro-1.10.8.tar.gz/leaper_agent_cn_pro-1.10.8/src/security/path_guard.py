"""路径安全守卫 — 路径遍历防护 + 符号链接检测 + 敏感目录保护"""

from __future__ import annotations

import os
import stat
from pathlib import Path
from typing import List, Optional, Set

from ..constants import SENSITIVE_PATHS


# ── 额外敏感目录模式 ──────────────────────────────────────────────────

_SENSITIVE_DIRS: List[str] = [
    # Unix
    "/etc/", "/boot/", "/root/", "/proc/", "/sys/",
    "/var/run/", "/var/log/",
    # Windows
    "C:\\Windows\\", "C:\\Program Files\\", "C:\\ProgramData\\",
    # 用户敏感目录
    "/.ssh/", "/.gnupg/", "/.aws/", "/.kube/",
    "/.docker/", "/.config/gcloud/",
]


def is_safe_path(path: str, workspace: str) -> bool:
    """检查路径是否安全

    规则：
    1. 不允许路径穿越（.. 逃逸 workspace）
    2. 不允许访问敏感路径
    3. 不允许符号链接指向 workspace 外
    4. 不允许 null 字节注入
    """
    if not path or not workspace:
        return False

    # null 字节注入检查
    if "\x00" in path or "\x00" in workspace:
        return False

    try:
        # 解析为绝对路径
        abs_workspace = os.path.abspath(workspace)
        abs_path = os.path.abspath(os.path.join(abs_workspace, path))

        # 检查路径穿越：解析后必须在 workspace 内
        if not abs_path.startswith(abs_workspace + os.sep) and abs_path != abs_workspace:
            return False

        # 检查敏感路径（用 / 归一化比对）
        normalized = abs_path.replace("\\", "/").lower()
        for sensitive in SENSITIVE_PATHS:
            if sensitive.lower() in normalized:
                return False

        # 检查敏感目录
        for sdir in _SENSITIVE_DIRS:
            if sdir.lower() in normalized:
                return False

        # 如果路径存在，检查符号链接
        if os.path.exists(abs_path):
            if os.path.islink(abs_path):
                real_path = os.path.realpath(abs_path)
                if not real_path.startswith(abs_workspace + os.sep) and real_path != abs_workspace:
                    return False
            # 检查中间目录的符号链接
            if _has_symlink_in_chain(abs_path, abs_workspace):
                return False

        return True
    except (OSError, ValueError):
        return False


def _has_symlink_in_chain(path: str, workspace: str) -> bool:
    """检查路径链中是否有指向 workspace 外部的符号链接"""
    try:
        parts = Path(path).parts
        current = Path(parts[0]) if parts else Path(".")
        for part in parts[1:]:
            current = current / part
            str_current = str(current)
            if os.path.islink(str_current):
                real = os.path.realpath(str_current)
                if not real.startswith(workspace + os.sep) and real != workspace:
                    return True
    except (OSError, ValueError):
        pass
    return False


def sanitize_path(path: str) -> str:
    """清理路径：移除 null 字节、危险字符、归一化

    不做安全判断，仅做格式清理。
    """
    if not path:
        return ""
    # 移除 null 字节
    cleaned = path.replace("\x00", "")
    # 移除控制字符（保留空格和正常可打印字符）
    cleaned = "".join(c for c in cleaned if ord(c) >= 32 or c in ("\t", "\n"))
    # 归一化
    cleaned = os.path.normpath(cleaned)
    return cleaned


def is_sensitive_path(path: str) -> bool:
    """检查路径是否在敏感路径/目录黑名单中"""
    if not path:
        return False
    normalized = path.replace("\\", "/").lower()
    for sensitive in SENSITIVE_PATHS:
        if sensitive.lower() in normalized:
            return True
    for sdir in _SENSITIVE_DIRS:
        if sdir.replace("\\", "/").lower() in normalized:
            return True
    return False


def detect_symlink(path: str) -> Optional[str]:
    """检测符号链接，返回真实目标路径。非符号链接返回 None"""
    try:
        if os.path.islink(path):
            return os.path.realpath(path)
    except OSError:
        pass
    return None


def validate_path_component(name: str) -> bool:
    """验证路径组件名是否安全（无特殊字符注入）"""
    if not name:
        return False
    # 禁止 .. 和特殊字符
    if name in (".", ".."):
        return False
    # 禁止 null 字节和路径分隔符
    forbidden = set("\x00/\\:*?\"<>|")
    if any(c in forbidden for c in name):
        return False
    return True


def get_safe_relative_path(path: str, workspace: str) -> Optional[str]:
    """获取相对于 workspace 的安全路径，不安全返回 None"""
    if not is_safe_path(path, workspace):
        return None
    abs_ws = os.path.abspath(workspace)
    abs_path = os.path.abspath(os.path.join(abs_ws, path))
    try:
        return os.path.relpath(abs_path, abs_ws)
    except ValueError:
        return None
