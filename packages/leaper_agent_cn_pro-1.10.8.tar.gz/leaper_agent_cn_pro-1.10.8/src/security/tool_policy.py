"""Per-agent 工具策略 — 控制哪些 tool 可以执行

从 agent 的 config.yaml 中加载 policy，在 tool 执行前检查权限。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class ToolPolicy:
    """工具执行策略

    Attributes:
        allowed_tools: 允许执行的工具列表，None 表示全部允许
        denied_tools: 禁止执行的工具列表，None 表示不禁止
        require_approval: 需要审批才能执行的工具列表
    """
    allowed_tools: list[str] | None = None
    denied_tools: list[str] | None = None
    require_approval: list[str] | None = None

    def check(self, tool_name: str) -> tuple[bool, str]:
        """检查工具是否允许执行

        Args:
            tool_name: 工具名称

        Returns:
            (allowed, reason) — allowed=False 时 reason 说明原因
        """
        # 黑名单优先
        if self.denied_tools and tool_name in self.denied_tools:
            return False, f"工具 {tool_name} 在禁止列表中"

        # 白名单检查
        if self.allowed_tools is not None and tool_name not in self.allowed_tools:
            return False, f"工具 {tool_name} 不在允许列表中"

        return True, ""

    def needs_approval(self, tool_name: str) -> bool:
        """检查工具是否需要审批"""
        if self.require_approval and tool_name in self.require_approval:
            return True
        return False

    @classmethod
    def from_dict(cls, data: dict) -> "ToolPolicy":
        """从字典创建 ToolPolicy

        Args:
            data: 配置字典，支持 allowed_tools, denied_tools, require_approval

        Returns:
            ToolPolicy 实例
        """
        return cls(
            allowed_tools=data.get("allowed_tools"),
            denied_tools=data.get("denied_tools"),
            require_approval=data.get("require_approval"),
        )

    @classmethod
    def from_config_file(cls, config_path: str) -> "ToolPolicy":
        """从 config.yaml 加载工具策略

        Args:
            config_path: config.yaml 文件路径

        Returns:
            ToolPolicy 实例，文件不存在或无策略时返回全放行策略
        """
        path = Path(config_path)
        if not path.exists():
            return cls()

        try:
            import yaml
            with open(path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
        except ImportError:
            # 无 PyYAML，返回默认策略
            logger.debug("PyYAML 不可用，使用默认工具策略")
            return cls()
        except Exception as e:
            logger.warning("加载工具策略配置失败 %s: %s", config_path, e)
            return cls()

        policy_data = config.get("tool_policy", {})
        if not policy_data:
            return cls()

        return cls.from_dict(policy_data)
