"""操作审批机制 — 命令黑名单 + 分级审批 + 审批日志"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

from ..constants import RE_DANGEROUS_CMD, SENSITIVE_PATHS

logger = logging.getLogger("leaper.security.approval")


class ApprovalLevel(Enum):
    """审批级别"""
    AUTO_APPROVE = "auto_approve"    # 自动批准
    PROMPT_USER = "prompt_user"      # 需要用户确认
    DENY = "deny"                    # 直接拒绝


class ApprovalStatus(Enum):
    """审批结果状态"""
    APPROVED = "approved"
    DENIED = "denied"
    PENDING = "pending"


@dataclass
class ApprovalResult:
    """审批结果"""
    status: ApprovalStatus
    reason: str
    level: ApprovalLevel
    timestamp: float = field(default_factory=time.time)
    action_type: str = ""
    context_summary: str = ""

    @property
    def is_approved(self) -> bool:
        return self.status == ApprovalStatus.APPROVED

    @property
    def is_denied(self) -> bool:
        return self.status == ApprovalStatus.DENIED


# 操作类型定义
class ActionType(Enum):
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    FILE_DELETE = "file_delete"
    COMMAND_EXEC = "command_exec"
    NETWORK_REQUEST = "network_request"
    SYSTEM_MODIFY = "system_modify"
    CODE_EXECUTE = "code_execute"


# ── 命令黑名单（增强版）──────────────────────────────────────────────

# (正则, 描述, 级别)
_COMMAND_RULES: List[tuple] = [
    # 直接拒绝 — 极度危险
    (r"\brm\s+(-\w*)?rf\s+/\s*$", "递归删除根目录", ApprovalLevel.DENY),
    (r"\brm\s+(-\w*)?rf\s+/\s", "递归删除根目录下内容", ApprovalLevel.DENY),
    (r"\bmkfs\b", "创建文件系统", ApprovalLevel.DENY),
    (r"\bdd\s+.*of=/dev/", "直接写入块设备", ApprovalLevel.DENY),
    (r">\s*/dev/sd[a-z]", "直接写入磁盘设备", ApprovalLevel.DENY),
    (r"\bchmod\s+777\s+/\s*$", "修改根目录权限为 777", ApprovalLevel.DENY),
    (r"\bcurl\b.*\|\s*\b(bash|sh)\b", "远程代码执行（curl pipe bash）", ApprovalLevel.DENY),
    (r"\bwget\b.*\|\s*\b(bash|sh)\b", "远程代码执行（wget pipe bash）", ApprovalLevel.DENY),
    # 需确认 — 有风险但可能合理
    (r"\brm\s+(-\w*)?rf\b", "递归强制删除", ApprovalLevel.PROMPT_USER),
    (r"\bformat\b", "格式化命令", ApprovalLevel.PROMPT_USER),
    (r"\bshutdown\b", "关机命令", ApprovalLevel.PROMPT_USER),
    (r"\breboot\b", "重启命令", ApprovalLevel.PROMPT_USER),
    (r"\bdel\s+/[sfq]", "Windows 强制删除", ApprovalLevel.PROMPT_USER),
    (r"\bsudo\s+rm\b", "sudo 删除", ApprovalLevel.PROMPT_USER),
    (r"\bkill\s+-9\b", "强制终止进程", ApprovalLevel.PROMPT_USER),
    (r"\bchown\b.*\s+/", "修改根目录文件所有者", ApprovalLevel.PROMPT_USER),
    (r"\biptables\b", "防火墙规则修改", ApprovalLevel.PROMPT_USER),
    (r"\bsystemctl\s+(stop|disable|mask)\b", "停止/禁用系统服务", ApprovalLevel.PROMPT_USER),
    (r"\breg\s+(delete|add)\b", "修改 Windows 注册表", ApprovalLevel.PROMPT_USER),
    (r"\bnet\s+stop\b", "停止 Windows 服务", ApprovalLevel.PROMPT_USER),
]

# 系统文件路径模式
_SYSTEM_FILE_PATTERNS = [
    re.compile(r"^/etc/", re.IGNORECASE),
    re.compile(r"^/usr/", re.IGNORECASE),
    re.compile(r"^/boot/", re.IGNORECASE),
    re.compile(r"^C:\\Windows\\", re.IGNORECASE),
    re.compile(r"^C:\\Program Files", re.IGNORECASE),
]

# 已知安全域名（自动批准网络请求）
_SAFE_DOMAINS = {
    "api.deepleaper.com",
    "portal.deepleaper.com",
    "dashscope.aliyuncs.com",
    "open.bigmodel.cn",
    "api.deepseek.com",
    "api.moonshot.cn",
}


class ApprovalEngine:
    """审批引擎 — 命令黑名单检查 + 分级审批 + 审批日志持久化"""

    def __init__(self, log_dir: Optional[str] = None):
        self._history: List[ApprovalResult] = []
        self._user_approved_actions: set = set()  # 用户已批准的操作签名
        self._log_dir = Path(log_dir) if log_dir else None
        # 预编译命令规则
        self._compiled_rules = [
            (re.compile(pat, re.IGNORECASE), desc, level)
            for pat, desc, level in _COMMAND_RULES
        ]

    def check_approval(
        self,
        action: "Union[ActionType, str]",
        context: Optional[dict] = None,
    ) -> "ApprovalResult":
        """检查操作是否需要审批"""
        ctx = context or {}

        # 兼容字符串输入
        if isinstance(action, str):
            # 尝试匹配为命令执行
            ctx.setdefault("command", action)
            action = ActionType.COMMAND_EXEC

        if action == ActionType.FILE_READ:
            result = self._check_file_read(ctx)
        elif action == ActionType.FILE_WRITE:
            result = self._check_file_write(ctx)
        elif action == ActionType.FILE_DELETE:
            result = self._check_file_delete(ctx)
        elif action == ActionType.COMMAND_EXEC:
            result = self._check_command(ctx)
        elif action == ActionType.NETWORK_REQUEST:
            result = self._check_network(ctx)
        elif action == ActionType.SYSTEM_MODIFY:
            result = ApprovalResult(
                status=ApprovalStatus.DENIED,
                reason="系统文件修改被禁止",
                level=ApprovalLevel.DENY,
            )
        elif action == ActionType.CODE_EXECUTE:
            result = self._check_code_execute(ctx)
        else:
            result = ApprovalResult(
                status=ApprovalStatus.PENDING,
                reason=f"未知操作类型: {action}",
                level=ApprovalLevel.PROMPT_USER,
            )

        # 填充元信息
        result.action_type = action.value if isinstance(action, ActionType) else str(action)
        result.context_summary = str(ctx)[:200]

        self._history.append(result)
        self._write_log(result)
        return result

    def approve_action(self, action_signature: str) -> None:
        """用户手动批准某个操作"""
        self._user_approved_actions.add(action_signature)
        logger.info("用户批准操作: %s", action_signature)

    def get_history(self) -> List[ApprovalResult]:
        """获取审批历史"""
        return list(self._history)

    def get_stats(self) -> Dict[str, int]:
        """获取审批统计"""
        stats: Dict[str, int] = {"approved": 0, "denied": 0, "pending": 0}
        for r in self._history:
            stats[r.status.value] = stats.get(r.status.value, 0) + 1
        return stats

    # ── 审批日志持久化 ────────────────────────────────────────────

    def _write_log(self, result: ApprovalResult) -> None:
        """写审批日志到文件"""
        if not self._log_dir:
            return
        try:
            self._log_dir.mkdir(parents=True, exist_ok=True)
            log_file = self._log_dir / "approval.log"
            entry = {
                "timestamp": result.timestamp,
                "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(result.timestamp)),
                "action": result.action_type,
                "status": result.status.value,
                "level": result.level.value,
                "reason": result.reason,
                "context": result.context_summary,
            }
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError:
            pass  # 日志写入失败不影响主流程

    def load_log(self) -> List[dict]:
        """加载审批日志"""
        if not self._log_dir:
            return []
        log_file = self._log_dir / "approval.log"
        if not log_file.exists():
            return []
        entries = []
        try:
            with open(log_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            entries.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        except OSError:
            pass
        return entries

    # ── 内部检查方法 ──────────────────────────────────────────────

    def _check_file_read(self, ctx: dict) -> ApprovalResult:
        path = ctx.get("path", "")
        normalized = path.replace("\\", "/").lower()
        for sensitive in SENSITIVE_PATHS:
            if sensitive.lower() in normalized:
                return ApprovalResult(
                    status=ApprovalStatus.DENIED,
                    reason=f"敏感路径禁止读取: {path}",
                    level=ApprovalLevel.DENY,
                )
        return ApprovalResult(
            status=ApprovalStatus.APPROVED,
            reason="文件读取自动批准",
            level=ApprovalLevel.AUTO_APPROVE,
        )

    def _check_file_write(self, ctx: dict) -> ApprovalResult:
        path = ctx.get("path", "")
        if self._is_system_file(path):
            return ApprovalResult(
                status=ApprovalStatus.DENIED,
                reason=f"系统文件禁止写入: {path}",
                level=ApprovalLevel.DENY,
            )
        return ApprovalResult(
            status=ApprovalStatus.APPROVED,
            reason="文件写入自动批准",
            level=ApprovalLevel.AUTO_APPROVE,
        )

    def _check_file_delete(self, ctx: dict) -> ApprovalResult:
        path = ctx.get("path", "")
        if self._is_system_file(path):
            return ApprovalResult(
                status=ApprovalStatus.DENIED,
                reason=f"系统文件禁止删除: {path}",
                level=ApprovalLevel.DENY,
            )
        return ApprovalResult(
            status=ApprovalStatus.PENDING,
            reason=f"删除文件需要确认: {path}",
            level=ApprovalLevel.PROMPT_USER,
        )

    def _check_command(self, ctx: dict) -> ApprovalResult:
        """增强版命令检查：使用分级规则"""
        command = ctx.get("command", "")

        # 遍历分级规则
        for pattern, desc, level in self._compiled_rules:
            if pattern.search(command):
                if level == ApprovalLevel.DENY:
                    return ApprovalResult(
                        status=ApprovalStatus.DENIED,
                        reason=f"危险命令被拒绝 [{desc}]: {command}",
                        level=ApprovalLevel.DENY,
                    )
                else:
                    return ApprovalResult(
                        status=ApprovalStatus.PENDING,
                        reason=f"危险命令需要确认 [{desc}]: {command}",
                        level=ApprovalLevel.PROMPT_USER,
                    )

        # 兼容旧的 RE_DANGEROUS_CMD
        if RE_DANGEROUS_CMD.search(command):
            return ApprovalResult(
                status=ApprovalStatus.PENDING,
                reason=f"危险命令需要确认: {command}",
                level=ApprovalLevel.PROMPT_USER,
            )

        return ApprovalResult(
            status=ApprovalStatus.APPROVED,
            reason="命令执行自动批准",
            level=ApprovalLevel.AUTO_APPROVE,
        )

    def _check_network(self, ctx: dict) -> ApprovalResult:
        url = ctx.get("url", "")
        logger.info("网络请求: %s", url)
        return ApprovalResult(
            status=ApprovalStatus.APPROVED,
            reason=f"网络请求自动批准（已记录）: {url}",
            level=ApprovalLevel.AUTO_APPROVE,
        )

    def _check_code_execute(self, ctx: dict) -> ApprovalResult:
        return ApprovalResult(
            status=ApprovalStatus.PENDING,
            reason="代码执行需要确认",
            level=ApprovalLevel.PROMPT_USER,
        )

    @staticmethod
    def _is_system_file(path: str) -> bool:
        for pattern in _SYSTEM_FILE_PATTERNS:
            if pattern.match(path):
                return True
        return False
