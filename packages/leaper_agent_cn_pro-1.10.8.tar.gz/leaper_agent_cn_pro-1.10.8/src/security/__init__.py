"""安全模块"""
from .sandbox import Sandbox, ResourceLimits, ExecutionResult
from .permissions import PermissionManager
from .path_guard import (
    is_safe_path, sanitize_path, is_sensitive_path,
    detect_symlink, validate_path_component, get_safe_relative_path,
)
from .url_guard import is_safe_url, normalize_url
from .approval import ApprovalEngine, ApprovalResult, ActionType, ApprovalLevel, ApprovalStatus
from .prompt_guard import scan_content

__all__ = [
    "Sandbox", "ResourceLimits", "ExecutionResult",
    "PermissionManager",
    "is_safe_path", "sanitize_path", "is_sensitive_path",
    "detect_symlink", "validate_path_component", "get_safe_relative_path",
    "is_safe_url", "normalize_url",
    "ApprovalEngine", "ApprovalResult", "ActionType", "ApprovalLevel", "ApprovalStatus",
    "scan_content",
]
