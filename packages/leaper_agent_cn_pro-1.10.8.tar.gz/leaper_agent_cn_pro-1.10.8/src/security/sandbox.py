"""沙箱执行 — 命令黑名单 + 进程隔离 + 文件系统/网络/资源限制"""

from __future__ import annotations

import asyncio
import os
import re
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set


# 危险命令黑名单(正则 + 描述)
_COMMAND_BLACKLIST: List[tuple] = [
    (r"\brm\s+(-\w*)?rf\s+/\s*$", "递归删除根目录"),
    (r"\brm\s+(-\w*)?rf\s+/\s", "递归删除根目录"),
    (r"\bformat\b", "格式化磁盘"),
    (r"\bshutdown\b", "关机命令"),
    (r"\breboot\b", "重启命令"),
    (r"\bmkfs\b", "创建文件系统"),
    (r"\bdd\s+.*of=/dev/", "直接写入设备"),
    (r">\s*/dev/sda", "直接写入设备"),
    (r"\bchmod\s+777\s+/", "修改根目录权限"),
    (r"\bcurl\b.*\|\s*\bbash\b", "远程代码执行"),
    (r"\bwget\b.*\|\s*\bbash\b", "远程代码执行"),
]

# 预编译黑名单正则
_COMPILED_BLACKLIST = [(re.compile(p, re.IGNORECASE), d) for p, d in _COMMAND_BLACKLIST]


@dataclass
class ResourceLimits:
    """资源限制配置"""
    max_memory_mb: int = 512        # 最大内存（MB）
    max_cpu_seconds: int = 30       # 最大 CPU 时间（秒）
    max_file_count: int = 100       # 最大文件数
    max_file_size_mb: int = 10      # 单文件最大大小（MB）
    max_output_bytes: int = 1024 * 1024  # 最大输出大小（1MB）
    allow_network: bool = True      # 是否允许网络访问
    use_temp_dir: bool = False      # 是否使用临时目录隔离
    allowed_env_vars: Optional[Set[str]] = None  # 允许传递的环境变量


@dataclass
class ExecutionResult:
    """执行结果"""
    output: str
    exit_code: int = 0
    duration_ms: int = 0
    was_timeout: bool = False
    was_blocked: bool = False
    blocked_reason: str = ""


class Sandbox:
    """沙箱执行器 — 文件系统 + 网络 + 进程权限 + 资源限制"""

    def __init__(
        self,
        allowed_dirs: Optional[List[str]] = None,
        blocked_dirs: Optional[List[str]] = None,
        timeout: int = 30,
        resource_limits: Optional[ResourceLimits] = None,
    ):
        """
        allowed_dirs: 允许访问的目录（默认为当前目录）
        blocked_dirs: 额外禁止访问的目录
        timeout: 执行超时时间(秒)
        resource_limits: 资源限制配置
        """
        if allowed_dirs:
            self._allowed_dirs = [os.path.abspath(d) for d in allowed_dirs]
        else:
            self._allowed_dirs = [os.getcwd()]
        self._blocked_dirs = [os.path.abspath(d) for d in (blocked_dirs or [])]
        self._timeout = timeout
        self._limits = resource_limits or ResourceLimits()

        # 执行历史（记录最近的执行）
        self._exec_history: List[Dict] = []
        self._max_history = 50

    # ── 文件系统访问控制 ──────────────────────────────────────────

    def check_file_access(self, path: str) -> bool:
        """检查文件路径是否在允许范围"""
        abs_path = os.path.abspath(path)

        # 检查黑名单目录
        for blocked in self._blocked_dirs:
            if abs_path.startswith(blocked):
                return False

        # 检查白名单目录
        return any(abs_path.startswith(d) for d in self._allowed_dirs)

    def check_file_size(self, path: str) -> bool:
        """检查文件大小是否在限制内"""
        try:
            size = os.path.getsize(path)
            return size <= self._limits.max_file_size_mb * 1024 * 1024
        except OSError:
            return True  # 文件不存在时放行

    # ── 命令安全检查 ──────────────────────────────────────────────

    def check_command(self, command: str) -> tuple:
        """检查命令安全性，返回 (是否允许, 原因)"""
        cmd_lower = command.strip().lower()
        for pattern, reason in _COMPILED_BLACKLIST:
            if pattern.search(cmd_lower):
                return False, reason
        return True, "通过"

    # ── 环境变量过滤 ──────────────────────────────────────────────

    def _build_env(self) -> dict:
        """构建沙箱环境变量"""
        env = os.environ.copy()

        # 如果限制网络，设置代理为无效地址
        if not self._limits.allow_network:
            env["http_proxy"] = "http://0.0.0.0:0"
            env["https_proxy"] = "http://0.0.0.0:0"
            env["no_proxy"] = ""

        # 如果设置了允许的环境变量白名单，只保留白名单中的
        if self._limits.allowed_env_vars is not None:
            # 保留 PATH 和基础变量
            base_vars = {"PATH", "SYSTEMROOT", "COMSPEC", "HOME", "USER", "TEMP", "TMP"}
            allowed = base_vars | self._limits.allowed_env_vars
            env = {k: v for k, v in env.items() if k in allowed}

        return env

    # ── 代码执行 ──────────────────────────────────────────────────

    async def execute_code(self, code: str, language: str = "python") -> str:
        """沙箱执行代码(subprocess + timeout)"""
        if language != "python":
            return f"不支持 {language} 语言执行"

        result = await self._run_in_sandbox(
            [sys.executable, "-c", code],
            use_shell=False,
        )

        if result.was_blocked:
            return f"执行被拒绝: {result.blocked_reason}"
        if result.was_timeout:
            return f"执行超时({self._timeout}秒)"
        return result.output

    async def execute_command(self, command: str) -> str:
        """沙箱执行命令"""
        allowed, reason = self.check_command(command)
        if not allowed:
            return f"命令被拒绝: {reason}"

        result = await self._run_in_sandbox(
            command,
            use_shell=True,
        )

        if result.was_timeout:
            return f"执行超时({self._timeout}秒)"
        return result.output

    # ── 内部执行引擎 ──────────────────────────────────────────────

    async def _run_in_sandbox(
        self,
        cmd,
        use_shell: bool = False,
    ) -> ExecutionResult:
        """统一的沙箱执行入口"""
        start_time = time.time()
        env = self._build_env()

        # 确定工作目录
        work_dir = None
        temp_dir_obj = None
        if self._limits.use_temp_dir:
            temp_dir_obj = tempfile.TemporaryDirectory(prefix="leaper_sandbox_")
            work_dir = temp_dir_obj.name

        try:
            if use_shell:
                proc = await asyncio.create_subprocess_shell(
                    cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=work_dir,
                    env=env,
                )
            else:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=work_dir,
                    env=env,
                )

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=self._timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                elapsed = int((time.time() - start_time) * 1000)
                result = ExecutionResult(
                    output=f"执行超时({self._timeout}秒)",
                    exit_code=-1,
                    duration_ms=elapsed,
                    was_timeout=True,
                )
                self._record_exec(cmd, result)
                return result

            # 截断过大输出
            stdout_bytes = stdout[:self._limits.max_output_bytes] if stdout else b""
            stderr_bytes = stderr[:self._limits.max_output_bytes] if stderr else b""

            output = stdout_bytes.decode(errors="replace")
            if stderr_bytes:
                output += "\n[stderr] " + stderr_bytes.decode(errors="replace")
            output = output.strip() or "(无输出)"

            elapsed = int((time.time() - start_time) * 1000)
            result = ExecutionResult(
                output=output,
                exit_code=proc.returncode or 0,
                duration_ms=elapsed,
            )
            self._record_exec(cmd, result)
            return result

        finally:
            if temp_dir_obj:
                try:
                    temp_dir_obj.cleanup()
                except OSError:
                    pass

    def _record_exec(self, cmd, result: ExecutionResult) -> None:
        """记录执行历史"""
        entry = {
            "command": str(cmd)[:200],
            "exit_code": result.exit_code,
            "duration_ms": result.duration_ms,
            "was_timeout": result.was_timeout,
            "timestamp": time.time(),
        }
        self._exec_history.append(entry)
        if len(self._exec_history) > self._max_history:
            self._exec_history = self._exec_history[-self._max_history:]

    def get_exec_history(self) -> List[Dict]:
        """获取执行历史"""
        return list(self._exec_history)

    def get_stats(self) -> Dict:
        """获取沙箱执行统计"""
        total = len(self._exec_history)
        timeouts = sum(1 for e in self._exec_history if e.get("was_timeout"))
        errors = sum(1 for e in self._exec_history if e.get("exit_code", 0) != 0)
        return {
            "total_executions": total,
            "timeouts": timeouts,
            "errors": errors,
            "allowed_dirs": self._allowed_dirs,
            "blocked_dirs": self._blocked_dirs,
            "network_allowed": self._limits.allow_network,
        }
