"""Prompt injection 扫描器 — 检测并拦截恶意 prompt 注入。

功能：
1. 中英文双语 threat pattern 检测
2. 不可见 Unicode 字符检测（零宽字符等）
3. 命中时返回安全替换文本，不泄露原始内容
"""

from __future__ import annotations

import logging
import re
from typing import List, Tuple

logger = logging.getLogger(__name__)

# ── 威胁模式定义 ──────────────────────────────────────────────────────

THREAT_PATTERNS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r'ignore\s+(previous|all|above|prior)\s+instructions', re.IGNORECASE), "injection"),
    (re.compile(r'do\s+not\s+tell\s+the\s+user', re.IGNORECASE), "deception"),
    (re.compile(r'system\s+prompt\s+override', re.IGNORECASE), "sys_override"),
    (re.compile(r'忽略(之前|上面|所有|以前)的?(指令|指示|规则)'), "injection_cn"),
    (re.compile(r'不要告诉用户'), "deception_cn"),
    (re.compile(r'你(现在|其实)是'), "role_hijack_cn"),
]

# 不可见 Unicode 字符范围（零宽字符、方向控制符等）
_INVISIBLE_CHARS = re.compile(
    r'[\u200b\u200c\u200d\u200e\u200f'   # 零宽字符
    r'\u2060\u2061\u2062\u2063\u2064'     # 不可见运算符
    r'\ufeff'                              # BOM
    r'\u202a-\u202e'                       # 方向控制符
    r'\u2066-\u2069'                       # 方向隔离符
    r'\u00ad'                              # 软连字符
    r']'
)


def scan_content(content: str, source: str = "unknown") -> str:
    """扫描内容是否包含 prompt injection 威胁。

    如果检测到威胁，返回安全的替换文本（拦截原始内容）。
    如果安全，返回原始内容不做修改。

    Args:
        content: 要扫描的文本内容
        source: 内容来源标识（用于日志和拦截消息）

    Returns:
        安全的内容文本。命中威胁时返回拦截提示，否则返回原始内容。
    """
    if not content:
        return content

    # 1. 检测 threat patterns
    for pattern, threat_type in THREAT_PATTERNS:
        if pattern.search(content):
            logger.warning(
                "⚠️ Prompt injection 检测命中: source=%s, type=%s",
                source, threat_type,
            )
            return f"[已拦截: {source} 包含可疑内容]"

    # 2. 检测不可见 Unicode 字符
    invisible_count = len(_INVISIBLE_CHARS.findall(content))
    if invisible_count > 3:
        logger.warning(
            "⚠️ 不可见字符检测命中: source=%s, count=%d",
            source, invisible_count,
        )
        return f"[已拦截: {source} 包含可疑内容]"

    return content
