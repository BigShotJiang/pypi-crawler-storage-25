"""轨迹压缩器 — 多级压缩 + 重要性评分 + 滑动窗口

功能：
1. 滑动窗口压缩 — 超过 token 限制时自动压缩旧消息
2. 重要性评分 — 标记关键转折点不压缩
3. 多级压缩 — L1 摘要 → L2 要点 → L3 关键词
4. 压缩元数据 — 记录原始消息数、压缩比、关键点

参考 Hermes trajectory_compressor.py 设计，纯标准库实现。
"""

from __future__ import annotations

import hashlib
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)


# ── 压缩前 memory flush ──────────────────────────────────

# 关键信息提取关键词
_FLUSH_KEYWORDS = [
    "偏好", "记住", "以后", "总是", "不要", "喜欢", "习惯",
    "prefer", "remember", "always", "never", "important",
    "结论", "决定", "确认",
]


async def flush_before_compression(messages: List[dict], brain: Any = None) -> None:
    """压缩前将重要信息保存到 brain。

    从即将被压缩的旧消息中提取关键信息（用户偏好、指令、重要结论），
    保存到 brain。如果 brain 不可用，静默跳过。

    Args:
        messages: 即将被压缩的消息列表
        brain: Brain 实例（可选）
    """
    if not brain or not hasattr(brain, "extract_and_learn"):
        return

    # 提取包含关键词的用户消息和助手回复
    important_pairs: List[Tuple[str, str]] = []
    for i, msg in enumerate(messages):
        if msg.get("role") != "user":
            continue
        content = str(msg.get("content", ""))
        content_lower = content.lower()
        if any(kw in content_lower or kw in content for kw in _FLUSH_KEYWORDS):
            # 找下一个 assistant 回复
            for j in range(i + 1, len(messages)):
                if messages[j].get("role") == "assistant" and messages[j].get("content"):
                    important_pairs.append((content[:300], str(messages[j]["content"])[:300]))
                    break

    # 批量保存到 brain
    for user_msg, assistant_msg in important_pairs[:5]:  # 最多 5 条
        try:
            await brain.extract_and_learn(user_msg, assistant_msg)
        except Exception:
            pass  # 静默失败


# ── Token 估算 ──────────────────────────────────────────

def _is_chinese(ch: str) -> bool:
    """判断是否为中文字符"""
    cp = ord(ch)
    return (0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF
            or 0x20000 <= cp <= 0x2A6DF or 0xF900 <= cp <= 0xFAFF)


def estimate_tokens(text: str) -> int:
    """估算 token 数：中文字 1 字 ≈ 2 token，英文 4 字符 ≈ 1 token。"""
    if not text:
        return 0
    chinese_count = sum(1 for ch in text if _is_chinese(ch))
    other_count = len(text) - chinese_count
    return chinese_count * 2 + other_count // 4


def estimate_messages_tokens(messages: List[dict]) -> int:
    """估算消息列表的总 token 数"""
    total = 0
    for msg in messages:
        content = msg.get("content") or ""
        if isinstance(content, str):
            total += estimate_tokens(content)
        # tool_calls 额外 token
        tool_calls = msg.get("tool_calls")
        if tool_calls:
            total += estimate_tokens(str(tool_calls))
        # 每条消息 role/metadata 约 4 token
        total += 4
    return total


# ── 压缩级别 ────────────────────────────────────────────

class CompressionLevel(Enum):
    """压缩级别"""
    NONE = 0      # 不压缩
    L1_SUMMARY = 1   # 摘要：保留主要内容和上下文
    L2_BULLET = 2    # 要点：只保留关键要点
    L3_KEYWORD = 3   # 关键词：最小化，只保留关键词


# ── 重要性评分 ──────────────────────────────────────────

# 重要性关键词（出现这些词的消息评分更高）
_IMPORTANCE_KEYWORDS = [
    # 决策相关
    "决定", "确认", "同意", "拒绝", "选择", "方案",
    "decide", "confirm", "approve", "reject",
    # 转折相关
    "但是", "然而", "不过", "其实", "实际上", "关键是",
    "however", "actually", "important", "critical",
    # 错误/问题
    "错误", "失败", "异常", "bug", "error", "fail", "exception",
    # 工具调用结果
    "成功", "完成", "已创建", "已修改",
    "success", "created", "modified", "done",
]

# 角色权重
_ROLE_WEIGHTS: Dict[str, float] = {
    "system": 1.0,      # system 消息始终重要
    "user": 0.6,        # 用户输入中等重要
    "assistant": 0.5,   # 助手回复基础重要
    "tool": 0.4,        # 工具输出可压缩性高
}


@dataclass
class ImportanceScore:
    """消息重要性评分"""
    score: float = 0.0          # 0.0 ~ 1.0
    reasons: List[str] = field(default_factory=list)
    is_pivot: bool = False       # 是否为关键转折点


def score_message_importance(msg: dict, index: int, total: int) -> ImportanceScore:
    """评估单条消息的重要性

    评分因子：
    1. 角色权重（system > user > assistant > tool）
    2. 关键词匹配
    3. 工具调用（含 tool_calls 的消息更重要）
    4. 位置权重（首尾消息更重要）
    5. 内容长度（太短的可能不重要，太长的信息量大）

    Args:
        msg: 消息字典
        index: 消息在列表中的位置
        total: 消息总数

    Returns:
        ImportanceScore 评分结果
    """
    result = ImportanceScore()
    role = msg.get("role", "user")
    content = str(msg.get("content") or "")

    # 1. 角色权重
    base_weight = _ROLE_WEIGHTS.get(role, 0.5)
    result.score = base_weight
    if base_weight >= 0.9:
        result.reasons.append(f"角色权重高({role})")

    # 2. 关键词匹配
    content_lower = content.lower()
    matched_keywords = [kw for kw in _IMPORTANCE_KEYWORDS if kw.lower() in content_lower]
    if matched_keywords:
        keyword_bonus = min(0.3, len(matched_keywords) * 0.05)
        result.score += keyword_bonus
        result.reasons.append(f"关键词: {', '.join(matched_keywords[:3])}")

    # 3. 工具调用
    if msg.get("tool_calls"):
        result.score += 0.15
        result.reasons.append("含工具调用")
    if role == "tool" and msg.get("tool_call_id"):
        # 工具返回结果，根据内容长度判断重要性
        if len(content) > 500:
            result.score += 0.1
            result.reasons.append("工具输出较长")

    # 4. 位置权重（首尾 10% 的消息更重要）
    if total > 0:
        position_ratio = index / max(total - 1, 1)
        if position_ratio < 0.1 or position_ratio > 0.9:
            result.score += 0.1
            result.reasons.append("位置靠近首/尾")

    # 5. 内容长度因子
    content_tokens = estimate_tokens(content)
    if content_tokens > 200:
        result.score += 0.05  # 长内容信息量大
    elif content_tokens < 10 and role != "system":
        result.score -= 0.1  # 极短内容可能不重要

    # 归一化到 [0, 1]
    result.score = max(0.0, min(1.0, result.score))

    # 判断是否为关键转折点（评分 > 0.75）
    if result.score >= 0.75:
        result.is_pivot = True
        result.reasons.append("关键转折点")

    return result


def score_messages(messages: List[dict]) -> List[ImportanceScore]:
    """批量评估消息重要性

    Args:
        messages: 消息列表

    Returns:
        与 messages 一一对应的评分列表
    """
    total = len(messages)
    return [score_message_importance(msg, i, total) for i, msg in enumerate(messages)]


# ── 多级压缩 ────────────────────────────────────────────

def _extract_topics(messages: List[dict], max_topics: int = 5) -> str:
    """从消息列表中提取主题（简化版：取 user 消息前 50 字符）。"""
    topics: List[str] = []
    for msg in messages:
        if msg.get("role") == "user" and msg.get("content"):
            text = str(msg["content"])[:50].replace("\n", " ")
            topics.append(text)
            if len(topics) >= max_topics:
                break
    return "; ".join(topics) if topics else "(无明确主题)"


def _extract_key_points(messages: List[dict], scores: List[ImportanceScore],
                         max_points: int = 5) -> List[str]:
    """提取关键转折点的内容摘要

    Args:
        messages: 消息列表
        scores: 对应的重要性评分
        max_points: 最多提取几个关键点

    Returns:
        关键点摘要列表
    """
    # 按评分排序，取最高的几条
    indexed = sorted(enumerate(scores), key=lambda x: x[1].score, reverse=True)
    points: List[str] = []

    for idx, sc in indexed[:max_points]:
        msg = messages[idx]
        content = str(msg.get("content") or "")[:100].replace("\n", " ")
        role = msg.get("role", "?")
        points.append(f"[{role}] {content}")

    return points


def compress_l1_summary(messages: List[dict],
                         scores: Optional[List[ImportanceScore]] = None) -> str:
    """L1 摘要压缩 — 保留主要内容和上下文

    生成结构化摘要，包含：
    - 对话轮次
    - 主要话题
    - 关键转折点
    - 工具调用概况

    Args:
        messages: 要压缩的消息列表
        scores: 重要性评分（可选，不传则自动计算）

    Returns:
        摘要文本
    """
    if not messages:
        return ""

    if scores is None:
        scores = score_messages(messages)

    topics = _extract_topics(messages)
    key_points = _extract_key_points(messages, scores)

    # 统计
    user_count = sum(1 for m in messages if m.get("role") == "user")
    tool_count = sum(1 for m in messages if m.get("tool_calls"))
    total_tokens = estimate_messages_tokens(messages)

    parts = [
        f"[L1 摘要] 原始 {len(messages)} 条消息, {user_count} 轮对话, "
        f"约 {total_tokens} token",
        f"主题: {topics}",
    ]

    if tool_count:
        parts.append(f"工具调用: {tool_count} 次")

    if key_points:
        parts.append("关键点:")
        for i, point in enumerate(key_points, 1):
            parts.append(f"  {i}. {point}")

    return "\n".join(parts)


def compress_l2_bullet(messages: List[dict],
                        scores: Optional[List[ImportanceScore]] = None) -> str:
    """L2 要点压缩 — 只保留关键要点

    比 L1 更精简，只列出要点。

    Args:
        messages: 要压缩的消息列表
        scores: 重要性评分

    Returns:
        要点文本
    """
    if not messages:
        return ""

    if scores is None:
        scores = score_messages(messages)

    topics = _extract_topics(messages, max_topics=3)
    key_points = _extract_key_points(messages, scores, max_points=3)

    parts = [
        f"[L2 要点] {len(messages)} 条消息压缩",
        f"话题: {topics}",
    ]

    for point in key_points:
        parts.append(f"• {point}")

    return "\n".join(parts)


def compress_l3_keyword(messages: List[dict]) -> str:
    """L3 关键词压缩 — 最小化，只保留关键词

    极限压缩，仅保留关键实体和操作词。

    Args:
        messages: 要压缩的消息列表

    Returns:
        关键词文本
    """
    if not messages:
        return ""

    # 收集所有内容
    all_content = []
    for msg in messages:
        content = str(msg.get("content") or "")
        if content:
            all_content.append(content)

    full_text = " ".join(all_content)

    # 提取关键词：简单频率统计（不引入 jieba）
    # 中文：提取 2-4 字词组（基于相邻中文字符）
    # 英文：提取 4+ 字母单词
    keywords: Dict[str, int] = {}

    # 英文单词
    for word in re.findall(r'[a-zA-Z]{4,}', full_text):
        w = word.lower()
        if w not in {"this", "that", "with", "from", "have", "been", "will",
                      "would", "could", "should", "about", "their", "there",
                      "which", "these", "those", "some", "other", "into"}:
            keywords[w] = keywords.get(w, 0) + 1

    # 中文：连续中文字符片段
    for segment in re.findall(r'[\u4e00-\u9fff]{2,6}', full_text):
        keywords[segment] = keywords.get(segment, 0) + 1

    # 按频率排序，取 top 15
    sorted_kw = sorted(keywords.items(), key=lambda x: x[1], reverse=True)
    top_keywords = [kw for kw, _ in sorted_kw[:15]]

    return f"[L3 关键词] {len(messages)} 条 → {', '.join(top_keywords)}"


# ── 压缩元数据 ──────────────────────────────────────────

@dataclass
class CompressionMeta:
    """压缩元数据"""
    original_count: int = 0          # 原始消息数
    compressed_count: int = 0        # 压缩后消息数
    original_tokens: int = 0         # 原始 token 数
    compressed_tokens: int = 0       # 压缩后 token 数
    compression_ratio: float = 0.0   # 压缩比 (0~1, 越小越好)
    level: CompressionLevel = CompressionLevel.NONE
    key_points: List[str] = field(default_factory=list)  # 保留的关键点
    pivot_count: int = 0             # 关键转折点数
    timestamp: float = 0.0          # 压缩时间

    def to_dict(self) -> dict:
        """序列化为字典"""
        return {
            "original_count": self.original_count,
            "compressed_count": self.compressed_count,
            "original_tokens": self.original_tokens,
            "compressed_tokens": self.compressed_tokens,
            "compression_ratio": round(self.compression_ratio, 3),
            "level": self.level.name,
            "key_points": self.key_points,
            "pivot_count": self.pivot_count,
            "timestamp": self.timestamp,
        }


# ── 滑动窗口压缩器 ──────────────────────────────────────

# 摘要模板
_SUMMARY_TEMPLATE = "[对话摘要] 以下是 {count} 条消息的压缩摘要：\n{summary}"


class TrajectoryCompressor:
    """轨迹压缩器 — 带滑动窗口和多级压缩

    使用方式：
        compressor = TrajectoryCompressor(max_tokens=100000)
        result = compressor.compress(messages)
        meta = compressor.last_meta  # 获取压缩元数据

    压缩策略：
    1. token 数 <= max_tokens → 不压缩
    2. 超出 → 按重要性评分，保留关键消息，压缩其余
    3. 压缩级别自动升级：L1 → L2 → L3，直到满足限制
    """

    def __init__(
        self,
        max_tokens: int = 100000,
        keep_recent: int = 20,
        pivot_threshold: float = 0.75,
        system_roles: Optional[set] = None,
        llm_fn=None,
        brain: Any = None,
    ):
        """
        Args:
            max_tokens: token 上限
            keep_recent: 始终保留最近 N 条对话消息（不含 system）
            pivot_threshold: 重要性评分阈值，高于此值的消息标记为转折点
            system_roles: 视为 system 的角色集合
            llm_fn: 可选的异步 LLM 调用函数，用于生成摘要。
                     签名: async (messages: list[dict]) -> str
            brain: 可选的 Brain 实例，压缩前 flush 重要信息
        """
        self.max_tokens = max_tokens
        self.keep_recent = keep_recent
        self.pivot_threshold = pivot_threshold
        self.system_roles = system_roles or {"system"}
        self.llm_fn = llm_fn
        self._brain = brain

        # 上次压缩的元数据
        self.last_meta: Optional[CompressionMeta] = None

        # 历史压缩记录（用于多级递进压缩）
        self._compression_history: List[CompressionMeta] = []

    def compress(self, messages: List[dict]):
        """执行压缩。当 llm_fn 存在时返回 coroutine，否则同步返回。

        Args:
            messages: 完整消息列表

        Returns:
            压缩后的消息列表
        """
        if self.llm_fn:
            return self._compress_async(messages)
        return self._compress_sync(messages)

    def _compress_sync(self, messages: List[dict]) -> List[dict]:
        """同步压缩（无 LLM）"""
        original_tokens = estimate_messages_tokens(messages)

        if original_tokens <= self.max_tokens:
            self.last_meta = CompressionMeta(
                original_count=len(messages),
                compressed_count=len(messages),
                original_tokens=original_tokens,
                compressed_tokens=original_tokens,
                compression_ratio=1.0,
                level=CompressionLevel.NONE,
                timestamp=time.time(),
            )
            return messages

        logger.info("当前 token 数 %d 超过限制 %d，开始压缩", original_tokens, self.max_tokens)

        system_msgs, conversation_msgs = self._split_messages(messages)

        if len(conversation_msgs) <= self.keep_recent:
            return messages

        # 对齐 tool 配对边界
        split_idx = len(conversation_msgs) - self.keep_recent
        split_idx = self._align_tool_boundary(conversation_msgs, split_idx)

        old_msgs = conversation_msgs[:split_idx]
        recent_msgs = conversation_msgs[split_idx:]

        if not old_msgs:
            return messages

        scores = score_messages(old_msgs)

        pivot_msgs: List[dict] = []
        compressible_msgs: List[dict] = []
        compressible_scores: List[ImportanceScore] = []

        for msg, sc in zip(old_msgs, scores):
            if sc.is_pivot and sc.score >= self.pivot_threshold:
                pivot_msgs.append(msg)
            else:
                compressible_msgs.append(msg)
                compressible_scores.append(sc)

        result = self._try_compress_levels(
            system_msgs=system_msgs,
            pivot_msgs=pivot_msgs,
            compressible_msgs=compressible_msgs,
            compressible_scores=compressible_scores,
            recent_msgs=recent_msgs,
            original_count=len(messages),
            original_tokens=original_tokens,
        )

        return result

    async def _compress_async(self, messages: List[dict]) -> List[dict]:
        """异步压缩（使用 LLM 生成摘要）"""
        original_tokens = estimate_messages_tokens(messages)

        if original_tokens <= self.max_tokens:
            self.last_meta = CompressionMeta(
                original_count=len(messages),
                compressed_count=len(messages),
                original_tokens=original_tokens,
                compressed_tokens=original_tokens,
                compression_ratio=1.0,
                level=CompressionLevel.NONE,
                timestamp=time.time(),
            )
            return messages

        logger.info("当前 token 数 %d 超过限制 %d，开始 LLM 摘要压缩", original_tokens, self.max_tokens)

        system_msgs, conversation_msgs = self._split_messages(messages)

        if len(conversation_msgs) <= self.keep_recent:
            return messages

        # 对齐 tool 配对边界
        split_idx = len(conversation_msgs) - self.keep_recent
        split_idx = self._align_tool_boundary(conversation_msgs, split_idx)

        old_msgs = conversation_msgs[:split_idx]
        recent_msgs = conversation_msgs[split_idx:]

        if not old_msgs:
            return messages

        # #6 压缩前 memory flush — 保存重要信息到 brain
        await flush_before_compression(old_msgs, getattr(self, '_brain', None))

        # 尝试 LLM 摘要
        try:
            summary = await self._llm_summarize(old_msgs)
            summary_msg = {"role": "system", "content": f"[对话历史摘要] {summary}"}
            result = system_msgs + [summary_msg] + recent_msgs
            new_tokens = estimate_messages_tokens(result)

            meta = CompressionMeta(
                original_count=len(messages),
                compressed_count=len(result),
                original_tokens=original_tokens,
                compressed_tokens=new_tokens,
                compression_ratio=new_tokens / max(original_tokens, 1),
                level=CompressionLevel.L1_SUMMARY,
                timestamp=time.time(),
            )
            self.last_meta = meta
            self._compression_history.append(meta)
            logger.info("LLM 摘要压缩完成: %d→%d 消息, %d→%d token",
                        len(messages), len(result), original_tokens, new_tokens)
            return result
        except Exception as e:
            logger.warning("LLM 摘要压缩失败，回退到本地压缩: %s", e)
            # Fallback 到同步压缩
            scores = score_messages(old_msgs)
            pivot_msgs: List[dict] = []
            compressible_msgs: List[dict] = []
            compressible_scores: List[ImportanceScore] = []
            for msg, sc in zip(old_msgs, scores):
                if sc.is_pivot and sc.score >= self.pivot_threshold:
                    pivot_msgs.append(msg)
                else:
                    compressible_msgs.append(msg)
                    compressible_scores.append(sc)
            return self._try_compress_levels(
                system_msgs=system_msgs,
                pivot_msgs=pivot_msgs,
                compressible_msgs=compressible_msgs,
                compressible_scores=compressible_scores,
                recent_msgs=recent_msgs,
                original_count=len(messages),
                original_tokens=original_tokens,
            )

    async def _llm_summarize(self, old_msgs: List[dict]) -> str:
        """调用 LLM 生成对话摘要"""
        # 构建摘要用的对话内容（截断过长的消息）
        conversation_text = []
        for msg in old_msgs:
            role = msg.get("role", "unknown")
            content = str(msg.get("content") or "")
            if len(content) > 300:
                content = content[:300] + "..."
            if role == "tool":
                tool_name = msg.get("name", "unknown")
                conversation_text.append(f"[工具 {tool_name} 返回]: {content}")
            else:
                conversation_text.append(f"[{role}]: {content}")

        conv_str = "\n".join(conversation_text[-30:])  # 最多取最近 30 条

        prompt_messages = [
            {"role": "system", "content": "你是一个对话摘要助手。请将以下对话历史压缩为简洁的摘要，保留关键信息、决策和结论。用中文输出。"},
            {"role": "user", "content": f"请将以下对话历史压缩为一段简洁的摘要（200字以内）：\n\n{conv_str}"},
        ]

        summary = await self.llm_fn(prompt_messages)
        return summary.strip() if summary else _extract_topics(old_msgs)

    @staticmethod
    def _align_tool_boundary(messages: List[dict], split_idx: int) -> int:
        """对齐 tool 配对边界：如果裁剪点落在 assistant(tool_calls) 和 tool result 之间，
        向前移动到配对开始之前。

        Args:
            messages: 对话消息列表（不含 system）
            split_idx: 初始裁剪点索引

        Returns:
            调整后的裁剪点索引
        """
        if split_idx <= 0 or split_idx >= len(messages):
            return split_idx

        # 检查 split_idx 处的消息是否是 tool result
        # 如果是，说明裁剪点落在了 tool 配对中间，需要向前移动
        while split_idx > 0:
            msg = messages[split_idx]
            if msg.get("role") == "tool" and msg.get("tool_call_id"):
                # 这是一个 tool result，向前找到对应的 assistant tool_calls
                split_idx -= 1
            elif msg.get("role") == "assistant" and msg.get("tool_calls"):
                # 裁剪点正好在 assistant tool_calls 上，也需要向前移
                # 因为后面的 tool results 属于 recent 部分
                split_idx -= 1
                # 继续检查前面是否还有 tool result
            else:
                break

        return max(0, split_idx)

    def _split_messages(self, messages: List[dict]) -> Tuple[List[dict], List[dict]]:
        """分离 system 消息和对话消息"""
        system_msgs: List[dict] = []
        conversation_msgs: List[dict] = []
        for msg in messages:
            if msg.get("role") in self.system_roles:
                system_msgs.append(msg)
            else:
                conversation_msgs.append(msg)
        return system_msgs, conversation_msgs

    def _try_compress_levels(
        self,
        system_msgs: List[dict],
        pivot_msgs: List[dict],
        compressible_msgs: List[dict],
        compressible_scores: List[ImportanceScore],
        recent_msgs: List[dict],
        original_count: int,
        original_tokens: int,
    ) -> List[dict]:
        """尝试不同压缩级别，直到满足 token 限制

        压缩顺序：L1 摘要 → L2 要点 → L3 关键词
        """
        levels = [
            (CompressionLevel.L1_SUMMARY, compress_l1_summary),
            (CompressionLevel.L2_BULLET, compress_l2_bullet),
            (CompressionLevel.L3_KEYWORD, lambda msgs, _=None: compress_l3_keyword(msgs)),
        ]

        for level, compress_fn in levels:
            # 生成压缩摘要
            if level == CompressionLevel.L3_KEYWORD:
                summary_text = compress_fn(compressible_msgs)
            else:
                summary_text = compress_fn(compressible_msgs, compressible_scores)

            summary_msg = {"role": "system", "content": _SUMMARY_TEMPLATE.format(
                count=len(compressible_msgs), summary=summary_text
            )}

            # 组装结果
            result = system_msgs + [summary_msg] + pivot_msgs + recent_msgs
            new_tokens = estimate_messages_tokens(result)

            if new_tokens <= self.max_tokens:
                # 成功，记录元数据
                key_points = _extract_key_points(
                    compressible_msgs, compressible_scores, max_points=5
                ) if compressible_scores else []

                meta = CompressionMeta(
                    original_count=original_count,
                    compressed_count=len(result),
                    original_tokens=original_tokens,
                    compressed_tokens=new_tokens,
                    compression_ratio=new_tokens / max(original_tokens, 1),
                    level=level,
                    key_points=key_points,
                    pivot_count=len(pivot_msgs),
                    timestamp=time.time(),
                )
                self.last_meta = meta
                self._compression_history.append(meta)

                logger.info(
                    "压缩完成: %s, %d→%d 消息, %d→%d token (比率 %.2f), "
                    "保留 %d 个转折点",
                    level.name, original_count, len(result),
                    original_tokens, new_tokens, meta.compression_ratio,
                    len(pivot_msgs),
                )
                return result

            logger.info("%s 压缩后仍有 %d token，尝试更高级别", level.name, new_tokens)

        # 所有级别都不够，返回 L3 结果（尽力而为）
        logger.warning("所有压缩级别仍超限，返回 L3 结果")
        return result  # type: ignore[possibly-undefined]

    def get_compression_history(self) -> List[dict]:
        """获取历史压缩记录

        Returns:
            压缩元数据字典列表
        """
        return [m.to_dict() for m in self._compression_history]


# ── 兼容接口（保持向后兼容） ────────────────────────────

def compress_if_needed(
    messages: List[dict],
    max_tokens: int = 100000,
    keep_recent: int = 20,
    system_roles: Optional[set] = None,
    llm_fn=None,
) -> "List[dict]":
    """向后兼容的压缩入口 — 同时支持同步和异步调用。

    当传入 llm_fn 时返回 coroutine（需 await），否则同步返回。

    Args:
        messages: 消息列表（含 system/user/assistant/tool）。
        max_tokens: token 上限。
        keep_recent: 保留最近的消息数（不含 system 消息）。
        system_roles: 视为 system 的角色集合，默认 {"system"}。
        llm_fn: 可选的异步 LLM 调用函数，用于生成摘要压缩。
                 签名: async (messages: list[dict]) -> str

    Returns:
        压缩后的消息列表（可能与原列表相同，表示无需压缩）。
    """
    compressor = TrajectoryCompressor(
        max_tokens=max_tokens,
        keep_recent=keep_recent,
        system_roles=system_roles,
        llm_fn=llm_fn,
    )
    return compressor.compress(messages)
