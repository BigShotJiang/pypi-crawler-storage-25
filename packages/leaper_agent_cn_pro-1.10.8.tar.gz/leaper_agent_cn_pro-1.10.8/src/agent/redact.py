"""日志脱敏 — 隐藏 API key、手机号、身份证号等敏感信息。

参考 Hermes redact.py 的简化版，增加中国特色脱敏规则。
"""

from __future__ import annotations

import os
import re
from typing import List, Tuple

# ── 脱敏开关（模块导入时锁定，运行时不可修改） ──────────────────────
_REDACT_ENABLED: bool = os.getenv("REDACT_SECRETS", "").lower() not in ("0", "false")

# ── 脱敏规则 ──────────────────────────────────────────────────────────

# (正则, 替换函数或字符串)
_PATTERNS: List[Tuple[re.Pattern, str]] = []


def _mask_token(match: re.Match) -> str:
    """对 API key 类 token 脱敏：短的全掩，长的保留首尾。"""
    token = match.group(0)
    if len(token) < 18:
        return "***REDACTED***"
    return token[:6] + "..." + token[-4:]


def _mask_phone(match: re.Match) -> str:
    """手机号脱敏：保留前 3 后 4。"""
    phone = match.group(0)
    return phone[:3] + "****" + phone[-4:]


def _mask_id_card(match: re.Match) -> str:
    """身份证号脱敏：保留前 4 后 4。"""
    idcard = match.group(0)
    return idcard[:4] + "**********" + idcard[-4:]


# API key 前缀模式（与 Hermes 一致）
_API_KEY_PREFIXES = [
    r"sk-[A-Za-z0-9_-]{10,}",           # OpenAI / Anthropic
    r"ghp_[A-Za-z0-9]{10,}",            # GitHub PAT
    r"github_pat_[A-Za-z0-9_]{10,}",    # GitHub fine-grained PAT
    r"AIza[A-Za-z0-9_-]{30,}",          # Google API key
    r"AKIA[A-Z0-9]{16}",                # AWS Access Key
    r"sk_live_[A-Za-z0-9]{10,}",        # Stripe
    r"sk_test_[A-Za-z0-9]{10,}",        # Stripe test
]

# ── 中国 provider API Key pattern ──────────────────────────────────────
_CN_PATTERNS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"sk-[A-Za-z0-9]{20,}"), "DeepSeek"),
    (re.compile(r"LTAI[A-Za-z0-9]{10,}"), "Aliyun AK"),
    (re.compile(r"ak-[A-Za-z0-9]{20,}"), "Moonshot"),
    (re.compile(r"[a-f0-9]{32}\.[A-Za-z0-9_-]+"), "Zhipu"),
    (re.compile(r"bce-v3/[A-Za-z0-9+/=]+"), "Baidu BCE"),
    (re.compile(r"Bearer\s+[A-Za-z0-9._-]{20,}"), "Bearer token"),
]

# 中国手机号：1[3-9] 开头 11 位
_PHONE_PATTERN = re.compile(r'(?<!\d)1[3-9]\d{9}(?!\d)')

# 中国身份证号：18 位，最后一位可为 X
_ID_CARD_PATTERN = re.compile(r'(?<!\d)\d{17}[\dXx](?!\d)')

# Bearer token: Authorization: Bearer xxx
_BEARER_PATTERN = re.compile(r'(Bearer\s+)([A-Za-z0-9_.\-/+=]{10,})', re.IGNORECASE)

# 编译 API key 正则
_API_KEY_COMPILED = [re.compile(p) for p in _API_KEY_PREFIXES]


def redact_sensitive(text: str) -> str:
    """对文本中的敏感信息进行脱敏。

    Args:
        text: 原始文本。

    Returns:
        脱敏后的文本。
    """
    if not text:
        return text

    result = text

    # 1. API key 前缀脱敏
    for pattern in _API_KEY_COMPILED:
        result = pattern.sub(_mask_token, result)

    # 2. Bearer token 脱敏
    result = _BEARER_PATTERN.sub(
        lambda m: m.group(1) + _mask_token(type(m)("", m.group(2), 0, 0)) if len(m.group(2)) >= 10
        else m.group(0),
        result,
    )

    # 3. 中国手机号
    result = _PHONE_PATTERN.sub(_mask_phone, result)

    # 4. 中国身份证号
    result = _ID_CARD_PATTERN.sub(_mask_id_card, result)

    return result


# 简化 Bearer 处理（上面的 lambda 有 bug，修正）
def _mask_bearer(match: re.Match) -> str:
    """Bearer token 脱敏。"""
    prefix = match.group(1)
    token = match.group(2)
    if len(token) < 18:
        return prefix + "***REDACTED***"
    return prefix + token[:6] + "..." + token[-4:]

# 重新注册 Bearer 处理
_BEARER_PATTERN_V2 = re.compile(r'(Bearer\s+)([A-Za-z0-9_.\-/+=]{10,})', re.IGNORECASE)


def redact_sensitive(text: str) -> str:  # noqa: F811 — 覆盖上面的版本
    """对文本中的敏感信息进行脱敏。

    支持：
    - API key（sk-、ghp_、AIza 等前缀）
    - 中国 provider API key（DeepSeek、阿里云、Moonshot、智谱、百度）
    - Bearer token
    - 中国手机号（1[3-9]开头 11 位）
    - 中国身份证号（18 位）

    脱敏开关由模块导入时的 REDACT_SECRETS 环境变量控制，运行时不可修改。

    Args:
        text: 原始文本。

    Returns:
        脱敏后的文本。
    """
    if not text or not _REDACT_ENABLED:
        return text

    result = text

    # 1. API key 前缀脱敏
    for pattern in _API_KEY_COMPILED:
        result = pattern.sub(_mask_token, result)

    # 2. 中国 provider API key 脱敏
    for pattern, _provider_name in _CN_PATTERNS:
        result = pattern.sub(_mask_token, result)

    # 3. Bearer token
    result = _BEARER_PATTERN_V2.sub(_mask_bearer, result)

    # 4. 中国手机号
    result = _PHONE_PATTERN.sub(_mask_phone, result)

    # 5. 中国身份证号
    result = _ID_CARD_PATTERN.sub(_mask_id_card, result)

    return result
