"""Bootstrap 文件加载器 — 带截断和优先级控制

加载 workspace 下的标准文件（SOUL.md, AGENTS.md 等），按优先级排序，
每个文件截断到 MAX_FILE_CHARS，总量截断到 MAX_BOOTSTRAP_CHARS。
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# 总字符限制
MAX_BOOTSTRAP_CHARS = 50000
# 单文件字符限制
MAX_FILE_CHARS = 10000

# 加载优先级（越靠前越先加载，先加载的不截断）
BOOTSTRAP_PRIORITY = [
    "SOUL.md",
    "AGENTS.md",
    "EGO.md",
    "USER.md",
    "MEMORY.md",
]


def _truncate_to_paragraph(content: str, max_chars: int) -> str:
    """截断到最后一个完整段落

    Args:
        content: 原始内容
        max_chars: 最大字符数

    Returns:
        截断后的内容（含截断标记）
    """
    if len(content) <= max_chars:
        return content

    original_len = len(content)
    truncated = content[:max_chars]

    # 找最后一个段落分隔符（空行）
    last_para = truncated.rfind("\n\n")
    if last_para > max_chars // 2:
        truncated = truncated[:last_para]
    else:
        # 退而找最后一个换行
        last_nl = truncated.rfind("\n")
        if last_nl > max_chars // 2:
            truncated = truncated[:last_nl]

    truncated += f"\n\n...[已截断，原始 {original_len} 字符]"
    return truncated


def load_bootstrap_files(
    workspace_dir: str,
    max_total_chars: int = MAX_BOOTSTRAP_CHARS,
    max_file_chars: int = MAX_FILE_CHARS,
    priority: Optional[list[str]] = None,
) -> str:
    """加载 workspace 下的 bootstrap 文件，带截断控制

    Args:
        workspace_dir: workspace 目录路径
        max_total_chars: 总字符限制
        max_file_chars: 单文件字符限制
        priority: 文件加载优先级列表，默认使用 BOOTSTRAP_PRIORITY

    Returns:
        拼接后的 bootstrap 内容
    """
    if priority is None:
        priority = list(BOOTSTRAP_PRIORITY)

    ws_path = Path(workspace_dir)
    if not ws_path.is_dir():
        logger.warning("workspace 目录不存在: %s", workspace_dir)
        return ""

    # 收集所有 .md 文件
    all_md_files = {f.name for f in ws_path.iterdir() if f.is_file() and f.suffix == ".md"}

    # 按优先级排序：优先级列表中的在前，其余按名称排序
    ordered_files: list[str] = []
    for fname in priority:
        if fname in all_md_files:
            ordered_files.append(fname)
            all_md_files.discard(fname)
    # 其余文件按名称排序追加
    ordered_files.extend(sorted(all_md_files))

    parts: list[str] = []
    total_chars = 0

    for fname in ordered_files:
        if total_chars >= max_total_chars:
            logger.debug("Bootstrap 总字符已达上限 %d，跳过 %s", max_total_chars, fname)
            break

        fpath = ws_path / fname
        try:
            content = fpath.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as e:
            logger.debug("读取 bootstrap 文件失败 %s: %s", fname, e)
            continue

        # 单文件截断
        remaining_budget = max_total_chars - total_chars
        effective_limit = min(max_file_chars, remaining_budget)
        content = _truncate_to_paragraph(content, effective_limit)

        section = f"## {fname}\n{content}"
        parts.append(section)
        total_chars += len(section)
        logger.debug("加载 bootstrap 文件: %s (%d 字符)", fname, len(section))

    result = "\n\n".join(parts)
    logger.info("Bootstrap 文件加载完成: %d 个文件, %d 字符", len(parts), len(result))
    return result
