"""
ContextEngine - 对话上下文管理引擎

管理对话上下文的各种注入源：
1. Workspace 文件注入（.md 文件）
2. Brain recall 记忆注入
3. Tool 结果注入（截断过长输出）
4. 统一构建最终 context 字符串

注意：这是独立的上下文片段构建器，与 context.py 的 ContextEngine（消息组装）不同。
context.py 负责组装最终 messages 列表；本模块负责构建注入片段。
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Optional, Union

try:
    from ..security.prompt_guard import scan_content
except (ImportError, ValueError):
    # 回退：直接导入或提供 no-op
    try:
        from security.prompt_guard import scan_content
    except ImportError:
        def scan_content(content: str, source: str = "unknown") -> str:
            return content

logger = logging.getLogger(__name__)

# 默认限制
DEFAULT_WORKSPACE_MAX_CHARS = 10000
DEFAULT_BRAIN_MAX_CHARS = 2000
DEFAULT_TOOL_MAX_CHARS = 5000
DEFAULT_FILE_MAX_CHARS = 2000

# 支持注入的文件扩展名
INJECTABLE_EXTENSIONS = {".md", ".txt"}


class ContextEngine:
    """对话上下文管理引擎

    负责从多个来源构建上下文片段，供 Agent Loop 注入到 system prompt 中。
    各方法独立可用，也可通过 build_context() 一次性构建。

    示例::

        engine = ContextEngine()
        ctx = await engine.build_context(
            workspace_dir="/path/to/workspace",
            brain=brain_instance,
            query="用户问题",
            tool_results=[{"name": "search", "output": "结果..."}],
        )
    """

    def __init__(
        self,
        workspace_max_chars: int = DEFAULT_WORKSPACE_MAX_CHARS,
        brain_max_chars: int = DEFAULT_BRAIN_MAX_CHARS,
        tool_max_chars: int = DEFAULT_TOOL_MAX_CHARS,
        file_max_chars: int = DEFAULT_FILE_MAX_CHARS,
    ):
        """初始化上下文引擎

        Args:
            workspace_max_chars: workspace 注入的最大字符数
            brain_max_chars: brain recall 注入的最大字符数
            tool_max_chars: tool 结果注入的最大字符数
            file_max_chars: 单个文件的最大字符数
        """
        self.workspace_max_chars = workspace_max_chars
        self.brain_max_chars = brain_max_chars
        self.tool_max_chars = tool_max_chars
        self.file_max_chars = file_max_chars
        # workspace 文件缓存（避免重复读取）
        self._workspace_cache: dict[str, str] = {}

    def inject_workspace(self, workspace_dir: str) -> str:
        """扫描 workspace 目录下的 .md/.txt 文件，拼接为注入文本

        只扫描顶层文件，按文件名排序。每个文件截断到 file_max_chars。
        总输出截断到 workspace_max_chars。

        Args:
            workspace_dir: workspace 目录路径

        Returns:
            拼接后的 workspace 内容字符串，空目录返回空字符串
        """
        if not workspace_dir:
            return ""

        # 检查缓存
        if workspace_dir in self._workspace_cache:
            return self._workspace_cache[workspace_dir]

        ws_path = Path(workspace_dir)
        if not ws_path.is_dir():
            logger.debug("Workspace 目录不存在: %s", workspace_dir)
            self._workspace_cache[workspace_dir] = ""
            return ""

        parts: list[str] = []
        total_chars = 0

        # 扫描顶层可注入文件，按名称排序
        files = sorted(
            f for f in ws_path.iterdir()
            if f.is_file() and f.suffix.lower() in INJECTABLE_EXTENSIONS
        )

        for file_path in files:
            if total_chars >= self.workspace_max_chars:
                break

            try:
                content = file_path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError) as e:
                logger.debug("读取文件失败 %s: %s", file_path.name, e)
                continue

            # Prompt injection 扫描
            content = scan_content(content, source=f"workspace/{file_path.name}")

            # 单文件截断
            if len(content) > self.file_max_chars:
                content = content[:self.file_max_chars] + "\n...[截断]"

            section = f"## {file_path.name}\n{content}"
            parts.append(section)
            total_chars += len(section)

        result = "\n\n".join(parts)

        # 总长度截断
        if len(result) > self.workspace_max_chars:
            result = result[:self.workspace_max_chars] + "\n...[workspace 内容截断]"

        self._workspace_cache[workspace_dir] = result
        return result

    def clear_workspace_cache(self) -> None:
        """清除 workspace 文件缓存（文件变更后调用）"""
        self._workspace_cache.clear()

    async def inject_brain_recall(
        self,
        brain: Any,
        query: str,
        max_chars: Optional[int] = None,
    ) -> str:
        """调用 brain.recall 获取相关记忆，格式化为注入文本

        Args:
            brain: Brain 实例，需要有 recall(query) 方法
            query: 查询字符串
            max_chars: 最大字符数，默认使用 self.brain_max_chars

        Returns:
            格式化的记忆文本，无记忆返回空字符串
        """
        if max_chars is None:
            max_chars = self.brain_max_chars

        if brain is None or not hasattr(brain, "recall"):
            return ""

        if not query or not query.strip():
            return ""

        # 尝试调用 recall，兼容不同签名
        try:
            memories = await brain.recall(query, top_k=5)
        except TypeError:
            try:
                memories = await brain.recall(query)
            except Exception as e:
                logger.debug("Brain recall 失败: %s", e)
                return ""
        except Exception as e:
            logger.debug("Brain recall 失败: %s", e)
            return ""

        if not memories:
            return ""

        # 格式化记忆条目
        lines: list[str] = []
        total_chars = 0

        for entry in memories[:10]:  # 最多 10 条
            if isinstance(entry, dict):
                text = (
                    entry.get("content", "")
                    or entry.get("text", "")
                    or str(entry)
                )
            else:
                text = str(entry)

            # 单条截断
            if len(text) > 300:
                text = text[:300] + "…"

            line = f"- {text}"
            if total_chars + len(line) > max_chars:
                break
            lines.append(line)
            total_chars += len(line) + 1  # +1 for newline

        if not lines:
            return ""

        return "[相关记忆]\n" + "\n".join(lines)

    def inject_tool_results(
        self,
        results: list[dict],
        max_chars: Optional[int] = None,
    ) -> str:
        """将 tool 执行结果格式化为注入文本，截断过长输出

        Args:
            results: tool 结果列表，每项包含 name 和 output 字段
                     例: [{"name": "search", "output": "搜索结果..."}, ...]
            max_chars: 最大总字符数，默认使用 self.tool_max_chars

        Returns:
            格式化的 tool 结果文本
        """
        if max_chars is None:
            max_chars = self.tool_max_chars

        if not results:
            return ""

        parts: list[str] = []
        total_chars = 0
        # 每个 tool 结果的单项上限
        per_tool_limit = max(max_chars // max(len(results), 1), 500)

        for item in results:
            if not isinstance(item, dict):
                continue

            name = item.get("name", "unknown")
            output = str(item.get("output", ""))

            # 单项截断
            if len(output) > per_tool_limit:
                output = output[:per_tool_limit] + "\n...[输出截断]"

            section = f"### {name}\n{output}"
            if total_chars + len(section) > max_chars:
                # 剩余空间不够，截断追加
                remaining = max_chars - total_chars
                if remaining > 50:
                    parts.append(section[:remaining] + "\n...[截断]")
                break

            parts.append(section)
            total_chars += len(section) + 2  # +2 for separator

        if not parts:
            return ""

        return "[工具结果]\n" + "\n\n".join(parts)

    async def build_context(
        self,
        workspace_dir: str = "",
        brain: Any = None,
        query: str = "",
        tool_results: Optional[list[dict]] = None,
    ) -> str:
        """一次性构建完整上下文字符串

        按顺序拼接：workspace → brain recall → tool results

        Args:
            workspace_dir: workspace 目录路径
            brain: Brain 实例
            query: 用户查询（用于 brain recall）
            tool_results: tool 执行结果列表

        Returns:
            完整的上下文字符串
        """
        sections: list[str] = []

        # 1. Workspace 文件
        ws = self.inject_workspace(workspace_dir)
        if ws:
            sections.append(ws)

        # 2. Brain recall
        if brain and query:
            recall = await self.inject_brain_recall(brain, query)
            if recall:
                sections.append(recall)

        # 3. Tool results
        if tool_results:
            tools = self.inject_tool_results(tool_results)
            if tools:
                sections.append(tools)

        return "\n\n".join(sections)
