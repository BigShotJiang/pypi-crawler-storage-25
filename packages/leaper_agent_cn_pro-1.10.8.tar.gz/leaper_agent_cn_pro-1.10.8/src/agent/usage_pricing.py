"""Usage Pricing 用量计费

功能：
- Token 用量追踪（输入/输出分开计）
- 各 provider 价格配置（DeepSeek/通义/智谱/Moonshot 实际价格）
- 对话成本计算
- 日/周/月成本统计
- 预算告警
- 成本优化建议（推荐更便宜的模型）
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ──────────────── 价格配置（单位：人民币元 / 百万 token）────────────────

# 价格数据截至 2024-12 月，实际价格请以官网为准
PRICING: Dict[str, Dict[str, Dict[str, float]]] = {
    "deepseek": {
        "deepseek-chat": {"input": 1.0, "output": 2.0},
        "deepseek-coder": {"input": 1.0, "output": 2.0},
        "deepseek-reasoner": {"input": 4.0, "output": 16.0},
    },
    "qwen": {
        "qwen-turbo": {"input": 2.0, "output": 6.0},
        "qwen-plus": {"input": 4.0, "output": 12.0},
        "qwen-max": {"input": 20.0, "output": 60.0},
        "qwen-long": {"input": 0.5, "output": 2.0},
    },
    "zhipu": {
        "glm-4": {"input": 15.0, "output": 15.0},
        "glm-4-flash": {"input": 0.1, "output": 0.1},
        "glm-4-air": {"input": 1.0, "output": 1.0},
        "glm-4-plus": {"input": 50.0, "output": 50.0},
    },
    "moonshot": {
        "moonshot-v1-8k": {"input": 12.0, "output": 12.0},
        "moonshot-v1-32k": {"input": 24.0, "output": 24.0},
        "moonshot-v1-128k": {"input": 60.0, "output": 60.0},
    },
}


@dataclass
class UsageRecord:
    """单次 API 调用用量记录"""
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_yuan: float  # 人民币元
    timestamp: float = field(default_factory=time.time)
    session_id: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "UsageRecord":
        valid = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in d.items() if k in valid})


@dataclass
class BudgetConfig:
    """预算配置"""
    daily_limit_yuan: float = 50.0
    weekly_limit_yuan: float = 200.0
    monthly_limit_yuan: float = 500.0
    alert_threshold: float = 0.8  # 达到预算 80% 时告警


class UsagePricing:
    """用量计费管理器"""

    def __init__(
        self,
        persist_path: Optional[str] = None,
        budget: Optional[BudgetConfig] = None,
        custom_pricing: Optional[Dict] = None,
    ):
        self._records: List[UsageRecord] = []
        self._persist_path = Path(persist_path) if persist_path else None
        self._budget = budget or BudgetConfig()
        # 合并自定义价格
        self._pricing = dict(PRICING)
        if custom_pricing:
            for provider, models in custom_pricing.items():
                if provider not in self._pricing:
                    self._pricing[provider] = {}
                self._pricing[provider].update(models)
        self._load()

    # --- 核心 API ---

    def calculate_cost(self, provider: str, model: str, input_tokens: int, output_tokens: int) -> float:
        """计算单次调用成本（人民币元）"""
        prices = self._get_price(provider, model)
        if not prices:
            return 0.0
        cost = (input_tokens * prices["input"] + output_tokens * prices["output"]) / 1_000_000
        return round(cost, 6)

    def record_usage(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        session_id: str = "",
        metadata: Optional[Dict] = None,
    ) -> UsageRecord:
        """记录一次 API 调用用量"""
        cost = self.calculate_cost(provider, model, input_tokens, output_tokens)
        record = UsageRecord(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_yuan=cost,
            session_id=session_id,
            metadata=metadata or {},
        )
        self._records.append(record)
        # 只保留最近 10000 条
        if len(self._records) > 10000:
            self._records = self._records[-10000:]
        self._save()
        return record

    def get_session_cost(self, session_id: str) -> Dict[str, Any]:
        """获取指定会话的成本"""
        records = [r for r in self._records if r.session_id == session_id]
        return self._summarize(records, label=f"session:{session_id}")

    def get_daily_cost(self, date: Optional[datetime] = None) -> Dict[str, Any]:
        """获取指定日期的成本统计"""
        if date is None:
            date = datetime.now()
        start = date.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        records = self._filter_by_time(start, end)
        return self._summarize(records, label=start.strftime("%Y-%m-%d"))

    def get_weekly_cost(self) -> Dict[str, Any]:
        """获取本周成本统计"""
        now = datetime.now()
        start = now - timedelta(days=now.weekday())
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        records = self._filter_by_time(start, now)
        return self._summarize(records, label="本周")

    def get_monthly_cost(self) -> Dict[str, Any]:
        """获取本月成本统计"""
        now = datetime.now()
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        records = self._filter_by_time(start, now)
        return self._summarize(records, label="本月")

    def check_budget(self) -> List[str]:
        """检查预算，返回告警信息列表"""
        alerts: List[str] = []
        daily = self.get_daily_cost()
        weekly = self.get_weekly_cost()
        monthly = self.get_monthly_cost()

        if daily["total_cost"] >= self._budget.daily_limit_yuan:
            alerts.append(f"🚨 日预算已超！当日消费 ¥{daily['total_cost']:.2f}，限额 ¥{self._budget.daily_limit_yuan:.2f}")
        elif daily["total_cost"] >= self._budget.daily_limit_yuan * self._budget.alert_threshold:
            alerts.append(f"⚠️ 日预算接近上限：¥{daily['total_cost']:.2f} / ¥{self._budget.daily_limit_yuan:.2f}")

        if weekly["total_cost"] >= self._budget.weekly_limit_yuan:
            alerts.append(f"🚨 周预算已超！本周消费 ¥{weekly['total_cost']:.2f}")
        elif weekly["total_cost"] >= self._budget.weekly_limit_yuan * self._budget.alert_threshold:
            alerts.append(f"⚠️ 周预算接近上限：¥{weekly['total_cost']:.2f} / ¥{self._budget.weekly_limit_yuan:.2f}")

        if monthly["total_cost"] >= self._budget.monthly_limit_yuan:
            alerts.append(f"🚨 月预算已超！本月消费 ¥{monthly['total_cost']:.2f}")
        elif monthly["total_cost"] >= self._budget.monthly_limit_yuan * self._budget.alert_threshold:
            alerts.append(f"⚠️ 月预算接近上限：¥{monthly['total_cost']:.2f} / ¥{self._budget.monthly_limit_yuan:.2f}")

        return alerts

    def suggest_cheaper_model(self, provider: str, model: str) -> Optional[Dict[str, Any]]:
        """推荐更便宜的替代模型"""
        current_price = self._get_price(provider, model)
        if not current_price:
            return None

        current_avg = (current_price["input"] + current_price["output"]) / 2
        alternatives: List[Dict[str, Any]] = []

        for p, models in self._pricing.items():
            for m, prices in models.items():
                if p == provider and m == model:
                    continue
                avg = (prices["input"] + prices["output"]) / 2
                if avg < current_avg:
                    saving_pct = (1 - avg / current_avg) * 100
                    alternatives.append({
                        "provider": p,
                        "model": m,
                        "input_price": prices["input"],
                        "output_price": prices["output"],
                        "saving_percent": round(saving_pct, 1),
                    })

        if not alternatives:
            return None

        alternatives.sort(key=lambda x: x["saving_percent"], reverse=True)
        return {
            "current": {"provider": provider, "model": model, "avg_price": current_avg},
            "alternatives": alternatives[:5],
        }

    def get_cost_by_model(self) -> Dict[str, Dict[str, Any]]:
        """按模型分组统计成本"""
        model_stats: Dict[str, Dict[str, Any]] = {}
        for r in self._records:
            key = f"{r.provider}/{r.model}"
            if key not in model_stats:
                model_stats[key] = {
                    "calls": 0, "input_tokens": 0, "output_tokens": 0, "total_cost": 0.0,
                }
            s = model_stats[key]
            s["calls"] += 1
            s["input_tokens"] += r.input_tokens
            s["output_tokens"] += r.output_tokens
            s["total_cost"] += r.cost_yuan
        # 四舍五入
        for s in model_stats.values():
            s["total_cost"] = round(s["total_cost"], 4)
        return model_stats

    def get_all_pricing(self) -> Dict:
        """获取所有价格配置"""
        return dict(self._pricing)

    # --- 内部 ---

    def _get_price(self, provider: str, model: str) -> Optional[Dict[str, float]]:
        """获取模型价格"""
        provider_prices = self._pricing.get(provider, {})
        return provider_prices.get(model)

    def _filter_by_time(self, start: datetime, end: datetime) -> List[UsageRecord]:
        s_ts = start.timestamp()
        e_ts = end.timestamp()
        return [r for r in self._records if s_ts <= r.timestamp <= e_ts]

    def _summarize(self, records: List[UsageRecord], label: str = "") -> Dict[str, Any]:
        total_input = sum(r.input_tokens for r in records)
        total_output = sum(r.output_tokens for r in records)
        total_cost = sum(r.cost_yuan for r in records)
        return {
            "label": label,
            "calls": len(records),
            "input_tokens": total_input,
            "output_tokens": total_output,
            "total_cost": round(total_cost, 4),
        }

    def _save(self) -> None:
        if not self._persist_path:
            return
        try:
            self._persist_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._persist_path, "w", encoding="utf-8") as f:
                json.dump([r.to_dict() for r in self._records[-5000:]], f, ensure_ascii=False)
        except Exception:
            pass

    def _load(self) -> None:
        if not self._persist_path or not self._persist_path.exists():
            return
        try:
            with open(self._persist_path, "r", encoding="utf-8") as f:
                self._records = [UsageRecord.from_dict(d) for d in json.load(f)]
        except Exception:
            pass
