"""
OnboardingManager - 冷启动引导管理器

负责：
1. 检查是否需要冷启动引导
2. 读取 ONBOARDING.md 作为额外 system prompt
3. 判断引导是否完成
4. 从对话中提取用户基本信息（纯规则，不调 LLM）
5. 将用户信息写入 brain
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Protocol


class BrainProtocol(Protocol):
    """Brain 协议 - 用于 onboarding 的最小接口"""
    async def recall(self, query: str, **kwargs) -> list: ...
    async def extract_and_learn(self, user_msg: str, reply: str, **kwargs) -> None: ...


# 行业关键词
_INDUSTRY_KEYWORDS = [
    "电商", "金融", "医疗", "教育", "物流", "零售", "制造", "游戏",
    "社交", "旅游", "房地产", "农业", "能源", "汽车", "媒体", "广告",
    "SaaS", "企业服务", "人工智能", "AI", "大数据", "云计算", "区块链",
    "硬件", "芯片", "机器人", "生物科技", "新能源", "跨境", "出海",
]

# 阶段关键词
_STAGE_KEYWORDS = [
    "天使轮", "天使", "种子轮", "种子", "Pre-A", "A轮", "A+轮",
    "B轮", "B+轮", "C轮", "D轮", "Pre-IPO", "IPO", "上市",
    "盈利", "盈亏平衡", "自负盈亏", "bootstrap", "初创", "成长期",
]

# 团队规模模式
_TEAM_PATTERNS = [
    r"(\d+)\s*[个名位人]",
    r"团队[有约]?\s*(\d+)",
    r"(\d+)\s*人[的]?团队",
]

# 公司名提取模式
_COMPANY_PATTERNS = [
    r"我是(.{2,15}?)的",
    r"我们公司(?:是|叫|做)(.{2,20})",
    r"我(?:在|来自)(.{2,15}?)(?:工作|做|负责)",
    r"公司(?:叫|名|是)(.{2,20})",
]


class OnboardingManager:
    """冷启动引导管理器"""

    def __init__(self, brain: Any, workspace_dir: str = ""):
        """
        brain: LeaperBrain 实例，用于检查是否已有用户信息
        workspace_dir: 模板 workspace 目录，包含 ONBOARDING.md 等
        """
        self.brain = brain
        self.workspace_dir = workspace_dir
        self._onboarding_done = False

    def needs_onboarding(self) -> bool:
        """检查是否需要冷启动引导（同步方法，使用缓存标记）"""
        if self._onboarding_done:
            return False
        return True

    async def async_needs_onboarding(self) -> bool:
        """异步检查是否需要冷启动引导
        条件：brain 中没有用户信息相关记忆
        """
        if self._onboarding_done:
            return False
        if not self.brain:
            return True

        try:
            memories = await self.brain.recall(query="用户信息 公司 行业", top_k=1)
        except TypeError:
            try:
                memories = await self.brain.recall("用户信息 公司 行业")
            except Exception:
                return True
        except Exception:
            return True

        if not memories:
            return True

        # 检查返回内容是否包含公司/行业相关词
        for mem in memories:
            text = mem if isinstance(mem, str) else str(mem)
            if any(kw in text for kw in ["公司", "行业", "团队", "融资", "阶段"]):
                self._onboarding_done = True
                return False

        return True

    def get_onboarding_prompt(self) -> str:
        """读取 ONBOARDING.md 内容，作为额外的 system prompt 注入"""
        # 优先从 workspace_dir 读取
        if self.workspace_dir:
            ws_path = Path(self.workspace_dir) / "ONBOARDING.md"
            if ws_path.exists():
                return ws_path.read_text(encoding="utf-8")

        # fallback: bundled templates 里的 _common/ONBOARDING.md
        fallback_path = (
            Path(__file__).parent.parent / "templates" / "workshop" / "templates" / "_common" / "ONBOARDING.md"
        )
        if fallback_path.exists():
            return fallback_path.read_text(encoding="utf-8")

        return ""

    def check_onboarding_complete(self, conversation: list[dict]) -> bool:
        """判断引导是否完成：
        - 对话超过 5 轮（10 条消息，user+assistant 各一条算一轮）
        - 或已知公司基本情况
        """
        if self._onboarding_done:
            return True

        # 计算用户消息数（每条 user 消息算半轮）
        user_msgs = [m for m in conversation if m.get("role") == "user"]
        if len(user_msgs) >= 5:
            return True

        # 检查是否已有足够的公司信息
        all_text = " ".join(
            m.get("content", "") for m in conversation if m.get("content")
        )
        info_signals = 0
        if any(kw in all_text for kw in _INDUSTRY_KEYWORDS):
            info_signals += 1
        if any(kw in all_text for kw in _STAGE_KEYWORDS):
            info_signals += 1
        if any(re.search(p, all_text) for p in _COMPANY_PATTERNS):
            info_signals += 1
        if any(re.search(p, all_text) for p in _TEAM_PATTERNS):
            info_signals += 1

        # 至少有 2 个信号认为信息足够
        if info_signals >= 2:
            return True

        return False

    async def extract_user_info(self, conversation: list[dict]) -> dict | None:
        """从对话中提取用户基本信息（公司、行业、阶段、团队规模）
        纯规则提取，不调用 LLM。返回 dict 或 None（信息不足时）
        """
        all_text = " ".join(
            m.get("content", "") for m in conversation
            if m.get("role") == "user" and m.get("content")
        )

        if not all_text.strip():
            return None

        info: dict[str, str] = {}

        # 提取公司名
        for pattern in _COMPANY_PATTERNS:
            match = re.search(pattern, all_text)
            if match:
                info["company"] = match.group(1).strip()
                break

        # 提取行业
        for kw in _INDUSTRY_KEYWORDS:
            if kw in all_text:
                info["industry"] = kw
                break

        # 提取阶段
        for kw in _STAGE_KEYWORDS:
            if kw in all_text:
                info["stage"] = kw
                break

        # 提取团队规模
        for pattern in _TEAM_PATTERNS:
            match = re.search(pattern, all_text)
            if match:
                info["team_size"] = match.group(1)
                break

        # 至少需要一个字段才算有效
        if not info:
            return None

        return info

    async def complete_onboarding(self, user_info: dict) -> None:
        """将用户信息写入 brain，标记引导完成"""
        self._onboarding_done = True

        if not self.brain:
            return

        # 格式化用户信息为文本
        parts = []
        if "company" in user_info:
            parts.append(f"公司: {user_info['company']}")
        if "industry" in user_info:
            parts.append(f"行业: {user_info['industry']}")
        if "stage" in user_info:
            parts.append(f"阶段: {user_info['stage']}")
        if "team_size" in user_info:
            parts.append(f"团队规模: {user_info['team_size']}人")

        info_text = "用户信息: " + ", ".join(parts)

        try:
            await self.brain.extract_and_learn(
                "用户基本信息收集完成", info_text
            )
        except Exception:
            pass  # 静默失败
