"""BatchRunner — 批量任务执行引擎

支持串行/并行执行多条任务，错误隔离，进度回调，结果导出。
支持 YAML/JSON 格式任务定义、失败重试、并发限制、日志记录。
"""

from __future__ import annotations

import asyncio
import csv
import json
import logging
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from .runner import AgentRunner

logger = logging.getLogger(__name__)


# ============================================================================
# 数据模型
# ============================================================================

@dataclass
class TaskDefinition:
    """批量任务定义（支持从 YAML/JSON 解析）"""
    prompt: str
    name: str = ""
    tags: List[str] = field(default_factory=list)
    max_retries: int = 0          # 每个任务独立重试次数，0=不重试
    timeout_seconds: float = 0    # 每任务超时，0=无限制
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TaskDefinition":
        """从字典构建（JSON / YAML 解析后的结构）"""
        return cls(
            prompt=data.get("prompt", data.get("task", "")),
            name=data.get("name", ""),
            tags=data.get("tags", []),
            max_retries=int(data.get("max_retries", data.get("retries", 0))),
            timeout_seconds=float(data.get("timeout_seconds", data.get("timeout", 0))),
            metadata=data.get("metadata", {}),
        )

    @classmethod
    def from_string(cls, text: str) -> "TaskDefinition":
        """从纯字符串构建"""
        return cls(prompt=text)


@dataclass
class BatchResult:
    """单个批量任务的执行结果"""
    task: str
    response: str = ""
    success: bool = False
    duration_ms: int = 0
    tokens_used: int = 0
    error: Optional[str] = None
    index: int = 0
    retries: int = 0             # 实际重试次数
    name: str = ""               # 任务名称
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """转为字典"""
        return asdict(self)


@dataclass
class BatchSummary:
    """批量执行的汇总统计"""
    total: int = 0
    success: int = 0
    failed: int = 0
    total_duration_ms: int = 0
    total_tokens: int = 0
    avg_duration_ms: float = 0.0
    total_retries: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


# ============================================================================
# 进度追踪器
# ============================================================================

class ProgressTracker:
    """线程安全的进度追踪"""

    def __init__(self, total: int):
        self.total = total
        self.completed = 0
        self.succeeded = 0
        self.failed = 0
        self._lock = asyncio.Lock()

    async def update(self, success: bool) -> Dict[str, Any]:
        """更新进度，返回当前快照"""
        async with self._lock:
            self.completed += 1
            if success:
                self.succeeded += 1
            else:
                self.failed += 1
            return self.snapshot()

    def snapshot(self) -> Dict[str, Any]:
        return {
            "total": self.total,
            "completed": self.completed,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "percent": round(self.completed / self.total * 100, 1) if self.total else 0,
        }


# ============================================================================
# BatchRunner 主类
# ============================================================================

class BatchRunner:
    """批量任务执行器

    支持串行和并行执行，错误隔离，进度回调，失败重试。

    用法：
        runner = BatchRunner(agent_runner)
        results = await runner.run_batch(["任务1", "任务2"], concurrency=2)
        summary = runner.get_summary()
        runner.export_results("output.json")

        # 从 JSON/YAML 文件加载任务定义
        results = await runner.run_from_definition("tasks.json")
    """

    def __init__(self, runner: "AgentRunner", default_retries: int = 0):
        """初始化批量执行器

        Args:
            runner: AgentRunner 实例，用于执行单个任务
            default_retries: 默认重试次数（任务级可覆盖）
        """
        self.runner = runner
        self.results: List[BatchResult] = []
        self._running = False
        self._cancelled = False
        self._default_retries = default_retries
        self._tracker: Optional[ProgressTracker] = None

    # ------------------------------------------------------------------
    # 任务定义解析
    # ------------------------------------------------------------------

    @staticmethod
    def parse_definitions(raw: str, fmt: str = "json") -> List[TaskDefinition]:
        """解析 JSON 或 YAML 格式的任务定义

        JSON 格式（列表或 { tasks: [...] }）：
            [{"prompt": "...", "name": "t1", "retries": 2}]

        YAML 格式（纯标准库 — 用简单行解析代替 pyyaml）：
            - prompt: "..."
              name: t1
              retries: 2

        Args:
            raw: 文件内容字符串
            fmt: "json" 或 "yaml"

        Returns:
            TaskDefinition 列表
        """
        if fmt == "json":
            data = json.loads(raw)
            if isinstance(data, dict):
                data = data.get("tasks", [])
            return [TaskDefinition.from_dict(item) if isinstance(item, dict) else TaskDefinition.from_string(str(item)) for item in data]
        elif fmt == "yaml":
            return BatchRunner._parse_simple_yaml(raw)
        else:
            raise ValueError(f"不支持的格式: {fmt}")

    @staticmethod
    def _parse_simple_yaml(raw: str) -> List[TaskDefinition]:
        """简易 YAML 列表解析（只用标准库，不依赖 pyyaml）

        支持格式：
            - prompt: "任务内容"
              name: t1
              retries: 2
        或纯文本（每行一个任务，# 为注释）
        """
        lines = raw.strip().splitlines()
        tasks: List[TaskDefinition] = []
        current: Optional[Dict[str, Any]] = None

        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            # 新的列表项
            if stripped.startswith("- "):
                if current is not None:
                    tasks.append(TaskDefinition.from_dict(current))
                rest = stripped[2:].strip()
                current = {}
                if ":" in rest:
                    k, v = rest.split(":", 1)
                    current[k.strip()] = _yaml_value(v.strip())
                else:
                    # 纯字符串列表项
                    current["prompt"] = _unquote(rest)
            elif current is not None and ":" in stripped:
                k, v = stripped.split(":", 1)
                current[k.strip()] = _yaml_value(v.strip())
            elif current is None:
                # 纯文本行（非 YAML 列表格式）
                tasks.append(TaskDefinition.from_string(stripped))

        if current is not None:
            tasks.append(TaskDefinition.from_dict(current))

        return tasks

    # ------------------------------------------------------------------
    # 核心执行
    # ------------------------------------------------------------------

    async def run_batch(
        self,
        tasks: Union[List[str], List[TaskDefinition]],
        concurrency: int = 1,
        on_progress: Optional[Callable[[int, int, BatchResult], Any]] = None,
        retry_count: Optional[int] = None,
    ) -> List[BatchResult]:
        """批量执行任务

        Args:
            tasks: 任务列表（字符串或 TaskDefinition）
            concurrency: 并发数，1 为串行
            on_progress: 进度回调 (completed, total, result)
            retry_count: 全局重试次数覆盖（优先级低于任务级）

        Returns:
            执行结果列表
        """
        if not tasks:
            return []

        if concurrency < 1:
            concurrency = 1

        # 统一转为 TaskDefinition
        defs: List[TaskDefinition] = []
        for t in tasks:
            if isinstance(t, TaskDefinition):
                defs.append(t)
            else:
                defs.append(TaskDefinition.from_string(str(t)))

        self.results = []
        self._running = True
        self._cancelled = False
        total = len(defs)
        self._tracker = ProgressTracker(total)

        logger.info(f"批量执行开始: {total} 个任务, 并发={concurrency}")

        if concurrency == 1:
            # 串行执行
            for i, td in enumerate(defs):
                if self._cancelled:
                    break
                result = await self._execute_with_retry(td, i, retry_count)
                self.results.append(result)
                await self._tracker.update(result.success)
                if on_progress:
                    try:
                        on_progress(self._tracker.completed, total, result)
                    except Exception:
                        pass
        else:
            # 并行执行，使用信号量控制并发
            semaphore = asyncio.Semaphore(concurrency)
            results_map: Dict[int, BatchResult] = {}

            async def _run_with_sem(idx: int, td: TaskDefinition) -> None:
                if self._cancelled:
                    return
                async with semaphore:
                    if self._cancelled:
                        return
                    result = await self._execute_with_retry(td, idx, retry_count)
                    results_map[idx] = result
                    await self._tracker.update(result.success)
                    if on_progress:
                        try:
                            on_progress(self._tracker.completed, total, result)
                        except Exception:
                            pass

            await asyncio.gather(
                *[_run_with_sem(i, td) for i, td in enumerate(defs)],
                return_exceptions=True,
            )

            # 按原始顺序排列结果
            for i in range(total):
                if i in results_map:
                    self.results.append(results_map[i])

        self._running = False
        logger.info(f"批量执行完成: {self.get_summary()}")
        return self.results

    async def run_from_file(
        self,
        file_path: str,
        concurrency: int = 1,
        on_progress: Optional[Callable[[int, int, BatchResult], Any]] = None,
    ) -> List[BatchResult]:
        """从文件读取任务列表执行

        文件格式：每行一个任务，空行和 # 开头的行会被跳过。

        Args:
            file_path: 任务文件路径
            concurrency: 并发数
            on_progress: 进度回调

        Returns:
            执行结果列表
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"任务文件不存在: {file_path}")

        tasks: List[str] = []
        text = path.read_text(encoding="utf-8")
        for line in text.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                tasks.append(line)

        if not tasks:
            return []

        return await self.run_batch(tasks, concurrency=concurrency, on_progress=on_progress)

    async def run_from_definition(
        self,
        file_path: str,
        concurrency: int = 1,
        on_progress: Optional[Callable[[int, int, BatchResult], Any]] = None,
    ) -> List[BatchResult]:
        """从 JSON/YAML 定义文件加载任务并执行

        Args:
            file_path: 任务定义文件（.json 或 .yaml/.yml）
            concurrency: 并发数
            on_progress: 进度回调

        Returns:
            执行结果列表
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"任务定义文件不存在: {file_path}")

        raw = path.read_text(encoding="utf-8")
        suffix = path.suffix.lower()
        fmt = "yaml" if suffix in (".yaml", ".yml") else "json"

        defs = self.parse_definitions(raw, fmt=fmt)
        if not defs:
            return []

        return await self.run_batch(defs, concurrency=concurrency, on_progress=on_progress)

    def cancel(self) -> None:
        """取消批量执行"""
        self._cancelled = True

    def get_progress(self) -> Optional[Dict[str, Any]]:
        """获取当前进度快照"""
        if self._tracker:
            return self._tracker.snapshot()
        return None

    # ------------------------------------------------------------------
    # 导出
    # ------------------------------------------------------------------

    def export_results(self, path: str, format: str = "json") -> None:
        """导出结果到文件

        Args:
            path: 输出文件路径
            format: 导出格式，支持 "json" 和 "csv"
        """
        out_path = Path(path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        if format == "csv":
            self._export_csv(out_path)
        else:
            self._export_json(out_path)

    def _export_json(self, path: Path) -> None:
        """导出为 JSON"""
        data = {
            "summary": self.get_summary(),
            "results": [r.to_dict() for r in self.results],
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _export_csv(self, path: Path) -> None:
        """导出为 CSV"""
        if not self.results:
            path.write_text("", encoding="utf-8")
            return

        fieldnames = ["index", "name", "task", "response", "success", "duration_ms",
                       "tokens_used", "retries", "error"]
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for r in self.results:
                d = r.to_dict()
                # 只写 fieldnames 中的字段
                writer.writerow({k: d.get(k, "") for k in fieldnames})

    def get_summary(self) -> dict:
        """获取执行统计摘要"""
        total = len(self.results)
        success = sum(1 for r in self.results if r.success)
        failed = total - success
        total_duration = sum(r.duration_ms for r in self.results)
        total_tokens = sum(r.tokens_used for r in self.results)
        total_retries = sum(r.retries for r in self.results)

        return BatchSummary(
            total=total,
            success=success,
            failed=failed,
            total_duration_ms=total_duration,
            total_tokens=total_tokens,
            avg_duration_ms=round(total_duration / total, 1) if total > 0 else 0.0,
            total_retries=total_retries,
        ).to_dict()

    # ------------------------------------------------------------------
    # 内部方法
    # ------------------------------------------------------------------

    async def _execute_with_retry(
        self, td: TaskDefinition, index: int, global_retry: Optional[int]
    ) -> BatchResult:
        """带重试的单任务执行

        重试优先级：任务级 > 全局参数 > 构造时默认值
        """
        max_retries = td.max_retries or (global_retry if global_retry is not None else self._default_retries)
        attempts = 0
        last_result: Optional[BatchResult] = None

        while attempts <= max_retries:
            result = await self._execute_single(td, index)
            result.retries = attempts
            result.name = td.name
            result.tags = td.tags

            if result.success:
                return result

            last_result = result
            attempts += 1
            if attempts <= max_retries:
                # 指数退避：100ms, 200ms, 400ms...
                delay = 0.1 * (2 ** (attempts - 1))
                logger.info(f"任务 #{index} 第 {attempts} 次重试 (等待 {delay:.1f}s)")
                await asyncio.sleep(delay)

        # 所有重试都失败
        if last_result:
            last_result.retries = attempts - 1
        return last_result or BatchResult(task=td.prompt, index=index, error="未知错误")

    async def _execute_single(self, td: TaskDefinition, index: int) -> BatchResult:
        """执行单个任务，错误隔离

        Args:
            td: 任务定义
            index: 任务索引

        Returns:
            BatchResult
        """
        start = time.monotonic()
        try:
            # 带超时执行
            if td.timeout_seconds > 0:
                response = await asyncio.wait_for(
                    self.runner.run_single(td.prompt),
                    timeout=td.timeout_seconds,
                )
            else:
                response = await self.runner.run_single(td.prompt)

            duration_ms = int((time.monotonic() - start) * 1000)

            # 尝试从 state 获取 token 使用量
            tokens = 0
            if hasattr(self.runner, "state") and self.runner.state:
                tokens = getattr(self.runner.state, "total_tokens", 0)

            return BatchResult(
                task=td.prompt,
                response=response if isinstance(response, str) else str(response),
                success=True,
                duration_ms=duration_ms,
                tokens_used=tokens,
                error=None,
                index=index,
            )
        except asyncio.TimeoutError:
            duration_ms = int((time.monotonic() - start) * 1000)
            msg = f"任务超时 ({td.timeout_seconds}s)"
            logger.warning(f"批量任务 #{index} {msg}")
            return BatchResult(
                task=td.prompt, response="", success=False,
                duration_ms=duration_ms, tokens_used=0, error=msg, index=index,
            )
        except Exception as e:
            duration_ms = int((time.monotonic() - start) * 1000)
            logger.warning(f"批量任务 #{index} 执行失败: {e}")
            return BatchResult(
                task=td.prompt, response="", success=False,
                duration_ms=duration_ms, tokens_used=0, error=str(e), index=index,
            )


# ============================================================================
# 辅助函数
# ============================================================================

def _unquote(s: str) -> str:
    """去除 YAML 值的引号"""
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ('"', "'"):
        return s[1:-1]
    return s


def _yaml_value(s: str) -> Any:
    """将 YAML 值字符串转为 Python 类型"""
    s = _unquote(s)
    if s.lower() in ("true", "yes"):
        return True
    if s.lower() in ("false", "no"):
        return False
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        pass
    return s
