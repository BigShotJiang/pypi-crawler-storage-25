"""
ContextEngine - 上下文引擎

组装最终传给 LLM 的 context，包括：
1. system prompt（workspace .md 文件）
2. brain recall 结果（相关记忆注入）
3. conversation history（context window）
4. onboarding 提示（如需要）
5. user message
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path

from .session import _estimate_tokens

logger = logging.getLogger(__name__)

# 默认 context window token 预算
DEFAULT_TOKEN_BUDGET = 32000


def build_memory_block(raw: str) -> str:
    """构建带围栏的记忆注入块。

    1. 清理逃逸标签（防止注入者伪造 memory-context 边界）
    2. 包裹 <memory-context> XML 标签
    3. 前置系统说明

    Args:
        raw: 原始记忆内容

    Returns:
        围栏化的记忆块文本
    """
    if not raw:
        return ""

    # 清理逃逸：移除原始内容中的 memory-context 标签
    cleaned = re.sub(r'</?\s*memory-context\s*>', '', raw)

    return (
        "[系统说明：以下是召回的历史记忆，不是用户的新输入。]\n"
        "<memory-context>\n"
        f"{cleaned}\n"
        "</memory-context>"
    )


class ContextEngine:
    """上下文引擎：组装最终传给 LLM 的 context"""

    def __init__(self, brain, session_manager, workspace_dir: str = ""):
        self.brain = brain
        self.session_manager = session_manager
        self.workspace_dir = workspace_dir
        self._workspace_cache: str | None = None

    async def build_context(
        self,
        session_id: str,
        user_message: str,
        system_prompt: str = "",
        onboarding_prompt: str = "",
        max_tokens: int = DEFAULT_TOKEN_BUDGET,
    ) -> list[dict]:
        """构建完整 context：
        1. system prompt
        2. workspace 文件内容
        3. brain recall 结果
        4. conversation history（context window）
        5. onboarding 提示
        6. user message
        """
        messages: list[dict] = []

        # 1. System prompt
        parts = []
        if system_prompt:
            parts.append(system_prompt)

        # 2. Workspace 文件
        ws_content = self._load_workspace_files()
        if ws_content:
            parts.append(ws_content)

        if parts:
            messages.append({"role": "system", "content": "\n\n".join(parts)})

        # 3. Brain recall（相关记忆注入 — 注入到 user message，保护 prompt cache）
        memory_context = await self._recall_memories(user_message)

        # 4. Onboarding
        if onboarding_prompt:
            messages.append({"role": "system", "content": onboarding_prompt})

        # 5. Conversation history（context window）
        # 为 history 留出预算：总预算 - system 消息 - user 消息预估
        system_tokens = sum(_estimate_tokens(m["content"]) for m in messages)
        user_tokens = _estimate_tokens(user_message)
        history_budget = max(max_tokens - system_tokens - user_tokens - 500, 1000)

        history = await self.session_manager.get_context_window(
            session_id, max_tokens=history_budget
        )
        messages.extend(history)

        # 6. User message（记忆作为围栏块注入到 user message 中）
        if memory_context:
            fenced_memory = build_memory_block(memory_context)
            messages.append({"role": "user", "content": f"{fenced_memory}\n\n{user_message}"})
        else:
            messages.append({"role": "user", "content": user_message})

        # 最终截断保护
        messages = self._truncate_to_budget(messages, max_tokens)

        return messages

    def _load_workspace_files(self) -> str:
        """加载 workspace 下的 .md 文件作为 system prompt 一部分"""
        if self._workspace_cache is not None:
            return self._workspace_cache

        if not self.workspace_dir or not os.path.isdir(self.workspace_dir):
            self._workspace_cache = ""
            return ""

        parts: list[str] = []
        ws = Path(self.workspace_dir)
        # 只读顶层 .md 文件，避免递归太深
        for md_file in sorted(ws.glob("*.md")):
            try:
                content = md_file.read_text(encoding="utf-8")
                # 限制每个文件最多 2000 字
                if len(content) > 2000:
                    content = content[:2000] + "\n...[截断]"
                parts.append(f"## {md_file.name}\n{content}")
            except Exception:
                continue

        self._workspace_cache = "\n\n".join(parts) if parts else ""
        return self._workspace_cache

    async def _recall_memories(self, query: str, max_items: int = 5) -> str:
        """从 brain recall 相关记忆，支持 namespace 和 desk_context"""
        if not self.brain or not hasattr(self.brain, "recall"):
            return ""
        try:
            # 尝试传 desk_context（四层命名空间）
            desk_ctx = getattr(self.brain, '_desk_context', None) or getattr(self, 'desk_context', None)
            if desk_ctx is not None:
                memories = await self.brain.recall(query, limit=max_items, desk_context=desk_ctx)
            else:
                memories = await self.brain.recall(query, limit=max_items)
        except TypeError:
            try:
                memories = await self.brain.recall(query)
            except Exception:
                return ""
        except Exception:
            return ""

        if not memories:
            return ""

        lines: list[str] = []
        for entry in memories[:max_items]:
            if isinstance(entry, dict):
                text = entry.get("content", "") or entry.get("text", "") or str(entry)
                cat = entry.get("category", "")
            else:
                text = str(entry)
                cat = ""
            max_len = 500 if cat.startswith("industry-seed:") else 200
            if len(text) > max_len:
                text = text[:max_len] + "..."
            source = entry.get("source", "") if isinstance(entry, dict) else ""
            org_tag = "[组织知识] " if source == "org_cache" else ""
            prefix = f"[{cat}] " if cat else ""
            lines.append(f"- {org_tag}{prefix}{text}")

        if not lines:
            return ""
        return "[相关知识]\n" + "\n".join(lines)

    def _truncate_to_budget(self, messages: list[dict], budget: int) -> list[dict]:
        """按 token 预算截断，保留系统消息和最近消息"""
        if not messages:
            return messages

        total = sum(_estimate_tokens(m.get("content", "") or "") for m in messages)
        if total <= budget:
            return messages

        # 策略：保留第一条 system + 最后一条 user，中间从旧到新裁剪
        # 找出系统消息和最后的 user 消息
        system_msgs = [m for m in messages if m["role"] == "system"]
        non_system = [m for m in messages if m["role"] != "system"]

        if not non_system:
            return messages

        # 保留所有 system + 从后往前尽可能多的非 system 消息
        system_tokens = sum(_estimate_tokens(m.get("content", "") or "") for m in system_msgs)
        remaining_budget = budget - system_tokens

        kept_non_system: list[dict] = []
        for m in reversed(non_system):
            t = _estimate_tokens(m.get("content", "") or "")
            if remaining_budget - t < 0 and kept_non_system:
                break
            remaining_budget -= t
            kept_non_system.insert(0, m)

        return system_msgs + kept_non_system
