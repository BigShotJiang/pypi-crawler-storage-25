"""Smart model routing — 根据消息复杂度选择合适的模型。

简单消息路由到便宜模型，复杂消息路由到强模型。
只提供判断函数，不改变现有 provider 逻辑。
"""

from __future__ import annotations

import re
import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

# ── 复杂度关键词 ──────────────────────────────────────────────────────

_COMPLEX_KEYWORDS_CN = [
    "分析", "设计", "架构", "对比", "代码", "实现", "debug",
    "重构", "优化", "评估", "方案", "策略", "调试", "排查",
    "算法", "数据结构", "并发", "性能", "安全",
]

_COMPLEX_KEYWORDS_EN = [
    "analyze", "design", "architect", "compare", "implement", "debug",
    "refactor", "optimize", "evaluate", "strategy", "algorithm",
    "performance", "security", "concurrent", "infrastructure",
]

# URL 检测
_URL_PATTERN = re.compile(r'https?://\S+', re.IGNORECASE)

# 代码块检测
_CODE_BLOCK_PATTERN = re.compile(r'```[\s\S]*?```')

# 复杂度阈值
_LENGTH_THRESHOLD = 200  # 字符数


def _estimate_complexity(message: str) -> float:
    """估算消息复杂度，返回 0.0~1.0。

    Args:
        message: 用户消息文本

    Returns:
        复杂度分数，越高越复杂
    """
    if not message:
        return 0.0

    score = 0.0
    msg_lower = message.lower()

    # 1. 关键词匹配（每个命中 +0.15，上限 0.45）
    keyword_hits = 0
    for kw in _COMPLEX_KEYWORDS_CN:
        if kw in message:
            keyword_hits += 1
    for kw in _COMPLEX_KEYWORDS_EN:
        if kw in msg_lower:
            keyword_hits += 1
    score += min(keyword_hits * 0.15, 0.45)

    # 2. URL 检测（+0.1）
    if _URL_PATTERN.search(message):
        score += 0.1

    # 3. 代码块检测（+0.2）
    if _CODE_BLOCK_PATTERN.search(message):
        score += 0.2

    # 4. 消息长度（>200 字符 +0.15，>500 +0.25）
    if len(message) > 500:
        score += 0.25
    elif len(message) > _LENGTH_THRESHOLD:
        score += 0.15

    # 5. 问号数量（多个问题 = 多步推理）
    question_marks = message.count("?") + message.count("？")
    if question_marks >= 3:
        score += 0.1

    return min(score, 1.0)


def route_model(
    message: str,
    available_models: List[str],
    strong_model: Optional[str] = None,
    cheap_model: Optional[str] = None,
    threshold: float = 0.4,
) -> str:
    """根据消息复杂度选择模型。

    Args:
        message: 用户消息文本
        available_models: 可用模型列表
        strong_model: 强模型名称（可选，默认取列表中含 reasoner 的）
        cheap_model: 便宜模型名称（可选，默认取列表中含 chat 的）
        threshold: 复杂度阈值，高于此值使用强模型

    Returns:
        选中的模型名称
    """
    if not available_models:
        return "deepseek-chat"

    if len(available_models) == 1:
        return available_models[0]

    # 自动识别 strong/cheap model
    if not strong_model:
        for m in available_models:
            if "reasoner" in m.lower() or "pro" in m.lower() or "plus" in m.lower():
                strong_model = m
                break
        if not strong_model:
            strong_model = available_models[0]

    if not cheap_model:
        for m in available_models:
            if "chat" in m.lower() or "lite" in m.lower() or "mini" in m.lower():
                cheap_model = m
                break
        if not cheap_model:
            cheap_model = available_models[-1]

    complexity = _estimate_complexity(message)

    if complexity >= threshold:
        selected = strong_model
        logger.debug("消息复杂度 %.2f ≥ %.2f，选择强模型: %s", complexity, threshold, selected)
    else:
        selected = cheap_model
        logger.debug("消息复杂度 %.2f < %.2f，选择经济模型: %s", complexity, threshold, selected)

    return selected
