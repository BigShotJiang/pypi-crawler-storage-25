"""Shell Hooks - 命令执行前后的 hook 机制

提供 pre/post hook 用于：
- 危险命令拦截
- 输出过滤（敏感信息脱敏）
- 命令历史记录
- 错误分析
- 环境变量管理
- 工作目录跟踪
"""
from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Awaitable, Union


@dataclass
class HookResult:
    """Hook 执行结果"""
    allow: bool = True
    modified_command: Optional[str] = None
    warning: Optional[str] = None


@dataclass
class CommandRecord:
    """命令执行记录"""
    command: str
    cwd: str
    exit_code: Optional[int] = None
    output: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    duration: Optional[float] = None
    env_snapshot: Optional[Dict[str, str]] = None


# 类型: hook 函数可以是同步或异步
PreHookFn = Callable[[str, str], Union[HookResult, Awaitable[HookResult]]]
PostHookFn = Callable[[str, int, str], Union[None, Awaitable[None]]]


class ShellHooks:
    """命令执行 hook 管理器"""

    def __init__(self) -> None:
        self.pre_hooks: List[PreHookFn] = []
        self.post_hooks: List[PostHookFn] = []
        self.history: List[CommandRecord] = []
        self._max_history: int = 500
        # 环境变量管理
        self._env_overrides: Dict[str, str] = {}
        self._env_removed: set = set()
        # 工作目录跟踪
        self._cwd_history: List[str] = []
        self._current_cwd: Optional[str] = None

    def add_pre_hook(self, hook: PreHookFn) -> None:
        """添加前置 hook"""
        self.pre_hooks.append(hook)

    def add_post_hook(self, hook: PostHookFn) -> None:
        """添加后置 hook"""
        self.post_hooks.append(hook)

    def remove_pre_hook(self, hook: PreHookFn) -> bool:
        """移除前置 hook"""
        try:
            self.pre_hooks.remove(hook)
            return True
        except ValueError:
            return False

    def remove_post_hook(self, hook: PostHookFn) -> bool:
        """移除后置 hook"""
        try:
            self.post_hooks.remove(hook)
            return True
        except ValueError:
            return False

    async def run_pre_hooks(self, command: str, cwd: str) -> HookResult:
        """执行所有前置 hook，任何一个拒绝则整体拒绝"""
        import asyncio
        result = HookResult(allow=True)
        current_cmd = command
        warnings = []
        for hook in self.pre_hooks:
            r = hook(current_cmd, cwd)
            if asyncio.iscoroutine(r):
                r = await r
            if not r.allow:
                return r
            if r.modified_command:
                current_cmd = r.modified_command
            if r.warning:
                warnings.append(r.warning)
        result.modified_command = current_cmd if current_cmd != command else None
        result.warning = "; ".join(warnings) if warnings else None
        # 跟踪工作目录
        self._track_cwd(cwd)
        return result

    async def run_post_hooks(self, command: str, exit_code: int, output: str) -> None:
        """执行所有后置 hook"""
        import asyncio
        for hook in self.post_hooks:
            r = hook(command, exit_code, output)
            if asyncio.iscoroutine(r):
                await r

    def record(self, rec: CommandRecord) -> None:
        """记录命令"""
        self.history.append(rec)
        if len(self.history) > self._max_history:
            self.history = self.history[-self._max_history:]

    # --- 环境变量管理 ---

    def set_env(self, key: str, value: str) -> None:
        """设置环境变量覆盖"""
        self._env_overrides[key] = value
        self._env_removed.discard(key)

    def unset_env(self, key: str) -> None:
        """标记删除环境变量"""
        self._env_removed.add(key)
        self._env_overrides.pop(key, None)

    def get_env(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """获取环境变量（优先覆盖值）"""
        if key in self._env_removed:
            return default
        if key in self._env_overrides:
            return self._env_overrides[key]
        return os.environ.get(key, default)

    def get_effective_env(self) -> Dict[str, str]:
        """获取合并后的完整环境变量"""
        env = dict(os.environ)
        env.update(self._env_overrides)
        for k in self._env_removed:
            env.pop(k, None)
        return env

    def list_env_overrides(self) -> Dict[str, str]:
        """列出所有覆盖的环境变量"""
        return dict(self._env_overrides)

    # --- 工作目录跟踪 ---

    def _track_cwd(self, cwd: str) -> None:
        """记录工作目录变化"""
        if cwd and cwd != self._current_cwd:
            self._current_cwd = cwd
            self._cwd_history.append(cwd)
            # 只保留最近 50 条
            if len(self._cwd_history) > 50:
                self._cwd_history = self._cwd_history[-50:]

    def get_current_cwd(self) -> Optional[str]:
        """获取当前工作目录"""
        return self._current_cwd

    def get_cwd_history(self) -> List[str]:
        """获取工作目录历史"""
        return list(self._cwd_history)

    # --- 搜索历史 ---

    def search_history(self, keyword: str, limit: int = 20) -> List[CommandRecord]:
        """搜索命令历史"""
        results = []
        for rec in reversed(self.history):
            if keyword.lower() in rec.command.lower():
                results.append(rec)
                if len(results) >= limit:
                    break
        return results

    def get_recent_errors(self, limit: int = 10) -> List[CommandRecord]:
        """获取最近失败的命令"""
        errors = []
        for rec in reversed(self.history):
            if rec.exit_code is not None and rec.exit_code != 0:
                errors.append(rec)
                if len(errors) >= limit:
                    break
        return errors


# ── 内置 Hooks ──

# 危险命令正则
_DANGEROUS_PATTERNS = [
    re.compile(r"\brm\s+-[rf]{1,3}\s+/"),
    re.compile(r"\brm\s+-[rf]{1,3}\s+~"),
    re.compile(r"\bformat\s+[a-zA-Z]:", re.IGNORECASE),
    re.compile(r"\bdd\s+.*of=/dev/sd", re.IGNORECASE),
    re.compile(r"\bmkfs\b", re.IGNORECASE),
    re.compile(r"\bdel\s+/[sS]\s+/[qQ]\s+[A-Z]:\\", re.IGNORECASE),
    re.compile(r"\bRemove-Item\s+.*-Recurse.*[A-Z]:\\", re.IGNORECASE),
    re.compile(r"\b(DROP|TRUNCATE|DELETE\s+FROM)\b.*;\s*$", re.IGNORECASE),
    re.compile(r"\b(shutdown|reboot|halt|poweroff)\b", re.IGNORECASE),
]


def dangerous_command_guard(command: str, cwd: str) -> HookResult:
    """拦截危险命令"""
    for pat in _DANGEROUS_PATTERNS:
        if pat.search(command):
            return HookResult(
                allow=False,
                warning=f"⚠️ 危险命令被拦截: {command}"
            )
    return HookResult(allow=True)


# 敏感信息脱敏正则
_SENSITIVE_PATTERNS = [
    (re.compile(r"(sk-[A-Za-z0-9]{20,})"), "[API_KEY_REDACTED]"),
    (re.compile(r"(ghp_[A-Za-z0-9]{36,})"), "[GITHUB_TOKEN_REDACTED]"),
    (re.compile(r"(password\s*[:=]\s*)\S+", re.IGNORECASE), r"\1[REDACTED]"),
    (re.compile(r"(token\s*[:=]\s*)\S+", re.IGNORECASE), r"\1[REDACTED]"),
    (re.compile(r"(secret\s*[:=]\s*)\S+", re.IGNORECASE), r"\1[REDACTED]"),
    (re.compile(r"(api[_-]?key\s*[:=]\s*)\S+", re.IGNORECASE), r"\1[REDACTED]"),
]


def redact_sensitive_output(text: str) -> str:
    """脱敏处理 — 过滤敏感信息"""
    for pattern, replacement in _SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def output_redactor(command: str, exit_code: int, output: str) -> None:
    """输出脱敏 post hook（仅作为示范；实际脱敏应在调用方使用 redact_sensitive_output）"""
    pass


def output_truncator(command: str, exit_code: int, output: str) -> None:
    """截断过长输出（本函数不修改 output，仅作为示例；实际截断在调用方处理）"""
    pass


_command_log: List[CommandRecord] = []


def command_logger(command: str, cwd: str) -> HookResult:
    """记录命令（pre hook 形式，总是放行）"""
    _command_log.append(CommandRecord(command=command, cwd=cwd))
    if len(_command_log) > 1000:
        _command_log.pop(0)
    return HookResult(allow=True)


def get_command_log() -> List[CommandRecord]:
    """获取命令日志"""
    return list(_command_log)


# 常见错误模式 → 建议
_ERROR_SUGGESTIONS = {
    "command not found": "命令未找到，请检查 PATH 或安装对应工具",
    "permission denied": "权限不足，可能需要 sudo 或管理员权限",
    "no such file": "文件或目录不存在，请检查路径",
    "connection refused": "连接被拒绝，请检查服务是否启动",
    "out of memory": "内存不足，尝试关闭其他程序或增加内存",
    "disk full": "磁盘已满，请清理磁盘空间",
    "timeout": "操作超时，请检查网络或增加超时时间",
}


def analyze_error(output: str) -> Optional[str]:
    """分析错误输出，返回建议"""
    lower_output = output.lower()
    for pattern, suggestion in _ERROR_SUGGESTIONS.items():
        if pattern in lower_output:
            return suggestion
    return None


def error_analyzer(command: str, exit_code: int, output: str) -> None:
    """分析常见错误并记录建议（post hook）"""
    if exit_code == 0:
        return
    analyze_error(output)


def truncate_output(output: str, max_lines: int = 200, max_chars: int = 50000) -> str:
    """工具函数：截断过长输出"""
    if len(output) > max_chars:
        output = output[:max_chars] + "\n... [输出过长，已截断]"
    lines = output.split("\n")
    if len(lines) > max_lines:
        head = lines[:50]
        tail = lines[-10:]
        output = "\n".join(head) + f"\n\n... [省略 {len(lines) - 60} 行] ...\n\n" + "\n".join(tail)
    return output


def create_default_hooks() -> ShellHooks:
    """创建带默认内置 hooks 的 ShellHooks 实例"""
    hooks = ShellHooks()
    hooks.add_pre_hook(dangerous_command_guard)
    hooks.add_pre_hook(command_logger)
    hooks.add_post_hook(error_analyzer)
    return hooks
