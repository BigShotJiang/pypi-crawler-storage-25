"""Rate limit header 解析器 — 从 HTTP 响应头中提取限流状态。

解析 OpenAI 兼容的 rate limit headers，提供智能退避建议。
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# 支持的 rate limit header 名称
RATE_LIMIT_HEADERS = [
    "x-ratelimit-limit-requests",
    "x-ratelimit-remaining-requests",
    "x-ratelimit-limit-tokens",
    "x-ratelimit-remaining-tokens",
    "x-ratelimit-reset-requests",
    "x-ratelimit-reset-tokens",
    "retry-after",
]


@dataclass
class RateLimitState:
    """Rate limit 状态快照"""
    # 请求限制
    limit_requests: Optional[int] = None
    remaining_requests: Optional[int] = None
    reset_requests: Optional[str] = None      # 重置时间（原始字符串，可能是秒或时间戳）

    # Token 限制
    limit_tokens: Optional[int] = None
    remaining_tokens: Optional[int] = None
    reset_tokens: Optional[str] = None

    # Retry-After
    retry_after: Optional[float] = None        # 秒

    # 解析时间
    timestamp: float = field(default_factory=time.time)

    @property
    def is_exhausted(self) -> bool:
        """请求或 token 配额是否已用尽"""
        if self.remaining_requests is not None and self.remaining_requests <= 0:
            return True
        if self.remaining_tokens is not None and self.remaining_tokens <= 0:
            return True
        return False

    @property
    def suggested_wait_seconds(self) -> float:
        """建议等待秒数（基于 header 信息）"""
        if self.retry_after is not None:
            return self.retry_after

        waits: list[float] = []
        for reset_str in (self.reset_requests, self.reset_tokens):
            if reset_str:
                parsed = _parse_reset_value(reset_str)
                if parsed is not None and parsed > 0:
                    waits.append(parsed)

        return min(waits) if waits else 0.0


def _parse_reset_value(value: str) -> Optional[float]:
    """解析 reset 值为秒数。

    支持格式：
    - 纯数字（秒）："30"
    - 带单位："30s", "1m", "500ms"
    """
    if not value:
        return None
    value = value.strip()

    # 毫秒
    if value.endswith("ms"):
        try:
            return float(value[:-2]) / 1000.0
        except ValueError:
            return None

    # 秒
    if value.endswith("s"):
        try:
            return float(value[:-1])
        except ValueError:
            return None

    # 分钟
    if value.endswith("m"):
        try:
            return float(value[:-1]) * 60
        except ValueError:
            return None

    # 纯数字（秒）
    try:
        return float(value)
    except ValueError:
        return None


def parse_rate_limit_headers(headers: Dict[str, str]) -> Optional[RateLimitState]:
    """从 HTTP 响应头中解析 rate limit 状态。

    Args:
        headers: HTTP 响应头字典（key 不区分大小写）

    Returns:
        RateLimitState 或 None（如果没有相关 header）
    """
    if not headers:
        return None

    # 统一转小写
    lower_headers = {k.lower(): v for k, v in headers.items()}

    # 检查是否有任何 rate limit header
    has_any = any(h in lower_headers for h in RATE_LIMIT_HEADERS)
    if not has_any:
        return None

    state = RateLimitState()

    # 解析各字段
    def _get_int(key: str) -> Optional[int]:
        val = lower_headers.get(key)
        if val:
            try:
                return int(val)
            except (ValueError, TypeError):
                pass
        return None

    state.limit_requests = _get_int("x-ratelimit-limit-requests")
    state.remaining_requests = _get_int("x-ratelimit-remaining-requests")
    state.limit_tokens = _get_int("x-ratelimit-limit-tokens")
    state.remaining_tokens = _get_int("x-ratelimit-remaining-tokens")
    state.reset_requests = lower_headers.get("x-ratelimit-reset-requests")
    state.reset_tokens = lower_headers.get("x-ratelimit-reset-tokens")

    retry_after_str = lower_headers.get("retry-after")
    if retry_after_str:
        parsed = _parse_reset_value(retry_after_str)
        state.retry_after = parsed

    if state.is_exhausted:
        logger.warning(
            "⚠️ Rate limit 配额耗尽: requests=%s, tokens=%s, 建议等待 %.1fs",
            state.remaining_requests, state.remaining_tokens,
            state.suggested_wait_seconds,
        )

    return state
