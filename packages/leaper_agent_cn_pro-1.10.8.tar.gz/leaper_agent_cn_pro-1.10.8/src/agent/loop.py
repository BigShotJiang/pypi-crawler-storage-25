"""
AgentLoop - 核心对话循环

负责：
1. 接收用户消息
2. 调用 provider 获取 LLM 响应
3. 处理 tool_calls 并循环
4. 注入记忆上下文（recall）
5. 后台异步提取知识（extract_and_learn）
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any, Callable, Protocol

try:
    from ..providers.base import Message, Response
except ImportError:
    from providers.base import Message, Response

try:
    from ..tools.base import Tool
except ImportError:
    from tools.base import Tool

from .onboarding import OnboardingManager
from .session import SessionManager
from .context import ContextEngine
from .compressor import compress_if_needed, estimate_messages_tokens
from .error_classifier import classify_error
from .rate_limiter import RateLimiter
from .retry import retry_with_backoff
from . import context_engine as ctx_engine_mod
from . import insights as insights_mod
from . import model_meta
from .credential_pool import CredentialPool, AllCredentialsExhausted

logger = logging.getLogger(__name__)


class Provider(Protocol):
    """LLM Provider 协议 - 支持返回 Response 对象或 dict"""
    async def chat(self, messages: list[Message], tools: list[dict] | None = None) -> Response: ...


class Brain(Protocol):
    """Brain 记忆协议 - 兼容 core.py 和 engine.py 的 LeaperBrain"""
    async def recall(self, query: str, top_k: int = 5) -> list[dict]: ...
    async def extract_and_learn(self, user_msg: str, assistant_msg: str) -> None: ...


# Tool 结果最大字符数
MAX_TOOL_RESULT_CHARS = 4000


class AgentLoop:
    """核心 Agent 对话循环"""

    def __init__(
        self,
        provider: Provider,
        brain: Brain | None = None,
        tools: dict[str, Any] | None = None,
        system_prompt: str = "",
        workspace_dir: str = "",
        agent_id: str = "default",
        user_id: str = "default",
        skill_manager=None,
        model_name: str = "",
        api_keys: list[str] | None = None,
        step_callback: Callable | None = None,
    ):
        self.provider = provider
        self.brain = brain
        # tools 支持 {name: Tool} 或 {name: Callable}，统一存储
        self.tools = tools or {}
        self.system_prompt = system_prompt
        self.workspace_dir = workspace_dir
        self.skill_manager = skill_manager  # SkillManager 实例
        self._history: list[dict] = []
        self._onboarding = OnboardingManager(brain, workspace_dir)
        self._agent_id = agent_id
        self._user_id = user_id
        self._rate_limiter = RateLimiter(max_calls=30, window_seconds=60.0)

        # session + context engine（brain 可用时启用持久化）
        self._session_manager: SessionManager | None = None
        self._context_engine: ContextEngine | None = None
        self._session_id: str | None = None

        # 路线 D 增强：model_meta + credential_pool + insights
        self._model_name = model_name
        self._model_max_tokens = model_meta.get_max_tokens(model_name) if model_name else 100000
        self._credential_pool: CredentialPool | None = None
        if api_keys and len(api_keys) > 1:
            self._credential_pool = CredentialPool(api_keys)
        self._turn_count = 0
        self._loop_check_interval = 5  # 每 5 轮检查一次死循环
        self._step_callback = step_callback

        # Orchestrator（brain 可用时启用生命周期钩子）
        self._orchestrator = None
        if brain and workspace_dir:
            try:
                from ..brain.orchestrator import LeaperOrchestrator
                db_path = getattr(brain, 'db_path', None) or getattr(getattr(brain, 'db', None), '_path', '')
                if db_path:
                    self._orchestrator = LeaperOrchestrator(
                        agent_id=agent_id,
                        db_path=str(db_path),
                        workspace_dir=workspace_dir,
                    )
            except Exception:
                pass  # orchestrator 是增强功能，不影响核心流程

    async def _ensure_session(self) -> str | None:
        """确保 session 已初始化（懒加载）"""
        if self._session_id:
            return self._session_id
        if not self.brain or not hasattr(self.brain, "db"):
            return None
        try:
            if self._session_manager is None:
                self._session_manager = SessionManager(self.brain)
                await self._session_manager.ensure_tables()
                self._context_engine = ContextEngine(
                    self.brain, self._session_manager, self.workspace_dir
                )
            self._session_id = await self._session_manager.get_or_create(
                self._agent_id, self._user_id
            )
            # 初始化 orchestrator（懒加载，仅首次）
            if self._orchestrator and not self._orchestrator._initialized:
                try:
                    await self._orchestrator.initialize()
                except Exception:
                    self._orchestrator = None  # 初始化失败则禁用
            return self._session_id
        except Exception:
            return None

    async def _recall_memories(self, query: str, max_tokens: int = 800) -> str:
        """调用 brain.recall 获取相关记忆，按 confidence 排序，token budget 裁剪"""
        if not self.brain or not hasattr(self.brain, "recall"):
            return ""
        try:
            memories = await self.brain.recall(query)
        except TypeError:
            try:
                memories = await self.brain.recall(query=query, limit=10)
            except Exception:
                return ""
        except Exception:
            return ""

        if not memories:
            return ""

        # 按 confidence 降序排序
        sorted_memories = sorted(
            memories,
            key=lambda e: (e.get("confidence", 0) if isinstance(e, dict) else 0),
            reverse=True,
        )

        # Token budget 裁剪（1 token ≈ 2 中文字符 or 4 英文字符）
        lines: list[str] = []
        used_tokens = 10  # "[相关记忆]\n" header
        for entry in sorted_memories:
            if isinstance(entry, dict):
                text = entry.get("content", "") or entry.get("text", "") or str(entry)
                cat = entry.get("category", "")
            else:
                text = str(entry)
                cat = ""

            if len(text) > 300:
                text = text[:300] + "…"

            line = f"- [{cat}] {text}" if cat else f"- {text}"

            # 估算 token: 中文按2字/token, 英文按4字/token, 取混合估算
            line_tokens = len(line) // 2
            if used_tokens + line_tokens > max_tokens:
                break

            lines.append(line)
            used_tokens += line_tokens

        if not lines:
            return ""
        return "[相关记忆]\n" + "\n".join(lines)

    async def _safe_extract(self, user_msg: str, content: str):
        """安全地后台提取知识，包含历史上下文用于 correction 检测"""
        try:
            # Build conversation with recent history for correction detection
            conversation = []
            # Include last 4 messages from in-memory history (before current turn)
            recent = self._history[-(4 + 2):-2] if len(self._history) > 2 else []
            for msg in recent:
                conversation.append({"role": msg.get("role", ""), "content": msg.get("content", "")})
            conversation.append({"role": "user", "content": user_msg})
            conversation.append({"role": "assistant", "content": content})

            if hasattr(self.brain, "extract_knowledge"):
                await self.brain.extract_knowledge(conversation)
            else:
                await self.brain.extract_and_learn(user_msg, content)
        except Exception:
            pass

    async def _safe_orchestrator_turn_end(self, session_id: str, user_msg: str, content: str):
        """安全地调用 orchestrator.on_turn_end（存消息+提取知识+触发进化）"""
        try:
            await self._orchestrator.on_turn_end(session_id, user_msg, content)
        except Exception as e:
            # orchestrator 失败时回退到基础 extract
            import logging
            logging.getLogger("leaper.loop").debug("orchestrator.on_turn_end failed: %s", e)
            try:
                if self.brain and hasattr(self.brain, "extract_and_learn"):
                    await self.brain.extract_and_learn(user_msg, content)
            except Exception:
                pass

    def _normalize_response(self, response) -> dict:
        """将 Response 对象或 dict 统一为 dict 格式（兼容层）"""
        if isinstance(response, Response):
            return {
                "content": response.content,
                "tool_calls": response.tool_calls,
                "finish_reason": response.finish_reason,
            }
        # 已经是 dict（兼容旧测试）
        return response

    def _normalize_tool_calls(self, tool_calls) -> list[dict]:
        """将 tool_calls（可能是对象列表）规范化为纯 dict 列表，确保可 JSON 序列化"""
        if not tool_calls:
            return []
        result = []
        for tc in tool_calls:
            if isinstance(tc, dict):
                result.append(tc)
            else:
                # 对象格式 → dict
                result.append({
                    "id": getattr(tc, "id", "") or "",
                    "type": "function",
                    "function": {
                        "name": getattr(tc.function, "name", "") if hasattr(tc, "function") else "",
                        "arguments": getattr(tc.function, "arguments", "{}") if hasattr(tc, "function") else "{}",
                    },
                })
        return result

    def _to_messages(self, dicts: list[dict]) -> list[Message]:
        """将内部 dict 格式消息列表转为 Message 对象列表，传给 provider"""
        result = []
        for d in dicts:
            result.append(Message(
                role=d["role"],
                content=d.get("content"),
                tool_calls=d.get("tool_calls"),
                tool_call_id=d.get("tool_call_id"),
                name=d.get("name"),
            ))
        return result

    def _sanitize_messages(self, messages: list[dict]) -> list[dict]:
        """清理消息列表，确保 tool_calls 和 tool results 配对完整。

        规则：
        1. 收集所有 assistant 消息中的 tool_call_id 集合
        2. 收集所有 tool result 消息中的 tool_call_id 集合
        3. 删除孤立的 tool result（其 tool_call_id 不在 assistant tool_calls 中）
        4. 孤立的 assistant tool_calls（没有对应 tool result）→ 注入 stub result
           而不是删除 assistant 消息，保留模型的推理上下文

        返回清理后的新列表（不修改原列表）。
        """
        # 第一遍：收集所有 assistant tool_call_ids 和 tool result ids
        assistant_tc_ids: set[str] = set()
        tool_result_ids: set[str] = set()

        for msg in messages:
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                for tc in msg["tool_calls"]:
                    tc_id = tc.get("id", "")
                    if tc_id:
                        assistant_tc_ids.add(tc_id)
            elif msg.get("role") == "tool" and msg.get("tool_call_id"):
                tool_result_ids.add(msg["tool_call_id"])

        # 找出缺失 result 的 tool_call_ids
        orphan_call_ids = assistant_tc_ids - tool_result_ids

        # 第二遍：过滤孤立 tool results，保留 assistant 消息
        result: list[dict] = []
        for msg in messages:
            role = msg.get("role")

            if role == "tool":
                tc_id = msg.get("tool_call_id", "")
                if tc_id and tc_id not in assistant_tc_ids:
                    # 孤立的 tool result（没有对应的 assistant tool_calls），删除
                    continue
                result.append(msg)
            else:
                result.append(msg)

        # 第三遍：为孤立的 tool_calls 注入 stub result
        if orphan_call_ids:
            # 找到每个孤立 call_id 对应的 assistant 消息位置，在其后注入 stub
            injected: list[dict] = []
            for msg in result:
                injected.append(msg)
                if msg.get("role") == "assistant" and msg.get("tool_calls"):
                    for tc in msg["tool_calls"]:
                        tc_id = tc.get("id", "")
                        if tc_id in orphan_call_ids:
                            injected.append({
                                "role": "tool",
                                "tool_call_id": tc_id,
                                "content": "[结果不可用 — 请参考上下文摘要]",
                            })
            result = injected

        return result

    async def chat(self, user_message: str) -> str:
        """处理一次用户消息，返回助手回复"""
        # 尝试启用持久化 session
        session_id = await self._ensure_session()

        # 持久化模式：用 ContextEngine 构建 context
        if session_id and self._session_manager and self._context_engine:
            return await self._chat_with_session(user_message, session_id)

        # 回退到原始 in-memory 模式
        return await self._chat_in_memory(user_message)

    async def _chat_with_session(self, user_message: str, session_id: str) -> str:
        """持久化模式的对话处理"""
        sm = self._session_manager
        ce = self._context_engine

        # 1. 持久化用户消息
        await sm.add_message(session_id, "user", user_message)

        # 2. 构建 context
        onboarding_needed = await self._onboarding.async_needs_onboarding()
        onboarding_prompt = ""
        if onboarding_needed:
            onboarding_prompt = self._onboarding.get_onboarding_prompt() or ""

        messages = await ce.build_context(
            session_id, user_message,
            system_prompt=self.system_prompt,
            onboarding_prompt=onboarding_prompt,
        )

        # 也同步到 in-memory history（兼容 onboarding 检查等）
        self._history.append({"role": "user", "content": user_message})

        # 工具定义
        tool_defs = self._build_tool_defs()

        # 记录 tool 调用前的 messages 长度，用于提取 tool 结果
        pre_tool_len = len(messages)

        # 循环处理 tool_calls
        content = await self._run_tool_loop(messages, tool_defs, onboarding_needed, user_message)

        # 持久化中间 tool 消息到 session DB（完整格式，包括 tool_calls 和 tool results）
        tool_messages = messages[pre_tool_len:]
        for msg in tool_messages:
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                # assistant with tool_calls
                await sm.add_message(
                    session_id, "assistant", msg.get("content") or "",
                    tool_calls=msg["tool_calls"],
                )
            elif msg.get("role") == "tool":
                # tool result
                await sm.add_message(
                    session_id, "tool", msg.get("content", ""),
                    tool_call_id=msg.get("tool_call_id"),
                    tool_name=msg.get("name"),
                )

        # 每 N 轮检查死循环
        self._turn_count += 1
        if self._turn_count % self._loop_check_interval == 0:
            if insights_mod.detect_loop(self._history):
                content += "\n\n⚠️ 检测到可能的循环调用，建议调整策略。"

        # 4. 持久化助手回复
        await sm.add_message(session_id, "assistant", content)

        # 5. 后台知识提取 + 生命周期钩子
        if self._orchestrator and self._orchestrator._initialized:
            asyncio.create_task(self._safe_orchestrator_turn_end(session_id, user_message, content))
        elif self.brain and hasattr(self.brain, "extract_and_learn"):
            asyncio.create_task(self._safe_extract(user_message, content))

        return content

    async def _chat_in_memory(self, user_message: str) -> str:
        """原始 in-memory 模式（无 brain.db 时的回退）"""
        # 历史长度限制：超过 80 条消息（40 轮）截断保留最近 40 条（20 轮）
        if len(self._history) > 80:
            self._history = self._history[-40:]

        # 冷启动引导检查
        onboarding_needed = await self._onboarding.async_needs_onboarding()

        # 记忆召回注入
        memory_context = await self._recall_memories(user_message)

        # 构建消息列表（内部用 dict，传给 provider 前转 Message）
        messages = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        if onboarding_needed:
            onboarding_prompt = self._onboarding.get_onboarding_prompt()
            if onboarding_prompt:
                messages.append({"role": "system", "content": onboarding_prompt})
        if memory_context:
            messages.append({"role": "system", "content": memory_context})
        messages.extend(self._history)
        messages.append({"role": "user", "content": user_message})

        self._history.append({"role": "user", "content": user_message})

        tool_defs = self._build_tool_defs()

        # 循环处理 tool_calls
        content = await self._run_tool_loop(messages, tool_defs, onboarding_needed, user_message)

        # 后台异步提取知识（不阻塞回复）
        if self._orchestrator and self._orchestrator._initialized:
            asyncio.create_task(self._safe_orchestrator_turn_end("memory", user_message, content))
        elif self.brain and hasattr(self.brain, "extract_and_learn"):
            asyncio.create_task(self._safe_extract(user_message, content))
        return content

    def _build_tool_defs(self) -> list[dict] | None:
        """构建工具定义列表（含 skill_manager 的技能）"""
        tool_defs = []
        for k, v in (self.tools or {}).items():
            if isinstance(v, Tool):
                tool_defs.append({
                    "type": "function",
                    "function": {
                        "name": v.name,
                        "description": v.description,
                        "parameters": v.parameters,
                    },
                })
            else:
                tool_defs.append({"type": "function", "function": {"name": k}})
        # 注入 skill_manager 的技能
        if self.skill_manager:
            tool_defs.extend(self.skill_manager.to_tool_defs())
        return tool_defs if tool_defs else None

    # ─── 去重和模糊匹配辅助方法 ──────────────────────────────────

    @staticmethod
    def _deduplicate_tool_calls(tool_calls: list[dict], max_delegates: int = 3) -> list[dict]:
        """去重 + delegate 并发限制。

        规则：
        1. (tool_name, arguments) 完全相同的 tool_call 只保留第一个
        2. delegate_task 类型的调用最多保留 max_delegates 个

        Args:
            tool_calls: 原始 tool_calls 列表
            max_delegates: delegate_task 最大并发数

        Returns:
            去重后的 tool_calls 列表
        """
        if not tool_calls:
            return tool_calls

        seen: set[str] = set()
        delegate_count = 0
        result: list[dict] = []

        for tc in tool_calls:
            func = tc.get("function", {})
            name = func.get("name", "")
            args = func.get("arguments", "{}")

            # 去重 key
            dedup_key = f"{name}:{args}"
            if dedup_key in seen:
                logger.debug("去重跳过重复 tool_call: %s", name)
                continue
            seen.add(dedup_key)

            # delegate 并发限制
            if name == "delegate_task":
                delegate_count += 1
                if delegate_count > max_delegates:
                    logger.warning("delegate_task 超过并发限制 %d，截断", max_delegates)
                    continue

            result.append(tc)

        return result

    @staticmethod
    def _levenshtein(s1: str, s2: str) -> int:
        """简单 Levenshtein 距离实现（无外部依赖）"""
        if len(s1) < len(s2):
            return AgentLoop._levenshtein(s2, s1)
        if len(s2) == 0:
            return len(s1)
        prev_row = list(range(len(s2) + 1))
        for i, c1 in enumerate(s1):
            curr_row = [i + 1]
            for j, c2 in enumerate(s2):
                cost = 0 if c1 == c2 else 1
                curr_row.append(min(
                    curr_row[j] + 1,
                    prev_row[j + 1] + 1,
                    prev_row[j] + cost,
                ))
            prev_row = curr_row
        return prev_row[-1]

    def _fuzzy_match_tool(self, tool_name: str) -> str | None:
        """模糊匹配工具名。

        规则：
        1. 忽略大小写
        2. 忽略下划线/连字符差异
        3. Levenshtein distance ≤ 2

        Returns:
            匹配到的工具名，或 None
        """
        registered = list(self.tools.keys())
        if self.skill_manager:
            registered.extend(s.name for s in self.skill_manager.get_all_skills())

        if not registered:
            return None

        def normalize(s: str) -> str:
            return s.lower().replace("-", "_")

        norm_name = normalize(tool_name)

        # 精确归一化匹配
        for name in registered:
            if normalize(name) == norm_name:
                logger.info("工具名模糊修复: %s → %s（大小写/连字符）", tool_name, name)
                return name

        # Levenshtein ≤ 2
        best_match = None
        best_dist = 3  # 阈值
        for name in registered:
            dist = self._levenshtein(norm_name, normalize(name))
            if dist < best_dist:
                best_dist = dist
                best_match = name

        if best_match:
            logger.info("工具名模糊修复: %s → %s（编辑距离 %d）", tool_name, best_match, best_dist)
        return best_match

    def _notify_step(self, step_info: dict) -> None:
        """安全地调用 step_callback，失败不影响主流程"""
        if not self._step_callback:
            return
        try:
            self._step_callback(step_info)
        except Exception:
            pass  # callback 失败不应影响主流程

    async def _run_tool_loop(
        self, messages: list[dict], tool_defs: list[dict] | None,
        onboarding_needed: bool, user_message: str,
    ) -> str:
        """循环处理 tool_calls，返回最终文本回复"""

        # 构造 llm_fn 供压缩器使用（LLM 摘要压缩）
        async def _llm_fn(msgs: list[dict]) -> str:
            resp = await self.provider.chat(self._to_messages(msgs))
            normalized = self._normalize_response(resp)
            return normalized.get("content", "") or ""

        # #7 Preflight compression — 进入 tool 循环前预检 token 压力
        current_tokens = estimate_messages_tokens(messages)
        preflight_threshold = int(self._model_max_tokens * 0.85)
        if current_tokens > preflight_threshold:
            logger.info("⚡ Preflight compression: %d token > 85%% 阈值 %d，提前压缩",
                        current_tokens, preflight_threshold)
            self._notify_step({"step": 0, "action": "compression", "status": "started"})
            messages = await compress_if_needed(messages, max_tokens=self._model_max_tokens, keep_recent=20, llm_fn=_llm_fn)
            self._notify_step({"step": 0, "action": "compression", "status": "completed"})

        # 常规压缩（向后兼容）
        messages = await compress_if_needed(messages, max_tokens=self._model_max_tokens, keep_recent=20, llm_fn=_llm_fn)

        max_rounds = 10
        for iteration in range(max_rounds):
            # 限流检查
            await self._rate_limiter.wait_if_needed()
            self._rate_limiter.record_call()

            # 清理消息配对，防止 API 400 错误
            sanitized = self._sanitize_messages(messages)

            # #15 step_callback 进度推送
            step_start = time.monotonic()
            self._notify_step({
                "step": iteration + 1,
                "action": "api_call",
                "status": "started",
            })

            # 带重试的 API 调用
            try:
                raw_response = await retry_with_backoff(
                    self.provider.chat,
                    self._to_messages(sanitized),
                    tools=tool_defs,
                    max_retries=2,
                )
            except Exception as exc:
                error_info = classify_error(exc)
                self._notify_step({
                    "step": iteration + 1,
                    "action": "api_call",
                    "status": "error",
                    "duration_ms": int((time.monotonic() - step_start) * 1000),
                })
                # #5 使用 ErrorInfo 恢复提示字段
                if error_info.should_compress:
                    messages = await compress_if_needed(messages, max_tokens=128000, keep_recent=10, llm_fn=_llm_fn)
                    sanitized = self._sanitize_messages(messages)
                    raw_response = await self.provider.chat(self._to_messages(sanitized), tools=tool_defs)
                else:
                    raise

            duration_ms = int((time.monotonic() - step_start) * 1000)
            self._notify_step({
                "step": iteration + 1,
                "action": "api_call",
                "status": "completed",
                "duration_ms": duration_ms,
            })

            response = self._normalize_response(raw_response)

            # #9 Context pressure 预警
            post_tokens = estimate_messages_tokens(messages)
            if self._model_max_tokens > 0:
                pct = post_tokens / self._model_max_tokens
                if pct > 0.80:
                    logger.warning("⚠️ Context pressure: %.0f%% used", pct * 100)

            if not response.get("tool_calls"):
                content = response.get("content", "") or ""
                self._history.append({"role": "assistant", "content": content})

                if onboarding_needed and self._onboarding.check_onboarding_complete(self._history):
                    user_info = await self._onboarding.extract_user_info(self._history)
                    if user_info:
                        await self._onboarding.complete_onboarding(user_info)

                return content

            # #10 去重和 delegate 并发限制
            raw_tool_calls = self._normalize_tool_calls(response["tool_calls"])
            deduped_tool_calls = self._deduplicate_tool_calls(raw_tool_calls)

            assistant_msg = {"role": "assistant", "tool_calls": deduped_tool_calls}
            messages.append(assistant_msg)
            self._history.append(assistant_msg)

            for tc in assistant_msg["tool_calls"]:
                func_name = tc["function"]["name"]
                func_args_raw = tc["function"].get("arguments", {})
                if isinstance(func_args_raw, str):
                    try:
                        func_args = json.loads(func_args_raw) if func_args_raw else {}
                    except json.JSONDecodeError:
                        func_args = {}
                else:
                    func_args = func_args_raw

                # #11 工具名模糊修复
                resolved_name = func_name
                if func_name not in self.tools:
                    # 检查 skill_manager
                    skill_names = [s.name for s in self.skill_manager.get_all_skills()] if self.skill_manager else []
                    if func_name not in skill_names:
                        fuzzy = self._fuzzy_match_tool(func_name)
                        if fuzzy:
                            resolved_name = fuzzy

                tc_start = time.monotonic()
                self._notify_step({
                    "step": iteration + 1,
                    "action": "tool_call",
                    "tool_name": resolved_name,
                    "status": "started",
                })

                if resolved_name in self.tools:
                    tool_or_fn = self.tools[resolved_name]
                    if isinstance(tool_or_fn, Tool):
                        result = await tool_or_fn.execute(func_args)
                    elif asyncio.iscoroutinefunction(tool_or_fn):
                        result = await tool_or_fn(**func_args)
                    else:
                        result = tool_or_fn(**func_args)
                elif self.skill_manager and resolved_name in [s.name for s in self.skill_manager.get_all_skills()]:
                    result = await self.skill_manager.execute_skill(resolved_name, func_args)
                else:
                    result = f"工具 {func_name} 不存在"

                tc_duration = int((time.monotonic() - tc_start) * 1000)
                self._notify_step({
                    "step": iteration + 1,
                    "action": "tool_call",
                    "tool_name": resolved_name,
                    "status": "completed",
                    "duration_ms": tc_duration,
                })

                # Tool 结果截断
                result_str = str(result)
                if len(result_str) > MAX_TOOL_RESULT_CHARS:
                    original_len = len(result_str)
                    result_str = result_str[:MAX_TOOL_RESULT_CHARS] + f"\n...[结果已截断，原始长度: {original_len}字符]"

                tool_msg = {
                    "role": "tool",
                    "tool_call_id": tc.get("id", ""),
                    "content": result_str,
                }
                messages.append(tool_msg)
                self._history.append(tool_msg)

        return "达到最大工具调用轮数"

    # ─── 增强方法：完整 Agent Loop API ──────────────────────────────

    async def handle_message(self, session_id: str, message: str) -> str:
        """完整消息处理（含历史、记忆召回、工具调用）

        Args:
            session_id: 会话 ID（用于持久化历史）
            message: 用户消息文本

        Returns:
            助手回复文本
        """
        # 确保 session 基础设施就绪
        await self._ensure_session()

        # 如果有持久化能力，强制使用指定 session_id
        if self._session_manager and self._context_engine:
            # 覆盖内部 session_id 为调用者指定的
            old_sid = self._session_id
            self._session_id = session_id
            try:
                return await self._chat_with_session(message, session_id)
            finally:
                self._session_id = old_sid
        else:
            # 无持久化时回退到内存模式
            return await self._chat_in_memory(message)

    async def handle_tool_call(self, tool_name: str, arguments: dict) -> str:
        """工具调用分发 — 直接执行指定工具并返回结果

        Args:
            tool_name: 工具名称
            arguments: 工具参数字典

        Returns:
            工具执行结果字符串
        """
        if tool_name in self.tools:
            tool_or_fn = self.tools[tool_name]
            if isinstance(tool_or_fn, Tool):
                result = await tool_or_fn.execute(arguments)
            elif asyncio.iscoroutinefunction(tool_or_fn):
                result = await tool_or_fn(**arguments)
            else:
                result = tool_or_fn(**arguments)
            return str(result)

        # 检查 skill_manager
        if self.skill_manager:
            all_skills = self.skill_manager.get_all_skills()
            if tool_name in [s.name for s in all_skills]:
                result = await self.skill_manager.execute_skill(tool_name, arguments)
                return str(result)

        return f"工具 {tool_name} 不存在"

    async def stream_chat(self, session_id: str, message: str):
        """流式响应 — async generator，逐块 yield 回复内容

        Args:
            session_id: 会话 ID
            message: 用户消息

        Yields:
            str: 回复文本片段
        """
        # 当前实现：先获取完整回复，再按句分块 yield
        # 后续可对接 provider 的原生 streaming 接口
        full_response = await self.handle_message(session_id, message)

        # 按标点符号分块输出，模拟流式效果
        import re as _re
        chunks = _re.split(r'(?<=[。！？\n.!?])', full_response)
        for chunk in chunks:
            if chunk:
                yield chunk

    async def get_history(self, session_id: str, limit: int = 50) -> list[dict]:
        """获取对话历史

        Args:
            session_id: 会话 ID
            limit: 最大返回条数

        Returns:
            消息列表 [{"role": str, "content": str}, ...]
        """
        # 优先使用持久化 session
        if self._session_manager:
            try:
                return await self._session_manager.get_history(session_id, limit=limit)
            except Exception:
                pass

        # 回退到内存历史
        return self._history[-limit:] if self._history else []

    async def clear_history(self, session_id: str) -> bool:
        """清空对话历史

        Args:
            session_id: 会话 ID

        Returns:
            是否成功清空
        """
        # 清空内存历史
        self._history.clear()

        # 清空持久化历史（如果有）
        if self._session_manager and hasattr(self._session_manager, 'db'):
            try:
                db = self._session_manager.db
                await db.execute(
                    "DELETE FROM messages WHERE session_id = ?",
                    (session_id,),
                )
                await db.commit()
            except Exception:
                pass  # 表可能不存在，静默处理

        return True
