"""
SessionManager - 多轮对话持久化 + context window 管理

基于 brain 的 SQLite DB 存储会话和消息，支持：
- 会话创建/恢复（30 分钟超时自动新建）
- 消息持久化
- 智能 context window（最近消息 + 旧消息摘要）
- 文件级 session persistence（save/load/list/delete）
- Session scope 隔离（dm/group/isolated）
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import List, Optional

# 30 分钟无活动自动创建新会话
SESSION_TIMEOUT_MINUTES = 30

# 估算 token 数：1 中文字 ≈ 2 tokens，1 英文词 ≈ 1.3 tokens
def _estimate_tokens(text: str) -> int:
    """粗略估算 token 数"""
    if not text:
        return 0
    cn_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    rest = len(text) - cn_chars
    return cn_chars * 2 + max(rest // 4, 1)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_iso(s: str) -> datetime:
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


# 建表 SQL（在 brain initialize 时执行）
SESSIONS_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    last_active TEXT NOT NULL,
    summary TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sessions_agent_user ON sessions(agent_id, user_id);
"""


class SessionManager:
    """会话管理器：多轮对话持久化 + context window"""

    def __init__(self, brain):
        """使用 brain 的 db 存储会话

        brain 需要有 .db 属性（aiosqlite.Connection）和 .initialize() 已调用。
        """
        self.brain = brain

    @property
    def db(self):
        return self.brain.db

    async def ensure_tables(self) -> None:
        """确保 sessions 表存在（幂等）"""
        await self.db.executescript(SESSIONS_SCHEMA_SQL)
        await self.db.commit()

    async def create_session(self, agent_id: str, user_id: str) -> str:
        """创建新会话，返回 session_id"""
        session_id = uuid.uuid4().hex
        now = _now_iso()
        await self.db.execute(
            "INSERT INTO sessions (id, agent_id, user_id, created_at, last_active, summary) "
            "VALUES (?, ?, ?, ?, ?, '')",
            (session_id, agent_id, user_id, now, now),
        )
        await self.db.commit()
        return session_id

    async def get_or_create(self, agent_id: str, user_id: str) -> str:
        """获取最近活跃会话或创建新的（30 分钟超时）"""
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(minutes=SESSION_TIMEOUT_MINUTES)

        async with self.db.execute(
            "SELECT id, last_active FROM sessions "
            "WHERE agent_id = ? AND user_id = ? "
            "ORDER BY last_active DESC LIMIT 1",
            (agent_id, user_id),
        ) as cur:
            row = await cur.fetchone()

        if row:
            last_active = _parse_iso(row[1] if isinstance(row, (list, tuple)) else row["last_active"])
            if last_active >= cutoff:
                session_id = row[0] if isinstance(row, (list, tuple)) else row["id"]
                return session_id

        # 超时或无会话，创建新的
        return await self.create_session(agent_id, user_id)

    async def _touch_session(self, session_id: str) -> None:
        """更新会话最后活跃时间"""
        await self.db.execute(
            "UPDATE sessions SET last_active = ? WHERE id = ?",
            (_now_iso(), session_id),
        )

    async def add_message(
        self, session_id: str, role: str, content: str,
        tool_calls: list | None = None, tool_call_id: str | None = None,
        tool_name: str | None = None,
    ) -> None:
        """添加消息到会话（存入 brain 的 messages 表）

        Args:
            session_id: 会话 ID
            role: 消息角色 (user/assistant/tool)
            content: 消息内容
            tool_calls: assistant 消息的 tool_calls 列表（JSON 序列化存储）
            tool_call_id: tool 消息对应的 tool_call_id
            tool_name: tool 消息对应的工具名称
        """
        import json as _json
        msg_id = uuid.uuid4().hex
        now = _now_iso()
        tool_calls_json = _json.dumps(tool_calls, ensure_ascii=False) if tool_calls else None
        await self.db.execute(
            "INSERT INTO messages (id, agent_id, session_id, role, content, tool_calls, tool_call_id, tool_name, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (msg_id, self.brain.agent_id, session_id, role, content, tool_calls_json, tool_call_id, tool_name, now),
        )
        await self._touch_session(session_id)
        await self.db.commit()

    async def get_history(self, session_id: str, limit: int = 50) -> list[dict]:
        """获取会话历史（按时间正序），包含完整的 tool_calls/tool_call_id/tool_name 字段"""
        import json as _json
        async with self.db.execute(
            "SELECT role, content, tool_calls, tool_call_id, tool_name, created_at FROM messages "
            "WHERE session_id = ? ORDER BY created_at ASC LIMIT ?",
            (session_id, limit),
        ) as cur:
            rows = await cur.fetchall()
        result = []
        for r in rows:
            if isinstance(r, (list, tuple)):
                role, content, tool_calls_json, tool_call_id, tool_name = r[0], r[1], r[2], r[3], r[4]
            else:
                role = r["role"]
                content = r["content"]
                tool_calls_json = r["tool_calls"] if "tool_calls" in r.keys() else None
                tool_call_id = r["tool_call_id"] if "tool_call_id" in r.keys() else None
                tool_name = r["tool_name"] if "tool_name" in r.keys() else None

            msg: dict = {"role": role, "content": content or ""}

            # 还原 assistant 的 tool_calls
            if role == "assistant" and tool_calls_json:
                try:
                    msg["tool_calls"] = _json.loads(tool_calls_json)
                    if not content:
                        msg["content"] = None
                except (ValueError, TypeError):
                    pass

            # 还原 tool result 消息
            if role == "tool" and tool_call_id:
                msg["tool_call_id"] = tool_call_id
                if tool_name:
                    msg["name"] = tool_name

            result.append(msg)
        return result

    async def get_context_window(self, session_id: str, max_tokens: int = 32000) -> list[dict]:
        """智能 context window：从最新消息往回取，不超过 token 预算

        恢复完整的 tool_calls 和 tool result 消息格式。
        """
        import json as _json
        # 取最近 200 条，然后按 token 预算裁剪
        async with self.db.execute(
            "SELECT role, content, tool_calls, tool_call_id, tool_name FROM ("
            "  SELECT role, content, tool_calls, tool_call_id, tool_name, created_at FROM messages "
            "  WHERE session_id = ? ORDER BY created_at DESC LIMIT 200"
            ") sub ORDER BY created_at ASC",
            (session_id,),
        ) as cur:
            rows = await cur.fetchall()

        messages = []
        for r in rows:
            if isinstance(r, (list, tuple)):
                role, content, tool_calls_json, tool_call_id, tool_name = r[0], r[1], r[2], r[3], r[4]
            else:
                role = r["role"]
                content = r["content"]
                tool_calls_json = r["tool_calls"] if "tool_calls" in r.keys() else None
                tool_call_id = r["tool_call_id"] if "tool_call_id" in r.keys() else None
                tool_name = r["tool_name"] if "tool_name" in r.keys() else None

            msg: dict = {"role": role, "content": content or ""}

            # 还原 assistant 的 tool_calls
            if role == "assistant" and tool_calls_json:
                try:
                    msg["tool_calls"] = _json.loads(tool_calls_json)
                    # DeepSeek 要求有 tool_calls 时 content 可以为 None
                    if not content:
                        msg["content"] = None
                except (ValueError, TypeError):
                    pass

            # 还原 tool result 消息
            if role == "tool" and tool_call_id:
                msg["tool_call_id"] = tool_call_id
                if tool_name:
                    msg["name"] = tool_name

            messages.append(msg)

        if not messages:
            return []

        # 从后往前累计 token，直到超预算
        total = 0
        start_idx = len(messages)
        for i in range(len(messages) - 1, -1, -1):
            tokens = _estimate_tokens(messages[i]["content"])
            if total + tokens > max_tokens:
                break
            total += tokens
            start_idx = i

        # 如果有被截断的旧消息，尝试插入摘要
        result = messages[start_idx:]

        # 如果截断了很多消息，获取会话摘要作为前缀
        if start_idx > 0:
            async with self.db.execute(
                "SELECT summary FROM sessions WHERE id = ?", (session_id,)
            ) as cur:
                row = await cur.fetchone()
            summary = (row[0] if isinstance(row, (list, tuple)) else row["summary"]) if row else ""
            if summary:
                result.insert(0, {"role": "system", "content": f"[历史对话摘要]\n{summary}"})

        return result

    async def summarize_old_messages(self, session_id: str) -> str:
        """将旧消息摘要化（简单实现：取前 N 条的要点拼接）

        注意：完整实现应调用 LLM 做摘要，这里用轻量方案。
        """
        async with self.db.execute(
            "SELECT role, content FROM messages "
            "WHERE session_id = ? ORDER BY created_at ASC LIMIT 50",
            (session_id,),
        ) as cur:
            rows = await cur.fetchall()

        if not rows:
            return ""

        # 轻量摘要：提取每条消息的前 100 字
        parts = []
        for r in rows[:20]:  # 最多取 20 条做摘要
            role = r[0] if isinstance(r, (list, tuple)) else r["role"]
            content = r[1] if isinstance(r, (list, tuple)) else r["content"]
            snippet = content[:100].replace("\n", " ")
            parts.append(f"[{role}] {snippet}")

        summary = "\n".join(parts)

        # 保存摘要到 session
        await self.db.execute(
            "UPDATE sessions SET summary = ? WHERE id = ?",
            (summary, session_id),
        )
        await self.db.commit()
        return summary


# ============================================================
# 文件级 Session Persistence（不依赖 brain/SQLite）
# ============================================================

SESSIONS_DIR_NAME = ".sessions"


@dataclass
class SessionInfo:
    """Session 摘要信息"""
    session_id: str
    agent_id: str
    user_id: str
    created_at: str
    last_active: str
    message_count: int
    summary: str = ""


@dataclass
class FileSession:
    """文件持久化的 Session"""
    session_id: str
    agent_id: str
    user_id: str
    created_at: str
    last_active: str
    summary: str
    messages: List[dict]


def _sessions_dir(workspace_dir: str) -> Path:
    """获取 sessions 存储目录"""
    p = Path(workspace_dir) / SESSIONS_DIR_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def _session_file(workspace_dir: str, session_id: str) -> Path:
    """获取 session 文件路径"""
    # 安全化 session_id
    safe_id = session_id.replace("/", "_").replace("\\", "_")
    return _sessions_dir(workspace_dir) / f"{safe_id}.json"


def save_session(
    session_id: str,
    workspace_dir: str,
    agent_id: str = "",
    user_id: str = "",
    messages: Optional[List[dict]] = None,
    summary: str = "",
) -> None:
    """保存 session 到文件

    Args:
        session_id: 会话 ID
        workspace_dir: workspace 目录
        agent_id: agent 标识
        user_id: 用户标识
        messages: 消息列表
        summary: 会话摘要
    """
    file_path = _session_file(workspace_dir, session_id)
    now = _now_iso()

    # 尝试加载已有数据（保留 created_at）
    existing_created = now
    if file_path.exists():
        try:
            data = json.loads(file_path.read_text(encoding="utf-8"))
            existing_created = data.get("created_at", now)
        except (json.JSONDecodeError, OSError):
            pass

    session_data = {
        "session_id": session_id,
        "agent_id": agent_id,
        "user_id": user_id,
        "created_at": existing_created,
        "last_active": now,
        "summary": summary,
        "messages": messages or [],
    }

    tmp_path = file_path.with_suffix(".tmp")
    try:
        tmp_path.write_text(
            json.dumps(session_data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        tmp_path.replace(file_path)
    except OSError:
        tmp_path.unlink(missing_ok=True)
        raise


def load_session(
    session_id: str,
    workspace_dir: str,
) -> Optional[FileSession]:
    """从文件加载 session

    Args:
        session_id: 会话 ID
        workspace_dir: workspace 目录

    Returns:
        FileSession 或 None（不存在时）
    """
    file_path = _session_file(workspace_dir, session_id)
    if not file_path.exists():
        return None

    try:
        data = json.loads(file_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None

    return FileSession(
        session_id=data.get("session_id", session_id),
        agent_id=data.get("agent_id", ""),
        user_id=data.get("user_id", ""),
        created_at=data.get("created_at", ""),
        last_active=data.get("last_active", ""),
        summary=data.get("summary", ""),
        messages=data.get("messages", []),
    )


def list_sessions(workspace_dir: str) -> List[SessionInfo]:
    """列出所有已保存的 session

    Args:
        workspace_dir: workspace 目录

    Returns:
        SessionInfo 列表，按 last_active 倒序
    """
    sessions_path = Path(workspace_dir) / SESSIONS_DIR_NAME
    if not sessions_path.is_dir():
        return []

    results: List[SessionInfo] = []
    for file_path in sessions_path.glob("*.json"):
        try:
            data = json.loads(file_path.read_text(encoding="utf-8"))
            results.append(SessionInfo(
                session_id=data.get("session_id", file_path.stem),
                agent_id=data.get("agent_id", ""),
                user_id=data.get("user_id", ""),
                created_at=data.get("created_at", ""),
                last_active=data.get("last_active", ""),
                message_count=len(data.get("messages", [])),
                summary=data.get("summary", ""),
            ))
        except (json.JSONDecodeError, OSError):
            continue

    # 按 last_active 倒序
    results.sort(key=lambda s: s.last_active, reverse=True)
    return results


def delete_session(session_id: str, workspace_dir: str) -> bool:
    """删除 session 文件

    Args:
        session_id: 会话 ID
        workspace_dir: workspace 目录

    Returns:
        True 表示删除成功，False 表示文件不存在
    """
    file_path = _session_file(workspace_dir, session_id)
    if file_path.exists():
        file_path.unlink()
        return True
    return False


# ============================================================
# Session Scope 隔离
# ============================================================

class SessionScope:
    """Session scope 常量"""
    DM = "dm"           # 私聊 session（默认）
    GROUP = "group"     # 群聊 session
    ISOLATED = "isolated"  # 隔离 session（cron/子任务）


def make_scoped_session_id(
    scope: str = SessionScope.DM,
    user_id: str = "",
    agent_id: str = "",
) -> str:
    """生成带 scope 的 session ID

    格式: {scope}:{user_id}:{agent_id}

    Args:
        scope: session scope (dm/group/isolated)
        user_id: 用户 ID
        agent_id: agent ID

    Returns:
        编码了 scope 的 session ID
    """
    return f"{scope}:{user_id}:{agent_id}"


def parse_scoped_session_id(session_id: str) -> tuple[str, str, str]:
    """从 scoped session ID 解析 scope, user_id, agent_id

    Args:
        session_id: 带 scope 的 session ID

    Returns:
        (scope, user_id, agent_id)，无法解析时返回 ("dm", session_id, "")
    """
    parts = session_id.split(":", 2)
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    return SessionScope.DM, session_id, ""


def export_session_jsonl(session_id: str, workspace_dir: str, output_path: str) -> int:
    """便捷方法：将指定 session 导出为 JSONL

    Args:
        session_id: 会话 ID
        workspace_dir: workspace 目录
        output_path: 输出文件路径

    Returns:
        导出的消息数量
    """
    from .session_export import export_session_jsonl as _export
    session = load_session(session_id, workspace_dir)
    if session is None:
        return 0
    session_dict = {
        "messages": session.messages,
        "session_id": session.session_id,
    }
    return _export(session_dict, output_path)
