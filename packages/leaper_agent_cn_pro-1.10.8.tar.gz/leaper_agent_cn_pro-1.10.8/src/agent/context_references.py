"""Context References 上下文引用管理

功能：
- 文件引用管理（对话中提到的文件）
- URL 引用追踪
- 代码片段引用
- 引用去重
- 引用上下文注入到 prompt
"""

from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class RefType(Enum):
    """引用类型"""
    FILE = "file"
    URL = "url"
    CODE = "code"
    IMAGE = "image"


@dataclass
class ContextRef:
    """单个上下文引用"""
    ref_type: RefType
    source: str          # 文件路径 / URL / 代码标识
    content: str = ""    # 引用内容（可选）
    language: str = ""   # 代码语言（仅 code 类型）
    line_range: Optional[str] = None  # 行范围（如 "10-20"）
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    _hash: str = ""      # 去重用

    def __post_init__(self):
        if not self._hash:
            # 基于 type+source+content 计算哈希
            key = f"{self.ref_type.value}:{self.source}:{self.content[:200]}"
            self._hash = hashlib.md5(key.encode()).hexdigest()[:12]

    @property
    def dedup_key(self) -> str:
        return self._hash


class ContextReferences:
    """上下文引用管理器

    在对话过程中收集和管理引用到的文件、URL、代码片段，
    并支持去重和注入到 prompt 中。
    """

    def __init__(self, max_refs: int = 100, max_content_chars: int = 50000):
        self._refs: List[ContextRef] = []
        self._seen: set = set()  # 去重集合
        self._max_refs = max_refs
        self._max_content_chars = max_content_chars

    def add_file(self, path: str, content: str = "", line_range: Optional[str] = None) -> Optional[ContextRef]:
        """添加文件引用"""
        ref = ContextRef(
            ref_type=RefType.FILE,
            source=path,
            content=content,
            line_range=line_range,
        )
        return self._add(ref)

    def add_url(self, url: str, content: str = "", metadata: Optional[Dict] = None) -> Optional[ContextRef]:
        """添加 URL 引用"""
        ref = ContextRef(
            ref_type=RefType.URL,
            source=url,
            content=content,
            metadata=metadata or {},
        )
        return self._add(ref)

    def add_code(self, source: str, content: str, language: str = "",
                 line_range: Optional[str] = None) -> Optional[ContextRef]:
        """添加代码片段引用"""
        ref = ContextRef(
            ref_type=RefType.CODE,
            source=source,
            content=content,
            language=language,
            line_range=line_range,
        )
        return self._add(ref)

    def add_image(self, path: str, metadata: Optional[Dict] = None) -> Optional[ContextRef]:
        """添加图片引用"""
        ref = ContextRef(
            ref_type=RefType.IMAGE,
            source=path,
            metadata=metadata or {},
        )
        return self._add(ref)

    def _add(self, ref: ContextRef) -> Optional[ContextRef]:
        """内部添加引用（去重）"""
        if ref.dedup_key in self._seen:
            return None
        self._seen.add(ref.dedup_key)
        self._refs.append(ref)
        # 超出上限则移除最早的
        if len(self._refs) > self._max_refs:
            removed = self._refs.pop(0)
            self._seen.discard(removed.dedup_key)
        return ref

    def remove(self, source: str) -> int:
        """移除指定 source 的所有引用，返回移除数量"""
        before = len(self._refs)
        removed_refs = [r for r in self._refs if r.source == source]
        self._refs = [r for r in self._refs if r.source != source]
        for r in removed_refs:
            self._seen.discard(r.dedup_key)
        return before - len(self._refs)

    def clear(self) -> None:
        """清空所有引用"""
        self._refs.clear()
        self._seen.clear()

    def list_refs(self, ref_type: Optional[RefType] = None) -> List[ContextRef]:
        """列出引用，可按类型过滤"""
        if ref_type is None:
            return list(self._refs)
        return [r for r in self._refs if r.ref_type == ref_type]

    def get_files(self) -> List[ContextRef]:
        """获取所有文件引用"""
        return self.list_refs(RefType.FILE)

    def get_urls(self) -> List[ContextRef]:
        """获取所有 URL 引用"""
        return self.list_refs(RefType.URL)

    def get_code_snippets(self) -> List[ContextRef]:
        """获取所有代码片段"""
        return self.list_refs(RefType.CODE)

    @property
    def count(self) -> int:
        return len(self._refs)

    # --- 从消息中自动提取引用 ---

    def extract_from_message(self, message: str) -> List[ContextRef]:
        """从消息文本中自动提取文件路径和 URL 引用"""
        added: List[ContextRef] = []

        # 提取 URL
        url_pattern = re.compile(r'https?://[^\s<>"\')\]]+')
        for url in url_pattern.findall(message):
            ref = self.add_url(url.rstrip(".,;:"))
            if ref:
                added.append(ref)

        # 提取文件路径（Unix 和 Windows）
        # Unix: /path/to/file
        unix_path = re.compile(r'(?:^|\s)(/[a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)')
        for path in unix_path.findall(message):
            ref = self.add_file(path)
            if ref:
                added.append(ref)

        # Windows: C:\path\to\file
        win_path = re.compile(r'(?:^|\s)([A-Z]:\\[^\s<>"]+\.[a-zA-Z0-9]+)')
        for path in win_path.findall(message):
            ref = self.add_file(path)
            if ref:
                added.append(ref)

        return added

    # --- Prompt 注入 ---

    def build_context_block(self) -> str:
        """构建可注入 prompt 的上下文引用块"""
        if not self._refs:
            return ""

        parts: List[str] = []
        total_chars = 0

        # 按类型分组
        files = self.get_files()
        urls = self.get_urls()
        codes = self.get_code_snippets()

        if files:
            parts.append("## 引用文件")
            for ref in files:
                line = f"- `{ref.source}`"
                if ref.line_range:
                    line += f" (行 {ref.line_range})"
                parts.append(line)
                if ref.content and total_chars < self._max_content_chars:
                    snippet = ref.content[:2000]
                    total_chars += len(snippet)
                    parts.append(f"```\n{snippet}\n```")

        if urls:
            parts.append("\n## 引用 URL")
            for ref in urls:
                parts.append(f"- {ref.source}")

        if codes:
            parts.append("\n## 代码片段")
            for ref in codes:
                lang = ref.language or ""
                if total_chars < self._max_content_chars:
                    snippet = ref.content[:3000]
                    total_chars += len(snippet)
                    header = f"来自 `{ref.source}`"
                    if ref.line_range:
                        header += f" 行 {ref.line_range}"
                    parts.append(header)
                    parts.append(f"```{lang}\n{snippet}\n```")

        return "\n".join(parts)

    def inject_into_messages(self, messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """将引用上下文注入到消息列表中（作为 system 消息）"""
        block = self.build_context_block()
        if not block:
            return messages

        context_msg = {
            "role": "system",
            "content": f"以下是当前对话引用的上下文：\n\n{block}",
        }

        # 插入到第一条 system 消息之后
        result = list(messages)
        insert_idx = 0
        for i, msg in enumerate(result):
            if msg.get("role") == "system":
                insert_idx = i + 1
                break

        result.insert(insert_idx, context_msg)
        return result
