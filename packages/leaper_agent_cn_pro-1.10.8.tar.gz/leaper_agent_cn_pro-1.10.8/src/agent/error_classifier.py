"""API 错误分类器 — 分类错误类型并决定重试策略。

参考 Hermes error_classifier.py 的简化版，专注中国服务商场景。
"""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


class ErrorCategory(enum.Enum):
    """错误分类"""
    rate_limit = "rate_limit"          # 429 限流（临时性）
    billing = "billing"                # 402 余额不足（永久性）
    auth = "auth"                      # 401/403 认证失败
    network = "network"                # 连接/超时
    context_overflow = "context_overflow"  # 上下文过长
    server_error = "server_error"      # 500/502/503
    format_error = "format_error"      # 400 请求格式错误
    unknown = "unknown"                # 未知


# ── billing vs rate_limit 消歧 pattern ──────────────────────────────
_BILLING_PATTERNS = ["insufficient", "credits", "balance", "payment", "quota exceeded",
                     "余额不足", "欠费", "充值"]
_RATE_LIMIT_PATTERNS = ["rate limit", "too many requests", "throttled", "rate_limit",
                        "限流", "频率限制"]
_TRANSIENT_SIGNALS = ["retry", "try again", "稍后重试"]


@dataclass
class ErrorInfo:
    """错误分类结果"""
    category: ErrorCategory
    retryable: bool = True
    wait_seconds: float = 1.0
    should_compress: bool = False
    should_rotate_credential: bool = False
    should_fallback: bool = False
    message: str = ""


def classify_error(exc: Exception) -> ErrorInfo:
    """分类 API 异常，返回结构化的错误信息。

    Args:
        exc: 捕获到的异常。

    Returns:
        ErrorInfo 包含分类、是否可重试、建议等待时间。
    """
    msg = str(exc).lower()
    status_code = _extract_status_code(exc)

    # 按优先级匹配

    # 1. billing vs rate_limit 消歧
    is_billing = any(p in msg for p in _BILLING_PATTERNS)
    is_rate_limit_msg = any(p in msg for p in _RATE_LIMIT_PATTERNS)

    if status_code == 402 or (is_billing and not is_rate_limit_msg):
        # 歧义情况：同时匹配 billing 和 rate_limit
        if is_billing and is_rate_limit_msg:
            has_transient = any(s in msg for s in _TRANSIENT_SIGNALS)
            if has_transient:
                wait = _extract_retry_after(exc) or 30.0
                return ErrorInfo(
                    category=ErrorCategory.rate_limit,
                    retryable=True,
                    wait_seconds=wait,
                    should_rotate_credential=True,
                    message="使用量限制（临时性），需等待后重试",
                )
        return ErrorInfo(
            category=ErrorCategory.billing,
            retryable=False,
            wait_seconds=0,
            should_rotate_credential=True,
            should_fallback=True,
            message="余额不足或配额耗尽，需充值或切换 credential",
        )

    # 2. 限流 429
    if status_code == 429 or is_rate_limit_msg:
        wait = _extract_retry_after(exc) or 30.0
        return ErrorInfo(
            category=ErrorCategory.rate_limit,
            retryable=True,
            wait_seconds=wait,
            should_rotate_credential=True,
            message="API 限流，需等待后重试",
        )

    # 3. 认证
    if status_code in (401, 403) or "unauthorized" in msg or "forbidden" in msg or "invalid api key" in msg:
        return ErrorInfo(
            category=ErrorCategory.auth,
            retryable=False,
            wait_seconds=0,
            should_rotate_credential=True,
            message="认证失败，请检查 API Key",
        )

    # 4. 上下文过长
    context_keywords = ["context_length", "context length", "maximum context", "token limit",
                        "too many tokens", "max_tokens", "content_too_large"]
    if any(kw in msg for kw in context_keywords):
        return ErrorInfo(
            category=ErrorCategory.context_overflow,
            retryable=True,
            wait_seconds=0,
            should_compress=True,
            message="上下文超出限制，需压缩对话历史",
        )

    # 5. 服务器错误
    if status_code in (500, 502, 503, 529):
        return ErrorInfo(
            category=ErrorCategory.server_error,
            retryable=True,
            wait_seconds=5.0,
            should_fallback=True,
            message="服务器错误，将重试",
        )

    # 6. 格式错误
    if status_code == 400 or "bad request" in msg:
        return ErrorInfo(
            category=ErrorCategory.format_error,
            retryable=False,
            wait_seconds=0,
            message="请求格式错误",
        )

    # 7. 网络错误
    network_keywords = ["timeout", "connection", "connect", "network", "dns", "reset", "eof"]
    if any(kw in msg for kw in network_keywords):
        return ErrorInfo(
            category=ErrorCategory.network,
            retryable=True,
            wait_seconds=3.0,
            message="网络错误，将重试",
        )

    # 8. 未知
    return ErrorInfo(
        category=ErrorCategory.unknown,
        retryable=True,
        wait_seconds=2.0,
        message=f"未知错误: {str(exc)[:100]}",
    )


def _extract_status_code(exc: Exception) -> Optional[int]:
    """从异常中提取 HTTP 状态码。"""
    # httpx.HTTPStatusError
    if hasattr(exc, "response") and hasattr(exc.response, "status_code"):
        return exc.response.status_code
    # 通用属性
    if hasattr(exc, "status_code"):
        return exc.status_code
    if hasattr(exc, "status"):
        return exc.status
    # 从消息中匹配
    import re
    match = re.search(r'\b(4\d{2}|5\d{2})\b', str(exc))
    if match:
        return int(match.group(1))
    return None


def _extract_retry_after(exc: Exception) -> Optional[float]:
    """从异常/响应头中提取 Retry-After 秒数。"""
    if hasattr(exc, "response") and hasattr(exc.response, "headers"):
        retry_after = exc.response.headers.get("retry-after")
        if retry_after:
            try:
                return float(retry_after)
            except (ValueError, TypeError):
                pass
    return None
