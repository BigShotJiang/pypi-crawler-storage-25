"""Session 维护 — 定期清理和归档过期 session

提供 cleanup_old_sessions() 用于清理策略：
- 超过 max_age_days 的 session 归档
- 超过 max_sessions 时按最后活跃时间淘汰
"""

from __future__ import annotations

import json
import logging
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

SESSIONS_DIR_NAME = ".sessions"
ARCHIVE_DIR_NAME = ".sessions_archive"


def cleanup_old_sessions(
    workspace_dir: str,
    max_age_days: int = 30,
    max_sessions: int = 100,
) -> dict:
    """清理过期 session 文件

    策略：
    1. 超过 max_age_days 的 session 归档到 archive 目录
    2. 超过 max_sessions 时按最后活跃时间淘汰最旧的

    Args:
        workspace_dir: workspace 目录
        max_age_days: 最大保留天数
        max_sessions: 最大 session 数量

    Returns:
        清理结果统计 {"archived": N, "total_before": N, "total_after": N}
    """
    sessions_path = Path(workspace_dir) / SESSIONS_DIR_NAME
    archive_path = Path(workspace_dir) / ARCHIVE_DIR_NAME

    if not sessions_path.is_dir():
        return {"archived": 0, "total_before": 0, "total_after": 0}

    # 收集所有 session 文件及其最后活跃时间
    session_files: list[tuple[Path, str]] = []  # (path, last_active)
    for f in sessions_path.glob("*.json"):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            last_active = data.get("last_active", "")
            session_files.append((f, last_active))
        except (json.JSONDecodeError, OSError):
            continue

    total_before = len(session_files)
    archived = 0
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=max_age_days)

    # 按最后活跃时间排序（最新在前）
    session_files.sort(key=lambda x: x[1], reverse=True)

    to_archive: list[Path] = []

    for idx, (fpath, last_active) in enumerate(session_files):
        should_archive = False

        # 超过 max_age_days
        if last_active:
            try:
                dt = datetime.fromisoformat(last_active)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                if dt < cutoff:
                    should_archive = True
            except (ValueError, TypeError):
                pass

        # 超过 max_sessions（按排名淘汰）
        if idx >= max_sessions:
            should_archive = True

        if should_archive:
            to_archive.append(fpath)

    # 执行归档
    if to_archive:
        archive_path.mkdir(parents=True, exist_ok=True)
        for fpath in to_archive:
            try:
                dest = archive_path / fpath.name
                shutil.move(str(fpath), str(dest))
                archived += 1
            except OSError as e:
                logger.warning("归档 session 失败 %s: %s", fpath.name, e)

    total_after = total_before - archived
    logger.info(
        "Session 清理完成: 归档 %d 个, 总量 %d → %d",
        archived, total_before, total_after,
    )
    return {
        "archived": archived,
        "total_before": total_before,
        "total_after": total_after,
    }
