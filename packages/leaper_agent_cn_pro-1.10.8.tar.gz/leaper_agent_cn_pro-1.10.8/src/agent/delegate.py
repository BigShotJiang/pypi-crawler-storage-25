"""
Delegate - 子任务委派管理器（完整增强版）

功能：
1. 任务分解（将复杂任务拆成子任务）
2. 子 Agent 创建与管理
3. 结果聚合
4. 超时与错误处理
5. 任务依赖图（DAG 执行）
"""

from __future__ import annotations

import asyncio
import enum
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine, Dict, List, Optional, Set, Tuple, Union

logger = logging.getLogger(__name__)


# ─── 枚举和数据类 ─────────────────────────────────────────────────────


class SubAgentStatus(enum.Enum):
    """子 agent 状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
    BLOCKED = "blocked"    # 等待依赖完成


@dataclass
class SubAgentResult:
    """子 agent 执行结果"""
    output: str = ""
    error: Optional[str] = None
    status: SubAgentStatus = SubAgentStatus.PENDING
    elapsed_seconds: float = 0.0
    task_id: str = ""

    @property
    def success(self) -> bool:
        return self.status == SubAgentStatus.COMPLETED


@dataclass
class SubAgentHandle:
    """子 agent 句柄，用于跟踪和管理子任务"""
    id: str = ""
    task_description: str = ""
    status: SubAgentStatus = SubAgentStatus.PENDING
    created_at: float = 0.0
    result: Optional[SubAgentResult] = None
    # 依赖关系：本任务依赖这些任务完成
    depends_on: List[str] = field(default_factory=list)
    # 内部字段
    _task: Optional[asyncio.Task] = field(default=None, repr=False)
    _result_queue: asyncio.Queue = field(default_factory=asyncio.Queue, repr=False)


@dataclass
class DelegateConfig:
    """委派配置"""
    system_prompt: str = ""
    max_turns: int = 10
    timeout: float = 300.0  # 秒
    # 传递给子 agent 的额外参数
    extra: Dict[str, Any] = field(default_factory=dict)


# 子 agent 执行函数类型：接收 (task, config) 返回 str
SubAgentFn = Callable[[str, DelegateConfig], Coroutine[Any, Any, str]]


async def _default_subagent_fn(task: str, config: DelegateConfig) -> str:
    """默认子 agent 实现（占位，实际使用时需注入真实实现）"""
    return f"[子任务完成] {task}"


# ─── 任务分解器 ───────────────────────────────────────────────────────


@dataclass
class SubTask:
    """子任务定义"""
    id: str
    description: str
    depends_on: List[str] = field(default_factory=list)
    priority: int = 0  # 越高越优先
    config: Optional[DelegateConfig] = None


class TaskDecomposer:
    """任务分解器

    将复杂任务拆分为可并行/串行执行的子任务。
    支持手动指定子任务列表或自动分解（需配合 LLM）。
    """

    @staticmethod
    def create_subtasks(
        tasks: List[Dict[str, Any]],
    ) -> List[SubTask]:
        """从字典列表创建子任务

        Args:
            tasks: 子任务列表，每项包含:
                - id: 唯一标识
                - description: 任务描述
                - depends_on: 依赖的任务 ID 列表（可选）
                - priority: 优先级（可选）

        Returns:
            SubTask 列表

        示例::

            subtasks = TaskDecomposer.create_subtasks([
                {"id": "fetch", "description": "获取数据"},
                {"id": "parse", "description": "解析数据", "depends_on": ["fetch"]},
                {"id": "render", "description": "渲染结果", "depends_on": ["parse"]},
            ])
        """
        result = []
        for t in tasks:
            task_id = t.get("id", uuid.uuid4().hex[:8])
            result.append(SubTask(
                id=task_id,
                description=t.get("description", ""),
                depends_on=t.get("depends_on", []),
                priority=t.get("priority", 0),
                config=t.get("config"),
            ))
        return result

    @staticmethod
    def validate_dag(subtasks: List[SubTask]) -> Optional[str]:
        """验证子任务依赖图是否为有效 DAG（无环）

        Returns:
            错误信息，None 表示有效
        """
        task_ids = {t.id for t in subtasks}
        # 检查依赖是否存在
        for t in subtasks:
            for dep in t.depends_on:
                if dep not in task_ids:
                    return f"任务 '{t.id}' 依赖的 '{dep}' 不存在"

        # 拓扑排序检测环
        in_degree: Dict[str, int] = {t.id: 0 for t in subtasks}
        graph: Dict[str, List[str]] = defaultdict(list)
        for t in subtasks:
            for dep in t.depends_on:
                graph[dep].append(t.id)
                in_degree[t.id] += 1

        queue = [tid for tid, deg in in_degree.items() if deg == 0]
        visited = 0
        while queue:
            node = queue.pop(0)
            visited += 1
            for child in graph[node]:
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)

        if visited != len(subtasks):
            return "依赖图中存在循环依赖"

        return None

    @staticmethod
    def topological_sort(subtasks: List[SubTask]) -> List[List[SubTask]]:
        """拓扑排序，返回分层列表（同层可并行）

        Returns:
            分层列表，每层是可以并行执行的子任务集合
        """
        task_map = {t.id: t for t in subtasks}
        in_degree: Dict[str, int] = {t.id: 0 for t in subtasks}
        graph: Dict[str, List[str]] = defaultdict(list)

        for t in subtasks:
            for dep in t.depends_on:
                graph[dep].append(t.id)
                in_degree[t.id] += 1

        layers: List[List[SubTask]] = []
        remaining = set(in_degree.keys())

        while remaining:
            # 当前层：入度为 0 的节点
            layer_ids = [tid for tid in remaining if in_degree[tid] == 0]
            if not layer_ids:
                break  # 有环，无法继续

            # 按优先级排序
            layer = sorted(
                [task_map[tid] for tid in layer_ids],
                key=lambda t: -t.priority,
            )
            layers.append(layer)

            for tid in layer_ids:
                remaining.discard(tid)
                for child in graph[tid]:
                    in_degree[child] -= 1

        return layers


# ─── 结果聚合器 ───────────────────────────────────────────────────────


class ResultAggregator:
    """结果聚合器 — 将多个子任务结果合并为统一输出"""

    def __init__(self) -> None:
        self._results: Dict[str, SubAgentResult] = {}

    def add(self, task_id: str, result: SubAgentResult) -> None:
        """添加任务结果"""
        self._results[task_id] = result

    @property
    def all_success(self) -> bool:
        """是否全部成功"""
        return all(r.success for r in self._results.values())

    @property
    def success_count(self) -> int:
        return sum(1 for r in self._results.values() if r.success)

    @property
    def failure_count(self) -> int:
        return sum(1 for r in self._results.values() if not r.success)

    @property
    def total_elapsed(self) -> float:
        """总耗时（各子任务之和）"""
        return sum(r.elapsed_seconds for r in self._results.values())

    def get(self, task_id: str) -> Optional[SubAgentResult]:
        return self._results.get(task_id)

    def summary(self) -> str:
        """生成汇总报告"""
        parts = []
        total = len(self._results)
        ok = self.success_count
        fail = self.failure_count

        parts.append(f"📊 任务汇总: {ok}/{total} 成功")
        if fail > 0:
            parts.append(f"  ❌ {fail} 个失败")
        parts.append(f"  ⏱️ 总耗时: {self.total_elapsed:.1f}s")
        parts.append("")

        for task_id, result in self._results.items():
            icon = "✅" if result.success else "❌"
            parts.append(f"{icon} [{task_id}] ({result.elapsed_seconds:.1f}s)")
            if result.output:
                # 截取前 200 字符
                output_preview = result.output[:200]
                if len(result.output) > 200:
                    output_preview += "..."
                parts.append(f"   {output_preview}")
            if result.error:
                parts.append(f"   错误: {result.error}")

        return "\n".join(parts)

    def merged_output(self, separator: str = "\n\n---\n\n") -> str:
        """合并所有成功输出"""
        outputs = []
        for task_id, result in self._results.items():
            if result.success and result.output:
                outputs.append(f"## [{task_id}]\n{result.output}")
        return separator.join(outputs)

    def clear(self) -> None:
        self._results.clear()


# ─── 委派管理器 ───────────────────────────────────────────────────────


class DelegateManager:
    """子任务委派管理器

    管理多个子 agent 的生命周期：spawn / wait / cancel。
    支持 DAG 依赖图执行和结果聚合。

    示例::

        manager = DelegateManager(subagent_fn=my_agent_fn)

        # 简单模式
        handle = await manager.spawn_subagent("分析这段代码", DelegateConfig(timeout=60))
        result = await manager.wait_for_result(handle, timeout=60)

        # DAG 模式
        subtasks = TaskDecomposer.create_subtasks([
            {"id": "fetch", "description": "获取数据"},
            {"id": "parse", "description": "解析数据", "depends_on": ["fetch"]},
        ])
        aggregator = await manager.execute_dag(subtasks)
        print(aggregator.summary())
    """

    def __init__(
        self,
        subagent_fn: Optional[SubAgentFn] = None,
        max_concurrent: int = 5,
    ):
        """初始化委派管理器

        Args:
            subagent_fn: 子 agent 执行函数，接收 (task, config)，返回结果字符串
            max_concurrent: 最大并发子 agent 数
        """
        self._subagent_fn = subagent_fn or _default_subagent_fn
        self._max_concurrent = max_concurrent
        self._handles: Dict[str, SubAgentHandle] = {}
        self._semaphore = asyncio.Semaphore(max_concurrent)

    @property
    def active_count(self) -> int:
        """当前活跃的子 agent 数"""
        return sum(
            1 for h in self._handles.values()
            if h.status in (SubAgentStatus.PENDING, SubAgentStatus.RUNNING)
        )

    def list_handles(self) -> List[SubAgentHandle]:
        """列出所有子 agent 句柄"""
        return list(self._handles.values())

    async def spawn_subagent(
        self,
        task: str,
        config: Optional[DelegateConfig] = None,
        task_id: Optional[str] = None,
        depends_on: Optional[List[str]] = None,
    ) -> SubAgentHandle:
        """创建并启动子 agent

        Args:
            task: 任务描述
            config: 委派配置，默认使用 DelegateConfig()
            task_id: 自定义任务 ID
            depends_on: 依赖的任务 ID 列表

        Returns:
            SubAgentHandle 句柄

        Raises:
            RuntimeError: 并发数超限
        """
        if config is None:
            config = DelegateConfig()

        if self.active_count >= self._max_concurrent:
            raise RuntimeError(
                f"子 agent 并发数已达上限 ({self._max_concurrent})，"
                "请等待现有任务完成或取消后再试"
            )

        handle = SubAgentHandle(
            id=task_id or uuid.uuid4().hex[:12],
            task_description=task[:200],
            status=SubAgentStatus.PENDING,
            created_at=time.time(),
            depends_on=depends_on or [],
        )

        # 启动 asyncio task
        handle._task = asyncio.create_task(
            self._run_subagent(handle, task, config)
        )
        self._handles[handle.id] = handle

        logger.info("子 agent 已创建: %s (任务: %s)", handle.id, task[:50])
        return handle

    async def _run_subagent(
        self,
        handle: SubAgentHandle,
        task: str,
        config: DelegateConfig,
    ) -> None:
        """执行子 agent（内部方法）"""
        start_time = time.time()
        handle.status = SubAgentStatus.RUNNING

        try:
            async with self._semaphore:
                # 带超时执行
                result_str = await asyncio.wait_for(
                    self._subagent_fn(task, config),
                    timeout=config.timeout,
                )

            elapsed = time.time() - start_time
            handle.status = SubAgentStatus.COMPLETED
            result = SubAgentResult(
                output=result_str,
                status=SubAgentStatus.COMPLETED,
                elapsed_seconds=elapsed,
                task_id=handle.id,
            )
            handle.result = result
            await handle._result_queue.put(result)

        except asyncio.TimeoutError:
            elapsed = time.time() - start_time
            handle.status = SubAgentStatus.TIMEOUT
            result = SubAgentResult(
                error=f"子任务超时 ({config.timeout}s)",
                status=SubAgentStatus.TIMEOUT,
                elapsed_seconds=elapsed,
                task_id=handle.id,
            )
            handle.result = result
            await handle._result_queue.put(result)
            logger.warning("子 agent %s 超时 (%.1fs)", handle.id, elapsed)

        except asyncio.CancelledError:
            handle.status = SubAgentStatus.CANCELLED
            result = SubAgentResult(
                error="子任务已取消",
                status=SubAgentStatus.CANCELLED,
                elapsed_seconds=time.time() - start_time,
                task_id=handle.id,
            )
            handle.result = result
            await handle._result_queue.put(result)

        except Exception as e:
            elapsed = time.time() - start_time
            handle.status = SubAgentStatus.FAILED
            result = SubAgentResult(
                error=str(e),
                status=SubAgentStatus.FAILED,
                elapsed_seconds=elapsed,
                task_id=handle.id,
            )
            handle.result = result
            await handle._result_queue.put(result)
            logger.error("子 agent %s 失败: %s", handle.id, e)

    async def wait_for_result(
        self,
        handle: SubAgentHandle,
        timeout: float = 300.0,
    ) -> str:
        """等待子 agent 完成并返回结果

        Args:
            handle: 子 agent 句柄
            timeout: 等待超时（秒）

        Returns:
            子 agent 输出字符串

        Raises:
            TimeoutError: 等待超时
            RuntimeError: 子 agent 执行失败
        """
        try:
            result: SubAgentResult = await asyncio.wait_for(
                handle._result_queue.get(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            raise TimeoutError(f"等待子 agent {handle.id} 超时 ({timeout}s)")

        if result.status == SubAgentStatus.COMPLETED:
            return result.output
        elif result.status == SubAgentStatus.TIMEOUT:
            raise TimeoutError(result.error or "子任务超时")
        elif result.status == SubAgentStatus.CANCELLED:
            raise RuntimeError(result.error or "子任务已取消")
        else:
            raise RuntimeError(result.error or "子任务执行失败")

    async def cancel(self, handle: SubAgentHandle) -> None:
        """取消子 agent"""
        if handle._task and not handle._task.done():
            handle._task.cancel()
            logger.info("子 agent %s 已请求取消", handle.id)

    async def cancel_all(self) -> int:
        """取消所有活跃的子 agent"""
        cancelled = 0
        for handle in self._handles.values():
            if handle._task and not handle._task.done():
                handle._task.cancel()
                cancelled += 1
        if cancelled:
            logger.info("已取消 %d 个子 agent", cancelled)
        return cancelled

    def cleanup_completed(self) -> int:
        """清理已完成的子 agent 记录"""
        done_ids = [
            hid for hid, h in self._handles.items()
            if h.status not in (SubAgentStatus.PENDING, SubAgentStatus.RUNNING)
        ]
        for hid in done_ids:
            del self._handles[hid]
        return len(done_ids)

    # ─── DAG 执行 ────────────────────────────────────────────

    async def execute_dag(
        self,
        subtasks: List[SubTask],
        default_config: Optional[DelegateConfig] = None,
        fail_fast: bool = True,
    ) -> ResultAggregator:
        """按 DAG 依赖图执行子任务

        同一层（无依赖关系）的任务并行执行，
        层与层之间按拓扑顺序串行。

        Args:
            subtasks: 子任务列表
            default_config: 默认配置
            fail_fast: 遇到失败是否立即中止后续层

        Returns:
            ResultAggregator 聚合器
        """
        if default_config is None:
            default_config = DelegateConfig()

        # 验证 DAG
        error = TaskDecomposer.validate_dag(subtasks)
        if error:
            aggregator = ResultAggregator()
            aggregator.add("__dag_error__", SubAgentResult(
                error=f"DAG 验证失败: {error}",
                status=SubAgentStatus.FAILED,
            ))
            return aggregator

        # 拓扑排序分层
        layers = TaskDecomposer.topological_sort(subtasks)
        aggregator = ResultAggregator()

        for layer_idx, layer in enumerate(layers):
            logger.info("执行 DAG 第 %d 层 (%d 个任务)", layer_idx + 1, len(layer))

            # 并行执行同一层的任务
            handles = []
            for subtask in layer:
                config = subtask.config or default_config
                handle = await self.spawn_subagent(
                    task=subtask.description,
                    config=config,
                    task_id=subtask.id,
                    depends_on=subtask.depends_on,
                )
                handles.append(handle)

            # 等待本层所有任务完成
            for handle in handles:
                try:
                    output = await self.wait_for_result(handle, timeout=default_config.timeout)
                    aggregator.add(handle.id, SubAgentResult(
                        output=output,
                        status=SubAgentStatus.COMPLETED,
                        elapsed_seconds=time.time() - handle.created_at,
                        task_id=handle.id,
                    ))
                except (TimeoutError, RuntimeError) as e:
                    aggregator.add(handle.id, SubAgentResult(
                        error=str(e),
                        status=SubAgentStatus.FAILED,
                        elapsed_seconds=time.time() - handle.created_at,
                        task_id=handle.id,
                    ))
                    if fail_fast:
                        logger.warning("DAG 第 %d 层任务 %s 失败，中止后续执行", layer_idx + 1, handle.id)
                        # 取消所有活跃任务
                        await self.cancel_all()
                        return aggregator

        return aggregator

    async def execute_tasks(
        self,
        tasks: List[Dict[str, Any]],
        default_config: Optional[DelegateConfig] = None,
        fail_fast: bool = True,
    ) -> ResultAggregator:
        """便捷方法：从字典列表创建并执行 DAG

        Args:
            tasks: 任务字典列表
            default_config: 默认配置
            fail_fast: 遇到失败是否中止

        Returns:
            ResultAggregator

        示例::

            result = await manager.execute_tasks([
                {"id": "a", "description": "步骤A"},
                {"id": "b", "description": "步骤B", "depends_on": ["a"]},
            ])
            print(result.summary())
        """
        subtasks = TaskDecomposer.create_subtasks(tasks)
        return await self.execute_dag(subtasks, default_config, fail_fast)
