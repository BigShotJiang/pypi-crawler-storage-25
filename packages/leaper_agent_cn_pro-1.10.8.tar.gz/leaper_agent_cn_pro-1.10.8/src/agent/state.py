"""Agent 状态管理 — 全局单例 + 运行状态机 + 持久化 + 事件通知 + 快照恢复 + 多 Agent 隔离

参考 Hermes hermes_state.py，增强版实现。
"""

from __future__ import annotations

import copy
import json
import os
import time
import threading
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from ..constants import (
    STATE_FILE,
    STATE_SAVE_INTERVAL,
    STATE_SAVE_OPS_THRESHOLD,
)


# ── 运行状态枚举 ──────────────────────────────────────────────────────


class RunStatus(Enum):
    """Agent 运行状态"""
    IDLE = "idle"                    # 空闲等待
    THINKING = "thinking"            # LLM 推理中
    TOOL_CALLING = "tool_calling"    # 工具调用中
    STREAMING = "streaming"          # 流式输出中
    ERROR = "error"                  # 错误状态
    SHUTDOWN = "shutdown"            # 关闭中


# ── 数据结构 ──────────────────────────────────────────────────────────


@dataclass
class MessageStats:
    """消息统计"""
    total: int = 0
    user_messages: int = 0
    assistant_messages: int = 0
    system_messages: int = 0
    total_tokens: int = 0

    def to_dict(self) -> dict:
        return {
            "total": self.total,
            "user_messages": self.user_messages,
            "assistant_messages": self.assistant_messages,
            "system_messages": self.system_messages,
            "total_tokens": self.total_tokens,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MessageStats":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class ToolStats:
    """工具调用统计"""
    total_calls: int = 0
    success_count: int = 0
    error_count: int = 0
    by_tool: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "total_calls": self.total_calls,
            "success_count": self.success_count,
            "error_count": self.error_count,
            "by_tool": dict(self.by_tool),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ToolStats":
        return cls(
            total_calls=data.get("total_calls", 0),
            success_count=data.get("success_count", 0),
            error_count=data.get("error_count", 0),
            by_tool=dict(data.get("by_tool", {})),
        )


@dataclass
class CostTracker:
    """成本追踪"""
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_api_calls: int = 0
    by_provider: Dict[str, Dict[str, int]] = field(default_factory=dict)

    def record(self, provider: str, model: str, tokens_in: int, tokens_out: int) -> None:
        """记录一次 API 调用"""
        self.total_tokens_in += tokens_in
        self.total_tokens_out += tokens_out
        self.total_api_calls += 1
        key = f"{provider}/{model}"
        if key not in self.by_provider:
            self.by_provider[key] = {"tokens_in": 0, "tokens_out": 0, "calls": 0}
        self.by_provider[key]["tokens_in"] += tokens_in
        self.by_provider[key]["tokens_out"] += tokens_out
        self.by_provider[key]["calls"] += 1

    def to_dict(self) -> dict:
        return {
            "total_tokens_in": self.total_tokens_in,
            "total_tokens_out": self.total_tokens_out,
            "total_api_calls": self.total_api_calls,
            "by_provider": dict(self.by_provider),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CostTracker":
        obj = cls()
        obj.total_tokens_in = data.get("total_tokens_in", 0)
        obj.total_tokens_out = data.get("total_tokens_out", 0)
        obj.total_api_calls = data.get("total_api_calls", 0)
        obj.by_provider = {k: dict(v) for k, v in data.get("by_provider", {}).items()}
        return obj


@dataclass
class ErrorRecord:
    """错误记录"""
    error_type: str
    message: str
    timestamp: float
    context: Optional[str] = None

    def to_dict(self) -> dict:
        d: Dict[str, Any] = {
            "error_type": self.error_type,
            "message": self.message,
            "timestamp": self.timestamp,
        }
        if self.context:
            d["context"] = self.context
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "ErrorRecord":
        return cls(
            error_type=data.get("error_type", "unknown"),
            message=data.get("message", ""),
            timestamp=data.get("timestamp", 0.0),
            context=data.get("context"),
        )


@dataclass
class SessionInfo:
    """会话信息"""
    session_id: str
    started_at: float
    last_active: float
    message_count: int = 0
    channel: str = "unknown"

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "started_at": self.started_at,
            "last_active": self.last_active,
            "message_count": self.message_count,
            "channel": self.channel,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SessionInfo":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


# ── 状态变更事件 ──────────────────────────────────────────────────────


class StateChangeEvent:
    """状态变更事件"""
    __slots__ = ("field", "old_value", "new_value", "timestamp", "agent_id")

    def __init__(
        self,
        field: str,
        old_value: Any,
        new_value: Any,
        agent_id: str = "",
    ):
        self.field = field
        self.old_value = old_value
        self.new_value = new_value
        self.timestamp = time.time()
        self.agent_id = agent_id


# 状态变更回调类型
StateChangeCallback = Callable[[StateChangeEvent], None]


# ── 主状态类 ──────────────────────────────────────────────────────────


class AgentState:
    """Agent 运行状态管理

    功能：
    - 全局单例模式（通过 get_global_state）
    - Agent 运行状态机（idle/thinking/tool_calling/streaming）
    - 记录消息/工具调用/错误
    - 统计 token 消耗和成本
    - 管理活跃 session
    - 持久化到 .state.json
    - 状态变更事件通知
    - 状态快照与恢复
    - 多 Agent 状态隔离
    """

    def __init__(self, state_dir: Optional[str] = None, agent_id: str = "default"):
        """
        state_dir: 状态文件存储目录（默认当前目录）
        agent_id: Agent 标识，用于多 Agent 隔离
        """
        self._state_dir = Path(state_dir) if state_dir else Path.cwd()
        # 多 Agent 隔离：每个 agent 使用独立的状态文件
        if agent_id and agent_id != "default":
            self._state_file = self._state_dir / f".state.{agent_id}.json"
        else:
            self._state_file = self._state_dir / STATE_FILE
        self._agent_id = agent_id
        self._lock = threading.Lock()

        # 运行状态
        self._run_status: RunStatus = RunStatus.IDLE
        self._status_detail: str = ""
        self._status_changed_at: float = time.time()

        # 核心状态
        self.messages = MessageStats()
        self.tools = ToolStats()
        self.costs = CostTracker()
        self.errors: List[ErrorRecord] = []
        self.sessions: Dict[str, SessionInfo] = {}

        # 元数据
        self.started_at: float = time.time()
        self.last_save: float = 0.0
        self._ops_since_save: int = 0
        self._max_errors: int = 100  # 最多保留的错误记录数

        # 事件监听器
        self._listeners: List[StateChangeCallback] = []

        # 快照存储
        self._snapshots: Dict[str, dict] = {}

    # ── 运行状态机 ────────────────────────────────────────────────

    @property
    def run_status(self) -> RunStatus:
        """当前运行状态"""
        return self._run_status

    @property
    def status_detail(self) -> str:
        """运行状态的详细说明"""
        return self._status_detail

    def set_status(self, status: RunStatus, detail: str = "") -> None:
        """设置运行状态，触发事件通知"""
        with self._lock:
            old = self._run_status
            if old == status and self._status_detail == detail:
                return  # 无变化
            self._run_status = status
            self._status_detail = detail
            self._status_changed_at = time.time()

        # 在锁外触发事件，避免死锁
        self._emit(StateChangeEvent(
            field="run_status",
            old_value=old.value,
            new_value=status.value,
            agent_id=self._agent_id,
        ))

    def get_status_info(self) -> dict:
        """获取完整运行状态信息"""
        with self._lock:
            return {
                "status": self._run_status.value,
                "detail": self._status_detail,
                "since": self._status_changed_at,
                "duration": time.time() - self._status_changed_at,
                "agent_id": self._agent_id,
            }

    # ── 事件通知 ──────────────────────────────────────────────────

    def on_change(self, callback: StateChangeCallback) -> None:
        """注册状态变更监听器"""
        self._listeners.append(callback)

    def off_change(self, callback: StateChangeCallback) -> None:
        """移除状态变更监听器"""
        try:
            self._listeners.remove(callback)
        except ValueError:
            pass

    def _emit(self, event: StateChangeEvent) -> None:
        """触发状态变更事件"""
        for cb in self._listeners:
            try:
                cb(event)
            except Exception:
                pass  # 监听器异常不影响状态管理

    # ── 记录方法 ──────────────────────────────────────────────────

    def record_message(
        self,
        role: str,
        tokens: int = 0,
        session_id: Optional[str] = None,
    ) -> None:
        """记录一条消息"""
        with self._lock:
            old_total = self.messages.total
            self.messages.total += 1
            self.messages.total_tokens += tokens
            if role == "user":
                self.messages.user_messages += 1
            elif role == "assistant":
                self.messages.assistant_messages += 1
            elif role == "system":
                self.messages.system_messages += 1

            if session_id and session_id in self.sessions:
                self.sessions[session_id].message_count += 1
                self.sessions[session_id].last_active = time.time()

            self._tick_ops()

        self._emit(StateChangeEvent(
            field="messages.total",
            old_value=old_total,
            new_value=old_total + 1,
            agent_id=self._agent_id,
        ))

    def record_tool_call(
        self,
        tool_name: str,
        success: bool = True,
    ) -> None:
        """记录工具调用"""
        with self._lock:
            self.tools.total_calls += 1
            if success:
                self.tools.success_count += 1
            else:
                self.tools.error_count += 1
            self.tools.by_tool[tool_name] = self.tools.by_tool.get(tool_name, 0) + 1
            self._tick_ops()

    def record_api_call(
        self,
        provider: str,
        model: str,
        tokens_in: int = 0,
        tokens_out: int = 0,
    ) -> None:
        """记录 API 调用"""
        with self._lock:
            self.costs.record(provider, model, tokens_in, tokens_out)
            self._tick_ops()

    def record_error(
        self,
        error_type: str,
        message: str,
        context: Optional[str] = None,
    ) -> None:
        """记录错误"""
        with self._lock:
            record = ErrorRecord(
                error_type=error_type,
                message=message,
                timestamp=time.time(),
                context=context,
            )
            self.errors.append(record)
            if len(self.errors) > self._max_errors:
                self.errors = self.errors[-self._max_errors:]
            self._tick_ops()

    # ── Session 管理 ──────────────────────────────────────────────

    def start_session(
        self,
        session_id: str,
        channel: str = "unknown",
    ) -> SessionInfo:
        """创建新会话"""
        now = time.time()
        info = SessionInfo(
            session_id=session_id,
            started_at=now,
            last_active=now,
            channel=channel,
        )
        with self._lock:
            self.sessions[session_id] = info
        return info

    def end_session(self, session_id: str) -> None:
        """结束会话"""
        with self._lock:
            self.sessions.pop(session_id, None)

    def get_active_sessions(self) -> List[SessionInfo]:
        """获取所有活跃会话"""
        return list(self.sessions.values())

    # ── 快照与恢复 ────────────────────────────────────────────────

    def take_snapshot(self, name: str = "default") -> str:
        """创建当前状态快照，返回快照名"""
        with self._lock:
            data = self._to_dict_locked()
            data["run_status"] = self._run_status.value
            data["status_detail"] = self._status_detail
            self._snapshots[name] = data
        return name

    def restore_snapshot(self, name: str = "default") -> bool:
        """从快照恢复状态，返回是否成功"""
        with self._lock:
            snap = self._snapshots.get(name)
            if not snap:
                return False
            data = copy.deepcopy(snap)

        # 恢复运行状态
        status_str = data.pop("run_status", "idle")
        detail = data.pop("status_detail", "")
        try:
            self.set_status(RunStatus(status_str), detail)
        except ValueError:
            self.set_status(RunStatus.IDLE)

        # 恢复数据
        self._load_from_dict(data)
        return True

    def list_snapshots(self) -> List[str]:
        """列出所有快照名"""
        return list(self._snapshots.keys())

    def delete_snapshot(self, name: str) -> bool:
        """删除快照"""
        return self._snapshots.pop(name, None) is not None

    # ── 汇总 ──────────────────────────────────────────────────────

    def get_summary(self) -> Dict[str, Any]:
        """获取状态汇总"""
        uptime = time.time() - self.started_at
        with self._lock:
            return {
                "agent_id": self._agent_id,
                "run_status": self._run_status.value,
                "uptime_seconds": round(uptime, 1),
                "messages": self.messages.to_dict(),
                "tools": self.tools.to_dict(),
                "costs": self.costs.to_dict(),
                "error_count": len(self.errors),
                "active_sessions": len(self.sessions),
                "last_save": self.last_save,
                "snapshots": list(self._snapshots.keys()),
            }

    # ── 持久化 ────────────────────────────────────────────────────

    def _to_dict_locked(self) -> dict:
        """内部方法：序列化为 dict（需在锁内调用）"""
        return {
            "version": 2,
            "agent_id": self._agent_id,
            "started_at": self.started_at,
            "saved_at": time.time(),
            "messages": self.messages.to_dict(),
            "tools": self.tools.to_dict(),
            "costs": self.costs.to_dict(),
            "errors": [e.to_dict() for e in self.errors],
            "sessions": {k: v.to_dict() for k, v in self.sessions.items()},
        }

    def save(self) -> None:
        """保存状态到文件"""
        with self._lock:
            data = self._to_dict_locked()
            self._state_dir.mkdir(parents=True, exist_ok=True)
            tmp_file = self._state_file.with_suffix(".tmp")
            try:
                tmp_file.write_text(
                    json.dumps(data, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                if os.name == "nt":
                    if self._state_file.exists():
                        self._state_file.unlink()
                tmp_file.rename(self._state_file)
            except OSError:
                try:
                    self._state_file.write_text(
                        json.dumps(data, ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                except OSError:
                    pass
                finally:
                    if tmp_file.exists():
                        try:
                            tmp_file.unlink()
                        except OSError:
                            pass
            self.last_save = time.time()
            self._ops_since_save = 0

    def _load_from_dict(self, data: dict) -> None:
        """从 dict 恢复状态"""
        with self._lock:
            self.started_at = data.get("started_at", self.started_at)
            self.messages = MessageStats.from_dict(data.get("messages", {}))
            self.tools = ToolStats.from_dict(data.get("tools", {}))
            self.costs = CostTracker.from_dict(data.get("costs", {}))
            self.errors = [
                ErrorRecord.from_dict(e) for e in data.get("errors", [])
            ]
            self.sessions = {
                k: SessionInfo.from_dict(v)
                for k, v in data.get("sessions", {}).items()
            }
            self.last_save = data.get("saved_at", 0.0)

    def load(self) -> bool:
        """从文件加载状态，返回是否成功"""
        if not self._state_file.exists():
            return False
        try:
            data = json.loads(self._state_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return False
        self._load_from_dict(data)
        return True

    # ── 内部 ──────────────────────────────────────────────────────

    def _tick_ops(self) -> None:
        """操作计数，达到阈值自动保存"""
        self._ops_since_save += 1
        now = time.time()
        if (
            self._ops_since_save >= STATE_SAVE_OPS_THRESHOLD
            or (self.last_save > 0 and now - self.last_save >= STATE_SAVE_INTERVAL)
        ):
            pass  # 实际保存由外部调度或显式调用

    def reset(self) -> None:
        """重置所有状态"""
        with self._lock:
            self.messages = MessageStats()
            self.tools = ToolStats()
            self.costs = CostTracker()
            self.errors = []
            self.sessions = {}
            self.started_at = time.time()
            self.last_save = 0.0
            self._ops_since_save = 0
            self._run_status = RunStatus.IDLE
            self._status_detail = ""
            self._snapshots = {}


# ── 全局单例管理 ──────────────────────────────────────────────────────

_global_states: Dict[str, AgentState] = {}
_global_lock = threading.Lock()


def get_global_state(agent_id: str = "default", state_dir: Optional[str] = None) -> AgentState:
    """获取全局单例状态实例（按 agent_id 隔离）

    同一个 agent_id 返回同一个实例，实现多 Agent 状态隔离。
    """
    with _global_lock:
        if agent_id not in _global_states:
            state = AgentState(state_dir=state_dir, agent_id=agent_id)
            state.load()  # 尝试加载持久化状态
            _global_states[agent_id] = state
        return _global_states[agent_id]


def reset_global_states() -> None:
    """重置所有全局状态（测试用）"""
    with _global_lock:
        _global_states.clear()
