"""Session JSONL 导出/导入 — 将 session 消息导出为 JSONL 格式

每行一个 JSON 对象，包含 timestamp, role, content, tool_calls, tool_call_id, tool_name。
支持反向导入。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional


def export_session_jsonl(session: dict, output_path: str) -> int:
    """将 session 的所有消息导出为 JSONL 格式

    Args:
        session: session 字典，需包含 "messages" 键（list[dict]）
        output_path: 输出文件路径

    Returns:
        导出的消息数量
    """
    messages = session.get("messages", [])
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    count = 0
    with open(output, "w", encoding="utf-8") as f:
        for msg in messages:
            record = {
                "timestamp": msg.get("timestamp", msg.get("created_at", "")),
                "role": msg.get("role", ""),
                "content": msg.get("content", ""),
                "tool_calls": msg.get("tool_calls"),
                "tool_call_id": msg.get("tool_call_id"),
                "tool_name": msg.get("tool_name", msg.get("name")),
            }
            # 去掉 None 值以节省空间
            record = {k: v for k, v in record.items() if v is not None}
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            count += 1

    return count


def import_session_jsonl(input_path: str) -> dict:
    """从 JSONL 文件导入 session

    Args:
        input_path: JSONL 文件路径

    Returns:
        session 字典，包含 "messages" 列表
    """
    messages: list[dict] = []
    input_file = Path(input_path)

    if not input_file.exists():
        raise FileNotFoundError(f"JSONL 文件不存在: {input_path}")

    with open(input_file, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
                msg: dict = {
                    "role": record.get("role", "user"),
                    "content": record.get("content", ""),
                }
                if record.get("timestamp"):
                    msg["timestamp"] = record["timestamp"]
                if record.get("tool_calls"):
                    msg["tool_calls"] = record["tool_calls"]
                if record.get("tool_call_id"):
                    msg["tool_call_id"] = record["tool_call_id"]
                if record.get("tool_name"):
                    msg["tool_name"] = record["tool_name"]
                messages.append(msg)
            except json.JSONDecodeError:
                continue  # 跳过无效行

    return {"messages": messages}
