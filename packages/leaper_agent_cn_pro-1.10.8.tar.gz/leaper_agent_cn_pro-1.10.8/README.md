<div align="center">

# 🚀 Leaper Agent CN

**面向中国市场的自进化 AI Agent 框架 — 国产大模型原生适配，国内渠道开箱即用**

[![PyPI](https://img.shields.io/pypi/v/leaper-agent-cn?color=%2334D058&label=PyPI)](https://pypi.org/project/leaper-agent-cn/)
[![Python](https://img.shields.io/badge/Python-3.10+-blue)](https://pypi.org/project/leaper-agent-cn/)
[![License](https://img.shields.io/badge/License-Apache_2.0-green)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-1%2C156_passed-brightgreen)]()
[![GitHub Stars](https://img.shields.io/github/stars/Deepleaper/leaper-agent-cn?style=social)](https://github.com/Deepleaper/leaper-agent-cn)

</div>

<p align="center">
  <a href="#快速开始">快速开始</a> ·
  <a href="#核心特性">核心特性</a> ·
  <a href="#架构">架构</a> ·
  <a href="#与国际版的关系">与国际版</a> ·
  <a href="https://github.com/Deepleaper/leaper-agent">English (International)</a>
</p>

---

> **为什么需要中国版？** 国际 AI Agent 框架在中国落地面临三重阻力：模型 API 不通、渠道（飞书/钉钉/企微）无适配、中文场景（长文本/多轮/口语化）表现差。Leaper Agent CN 不是套壳、不是翻译、不是 fork——是**对标全球最好的 Agent 框架，100% 自研的纯国产版本**。代码完全自主，技术栈完全国产，从模型适配到渠道接入到记忆引擎全部独立实现。

## 数据一览

| 指标 | 数据 |
|------|------|
| 版本 | **v1.8.1** |
| 源代码 | 186 文件 · 30,984 行 Python |
| 测试 | 65 文件 · 1,156 用例 · **全绿** ✅ |
| 内置工具 | **17+**（终端/文件/搜索/浏览器/代码执行/图片生成/语音转文字…） |
| 角色模板 | **10** CXO + **140** 行业 |
| License | Apache-2.0 |

## 快速开始

```bash
pip install leaper-agent-cn

leaper-cn create --template cto          # 交互式创建 Agent（会询问名称、行业、API Key）
leaper-cn chat                           # 开始对话（自动加载上次创建的 Agent）
```

> ⚠️ 需要 Python 3.10+。安装后如果 `leaper-cn` 命令不可用，请将 Python Scripts 目录加入 PATH：
> ```bash
> # Windows PowerShell（临时生效）
> $env:PATH += ";$env:LOCALAPPDATA\Programs\Python\Python312\Scripts"
> # 永久生效：在系统环境变量 PATH 中添加上述路径
> ```

三行命令，一个会自学习的 AI 员工上线。

## 核心特性

### 🧠 DeepBrain 六层记忆进化引擎

**CN 版记忆引擎始终领先**——所有 DeepBrain 新算法、新特性按 **CN 版 → Global 版 → OPC 版** 的顺序逐级落地。CN 版是记忆引擎的首发阵地。

```
L0 原始存储    →  对话/文档/输入的原始数据
L1 结构化提取  →  4Gate 门控：新颖性 · 可操作性 · 持久性 · 关联性
L2 技能合成    →  跨对话聚类 · 知识合并 · 去重
L3 知识治理    →  冲突检测 · 淘汰 · 晋升 · 漂移检测
L4 用户画像    →  多维特征建模 · 偏好学习
L5 一致性守护  →  回归测试 · 时间衰减 · 异常检测
```

**效果：Agent 第一天是新手，一个月后比新员工更懂你的业务。**

### 🇨🇳 国产大模型原生适配

不是"兼容"，是**原生适配** — 针对每个模型的 token 计费、上下文窗口、function calling 差异做了专项优化：

| 模型 | 状态 | 备注 |
|------|------|------|
| DeepSeek V3 | ✅ 推荐 | 性价比最高 |
| 通义千问 (Qwen) | ✅ | 长文本优势 |
| 智谱 GLM-4 | ✅ | 工具调用强 |
| Moonshot (Kimi) | ✅ | 128K 上下文 |
| 自定义国产模型 | ✅ | 任意国产私有部署 |

> ⚠️ **纯国产定位**：本项目不支持也不计划支持海外模型（OpenAI/Claude/Gemini 等）。需要海外模型请使用 [Leaper Agent 国际版](https://github.com/Deepleaper/leaper-agent)。

### 📱 国内渠道原生集成

| 渠道 | 状态 | 特色 |
|------|------|------|
| 飞书 | ✅ | 消息卡片 · 机器人指令 · 群聊 |
| 钉钉 | ✅ | 工作通知 · 机器人 · 群聊 |
| 企业微信 | ✅ | 应用消息 · 客服 · 群机器人 |
| REST API | ✅ | 自定义前端接入 |

### 🔧 17+ 内置工具

终端执行 · 文件操作 · 网页搜索 · 浏览器自动化 · 代码执行 · 图片生成 · 语音转文字 · MCP 协议（客户端+服务端）· Cron 定时任务 · 检查点恢复 · 模糊匹配...

### 🔒 安全三件套

| 机制 | 说明 |
|------|------|
| 审批流 | 敏感操作需人工确认 |
| 沙箱隔离 | 工具执行在受限环境 |
| 路径守卫 | 文件系统访问白名单 |

### 📊 成本优化

针对国产模型实际定价做成本追踪和智能路由。知道 DeepSeek 便宜但 GLM-4 工具调用好？系统帮你按场景自动选。

## 架构

```
┌──────────────────────────────────────────────────────┐
│                    CLI / REST API                      │
├──────────────────────────────────────────────────────┤
│                   Agent Runtime                        │
│  ┌───────────┐  ┌──────────┐  ┌────────────────────┐ │
│  │  Templates │  │  17+     │  │  Channels          │ │
│  │  CXO ×10  │  │  Tools   │  │  飞书 · 钉钉 · 企微 │ │
│  │  行业 ×140 │  │  + MCP   │  │  REST API          │ │
│  └───────────┘  └──────────┘  └────────────────────┘ │
├──────────────────────────────────────────────────────┤
│            DeepBrain 六层记忆进化引擎                    │
│   L0 → L1(4Gate) → L2 → L3 → L4 → L5                │
├──────────────────────────────────────────────────────┤
│  ┌─────────────┐ ┌─────────┐ ┌──────────────────┐   │
│  │ LLM Adapter │ │  Cron   │ │  Security        │   │
│  │ DeepSeek    │ │  定时    │ │  审批/沙箱/路径   │   │
│  │ Qwen/GLM    │ │  任务    │ │                  │   │
│  │ Moonshot    │ │         │ │                  │   │
│  └─────────────┘ └─────────┘ └──────────────────┘   │
└──────────────────────────────────────────────────────┘
```

## 模板系统

```bash
leaper-cn templates list                                          # 查看所有模板
leaper-cn create my-cfo --template cfo                            # 创建 CFO
leaper-cn create my-cs --template customer-success --industry saas # 行业定制
leaper-cn start --all                                             # 一键启动
```

10 个通用 CXO 角色（CEO Coach / CTO / CFO / CMO / COO / CHRO / CSO / CLO / CPO / CIO）+ 140 行业定制版。

## 与国际版的关系

| | **Leaper Agent (国际版)** | **Leaper Agent CN (中国版)** |
|---|---|---|
| 代码 | Hermes fork + 差异化 | **100% 自研** |
| 模型 | OpenAI / Claude / etc. | **纯国产**（DeepSeek/Qwen/GLM/Moonshot） |
| 渠道 | Telegram / Discord | 飞书 / 钉钉 / 企微 |
| 记忆引擎 | DeepBrain 6-layer | DeepBrain 六层（**始终领先，最新算法优先落地**） |
| 模板 | 英文为主 | 全中文 |
| 海外模型 | ✅ 支持 | ❌ 不支持，纯国产 |

**不是翻译，不是 fork，没有任何海外基因。** 100% 自研，为中国市场从零打造。

## 系统要求

- Python >= 3.10
- Linux / macOS / Windows
- 2 GB+ RAM（推荐 4 GB）
- 国产模型 API Key（DeepSeek / Qwen / GLM / Moonshot 任选）

## License

[Apache-2.0](LICENSE) — 商用友好。

## 相关项目

| 项目 | 说明 |
|------|------|
| [leaper-agent](https://github.com/Deepleaper/leaper-agent) | 🌍 国际版 — OpenAI/Claude + Telegram/Discord |
| [opc-deepbrain](https://github.com/Deepleaper/opc-deepbrain) | 🧠 独立六层记忆引擎 — <2000 行，可嵌入任何框架 |

---

<div align="center">
  <a href="https://github.com/Deepleaper"><strong>Deepleaper 跃盟开源</strong></a><br>
  <sub>让 AI 越用越聪明。中国市场，原生体验。</sub>
</div>

<div align="center">
  ⭐ 觉得有用？Star 一下，让更多人看到。
</div>
