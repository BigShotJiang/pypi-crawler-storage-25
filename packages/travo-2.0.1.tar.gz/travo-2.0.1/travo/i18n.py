import os.path
import importlib.resources
from contextlib import ExitStack
import atexit
import typing
import yaml  # type: ignore
import i18n  # type: ignore


class MyLoader(i18n.loaders.YamlLoader):
    loader = yaml.FullLoader


i18n.register_loader(MyLoader, ["yml", "yaml"])
i18n.set("enable_memoization", True)
file_manager = ExitStack()
atexit.register(file_manager.close)
ref = importlib.resources.files(__package__) / "locale"
i18n.load_path.append(
    file_manager.enter_context(importlib.resources.as_file(ref)).__str__()
)


def init_locale() -> None:
    """Initialize the user's prefered language according to POSIX+gettext conventions:

    https://www.gnu.org/software/gettext/manual/html_node/Locale-Environment-Variables
    """
    language = (
        os.environ.get("LANGUAGE")
        or os.environ.get("LC_ALL")
        or os.environ.get("LC_MESSAGES")
        or os.environ.get("LANG")
        or "en"
    )[:2]
    i18n.set("locale", language)
    # Default to en if a translation for `language` is not available
    # Apparently needs to be set AFTER setting the locale
    i18n.set("fallback", "en")


init_locale()


def _(key: str, **kwargs: typing.Any) -> str:
    """Return the i18n translation for this key

    Examples:

        >>> from travo.i18n import _

        >>> i18n.set('locale', 'en')
        >>> _('hi')
        'Hello'
        >>> _('help', script='foo')
        "Type 'foo' for help"

        >>> i18n.set('locale', 'fr')
        >>> _('hi')
        'Bonjour'
        >>> _('help', script='foo')
        "Tapez «foo» pour de l'aide"
    """
    return typing.cast(str, i18n.t(f"travo.{key}", **kwargs))
