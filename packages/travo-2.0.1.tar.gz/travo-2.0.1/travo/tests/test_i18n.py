import os
import pytest
from travo.i18n import init_locale

NoneType = type(None)


def test_init_locale_unspecified(nolocale: NoneType) -> None:
    """Test that locale is set to English by default"""
    init_locale()
    import travo.i18n

    assert travo.i18n._("hi") == "Hello"


@pytest.mark.parametrize(
    ["lang", "hello"],
    [["fr_FR.UTF-8", "Bonjour"], ["en_US.UTF-8", "Hello"], ["zz_ZZ.UTF-8", "Hello"]],
)
def test_init_locale_lang_fr(nolocale: NoneType, lang: str, hello: str) -> None:
    """Test setting the locale to French through LANG"""
    os.environ["LANG"] = lang
    init_locale()
    import travo.i18n

    assert travo.i18n._("hi") == hello


def test_init_locale_LC_MESSAGES(nolocale: NoneType) -> None:
    """Test that LC_MESSAGES overrides LANG"""
    os.environ["LC_MESSAGES"] = "fr_FR.UTF-8"
    os.environ["LANG"] = "en_US.UTF-8"
    init_locale()
    import travo.i18n

    assert travo.i18n._("hi") == "Bonjour"


def test_init_locale_LC_ALL_fr(nolocale: NoneType) -> None:
    """Test that LC_ALL overrides LANG, LC_MESSAGES"""
    os.environ["LC_ALL"] = "fr_FR.UTF-8"
    os.environ["LC_MESSAGES"] = "en_US.UTF-8"
    os.environ["LANG"] = "en_US.UTF-8"
    init_locale()
    import travo.i18n

    assert travo.i18n._("hi") == "Bonjour"


def test_init_locale_LANGUAGE_fr(nolocale: NoneType) -> None:
    """Test that LANGUAGE overrides all"""
    os.environ["LANGUAGE"] = "fr_FR.UTF-8"
    os.environ["LC_ALL"] = "en_US.UTF-8"
    os.environ["LC_MESSAGES"] = "en_US.UTF-8"
    os.environ["LANG"] = "en_US.UTF-8"
    init_locale()
    import travo.i18n

    assert travo.i18n._("hi") == "Bonjour"
