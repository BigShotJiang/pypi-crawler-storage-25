from thoth_mcp_proxy.cli import main

main()
