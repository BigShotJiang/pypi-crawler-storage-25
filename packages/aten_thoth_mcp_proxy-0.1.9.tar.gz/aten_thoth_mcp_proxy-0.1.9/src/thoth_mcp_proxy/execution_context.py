"""Runtime execution context checks for least-privileged proxy operation."""

from __future__ import annotations

from dataclasses import dataclass
import importlib.util
import os

_PWD_AVAILABLE = importlib.util.find_spec("pwd") is not None
if _PWD_AVAILABLE:  # pragma: no branch
    import pwd


def _env_bool(name: str, *, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str) -> int | None:
    raw = os.getenv(name)
    if raw is None:
        return None
    value = raw.strip()
    if not value:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def _resolve_username(uid: int) -> str | None:
    if not _PWD_AVAILABLE:
        return None
    try:
        return pwd.getpwuid(uid).pw_name
    except Exception:
        return None


@dataclass(frozen=True)
class RuntimeIdentity:
    uid: int
    gid: int
    username: str | None
    is_root: bool


@dataclass(frozen=True)
class LeastPrivilegeAssessment:
    identity: RuntimeIdentity
    require_non_root: bool
    expected_user: str | None
    expected_uid: int | None
    gate_ok: bool
    reasons: tuple[str, ...]


def runtime_identity() -> RuntimeIdentity:
    uid = os.geteuid() if hasattr(os, "geteuid") else os.getuid()
    gid = os.getegid() if hasattr(os, "getegid") else os.getgid()
    username = _resolve_username(uid)
    return RuntimeIdentity(uid=uid, gid=gid, username=username, is_root=(uid == 0))


def assess_least_privilege() -> LeastPrivilegeAssessment:
    identity = runtime_identity()
    env = os.getenv("THOTH_ENV", "prod").strip().lower()
    require_non_root = _env_bool("THOTH_REQUIRE_NON_ROOT", default=(env in {"staging", "prod"}))
    expected_user = os.getenv("THOTH_EXPECTED_PROXY_USER", "").strip() or None
    expected_uid = _env_int("THOTH_EXPECTED_PROXY_UID")

    reasons: list[str] = []
    if require_non_root and identity.is_root:
        reasons.append("proxy must not run as root")
    if expected_user and identity.username != expected_user:
        reasons.append(f"proxy user mismatch (expected {expected_user}, got {identity.username or 'unknown'})")
    if expected_uid is not None and identity.uid != expected_uid:
        reasons.append(f"proxy uid mismatch (expected {expected_uid}, got {identity.uid})")

    return LeastPrivilegeAssessment(
        identity=identity,
        require_non_root=require_non_root,
        expected_user=expected_user,
        expected_uid=expected_uid,
        gate_ok=(len(reasons) == 0),
        reasons=tuple(reasons),
    )
