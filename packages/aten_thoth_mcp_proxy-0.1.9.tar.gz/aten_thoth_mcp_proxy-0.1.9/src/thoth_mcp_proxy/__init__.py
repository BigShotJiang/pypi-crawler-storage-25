"""Thoth MCP Proxy — Thoth governance sidecar for Claude Desktop / MCP servers."""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("aten-thoth-mcp-proxy")
except PackageNotFoundError:
    __version__ = "0.0.0"

from thoth_mcp_proxy.proxy import MCPProxy, ProxyConfig, build_proxy_from_env

__all__ = ["MCPProxy", "ProxyConfig", "__version__", "build_proxy_from_env"]
