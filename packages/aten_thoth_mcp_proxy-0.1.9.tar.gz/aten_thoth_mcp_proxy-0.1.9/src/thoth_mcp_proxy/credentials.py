"""Credential resolution helpers for proxy and fleet auth material."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
import json
import os
from pathlib import Path


@dataclass(frozen=True)
class CredentialState:
    value: str | None
    key_id: str | None
    source: str | None
    file_path: str | None
    expires_at: datetime | None
    error: str | None = None

    @property
    def configured(self) -> bool:
        return bool(self.value)

    @property
    def expired(self) -> bool:
        if self.expires_at is None:
            return False
        return self.expires_at <= datetime.now(UTC)

    def days_to_expiry(self) -> int | None:
        if self.expires_at is None:
            return None
        delta = self.expires_at - datetime.now(UTC)
        return int(delta.total_seconds() // 86400)


def _parse_expiry(raw: str | None) -> datetime | None:
    if raw is None:
        return None
    value = raw.strip()
    if not value:
        return None
    if value.endswith("Z"):
        value = f"{value[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _read_secret_file(path: Path) -> tuple[str | None, str | None, datetime | None, str | None]:
    """Read credential material from a file.

    Supports plain-text files and JSON files with keys like:
      - `api_key` / `key` / `token` / `value`
      - `key_id`
      - `expires_at`
    """
    try:
        raw = path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        return None, None, None, f"read_error:{exc}"

    if not raw:
        return None, None, None, "file_empty"

    if raw.startswith("{"):
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            return None, None, None, f"json_decode_error:{exc}"
        if not isinstance(payload, dict):
            return None, None, None, "invalid_json_shape"

        value: str | None = None
        for key_name in ("api_key", "key", "token", "value"):
            candidate = payload.get(key_name)
            if isinstance(candidate, str) and candidate.strip():
                value = candidate.strip()
                break

        key_id_raw = payload.get("key_id")
        key_id = key_id_raw.strip() if isinstance(key_id_raw, str) and key_id_raw.strip() else None

        expires_raw = payload.get("expires_at")
        expires_at = _parse_expiry(expires_raw) if isinstance(expires_raw, str) else None

        if not value:
            return None, key_id, expires_at, "missing_secret_value"
        return value, key_id, expires_at, None

    return raw, None, None, None


def resolve_credential(
    *,
    explicit_value: str | None,
    explicit_key_id: str | None = None,
    value_env: str,
    file_env: str,
    key_id_env: str,
    expires_env: str,
) -> CredentialState:
    """Resolve a credential from explicit input, file-backed secret, or env var."""
    env_key_id = os.getenv(key_id_env, "").strip() or None
    env_expiry = _parse_expiry(os.getenv(expires_env))

    explicit = (explicit_value or "").strip()
    if explicit:
        key_id = (explicit_key_id or "").strip() or env_key_id
        return CredentialState(
            value=explicit,
            key_id=key_id,
            source="argument",
            file_path=None,
            expires_at=env_expiry,
            error=None,
        )

    file_path = os.getenv(file_env, "").strip()
    if file_path:
        value, file_key_id, file_expiry, err = _read_secret_file(Path(file_path))
        if value:
            key_id = (explicit_key_id or "").strip() or file_key_id or env_key_id
            expires_at = file_expiry or env_expiry
            return CredentialState(
                value=value,
                key_id=key_id,
                source="file",
                file_path=file_path,
                expires_at=expires_at,
                error=None,
            )

        env_value = os.getenv(value_env, "").strip() or None
        if env_value:
            key_id = (explicit_key_id or "").strip() or env_key_id
            return CredentialState(
                value=env_value,
                key_id=key_id,
                source="env",
                file_path=file_path,
                expires_at=env_expiry,
                error=err,
            )

        key_id = (explicit_key_id or "").strip() or file_key_id or env_key_id
        return CredentialState(
            value=None,
            key_id=key_id,
            source="file",
            file_path=file_path,
            expires_at=file_expiry or env_expiry,
            error=err,
        )

    env_value = os.getenv(value_env, "").strip() or None
    key_id = (explicit_key_id or "").strip() or env_key_id
    source = "env" if env_value else None
    return CredentialState(
        value=env_value,
        key_id=key_id,
        source=source,
        file_path=None,
        expires_at=env_expiry,
        error=None,
    )


def _parse_key_id_list(raw: str) -> set[str]:
    ids: set[str] = set()
    normalized = raw.replace("\n", ",")
    for part in normalized.split(","):
        key_id = part.strip()
        if key_id:
            ids.add(key_id)
    return ids


def load_revoked_key_ids(
    *,
    env_name: str = "THOTH_REVOKED_API_KEY_IDS",
    file_env: str = "THOTH_REVOKED_API_KEY_IDS_FILE",
) -> set[str]:
    revoked: set[str] = set()
    raw_env = os.getenv(env_name, "").strip()
    if raw_env:
        revoked.update(_parse_key_id_list(raw_env))

    file_path = os.getenv(file_env, "").strip()
    if not file_path:
        return revoked

    try:
        raw_file = Path(file_path).read_text(encoding="utf-8").strip()
    except OSError:
        return revoked

    if not raw_file:
        return revoked

    if raw_file.startswith("{") or raw_file.startswith("["):
        try:
            payload = json.loads(raw_file)
        except json.JSONDecodeError:
            return revoked
        if isinstance(payload, list):
            for item in payload:
                if isinstance(item, str) and item.strip():
                    revoked.add(item.strip())
            return revoked
        if isinstance(payload, dict):
            values = payload.get("revoked_key_ids")
            if isinstance(values, list):
                for item in values:
                    if isinstance(item, str) and item.strip():
                        revoked.add(item.strip())
            return revoked
        return revoked

    revoked.update(_parse_key_id_list(raw_file))
    return revoked
