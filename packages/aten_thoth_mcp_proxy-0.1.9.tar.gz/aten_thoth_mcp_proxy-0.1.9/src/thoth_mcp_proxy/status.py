# thoth_mcp_proxy/status.py
"""
thoth status — show governance state of the local Claude Desktop config.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys
from typing import Any, TextIO

from thoth_mcp_proxy.wrap_config import _is_already_governed


def _default_config_path() -> Path | None:
    """Return the platform-default Claude Desktop config path, or None if not found."""
    env_path = os.getenv("THOTH_CONFIG_PATH")
    if env_path:
        return Path(env_path)

    if sys.platform == "darwin":
        candidate = Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    elif sys.platform == "win32":
        appdata = os.getenv("APPDATA", "")
        candidate = Path(appdata) / "Claude" / "claude_desktop_config.json"
    else:
        candidate = Path.home() / ".config" / "Claude" / "claude_desktop_config.json"

    return candidate if candidate.exists() else None


def _parse_governed_entry(entry: dict[str, Any]) -> tuple[bool, str | None, str | None]:
    """
    Parse a governed server entry.
    Returns (is_governed, agent_id, session_intent).
    """
    if not _is_already_governed(entry):
        return False, None, None

    args = entry.get("args") or []
    agent_id: str | None = None
    session_intent: str | None = None

    i = 0
    while i < len(args):
        if args[i] == "--agent-id" and i + 1 < len(args):
            agent_id = args[i + 1]
            i += 2
        elif args[i] == "--session-intent" and i + 1 < len(args):
            session_intent = args[i + 1]
            i += 2
        elif args[i] == "--":
            break
        else:
            i += 1

    return True, agent_id, session_intent


def show_status(config_path: str | None = None, *, out: TextIO | None = None) -> int:
    """
    Print governance state table for the local Claude Desktop config.

    Returns:
        0  — config found and parsed (even if no servers defined)
        1  — config file not found
    """
    if out is None:
        out = sys.stdout

    # Resolve config path
    path: Path | None
    if config_path:
        path = Path(config_path)
    else:
        path = _default_config_path()

    if path is None or not path.exists():
        out.write(f"error: config file not found: {config_path or '<default location>'}\n")
        return 1

    with path.open() as fh:
        config = json.load(fh)

    servers: dict[str, Any] = config.get("mcpServers") or {}

    if not servers:
        out.write("No MCP servers defined.\n")
        return 0

    # Header
    col_w = [20, 10, 20, 25, 15]
    headers = ["Server", "Governed", "Agent ID", "Session Intent", "Enforcement"]
    sep = "\u2500" * sum(col_w)
    out.write(f"{'  '.join(h.ljust(w) for h, w in zip(headers, col_w, strict=True))}\n")
    out.write(sep + "\n")

    for name, entry in servers.items():
        governed, agent_id, session_intent = _parse_governed_entry(entry)
        mark = "\u2713" if governed else "\u2717"
        # Parse enforcement_mode from args when governed
        enforcement_mode = "-"
        if governed:
            args = entry.get("args") or []
            try:
                idx = args.index("--enforcement-mode")
                enforcement_mode = args[idx + 1]
            except (ValueError, IndexError):
                enforcement_mode = "progressive"

        row = [
            name,
            mark,
            agent_id or "-",
            session_intent or "-",
            enforcement_mode,
        ]
        out.write(f"{'  '.join(str(v).ljust(w) for v, w in zip(row, col_w, strict=True))}\n")

    return 0
