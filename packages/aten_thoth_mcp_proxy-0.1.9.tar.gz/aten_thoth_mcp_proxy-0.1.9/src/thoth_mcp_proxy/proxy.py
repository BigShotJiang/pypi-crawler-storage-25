# thoth_mcp_proxy/proxy.py
"""
MCP stdio proxy with Thoth governance enforcement.

Architecture
------------
Claude Desktop <─stdin/stdout─> MCPProxy <─subprocess stdin/stdout─> upstream MCP server

The proxy passes all JSON-RPC messages through transparently EXCEPT for
``tools/call`` requests, which are checked against the Thoth enforcer first.

Message framing: newline-delimited JSON (one JSON-RPC object per line).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from importlib.metadata import PackageNotFoundError, version as _pkg_version
import ipaddress
import json
import logging
import os
from pathlib import Path
import sys
from typing import Any
from urllib.parse import urlparse
import uuid

import anyio
import anyio.abc
import httpx

from thoth_mcp_proxy.bootstrap import bootstrap_local_profile
from thoth_mcp_proxy.credentials import CredentialState, load_revoked_key_ids, resolve_credential
from thoth_mcp_proxy.fleet import CheckinTelemetry, FleetReporter, build_govapi_headers, resolve_endpoint_identity, resolve_govapi_url
from thoth_mcp_proxy.process_resolver import (
    ProcessResolutionError,
    ResolvedProcessCommand,
    resolve_upstream_command,
    validate_exec_command,
    validate_runtime_environment,
)
from thoth_mcp_proxy.runtime_policy import RuntimePolicyManager
from thoth_mcp_proxy.tls import TLSCertPinVerifier, httpx_verify_value, resolve_tls_config

logger = logging.getLogger(__name__)

# MCP JSON-RPC error codes
_MCP_INTERNAL_ERROR = -32603
_THOTH_BLOCK_CODE = -32001  # Custom: tool call blocked by policy
_THOTH_STEP_UP_CODE = -32002  # Custom: tool call requires step-up auth

_DEFAULT_ENFORCER_URL = "http://enforcer:8080"
_ENFORCE_TIMEOUT = httpx.Timeout(connect=2.0, read=5.0, write=2.0, pool=2.0)
_DEFAULT_SPAWN_PATH_POSIX = "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
_DEFAULT_SPAWN_PATH_WINDOWS = r"C:\Windows\System32;C:\Windows"
try:
    _PROXY_VERSION = _pkg_version("aten-thoth-mcp-proxy")
except PackageNotFoundError:
    _PROXY_VERSION = "0.0.0"


@dataclass
class ProxyConfig:
    agent_id: str
    tenant_id: str
    approved_scope: list[str] = field(default_factory=list)
    user_id: str = "system"
    enforcement_mode: str = "progressive"
    api_key: str | None = None
    api_key_id: str | None = None
    enforcer_url: str = _DEFAULT_ENFORCER_URL
    govapi_url: str | None = None
    session_intent: str | None = None


class MCPProxy:
    """
    Stdio JSON-RPC proxy that intercepts ``tools/call`` messages and enforces
    Thoth governance policy before forwarding to the upstream MCP server.
    """

    def __init__(self, config: ProxyConfig) -> None:
        self._config = config
        self._session_id = str(uuid.uuid4())
        self._tool_calls: list[str] = []
        self._violations_today = 0
        self._enforcer_failure_decision = _resolve_enforcer_failure_decision()
        self._revoked_api_key_ids: set[str] = set()
        self._api_credential = self._resolve_api_credential()
        self._tls_config = resolve_tls_config()
        self._tls_pin_verifier = TLSCertPinVerifier(self._tls_config)
        self._http = httpx.AsyncClient(
            base_url=config.enforcer_url,
            headers={},
            timeout=_ENFORCE_TIMEOUT,
            verify=httpx_verify_value(self._tls_config),
        )
        self._apply_api_credential(self._api_credential)
        self._runtime_policy = RuntimePolicyManager.from_env()
        self._runtime_policy.refresh()
        self._client_stdout: anyio.AsyncFile[Any] | anyio.abc.ByteSendStream | None = None
        endpoint_identity = resolve_endpoint_identity()
        self._fleet = FleetReporter(
            govapi_url=config.govapi_url or resolve_govapi_url(config.enforcer_url),
            tenant_id=config.tenant_id,
            endpoint=endpoint_identity,
            proxy_version=_PROXY_VERSION,
            enforcement_mode=config.enforcement_mode,
            headers=build_govapi_headers(
                fallback_api_key=self._api_credential.value,
                fallback_api_key_id=self._api_credential.key_id,
            ),
            timeout=httpx.Timeout(connect=2.0, read=4.0, write=2.0, pool=2.0),
            tls_config=self._tls_config,
        )

    async def run(self, upstream_cmd: list[str]) -> int:
        """
        Start the upstream MCP server subprocess and bridge stdio.
        Returns the upstream process exit code.
        """
        try:
            resolved = resolve_upstream_command(upstream_cmd)
        except ProcessResolutionError as exc:
            logger.error(
                "thoth-proxy: failed to resolve upstream command: %s",
                json.dumps(exc.to_dict(), sort_keys=True),
            )
            return 127

        try:
            full_cmd = _build_spawn_command(resolved)
        except RuntimeError as exc:
            logger.error("thoth-proxy: invalid spawn command: %s", exc)
            return 127
        env = _build_spawn_env(resolved, full_cmd)

        launch_payload: dict[str, object] = {
            "resolved_executable": resolved.executable,
            "args": resolved.args,
            "full_command": full_cmd,
            "cwd": resolved.cwd or str(Path.cwd()),
            "PATH": env.get("PATH", ""),
            "source": resolved.source,
        }
        logger.debug("thoth-proxy: upstream launch config: %s", json.dumps(launch_payload, sort_keys=True))

        try:
            validate_exec_command(resolved.executable, resolved.args, cwd=resolved.cwd)
        except ProcessResolutionError as exc:
            logger.error(
                "thoth-proxy: resolved upstream command failed preflight validation: %s",
                json.dumps(exc.to_dict(), sort_keys=True),
            )
            return 127

        if not validate_runtime_environment(
            resolved,
            enforcement_mode=self._config.enforcement_mode,
            stderr=sys.stderr,
        ):
            return 127

        if not await self._startup_preflight():
            return 127

        # Init client_stdout BEFORE spawning the upstream process
        self._client_stdout = anyio.wrap_file(sys.stdout.buffer)
        _emit_spawn_debug(launch_payload)

        try:
            process_cm = await anyio.open_process(
                full_cmd,
                stdin=True,
                stdout=True,
                stderr=True,
                env=env,
                cwd=resolved.cwd or None,
            )
        except FileNotFoundError as exc:
            logger.error(
                "SPAWN FAILURE DEBUG",
                extra={
                    "cmd": full_cmd,
                    "executable_exists": Path(full_cmd[0]).exists(),
                    "script_exists": Path(full_cmd[1]).exists() if len(full_cmd) > 1 else None,
                    "cwd": resolved.cwd or str(Path.cwd()),
                    "PATH": env.get("PATH"),
                },
            )
            error_payload = {
                "full_command": full_cmd,
                "cwd": resolved.cwd or str(Path.cwd()),
                "PATH": env.get("PATH"),
                "error": str(exc),
            }
            logger.error("thoth-proxy: failed to spawn upstream process: %s", json.dumps(error_payload, sort_keys=True))
            return 127
        except Exception:
            logger.exception("thoth-proxy: unexpected error while spawning upstream process")
            return 127

        async with process_cm as process:
            up_stdin: anyio.abc.ByteSendStream = process.stdin  # type: ignore[assignment]
            up_stdout: anyio.abc.ByteReceiveStream = process.stdout  # type: ignore[assignment]
            up_stderr: anyio.abc.ByteReceiveStream = process.stderr  # type: ignore[assignment]
            stop_event = anyio.Event()

            async def _client_to_upstream_task() -> None:
                # Do not end the session immediately when client stdin closes.
                # We still need to flush any in-flight upstream responses.
                await self._client_to_upstream(up_stdin)

            async def _upstream_to_client_task() -> None:
                try:
                    await self._upstream_to_client(up_stdout)
                finally:
                    stop_event.set()

            async def _forward_stderr_task() -> None:
                try:
                    await self._forward_stderr(up_stderr)
                finally:
                    stop_event.set()

            if self._fleet.enabled:
                try:
                    await self._fleet.register()
                    await self._fleet.checkin(self._telemetry_snapshot())
                except Exception:
                    logger.warning(
                        "thoth-proxy: endpoint registration/check-in failed during startup",
                        exc_info=True,
                    )

            # Initialize client stdout eagerly so error responses before the first
            # client message always go through the JSON-RPC response channel.
            self._client_stdout = anyio.wrap_file(sys.stdout.buffer)

            async with anyio.create_task_group() as tg:
                tg.start_soon(_client_to_upstream_task)
                tg.start_soon(_upstream_to_client_task)
                tg.start_soon(_forward_stderr_task)
                tg.start_soon(self._fleet.checkin_loop, stop_event, self._telemetry_snapshot)
                await stop_event.wait()
                tg.cancel_scope.cancel()
        return process.returncode or 0

    # ── Stream bridges ────────────────────────────────────────────────────────

    async def _client_to_upstream(self, up_stdin: anyio.abc.ByteSendStream) -> None:
        """Read from Claude Desktop (our stdin), enforce, forward to upstream."""
        client_stdin = anyio.wrap_file(sys.stdin.buffer)
        try:
            async for raw_line in client_stdin:
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    logger.debug("thoth-proxy: malformed line from client: %r", line[:200])
                    await _write_bytes(up_stdin, raw_line)
                    continue

                if msg.get("method") == "tools/call":
                    await self._handle_tools_call(msg, up_stdin)
                else:
                    await _write_bytes(up_stdin, raw_line)
        except anyio.EndOfStream:
            pass
        finally:
            await up_stdin.aclose()

    async def _upstream_to_client(self, up_stdout: anyio.abc.ByteReceiveStream) -> None:
        """Read from upstream stdout, write to Claude Desktop (our stdout)."""
        # Use the eagerly initialized client_stdout from run() to avoid
        # race conditions during startup.
        if self._client_stdout is None:
            # Tests may call this method directly without invoking run().
            self._client_stdout = anyio.wrap_file(sys.stdout.buffer)
        client_stdout = self._client_stdout
        buffer = b""
        try:
            async for chunk in up_stdout:
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    line = line + b"\n"
                    if not line.strip():
                        continue
                    if not _is_json_rpc_line(line):
                        # stdout must remain JSON-RPC only; send banners/noise to stderr.
                        sys.stderr.buffer.write(line)
                        sys.stderr.buffer.flush()
                        continue
                    await _write_bytes(client_stdout, line)
            # Flush any remaining buffer content after stream ends
            if buffer.strip():
                if _is_json_rpc_line(buffer):
                    await _write_bytes(client_stdout, buffer)
                else:
                    sys.stderr.buffer.write(buffer)
                    sys.stderr.buffer.flush()
        except anyio.EndOfStream:
            pass

    async def _forward_stderr(self, up_stderr: anyio.abc.ByteReceiveStream) -> None:
        """Forward upstream stderr → our stderr so server logs are visible."""
        try:
            async for line in up_stderr:
                sys.stderr.buffer.write(line)
                sys.stderr.buffer.flush()
        except anyio.EndOfStream:
            pass

    # ── Enforcement ───────────────────────────────────────────────────────────

    async def _handle_tools_call(
        self,
        msg: dict[str, Any],
        up_stdin: anyio.abc.ByteSendStream,
    ) -> None:
        """Enforce the tools/call message and either forward or reject it."""
        params = msg.get("params") or {}
        tool_name: str = params.get("name", "")
        msg_id = msg.get("id")

        decision, reason = await self._enforce(tool_name)

        if decision == "ALLOW":
            self._tool_calls.append(tool_name)
            raw = (json.dumps(msg) + "\n").encode()
            await _write_bytes(up_stdin, raw)
        elif decision == "BLOCK":
            self._violations_today += 1
            await self._send_error(
                msg_id,
                code=_THOTH_BLOCK_CODE,
                message=f"Tool call blocked by Thoth policy: {reason or tool_name}",
            )
        elif decision == "STEP_UP":
            self._violations_today += 1
            await self._send_error(
                msg_id,
                code=_THOTH_STEP_UP_CODE,
                message=(f"Tool call requires step-up authorization: {reason or tool_name}. A supervisor has been notified. Please retry after approval."),
            )
        else:
            # Unknown decision (e.g. OBSERVE) — allow through
            self._tool_calls.append(tool_name)
            raw = (json.dumps(msg) + "\n").encode()
            await _write_bytes(up_stdin, raw)

    async def _enforce(self, tool_name: str) -> tuple[str, str | None]:
        """
        Call POST /v1/enforce.  Returns (decision, reason).
        Falls back to ALLOW on any network error — same non-fatal pattern
        as the SDK's EnforcerClient.
        """
        self._refresh_revoked_api_keys()
        self._refresh_api_credential()
        if self._api_key_required():
            if not self._api_credential.configured:
                logger.error("thoth-proxy: API key required but not configured")
                return "BLOCK", "proxy API key is missing"
            if self._api_credential.expired:
                logger.error("thoth-proxy: configured API key is expired")
                return "BLOCK", "proxy API key is expired"
        if self._api_credential.key_id and self._api_credential.key_id in self._revoked_api_key_ids:
            logger.error("thoth-proxy: configured API key id is revoked: %s", self._api_credential.key_id)
            return "BLOCK", "proxy API key is revoked"
        self._runtime_policy.refresh()
        effective_scope = self._runtime_policy.effective_approved_scope(self._config.approved_scope)
        effective_mode = self._runtime_policy.effective_enforcement_mode(self._config.enforcement_mode)
        effective_intent = self._runtime_policy.effective_session_intent(self._config.session_intent)

        payload: dict[str, Any] = {
            "agent_id": self._config.agent_id,
            "tenant_id": self._config.tenant_id,
            "user_id": self._config.user_id,
            "tool_name": tool_name,
            "session_id": self._session_id,
            "session_tool_calls": list(self._tool_calls),
            "approved_scope": effective_scope,
            "enforcement_mode": effective_mode,
        }
        if effective_intent:
            payload["session_intent"] = effective_intent
        if self._tls_pin_verifier.enabled:
            try:
                self._tls_pin_verifier.verify(self._config.enforcer_url)
            except Exception:
                logger.error(
                    "thoth-proxy: outbound TLS verification failed for enforcer %s",
                    self._config.enforcer_url,
                    exc_info=True,
                )
                return "BLOCK", "enforcer TLS verification failed"
        try:
            resp = await self._http.post("/v1/enforce", json=payload)
            resp.raise_for_status()
            body = resp.json()
            return body.get("decision", "ALLOW"), body.get("reason")
        except Exception:
            logger.warning(
                "thoth-proxy: enforcer unreachable, falling back to %s for %s",
                self._enforcer_failure_decision,
                tool_name,
                exc_info=True,
            )
            if self._enforcer_failure_decision == "BLOCK":
                return "BLOCK", "enforcer unreachable and fallback mode is BLOCK"
            if self._enforcer_failure_decision == "STEP_UP":
                return "STEP_UP", "enforcer unreachable and fallback mode is STEP_UP"
            return "ALLOW", None

    async def _send_error(self, msg_id: Any, *, code: int, message: str) -> None:
        """Write a JSON-RPC error response directly to Claude Desktop."""
        error_resp = {
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {"code": code, "message": message},
        }
        line = (json.dumps(error_resp) + "\n").encode()
        # _client_stdout is initialized eagerly in run() before task startup.
        # Keep a defensive fallback for direct method calls in tests.
        stdout = self._client_stdout or anyio.wrap_file(sys.stdout.buffer)
        await _write_bytes(stdout, line)

    async def aclose(self) -> None:
        await self._fleet.aclose()
        await self._http.aclose()

    def _telemetry_snapshot(self) -> CheckinTelemetry:
        self._refresh_revoked_api_keys()
        self._refresh_api_credential()
        self._runtime_policy.refresh()
        metadata = self._runtime_policy.metadata()
        return CheckinTelemetry(
            proxy_version=_PROXY_VERSION,
            agent_ids=[self._config.agent_id],
            risk_score=0.0,
            violations_today=self._violations_today,
            sessions_today=1,
            policy_version=metadata.policy_version,
            policy_source=metadata.policy_source,
            policy_profile_id=metadata.policy_profile_id,
            policy_signature_valid=metadata.signature_valid,
            policy_rollback_active=metadata.rollback_active,
            api_key_id=self._api_credential.key_id,
            api_key_source=self._api_credential.source,
            api_key_expired=self._api_credential.expired if self._api_credential.expires_at else None,
            api_key_revoked=(self._api_credential.key_id in self._revoked_api_key_ids if self._api_credential.key_id else None),
        )

    def _resolve_api_credential(self) -> CredentialState:
        return resolve_credential(
            explicit_value=self._config.api_key,
            explicit_key_id=self._config.api_key_id,
            value_env="THOTH_API_KEY",
            file_env="THOTH_API_KEY_FILE",
            key_id_env="THOTH_API_KEY_ID",
            expires_env="THOTH_API_KEY_EXPIRES_AT",
        )

    def _apply_api_credential(self, cred: CredentialState) -> None:
        if cred.value:
            self._http.headers["x-api-key"] = cred.value
        else:
            self._http.headers.pop("x-api-key", None)
        self._config.api_key = cred.value
        self._config.api_key_id = cred.key_id

    def _refresh_api_credential(self) -> None:
        refreshed = self._resolve_api_credential()
        if refreshed == self._api_credential:
            return
        self._api_credential = refreshed
        self._apply_api_credential(refreshed)
        self._fleet.update_headers(
            build_govapi_headers(
                fallback_api_key=refreshed.value,
                fallback_api_key_id=refreshed.key_id,
            )
        )

    def _refresh_revoked_api_keys(self) -> None:
        self._revoked_api_key_ids = load_revoked_key_ids()

    def _api_key_required(self) -> bool:
        raw = os.getenv("THOTH_REQUIRE_API_KEY", "").strip().lower()
        if raw in {"1", "true", "yes", "on"}:
            return True
        if raw in {"0", "false", "no", "off"}:
            return False
        env = os.getenv("THOTH_ENV", "prod").strip().lower()
        return env in {"staging", "prod"}

    async def _startup_preflight(self) -> bool:
        checks = [
            ("enforcer", self._config.enforcer_url, self._config.enforcement_mode not in {"observe", "progressive"}),
            ("govapi", self._fleet.govapi_url, False),
        ]
        for name, url, required in checks:
            if not url:
                continue
            if await _is_url_reachable(url, tls_config=self._tls_config, pin_verifier=self._tls_pin_verifier):
                continue
            if required:
                logger.error("thoth-proxy: startup preflight failed: %s endpoint unreachable: %s", name, url)
                return False
            logger.warning("thoth-proxy: startup preflight warning: %s endpoint unreachable: %s", name, url)
        return True


# ── Helpers ───────────────────────────────────────────────────────────────────


async def _write_bytes(stream: Any, data: bytes) -> None:
    """Write bytes to an anyio byte send stream."""
    await stream.send(data)


def _is_json_rpc_line(line: bytes) -> bool:
    try:
        payload = json.loads(line)
    except Exception:
        return False
    if not isinstance(payload, dict):
        return False
    if payload.get("jsonrpc") != "2.0":
        return False
    return any(key in payload for key in ("id", "method", "result", "error"))


async def _is_url_reachable(
    url: str,
    *,
    tls_config: Any,
    pin_verifier: TLSCertPinVerifier | None = None,
) -> bool:
    try:
        if pin_verifier and pin_verifier.enabled:
            pin_verifier.verify(url)
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(connect=2.0, read=2.0, write=2.0, pool=2.0),
            verify=httpx_verify_value(tls_config),
        ) as client:
            resp = await client.get(url)
        return resp.status_code > 0
    except Exception:
        return False


def _spawn_debug_enabled() -> bool:
    raw = os.getenv("THOTH_DEBUG_SPAWN", "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _emit_spawn_debug(payload: dict[str, object]) -> None:
    if not _spawn_debug_enabled():
        return
    sys.stderr.write(f"thoth-proxy spawn debug: {json.dumps(payload, sort_keys=True)}\n")
    sys.stderr.flush()


def _build_spawn_command(cmd: ResolvedProcessCommand) -> list[str]:
    assert isinstance(cmd.executable, str)
    assert all(isinstance(arg, str) for arg in cmd.args)

    full_cmd = [cmd.executable, *cmd.args]
    full_cmd = [str(token) for token in full_cmd]

    if len(full_cmd) >= 2 and full_cmd[0].endswith("node") and full_cmd[1].endswith(".js"):
        full_cmd = [full_cmd[0], full_cmd[1], *full_cmd[2:]]

    for i, token in enumerate(full_cmd):
        if not token or token.strip() != token:
            raise RuntimeError(f"Invalid token at index {i}: {token!r}")
    return full_cmd


def _build_spawn_env(cmd: ResolvedProcessCommand, full_cmd: list[str]) -> dict[str, str]:
    env = dict(cmd.env)
    default_path = _DEFAULT_SPAWN_PATH_WINDOWS if os.name == "nt" else _DEFAULT_SPAWN_PATH_POSIX
    path_value = env.get("PATH", "") or default_path
    node_dir = str(Path(full_cmd[0]).parent) if full_cmd else ""
    if node_dir:
        path_value = f"{node_dir}{os.pathsep}{path_value}"
    env["PATH"] = path_value

    env.setdefault("HOME", str(Path("~").expanduser()))
    if os.name != "nt":
        env.setdefault("TMPDIR", "/tmp")
    return env


def build_proxy_from_env(
    agent_id: str,
    tenant_id: str,
    *,
    approved_scope: list[str] | None = None,
    user_id: str | None = None,
    enforcement_mode: str = "progressive",
    api_key: str | None = None,
    enforcer_url: str | None = None,
    session_intent: str | None = None,
) -> MCPProxy:
    """Construct an MCPProxy, resolving api_key, enforcer_url, and user_id from env vars."""
    explicit_enforcer = bool(enforcer_url and enforcer_url.strip())
    inferred_apex = _derive_apex_domain_from_url(enforcer_url or "") if explicit_enforcer else None
    bootstrap_local_profile(
        tenant_id=tenant_id,
        user_id=user_id,
        apex_domain=inferred_apex,
    )
    resolved_credential = resolve_credential(
        explicit_value=api_key,
        value_env="THOTH_API_KEY",
        file_env="THOTH_API_KEY_FILE",
        key_id_env="THOTH_API_KEY_ID",
        expires_env="THOTH_API_KEY_EXPIRES_AT",
    )
    resolved_key = resolved_credential.value
    resolved_url = enforcer_url or os.getenv("THOTH_ENFORCER_URL") or _DEFAULT_ENFORCER_URL
    _validate_enforcer_url_for_environment(resolved_url)
    resolved_govapi_url = resolve_govapi_url(resolved_url)
    resolved_user = user_id or os.getenv("THOTH_USER_ID") or "system"
    config = ProxyConfig(
        agent_id=agent_id,
        tenant_id=tenant_id,
        approved_scope=approved_scope or [],
        user_id=resolved_user,
        enforcement_mode=enforcement_mode,
        api_key=resolved_key,
        api_key_id=resolved_credential.key_id,
        enforcer_url=resolved_url.rstrip("/"),
        govapi_url=resolved_govapi_url,
        session_intent=session_intent,
    )
    return MCPProxy(config)


def _derive_apex_domain_from_url(url: str) -> str | None:
    if not url:
        return None
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").strip().lower()
    if not hostname:
        return None
    labels = hostname.split(".")
    if len(labels) < 3:
        return None
    if labels[0] not in {"enforce", "grid", "enforcer", "govapi"}:
        return None
    return ".".join(labels[2:])


def _resolve_enforcer_failure_decision() -> str:
    raw = os.getenv("THOTH_ENFORCER_FAILURE_DECISION", "").strip().lower()
    env = os.getenv("THOTH_ENV", "prod").strip().lower()
    if raw in {"allow", "block", "step_up"}:
        if raw == "allow" and env in {"staging", "prod"} and not _allow_insecure_enforcer_allow_fallback():
            return "STEP_UP"
        return raw.upper()
    if env in {"staging", "prod"}:
        return "STEP_UP"
    return "ALLOW"


def _allow_insecure_enforcer_allow_fallback() -> bool:
    raw = os.getenv("THOTH_ENFORCER_ALLOW_FALLBACK_OVERRIDE", "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _validate_enforcer_url_for_environment(enforcer_url: str) -> None:
    parsed = urlparse(enforcer_url)
    scheme = parsed.scheme.lower()
    if scheme not in {"http", "https"}:
        raise ValueError(f"THOTH_ENFORCER_URL must use http or https, got: {enforcer_url}")
    if not parsed.hostname:
        raise ValueError(f"THOTH_ENFORCER_URL must include a hostname, got: {enforcer_url}")

    env = os.getenv("THOTH_ENV", "").strip().lower()
    if env not in {"staging", "prod"}:
        return
    if scheme == "https":
        return
    if _is_loopback_host(parsed.hostname):
        return
    raise ValueError(
        "THOTH_ENFORCER_URL must use https in staging/prod (http is allowed only for localhost/loopback).",
    )


def _is_loopback_host(hostname: str) -> bool:
    value = hostname.strip().lower()
    if value == "localhost":
        return True
    try:
        return ipaddress.ip_address(value).is_loopback
    except ValueError:
        return False
