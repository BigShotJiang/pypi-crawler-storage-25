"""TLS verification and certificate pinning helpers for outbound HTTP clients."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import socket
import ssl
import time
from urllib.parse import urlparse


def _env_bool(name: str, *, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, *, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _normalize_pin_sha256(value: str) -> str:
    normalized = value.strip().lower()
    if normalized.startswith("sha256:"):
        normalized = normalized.removeprefix("sha256:")
    normalized = normalized.replace(":", "").replace(" ", "")
    if len(normalized) != 64 or any(ch not in "0123456789abcdef" for ch in normalized):
        raise ValueError(f"invalid sha256 pin format: {value}")
    return normalized


@dataclass(frozen=True)
class TLSConfig:
    verify: bool
    ca_bundle: str | None
    pinned_cert_sha256: tuple[str, ...]
    pin_cache_seconds: int
    require_aws_backed_certs: bool
    aws_acm_cert_arn: str | None
    aws_private_ca_arn: str | None


def _normalize_arn(raw: str | None, *, service: str, env_name: str) -> str | None:
    if raw is None:
        return None
    value = raw.strip()
    if not value:
        return None
    if not value.startswith("arn:") or f":{service}:" not in value:
        raise ValueError(f"{env_name} must be a valid {service} ARN")
    return value


def resolve_tls_config() -> TLSConfig:
    verify = _env_bool("THOTH_TLS_VERIFY", default=True)
    ca_bundle = os.getenv("THOTH_TLS_CA_BUNDLE", "").strip() or None
    if ca_bundle and not Path(ca_bundle).is_file():
        raise ValueError(f"THOTH_TLS_CA_BUNDLE does not exist: {ca_bundle}")

    raw_pins = os.getenv("THOTH_TLS_PINNED_CERT_SHA256", "").replace(";", ",")
    pins: list[str] = []
    for part in raw_pins.split(","):
        chunk = part.strip()
        if not chunk:
            continue
        normalized = _normalize_pin_sha256(chunk)
        if normalized not in pins:
            pins.append(normalized)
    if pins and not verify:
        raise ValueError("THOTH_TLS_VERIFY must remain enabled when THOTH_TLS_PINNED_CERT_SHA256 is configured")

    require_aws_backed_certs = _env_bool("THOTH_TLS_REQUIRE_AWS_BACKED_CERTS", default=False)
    aws_acm_cert_arn = _normalize_arn(
        os.getenv("THOTH_TLS_AWS_ACM_CERT_ARN"),
        service="acm",
        env_name="THOTH_TLS_AWS_ACM_CERT_ARN",
    )
    aws_private_ca_arn = _normalize_arn(
        os.getenv("THOTH_TLS_AWS_PRIVATE_CA_ARN"),
        service="acm-pca",
        env_name="THOTH_TLS_AWS_PRIVATE_CA_ARN",
    )
    if require_aws_backed_certs and not verify:
        raise ValueError("THOTH_TLS_VERIFY must remain enabled when THOTH_TLS_REQUIRE_AWS_BACKED_CERTS is true")
    if require_aws_backed_certs and not (aws_acm_cert_arn or aws_private_ca_arn):
        raise ValueError("THOTH_TLS_REQUIRE_AWS_BACKED_CERTS requires THOTH_TLS_AWS_ACM_CERT_ARN or THOTH_TLS_AWS_PRIVATE_CA_ARN")

    pin_cache_seconds = max(0, _env_int("THOTH_TLS_PIN_CACHE_SECONDS", default=300))
    return TLSConfig(
        verify=verify,
        ca_bundle=ca_bundle,
        pinned_cert_sha256=tuple(pins),
        pin_cache_seconds=pin_cache_seconds,
        require_aws_backed_certs=require_aws_backed_certs,
        aws_acm_cert_arn=aws_acm_cert_arn,
        aws_private_ca_arn=aws_private_ca_arn,
    )


def httpx_verify_value(config: TLSConfig) -> bool | str:
    if config.ca_bundle:
        return config.ca_bundle
    return config.verify


class TLSCertPinVerifier:
    """Validates remote certificate SHA-256 fingerprints with a short-lived cache."""

    def __init__(self, config: TLSConfig) -> None:
        self._config = config
        self._verified_at: dict[str, float] = {}

    @property
    def enabled(self) -> bool:
        return bool(self._config.pinned_cert_sha256)

    def verify(self, target_url: str) -> None:
        if not self.enabled:
            return

        parsed = urlparse(target_url)
        scheme = parsed.scheme.lower()
        if scheme != "https":
            raise ValueError(f"certificate pinning requires https target, got: {target_url}")
        if not parsed.hostname:
            raise ValueError(f"cannot resolve hostname from url: {target_url}")

        port = parsed.port or 443
        origin = f"{scheme}://{parsed.hostname}:{port}"
        now = time.time()
        last_verified = self._verified_at.get(origin)
        if last_verified is not None and (now - last_verified) < self._config.pin_cache_seconds:
            return

        fingerprint = self._fetch_leaf_cert_sha256(parsed.hostname, port)
        if fingerprint not in self._config.pinned_cert_sha256:
            raise RuntimeError(f"tls certificate pin mismatch for {origin}: got {fingerprint}")
        self._verified_at[origin] = now

    def _fetch_leaf_cert_sha256(self, host: str, port: int) -> str:
        context = ssl.create_default_context()
        if self._config.ca_bundle:
            context.load_verify_locations(cafile=self._config.ca_bundle)
        with socket.create_connection((host, port), timeout=5.0) as raw_sock:
            with context.wrap_socket(raw_sock, server_hostname=host) as tls_sock:
                cert_der = tls_sock.getpeercert(binary_form=True)
        if not cert_der:
            raise RuntimeError(f"no peer certificate received from {host}:{port}")
        return hashlib.sha256(cert_der).hexdigest()
