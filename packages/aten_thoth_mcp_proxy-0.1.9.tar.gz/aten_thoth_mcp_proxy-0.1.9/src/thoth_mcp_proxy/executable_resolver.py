from __future__ import annotations

import os
from pathlib import Path
import shutil
import sys
from typing import Mapping

_POSIX_FALLBACK_DIRS = [
    "/usr/local/bin",
    "/opt/homebrew/bin",
    "/usr/bin",
    "/bin",
]

_WINDOWS_FALLBACK_ENV_KEYS = [
    "ProgramFiles",
    "ProgramFiles(x86)",
    "LocalAppData",
]

_WINDOWS_FALLBACK_DIRS = [
    r"C:\Windows\System32",
]

_WINDOWS_PATHEXT_DEFAULT = [".exe", ".cmd", ".bat", ""]


class ProcessResolutionError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        command: str,
        attempted_paths: list[str] | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__(message)
        self.command = command
        self.attempted_paths = attempted_paths or []
        self.suggestion = suggestion

    def to_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "command": self.command,
            "message": str(self),
            "attempted_paths": self.attempted_paths,
        }
        if self.suggestion:
            payload["suggestion"] = self.suggestion
        return payload


def _is_windows() -> bool:
    return os.name == "nt" or sys.platform.startswith("win")


def _is_executable(path: Path) -> bool:
    if not path.is_file():
        return False
    if _is_windows():
        return True
    return os.access(path, os.X_OK)


def _normalize_path(path_value: str) -> str:
    return str(Path(path_value).resolve())


def _build_env(env: Mapping[str, str] | None) -> dict[str, str]:
    merged = dict(os.environ)
    if env:
        merged.update({k: str(v) for k, v in env.items()})
    return merged


def _build_windows_pathext(env: Mapping[str, str]) -> list[str]:
    raw = env.get("PATHEXT", "")
    if not raw.strip():
        return _WINDOWS_PATHEXT_DEFAULT
    exts = [ext.strip().lower() for ext in raw.split(";") if ext.strip()]
    if "" not in exts:
        exts.append("")
    return exts


def _fallback_dirs(env: Mapping[str, str]) -> list[str]:
    if not _is_windows():
        return _POSIX_FALLBACK_DIRS

    dirs: list[str] = []
    for key in _WINDOWS_FALLBACK_ENV_KEYS:
        value = env.get(key, "").strip()
        if value:
            dirs.append(value)
    dirs.extend(_WINDOWS_FALLBACK_DIRS)
    return dirs


def _path_entries(path_value: str) -> list[str]:
    return [entry for entry in path_value.split(os.pathsep) if entry]


def _dedupe_keep_order(entries: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for entry in entries:
        key = entry.lower() if _is_windows() else entry
        if key in seen:
            continue
        seen.add(key)
        result.append(entry)
    return result


def _candidate_names(name: str, env: Mapping[str, str]) -> list[str]:
    if not _is_windows():
        return [name]

    existing_suffix = Path(name).suffix.lower()
    pathext = _build_windows_pathext(env)
    if existing_suffix and existing_suffix in pathext:
        return [name]

    candidates: list[str] = []
    for ext in pathext:
        candidates.append(f"{name}{ext}")
    return candidates


def resolve_executable(name: str, env: dict[str, str] | None = None) -> str:
    command = (name or "").strip()
    if not command:
        raise ProcessResolutionError(
            "executable name is empty",
            command=name,
            suggestion="Provide a non-empty executable name or an absolute path.",
        )

    runtime_env = _build_env(env)
    searched_paths: list[str] = []

    command_path = Path(command)
    if command_path.is_absolute() or os.sep in command or (os.altsep and os.altsep in command):
        candidate = command_path.resolve()
        searched_paths.append(str(candidate))
        if _is_executable(candidate):
            return str(candidate)
        raise ProcessResolutionError(
            f"executable not found or not executable: {candidate}",
            command=command,
            attempted_paths=searched_paths,
            suggestion="Use a valid absolute path and ensure execute permissions are set.",
        )

    # Step 1: platform `which` lookup.
    which_path = shutil.which(command, path=runtime_env.get("PATH"))
    if which_path:
        return _normalize_path(which_path)

    # Step 2/3: explicit directory scan (PATH + platform fallbacks) with PATHEXT.
    search_dirs = _dedupe_keep_order(_path_entries(runtime_env.get("PATH", "")) + _fallback_dirs(runtime_env))
    for directory in search_dirs:
        if not directory:
            continue
        base = Path(directory)
        for candidate_name in _candidate_names(command, runtime_env):
            candidate = base / candidate_name
            searched_paths.append(str(candidate))
            if _is_executable(candidate):
                return str(candidate.resolve())

    # Step 4: fail fast with actionable detail.
    raise ProcessResolutionError(
        f"executable '{command}' not found",
        command=command,
        attempted_paths=searched_paths,
        suggestion=f"Install '{command}' and ensure it is available in PATH, or configure an absolute executable path.",
    )
