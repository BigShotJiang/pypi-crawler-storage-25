"""Signed runtime policy profile loading for Jamf-managed proxy configuration.

This module enables dynamic policy updates (without binary repack) by loading a
JSON policy profile from disk, verifying its signature, and exposing effective
runtime overrides for the proxy.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import hmac
import json
import logging
import os
from pathlib import Path
import tempfile
from typing import Any

logger = logging.getLogger(__name__)

SCHEMA_VERSION = "thoth.proxy.runtime.v1"
SIGNATURE_ALGORITHM = "hmac-sha256"
_ALLOWED_ENFORCEMENT_MODES = {"observe", "block", "step_up", "progressive"}


class RuntimePolicyValidationError(ValueError):
    """Raised when a runtime policy profile fails schema or signature validation."""


def _env_bool(name: str, *, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _canonical_bytes(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def sign_policy_profile(payload: dict[str, Any], secret: str) -> str:
    """Build an HMAC-SHA256 signature for a profile payload (without signature field)."""
    signable = dict(payload)
    signable.pop("signature", None)
    return hmac.new(secret.encode("utf-8"), _canonical_bytes(signable), hashlib.sha256).hexdigest()


@dataclass(frozen=True)
class RuntimePolicyProfile:
    profile_id: str
    policy_version: int
    source: str
    enforcement_mode: str | None
    approved_scope: list[str] | None
    session_intent: str | None
    signature_valid: bool


def _validate_payload(payload: dict[str, Any]) -> RuntimePolicyProfile:
    schema_version = payload.get("schema_version")
    if schema_version != SCHEMA_VERSION:
        raise RuntimePolicyValidationError(f"schema_version must be {SCHEMA_VERSION!r}, got {schema_version!r}")

    profile_id = payload.get("profile_id")
    if not isinstance(profile_id, str) or not profile_id.strip():
        raise RuntimePolicyValidationError("profile_id is required")

    policy_version = payload.get("policy_version")
    if not isinstance(policy_version, int) or policy_version < 0:
        raise RuntimePolicyValidationError("policy_version must be a non-negative integer")

    source = payload.get("source")
    if not isinstance(source, str) or not source.strip():
        raise RuntimePolicyValidationError("source is required")

    enforcement_mode = payload.get("enforcement_mode")
    if enforcement_mode is not None:
        if not isinstance(enforcement_mode, str) or enforcement_mode not in _ALLOWED_ENFORCEMENT_MODES:
            raise RuntimePolicyValidationError("enforcement_mode must be one of observe|block|step_up|progressive")

    approved_scope = payload.get("approved_scope")
    if approved_scope is not None:
        if not isinstance(approved_scope, list) or any(not isinstance(x, str) for x in approved_scope):
            raise RuntimePolicyValidationError("approved_scope must be a list of strings")

    session_intent = payload.get("session_intent")
    if session_intent is not None and not isinstance(session_intent, str):
        raise RuntimePolicyValidationError("session_intent must be a string when provided")

    return RuntimePolicyProfile(
        profile_id=profile_id.strip(),
        policy_version=policy_version,
        source=source.strip(),
        enforcement_mode=enforcement_mode,
        approved_scope=approved_scope,
        session_intent=session_intent,
        signature_valid=True,
    )


def _load_profile_file(path: Path) -> dict[str, Any]:
    with path.open() as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise RuntimePolicyValidationError("policy profile must be a JSON object")
    return data


def _verify_signature(
    data: dict[str, Any],
    *,
    secret: str | None,
    allow_unsigned: bool,
) -> bool:
    signature = data.get("signature")
    if signature is None:
        if allow_unsigned:
            return False
        raise RuntimePolicyValidationError("signature is required")
    if not isinstance(signature, dict):
        raise RuntimePolicyValidationError("signature must be an object")

    algorithm = signature.get("algorithm")
    value = signature.get("value")
    if algorithm != SIGNATURE_ALGORITHM:
        raise RuntimePolicyValidationError(f"signature.algorithm must be {SIGNATURE_ALGORITHM!r}")
    if not isinstance(value, str) or not value:
        raise RuntimePolicyValidationError("signature.value is required")
    if not secret:
        raise RuntimePolicyValidationError("THOTH_POLICY_PROFILE_HMAC_SECRET is required for signed profile verification")

    payload = dict(data)
    payload.pop("signature", None)
    expected = sign_policy_profile(payload, secret)
    if not hmac.compare_digest(expected, value):
        raise RuntimePolicyValidationError("signature verification failed")
    return True


def _write_json_atomic(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".runtime_policy.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
            fh.flush()
            os.fsync(fh.fileno())
        Path(tmp_name).replace(path)
    finally:
        try:
            Path(tmp_name).unlink(missing_ok=True)
        except Exception:
            logger.debug("failed to clean temporary runtime profile file %s", tmp_name, exc_info=True)


@dataclass
class RuntimePolicyMetadata:
    policy_version: int | None
    policy_source: str | None
    policy_profile_id: str | None
    signature_valid: bool | None
    rollback_active: bool


class RuntimePolicyManager:
    """Loads, verifies, and hot-reloads signed runtime policy profiles."""

    def __init__(
        self,
        *,
        profile_path: str | None,
        hmac_secret: str | None,
        allow_unsigned: bool,
        last_good_path: str | None,
    ) -> None:
        self._profile_path = Path(profile_path).expanduser() if profile_path else None
        self._last_good_path = Path(last_good_path).expanduser() if last_good_path else (Path(str(self._profile_path) + ".last_good.json") if self._profile_path else None)
        self._hmac_secret = hmac_secret
        self._allow_unsigned = allow_unsigned
        self._profile: RuntimePolicyProfile | None = None
        self._profile_mtime_ns: int | None = None
        self._rollback_active = False

    @classmethod
    def from_env(cls) -> RuntimePolicyManager:
        profile_path = os.getenv("THOTH_POLICY_PROFILE_PATH", "").strip() or None
        secret = os.getenv("THOTH_POLICY_PROFILE_HMAC_SECRET", "").strip() or None
        runtime_env = os.getenv("THOTH_ENV", "").strip().lower() or os.getenv("APP_ENV", "").strip().lower()
        # Unsigned profiles are allowed only in local/dev/test unless explicitly overridden.
        default_allow_unsigned = runtime_env in {"local", "dev", "development", "test"}
        allow_unsigned = _env_bool(
            "THOTH_POLICY_PROFILE_ALLOW_UNSIGNED",
            default=default_allow_unsigned,
        )
        last_good_path = os.getenv("THOTH_POLICY_PROFILE_LAST_GOOD_PATH", "").strip() or None
        return cls(
            profile_path=profile_path,
            hmac_secret=secret,
            allow_unsigned=allow_unsigned,
            last_good_path=last_good_path,
        )

    @property
    def configured(self) -> bool:
        return self._profile_path is not None

    def refresh(self) -> None:
        if self._profile_path is None:
            return
        if not self._profile_path.exists():
            return
        mtime_ns = self._profile_path.stat().st_mtime_ns
        if self._profile_mtime_ns == mtime_ns:
            return

        self._profile_mtime_ns = mtime_ns
        try:
            profile, raw = self._load_and_validate(self._profile_path)
            self._profile = profile
            self._rollback_active = False
            if self._last_good_path is not None:
                _write_json_atomic(self._last_good_path, raw)
        except Exception as exc:
            logger.warning(
                "thoth-proxy: runtime policy profile validation failed; attempting last-known-good rollback",
                exc_info=True,
            )
            if self._restore_last_good():
                self._rollback_active = True
                logger.warning("thoth-proxy: rolled back to last-known-good runtime policy: %s", exc)

    def _load_and_validate(self, path: Path) -> tuple[RuntimePolicyProfile, dict[str, Any]]:
        raw = _load_profile_file(path)
        signature_valid = _verify_signature(
            raw,
            secret=self._hmac_secret,
            allow_unsigned=self._allow_unsigned,
        )
        profile = _validate_payload(raw)
        return (
            RuntimePolicyProfile(
                profile_id=profile.profile_id,
                policy_version=profile.policy_version,
                source=profile.source,
                enforcement_mode=profile.enforcement_mode,
                approved_scope=profile.approved_scope,
                session_intent=profile.session_intent,
                signature_valid=signature_valid,
            ),
            raw,
        )

    def _restore_last_good(self) -> bool:
        if self._last_good_path is None or not self._last_good_path.exists():
            return False
        try:
            profile, _ = self._load_and_validate(self._last_good_path)
        except Exception:
            return False
        self._profile = profile
        return True

    def effective_enforcement_mode(self, default: str) -> str:
        if self._profile is None or self._profile.enforcement_mode is None:
            return default
        return self._profile.enforcement_mode

    def effective_approved_scope(self, default: list[str]) -> list[str]:
        if self._profile is None or self._profile.approved_scope is None:
            return list(default)
        return list(self._profile.approved_scope)

    def effective_session_intent(self, default: str | None) -> str | None:
        if self._profile is None:
            return default
        if self._profile.session_intent is None:
            return default
        return self._profile.session_intent

    def metadata(self) -> RuntimePolicyMetadata:
        if self._profile is None:
            return RuntimePolicyMetadata(
                policy_version=None,
                policy_source=None,
                policy_profile_id=None,
                signature_valid=None,
                rollback_active=self._rollback_active,
            )
        return RuntimePolicyMetadata(
            policy_version=self._profile.policy_version,
            policy_source=self._profile.source,
            policy_profile_id=self._profile.profile_id,
            signature_valid=self._profile.signature_valid,
            rollback_active=self._rollback_active,
        )
