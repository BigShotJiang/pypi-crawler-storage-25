from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Mapping, Sequence, TextIO

from thoth_mcp_proxy.executable_resolver import ProcessResolutionError, resolve_executable as _resolve_executable

_DEFAULT_POSIX_PATH = "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
_DEFAULT_WINDOWS_PATH = r"C:\\Windows\\System32;C:\\Windows"

__all__ = [
    "ProcessResolutionError",
    "ResolvedProcessCommand",
    "build_clean_env",
    "build_exec_command",
    "resolve_executable",
    "resolve_upstream_command",
    "validate_exec_command",
    "validate_runtime_environment",
    "with_path_prepend",
]


@dataclass(frozen=True)
class ResolvedProcessCommand:
    executable: str
    args: list[str]
    env: dict[str, str]
    cwd: str | None
    source: str


def _is_windows() -> bool:
    return os.name == "nt" or sys.platform.startswith("win")


def build_clean_env(base_env: Mapping[str, str] | None = None) -> dict[str, str]:
    env = dict(os.environ)
    if base_env:
        env.update({k: str(v) for k, v in base_env.items()})

    default_path = _DEFAULT_WINDOWS_PATH if _is_windows() else _DEFAULT_POSIX_PATH
    path_value = env.get("PATH", "").strip() or default_path
    env["PATH"] = path_value
    return env


def _path_entries(path_value: str) -> list[str]:
    return [entry for entry in path_value.split(os.pathsep) if entry]


def _dedupe_keep_order(entries: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for entry in entries:
        key = entry.lower() if _is_windows() else entry
        if key in seen:
            continue
        seen.add(key)
        result.append(entry)
    return result


def with_path_prepend(env: Mapping[str, str], prepend: list[str]) -> dict[str, str]:
    current = _path_entries(str(env.get("PATH", "")))
    merged = _dedupe_keep_order([p for p in prepend if p] + current)
    next_env = dict(env)
    next_env["PATH"] = os.pathsep.join(merged)
    return next_env


def _is_explicit_path(command: str) -> bool:
    return Path(command).is_absolute() or (os.sep in command) or (os.altsep is not None and os.altsep in command)


def _normalize_command_tokens(raw_args: Sequence[object]) -> list[str]:
    if isinstance(raw_args, str | bytes | bytearray):
        raise ProcessResolutionError(
            "upstream command must be provided as a list/sequence of arguments",
            command=str(raw_args),
            suggestion="Provide argv tokens, not a shell command string.",
        )

    normalized: list[str] = []
    for token in raw_args:
        if isinstance(token, list | tuple | dict | set):
            raise ProcessResolutionError(
                "upstream command must be a flat list of strings",
                command=str(raw_args[0]) if raw_args else "",
                suggestion="Flatten nested arguments before launching the process.",
            )
        if token is None:
            continue
        value = str(token).strip()
        if not value:
            continue
        if "\x00" in value:
            raise ProcessResolutionError(
                "upstream command contains a NUL byte, which is invalid for subprocess execution",
                command=value,
            )
        normalized.append(value)
    return normalized


def build_exec_command(args: Sequence[object]) -> tuple[str, list[str]]:
    normalized = _normalize_command_tokens(args)

    if "--" in normalized:
        normalized = normalized[normalized.index("--") + 1 :]

    if not normalized:
        raise ProcessResolutionError(
            "upstream command is empty",
            command="",
            suggestion="Provide a command after '--', for example: thoth run ... -- node server.js",
        )

    executable = normalized[0]
    exec_args = normalized[1:]

    if len(normalized) == 1 and " " in executable and not _is_explicit_path(executable):
        raise ProcessResolutionError(
            "upstream command appears to be a single shell string instead of argv tokens",
            command=executable,
            suggestion="Pass command and arguments as separate list items (e.g. ['node', 'server.js']).",
        )

    return executable, exec_args


def _resolve_path_argument(value: str, *, cwd: str | None) -> Path:
    candidate = Path(value)
    if candidate.is_absolute():
        return candidate
    base = Path(cwd) if cwd else Path.cwd()
    return (base / candidate).resolve()


def validate_exec_command(executable: str, args: list[str], *, cwd: str | None = None) -> None:
    exec_path = _resolve_path_argument(executable, cwd=cwd)
    if not exec_path.exists():
        raise ProcessResolutionError(
            f"Executable not found: {exec_path}",
            command=executable,
            attempted_paths=[str(exec_path)],
        )
    if not _is_windows() and not os.access(exec_path, os.X_OK):
        raise ProcessResolutionError(
            f"Executable is not runnable: {exec_path}",
            command=executable,
            attempted_paths=[str(exec_path)],
        )

    if not args:
        return

    first_arg = args[0]
    if first_arg in {"-", "--"} or first_arg.startswith("-"):
        return
    if not _is_explicit_path(first_arg):
        return

    arg_path = _resolve_path_argument(first_arg, cwd=cwd)
    if not arg_path.exists():
        raise ProcessResolutionError(
            f"Command argument path does not exist: {arg_path}",
            command=executable,
            attempted_paths=[str(arg_path)],
        )


def validate_runtime_environment(
    resolved: ResolvedProcessCommand,
    *,
    enforcement_mode: str,
    stderr: TextIO | None = None,
) -> bool:
    """Best-effort runtime dependency checks for constrained MCP hosts."""
    stream = stderr or sys.stderr

    try:
        validate_exec_command(resolved.executable, resolved.args, cwd=resolved.cwd)
    except ProcessResolutionError as exc:
        stream.write(f"error: runtime validation failed for executable: {exc}\n")
        if exc.suggestion:
            stream.write(f"error: suggestion: {exc.suggestion}\n")
        stream.flush()
        return False

    # Validate common Node runtime dependencies for npx/npm-backed launches.
    required_bins: list[str] = []
    optional_bins: list[str] = ["node", "npm", "npx"]
    executable_name = Path(resolved.executable).name.lower()

    if resolved.source == "node_package_global":
        required_bins.append("node")
    if executable_name.startswith("npx"):
        required_bins.append("node")

    # Progressive/observe mode tolerates optional runtime gaps.
    tolerant_mode = enforcement_mode in {"observe", "progressive"}

    seen_required: set[str] = set()
    for name in required_bins:
        if name in seen_required:
            continue
        seen_required.add(name)
        try:
            resolve_executable(name, cwd=resolved.cwd, env=resolved.env)
        except ProcessResolutionError as exc:
            stream.write(f"error: required runtime dependency '{name}' is unavailable: {exc}\n")
            if exc.suggestion:
                stream.write(f"error: suggestion: {exc.suggestion}\n")
            stream.flush()
            return False

    for name in optional_bins:
        if name in seen_required:
            continue
        try:
            resolve_executable(name, cwd=resolved.cwd, env=resolved.env)
        except ProcessResolutionError as exc:
            prefix = "warn" if tolerant_mode else "info"
            stream.write(f"{prefix}: optional runtime dependency '{name}' not found: {exc}\n")
            if exc.suggestion:
                stream.write(f"{prefix}: suggestion: {exc.suggestion}\n")
    stream.flush()
    return True


def resolve_executable(command: str, *, cwd: str | None = None, env: Mapping[str, str] | None = None) -> str:
    resolved_env = build_clean_env(env)
    if _is_explicit_path(command):
        candidate = Path(command)
        if not candidate.is_absolute():
            base = Path(cwd) if cwd else Path.cwd()
            candidate = (base / candidate).resolve()
        return _resolve_executable(str(candidate), env=resolved_env)
    return _resolve_executable(command, env=resolved_env)


def _looks_like_node_package(value: str) -> bool:
    return value.startswith("@") and "/" in value


def _parse_npx_package_and_args(args: list[str]) -> tuple[str | None, list[str]]:
    package_from_flag: str | None = None
    i = 0
    while i < len(args):
        token = args[i]
        if token == "--":
            i += 1
            break
        if token in {"-y", "--yes", "--no"}:
            i += 1
            continue
        if token in {"-p", "--package"} and i + 1 < len(args):
            package_from_flag = args[i + 1]
            i += 2
            continue
        if token.startswith("-"):
            i += 1
            continue
        return token, args[i + 1 :]

    if package_from_flag:
        return package_from_flag, args[i:]
    if i < len(args):
        return args[i], args[i + 1 :]
    return None, []


def _npm_query(npm_executable: str, query_args: list[str], *, env: Mapping[str, str]) -> str:
    proc = subprocess.run(
        [npm_executable, *query_args],
        capture_output=True,
        text=True,
        check=False,
        env=dict(env),
    )
    if proc.returncode != 0:
        raise ProcessResolutionError(
            f"npm {' '.join(query_args)} failed with exit code {proc.returncode}",
            command=npm_executable,
            suggestion=(proc.stderr or "").strip() or "Verify npm installation and permissions.",
        )
    value = (proc.stdout or "").strip()
    if not value:
        raise ProcessResolutionError(
            f"npm {' '.join(query_args)} returned empty output",
            command=npm_executable,
        )
    return value


def _node_package_bin_names(package_name: str, global_root: Path) -> list[str]:
    package_dir = global_root / Path(package_name)
    package_json = package_dir / "package.json"
    if not package_json.exists():
        return []

    try:
        payload = json.loads(package_json.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []

    bin_field = payload.get("bin")
    if isinstance(bin_field, str):
        return [package_name.rsplit("/", maxsplit=1)[-1]]
    if isinstance(bin_field, dict):
        return [str(name) for name in bin_field if str(name).strip()]
    return []


def _node_package_default_bin_candidates(package_name: str) -> list[str]:
    leaf = package_name.rsplit("/", maxsplit=1)[-1]
    if leaf.startswith("server-"):
        return [f"mcp-{leaf}", leaf]
    return [leaf]


def _resolve_node_package(
    package_name: str,
    package_args: list[str],
    *,
    cwd: str | None,
    env: Mapping[str, str],
    parent_error: ProcessResolutionError,
) -> ResolvedProcessCommand:
    try:
        node_exec = resolve_executable("node", cwd=cwd, env=env)
        npm_exec = resolve_executable("npm", cwd=cwd, env=env)
    except ProcessResolutionError as exc:
        raise ProcessResolutionError(
            f"Node.js runtime is required to launch MCP package '{package_name}'.",
            command=package_name,
            attempted_paths=parent_error.attempted_paths + exc.attempted_paths,
            suggestion="Install Node.js and npm, then retry.",
        ) from exc

    npm_global_root = Path(_npm_query(npm_exec, ["root", "-g"], env=env))
    npm_global_bin = npm_global_root.parent / "bin"
    if not npm_global_bin.exists():
        npm_global_bin = Path(npm_exec).parent

    package_dir = npm_global_root / Path(package_name)
    if not package_dir.exists():
        raise ProcessResolutionError(
            f"MCP package '{package_name}' is not installed globally.",
            command=package_name,
            attempted_paths=parent_error.attempted_paths,
            suggestion=f"Run: npm install -g {package_name}",
        )

    candidates = _node_package_bin_names(package_name, npm_global_root)
    if not candidates:
        candidates = _node_package_default_bin_candidates(package_name)

    env_with_bins = with_path_prepend(
        env,
        [str(npm_global_bin), str(Path(node_exec).parent), str(Path(npm_exec).parent)],
    )

    attempted: list[str] = []
    for candidate in candidates:
        try:
            executable = resolve_executable(candidate, cwd=cwd, env=env_with_bins)
            return ResolvedProcessCommand(
                executable=executable,
                args=package_args,
                env=env_with_bins,
                cwd=cwd,
                source="node_package_global",
            )
        except ProcessResolutionError as exc:
            attempted.extend(exc.attempted_paths)

    raise ProcessResolutionError(
        f"Unable to resolve executable for MCP package '{package_name}'.",
        command=package_name,
        attempted_paths=attempted,
        suggestion=f"Reinstall package: npm install -g {package_name}",
    )


def resolve_upstream_command(
    upstream_cmd: list[str],
    *,
    cwd: str | None = None,
    env: Mapping[str, str] | None = None,
) -> ResolvedProcessCommand:
    cmd, args = build_exec_command(upstream_cmd)
    resolved_env = build_clean_env(env)

    # Always normalize `npx <package> ...` into a deterministic executable path.
    # This avoids runtime dependence on npx behavior and PATH quirks.
    if cmd == "npx":
        package, package_args = _parse_npx_package_and_args(args)
        if not package:
            raise ProcessResolutionError(
                "Unable to parse npm package from npx invocation.",
                command=cmd,
                suggestion="Specify package explicitly, e.g. 'npx -y <package>'.",
            )
        resolved = _resolve_node_package(
            package,
            package_args,
            cwd=cwd,
            env=resolved_env,
            parent_error=ProcessResolutionError(
                "npx invocation normalized to node package resolution",
                command=cmd,
            ),
        )
        validate_exec_command(resolved.executable, resolved.args, cwd=resolved.cwd)
        return resolved

    try:
        executable = resolve_executable(cmd, cwd=cwd, env=resolved_env)
        # npx often uses '/usr/bin/env node' shebang; ensure node dir is visible.
        if Path(executable).name.lower().startswith("npx"):
            try:
                node_exec = resolve_executable("node", cwd=cwd, env=resolved_env)
                resolved_env = with_path_prepend(
                    resolved_env,
                    [str(Path(executable).parent), str(Path(node_exec).parent)],
                )
            except ProcessResolutionError:
                pass
        resolved = ResolvedProcessCommand(
            executable=executable,
            args=args,
            env=resolved_env,
            cwd=cwd,
            source="direct",
        )
        validate_exec_command(resolved.executable, resolved.args, cwd=resolved.cwd)
        return resolved
    except ProcessResolutionError as base_error:
        if _looks_like_node_package(cmd):
            resolved = _resolve_node_package(
                cmd,
                args,
                cwd=cwd,
                env=resolved_env,
                parent_error=base_error,
            )
            validate_exec_command(resolved.executable, resolved.args, cwd=resolved.cwd)
            return resolved

        raise
