from setuptools import setup, find_packages

setup(
    name="artp",
    version="0.2.37",
    author="Artem",
    description="?????????? ? ????????? ????????? ??? Python",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.6",
)
