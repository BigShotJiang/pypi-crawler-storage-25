"""Base runner interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from space_evals.events import Event, EventBus, EventType
from space_evals.graders.base import get_grader
from space_evals.models.results import GraderResult, TestResult
from space_evals.models.spec import TestSpec
from space_evals.models.transcript import Transcript, Turn


class BaseRunner(ABC):
    """Interface that all test runners must implement.

    Runners receive an EventBus so they can emit events as the test
    progresses (for real-time UI).  They return both a TestResult and
    a Transcript so the engine can persist and report on them.

    The ``grader_context`` dict is forwarded to every grader's grade()
    call, providing shared resources like the judge client.
    """

    def __init__(self, event_bus: EventBus, grader_context: dict | None = None) -> None:
        self.event_bus = event_bus
        self.grader_context = grader_context or {}

    @abstractmethod
    async def run(self, spec: TestSpec) -> tuple[TestResult, Transcript]:
        """Execute a test spec and return (result, transcript)."""
        ...

    async def _run_graders(
        self,
        grader_specs: list[dict[str, Any]],
        turn: Turn,
        test_id: str,
        extra_event_data: dict[str, Any] | None = None,
    ) -> tuple[bool, list[GraderResult]]:
        """Run graders against a turn, emitting events. Returns (all_passed, results)."""
        all_passed = True
        results: list[GraderResult] = []
        for grader_spec in grader_specs:
            grader = get_grader(grader_spec["type"])
            result = await grader.grade(turn, grader_spec, context=self.grader_context)
            results.append(result)

            data: dict[str, Any] = {
                "grader_type": result.grader_type,
                "passed": result.passed,
                "message": result.message,
            }
            if extra_event_data:
                data.update(extra_event_data)

            self.event_bus.emit(Event(
                event_type=EventType.GRADER_COMPLETED,
                test_id=test_id,
                data=data,
            ))

            if not result.passed:
                all_passed = False

        return all_passed, results
