from __future__ import annotations

import time
from typing import Any

from space_evals.clients.base import BaseClient, Message
from space_evals.models.token_usage import TokenUsage
from space_evals.events import Event, EventBus, EventType
from space_evals.models.results import TestOutcome, TestResult
from space_evals.models.spec import ScriptedTestSpec, TestSpec
from space_evals.models.transcript import Transcript, Turn
from space_evals.runners.base import BaseRunner


class ScriptedRunner(BaseRunner):
    """Replays scripted turns against a target LLM and grades each response."""

    def __init__(self, event_bus: EventBus, target_client: BaseClient, grader_context: dict[str, Any] | None = None) -> None:
        super().__init__(event_bus, grader_context)
        self.target_client = target_client

    async def run(self, spec: TestSpec) -> tuple[TestResult, Transcript]:
        if not isinstance(spec, ScriptedTestSpec):
            raise TypeError(f"ScriptedRunner requires ScriptedTestSpec, got {type(spec).__name__}")

        transcript = Transcript(test_id=spec.id)
        conversation: list[Message] = []
        all_passed = True
        total_usage = TokenUsage()
        start = time.monotonic()

        self.event_bus.emit(Event(
            event_type=EventType.TEST_STARTED,
            test_id=spec.id,
            data={"scenario": spec.scenario, "type": "scripted"},
        ))

        for i, turn_spec in enumerate(spec.turns):
            turn_number = i + 1
            self.event_bus.emit(Event(
                event_type=EventType.TURN_STARTED,
                test_id=spec.id,
                data={"turn_number": turn_number, "user_message": turn_spec.user_message},
            ))

            conversation.append(Message(role="user", content=turn_spec.user_message))
            turn_start = time.monotonic()
            response = await self.target_client.send(messages=conversation)
            turn_duration = (time.monotonic() - turn_start) * 1000

            conversation.append(Message(role="assistant", content=response.content))

            turn = Turn(
                turn_number=turn_number,
                user_message=turn_spec.user_message,
                assistant_response=response.content,
                tool_calls=response.tool_calls,
                duration_ms=turn_duration,
                token_usage=response.usage,
            )
            if response.usage:
                total_usage += response.usage

            self.event_bus.emit(Event(
                event_type=EventType.RESPONSE_RECEIVED,
                test_id=spec.id,
                data={"turn_number": turn_number, "response": response.content},
            ))

            # Run graders for this turn.
            turn_passed, grader_results = await self._run_graders(
                turn_spec.graders, turn, spec.id, {"turn_number": turn_number},
            )
            turn.grader_results = grader_results
            if not turn_passed:
                all_passed = False

            transcript.add_turn(turn)

        total_duration = (time.monotonic() - start) * 1000
        outcome = TestOutcome.PASSED if all_passed else TestOutcome.FAILED
        transcript.total_usage = total_usage

        test_result = TestResult(
            test_id=spec.id,
            scenario=spec.scenario,
            test_type="scripted",
            outcome=outcome,
            duration_ms=total_duration,
            total_input_tokens=total_usage.input_tokens,
            total_output_tokens=total_usage.output_tokens,
        )

        self.event_bus.emit(Event(
            event_type=EventType.TEST_COMPLETED,
            test_id=spec.id,
            data={"outcome": outcome.value, "duration_ms": total_duration},
        ))

        return test_result, transcript
