from __future__ import annotations

import time
from typing import Any

from space_evals.clients.base import BaseClient, Message
from space_evals.models.token_usage import TokenUsage
from space_evals.events import Event, EventBus, EventType
from space_evals.models.results import TestOutcome, TestResult
from space_evals.models.spec import TaskBasedTestSpec, TestSpec
from space_evals.models.transcript import Transcript, Turn
from space_evals.runners.base import BaseRunner


class TaskBasedRunner(BaseRunner):
    """LLM-as-customer loop: a customer LLM talks to the target LLM until
    an end condition is met or max_turns is reached."""

    def __init__(
        self,
        event_bus: EventBus,
        target_client: BaseClient,
        customer_client: BaseClient,
        grader_context: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(event_bus, grader_context)
        self.target_client = target_client
        self.customer_client = customer_client

    async def run(self, spec: TestSpec) -> tuple[TestResult, Transcript]:
        if not isinstance(spec, TaskBasedTestSpec):
            raise TypeError(f"TaskBasedRunner requires TaskBasedTestSpec, got {type(spec).__name__}")

        transcript = Transcript(test_id=spec.id)
        target_conversation: list[Message] = []
        customer_conversation: list[Message] = []
        total_usage = TokenUsage()
        start = time.monotonic()

        self.event_bus.emit(Event(
            event_type=EventType.TEST_STARTED,
            test_id=spec.id,
            data={"scenario": spec.scenario, "type": "task_based", "goal": spec.goal},
        ))

        # Seed the conversation with the initial user message.
        current_user_message = spec.initial_user_message

        for i in range(spec.max_turns):
            turn_number = i + 1
            self.event_bus.emit(Event(
                event_type=EventType.TURN_STARTED,
                test_id=spec.id,
                data={"turn_number": turn_number, "user_message": current_user_message},
            ))

            # Send to target.
            target_conversation.append(Message(role="user", content=current_user_message))
            turn_start = time.monotonic()
            target_response = await self.target_client.send(messages=target_conversation)
            turn_duration = (time.monotonic() - turn_start) * 1000

            target_conversation.append(Message(role="assistant", content=target_response.content))

            turn = Turn(
                turn_number=turn_number,
                user_message=current_user_message,
                assistant_response=target_response.content,
                tool_calls=target_response.tool_calls,
                duration_ms=turn_duration,
                token_usage=target_response.usage,
            )
            if target_response.usage:
                total_usage += target_response.usage
            transcript.add_turn(turn)

            self.event_bus.emit(Event(
                event_type=EventType.RESPONSE_RECEIVED,
                test_id=spec.id,
                data={"turn_number": turn_number, "response": target_response.content},
            ))

            # Check end conditions.
            if self._check_end_conditions(turn, spec):
                break

            # Generate next customer message.
            customer_conversation.append(
                Message(role="assistant", content=target_response.content)
            )

            if spec.customer_system_prompt is not None:
                system_prompt = spec.customer_system_prompt
            else:
                system_prompt = (
                    f"You are a user trying to accomplish this goal: {spec.goal}\n"
                    f"Continue the conversation naturally to achieve your goal."
                )

            customer_response = await self.customer_client.send(
                messages=customer_conversation,
                system_prompt=system_prompt,
            )

            if customer_response.usage:
                total_usage += customer_response.usage

            current_user_message = customer_response.content
            customer_conversation.append(
                Message(role="user", content=current_user_message)
            )

        # Run transcript-level graders.
        last_turn = transcript.turns[-1] if transcript.turns else Turn(turn_number=0, user_message="")
        all_passed, _ = await self._run_graders(spec.transcript_graders, last_turn, spec.id)

        total_duration = (time.monotonic() - start) * 1000
        outcome = TestOutcome.PASSED if all_passed else TestOutcome.FAILED
        transcript.total_usage = total_usage

        test_result = TestResult(
            test_id=spec.id,
            scenario=spec.scenario,
            test_type="task_based",
            outcome=outcome,
            duration_ms=total_duration,
            total_input_tokens=total_usage.input_tokens,
            total_output_tokens=total_usage.output_tokens,
        )

        self.event_bus.emit(Event(
            event_type=EventType.TEST_COMPLETED,
            test_id=spec.id,
            data={"outcome": outcome.value, "duration_ms": total_duration},
        ))

        return test_result, transcript

    def _check_end_conditions(self, turn: Turn, spec: TaskBasedTestSpec) -> bool:
        """Check if any end condition is met. Returns True to stop."""
        for condition in spec.end_conditions:
            condition_type = condition.get("type")

            if condition_type == "tool_calls":
                expected_calls = condition.get("expected_calls", [])
                actual = {(tc.tool_name, tuple(sorted(tc.arguments.items()))) for tc in turn.tool_calls}
                for ec in expected_calls:
                    key = (ec["tool_name"], tuple(sorted(ec.get("arguments", {}).items())))
                    if key in actual:
                        return True

            elif condition_type == "keyword_match":
                keyword = condition.get("keyword", "")
                if keyword and keyword in (turn.assistant_response or ""):
                    return True

        return False
