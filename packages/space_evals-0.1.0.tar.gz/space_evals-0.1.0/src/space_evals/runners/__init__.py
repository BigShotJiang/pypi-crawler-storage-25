"""Runner package — test execution strategies."""

from __future__ import annotations

from typing import Any

from space_evals.events import EventBus
from space_evals.models.spec import TestType


def create_runner(
    spec: Any,
    event_bus: EventBus,
    target_client: Any,
    customer_client: Any | None = None,
    grader_context: dict[str, Any] | None = None,
) -> Any:
    """Factory: instantiate the correct runner for a test spec."""
    from space_evals.runners.scripted import ScriptedRunner
    from space_evals.runners.task_based import TaskBasedRunner

    if spec.type == TestType.SCRIPTED:
        return ScriptedRunner(
            event_bus=event_bus,
            target_client=target_client,
            grader_context=grader_context,
        )
    elif spec.type == TestType.TASK_BASED:
        if customer_client is None:
            raise ValueError(
                f"Test '{spec.id}' is task_based but no customer_client was provided."
            )
        return TaskBasedRunner(
            event_bus=event_bus,
            target_client=target_client,
            customer_client=customer_client,
            grader_context=grader_context,
        )
    else:
        raise ValueError(f"No runner registered for type: {spec.type}")
