"""JUnit XML output for CI/CD integration."""

from __future__ import annotations

from typing import TYPE_CHECKING
from xml.etree.ElementTree import Element, SubElement, tostring

if TYPE_CHECKING:
    from space_evals.engine import RunResult

from space_evals.models.results import TestOutcome


def to_junit_xml(run_result: RunResult) -> str:
    """Convert a RunResult to JUnit XML format.

    Produces a <testsuites> document with one <testsuite> containing
    one <testcase> per test. Failed tests get a <failure> element,
    errored tests get an <error> element.
    """
    testsuites = Element("testsuites")

    testsuite = SubElement(testsuites, "testsuite", {
        "name": "space-evals",
        "tests": str(run_result.total),
        "failures": str(run_result.failed),
        "errors": str(run_result.errors),
    })

    for result, transcript in run_result.results:
        testcase = SubElement(testsuite, "testcase", {
            "name": result.test_id,
            "classname": result.test_type,
        })
        if result.duration_ms is not None:
            testcase.set("time", f"{result.duration_ms / 1000:.3f}")

        # Emit parameter values and parent ID as JUnit properties.
        if result.parameters or result.parent_test_id:
            properties = SubElement(testcase, "properties")
            if result.parent_test_id:
                SubElement(properties, "property", {
                    "name": "parent_test_id",
                    "value": result.parent_test_id,
                })
            if result.parameters:
                for key, value in result.parameters.items():
                    SubElement(properties, "property", {
                        "name": key,
                        "value": str(value),
                    })

        if result.outcome == TestOutcome.FAILED:
            failure = SubElement(testcase, "failure", {
                "message": f"Test {result.test_id} failed",
            })
            # Include grader messages in the failure body.
            messages = []
            for turn in transcript.turns:
                for gr in turn.grader_results:
                    if not gr.passed:
                        messages.append(f"[{gr.grader_type}] {gr.message}")
            failure.text = "\n".join(messages) if messages else "Test failed."

        elif result.outcome == TestOutcome.ERROR:
            error = SubElement(testcase, "error", {
                "message": result.error or "Unknown error",
            })
            error.text = result.error or ""

    return tostring(testsuites, encoding="unicode", xml_declaration=True)
