"""First-class transcript data structure built incrementally by runners."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from space_evals.models.results import GraderResult
from space_evals.models.token_usage import TokenUsage


@dataclass
class ToolCall:
    tool_name: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass
class Turn:
    turn_number: int
    user_message: str
    assistant_response: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)
    grader_results: list[GraderResult] = field(default_factory=list)
    duration_ms: float | None = None
    token_usage: TokenUsage | None = None


@dataclass
class Transcript:
    test_id: str
    turns: list[Turn] = field(default_factory=list)
    total_usage: TokenUsage = field(default_factory=TokenUsage)

    def add_turn(self, turn: Turn) -> None:
        self.turns.append(turn)

    @property
    def total_turns(self) -> int:
        return len(self.turns)
