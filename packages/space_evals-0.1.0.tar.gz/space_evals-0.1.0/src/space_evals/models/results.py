"""Result models for graders and test runs."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class GraderOutcome(Enum):
    PASSED = "passed"
    FAILED = "failed"


@dataclass
class GraderResult:
    grader_type: str
    outcome: GraderOutcome
    message: str = ""
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return self.outcome == GraderOutcome.PASSED


class TestOutcome(Enum):
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"


@dataclass
class TestResult:
    test_id: str
    scenario: str
    test_type: str
    outcome: TestOutcome
    run_id: str = ""
    error: str | None = None
    duration_ms: float | None = None
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    parameters: dict[str, Any] | None = None
    parent_test_id: str | None = None
