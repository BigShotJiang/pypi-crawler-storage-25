"""Pydantic models for the space-evals.yaml config file."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field


class RetryConfig(BaseModel):
    max_retries: int = Field(default=3, ge=0)
    base_delay: float = Field(default=1.0, gt=0)
    max_delay: float = Field(default=60.0, gt=0)
    retryable_status_codes: list[int] = Field(default=[429, 503])


class RateLimitConfig(BaseModel):
    requests_per_minute: int = Field(default=60, ge=1)


class LoggingConfig(BaseModel):
    level: str = Field(default="WARNING", pattern="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$")
    format: str = Field(default="text", pattern="^(text|json)$")
    output: str = Field(default="stderr", min_length=1)


class ClientConfig(BaseModel):
    provider: str = Field(pattern=r"^[a-z][a-z0-9_-]*$")
    model: str = Field(min_length=1)
    api_key_env: str | None = Field(default=None, pattern=r"^[A-Za-z_][A-Za-z0-9_]*$")
    params: dict[str, Any] = Field(default_factory=dict)
    retry: RetryConfig | None = None
    rate_limit: RateLimitConfig | None = None


class ClientsConfig(BaseModel):
    target: ClientConfig
    customer: ClientConfig | None = None
    judge: ClientConfig | None = None


class RunnerConfig(BaseModel):
    max_concurrency: int = Field(default=10, ge=1)
    fail_under: float | None = Field(default=None, ge=0.0, le=1.0)
    max_failures: int | None = Field(default=None, ge=1)


class OutputConfig(BaseModel):
    dir: str = "./results"
    format: str = Field(default="text", pattern="^(text|junit)$")


class Config(BaseModel):
    clients: ClientsConfig
    runner: RunnerConfig = RunnerConfig()
    output: OutputConfig = OutputConfig()
    retry: RetryConfig = RetryConfig()
    rate_limit: RateLimitConfig | None = None
    logging: LoggingConfig = LoggingConfig()


CONFIG_FILENAMES = ["space-evals.yaml", "space-evals.yml", ".space-evals.yaml", ".space-evals.yml"]


def find_config(start_dir: str | Path | None = None) -> Path | None:
    """Search for a config file starting from start_dir, walking up to root."""
    current = Path(start_dir) if start_dir else Path.cwd()
    current = current.resolve()

    while True:
        for name in CONFIG_FILENAMES:
            candidate = current / name
            if candidate.is_file():
                return candidate
        parent = current.parent
        if parent == current:
            return None
        current = parent


def load_config(path: str | Path | None = None) -> Config:
    """Load and validate a config file.

    If path is None, searches for one automatically.
    """
    if path is None:
        found = find_config()
        if found is None:
            raise FileNotFoundError(f"No config file found. Create one of: {CONFIG_FILENAMES}")
        path = found

    path = Path(path)
    with open(path) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict):
        raise ValueError(f"{path}: expected a YAML mapping, got {type(raw).__name__}")

    return Config.model_validate(raw)
