"""Pydantic models for YAML test spec files."""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class TestType(str, Enum):
    SCRIPTED = "scripted"
    TASK_BASED = "task_based"


# --- Grader specs (shared across test types) ---


class GraderSpec(BaseModel):
    type: str


class ExactMatchGraderSpec(GraderSpec):
    type: Literal["exact_match"] = "exact_match"
    expected_response: str


class LLMJudgeAssertion(BaseModel):
    type: str


class LLMJudgeGraderSpec(GraderSpec):
    type: Literal["llm_judge"] = "llm_judge"
    assertions: list[LLMJudgeAssertion]


class ExpectedToolCall(BaseModel):
    tool_name: str
    arguments: dict[str, Any] = {}


class ToolCallsGraderSpec(GraderSpec):
    type: Literal["tool_calls"] = "tool_calls"
    expected_calls: list[ExpectedToolCall]


# --- Shared mixin for parameterizable specs ---


class _ParameterizableMixin(BaseModel):
    tags: list[str] = []
    parameters: list[dict[str, Any]] | None = None
    parameters_from: str | None = None

    @model_validator(mode="after")
    def _check_params_exclusive(self):
        if self.parameters is not None and self.parameters_from is not None:
            raise ValueError("Cannot specify both 'parameters' and 'parameters_from'")
        return self


# --- Scripted test spec ---


class ScriptedTurn(BaseModel):
    user_message: str = Field(min_length=1)
    graders: list[dict[str, Any]] = []

    @field_validator("graders")
    @classmethod
    def _validate_graders(cls, v: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for i, g in enumerate(v):
            if "type" not in g:
                raise ValueError(f"graders[{i}]: missing required field 'type'")
        return v


class ScriptedTestSpec(_ParameterizableMixin):
    id: str = Field(pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_.\[\]-]*$")
    type: Literal[TestType.SCRIPTED]
    scenario: str = Field(min_length=1)
    turns: list[ScriptedTurn] = Field(min_length=1)


# --- Task-based test spec ---


class EndCondition(BaseModel):
    type: str
    model_config = {"extra": "allow"}


class TaskBasedTestSpec(_ParameterizableMixin):
    id: str = Field(pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_.\[\]-]*$")
    type: Literal[TestType.TASK_BASED]
    scenario: str = Field(min_length=1)
    goal: str = Field(min_length=1)
    initial_user_message: str = Field(min_length=1)
    max_turns: int = Field(ge=1)
    end_conditions: list[dict[str, Any]] = []
    transcript_graders: list[dict[str, Any]] = []
    customer_system_prompt: str | None = None

    @field_validator("end_conditions")
    @classmethod
    def _validate_end_conditions(cls, v: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for i, ec in enumerate(v):
            if "type" not in ec:
                raise ValueError(f"end_conditions[{i}]: missing required field 'type'")
        return v

    @field_validator("transcript_graders")
    @classmethod
    def _validate_transcript_graders(cls, v: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for i, g in enumerate(v):
            if "type" not in g:
                raise ValueError(f"transcript_graders[{i}]: missing required field 'type'")
        return v


# --- Union type for loading ---

TestSpec = ScriptedTestSpec | TaskBasedTestSpec


def parse_test_spec(data: dict[str, Any]) -> TestSpec:
    """Parse a raw dict (from YAML) into the correct TestSpec model."""
    test_type = data.get("type")
    if test_type == TestType.SCRIPTED:
        return ScriptedTestSpec.model_validate(data)
    elif test_type == TestType.TASK_BASED:
        return TaskBasedTestSpec.model_validate(data)
    else:
        raise ValueError(
            f"Unknown or missing test type: {test_type!r}. Must be one of: {[t.value for t in TestType]}"
        )
