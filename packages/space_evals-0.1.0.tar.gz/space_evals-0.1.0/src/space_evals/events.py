from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol

logger = logging.getLogger("space_evals.events")


class EventType(Enum):
    TEST_STARTED = "test_started"
    TURN_STARTED = "turn_started"
    RESPONSE_RECEIVED = "response_received"
    GRADER_COMPLETED = "grader_completed"
    TEST_COMPLETED = "test_completed"
    RUN_STARTED = "run_started"
    RUN_COMPLETED = "run_completed"


@dataclass
class Event:
    event_type: EventType
    test_id: str
    data: dict[str, Any] = field(default_factory=dict)


class EventListener(Protocol):
    def on_event(self, event: Event) -> None: ...


class EventBus:
    def __init__(self) -> None:
        self._listeners: list[EventListener] = []

    def subscribe(self, listener: EventListener) -> None:
        self._listeners.append(listener)

    def unsubscribe(self, listener: EventListener) -> None:
        try:
            self._listeners.remove(listener)
        except ValueError:
            pass

    def emit(self, event: Event) -> None:
        for listener in self._listeners:
            try:
                listener.on_event(event)
            except Exception:
                logger.exception(
                    "Listener %s failed on %s event",
                    type(listener).__name__,
                    event.event_type.value,
                )
