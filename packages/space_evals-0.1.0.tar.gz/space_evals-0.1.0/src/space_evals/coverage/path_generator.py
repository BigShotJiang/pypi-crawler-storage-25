"""Generate minimum edge-covering paths from a coverage graph.

Uses a greedy DFS approach to find a minimal set of paths from entry
nodes to terminal nodes such that every edge is traversed at least once.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

from space_evals.coverage.graph import CoverageGraph


@dataclass
class GeneratedPath:
    """A single path through the coverage graph."""
    path_id: int
    intents: list[str]
    edges: list[tuple[str, str]] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.edges and len(self.intents) >= 2:
            self.edges = [
                (self.intents[i], self.intents[i + 1])
                for i in range(len(self.intents) - 1)
            ]


def generate_covering_paths(graph: CoverageGraph) -> list[GeneratedPath]:
    """Compute a set of paths that cover every edge in the graph.

    Strategy:
    1. Build the set of uncovered edges.
    2. For each entry intent, run a DFS that greedily follows uncovered
       edges, preferring edges to terminal nodes when available.
    3. Continue until all edges are covered.
    """
    uncovered: set[tuple[str, str]] = set(graph.edges)

    if not uncovered:
        return []

    entries = graph.entry_intents or [next(iter(graph.intents))]
    terminals = set(graph.terminal_intents)

    adjacency: dict[str, list[str]] = defaultdict(list)
    for src, dst in graph.edges:
        adjacency[src].append(dst)

    paths: list[GeneratedPath] = []
    path_counter = 0

    def _extend_path(start: str) -> list[str]:
        """Greedily walk from start, preferring uncovered edges."""
        path = [start]
        current = start
        while True:
            neighbors = adjacency.get(current, [])
            if not neighbors:
                break

            # Prefer uncovered edges, and among those, prefer terminal targets.
            uncovered_to_terminal = [n for n in neighbors if (current, n) in uncovered and n in terminals]
            uncovered_neighbors = [n for n in neighbors if (current, n) in uncovered]

            if uncovered_to_terminal:
                nxt = uncovered_to_terminal[0]
            elif uncovered_neighbors:
                nxt = uncovered_neighbors[0]
            else:
                break

            uncovered.discard((current, nxt))
            path.append(nxt)
            current = nxt

        return path

    # Phase 1: Generate paths from each entry node.
    for entry in entries:
        while any((entry, t) in uncovered for t in adjacency.get(entry, [])):
            path = _extend_path(entry)
            paths.append(GeneratedPath(path_id=path_counter, intents=path))
            path_counter += 1

    # Phase 2: Cover remaining edges not reachable from entry nodes.
    # Find the shortest prefix from any entry to the edge's source,
    # then extend from there.
    while uncovered:
        edge = next(iter(uncovered))
        src, dst = edge

        prefix = _find_path_to(entries, src, adjacency)
        uncovered.discard(edge)
        continuation = [dst]

        current = dst
        while True:
            neighbors = adjacency.get(current, [])
            uncovered_neighbors = [n for n in neighbors if (current, n) in uncovered]
            if not uncovered_neighbors:
                break
            uncovered_to_terminal = [n for n in uncovered_neighbors if n in terminals]
            nxt = uncovered_to_terminal[0] if uncovered_to_terminal else uncovered_neighbors[0]
            uncovered.discard((current, nxt))
            continuation.append(nxt)
            current = nxt

        full_path = prefix + continuation
        paths.append(GeneratedPath(path_id=path_counter, intents=full_path))
        path_counter += 1

    return paths


def _find_path_to(
    entries: list[str],
    target: str,
    adjacency: dict[str, list[str]],
) -> list[str]:
    """BFS to find the shortest path from any entry to target."""
    from collections import deque

    if target in entries:
        return [target]

    for entry in entries:
        visited: set[str] = {entry}
        queue: deque[list[str]] = deque([[entry]])
        while queue:
            path = queue.popleft()
            current = path[-1]
            for neighbor in adjacency.get(current, []):
                if neighbor == target:
                    return path + [target]
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(path + [neighbor])

    return [target]
