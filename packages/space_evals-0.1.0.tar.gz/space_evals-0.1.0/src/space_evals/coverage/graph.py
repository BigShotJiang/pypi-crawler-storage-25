"""Coverage graph model and YAML parser."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, field_validator, model_validator


class IntentSpec(BaseModel):
    """YAML schema for a single intent in the coverage graph."""

    description: str = ""
    transitions: list[str] = []
    variations: dict[str, list[str]] = {}
    requires: list[str] = []
    error_modes: list[str] = []


class BoundarySpec(BaseModel):
    """YAML schema for a boundary — either a bare string or a dict with triggers."""

    id: str
    example_triggers: list[str] = []


class CoverageGraphSpec(BaseModel):
    """Top-level YAML schema for a coverage graph file."""

    intents: dict[str, IntentSpec]
    boundaries: list[str | dict[str, Any]] = []
    invariants: list[str] = []

    @field_validator("intents")
    @classmethod
    def _validate_intents_nonempty(cls, v: dict[str, IntentSpec]) -> dict[str, IntentSpec]:
        if not v:
            raise ValueError("At least one intent is required")
        return v

    @model_validator(mode="after")
    def _validate_transitions_reference_known_intents(self) -> CoverageGraphSpec:
        known = set(self.intents.keys())
        for name, intent in self.intents.items():
            for t in intent.transitions:
                if t not in known:
                    raise ValueError(f"Intent '{name}' references unknown transition target '{t}'")
            for r in intent.requires:
                if r not in known:
                    raise ValueError(f"Intent '{name}' has unknown precondition '{r}'")
        return self


@dataclass(frozen=True)
class Intent:
    """A single intent node in the coverage graph."""

    name: str
    description: str = ""
    transitions: tuple[str, ...] = ()
    variations: dict[str, list[str]] = field(default_factory=dict)
    requires: tuple[str, ...] = ()
    error_modes: tuple[str, ...] = ()


@dataclass(frozen=True)
class Boundary:
    """A boundary (disallowed action) in the coverage graph."""

    id: str
    example_triggers: tuple[str, ...] = ()


@dataclass
class CoverageGraph:
    """Parsed coverage graph with computed properties."""

    intents: dict[str, Intent]
    boundaries: list[Boundary]
    invariants: list[str]

    def __post_init__(self) -> None:
        self._edges: list[tuple[str, str]] = []
        self._in_degree_map: dict[str, int] = {n: 0 for n in self.intents}
        for name, intent in self.intents.items():
            for t in intent.transitions:
                self._edges.append((name, t))
                self._in_degree_map[t] = self._in_degree_map.get(t, 0) + 1

    @property
    def edges(self) -> list[tuple[str, str]]:
        return self._edges

    @property
    def entry_intents(self) -> list[str]:
        """Intents that serve as conversation entry points.

        Prefers intents with no incoming edges. If none exist (e.g., the
        graph has cycles back to the start), falls back to intents with
        more outgoing than incoming edges, or simply the first intent.
        """
        no_incoming = [n for n in self.intents if self._in_degree_map[n] == 0]
        if no_incoming:
            return no_incoming

        imbalanced = [n for n in self.intents if self.out_degree(n) > self.in_degree(n)]
        if imbalanced:
            return imbalanced

        return [next(iter(self.intents))]

    @property
    def terminal_intents(self) -> list[str]:
        return [n for n, i in self.intents.items() if not i.transitions]

    def in_degree(self, intent: str) -> int:
        return self._in_degree_map.get(intent, 0)

    def out_degree(self, intent: str) -> int:
        return len(self.intents[intent].transitions)

    @property
    def cyclomatic_complexity(self) -> int:
        """M = |E| - |V| + 2"""
        return len(self._edges) - len(self.intents) + 2

    @property
    def min_edge_covering_paths(self) -> int:
        """Minimum paths needed for full edge coverage (degree imbalance sum)."""
        total = 0
        for name in self.intents:
            excess = self.out_degree(name) - self.in_degree(name)
            if excess > 0:
                total += excess
        return max(total, 1)


def _parse_boundary(raw: str | dict[str, Any]) -> Boundary:
    if isinstance(raw, str):
        return Boundary(id=raw)
    spec = BoundarySpec.model_validate(raw)
    return Boundary(id=spec.id, example_triggers=tuple(spec.example_triggers))


def load_coverage_graph(path: str | Path) -> CoverageGraph:
    """Load and validate a coverage graph from a YAML file."""
    path = Path(path)
    with open(path) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict):
        raise ValueError(f"Coverage graph must be a YAML mapping, got {type(raw).__name__}")

    spec = CoverageGraphSpec.model_validate(raw)

    intents = {}
    for name, intent_spec in spec.intents.items():
        intents[name] = Intent(
            name=name,
            description=intent_spec.description,
            transitions=tuple(intent_spec.transitions),
            variations=intent_spec.variations,
            requires=tuple(intent_spec.requires),
            error_modes=tuple(intent_spec.error_modes),
        )

    boundaries = [_parse_boundary(b) for b in spec.boundaries]

    return CoverageGraph(
        intents=intents,
        boundaries=boundaries,
        invariants=spec.invariants,
    )
