"""Post-run coverage analyzer.

Reads persisted test results, classifies each turn's intent, maps
turns to graph edges, and computes coverage metrics.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from space_evals.coverage.graph import CoverageGraph
from space_evals.models.results import TestOutcome


@dataclass
class ClassifiedTurn:
    """A transcript turn with its classified intent."""
    turn_number: int
    user_message: str
    assistant_response: str | None
    classified_intent: str | None = None


@dataclass
class ClassifiedTest:
    """A test transcript with all turns classified."""
    test_id: str
    turns: list[ClassifiedTurn]
    observed_edges: list[tuple[str, str]] = field(default_factory=list)

    def compute_edges(self) -> None:
        """Derive edges from consecutive classified intents."""
        self.observed_edges = []
        intents = [t.classified_intent for t in self.turns if t.classified_intent]
        for i in range(len(intents) - 1):
            self.observed_edges.append((intents[i], intents[i + 1]))


@dataclass
class CoverageReport:
    """Full coverage analysis results."""
    total_edges: int
    covered_edges: set[tuple[str, str]]
    uncovered_edges: set[tuple[str, str]]
    unexpected_edges: set[tuple[str, str]]
    total_intents: int
    covered_intents: set[str]
    uncovered_intents: set[str]
    total_boundaries: int
    covered_boundaries: set[str]
    uncovered_boundaries: set[str]
    classified_tests: list[ClassifiedTest]

    @property
    def edge_coverage(self) -> float:
        if self.total_edges == 0:
            return 1.0
        return len(self.covered_edges) / self.total_edges

    @property
    def intent_coverage(self) -> float:
        if self.total_intents == 0:
            return 1.0
        return len(self.covered_intents) / self.total_intents

    @property
    def boundary_coverage(self) -> float:
        if self.total_boundaries == 0:
            return 1.0
        return len(self.covered_boundaries) / self.total_boundaries

    def to_dict(self) -> dict[str, Any]:
        return {
            "edge_coverage": self.edge_coverage,
            "intent_coverage": self.intent_coverage,
            "boundary_coverage": self.boundary_coverage,
            "total_edges": self.total_edges,
            "covered_edges": sorted(self.covered_edges),
            "uncovered_edges": sorted(self.uncovered_edges),
            "unexpected_edges": sorted(self.unexpected_edges),
            "total_intents": self.total_intents,
            "covered_intents": sorted(self.covered_intents),
            "uncovered_intents": sorted(self.uncovered_intents),
            "total_boundaries": self.total_boundaries,
            "covered_boundaries": sorted(self.covered_boundaries),
            "uncovered_boundaries": sorted(self.uncovered_boundaries),
        }

    def format_text(self) -> str:
        """Format a human-readable coverage report."""
        lines = [
            "Coverage Report",
            "=" * 50,
            "",
            f"Edge coverage:     {len(self.covered_edges)}/{self.total_edges} ({self.edge_coverage:.1%})",
            f"Intent coverage:   {len(self.covered_intents)}/{self.total_intents} ({self.intent_coverage:.1%})",
            f"Boundary coverage: {len(self.covered_boundaries)}/{self.total_boundaries} ({self.boundary_coverage:.1%})",
        ]

        if self.uncovered_edges:
            lines.append("")
            lines.append("Uncovered edges:")
            for src, dst in sorted(self.uncovered_edges):
                lines.append(f"  ✗ {src} → {dst}")

        if self.uncovered_intents:
            lines.append("")
            lines.append("Uncovered intents:")
            for intent in sorted(self.uncovered_intents):
                lines.append(f"  ✗ {intent}")

        if self.uncovered_boundaries:
            lines.append("")
            lines.append("Uncovered boundaries:")
            for b in sorted(self.uncovered_boundaries):
                lines.append(f"  ✗ {b}")

        if self.unexpected_edges:
            lines.append("")
            lines.append("Unexpected edges (not in graph):")
            for src, dst in sorted(self.unexpected_edges):
                lines.append(f"  ⚠ {src} → {dst}")

        return "\n".join(lines)


def load_test_transcripts(results_dir: str | Path) -> list[dict[str, Any]]:
    """Load all test result JSON files from a results directory.

    Supports both flat structure (results_dir/test_id/result.json)
    and run-scoped structure (results_dir/run_id/test_id/result.json).
    """
    results_dir = Path(results_dir)
    transcripts = []

    for result_file in sorted(results_dir.rglob("result.json")):
        with open(result_file) as f:
            transcripts.append(json.load(f))

    return transcripts


def classify_turns_simple(
    transcript: dict[str, Any],
    graph: CoverageGraph,
) -> ClassifiedTest:
    """Classify turns using simple keyword matching against intent names.

    This is the non-LLM fallback classifier. For production use,
    replace with an LLM-based classifier.
    """
    intent_names = list(graph.intents.keys())
    turns_data = transcript.get("transcript", [])

    intent_keywords: dict[str, tuple[list[str], list[str]]] = {}
    for name in intent_names:
        keywords = name.replace("_", " ").split()
        intent = graph.intents[name]
        desc_words = intent.description.lower().split() if intent.description else []
        intent_keywords[name] = (keywords, desc_words)

    classified_turns = []
    for turn_data in turns_data:
        turn = ClassifiedTurn(
            turn_number=turn_data.get("turn_number", 0),
            user_message=turn_data.get("user_message", ""),
            assistant_response=turn_data.get("assistant_response"),
        )

        combined_words = set(
            (turn.user_message + " " + (turn.assistant_response or "")).lower().split()
        )
        best_intent = None
        best_score = 0.0

        for intent_name in intent_names:
            keywords, desc_words = intent_keywords[intent_name]
            score = sum(1 for kw in keywords if kw in combined_words)
            score += sum(0.5 for w in desc_words if w in combined_words)
            if score > best_score:
                best_score = score
                best_intent = intent_name

        turn.classified_intent = best_intent
        classified_turns.append(turn)

    ct = ClassifiedTest(
        test_id=transcript.get("test_id", "unknown"),
        turns=classified_turns,
    )
    ct.compute_edges()
    return ct


def analyze_coverage(
    graph: CoverageGraph,
    results_dir: str | Path,
) -> CoverageReport:
    """Run coverage analysis on persisted test results."""
    transcripts = load_test_transcripts(results_dir)

    all_edges = set(graph.edges)
    all_intents = set(graph.intents.keys())
    all_boundaries = {b.id for b in graph.boundaries}

    classified_tests = []
    observed_edges: set[tuple[str, str]] = set()
    observed_intents: set[str] = set()
    observed_boundaries: set[str] = set()

    for transcript in transcripts:
        ct = classify_turns_simple(transcript, graph)
        classified_tests.append(ct)

        for edge in ct.observed_edges:
            observed_edges.add(edge)
        for turn in ct.turns:
            if turn.classified_intent:
                observed_intents.add(turn.classified_intent)

        test_id = transcript.get("test_id", "")
        if test_id.startswith("boundary_"):
            boundary_name = test_id.removeprefix("boundary_")
            if "[" in boundary_name:
                boundary_name = boundary_name.split("[")[0]
            if boundary_name in all_boundaries:
                outcome = transcript.get("outcome", "")
                if outcome == TestOutcome.PASSED.value:
                    observed_boundaries.add(boundary_name)

    covered_edges = observed_edges & all_edges
    uncovered_edges = all_edges - observed_edges
    unexpected_edges = observed_edges - all_edges
    covered_intents = observed_intents & all_intents
    uncovered_intents = all_intents - observed_intents
    covered_boundaries = observed_boundaries & all_boundaries
    uncovered_boundaries = all_boundaries - observed_boundaries

    return CoverageReport(
        total_edges=len(all_edges),
        covered_edges=covered_edges,
        uncovered_edges=uncovered_edges,
        unexpected_edges=unexpected_edges,
        total_intents=len(all_intents),
        covered_intents=covered_intents,
        uncovered_intents=uncovered_intents,
        total_boundaries=len(all_boundaries),
        covered_boundaries=covered_boundaries,
        uncovered_boundaries=uncovered_boundaries,
        classified_tests=classified_tests,
    )
