"""Structured logging for space-evals.

Provides a JSON formatter, a one-call ``setup_logging()`` function, and
a ``LoggingReporter`` that bridges EventBus events into Python's
``logging`` system so that all output (LLM calls, retries, rate limit
waits, grader results, test outcomes) can flow through a single
configurable logging pipeline.
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any

from space_evals.events import Event, EventType
from space_evals.models.config import LoggingConfig
from space_evals.reporters.base import BaseReporter

# Extra fields that the JSON formatter will pick up from LogRecords.
_EXTRA_FIELDS = (
    "provider",
    "attempt",
    "error",
    "delay_seconds",
    "wait_seconds",
    "message_count",
    "content_length",
    "has_usage",
    "test_id",
    "outcome",
    "grader_type",
    "passed",
    "duration_ms",
    "total_tests",
    "max_concurrency",
    "scenario",
    "turn_number",
    "event_message",
)


class JSONFormatter(logging.Formatter):
    """Emits one JSON object per log line — ready for DataDog, Splunk, ELK, etc."""

    def format(self, record: logging.LogRecord) -> str:
        entry: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key in _EXTRA_FIELDS:
            val = getattr(record, key, None)
            if val is not None:
                entry[key] = val
        return json.dumps(entry, default=str)


def setup_logging(config: LoggingConfig) -> None:
    """Configure the ``space_evals`` logger hierarchy."""
    root = logging.getLogger("space_evals")
    root.setLevel(getattr(logging, config.level))
    root.handlers.clear()

    if config.output == "stderr":
        handler: logging.Handler = logging.StreamHandler(sys.stderr)
    elif config.output == "stdout":
        handler = logging.StreamHandler(sys.stdout)
    else:
        handler = logging.FileHandler(config.output)

    if config.format == "json":
        handler.setFormatter(JSONFormatter())
    else:
        handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        ))

    root.addHandler(handler)


class LoggingReporter(BaseReporter):
    """Bridges EventBus events into Python's ``logging`` system."""

    def __init__(self) -> None:
        self.logger = logging.getLogger("space_evals.events")

    def on_event(self, event: Event) -> None:
        # Rename keys that clash with LogRecord built-in attributes.
        safe_data = {}
        for k, v in event.data.items():
            if k in ("message", "asctime"):
                safe_data[f"event_{k}"] = v
            else:
                safe_data[k] = v
        extra = {"test_id": event.test_id, **safe_data}

        match event.event_type:
            case EventType.RUN_STARTED:
                self.logger.info("Run started", extra=extra)
            case EventType.TEST_STARTED:
                self.logger.info("Test started: %s", event.test_id, extra=extra)
            case EventType.TURN_STARTED:
                self.logger.debug("Turn started", extra=extra)
            case EventType.RESPONSE_RECEIVED:
                self.logger.debug("Response received", extra=extra)
            case EventType.GRADER_COMPLETED:
                level = logging.INFO if event.data.get("passed") else logging.WARNING
                self.logger.log(level, "Grader %s", "passed" if event.data.get("passed") else "failed", extra=extra)
            case EventType.TEST_COMPLETED:
                outcome = event.data.get("outcome", "")
                level = logging.INFO if outcome == "passed" else logging.WARNING
                self.logger.log(level, "Test %s: %s", outcome, event.test_id, extra=extra)
            case EventType.RUN_COMPLETED:
                self.logger.info("Run completed", extra=extra)
