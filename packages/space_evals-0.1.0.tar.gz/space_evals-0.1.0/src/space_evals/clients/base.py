"""Base client interface and unified registry."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from space_evals.models.token_usage import TokenUsage
from space_evals.models.transcript import ToolCall


@dataclass
class Message:
    role: str  # "user" or "assistant"
    content: str
    tool_calls: list[ToolCall] = field(default_factory=list)


@dataclass
class ClientResponse:
    content: str
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: TokenUsage | None = None
    raw: dict[str, Any] = field(default_factory=dict)


class BaseClient(ABC):
    """Interface that all LLM clients must implement.

    A client can play any role: the target being tested, the simulated
    customer (for task-based tests), or the LLM judge (for grading).
    The runner decides which role a client instance plays.
    """

    @abstractmethod
    async def send(self, messages: list[Message], system_prompt: str = "") -> ClientResponse:
        """Send a conversation and return the assistant's response."""
        ...


# Unified registry — populated by register_client() and by plugin discovery.
_CLIENT_REGISTRY: dict[str, type[BaseClient]] = {}

# Provider aliases — map friendly names to an underlying provider + default params.
# When a user writes e.g. `provider: huggingface`, we resolve it to the "openai"
# client with the right base_url and api_key_env defaults.  User-supplied values
# in the config override these defaults.
_PROVIDER_ALIASES: dict[str, dict[str, Any]] = {
    "huggingface": {
        "provider": "openai",
        "base_url": "https://api-inference.huggingface.co/v1/",
        "api_key_env": "HF_TOKEN",
    },
    "groq": {
        "provider": "openai",
        "base_url": "https://api.groq.com/openai/v1",
        "api_key_env": "GROQ_API_KEY",
    },
    "together": {
        "provider": "openai",
        "base_url": "https://api.together.xyz/v1",
        "api_key_env": "TOGETHER_API_KEY",
    },
    "fireworks": {
        "provider": "openai",
        "base_url": "https://api.fireworks.ai/inference/v1",
        "api_key_env": "FIREWORKS_API_KEY",
    },
    "ollama": {
        "provider": "openai",
        "base_url": "http://localhost:11434/v1",
        "api_key_env": "OLLAMA_API_KEY",
    },
}


def register_client(provider: str):
    """Decorator to register a client class under a provider string.

    Works for both plugin clients and programmatic registration:

        @register_client("my_provider")
        class MyClient(BaseClient):
            ...
    """

    def decorator(cls: type[BaseClient]):
        _CLIENT_REGISTRY[provider] = cls
        return cls

    return decorator


def get_client(provider: str, **kwargs: Any) -> BaseClient:
    """Instantiate a client by its provider string.

    Resolves provider aliases first (e.g. "huggingface" → "openai" with
    default base_url), then checks the registry, then falls back to
    entry point discovery for installed plugins.
    """
    # Resolve alias — inject defaults, then let kwargs override.
    alias = _PROVIDER_ALIASES.get(provider)
    if alias is not None:
        real_provider = alias["provider"]
        # Apply alias defaults, but user-supplied kwargs take precedence.
        kwargs.setdefault("api_key_env", alias.get("api_key_env"))
        kwargs.setdefault("base_url", alias.get("base_url"))
        provider = real_provider

    cls = _CLIENT_REGISTRY.get(provider)
    if cls is None:
        # Lazy entry point fallback — discover and cache.
        cls = _discover_client_plugin(provider)
        if cls is not None:
            _CLIENT_REGISTRY[provider] = cls

    if cls is None:
        known = list(_CLIENT_REGISTRY.keys()) + list(_PROVIDER_ALIASES.keys())
        raise ValueError(
            f"Unknown provider: {provider!r}. "
            f"Available: {sorted(set(known))}. "
            f"If this is a plugin, install it: pip install space-evals-client-{provider}"
        )
    return cls(**kwargs)


def _discover_client_plugin(provider: str) -> type[BaseClient] | None:
    """Try to find a client via installed entry points."""
    from importlib.metadata import entry_points

    eps = entry_points()
    if hasattr(eps, "select"):
        matches = eps.select(group="space_evals.clients", name=provider)
    else:
        matches = [ep for ep in eps.get("space_evals.clients", []) if ep.name == provider]

    for ep in matches:
        return ep.load()
    return None
