"""Generic HTTP client for custom LLM endpoints.

This client ships with space-evals core so users can connect to any
HTTP-based LLM endpoint without writing a plugin package. It sends
a POST request and extracts the response using configurable JSON paths.

Config example:

    clients:
      target:
        provider: http
        model: my-model
        params:
          url: "https://my-llm.example.com/v1/chat"
          headers:
            Authorization: "Bearer ${MY_API_KEY}"
          # JSON paths to extract from the response body:
          response_content_path: "choices.0.message.content"
          # Optional paths for token usage:
          input_tokens_path: "usage.prompt_tokens"
          output_tokens_path: "usage.completion_tokens"
          # Optional: customize the request body structure.
          # Default builds an OpenAI-compatible body.
          request_template:
            model: "{{model}}"
            messages: "{{messages}}"
            stream: false
"""

from __future__ import annotations

import copy
import os
import re
from typing import Any

from space_evals.clients.base import BaseClient, ClientResponse, Message, register_client
from space_evals.models.token_usage import TokenUsage


def _resolve_env_vars(value: str) -> str:
    """Replace ${VAR_NAME} patterns with environment variable values."""

    def _replacer(match: re.Match) -> str:
        var_name = match.group(1)
        env_val = os.environ.get(var_name)
        if env_val is None:
            raise ValueError(f"Environment variable '{var_name}' is not set")
        return env_val

    return re.sub(r"\$\{(\w+)\}", _replacer, value)


def _resolve_env_in_dict(d: dict[str, Any]) -> dict[str, Any]:
    """Recursively resolve ${VAR} references in dict string values."""
    resolved = {}
    for k, v in d.items():
        if isinstance(v, str):
            resolved[k] = _resolve_env_vars(v)
        elif isinstance(v, dict):
            resolved[k] = _resolve_env_in_dict(v)
        else:
            resolved[k] = v
    return resolved


def _extract_json_path(data: Any, path: str) -> Any:
    """Extract a value from nested JSON using a dot-separated path.

    Supports dict keys and integer list indices:
        "choices.0.message.content" -> data["choices"][0]["message"]["content"]
    """
    current = data
    for part in path.split("."):
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError):
                return None
        elif isinstance(current, dict):
            current = current.get(part)
            if current is None:
                return None
        else:
            return None
    return current


@register_client("http")
class HTTPClient(BaseClient):
    """A generic HTTP client that works with any JSON-based LLM endpoint.

    Translates space-evals's Message format into an HTTP POST and extracts
    the response content from the JSON body using configurable paths.
    """

    def __init__(
        self,
        model: str,
        url: str,
        headers: dict[str, str] | None = None,
        response_content_path: str = "choices.0.message.content",
        input_tokens_path: str | None = None,
        output_tokens_path: str | None = None,
        request_template: dict[str, Any] | None = None,
        **params: Any,
    ) -> None:
        self.model = model
        self.url = _resolve_env_vars(url)
        self.headers = _resolve_env_in_dict(headers or {})
        self.response_content_path = response_content_path
        self.input_tokens_path = input_tokens_path
        self.output_tokens_path = output_tokens_path
        self.request_template = request_template
        self.params = params
        self._session: Any = None

    async def close(self) -> None:
        """Close the underlying HTTP session."""
        if self._session is not None:
            await self._session.close()
            self._session = None

    async def _get_session(self) -> Any:
        if self._session is None:
            try:
                import aiohttp
            except ImportError:
                raise ImportError(
                    "aiohttp is required for the HTTP client. "
                    "Install it with: pip install 'space-evals[http]'"
                )
            self._session = aiohttp.ClientSession()
        return self._session

    def _build_request_body(self, messages: list[Message], system_prompt: str) -> dict[str, Any]:
        """Build the JSON request body to POST to the endpoint."""
        api_messages = []
        if system_prompt:
            api_messages.append({"role": "system", "content": system_prompt})
        for msg in messages:
            api_messages.append({"role": msg.role, "content": msg.content})

        if self.request_template:
            body = copy.deepcopy(self.request_template)
            body = _substitute_template(
                body,
                {
                    "model": self.model,
                    "messages": api_messages,
                },
            )
            return body

        # Default: OpenAI-compatible request body.
        return {
            "model": self.model,
            "messages": api_messages,
            **self.params,
        }

    async def send(self, messages: list[Message], system_prompt: str = "") -> ClientResponse:
        session = await self._get_session()

        body = self._build_request_body(messages, system_prompt)
        request_headers = {"Content-Type": "application/json", **self.headers}

        async with session.post(self.url, json=body, headers=request_headers) as resp:
            resp.raise_for_status()
            data = await resp.json()

        content = _extract_json_path(data, self.response_content_path)
        if content is None:
            content = ""
        content = str(content)

        usage = None
        if self.input_tokens_path and self.output_tokens_path:
            input_tokens = _extract_json_path(data, self.input_tokens_path)
            output_tokens = _extract_json_path(data, self.output_tokens_path)
            if input_tokens is not None and output_tokens is not None:
                usage = TokenUsage(
                    input_tokens=int(input_tokens),
                    output_tokens=int(output_tokens),
                )

        return ClientResponse(
            content=content,
            usage=usage,
            raw=data if isinstance(data, dict) else {"response": data},
        )


def _substitute_template(obj: Any, values: dict[str, Any]) -> Any:
    """Replace '{{key}}' string placeholders in a template structure."""
    if isinstance(obj, str):
        # Check for exact placeholder match (returns the actual object, not str).
        for key, val in values.items():
            if obj == "{{" + key + "}}":
                return val
        # Otherwise do string interpolation.
        for key, val in values.items():
            obj = obj.replace("{{" + key + "}}", str(val))
        return obj
    elif isinstance(obj, dict):
        return {k: _substitute_template(v, values) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_substitute_template(item, values) for item in obj]
    return obj
