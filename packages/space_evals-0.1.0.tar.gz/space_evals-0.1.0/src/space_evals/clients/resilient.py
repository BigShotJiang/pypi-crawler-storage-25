"""Resilient client wrapper: retry with exponential backoff and rate limiting.

Wraps any ``BaseClient`` transparently — callers still see the same
``send()`` interface.  Retry and rate limiting are composed in a single
wrapper so that all client implementations (OpenAI, Anthropic, HTTP,
future plugins) get resilience for free.
"""

from __future__ import annotations

import asyncio
import logging
import random
import time

from space_evals.clients.base import BaseClient, ClientResponse, Message
from space_evals.models.config import RetryConfig

logger = logging.getLogger("space_evals.clients")


# ---------------------------------------------------------------------------
# Retry
# ---------------------------------------------------------------------------


class RetryHandler:
    """Exponential backoff with jitter for transient LLM API errors."""

    def __init__(self, config: RetryConfig) -> None:
        self.max_retries = config.max_retries
        self.base_delay = config.base_delay
        self.max_delay = config.max_delay
        self.retryable_status_codes = set(config.retryable_status_codes)

    def is_retryable(self, exc: Exception) -> bool:
        """Decide whether *exc* is transient and worth retrying.

        Uses duck-typing to check for ``.status_code`` or ``.status``
        attributes so we don't need hard dependencies on aiohttp, openai,
        or anthropic.
        """
        # Network-level errors are always retryable.
        if isinstance(exc, (ConnectionError, TimeoutError, OSError)):
            return True

        # Check for HTTP status codes on provider-specific exceptions.
        status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
        if status is not None and int(status) in self.retryable_status_codes:
            return True

        return False

    def delay_for_attempt(self, attempt: int) -> float:
        """Calculate delay with exponential backoff + jitter."""
        delay = min(self.base_delay * (2**attempt), self.max_delay)
        jitter = random.uniform(0, delay * 0.1)
        return delay + jitter


# ---------------------------------------------------------------------------
# Rate limiting (token bucket)
# ---------------------------------------------------------------------------


class TokenBucketRateLimiter:
    """Async token-bucket rate limiter.  Throttles *before* sending."""

    def __init__(self, requests_per_minute: int) -> None:
        self.rate = requests_per_minute / 60.0  # tokens per second
        self.max_tokens = float(requests_per_minute)
        self._tokens = float(requests_per_minute)
        self._last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> float:
        """Wait until a token is available.  Returns seconds waited."""
        async with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return 0.0
            wait_time = (1.0 - self._tokens) / self.rate
            # Release lock while sleeping so other tasks aren't blocked.
        await asyncio.sleep(wait_time)
        async with self._lock:
            self._refill()
            self._tokens -= 1.0
            return wait_time

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self.max_tokens, self._tokens + elapsed * self.rate)
        self._last_refill = now


# ---------------------------------------------------------------------------
# Composed wrapper
# ---------------------------------------------------------------------------


class ResilientClient(BaseClient):
    """Wraps any ``BaseClient`` with retry and rate limiting."""

    def __init__(
        self,
        inner: BaseClient,
        retry_handler: RetryHandler | None = None,
        rate_limiter: TokenBucketRateLimiter | None = None,
        provider: str = "",
    ) -> None:
        self.inner = inner
        self.retry_handler = retry_handler
        self.rate_limiter = rate_limiter
        self.provider = provider

    async def send(self, messages: list[Message], system_prompt: str = "") -> ClientResponse:
        last_exception: Exception | None = None
        max_attempts = (self.retry_handler.max_retries + 1) if self.retry_handler else 1

        for attempt in range(max_attempts):
            # Rate limit (pre-send throttle).
            if self.rate_limiter:
                wait_time = await self.rate_limiter.acquire()
                if wait_time > 0:
                    logger.info(
                        "Rate limited: waited %.2fs",
                        wait_time,
                        extra={"provider": self.provider, "wait_seconds": round(wait_time, 2)},
                    )

            try:
                logger.debug(
                    "Sending request (attempt %d/%d)",
                    attempt + 1,
                    max_attempts,
                    extra={
                        "provider": self.provider,
                        "attempt": attempt + 1,
                        "message_count": len(messages),
                    },
                )
                response = await self.inner.send(messages, system_prompt)
                if attempt > 0:
                    logger.info(
                        "Request succeeded after %d retries",
                        attempt,
                        extra={"provider": self.provider, "attempt": attempt + 1},
                    )
                return response

            except Exception as exc:
                last_exception = exc
                if (
                    self.retry_handler
                    and self.retry_handler.is_retryable(exc)
                    and attempt < self.retry_handler.max_retries
                ):
                    delay = self.retry_handler.delay_for_attempt(attempt)
                    logger.warning(
                        "Retrying after error: %s (attempt %d/%d, delay %.2fs)",
                        exc,
                        attempt + 1,
                        max_attempts,
                        delay,
                        extra={
                            "provider": self.provider,
                            "attempt": attempt + 1,
                            "error": str(exc),
                            "delay_seconds": round(delay, 2),
                        },
                    )
                    await asyncio.sleep(delay)
                else:
                    raise

        raise last_exception  # type: ignore[misc]
