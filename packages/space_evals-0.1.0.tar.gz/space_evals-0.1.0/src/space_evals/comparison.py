"""Run comparison and historical tracking.

Compare two test runs to find regressions and improvements, list past
runs, and build historical pass-rate data.
"""

from __future__ import annotations

import json
import os
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class ChangeType(str, Enum):
    REGRESSION = "regression"
    IMPROVEMENT = "improvement"
    UNCHANGED = "unchanged"
    CHANGED = "changed"
    ADDED = "added"
    REMOVED = "removed"


@dataclass
class RunMetadata:
    """Metadata for a single test run."""

    run_id: str
    label: str | None = None
    timestamp: str | None = None
    config: dict[str, Any] | None = None
    test_path: str | None = None
    max_concurrency: int | None = None
    summary: dict[str, int] = field(default_factory=dict)
    _dir_path: Path | None = field(default=None, repr=False)

    @property
    def pass_rate(self) -> float:
        total = self.summary.get("total", 0)
        if total == 0:
            return 0.0
        return self.summary.get("passed", 0) / total


@dataclass
class TestComparison:
    """Comparison of a single test across two runs."""

    test_id: str
    scenario: str
    outcome_a: str | None
    outcome_b: str | None
    duration_a: float | None
    duration_b: float | None
    change: ChangeType


@dataclass
class RunComparison:
    """Full comparison between two runs."""

    run_a: RunMetadata
    run_b: RunMetadata
    tests: list[TestComparison] = field(default_factory=list)

    def _by_change(self, change: ChangeType) -> list[TestComparison]:
        return [t for t in self.tests if t.change == change]

    @property
    def regressions(self) -> list[TestComparison]:
        return self._by_change(ChangeType.REGRESSION)

    @property
    def improvements(self) -> list[TestComparison]:
        return self._by_change(ChangeType.IMPROVEMENT)

    @property
    def unchanged(self) -> list[TestComparison]:
        return self._by_change(ChangeType.UNCHANGED)

    @property
    def added(self) -> list[TestComparison]:
        return self._by_change(ChangeType.ADDED)

    @property
    def removed(self) -> list[TestComparison]:
        return self._by_change(ChangeType.REMOVED)

    @property
    def changed(self) -> list[TestComparison]:
        return self._by_change(ChangeType.CHANGED)

    def to_dict(self) -> dict[str, Any]:
        counts = Counter(t.change for t in self.tests)
        return {
            "run_a": _metadata_to_dict(self.run_a),
            "run_b": _metadata_to_dict(self.run_b),
            "tests": [
                {
                    "test_id": t.test_id,
                    "scenario": t.scenario,
                    "outcome_a": t.outcome_a,
                    "outcome_b": t.outcome_b,
                    "duration_a": t.duration_a,
                    "duration_b": t.duration_b,
                    "change": t.change,
                }
                for t in self.tests
            ],
            "summary": {
                "regressions": counts.get(ChangeType.REGRESSION, 0),
                "improvements": counts.get(ChangeType.IMPROVEMENT, 0),
                "unchanged": counts.get(ChangeType.UNCHANGED, 0),
                "changed": counts.get(ChangeType.CHANGED, 0),
                "added": counts.get(ChangeType.ADDED, 0),
                "removed": counts.get(ChangeType.REMOVED, 0),
            },
        }


def _metadata_to_dict(meta: RunMetadata) -> dict[str, Any]:
    return {
        "run_id": meta.run_id,
        "label": meta.label,
        "timestamp": meta.timestamp,
        "config": meta.config,
        "test_path": meta.test_path,
        "summary": meta.summary,
    }


# ---- Loading ----


def load_run_metadata(run_dir: Path) -> RunMetadata:
    """Load metadata for a run.  Falls back to synthesising from results."""
    meta_path = run_dir / "run_metadata.json"
    try:
        with open(meta_path) as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return _synthesize_metadata(run_dir)

    return RunMetadata(
        run_id=data.get("run_id", run_dir.name),
        label=data.get("label"),
        timestamp=data.get("timestamp"),
        config=data.get("config"),
        test_path=data.get("test_path"),
        max_concurrency=data.get("max_concurrency"),
        summary=data.get("summary", {}),
        _dir_path=run_dir,
    )


def _synthesize_metadata(run_dir: Path, results: dict[str, dict] | None = None) -> RunMetadata:
    """Build metadata from result files when run_metadata.json is missing."""
    if results is None:
        results = _load_test_results(run_dir)
    total = len(results)
    passed = sum(1 for r in results.values() if r.get("outcome") == "passed")
    failed = sum(1 for r in results.values() if r.get("outcome") == "failed")
    errors = sum(1 for r in results.values() if r.get("outcome") == "error")

    # Use directory mtime as approximate timestamp.
    try:
        mtime = os.path.getmtime(run_dir)
        from datetime import datetime, timezone

        timestamp = datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat()
    except OSError:
        timestamp = None

    return RunMetadata(
        run_id=run_dir.name,
        timestamp=timestamp,
        summary={"total": total, "passed": passed, "failed": failed, "errors": errors},
        _dir_path=run_dir,
    )


def _load_test_results(run_dir: Path) -> dict[str, dict]:
    """Load all result.json files from a run directory."""
    results = {}
    for result_file in sorted(run_dir.glob("*/result.json")):
        try:
            with open(result_file) as f:
                data = json.load(f)
            results[data["test_id"]] = data
        except (json.JSONDecodeError, KeyError, OSError):
            # Skip malformed or unreadable result files.
            continue
    return results


def load_run(run_dir: Path) -> tuple[RunMetadata, dict[str, dict]]:
    """Load metadata and all test results for a run."""
    results = _load_test_results(run_dir)
    meta_path = run_dir / "run_metadata.json"
    try:
        with open(meta_path) as f:
            data = json.load(f)
        meta = RunMetadata(
            run_id=data.get("run_id", run_dir.name),
            label=data.get("label"),
            timestamp=data.get("timestamp"),
            config=data.get("config"),
            test_path=data.get("test_path"),
            max_concurrency=data.get("max_concurrency"),
            summary=data.get("summary", {}),
            _dir_path=run_dir,
        )
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        meta = _synthesize_metadata(run_dir, results)
    return meta, results


def list_runs(output_dir: Path) -> list[RunMetadata]:
    """List all runs in the output directory, sorted by timestamp descending."""
    runs = []
    if not output_dir.is_dir():
        return runs

    for entry in output_dir.iterdir():
        if not entry.is_dir():
            continue
        # A run directory contains at least one result.json or run_metadata.json.
        if (entry / "run_metadata.json").exists() or any(entry.glob("*/result.json")):
            runs.append(load_run_metadata(entry))

    # Sort by timestamp descending (newest first).
    runs.sort(key=lambda r: r.timestamp or "", reverse=True)
    return runs


def find_run(output_dir: Path, run_id_or_label: str) -> Path:
    """Resolve a run by ID prefix match or exact label match.

    Raises ``ValueError`` if no unique match is found.
    """
    candidates: list[Path] = []

    for entry in output_dir.iterdir():
        if not entry.is_dir():
            continue

        # Check ID prefix match.
        if entry.name.startswith(run_id_or_label):
            candidates.append(entry)
            continue

        # Check label match.
        meta_path = entry / "run_metadata.json"
        if meta_path.exists():
            try:
                with open(meta_path) as f:
                    data = json.load(f)
                if data.get("label") == run_id_or_label:
                    candidates.append(entry)
            except (json.JSONDecodeError, OSError):
                continue

    if len(candidates) == 0:
        raise ValueError(f"No run found matching: {run_id_or_label!r}")
    if len(candidates) > 1:
        ids = [c.name for c in candidates]
        raise ValueError(f"Ambiguous match for {run_id_or_label!r}: {ids}")

    return candidates[0]


# ---- Comparison ----


def _classify_change(outcome_a: str | None, outcome_b: str | None) -> ChangeType:
    """Classify the change between two outcomes."""
    if outcome_a is None:
        return ChangeType.ADDED
    if outcome_b is None:
        return ChangeType.REMOVED
    if outcome_a == outcome_b:
        return ChangeType.UNCHANGED
    if outcome_a == "passed" and outcome_b in ("failed", "error"):
        return ChangeType.REGRESSION
    if outcome_a in ("failed", "error") and outcome_b == "passed":
        return ChangeType.IMPROVEMENT
    return ChangeType.CHANGED


def compare_runs(run_dir_a: Path, run_dir_b: Path) -> RunComparison:
    """Compare two runs and classify each test as regression/improvement/etc."""
    meta_a, results_a = load_run(run_dir_a)
    meta_b, results_b = load_run(run_dir_b)

    all_test_ids = sorted(set(results_a.keys()) | set(results_b.keys()))

    tests = []
    for test_id in all_test_ids:
        result_a = results_a.get(test_id)
        result_b = results_b.get(test_id)

        outcome_a = result_a["outcome"] if result_a else None
        outcome_b = result_b["outcome"] if result_b else None

        tests.append(TestComparison(
            test_id=test_id,
            scenario=(result_b or result_a or {}).get("scenario", ""),
            outcome_a=outcome_a,
            outcome_b=outcome_b,
            duration_a=result_a.get("duration_ms") if result_a else None,
            duration_b=result_b.get("duration_ms") if result_b else None,
            change=_classify_change(outcome_a, outcome_b),
        ))

    return RunComparison(run_a=meta_a, run_b=meta_b, tests=tests)


def build_history(
    output_dir: Path,
    test_id: str | None = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Build historical pass-rate data across runs.

    If *test_id* is given, tracks that specific test's outcome over time.
    """
    runs = list_runs(output_dir)[:limit]
    # Reverse to chronological order (oldest first).
    runs.reverse()

    history = []
    for meta in runs:
        entry: dict[str, Any] = {
            "run_id": meta.run_id,
            "label": meta.label,
            "timestamp": meta.timestamp,
            "total": meta.summary.get("total", 0),
            "passed": meta.summary.get("passed", 0),
            "failed": meta.summary.get("failed", 0),
            "errors": meta.summary.get("errors", 0),
            "pass_rate": meta.pass_rate,
        }

        if test_id:
            run_dir = meta._dir_path or output_dir / meta.run_id
            result_path = run_dir / test_id / "result.json"
            try:
                with open(result_path) as f:
                    result = json.load(f)
                entry["test_outcome"] = result.get("outcome")
            except (FileNotFoundError, json.JSONDecodeError, OSError):
                entry["test_outcome"] = None

        history.append(entry)

    return history
