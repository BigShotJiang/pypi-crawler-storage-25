from __future__ import annotations

from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("starts_with")
class StartsWithGrader(BaseGrader):
    """Checks whether the assistant response starts with a given prefix.

    Spec fields:
        prefix: str             — required prefix to check
        case_sensitive: bool    — default True
    """

    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        prefix = spec.get("prefix", "")
        case_sensitive = spec.get("case_sensitive", True)
        actual = turn.assistant_response or ""

        if not prefix:
            return GraderResult(
                grader_type="starts_with",
                outcome=GraderOutcome.FAILED,
                message="Grader misconfigured: 'prefix' is empty.",
            )

        check_actual = actual if case_sensitive else actual.lower()
        check_prefix = prefix if case_sensitive else prefix.lower()

        if check_actual.startswith(check_prefix):
            return GraderResult(
                grader_type="starts_with",
                outcome=GraderOutcome.PASSED,
                message=f"Response starts with '{prefix}'.",
            )

        return GraderResult(
            grader_type="starts_with",
            outcome=GraderOutcome.FAILED,
            message=f"Response does not start with '{prefix}'.",
            details={"prefix": prefix, "actual": actual},
        )
