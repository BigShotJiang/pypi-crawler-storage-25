from __future__ import annotations

from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("contains")
class ContainsGrader(BaseGrader):
    """Checks whether the assistant response contains a given substring.

    Spec fields:
        substring: str          — required text to search for
        case_sensitive: bool    — default True
    """

    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        substring = spec.get("substring", "")
        case_sensitive = spec.get("case_sensitive", True)
        actual = turn.assistant_response or ""

        if not substring:
            return GraderResult(
                grader_type="contains",
                outcome=GraderOutcome.FAILED,
                message="Grader misconfigured: 'substring' is empty.",
            )

        haystack = actual if case_sensitive else actual.lower()
        needle = substring if case_sensitive else substring.lower()

        if needle in haystack:
            return GraderResult(
                grader_type="contains",
                outcome=GraderOutcome.PASSED,
                message=f"Response contains '{substring}'.",
            )

        return GraderResult(
            grader_type="contains",
            outcome=GraderOutcome.FAILED,
            message=f"Response does not contain '{substring}'.",
            details={"substring": substring, "actual": actual},
        )
