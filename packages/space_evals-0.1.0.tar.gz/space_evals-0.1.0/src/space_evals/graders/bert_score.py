from __future__ import annotations

from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("bert_score")
class BertScoreGrader(BaseGrader):
    """Computes BERTScore between the assistant response and a reference.

    BERTScore uses contextual embeddings to measure semantic similarity,
    making it more robust to paraphrasing than ROUGE or BLEU.

    Passes if the F1 score meets or exceeds ``min_score``.

    Spec fields:
        reference: str    — required reference text to compare against
        min_score: float  — minimum F1 score to pass (0.0–1.0, default 0.8)
        model_type: str   — BERT model to use (default "distilbert-base-uncased")

    Requires ``pip install 'space-evals[metrics]'``.
    """

    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        reference = spec.get("reference", "")
        min_score = spec.get("min_score", 0.8)
        model_type = spec.get("model_type", "distilbert-base-uncased")
        actual = turn.assistant_response or ""

        if not reference:
            return GraderResult(
                grader_type="bert_score",
                outcome=GraderOutcome.FAILED,
                message="No 'reference' text provided in grader spec.",
            )

        try:
            from bert_score import score as bert_score_fn
        except ImportError:
            return GraderResult(
                grader_type="bert_score",
                outcome=GraderOutcome.FAILED,
                message=(
                    "bert-score library is not installed. "
                    "Install it with: pip install 'space-evals[metrics]'"
                ),
            )

        P, R, F1 = bert_score_fn(
            [actual],
            [reference],
            model_type=model_type,
            verbose=False,
        )

        f1 = F1[0].item()
        precision = P[0].item()
        recall = R[0].item()
        passed = f1 >= min_score

        return GraderResult(
            grader_type="bert_score",
            outcome=GraderOutcome.PASSED if passed else GraderOutcome.FAILED,
            message=f"BERTScore F1 = {f1:.3f} (threshold: {min_score})",
            details={
                "f1": f1,
                "precision": precision,
                "recall": recall,
                "min_score": min_score,
                "model_type": model_type,
            },
        )
