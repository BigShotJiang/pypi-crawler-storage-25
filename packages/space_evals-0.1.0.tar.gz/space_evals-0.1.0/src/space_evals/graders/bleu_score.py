from __future__ import annotations

from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("bleu")
class BleuGrader(BaseGrader):
    """Computes BLEU score between the assistant response and a reference.

    Passes if the score meets or exceeds ``min_score``.

    Spec fields:
        reference: str    — required reference text to compare against
        min_score: float  — minimum score to pass (0.0–1.0, default 0.5)

    Requires ``pip install 'space-evals[metrics]'``.
    """

    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        reference = spec.get("reference", "")
        min_score = spec.get("min_score", 0.5)
        actual = turn.assistant_response or ""

        if not reference:
            return GraderResult(
                grader_type="bleu",
                outcome=GraderOutcome.FAILED,
                message="No 'reference' text provided in grader spec.",
            )

        try:
            from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
        except ImportError:
            return GraderResult(
                grader_type="bleu",
                outcome=GraderOutcome.FAILED,
                message=(
                    "nltk library is not installed. "
                    "Install it with: pip install 'space-evals[metrics]'"
                ),
            )

        ref_tokens = reference.split()
        hyp_tokens = actual.split()

        # Use smoothing to avoid zero scores on short texts.
        smoothie = SmoothingFunction().method1
        score = sentence_bleu([ref_tokens], hyp_tokens, smoothing_function=smoothie)

        passed = score >= min_score

        return GraderResult(
            grader_type="bleu",
            outcome=GraderOutcome.PASSED if passed else GraderOutcome.FAILED,
            message=f"BLEU = {score:.3f} (threshold: {min_score})",
            details={
                "score": score,
                "min_score": min_score,
            },
        )
