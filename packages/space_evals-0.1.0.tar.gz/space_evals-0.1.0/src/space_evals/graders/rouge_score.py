from __future__ import annotations

from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("rouge")
class RougeGrader(BaseGrader):
    """Computes ROUGE score between the assistant response and a reference.

    Passes if the score meets or exceeds ``min_score``.

    Spec fields:
        reference: str    — required reference text to compare against
        metric: str       — ROUGE variant: "rouge1", "rouge2", or "rougeL" (default "rougeL")
        min_score: float  — minimum score to pass (0.0–1.0, default 0.5)

    Requires ``pip install 'space-evals[metrics]'``.
    """

    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        reference = spec.get("reference", "")
        metric = spec.get("metric", "rougeL")
        min_score = spec.get("min_score", 0.5)
        actual = turn.assistant_response or ""

        if not reference:
            return GraderResult(
                grader_type="rouge",
                outcome=GraderOutcome.FAILED,
                message="No 'reference' text provided in grader spec.",
            )

        try:
            from rouge_score import rouge_scorer
        except ImportError:
            return GraderResult(
                grader_type="rouge",
                outcome=GraderOutcome.FAILED,
                message=(
                    "rouge-score library is not installed. "
                    "Install it with: pip install 'space-evals[metrics]'"
                ),
            )

        scorer = rouge_scorer.RougeScorer([metric], use_stemmer=True)
        scores = scorer.score(reference, actual)
        score_obj = scores.get(metric)
        if score_obj is None:
            return GraderResult(
                grader_type="rouge",
                outcome=GraderOutcome.FAILED,
                message=f"Unknown ROUGE metric: {metric}. Use rouge1, rouge2, or rougeL.",
            )

        fmeasure = score_obj.fmeasure
        passed = fmeasure >= min_score

        return GraderResult(
            grader_type="rouge",
            outcome=GraderOutcome.PASSED if passed else GraderOutcome.FAILED,
            message=f"ROUGE {metric} = {fmeasure:.3f} (threshold: {min_score})",
            details={
                "metric": metric,
                "score": fmeasure,
                "precision": score_obj.precision,
                "recall": score_obj.recall,
                "min_score": min_score,
            },
        )
