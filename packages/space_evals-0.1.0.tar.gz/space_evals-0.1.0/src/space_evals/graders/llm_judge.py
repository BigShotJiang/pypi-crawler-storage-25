from __future__ import annotations

from typing import Any

from space_evals.clients.base import BaseClient, Message
from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("llm_judge")
class LLMJudgeGrader(BaseGrader):
    """Uses an LLM to judge whether assertions hold for a given turn.

    The judge client is provided via context["judge_client"], which is
    wired up automatically by the engine from the config's clients.judge
    section.
    """

    async def grade(
        self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None
    ) -> GraderResult:
        context = context or {}
        judge_client: BaseClient | None = context.get("judge_client")

        if judge_client is None:
            return GraderResult(
                grader_type="llm_judge",
                outcome=GraderOutcome.FAILED,
                message=(
                    "No judge client configured. Add a 'judge' section to "
                    "clients in your space-evals config file."
                ),
            )

        assertions = spec.get("assertions", [])
        assertion_texts = [a.get("type", "") for a in assertions]

        prompt = (
            f"You are an evaluator. Given the following conversation turn, "
            f"determine whether ALL of the following assertions are true.\n\n"
            f"User message: {turn.user_message}\n"
            f"Assistant response: {turn.assistant_response}\n\n"
            f"Assertions:\n"
        )
        for i, text in enumerate(assertion_texts, 1):
            prompt += f"  {i}. {text}\n"
        prompt += (
            "\nRespond with PASS if all assertions hold, or FAIL followed by "
            "a brief explanation if any fail."
        )

        response = await judge_client.send(
            messages=[Message(role="user", content=prompt)],
        )

        passed = response.content.strip().upper().startswith("PASS")
        return GraderResult(
            grader_type="llm_judge",
            outcome=GraderOutcome.PASSED if passed else GraderOutcome.FAILED,
            message=response.content.strip(),
            details={"assertions": assertion_texts},
        )
