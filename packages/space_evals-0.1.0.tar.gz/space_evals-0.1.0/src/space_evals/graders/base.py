"""Base grader interface and unified registry."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from space_evals.models.results import GraderResult
from space_evals.models.transcript import Turn


class BaseGrader(ABC):
    """Interface that all graders must implement.

    Graders are stateless — they receive a turn (or transcript) and
    return a result.  They know nothing about which runner invoked them.

    Graders that need external resources (e.g. an LLM client for judging)
    receive them via the ``context`` dict, which is populated by the engine.
    """

    @abstractmethod
    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        """Evaluate a single turn against the grader spec."""
        ...


# Unified registry — populated by @register_grader and by plugin discovery.
_GRADER_REGISTRY: dict[str, type[BaseGrader]] = {}
_GRADER_INSTANCES: dict[str, BaseGrader] = {}


def register_grader(grader_type: str):
    """Decorator to register a grader class under a type string.

    Works for both core graders and external graders:

        @register_grader("my_grader")
        class MyGrader(BaseGrader):
            ...
    """

    def decorator(cls: type[BaseGrader]):
        _GRADER_REGISTRY[grader_type] = cls
        return cls

    return decorator


def get_grader(grader_type: str) -> BaseGrader:
    """Instantiate a grader by its type string.

    Checks the registry first (core graders + any manually registered).
    Falls back to entry point discovery for installed plugins.
    """
    cls = _GRADER_REGISTRY.get(grader_type)
    if cls is None:
        # Lazy entry point fallback — discover and cache.
        cls = _discover_grader_plugin(grader_type)
        if cls is not None:
            _GRADER_REGISTRY[grader_type] = cls

    if cls is None:
        raise ValueError(
            f"Unknown grader type: {grader_type!r}. "
            f"Registered: {list(_GRADER_REGISTRY.keys())}. "
            f"If this is a plugin, install it: pip install space-evals-grader-{grader_type}"
        )
    if grader_type not in _GRADER_INSTANCES:
        _GRADER_INSTANCES[grader_type] = cls()
    return _GRADER_INSTANCES[grader_type]


def _discover_grader_plugin(grader_type: str) -> type[BaseGrader] | None:
    """Try to find a grader via installed entry points."""
    from importlib.metadata import entry_points

    eps = entry_points()
    if hasattr(eps, "select"):
        matches = eps.select(group="space_evals.graders", name=grader_type)
    else:
        matches = [ep for ep in eps.get("space_evals.graders", []) if ep.name == grader_type]

    for ep in matches:
        return ep.load()
    return None
