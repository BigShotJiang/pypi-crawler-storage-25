from __future__ import annotations

from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("tool_calls")
class ToolCallsGrader(BaseGrader):
    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        expected_calls = spec.get("expected_calls", [])
        actual_calls = [
            {"tool_name": tc.tool_name, "arguments": tc.arguments}
            for tc in turn.tool_calls
        ]

        missing = []
        for expected in expected_calls:
            tool_name = expected.get("tool_name")
            expected_args = expected.get("arguments", {})
            found = any(
                ac["tool_name"] == tool_name and ac["arguments"] == expected_args
                for ac in actual_calls
            )
            if not found:
                missing.append(expected)

        if not missing:
            return GraderResult(
                grader_type="tool_calls",
                outcome=GraderOutcome.PASSED,
                message="All expected tool calls were made.",
            )

        return GraderResult(
            grader_type="tool_calls",
            outcome=GraderOutcome.FAILED,
            message=f"{len(missing)} expected tool call(s) not found.",
            details={"missing": missing, "actual": actual_calls},
        )
