from __future__ import annotations

import json
from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("json_schema")
class JsonSchemaGrader(BaseGrader):
    """Validates that the assistant response is valid JSON matching a schema.

    Spec fields:
        schema: dict            — JSON Schema object to validate against
        extract_json: bool      — if True, tries to extract JSON from markdown
                                  code blocks (default True)
    """

    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        schema = spec.get("schema", {})
        extract = spec.get("extract_json", True)
        actual = turn.assistant_response or ""

        # Try to parse JSON from the response.
        json_str = actual
        if extract:
            json_str = _extract_json(actual)

        try:
            parsed = json.loads(json_str)
        except (json.JSONDecodeError, ValueError) as e:
            return GraderResult(
                grader_type="json_schema",
                outcome=GraderOutcome.FAILED,
                message=f"Response is not valid JSON: {e}",
                details={"actual": actual, "error": str(e)},
            )

        # Validate against schema.
        errors = _validate_schema(parsed, schema)
        if not errors:
            return GraderResult(
                grader_type="json_schema",
                outcome=GraderOutcome.PASSED,
                message="Response matches JSON schema.",
            )

        return GraderResult(
            grader_type="json_schema",
            outcome=GraderOutcome.FAILED,
            message=f"Schema validation failed: {errors[0]}",
            details={"errors": errors, "parsed": parsed},
        )


def _extract_json(text: str) -> str:
    """Try to extract JSON from markdown code blocks or raw text."""
    import re

    # Look for ```json ... ``` blocks.
    match = re.search(r"```(?:json)?\s*\n?(.*?)\n?\s*```", text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return text.strip()


def _validate_schema(data: Any, schema: dict[str, Any], path: str = "") -> list[str]:
    """Lightweight JSON Schema validator (supports type, required, properties, items).

    This avoids a dependency on jsonschema while covering common use cases.
    """
    errors: list[str] = []

    if not schema:
        return errors

    # Type check.
    expected_type = schema.get("type")
    if expected_type:
        type_map = {
            "object": dict,
            "array": list,
            "string": str,
            "number": (int, float),
            "integer": int,
            "boolean": bool,
            "null": type(None),
        }
        expected = type_map.get(expected_type)
        if expected and not isinstance(data, expected):
            errors.append(f"{path or 'root'}: expected type '{expected_type}', got '{type(data).__name__}'")
            return errors

    # Object properties.
    if isinstance(data, dict):
        required = schema.get("required", [])
        for key in required:
            if key not in data:
                errors.append(f"{path or 'root'}: missing required field '{key}'")

        properties = schema.get("properties", {})
        for key, prop_schema in properties.items():
            if key in data:
                sub_path = f"{path}.{key}" if path else key
                errors.extend(_validate_schema(data[key], prop_schema, sub_path))

    # Array items.
    if isinstance(data, list) and "items" in schema:
        for i, item in enumerate(data):
            sub_path = f"{path}[{i}]"
            errors.extend(_validate_schema(item, schema["items"], sub_path))

    return errors
