from __future__ import annotations

import re
from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("regex")
class RegexGrader(BaseGrader):
    """Checks whether the assistant response matches a regular expression.

    Spec fields:
        pattern: str            — required regex pattern
        flags: list[str]        — optional, e.g. ["IGNORECASE", "DOTALL"]
        full_match: bool        — if True, requires full match; default False (search)
    """

    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        pattern = spec.get("pattern", "")
        flag_names = spec.get("flags", [])
        full_match = spec.get("full_match", False)
        actual = turn.assistant_response or ""

        # Build regex flags.
        flags = 0
        for name in flag_names:
            flag = getattr(re, name.upper(), None)
            if isinstance(flag, re.RegexFlag):
                flags |= flag

        try:
            compiled = re.compile(pattern, flags)
        except re.error as e:
            return GraderResult(
                grader_type="regex",
                outcome=GraderOutcome.FAILED,
                message=f"Invalid regex pattern: {e}",
                details={"pattern": pattern, "error": str(e)},
            )

        match = compiled.fullmatch(actual) if full_match else compiled.search(actual)

        if match:
            return GraderResult(
                grader_type="regex",
                outcome=GraderOutcome.PASSED,
                message=f"Response matched pattern '{pattern}'.",
                details={"matched": match.group()},
            )

        return GraderResult(
            grader_type="regex",
            outcome=GraderOutcome.FAILED,
            message=f"Response did not match pattern '{pattern}'.",
            details={"pattern": pattern, "actual": actual},
        )
