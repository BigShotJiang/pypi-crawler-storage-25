from __future__ import annotations

import importlib
from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("custom_function")
class CustomFunctionGrader(BaseGrader):
    """Calls a user-defined Python function to grade a turn.

    Spec fields:
        function: str           — dotted path to a callable, e.g.
                                  "my_package.graders.check_response"

    The function receives (turn: Turn, spec: dict) and must return a
    GraderResult or a dict with keys "passed" (bool) and optionally
    "message" (str) and "details" (dict).
    """

    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        func_path = spec.get("function", "")
        if not func_path:
            return GraderResult(
                grader_type="custom_function",
                outcome=GraderOutcome.FAILED,
                message="No 'function' path specified in grader spec.",
            )

        try:
            func = _import_function(func_path)
        except (ImportError, AttributeError) as e:
            return GraderResult(
                grader_type="custom_function",
                outcome=GraderOutcome.FAILED,
                message=f"Could not import function '{func_path}': {e}",
            )

        try:
            result = func(turn, spec)

            # Support async functions.
            if hasattr(result, "__await__"):
                result = await result

            # If the function returns a GraderResult, use it directly.
            if isinstance(result, GraderResult):
                return result

            # Otherwise expect a dict with "passed" key.
            if isinstance(result, dict):
                passed = bool(result.get("passed", False))
                return GraderResult(
                    grader_type="custom_function",
                    outcome=GraderOutcome.PASSED if passed else GraderOutcome.FAILED,
                    message=result.get("message", ""),
                    details=result.get("details", {}),
                )

            # Treat truthy/falsy return as pass/fail.
            return GraderResult(
                grader_type="custom_function",
                outcome=GraderOutcome.PASSED if result else GraderOutcome.FAILED,
                message=str(result) if result else "Custom function returned falsy.",
            )

        except Exception as e:
            return GraderResult(
                grader_type="custom_function",
                outcome=GraderOutcome.FAILED,
                message=f"Custom function raised an error: {e}",
                details={"error": str(e)},
            )


def _import_function(dotted_path: str) -> Any:
    """Import a function from a dotted path like 'package.module.func'."""
    module_path, _, func_name = dotted_path.rpartition(".")
    if not module_path:
        raise ImportError(f"Invalid function path: '{dotted_path}' (need module.function)")
    module = importlib.import_module(module_path)
    return getattr(module, func_name)
