from __future__ import annotations

from typing import Any

from space_evals.graders.base import BaseGrader, register_grader
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn


@register_grader("exact_match")
class ExactMatchGrader(BaseGrader):
    async def grade(self, turn: Turn, spec: dict[str, Any], context: dict[str, Any] | None = None) -> GraderResult:
        expected = spec.get("expected_response", "")
        actual = turn.assistant_response or ""

        if actual == expected:
            return GraderResult(
                grader_type="exact_match",
                outcome=GraderOutcome.PASSED,
                message="Response matched exactly.",
            )

        return GraderResult(
            grader_type="exact_match",
            outcome=GraderOutcome.FAILED,
            message="Response did not match.",
            details={"expected": expected, "actual": actual},
        )
