"""Base reporter interface."""

from __future__ import annotations

from abc import ABC, abstractmethod

from space_evals.events import Event


class BaseReporter(ABC):
    """Reporters listen to events and produce output.

    They implement the EventListener protocol so they can be
    subscribed to the EventBus directly.
    """

    @abstractmethod
    def on_event(self, event: Event) -> None: ...
