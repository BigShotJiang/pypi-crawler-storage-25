"""Console reporter — prints test progress to stdout."""

from __future__ import annotations

from enum import Enum

from space_evals.events import Event, EventType
from space_evals.reporters.base import BaseReporter


class Verbosity(str, Enum):
    QUIET = "quiet"
    NORMAL = "normal"
    VERBOSE = "verbose"


_OUTCOME_ICONS = {"passed": "PASS", "failed": "FAIL", "error": "ERROR"}


def _format_params(params: dict | None) -> str:
    if not params:
        return ""
    pairs = ", ".join(f"{k}={v}" for k, v in params.items())
    return f" {{{pairs}}}"


class ConsoleReporter(BaseReporter):
    def __init__(self, verbosity: Verbosity = Verbosity.NORMAL) -> None:
        self.verbosity = verbosity
        self._failures: list[dict] = []

    def on_event(self, event: Event) -> None:
        match event.event_type:
            case EventType.RUN_STARTED:
                self._failures.clear()
                total = event.data.get("total_tests", 0)
                print(f"\n{'=' * 60}")
                print(f"  Running {total} test(s)...")
                print(f"{'=' * 60}\n")

            case EventType.TEST_STARTED:
                if self.verbosity in (Verbosity.NORMAL, Verbosity.VERBOSE):
                    scenario = event.data.get("scenario", "")
                    test_type = event.data.get("type", "")
                    params = event.data.get("parameters")
                    param_str = _format_params(params)
                    print(f"  [{test_type}] {event.test_id}{param_str}: {scenario}")

            case EventType.TURN_STARTED:
                if self.verbosity == Verbosity.VERBOSE:
                    turn = event.data.get("turn_number", 0)
                    msg = event.data.get("user_message", "")
                    preview = msg[:60] + "..." if len(msg) > 60 else msg
                    print(f"    Turn {turn} -> {preview}")

            case EventType.RESPONSE_RECEIVED:
                if self.verbosity == Verbosity.VERBOSE:
                    turn = event.data.get("turn_number", 0)
                    resp = event.data.get("response", "")
                    preview = resp[:60] + "..." if len(resp) > 60 else resp
                    print(f"    Turn {turn} <- {preview}")

            case EventType.GRADER_COMPLETED:
                if self.verbosity == Verbosity.VERBOSE:
                    grader = event.data.get("grader_type", "")
                    passed = event.data.get("passed", False)
                    msg = event.data.get("message", "")
                    print(f"    [{'PASS' if passed else 'FAIL'}] {grader}: {msg}")

            case EventType.TEST_COMPLETED:
                outcome = event.data.get("outcome", "")
                duration = event.data.get("duration_ms", 0)
                icon = _OUTCOME_ICONS.get(outcome, "FAIL")

                if outcome != "passed":
                    self._failures.append({
                        "test_id": event.test_id,
                        "outcome": outcome,
                        "duration_ms": duration,
                    })

                if self.verbosity == Verbosity.QUIET:
                    if outcome != "passed":
                        print(f"  [{icon}] {event.test_id} ({duration:.0f}ms)")
                else:
                    print(f"  [{icon}] {event.test_id} ({duration:.0f}ms)\n")

            case EventType.RUN_COMPLETED:
                total = event.data.get("total", 0)
                passed = event.data.get("passed", 0)
                failed = event.data.get("failed", 0)
                errors = event.data.get("errors", 0)

                if self.verbosity == Verbosity.QUIET and self._failures:
                    print()

                print(f"{'=' * 60}")
                print(f"  Results: {passed} passed, {failed} failed, {errors} errors ({total} total)")
                print(f"{'=' * 60}\n")
