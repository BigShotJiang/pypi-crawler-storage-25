"""Parameter expansion for parameterized test specs.

Handles template substitution (``{{variable}}`` syntax), loading
parameter sets from external files (CSV, JSON), and expanding a
single parameterized spec into multiple concrete test instances.
"""

from __future__ import annotations

import copy
import csv
import json
import re
from pathlib import Path
from typing import Any

from space_evals.models.spec import parse_test_spec

_TEMPLATE_RE = re.compile(r"\{\{(\w+)\}\}")


def render_template(template: str, params: dict[str, Any]) -> str:
    """Replace ``{{key}}`` placeholders in *template* with values from *params*.

    Raises ``ValueError`` if a placeholder references a key not in *params*.
    """
    def _replacer(match: re.Match) -> str:
        key = match.group(1)
        if key not in params:
            raise ValueError(
                f"Template variable '{{{{{key}}}}}' has no matching parameter. "
                f"Available: {sorted(params.keys())}"
            )
        return str(params[key])

    return _TEMPLATE_RE.sub(_replacer, template)


def _substitute_recursive(obj: Any, params: dict[str, Any]) -> Any:
    """Walk a nested dict/list structure, substituting template strings."""
    if isinstance(obj, str):
        return render_template(obj, params)
    if isinstance(obj, dict):
        return {k: _substitute_recursive(v, params) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_substitute_recursive(item, params) for item in obj]
    return obj


def load_parameters_from_file(file_path: str, base_dir: Path) -> list[dict[str, Any]]:
    """Load parameter sets from a CSV, JSON, or Hugging Face dataset.

    *file_path* is resolved relative to *base_dir* (the directory
    containing the YAML spec).  Hugging Face datasets use a ``hf://``
    URI scheme: ``hf://dataset_name/split`` or ``hf://dataset_name/config/split``.

    CSV files use the header row as parameter names.
    JSON files must contain a list of objects.
    """
    # Handle hf:// URIs for Hugging Face datasets.
    if file_path.startswith("hf://"):
        return _load_hf_dataset(file_path)

    resolved = (base_dir / file_path).resolve()
    if not resolved.is_relative_to(base_dir.resolve()):
        raise ValueError(
            f"Parameters file path escapes base directory: {file_path}"
        )
    if not resolved.exists():
        raise FileNotFoundError(f"Parameters file not found: {resolved}")

    suffix = resolved.suffix.lower()

    if suffix == ".csv":
        with open(resolved, newline="") as f:
            reader = csv.DictReader(f)
            return [dict(row) for row in reader]

    if suffix == ".json":
        with open(resolved) as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError(f"Parameters JSON must be a list of objects, got {type(data).__name__}")
        for i, item in enumerate(data):
            if not isinstance(item, dict):
                raise ValueError(f"Parameters JSON item {i} must be an object, got {type(item).__name__}")
        return data

    raise ValueError(f"Unsupported parameters file format: {suffix} (use .csv or .json)")


def _load_hf_dataset(uri: str) -> list[dict[str, Any]]:
    """Load parameter sets from a Hugging Face dataset.

    URI format::

        hf://dataset_name/split
        hf://dataset_name/split[:N]
        hf://dataset_name/config/split
        hf://dataset_name/config/split[:N]

    Examples::

        hf://cais/mmlu/all/test
        hf://gsm8k/main/test[:100]
        hf://squad/train[:50]

    Requires ``pip install 'space-evals[huggingface]'``.
    """
    try:
        from datasets import load_dataset
    except ImportError:
        raise ImportError(
            "The 'datasets' library is required for Hugging Face dataset parameters. "
            "Install it with: pip install 'space-evals[huggingface]'"
        )

    # Parse: strip hf:// prefix, then split path and optional slice.
    path = uri[len("hf://"):]

    # Extract optional slice like [:100] or [10:50].
    limit_slice = None
    if path.endswith("]"):
        bracket_idx = path.rfind("[")
        if bracket_idx != -1:
            slice_str = path[bracket_idx + 1 : -1]
            path = path[:bracket_idx]
            limit_slice = _parse_slice(slice_str)

    # Split remaining path into dataset name, optional config, and split.
    parts = path.split("/")
    if len(parts) < 2:
        raise ValueError(
            f"Invalid hf:// URI: {uri!r}. "
            f"Expected format: hf://dataset_name/split or hf://dataset_name/config/split"
        )

    # Determine if there's a config: datasets with org/name have >=3 parts already.
    # Heuristic: if 2 parts → dataset + split; if 3 → could be org/dataset/split
    # or dataset/config/split; if 4 → org/dataset/config/split.
    if len(parts) == 2:
        dataset_name = parts[0]
        config_name = None
        split_name = parts[1]
    elif len(parts) == 3:
        # Could be "org/dataset/split" or "dataset/config/split".
        # Convention: treat first two as dataset name (org/dataset), last as split.
        dataset_name = f"{parts[0]}/{parts[1]}"
        config_name = None
        split_name = parts[2]
    elif len(parts) == 4:
        # "org/dataset/config/split"
        dataset_name = f"{parts[0]}/{parts[1]}"
        config_name = parts[2]
        split_name = parts[3]
    else:
        raise ValueError(
            f"Invalid hf:// URI: {uri!r}. Too many path segments."
        )

    kwargs: dict[str, Any] = {"path": dataset_name, "split": split_name}
    if config_name is not None:
        kwargs["name"] = config_name

    ds = load_dataset(**kwargs)

    # Apply slice if specified.
    if limit_slice is not None:
        ds = ds.select(range(*limit_slice.indices(len(ds))))

    # Convert to list of dicts, casting non-serializable values to strings.
    rows: list[dict[str, Any]] = []
    for row in ds:
        rows.append({k: _normalize_value(v) for k, v in row.items()})
    return rows


def _parse_slice(s: str) -> slice:
    """Parse a slice string like '100', ':100', '10:50' into a slice object."""
    parts = s.split(":")
    if len(parts) == 1:
        # Just a number means [:N]
        return slice(None, int(parts[0]))
    if len(parts) == 2:
        start = int(parts[0]) if parts[0] else None
        stop = int(parts[1]) if parts[1] else None
        return slice(start, stop)
    raise ValueError(f"Invalid slice: [{s}]")


def _normalize_value(v: Any) -> Any:
    """Convert dataset values to template-friendly types."""
    if isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, list):
        return str(v)
    return str(v)


def expand_spec(
    raw: dict[str, Any],
    base_dir: Path,
) -> list[tuple[Any, dict[str, Any] | None]]:
    """Expand a raw YAML dict into concrete ``(TestSpec, params)`` tuples.

    If the spec is not parameterized, returns a single-element list with
    ``params=None``.  Otherwise, returns one entry per parameter set,
    each with a unique instance ID (``original_id[index]``).

    Substitution happens on the **raw dict** before Pydantic validation,
    so template values in integer fields (e.g. ``max_turns: "{{n}}"``)
    are handled correctly by YAML/Pydantic coercion.
    """
    parameters = raw.get("parameters")
    parameters_from = raw.get("parameters_from")

    if parameters is None and not parameters_from:
        # Not parameterized — validate and return as-is.
        spec = parse_test_spec(raw)
        return [(spec, None)]

    # Load parameter sets.
    if parameters_from:
        param_sets = load_parameters_from_file(parameters_from, base_dir)
    else:
        param_sets = parameters  # type: ignore[assignment]

    if not param_sets:
        raise ValueError("Parameters list is empty")

    original_id = raw.get("id", "unknown")
    results = []

    for index, params in enumerate(param_sets):
        # Deep-copy and substitute.
        instance_raw = copy.deepcopy(raw)

        # Remove parameter fields — the expanded instance is concrete.
        instance_raw.pop("parameters", None)
        instance_raw.pop("parameters_from", None)

        # Set unique instance ID.
        instance_raw["id"] = f"{original_id}[{index}]"

        # Substitute all template strings.
        instance_raw = _substitute_recursive(instance_raw, params)

        # Validate the substituted spec.
        spec = parse_test_spec(instance_raw)
        results.append((spec, params))

    return results
