"""Engine: discovery, validation, routing, and orchestration."""

from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from space_evals.clients.base import BaseClient
from space_evals.events import Event, EventBus, EventType
from space_evals.models.results import TestOutcome, TestResult
from space_evals.models.spec import parse_test_spec
from space_evals.models.transcript import Transcript
from space_evals.params import expand_spec
from space_evals.runners import create_runner

# Ensure built-in clients are registered on import.
import space_evals.clients.http_client  # noqa: F401

# Ensure graders are registered on import.
import space_evals.graders.contains  # noqa: F401
import space_evals.graders.custom_function  # noqa: F401
import space_evals.graders.exact_match  # noqa: F401
import space_evals.graders.json_schema  # noqa: F401
import space_evals.graders.llm_judge  # noqa: F401
import space_evals.graders.regex_match  # noqa: F401
import space_evals.graders.starts_with  # noqa: F401
import space_evals.graders.tool_calls  # noqa: F401
import space_evals.graders.rouge_score  # noqa: F401
import space_evals.graders.bleu_score  # noqa: F401
import space_evals.graders.bert_score  # noqa: F401


class RunResult:
    """Aggregated result of running a full test suite."""

    def __init__(self, run_id: str) -> None:
        self.run_id = run_id
        self.results: list[tuple[TestResult, Transcript]] = []
        self.metadata: dict[str, Any] | None = None

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed(self) -> int:
        return sum(1 for r, _ in self.results if r.outcome == TestOutcome.PASSED)

    @property
    def failed(self) -> int:
        return sum(1 for r, _ in self.results if r.outcome == TestOutcome.FAILED)

    @property
    def errors(self) -> int:
        return sum(1 for r, _ in self.results if r.outcome == TestOutcome.ERROR)


class _ParameterEnrichingBus:
    """Wraps an EventBus to inject parameter metadata into TEST_STARTED events.

    Runners remain unaware of parameterization — enrichment happens at the bus layer.
    """

    def __init__(
        self,
        inner: EventBus,
        params_map: dict[str, dict[str, Any] | None],
        parent_map: dict[str, str | None],
    ) -> None:
        self._inner = inner
        self._params_map = params_map
        self._parent_map = parent_map

    def emit(self, event: Event) -> None:
        if event.event_type == EventType.TEST_STARTED:
            enriched_data = {
                **event.data,
                "parameters": self._params_map.get(event.test_id),
                "parent_test_id": self._parent_map.get(event.test_id),
            }
            event = Event(event_type=event.event_type, test_id=event.test_id, data=enriched_data)
        self._inner.emit(event)

    def subscribe(self, listener: Any) -> None:
        self._inner.subscribe(listener)

    def unsubscribe(self, listener: Any) -> None:
        self._inner.unsubscribe(listener)


def discover_test_files(path: str | Path) -> list[Path]:
    """Recursively find all .yaml/.yml files from the given path."""
    path = Path(path)
    if path.is_file():
        return [path]
    return sorted(path.rglob("*.yaml")) + sorted(path.rglob("*.yml"))


def load_yaml(file_path: Path) -> dict[str, Any]:
    """Load a YAML file and return the raw dict."""
    with open(file_path) as f:
        raw = yaml.safe_load(f)
    if not isinstance(raw, dict):
        raise ValueError(f"{file_path}: expected a YAML mapping, got {type(raw).__name__}")
    return raw


def load_and_validate(file_path: Path) -> Any:
    """Load a YAML file and validate it against the correct spec model."""
    raw = load_yaml(file_path)
    return parse_test_spec(raw)


def _expand_all_specs(
    file_specs: list[tuple[Path, dict[str, Any]]],
) -> list[tuple[Any, dict[str, Any] | None]]:
    """Expand parameterized specs into concrete instances.

    If a single spec fails to expand (bad template, missing file, etc.),
    it is skipped with a warning rather than aborting the entire run.
    """
    import logging

    logger = logging.getLogger("space_evals.engine")
    expanded = []
    for file_path, raw in file_specs:
        try:
            instances = expand_spec(raw, base_dir=file_path.parent)
            expanded.extend(instances)
        except Exception as e:
            spec_id = raw.get("id", file_path.name)
            logger.warning("Skipping spec '%s' from %s: %s", spec_id, file_path, e)
    return expanded


async def run_tests(
    path: str | Path,
    target_client: BaseClient,
    customer_client: BaseClient | None = None,
    judge_client: BaseClient | None = None,
    event_bus: EventBus | None = None,
    output_dir: str | Path | None = None,
    max_concurrency: int = 10,
    label: str | None = None,
    config: Any | None = None,
    tags: list[str] | None = None,
    max_failures: int | None = None,
) -> RunResult:
    """Main entrypoint: discover, validate, route, execute, aggregate."""
    if event_bus is None:
        event_bus = EventBus()

    run_id = uuid.uuid4().hex[:12]
    run_result = RunResult(run_id=run_id)
    started_at = datetime.now(timezone.utc)

    files = discover_test_files(path)
    if not files:
        raise FileNotFoundError(f"No .yaml/.yml test files found at: {path}")

    file_specs: list[tuple[Path, dict[str, Any]]] = []
    for f in files:
        raw = load_yaml(f)
        file_specs.append((f, raw))

    expanded = _expand_all_specs(file_specs)
    if not expanded:
        raise ValueError("No valid test specs found after expansion")

    # Filter by tags if requested.
    if tags:
        tag_set = set(tags)
        expanded = [(spec, params) for spec, params in expanded if tag_set & set(spec.tags)]
        if not expanded:
            raise ValueError(f"No tests match the requested tags: {tags}")

    specs = [spec for spec, _params in expanded]

    # Build maps for parameter enrichment.
    params_map: dict[str, dict[str, Any] | None] = {}
    parent_map: dict[str, str | None] = {}
    for spec, params in expanded:
        params_map[spec.id] = params
        parent_map[spec.id] = spec.id.rsplit("[", 1)[0] if params is not None else None

    # Wrap event bus to inject parameter metadata into events.
    enriched_bus = _ParameterEnrichingBus(event_bus, params_map, parent_map)

    event_bus.emit(
        Event(
            event_type=EventType.RUN_STARTED,
            test_id=run_id,
            data={"total_tests": len(specs), "max_concurrency": max_concurrency},
        )
    )

    semaphore = asyncio.Semaphore(max_concurrency)

    grader_context: dict[str, Any] = {}
    if judge_client is not None:
        grader_context["judge_client"] = judge_client

    # Fail-fast: shared counter + cancellation signal, guarded by lock.
    failure_count = 0
    failure_lock = asyncio.Lock()
    cancelled = asyncio.Event()

    def _make_error_result(spec: Any, error: str) -> tuple[TestResult, Transcript]:
        return (
            TestResult(
                test_id=spec.id,
                scenario=spec.scenario,
                test_type=spec.type.value,
                outcome=TestOutcome.ERROR,
                run_id=run_id,
                error=error,
                parameters=params_map.get(spec.id),
                parent_test_id=parent_map.get(spec.id),
            ),
            Transcript(test_id=spec.id),
        )

    async def _record_failure() -> None:
        nonlocal failure_count
        if max_failures is None:
            return
        async with failure_lock:
            failure_count += 1
            if failure_count >= max_failures:
                cancelled.set()

    async def _run_one(spec: Any) -> tuple[TestResult, Transcript]:
        if cancelled.is_set():
            return _make_error_result(spec, "Skipped: fail-fast threshold reached")

        async with semaphore:
            if cancelled.is_set():
                return _make_error_result(spec, "Skipped: fail-fast threshold reached")

            try:
                runner = create_runner(
                    spec,
                    event_bus=enriched_bus,
                    target_client=target_client,
                    customer_client=customer_client,
                    grader_context=grader_context,
                )
                result, transcript = await runner.run(spec)
                result.run_id = run_id
                result.parameters = params_map.get(spec.id)
                result.parent_test_id = parent_map.get(spec.id)

                if result.outcome in (TestOutcome.FAILED, TestOutcome.ERROR):
                    await _record_failure()

                return result, transcript

            except Exception as e:
                await _record_failure()
                return _make_error_result(spec, str(e))

    results = await asyncio.gather(*[_run_one(spec) for spec in specs])
    run_result.results = list(results)

    event_bus.emit(
        Event(
            event_type=EventType.RUN_COMPLETED,
            test_id=run_id,
            data={
                "total": run_result.total,
                "passed": run_result.passed,
                "failed": run_result.failed,
                "errors": run_result.errors,
            },
        )
    )

    # Build run metadata.
    config_data = None
    if config is not None:
        config_data = {
            "target": {
                "provider": config.clients.target.provider,
                "model": config.clients.target.model,
            },
        }
        if config.clients.customer:
            config_data["customer"] = {
                "provider": config.clients.customer.provider,
                "model": config.clients.customer.model,
            }

    total_input = sum(r.total_input_tokens for r, _ in run_result.results)
    total_output = sum(r.total_output_tokens for r, _ in run_result.results)

    run_result.metadata = {
        "run_id": run_id,
        "label": label,
        "timestamp": started_at.isoformat(),
        "config": config_data,
        "test_path": str(path),
        "max_concurrency": max_concurrency,
        "summary": {
            "total": run_result.total,
            "passed": run_result.passed,
            "failed": run_result.failed,
            "errors": run_result.errors,
        },
        "token_usage": {
            "total_input_tokens": total_input,
            "total_output_tokens": total_output,
            "total_tokens": total_input + total_output,
        },
    }

    # Persist results if output_dir is set.
    if output_dir:
        _persist_results(run_result, Path(output_dir))

    return run_result


def _persist_results(run_result: RunResult, output_dir: Path) -> None:
    """Write run results to disk keyed by run ID."""
    run_dir = output_dir / run_result.run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    # Write run-level metadata.
    if run_result.metadata:
        with open(run_dir / "run_metadata.json", "w") as f:
            json.dump(run_result.metadata, f, indent=2)

    for result, transcript in run_result.results:
        test_dir = run_dir / result.test_id
        test_dir.mkdir(exist_ok=True)

        # Serialize transcript turns.
        turns_data = []
        for turn in transcript.turns:
            turn_data: dict[str, Any] = {
                "turn_number": turn.turn_number,
                "user_message": turn.user_message,
                "assistant_response": turn.assistant_response,
                "tool_calls": [
                    {"tool_name": tc.tool_name, "arguments": tc.arguments} for tc in turn.tool_calls
                ],
                "grader_results": [
                    {
                        "grader_type": gr.grader_type,
                        "outcome": gr.outcome.value,
                        "message": gr.message,
                        "details": gr.details,
                    }
                    for gr in turn.grader_results
                ],
                "duration_ms": turn.duration_ms,
            }
            if turn.token_usage:
                turn_data["token_usage"] = {
                    "input_tokens": turn.token_usage.input_tokens,
                    "output_tokens": turn.token_usage.output_tokens,
                    "total_tokens": turn.token_usage.total_tokens,
                }
            turns_data.append(turn_data)

        data: dict[str, Any] = {
            "test_id": result.test_id,
            "scenario": result.scenario,
            "test_type": result.test_type,
            "outcome": result.outcome.value,
            "error": result.error,
            "duration_ms": result.duration_ms,
            "token_usage": {
                "input_tokens": result.total_input_tokens,
                "output_tokens": result.total_output_tokens,
                "total_tokens": result.total_input_tokens + result.total_output_tokens,
            },
            "transcript": turns_data,
        }

        if result.parameters is not None:
            data["parameters"] = result.parameters
        if result.parent_test_id is not None:
            data["parent_test_id"] = result.parent_test_id

        with open(test_dir / "result.json", "w") as f:
            json.dump(data, f, indent=2)
