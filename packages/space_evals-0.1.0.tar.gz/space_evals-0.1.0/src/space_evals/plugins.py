"""Plugin utilities.

The registries in clients.base and graders.base handle discovery lazily —
they check entry points on first lookup and cache the result. This module
provides helpers for eager loading and listing all installed plugins.
"""

from __future__ import annotations

from importlib.metadata import entry_points

CLIENT_GROUP = "space_evals.clients"
GRADER_GROUP = "space_evals.graders"
REPORTER_GROUP = "space_evals.reporters"


def load_all_plugins() -> None:
    """Eagerly load all installed client and grader plugins into their registries.

    Call this at startup if you want all plugins registered before any tests run.
    Not required — the registries discover lazily on first lookup.
    """
    from space_evals.clients.base import _CLIENT_REGISTRY
    from space_evals.graders.base import _GRADER_REGISTRY

    eps = entry_points()

    for ep in _select(eps, CLIENT_GROUP):
        if ep.name not in _CLIENT_REGISTRY:
            _CLIENT_REGISTRY[ep.name] = ep.load()

    for ep in _select(eps, GRADER_GROUP):
        if ep.name not in _GRADER_REGISTRY:
            _GRADER_REGISTRY[ep.name] = ep.load()


def list_installed_plugins() -> dict[str, list[str]]:
    """Return names of all installed plugins by category."""
    eps = entry_points()
    return {
        "clients": [ep.name for ep in _select(eps, CLIENT_GROUP)],
        "graders": [ep.name for ep in _select(eps, GRADER_GROUP)],
        "reporters": [ep.name for ep in _select(eps, REPORTER_GROUP)],
    }


def get_reporter_plugin(name: str):
    """Load a reporter plugin by name from entry points.

    Returns the reporter class, or None if not found.
    """
    eps = entry_points()
    for ep in _select(eps, REPORTER_GROUP):
        if ep.name == name:
            return ep.load()
    return None


def _select(eps, group: str):
    if hasattr(eps, "select"):
        return eps.select(group=group)
    return eps.get(group, [])
