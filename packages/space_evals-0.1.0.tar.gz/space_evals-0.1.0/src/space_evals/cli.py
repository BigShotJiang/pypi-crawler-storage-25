"""CLI entrypoint for space-evals."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Any

import click


@click.group()
def main():
    """space-evals: Build and validate agentic AI chat experiences."""
    pass


@main.command()
@click.argument("path", type=click.Path(exists=True))
@click.option(
    "--config", "-c", type=click.Path(exists=True), default=None, help="Path to config file."
)
@click.option(
    "--output", "-o", type=click.Path(), default=None, help="Directory to persist results."
)
@click.option(
    "--concurrency", type=int, default=None, help="Max parallel tests (overrides config)."
)
@click.option("--label", "-l", default=None, help="Human-readable label for this run.")
@click.option(
    "--fail-under",
    type=float,
    default=None,
    help="Minimum pass rate (0.0–1.0) to exit 0. E.g. --fail-under 0.9 requires 90%% pass rate.",
)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["text", "junit"]),
    default=None,
    help="Output format. 'junit' writes JUnit XML to stdout.",
)
@click.option(
    "--tags",
    default=None,
    help="Comma-separated list of tags to filter tests. Only tests with at least one matching tag will run.",
)
@click.option(
    "--max-failures",
    type=int,
    default=None,
    help="Stop after N failures (fail-fast). Remaining tests are skipped.",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    default=False,
    help="Verbose output: show turns, messages, and grader details.",
)
@click.option(
    "-q",
    "--quiet",
    is_flag=True,
    default=False,
    help="Quiet output: show only failures and the final summary.",
)
def run(
    path: str,
    config: str | None,
    output: str | None,
    concurrency: int | None,
    label: str | None,
    fail_under: float | None,
    fmt: str | None,
    tags: str | None,
    max_failures: int | None,
    verbose: bool,
    quiet: bool,
):
    """Run all tests found at PATH (file or directory)."""
    asyncio.run(
        _run(
            path,
            config,
            output,
            concurrency,
            label,
            fail_under,
            fmt,
            tags,
            max_failures,
            verbose,
            quiet,
        )
    )


async def _run(
    path: str,
    config_path: str | None,
    output: str | None,
    concurrency: int | None,
    label: str | None,
    fail_under: float | None,
    fmt: str | None,
    tags: str | None,
    max_failures: int | None = None,
    verbose: bool = False,
    quiet: bool = False,
):
    from space_evals.engine import run_tests
    from space_evals.events import EventBus
    from space_evals.log import setup_logging, LoggingReporter
    from space_evals.models.config import load_config
    from space_evals.reporters.console import ConsoleReporter, Verbosity

    try:
        cfg = load_config(config_path)
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    setup_logging(cfg.logging)

    effective_fail_under = fail_under if fail_under is not None else cfg.runner.fail_under
    effective_fmt = fmt if fmt is not None else cfg.output.format

    target_client = _build_client(cfg.clients.target, cfg)
    customer_client = _build_client(cfg.clients.customer, cfg) if cfg.clients.customer else None
    judge_client = _build_client(cfg.clients.judge, cfg) if cfg.clients.judge else None

    if quiet:
        verbosity = Verbosity.QUIET
    elif verbose:
        verbosity = Verbosity.VERBOSE
    else:
        verbosity = Verbosity.NORMAL

    event_bus = EventBus()
    event_bus.subscribe(ConsoleReporter(verbosity=verbosity))
    event_bus.subscribe(LoggingReporter())

    effective_max_failures = max_failures if max_failures is not None else cfg.runner.max_failures
    tag_list = _parse_tags(tags)

    result = await run_tests(
        path=path,
        target_client=target_client,
        customer_client=customer_client,
        judge_client=judge_client,
        event_bus=event_bus,
        output_dir=output or cfg.output.dir,
        max_concurrency=concurrency or cfg.runner.max_concurrency,
        label=label,
        config=cfg,
        tags=tag_list,
        max_failures=effective_max_failures,
    )

    # Emit JUnit XML if requested.
    if effective_fmt == "junit":
        from space_evals.junit import to_junit_xml

        click.echo(to_junit_xml(result))

    # Determine exit code.
    if effective_fail_under is not None:
        pass_rate = result.passed / result.total if result.total > 0 else 0.0
        if pass_rate < effective_fail_under:
            click.echo(
                f"FAIL: pass rate {pass_rate:.1%} is below threshold {effective_fail_under:.1%}",
                err=True,
            )
            sys.exit(1)
        sys.exit(0)

    exit_code = 0 if result.failed == 0 and result.errors == 0 else 1
    sys.exit(exit_code)


# ---- CI/CD commands ----


@main.command(name="init-ci")
@click.option(
    "--provider",
    type=click.Choice(["github-actions"]),
    default="github-actions",
    help="CI provider to generate a template for.",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default=None,
    help="Write template to a file instead of stdout.",
)
def init_ci(provider: str, output: str | None):
    """Generate a CI workflow template for running space-evals tests."""
    from importlib.resources import files

    template = files("space_evals.templates").joinpath("github_actions.yml").read_text()

    if output:
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(template)
        click.echo(f"CI template written to: {out_path}")
    else:
        click.echo(template)


# ---- Coverage commands ----


@main.command()
@click.argument("graph", type=click.Path(exists=True))
@click.option(
    "--results",
    "-r",
    type=click.Path(exists=True),
    default=None,
    help="Results directory to analyze.",
)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["text", "json", "mermaid"]),
    default="text",
    help="Output format.",
)
@click.option(
    "--fail-under", type=float, default=None, help="Minimum edge coverage (0.0–1.0) to exit 0."
)
def coverage(graph: str, results: str | None, fmt: str, fail_under: float | None):
    """Analyze test coverage against a coverage graph.

    GRAPH is the path to a coverage.yaml file defining intents and transitions.
    """
    from space_evals.coverage.graph import load_coverage_graph
    from space_evals.coverage.analyzer import analyze_coverage as _analyze

    try:
        cg = load_coverage_graph(graph)
    except Exception as e:
        click.echo(f"Error loading coverage graph: {e}", err=True)
        sys.exit(1)

    if results is None:
        # No results — just show graph stats.
        click.echo(f"Coverage graph: {graph}")
        click.echo(f"  Intents: {len(cg.intents)}")
        click.echo(f"  Edges: {len(cg.edges)}")
        click.echo(f"  Boundaries: {len(cg.boundaries)}")
        click.echo(f"  Cyclomatic complexity: {cg.cyclomatic_complexity}")
        click.echo(f"  Minimum paths for edge coverage: {cg.min_edge_covering_paths}")
        return

    report = _analyze(cg, results)

    if fmt == "json":
        click.echo(json.dumps(report.to_dict(), indent=2))
    elif fmt == "mermaid":
        click.echo(_format_mermaid(cg, report))
    else:
        click.echo(report.format_text())

    if fail_under is not None and report.edge_coverage < fail_under:
        click.echo(
            f"\nFAIL: edge coverage {report.edge_coverage:.1%} is below threshold {fail_under:.1%}",
            err=True,
        )
        sys.exit(1)


@main.command()
@click.argument("graph", type=click.Path(exists=True))
@click.option(
    "--output", "-o", type=click.Path(), required=True, help="Directory for generated test files."
)
@click.option(
    "--results",
    "-r",
    type=click.Path(exists=True),
    default=None,
    help="Results directory (generates only uncovered paths).",
)
@click.option(
    "--format", "fmt", type=click.Choice(["text", "json"]), default="text", help="Output format."
)
def generate(graph: str, output: str, results: str | None, fmt: str):
    """Generate test specs from a coverage graph.

    GRAPH is the path to a coverage.yaml file. Generated test files are
    written to --output as individual YAML files.
    """
    from space_evals.coverage.graph import load_coverage_graph
    from space_evals.coverage.test_generator import generate_test_specs, write_test_specs

    try:
        cg = load_coverage_graph(graph)
    except Exception as e:
        click.echo(f"Error loading coverage graph: {e}", err=True)
        sys.exit(1)

    uncovered = None
    if results:
        from space_evals.coverage.analyzer import analyze_coverage as _analyze

        report = _analyze(cg, results)
        uncovered = report.uncovered_edges
        click.echo(f"Generating tests for {len(uncovered)} uncovered edge(s)...")
    else:
        click.echo(f"Generating tests for full graph ({len(cg.edges)} edges)...")

    specs = generate_test_specs(cg, uncovered_edges=uncovered)
    written = write_test_specs(specs, output)

    if fmt == "json":
        click.echo(json.dumps([str(p) for p in written], indent=2))
    else:
        click.echo(f"\nGenerated {len(written)} test file(s) in {output}/:")
        for p in written:
            click.echo(f"  {p.name}")


def _format_mermaid(graph, report) -> str:
    """Format coverage as a Mermaid graph diagram."""
    lines = ["graph LR"]
    for src, dst in sorted(graph.edges):
        edge = (src, dst)
        if edge in report.covered_edges:
            label = "✅"
            lines.append(f"    {src} -->|{label}| {dst}")
        else:
            label = "❌"
            lines.append(f"    {src} -.->|{label}| {dst}")
    return "\n".join(lines)


# ---- Comparison commands ----


@main.command()
@click.argument("run_a")
@click.argument("run_b")
@click.option(
    "--output-dir", "-o", type=click.Path(exists=True), default=None, help="Results directory."
)
@click.option(
    "--config", "-c", type=click.Path(exists=True), default=None, help="Path to config file."
)
@click.option(
    "--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format."
)
@click.option(
    "--only",
    type=click.Choice(["regressions", "improvements", "added", "removed"]),
    default=None,
    help="Show only a specific change type.",
)
def compare(
    run_a: str, run_b: str, output_dir: str | None, config: str | None, fmt: str, only: str | None
):
    """Compare two test runs to find regressions and improvements.

    RUN_A and RUN_B are run IDs (or prefixes) or labels.
    """
    from space_evals.comparison import compare_runs, find_run

    results_dir = _resolve_output_dir(output_dir, config)

    if not results_dir.is_dir():
        click.echo(f"Error: Results directory not found: {results_dir}", err=True)
        sys.exit(1)

    try:
        dir_a = find_run(results_dir, run_a)
        dir_b = find_run(results_dir, run_b)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    comparison = compare_runs(dir_a, dir_b)

    if fmt == "json":
        click.echo(json.dumps(comparison.to_dict(), indent=2))
        return

    # Table output.
    label_a = comparison.run_a.label or comparison.run_a.run_id
    label_b = comparison.run_b.label or comparison.run_b.run_id
    click.echo(f"\nComparing: {label_a} vs {label_b}\n")

    tests = comparison.tests
    if only:
        if only == "regressions":
            tests = comparison.regressions
        elif only == "improvements":
            tests = comparison.improvements
        elif only == "added":
            tests = comparison.added
        elif only == "removed":
            tests = comparison.removed

    if not tests:
        click.echo("  No differences found.\n")
        return

    _print_comparison_table(tests)

    click.echo(
        f"\nSummary: {len(comparison.regressions)} regression(s), "
        f"{len(comparison.improvements)} improvement(s), "
        f"{len(comparison.unchanged)} unchanged, "
        f"{len(comparison.changed)} changed, "
        f"{len(comparison.added)} added, "
        f"{len(comparison.removed)} removed\n"
    )


@main.command()
@click.option(
    "--output-dir", "-o", type=click.Path(exists=True), default=None, help="Results directory."
)
@click.option(
    "--config", "-c", type=click.Path(exists=True), default=None, help="Path to config file."
)
@click.option("--test-id", default=None, help="Track a specific test across runs.")
@click.option("--limit", type=int, default=20, help="Number of recent runs to show.")
@click.option(
    "--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format."
)
def history(output_dir: str | None, config: str | None, test_id: str | None, limit: int, fmt: str):
    """Show pass rate history across recent runs."""
    from space_evals.comparison import build_history

    results_dir = _resolve_output_dir(output_dir, config)

    if not results_dir.is_dir():
        click.echo(f"Error: Results directory not found: {results_dir}", err=True)
        sys.exit(1)

    data = build_history(results_dir, test_id=test_id, limit=limit)

    if fmt == "json":
        click.echo(json.dumps(data, indent=2))
        return

    if not data:
        click.echo("No runs found.")
        return

    click.echo(f"\nRun History (last {len(data)} runs):\n")
    click.echo(
        f"  {'Run ID':<14} {'Label':<24} {'Timestamp':<22} {'Pass Rate':>10} {'P':>4} {'F':>4} {'E':>4}"
    )
    click.echo(f"  {'-'*14} {'-'*24} {'-'*22} {'-'*10} {'-'*4} {'-'*4} {'-'*4}")

    for entry in data:
        run_id = entry["run_id"][:12]
        label = (entry["label"] or "")[:22]
        ts = (entry["timestamp"] or "")[:19]
        rate = f"{entry['pass_rate']:.0%}"
        line = f"  {run_id:<14} {label:<24} {ts:<22} {rate:>10} {entry['passed']:>4} {entry['failed']:>4} {entry['errors']:>4}"

        if test_id and entry.get("test_outcome"):
            line += f"  [{entry['test_outcome']}]"

        click.echo(line)

    click.echo()


@main.command(name="label")
@click.argument("run_id")
@click.argument("label_text")
@click.option(
    "--output-dir", "-o", type=click.Path(exists=True), default=None, help="Results directory."
)
@click.option(
    "--config", "-c", type=click.Path(exists=True), default=None, help="Path to config file."
)
def label_run(run_id: str, label_text: str, output_dir: str | None, config: str | None):
    """Set or update a label for a run.

    RUN_ID is the run ID or prefix.
    """
    from space_evals.comparison import find_run

    results_dir = _resolve_output_dir(output_dir, config)

    try:
        run_dir = find_run(results_dir, run_id)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    meta_path = run_dir / "run_metadata.json"
    try:
        with open(meta_path) as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {"run_id": run_dir.name}

    data["label"] = label_text
    with open(meta_path, "w") as f:
        json.dump(data, f, indent=2)

    click.echo(f"Labeled run {run_dir.name} as: {label_text}")


# ---- Helpers ----


def _parse_tags(tags: str | None) -> list[str] | None:
    """Parse a comma-separated tag string into a list, or None."""
    if not tags:
        return None
    return [t.strip() for t in tags.split(",") if t.strip()] or None


def _resolve_output_dir(output_dir: str | None, config_path: str | None) -> Path:
    """Resolve the results directory from explicit flag or config."""
    if output_dir:
        return Path(output_dir)
    try:
        from space_evals.models.config import load_config

        cfg = load_config(config_path)
        return Path(cfg.output.dir)
    except FileNotFoundError:
        return Path("./results")


def _print_comparison_table(tests: list) -> None:
    """Print a comparison table to stdout."""
    click.echo(f"  {'Status':<12} {'Test ID':<30} {'Run A':<10} {'Run B':<10} {'Duration'}")
    click.echo(f"  {'-'*12} {'-'*30} {'-'*10} {'-'*10} {'-'*12}")

    for t in tests:
        status = t.change.value.upper()
        oa = t.outcome_a or "-"
        ob = t.outcome_b or "-"

        dur = ""
        if t.duration_a is not None and t.duration_b is not None:
            delta = t.duration_b - t.duration_a
            sign = "+" if delta >= 0 else ""
            dur = f"{sign}{delta:.0f}ms"
        elif t.duration_b is not None:
            dur = f"{t.duration_b:.0f}ms"

        click.echo(f"  {status:<12} {t.test_id:<30} {oa:<10} {ob:<10} {dur}")


def _build_client(client_config: Any, global_config: Any = None) -> Any:
    from space_evals.clients.base import get_client
    from space_evals.clients.resilient import ResilientClient, RetryHandler, TokenBucketRateLimiter
    from space_evals.models.config import RetryConfig

    inner = get_client(
        provider=client_config.provider,
        model=client_config.model,
        api_key_env=client_config.api_key_env,
        **client_config.params,
    )

    retry_cfg = client_config.retry
    if retry_cfg is None and global_config is not None:
        retry_cfg = global_config.retry
    if retry_cfg is None:
        retry_cfg = RetryConfig()
    retry_handler = RetryHandler(retry_cfg) if retry_cfg.max_retries > 0 else None

    rl_cfg = client_config.rate_limit
    if rl_cfg is None and global_config is not None:
        rl_cfg = global_config.rate_limit
    rate_limiter = None
    if rl_cfg is not None:
        provider_key = client_config.provider
        if provider_key not in _rate_limiters:
            _rate_limiters[provider_key] = TokenBucketRateLimiter(rl_cfg.requests_per_minute)
        rate_limiter = _rate_limiters[provider_key]

    return ResilientClient(
        inner=inner,
        retry_handler=retry_handler,
        rate_limiter=rate_limiter,
        provider=client_config.provider,
    )


# Multiple client roles sharing a provider share one rate-limit bucket.
_rate_limiters: dict = {}


if __name__ == "__main__":
    main()
