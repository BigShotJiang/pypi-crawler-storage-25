"""Tests for Hugging Face dataset loading in params.py."""

import sys
import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path

from space_evals.params import _load_hf_dataset, _parse_slice, load_parameters_from_file


class TestParseSlice:
    def test_single_number(self):
        s = _parse_slice("100")
        assert s == slice(None, 100)

    def test_start_stop(self):
        s = _parse_slice("10:50")
        assert s == slice(10, 50)

    def test_start_only(self):
        s = _parse_slice("10:")
        assert s == slice(10, None)

    def test_stop_only(self):
        s = _parse_slice(":50")
        assert s == slice(None, 50)

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="Invalid slice"):
            _parse_slice("1:2:3")


def _make_mock_datasets_module(rows):
    """Create a mock 'datasets' module with a load_dataset function."""
    mock_ds = MagicMock()
    mock_ds.__iter__ = MagicMock(return_value=iter(rows))
    mock_ds.__len__ = MagicMock(return_value=len(rows))
    mock_ds.select = MagicMock(return_value=mock_ds)

    mock_module = MagicMock()
    mock_module.load_dataset = MagicMock(return_value=mock_ds)
    return mock_module, mock_ds


class TestHfUriParsing:
    """Test URI parsing without actually loading datasets."""

    def test_simple_dataset_split(self):
        """hf://dataset/split — 2-part path."""
        mock_mod, mock_ds = _make_mock_datasets_module(
            [
                {"question": "What is 2+2?", "answer": "4"},
            ]
        )

        with patch.dict(sys.modules, {"datasets": mock_mod}):
            result = _load_hf_dataset("hf://gsm8k/test")
            mock_mod.load_dataset.assert_called_once_with(path="gsm8k", split="test")
        assert len(result) == 1
        assert result[0]["question"] == "What is 2+2?"

    def test_org_dataset_split(self):
        """hf://org/dataset/split — 3-part path."""
        mock_mod, mock_ds = _make_mock_datasets_module([{"q": "test"}])

        with patch.dict(sys.modules, {"datasets": mock_mod}):
            _load_hf_dataset("hf://cais/mmlu/test")
            mock_mod.load_dataset.assert_called_once_with(path="cais/mmlu", split="test")

    def test_org_dataset_config_split(self):
        """hf://org/dataset/config/split — 4-part path."""
        mock_mod, mock_ds = _make_mock_datasets_module([{"q": "test"}])

        with patch.dict(sys.modules, {"datasets": mock_mod}):
            _load_hf_dataset("hf://cais/mmlu/all/test")
            mock_mod.load_dataset.assert_called_once_with(
                path="cais/mmlu", split="test", name="all"
            )

    def test_slice_applied(self):
        """hf://dataset/split[:N] should call select."""
        mock_mod, mock_ds = _make_mock_datasets_module([{"q": f"q{i}"} for i in range(5)])

        with patch.dict(sys.modules, {"datasets": mock_mod}):
            _load_hf_dataset("hf://gsm8k/test[:5]")
            mock_mod.load_dataset.assert_called_once_with(path="gsm8k", split="test")
            mock_ds.select.assert_called_once()

    def test_invalid_uri_too_few_parts(self):
        mock_mod, _ = _make_mock_datasets_module([])
        with patch.dict(sys.modules, {"datasets": mock_mod}):
            with pytest.raises(ValueError, match="Invalid hf:// URI"):
                _load_hf_dataset("hf://onlyname")

    def test_invalid_uri_too_many_parts(self):
        mock_mod, _ = _make_mock_datasets_module([])
        with patch.dict(sys.modules, {"datasets": mock_mod}):
            with pytest.raises(ValueError, match="Too many path segments"):
                _load_hf_dataset("hf://a/b/c/d/e")

    def test_missing_datasets_library(self):
        """Should raise ImportError with install instructions."""
        with patch.dict(sys.modules, {"datasets": None}):
            with pytest.raises(ImportError, match="space-evals"):
                _load_hf_dataset("hf://test/train")


class TestLoadParametersFromFileHf:
    """Test that load_parameters_from_file routes hf:// URIs correctly."""

    def test_hf_uri_dispatched(self):
        mock_mod, _ = _make_mock_datasets_module(
            [
                {"col1": "val1", "col2": "val2"},
            ]
        )

        with patch.dict(sys.modules, {"datasets": mock_mod}):
            result = load_parameters_from_file("hf://test_ds/train", base_dir=Path("/tmp"))
        assert len(result) == 1
        assert result[0]["col1"] == "val1"

    def test_regular_file_still_works(self, tmp_path):
        csv_file = tmp_path / "params.csv"
        csv_file.write_text("name,age\nAlice,30\nBob,25\n")
        result = load_parameters_from_file("params.csv", base_dir=tmp_path)
        assert len(result) == 2
        assert result[0]["name"] == "Alice"


class TestNormalizeValues:
    """Test that dataset values are normalized for template substitution."""

    def test_list_values_stringified(self):
        mock_mod, _ = _make_mock_datasets_module(
            [
                {"choices": ["A", "B", "C", "D"], "answer": 2},
            ]
        )

        with patch.dict(sys.modules, {"datasets": mock_mod}):
            result = _load_hf_dataset("hf://test/train")
        assert isinstance(result[0]["choices"], str)
        assert result[0]["answer"] == 2  # int preserved
