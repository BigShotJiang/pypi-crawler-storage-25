"""Tests for run comparison and history tracking."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from space_evals.comparison import (
    RunMetadata,
    build_history,
    compare_runs,
    find_run,
    list_runs,
    load_run,
    load_run_metadata,
)


def _write_result(run_dir: Path, test_id: str, outcome: str, **extra) -> None:
    """Write a minimal result.json for testing."""
    test_dir = run_dir / test_id
    test_dir.mkdir(parents=True, exist_ok=True)
    data = {
        "test_id": test_id,
        "scenario": f"Test {test_id}",
        "test_type": "scripted",
        "outcome": outcome,
        **extra,
    }
    with open(test_dir / "result.json", "w") as f:
        json.dump(data, f)


def _write_metadata(run_dir: Path, **overrides) -> None:
    """Write a run_metadata.json."""
    data = {
        "run_id": run_dir.name,
        "label": None,
        "timestamp": "2026-04-10T10:00:00Z",
        "config": {"target": {"provider": "openai", "model": "gpt-4o"}},
        "summary": {"total": 0, "passed": 0, "failed": 0, "errors": 0},
        **overrides,
    }
    with open(run_dir / "run_metadata.json", "w") as f:
        json.dump(data, f)


class TestLoadRunMetadata:
    def test_loads_from_file(self, tmp_path):
        run_dir = tmp_path / "run1"
        run_dir.mkdir()
        _write_metadata(
            run_dir, label="first run", summary={"total": 3, "passed": 2, "failed": 1, "errors": 0}
        )
        meta = load_run_metadata(run_dir)
        assert meta.run_id == "run1"
        assert meta.label == "first run"
        assert meta.summary["passed"] == 2

    def test_synthesizes_from_results(self, tmp_path):
        run_dir = tmp_path / "run2"
        run_dir.mkdir()
        _write_result(run_dir, "t1", "passed")
        _write_result(run_dir, "t2", "failed")
        meta = load_run_metadata(run_dir)
        assert meta.run_id == "run2"
        assert meta.label is None
        assert meta.summary["total"] == 2
        assert meta.summary["passed"] == 1
        assert meta.summary["failed"] == 1

    def test_pass_rate(self):
        meta = RunMetadata(run_id="x", summary={"total": 4, "passed": 3, "failed": 1, "errors": 0})
        assert meta.pass_rate == 0.75

    def test_pass_rate_zero_total(self):
        meta = RunMetadata(run_id="x", summary={"total": 0})
        assert meta.pass_rate == 0.0


class TestLoadRun:
    def test_load_run(self, tmp_path):
        run_dir = tmp_path / "run1"
        run_dir.mkdir()
        _write_metadata(run_dir)
        _write_result(run_dir, "t1", "passed")
        _write_result(run_dir, "t2", "failed")
        meta, results = load_run(run_dir)
        assert meta.run_id == "run1"
        assert len(results) == 2
        assert results["t1"]["outcome"] == "passed"


class TestListRuns:
    def test_lists_runs_sorted_by_timestamp(self, tmp_path):
        for name, ts in [
            ("r1", "2026-01-01T00:00:00Z"),
            ("r2", "2026-06-01T00:00:00Z"),
            ("r3", "2026-03-01T00:00:00Z"),
        ]:
            d = tmp_path / name
            d.mkdir()
            _write_metadata(d, timestamp=ts)
            _write_result(d, "t1", "passed")

        runs = list_runs(tmp_path)
        assert [r.run_id for r in runs] == ["r2", "r3", "r1"]

    def test_empty_dir(self, tmp_path):
        assert list_runs(tmp_path) == []

    def test_skips_non_run_dirs(self, tmp_path):
        (tmp_path / "random_file.txt").write_text("hi")
        (tmp_path / "empty_dir").mkdir()
        assert list_runs(tmp_path) == []


class TestFindRun:
    def test_find_by_id_prefix(self, tmp_path):
        run_dir = tmp_path / "abc123def456"
        run_dir.mkdir()
        _write_result(run_dir, "t1", "passed")
        found = find_run(tmp_path, "abc123")
        assert found == run_dir

    def test_find_by_label(self, tmp_path):
        run_dir = tmp_path / "xyz789"
        run_dir.mkdir()
        _write_metadata(run_dir, label="my-run")
        found = find_run(tmp_path, "my-run")
        assert found == run_dir

    def test_not_found_raises(self, tmp_path):
        with pytest.raises(ValueError, match="No run found"):
            find_run(tmp_path, "nonexistent")

    def test_ambiguous_raises(self, tmp_path):
        (tmp_path / "abc1").mkdir()
        _write_result(tmp_path / "abc1", "t1", "passed")
        (tmp_path / "abc2").mkdir()
        _write_result(tmp_path / "abc2", "t1", "passed")
        with pytest.raises(ValueError, match="Ambiguous"):
            find_run(tmp_path, "abc")


class TestCompareRuns:
    def test_regression(self, tmp_path):
        a = tmp_path / "run_a"
        b = tmp_path / "run_b"
        a.mkdir()
        b.mkdir()
        _write_metadata(a)
        _write_metadata(b)
        _write_result(a, "t1", "passed")
        _write_result(b, "t1", "failed")
        comp = compare_runs(a, b)
        assert len(comp.regressions) == 1
        assert comp.regressions[0].test_id == "t1"

    def test_improvement(self, tmp_path):
        a = tmp_path / "run_a"
        b = tmp_path / "run_b"
        a.mkdir()
        b.mkdir()
        _write_metadata(a)
        _write_metadata(b)
        _write_result(a, "t1", "failed")
        _write_result(b, "t1", "passed")
        comp = compare_runs(a, b)
        assert len(comp.improvements) == 1

    def test_unchanged(self, tmp_path):
        a = tmp_path / "run_a"
        b = tmp_path / "run_b"
        a.mkdir()
        b.mkdir()
        _write_metadata(a)
        _write_metadata(b)
        _write_result(a, "t1", "passed")
        _write_result(b, "t1", "passed")
        comp = compare_runs(a, b)
        assert len(comp.unchanged) == 1

    def test_added_and_removed(self, tmp_path):
        a = tmp_path / "run_a"
        b = tmp_path / "run_b"
        a.mkdir()
        b.mkdir()
        _write_metadata(a)
        _write_metadata(b)
        _write_result(a, "t1", "passed")  # only in A
        _write_result(b, "t2", "passed")  # only in B
        comp = compare_runs(a, b)
        assert len(comp.removed) == 1
        assert comp.removed[0].test_id == "t1"
        assert len(comp.added) == 1
        assert comp.added[0].test_id == "t2"

    def test_mixed_changes(self, tmp_path):
        a = tmp_path / "run_a"
        b = tmp_path / "run_b"
        a.mkdir()
        b.mkdir()
        _write_metadata(a)
        _write_metadata(b)
        _write_result(a, "t1", "passed")
        _write_result(a, "t2", "failed")
        _write_result(a, "t3", "passed")
        _write_result(b, "t1", "failed")  # regression
        _write_result(b, "t2", "passed")  # improvement
        _write_result(b, "t3", "passed")  # unchanged
        _write_result(b, "t4", "passed")  # added
        comp = compare_runs(a, b)
        assert len(comp.regressions) == 1
        assert len(comp.improvements) == 1
        assert len(comp.unchanged) == 1
        assert len(comp.added) == 1

    def test_to_dict(self, tmp_path):
        a = tmp_path / "run_a"
        b = tmp_path / "run_b"
        a.mkdir()
        b.mkdir()
        _write_metadata(a)
        _write_metadata(b)
        _write_result(a, "t1", "passed")
        _write_result(b, "t1", "failed")
        comp = compare_runs(a, b)
        d = comp.to_dict()
        assert d["summary"]["regressions"] == 1
        assert len(d["tests"]) == 1

    def test_duration_tracking(self, tmp_path):
        a = tmp_path / "run_a"
        b = tmp_path / "run_b"
        a.mkdir()
        b.mkdir()
        _write_metadata(a)
        _write_metadata(b)
        _write_result(a, "t1", "passed", duration_ms=100.0)
        _write_result(b, "t1", "passed", duration_ms=250.0)
        comp = compare_runs(a, b)
        assert comp.tests[0].duration_a == 100.0
        assert comp.tests[0].duration_b == 250.0


class TestBuildHistory:
    def test_basic_history(self, tmp_path):
        for name, ts, passed in [
            ("r1", "2026-01-01T00:00:00Z", 2),
            ("r2", "2026-02-01T00:00:00Z", 3),
        ]:
            d = tmp_path / name
            d.mkdir()
            _write_metadata(
                d,
                timestamp=ts,
                summary={"total": 5, "passed": passed, "failed": 5 - passed, "errors": 0},
            )
        history = build_history(tmp_path)
        assert len(history) == 2
        # Should be chronological (oldest first)
        assert history[0]["run_id"] == "r1"
        assert history[1]["run_id"] == "r2"
        assert history[0]["pass_rate"] == pytest.approx(0.4)
        assert history[1]["pass_rate"] == pytest.approx(0.6)

    def test_history_with_limit(self, tmp_path):
        for i in range(5):
            d = tmp_path / f"r{i}"
            d.mkdir()
            _write_metadata(
                d,
                timestamp=f"2026-0{i+1}-01T00:00:00Z",
                summary={"total": 1, "passed": 1, "failed": 0, "errors": 0},
            )
        history = build_history(tmp_path, limit=3)
        assert len(history) == 3

    def test_history_with_test_id(self, tmp_path):
        for i, (name, outcome) in enumerate([("r1", "passed"), ("r2", "failed")]):
            d = tmp_path / name
            d.mkdir()
            _write_metadata(
                d,
                timestamp=f"2026-0{i+1}-01T00:00:00Z",
                summary={
                    "total": 1,
                    "passed": 1 if outcome == "passed" else 0,
                    "failed": 0 if outcome == "passed" else 1,
                    "errors": 0,
                },
            )
            _write_result(d, "t1", outcome)
        history = build_history(tmp_path, test_id="t1")
        assert history[0]["test_outcome"] == "passed"
        assert history[1]["test_outcome"] == "failed"
