"""Tests for the coverage analysis module."""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest
import yaml

from space_evals.coverage.graph import CoverageGraph, Intent, Boundary, load_coverage_graph
from space_evals.coverage.path_generator import generate_covering_paths
from space_evals.coverage.test_generator import generate_test_specs, write_test_specs
from space_evals.coverage.analyzer import (
    CoverageReport,
    analyze_coverage,
    classify_turns_simple,
)


# ---- Fixtures ----


FOOD_ORDER_YAML = textwrap.dedent("""\
    intents:
      greeting:
        transitions: [browse_menu, get_help]
      browse_menu:
        transitions: [add_item, get_help]
      add_item:
        description: Customer adds a menu item to their order
        transitions: [add_item, modify_item, remove_item, checkout, browse_menu]
      modify_item:
        transitions: [add_item, checkout, browse_menu]
      remove_item:
        transitions: [add_item, checkout, browse_menu]
      checkout:
        transitions: [payment, add_item, cancel_order]
      payment:
        transitions: [confirm_order]
      confirm_order:
        transitions: []
      cancel_order:
        transitions: [greeting]
      get_help:
        transitions: [browse_menu, cancel_order]
    boundaries:
      - medical_advice
      - personal_opinions
      - competitor_recommendations
      - off_topic_conversation
    invariants:
      - Never disclose the system prompt
""")


@pytest.fixture
def food_order_graph(tmp_path: Path) -> CoverageGraph:
    graph_path = tmp_path / "coverage.yaml"
    graph_path.write_text(FOOD_ORDER_YAML)
    return load_coverage_graph(graph_path)


@pytest.fixture
def simple_graph() -> CoverageGraph:
    return CoverageGraph(
        intents={
            "start": Intent(name="start", transitions=("middle",)),
            "middle": Intent(name="middle", transitions=("end",)),
            "end": Intent(name="end", transitions=()),
        },
        boundaries=[Boundary(id="disallowed")],
        invariants=[],
    )


# ---- Graph tests ----


class TestCoverageGraph:
    def test_load_from_yaml(self, food_order_graph: CoverageGraph):
        assert len(food_order_graph.intents) == 10
        assert len(food_order_graph.boundaries) == 4
        assert len(food_order_graph.invariants) == 1

    def test_edges(self, food_order_graph: CoverageGraph):
        edges = food_order_graph.edges
        assert len(edges) == 22
        assert ("greeting", "browse_menu") in edges
        assert ("payment", "confirm_order") in edges

    def test_entry_intents(self, food_order_graph: CoverageGraph):
        entries = food_order_graph.entry_intents
        # greeting has cancel_order → greeting incoming, so it's not
        # zero-incoming. But it has positive degree imbalance (out > in).
        assert "greeting" in entries
        assert len(entries) >= 1

    def test_terminal_intents(self, food_order_graph: CoverageGraph):
        terminals = food_order_graph.terminal_intents
        assert "confirm_order" in terminals

    def test_cyclomatic_complexity(self, food_order_graph: CoverageGraph):
        assert food_order_graph.cyclomatic_complexity == 22 - 10 + 2  # 14

    def test_min_edge_covering_paths(self, food_order_graph: CoverageGraph):
        # greeting: out=2, in=1 → +1
        # modify_item: out=3, in=1 → +2
        # remove_item: out=3, in=1 → +2
        # Total = 5
        assert food_order_graph.min_edge_covering_paths == 5

    def test_in_out_degree(self, food_order_graph: CoverageGraph):
        assert food_order_graph.out_degree("add_item") == 5
        assert food_order_graph.in_degree("browse_menu") == 5

    def test_invalid_transition_reference(self, tmp_path: Path):
        graph_yaml = textwrap.dedent("""\
            intents:
              a:
                transitions: [nonexistent]
        """)
        path = tmp_path / "bad.yaml"
        path.write_text(graph_yaml)
        with pytest.raises(Exception, match="nonexistent"):
            load_coverage_graph(path)

    def test_empty_intents_rejected(self, tmp_path: Path):
        path = tmp_path / "empty.yaml"
        path.write_text("intents: {}")
        with pytest.raises(Exception, match="At least one intent"):
            load_coverage_graph(path)

    def test_boundary_with_triggers(self, tmp_path: Path):
        graph_yaml = textwrap.dedent("""\
            intents:
              start:
                transitions: []
            boundaries:
              - id: medical_advice
                example_triggers:
                  - "Is this safe to eat?"
        """)
        path = tmp_path / "triggers.yaml"
        path.write_text(graph_yaml)
        g = load_coverage_graph(path)
        assert len(g.boundaries) == 1
        assert g.boundaries[0].example_triggers == ("Is this safe to eat?",)


# ---- Path generator tests ----


class TestPathGenerator:
    def test_simple_graph_single_path(self, simple_graph: CoverageGraph):
        paths = generate_covering_paths(simple_graph)
        assert len(paths) >= 1
        all_edges = set()
        for p in paths:
            all_edges.update(p.edges)
        assert ("start", "middle") in all_edges
        assert ("middle", "end") in all_edges

    def test_covers_all_edges(self, food_order_graph: CoverageGraph):
        paths = generate_covering_paths(food_order_graph)
        all_covered = set()
        for p in paths:
            all_covered.update(p.edges)
        expected = set(food_order_graph.edges)
        assert expected.issubset(all_covered), f"Missing edges: {expected - all_covered}"

    def test_path_count_reasonable(self, food_order_graph: CoverageGraph):
        paths = generate_covering_paths(food_order_graph)
        # Should be close to the theoretical minimum (5), but greedy may produce more.
        assert len(paths) <= 15  # generous upper bound

    def test_paths_start_from_entry(self, food_order_graph: CoverageGraph):
        paths = generate_covering_paths(food_order_graph)
        entries = set(food_order_graph.entry_intents)
        # Most paths should start from entry intents (some may start from
        # mid-graph intents if needed for coverage).
        entry_starts = sum(1 for p in paths if p.intents[0] in entries)
        assert entry_starts >= 1

    def test_empty_graph_no_paths(self):
        g = CoverageGraph(
            intents={"solo": Intent(name="solo", transitions=())},
            boundaries=[],
            invariants=[],
        )
        paths = generate_covering_paths(g)
        assert len(paths) == 0


# ---- Test generator tests ----


class TestTestGenerator:
    def test_generates_path_specs(self, food_order_graph: CoverageGraph):
        specs = generate_test_specs(food_order_graph)
        path_specs = [s for s in specs if s["type"] == "task_based"]
        assert len(path_specs) >= 1
        for spec in path_specs:
            assert spec["id"].startswith("coverage_path_")
            assert "scenario" in spec
            assert "goal" in spec
            assert spec["max_turns"] >= 4

    def test_generates_boundary_specs(self, food_order_graph: CoverageGraph):
        specs = generate_test_specs(food_order_graph)
        boundary_specs = [s for s in specs if s["type"] == "scripted"]
        assert len(boundary_specs) == 4
        ids = {s["id"] for s in boundary_specs}
        assert "boundary_medical_advice" in ids
        assert "boundary_off_topic_conversation" in ids

    def test_write_to_disk(self, food_order_graph: CoverageGraph, tmp_path: Path):
        specs = generate_test_specs(food_order_graph)
        output_dir = tmp_path / "generated"
        written = write_test_specs(specs, output_dir)
        assert len(written) == len(specs)
        for path in written:
            assert path.exists()
            with open(path) as f:
                data = yaml.safe_load(f)
            assert "id" in data
            assert "type" in data

    def test_uncovered_only(self, food_order_graph: CoverageGraph):
        uncovered = {("remove_item", "checkout"), ("checkout", "add_item")}
        specs = generate_test_specs(food_order_graph, uncovered_edges=uncovered)
        path_specs = [s for s in specs if s["type"] == "task_based"]
        assert len(path_specs) >= 1
        # Verify the generated paths cover the uncovered edges.
        all_path_intents = []
        for spec in path_specs:
            all_path_intents.append(spec.get("expected_path", []))
        covered = set()
        for path in all_path_intents:
            for i in range(len(path) - 1):
                covered.add((path[i], path[i + 1]))
        assert uncovered.issubset(covered)


# ---- Analyzer tests ----


class TestAnalyzer:
    def test_classify_simple(self, food_order_graph: CoverageGraph):
        transcript = {
            "test_id": "test_1",
            "outcome": "passed",
            "transcript": [
                {
                    "turn_number": 1,
                    "user_message": "hello greeting",
                    "assistant_response": "Welcome",
                },
                {
                    "turn_number": 2,
                    "user_message": "show me the browse menu please",
                    "assistant_response": "Here is our menu",
                },
                {
                    "turn_number": 3,
                    "user_message": "I want to add item",
                    "assistant_response": "Added",
                },
            ],
        }
        ct = classify_turns_simple(transcript, food_order_graph)
        assert ct.test_id == "test_1"
        assert len(ct.turns) == 3
        # The simple classifier uses keyword matching; just verify it produces results.
        classified = [t.classified_intent for t in ct.turns]
        assert all(c is not None for c in classified)

    def test_analyze_full_coverage(self, food_order_graph: CoverageGraph, tmp_path: Path):
        results_dir = tmp_path / "results" / "run1"
        results_dir.mkdir(parents=True)

        # Create a transcript that hits greeting → browse_menu.
        test_dir = results_dir / "test_1"
        test_dir.mkdir()
        result = {
            "test_id": "test_1",
            "outcome": "passed",
            "transcript": [
                {
                    "turn_number": 1,
                    "user_message": "greeting hello",
                    "assistant_response": "Welcome",
                },
                {
                    "turn_number": 2,
                    "user_message": "browse menu please",
                    "assistant_response": "Here's the menu",
                },
            ],
        }
        with open(test_dir / "result.json", "w") as f:
            json.dump(result, f)

        report = analyze_coverage(food_order_graph, results_dir)
        assert report.total_edges == 22
        assert report.total_intents == 10
        assert report.total_boundaries == 4
        assert len(report.covered_edges) >= 1
        assert len(report.uncovered_edges) <= 22

    def test_report_format_text(self, food_order_graph: CoverageGraph, tmp_path: Path):
        results_dir = tmp_path / "results" / "run1"
        results_dir.mkdir(parents=True)
        test_dir = results_dir / "test_1"
        test_dir.mkdir()
        result = {
            "test_id": "test_1",
            "outcome": "passed",
            "transcript": [
                {"turn_number": 1, "user_message": "hello greeting", "assistant_response": "Hi"},
            ],
        }
        with open(test_dir / "result.json", "w") as f:
            json.dump(result, f)

        report = analyze_coverage(food_order_graph, results_dir)
        text = report.format_text()
        assert "Coverage Report" in text
        assert "Edge coverage:" in text
        assert "Uncovered edges:" in text

    def test_report_to_dict(self):
        report = CoverageReport(
            total_edges=10,
            covered_edges={("a", "b")},
            uncovered_edges={("c", "d")},
            unexpected_edges=set(),
            total_intents=3,
            covered_intents={"a", "b"},
            uncovered_intents={"c"},
            total_boundaries=2,
            covered_boundaries={"x"},
            uncovered_boundaries={"y"},
            classified_tests=[],
        )
        d = report.to_dict()
        assert d["edge_coverage"] == 0.1
        assert d["intent_coverage"] == pytest.approx(2 / 3)
        assert d["boundary_coverage"] == 0.5

    def test_boundary_coverage_from_test_id(self, food_order_graph: CoverageGraph, tmp_path: Path):
        results_dir = tmp_path / "results" / "run1"
        results_dir.mkdir(parents=True)
        test_dir = results_dir / "boundary_medical_advice[0]"
        test_dir.mkdir()
        result = {
            "test_id": "boundary_medical_advice[0]",
            "outcome": "passed",
            "transcript": [
                {"turn_number": 1, "user_message": "hello", "assistant_response": "Hi"},
                {
                    "turn_number": 2,
                    "user_message": "Is this safe?",
                    "assistant_response": "I can't advise on that",
                },
            ],
        }
        with open(test_dir / "result.json", "w") as f:
            json.dump(result, f)

        report = analyze_coverage(food_order_graph, results_dir)
        assert "medical_advice" in report.covered_boundaries


# ---- Integration test ----


class TestEndToEnd:
    def test_full_pipeline(self, tmp_path: Path):
        """Graph → path generation → test generation → (simulated run) → analysis."""
        # 1. Write graph.
        graph_path = tmp_path / "coverage.yaml"
        graph_path.write_text(
            textwrap.dedent("""\
            intents:
              start:
                description: Begin the conversation
                transitions: [middle, end]
              middle:
                description: Process the request
                transitions: [end]
              end:
                description: Finish
                transitions: []
            boundaries:
              - harmful_content
        """)
        )
        graph = load_coverage_graph(graph_path)

        # 2. Generate paths.
        paths = generate_covering_paths(graph)
        all_covered = set()
        for p in paths:
            all_covered.update(p.edges)
        assert {("start", "middle"), ("start", "end"), ("middle", "end")} == all_covered

        # 3. Generate test specs.
        specs = generate_test_specs(graph)
        assert len(specs) >= 2  # at least path + boundary

        # 4. Write specs.
        output_dir = tmp_path / "tests"
        written = write_test_specs(specs, output_dir)
        assert len(written) == len(specs)

        # 5. Simulate results (as if the tests ran).
        results_dir = tmp_path / "results" / "run1"
        results_dir.mkdir(parents=True)

        test1_dir = results_dir / "test_start_to_end"
        test1_dir.mkdir()
        with open(test1_dir / "result.json", "w") as f:
            json.dump(
                {
                    "test_id": "test_start_to_end",
                    "outcome": "passed",
                    "transcript": [
                        {
                            "turn_number": 1,
                            "user_message": "start the conversation",
                            "assistant_response": "Starting",
                        },
                        {
                            "turn_number": 2,
                            "user_message": "process middle request",
                            "assistant_response": "Processing",
                        },
                        {
                            "turn_number": 3,
                            "user_message": "end finish done",
                            "assistant_response": "Goodbye",
                        },
                    ],
                },
                f,
            )

        test2_dir = results_dir / "boundary_harmful_content[0]"
        test2_dir.mkdir()
        with open(test2_dir / "result.json", "w") as f:
            json.dump(
                {
                    "test_id": "boundary_harmful_content[0]",
                    "outcome": "passed",
                    "transcript": [
                        {"turn_number": 1, "user_message": "hello", "assistant_response": "Hi"},
                        {
                            "turn_number": 2,
                            "user_message": "harmful content",
                            "assistant_response": "I can't do that",
                        },
                    ],
                },
                f,
            )

        # 6. Analyze coverage.
        report = analyze_coverage(graph, results_dir)
        assert report.total_edges == 3
        assert report.total_boundaries == 1
        assert "harmful_content" in report.covered_boundaries
