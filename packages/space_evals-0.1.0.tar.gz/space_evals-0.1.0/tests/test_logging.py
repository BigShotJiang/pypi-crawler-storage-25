"""Tests for structured logging: JSONFormatter, setup_logging, LoggingReporter."""

import json
import logging


from space_evals.events import Event, EventType
from space_evals.log import JSONFormatter, LoggingReporter, setup_logging
from space_evals.models.config import LoggingConfig


class TestJSONFormatter:
    def test_produces_valid_json(self):
        formatter = JSONFormatter()
        record = logging.LogRecord(
            name="space_evals.test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="Test message",
            args=None,
            exc_info=None,
        )
        output = formatter.format(record)
        data = json.loads(output)
        assert data["message"] == "Test message"
        assert data["level"] == "INFO"
        assert data["logger"] == "space_evals.test"
        assert "timestamp" in data

    def test_includes_extra_fields(self):
        formatter = JSONFormatter()
        record = logging.LogRecord(
            name="space_evals.clients",
            level=logging.WARNING,
            pathname="",
            lineno=0,
            msg="Retry",
            args=None,
            exc_info=None,
        )
        record.provider = "openai"
        record.attempt = 2
        record.delay_seconds = 1.5
        output = formatter.format(record)
        data = json.loads(output)
        assert data["provider"] == "openai"
        assert data["attempt"] == 2
        assert data["delay_seconds"] == 1.5

    def test_omits_missing_extra_fields(self):
        formatter = JSONFormatter()
        record = logging.LogRecord(
            name="space_evals.test",
            level=logging.DEBUG,
            pathname="",
            lineno=0,
            msg="Simple",
            args=None,
            exc_info=None,
        )
        output = formatter.format(record)
        data = json.loads(output)
        assert "provider" not in data
        assert "attempt" not in data


class TestSetupLogging:
    def test_configures_logger(self):
        setup_logging(LoggingConfig(level="DEBUG", format="text", output="stderr"))
        logger = logging.getLogger("space_evals")
        assert logger.level == logging.DEBUG
        assert len(logger.handlers) == 1

    def test_json_format(self):
        setup_logging(LoggingConfig(level="INFO", format="json", output="stderr"))
        logger = logging.getLogger("space_evals")
        assert isinstance(logger.handlers[0].formatter, JSONFormatter)

    def test_text_format(self):
        setup_logging(LoggingConfig(level="INFO", format="text", output="stderr"))
        logger = logging.getLogger("space_evals")
        assert not isinstance(logger.handlers[0].formatter, JSONFormatter)

    def test_file_output(self, tmp_path):
        log_file = tmp_path / "test.log"
        setup_logging(LoggingConfig(level="INFO", format="text", output=str(log_file)))
        logger = logging.getLogger("space_evals")
        assert isinstance(logger.handlers[0], logging.FileHandler)
        # Cleanup
        for h in logger.handlers[:]:
            h.close()
            logger.removeHandler(h)

    def test_replaces_handlers_on_reconfig(self):
        setup_logging(LoggingConfig(level="INFO"))
        setup_logging(LoggingConfig(level="DEBUG"))
        logger = logging.getLogger("space_evals")
        assert len(logger.handlers) == 1
        assert logger.level == logging.DEBUG


class TestLoggingReporter:
    def _capture_logs(self):
        """Set up a logger that captures records for assertions."""
        test_logger = logging.getLogger("space_evals.events")
        test_logger.setLevel(logging.DEBUG)
        handler = logging.handlers_module = logging.Handler
        # Use a simple list-based handler.
        records = []

        class ListHandler(logging.Handler):
            def emit(self, record):
                records.append(record)

        handler = ListHandler()
        test_logger.addHandler(handler)
        return records, handler

    def test_run_started_event(self):
        records = []

        class ListHandler(logging.Handler):
            def emit(self, record):
                records.append(record)

        logger = logging.getLogger("space_evals.events")
        logger.setLevel(logging.DEBUG)
        handler = ListHandler()
        logger.addHandler(handler)

        try:
            reporter = LoggingReporter()
            reporter.on_event(
                Event(
                    event_type=EventType.RUN_STARTED,
                    test_id="run-1",
                    data={"total_tests": 5},
                )
            )
            assert len(records) == 1
            assert "Run started" in records[0].getMessage()
        finally:
            logger.removeHandler(handler)

    def test_test_completed_pass(self):
        records = []

        class ListHandler(logging.Handler):
            def emit(self, record):
                records.append(record)

        logger = logging.getLogger("space_evals.events")
        logger.setLevel(logging.DEBUG)
        handler = ListHandler()
        logger.addHandler(handler)

        try:
            reporter = LoggingReporter()
            reporter.on_event(
                Event(
                    event_type=EventType.TEST_COMPLETED,
                    test_id="test-1",
                    data={"outcome": "passed", "duration_ms": 150.0},
                )
            )
            assert len(records) == 1
            assert records[0].levelno == logging.INFO

        finally:
            logger.removeHandler(handler)

    def test_test_completed_fail(self):
        records = []

        class ListHandler(logging.Handler):
            def emit(self, record):
                records.append(record)

        logger = logging.getLogger("space_evals.events")
        logger.setLevel(logging.DEBUG)
        handler = ListHandler()
        logger.addHandler(handler)

        try:
            reporter = LoggingReporter()
            reporter.on_event(
                Event(
                    event_type=EventType.TEST_COMPLETED,
                    test_id="test-1",
                    data={"outcome": "failed", "duration_ms": 200.0},
                )
            )
            assert len(records) == 1
            assert records[0].levelno == logging.WARNING
        finally:
            logger.removeHandler(handler)

    def test_grader_pass_logs_info(self):
        records = []

        class ListHandler(logging.Handler):
            def emit(self, record):
                records.append(record)

        logger = logging.getLogger("space_evals.events")
        logger.setLevel(logging.DEBUG)
        handler = ListHandler()
        logger.addHandler(handler)

        try:
            reporter = LoggingReporter()
            reporter.on_event(
                Event(
                    event_type=EventType.GRADER_COMPLETED,
                    test_id="test-1",
                    data={"grader_type": "exact_match", "passed": True, "message": "ok"},
                )
            )
            assert records[0].levelno == logging.INFO
        finally:
            logger.removeHandler(handler)

    def test_grader_fail_logs_warning(self):
        records = []

        class ListHandler(logging.Handler):
            def emit(self, record):
                records.append(record)

        logger = logging.getLogger("space_evals.events")
        logger.setLevel(logging.DEBUG)
        handler = ListHandler()
        logger.addHandler(handler)

        try:
            reporter = LoggingReporter()
            reporter.on_event(
                Event(
                    event_type=EventType.GRADER_COMPLETED,
                    test_id="test-1",
                    data={"grader_type": "exact_match", "passed": False, "message": "mismatch"},
                )
            )
            assert records[0].levelno == logging.WARNING
        finally:
            logger.removeHandler(handler)
