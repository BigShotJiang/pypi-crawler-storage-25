"""Tests for the generic HTTP client."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from space_evals.clients.base import Message
from space_evals.clients.http_client import (
    HTTPClient,
    _extract_json_path,
    _resolve_env_vars,
    _substitute_template,
)


class TestExtractJsonPath:
    def test_simple_key(self):
        assert _extract_json_path({"content": "hello"}, "content") == "hello"

    def test_nested_keys(self):
        data = {"choices": [{"message": {"content": "hi"}}]}
        assert _extract_json_path(data, "choices.0.message.content") == "hi"

    def test_missing_key_returns_none(self):
        assert _extract_json_path({"a": 1}, "b") is None

    def test_missing_nested_returns_none(self):
        assert _extract_json_path({"a": {"b": 1}}, "a.c.d") is None

    def test_array_index_out_of_bounds(self):
        assert _extract_json_path({"items": [1, 2]}, "items.5") is None

    def test_deeply_nested(self):
        data = {"a": {"b": {"c": {"d": 42}}}}
        assert _extract_json_path(data, "a.b.c.d") == 42

    def test_top_level_list(self):
        data = [{"content": "first"}, {"content": "second"}]
        assert _extract_json_path(data, "0.content") == "first"

    def test_integer_value(self):
        data = {"usage": {"prompt_tokens": 150}}
        assert _extract_json_path(data, "usage.prompt_tokens") == 150


class TestResolveEnvVars:
    def test_resolves_variable(self, monkeypatch):
        monkeypatch.setenv("TEST_KEY_123", "secret")
        assert _resolve_env_vars("Bearer ${TEST_KEY_123}") == "Bearer secret"

    def test_missing_variable_raises(self):
        with pytest.raises(ValueError, match="not set"):
            _resolve_env_vars("${DEFINITELY_NOT_SET_XYZ_999}")

    def test_no_variables_passthrough(self):
        assert _resolve_env_vars("plain string") == "plain string"

    def test_multiple_variables(self, monkeypatch):
        monkeypatch.setenv("HOST_ABC", "example.com")
        monkeypatch.setenv("PORT_ABC", "8080")
        result = _resolve_env_vars("https://${HOST_ABC}:${PORT_ABC}/api")
        assert result == "https://example.com:8080/api"


class TestSubstituteTemplate:
    def test_exact_placeholder_returns_object(self):
        messages = [{"role": "user", "content": "hi"}]
        result = _substitute_template("{{messages}}", {"messages": messages})
        assert result == messages
        assert isinstance(result, list)

    def test_string_interpolation(self):
        result = _substitute_template("model-{{model}}", {"model": "gpt-4"})
        assert result == "model-gpt-4"

    def test_nested_dict(self):
        template = {"body": {"model": "{{model}}", "data": "{{messages}}"}}
        messages = [{"role": "user"}]
        result = _substitute_template(template, {"model": "gpt-4", "messages": messages})
        assert result == {"body": {"model": "gpt-4", "data": messages}}

    def test_list_substitution(self):
        template = ["{{model}}", "other"]
        result = _substitute_template(template, {"model": "gpt-4"})
        assert result == ["gpt-4", "other"]

    def test_non_string_passthrough(self):
        assert _substitute_template(42, {"model": "gpt-4"}) == 42
        assert _substitute_template(True, {}) is True


class TestHTTPClientInit:
    def test_resolves_url_env_vars(self, monkeypatch):
        monkeypatch.setenv("LLM_HOST", "my-llm.example.com")
        client = HTTPClient(model="test", url="https://${LLM_HOST}/v1/chat")
        assert client.url == "https://my-llm.example.com/v1/chat"

    def test_resolves_header_env_vars(self, monkeypatch):
        monkeypatch.setenv("LLM_TOKEN", "tok_abc")
        client = HTTPClient(
            model="test",
            url="https://example.com",
            headers={"Authorization": "Bearer ${LLM_TOKEN}"},
        )
        assert client.headers["Authorization"] == "Bearer tok_abc"

    def test_defaults(self):
        client = HTTPClient(model="test", url="https://example.com")
        assert client.response_content_path == "choices.0.message.content"
        assert client.input_tokens_path is None
        assert client.output_tokens_path is None
        assert client.request_template is None


class TestHTTPClientBuildRequestBody:
    def test_default_openai_compatible(self):
        client = HTTPClient(model="my-model", url="https://example.com")
        messages = [Message(role="user", content="hello")]
        body = client._build_request_body(messages, system_prompt="")

        assert body["model"] == "my-model"
        assert len(body["messages"]) == 1
        assert body["messages"][0] == {"role": "user", "content": "hello"}

    def test_includes_system_prompt(self):
        client = HTTPClient(model="my-model", url="https://example.com")
        messages = [Message(role="user", content="hello")]
        body = client._build_request_body(messages, system_prompt="Be helpful")

        assert body["messages"][0] == {"role": "system", "content": "Be helpful"}
        assert body["messages"][1] == {"role": "user", "content": "hello"}

    def test_custom_template(self):
        client = HTTPClient(
            model="custom",
            url="https://example.com",
            request_template={
                "llm_model": "{{model}}",
                "conversation": "{{messages}}",
                "stream": False,
            },
        )
        messages = [Message(role="user", content="hi")]
        body = client._build_request_body(messages, system_prompt="")

        assert body["llm_model"] == "custom"
        assert body["conversation"] == [{"role": "user", "content": "hi"}]
        assert body["stream"] is False

    def test_extra_params_in_default_body(self):
        client = HTTPClient(
            model="my-model",
            url="https://example.com",
            temperature=0.7,
            max_tokens=100,
        )
        messages = [Message(role="user", content="hello")]
        body = client._build_request_body(messages, system_prompt="")

        assert body["temperature"] == 0.7
        assert body["max_tokens"] == 100


class TestHTTPClientSend:
    @pytest.mark.asyncio
    async def test_sends_and_extracts_response(self):
        client = HTTPClient(model="test", url="https://example.com/chat")

        response_data = {
            "choices": [{"message": {"content": "Hello back!"}}],
        }

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json = AsyncMock(return_value=response_data)
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=mock_resp)
        client._session = mock_session

        result = await client.send([Message(role="user", content="Hello")])

        assert result.content == "Hello back!"
        assert result.usage is None
        assert result.raw == response_data

    @pytest.mark.asyncio
    async def test_extracts_token_usage(self):
        client = HTTPClient(
            model="test",
            url="https://example.com/chat",
            input_tokens_path="usage.prompt_tokens",
            output_tokens_path="usage.completion_tokens",
        )

        response_data = {
            "choices": [{"message": {"content": "Hi"}}],
            "usage": {"prompt_tokens": 50, "completion_tokens": 20},
        }

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json = AsyncMock(return_value=response_data)
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=mock_resp)
        client._session = mock_session

        result = await client.send([Message(role="user", content="Hello")])

        assert result.usage is not None
        assert result.usage.input_tokens == 50
        assert result.usage.output_tokens == 20

    @pytest.mark.asyncio
    async def test_custom_response_path(self):
        client = HTTPClient(
            model="test",
            url="https://example.com/chat",
            response_content_path="result.text",
        )

        response_data = {"result": {"text": "Custom response"}}

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json = AsyncMock(return_value=response_data)
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=mock_resp)
        client._session = mock_session

        result = await client.send([Message(role="user", content="Hello")])

        assert result.content == "Custom response"

    @pytest.mark.asyncio
    async def test_missing_content_path_returns_empty(self):
        client = HTTPClient(
            model="test",
            url="https://example.com/chat",
            response_content_path="does.not.exist",
        )

        response_data = {"other": "data"}

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json = AsyncMock(return_value=response_data)
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=mock_resp)
        client._session = mock_session

        result = await client.send([Message(role="user", content="Hello")])

        assert result.content == ""

    @pytest.mark.asyncio
    async def test_sends_correct_headers(self):
        client = HTTPClient(
            model="test",
            url="https://example.com/chat",
            headers={"X-Custom": "value"},
        )

        response_data = {"choices": [{"message": {"content": "ok"}}]}

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json = AsyncMock(return_value=response_data)
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=mock_resp)
        client._session = mock_session

        await client.send([Message(role="user", content="Hello")])

        call_kwargs = mock_session.post.call_args
        headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers")
        assert headers["X-Custom"] == "value"
        assert headers["Content-Type"] == "application/json"


class TestHTTPClientRegistered:
    def test_registered_as_http(self):
        from space_evals.clients.base import _CLIENT_REGISTRY

        assert "http" in _CLIENT_REGISTRY
