"""Shared fixtures for core tests."""

from __future__ import annotations

import pytest

from space_evals.clients.base import BaseClient, ClientResponse, Message
from space_evals.events import EventBus


class MockClient(BaseClient):
    """A mock client that returns preconfigured responses in order."""

    def __init__(self, responses: list[ClientResponse] | None = None) -> None:
        self.responses = list(responses or [])
        self.calls: list[tuple[list[Message], str]] = []
        self._index = 0

    async def send(self, messages: list[Message], system_prompt: str = "") -> ClientResponse:
        self.calls.append((list(messages), system_prompt))
        if self._index < len(self.responses):
            resp = self.responses[self._index]
            self._index += 1
            return resp
        return ClientResponse(content="default mock response")


@pytest.fixture
def mock_client():
    """Create a MockClient with optional responses."""

    def _factory(responses: list[ClientResponse] | None = None) -> MockClient:
        return MockClient(responses)

    return _factory


@pytest.fixture
def event_bus():
    return EventBus()


@pytest.fixture
def sample_scripted_spec() -> dict:
    return {
        "id": "test-scripted-1",
        "type": "scripted",
        "scenario": "Test greeting flow",
        "turns": [
            {
                "user_message": "Hello",
                "graders": [
                    {"type": "exact_match", "expected_response": "Hi there!"},
                ],
            },
            {
                "user_message": "How are you?",
                "graders": [
                    {"type": "exact_match", "expected_response": "I'm doing well!"},
                ],
            },
        ],
    }


@pytest.fixture
def sample_task_based_spec() -> dict:
    return {
        "id": "test-task-1",
        "type": "task_based",
        "scenario": "Test weather lookup",
        "goal": "Get the weather in NYC",
        "initial_user_message": "What's the weather in NYC?",
        "max_turns": 3,
        "end_conditions": [
            {
                "type": "keyword_match",
                "keyword": "sunny",
            },
        ],
        "transcript_graders": [],
    }
