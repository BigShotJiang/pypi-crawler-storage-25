"""Tests for parameterized test spec expansion."""

from __future__ import annotations

import json

import pytest

from space_evals.params import (
    expand_spec,
    load_parameters_from_file,
    render_template,
)


class TestRenderTemplate:
    def test_simple_substitution(self):
        assert render_template("Hello {{name}}", {"name": "World"}) == "Hello World"

    def test_multiple_substitutions(self):
        result = render_template("{{a}} and {{b}}", {"a": "X", "b": "Y"})
        assert result == "X and Y"

    def test_no_placeholders(self):
        assert render_template("plain text", {"x": "y"}) == "plain text"

    def test_missing_variable_raises(self):
        with pytest.raises(ValueError, match="missing_var"):
            render_template("{{missing_var}}", {})

    def test_repeated_placeholder(self):
        assert render_template("{{x}} {{x}}", {"x": "A"}) == "A A"


class TestLoadParametersFromFile:
    def test_load_csv(self, tmp_path):
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("lang,greeting\nEnglish,Hello\nSpanish,Hola\n")
        result = load_parameters_from_file("data.csv", tmp_path)
        assert len(result) == 2
        assert result[0] == {"lang": "English", "greeting": "Hello"}
        assert result[1] == {"lang": "Spanish", "greeting": "Hola"}

    def test_load_json(self, tmp_path):
        json_file = tmp_path / "data.json"
        json_file.write_text(
            json.dumps(
                [
                    {"lang": "English", "greeting": "Hello"},
                    {"lang": "French", "greeting": "Bonjour"},
                ]
            )
        )
        result = load_parameters_from_file("data.json", tmp_path)
        assert len(result) == 2
        assert result[1]["lang"] == "French"

    def test_missing_file_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            load_parameters_from_file("missing.csv", tmp_path)

    def test_unsupported_format_raises(self, tmp_path):
        (tmp_path / "data.txt").write_text("stuff")
        with pytest.raises(ValueError, match="Unsupported"):
            load_parameters_from_file("data.txt", tmp_path)

    def test_json_not_list_raises(self, tmp_path):
        (tmp_path / "data.json").write_text('{"not": "a list"}')
        with pytest.raises(ValueError, match="list of objects"):
            load_parameters_from_file("data.json", tmp_path)


class TestExpandSpec:
    def test_non_parameterized_passthrough(self, tmp_path):
        raw = {
            "id": "test-1",
            "type": "scripted",
            "scenario": "A test",
            "turns": [{"user_message": "Hello"}],
        }
        result = expand_spec(raw, tmp_path)
        assert len(result) == 1
        spec, params = result[0]
        assert spec.id == "test-1"
        assert params is None

    def test_inline_parameters_scripted(self, tmp_path):
        raw = {
            "id": "greeting",
            "type": "scripted",
            "scenario": "Greet in {{language}}",
            "parameters": [
                {"language": "English", "word": "Hello"},
                {"language": "Spanish", "word": "Hola"},
                {"language": "French", "word": "Bonjour"},
            ],
            "turns": [{"user_message": "{{word}}, help me"}],
        }
        result = expand_spec(raw, tmp_path)
        assert len(result) == 3

        spec0, params0 = result[0]
        assert spec0.id == "greeting[0]"
        assert spec0.scenario == "Greet in English"
        assert spec0.turns[0].user_message == "Hello, help me"
        assert params0 == {"language": "English", "word": "Hello"}

        spec2, params2 = result[2]
        assert spec2.id == "greeting[2]"
        assert spec2.scenario == "Greet in French"
        assert spec2.turns[0].user_message == "Bonjour, help me"

    def test_inline_parameters_task_based(self, tmp_path):
        raw = {
            "id": "order",
            "type": "task_based",
            "scenario": "Order {{order_id}}",
            "goal": "Find order {{order_id}}",
            "initial_user_message": "Check on order {{order_id}}",
            "max_turns": 5,
            "parameters": [
                {"order_id": "123"},
                {"order_id": "456"},
            ],
        }
        result = expand_spec(raw, tmp_path)
        assert len(result) == 2

        spec0, _ = result[0]
        assert spec0.id == "order[0]"
        assert spec0.goal == "Find order 123"
        assert spec0.initial_user_message == "Check on order 123"

    def test_parameters_from_csv(self, tmp_path):
        csv_file = tmp_path / "items.csv"
        csv_file.write_text("item\napple\nbanana\n")

        raw = {
            "id": "item-test",
            "type": "scripted",
            "scenario": "Test {{item}}",
            "parameters_from": "items.csv",
            "turns": [{"user_message": "I want a {{item}}"}],
        }
        result = expand_spec(raw, tmp_path)
        assert len(result) == 2
        assert result[0][0].turns[0].user_message == "I want a apple"
        assert result[1][0].turns[0].user_message == "I want a banana"

    def test_grader_template_substitution(self, tmp_path):
        raw = {
            "id": "grader-test",
            "type": "scripted",
            "scenario": "Test {{lang}}",
            "parameters": [{"lang": "English"}],
            "turns": [
                {
                    "user_message": "Hi",
                    "graders": [
                        {"type": "llm_judge", "assertions": [{"type": "Response is in {{lang}}"}]},
                    ],
                }
            ],
        }
        result = expand_spec(raw, tmp_path)
        spec, _ = result[0]
        grader = spec.turns[0].graders[0]
        assert grader["assertions"][0]["type"] == "Response is in English"

    def test_empty_parameters_raises(self, tmp_path):
        raw = {
            "id": "test",
            "type": "scripted",
            "scenario": "Test",
            "parameters": [],
            "turns": [{"user_message": "Hi"}],
        }
        with pytest.raises(ValueError, match="empty"):
            expand_spec(raw, tmp_path)

    def test_parameters_fields_removed_from_expanded(self, tmp_path):
        raw = {
            "id": "test",
            "type": "scripted",
            "scenario": "Test",
            "parameters": [{"x": "1"}],
            "turns": [{"user_message": "Hi"}],
        }
        result = expand_spec(raw, tmp_path)
        spec, _ = result[0]
        assert spec.parameters is None
        assert spec.parameters_from is None
