"""Tests for the plugin discovery system."""

import pytest

from space_evals.clients.base import (
    BaseClient,
    ClientResponse,
    _CLIENT_REGISTRY,
    get_client,
    register_client,
)
from space_evals.graders.base import (
    BaseGrader,
    _GRADER_REGISTRY,
    get_grader,
    register_grader,
)
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.plugins import list_installed_plugins


class TestClientRegistry:
    def test_register_and_retrieve(self):
        @register_client("_test_provider")
        class TestClient(BaseClient):
            def __init__(self, **kwargs):
                pass

            async def send(self, messages, system_prompt=""):
                return ClientResponse(content="test")

        client = get_client("_test_provider")
        assert type(client).__name__ == "TestClient"

        # Cleanup
        del _CLIENT_REGISTRY["_test_provider"]

    def test_unknown_provider_raises(self):
        with pytest.raises(ValueError, match="Unknown provider"):
            get_client("nonexistent_provider_xyz")

    def test_entry_point_discovery_returns_correct_structure(self):
        """Verify that list_installed_plugins returns the expected shape.

        We don't assert specific plugins are present because the core
        package deliberately does not depend on any client plugins.
        """
        plugins = list_installed_plugins()
        assert "clients" in plugins
        assert "graders" in plugins
        assert "reporters" in plugins
        assert isinstance(plugins["clients"], list)
        assert isinstance(plugins["graders"], list)
        assert isinstance(plugins["reporters"], list)


class TestGraderRegistry:
    def test_register_and_retrieve(self):
        @register_grader("_test_grader")
        class TestGrader(BaseGrader):
            async def grade(self, turn, spec):
                return GraderResult(grader_type="_test_grader", outcome=GraderOutcome.PASSED)

        grader = get_grader("_test_grader")
        assert type(grader).__name__ == "TestGrader"

        # Cleanup
        del _GRADER_REGISTRY["_test_grader"]

    def test_unknown_grader_raises(self):
        with pytest.raises(ValueError, match="Unknown grader type"):
            get_grader("nonexistent_grader_xyz")
