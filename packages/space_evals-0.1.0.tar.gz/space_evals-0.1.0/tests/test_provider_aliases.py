"""Tests for provider aliases and base_url passthrough."""

import os

import pytest

from space_evals.clients.base import (
    _PROVIDER_ALIASES,
    get_client,
    _CLIENT_REGISTRY,
    register_client,
    BaseClient,
    ClientResponse,
)


class TestProviderAliases:
    def test_aliases_defined(self):
        assert "huggingface" in _PROVIDER_ALIASES
        assert "groq" in _PROVIDER_ALIASES
        assert "together" in _PROVIDER_ALIASES
        assert "fireworks" in _PROVIDER_ALIASES
        assert "ollama" in _PROVIDER_ALIASES

    def test_alias_structure(self):
        for name, alias in _PROVIDER_ALIASES.items():
            assert "provider" in alias, f"Alias {name} missing 'provider'"
            assert "base_url" in alias, f"Alias {name} missing 'base_url'"
            assert "api_key_env" in alias, f"Alias {name} missing 'api_key_env'"

    def test_huggingface_defaults(self):
        alias = _PROVIDER_ALIASES["huggingface"]
        assert alias["provider"] == "openai"
        assert "huggingface.co" in alias["base_url"]
        assert alias["api_key_env"] == "HF_TOKEN"

    def test_alias_resolves_to_real_provider(self):
        """Alias resolution should look up the real provider in the registry."""

        # Register a mock provider to test alias resolution without
        # needing the real openai package.
        @register_client("_test_alias_target")
        class MockClient(BaseClient):
            def __init__(self, **kwargs):
                self.kwargs = kwargs

            async def send(self, messages, system_prompt=""):
                return ClientResponse(content="test")

        # Add a test alias pointing at our mock provider.
        _PROVIDER_ALIASES["_test_alias"] = {
            "provider": "_test_alias_target",
            "base_url": "https://test.example.com/v1",
            "api_key_env": "TEST_KEY",
        }

        try:
            os.environ["TEST_KEY"] = "fake-key"
            client = get_client("_test_alias", model="test-model")
            assert isinstance(client, MockClient)
            assert client.kwargs.get("base_url") == "https://test.example.com/v1"
            assert client.kwargs.get("api_key_env") == "TEST_KEY"
        finally:
            del _PROVIDER_ALIASES["_test_alias"]
            del _CLIENT_REGISTRY["_test_alias_target"]
            del os.environ["TEST_KEY"]

    def test_alias_user_overrides(self):
        """User-supplied kwargs should override alias defaults."""

        @register_client("_test_alias_target2")
        class MockClient(BaseClient):
            def __init__(self, **kwargs):
                self.kwargs = kwargs

            async def send(self, messages, system_prompt=""):
                return ClientResponse(content="test")

        _PROVIDER_ALIASES["_test_alias2"] = {
            "provider": "_test_alias_target2",
            "base_url": "https://default.example.com/v1",
            "api_key_env": "DEFAULT_KEY",
        }

        try:
            os.environ["CUSTOM_KEY"] = "custom-value"
            client = get_client(
                "_test_alias2",
                model="test-model",
                base_url="https://custom.example.com/v1",
                api_key_env="CUSTOM_KEY",
            )
            assert client.kwargs.get("base_url") == "https://custom.example.com/v1"
            assert client.kwargs.get("api_key_env") == "CUSTOM_KEY"
        finally:
            del _PROVIDER_ALIASES["_test_alias2"]
            del _CLIENT_REGISTRY["_test_alias_target2"]
            del os.environ["CUSTOM_KEY"]

    def test_unknown_provider_error_includes_aliases(self):
        """Error message for unknown provider should list aliases too."""
        with pytest.raises(ValueError, match="huggingface"):
            get_client("nonexistent_provider_xyz_12345")
