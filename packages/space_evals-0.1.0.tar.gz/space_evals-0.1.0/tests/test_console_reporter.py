"""Tests for console reporter: parameter display and verbosity modes."""

from space_evals.events import Event, EventType
from space_evals.reporters.console import (
    ConsoleReporter,
    Verbosity,
    _format_params,
)


class TestFormatParams:
    def test_none_returns_empty(self):
        assert _format_params(None) == ""

    def test_empty_dict_returns_empty(self):
        assert _format_params({}) == ""

    def test_single_param(self):
        assert _format_params({"city": "NYC"}) == " {city=NYC}"

    def test_multiple_params(self):
        result = _format_params({"city": "NYC", "lang": "en"})
        assert result == " {city=NYC, lang=en}"


class TestConsoleReporterParams:
    def test_test_started_shows_params(self, capsys):
        reporter = ConsoleReporter()
        reporter.on_event(Event(
            event_type=EventType.TEST_STARTED,
            test_id="weather[0]",
            data={
                "scenario": "Weather in NYC",
                "type": "scripted",
                "parameters": {"city": "NYC", "lang": "en"},
            },
        ))
        output = capsys.readouterr().out
        assert "weather[0]" in output
        assert "{city=NYC, lang=en}" in output
        assert "Weather in NYC" in output

    def test_test_started_no_params(self, capsys):
        reporter = ConsoleReporter()
        reporter.on_event(Event(
            event_type=EventType.TEST_STARTED,
            test_id="simple-test",
            data={
                "scenario": "A simple test",
                "type": "scripted",
            },
        ))
        output = capsys.readouterr().out
        assert "simple-test" in output
        assert "{" not in output


class TestVerbosityQuiet:
    """Quiet mode: only failures and the final summary."""

    def test_quiet_hides_test_started(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.QUIET)
        reporter.on_event(Event(
            event_type=EventType.TEST_STARTED,
            test_id="test-1",
            data={"scenario": "Test", "type": "scripted"},
        ))
        assert capsys.readouterr().out == ""

    def test_quiet_hides_turn_events(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.QUIET)
        reporter.on_event(Event(
            event_type=EventType.TURN_STARTED,
            test_id="test-1",
            data={"turn_number": 1, "user_message": "hi"},
        ))
        reporter.on_event(Event(
            event_type=EventType.RESPONSE_RECEIVED,
            test_id="test-1",
            data={"turn_number": 1, "response": "hello"},
        ))
        assert capsys.readouterr().out == ""

    def test_quiet_hides_grader_events(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.QUIET)
        reporter.on_event(Event(
            event_type=EventType.GRADER_COMPLETED,
            test_id="test-1",
            data={"grader_type": "exact_match", "passed": True, "message": "ok"},
        ))
        assert capsys.readouterr().out == ""

    def test_quiet_hides_passing_tests(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.QUIET)
        reporter.on_event(Event(
            event_type=EventType.TEST_COMPLETED,
            test_id="test-1",
            data={"outcome": "passed", "duration_ms": 100},
        ))
        assert capsys.readouterr().out == ""

    def test_quiet_shows_failing_tests(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.QUIET)
        reporter.on_event(Event(
            event_type=EventType.TEST_COMPLETED,
            test_id="test-1",
            data={"outcome": "failed", "duration_ms": 200},
        ))
        output = capsys.readouterr().out
        assert "FAIL" in output
        assert "test-1" in output

    def test_quiet_shows_summary(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.QUIET)
        reporter.on_event(Event(
            event_type=EventType.RUN_COMPLETED,
            test_id="run-1",
            data={"total": 10, "passed": 8, "failed": 2, "errors": 0},
        ))
        output = capsys.readouterr().out
        assert "8 passed" in output
        assert "2 failed" in output


class TestVerbosityNormal:
    """Normal mode: test outcomes but no turn detail."""

    def test_normal_shows_test_started(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.NORMAL)
        reporter.on_event(Event(
            event_type=EventType.TEST_STARTED,
            test_id="test-1",
            data={"scenario": "Test", "type": "scripted"},
        ))
        assert "test-1" in capsys.readouterr().out

    def test_normal_hides_turn_events(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.NORMAL)
        reporter.on_event(Event(
            event_type=EventType.TURN_STARTED,
            test_id="test-1",
            data={"turn_number": 1, "user_message": "hi"},
        ))
        assert capsys.readouterr().out == ""

    def test_normal_hides_grader_details(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.NORMAL)
        reporter.on_event(Event(
            event_type=EventType.GRADER_COMPLETED,
            test_id="test-1",
            data={"grader_type": "exact_match", "passed": True, "message": "ok"},
        ))
        assert capsys.readouterr().out == ""

    def test_normal_shows_test_completed(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.NORMAL)
        reporter.on_event(Event(
            event_type=EventType.TEST_COMPLETED,
            test_id="test-1",
            data={"outcome": "passed", "duration_ms": 100},
        ))
        output = capsys.readouterr().out
        assert "PASS" in output
        assert "test-1" in output


class TestVerbosityVerbose:
    """Verbose mode: everything including turns and grader messages."""

    def test_verbose_shows_turns(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.VERBOSE)
        reporter.on_event(Event(
            event_type=EventType.TURN_STARTED,
            test_id="test-1",
            data={"turn_number": 1, "user_message": "What's the weather?"},
        ))
        output = capsys.readouterr().out
        assert "Turn 1" in output
        assert "What's the weather?" in output

    def test_verbose_shows_responses(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.VERBOSE)
        reporter.on_event(Event(
            event_type=EventType.RESPONSE_RECEIVED,
            test_id="test-1",
            data={"turn_number": 1, "response": "It's sunny"},
        ))
        output = capsys.readouterr().out
        assert "Turn 1" in output
        assert "It's sunny" in output

    def test_verbose_shows_grader_results(self, capsys):
        reporter = ConsoleReporter(verbosity=Verbosity.VERBOSE)
        reporter.on_event(Event(
            event_type=EventType.GRADER_COMPLETED,
            test_id="test-1",
            data={"grader_type": "exact_match", "passed": False, "message": "mismatch"},
        ))
        output = capsys.readouterr().out
        assert "FAIL" in output
        assert "exact_match" in output
        assert "mismatch" in output
