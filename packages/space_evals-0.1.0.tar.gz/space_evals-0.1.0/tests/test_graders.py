"""Tests for built-in graders and the grader registry."""

import pytest

from space_evals.graders.base import get_grader, register_grader, BaseGrader, _GRADER_REGISTRY
from space_evals.models.results import GraderOutcome, GraderResult
from space_evals.models.transcript import Turn, ToolCall

# Ensure core graders are registered.
import space_evals.graders.contains  # noqa: F401
import space_evals.graders.custom_function  # noqa: F401
import space_evals.graders.exact_match  # noqa: F401
import space_evals.graders.json_schema  # noqa: F401
import space_evals.graders.llm_judge  # noqa: F401
import space_evals.graders.regex_match  # noqa: F401
import space_evals.graders.starts_with  # noqa: F401
import space_evals.graders.tool_calls  # noqa: F401
import space_evals.graders.rouge_score  # noqa: F401
import space_evals.graders.bleu_score  # noqa: F401
import space_evals.graders.bert_score  # noqa: F401


class TestGraderRegistry:
    def test_core_graders_registered(self):
        assert "exact_match" in _GRADER_REGISTRY
        assert "llm_judge" in _GRADER_REGISTRY
        assert "tool_calls" in _GRADER_REGISTRY
        assert "contains" in _GRADER_REGISTRY
        assert "regex" in _GRADER_REGISTRY
        assert "json_schema" in _GRADER_REGISTRY
        assert "starts_with" in _GRADER_REGISTRY
        assert "custom_function" in _GRADER_REGISTRY
        assert "rouge" in _GRADER_REGISTRY
        assert "bleu" in _GRADER_REGISTRY
        assert "bert_score" in _GRADER_REGISTRY

    def test_get_grader_returns_instance(self):
        grader = get_grader("exact_match")
        assert isinstance(grader, BaseGrader)

    def test_get_grader_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown grader type"):
            get_grader("nonexistent_grader_xyz")

    def test_register_custom_grader(self):
        @register_grader("_test_custom")
        class CustomGrader(BaseGrader):
            async def grade(self, turn, spec):
                return GraderResult(grader_type="_test_custom", outcome=GraderOutcome.PASSED)

        grader = get_grader("_test_custom")
        assert type(grader).__name__ == "CustomGrader"

        # Cleanup
        del _GRADER_REGISTRY["_test_custom"]


class TestExactMatchGrader:
    @pytest.mark.asyncio
    async def test_passes_on_exact_match(self):
        grader = get_grader("exact_match")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="hello")
        result = await grader.grade(turn, {"expected_response": "hello"})
        assert result.passed

    @pytest.mark.asyncio
    async def test_fails_on_mismatch(self):
        grader = get_grader("exact_match")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="hey")
        result = await grader.grade(turn, {"expected_response": "hello"})
        assert not result.passed
        assert "hello" in result.details["expected"]

    @pytest.mark.asyncio
    async def test_fails_on_none_response(self):
        grader = get_grader("exact_match")
        turn = Turn(turn_number=1, user_message="hi", assistant_response=None)
        result = await grader.grade(turn, {"expected_response": "hello"})
        assert not result.passed


class TestToolCallsGrader:
    @pytest.mark.asyncio
    async def test_passes_when_tool_called(self):
        grader = get_grader("tool_calls")
        turn = Turn(
            turn_number=1,
            user_message="weather?",
            assistant_response="sure",
            tool_calls=[ToolCall(tool_name="get_weather", arguments={"city": "NYC"})],
        )
        result = await grader.grade(
            turn,
            {
                "expected_calls": [{"tool_name": "get_weather", "arguments": {"city": "NYC"}}],
            },
        )
        assert result.passed

    @pytest.mark.asyncio
    async def test_fails_when_tool_not_called(self):
        grader = get_grader("tool_calls")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="hey", tool_calls=[])
        result = await grader.grade(
            turn,
            {
                "expected_calls": [{"tool_name": "get_weather", "arguments": {}}],
            },
        )
        assert not result.passed

    @pytest.mark.asyncio
    async def test_fails_on_wrong_arguments(self):
        grader = get_grader("tool_calls")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response="hey",
            tool_calls=[ToolCall(tool_name="get_weather", arguments={"city": "LA"})],
        )
        result = await grader.grade(
            turn,
            {
                "expected_calls": [{"tool_name": "get_weather", "arguments": {"city": "NYC"}}],
            },
        )
        assert not result.passed


class TestLLMJudgeGrader:
    @pytest.mark.asyncio
    async def test_fails_without_judge_client(self):
        grader = get_grader("llm_judge")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="hello")
        result = await grader.grade(turn, {"assertions": [{"type": "is polite"}]})
        assert not result.passed
        assert "No judge client" in result.message

    @pytest.mark.asyncio
    async def test_passes_with_judge_client(self):
        from space_evals.clients.base import ClientResponse

        class MockJudge:
            async def send(self, messages, system_prompt=""):
                return ClientResponse(content="PASS - all assertions hold")

        grader = get_grader("llm_judge")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="Hello! How can I help?")
        context = {"judge_client": MockJudge()}
        result = await grader.grade(
            turn,
            {"assertions": [{"type": "response is polite"}]},
            context=context,
        )
        assert result.passed
        assert "PASS" in result.message

    @pytest.mark.asyncio
    async def test_fails_when_judge_says_fail(self):
        from space_evals.clients.base import ClientResponse

        class MockJudge:
            async def send(self, messages, system_prompt=""):
                return ClientResponse(content="FAIL - response was rude")

        grader = get_grader("llm_judge")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="go away")
        context = {"judge_client": MockJudge()}
        result = await grader.grade(
            turn,
            {"assertions": [{"type": "response is polite"}]},
            context=context,
        )
        assert not result.passed
        assert "FAIL" in result.message


class TestContainsGrader:
    @pytest.mark.asyncio
    async def test_passes_when_substring_found(self):
        grader = get_grader("contains")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="Hello, world!")
        result = await grader.grade(turn, {"substring": "world"})
        assert result.passed

    @pytest.mark.asyncio
    async def test_fails_when_substring_not_found(self):
        grader = get_grader("contains")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="Hello!")
        result = await grader.grade(turn, {"substring": "world"})
        assert not result.passed

    @pytest.mark.asyncio
    async def test_case_insensitive(self):
        grader = get_grader("contains")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="Hello, WORLD!")
        result = await grader.grade(turn, {"substring": "world", "case_sensitive": False})
        assert result.passed

    @pytest.mark.asyncio
    async def test_case_sensitive_fails(self):
        grader = get_grader("contains")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="Hello, WORLD!")
        result = await grader.grade(turn, {"substring": "world", "case_sensitive": True})
        assert not result.passed

    @pytest.mark.asyncio
    async def test_none_response(self):
        grader = get_grader("contains")
        turn = Turn(turn_number=1, user_message="hi", assistant_response=None)
        result = await grader.grade(turn, {"substring": "hello"})
        assert not result.passed


class TestStartsWithGrader:
    @pytest.mark.asyncio
    async def test_passes_when_starts_with(self):
        grader = get_grader("starts_with")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="Hello, world!")
        result = await grader.grade(turn, {"prefix": "Hello"})
        assert result.passed

    @pytest.mark.asyncio
    async def test_fails_when_not_starts_with(self):
        grader = get_grader("starts_with")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="Goodbye!")
        result = await grader.grade(turn, {"prefix": "Hello"})
        assert not result.passed

    @pytest.mark.asyncio
    async def test_case_insensitive(self):
        grader = get_grader("starts_with")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="HELLO world")
        result = await grader.grade(turn, {"prefix": "hello", "case_sensitive": False})
        assert result.passed

    @pytest.mark.asyncio
    async def test_none_response(self):
        grader = get_grader("starts_with")
        turn = Turn(turn_number=1, user_message="hi", assistant_response=None)
        result = await grader.grade(turn, {"prefix": "Hello"})
        assert not result.passed


class TestRegexGrader:
    @pytest.mark.asyncio
    async def test_passes_on_match(self):
        grader = get_grader("regex")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="The answer is 42.")
        result = await grader.grade(turn, {"pattern": r"\d+"})
        assert result.passed

    @pytest.mark.asyncio
    async def test_fails_on_no_match(self):
        grader = get_grader("regex")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="No numbers here.")
        result = await grader.grade(turn, {"pattern": r"\d+"})
        assert not result.passed

    @pytest.mark.asyncio
    async def test_full_match(self):
        grader = get_grader("regex")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="42")
        result = await grader.grade(turn, {"pattern": r"\d+", "full_match": True})
        assert result.passed

    @pytest.mark.asyncio
    async def test_full_match_fails_on_partial(self):
        grader = get_grader("regex")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="The answer is 42.")
        result = await grader.grade(turn, {"pattern": r"\d+", "full_match": True})
        assert not result.passed

    @pytest.mark.asyncio
    async def test_flags_ignorecase(self):
        grader = get_grader("regex")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="HELLO world")
        result = await grader.grade(turn, {"pattern": r"hello", "flags": ["IGNORECASE"]})
        assert result.passed

    @pytest.mark.asyncio
    async def test_invalid_pattern(self):
        grader = get_grader("regex")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="test")
        result = await grader.grade(turn, {"pattern": r"[invalid"})
        assert not result.passed
        assert "Invalid regex" in result.message


class TestJsonSchemaGrader:
    @pytest.mark.asyncio
    async def test_passes_valid_json(self):
        grader = get_grader("json_schema")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response='{"name": "Alice", "age": 30}',
        )
        result = await grader.grade(
            turn,
            {
                "schema": {
                    "type": "object",
                    "required": ["name", "age"],
                    "properties": {
                        "name": {"type": "string"},
                        "age": {"type": "integer"},
                    },
                },
            },
        )
        assert result.passed

    @pytest.mark.asyncio
    async def test_fails_missing_required(self):
        grader = get_grader("json_schema")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response='{"name": "Alice"}',
        )
        result = await grader.grade(
            turn,
            {
                "schema": {
                    "type": "object",
                    "required": ["name", "age"],
                },
            },
        )
        assert not result.passed
        assert "age" in result.message

    @pytest.mark.asyncio
    async def test_fails_wrong_type(self):
        grader = get_grader("json_schema")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response='{"age": "thirty"}',
        )
        result = await grader.grade(
            turn,
            {
                "schema": {
                    "type": "object",
                    "properties": {
                        "age": {"type": "integer"},
                    },
                },
            },
        )
        assert not result.passed

    @pytest.mark.asyncio
    async def test_fails_invalid_json(self):
        grader = get_grader("json_schema")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="not json")
        result = await grader.grade(turn, {"schema": {"type": "object"}})
        assert not result.passed
        assert "not valid JSON" in result.message

    @pytest.mark.asyncio
    async def test_extracts_json_from_code_block(self):
        grader = get_grader("json_schema")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response='Here is the result:\n```json\n{"key": "value"}\n```',
        )
        result = await grader.grade(
            turn,
            {
                "schema": {
                    "type": "object",
                    "required": ["key"],
                },
            },
        )
        assert result.passed

    @pytest.mark.asyncio
    async def test_validates_array_items(self):
        grader = get_grader("json_schema")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response="[1, 2, 3]",
        )
        result = await grader.grade(
            turn,
            {
                "schema": {
                    "type": "array",
                    "items": {"type": "integer"},
                },
            },
        )
        assert result.passed

    @pytest.mark.asyncio
    async def test_empty_schema_passes_any_json(self):
        grader = get_grader("json_schema")
        turn = Turn(turn_number=1, user_message="hi", assistant_response='"just a string"')
        result = await grader.grade(turn, {"schema": {}})
        assert result.passed


class TestCustomFunctionGrader:
    @pytest.mark.asyncio
    async def test_fails_no_function_path(self):
        grader = get_grader("custom_function")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="test")
        result = await grader.grade(turn, {})
        assert not result.passed
        assert "No 'function' path" in result.message

    @pytest.mark.asyncio
    async def test_fails_bad_import(self):
        grader = get_grader("custom_function")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="test")
        result = await grader.grade(turn, {"function": "nonexistent_module.func"})
        assert not result.passed
        assert "Could not import" in result.message

    @pytest.mark.asyncio
    async def test_calls_function_returning_dict(self):
        grader = get_grader("custom_function")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="hello world")
        # Use a built-in module function path to test the import mechanism.
        # We'll test with a function that returns a dict via a spec trick.
        # For a real test, we patch the import.
        from unittest.mock import patch, MagicMock

        mock_func = MagicMock(return_value={"passed": True, "message": "Custom OK"})
        with patch("space_evals.graders.custom_function._import_function", return_value=mock_func):
            result = await grader.grade(turn, {"function": "my_module.my_func"})
        assert result.passed
        assert result.message == "Custom OK"

    @pytest.mark.asyncio
    async def test_calls_function_returning_grader_result(self):
        grader = get_grader("custom_function")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="test")
        from unittest.mock import patch, MagicMock

        expected_result = GraderResult(
            grader_type="custom_function",
            outcome=GraderOutcome.PASSED,
            message="Direct result",
        )
        mock_func = MagicMock(return_value=expected_result)
        with patch("space_evals.graders.custom_function._import_function", return_value=mock_func):
            result = await grader.grade(turn, {"function": "my_module.my_func"})
        assert result.passed
        assert result.message == "Direct result"

    @pytest.mark.asyncio
    async def test_handles_function_exception(self):
        grader = get_grader("custom_function")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="test")
        from unittest.mock import patch, MagicMock

        mock_func = MagicMock(side_effect=RuntimeError("boom"))
        with patch("space_evals.graders.custom_function._import_function", return_value=mock_func):
            result = await grader.grade(turn, {"function": "my_module.my_func"})
        assert not result.passed
        assert "boom" in result.message


class TestRougeGrader:
    @pytest.mark.asyncio
    async def test_no_reference_fails(self):
        grader = get_grader("rouge")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="test")
        result = await grader.grade(turn, {})
        assert not result.passed
        assert "reference" in result.message

    @pytest.mark.asyncio
    async def test_passes_on_high_similarity(self):
        grader = get_grader("rouge")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response="The cat sat on the mat.",
        )
        result = await grader.grade(
            turn,
            {
                "reference": "The cat sat on the mat.",
                "min_score": 0.9,
            },
        )
        # If rouge-score is not installed, the grader returns a graceful failure.
        try:
            import rouge_score  # noqa: F401
        except ImportError:
            assert not result.passed
            assert "not installed" in result.message
            return
        assert result.passed
        assert result.details["score"] >= 0.9

    @pytest.mark.asyncio
    async def test_fails_on_low_similarity(self):
        try:
            import rouge_score  # noqa: F401
        except ImportError:
            pytest.skip("rouge-score not installed")
        grader = get_grader("rouge")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response="Something completely different.",
        )
        result = await grader.grade(
            turn,
            {
                "reference": "The cat sat on the mat.",
                "min_score": 0.8,
            },
        )
        assert not result.passed

    @pytest.mark.asyncio
    async def test_custom_metric(self):
        try:
            import rouge_score  # noqa: F401
        except ImportError:
            pytest.skip("rouge-score not installed")
        grader = get_grader("rouge")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response="The cat sat on the mat.",
        )
        result = await grader.grade(
            turn,
            {
                "reference": "The cat sat on the mat.",
                "metric": "rouge1",
                "min_score": 0.5,
            },
        )
        assert result.passed
        assert result.details["metric"] == "rouge1"


class TestBleuGrader:
    @pytest.mark.asyncio
    async def test_no_reference_fails(self):
        grader = get_grader("bleu")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="test")
        result = await grader.grade(turn, {})
        assert not result.passed
        assert "reference" in result.message

    @pytest.mark.asyncio
    async def test_passes_on_exact_match(self):
        grader = get_grader("bleu")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response="The cat sat on the mat.",
        )
        result = await grader.grade(
            turn,
            {
                "reference": "The cat sat on the mat.",
                "min_score": 0.9,
            },
        )
        try:
            import nltk  # noqa: F401
        except ImportError:
            assert not result.passed
            assert "not installed" in result.message
            return
        assert result.passed

    @pytest.mark.asyncio
    async def test_fails_on_low_similarity(self):
        try:
            import nltk  # noqa: F401
        except ImportError:
            pytest.skip("nltk not installed")
        grader = get_grader("bleu")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response="Something completely different and unrelated.",
        )
        result = await grader.grade(
            turn,
            {
                "reference": "The cat sat on the mat.",
                "min_score": 0.5,
            },
        )
        assert not result.passed


class TestBertScoreGrader:
    @pytest.mark.asyncio
    async def test_no_reference_fails(self):
        grader = get_grader("bert_score")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="test")
        result = await grader.grade(turn, {})
        assert not result.passed
        assert "reference" in result.message

    @pytest.mark.asyncio
    async def test_missing_library_graceful(self):
        """When bert-score isn't installed, grader returns a graceful failure."""
        grader = get_grader("bert_score")
        turn = Turn(
            turn_number=1,
            user_message="hi",
            assistant_response="The weather is nice today.",
        )
        result = await grader.grade(
            turn,
            {
                "reference": "Today has nice weather.",
                "min_score": 0.85,
            },
        )
        try:
            import bert_score  # noqa: F401
        except ImportError:
            assert not result.passed
            assert "not installed" in result.message
