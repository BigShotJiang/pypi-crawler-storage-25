"""Tests for the engine (discovery, validation, orchestration)."""

import pytest
import yaml

from space_evals.clients.base import ClientResponse
from space_evals.engine import discover_test_files, load_and_validate, run_tests

# Ensure graders are registered.
import space_evals.graders.exact_match  # noqa: F401


class TestDiscoverTestFiles:
    def test_discovers_yaml_files(self, tmp_path):
        (tmp_path / "a.yaml").write_text("id: a")
        (tmp_path / "b.yml").write_text("id: b")
        (tmp_path / "c.txt").write_text("not a test")

        files = discover_test_files(tmp_path)
        names = [f.name for f in files]
        assert "a.yaml" in names
        assert "b.yml" in names
        assert "c.txt" not in names

    def test_discovers_nested_files(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "test.yaml").write_text("id: nested")

        files = discover_test_files(tmp_path)
        assert any("nested" in f.read_text() for f in files)

    def test_single_file(self, tmp_path):
        f = tmp_path / "single.yaml"
        f.write_text("id: single")

        files = discover_test_files(f)
        assert len(files) == 1

    def test_empty_dir_returns_empty(self, tmp_path):
        files = discover_test_files(tmp_path)
        assert files == []


class TestLoadAndValidate:
    def test_loads_valid_scripted(self, tmp_path, sample_scripted_spec):
        f = tmp_path / "test.yaml"
        f.write_text(yaml.dump(sample_scripted_spec))

        spec = load_and_validate(f)
        assert spec.id == "test-scripted-1"

    def test_loads_valid_task_based(self, tmp_path, sample_task_based_spec):
        f = tmp_path / "test.yaml"
        f.write_text(yaml.dump(sample_task_based_spec))

        spec = load_and_validate(f)
        assert spec.id == "test-task-1"

    def test_rejects_invalid_yaml(self, tmp_path):
        f = tmp_path / "bad.yaml"
        f.write_text("just a string")

        with pytest.raises(ValueError, match="expected a YAML mapping"):
            load_and_validate(f)

    def test_rejects_invalid_spec(self, tmp_path):
        f = tmp_path / "bad.yaml"
        f.write_text(yaml.dump({"id": "x", "type": "scripted", "scenario": "x"}))

        with pytest.raises(Exception):
            load_and_validate(f)


class TestRunTests:
    @pytest.mark.asyncio
    async def test_runs_scripted_test(self, tmp_path, mock_client, sample_scripted_spec):
        f = tmp_path / "test.yaml"
        f.write_text(yaml.dump(sample_scripted_spec))

        target = mock_client(
            [
                ClientResponse(content="Hi there!"),
                ClientResponse(content="I'm doing well!"),
            ]
        )

        result = await run_tests(path=tmp_path, target_client=target)

        assert result.total == 1
        assert result.passed == 1

    @pytest.mark.asyncio
    async def test_runs_mixed_tests(
        self, tmp_path, mock_client, sample_scripted_spec, sample_task_based_spec
    ):
        (tmp_path / "scripted.yaml").write_text(yaml.dump(sample_scripted_spec))
        (tmp_path / "task.yaml").write_text(yaml.dump(sample_task_based_spec))

        target = mock_client(
            [
                ClientResponse(content="Hi there!"),
                ClientResponse(content="I'm doing well!"),
                ClientResponse(content="It's sunny in NYC!"),
            ]
        )
        customer = mock_client([])

        result = await run_tests(
            path=tmp_path,
            target_client=target,
            customer_client=customer,
        )

        assert result.total == 2

    @pytest.mark.asyncio
    async def test_fails_fast_on_invalid_spec(self, tmp_path, mock_client):
        """When all specs are invalid, the run raises ValueError."""
        (tmp_path / "bad.yaml").write_text(yaml.dump({"id": "x", "type": "unknown"}))

        with pytest.raises(ValueError, match="No valid test specs"):
            await run_tests(path=tmp_path, target_client=mock_client())

    @pytest.mark.asyncio
    async def test_no_files_raises(self, tmp_path, mock_client):
        with pytest.raises(FileNotFoundError):
            await run_tests(path=tmp_path, target_client=mock_client())

    @pytest.mark.asyncio
    async def test_persists_results(self, tmp_path, mock_client, sample_scripted_spec):
        test_dir = tmp_path / "tests"
        test_dir.mkdir()
        (test_dir / "test.yaml").write_text(yaml.dump(sample_scripted_spec))
        output_dir = tmp_path / "output"

        target = mock_client(
            [
                ClientResponse(content="Hi there!"),
                ClientResponse(content="I'm doing well!"),
            ]
        )

        result = await run_tests(
            path=test_dir,
            target_client=target,
            output_dir=output_dir,
        )

        # Check that result files were written.
        run_dir = output_dir / result.run_id
        assert run_dir.exists()
        result_files = list(run_dir.rglob("result.json"))
        assert len(result_files) == 1

    @pytest.mark.asyncio
    async def test_task_based_without_customer_errors(
        self, tmp_path, mock_client, sample_task_based_spec
    ):
        (tmp_path / "test.yaml").write_text(yaml.dump(sample_task_based_spec))

        result = await run_tests(path=tmp_path, target_client=mock_client())

        assert result.errors == 1

    @pytest.mark.asyncio
    async def test_filters_by_tags(self, tmp_path, mock_client):
        """Only tests matching --tags should run."""
        smoke_spec = {
            "id": "smoke-test",
            "type": "scripted",
            "scenario": "Smoke",
            "tags": ["smoke"],
            "turns": [
                {
                    "user_message": "hi",
                    "graders": [{"type": "exact_match", "expected_response": "ok"}],
                }
            ],
        }
        regression_spec = {
            "id": "regression-test",
            "type": "scripted",
            "scenario": "Regression",
            "tags": ["regression"],
            "turns": [
                {
                    "user_message": "hi",
                    "graders": [{"type": "exact_match", "expected_response": "ok"}],
                }
            ],
        }
        (tmp_path / "smoke.yaml").write_text(yaml.dump(smoke_spec))
        (tmp_path / "regression.yaml").write_text(yaml.dump(regression_spec))

        target = mock_client([ClientResponse(content="ok")])

        result = await run_tests(path=tmp_path, target_client=target, tags=["smoke"])

        assert result.total == 1
        assert result.results[0][0].test_id == "smoke-test"

    @pytest.mark.asyncio
    async def test_tags_no_match_raises(self, tmp_path, mock_client):
        """When no tests match the requested tags, raise ValueError."""
        spec = {
            "id": "test-1",
            "type": "scripted",
            "scenario": "Test",
            "tags": ["regression"],
            "turns": [{"user_message": "hi"}],
        }
        (tmp_path / "test.yaml").write_text(yaml.dump(spec))

        with pytest.raises(ValueError, match="No tests match the requested tags"):
            await run_tests(path=tmp_path, target_client=mock_client(), tags=["nonexistent"])

    @pytest.mark.asyncio
    async def test_tags_multiple_match(self, tmp_path, mock_client):
        """A test with any of the requested tags should be included."""
        spec = {
            "id": "multi-tag",
            "type": "scripted",
            "scenario": "Multi",
            "tags": ["smoke", "pricing"],
            "turns": [
                {
                    "user_message": "hi",
                    "graders": [{"type": "exact_match", "expected_response": "ok"}],
                }
            ],
        }
        (tmp_path / "test.yaml").write_text(yaml.dump(spec))

        target = mock_client([ClientResponse(content="ok")])

        result = await run_tests(path=tmp_path, target_client=target, tags=["pricing"])
        assert result.total == 1

    @pytest.mark.asyncio
    async def test_no_tags_runs_all(self, tmp_path, mock_client):
        """When tags=None, all tests run regardless of their tags."""
        tagged_spec = {
            "id": "tagged",
            "type": "scripted",
            "scenario": "Tagged",
            "tags": ["smoke"],
            "turns": [
                {
                    "user_message": "hi",
                    "graders": [{"type": "exact_match", "expected_response": "ok"}],
                }
            ],
        }
        untagged_spec = {
            "id": "untagged",
            "type": "scripted",
            "scenario": "Untagged",
            "turns": [
                {
                    "user_message": "hi",
                    "graders": [{"type": "exact_match", "expected_response": "ok"}],
                }
            ],
        }
        (tmp_path / "tagged.yaml").write_text(yaml.dump(tagged_spec))
        (tmp_path / "untagged.yaml").write_text(yaml.dump(untagged_spec))

        target = mock_client([ClientResponse(content="ok"), ClientResponse(content="ok")])

        result = await run_tests(path=tmp_path, target_client=target, tags=None)
        assert result.total == 2


class TestFailFast:
    @pytest.mark.asyncio
    async def test_no_max_failures_runs_all(self, tmp_path, mock_client):
        """Without max_failures, all tests run even if some fail."""
        for i in range(5):
            spec = {
                "id": f"test-{i}",
                "type": "scripted",
                "scenario": f"Test {i}",
                "turns": [
                    {
                        "user_message": "hi",
                        "graders": [
                            {"type": "exact_match", "expected_response": "wrong"},
                        ],
                    }
                ],
            }
            (tmp_path / f"test-{i}.yaml").write_text(yaml.dump(spec))

        target = mock_client([ClientResponse(content="ok")] * 5)
        result = await run_tests(path=tmp_path, target_client=target)

        assert result.total == 5
        assert result.failed == 5

    @pytest.mark.asyncio
    async def test_max_failures_skips_remaining(self, tmp_path, mock_client):
        """After max_failures is reached, remaining tests are skipped."""
        for i in range(10):
            spec = {
                "id": f"test-{i}",
                "type": "scripted",
                "scenario": f"Test {i}",
                "turns": [
                    {
                        "user_message": "hi",
                        "graders": [
                            {"type": "exact_match", "expected_response": "wrong"},
                        ],
                    }
                ],
            }
            (tmp_path / f"test-{i}.yaml").write_text(yaml.dump(spec))

        target = mock_client([ClientResponse(content="ok")] * 10)
        result = await run_tests(
            path=tmp_path,
            target_client=target,
            max_failures=3,
            max_concurrency=1,  # Sequential so failure order is deterministic.
        )

        assert result.total == 10
        # At most 3 tests actually ran and failed; the rest were skipped.
        actually_ran = sum(
            1 for r, _ in result.results if r.error != "Skipped: fail-fast threshold reached"
        )
        assert actually_ran <= 3
        skipped = sum(
            1 for r, _ in result.results if r.error == "Skipped: fail-fast threshold reached"
        )
        assert skipped >= 7

    @pytest.mark.asyncio
    async def test_max_failures_all_pass_runs_all(self, tmp_path, mock_client):
        """If all tests pass, max_failures doesn't interfere."""
        for i in range(5):
            spec = {
                "id": f"test-{i}",
                "type": "scripted",
                "scenario": f"Test {i}",
                "turns": [
                    {
                        "user_message": "hi",
                        "graders": [
                            {"type": "exact_match", "expected_response": "ok"},
                        ],
                    }
                ],
            }
            (tmp_path / f"test-{i}.yaml").write_text(yaml.dump(spec))

        target = mock_client([ClientResponse(content="ok")] * 5)
        result = await run_tests(
            path=tmp_path,
            target_client=target,
            max_failures=2,
        )

        assert result.total == 5
        assert result.passed == 5
        assert result.errors == 0

    @pytest.mark.asyncio
    async def test_max_failures_one_stops_immediately(self, tmp_path, mock_client):
        """max_failures=1 is effectively fail-fast on first failure."""
        for i in range(5):
            spec = {
                "id": f"test-{i}",
                "type": "scripted",
                "scenario": f"Test {i}",
                "turns": [
                    {
                        "user_message": "hi",
                        "graders": [
                            {"type": "exact_match", "expected_response": "wrong"},
                        ],
                    }
                ],
            }
            (tmp_path / f"test-{i}.yaml").write_text(yaml.dump(spec))

        target = mock_client([ClientResponse(content="ok")] * 5)
        result = await run_tests(
            path=tmp_path,
            target_client=target,
            max_failures=1,
            max_concurrency=1,
        )

        actually_ran = sum(
            1 for r, _ in result.results if r.error != "Skipped: fail-fast threshold reached"
        )
        assert actually_ran == 1
