"""Tests for scripted and task-based runners."""

import pytest

from space_evals.clients.base import ClientResponse
from space_evals.events import EventBus, Event, EventType
from space_evals.models.results import TestOutcome
from space_evals.models.spec import parse_test_spec
from space_evals.runners.scripted import ScriptedRunner
from space_evals.runners.task_based import TaskBasedRunner

# Ensure graders are registered.
import space_evals.graders.exact_match  # noqa: F401
import space_evals.graders.tool_calls  # noqa: F401


class RecordingListener:
    def __init__(self):
        self.events: list[Event] = []

    def on_event(self, event: Event) -> None:
        self.events.append(event)


class TestScriptedRunner:
    @pytest.mark.asyncio
    async def test_all_graders_pass(self, mock_client, event_bus, sample_scripted_spec):
        target = mock_client(
            [
                ClientResponse(content="Hi there!"),
                ClientResponse(content="I'm doing well!"),
            ]
        )
        runner = ScriptedRunner(event_bus=event_bus, target_client=target)
        spec = parse_test_spec(sample_scripted_spec)

        result, transcript = await runner.run(spec)

        assert result.outcome == TestOutcome.PASSED
        assert transcript.total_turns == 2
        assert len(target.calls) == 2

    @pytest.mark.asyncio
    async def test_grader_failure_marks_test_failed(
        self, mock_client, event_bus, sample_scripted_spec
    ):
        target = mock_client(
            [
                ClientResponse(content="Wrong response"),
                ClientResponse(content="I'm doing well!"),
            ]
        )
        runner = ScriptedRunner(event_bus=event_bus, target_client=target)
        spec = parse_test_spec(sample_scripted_spec)

        result, transcript = await runner.run(spec)

        assert result.outcome == TestOutcome.FAILED
        assert not transcript.turns[0].grader_results[0].passed
        assert transcript.turns[1].grader_results[0].passed

    @pytest.mark.asyncio
    async def test_emits_events_in_order(self, mock_client, sample_scripted_spec):
        bus = EventBus()
        listener = RecordingListener()
        bus.subscribe(listener)

        target = mock_client(
            [
                ClientResponse(content="Hi there!"),
                ClientResponse(content="I'm doing well!"),
            ]
        )
        runner = ScriptedRunner(event_bus=bus, target_client=target)
        spec = parse_test_spec(sample_scripted_spec)

        await runner.run(spec)

        event_types = [e.event_type for e in listener.events]
        assert event_types[0] == EventType.TEST_STARTED
        assert EventType.TURN_STARTED in event_types
        assert EventType.RESPONSE_RECEIVED in event_types
        assert EventType.GRADER_COMPLETED in event_types
        assert event_types[-1] == EventType.TEST_COMPLETED

    @pytest.mark.asyncio
    async def test_builds_conversation_history(self, mock_client, event_bus, sample_scripted_spec):
        target = mock_client(
            [
                ClientResponse(content="Hi there!"),
                ClientResponse(content="I'm doing well!"),
            ]
        )
        runner = ScriptedRunner(event_bus=event_bus, target_client=target)
        spec = parse_test_spec(sample_scripted_spec)

        await runner.run(spec)

        # Second call should include the full conversation history.
        second_call_messages = target.calls[1][0]
        assert len(second_call_messages) == 3  # user, assistant, user
        assert second_call_messages[0].role == "user"
        assert second_call_messages[1].role == "assistant"
        assert second_call_messages[2].role == "user"


class TestTaskBasedRunner:
    @pytest.mark.asyncio
    async def test_stops_on_end_condition(self, mock_client, event_bus, sample_task_based_spec):
        target = mock_client(
            [
                ClientResponse(content="It's sunny in NYC today!"),
            ]
        )
        customer = mock_client([])  # shouldn't be called if end condition met on first turn

        runner = TaskBasedRunner(
            event_bus=event_bus,
            target_client=target,
            customer_client=customer,
        )
        spec = parse_test_spec(sample_task_based_spec)

        result, transcript = await runner.run(spec)

        assert transcript.total_turns == 1
        assert "sunny" in transcript.turns[0].assistant_response

    @pytest.mark.asyncio
    async def test_stops_on_max_turns(self, mock_client, event_bus):
        spec_data = {
            "id": "max-turns-test",
            "type": "task_based",
            "scenario": "Should stop at max turns",
            "goal": "Get weather",
            "initial_user_message": "weather?",
            "max_turns": 2,
            "end_conditions": [],
            "transcript_graders": [],
        }
        target = mock_client(
            [
                ClientResponse(content="Let me check..."),
                ClientResponse(content="Still checking..."),
            ]
        )
        customer = mock_client(
            [
                ClientResponse(content="Any update?"),
            ]
        )

        runner = TaskBasedRunner(
            event_bus=event_bus,
            target_client=target,
            customer_client=customer,
        )
        spec = parse_test_spec(spec_data)

        result, transcript = await runner.run(spec)

        assert transcript.total_turns == 2

    @pytest.mark.asyncio
    async def test_default_customer_system_prompt(self, mock_client, event_bus):
        """When no customer_system_prompt is set, runner uses the default goal-based prompt."""
        spec_data = {
            "id": "default-prompt-test",
            "type": "task_based",
            "scenario": "Check default prompt",
            "goal": "Book a flight",
            "initial_user_message": "I need a flight",
            "max_turns": 2,
        }
        target = mock_client(
            [
                ClientResponse(content="Where to?"),
                ClientResponse(content="Booked!"),
            ]
        )
        customer = mock_client(
            [
                ClientResponse(content="To NYC"),
            ]
        )

        runner = TaskBasedRunner(
            event_bus=event_bus,
            target_client=target,
            customer_client=customer,
        )
        spec = parse_test_spec(spec_data)
        await runner.run(spec)

        # Customer should have been called with the default prompt containing the goal.
        customer_prompt = customer.calls[0][1]
        assert "Book a flight" in customer_prompt
        assert "[GOAL_COMPLETE]" not in customer_prompt

    @pytest.mark.asyncio
    async def test_custom_customer_system_prompt(self, mock_client, event_bus):
        """When customer_system_prompt is set, it's prepended to the base goal prompt."""
        custom_prompt = (
            "You are an impatient customer. Your account number is 12345. "
            "You want to dispute a $50 charge. Be curt and direct."
        )
        spec_data = {
            "id": "custom-prompt-test",
            "type": "task_based",
            "scenario": "Check custom prompt",
            "goal": "Dispute a charge",
            "initial_user_message": "I have a billing issue",
            "max_turns": 2,
            "customer_system_prompt": custom_prompt,
        }
        target = mock_client(
            [
                ClientResponse(content="I can help with that. What's your account?"),
                ClientResponse(content="Done, refund issued."),
            ]
        )
        customer = mock_client(
            [
                ClientResponse(content="Account 12345, remove the $50 charge."),
            ]
        )

        runner = TaskBasedRunner(
            event_bus=event_bus,
            target_client=target,
            customer_client=customer,
        )
        spec = parse_test_spec(spec_data)
        await runner.run(spec)

        # Custom prompt fully replaces the default — no injected goal or framework text.
        customer_prompt = customer.calls[0][1]
        assert customer_prompt == custom_prompt

    @pytest.mark.asyncio
    async def test_customer_system_prompt_parameterized(self, mock_client, event_bus):
        """customer_system_prompt supports {{variable}} substitution via parameterization."""
        from space_evals.params import expand_spec
        from pathlib import Path

        raw_spec = {
            "id": "persona-test",
            "type": "task_based",
            "scenario": "Test with {{persona}} persona",
            "goal": "Get help with {{issue}}",
            "initial_user_message": "Hi, I need help with {{issue}}",
            "max_turns": 2,
            "customer_system_prompt": "You are a {{persona}} customer. Your issue: {{issue}}. Say [GOAL_COMPLETE] when done.",
            "parameters": [
                {"persona": "frustrated", "issue": "billing"},
                {"persona": "polite", "issue": "returns"},
            ],
        }

        expanded = expand_spec(raw_spec, base_dir=Path("/tmp"))
        assert len(expanded) == 2

        spec_0, params_0 = expanded[0]
        assert "frustrated" in spec_0.customer_system_prompt
        assert "billing" in spec_0.customer_system_prompt

        spec_1, params_1 = expanded[1]
        assert "polite" in spec_1.customer_system_prompt
        assert "returns" in spec_1.customer_system_prompt
