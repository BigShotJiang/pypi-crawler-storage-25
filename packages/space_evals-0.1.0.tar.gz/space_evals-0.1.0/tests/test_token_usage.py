"""Tests for token usage tracking through the pipeline."""

import pytest
import yaml

from space_evals.clients.base import ClientResponse
from space_evals.models.token_usage import TokenUsage
from space_evals.engine import run_tests

# Ensure graders are registered.
import space_evals.graders.exact_match  # noqa: F401


class TestTokenUsageModel:
    def test_defaults_to_zero(self):
        usage = TokenUsage()
        assert usage.input_tokens == 0
        assert usage.output_tokens == 0
        assert usage.total_tokens == 0

    def test_total_tokens(self):
        usage = TokenUsage(input_tokens=100, output_tokens=50)
        assert usage.total_tokens == 150

    def test_add(self):
        a = TokenUsage(input_tokens=100, output_tokens=50)
        b = TokenUsage(input_tokens=200, output_tokens=75)
        c = a + b
        assert c.input_tokens == 300
        assert c.output_tokens == 125

    def test_iadd(self):
        a = TokenUsage(input_tokens=100, output_tokens=50)
        a += TokenUsage(input_tokens=200, output_tokens=75)
        assert a.input_tokens == 300
        assert a.output_tokens == 125


class TestTokenUsageInResults:
    @pytest.mark.asyncio
    async def test_token_usage_propagated_to_result(self, tmp_path, mock_client):
        spec = {
            "id": "token-test",
            "type": "scripted",
            "scenario": "Test token tracking",
            "turns": [
                {
                    "user_message": "Hello",
                    "graders": [
                        {"type": "exact_match", "expected_response": "Hi!"},
                    ],
                },
            ],
        }
        (tmp_path / "test.yaml").write_text(yaml.dump(spec))

        target = mock_client(
            [
                ClientResponse(
                    content="Hi!",
                    usage=TokenUsage(input_tokens=10, output_tokens=5),
                ),
            ]
        )

        result = await run_tests(path=tmp_path, target_client=target)

        assert result.total == 1
        test_result, transcript = result.results[0]
        assert test_result.total_input_tokens == 10
        assert test_result.total_output_tokens == 5

        # Check turn-level usage.
        assert transcript.turns[0].token_usage is not None
        assert transcript.turns[0].token_usage.input_tokens == 10
        assert transcript.turns[0].token_usage.output_tokens == 5

        # Check transcript total.
        assert transcript.total_usage.input_tokens == 10
        assert transcript.total_usage.output_tokens == 5

    @pytest.mark.asyncio
    async def test_token_usage_aggregated_across_turns(self, tmp_path, mock_client):
        spec = {
            "id": "multi-turn-token",
            "type": "scripted",
            "scenario": "Multi-turn token tracking",
            "turns": [
                {"user_message": "Hello", "graders": []},
                {"user_message": "How are you?", "graders": []},
            ],
        }
        (tmp_path / "test.yaml").write_text(yaml.dump(spec))

        target = mock_client(
            [
                ClientResponse(
                    content="Hi!",
                    usage=TokenUsage(input_tokens=10, output_tokens=5),
                ),
                ClientResponse(
                    content="Good!",
                    usage=TokenUsage(input_tokens=20, output_tokens=10),
                ),
            ]
        )

        result = await run_tests(path=tmp_path, target_client=target)

        test_result, transcript = result.results[0]
        assert test_result.total_input_tokens == 30
        assert test_result.total_output_tokens == 15
        assert transcript.total_usage.total_tokens == 45

    @pytest.mark.asyncio
    async def test_no_usage_when_client_returns_none(self, tmp_path, mock_client):
        spec = {
            "id": "no-usage",
            "type": "scripted",
            "scenario": "No token usage",
            "turns": [{"user_message": "Hello", "graders": []}],
        }
        (tmp_path / "test.yaml").write_text(yaml.dump(spec))

        target = mock_client([ClientResponse(content="Hi!")])

        result = await run_tests(path=tmp_path, target_client=target)

        test_result, transcript = result.results[0]
        assert test_result.total_input_tokens == 0
        assert test_result.total_output_tokens == 0
        assert transcript.turns[0].token_usage is None

    @pytest.mark.asyncio
    async def test_token_usage_in_metadata(self, tmp_path, mock_client):
        spec = {
            "id": "meta-tokens",
            "type": "scripted",
            "scenario": "Metadata token check",
            "turns": [{"user_message": "Hello", "graders": []}],
        }
        (tmp_path / "test.yaml").write_text(yaml.dump(spec))

        target = mock_client(
            [
                ClientResponse(
                    content="Hi!",
                    usage=TokenUsage(input_tokens=100, output_tokens=50),
                ),
            ]
        )

        result = await run_tests(path=tmp_path, target_client=target)

        assert result.metadata is not None
        assert result.metadata["token_usage"]["total_input_tokens"] == 100
        assert result.metadata["token_usage"]["total_output_tokens"] == 50
        assert result.metadata["token_usage"]["total_tokens"] == 150

    @pytest.mark.asyncio
    async def test_token_usage_persisted(self, tmp_path, mock_client):
        import json

        test_dir = tmp_path / "tests"
        test_dir.mkdir()
        spec = {
            "id": "persist-tokens",
            "type": "scripted",
            "scenario": "Persist token check",
            "turns": [{"user_message": "Hello", "graders": []}],
        }
        (test_dir / "test.yaml").write_text(yaml.dump(spec))
        output_dir = tmp_path / "output"

        target = mock_client(
            [
                ClientResponse(
                    content="Hi!",
                    usage=TokenUsage(input_tokens=50, output_tokens=25),
                ),
            ]
        )

        result = await run_tests(
            path=test_dir,
            target_client=target,
            output_dir=output_dir,
        )

        # Check result.json has token_usage.
        result_files = list((output_dir / result.run_id).rglob("result.json"))
        assert len(result_files) == 1
        data = json.loads(result_files[0].read_text())
        assert data["token_usage"]["input_tokens"] == 50
        assert data["token_usage"]["output_tokens"] == 25
        assert data["token_usage"]["total_tokens"] == 75

        # Check turn-level token_usage.
        turn_data = data["transcript"][0]
        assert turn_data["token_usage"]["input_tokens"] == 50
