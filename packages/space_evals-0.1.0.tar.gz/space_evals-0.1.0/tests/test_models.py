"""Tests for YAML spec parsing and validation."""

import pytest
from pydantic import ValidationError

from space_evals.models.spec import (
    ScriptedTestSpec,
    TaskBasedTestSpec,
    TestType,
    parse_test_spec,
)


class TestParseTestSpec:
    def test_parses_scripted_spec(self, sample_scripted_spec):
        spec = parse_test_spec(sample_scripted_spec)
        assert isinstance(spec, ScriptedTestSpec)
        assert spec.type == TestType.SCRIPTED
        assert spec.id == "test-scripted-1"
        assert len(spec.turns) == 2
        assert spec.turns[0].user_message == "Hello"

    def test_parses_task_based_spec(self, sample_task_based_spec):
        spec = parse_test_spec(sample_task_based_spec)
        assert isinstance(spec, TaskBasedTestSpec)
        assert spec.type == TestType.TASK_BASED
        assert spec.goal == "Get the weather in NYC"
        assert spec.max_turns == 3

    def test_rejects_missing_type(self):
        with pytest.raises(ValueError, match="Unknown or missing test type"):
            parse_test_spec({"id": "x", "scenario": "x"})

    def test_rejects_unknown_type(self):
        with pytest.raises(ValueError, match="Unknown or missing test type"):
            parse_test_spec({"id": "x", "type": "unknown", "scenario": "x"})

    def test_rejects_scripted_without_turns(self):
        with pytest.raises(ValidationError):
            parse_test_spec({
                "id": "x",
                "type": "scripted",
                "scenario": "x",
                # missing turns
            })

    def test_rejects_task_based_without_goal(self):
        with pytest.raises(ValidationError):
            parse_test_spec({
                "id": "x",
                "type": "task_based",
                "scenario": "x",
                "initial_user_message": "hi",
                "max_turns": 3,
                # missing goal
            })

    def test_rejects_task_based_zero_max_turns(self):
        with pytest.raises(ValidationError):
            parse_test_spec({
                "id": "x",
                "type": "task_based",
                "scenario": "x",
                "goal": "do something",
                "initial_user_message": "hi",
                "max_turns": 0,
            })

    def test_rejects_task_based_negative_max_turns(self):
        with pytest.raises(ValidationError):
            parse_test_spec({
                "id": "x",
                "type": "task_based",
                "scenario": "x",
                "goal": "do something",
                "initial_user_message": "hi",
                "max_turns": -1,
            })

    def test_scripted_turns_graders_default_empty(self):
        spec = parse_test_spec({
            "id": "x",
            "type": "scripted",
            "scenario": "x",
            "turns": [{"user_message": "hi"}],
        })
        assert spec.turns[0].graders == []

    def test_task_based_end_conditions_default_empty(self):
        spec = parse_test_spec({
            "id": "x",
            "type": "task_based",
            "scenario": "x",
            "goal": "do something",
            "initial_user_message": "hi",
            "max_turns": 5,
        })
        assert spec.end_conditions == []
        assert spec.transcript_graders == []

    def test_task_based_customer_system_prompt_default_none(self):
        spec = parse_test_spec({
            "id": "x",
            "type": "task_based",
            "scenario": "x",
            "goal": "do something",
            "initial_user_message": "hi",
            "max_turns": 5,
        })
        assert spec.customer_system_prompt is None

    def test_task_based_customer_system_prompt_set(self):
        spec = parse_test_spec({
            "id": "x",
            "type": "task_based",
            "scenario": "x",
            "goal": "do something",
            "initial_user_message": "hi",
            "max_turns": 5,
            "customer_system_prompt": "You are a frustrated user who speaks Spanish.",
        })
        assert spec.customer_system_prompt == "You are a frustrated user who speaks Spanish."


class TestTagsParsing:
    def test_scripted_tags_default_empty(self):
        spec = parse_test_spec({
            "id": "x",
            "type": "scripted",
            "scenario": "x",
            "turns": [{"user_message": "hi"}],
        })
        assert spec.tags == []

    def test_scripted_tags_parsed(self):
        spec = parse_test_spec({
            "id": "x",
            "type": "scripted",
            "scenario": "x",
            "turns": [{"user_message": "hi"}],
            "tags": ["smoke", "regression"],
        })
        assert spec.tags == ["smoke", "regression"]

    def test_task_based_tags_default_empty(self):
        spec = parse_test_spec({
            "id": "x",
            "type": "task_based",
            "scenario": "x",
            "goal": "do something",
            "initial_user_message": "hi",
            "max_turns": 5,
        })
        assert spec.tags == []

    def test_task_based_tags_parsed(self):
        spec = parse_test_spec({
            "id": "x",
            "type": "task_based",
            "scenario": "x",
            "goal": "do something",
            "initial_user_message": "hi",
            "max_turns": 5,
            "tags": ["pricing", "slow"],
        })
        assert spec.tags == ["pricing", "slow"]


class TestConfigModel:
    def test_parses_valid_config(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
        })
        assert cfg.clients.target.provider == "openai"
        assert cfg.runner.max_concurrency == 10
        assert cfg.output.dir == "./results"

    def test_config_requires_target(self):
        from space_evals.models.config import Config

        with pytest.raises(ValidationError):
            Config.model_validate({"clients": {}})

    def test_config_optional_customer(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
        })
        assert cfg.clients.customer is None

    def test_config_ci_defaults(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
        })
        assert cfg.runner.fail_under is None
        assert cfg.runner.max_failures is None
        assert cfg.output.format == "text"

    def test_config_max_failures(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
            "runner": {
                "max_failures": 5,
            },
        })
        assert cfg.runner.max_failures == 5

    def test_config_ci_values(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
            "runner": {
                "fail_under": 0.9,
            },
            "output": {
                "format": "junit",
            },
        })
        assert cfg.runner.fail_under == 0.9
        assert cfg.output.format == "junit"

    def test_config_fail_under_validation(self):
        from space_evals.models.config import Config

        with pytest.raises(ValidationError):
            Config.model_validate({
                "clients": {
                    "target": {"provider": "openai", "model": "gpt-4o"},
                },
                "runner": {
                    "fail_under": 1.5,
                },
            })

    def test_config_retry_defaults(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
        })
        assert cfg.retry.max_retries == 3
        assert cfg.retry.base_delay == 1.0
        assert cfg.retry.max_delay == 60.0
        assert 429 in cfg.retry.retryable_status_codes

    def test_config_retry_custom(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
            "retry": {
                "max_retries": 5,
                "base_delay": 2.0,
                "retryable_status_codes": [429, 500, 503],
            },
        })
        assert cfg.retry.max_retries == 5
        assert cfg.retry.base_delay == 2.0
        assert 500 in cfg.retry.retryable_status_codes

    def test_config_rate_limit_default_none(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
        })
        assert cfg.rate_limit is None

    def test_config_rate_limit_set(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
            "rate_limit": {"requests_per_minute": 30},
        })
        assert cfg.rate_limit.requests_per_minute == 30

    def test_config_per_client_rate_limit(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {
                    "provider": "openai",
                    "model": "gpt-4o",
                    "rate_limit": {"requests_per_minute": 10},
                },
            },
        })
        assert cfg.clients.target.rate_limit.requests_per_minute == 10

    def test_config_logging_defaults(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
        })
        assert cfg.logging.level == "WARNING"
        assert cfg.logging.format == "text"
        assert cfg.logging.output == "stderr"

    def test_config_logging_custom(self):
        from space_evals.models.config import Config

        cfg = Config.model_validate({
            "clients": {
                "target": {"provider": "openai", "model": "gpt-4o"},
            },
            "logging": {
                "level": "DEBUG",
                "format": "json",
                "output": "/var/log/space-evals.log",
            },
        })
        assert cfg.logging.level == "DEBUG"
        assert cfg.logging.format == "json"
        assert cfg.logging.output == "/var/log/space-evals.log"

    def test_config_logging_invalid_level(self):
        from space_evals.models.config import Config

        with pytest.raises(ValidationError):
            Config.model_validate({
                "clients": {
                    "target": {"provider": "openai", "model": "gpt-4o"},
                },
                "logging": {"level": "VERBOSE"},
            })
