"""Tests for the event bus system."""

from space_evals.events import Event, EventBus, EventType


class RecordingListener:
    def __init__(self):
        self.events: list[Event] = []

    def on_event(self, event: Event) -> None:
        self.events.append(event)


class TestEventBus:
    def test_emits_to_subscriber(self):
        bus = EventBus()
        listener = RecordingListener()
        bus.subscribe(listener)

        event = Event(event_type=EventType.TEST_STARTED, test_id="t1", data={"x": 1})
        bus.emit(event)

        assert len(listener.events) == 1
        assert listener.events[0].test_id == "t1"

    def test_emits_to_multiple_subscribers(self):
        bus = EventBus()
        l1 = RecordingListener()
        l2 = RecordingListener()
        bus.subscribe(l1)
        bus.subscribe(l2)

        bus.emit(Event(event_type=EventType.RUN_STARTED, test_id="r1"))

        assert len(l1.events) == 1
        assert len(l2.events) == 1

    def test_unsubscribe(self):
        bus = EventBus()
        listener = RecordingListener()
        bus.subscribe(listener)
        bus.unsubscribe(listener)

        bus.emit(Event(event_type=EventType.RUN_STARTED, test_id="r1"))

        assert len(listener.events) == 0

    def test_no_subscribers_does_not_error(self):
        bus = EventBus()
        bus.emit(Event(event_type=EventType.RUN_STARTED, test_id="r1"))

    def test_bad_listener_does_not_block_others(self):
        class FailingListener:
            def on_event(self, event: Event) -> None:
                raise RuntimeError("exploded")

        bus = EventBus()
        recorder = RecordingListener()
        bus.subscribe(FailingListener())
        bus.subscribe(recorder)

        bus.emit(Event(event_type=EventType.RUN_STARTED, test_id="r1"))

        assert len(recorder.events) == 1

    def test_double_unsubscribe_is_safe(self):
        bus = EventBus()
        listener = RecordingListener()
        bus.subscribe(listener)
        bus.unsubscribe(listener)
        bus.unsubscribe(listener)  # should not raise

    def test_unsubscribe_nonexistent_is_safe(self):
        bus = EventBus()
        listener = RecordingListener()
        bus.unsubscribe(listener)  # should not raise
