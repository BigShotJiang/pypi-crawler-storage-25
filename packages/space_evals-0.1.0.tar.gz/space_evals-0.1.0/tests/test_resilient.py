"""Tests for retry, rate limiting, and the ResilientClient wrapper."""

import pytest

from space_evals.clients.base import BaseClient, ClientResponse, Message
from space_evals.clients.resilient import (
    ResilientClient,
    RetryHandler,
    TokenBucketRateLimiter,
)
from space_evals.models.config import RetryConfig


# -- Helpers --


class FailNTimesClient(BaseClient):
    """Fails the first *n* calls with *exc*, then succeeds."""

    def __init__(self, fail_count: int, exc: Exception) -> None:
        self.fail_count = fail_count
        self.exc = exc
        self.call_count = 0

    async def send(self, messages: list[Message], system_prompt: str = "") -> ClientResponse:
        self.call_count += 1
        if self.call_count <= self.fail_count:
            raise self.exc
        return ClientResponse(content="ok")


class _HttpError(Exception):
    """Simulates a provider SDK error with a status_code attribute."""

    def __init__(self, status_code: int) -> None:
        super().__init__(f"HTTP {status_code}")
        self.status_code = status_code


# -- RetryHandler unit tests --


class TestRetryHandler:
    def test_network_errors_are_retryable(self):
        handler = RetryHandler(RetryConfig())
        assert handler.is_retryable(ConnectionError("reset"))
        assert handler.is_retryable(TimeoutError("timed out"))
        assert handler.is_retryable(OSError("network unreachable"))

    def test_429_is_retryable(self):
        handler = RetryHandler(RetryConfig())
        assert handler.is_retryable(_HttpError(429))

    def test_503_is_retryable(self):
        handler = RetryHandler(RetryConfig())
        assert handler.is_retryable(_HttpError(503))

    def test_400_not_retryable(self):
        handler = RetryHandler(RetryConfig())
        assert not handler.is_retryable(_HttpError(400))

    def test_401_not_retryable(self):
        handler = RetryHandler(RetryConfig())
        assert not handler.is_retryable(_HttpError(401))

    def test_generic_exception_not_retryable(self):
        handler = RetryHandler(RetryConfig())
        assert not handler.is_retryable(ValueError("bad"))

    def test_delay_increases_exponentially(self):
        handler = RetryHandler(RetryConfig(base_delay=1.0, max_delay=60.0))
        delays = [handler.delay_for_attempt(i) for i in range(5)]
        # Each delay should be roughly 2x the previous (with jitter < 10%).
        for i in range(1, len(delays)):
            assert delays[i] > delays[i - 1]

    def test_delay_capped_at_max(self):
        handler = RetryHandler(RetryConfig(base_delay=1.0, max_delay=5.0))
        delay = handler.delay_for_attempt(100)
        assert delay <= 5.0 * 1.1  # max + 10% jitter

    def test_custom_retryable_status_codes(self):
        handler = RetryHandler(RetryConfig(retryable_status_codes=[500, 502]))
        assert handler.is_retryable(_HttpError(500))
        assert not handler.is_retryable(_HttpError(429))


# -- ResilientClient retry tests --


class TestResilientClientRetry:
    @pytest.mark.asyncio
    async def test_no_retry_on_success(self):
        inner = FailNTimesClient(0, _HttpError(429))
        client = ResilientClient(
            inner=inner,
            retry_handler=RetryHandler(RetryConfig(max_retries=3)),
        )
        result = await client.send([Message(role="user", content="hi")])
        assert result.content == "ok"
        assert inner.call_count == 1

    @pytest.mark.asyncio
    async def test_retries_on_transient_error(self):
        inner = FailNTimesClient(2, _HttpError(429))
        client = ResilientClient(
            inner=inner,
            retry_handler=RetryHandler(RetryConfig(max_retries=3, base_delay=0.01)),
        )
        result = await client.send([Message(role="user", content="hi")])
        assert result.content == "ok"
        assert inner.call_count == 3  # 2 failures + 1 success

    @pytest.mark.asyncio
    async def test_exhausts_retries_then_raises(self):
        inner = FailNTimesClient(10, _HttpError(429))
        client = ResilientClient(
            inner=inner,
            retry_handler=RetryHandler(RetryConfig(max_retries=2, base_delay=0.01)),
        )
        with pytest.raises(_HttpError):
            await client.send([Message(role="user", content="hi")])
        assert inner.call_count == 3  # 1 initial + 2 retries

    @pytest.mark.asyncio
    async def test_no_retry_on_non_transient(self):
        inner = FailNTimesClient(1, _HttpError(400))
        client = ResilientClient(
            inner=inner,
            retry_handler=RetryHandler(RetryConfig(max_retries=3, base_delay=0.01)),
        )
        with pytest.raises(_HttpError):
            await client.send([Message(role="user", content="hi")])
        assert inner.call_count == 1  # No retry for 400

    @pytest.mark.asyncio
    async def test_retries_on_connection_error(self):
        inner = FailNTimesClient(1, ConnectionError("reset"))
        client = ResilientClient(
            inner=inner,
            retry_handler=RetryHandler(RetryConfig(max_retries=2, base_delay=0.01)),
        )
        result = await client.send([Message(role="user", content="hi")])
        assert result.content == "ok"
        assert inner.call_count == 2

    @pytest.mark.asyncio
    async def test_no_retry_when_disabled(self):
        inner = FailNTimesClient(1, _HttpError(429))
        client = ResilientClient(
            inner=inner,
            retry_handler=RetryHandler(RetryConfig(max_retries=0)),
        )
        with pytest.raises(_HttpError):
            await client.send([Message(role="user", content="hi")])
        assert inner.call_count == 1

    @pytest.mark.asyncio
    async def test_no_retry_handler_at_all(self):
        inner = FailNTimesClient(1, _HttpError(429))
        client = ResilientClient(inner=inner, retry_handler=None)
        with pytest.raises(_HttpError):
            await client.send([Message(role="user", content="hi")])
        assert inner.call_count == 1


# -- TokenBucketRateLimiter tests --


class TestTokenBucketRateLimiter:
    @pytest.mark.asyncio
    async def test_first_request_not_throttled(self):
        limiter = TokenBucketRateLimiter(requests_per_minute=60)
        wait = await limiter.acquire()
        assert wait == 0.0

    @pytest.mark.asyncio
    async def test_burst_allowed(self):
        limiter = TokenBucketRateLimiter(requests_per_minute=10)
        # First 10 requests should go through without waiting.
        for _ in range(10):
            wait = await limiter.acquire()
            assert wait == 0.0

    @pytest.mark.asyncio
    async def test_throttles_after_burst(self):
        limiter = TokenBucketRateLimiter(requests_per_minute=5)
        # Drain the bucket.
        for _ in range(5):
            await limiter.acquire()
        # Next request should wait.
        wait = await limiter.acquire()
        assert wait > 0

    @pytest.mark.asyncio
    async def test_refills_over_time(self):
        limiter = TokenBucketRateLimiter(requests_per_minute=60)
        # Drain the bucket.
        for _ in range(60):
            await limiter.acquire()
        # Simulate time passing (1 second = 1 token at 60 RPM).
        limiter._last_refill -= 1.0
        wait = await limiter.acquire()
        assert wait == 0.0


# -- ResilientClient with rate limiting --


class TestResilientClientRateLimit:
    @pytest.mark.asyncio
    async def test_rate_limiter_called(self):
        from conftest import MockClient

        inner = MockClient([ClientResponse(content="ok")])
        limiter = TokenBucketRateLimiter(requests_per_minute=60)
        client = ResilientClient(inner=inner, rate_limiter=limiter)

        result = await client.send([Message(role="user", content="hi")])
        assert result.content == "ok"

    @pytest.mark.asyncio
    async def test_shared_limiter_across_clients(self):
        """Two clients sharing a limiter should contend for the same bucket."""
        limiter = TokenBucketRateLimiter(requests_per_minute=2)

        inner1 = FailNTimesClient(0, _HttpError(429))
        inner2 = FailNTimesClient(0, _HttpError(429))

        client1 = ResilientClient(inner=inner1, rate_limiter=limiter)
        client2 = ResilientClient(inner=inner2, rate_limiter=limiter)

        # First 2 requests should be immediate (burst).
        await client1.send([Message(role="user", content="hi")])
        await client2.send([Message(role="user", content="hi")])
        # Bucket is now empty — both clients used the same limiter.
        assert limiter._tokens < 1.0
