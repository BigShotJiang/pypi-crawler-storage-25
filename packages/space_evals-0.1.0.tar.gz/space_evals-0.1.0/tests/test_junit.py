"""Tests for JUnit XML output."""

import xml.etree.ElementTree as ET


from space_evals.engine import RunResult
from space_evals.junit import to_junit_xml
from space_evals.models.results import TestOutcome, TestResult
from space_evals.models.transcript import Transcript, Turn
from space_evals.models.results import GraderOutcome, GraderResult


class TestJunitXml:
    def test_basic_structure(self):
        run = RunResult(run_id="test123")
        run.results = [
            (
                TestResult(
                    test_id="test-1",
                    scenario="Test scenario",
                    test_type="scripted",
                    outcome=TestOutcome.PASSED,
                    duration_ms=100.0,
                ),
                Transcript(test_id="test-1"),
            ),
        ]

        xml_str = to_junit_xml(run)
        root = ET.fromstring(xml_str)

        assert root.tag == "testsuites"
        suite = root.find("testsuite")
        assert suite is not None
        assert suite.get("tests") == "1"
        assert suite.get("failures") == "0"
        assert suite.get("errors") == "0"

        testcase = suite.find("testcase")
        assert testcase is not None
        assert testcase.get("name") == "test-1"
        assert testcase.get("classname") == "scripted"
        assert testcase.get("time") == "0.100"

    def test_failed_test_has_failure_element(self):
        run = RunResult(run_id="test123")
        transcript = Transcript(test_id="test-1")
        turn = Turn(turn_number=1, user_message="hi", assistant_response="wrong")
        turn.grader_results.append(
            GraderResult(
                grader_type="exact_match",
                outcome=GraderOutcome.FAILED,
                message="Did not match expected response.",
            )
        )
        transcript.add_turn(turn)

        run.results = [
            (
                TestResult(
                    test_id="test-1",
                    scenario="Test",
                    test_type="scripted",
                    outcome=TestOutcome.FAILED,
                ),
                transcript,
            ),
        ]

        xml_str = to_junit_xml(run)
        root = ET.fromstring(xml_str)
        suite = root.find("testsuite")
        assert suite.get("failures") == "1"

        testcase = suite.find("testcase")
        failure = testcase.find("failure")
        assert failure is not None
        assert "Did not match" in failure.text

    def test_errored_test_has_error_element(self):
        run = RunResult(run_id="test123")
        run.results = [
            (
                TestResult(
                    test_id="test-err",
                    scenario="Test",
                    test_type="scripted",
                    outcome=TestOutcome.ERROR,
                    error="Connection refused",
                ),
                Transcript(test_id="test-err"),
            ),
        ]

        xml_str = to_junit_xml(run)
        root = ET.fromstring(xml_str)
        testcase = root.find(".//testcase")
        error = testcase.find("error")
        assert error is not None
        assert error.get("message") == "Connection refused"

    def test_multiple_tests(self):
        run = RunResult(run_id="test123")
        run.results = [
            (
                TestResult(
                    test_id="pass-1", scenario="A", test_type="scripted", outcome=TestOutcome.PASSED
                ),
                Transcript(test_id="pass-1"),
            ),
            (
                TestResult(
                    test_id="fail-1", scenario="B", test_type="scripted", outcome=TestOutcome.FAILED
                ),
                Transcript(test_id="fail-1"),
            ),
            (
                TestResult(
                    test_id="err-1",
                    scenario="C",
                    test_type="scripted",
                    outcome=TestOutcome.ERROR,
                    error="oops",
                ),
                Transcript(test_id="err-1"),
            ),
        ]

        xml_str = to_junit_xml(run)
        root = ET.fromstring(xml_str)
        suite = root.find("testsuite")
        assert suite.get("tests") == "3"
        assert suite.get("failures") == "1"
        assert suite.get("errors") == "1"
        assert len(suite.findall("testcase")) == 3

    def test_xml_declaration_present(self):
        run = RunResult(run_id="test123")
        run.results = []
        xml_str = to_junit_xml(run)
        assert xml_str.startswith("<?xml")

    def test_parameterized_test_includes_properties(self):
        run = RunResult(run_id="test123")
        run.results = [
            (
                TestResult(
                    test_id="weather[0]",
                    scenario="Weather in NYC",
                    test_type="scripted",
                    outcome=TestOutcome.PASSED,
                    parameters={"city": "NYC", "lang": "en"},
                    parent_test_id="weather",
                ),
                Transcript(test_id="weather[0]"),
            ),
        ]

        xml_str = to_junit_xml(run)
        root = ET.fromstring(xml_str)
        testcase = root.find(".//testcase")
        props = testcase.find("properties")
        assert props is not None

        prop_dict = {p.get("name"): p.get("value") for p in props.findall("property")}
        assert prop_dict["parent_test_id"] == "weather"
        assert prop_dict["city"] == "NYC"
        assert prop_dict["lang"] == "en"

    def test_non_parameterized_test_has_no_properties(self):
        run = RunResult(run_id="test123")
        run.results = [
            (
                TestResult(
                    test_id="test-1",
                    scenario="Simple test",
                    test_type="scripted",
                    outcome=TestOutcome.PASSED,
                ),
                Transcript(test_id="test-1"),
            ),
        ]

        xml_str = to_junit_xml(run)
        root = ET.fromstring(xml_str)
        testcase = root.find(".//testcase")
        assert testcase.find("properties") is None
