"""CDP-based network traffic capture using Playwright."""

from __future__ import annotations

import asyncio
import time
from urllib.parse import urlparse

from site2cli.config import get_config
from site2cli.models import (
    CapturedExchange,
    CapturedHeader,
    CapturedRequest,
    CapturedResponse,
)


class TrafficCapture:
    """Captures network traffic from browser sessions using CDP."""

    def __init__(self, target_domain: str | None = None) -> None:
        self.target_domain = target_domain
        self.exchanges: list[CapturedExchange] = []
        self._pending: dict[str, tuple[CapturedRequest, float]] = {}
        self._config = get_config()

    def _should_capture(self, url: str) -> bool:
        """Filter to only capture relevant API-like requests."""
        parsed = urlparse(url)

        # Skip static assets
        skip_extensions = {
            ".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".svg",
            ".ico", ".woff", ".woff2", ".ttf", ".eot", ".map",
        }
        path_lower = parsed.path.lower()
        if any(path_lower.endswith(ext) for ext in skip_extensions):
            return False

        # If we have a target domain, filter to it
        if self.target_domain:
            target = self.target_domain.replace("www.", "")
            host = parsed.hostname or ""
            host = host.replace("www.", "")
            if target not in host:
                return False

        return True

    def _is_api_like(self, url: str, content_type: str | None) -> bool:
        """Check if a request looks like an API call."""
        if content_type and any(
            t in content_type
            for t in [
                "application/json",
                "application/xml",
                "text/xml",
                "application/ld+json",
                "application/hal+json",
                "application/vnd.",
            ]
        ):
            return True
        parsed = urlparse(url)
        path = parsed.path.lower()
        api_indicators = [
            "/api/", "/v1/", "/v1.", "/v2/", "/v2.", "/v3/", "/v3.",
            "/graphql", "/rest/", "/ajax/", "/data/", "/feed/",
        ]
        return any(ind in path for ind in api_indicators)

    def _ensure_playwright(self):
        try:
            from playwright.async_api import async_playwright
            return async_playwright
        except ImportError:
            raise ImportError(
                "Playwright is required for browser capture. "
                "Install it with: pip install site2cli[browser]"
            )

    async def capture_page_traffic(
        self,
        url: str,
        interaction_callback: callable | None = None,
        duration_seconds: int = 30,
        *,
        profile: str | None = None,
        inject_cookies_for: str | None = None,
    ) -> list[CapturedExchange]:
        """Launch browser, navigate to URL, capture traffic.

        Args:
            url: The URL to navigate to.
            interaction_callback: Optional async function(page) to interact with the page.
            duration_seconds: How long to wait for traffic if no callback.
            profile: Browser profile name to use.
            inject_cookies_for: Domain to inject stored cookies for.

        Returns:
            List of captured request/response exchanges.
        """
        config = self._config
        self._ensure_playwright()
        from site2cli.browser.context import create_browser_context

        cookie_domain = inject_cookies_for or self.target_domain
        async with create_browser_context(
            profile=profile or config.browser.profile,
            inject_cookies_for=cookie_domain,
        ) as (browser, context, page):

            # Set up CDP network interception
            client = await context.new_cdp_session(page)
            await client.send("Network.enable")

            request_data: dict[str, dict] = {}

            def on_request_will_be_sent(params: dict) -> None:
                req = params.get("request", {})
                url = req.get("url", "")
                if not self._should_capture(url):
                    return
                request_id = params.get("requestId", "")
                headers = [
                    CapturedHeader(name=k, value=v)
                    for k, v in req.get("headers", {}).items()
                ]
                body = params.get("request", {}).get("postData")
                ct = req.get("headers", {}).get("Content-Type") or req.get(
                    "headers", {}
                ).get("content-type")
                request_data[request_id] = {
                    "request": CapturedRequest(
                        method=req.get("method", "GET"),
                        url=url,
                        headers=headers,
                        body=body,
                        content_type=ct,
                        timestamp=params.get("timestamp", time.time()),
                    ),
                    "start_time": time.time(),
                }

            async def on_response_received(params: dict) -> None:
                request_id = params.get("requestId", "")
                if request_id not in request_data:
                    return
                response = params.get("response", {})
                resp_ct = response.get("headers", {}).get("content-type", "")

                # Only capture API-like responses
                req_info = request_data[request_id]
                if not self._is_api_like(req_info["request"].url, resp_ct):
                    return

                # Try to get response body
                body = None
                try:
                    result = await client.send(
                        "Network.getResponseBody", {"requestId": request_id}
                    )
                    body = result.get("body")
                except Exception:
                    pass

                resp_headers = [
                    CapturedHeader(name=k, value=v)
                    for k, v in response.get("headers", {}).items()
                ]
                captured_resp = CapturedResponse(
                    status=response.get("status", 0),
                    headers=resp_headers,
                    body=body,
                    content_type=resp_ct,
                )
                duration = (time.time() - req_info["start_time"]) * 1000
                self.exchanges.append(
                    CapturedExchange(
                        request=req_info["request"],
                        response=captured_resp,
                        duration_ms=duration,
                    )
                )

            client.on("Network.requestWillBeSent", on_request_will_be_sent)
            client.on(
                "Network.responseReceived",
                lambda p: asyncio.ensure_future(on_response_received(p)),
            )

            # Navigate (fall back to domcontentloaded if networkidle times out)
            try:
                await page.goto(
                    url, wait_until="networkidle", timeout=config.browser.timeout_ms
                )
            except Exception:
                await page.goto(
                    url, wait_until="domcontentloaded", timeout=config.browser.timeout_ms
                )
                await page.wait_for_timeout(3000)

            # Dismiss cookie banners before interaction
            try:
                from site2cli.browser.cookie_banner import dismiss_cookie_banner

                await dismiss_cookie_banner(page)
            except Exception:
                pass

            # Detect auth pages and log warning
            try:
                from site2cli.browser.detectors import detect_auth_page

                auth_result = await detect_auth_page(page)
                if auth_result.detected:
                    import logging

                    logging.getLogger("site2cli").warning(
                        "Auth page detected (%s). Some traffic may still be captured.",
                        auth_result.kind,
                    )
            except Exception:
                pass

            if interaction_callback:
                await interaction_callback(page)
            else:
                # Wait for dynamic content and API calls
                await page.wait_for_timeout(
                    min(duration_seconds * 1000, config.browser.timeout_ms)
                )

            # Auto-probe: if no API exchanges captured, discover and fetch
            # API-like links from the page (handles static doc homepages)
            if not self.exchanges:
                await self._auto_probe_links(page)

        return self.exchanges

    async def _auto_probe_links(self, page) -> None:
        """Discover API-like links on the page and fetch them to capture traffic.

        When a homepage is static documentation (no XHR on load), this finds
        links that point to API endpoints and navigates to them.
        """
        try:
            links = await page.evaluate("""() => {
                const anchors = document.querySelectorAll('a[href]');
                const seen = new Set();
                const results = [];
                for (const a of anchors) {
                    const href = a.href;
                    if (!href || seen.has(href)) continue;
                    seen.add(href);
                    results.push(href);
                }
                return results;
            }""")

            # Filter to API-like links on the target domain
            api_links = []
            rest_links = []
            for link in links:
                parsed = urlparse(link)
                host = (parsed.hostname or "").replace("www.", "")
                target = (self.target_domain or "").replace("www.", "")
                if target and target not in host:
                    continue
                if not self._should_capture(link):
                    continue
                path = parsed.path.lower().rstrip("/")
                if not path or path == urlparse(page.url).path.lower().rstrip("/"):
                    continue  # skip current page
                # Priority 1: paths with API indicators
                if any(
                    ind in path
                    for ind in [
                        "/api/", "/v1/", "/v1.", "/v2/", "/v2.", "/v3/", "/v3.",
                        "/graphql", "/rest/", "/data/", "/feed/",
                    ]
                ):
                    api_links.append(link)
                # Priority 2: clean REST-like paths (e.g., /posts, /users)
                # Single-segment, no extension, no query — likely REST resources
                elif (
                    path.count("/") == 1
                    and "." not in path.split("/")[-1]
                    and not parsed.query
                ):
                    rest_links.append(link)

            # Probe API-indicator links first, then REST-like paths
            probe_links = api_links[:5] or rest_links[:5]
            for link in probe_links:
                try:
                    await page.goto(
                        link,
                        wait_until="networkidle",
                        timeout=10000,
                    )
                    await page.wait_for_timeout(500)
                except Exception:
                    pass
        except Exception:
            pass

    def get_api_exchanges(self) -> list[CapturedExchange]:
        """Return only exchanges that look like API calls."""
        return [
            ex
            for ex in self.exchanges
            if self._is_api_like(ex.request.url, ex.response.content_type)
        ]

    def summarize(self) -> dict:
        """Return a summary of captured traffic."""
        api_exchanges = self.get_api_exchanges()
        endpoints: dict[str, int] = {}
        for ex in api_exchanges:
            parsed = urlparse(ex.request.url)
            key = f"{ex.request.method} {parsed.path}"
            endpoints[key] = endpoints.get(key, 0) + 1

        return {
            "total_requests": len(self.exchanges),
            "api_requests": len(api_exchanges),
            "unique_endpoints": len(endpoints),
            "endpoints": endpoints,
        }
