"""
Shape-related proxy classes.

Provides python-pptx-compatible Shape and Shapes collection abstractions.
"""

from __future__ import annotations
import base64
from io import BytesIO
from pathlib import Path
from typing import TYPE_CHECKING, Any, Iterator, Optional, Union

from .commands import (
    AddTextBox, DeleteShape, SetTransform, AddShape as AddShapeCmd,
    SetShapeStyle, AddPicture as AddPictureCmd, AddTable as AddTableCmd,
    SetTableCell, SetTableRowCount, SetShapeShadow, SetGradientFill,
    SetShapeZOrder, AddConnector as AddConnectorCmd, SetShapeName,
    SetClickAction, CloneShape, GroupShapes, UngroupShapes, SetPictureCrop,
    SetShapeAdjustments, MergeCells as MergeCellsCmd,
    SplitCell as SplitCellCmd, SetCellMargins, SetColWidth, SetRowHeight,
    SetShapeAdjustments, SubstitutePlaceholder,
    UpdateChartData as UpdateChartDataCmd, AddChart as AddChartCmd,
)
from .chart.data import CategoryChartData, ChartData
from .dml.color import RGBColor, ColorFormat
from .errors import UnsupportedFeatureError
from .text import TextFrame
from .typing import ElementSnapshot, ShapeId, Transform, PlaceholderSnapshot, PP_PLACEHOLDER
from .units import Emu, Length, ensure_emu

if TYPE_CHECKING:
    from .batching import CommandBuffer
    from .slides import Slide


# Re-export MSO_SHAPE IntEnum from the canonical enum module so that both
# ``from pptx.shapes import MSO_SHAPE`` and
# ``from pptx.enum.shapes import MSO_SHAPE`` resolve to the same IntEnum.
from .enum.shapes import MSO_SHAPE, MSO_SHAPE_TYPE  # noqa: F811
from .enum.chart import XL_CHART_TYPE


# Map our internal element-type discriminants ('text', 'image', etc.) to the
# python-pptx ``MSO_SHAPE_TYPE`` integer enum. Placeholders override this and
# return ``PLACEHOLDER`` regardless of the underlying element type, matching
# python-pptx behaviour.
_ELEMENT_TYPE_TO_MSO_SHAPE_TYPE: dict[str, MSO_SHAPE_TYPE] = {
    "text": MSO_SHAPE_TYPE.TEXT_BOX,
    "image": MSO_SHAPE_TYPE.PICTURE,
    "shape": MSO_SHAPE_TYPE.AUTO_SHAPE,
    "table": MSO_SHAPE_TYPE.TABLE,
    "chart": MSO_SHAPE_TYPE.CHART,
    "group": MSO_SHAPE_TYPE.GROUP,
    "connector": MSO_SHAPE_TYPE.LINE,
}


# Map XL_CHART_TYPE → (server chart_type, grouping). Only the chart types
# author.ts supports today are listed here; anything else raises
# UnsupportedFeatureError. Surface area mirrors python-pptx's accepted enum
# values so callers can switch between python-pptx and athena-python-pptx
# without code changes for the supported subset.
_CHART_TYPE_MAP: dict[int, tuple[str, Optional[str]]] = {
    XL_CHART_TYPE.COLUMN_CLUSTERED: ("column", "clustered"),
    XL_CHART_TYPE.COLUMN_STACKED: ("column", "stacked"),
    XL_CHART_TYPE.COLUMN_STACKED_100: ("column", "percentStacked"),
    XL_CHART_TYPE.BAR_CLUSTERED: ("bar", "clustered"),
    XL_CHART_TYPE.BAR_STACKED: ("bar", "stacked"),
    XL_CHART_TYPE.BAR_STACKED_100: ("bar", "percentStacked"),
    XL_CHART_TYPE.LINE: ("line", "clustered"),
    XL_CHART_TYPE.LINE_MARKERS: ("line", "clustered"),
    XL_CHART_TYPE.LINE_STACKED: ("line", "stacked"),
    XL_CHART_TYPE.LINE_STACKED_100: ("line", "percentStacked"),
    XL_CHART_TYPE.AREA: ("area", "clustered"),
    XL_CHART_TYPE.AREA_STACKED: ("area", "stacked"),
    XL_CHART_TYPE.AREA_STACKED_100: ("area", "percentStacked"),
    XL_CHART_TYPE.PIE: ("pie", None),
    XL_CHART_TYPE.DOUGHNUT: ("doughnut", None),
    # Scatter / bubble — XY data shape (no category axis). All scatter
    # variants map to the same server chart_type "scatter" since the
    # author path currently emits a single style; line-vs-marker styling
    # is a follow-up via `Series.smooth` / `Series.marker`.
    XL_CHART_TYPE.XY_SCATTER: ("scatter", None),
    XL_CHART_TYPE.XY_SCATTER_LINES: ("scatter", None),
    XL_CHART_TYPE.XY_SCATTER_LINES_NO_MARKERS: ("scatter", None),
    XL_CHART_TYPE.XY_SCATTER_SMOOTH: ("scatter", None),
    XL_CHART_TYPE.XY_SCATTER_SMOOTH_NO_MARKERS: ("scatter", None),
    XL_CHART_TYPE.BUBBLE: ("bubble", None),
}


def _split_chart_type(chart_type: Any) -> tuple[str, Optional[str]]:
    """
    Resolve a `XL_CHART_TYPE` (or matching int / str) into the server's
    `(chart_type, grouping)` pair. Raises `UnsupportedFeatureError` for
    chart types the author.ts path does not yet emit (3-D variants,
    radar, stock, combo, surface).
    """
    if isinstance(chart_type, str):
        normalized = chart_type.lower().strip()
        if normalized in {"column", "bar", "line", "area"}:
            return normalized, "clustered"
        if normalized in {"pie", "doughnut", "scatter", "bubble"}:
            return normalized, None
        raise UnsupportedFeatureError(
            "add_chart",
            f"Unsupported chart type string '{chart_type}'. "
            "Use one of: 'column', 'bar', 'line', 'area', 'pie', 'doughnut', 'scatter', 'bubble'.",
        )
    try:
        key = int(chart_type)
    except (TypeError, ValueError):
        raise UnsupportedFeatureError(
            "add_chart",
            f"Unsupported chart_type value: {chart_type!r}",
        )
    mapped = _CHART_TYPE_MAP.get(key)
    if mapped is None:
        raise UnsupportedFeatureError(
            "add_chart",
            f"Chart type {chart_type!r} is not supported by the SDK author "
            "path. Supported XL_CHART_TYPE values: COLUMN_CLUSTERED, "
            "COLUMN_STACKED, COLUMN_STACKED_100, BAR_CLUSTERED, BAR_STACKED, "
            "BAR_STACKED_100, LINE, LINE_MARKERS, LINE_STACKED, "
            "LINE_STACKED_100, AREA, AREA_STACKED, AREA_STACKED_100, PIE, "
            "DOUGHNUT, XY_SCATTER (and variants), BUBBLE.",
        )
    return mapped


def _coerce_chart_type(chart_type: Any) -> str:
    """Backward-compatible single-string accessor."""
    return _split_chart_type(chart_type)[0]


class PlaceholderFormat:
    """
    Provides access to placeholder-specific properties.

    Mirrors python-pptx's _PlaceholderFormat class.
    """

    def __init__(self, placeholder_snapshot: PlaceholderSnapshot):
        self._type_str = placeholder_snapshot.type
        self._idx = placeholder_snapshot.idx
        self._sz = placeholder_snapshot.sz
        self._orient = placeholder_snapshot.orient
        self._has_custom_prompt = placeholder_snapshot.has_custom_prompt
        self._local_transform_override = placeholder_snapshot.local_transform_override

    @property
    def type(self) -> PP_PLACEHOLDER:
        """
        Placeholder type as PP_PLACEHOLDER enumeration member.

        Returns the placeholder type (e.g., PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.BODY).
        """
        return PP_PLACEHOLDER.from_ooxml_type(self._type_str)

    @property
    def idx(self) -> int:
        """
        Integer placeholder index.

        This value is unique for each placeholder on a slide and remains stable
        when the slide layout is changed.
        """
        return self._idx

    @property
    def sz(self) -> Optional[str]:
        """
        Placeholder size as OOXML string.

        Common values: 'full', 'half', 'quarter'.
        Returns None if not specified.
        """
        return self._sz

    @property
    def orient(self) -> Optional[str]:
        """
        Placeholder orientation as OOXML string.

        Values: 'horz' (default) or 'vert'.
        Returns None if not specified (treated as 'horz').
        """
        return self._orient

    @property
    def has_custom_prompt(self) -> bool:
        """
        True if this placeholder has a custom prompt text.

        Custom prompts override the default "Click to add..." text.
        """
        return self._has_custom_prompt or False

    @property
    def local_transform_override(self) -> bool:
        """
        True if this shape has its own transform rather than inheriting from layout.

        When False, the shape's position/size is inherited from the layout placeholder.
        """
        return self._local_transform_override or False

    # -------------------------------------------------------------------------
    # Convenience properties
    # -------------------------------------------------------------------------

    @property
    def is_title(self) -> bool:
        """True if this is a title placeholder."""
        return self._type_str in ('title', 'ctrTitle') or self._idx == 0

    @property
    def is_body(self) -> bool:
        """True if this is a body/content placeholder."""
        return self._type_str == 'body' or self._idx == 1

    @property
    def is_subtitle(self) -> bool:
        """True if this is a subtitle placeholder."""
        return self._type_str == 'subTitle'

    @property
    def is_picture(self) -> bool:
        """True if this is a picture placeholder."""
        return self._type_str == 'pic'

    @property
    def is_chart(self) -> bool:
        """True if this is a chart placeholder."""
        return self._type_str == 'chart'

    @property
    def is_table(self) -> bool:
        """True if this is a table placeholder."""
        return self._type_str == 'tbl'

    @property
    def is_footer(self) -> bool:
        """True if this is a footer placeholder."""
        return self._type_str == 'ftr'

    @property
    def is_date(self) -> bool:
        """True if this is a date placeholder."""
        return self._type_str == 'dt'

    @property
    def is_slide_number(self) -> bool:
        """True if this is a slide number placeholder."""
        return self._type_str == 'sldNum'

    @property
    def type_name(self) -> str:
        """Human-readable placeholder type name."""
        type_names = {
            'title': 'Title',
            'ctrTitle': 'Center Title',
            'subTitle': 'Subtitle',
            'body': 'Body',
            'pic': 'Picture',
            'chart': 'Chart',
            'tbl': 'Table',
            'dgm': 'Diagram',
            'media': 'Media',
            'clipArt': 'Clip Art',
            'ftr': 'Footer',
            'dt': 'Date',
            'sldNum': 'Slide Number',
            'hdr': 'Header',
        }
        return type_names.get(self._type_str, self._type_str or 'Unknown')

    def __repr__(self) -> str:
        return f"<PlaceholderFormat idx={self._idx} type={self._type_str}>"


class _FillColorFormat(ColorFormat):
    """
    ColorFormat subclass that notifies FillFormat when color changes.
    """

    def __init__(self, fill_format: "FillFormat", rgb: Optional[RGBColor] = None):
        super().__init__(rgb=rgb)
        self._fill_format = fill_format

    @ColorFormat.rgb.setter
    def rgb(self, value: RGBColor) -> None:
        """Set the RGB color and notify the fill format."""
        if not isinstance(value, RGBColor):
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._rgb = value
        self._theme_color = None
        self._fill_format._on_color_change(str(value))

    @ColorFormat.theme_color.setter
    def theme_color(self, value) -> None:
        """Set the theme/scheme color and notify the fill format.

        ``value`` is an ``MSO_THEME_COLOR`` enum (e.g.
        ``MSO_THEME_COLOR.ACCENT_1``); we translate it to the OOXML
        scheme-color name (``"accent1"``) before forwarding so the
        applier doesn't have to know the enum mapping.
        """
        from .dml.color import theme_color_to_scheme_name
        self._theme_color = value
        self._rgb = None
        scheme_name = theme_color_to_scheme_name(value)
        if scheme_name:
            self._fill_format._on_scheme_color_change(scheme_name)


class FillFormat:
    """
    Fill formatting for a shape.

    Provides access to shape fill properties like color and transparency.
    Mirrors python-pptx's FillFormat class.
    """

    def __init__(self, shape: Shape):
        self._shape = shape
        self._solid_color: Optional[str] = shape._properties.get("fillColorHex")
        self._transparency: float = 0.0
        self._type: Optional[str] = 'solid' if self._solid_color else None
        # Initialize fore_color ColorFormat
        rgb = RGBColor.from_string(self._solid_color) if self._solid_color else None
        self._fore_color_format = _FillColorFormat(self, rgb=rgb)

    def solid(self) -> None:
        """
        Set fill to solid color mode.

        After calling this method, set the color using ``fore_color.rgb``.

        Example::

            shape.fill.solid()
            shape.fill.fore_color.rgb = RGBColor(0xFF, 0x00, 0x00)
        """
        self._type = 'solid'
        # Default to white if no color set
        if self._solid_color is None:
            self._solid_color = 'FFFFFF'
            self._fore_color_format._rgb = RGBColor(255, 255, 255)

    @property
    def type(self) -> Optional[str]:
        """
        Fill type ('solid', 'gradient', 'pattern', or None for no fill).
        """
        return self._type

    @property
    def fore_color(self) -> _FillColorFormat:
        """
        Foreground (fill) color as a ColorFormat object.

        Use `fore_color.rgb = RGBColor(...)` to set the color.
        """
        return self._fore_color_format

    def _on_color_change(self, hex_value: str) -> None:
        """Called by ColorFormat when an sRGB color is set."""
        self._solid_color = hex_value.upper()
        self._scheme_color: Optional[str] = None
        self._type = 'solid'
        self._emit_style_change()

    def _on_scheme_color_change(self, scheme_name: str) -> None:
        """Called by ColorFormat when a theme/scheme color is set."""
        self._scheme_color = scheme_name
        self._solid_color = None
        self._type = 'solid'
        self._emit_style_change()

    def background(self) -> None:
        """Remove fill (make transparent/background)."""
        self._solid_color = None
        self._type = None
        self._fore_color_format._rgb = None
        self._emit_style_change()

    def patterned(self) -> None:
        """
        Set fill to pattern mode.

        After calling this method, set the pattern and colors using
        ``pattern``, ``fore_color``, and ``back_color`` properties.
        """
        self._type = 'patterned'
        if not hasattr(self, '_pattern'):
            self._pattern = None
        if not hasattr(self, '_back_color_format'):
            self._back_color_format = _FillColorFormat(self)

    @property
    def pattern(self):
        """Pattern type (MSO_PATTERN member or None)."""
        return getattr(self, '_pattern', None)

    @pattern.setter
    def pattern(self, value) -> None:
        self._pattern = value

    @property
    def back_color(self) -> "_FillColorFormat":
        """Background color for pattern fills."""
        if not hasattr(self, '_back_color_format'):
            self._back_color_format = _FillColorFormat(self)
        return self._back_color_format

    # -------------------------------------------------------------------------
    # Phase 3: Gradient fills
    # -------------------------------------------------------------------------

    def gradient(self) -> None:
        """
        Set fill to gradient mode.

        After calling this, configure the gradient using gradient_angle and
        gradient_stops properties.

        Example:
            shape.fill.gradient()
            shape.fill.gradient_angle = 45
            shape.fill.gradient_stops = [
                {'position': 0.0, 'color': RGBColor(255, 0, 0)},
                {'position': 1.0, 'color': RGBColor(0, 0, 255)},
            ]
        """
        self._type = 'gradient'
        if not hasattr(self, '_gradient_type'):
            self._gradient_type = 'linear'
        if not hasattr(self, '_gradient_angle'):
            self._gradient_angle = 0.0
        if not hasattr(self, '_gradient_stops'):
            self._gradient_stops = [
                {'position': 0.0, 'color_hex': 'FFFFFF'},
                {'position': 1.0, 'color_hex': '000000'},
            ]

    @property
    def gradient_angle(self) -> float:
        """
        Gradient rotation angle in degrees (for linear gradients).

        0 = left to right, 90 = top to bottom, 180 = right to left, etc.
        """
        return getattr(self, '_gradient_angle', 0.0)

    @gradient_angle.setter
    def gradient_angle(self, value: float) -> None:
        """Set gradient angle."""
        self._gradient_angle = value % 360
        if self._type == 'gradient':
            self._emit_gradient_change()

    @property
    def gradient_stops(self) -> list[dict]:
        """
        Gradient color stops.

        Each stop is a dict with 'position' (0.0-1.0) and 'color_hex' or 'color'.
        """
        return getattr(self, '_gradient_stops', [])

    @gradient_stops.setter
    def gradient_stops(self, stops: list[dict]) -> None:
        """
        Set gradient stops.

        Args:
            stops: List of dicts with 'position' (0.0-1.0) and either
                   'color_hex' (string) or 'color' (RGBColor)
        """
        normalized = []
        for stop in stops:
            pos = stop.get('position', 0.0)
            if 'color_hex' in stop:
                color_hex = stop['color_hex']
            elif 'color' in stop:
                color_hex = str(stop['color']).upper()
            else:
                color_hex = 'FFFFFF'
            normalized.append({'position': pos, 'color_hex': color_hex})
        self._gradient_stops = normalized
        if self._type == 'gradient':
            self._emit_gradient_change()

    def _emit_gradient_change(self) -> None:
        """Emit a SetGradientFill command."""
        if self._shape._buffer:
            cmd = SetGradientFill(
                shape_id=self._shape._shape_id,
                gradient_type=getattr(self, '_gradient_type', 'linear'),
                angle_deg=getattr(self, '_gradient_angle', 0.0),
                stops=getattr(self, '_gradient_stops', None),
            )
            self._shape._buffer.add(cmd)

    def _emit_style_change(self) -> None:
        """Emit a SetShapeStyle command for fill changes."""
        if self._shape._buffer:
            cmd = SetShapeStyle(
                shape_id=self._shape._shape_id,
                fill_color_hex=self._solid_color,
                fill_scheme_color=getattr(self, '_scheme_color', None),
                fill_transparency=None,
            )
            self._shape._buffer.add(cmd)


class _LineColorFormat(ColorFormat):
    """
    ColorFormat subclass that notifies LineFormat when color changes.
    """

    def __init__(self, line_format: "LineFormat", rgb: Optional[RGBColor] = None):
        super().__init__(rgb=rgb)
        self._line_format = line_format

    @ColorFormat.rgb.setter
    def rgb(self, value: RGBColor) -> None:
        """Set the RGB color and notify the line format."""
        if not isinstance(value, RGBColor):
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._rgb = value
        self._theme_color = None
        self._line_format._on_color_change(str(value))

    @ColorFormat.theme_color.setter
    def theme_color(self, value) -> None:
        """Set the theme/scheme color and notify the line format.

        ``value`` is an ``MSO_THEME_COLOR`` enum; we translate to the
        OOXML scheme-color name before forwarding so the line render
        comes from the deck's theme rather than a hard-coded sRGB.
        """
        from .dml.color import theme_color_to_scheme_name
        self._theme_color = value
        self._rgb = None
        scheme_name = theme_color_to_scheme_name(value)
        if scheme_name:
            self._line_format._on_scheme_color_change(scheme_name)


class LineFormat:
    """
    Line formatting for a shape.

    Provides access to shape outline/border properties.
    Mirrors python-pptx's LineFormat class.
    """

    def __init__(self, shape: Shape):
        self._shape = shape
        self._color_hex: Optional[str] = shape._properties.get("strokeColorHex")
        self._width_emu: int = shape._properties.get("strokeWidthEmu", 12700)  # Default 1pt
        self._dash_style: str = 'solid'
        # Initialize color ColorFormat
        rgb = RGBColor.from_string(self._color_hex) if self._color_hex else None
        self._color_format = _LineColorFormat(self, rgb=rgb)

    @property
    def color(self) -> _LineColorFormat:
        """
        Line color as a ColorFormat object.

        Use `line.color.rgb = RGBColor(...)` to set the color,
        or `line.color = "FF0000"` for direct hex string assignment.
        """
        return self._color_format

    @color.setter
    def color(self, value: Optional[str]) -> None:
        """
        Set line color with a hex string.

        Args:
            value: Hex color string (e.g., "FF0000" or "#FF0000"), or None to clear.
        """
        if value is None:
            self._color_hex = None
            self._color_format._rgb = None
        else:
            if value.startswith('#'):
                value = value[1:]
            self._color_hex = value.upper()
            self._color_format._rgb = RGBColor.from_string(value)
        self._emit_style_change()

    def _on_color_change(self, hex_value: str) -> None:
        """Called by ColorFormat when an sRGB color is set."""
        self._color_hex = hex_value.upper()
        self._scheme_color: Optional[str] = None
        self._emit_style_change()

    def _on_scheme_color_change(self, scheme_name: str) -> None:
        """Called by ColorFormat when a theme/scheme color is set."""
        self._scheme_color = scheme_name
        self._color_hex = None
        self._emit_style_change()

    @property
    def width(self) -> Emu:
        """Line width in EMU."""
        return Emu(self._width_emu)

    @width.setter
    def width(self, value: Length) -> None:
        """Set line width."""
        self._width_emu = int(ensure_emu(value))
        self._emit_style_change()

    @property
    def dash_style(self) -> str:
        """Line dash style ('solid', 'dash', 'dot', 'dash_dot', 'long_dash', 'long_dash_dot')."""
        return self._dash_style

    @dash_style.setter
    def dash_style(self, value: Any) -> None:
        """
        Set line dash style.

        Args:
            value: Dash style - either a string ('solid', 'dash', 'dot', etc.)
                   or MSO_LINE_DASH_STYLE enum value
        """
        # Handle MSO_LINE_DASH_STYLE enum values (integers)
        if isinstance(value, int):
            # MSO_LINE_DASH_STYLE: SOLID=1, SQUARE_DOT=2, ROUND_DOT=3, DASH=4,
            # DASH_DOT=5, LONG_DASH=6, LONG_DASH_DOT=7, LONG_DASH_DOT_DOT=8
            int_to_str = {
                1: 'solid',
                2: 'dot',         # SQUARE_DOT
                3: 'dot',         # ROUND_DOT
                4: 'dash',
                5: 'dash_dot',
                6: 'long_dash',
                7: 'long_dash_dot',
                8: 'long_dash_dot',  # LONG_DASH_DOT_DOT -> long_dash_dot
            }
            value = int_to_str.get(value, 'solid')

        valid = ('solid', 'dash', 'dot', 'dash_dot', 'long_dash', 'long_dash_dot')
        if value not in valid:
            raise ValueError(f"Invalid dash_style: {value}. Must be one of {valid}")
        self._dash_style = value
        self._emit_style_change()

    @property
    def fill(self) -> "LineFillFormat":
        """
        Fill format for the line itself (for thick lines with patterns/gradients).

        For simple solid-color lines, use `line.color.rgb` instead.
        """
        if not hasattr(self, '_fill_format'):
            self._fill_format = LineFillFormat(self)
        return self._fill_format

    def _no_fill(self) -> None:
        """Remove the line (no outline). Internal — use line.fill.background()."""
        self._color_hex = None
        self._color_format._rgb = None
        self._width_emu = 0
        self._emit_style_change()

    @property
    def is_solid(self) -> bool:
        """True if line style is solid."""
        return self._dash_style == 'solid'

    @property
    def is_dashed(self) -> bool:
        """True if line style is any dashed pattern."""
        return self._dash_style != 'solid'

    def _emit_style_change(self) -> None:
        """Emit a SetShapeStyle command for line changes."""
        if self._shape._buffer:
            cmd = SetShapeStyle(
                shape_id=self._shape._shape_id,
                line_color_hex=self._color_hex,
                line_scheme_color=getattr(self, '_scheme_color', None),
                line_width_emu=self._width_emu,
                line_dash=self._dash_style if self._dash_style != 'solid' else None,
            )
            self._shape._buffer.add(cmd)


class LineFillFormat:
    """
    Fill format for line fills (used for thick lines with patterns/gradients).

    For simple solid-color lines, use `line.color.rgb` instead.
    """

    def __init__(self, line_format: LineFormat):
        self._line_format = line_format
        self._type = 'solid'

    def solid(self) -> None:
        """Set solid fill for the line."""
        self._type = 'solid'

    def background(self) -> None:
        """Set background fill (transparent) for the line."""
        self._type = 'background'
        self._line_format._no_fill()

    @property
    def fore_color(self) -> _LineColorFormat:
        """Foreground color (alias for line.color for compatibility)."""
        return self._line_format.color


# -------------------------------------------------------------------------
# Phase 3: ShadowFormat class
# -------------------------------------------------------------------------

class ShadowFormat:
    """
    Shadow formatting for a shape.

    Provides access to shadow properties like visibility, blur, distance,
    direction, color, and transparency.

    Example:
        shape.shadow.visible = True
        shape.shadow.blur_radius = Pt(4)
        shape.shadow.distance = Pt(3)
        shape.shadow.direction = 45  # degrees
        shape.shadow.color = RGBColor(0, 0, 0)
        shape.shadow.transparency = 0.6
    """

    def __init__(self, shape: "Shape"):
        self._shape = shape
        self._visible: bool = False
        self._shadow_type: str = 'outer'
        self._blur_radius_emu: int = 50800  # ~4pt default
        self._distance_emu: int = 38100  # ~3pt default
        self._direction_deg: float = 45.0
        self._color_hex: str = '000000'  # Black default
        self._transparency: float = 0.6  # 60% transparent default

    @property
    def visible(self) -> bool:
        """Whether the shadow is visible."""
        return self._visible

    @visible.setter
    def visible(self, value: bool) -> None:
        """Set shadow visibility."""
        self._visible = value
        self._emit_shadow_change()

    @property
    def shadow_type(self) -> str:
        """Shadow type ('outer', 'inner', 'perspective')."""
        return self._shadow_type

    @shadow_type.setter
    def shadow_type(self, value: str) -> None:
        """Set shadow type."""
        valid = ('outer', 'inner', 'perspective')
        if value not in valid:
            raise ValueError(f"shadow_type must be one of {valid}")
        self._shadow_type = value
        self._emit_shadow_change()

    @property
    def blur_radius(self) -> Emu:
        """Shadow blur radius in EMU."""
        return Emu(self._blur_radius_emu)

    @blur_radius.setter
    def blur_radius(self, value: Length) -> None:
        """Set blur radius."""
        self._blur_radius_emu = int(ensure_emu(value))
        self._emit_shadow_change()

    @property
    def distance(self) -> Emu:
        """Shadow distance from shape in EMU."""
        return Emu(self._distance_emu)

    @distance.setter
    def distance(self, value: Length) -> None:
        """Set shadow distance."""
        self._distance_emu = int(ensure_emu(value))
        self._emit_shadow_change()

    @property
    def direction(self) -> float:
        """Shadow direction in degrees (0=right, 90=down, 180=left, 270=up)."""
        return self._direction_deg

    @direction.setter
    def direction(self, value: float) -> None:
        """Set shadow direction in degrees."""
        self._direction_deg = value % 360
        self._emit_shadow_change()

    @property
    def color(self) -> Optional[RGBColor]:
        """Shadow color as RGBColor."""
        if self._color_hex:
            return RGBColor.from_string(self._color_hex)
        return None

    @color.setter
    def color(self, value: RGBColor) -> None:
        """Set shadow color."""
        self._color_hex = str(value).upper()
        self._emit_shadow_change()

    @property
    def transparency(self) -> float:
        """Shadow transparency (0.0=opaque, 1.0=fully transparent)."""
        return self._transparency

    @transparency.setter
    def transparency(self, value: float) -> None:
        """Set shadow transparency."""
        if not (0.0 <= value <= 1.0):
            raise ValueError(f"transparency must be between 0.0 and 1.0, got {value}")
        self._transparency = value
        self._emit_shadow_change()

    def inherit(self) -> None:
        """Inherit shadow settings from the slide master/layout."""
        self._visible = False
        self._emit_shadow_change()

    def _emit_shadow_change(self) -> None:
        """Emit a SetShapeShadow command."""
        if self._shape._buffer:
            cmd = SetShapeShadow(
                shape_id=self._shape._shape_id,
                visible=self._visible,
                shadow_type=self._shadow_type,
                blur_radius_emu=self._blur_radius_emu,
                distance_emu=self._distance_emu,
                direction_deg=self._direction_deg,
                color_hex=self._color_hex,
                transparency=self._transparency,
            )
            self._shape._buffer.add(cmd)

    def __repr__(self) -> str:
        return f"<ShadowFormat visible={self._visible} type={self._shadow_type}>"


# -------------------------------------------------------------------------
# Phase 4: ClickAction class
# -------------------------------------------------------------------------

class ClickAction:
    """
    Click action (hyperlink) for a shape.

    Configures what happens when a shape is clicked during
    a presentation. Can link to URLs, other slides, or perform
    navigation actions.

    Example:
        # Link to external URL
        shape.click_action.hyperlink = "https://example.com"
        shape.click_action.tooltip = "Visit our website"

        # Link to another slide
        shape.click_action.target_slide = 3

        # Navigation actions
        shape.click_action.action = 'next_slide'
        shape.click_action.action = 'previous_slide'
        shape.click_action.action = 'first_slide'
        shape.click_action.action = 'last_slide'
        shape.click_action.action = 'end_show'

        # Remove click action
        shape.click_action.action = 'none'
    """

    def __init__(self, shape: "Shape"):
        self._shape = shape
        self._action_type: str = 'none'
        self._hyperlink_url: Optional[str] = None
        self._target_slide_index: Optional[int] = None
        self._tooltip: Optional[str] = None

    @property
    def action(self) -> str:
        """
        Current action type.

        Returns one of: 'none', 'hyperlink', 'slide', 'next_slide',
        'previous_slide', 'first_slide', 'last_slide', 'end_show'
        """
        return self._action_type

    @action.setter
    def action(self, value: str) -> None:
        """Set the action type."""
        valid = ('none', 'hyperlink', 'slide', 'next_slide', 'previous_slide',
                 'first_slide', 'last_slide', 'end_show')
        if value not in valid:
            raise ValueError(f"action must be one of {valid}")
        self._action_type = value
        self._emit_action_change()

    @property
    def hyperlink(self) -> Optional[str]:
        """URL for hyperlink action."""
        return self._hyperlink_url

    @hyperlink.setter
    def hyperlink(self, url: str) -> None:
        """Set hyperlink URL (automatically sets action to 'hyperlink')."""
        self._hyperlink_url = url
        self._action_type = 'hyperlink'
        self._emit_action_change()

    @property
    def target_slide(self) -> Optional[int]:
        """Target slide index for slide action (0-based)."""
        return self._target_slide_index

    @target_slide.setter
    def target_slide(self, slide_index: int) -> None:
        """Set target slide (automatically sets action to 'slide')."""
        self._target_slide_index = slide_index
        self._action_type = 'slide'
        self._emit_action_change()

    @property
    def tooltip(self) -> Optional[str]:
        """Tooltip text shown on hover."""
        return self._tooltip

    @tooltip.setter
    def tooltip(self, text: str) -> None:
        """Set tooltip text."""
        self._tooltip = text
        self._emit_action_change()

    def clear(self) -> None:
        """Remove any click action from the shape."""
        self._action_type = 'none'
        self._hyperlink_url = None
        self._target_slide_index = None
        self._tooltip = None
        self._emit_action_change()

    def _emit_action_change(self) -> None:
        """Emit a SetClickAction command."""
        if self._shape._buffer:
            cmd = SetClickAction(
                shape_id=self._shape._shape_id,
                action_type=self._action_type,
                hyperlink_url=self._hyperlink_url,
                target_slide_index=self._target_slide_index,
                tooltip=self._tooltip,
            )
            self._shape._buffer.add(cmd)

    def __bool__(self) -> bool:
        """True if a click action is configured."""
        return self._action_type != 'none'

    def __repr__(self) -> str:
        if self._action_type == 'hyperlink':
            return f"<ClickAction hyperlink={self._hyperlink_url!r}>"
        elif self._action_type == 'slide':
            return f"<ClickAction slide={self._target_slide_index}>"
        elif self._action_type == 'none':
            return "<ClickAction (none)>"
        else:
            return f"<ClickAction action={self._action_type}>"


class _ChartTitleTextFrame:
    """python-pptx-compatible ``TextFrame`` adapter for ``chart.chart_title``.

    Real python-pptx returns a full ``TextFrame`` with paragraphs/runs.
    Athena's chart-title pipeline only persists a single string title
    (``SetChartTitle`` patch), so this shim collapses the ``text_frame.
    text = ...`` form down to that same patch. Multi-paragraph chart
    titles aren't supported on the export side yet.
    """

    def __init__(self, chart_title: "_ChartTitle"):
        self._chart_title = chart_title

    @property
    def text(self) -> str:
        return self._chart_title._text or ""

    @text.setter
    def text(self, value: str) -> None:
        self._chart_title._emit(value)


class _ChartTitle:
    """python-pptx-compatible ``ChartTitle`` adapter.

    Exposes ``.text_frame.text`` which routes to the existing
    ``SetChartTitle`` patch path. Also keeps a `text` shorthand getter
    so callers can read back the title without going through
    ``text_frame``.
    """

    def __init__(self, chart: "Chart"):
        self._chart = chart
        self._text_frame = _ChartTitleTextFrame(self)

    @property
    def _text(self) -> Optional[str]:
        return self._chart._shape._properties.get("title")

    @property
    def text_frame(self) -> _ChartTitleTextFrame:
        return self._text_frame

    @property
    def has_text_frame(self) -> bool:
        return True

    def _emit(self, value: str) -> None:
        if self._chart._shape._buffer is None:
            return
        self._chart._shape._buffer.add(UpdateChartDataCmd(
            shape_id=self._chart._shape.shape_id,
            patches=[{
                "op": "SetChartTitle",
                "chartId": self._chart._shape.shape_id,
                "title": str(value),
            }],
        ))


class Chart:
    """
    Chart proxy for python-pptx compatibility.

    Wraps a chart Shape and exposes the python-pptx chart edit surface.
    Edits emit `UpdateChartData` commands that append `ChartPatch` intents
    onto the chart element's `chartPatches` queue; the export-worker drains
    the queue and applies each patch via
    `@pptx/chart-ooxml/export/patcher.ts` on the next export.
    """

    def __init__(self, shape: "Shape"):
        self._shape = shape

    @property
    def chart_type(self) -> Optional[str]:
        """Best-effort chart type if available in element properties."""
        return self._shape._properties.get("chartType")

    @property
    def has_title(self) -> bool:
        """python-pptx parity: True if the underlying chart has a title."""
        return bool(self._shape._properties.get("title"))

    @has_title.setter
    def has_title(self, value: bool) -> None:
        """python-pptx parity: toggle whether the chart's title is rendered.

        Athena's title pipeline auto-shows a title whenever a non-empty
        string is set via ``chart_title.text_frame.text``, so the True
        case is a no-op here. Setting to False clears the existing title
        via the same ``SetChartTitle`` patch with an empty string.
        """
        if not value:
            self._chart_title_obj._emit("")

    def replace_data(self, chart_data: Any) -> None:
        """
        Replace this chart's series data with the values in `chart_data`.

        Mirrors python-pptx semantics: existing series are kept in place
        and their values are overwritten in series order.

        Accepts:
          - ``CategoryChartData`` (column / bar / line / area / pie /
            doughnut). Emits ``UpdateSeriesName``, ``UpdateSeriesValue``,
            and ``UpdateCategoryLabel`` patches.
          - ``XyChartData`` (scatter). Emits ``UpdateSeriesName``,
            ``UpdateSeriesXValue``, and ``UpdateSeriesValue`` (the y-value)
            patches.
          - ``BubbleChartData`` (bubble). Emits the XY patches plus
            ``UpdateBubbleSize`` for each point.
        """
        from .chart.data import XyChartData, BubbleChartData

        chart_id = self._shape.shape_id
        existing_spec = self._shape._properties.get("chartSpec") or {}
        existing_plots = existing_spec.get("plots") or []
        existing_series_ids: list[str] = []
        if existing_plots:
            for s in (existing_plots[0].get("series") or []):
                existing_series_ids.append(str(s.get("id") or ""))

        def _series_id(idx: int) -> str:
            return (
                existing_series_ids[idx]
                if idx < len(existing_series_ids)
                else f"series-{idx}"
            )

        patches: list[dict[str, Any]] = []

        if isinstance(chart_data, CategoryChartData):
            for s_idx, (name, values) in enumerate(zip(
                [n for n, _ in chart_data._series],
                [v for _, v in chart_data._series],
            )):
                sid = _series_id(s_idx)
                patches.append({"op": "UpdateSeriesName", "chartId": chart_id,
                                "seriesId": sid, "name": name})
                for i, v in enumerate(values):
                    patches.append({"op": "UpdateSeriesValue", "chartId": chart_id,
                                    "seriesId": sid, "index": i, "value": v})
            for i, label in enumerate(chart_data.categories):
                patches.append({"op": "UpdateCategoryLabel", "chartId": chart_id,
                                "index": i, "label": label})

        elif isinstance(chart_data, BubbleChartData):
            for s_idx, series in enumerate(chart_data._series):
                sid = _series_id(s_idx)
                patches.append({"op": "UpdateSeriesName", "chartId": chart_id,
                                "seriesId": sid, "name": series.name})
                for i, (x, y) in enumerate(series.points):
                    patches.append({"op": "UpdateSeriesXValue", "chartId": chart_id,
                                    "seriesId": sid, "index": i, "value": x})
                    patches.append({"op": "UpdateSeriesValue", "chartId": chart_id,
                                    "seriesId": sid, "index": i, "value": y})
                for i, size in enumerate(series.sizes):
                    patches.append({"op": "UpdateBubbleSize", "chartId": chart_id,
                                    "seriesId": sid, "index": i, "value": size})

        elif isinstance(chart_data, XyChartData):
            for s_idx, series in enumerate(chart_data._series):
                sid = _series_id(s_idx)
                patches.append({"op": "UpdateSeriesName", "chartId": chart_id,
                                "seriesId": sid, "name": series.name})
                for i, (x, y) in enumerate(series.points):
                    patches.append({"op": "UpdateSeriesXValue", "chartId": chart_id,
                                    "seriesId": sid, "index": i, "value": x})
                    patches.append({"op": "UpdateSeriesValue", "chartId": chart_id,
                                    "seriesId": sid, "index": i, "value": y})

        else:
            raise TypeError(
                "replace_data() requires a CategoryChartData, XyChartData, "
                f"or BubbleChartData instance (got {type(chart_data).__name__})"
            )

        if not patches:
            return

        if self._shape._buffer is not None:
            self._shape._buffer.add(UpdateChartDataCmd(
                shape_id=chart_id,
                patches=patches,
            ))

    @property
    def _chart_title_obj(self) -> "_ChartTitle":
        if not hasattr(self, "_chart_title_cached") or self._chart_title_cached is None:
            self._chart_title_cached = _ChartTitle(self)
        return self._chart_title_cached

    @property
    def chart_title(self) -> "_ChartTitle":
        """Chart title — python-pptx-compatible ``ChartTitle`` object.

        Use ``chart.chart_title.text_frame.text = "..."`` to set the
        title. The legacy ``chart.chart_title = "string"`` shorthand is
        preserved via the setter for backwards compatibility.
        """
        return self._chart_title_obj

    @chart_title.setter
    def chart_title(self, value: Any) -> None:
        """Backwards-compat: accept a string and route it through SetChartTitle.

        Python-pptx's `chart.chart_title` is read-only (you mutate the
        returned ``ChartTitle`` object), so this setter is athena-only.
        New code should prefer ``chart.chart_title.text_frame.text =
        "..."``.
        """
        if isinstance(value, str):
            self._chart_title_obj._emit(value)
        elif isinstance(value, _ChartTitle):
            # Idempotent self-assignment: ignore.
            pass
        else:
            raise TypeError(
                "chart.chart_title = ... only accepts a string for "
                "backwards compatibility. Use chart.chart_title."
                "text_frame.text = '...' instead."
            )

    @property
    def has_legend(self) -> bool:
        legend = self._shape._properties.get("legend") or {}
        return bool(legend.get("visible"))

    @has_legend.setter
    def has_legend(self, value: bool) -> None:
        if self._shape._buffer is None:
            return
        self._shape._buffer.add(UpdateChartDataCmd(
            shape_id=self._shape.shape_id,
            patches=[{
                "op": "SetLegendVisible",
                "chartId": self._shape.shape_id,
                "visible": bool(value),
            }],
        ))


class _ElementParentProxy:
    """
    Proxy for shape.element.getparent() to support python-pptx deletion pattern.

    In python-pptx, shapes are deleted via:
        shape.element.getparent().remove(shape.element)

    This proxy intercepts that pattern and calls the SDK's delete() method.
    """

    def __init__(self, shape: Shape) -> None:
        self._shape = shape

    def remove(self, element: _ElementProxy) -> None:
        """Remove the element (delete the shape)."""
        self._shape.delete()


class _ElementProxy:
    """
    Proxy for shape.element to support python-pptx deletion pattern.

    In python-pptx, shapes are deleted via:
        shape.element.getparent().remove(shape.element)

    This proxy intercepts that pattern and calls the SDK's delete() method.
    """

    def __init__(self, shape: Shape) -> None:
        self._shape = shape
        self._parent = _ElementParentProxy(shape)

    def getparent(self) -> _ElementParentProxy:
        """Return the parent proxy for removal."""
        return self._parent


class Shape:
    """
    A shape on a slide.

    Mirrors python-pptx's Shape class with limited Phase 1 support.
    """

    def __init__(
        self,
        shape_id: ShapeId,
        slide: Slide,
        buffer: Optional[CommandBuffer],
        element_type: str = "text",
        transform: Optional[Transform] = None,
        preview_text: Optional[str] = None,
        properties: Optional[dict[str, Any]] = None,
        placeholder: Optional[PlaceholderSnapshot] = None,
        source: Optional[str] = None,
    ):
        self._shape_id = shape_id
        self._slide = slide
        self._buffer = buffer
        self._element_type = element_type
        self._transform = transform or Transform(x=0, y=0, w=0, h=0)
        self._preview_text = preview_text
        self._properties = properties or {}
        self._text_frame: Optional[TextFrame] = None
        self._placeholder = placeholder
        self._source = source

        # Auto-shapes also support text in PowerPoint (phase-1 behavior).
        if element_type in ("text", "shape"):
            rich_content = properties.get("richContent") if properties else None
            self._text_frame = TextFrame(
                shape_id=shape_id,
                buffer=buffer,
                preview_text=preview_text,
                rich_content=rich_content,
            )

    # Known misspelled/non-existent attributes with specific fix guidance
    _ATTRIBUTE_FIXES: dict[str, str] = {
        "fill_color": (
            "Shape has no 'fill_color' property. The fill was NOT applied.\n"
            "  Use instead:\n"
            "    shape.fill.solid()\n"
            "    shape.fill.fore_color.rgb = RGBColor(0xFF, 0x00, 0x00)"
        ),
        "fillColor": (
            "Shape has no 'fillColor' property. The fill was NOT applied.\n"
            "  Use instead:\n"
            "    shape.fill.solid()\n"
            "    shape.fill.fore_color.rgb = RGBColor(0xFF, 0x00, 0x00)"
        ),
        "fill_colour": (
            "Shape has no 'fill_colour' property. The fill was NOT applied.\n"
            "  Use instead:\n"
            "    shape.fill.solid()\n"
            "    shape.fill.fore_color.rgb = RGBColor(0xFF, 0x00, 0x00)"
        ),
        "line_width": (
            "Shape has no 'line_width' property. The line width was NOT applied.\n"
            "  Use instead:  shape.line.width = Pt(2)"
        ),
        "lineWidth": (
            "Shape has no 'lineWidth' property. The line width was NOT applied.\n"
            "  Use instead:  shape.line.width = Pt(2)"
        ),
        "line_color": (
            "Shape has no 'line_color' property. The line color was NOT applied.\n"
            "  Use instead:\n"
            "    shape.line.color.rgb = RGBColor(0x00, 0x00, 0x00)"
        ),
        "lineColor": (
            "Shape has no 'lineColor' property. The line color was NOT applied.\n"
            "  Use instead:\n"
            "    shape.line.color.rgb = RGBColor(0x00, 0x00, 0x00)"
        ),
        "background_color": (
            "Shape has no 'background_color' property. The fill was NOT applied.\n"
            "  Use instead:\n"
            "    shape.fill.solid()\n"
            "    shape.fill.fore_color.rgb = RGBColor(0xFF, 0x00, 0x00)"
        ),
        "font_size": (
            "Shape has no 'font_size' property.\n"
            "  Use instead:  shape.text_frame.paragraphs[0].font.size = Pt(14)"
        ),
        "font_color": (
            "Shape has no 'font_color' property.\n"
            "  Use instead:  shape.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 0, 0)"
        ),
        "border_color": (
            "Shape has no 'border_color' property. The border was NOT applied.\n"
            "  Use instead:\n"
            "    shape.line.color.rgb = RGBColor(0x00, 0x00, 0x00)"
        ),
        "border_width": (
            "Shape has no 'border_width' property. The border was NOT applied.\n"
            "  Use instead:  shape.line.width = Pt(2)"
        ),
    }

    def __setattr__(self, name: str, value: object) -> None:
        # Allow private/internal attributes (self._foo) unconditionally
        if name.startswith("_"):
            super().__setattr__(name, value)
            return

        # Check if it's a known property (has a setter defined on the class)
        cls = type(self)
        if isinstance(getattr(cls, name, None), property):
            super().__setattr__(name, value)
            return

        # Unknown public attribute — warn via both stderr (warnings) and stdout (print)
        # so the message is visible regardless of how output is captured
        import warnings
        fix = self._ATTRIBUTE_FIXES.get(name)
        if fix:
            msg = f"WARNING: {fix}"
        else:
            msg = (
                f"WARNING: Shape has no '{name}' attribute. "
                f"This assignment will be silently ignored and have no effect on the shape. "
                f"Check the python-pptx documentation for the correct API."
            )
        # Print to stdout so it's visible in captured output (e.g., agent sandboxes)
        print(msg)
        # Also emit as a proper Python warning for programmatic consumers
        warnings.warn(msg, stacklevel=2)

        # Still allow the set (don't error) per user request
        super().__setattr__(name, value)

    @property
    def shape_id(self) -> ShapeId:
        """Unique identifier for this shape."""
        return self._shape_id

    @property
    def shape_type(self) -> Optional[MSO_SHAPE_TYPE]:
        """Type of the shape as a ``MSO_SHAPE_TYPE`` enum value.

        python-pptx returns the ``MSO_SHAPE_TYPE`` IntEnum (so callers can
        compare ``shape.shape_type == MSO_SHAPE_TYPE.PLACEHOLDER``); placeholder
        shapes always report ``PLACEHOLDER`` regardless of the underlying
        content type. Non-placeholder shapes map their internal element type
        ('text', 'image', 'shape', etc.) to the matching enum value.
        """
        if self.is_placeholder:
            return MSO_SHAPE_TYPE.PLACEHOLDER
        return _ELEMENT_TYPE_TO_MSO_SHAPE_TYPE.get(self._element_type)

    @property
    def _is_inherited(self) -> bool:
        """True when this shape was projected from the slide's layout or master.

        Used by the ``Shapes`` collection to mirror python-pptx's contract that
        ``slide.shapes`` returns slide-level content only — inherited
        placeholders surface through ``slide.placeholders`` instead.
        """
        return self._source in ("layout", "master")

    @property
    def auto_shape_type(self) -> Optional[str]:
        """
        The autoshape type for shape elements (e.g., 'rectangle', 'oval', 'star5').

        Returns None if this is not an autoshape (e.g., for text boxes, images, tables).
        """
        return self._properties.get("shapeType")

    @property
    def source(self) -> Optional[str]:
        """
        Source of this shape: 'ingested' or 'sdk'.

        - 'ingested': Shape came from the original uploaded PPTX file
        - 'sdk': Shape was created via the SDK
        - None: Source unknown (e.g., for newly created shapes not yet synced)
        """
        return self._source

    @property
    def element(self) -> _ElementProxy:
        """
        Proxy for the underlying element.

        This provides compatibility with the python-pptx deletion pattern:
            shape.element.getparent().remove(shape.element)

        In this SDK, it's recommended to use shape.delete() directly instead.
        """
        return _ElementProxy(self)

    @property
    def has_text_frame(self) -> bool:
        """True if this shape has a text frame."""
        return self._text_frame is not None

    @property
    def text_frame(self) -> TextFrame:
        """
        Text frame for this shape.

        Raises AttributeError if the shape doesn't have text, matching python-pptx
        behavior. Use has_text_frame to check before accessing.
        """
        if self._text_frame is None:
            raise AttributeError(
                f"'{self._element_type}' object has no attribute 'text_frame'"
            )
        return self._text_frame

    @property
    def text(self) -> str:
        """
        Shortcut for shape.text_frame.text.

        Returns empty string for shapes without a text frame (images, connectors, etc.).
        Use has_text_frame to check if a shape supports text before setting.
        """
        if self._text_frame is None:
            return ""
        return self._text_frame.text

    @text.setter
    def text(self, value: str) -> None:
        """
        Shortcut for shape.text_frame.text = value.

        Raises UnsupportedFeatureError if the shape doesn't have a text frame.
        """
        self.text_frame.text = value

    # -------------------------------------------------------------------------
    # Position and size properties
    # -------------------------------------------------------------------------

    @property
    def left(self) -> Emu:
        """X position in EMU."""
        return Emu(self._transform.get("x", 0))

    @left.setter
    def left(self, value: Length) -> None:
        """Set X position."""
        emu_value = ensure_emu(value)
        self._transform["x"] = int(emu_value)
        self._emit_transform_change()

    @property
    def top(self) -> Emu:
        """Y position in EMU."""
        return Emu(self._transform.get("y", 0))

    @top.setter
    def top(self, value: Length) -> None:
        """Set Y position."""
        emu_value = ensure_emu(value)
        self._transform["y"] = int(emu_value)
        self._emit_transform_change()

    @property
    def width(self) -> Emu:
        """Width in EMU."""
        return Emu(self._transform.get("w", 0))

    @width.setter
    def width(self, value: Length) -> None:
        """Set width."""
        emu_value = ensure_emu(value)
        self._transform["w"] = int(emu_value)
        self._emit_transform_change()

    @property
    def height(self) -> Emu:
        """Height in EMU."""
        return Emu(self._transform.get("h", 0))

    @height.setter
    def height(self, value: Length) -> None:
        """Set height."""
        emu_value = ensure_emu(value)
        self._transform["h"] = int(emu_value)
        self._emit_transform_change()

    @property
    def rotation(self) -> float:
        """Rotation in degrees."""
        return self._transform.get("rot", 0.0) or 0.0

    @rotation.setter
    def rotation(self, value: float) -> None:
        """Set rotation in degrees."""
        self._transform["rot"] = value
        self._emit_transform_change()

    @property
    def flip_h(self) -> bool:
        """Whether the shape is flipped horizontally."""
        return self._transform.get("flipH", False) or False

    @flip_h.setter
    def flip_h(self, value: bool) -> None:
        """Set horizontal flip."""
        self._transform["flipH"] = value
        self._emit_transform_change()

    @property
    def flip_v(self) -> bool:
        """Whether the shape is flipped vertically."""
        return self._transform.get("flipV", False) or False

    @flip_v.setter
    def flip_v(self, value: bool) -> None:
        """Set vertical flip."""
        self._transform["flipV"] = value
        self._emit_transform_change()

    # -------------------------------------------------------------------------
    # Computed position properties (read-only)
    # -------------------------------------------------------------------------

    @property
    def right(self) -> Emu:
        """Right edge position in EMU (left + width). Read-only."""
        return Emu(int(self.left) + int(self.width))

    @property
    def bottom(self) -> Emu:
        """Bottom edge position in EMU (top + height). Read-only."""
        return Emu(int(self.top) + int(self.height))

    @property
    def center_x(self) -> Emu:
        """Horizontal center position in EMU. Read-only."""
        return Emu(int(self.left) + int(self.width) // 2)

    @property
    def center_y(self) -> Emu:
        """Vertical center position in EMU. Read-only."""
        return Emu(int(self.top) + int(self.height) // 2)

    @property
    def aspect_ratio(self) -> float:
        """Width-to-height aspect ratio. Returns 0.0 if height is 0."""
        h = int(self.height)
        if h == 0:
            return 0.0
        return float(self.width) / float(h)

    @property
    def bounds(self) -> tuple[Emu, Emu, Emu, Emu]:
        """
        Bounding box as (left, top, right, bottom) tuple in EMU.

        Returns:
            Tuple of (left, top, right, bottom) coordinates
        """
        return (self.left, self.top, self.right, self.bottom)

    @property
    def center(self) -> tuple[Emu, Emu]:
        """
        Center point as (x, y) tuple in EMU.

        Returns:
            Tuple of (center_x, center_y) coordinates
        """
        return (self.center_x, self.center_y)

    @property
    def size(self) -> tuple[Emu, Emu]:
        """
        Size as (width, height) tuple in EMU.

        Returns:
            Tuple of (width, height) dimensions
        """
        return (self.width, self.height)

    @property
    def position(self) -> tuple[Emu, Emu]:
        """
        Position as (left, top) tuple in EMU.

        Returns:
            Tuple of (left, top) coordinates
        """
        return (self.left, self.top)

    # -------------------------------------------------------------------------
    # Convenience positioning methods
    # -------------------------------------------------------------------------

    def move(self, dx: Length, dy: Length) -> None:
        """
        Move the shape by relative amounts.

        Args:
            dx: Horizontal distance to move (positive = right, negative = left)
            dy: Vertical distance to move (positive = down, negative = up)
        """
        dx_emu = int(ensure_emu(dx))
        dy_emu = int(ensure_emu(dy))
        self._transform["x"] = int(self.left) + dx_emu
        self._transform["y"] = int(self.top) + dy_emu
        self._emit_transform_change()

    def resize(self, dw: Length, dh: Length) -> None:
        """
        Resize the shape by relative amounts.

        Args:
            dw: Amount to add to width (positive = wider, negative = narrower)
            dh: Amount to add to height (positive = taller, negative = shorter)
        """
        dw_emu = int(ensure_emu(dw))
        dh_emu = int(ensure_emu(dh))
        new_w = max(0, int(self.width) + dw_emu)
        new_h = max(0, int(self.height) + dh_emu)
        self._transform["w"] = new_w
        self._transform["h"] = new_h
        self._emit_transform_change()

    def scale(self, factor: float) -> None:
        """
        Scale the shape uniformly by a factor.

        Args:
            factor: Scale factor (e.g., 2.0 = double size, 0.5 = half size)
        """
        self._transform["w"] = int(int(self.width) * factor)
        self._transform["h"] = int(int(self.height) * factor)
        self._emit_transform_change()

    def set_position(self, left: Length, top: Length) -> None:
        """
        Set the shape's position in a single call.

        Args:
            left: X position
            top: Y position
        """
        self._transform["x"] = int(ensure_emu(left))
        self._transform["y"] = int(ensure_emu(top))
        self._emit_transform_change()

    def set_size(self, width: Length, height: Length) -> None:
        """
        Set the shape's size in a single call.

        Args:
            width: Width
            height: Height
        """
        self._transform["w"] = int(ensure_emu(width))
        self._transform["h"] = int(ensure_emu(height))
        self._emit_transform_change()

    def contains_point(self, x: Length, y: Length) -> bool:
        """
        Check if a point is within this shape's bounding box.

        Args:
            x: X coordinate to test
            y: Y coordinate to test

        Returns:
            True if the point is within the shape's bounds
        """
        x_emu = int(ensure_emu(x))
        y_emu = int(ensure_emu(y))
        return (
            int(self.left) <= x_emu <= int(self.right) and
            int(self.top) <= y_emu <= int(self.bottom)
        )

    def intersects(self, other: "Shape") -> bool:
        """
        Check if this shape's bounding box intersects with another shape.

        Args:
            other: Another shape to test against

        Returns:
            True if the bounding boxes overlap
        """
        return not (
            int(self.right) < int(other.left) or
            int(other.right) < int(self.left) or
            int(self.bottom) < int(other.top) or
            int(other.bottom) < int(self.top)
        )

    def _emit_transform_change(self) -> None:
        """Emit a SetTransform command."""
        if self._buffer:
            cmd = SetTransform(
                shape_id=self._shape_id,
                x_emu=self._transform.get("x"),
                y_emu=self._transform.get("y"),
                w_emu=self._transform.get("w"),
                h_emu=self._transform.get("h"),
                rot_deg=self._transform.get("rot"),
                flip_h=self._transform.get("flipH"),
                flip_v=self._transform.get("flipV"),
            )
            self._buffer.add(cmd)

    def delete(self) -> None:
        """Delete this shape from the slide."""
        if self._buffer:
            cmd = DeleteShape(shape_id=self._shape_id)
            self._buffer.add(cmd)

    # -------------------------------------------------------------------------
    # Fill and line styling
    # -------------------------------------------------------------------------

    @property
    def fill(self) -> FillFormat:
        """
        Fill formatting for this shape.

        Returns a FillFormat object that can be used to set solid fill colors,
        transparency, or remove fill entirely.

        Example:
            shape.fill.solid_fill('FF0000')  # Red fill
            shape.fill.transparency = 0.5    # 50% transparent
            shape.fill.background()          # Remove fill
        """
        if not hasattr(self, '_fill_format') or self._fill_format is None:
            self._fill_format = FillFormat(self)
        return self._fill_format

    @property
    def line(self) -> LineFormat:
        """
        Line (outline/border) formatting for this shape.

        Returns a LineFormat object that can be used to set line color,
        width, and dash style.

        Example:
            shape.line.color = '000000'  # Black outline
            shape.line.width = Pt(2)     # 2-point line
            shape.line.dash_style = 'dash'
        """
        if not hasattr(self, '_line_format') or self._line_format is None:
            self._line_format = LineFormat(self)
        return self._line_format

    def fill_solid(self, color: "str | RGBColor") -> None:
        """
        Convenience method to set a solid fill color directly on the shape.

        Equivalent to shape.fill.solid_fill(color).

        Args:
            color: Color as hex string (e.g., "FF0000" or "#FF0000") or RGBColor object
        """
        self.fill.solid_fill(color)

    def line_fill_none(self) -> None:
        """
        Convenience method to remove the shape's outline.

        Equivalent to shape.line.no_fill().
        """
        self.line.no_fill()

    # -------------------------------------------------------------------------
    # Phase 4: Shape name and click action
    # -------------------------------------------------------------------------

    @property
    def name(self) -> Optional[str]:
        """
        Shape name.

        Shape names are useful for identifying shapes programmatically
        and are preserved in the PPTX file.

        Example:
            shape.name = "MyTitle"
            print(shape.name)  # "MyTitle"
        """
        return self._properties.get("name")

    @name.setter
    def name(self, value: str) -> None:
        """Set shape name."""
        self._properties["name"] = value
        if self._buffer:
            cmd = SetShapeName(shape_id=self._shape_id, name=value)
            self._buffer.add(cmd)

    @property
    def click_action(self) -> "ClickAction":
        """
        Click action (hyperlink) for this shape.

        Returns a ClickAction object for configuring what happens
        when the shape is clicked during a presentation.

        Example:
            # Link to URL
            shape.click_action.hyperlink = "https://example.com"

            # Link to another slide
            shape.click_action.target_slide = 3  # Go to slide 4

            # Navigation actions
            shape.click_action.action = 'next_slide'
        """
        if not hasattr(self, '_click_action') or self._click_action is None:
            self._click_action = ClickAction(self)
        return self._click_action

    @property
    def has_chart(self) -> bool:
        """True if this shape contains a chart."""
        return self._element_type == "chart"

    @property
    def chart(self) -> Chart:
        """Access chart proxy for chart shapes."""
        if not self.has_chart:
            raise ValueError(f"Shape '{self.name}' is not a chart")
        if not hasattr(self, "_chart") or self._chart is None:
            self._chart = Chart(self)
        return self._chart

    @property
    def has_table(self) -> bool:
        """True if this shape is a table."""
        return self._element_type == "table"

    @property
    def table(self) -> "Table":
        """Access the table object for this shape.

        Returns self for Table shapes (python-pptx compatibility).
        Raises ValueError for non-table shapes.
        """
        if self._element_type != "table":
            raise ValueError(f"Shape '{self.name}' is not a table")
        return self  # type: ignore[return-value]

    # -------------------------------------------------------------------------
    # Type checking helpers
    # -------------------------------------------------------------------------

    @property
    def is_text_shape(self) -> bool:
        """True if this is a text shape (textbox)."""
        return self._element_type == "text"

    @property
    def is_image(self) -> bool:
        """True if this is an image/picture shape."""
        return self._element_type == "image"

    @property
    def is_table(self) -> bool:
        """True if this is a table shape."""
        return self._element_type == "table"

    @property
    def is_autoshape(self) -> bool:
        """True if this is an autoshape (rectangle, oval, etc.)."""
        return self._element_type == "shape"

    @property
    def is_group(self) -> bool:
        """True if this is a group shape."""
        return self._element_type == "group"

    # -------------------------------------------------------------------------
    # python-pptx parity: Picture crop_* properties (image elements only)
    # -------------------------------------------------------------------------

    def _get_crop_dict(self) -> dict:
        """Internal: read the current crop fractions from snapshot properties."""
        crop = self._properties.get("crop") or {}
        return {
            "left": float(crop.get("left", 0.0)),
            "top": float(crop.get("top", 0.0)),
            "right": float(crop.get("right", 0.0)),
            "bottom": float(crop.get("bottom", 0.0)),
        }

    def _emit_crop_change(self, new_crop: dict) -> None:
        """Persist new crop fractions in local state and emit ``SetPictureCrop``."""
        if not self.is_image:
            raise ValueError(
                "crop_* properties are only valid for image (Picture) shapes"
            )
        self._properties["crop"] = dict(new_crop)
        if self._buffer:
            self._buffer.add(SetPictureCrop(shape_id=self._shape_id, crop=dict(new_crop)))

    @property
    def crop_left(self) -> float:
        """Fraction of the picture cropped from the left edge (python-pptx parity)."""
        return self._get_crop_dict()["left"]

    @crop_left.setter
    def crop_left(self, value: float) -> None:
        c = self._get_crop_dict()
        c["left"] = float(value)
        self._emit_crop_change(c)

    @property
    def crop_top(self) -> float:
        """Fraction of the picture cropped from the top edge (python-pptx parity)."""
        return self._get_crop_dict()["top"]

    @crop_top.setter
    def crop_top(self, value: float) -> None:
        c = self._get_crop_dict()
        c["top"] = float(value)
        self._emit_crop_change(c)

    @property
    def crop_right(self) -> float:
        """Fraction of the picture cropped from the right edge (python-pptx parity)."""
        return self._get_crop_dict()["right"]

    @crop_right.setter
    def crop_right(self, value: float) -> None:
        c = self._get_crop_dict()
        c["right"] = float(value)
        self._emit_crop_change(c)

    @property
    def crop_bottom(self) -> float:
        """Fraction of the picture cropped from the bottom edge (python-pptx parity)."""
        return self._get_crop_dict()["bottom"]

    @crop_bottom.setter
    def crop_bottom(self, value: float) -> None:
        c = self._get_crop_dict()
        c["bottom"] = float(value)
        self._emit_crop_change(c)

    @property
    def is_connector(self) -> bool:
        """True if this is a connector line."""
        return self._element_type == "connector"

    # -------------------------------------------------------------------------
    # python-pptx parity: GroupShape.shapes children traversal
    # -------------------------------------------------------------------------

    @property
    def shapes(self) -> list["Shape"]:
        """Child shapes when this is a group (python-pptx ``GroupShape.shapes``).

        Returns a list of Shape objects whose ids match the group's
        ``childIds`` property. Empty list for non-groups.

        Note: returns a flat list (snapshot of group membership at access time).
        Mutations to the returned list don't propagate to the deck — modify
        members through their own Shape objects.
        """
        if not self.is_group:
            return []
        child_ids = self._properties.get("childIds") or []
        slide_shapes = self._slide.shapes
        out: list["Shape"] = []
        for cid in child_ids:
            child = slide_shapes.get_by_id(cid)
            if child is not None:
                out.append(child)
        return out

    # -------------------------------------------------------------------------
    # python-pptx parity: Connector endpoint geometry
    # -------------------------------------------------------------------------
    # OOXML connector uses a:xfrm with @flipH/@flipV to encode endpoint order
    # rather than separate begin/end attributes. python-pptx exposes
    # `connector.begin_x / begin_y / end_x / end_y` as raw EMU positions
    # derived from the bounding box + flip flags. We mirror that calc here so
    # SDK users can read endpoints; setters move the bounding box and update
    # flips accordingly.

    def _check_connector(self) -> None:
        if not self.is_connector:
            raise ValueError(
                "begin_x/begin_y/end_x/end_y are only valid for connector shapes"
            )

    @property
    def begin_x(self) -> Emu:
        """Connector start-point X coordinate in EMU (python-pptx parity)."""
        self._check_connector()
        return Emu(int(self._transform["x"] + self._transform["w"])) if self.flip_h else Emu(int(self._transform["x"]))

    @begin_x.setter
    def begin_x(self, value: Length) -> None:
        self._check_connector()
        self._set_endpoint("begin", "x", int(value))

    @property
    def begin_y(self) -> Emu:
        """Connector start-point Y coordinate in EMU (python-pptx parity)."""
        self._check_connector()
        return Emu(int(self._transform["y"] + self._transform["h"])) if self.flip_v else Emu(int(self._transform["y"]))

    @begin_y.setter
    def begin_y(self, value: Length) -> None:
        self._check_connector()
        self._set_endpoint("begin", "y", int(value))

    @property
    def end_x(self) -> Emu:
        """Connector end-point X coordinate in EMU (python-pptx parity)."""
        self._check_connector()
        return Emu(int(self._transform["x"])) if self.flip_h else Emu(int(self._transform["x"] + self._transform["w"]))

    @end_x.setter
    def end_x(self, value: Length) -> None:
        self._check_connector()
        self._set_endpoint("end", "x", int(value))

    @property
    def end_y(self) -> Emu:
        """Connector end-point Y coordinate in EMU (python-pptx parity)."""
        self._check_connector()
        return Emu(int(self._transform["y"])) if self.flip_v else Emu(int(self._transform["y"] + self._transform["h"]))

    @end_y.setter
    def end_y(self, value: Length) -> None:
        self._check_connector()
        self._set_endpoint("end", "y", int(value))

    def _set_endpoint(self, which: str, axis: str, new_value: int) -> None:
        """Adjust transform + flip so the named endpoint lands at ``new_value``."""
        # Pull both current endpoints, replace the one we're updating, then
        # recompute the bounding box and flip flags.
        bx = int(self.begin_x)
        by = int(self.begin_y)
        ex = int(self.end_x)
        ey = int(self.end_y)
        if which == "begin" and axis == "x":
            bx = new_value
        elif which == "begin" and axis == "y":
            by = new_value
        elif which == "end" and axis == "x":
            ex = new_value
        elif which == "end" and axis == "y":
            ey = new_value

        self._transform["x"] = min(bx, ex)
        self._transform["y"] = min(by, ey)
        self._transform["w"] = max(1, abs(ex - bx))
        self._transform["h"] = max(1, abs(ey - by))
        self._transform["flipH"] = ex < bx
        self._transform["flipV"] = ey < by
        self._emit_transform_change()

    # -------------------------------------------------------------------------
    # Position/size copying helpers
    # -------------------------------------------------------------------------

    def copy_position_from(self, other: "Shape") -> None:
        """
        Copy position (left, top) from another shape.

        Args:
            other: Source shape to copy position from
        """
        self._transform["x"] = int(other.left)
        self._transform["y"] = int(other.top)
        self._emit_transform_change()

    def copy_size_from(self, other: "Shape") -> None:
        """
        Copy size (width, height) from another shape.

        Args:
            other: Source shape to copy size from
        """
        self._transform["w"] = int(other.width)
        self._transform["h"] = int(other.height)
        self._emit_transform_change()

    def copy_transform_from(self, other: "Shape") -> None:
        """
        Copy full transform (position, size, rotation, flip) from another shape.

        Args:
            other: Source shape to copy transform from
        """
        self._transform["x"] = int(other.left)
        self._transform["y"] = int(other.top)
        self._transform["w"] = int(other.width)
        self._transform["h"] = int(other.height)
        self._transform["rot"] = other.rotation
        self._transform["flipH"] = other.flip_h
        self._transform["flipV"] = other.flip_v
        self._emit_transform_change()

    def align_left_to(self, other: "Shape") -> None:
        """Align left edge to another shape's left edge."""
        self._transform["x"] = int(other.left)
        self._emit_transform_change()

    def align_right_to(self, other: "Shape") -> None:
        """Align right edge to another shape's right edge."""
        self._transform["x"] = int(other.right) - int(self.width)
        self._emit_transform_change()

    def align_top_to(self, other: "Shape") -> None:
        """Align top edge to another shape's top edge."""
        self._transform["y"] = int(other.top)
        self._emit_transform_change()

    def align_bottom_to(self, other: "Shape") -> None:
        """Align bottom edge to another shape's bottom edge."""
        self._transform["y"] = int(other.bottom) - int(self.height)
        self._emit_transform_change()

    def align_center_x_to(self, other: "Shape") -> None:
        """Align horizontal center to another shape's center."""
        self._transform["x"] = int(other.center_x) - int(self.width) // 2
        self._emit_transform_change()

    def align_center_y_to(self, other: "Shape") -> None:
        """Align vertical center to another shape's center."""
        self._transform["y"] = int(other.center_y) - int(self.height) // 2
        self._emit_transform_change()

    def center_on(self, other: "Shape") -> None:
        """Center this shape on another shape (both horizontally and vertically)."""
        self._transform["x"] = int(other.center_x) - int(self.width) // 2
        self._transform["y"] = int(other.center_y) - int(self.height) // 2
        self._emit_transform_change()

    # -------------------------------------------------------------------------
    # Computed geometry properties
    # -------------------------------------------------------------------------

    @property
    def area(self) -> int:
        """Area of the shape in square EMU."""
        return int(self.width) * int(self.height)

    @property
    def perimeter(self) -> int:
        """Perimeter of the shape bounding box in EMU."""
        return 2 * (int(self.width) + int(self.height))

    @property
    def diagonal(self) -> float:
        """Diagonal length of the shape bounding box in EMU."""
        return (int(self.width) ** 2 + int(self.height) ** 2) ** 0.5

    @property
    def is_square(self) -> bool:
        """True if shape has equal width and height (within 1% tolerance)."""
        w, h = int(self.width), int(self.height)
        if h == 0:
            return w == 0
        ratio = w / h
        return 0.99 <= ratio <= 1.01

    @property
    def is_landscape(self) -> bool:
        """True if width > height."""
        return int(self.width) > int(self.height)

    @property
    def is_portrait(self) -> bool:
        """True if height > width."""
        return int(self.height) > int(self.width)

    @property
    def area_inches(self) -> float:
        """Area in square inches."""
        from .units import EMU_PER_INCH
        return (int(self.width) / EMU_PER_INCH) * (int(self.height) / EMU_PER_INCH)

    def distance_to(self, other: "Shape") -> float:
        """
        Calculate distance between shape centers.

        Args:
            other: Another shape

        Returns:
            Distance in EMU between the centers of the two shapes
        """
        dx = int(self.center_x) - int(other.center_x)
        dy = int(self.center_y) - int(other.center_y)
        return (dx ** 2 + dy ** 2) ** 0.5

    def is_above(self, other: "Shape") -> bool:
        """True if this shape's bottom edge is above other shape's top edge."""
        return int(self.bottom) < int(other.top)

    def is_below(self, other: "Shape") -> bool:
        """True if this shape's top edge is below other shape's bottom edge."""
        return int(self.top) > int(other.bottom)

    def is_left_of(self, other: "Shape") -> bool:
        """True if this shape's right edge is left of other shape's left edge."""
        return int(self.right) < int(other.left)

    def is_right_of(self, other: "Shape") -> bool:
        """True if this shape's left edge is right of other shape's right edge."""
        return int(self.left) > int(other.right)

    def get_text_stats(self) -> dict:
        """
        Get text statistics for this shape.

        Returns:
            Dictionary containing:
            - word_count: Total word count
            - character_count: Total character count (excluding whitespace)
            - paragraph_count: Number of paragraphs
            - run_count: Number of text runs
            - has_formatting: Whether any formatting is applied
            - is_empty: Whether the text is empty

        Returns empty stats if shape has no text frame.
        """
        if not self.has_text_frame:
            return {
                'word_count': 0,
                'character_count': 0,
                'paragraph_count': 0,
                'run_count': 0,
                'has_formatting': False,
                'is_empty': True,
            }

        text = self.text
        return {
            'word_count': len(text.split()) if text else 0,
            'character_count': len(text.replace(" ", "").replace("\n", "")) if text else 0,
            'paragraph_count': self.text_frame.paragraph_count,
            'run_count': self.text_frame.run_count,
            'has_formatting': self.text_frame.has_formatting,
            'is_empty': not bool(text.strip()) if text else True,
        }

    def get_transform_dict(self) -> dict:
        """
        Get the shape's transform as a dictionary.

        Returns:
            Dictionary with left, top, width, height in EMU
        """
        return {
            'left': int(self.left),
            'top': int(self.top),
            'width': int(self.width),
            'height': int(self.height),
        }

    def get_transform_dict_inches(self) -> dict:
        """
        Get the shape's transform as a dictionary in inches.

        Returns:
            Dictionary with left, top, width, height in inches
        """
        emu_per_inch = 914400
        return {
            'left': int(self.left) / emu_per_inch,
            'top': int(self.top) / emu_per_inch,
            'width': int(self.width) / emu_per_inch,
            'height': int(self.height) / emu_per_inch,
        }

    @property
    def center_point(self) -> tuple:
        """Get center point as (x, y) tuple in EMU."""
        return (int(self.center_x), int(self.center_y))

    def scale_by(self, factor: float, anchor: str = 'center') -> None:
        """
        Scale the shape by a factor.

        Args:
            factor: Scale factor (1.0 = no change, 2.0 = double size, 0.5 = half size)
            anchor: Anchor point for scaling - 'center', 'top-left', 'top-right',
                   'bottom-left', 'bottom-right'

        Note: This modifies the shape's transform locally. Changes are automatically
        emitted to the server if a buffer is configured.
        """
        new_width = int(int(self.width) * factor)
        new_height = int(int(self.height) * factor)

        # Calculate offset based on anchor
        delta_w = new_width - int(self.width)
        delta_h = new_height - int(self.height)

        if anchor == 'center':
            self._transform['x'] = int(self._transform['x']) - delta_w // 2
            self._transform['y'] = int(self._transform['y']) - delta_h // 2
        elif anchor == 'top-right':
            self._transform['x'] = int(self._transform['x']) - delta_w
        elif anchor == 'bottom-left':
            self._transform['y'] = int(self._transform['y']) - delta_h
        elif anchor == 'bottom-right':
            self._transform['x'] = int(self._transform['x']) - delta_w
            self._transform['y'] = int(self._transform['y']) - delta_h
        # 'top-left' needs no adjustment

        self._transform['w'] = new_width
        self._transform['h'] = new_height
        self._emit_transform_change()

    def move_by(self, delta_x: int = 0, delta_y: int = 0) -> None:
        """
        Move the shape by relative amounts.

        Args:
            delta_x: Amount to move horizontally in EMU (positive = right)
            delta_y: Amount to move vertically in EMU (positive = down)
        """
        self._transform['x'] = int(self._transform['x']) + delta_x
        self._transform['y'] = int(self._transform['y']) + delta_y
        self._emit_transform_change()

    def resize_to(self, width: int, height: int) -> None:
        """
        Resize shape to exact dimensions.

        Args:
            width: New width in EMU
            height: New height in EMU
        """
        self._transform['w'] = width
        self._transform['h'] = height
        self._emit_transform_change()

    def move_to(self, x: int, y: int) -> None:
        """
        Move shape to exact position.

        Args:
            x: New left position in EMU
            y: New top position in EMU
        """
        self._transform['x'] = x
        self._transform['y'] = y
        self._emit_transform_change()

    def to_dict(self) -> dict:
        """
        Serialize shape to a dictionary.

        Returns a comprehensive dictionary representation of the shape
        suitable for JSON serialization or debugging.

        Returns:
            Dictionary with shape properties
        """
        result = {
            'id': self._shape_id,
            'type': self._element_type,
            'position': {
                'left': int(self.left),
                'top': int(self.top),
                'width': int(self.width),
                'height': int(self.height),
            },
            'rotation': self.rotation,
            'flip_h': self.flip_h,
            'flip_v': self.flip_v,
            'is_placeholder': self.is_placeholder,
        }

        # Add text content if available
        if self.has_text_frame:
            result['text'] = self.text
            result['text_stats'] = self.get_text_stats()

        # Add auto shape type if applicable
        if self._element_type == 'shape':
            result['auto_shape_type'] = self.auto_shape_type

        return result

    def get_bounds(self) -> dict:
        """
        Get bounding box as a dictionary.

        Returns:
            Dictionary with left, top, right, bottom, width, height, center_x, center_y
        """
        return {
            'left': int(self.left),
            'top': int(self.top),
            'right': int(self.right),
            'bottom': int(self.bottom),
            'width': int(self.width),
            'height': int(self.height),
            'center_x': int(self.center_x),
            'center_y': int(self.center_y),
        }

    def overlaps(self, other: "Shape") -> bool:
        """
        Check if this shape overlaps with another shape.

        Alias for intersects() method.

        Args:
            other: Another shape to test against

        Returns:
            True if the bounding boxes overlap
        """
        return self.intersects(other)

    def get_overlap_area(self, other: "Shape") -> int:
        """
        Calculate the area of overlap between two shapes.

        Args:
            other: Another shape

        Returns:
            Overlap area in square EMU (0 if no overlap)
        """
        if not self.intersects(other):
            return 0

        left = max(int(self.left), int(other.left))
        top = max(int(self.top), int(other.top))
        right = min(int(self.right), int(other.right))
        bottom = min(int(self.bottom), int(other.bottom))

        return (right - left) * (bottom - top)

    def contains(self, other: "Shape") -> bool:
        """
        Check if this shape fully contains another shape.

        Args:
            other: Another shape

        Returns:
            True if this shape's bounds fully contain the other shape
        """
        return (
            int(self.left) <= int(other.left) and
            int(self.top) <= int(other.top) and
            int(self.right) >= int(other.right) and
            int(self.bottom) >= int(other.bottom)
        )

    @property
    def shadow(self) -> ShadowFormat:
        """
        Shadow formatting for this shape.

        Returns a ShadowFormat object that can be used to add drop shadows,
        inner shadows, or perspective shadows to the shape.

        Example:
            shape.shadow.visible = True
            shape.shadow.blur_radius = Pt(4)
            shape.shadow.distance = Pt(3)
            shape.shadow.direction = 45
            shape.shadow.color = RGBColor(0, 0, 0)
            shape.shadow.transparency = 0.6
        """
        if not hasattr(self, '_shadow_format') or self._shadow_format is None:
            self._shadow_format = ShadowFormat(self)
        return self._shadow_format

    # -------------------------------------------------------------------------
    # Phase 3: Z-Order methods
    # -------------------------------------------------------------------------

    def bring_to_front(self) -> None:
        """
        Move shape to the front (top of z-order).

        The shape will be drawn on top of all other shapes.
        """
        if self._buffer:
            cmd = SetShapeZOrder(shape_id=self._shape_id, action='to_front')
            self._buffer.add(cmd)

    def send_to_back(self) -> None:
        """
        Move shape to the back (bottom of z-order).

        The shape will be drawn behind all other shapes.
        """
        if self._buffer:
            cmd = SetShapeZOrder(shape_id=self._shape_id, action='to_back')
            self._buffer.add(cmd)

    def bring_forward(self) -> None:
        """
        Move shape one level forward in z-order.

        The shape will be drawn on top of the next shape.
        """
        if self._buffer:
            cmd = SetShapeZOrder(shape_id=self._shape_id, action='forward')
            self._buffer.add(cmd)

    def send_backward(self) -> None:
        """
        Move shape one level backward in z-order.

        The shape will be drawn behind the previous shape.
        """
        if self._buffer:
            cmd = SetShapeZOrder(shape_id=self._shape_id, action='backward')
            self._buffer.add(cmd)

    # -------------------------------------------------------------------------
    # Phase 5: Clone and Adjustments
    # -------------------------------------------------------------------------

    def clone(
        self,
        target_slide: Optional["Slide"] = None,
        offset_x: Optional[Length] = None,
        offset_y: Optional[Length] = None,
    ) -> "Shape":
        """
        Clone/duplicate this shape.

        Creates a copy of this shape with all its properties, optionally
        placing it on a different slide and/or with a position offset.

        Args:
            target_slide: Slide to place the clone (default: same slide)
            offset_x: Horizontal offset from original position (default: 0.25 inch)
            offset_y: Vertical offset from original position (default: 0.25 inch)

        Returns:
            Shape: The newly created cloned shape.

        Example:
            # Clone on same slide with default offset
            new_shape = shape.clone()

            # Clone to another slide
            new_shape = shape.clone(target_slide=prs.slides[2])

            # Clone with custom offset
            new_shape = shape.clone(offset_x=Inches(1), offset_y=Inches(1))

            # Clone in place (no offset)
            new_shape = shape.clone(offset_x=0, offset_y=0)
        """
        import uuid

        # Default offsets (~0.25 inch)
        offset_x_emu = int(ensure_emu(offset_x)) if offset_x is not None else 228600
        offset_y_emu = int(ensure_emu(offset_y)) if offset_y is not None else 228600

        target_slide_index = target_slide.slide_index if target_slide else None
        client_id = f"shp_{uuid.uuid4().hex[:8]}"

        cmd = CloneShape(
            shape_id=self._shape_id,
            target_slide_index=target_slide_index,
            offset_x_emu=offset_x_emu,
            offset_y_emu=offset_y_emu,
            client_id=client_id,
        )

        if self._buffer:
            response = self._buffer.add(cmd)
            shape_id = client_id
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]
        else:
            shape_id = client_id

        # Create local shape proxy for the clone
        target = target_slide if target_slide else self._slide
        new_shape = Shape(
            shape_id=shape_id,
            slide=target,
            buffer=self._buffer,
            element_type=self._element_type,
            transform=Transform(
                x=int(self.left) + offset_x_emu,
                y=int(self.top) + offset_y_emu,
                w=int(self.width),
                h=int(self.height),
                rot=self.rotation,
                flipH=self.flip_h,
                flipV=self.flip_v,
            ),
            preview_text=self._preview_text,
            properties=dict(self._properties),
            source="sdk",
        )
        target._shapes._shapes.append(new_shape)
        target._shapes._shapes_by_id[shape_id] = new_shape
        return new_shape

    @property
    def adjustments(self) -> dict[str, float]:
        """
        Adjustment values for adjustable shapes.

        Adjustment values control shape-specific parameters like corner radius
        for rounded rectangles, arrow head size, etc. Values are typically
        in the range 0.0 to 1.0.

        Returns:
            Dictionary of adjustment name to value

        Example:
            # Get current adjustments
            print(shape.adjustments)  # {'adj': 0.25}

            # Set adjustments
            shape.adjustments = {'adj': 0.5}  # More rounded corners
        """
        return self._properties.get("adjustments", {})

    @adjustments.setter
    def adjustments(self, value: dict[str, float]) -> None:
        """Set adjustment values for the shape."""
        self._properties["adjustments"] = value
        if self._buffer:
            cmd = SetShapeAdjustments(
                shape_id=self._shape_id,
                adjustments=value,
            )
            self._buffer.add(cmd)

    def ungroup(self) -> list["Shape"]:
        """
        Ungroup this group shape into its component shapes.

        Only applicable to group shapes (is_group == True).

        Returns:
            List of ungrouped shapes

        Raises:
            ValueError: If this shape is not a group

        Example:
            if shape.is_group:
                children = shape.ungroup()
                for child in children:
                    print(child.shape_id)
        """
        if not self.is_group:
            raise ValueError("Cannot ungroup a non-group shape")

        cmd = UngroupShapes(group_shape_id=self._shape_id)

        if self._buffer:
            self._buffer.add(cmd)

        # The server will return the ungrouped shapes; for now return empty list
        # as we don't have the response handling for this yet
        return []

    @property
    def is_placeholder(self) -> bool:
        """
        True if this shape is a placeholder.

        A placeholder is a pre-positioned shape on a slide layout that can be
        populated with content. Common placeholder types include title, body,
        picture, chart, and table.
        """
        return self._placeholder is not None

    @property
    def placeholder_format(self) -> Optional[PlaceholderFormat]:
        """
        Access placeholder properties for this shape.

        Returns a PlaceholderFormat object if the shape is a placeholder, or None
        if the shape is not a placeholder.

        Example:
            if shape.is_placeholder:
                ph = shape.placeholder_format
                print(f"Placeholder type: {ph.type}")
                print(f"Placeholder index: {ph.idx}")
        """
        if self._placeholder is None:
            return None
        return PlaceholderFormat(self._placeholder)

    def insert_picture(
        self,
        image_file: Union[str, Path, BytesIO, bytes],
        width: Optional[Length] = None,
        height: Optional[Length] = None,
    ) -> "Shape":
        """
        Insert a picture into this placeholder.

        Uses SubstitutePlaceholder command to preserve placeholder linkage
        (p:ph element) for correct OOXML round-trip fidelity.
        """
        if not self.is_placeholder:
            raise ValueError("insert_picture() is only valid on placeholder shapes")

        # Read and base64 encode the image
        if isinstance(image_file, bytes):
            image_data = image_file
        elif isinstance(image_file, BytesIO):
            image_data = image_file.read()
            image_file.seek(0)
        elif isinstance(image_file, (str, Path)):
            with open(str(image_file), 'rb') as f:
                image_data = f.read()
        else:
            raise TypeError(f"Unsupported image_file type: {type(image_file)}")

        image_base64 = base64.b64encode(image_data).decode('ascii')

        # Detect format from first bytes
        image_format = 'png'
        if image_data[:3] == b'\xff\xd8\xff':
            image_format = 'jpeg'
        elif image_data[:4] == b'GIF8':
            image_format = 'gif'
        elif image_data[:2] == b'BM':
            image_format = 'bmp'

        cmd = SubstitutePlaceholder(
            shape_id=self._shape_id,
            kind='picture',
            image_base64=image_base64,
            image_format=image_format,
        )
        if self._buffer:
            self._buffer.add(cmd)
        return self

    def insert_table(self, rows: int, cols: int) -> "GraphicFrame":
        """
        Insert a table into this placeholder.

        The placeholder is replaced by the new table shape.
        Returns a GraphicFrame; access the Table via .table property.
        Uses SubstitutePlaceholder command to preserve placeholder linkage
        (p:ph element) for correct OOXML round-trip fidelity.
        """
        if not self.is_placeholder:
            raise ValueError("insert_table() is only valid on placeholder shapes")

        cmd = SubstitutePlaceholder(
            shape_id=self._shape_id,
            kind='table',
            rows=rows,
            cols=cols,
        )
        if self._buffer:
            self._buffer.add(cmd)

        # Build the GraphicFrame + Table locally for immediate use
        transform = Transform(x=self.left, y=self.top, w=self.width, h=self.height) if self._transform else None
        table = Table(
            shape_id=self._shape_id,
            slide=self._slide,
            buffer=self._buffer,
            rows=rows,
            cols=cols,
            transform=transform,
        )
        graphic_frame = GraphicFrame(
            shape_id=self._shape_id,
            slide=self._slide,
            buffer=self._buffer,
            table=table,
            transform=transform,
        )
        return graphic_frame

    def insert_chart(self, chart_type, chart_data):
        """
        Insert a chart into this placeholder.

        Authoring path: emits an `AddChart` command targeted at the
        placeholder's slide and uses the placeholder's anchor as the chart
        bounding box. The export-worker materializes the chart-part XML
        and embedded workbook on the next export via
        `@pptx/chart-ooxml/export/author.ts`.
        """
        if not self.is_placeholder:
            raise ValueError("insert_chart() is only valid on placeholder shapes")
        from .chart.data import XyChartData, BubbleChartData

        chart_type_str, grouping = _split_chart_type(chart_type)

        if chart_type_str == "scatter":
            if not isinstance(chart_data, XyChartData):
                raise TypeError(
                    "insert_chart() with scatter chart_type requires an "
                    f"XyChartData instance (got {type(chart_data).__name__})"
                )
        elif chart_type_str == "bubble":
            if not isinstance(chart_data, BubbleChartData):
                raise TypeError(
                    "insert_chart() with bubble chart_type requires a "
                    f"BubbleChartData instance (got {type(chart_data).__name__})"
                )
        else:
            if not isinstance(chart_data, CategoryChartData):
                raise TypeError(
                    "insert_chart() with category chart_type requires a "
                    f"CategoryChartData instance (got {type(chart_data).__name__})"
                )

        categories = list(chart_data.categories) if isinstance(chart_data, CategoryChartData) else []

        transform = self._transform
        x_emu = int(ensure_emu(self.left)) if transform else 0
        y_emu = int(ensure_emu(self.top)) if transform else 0
        w_emu = int(ensure_emu(self.width)) if transform else 6_858_000
        h_emu = int(ensure_emu(self.height)) if transform else 4_572_000

        if self._buffer is not None:
            self._buffer.add(AddChartCmd(
                slide_index=self._slide.slide_index,
                chart_type=chart_type_str,
                x_emu=x_emu, y_emu=y_emu, w_emu=w_emu, h_emu=h_emu,
                categories=categories,
                series=chart_data.to_series_payload(),
                grouping=grouping,
            ))

        host_shape = Shape(
            shape_id=self._shape_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="chart",
            transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
            properties={"chartType": chart_type_str},
            source="sdk",
        )
        return GraphicFrame(
            shape_id=self._shape_id,
            slide=self._slide,
            buffer=self._buffer,
            chart=Chart(host_shape),
            transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
        )

    def __repr__(self) -> str:
        return f"<Shape shape_id='{self._shape_id}' type='{self._element_type}'>"


class Shapes:
    """
    Collection of shapes on a slide.

    Mirrors python-pptx's Shapes class.
    """

    def __init__(
        self,
        slide: Slide,
        buffer: Optional[CommandBuffer],
        elements: Optional[dict[str, ElementSnapshot]] = None,
        element_ids: Optional[list[str]] = None,
    ):
        self._slide = slide
        self._buffer = buffer
        # Slide-level shapes only — what ``slide.shapes`` iterates. Matches
        # python-pptx's contract that inherited content is reached via
        # ``slide.placeholders`` / ``slide.slide_layout.shapes`` instead.
        self._shapes: list[Shape] = []
        # All shapes (slide-level + inherited) keyed by id, used by lookups
        # like ``get_by_id`` and the placeholders collection.
        self._shapes_by_id: dict[ShapeId, Shape] = {}
        self._placeholders_by_idx: dict[int, Shape] = {}
        self._title_shape: Optional[Shape] = None
        # Track placeholder idx → True when seen on a slide-level shape so the
        # inherited counterpart at the same idx is suppressed (the slide-level
        # shell is the canonical write target — same dedup we use in the
        # placeholders endpoint).
        slide_level_ph_idxs: set[int] = set()

        # Build shapes from element snapshots
        if elements and element_ids:
            for elem_id in element_ids:
                elem = elements.get(elem_id)
                if elem:
                    shape: Shape
                    if elem.type == "table" and elem.table_data:
                        td = elem.table_data
                        # Extract look flags from snapshot (Phase 2) or legacy fields
                        look = td.get("look", {})
                        table = Table(
                            shape_id=elem.id,
                            slide=slide,
                            buffer=buffer,
                            rows=td.get("rows", 0),
                            cols=td.get("cols", 0),
                            transform=elem.transform,
                            column_widths_emu=td.get("columnWidthsEmu"),
                            row_heights_emu=td.get("rowHeightsEmu"),
                            first_row=look.get("firstRow", td.get("firstRowStyled", False)),
                            last_row=look.get("lastRow", td.get("lastRowStyled", False)),
                            first_col=look.get("firstCol", False),
                            last_col=look.get("lastCol", False),
                            horz_banding=look.get("bandRow", td.get("bandRow", False)),
                            vert_banding=look.get("bandCol", False),
                        )
                        # Populate cells from snapshot data
                        cells_data = td.get("cells", [])
                        for r_idx, row_data in enumerate(cells_data):
                            if not isinstance(row_data, list):
                                continue
                            for c_idx, cell_data in enumerate(row_data):
                                if r_idx < table._rows and c_idx < table._cols and isinstance(cell_data, dict):
                                    cell = table.cell(r_idx, c_idx)
                                    cell._text = cell_data.get("text", "")
                                    cell._fill_color_hex = cell_data.get("fillColorHex")
                                    cell._font_size_pt = cell_data.get("fontSizePt")
                                    # Phase 2: populate merge span
                                    span = cell_data.get("span")
                                    if isinstance(span, dict):
                                        cell._grid_span = span.get("gridSpan", 1)
                                        cell._row_span = span.get("rowSpan", 1)
                                        cell._h_merge = span.get("hMerge", False)
                                        cell._v_merge = span.get("vMerge", False)
                                    # Phase 2: populate margins from tcPr
                                    tcPr = cell_data.get("tcPr")
                                    if isinstance(tcPr, dict):
                                        cell._margin_left = tcPr.get("marL")
                                        cell._margin_right = tcPr.get("marR")
                                        cell._margin_top = tcPr.get("marT")
                                        cell._margin_bottom = tcPr.get("marB")
                                    # Legacy margin fields
                                    if cell._margin_left is None:
                                        cell._margin_left = cell_data.get("marginLeftEmu")
                                    if cell._margin_right is None:
                                        cell._margin_right = cell_data.get("marginRightEmu")
                                    if cell._margin_top is None:
                                        cell._margin_top = cell_data.get("marginTopEmu")
                                    if cell._margin_bottom is None:
                                        cell._margin_bottom = cell_data.get("marginBottomEmu")
                        table._properties = elem.properties or {}
                        table._preview_text = elem.preview_text
                        table._placeholder = elem.placeholder
                        table._source = elem.source
                        shape = table
                    else:
                        shape = Shape(
                            shape_id=elem.id,
                            slide=slide,
                            buffer=buffer,
                            element_type=elem.type,
                            transform=elem.transform,
                            preview_text=elem.preview_text,
                            properties=elem.properties,
                            placeholder=elem.placeholder,
                            source=elem.source,
                        )
                    self._shapes_by_id[elem.id] = shape
                    is_inherited = shape._is_inherited
                    if not is_inherited:
                        # ``slide.shapes`` iterator parity: only slide-level.
                        self._shapes.append(shape)
                        if elem.placeholder:
                            slide_level_ph_idxs.add(elem.placeholder.idx)

                    # Track placeholders by idx; slide-level wins over an
                    # inherited copy at the same idx (matches the placeholders
                    # endpoint dedup).
                    if elem.placeholder:
                        idx = elem.placeholder.idx
                        if is_inherited and idx in slide_level_ph_idxs:
                            pass  # suppressed — slide-level shell already there
                        elif (not is_inherited) or idx not in self._placeholders_by_idx:
                            self._placeholders_by_idx[idx] = shape
                        # Title placeholder has idx 0
                        if elem.placeholder.type in ("title", "ctrTitle") or idx == 0:
                            # Prefer the slide-level title; only fall back to an
                            # inherited title shell if no slide-level one exists.
                            if (not is_inherited) or self._title_shape is None:
                                self._title_shape = shape

    def __len__(self) -> int:
        """Number of shapes."""
        return len(self._shapes)

    def __iter__(self) -> Iterator[Shape]:
        """Iterate over shapes."""
        return iter(self._shapes)

    def __getitem__(self, key: int) -> Shape:
        """Get shape by index."""
        return self._shapes[key]

    def get_by_id(self, shape_id: ShapeId) -> Optional[Shape]:
        """Get shape by ID."""
        return self._shapes_by_id.get(shape_id)

    def index(self, shape: Shape) -> int:
        """
        Return the index of shape in the sequence.

        Args:
            shape: The shape to find

        Returns:
            Zero-based index of the shape

        Raises:
            ValueError: If shape is not in collection
        """
        for i, s in enumerate(self._shapes):
            if s.shape_id == shape.shape_id:
                return i
        raise ValueError("shape not in collection")

    def add_textbox(
        self,
        left: Length,
        top: Length,
        width: Length,
        height: Length,
    ) -> Shape:
        """
        Add a new textbox shape.

        Args:
            left: X position in EMU
            top: Y position in EMU
            width: Width in EMU
            height: Height in EMU

        Returns:
            The newly created Shape
        """
        import uuid

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width))
        h_emu = int(ensure_emu(height))

        # Generate a client ID for referencing in batch mode
        client_id = f"shp_{uuid.uuid4().hex[:8]}"

        # Mirror python-pptx auto-naming: "TextBox <count_after_add>".
        # python-pptx uses sp_id - 1 which equals slide-shape count after this add.
        name = f"TextBox {len(self._shapes) + 1}"

        # Create command with client ID
        cmd = AddTextBox(
            slide_index=self._slide.slide_index,
            x_emu=x_emu,
            y_emu=y_emu,
            w_emu=w_emu,
            h_emu=h_emu,
            client_id=client_id,
            name=name,
        )

        # Send command and get response
        if self._buffer:
            response = self._buffer.add(cmd)

            # Extract created shape ID from response (immediate mode)
            shape_id = client_id  # Use client_id by default
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

            # Create local shape proxy
            shape = Shape(
                shape_id=shape_id,
                slide=self._slide,
                buffer=self._buffer,
                element_type="text",
                transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
                preview_text="",
                source="sdk",
            )
            self._shapes.append(shape)
            self._shapes_by_id[shape_id] = shape
            return shape

        # If no buffer (unlikely), still create a local placeholder
        shape = Shape(
            shape_id=client_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="text",
            transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
            preview_text="",
            source="sdk",
        )
        self._shapes.append(shape)
        self._shapes_by_id[client_id] = shape
        return shape

    def add_picture(
        self,
        image_file: Union[str, Path, BytesIO, bytes],
        left: Length,
        top: Length,
        width: Optional[Length] = None,
        height: Optional[Length] = None,
    ) -> Shape:
        """
        Add a picture to the slide.

        Args:
            image_file: Path to image file, file-like object, or bytes
            left: X position
            top: Y position
            width: Width (optional - uses image native size if not specified)
            height: Height (optional)

        Returns:
            The newly created picture Shape
        """
        import uuid

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width)) if width else None
        h_emu = int(ensure_emu(height)) if height else None

        # Read image data and determine format
        if isinstance(image_file, bytes):
            image_data = image_file
        elif isinstance(image_file, BytesIO):
            image_data = image_file.read()
        else:
            # Treat as path
            path = Path(image_file)
            with open(path, 'rb') as f:
                image_data = f.read()

        # Determine format from magic bytes
        image_format = self._detect_image_format(image_data)

        # Convert to base64
        image_base64 = base64.b64encode(image_data).decode('ascii')

        client_id = f"pic_{uuid.uuid4().hex[:8]}"

        # Mirror python-pptx: "Picture <count_after_add>".
        name = f"Picture {len(self._shapes) + 1}"

        cmd = AddPictureCmd(
            slide_index=self._slide.slide_index,
            x_emu=x_emu,
            y_emu=y_emu,
            w_emu=w_emu,
            h_emu=h_emu,
            client_id=client_id,
            image_base64=image_base64,
            image_format=image_format,
            name=name,
        )

        if self._buffer:
            response = self._buffer.add(cmd)
            shape_id = client_id
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

            shape = Shape(
                shape_id=shape_id,
                slide=self._slide,
                buffer=self._buffer,
                element_type="image",
                transform=Transform(x=x_emu, y=y_emu, w=w_emu or 914400, h=h_emu or 914400),
                source="sdk",
            )
            self._shapes.append(shape)
            self._shapes_by_id[shape_id] = shape
            return shape

        shape = Shape(
            shape_id=client_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="image",
            transform=Transform(x=x_emu, y=y_emu, w=w_emu or 914400, h=h_emu or 914400),
            source="sdk",
        )
        self._shapes.append(shape)
        self._shapes_by_id[client_id] = shape
        return shape

    def _detect_image_format(self, data: bytes) -> str:
        """Detect image format from magic bytes."""
        if data[:8] == b'\x89PNG\r\n\x1a\n':
            return 'png'
        elif data[:2] == b'\xff\xd8':
            return 'jpeg'
        elif data[:6] in (b'GIF87a', b'GIF89a'):
            return 'gif'
        elif data[:2] == b'BM':
            return 'bmp'
        elif data[:4] in (b'II*\x00', b'MM\x00*'):
            return 'tiff'
        else:
            # Default to PNG
            return 'png'

    def add_shape(
        self,
        autoshape_type_id,
        left: Length,
        top: Length,
        width: Length,
        height: Length,
    ) -> Shape:
        """
        Add an autoshape to the slide.

        Matches the standard python-pptx ``shapes.add_shape()`` signature.

        Args:
            autoshape_type_id: Shape type — an ``MSO_SHAPE`` member
                (e.g., ``MSO_SHAPE.RECTANGLE``), integer ID, or string name.
            left: X position in EMU (use ``Inches()`` / ``Pt()`` helpers)
            top: Y position in EMU
            width: Width in EMU
            height: Height in EMU

        Returns:
            The newly created Shape
        """
        import uuid

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width))
        h_emu = int(ensure_emu(height))

        # Handle MSO_SHAPE enum values - convert to backend string type
        # Supports both our string-based MSO_SHAPE and python-pptx's IntEnum
        from .enum.shapes import mso_shape_to_string, mso_shape_basename
        shape_type = mso_shape_to_string(autoshape_type_id)

        client_id = f"shp_{uuid.uuid4().hex[:8]}"

        # Mirror python-pptx auto-naming: "<basename> <count_after_add>".
        # E.g., "Rectangle 2", "Oval 3", "Right Triangle 4".
        name = f"{mso_shape_basename(autoshape_type_id)} {len(self._shapes) + 1}"

        cmd = AddShapeCmd(
            slide_index=self._slide.slide_index,
            shape_type=shape_type,
            x_emu=x_emu,
            y_emu=y_emu,
            w_emu=w_emu,
            h_emu=h_emu,
            client_id=client_id,
            name=name,
        )

        if self._buffer:
            response = self._buffer.add(cmd)
            shape_id = client_id
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

            shape = Shape(
                shape_id=shape_id,
                slide=self._slide,
                buffer=self._buffer,
                element_type="shape",
                transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
                properties={"shapeType": shape_type},
                source="sdk",
            )
            self._shapes.append(shape)
            self._shapes_by_id[shape_id] = shape
            return shape

        shape = Shape(
            shape_id=client_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="shape",
            transform=Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu),
            properties={"shapeType": shape_type},
            source="sdk",
        )
        self._shapes.append(shape)
        self._shapes_by_id[client_id] = shape
        return shape

    def add_table(
        self,
        rows: int,
        cols: int,
        left: Length,
        top: Length,
        width: Length,
        height: Length,
    ) -> "GraphicFrame":
        """
        Add a table to the slide.

        Returns a GraphicFrame containing the Table, matching python-pptx
        semantics where SlideShapes.add_table() returns a GraphicFrame
        and the table is accessed via .table property.
        """
        import uuid

        if rows < 1:
            raise ValueError("rows must be >= 1")
        if cols < 1:
            raise ValueError("cols must be >= 1")

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width))
        h_emu = int(ensure_emu(height))

        client_id = f"tbl_{uuid.uuid4().hex[:8]}"
        shape_id = client_id

        # Mirror python-pptx: "Table <count_after_add>".
        name = f"Table {len(self._shapes) + 1}"

        if self._buffer:
            cmd = AddTableCmd(
                slide_index=self._slide.slide_index,
                rows=rows,
                cols=cols,
                x_emu=x_emu,
                y_emu=y_emu,
                w_emu=w_emu,
                h_emu=h_emu,
                client_id=client_id,
                name=name,
            )
            response = self._buffer.add(cmd)
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

        transform = Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu)
        table = Table(
            shape_id=shape_id,
            slide=self._slide,
            buffer=self._buffer,
            rows=rows,
            cols=cols,
            transform=transform,
        )
        graphic_frame = GraphicFrame(
            shape_id=shape_id,
            slide=self._slide,
            buffer=self._buffer,
            table=table,
            transform=transform,
        )
        graphic_frame._source = "sdk"
        self._shapes.append(graphic_frame)
        self._shapes_by_id[shape_id] = graphic_frame
        return graphic_frame

    # -------------------------------------------------------------------------
    # Phase 3: Connectors
    # -------------------------------------------------------------------------

    def add_connector(
        self,
        connector_type: Union[str, int],
        begin_x: Length,
        begin_y: Length,
        end_x: Length,
        end_y: Length,
        begin_shape: Optional[Shape] = None,
        end_shape: Optional[Shape] = None,
    ) -> Shape:
        """
        Add a connector line to the slide.

        Connectors can be free-floating (with explicit coordinates) or
        attached to shapes (using begin_shape/end_shape).

        Args:
            connector_type: Type of connector ('straight', 'elbow', 'curved')
            begin_x: Start X position (used if begin_shape is None)
            begin_y: Start Y position (used if begin_shape is None)
            end_x: End X position (used if end_shape is None)
            end_y: End Y position (used if end_shape is None)
            begin_shape: Shape to connect from (optional)
            end_shape: Shape to connect to (optional)

        Returns:
            The created connector Shape

        Example:
            # Free connector
            conn = shapes.add_connector(
                'straight',
                Inches(1), Inches(1),
                Inches(5), Inches(3)
            )

            # Connector between shapes
            conn = shapes.add_connector(
                'elbow',
                Inches(0), Inches(0),  # ignored when shape is specified
                Inches(0), Inches(0),
                begin_shape=shape1,
                end_shape=shape2
            )
        """
        import uuid
        from .enum.shapes import MSO_CONNECTOR_TYPE

        # python-pptx parity: accept either the ``MSO_CONNECTOR`` IntEnum
        # (``MSO_CONNECTOR.STRAIGHT``) or the lowercase string the backend
        # expects ('straight' | 'elbow' | 'curved').
        if isinstance(connector_type, int) and not isinstance(connector_type, bool):
            _enum_to_str = {
                int(MSO_CONNECTOR_TYPE.STRAIGHT): "straight",
                int(MSO_CONNECTOR_TYPE.ELBOW): "elbow",
                int(MSO_CONNECTOR_TYPE.CURVE): "curved",
            }
            mapped = _enum_to_str.get(connector_type)
            if mapped is None:
                raise ValueError(
                    f"Unsupported MSO_CONNECTOR value {connector_type!r}; "
                    "must be STRAIGHT, ELBOW, or CURVE"
                )
            connector_type = mapped

        begin_x_emu = int(ensure_emu(begin_x))
        begin_y_emu = int(ensure_emu(begin_y))
        end_x_emu = int(ensure_emu(end_x))
        end_y_emu = int(ensure_emu(end_y))

        client_id = f"conn_{uuid.uuid4().hex[:8]}"

        # Mirror python-pptx: "<basename> <count_after_add>", e.g. "Straight Connector 5".
        from .enum.shapes import mso_connector_basename
        name = f"{mso_connector_basename(connector_type)} {len(self._shapes) + 1}"

        cmd = AddConnectorCmd(
            slide_index=self._slide.slide_index,
            connector_type=connector_type,
            begin_shape_id=begin_shape._shape_id if begin_shape else None,
            begin_x_emu=begin_x_emu if not begin_shape else None,
            begin_y_emu=begin_y_emu if not begin_shape else None,
            end_shape_id=end_shape._shape_id if end_shape else None,
            end_x_emu=end_x_emu if not end_shape else None,
            end_y_emu=end_y_emu if not end_shape else None,
            client_id=client_id,
            name=name,
        )

        if self._buffer:
            response = self._buffer.add(cmd)
            shape_id = client_id
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]
        else:
            shape_id = client_id

        # Calculate approximate transform for connector
        x = min(begin_x_emu, end_x_emu)
        y = min(begin_y_emu, end_y_emu)
        w = abs(end_x_emu - begin_x_emu)
        h = abs(end_y_emu - begin_y_emu)

        shape = Shape(
            shape_id=shape_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="connector",
            transform=Transform(x=x, y=y, w=w, h=h),
            properties={"connectorType": connector_type},
            source="sdk",
        )
        self._shapes.append(shape)
        self._shapes_by_id[shape_id] = shape
        return shape

    def add_chart(
        self,
        chart_type: Any,
        x: Length,
        y: Length,
        cx: Length,
        cy: Length,
        chart_data: Any,
    ) -> "GraphicFrame":
        """Author a chart. ``x``/``y``/``cx``/``cy`` mirror python-pptx's
        ``SlideShapes.add_chart`` signature (top-left position and size in EMU).
        """
        left, top, width, height = x, y, cx, cy
        return self._add_chart_impl(chart_type, left, top, width, height, chart_data)

    def _add_chart_impl(
        self,
        chart_type: Any,
        left: Length,
        top: Length,
        width: Length,
        height: Length,
        chart_data: Any,
    ) -> "GraphicFrame":
        """
        Author a brand-new chart on this slide.

        Mirrors python-pptx's `SlideShapes.add_chart()`. Returns a
        `GraphicFrame` whose `.chart` property exposes the resulting
        `Chart` proxy. Edits via `chart.replace_data()` / `chart.chart_title`
        / `chart.has_legend` are emitted as `UpdateChartData` patches and
        applied on export.

        Supported chart types: `XL_CHART_TYPE.COLUMN_CLUSTERED`,
        `BAR_CLUSTERED`, `BAR_STACKED`, `BAR_STACKED_100`,
        `COLUMN_STACKED`, `COLUMN_STACKED_100`, `LINE`, `LINE_STACKED`,
        `LINE_STACKED_100`, `AREA`, `AREA_STACKED`, `AREA_STACKED_100`,
        `PIE`, `DOUGHNUT`, `XY_SCATTER` (and variants), and `BUBBLE`.
        Other types raise `UnsupportedFeatureError`.
        """
        import uuid
        from .chart.data import XyChartData, BubbleChartData

        chart_type_str, grouping = _split_chart_type(chart_type)

        # Validate chart_data shape against chart_type.
        if chart_type_str == "scatter":
            if not isinstance(chart_data, XyChartData):
                raise TypeError(
                    "add_chart() with scatter chart_type requires an XyChartData "
                    f"instance (got {type(chart_data).__name__})"
                )
        elif chart_type_str == "bubble":
            if not isinstance(chart_data, BubbleChartData):
                raise TypeError(
                    "add_chart() with bubble chart_type requires a BubbleChartData "
                    f"instance (got {type(chart_data).__name__})"
                )
        else:
            if not isinstance(chart_data, CategoryChartData):
                raise TypeError(
                    "add_chart() with category chart_type requires a CategoryChartData "
                    f"instance (got {type(chart_data).__name__})"
                )

        # Categories array — empty for XY/bubble (their x-values come via xValues).
        categories = list(chart_data.categories) if isinstance(chart_data, CategoryChartData) else []

        x_emu = int(ensure_emu(left))
        y_emu = int(ensure_emu(top))
        w_emu = int(ensure_emu(width))
        h_emu = int(ensure_emu(height))

        client_id = f"cht_{uuid.uuid4().hex[:8]}"
        shape_id = client_id

        if self._buffer:
            cmd = AddChartCmd(
                slide_index=self._slide.slide_index,
                chart_type=chart_type_str,
                x_emu=x_emu, y_emu=y_emu, w_emu=w_emu, h_emu=h_emu,
                categories=categories,
                series=chart_data.to_series_payload(),
                title=None,
                grouping=grouping,
                client_id=client_id,
            )
            response = self._buffer.add(cmd)
            if response and response.get("created"):
                shape_ids = response["created"].get("shapeIds", [])
                if shape_ids:
                    shape_id = shape_ids[0]

        transform = Transform(x=x_emu, y=y_emu, w=w_emu, h=h_emu)

        host_shape = Shape(
            shape_id=shape_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="chart",
            transform=transform,
            properties={"chartType": chart_type_str},
            source="sdk",
        )
        chart_proxy = Chart(host_shape)

        graphic_frame = GraphicFrame(
            shape_id=shape_id,
            slide=self._slide,
            buffer=self._buffer,
            chart=chart_proxy,
            transform=transform,
        )
        graphic_frame._source = "sdk"
        self._shapes.append(graphic_frame)
        self._shapes_by_id[shape_id] = graphic_frame
        return graphic_frame

    # -------------------------------------------------------------------------
    # Phase 5: Grouping
    # -------------------------------------------------------------------------

    def group_shapes(self, shapes: list[Shape]) -> Shape:
        """
        Group multiple shapes together into a single group shape.

        The grouped shapes will be treated as a single unit for moving,
        resizing, and other operations.

        Args:
            shapes: List of Shape objects to group (at least 2 shapes required)

        Returns:
            Shape: The newly created group shape

        Raises:
            ValueError: If fewer than 2 shapes are provided

        Example:
            # Group three shapes
            rect1 = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, ...)
            rect2 = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, ...)
            rect3 = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, ...)
            group = slide.shapes.group_shapes([rect1, rect2, rect3])

            # The group can be moved as a unit
            group.left = Inches(1)

            # Ungroup later if needed
            children = group.ungroup()
        """
        import uuid

        if len(shapes) < 2:
            raise ValueError("At least 2 shapes are required for grouping")

        shape_ids = [s.shape_id for s in shapes]
        client_id = f"grp_{uuid.uuid4().hex[:8]}"

        cmd = GroupShapes(
            slide_index=self._slide.slide_index,
            shape_ids=shape_ids,
            client_id=client_id,
        )

        if self._buffer:
            response = self._buffer.add(cmd)
            shape_id = client_id
            # If the buffer flushed eagerly (auto_batch=False, no batch context),
            # `add` returns the response and we can stamp the real id immediately.
            if response and response.get("created"):
                group_ids = response["created"].get("shapeIds", [])
                if group_ids:
                    shape_id = group_ids[0]
            elif response is None and not self._buffer.is_batching:
                # Inside auto-batch mode the buffer queues without sending. Force
                # a flush so the returned Shape has its real server-assigned id;
                # this lets ``group_shapes(...).ungroup()`` work in immediate
                # mode without depending on per-batch client-id resolution.
                # See parity-tests GAP_REPORT.md Gap #10.
                forced_response = self._buffer.flush()
                if forced_response and forced_response.get("created"):
                    group_ids = forced_response["created"].get("shapeIds", [])
                    if group_ids:
                        shape_id = group_ids[-1]
        else:
            shape_id = client_id

        # Calculate bounding box for the group
        left = min(int(s.left) for s in shapes)
        top = min(int(s.top) for s in shapes)
        right = max(int(s.right) for s in shapes)
        bottom = max(int(s.bottom) for s in shapes)

        group_shape = Shape(
            shape_id=shape_id,
            slide=self._slide,
            buffer=self._buffer,
            element_type="group",
            transform=Transform(x=left, y=top, w=right - left, h=bottom - top),
            properties={"childIds": shape_ids},
            source="sdk",
        )
        self._shapes.append(group_shape)
        self._shapes_by_id[shape_id] = group_shape
        return group_shape

    @property
    def title(self) -> Optional[Shape]:
        """
        Title placeholder shape on this slide, or None if not present.

        Returns the title placeholder shape if the slide has one. The title
        placeholder typically has idx 0 and type 'title' or 'ctrTitle'.

        Example:
            title = slide.shapes.title
            if title:
                title.text = "New Slide Title"
        """
        return self._title_shape

    @property
    def placeholders(self) -> "SlidePlaceholders":
        """
        Collection of placeholder shapes on this slide.

        Returns a SlidePlaceholders object that supports dictionary-style access
        by placeholder idx.

        Example:
            title = slide.placeholders[0]  # Title placeholder
            body = slide.placeholders[1]   # Body placeholder
        """
        return SlidePlaceholders(self._placeholders_by_idx)

    def _add_shape_from_snapshot(self, elem: ElementSnapshot) -> Shape:
        """Internal: Add a shape from a snapshot element."""
        shape = Shape(
            shape_id=elem.id,
            slide=self._slide,
            buffer=self._buffer,
            element_type=elem.type,
            transform=elem.transform,
            preview_text=elem.preview_text,
            properties=elem.properties,
            placeholder=elem.placeholder,
            source=elem.source,
        )
        self._shapes.append(shape)
        self._shapes_by_id[elem.id] = shape

        # Track placeholders by idx
        if elem.placeholder:
            self._placeholders_by_idx[elem.placeholder.idx] = shape
            if elem.placeholder.type in ("title", "ctrTitle") or elem.placeholder.idx == 0:
                self._title_shape = shape

        return shape

    # -------------------------------------------------------------------------
    # Convenience properties
    # -------------------------------------------------------------------------

    @property
    def first(self) -> Optional[Shape]:
        """
        First shape in the collection.

        Returns None if there are no shapes.
        """
        return self._shapes[0] if self._shapes else None

    @property
    def last(self) -> Optional[Shape]:
        """
        Last shape in the collection.

        Returns None if there are no shapes.
        """
        return self._shapes[-1] if self._shapes else None

    @property
    def is_empty(self) -> bool:
        """True if there are no shapes on this slide."""
        return len(self._shapes) == 0

    @property
    def count(self) -> int:
        """Number of shapes (alias for len())."""
        return len(self._shapes)

    # -------------------------------------------------------------------------
    # Convenience search and filter methods
    # -------------------------------------------------------------------------

    def filter_by_type(self, element_type: str) -> list[Shape]:
        """
        Get all shapes of a specific type.

        Args:
            element_type: The type to filter by ('text', 'image', 'shape', 'table')

        Returns:
            List of shapes matching the type
        """
        # ``shape_type`` returns the python-pptx ``MSO_SHAPE_TYPE`` enum;
        # internal callers pass the raw element-type string ('text',
        # 'image', etc.), so compare against ``_element_type`` directly.
        return [s for s in self._shapes if s._element_type == element_type]

    def filter_by_text(self, text_contains: str, case_sensitive: bool = False) -> list[Shape]:
        """
        Get all shapes containing specific text.

        Args:
            text_contains: Text substring to search for
            case_sensitive: Whether to do case-sensitive search (default: False)

        Returns:
            List of shapes containing the text
        """
        results = []
        search_text = text_contains if case_sensitive else text_contains.lower()
        for shape in self._shapes:
            if shape.has_text_frame:
                shape_text = shape.text if case_sensitive else shape.text.lower()
                if search_text in shape_text:
                    results.append(shape)
        return results

    def find_by_text(self, text: str, case_sensitive: bool = False) -> Optional[Shape]:
        """
        Find the first shape with exactly matching text.

        Args:
            text: Exact text to match
            case_sensitive: Whether to do case-sensitive match (default: False)

        Returns:
            The first matching shape, or None
        """
        search_text = text if case_sensitive else text.lower()
        for shape in self._shapes:
            if shape.has_text_frame:
                shape_text = shape.text if case_sensitive else shape.text.lower()
                if shape_text == search_text:
                    return shape
        return None

    def get_textboxes(self) -> list[Shape]:
        """Get all text shapes (convenience method)."""
        return self.filter_by_type('text')

    def get_images(self) -> list[Shape]:
        """Get all image shapes (convenience method)."""
        return self.filter_by_type('image')

    def get_tables(self) -> list["Table"]:
        """Get all table shapes (convenience method)."""
        return [s for s in self._shapes if s.shape_type == 'table']

    def get_autoshapes(self) -> list[Shape]:
        """Get all autoshape shapes (convenience method)."""
        return self.filter_by_type('shape')

    def get_placeholders_list(self) -> list[Shape]:
        """Get all placeholder shapes as a list."""
        return [s for s in self._shapes if s.is_placeholder]

    # -------------------------------------------------------------------------
    # Bounding box and geometry methods
    # -------------------------------------------------------------------------

    def get_bounding_box(self) -> Optional[tuple[Emu, Emu, Emu, Emu]]:
        """
        Get the bounding box that contains all shapes.

        Returns:
            Tuple of (left, top, right, bottom) in EMU, or None if no shapes
        """
        if not self._shapes:
            return None

        left = min(int(s.left) for s in self._shapes)
        top = min(int(s.top) for s in self._shapes)
        right = max(int(s.right) for s in self._shapes)
        bottom = max(int(s.bottom) for s in self._shapes)

        return (Emu(left), Emu(top), Emu(right), Emu(bottom))

    def get_total_area(self) -> Emu:
        """
        Get the total area of all shapes combined.

        Returns:
            Total area in square EMU
        """
        return Emu(sum(int(s.width) * int(s.height) for s in self._shapes))

    # -------------------------------------------------------------------------
    # Sorting methods
    # -------------------------------------------------------------------------

    def sorted_by_left(self, reverse: bool = False) -> list[Shape]:
        """
        Get shapes sorted by left position.

        Args:
            reverse: If True, sort right-to-left

        Returns:
            List of shapes sorted by left position
        """
        return sorted(self._shapes, key=lambda s: int(s.left), reverse=reverse)

    def sorted_by_top(self, reverse: bool = False) -> list[Shape]:
        """
        Get shapes sorted by top position.

        Args:
            reverse: If True, sort bottom-to-top

        Returns:
            List of shapes sorted by top position
        """
        return sorted(self._shapes, key=lambda s: int(s.top), reverse=reverse)

    def sorted_by_area(self, reverse: bool = False) -> list[Shape]:
        """
        Get shapes sorted by area (width * height).

        Args:
            reverse: If True, sort largest first

        Returns:
            List of shapes sorted by area
        """
        return sorted(
            self._shapes,
            key=lambda s: int(s.width) * int(s.height),
            reverse=reverse
        )

    def sorted_by_width(self, reverse: bool = False) -> list[Shape]:
        """
        Get shapes sorted by width.

        Args:
            reverse: If True, sort widest first

        Returns:
            List of shapes sorted by width
        """
        return sorted(self._shapes, key=lambda s: int(s.width), reverse=reverse)

    def sorted_by_height(self, reverse: bool = False) -> list[Shape]:
        """
        Get shapes sorted by height.

        Args:
            reverse: If True, sort tallest first

        Returns:
            List of shapes sorted by height
        """
        return sorted(self._shapes, key=lambda s: int(s.height), reverse=reverse)

    # -------------------------------------------------------------------------
    # Selection methods
    # -------------------------------------------------------------------------

    def get_largest(self) -> Optional[Shape]:
        """Get the shape with the largest area."""
        if not self._shapes:
            return None
        return max(self._shapes, key=lambda s: int(s.width) * int(s.height))

    def get_smallest(self) -> Optional[Shape]:
        """Get the shape with the smallest area."""
        if not self._shapes:
            return None
        return min(self._shapes, key=lambda s: int(s.width) * int(s.height))

    def get_leftmost(self) -> Optional[Shape]:
        """Get the leftmost shape."""
        if not self._shapes:
            return None
        return min(self._shapes, key=lambda s: int(s.left))

    def get_rightmost(self) -> Optional[Shape]:
        """Get the rightmost shape (by right edge)."""
        if not self._shapes:
            return None
        return max(self._shapes, key=lambda s: int(s.right))

    def get_topmost(self) -> Optional[Shape]:
        """Get the topmost shape."""
        if not self._shapes:
            return None
        return min(self._shapes, key=lambda s: int(s.top))

    def get_bottommost(self) -> Optional[Shape]:
        """Get the bottommost shape (by bottom edge)."""
        if not self._shapes:
            return None
        return max(self._shapes, key=lambda s: int(s.bottom))

    def get_shapes_at_point(self, x: Length, y: Length) -> list[Shape]:
        """
        Get all shapes that contain a specific point.

        Args:
            x: X coordinate
            y: Y coordinate

        Returns:
            List of shapes containing the point
        """
        return [s for s in self._shapes if s.contains_point(x, y)]

    def get_overlapping(self, shape: Shape) -> list[Shape]:
        """
        Get all shapes that overlap with a given shape.

        Args:
            shape: Shape to check overlaps with

        Returns:
            List of shapes that intersect with the given shape
        """
        return [s for s in self._shapes if s != shape and s.intersects(shape)]

    def __repr__(self) -> str:
        return f"<Shapes count={len(self._shapes)}>"


class SlidePlaceholders:
    """
    Collection of placeholder shapes on a slide.

    Provides dictionary-style access to placeholder shapes by their idx value.
    Mirrors python-pptx's SlidePlaceholders class.
    """

    def __init__(self, placeholders_by_idx: dict[int, Shape]):
        self._placeholders = placeholders_by_idx

    def __len__(self) -> int:
        """Number of placeholders."""
        return len(self._placeholders)

    def __iter__(self) -> Iterator[Shape]:
        """Iterate over placeholder shapes in idx order."""
        for idx in sorted(self._placeholders.keys()):
            yield self._placeholders[idx]

    def __getitem__(self, key: int) -> Shape:
        """
        Get placeholder by idx.

        Args:
            key: Placeholder idx value (0 for title, etc.)

        Returns:
            The placeholder Shape

        Raises:
            KeyError: If no placeholder with that idx exists
        """
        if key not in self._placeholders:
            raise KeyError(f"No placeholder with idx={key} on this slide")
        return self._placeholders[key]

    def __contains__(self, key: int) -> bool:
        """Check if a placeholder with the given idx exists."""
        return key in self._placeholders

    def get(self, idx: int, default: Optional[Shape] = None) -> Optional[Shape]:
        """
        Get placeholder by idx, or default if not found.

        Args:
            idx: Placeholder idx value
            default: Value to return if placeholder not found

        Returns:
            The placeholder Shape or default
        """
        return self._placeholders.get(idx, default)

    def keys(self) -> Iterator[int]:
        """Iterate over placeholder idx values."""
        return iter(sorted(self._placeholders.keys()))

    def values(self) -> Iterator[Shape]:
        """Iterate over placeholder shapes."""
        return iter(self)

    def items(self) -> Iterator[tuple[int, Shape]]:
        """Iterate over (idx, shape) pairs."""
        for idx in sorted(self._placeholders.keys()):
            yield idx, self._placeholders[idx]

    # -------------------------------------------------------------------------
    # Convenience properties and methods
    # -------------------------------------------------------------------------

    @property
    def title(self) -> Optional[Shape]:
        """
        Get title placeholder (idx 0).

        Returns None if no title placeholder exists.
        """
        return self._placeholders.get(0)

    @property
    def body(self) -> Optional[Shape]:
        """
        Get body/content placeholder (idx 1).

        Returns None if no body placeholder exists.
        """
        return self._placeholders.get(1)

    @property
    def subtitle(self) -> Optional[Shape]:
        """
        Get subtitle placeholder.

        Searches for a placeholder with subtitle type.
        Returns None if not found.
        """
        for shape in self._placeholders.values():
            if shape.placeholder_format and shape.placeholder_format.is_subtitle:
                return shape
        return None

    @property
    def has_title(self) -> bool:
        """True if a title placeholder exists."""
        return 0 in self._placeholders

    @property
    def has_body(self) -> bool:
        """True if a body placeholder exists."""
        return 1 in self._placeholders

    @property
    def count(self) -> int:
        """Number of placeholders."""
        return len(self._placeholders)

    @property
    def is_empty(self) -> bool:
        """True if there are no placeholders."""
        return len(self._placeholders) == 0

    @property
    def indices(self) -> list[int]:
        """List of all placeholder indices."""
        return sorted(self._placeholders.keys())

    def get_by_type(self, type_name: str) -> Optional[Shape]:
        """
        Get placeholder by type name.

        Args:
            type_name: Placeholder type (e.g., 'title', 'body', 'pic', 'chart')

        Returns:
            First placeholder matching the type, or None
        """
        for shape in self._placeholders.values():
            if shape.placeholder_format:
                if shape.placeholder_format._type_str == type_name:
                    return shape
        return None

    def filter_by_type(self, type_name: str) -> list[Shape]:
        """
        Get all placeholders of a specific type.

        Args:
            type_name: Placeholder type to filter by

        Returns:
            List of placeholders matching the type
        """
        results = []
        for shape in self._placeholders.values():
            if shape.placeholder_format:
                if shape.placeholder_format._type_str == type_name:
                    results.append(shape)
        return results

    def __repr__(self) -> str:
        return f"<SlidePlaceholders count={len(self._placeholders)}>"


class _TableCellFillColorFormat(ColorFormat):
    """ColorFormat subclass that writes back to a TableCell's _fill_color_hex."""

    def __init__(self, fill_format: "_TableCellFillFormat", rgb: Optional[RGBColor] = None):
        super().__init__(rgb=rgb)
        self._fill_format = fill_format

    @ColorFormat.rgb.setter
    def rgb(self, value: RGBColor) -> None:
        if not isinstance(value, RGBColor):
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._rgb = value
        self._theme_color = None
        self._fill_format._on_color_change(str(value))


class _TableCellFillFormat:
    """python-pptx-compatible ``FillFormat`` adapter for a single table cell.

    python-pptx's ``_Cell.fill`` returns a ``FillFormat`` so callers do
    ``cell.fill.solid(); cell.fill.fore_color.rgb = RGBColor(...)``. Our
    ``TableCell`` keeps cell state on ``_fill_color_hex`` and emits
    ``SetTableCell`` commands, so this adapter just routes the standard
    API into the existing per-cell command pipeline.
    """

    def __init__(self, cell: "TableCell"):
        self._cell = cell
        rgb = (
            RGBColor.from_string(cell._fill_color_hex)
            if cell._fill_color_hex
            else None
        )
        self._type: Optional[str] = "solid" if cell._fill_color_hex else None
        self._fore_color_format = _TableCellFillColorFormat(self, rgb=rgb)

    def solid(self) -> None:
        self._type = "solid"
        if self._cell._fill_color_hex is None:
            self._cell._fill_color_hex = "FFFFFF"
            self._fore_color_format._rgb = RGBColor(255, 255, 255)
            self._cell._emit_cell_change()

    def background(self) -> None:
        self._type = None
        self._cell._fill_color_hex = None
        self._fore_color_format._rgb = None
        self._cell._emit_cell_change()

    @property
    def type(self) -> Optional[str]:
        return self._type

    @property
    def fore_color(self) -> _TableCellFillColorFormat:
        return self._fore_color_format

    def _on_color_change(self, hex_value: str) -> None:
        self._cell._fill_color_hex = hex_value.upper()
        self._type = "solid"
        self._cell._emit_cell_change()


class _TableCellFontColorFormat(ColorFormat):
    """ColorFormat subclass that writes back to a TableCell's _font_color_hex."""

    def __init__(self, font: "_TableCellRunFont", rgb: Optional[RGBColor] = None):
        super().__init__(rgb=rgb)
        self._font = font

    @ColorFormat.rgb.setter
    def rgb(self, value: RGBColor) -> None:
        if not isinstance(value, RGBColor):
            raise TypeError(f"Expected RGBColor, got {type(value).__name__}")
        self._rgb = value
        self._theme_color = None
        self._font._on_color_change(str(value))


class _TableCellRunFont:
    """``Font`` adapter for the synthetic single-run inside a table cell.

    Routes ``font.bold/.size/.color.rgb`` to the cell's existing
    ``_bold/_font_size_pt/_font_color_hex`` fields, then triggers
    ``_emit_cell_change`` so the same SetTableCell command picks the
    update up.
    """

    def __init__(self, cell: "TableCell"):
        self._cell = cell
        rgb = (
            RGBColor.from_string(cell._font_color_hex)
            if cell._font_color_hex
            else None
        )
        self._color_format = _TableCellFontColorFormat(self, rgb=rgb)

    @property
    def bold(self) -> Optional[bool]:
        return self._cell._bold

    @bold.setter
    def bold(self, value: bool) -> None:
        self._cell._bold = value
        self._cell._emit_cell_change()

    @property
    def size(self) -> Optional[int]:
        if self._cell._font_size_pt is None:
            return None
        from .units import EMU_PER_PT

        return int(self._cell._font_size_pt * EMU_PER_PT)

    @size.setter
    def size(self, value: int) -> None:
        from .units import EMU_PER_PT

        self._cell._font_size_pt = float(value) / EMU_PER_PT
        self._cell._emit_cell_change()

    @property
    def color(self) -> _TableCellFontColorFormat:
        return self._color_format

    def _on_color_change(self, hex_value: str) -> None:
        self._cell._font_color_hex = hex_value.upper()
        self._cell._emit_cell_change()


class _TableCellRun:
    """Synthetic single-run for a table cell — exposes ``font`` and ``text``."""

    def __init__(self, cell: "TableCell"):
        self._cell = cell
        self._font = _TableCellRunFont(cell)

    @property
    def font(self) -> _TableCellRunFont:
        return self._font

    @property
    def text(self) -> str:
        return self._cell._text

    @text.setter
    def text(self, value: str) -> None:
        self._cell.text = value


class _TableCellParagraph:
    """Synthetic single-paragraph for a table cell.

    Real python-pptx supports multi-paragraph and multi-run cells; this
    shim collapses everything into one paragraph + one run that maps to
    the existing per-cell style (``_bold/_font_size_pt/_font_color_hex``).
    Fine for the common header-row formatting use case; richer cells
    will need a real ``<a:txBody>`` model on the server side.
    """

    def __init__(self, cell: "TableCell"):
        self._cell = cell
        self._runs = [_TableCellRun(cell)]

    @property
    def runs(self) -> list[_TableCellRun]:
        return self._runs

    @property
    def text(self) -> str:
        return self._cell._text

    @text.setter
    def text(self, value: str) -> None:
        self._cell.text = value


class _TableCellTextFrame:
    """``TextFrame`` adapter for a table cell.

    Real python-pptx returns a full TextFrame here; we expose a single
    paragraph with a single run so the common ``cell.text_frame.
    paragraphs[0].runs[0].font.bold = True`` recipe works.
    """

    def __init__(self, cell: "TableCell"):
        self._cell = cell
        self._paragraphs = [_TableCellParagraph(cell)]

    @property
    def paragraphs(self) -> list[_TableCellParagraph]:
        return self._paragraphs

    @property
    def text(self) -> str:
        return self._cell._text

    @text.setter
    def text(self, value: str) -> None:
        self._cell.text = value


class TableCell:
    """
    A single cell in a table.

    Provides access to cell text, formatting, merge semantics, and margins.
    Mirrors python-pptx's _Cell API where applicable.
    """

    def __init__(
        self,
        table: "Table",
        row: int,
        col: int,
        text: str = "",
        fill_color_hex: Optional[str] = None,
        font_size_pt: Optional[float] = None,
        bold: Optional[bool] = None,
        font_color_hex: Optional[str] = None,
        *,
        grid_span: int = 1,
        row_span: int = 1,
        h_merge: bool = False,
        v_merge: bool = False,
        margin_left: Optional[int] = None,
        margin_right: Optional[int] = None,
        margin_top: Optional[int] = None,
        margin_bottom: Optional[int] = None,
        vertical_anchor: Optional[str] = None,
    ):
        self._table = table
        self._row = row
        self._col = col
        self._text = text
        self._fill_color_hex = fill_color_hex
        self._font_size_pt = font_size_pt
        self._bold = bold
        self._font_color_hex = font_color_hex
        self._grid_span = grid_span
        self._row_span = row_span
        self._h_merge = h_merge
        self._v_merge = v_merge
        self._margin_left = margin_left
        self._margin_right = margin_right
        self._margin_top = margin_top
        self._margin_bottom = margin_bottom
        self._vertical_anchor = vertical_anchor

    @property
    def text(self) -> str:
        """Cell text content."""
        return self._text

    @text.setter
    def text(self, value: str) -> None:
        """Set cell text."""
        self._text = value
        self._emit_cell_change()

    @property
    def fill(self) -> "_TableCellFillFormat":
        """Cell fill, as a python-pptx-compatible :class:`FillFormat` adapter.

        Use ``cell.fill.solid()`` then ``cell.fill.fore_color.rgb = RGBColor(...)``
        to set a solid fill, or ``cell.fill.background()`` to clear it. The
        previous string-assignment shorthand (``cell.fill = "FF0000"``) is
        preserved via the setter for backwards compatibility, but new code
        should use the python-pptx form.
        """
        if not hasattr(self, "_fill_format") or self._fill_format is None:
            self._fill_format = _TableCellFillFormat(self)
        return self._fill_format

    @fill.setter
    def fill(self, value: str) -> None:
        """Backwards-compat: set cell fill from a hex string."""
        if isinstance(value, str):
            if value.startswith('#'):
                value = value[1:]
            self._fill_color_hex = value.upper()
            # Keep the FillFormat adapter (if any) in sync.
            if hasattr(self, "_fill_format") and self._fill_format is not None:
                self._fill_format._fore_color_format._rgb = RGBColor.from_string(self._fill_color_hex)
                self._fill_format._type = "solid"
            self._emit_cell_change()
        else:
            raise TypeError(
                "TableCell.fill = ... only accepts a hex string for "
                "backwards compatibility. Use cell.fill.solid() and "
                "cell.fill.fore_color.rgb = RGBColor(...) instead."
            )

    @property
    def text_frame(self) -> "_TableCellTextFrame":
        """Cell ``text_frame`` adapter (python-pptx compatible).

        Exposes a single paragraph with a single run whose ``font`` maps
        to the cell's per-cell style fields. Suitable for the common
        ``cell.text_frame.paragraphs[0].runs[0].font.bold = True`` recipe;
        multi-paragraph / multi-run cells need a server-side text body
        model that doesn't exist yet.
        """
        if not hasattr(self, "_text_frame_adapter") or self._text_frame_adapter is None:
            self._text_frame_adapter = _TableCellTextFrame(self)
        return self._text_frame_adapter

    @property
    def font_size_pt(self) -> Optional[float]:
        """Font size in points. None if not available."""
        return self._font_size_pt

    @font_size_pt.setter
    def font_size_pt(self, value: float) -> None:
        """Set font size in points."""
        self._font_size_pt = value
        self._emit_cell_change()

    @property
    def bold(self) -> Optional[bool]:
        """Bold text. None if not set."""
        return self._bold

    @bold.setter
    def bold(self, value: bool) -> None:
        """Set bold text."""
        self._bold = value
        self._emit_cell_change()

    @property
    def font_color_hex(self) -> Optional[str]:
        """Font color as hex string. None if not set."""
        return self._font_color_hex

    @font_color_hex.setter
    def font_color_hex(self, value: str) -> None:
        """Set font color as hex string."""
        if value.startswith('#'):
            value = value[1:]
        self._font_color_hex = value.upper()
        self._emit_cell_change()

    # -------------------------------------------------------------------------
    # Agent-friendly aliases (common patterns in LLM-generated code)
    # -------------------------------------------------------------------------

    @property
    def font_bold(self) -> Optional[bool]:
        """Alias for bold."""
        return self._bold

    @font_bold.setter
    def font_bold(self, value: bool) -> None:
        self._bold = value
        self._emit_cell_change()

    @property
    def font_color_rgb(self) -> Optional[tuple]:
        """Font color as (R, G, B) tuple. None if not set."""
        if not self._font_color_hex:
            return None
        h = self._font_color_hex
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))

    @font_color_rgb.setter
    def font_color_rgb(self, value: tuple) -> None:
        """Set font color from (R, G, B) tuple."""
        self._font_color_hex = f"{value[0]:02X}{value[1]:02X}{value[2]:02X}"
        self._emit_cell_change()

    @property
    def fill_color_rgb(self) -> Optional[tuple]:
        """Fill color as (R, G, B) tuple. None if not set."""
        if not self._fill_color_hex:
            return None
        h = self._fill_color_hex
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))

    @fill_color_rgb.setter
    def fill_color_rgb(self, value: Union[tuple, str]) -> None:
        """Set fill color from (R, G, B) tuple or hex string."""
        if isinstance(value, str):
            self._fill_color_hex = value.lstrip('#').upper()
        elif isinstance(value, tuple):
            self._fill_color_hex = f"{value[0]:02X}{value[1]:02X}{value[2]:02X}"
        self._emit_cell_change()

    # -------------------------------------------------------------------------
    # Merge properties (python-pptx _Cell parity)
    # -------------------------------------------------------------------------

    @property
    def is_merge_origin(self) -> bool:
        """True if this cell is the top-left origin of a merged region."""
        return (self._grid_span > 1 or self._row_span > 1) and not self._h_merge and not self._v_merge

    @property
    def is_spanned(self) -> bool:
        """True if this cell is covered by a merge (not the origin)."""
        return self._h_merge or self._v_merge

    @property
    def span_width(self) -> int:
        """Number of columns this cell spans (meaningful on merge origin)."""
        return self._grid_span

    @property
    def span_height(self) -> int:
        """Number of rows this cell spans (meaningful on merge origin)."""
        return self._row_span

    def merge(self, other_cell: "TableCell") -> None:
        """
        Merge this cell with other_cell, creating a merged region.

        The merge region is the bounding rectangle from this cell to other_cell.
        Matches python-pptx _Cell.merge() semantics.

        Args:
            other_cell: The bottom-right cell of the merge region.

        Raises:
            ValueError: If cells are not in the same table or region is invalid.
        """
        if other_cell._table is not self._table:
            raise ValueError("Cannot merge cells from different tables")

        start_row = min(self._row, other_cell._row)
        start_col = min(self._col, other_cell._col)
        end_row = max(self._row, other_cell._row)
        end_col = max(self._col, other_cell._col)

        if start_row == end_row and start_col == end_col:
            return  # Single cell, nothing to merge

        # Update local span state
        col_span = end_col - start_col + 1
        row_span = end_row - start_row + 1

        for r in range(start_row, end_row + 1):
            for c in range(start_col, end_col + 1):
                cell = self._table._cells[r][c]
                if r == start_row and c == start_col:
                    cell._grid_span = col_span
                    cell._row_span = row_span
                    cell._h_merge = False
                    cell._v_merge = False
                else:
                    cell._grid_span = 1
                    cell._row_span = 1
                    cell._h_merge = c > start_col
                    cell._v_merge = r > start_row

        if self._table._buffer:
            cmd = MergeCellsCmd(
                shape_id=self._table._shape_id,
                start_row=start_row,
                start_col=start_col,
                end_row=end_row,
                end_col=end_col,
            )
            self._table._buffer.add(cmd)

    def split(self) -> None:
        """
        Split (unmerge) this cell if it is a merge origin.

        Matches python-pptx _Cell.split() semantics.
        """
        if not self.is_merge_origin:
            return

        end_row = self._row + self._row_span
        end_col = self._col + self._grid_span

        for r in range(self._row, end_row):
            for c in range(self._col, end_col):
                cell = self._table._cells[r][c]
                cell._grid_span = 1
                cell._row_span = 1
                cell._h_merge = False
                cell._v_merge = False

        if self._table._buffer:
            cmd = SplitCellCmd(
                shape_id=self._table._shape_id,
                row=self._row,
                col=self._col,
            )
            self._table._buffer.add(cmd)

    # -------------------------------------------------------------------------
    # Margin properties (python-pptx _Cell parity)
    # -------------------------------------------------------------------------

    @property
    def margin_left(self) -> Optional[int]:
        """Left margin in EMU. None means default."""
        return self._margin_left

    @margin_left.setter
    def margin_left(self, value: Optional[int]) -> None:
        self._margin_left = value
        self._emit_margin_change()

    @property
    def margin_right(self) -> Optional[int]:
        """Right margin in EMU. None means default."""
        return self._margin_right

    @margin_right.setter
    def margin_right(self, value: Optional[int]) -> None:
        self._margin_right = value
        self._emit_margin_change()

    @property
    def margin_top(self) -> Optional[int]:
        """Top margin in EMU. None means default."""
        return self._margin_top

    @margin_top.setter
    def margin_top(self, value: Optional[int]) -> None:
        self._margin_top = value
        self._emit_margin_change()

    @property
    def margin_bottom(self) -> Optional[int]:
        """Bottom margin in EMU. None means default."""
        return self._margin_bottom

    @margin_bottom.setter
    def margin_bottom(self, value: Optional[int]) -> None:
        self._margin_bottom = value
        self._emit_margin_change()

    @property
    def vertical_anchor(self) -> Optional[str]:
        """python-pptx parity: vertical text anchor inside the cell.

        Returns one of ``'top' | 'middle' | 'bottom' | None``. Maps to
        OOXML ``<a:tc><a:tcPr anchor="t|ctr|b">``.
        """
        # Stored as the raw OOXML token to round-trip cleanly via the
        # SetCellTcPr applier; project to the python-pptx spelling here.
        token = self._vertical_anchor
        if token is None:
            return None
        return {"t": "top", "ctr": "middle", "b": "bottom"}.get(token, token)

    @vertical_anchor.setter
    def vertical_anchor(self, value: Any) -> None:
        # Accept python-pptx's MSO_ANCHOR IntEnum, the python-pptx string
        # form ('top'/'middle'/'bottom'), or the raw OOXML token
        # ('t'/'ctr'/'b'). Normalize to the OOXML token before emit.
        from .commands import SetCellAnchor

        token: Optional[str]
        if value is None:
            token = None
        elif isinstance(value, int):
            # MSO_ANCHOR: TOP=1, MIDDLE=3, BOTTOM=4 (matches python-pptx).
            token = {1: "t", 3: "ctr", 4: "b"}.get(value)
            if token is None:
                raise ValueError(
                    f"Unsupported MSO_ANCHOR int value: {value}"
                )
        elif isinstance(value, str):
            v = value.lower()
            mapping = {
                "top": "t",
                "middle": "ctr",
                "bottom": "b",
                "t": "t",
                "ctr": "ctr",
                "b": "b",
            }
            if v not in mapping:
                raise ValueError(
                    f"vertical_anchor must be 'top'/'middle'/'bottom' "
                    f"(or MSO_ANCHOR enum), got {value!r}"
                )
            token = mapping[v]
        else:
            raise TypeError(
                f"vertical_anchor expected MSO_ANCHOR / str / None, "
                f"got {type(value).__name__}"
            )

        self._vertical_anchor = token
        if self._table._buffer:
            self._table._buffer.add(SetCellAnchor(
                shape_id=self._table._shape_id,
                row=self._row,
                col=self._col,
                anchor=token,
            ))

    def _emit_margin_change(self) -> None:
        """Emit a SetCellMargins command."""
        if self._table._buffer:
            cmd = SetCellMargins(
                shape_id=self._table._shape_id,
                row=self._row,
                col=self._col,
                mar_l_emu=self._margin_left,
                mar_r_emu=self._margin_right,
                mar_t_emu=self._margin_top,
                mar_b_emu=self._margin_bottom,
            )
            self._table._buffer.add(cmd)

    def _emit_cell_change(self) -> None:
        """Emit a SetTableCell command."""
        if self._table._buffer:
            cmd = SetTableCell(
                shape_id=self._table._shape_id,
                row=self._row,
                col=self._col,
                text=self._text,
                fill_color_hex=self._fill_color_hex,
                font_size_centipoints=int(self._font_size_pt * 100) if self._font_size_pt is not None else None,
                bold=self._bold,
                font_color_hex=self._font_color_hex,
            )
            self._table._buffer.add(cmd)

    # -------------------------------------------------------------------------
    # Convenience properties and methods
    # -------------------------------------------------------------------------

    @property
    def row_index(self) -> int:
        """Zero-based row index of this cell."""
        return self._row

    @property
    def column_index(self) -> int:
        """Zero-based column index of this cell."""
        return self._col

    @property
    def is_empty(self) -> bool:
        """True if cell has no content or only whitespace."""
        return not self._text or self._text.strip() == ""

    @property
    def has_fill(self) -> bool:
        """True if cell has a background fill color."""
        return self._fill_color_hex is not None

    def clear(self) -> None:
        """Clear cell text content."""
        self.text = ""

    def __len__(self) -> int:
        """Return text length (allows len(cell))."""
        return len(self._text)

    def __str__(self) -> str:
        """Return cell text (allows str(cell))."""
        return self._text

    def __bool__(self) -> bool:
        """Boolean evaluation - True if cell has content."""
        return not self.is_empty

    @property
    def word_count(self) -> int:
        """Approximate word count in this cell."""
        return len(self._text.split())

    def upper(self) -> None:
        """Convert cell text to uppercase."""
        self.text = self._text.upper()

    def lower(self) -> None:
        """Convert cell text to lowercase."""
        self.text = self._text.lower()

    def capitalize(self) -> None:
        """Capitalize first letter of cell text."""
        self.text = self._text.capitalize()

    def title(self) -> None:
        """Convert cell text to title case."""
        self.text = self._text.title()

    def strip(self) -> None:
        """Remove leading and trailing whitespace from cell text."""
        self.text = self._text.strip()

    @property
    def address(self) -> str:
        """
        Get cell address in A1 notation (e.g., 'A1', 'B2', 'C3').

        Returns:
            Cell address string
        """
        # Convert column index to letter(s)
        col = self._col
        col_str = ""
        while col >= 0:
            col_str = chr(65 + (col % 26)) + col_str
            col = col // 26 - 1
            if col < 0:
                break
        return f"{col_str}{self._row + 1}"

    def copy_from(self, other: "TableCell") -> None:
        """
        Copy text and fill from another cell.

        Args:
            other: Source cell to copy from
        """
        self._text = other._text
        self._fill_color_hex = other._fill_color_hex
        self._emit_cell_change()


class _Row:
    """
    A single table row with height property.

    Mirrors python-pptx's _Row class.
    """

    def __init__(self, table: "Table", index: int):
        self._table = table
        self._index = index

    @property
    def height(self) -> Optional[int]:
        """Row height in EMU. None if not explicitly set."""
        heights = self._table._row_heights_emu
        if heights and self._index < len(heights):
            return heights[self._index]
        return None

    @height.setter
    def height(self, value: int) -> None:
        """Set row height in EMU."""
        if self._table._row_heights_emu is None:
            self._table._row_heights_emu = [0] * self._table._rows
        if self._index < len(self._table._row_heights_emu):
            self._table._row_heights_emu[self._index] = value
        if self._table._buffer:
            cmd = SetRowHeight(
                shape_id=self._table._shape_id,
                row_index=self._index,
                height_emu=value,
            )
            self._table._buffer.add(cmd)

    @property
    def cells(self) -> list["TableCell"]:
        """List of cells in this row."""
        return self._table._cells[self._index]

    def __len__(self) -> int:
        return self._table._cols

    def __iter__(self) -> Iterator["TableCell"]:
        return iter(self._table._cells[self._index])

    def __getitem__(self, index: int) -> "TableCell":
        return self._table._cells[self._index][index]

    def __repr__(self) -> str:
        return f"<_Row index={self._index} height={self.height}>"


class _Column:
    """
    A single table column with width property.

    Mirrors python-pptx's _Column class.
    """

    def __init__(self, table: "Table", index: int):
        self._table = table
        self._index = index

    @property
    def width(self) -> Optional[int]:
        """Column width in EMU. None if not explicitly set."""
        widths = self._table._column_widths_emu
        if widths and self._index < len(widths):
            return widths[self._index]
        return None

    @width.setter
    def width(self, value: int) -> None:
        """Set column width in EMU."""
        if self._table._column_widths_emu is None:
            self._table._column_widths_emu = [0] * self._table._cols
        if self._index < len(self._table._column_widths_emu):
            self._table._column_widths_emu[self._index] = value
        if self._table._buffer:
            cmd = SetColWidth(
                shape_id=self._table._shape_id,
                col_index=self._index,
                width_emu=value,
            )
            self._table._buffer.add(cmd)

    @property
    def cells(self) -> list["TableCell"]:
        """List of cells in this column."""
        return [self._table._cells[r][self._index] for r in range(self._table._rows)]

    def __len__(self) -> int:
        return self._table._rows

    def __iter__(self) -> Iterator["TableCell"]:
        for r in range(self._table._rows):
            yield self._table._cells[r][self._index]

    def __getitem__(self, index: int) -> "TableCell":
        return self._table._cells[index][self._index]

    def __repr__(self) -> str:
        return f"<_Column index={self._index} width={self.width}>"


class _RowCollection:
    """
    Collection of table rows, compatible with python-pptx API.

    Supports len(), iteration, and indexing. Returns _Row objects.
    """

    def __init__(self, table: "Table"):
        self._table = table

    def __len__(self) -> int:
        return self._table._rows

    def __iter__(self) -> Iterator[_Row]:
        for r in range(self._table._rows):
            yield _Row(self._table, r)

    def __getitem__(self, index: int) -> _Row:
        if index < 0:
            index = self._table._rows + index
        if index < 0 or index >= self._table._rows:
            raise IndexError(f"Row index {index} out of range")
        return _Row(self._table, index)

    def __repr__(self) -> str:
        return f"<_RowCollection count={self._table._rows}>"


class _ColumnCollection:
    """
    Collection of table columns, compatible with python-pptx API.

    Supports len(), iteration, and indexing. Returns _Column objects.
    """

    def __init__(self, table: "Table"):
        self._table = table

    def __len__(self) -> int:
        return self._table._cols

    def __iter__(self) -> Iterator[_Column]:
        for c in range(self._table._cols):
            yield _Column(self._table, c)

    def __getitem__(self, index: int) -> _Column:
        if index < 0:
            index = self._table._cols + index
        if index < 0 or index >= self._table._cols:
            raise IndexError(f"Column index {index} out of range")
        return _Column(self._table, index)

    def __repr__(self) -> str:
        return f"<_ColumnCollection count={self._table._cols}>"


class GraphicFrame(Shape):
    """
    A graphic frame shape that contains a table or chart.

    Mirrors python-pptx's GraphicFrame class.
    In python-pptx, SlideShapes.add_table() returns a GraphicFrame and
    SlideShapes.add_chart() returns a GraphicFrame whose `.chart` exposes
    the underlying Chart object.
    """

    def __init__(
        self,
        shape_id: ShapeId,
        slide: "Slide",
        buffer: Optional["CommandBuffer"],
        table: Optional["Table"] = None,
        chart: Optional["Chart"] = None,
        transform: Optional[Transform] = None,
    ):
        if table is None and chart is None:
            raise ValueError("GraphicFrame requires a table or chart")
        super().__init__(
            shape_id=shape_id,
            slide=slide,
            buffer=buffer,
            element_type="chart" if chart is not None else "table",
            transform=transform,
        )
        self._table = table
        self._chart = chart

    @property
    def table(self) -> "Table":
        """The Table object contained in this graphic frame."""
        if self._table is None:
            raise ValueError("This GraphicFrame does not contain a table")
        return self._table

    @property
    def has_table(self) -> bool:
        """True if this graphic frame contains a table."""
        return self._table is not None

    @property
    def chart(self) -> "Chart":
        """The Chart object contained in this graphic frame."""
        if self._chart is None:
            raise ValueError("This GraphicFrame does not contain a chart")
        return self._chart

    @property
    def has_chart(self) -> bool:
        """True if this graphic frame contains a chart."""
        return self._chart is not None

    # Passthrough methods so agent code like tbl.cell(0,0) works directly
    def cell(self, row_idx: int, col_idx: int) -> "TableCell":
        """Shortcut: delegates to self.table.cell(row_idx, col_idx)."""
        return self.table.cell(row_idx, col_idx)

    @property
    def rows(self) -> "_RowCollection":
        """Shortcut: delegates to self.table.rows."""
        return self.table.rows

    @property
    def cols(self) -> int:
        """Shortcut: delegates to self.table.cols."""
        return self.table.cols

    def __repr__(self) -> str:
        if self._chart is not None:
            return f"<GraphicFrame shape_id={self._shape_id} chart>"
        return f"<GraphicFrame shape_id={self._shape_id} table={self._table._rows}x{self._table._cols}>"


class Table(Shape):
    """
    A table shape on a slide.

    Provides row/column access for table editing.
    Mirrors python-pptx's Table class accessed via GraphicFrame.table.
    """

    def __init__(
        self,
        shape_id: ShapeId,
        slide: "Slide",
        buffer: Optional["CommandBuffer"],
        rows: int,
        cols: int,
        transform: Optional[Transform] = None,
        column_widths_emu: Optional[list[int]] = None,
        row_heights_emu: Optional[list[int]] = None,
        *,
        first_row: bool = False,
        first_col: bool = False,
        last_row: bool = False,
        last_col: bool = False,
        horz_banding: bool = False,
        vert_banding: bool = False,
    ):
        super().__init__(
            shape_id=shape_id,
            slide=slide,
            buffer=buffer,
            element_type="table",
            transform=transform,
        )
        self._rows = rows
        self._cols = cols
        self._column_widths_emu = column_widths_emu
        self._row_heights_emu = row_heights_emu
        self._first_row = first_row
        self._first_col = first_col
        self._last_row = last_row
        self._last_col = last_col
        self._horz_banding = horz_banding
        self._vert_banding = vert_banding
        self._cells: list[list[TableCell]] = []

        # Initialize empty cell grid
        for r in range(rows):
            row_cells = []
            for c in range(cols):
                row_cells.append(TableCell(self, r, c))
            self._cells.append(row_cells)

    def delete(self) -> None:
        """Tables cannot be deleted. Adapt your data to fit the existing table dimensions."""
        raise UnsupportedFeatureError(
            "Tables cannot be deleted from template slides. "
            "Adapt your data to fit the existing table dimensions instead."
        )

    def add_row(self) -> list[TableCell]:
        """
        Add a new row to the end of the table.

        Returns:
            List of TableCell objects for the new row.
        """
        new_row_idx = self._rows
        self._rows += 1

        # Create new TableCell objects for the row
        row_cells = []
        for c in range(self._cols):
            row_cells.append(TableCell(self, new_row_idx, c))
        self._cells.append(row_cells)

        # Emit command
        if self._buffer:
            cmd = SetTableRowCount(
                shape_id=self._shape_id,
                row_count=self._rows,
            )
            self._buffer.add(cmd)

        return row_cells

    def remove_row(self, row_index: int = -1) -> None:
        """
        Remove a row from the table.

        Args:
            row_index: Index of the row to remove. Defaults to -1 (last row).

        Raises:
            IndexError: If row_index is out of range.
            ValueError: If the table has only 1 row.
        """
        if self._rows <= 1:
            raise ValueError("Cannot remove the last remaining row from a table.")

        # Resolve negative index
        if row_index < 0:
            row_index = self._rows + row_index
        if row_index < 0 or row_index >= self._rows:
            raise IndexError(f"Row {row_index} out of range (0-{self._rows - 1})")

        # Remove from internal cells and update indices
        self._cells.pop(row_index)
        self._rows -= 1

        # Re-index remaining cells
        for r in range(row_index, self._rows):
            for c in range(self._cols):
                self._cells[r][c]._row = r

        # Emit command
        if self._buffer:
            cmd = SetTableRowCount(
                shape_id=self._shape_id,
                row_count=self._rows,
            )
            self._buffer.add(cmd)

    def cell(self, row_idx: int, col_idx: int) -> TableCell:
        """
        Get a specific cell.

        Args:
            row_idx: Row index (0-based)
            col_idx: Column index (0-based)

        Returns:
            TableCell object
        """
        row, col = row_idx, col_idx
        if row < 0 or row >= self._rows:
            raise IndexError(f"Row {row} out of range (0-{self._rows - 1})")
        if col < 0 or col >= self._cols:
            raise IndexError(f"Column {col} out of range (0-{self._cols - 1})")
        return self._cells[row][col]

    @property
    def rows(self) -> _RowCollection:
        """Collection of table rows (supports len(), iteration, indexing). Returns _Row objects."""
        return _RowCollection(self)

    @property
    def columns(self) -> _ColumnCollection:
        """Collection of table columns (supports len(), iteration, indexing). Returns _Column objects."""
        return _ColumnCollection(self)

    @property
    def cols(self) -> int:
        """Number of columns."""
        return self._cols

    @property
    def column_widths_emu(self) -> Optional[list[int]]:
        """Column widths in EMUs (English Metric Units). 914400 EMU = 1 inch."""
        return self._column_widths_emu

    @property
    def row_heights_emu(self) -> Optional[list[int]]:
        """Row heights in EMUs. A value of 0 means auto-fit to content."""
        return self._row_heights_emu

    # -------------------------------------------------------------------------
    # Table look properties (python-pptx parity)
    # -------------------------------------------------------------------------

    @property
    def first_row(self) -> bool:
        """Whether the first row should be styled differently."""
        return self._first_row

    @first_row.setter
    def first_row(self, value: bool) -> None:
        self._first_row = value
        self._emit_look_change()

    @property
    def first_col(self) -> bool:
        """Whether the first column should be styled differently."""
        return self._first_col

    @first_col.setter
    def first_col(self, value: bool) -> None:
        self._first_col = value
        self._emit_look_change()

    @property
    def last_row(self) -> bool:
        """Whether the last row should be styled differently."""
        return self._last_row

    @last_row.setter
    def last_row(self, value: bool) -> None:
        self._last_row = value
        self._emit_look_change()

    @property
    def last_col(self) -> bool:
        """Whether the last column should be styled differently."""
        return self._last_col

    @last_col.setter
    def last_col(self, value: bool) -> None:
        self._last_col = value
        self._emit_look_change()

    @property
    def horz_banding(self) -> bool:
        """Whether alternating row banding is enabled."""
        return self._horz_banding

    @horz_banding.setter
    def horz_banding(self, value: bool) -> None:
        self._horz_banding = value
        self._emit_look_change()

    @property
    def vert_banding(self) -> bool:
        """Whether alternating column banding is enabled."""
        return self._vert_banding

    @vert_banding.setter
    def vert_banding(self, value: bool) -> None:
        self._vert_banding = value
        self._emit_look_change()

    def _emit_look_change(self) -> None:
        """Emit a SetTableLook command with the current look flag values."""
        if self._buffer:
            from .commands import Command
            # Build a SetTableLook command manually since it's a backend-only intent
            class _SetTableLookCmd(Command):
                @property
                def command_type(self_inner) -> str:
                    return "SetTableLook"
                def to_dict(self_inner) -> dict:
                    return {
                        "type": "SetTableLook",
                        "shapeId": self._shape_id,
                        "look": {
                            "firstRow": self._first_row,
                            "lastRow": self._last_row,
                            "firstCol": self._first_col,
                            "lastCol": self._last_col,
                            "bandRow": self._horz_banding,
                            "bandCol": self._vert_banding,
                        },
                    }
            self._buffer.add(_SetTableLookCmd())

    def iter_cells(self) -> Iterator[TableCell]:
        """Iterate over all cells row by row."""
        for row in self._cells:
            for cell in row:
                yield cell

    # -------------------------------------------------------------------------
    # Convenience properties and methods
    # -------------------------------------------------------------------------

    @property
    def row_count(self) -> int:
        """Number of rows (alias for rows property)."""
        return self._rows

    @property
    def column_count(self) -> int:
        """Number of columns (alias for cols property)."""
        return self._cols

    @property
    def cell_count(self) -> int:
        """Total number of cells in the table."""
        return self._rows * self._cols

    def get_row(self, row_index: int) -> list[TableCell]:
        """
        Get all cells in a specific row.

        Args:
            row_index: Zero-based row index

        Returns:
            List of TableCell objects in the row
        """
        if row_index < 0 or row_index >= self._rows:
            raise IndexError(f"Row {row_index} out of range (0-{self._rows - 1})")
        return self._cells[row_index][:]

    def get_column(self, col_index: int) -> list[TableCell]:
        """
        Get all cells in a specific column.

        Args:
            col_index: Zero-based column index

        Returns:
            List of TableCell objects in the column
        """
        if col_index < 0 or col_index >= self._cols:
            raise IndexError(f"Column {col_index} out of range (0-{self._cols - 1})")
        return [self._cells[r][col_index] for r in range(self._rows)]

    def set_row_text(self, row_index: int, texts: list[str]) -> None:
        """
        Set text for all cells in a row.

        Args:
            row_index: Zero-based row index
            texts: List of text values (one per column)
        """
        if row_index < 0 or row_index >= self._rows:
            raise IndexError(f"Row {row_index} out of range (0-{self._rows - 1})")
        for col, text in enumerate(texts[:self._cols]):
            self._cells[row_index][col].text = text

    def set_column_text(self, col_index: int, texts: list[str]) -> None:
        """
        Set text for all cells in a column.

        Args:
            col_index: Zero-based column index
            texts: List of text values (one per row)
        """
        if col_index < 0 or col_index >= self._cols:
            raise IndexError(f"Column {col_index} out of range (0-{self._cols - 1})")
        for row, text in enumerate(texts[:self._rows]):
            self._cells[row][col_index].text = text

    def set_row_fill(self, row_index: int, color_hex: str) -> None:
        """
        Set background color for all cells in a row.

        Args:
            row_index: Zero-based row index
            color_hex: Color as hex string (e.g., 'FF0000' or '#FF0000')
        """
        if row_index < 0 or row_index >= self._rows:
            raise IndexError(f"Row {row_index} out of range (0-{self._rows - 1})")
        for col in range(self._cols):
            self._cells[row_index][col].fill = color_hex

    def set_column_fill(self, col_index: int, color_hex: str) -> None:
        """
        Set background color for all cells in a column.

        Args:
            col_index: Zero-based column index
            color_hex: Color as hex string (e.g., 'FF0000' or '#FF0000')
        """
        if col_index < 0 or col_index >= self._cols:
            raise IndexError(f"Column {col_index} out of range (0-{self._cols - 1})")
        for row in range(self._rows):
            self._cells[row][col_index].fill = color_hex

    def get_all_text(self) -> list[list[str]]:
        """
        Get text from all cells as a 2D list.

        Returns:
            List of lists containing cell text, organized as rows[cols]
        """
        return [[cell.text for cell in row] for row in self._cells]

    def set_all_text(self, data: list[list[str]]) -> None:
        """
        Set text for all cells from a 2D list.

        Args:
            data: List of lists containing cell text, organized as rows[cols]
        """
        for row_idx, row_data in enumerate(data[:self._rows]):
            for col_idx, text in enumerate(row_data[:self._cols]):
                self._cells[row_idx][col_idx].text = text

    def clear_all(self) -> None:
        """Clear text from all cells in the table."""
        for row in self._cells:
            for cell in row:
                cell.clear()

    def iter_rows(self) -> Iterator[list[TableCell]]:
        """
        Iterate over rows as lists of cells.

        Yields:
            List of TableCell objects for each row
        """
        for row in self._cells:
            yield row

    def iter_columns(self) -> Iterator[list[TableCell]]:
        """
        Iterate over columns as lists of cells.

        Yields:
            List of TableCell objects for each column
        """
        for col_idx in range(self._cols):
            yield [self._cells[row_idx][col_idx] for row_idx in range(self._rows)]

    def get_first_row_cells(self) -> list[TableCell]:
        """Get cells in the first row."""
        return self._cells[0] if self._rows > 0 else []

    def get_last_row_cells(self) -> list[TableCell]:
        """Get cells in the last row."""
        return self._cells[-1] if self._rows > 0 else []

    def get_first_column_cells(self) -> list[TableCell]:
        """Get cells in the first column."""
        return [self._cells[r][0] for r in range(self._rows)] if self._cols > 0 else []

    def get_last_column_cells(self) -> list[TableCell]:
        """Get cells in the last column."""
        return [self._cells[r][-1] for r in range(self._rows)] if self._cols > 0 else []

    @property
    def top_left(self) -> Optional[TableCell]:
        """Get the top-left cell (0, 0)."""
        if self._rows > 0 and self._cols > 0:
            return self._cells[0][0]
        return None

    @property
    def top_right(self) -> Optional[TableCell]:
        """Get the top-right cell (0, last_col)."""
        if self._rows > 0 and self._cols > 0:
            return self._cells[0][-1]
        return None

    @property
    def bottom_left(self) -> Optional[TableCell]:
        """Get the bottom-left cell (last_row, 0)."""
        if self._rows > 0 and self._cols > 0:
            return self._cells[-1][0]
        return None

    @property
    def bottom_right(self) -> Optional[TableCell]:
        """Get the bottom-right cell (last_row, last_col)."""
        if self._rows > 0 and self._cols > 0:
            return self._cells[-1][-1]
        return None

    @property
    def all_text(self) -> str:
        """
        Get all cell text as a single string.

        Cells are separated by tabs, rows by newlines (TSV format).
        """
        return "\n".join(
            "\t".join(cell.text for cell in row)
            for row in self._cells
        )

    @property
    def word_count(self) -> int:
        """Total word count across all cells."""
        return sum(cell.word_count for cell in self.iter_cells())

    @property
    def is_empty(self) -> bool:
        """True if all cells are empty."""
        return all(cell.is_empty for cell in self.iter_cells())

    def contains_text(self, text: str, case_sensitive: bool = False) -> bool:
        """
        Check if any cell contains the specified text.

        Args:
            text: Text to search for
            case_sensitive: Whether to do case-sensitive search

        Returns:
            True if any cell contains the text
        """
        search = text if case_sensitive else text.lower()
        for cell in self.iter_cells():
            cell_text = cell.text if case_sensitive else cell.text.lower()
            if search in cell_text:
                return True
        return False

    def find_cells(self, text: str, case_sensitive: bool = False) -> list[TableCell]:
        """
        Find all cells containing the specified text.

        Args:
            text: Text to search for
            case_sensitive: Whether to do case-sensitive search

        Returns:
            List of cells containing the text
        """
        results = []
        search = text if case_sensitive else text.lower()
        for cell in self.iter_cells():
            cell_text = cell.text if case_sensitive else cell.text.lower()
            if search in cell_text:
                results.append(cell)
        return results

    def get_diagonal(self, start_top_left: bool = True) -> list[TableCell]:
        """
        Get cells along a diagonal.

        Args:
            start_top_left: If True, get diagonal from top-left to bottom-right.
                           If False, get diagonal from top-right to bottom-left.

        Returns:
            List of cells along the diagonal
        """
        diagonal = []
        size = min(self._rows, self._cols)
        for i in range(size):
            if start_top_left:
                diagonal.append(self._cells[i][i])
            else:
                diagonal.append(self._cells[i][self._cols - 1 - i])
        return diagonal

    def transpose_text(self) -> list[list[str]]:
        """
        Get transposed text data (rows become columns).

        Returns:
            2D list with rows and columns swapped
        """
        return [
            [self._cells[r][c].text for r in range(self._rows)]
            for c in range(self._cols)
        ]

    def to_csv(self, delimiter: str = ",", quote_char: str = '"') -> str:
        """
        Export table data as CSV string.

        Args:
            delimiter: Field separator (default comma)
            quote_char: Character to quote fields containing delimiter

        Returns:
            CSV formatted string
        """
        lines = []
        for row in self._cells:
            cells = []
            for cell in row:
                text = cell.text
                # Quote if contains delimiter or newline
                if delimiter in text or '\n' in text or quote_char in text:
                    text = text.replace(quote_char, quote_char + quote_char)
                    text = f'{quote_char}{text}{quote_char}'
                cells.append(text)
            lines.append(delimiter.join(cells))
        return '\n'.join(lines)

    def to_list(self) -> list[list[str]]:
        """
        Export table data as 2D list.

        Returns:
            2D list of cell text values
        """
        return [
            [cell.text for cell in row]
            for row in self._cells
        ]

    def to_dict_list(self, header_row: bool = True) -> list[dict]:
        """
        Export table as list of dictionaries.

        Args:
            header_row: If True, use first row as keys

        Returns:
            List of dictionaries, one per row (excluding header if used)
        """
        if not header_row or self._rows < 2:
            # Use column indices as keys
            return [
                {str(i): cell.text for i, cell in enumerate(row)}
                for row in self._cells
            ]

        # Use first row as headers
        headers = [cell.text for cell in self._cells[0]]
        return [
            {headers[i]: cell.text for i, cell in enumerate(row)}
            for row in self._cells[1:]
        ]

    def set_row(self, row_index: int, values: list[str]) -> None:
        """
        Set all cells in a row.

        Args:
            row_index: Zero-based row index
            values: List of text values (truncated or padded to fit columns)
        """
        for col_idx in range(min(len(values), self._cols)):
            self._cells[row_index][col_idx].text = values[col_idx]

    def set_column(self, col_index: int, values: list[str]) -> None:
        """
        Set all cells in a column.

        Args:
            col_index: Zero-based column index
            values: List of text values (truncated or padded to fit rows)
        """
        for row_idx in range(min(len(values), self._rows)):
            self._cells[row_idx][col_index].text = values[row_idx]

    def get_row_text(self, row_index: int) -> list[str]:
        """
        Get text from all cells in a row.

        Args:
            row_index: Zero-based row index

        Returns:
            List of cell text values
        """
        return [cell.text for cell in self._cells[row_index]]

    def get_column_text(self, col_index: int) -> list[str]:
        """
        Get text from all cells in a column.

        Args:
            col_index: Zero-based column index

        Returns:
            List of cell text values
        """
        return [self._cells[row_idx][col_index].text for row_idx in range(self._rows)]

    def fill_row(self, row_index: int, value: str) -> None:
        """
        Fill all cells in a row with the same value.

        Args:
            row_index: Zero-based row index
            value: Text to set in all cells
        """
        for cell in self._cells[row_index]:
            cell.text = value

    def fill_column(self, col_index: int, value: str) -> None:
        """
        Fill all cells in a column with the same value.

        Args:
            col_index: Zero-based column index
            value: Text to set in all cells
        """
        for row_idx in range(self._rows):
            self._cells[row_idx][col_index].text = value

    def swap_rows(self, row1: int, row2: int) -> None:
        """
        Swap text content between two rows.

        Args:
            row1: First row index
            row2: Second row index
        """
        for col_idx in range(self._cols):
            temp = self._cells[row1][col_idx].text
            self._cells[row1][col_idx].text = self._cells[row2][col_idx].text
            self._cells[row2][col_idx].text = temp

    def swap_columns(self, col1: int, col2: int) -> None:
        """
        Swap text content between two columns.

        Args:
            col1: First column index
            col2: Second column index
        """
        for row_idx in range(self._rows):
            temp = self._cells[row_idx][col1].text
            self._cells[row_idx][col1].text = self._cells[row_idx][col2].text
            self._cells[row_idx][col2].text = temp

    def replace_all(self, old: str, new: str) -> int:
        """
        Replace text in all cells.

        Args:
            old: Text to find
            new: Replacement text

        Returns:
            Total number of replacements made
        """
        count = 0
        for cell in self.iter_cells():
            cell_count = cell.text.count(old)
            if cell_count > 0:
                cell.text = cell.text.replace(old, new)
                count += cell_count
        return count

    def upper_all(self) -> None:
        """Convert all cell text to uppercase."""
        for cell in self.iter_cells():
            cell.upper()

    def lower_all(self) -> None:
        """Convert all cell text to lowercase."""
        for cell in self.iter_cells():
            cell.lower()

    def strip_all(self) -> None:
        """Remove leading/trailing whitespace from all cells."""
        for cell in self.iter_cells():
            cell.strip()

    def to_markdown(self, alignment: str = "left") -> str:
        """
        Export table as Markdown-formatted table.

        Args:
            alignment: Column alignment - 'left', 'center', 'right', or
                      a string with one character per column (e.g., 'lcr')

        Returns:
            Markdown table string

        Example:
            md = table.to_markdown()
            # | Header 1 | Header 2 |
            # |----------|----------|
            # | Cell 1   | Cell 2   |
        """
        if self._rows == 0 or self._cols == 0:
            return ""

        # Get all text
        data = self.to_list()

        # Calculate column widths
        col_widths = []
        for col_idx in range(self._cols):
            max_width = max(len(data[row_idx][col_idx]) for row_idx in range(self._rows))
            col_widths.append(max(3, max_width))  # Minimum 3 for separator

        # Determine alignment per column
        if len(alignment) == 1:
            alignments = [alignment] * self._cols
        elif len(alignment) == self._cols:
            alignments = list(alignment)
        else:
            alignments = ['left'] * self._cols

        # Build header separator
        separators = []
        for i, width in enumerate(col_widths):
            align = alignments[i] if i < len(alignments) else 'left'
            if align == 'center' or align == 'c':
                separators.append(':' + '-' * (width - 2) + ':')
            elif align == 'right' or align == 'r':
                separators.append('-' * (width - 1) + ':')
            else:  # left
                separators.append(':' + '-' * (width - 1))

        # Build rows
        lines = []
        for row_idx, row_data in enumerate(data):
            cells = [cell.ljust(col_widths[i]) for i, cell in enumerate(row_data)]
            lines.append('| ' + ' | '.join(cells) + ' |')

            # Add separator after first row (header)
            if row_idx == 0:
                lines.append('| ' + ' | '.join(separators) + ' |')

        return '\n'.join(lines)

    def sort_rows(
        self,
        key_column: int = 0,
        reverse: bool = False,
        numeric: bool = False,
    ) -> None:
        """
        Sort rows by values in a specific column.

        Note: This reorders the cell text content but not the cells themselves.

        Args:
            key_column: Column index to sort by
            reverse: If True, sort descending
            numeric: If True, parse values as numbers
        """
        if self._rows <= 1:
            return

        # Extract data
        data = self.to_list()

        # Sort data (skip header row)
        if self._rows > 1:
            header = data[0]
            body = data[1:]

            def get_key(row: list[str]):
                val = row[key_column]
                if numeric:
                    try:
                        return float(val.replace(',', ''))
                    except ValueError:
                        return 0.0
                return val.lower()

            body.sort(key=get_key, reverse=reverse)
            data = [header] + body

        # Write back
        self.set_all_text(data)

    def filter_rows(self, column: int, contains: str, case_sensitive: bool = False) -> list[int]:
        """
        Find rows where a column contains specific text.

        Args:
            column: Column index to search
            contains: Text to search for
            case_sensitive: Whether to do case-sensitive search

        Returns:
            List of row indices matching the filter
        """
        results = []
        search = contains if case_sensitive else contains.lower()

        for row_idx in range(self._rows):
            cell_text = self._cells[row_idx][column].text
            if not case_sensitive:
                cell_text = cell_text.lower()
            if search in cell_text:
                results.append(row_idx)

        return results

    def copy_row(self, from_row: int, to_row: int) -> None:
        """
        Copy text content from one row to another.

        Args:
            from_row: Source row index
            to_row: Destination row index
        """
        for col_idx in range(self._cols):
            self._cells[to_row][col_idx].text = self._cells[from_row][col_idx].text

    def copy_column(self, from_col: int, to_col: int) -> None:
        """
        Copy text content from one column to another.

        Args:
            from_col: Source column index
            to_col: Destination column index
        """
        for row_idx in range(self._rows):
            self._cells[row_idx][to_col].text = self._cells[row_idx][from_col].text

    def sum_column(self, column: int, skip_header: bool = True) -> float:
        """
        Sum numeric values in a column.

        Args:
            column: Column index
            skip_header: If True, skip the first row

        Returns:
            Sum of numeric values (non-numeric cells are treated as 0)
        """
        total = 0.0
        start_row = 1 if skip_header and self._rows > 1 else 0

        for row_idx in range(start_row, self._rows):
            text = self._cells[row_idx][column].text.strip()
            try:
                total += float(text.replace(',', ''))
            except ValueError:
                pass

        return total

    def average_column(self, column: int, skip_header: bool = True) -> float:
        """
        Calculate average of numeric values in a column.

        Args:
            column: Column index
            skip_header: If True, skip the first row

        Returns:
            Average of numeric values (non-numeric cells are excluded)
        """
        total = 0.0
        count = 0
        start_row = 1 if skip_header and self._rows > 1 else 0

        for row_idx in range(start_row, self._rows):
            text = self._cells[row_idx][column].text.strip()
            try:
                total += float(text.replace(',', ''))
                count += 1
            except ValueError:
                pass

        return total / count if count > 0 else 0.0

    def get_headers(self) -> list[str]:
        """
        Get the first row as column headers.

        Returns:
            List of header strings
        """
        if self._rows == 0:
            return []
        return [cell.text for cell in self._cells[0]]

    def set_headers(self, headers: list[str]) -> None:
        """
        Set the first row as column headers.

        Args:
            headers: List of header strings
        """
        if self._rows == 0:
            return
        for col_idx, header in enumerate(headers[:self._cols]):
            self._cells[0][col_idx].text = header

    def to_dict(self) -> dict:
        """
        Serialize table to a comprehensive dictionary.

        Returns:
            Dictionary with table metadata and content
        """
        return {
            'rows': self._rows,
            'columns': self._cols,
            'cell_count': self.cell_count,
            'word_count': self.word_count,
            'is_empty': self.is_empty,
            'headers': self.get_headers(),
            'data': self.to_list(),
        }

    def find_and_replace(
        self,
        find: str,
        replace: str,
        column: Optional[int] = None,
        case_sensitive: bool = False,
    ) -> int:
        """
        Find and replace text in the table.

        Args:
            find: Text to find
            replace: Replacement text
            column: If specified, only search in this column
            case_sensitive: Whether to do case-sensitive search

        Returns:
            Number of replacements made
        """
        import re
        count = 0
        flags = 0 if case_sensitive else re.IGNORECASE
        pattern = re.compile(re.escape(find), flags)

        for row_idx in range(self._rows):
            cols = [column] if column is not None else range(self._cols)
            for col_idx in cols:
                text = self._cells[row_idx][col_idx].text
                new_text, n = pattern.subn(replace, text)
                if n > 0:
                    self._cells[row_idx][col_idx].text = new_text
                    count += n

        return count

    def get_unique_values(self, column: int, skip_header: bool = True) -> set[str]:
        """
        Get unique values in a column.

        Args:
            column: Column index
            skip_header: If True, skip the first row

        Returns:
            Set of unique values
        """
        start_row = 1 if skip_header and self._rows > 1 else 0
        return {
            self._cells[row_idx][column].text
            for row_idx in range(start_row, self._rows)
        }

    def count_values(self, column: int, skip_header: bool = True) -> dict[str, int]:
        """
        Count occurrences of each value in a column.

        Args:
            column: Column index
            skip_header: If True, skip the first row

        Returns:
            Dictionary mapping values to counts
        """
        counts: dict[str, int] = {}
        start_row = 1 if skip_header and self._rows > 1 else 0

        for row_idx in range(start_row, self._rows):
            text = self._cells[row_idx][column].text
            counts[text] = counts.get(text, 0) + 1

        return counts

    def __repr__(self) -> str:
        return f"<Table shape_id='{self._shape_id}' rows={self._rows} cols={self._cols}>"
