"""Stock python-pptx exposes hyperlink/action classes via ``pptx.action``.

Mirror that module path so user code written for python-pptx
(``from pptx.action import Hyperlink, ActionSetting``) keeps working.

``ActionSetting`` and the ``PP_ACTION`` enum are not yet implemented in this
REST SDK — only ``Hyperlink`` is functional. The placeholders are provided so
that imports succeed and ``isinstance``-style checks behave predictably; they
will raise ``UnsupportedFeatureError`` if instantiated.
"""

from __future__ import annotations

from .errors import UnsupportedFeatureError
from .text import Hyperlink


class ActionSetting:
    """Placeholder for python-pptx's ``ActionSetting``.

    Click-action support is not yet implemented in athena-python-pptx. The
    class exists so that ``from pptx.action import ActionSetting`` succeeds;
    instantiation raises :class:`pptx.errors.UnsupportedFeatureError`.
    """

    def __init__(self, *_args: object, **_kwargs: object) -> None:
        raise UnsupportedFeatureError(
            "ActionSetting is not implemented in athena-python-pptx. "
            "Use Run.hyperlink for URL hyperlinks; click-actions to slides "
            "are not yet supported.",
        )


__all__ = ["ActionSetting", "Hyperlink"]
