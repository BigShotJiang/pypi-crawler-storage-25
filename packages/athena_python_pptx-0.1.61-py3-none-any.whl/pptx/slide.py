"""Stock python-pptx exposes slide-related classes via ``pptx.slide``.

This shim re-exports the canonical implementations so that user code written
against python-pptx (``from pptx.slide import Slide, Slides, ...``) works
verbatim against athena-python-pptx.
"""

from __future__ import annotations

from .slides import (
    Slide,
    SlideBackground,
    SlideLayout,
    SlideLayouts,
    SlideMaster,
    SlideMasters,
    Slides,
)

__all__ = [
    "Slide",
    "SlideBackground",
    "SlideLayout",
    "SlideLayouts",
    "SlideMaster",
    "SlideMasters",
    "Slides",
]
