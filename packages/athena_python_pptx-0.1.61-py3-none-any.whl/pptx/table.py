"""Stock python-pptx exposes table classes via ``pptx.table``.

This shim re-exports our table classes under the canonical module path so
that ``from pptx.table import Table, _Cell`` works against athena-python-pptx.
"""

from __future__ import annotations

from .shapes import Table, TableCell

# Stock python-pptx names the cell class ``_Cell`` (private convention) but
# exposes it via the public ``pptx.table`` module path. Mirror that alias.
_Cell = TableCell

__all__ = ["Table", "_Cell", "TableCell"]
