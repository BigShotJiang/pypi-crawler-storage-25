"""
Chart data classes matching python-pptx.

These classes capture series data client-side. The actual server-side
materialization happens via:

  * `Shape.chart.replace_data(chart_data)` for ingested charts — emits
    `UpdateSeriesValue` / `UpdateCategoryLabel` patches against the existing
    chart part.
  * `slide.shapes.add_chart(chart_type, ..., chart_data)` for SDK-authored
    charts — sends an `AddChart` command that the export-worker
    materializes via `@pptx/chart-ooxml/export/author.ts`.
"""

from __future__ import annotations
from typing import Any, Sequence

from ..errors import UnsupportedFeatureError


class CategoryChartData:
    """
    Chart data for category-based charts (column, bar, line, area, pie,
    doughnut). Matches python-pptx's `CategoryChartData` API.
    """

    def __init__(self) -> None:
        self._categories: list[str] = []
        self._series: list[tuple[str, list[float | None]]] = []

    @property
    def categories(self) -> list[str]:
        """Category labels (x-axis tick labels)."""
        return self._categories

    @categories.setter
    def categories(self, value: Sequence[str]) -> None:
        """Set category labels."""
        self._categories = [str(v) for v in value]

    def add_series(
        self,
        name: str,
        values: Sequence[float | None],
        number_format: str = "",
    ) -> None:
        """Add a data series.

        `number_format` is accepted for python-pptx parity but is not
        currently propagated to the chart spec — the embedded workbook's
        format string controls display formatting.
        """
        self._series.append((name, [None if v is None else float(v) for v in values]))

    def to_series_payload(self) -> list[dict[str, Any]]:
        """Internal: convert to the wire shape used by AddChart / patches."""
        return [{"name": name, "values": list(values)} for name, values in self._series]

    def __len__(self) -> int:
        return len(self._series)


# Alias for compatibility with python-pptx (which exposes both names).
ChartData = CategoryChartData


class _XySeries:
    def __init__(self, name: str) -> None:
        self.name = name
        self.points: list[tuple[float, float]] = []

    def add_data_point(self, x: float, y: float) -> None:
        self.points.append((float(x), float(y)))


class XyChartData:
    """Chart data for XY (scatter) charts.

    Mirrors python-pptx's `XyChartData`. Each series carries its own (x, y)
    pairs; the SDK serializes them to the wire format expected by
    ``AddChart`` so the export-worker's chart-ooxml authoring path can emit
    ``<c:scatterChart>`` with ``<c:xVal>`` / ``<c:yVal>``.
    """

    def __init__(self) -> None:
        self._series: list[_XySeries] = []

    def add_series(self, name: str, values: Any = None) -> _XySeries:
        series = _XySeries(name)
        if values is not None:
            for point in values:
                if isinstance(point, (tuple, list)) and len(point) == 2:
                    series.add_data_point(point[0], point[1])
        self._series.append(series)
        return series

    def to_series_payload(self) -> list[dict[str, Any]]:
        """Internal: convert to the wire shape used by AddChart for scatter charts.

        The applier maps ``xValues`` onto ``SeriesSpec.xValues`` so the chart-ooxml
        author writes ``<c:xVal>`` instead of ``<c:cat>``.
        """
        return [
            {
                "name": s.name,
                "values": [pt[1] for pt in s.points],
                "xValues": [pt[0] for pt in s.points],
            }
            for s in self._series
        ]

    def __len__(self) -> int:
        return len(self._series)


class _BubbleSeries(_XySeries):
    def __init__(self, name: str) -> None:
        super().__init__(name)
        self.sizes: list[float] = []

    def add_data_point(self, x: float, y: float, size: float = 1.0) -> None:  # type: ignore[override]
        super().add_data_point(x, y)
        self.sizes.append(float(size))


class BubbleChartData:
    """Chart data for bubble charts.

    Mirrors python-pptx's `BubbleChartData`. Each series carries (x, y, size)
    triples; the SDK serializes them to the wire format expected by
    ``AddChart`` so the export-worker's chart-ooxml authoring path can emit
    ``<c:bubbleChart>`` with ``<c:xVal>`` / ``<c:yVal>`` / ``<c:bubbleSize>``.
    """

    def __init__(self) -> None:
        self._series: list[_BubbleSeries] = []

    def add_series(self, name: str, values: Any = None) -> _BubbleSeries:
        series = _BubbleSeries(name)
        self._series.append(series)
        return series

    def to_series_payload(self) -> list[dict[str, Any]]:
        """Internal: convert to the wire shape used by AddChart for bubble charts."""
        return [
            {
                "name": s.name,
                "values": [pt[1] for pt in s.points],
                "xValues": [pt[0] for pt in s.points],
                "bubbleSizes": list(s.sizes) if s.sizes else [1.0] * len(s.points),
            }
            for s in self._series
        ]

    def __len__(self) -> int:
        return len(self._series)
