"""
Shape-related enumerations matching python-pptx.

Provides MSO_SHAPE (auto shape types), MSO_SHAPE_TYPE, MSO_CONNECTOR_TYPE,
and PP_PLACEHOLDER enumerations.
"""

import re
from enum import IntEnum
from typing import Optional


# ---------------------------------------------------------------------------
# MSO_SHAPE enum value → backend shape type string mapping.
# Every MSO_AUTO_SHAPE_TYPE integer value from standard python-pptx is mapped
# to the snake_case string the PPTX Studio backend expects.
# ---------------------------------------------------------------------------
_MSO_SHAPE_TO_STRING = {
    1: 'rectangle',
    2: 'parallelogram',
    3: 'trapezoid',
    4: 'diamond',
    5: 'rounded_rectangle',
    6: 'octagon',
    7: 'triangle',
    8: 'right_triangle',
    9: 'oval',
    10: 'hexagon',
    11: 'cross',
    12: 'pentagon',
    13: 'can',
    14: 'cube',
    15: 'bevel',
    16: 'folded_corner',
    17: 'smiley_face',
    18: 'donut',
    19: 'no_symbol',
    20: 'block_arc',
    21: 'heart',
    22: 'lightning_bolt',
    23: 'sun',
    24: 'moon',
    25: 'arc',
    26: 'double_bracket',
    27: 'double_brace',
    28: 'plaque',
    29: 'left_bracket',
    30: 'right_bracket',
    31: 'left_brace',
    32: 'right_brace',
    33: 'right_arrow',
    34: 'left_arrow',
    35: 'up_arrow',
    36: 'down_arrow',
    37: 'left_right_arrow',
    38: 'up_down_arrow',
    39: 'quad_arrow',
    40: 'left_right_up_arrow',
    41: 'bent_arrow',
    42: 'u_turn_arrow',
    43: 'left_up_arrow',
    44: 'bent_up_arrow',
    45: 'curved_right_arrow',
    46: 'curved_left_arrow',
    47: 'curved_up_arrow',
    48: 'curved_down_arrow',
    49: 'striped_right_arrow',
    50: 'notched_right_arrow',
    51: 'pentagon',
    52: 'chevron',
    53: 'right_arrow_callout',
    54: 'left_arrow_callout',
    55: 'up_arrow_callout',
    56: 'down_arrow_callout',
    57: 'left_right_arrow_callout',
    58: 'up_down_arrow_callout',
    59: 'quad_arrow_callout',
    60: 'circular_arrow',
    61: 'flowchart_process',
    62: 'flowchart_alternate_process',
    63: 'flowchart_decision',
    64: 'flowchart_data',
    65: 'flowchart_predefined_process',
    66: 'flowchart_internal_storage',
    67: 'flowchart_document',
    68: 'flowchart_multidocument',
    69: 'flowchart_terminator',
    70: 'flowchart_preparation',
    71: 'flowchart_manual_input',
    72: 'flowchart_manual_operation',
    73: 'flowchart_connector',
    74: 'flowchart_offpage_connector',
    75: 'flowchart_card',
    76: 'flowchart_punched_tape',
    77: 'flowchart_summing_junction',
    78: 'flowchart_or',
    79: 'flowchart_collate',
    80: 'flowchart_sort',
    81: 'flowchart_extract',
    82: 'flowchart_merge',
    83: 'flowchart_stored_data',
    84: 'flowchart_delay',
    85: 'flowchart_sequential_access_storage',
    86: 'flowchart_magnetic_disk',
    87: 'flowchart_direct_access_storage',
    88: 'flowchart_display',
    89: 'explosion1',
    90: 'explosion2',
    91: 'star4',
    92: 'star5',
    93: 'star8',
    94: 'star16',
    95: 'star24',
    96: 'star32',
    97: 'up_ribbon',
    98: 'down_ribbon',
    99: 'curved_up_ribbon',
    100: 'curved_down_ribbon',
    101: 'vertical_scroll',
    102: 'horizontal_scroll',
    103: 'wave',
    104: 'double_wave',
    105: 'rectangular_callout',
    106: 'rounded_rectangular_callout',
    107: 'oval_callout',
    108: 'cloud_callout',
    109: 'line_callout_1',
    110: 'line_callout_2',
    111: 'line_callout_3',
    112: 'line_callout_4',
    113: 'line_callout_1_accent_bar',
    114: 'line_callout_2_accent_bar',
    115: 'line_callout_3_accent_bar',
    116: 'line_callout_4_accent_bar',
    117: 'line_callout_1_no_border',
    118: 'line_callout_2_no_border',
    119: 'line_callout_3_no_border',
    120: 'line_callout_4_no_border',
    121: 'line_callout_1_border_and_accent_bar',
    122: 'line_callout_2_border_and_accent_bar',
    123: 'line_callout_3_border_and_accent_bar',
    124: 'line_callout_4_border_and_accent_bar',
    125: 'action_button_custom',
    126: 'action_button_home',
    127: 'action_button_help',
    128: 'action_button_information',
    129: 'action_button_back_or_previous',
    130: 'action_button_forward_or_next',
    131: 'action_button_beginning',
    132: 'action_button_end',
    133: 'action_button_return',
    134: 'action_button_document',
    135: 'action_button_sound',
    136: 'action_button_movie',
    137: 'balloon',
    139: 'flowchart_offline_storage',
    140: 'left_right_ribbon',
    141: 'diagonal_stripe',
    142: 'pie',
    143: 'non_isosceles_trapezoid',
    144: 'decagon',
    145: 'heptagon',
    146: 'dodecagon',
    147: 'star6',
    148: 'star7',
    149: 'star10',
    150: 'star12',
    151: 'round_1_rectangle',
    152: 'round_2_same_rectangle',
    153: 'round_2_diag_rectangle',
    154: 'snip_round_rectangle',
    155: 'snip_1_rectangle',
    156: 'snip_2_same_rectangle',
    157: 'snip_2_diag_rectangle',
    158: 'frame',
    159: 'half_frame',
    160: 'tear',
    161: 'chord',
    162: 'corner',
    163: 'math_plus',
    164: 'math_minus',
    165: 'math_multiply',
    166: 'math_divide',
    167: 'math_equal',
    168: 'math_not_equal',
    169: 'corner_tabs',
    170: 'square_tabs',
    171: 'plaque_tabs',
    172: 'gear_6',
    173: 'gear_9',
    174: 'funnel',
    175: 'pie_wedge',
    176: 'left_circular_arrow',
    177: 'left_right_circular_arrow',
    178: 'swoosh_arrow',
    179: 'cloud',
    180: 'chart_x',
    181: 'chart_star',
    182: 'chart_plus',
    183: 'line_inverse',
}

_STRING_SHAPE_ALIASES = {
    'roundedrectangle': 'rounded_rectangle',
    'roundrectangle': 'rounded_rectangle',
    'roundrect': 'rounded_rectangle',
    'roundedrect': 'rounded_rectangle',
    'rect': 'rectangle',
    'ellipse': 'oval',
    'calloutroundedrectangle': 'rounded_rectangular_callout',
    'roundedrectangularcallout': 'rounded_rectangular_callout',
    'triangle': 'triangle',
    'isosceles_triangle': 'triangle',
}


def _normalize_shape_string(shape: str) -> str:
    """Normalize common LLM/user shape spellings to backend enum values."""
    stripped = shape.strip()
    if '_' in stripped or stripped.isupper():
        camel_cased = stripped
    else:
        camel_cased = re.sub(r'(?<!^)(?=[A-Z])', '_', stripped)
    normalized = re.sub(r'[^A-Za-z0-9]+', '_', camel_cased).strip('_').lower()
    collapsed = normalized.replace('_', '')

    if normalized in _STRING_SHAPE_ALIASES:
        return _STRING_SHAPE_ALIASES[normalized]

    if collapsed in _STRING_SHAPE_ALIASES:
        return _STRING_SHAPE_ALIASES[collapsed]

    if normalized.endswith('_shape'):
        trimmed = normalized[:-6]
        if trimmed in _STRING_SHAPE_ALIASES:
            return _STRING_SHAPE_ALIASES[trimmed]
        return trimmed

    return normalized


def mso_shape_to_string(shape: "MSO_SHAPE") -> str:
    """
    Convert an MSO_SHAPE enum value to the backend shape type string.

    Args:
        shape: MSO_SHAPE enum value

    Returns:
        String shape type name for the backend API
    """
    if isinstance(shape, str):
        return _normalize_shape_string(shape)

    value = int(shape)
    result = _MSO_SHAPE_TO_STRING.get(value)
    if result:
        return result

    # Fallback: convert enum name to lowercase snake_case
    if hasattr(shape, 'name'):
        return _normalize_shape_string(shape.name)

    # Last resort: return rectangle as default
    return 'rectangle'


class MSO_SHAPE(IntEnum):
    """
    AutoShape type enumeration (MSO_AUTO_SHAPE_TYPE).

    Specifies the type of AutoShape for ``shapes.add_shape()``.
    Values are identical to standard python-pptx ``MSO_AUTO_SHAPE_TYPE``.
    """
    RECTANGLE = 1
    PARALLELOGRAM = 2
    TRAPEZOID = 3
    DIAMOND = 4
    ROUNDED_RECTANGLE = 5
    OCTAGON = 6
    ISOSCELES_TRIANGLE = 7
    RIGHT_TRIANGLE = 8
    OVAL = 9
    HEXAGON = 10
    CROSS = 11
    REGULAR_PENTAGON = 12
    CAN = 13
    CUBE = 14
    BEVEL = 15
    FOLDED_CORNER = 16
    SMILEY_FACE = 17
    DONUT = 18
    NO_SYMBOL = 19
    BLOCK_ARC = 20
    HEART = 21
    LIGHTNING_BOLT = 22
    SUN = 23
    MOON = 24
    ARC = 25
    DOUBLE_BRACKET = 26
    DOUBLE_BRACE = 27
    PLAQUE = 28
    LEFT_BRACKET = 29
    RIGHT_BRACKET = 30
    LEFT_BRACE = 31
    RIGHT_BRACE = 32
    RIGHT_ARROW = 33
    LEFT_ARROW = 34
    UP_ARROW = 35
    DOWN_ARROW = 36
    LEFT_RIGHT_ARROW = 37
    UP_DOWN_ARROW = 38
    QUAD_ARROW = 39
    LEFT_RIGHT_UP_ARROW = 40
    BENT_ARROW = 41
    U_TURN_ARROW = 42
    LEFT_UP_ARROW = 43
    BENT_UP_ARROW = 44
    CURVED_RIGHT_ARROW = 45
    CURVED_LEFT_ARROW = 46
    CURVED_UP_ARROW = 47
    CURVED_DOWN_ARROW = 48
    STRIPED_RIGHT_ARROW = 49
    NOTCHED_RIGHT_ARROW = 50
    PENTAGON = 51
    CHEVRON = 52
    RIGHT_ARROW_CALLOUT = 53
    LEFT_ARROW_CALLOUT = 54
    UP_ARROW_CALLOUT = 55
    DOWN_ARROW_CALLOUT = 56
    LEFT_RIGHT_ARROW_CALLOUT = 57
    UP_DOWN_ARROW_CALLOUT = 58
    QUAD_ARROW_CALLOUT = 59
    CIRCULAR_ARROW = 60
    FLOWCHART_PROCESS = 61
    FLOWCHART_ALTERNATE_PROCESS = 62
    FLOWCHART_DECISION = 63
    FLOWCHART_DATA = 64
    FLOWCHART_PREDEFINED_PROCESS = 65
    FLOWCHART_INTERNAL_STORAGE = 66
    FLOWCHART_DOCUMENT = 67
    FLOWCHART_MULTIDOCUMENT = 68
    FLOWCHART_TERMINATOR = 69
    FLOWCHART_PREPARATION = 70
    FLOWCHART_MANUAL_INPUT = 71
    FLOWCHART_MANUAL_OPERATION = 72
    FLOWCHART_CONNECTOR = 73
    FLOWCHART_OFFPAGE_CONNECTOR = 74
    FLOWCHART_CARD = 75
    FLOWCHART_PUNCHED_TAPE = 76
    FLOWCHART_SUMMING_JUNCTION = 77
    FLOWCHART_OR = 78
    FLOWCHART_COLLATE = 79
    FLOWCHART_SORT = 80
    FLOWCHART_EXTRACT = 81
    FLOWCHART_MERGE = 82
    FLOWCHART_STORED_DATA = 83
    FLOWCHART_DELAY = 84
    FLOWCHART_SEQUENTIAL_ACCESS_STORAGE = 85
    FLOWCHART_MAGNETIC_DISK = 86
    FLOWCHART_DIRECT_ACCESS_STORAGE = 87
    FLOWCHART_DISPLAY = 88
    EXPLOSION1 = 89
    EXPLOSION2 = 90
    STAR_4_POINT = 91
    STAR_5_POINT = 92
    STAR_8_POINT = 93
    STAR_16_POINT = 94
    STAR_24_POINT = 95
    STAR_32_POINT = 96
    UP_RIBBON = 97
    DOWN_RIBBON = 98
    CURVED_UP_RIBBON = 99
    CURVED_DOWN_RIBBON = 100
    VERTICAL_SCROLL = 101
    HORIZONTAL_SCROLL = 102
    WAVE = 103
    DOUBLE_WAVE = 104
    RECTANGULAR_CALLOUT = 105
    ROUNDED_RECTANGULAR_CALLOUT = 106
    OVAL_CALLOUT = 107
    CLOUD_CALLOUT = 108
    LINE_CALLOUT_1 = 109
    LINE_CALLOUT_2 = 110
    LINE_CALLOUT_3 = 111
    LINE_CALLOUT_4 = 112
    LINE_CALLOUT_1_ACCENT_BAR = 113
    LINE_CALLOUT_2_ACCENT_BAR = 114
    LINE_CALLOUT_3_ACCENT_BAR = 115
    LINE_CALLOUT_4_ACCENT_BAR = 116
    LINE_CALLOUT_1_NO_BORDER = 117
    LINE_CALLOUT_2_NO_BORDER = 118
    LINE_CALLOUT_3_NO_BORDER = 119
    LINE_CALLOUT_4_NO_BORDER = 120
    LINE_CALLOUT_1_BORDER_AND_ACCENT_BAR = 121
    LINE_CALLOUT_2_BORDER_AND_ACCENT_BAR = 122
    LINE_CALLOUT_3_BORDER_AND_ACCENT_BAR = 123
    LINE_CALLOUT_4_BORDER_AND_ACCENT_BAR = 124
    ACTION_BUTTON_CUSTOM = 125
    ACTION_BUTTON_HOME = 126
    ACTION_BUTTON_HELP = 127
    ACTION_BUTTON_INFORMATION = 128
    ACTION_BUTTON_BACK_OR_PREVIOUS = 129
    ACTION_BUTTON_FORWARD_OR_NEXT = 130
    ACTION_BUTTON_BEGINNING = 131
    ACTION_BUTTON_END = 132
    ACTION_BUTTON_RETURN = 133
    ACTION_BUTTON_DOCUMENT = 134
    ACTION_BUTTON_SOUND = 135
    ACTION_BUTTON_MOVIE = 136
    BALLOON = 137
    FLOWCHART_OFFLINE_STORAGE = 139
    LEFT_RIGHT_RIBBON = 140
    DIAGONAL_STRIPE = 141
    PIE = 142
    NON_ISOSCELES_TRAPEZOID = 143
    DECAGON = 144
    HEPTAGON = 145
    DODECAGON = 146
    STAR_6_POINT = 147
    STAR_7_POINT = 148
    STAR_10_POINT = 149
    STAR_12_POINT = 150
    ROUND_1_RECTANGLE = 151
    ROUND_2_SAME_RECTANGLE = 152
    ROUND_2_DIAG_RECTANGLE = 153
    SNIP_ROUND_RECTANGLE = 154
    SNIP_1_RECTANGLE = 155
    SNIP_2_SAME_RECTANGLE = 156
    SNIP_2_DIAG_RECTANGLE = 157
    FRAME = 158
    HALF_FRAME = 159
    TEAR = 160
    CHORD = 161
    CORNER = 162
    MATH_PLUS = 163
    MATH_MINUS = 164
    MATH_MULTIPLY = 165
    MATH_DIVIDE = 166
    MATH_EQUAL = 167
    MATH_NOT_EQUAL = 168
    CORNER_TABS = 169
    SQUARE_TABS = 170
    PLAQUE_TABS = 171
    GEAR_6 = 172
    GEAR_9 = 173
    FUNNEL = 174
    PIE_WEDGE = 175
    LEFT_CIRCULAR_ARROW = 176
    LEFT_RIGHT_CIRCULAR_ARROW = 177
    SWOOSH_ARROW = 178
    CLOUD = 179
    CHART_X = 180
    CHART_STAR = 181
    CHART_PLUS = 182
    LINE_INVERSE = 183


# Alias for compatibility with standard python-pptx import path
MSO_AUTO_SHAPE_TYPE = MSO_SHAPE


class MSO_SHAPE_TYPE(IntEnum):
    """
    Shape type enumeration.

    Identifies the type of a shape (autoshape, picture, chart, etc.).
    """
    AUTO_SHAPE = 1
    CALLOUT = 2
    CANVAS = 20
    CHART = 3
    COMMENT = 4
    CONTENT_APP = 25
    DIAGRAM = 21
    EMBEDDED_OLE_OBJECT = 7
    FORM_CONTROL = 8
    FREEFORM = 5
    GROUP = 6
    IGX_GRAPHIC = 24
    INK = 22
    INK_COMMENT = 23
    LINE = 9
    LINKED_OLE_OBJECT = 10
    LINKED_PICTURE = 11
    MEDIA = 16
    OLE_CONTROL_OBJECT = 12
    PICTURE = 13
    PLACEHOLDER = 14
    SCRIPT_ANCHOR = 18
    TABLE = 19
    TEXT_BOX = 17
    TEXT_EFFECT = 15
    WEB_VIDEO = 26

    def __str__(self) -> str:
        # Mirror python-pptx: ``str(MSO_SHAPE_TYPE.PLACEHOLDER) == "PLACEHOLDER (14)"``.
        return f"{self.name} ({self.value})"


class MSO_CONNECTOR_TYPE(IntEnum):
    """
    Connector type enumeration.

    Specifies the type of connector.
    """
    CURVE = 3
    ELBOW = 2
    STRAIGHT = 1
    MIXED = -2


# python-pptx exposes this enum under both names. Preserve parity.
MSO_CONNECTOR = MSO_CONNECTOR_TYPE


class PP_PLACEHOLDER(IntEnum):
    """
    Placeholder type enumeration (PP_PLACEHOLDER_TYPE).

    Specifies the type of placeholder shape.
    Values match python-pptx's PP_PLACEHOLDER_TYPE exactly.
    """
    TITLE = 1
    BODY = 2
    CENTER_TITLE = 3
    SUBTITLE = 4
    VERTICAL_TITLE = 5
    VERTICAL_BODY = 6
    OBJECT = 7
    CHART = 8
    BITMAP = 9
    MEDIA_CLIP = 10
    ORG_CHART = 11
    TABLE = 12
    SLIDE_NUMBER = 13
    HEADER = 14
    FOOTER = 15
    DATE = 16
    VERTICAL_OBJECT = 17
    PICTURE = 18
    SLIDE_IMAGE = 101
    MIXED = -2

    @classmethod
    def from_ooxml_type(cls, type_str: str) -> "PP_PLACEHOLDER":
        """
        Convert OOXML placeholder type string to PP_PLACEHOLDER enum.

        Args:
            type_str: OOXML placeholder type (e.g., 'title', 'body', 'ctrTitle')

        Returns:
            Corresponding PP_PLACEHOLDER enum member
        """
        mapping = {
            'title': cls.TITLE,
            'body': cls.BODY,
            'ctrTitle': cls.CENTER_TITLE,
            'subTitle': cls.SUBTITLE,
            'dt': cls.DATE,
            'ftr': cls.FOOTER,
            'sldNum': cls.SLIDE_NUMBER,
            'hdr': cls.HEADER,
            'obj': cls.OBJECT,
            'chart': cls.CHART,
            'tbl': cls.TABLE,
            'pic': cls.PICTURE,
            'media': cls.MEDIA_CLIP,
            'clipArt': cls.BITMAP,
            'dgm': cls.ORG_CHART,
            'sldImg': cls.SLIDE_IMAGE,
        }
        return mapping.get(type_str, cls.OBJECT)


# Alias for compatibility
PP_PLACEHOLDER_TYPE = PP_PLACEHOLDER


# ---------------------------------------------------------------------------
# MSO_SHAPE → display "basename" used by python-pptx for default shape names.
# python-pptx names new auto-shapes as "<basename> <slide_shape_count_after>".
# We mirror that contract so AI agents can find shapes by predictable names.
# ---------------------------------------------------------------------------
_MSO_SHAPE_BASENAME = {
    1: 'Rectangle',
    2: 'Parallelogram',
    3: 'Trapezoid',
    4: 'Diamond',
    5: 'Rounded Rectangle',
    6: 'Octagon',
    7: 'Isosceles Triangle',
    8: 'Right Triangle',
    9: 'Oval',
    10: 'Hexagon',
    11: 'Cross',
    12: 'Regular Pentagon',
    13: 'Can',
    14: 'Cube',
    15: 'Bevel',
    16: 'Folded Corner',
    17: 'Smiley Face',
    18: 'Donut',
    19: '"No" Symbol',
    20: 'Block Arc',
    21: 'Heart',
    22: 'Lightning Bolt',
    23: 'Sun',
    24: 'Moon',
    25: 'Arc',
    26: 'Double Bracket',
    27: 'Double Brace',
    28: 'Plaque',
    29: 'Left Bracket',
    30: 'Right Bracket',
    31: 'Left Brace',
    32: 'Right Brace',
    33: 'Right Arrow',
    34: 'Left Arrow',
    35: 'Up Arrow',
    36: 'Down Arrow',
    37: 'Left-Right Arrow',
    38: 'Up-Down Arrow',
    39: 'Quad Arrow',
    40: 'Left-Right-Up Arrow',
    41: 'Bent Arrow',
    42: 'U-Turn Arrow',
    43: 'Left-Up Arrow',
    44: 'Bent-Up Arrow',
    45: 'Curved Right Arrow',
    46: 'Curved Left Arrow',
    47: 'Curved Up Arrow',
    48: 'Curved Down Arrow',
    49: 'Striped Right Arrow',
    50: 'Notched Right Arrow',
    51: 'Pentagon',
    52: 'Chevron',
    53: 'Right Arrow Callout',
    54: 'Left Arrow Callout',
    55: 'Up Arrow Callout',
    56: 'Down Arrow Callout',
    57: 'Left-Right Arrow Callout',
    58: 'Up-Down Arrow Callout',
    59: 'Quad Arrow Callout',
    60: 'Circular Arrow',
    61: 'Process',
    62: 'Alternate Process',
    63: 'Decision',
    64: 'Data',
    65: 'Predefined Process',
    66: 'Internal Storage',
    67: 'Document',
    68: 'Multidocument',
    69: 'Terminator',
    70: 'Preparation',
    71: 'Manual Input',
    72: 'Manual Operation',
    73: 'Connector',
    74: 'Off-page Connector',
    75: 'Card',
    76: 'Punched Tape',
    77: 'Summing Junction',
    78: 'Or',
    79: 'Collate',
    80: 'Sort',
    81: 'Extract',
    82: 'Merge',
    83: 'Stored Data',
    84: 'Delay',
    85: 'Sequential Access Storage',
    86: 'Magnetic Disk',
    87: 'Direct Access Storage',
    88: 'Display',
    92: 'Explosion 1',
    93: 'Explosion 2',
    94: '4-Point Star',
    95: '5-Point Star',
    96: '8-Point Star',
    97: '16-Point Star',
    98: '24-Point Star',
    99: '32-Point Star',
    100: 'Up Ribbon',
    101: 'Down Ribbon',
    102: 'Curved Up Ribbon',
    103: 'Curved Down Ribbon',
    104: 'Vertical Scroll',
    105: 'Horizontal Scroll',
    106: 'Wave',
    107: 'Double Wave',
    108: 'Rectangular Callout',
    109: 'Rounded Rectangular Callout',
    110: 'Oval Callout',
    111: 'Cloud Callout',
    112: 'Line Callout 1',
    113: 'Line Callout 2',
    114: 'Line Callout 3',
    115: 'Line Callout 4',
    116: 'Line Callout 1 (Accent Bar)',
    117: 'Line Callout 2 (Accent Bar)',
    118: 'Line Callout 3 (Accent Bar)',
    119: 'Line Callout 4 (Accent Bar)',
    120: 'Line Callout 1 (No Border)',
    121: 'Line Callout 2 (No Border)',
    122: 'Line Callout 3 (No Border)',
    123: 'Line Callout 4 (No Border)',
    124: 'Line Callout 1 (Border and Accent Bar)',
    125: 'Line Callout 2 (Border and Accent Bar)',
    126: 'Line Callout 3 (Border and Accent Bar)',
    127: 'Line Callout 4 (Border and Accent Bar)',
    128: 'Action Button: Custom',
    129: 'Action Button: Back or Previous',
    130: 'Action Button: Forward or Next',
    131: 'Action Button: Beginning',
    132: 'Action Button: End',
    133: 'Action Button: Home',
    134: 'Action Button: Information',
    135: 'Action Button: Return',
    136: 'Action Button: Movie',
    137: 'Action Button: Document',
    138: 'Action Button: Sound',
    139: 'Action Button: Help',
    140: 'Bevel',
    156: 'Frame',
}


def mso_shape_basename(shape) -> str:
    """Return python-pptx-compatible display basename for an MSO_SHAPE.

    Used by ``Shapes.add_shape()`` to mirror python-pptx's default naming
    scheme: ``f"{basename} {slide_shape_count_after_add}"``.
    """
    if isinstance(shape, str):
        # Backend string ('rectangle', 'oval', etc.) — title-case fallback.
        return shape.replace('_', ' ').title()
    try:
        value = int(shape)
    except (TypeError, ValueError):
        return 'Shape'
    if value in _MSO_SHAPE_BASENAME:
        return _MSO_SHAPE_BASENAME[value]
    name = getattr(shape, 'name', None)
    if name:
        return name.replace('_', ' ').title()
    return 'Shape'


_MSO_CONNECTOR_BASENAME = {
    1: 'Straight Connector',
    2: 'Elbow Connector',
    3: 'Curved Connector',
}


def mso_connector_basename(connector) -> str:
    """python-pptx names new connectors as ``f"{basename} {slide_count_after}"``.

    Mirrors python-pptx — ``MSO_CONNECTOR.STRAIGHT`` → ``"Straight Connector"``.
    """
    if isinstance(connector, str):
        normalized = connector.lower()
        if normalized in {'straight', 'line'}:
            return 'Straight Connector'
        if normalized == 'elbow':
            return 'Elbow Connector'
        if normalized == 'curve':
            return 'Curved Connector'
        return connector.replace('_', ' ').title()
    try:
        value = int(connector)
    except (TypeError, ValueError):
        return 'Connector'
    return _MSO_CONNECTOR_BASENAME.get(value, 'Connector')
