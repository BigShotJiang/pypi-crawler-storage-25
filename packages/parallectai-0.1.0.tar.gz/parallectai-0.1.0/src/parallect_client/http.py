from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any
from urllib.error import HTTPError
from urllib.request import Request, urlopen


@dataclass
class ApiClient:
    api_url: str
    token: str

    def post(self, path: str, payload: dict[str, Any]) -> tuple[int, Any]:
        return self._request("POST", path, payload)

    def get(self, path: str) -> tuple[int, Any]:
        return self._request("GET", path, None)

    def _request(self, method: str, path: str, payload: dict[str, Any] | None) -> tuple[int, Any]:
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        request = Request(
            f"{self.api_url.rstrip('/')}{path}",
            data=body,
            method=method,
            headers={
                "authorization": f"Bearer {self.token}",
                "content-type": "application/json",
                "user-agent": "parallect-client/0.1.0",
            },
        )

        try:
            with urlopen(request, timeout=60) as response:
                raw = response.read()
                if not raw:
                    return response.status, None
                return response.status, json.loads(raw.decode("utf-8"))
        except HTTPError as error:
            raw = error.read()
            details = raw.decode("utf-8") if raw else error.reason
            raise RuntimeError(f"API {method} {path} failed: {error.code} {details}") from error

