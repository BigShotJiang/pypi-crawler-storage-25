"""Kivi — Unified AI Chat Interface."""
__version__ = "0.1.3"
