#!/usr/bin/env python3
"""The headline Apple Silicon benchmark.

Compares Zilver's three execution paths against Qiskit Aer on a single
statevector evaluation across the qubit ceiling of the host Mac.

Backends:
  - zilver.metal      (custom Metal compute kernels + mx.compile)
  - zilver.accel      (numba multithreaded, P-core capped)
  - zilver.mlx-legacy (the original transpose+matmul path)
  - qiskit-aer        (statevector method, state-of-the-art CPU baseline)

The Metal path is what Zilver brings that no x86-grown simulator can: hand-written
gate kernels dispatched via MLX onto the Apple GPU, fused via mx.compile.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from benchmarks._bench_attest import Attestor, hardware_summary


def bench_metal(n: int, depth: int, trials: int) -> dict:
    import mlx.core as mx
    from zilver.circuit import hardware_efficient
    from zilver import metal

    c = hardware_efficient(n, depth)
    p = np.random.default_rng(0).uniform(-np.pi, np.pi, c.n_params).astype(np.float32)
    for _ in range(3): _ = metal.run_circuit(c, p, compile=True)
    ts = []
    for _ in range(trials):
        t0 = time.perf_counter()
        _ = metal.run_circuit(c, p, compile=True)
        ts.append(time.perf_counter() - t0)
    return {"backend": "zilver-metal", "mean_ms": float(np.mean(ts) * 1000),
            "min_ms": float(min(ts) * 1000)}


def bench_accel(n: int, depth: int, trials: int) -> dict:
    from zilver.circuit import hardware_efficient
    from zilver.accel import run_circuit_auto
    c = hardware_efficient(n, depth)
    p = np.random.default_rng(0).uniform(-np.pi, np.pi, c.n_params).astype(np.float64)
    for _ in range(3): _ = run_circuit_auto(c, p)
    ts = []
    for _ in range(trials):
        t0 = time.perf_counter()
        _ = run_circuit_auto(c, p)
        ts.append(time.perf_counter() - t0)
    return {"backend": "zilver-accel", "mean_ms": float(np.mean(ts) * 1000),
            "min_ms": float(min(ts) * 1000)}


def bench_mlx_legacy(n: int, depth: int, trials: int) -> dict:
    import mlx.core as mx
    from zilver.circuit import hardware_efficient
    c = hardware_efficient(n, depth)
    p = mx.array(np.random.default_rng(0).uniform(-np.pi, np.pi, c.n_params).astype(np.float32))
    for _ in range(2):
        s = c._run(p); mx.eval(s)
    ts = []
    for _ in range(trials):
        mx.eval(mx.zeros(1))
        t0 = time.perf_counter()
        s = c._run(p); mx.eval(s)
        ts.append(time.perf_counter() - t0)
    return {"backend": "zilver-mlx-legacy",
            "mean_ms": float(np.mean(ts) * 1000),
            "min_ms": float(min(ts) * 1000)}


def bench_aer(n: int, depth: int, trials: int) -> dict:
    from qiskit import QuantumCircuit
    from qiskit.circuit import Parameter
    from qiskit_aer import AerSimulator
    P = 2 * n * (depth + 1)
    psyms = [Parameter(f"p{i}") for i in range(P)]
    qc = QuantumCircuit(n); pi = 0
    for layer in range(depth + 1):
        for q in range(n):
            qc.ry(psyms[pi], q); pi += 1
            qc.rz(psyms[pi], q); pi += 1
        if layer < depth:
            for q in range(n - 1):
                qc.cx(q, q + 1)
    qc.save_statevector()
    sim = AerSimulator(method="statevector")
    pv = np.random.default_rng(0).uniform(-np.pi, np.pi, P)
    bd = qc.assign_parameters({p: float(v) for p, v in zip(psyms, pv)})
    _ = sim.run(bd).result().get_statevector()
    ts = []
    for _ in range(trials):
        bd = qc.assign_parameters({p: float(v) for p, v in zip(psyms, pv)})
        t0 = time.perf_counter()
        _ = sim.run(bd).result().get_statevector()
        ts.append(time.perf_counter() - t0)
    return {"backend": "qiskit-aer", "mean_ms": float(np.mean(ts) * 1000),
            "min_ms": float(min(ts) * 1000)}


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--qubits-list", default="8,12,16,20,22,24")
    p.add_argument("--depth", type=int, default=2)
    p.add_argument("--trials", type=int, default=4)
    p.add_argument("--out-dir", default=None)
    args = p.parse_args()

    qs = [int(x) for x in args.qubits_list.split(",")]
    hw = hardware_summary()

    print()
    print("=" * 88)
    print(f"  Zilver Apple Silicon Ceiling — {hw['chip']} ({hw['memory_gb']} GB unified)")
    print("=" * 88)
    print(f"  hardware-efficient depth={args.depth}    {args.trials} trials per cell")
    print()
    print(f"  {'n':>3}  {'zilver-metal':>14}  {'zilver-accel':>14}  {'mlx-legacy':>14}  {'qiskit-aer':>14}  {'speedup vs Aer':>16}")
    print(f"  {'-'*3}  {'-'*14}  {'-'*14}  {'-'*14}  {'-'*14}  {'-'*16}")

    all_rows = []
    for n in qs:
        rows = {}
        for name, fn in [("zilver-metal", bench_metal),
                         ("zilver-accel", bench_accel),
                         ("mlx-legacy",   bench_mlx_legacy),
                         ("qiskit-aer",   bench_aer)]:
            try:
                rows[name] = fn(n, args.depth, args.trials)
            except Exception as e:
                rows[name] = {"backend": name, "mean_ms": -1, "min_ms": -1, "error": str(e)[:80]}
        sp = rows["qiskit-aer"]["min_ms"] / rows["zilver-metal"]["min_ms"] \
             if rows["qiskit-aer"]["min_ms"] > 0 and rows["zilver-metal"]["min_ms"] > 0 else 0.0
        marker = "✓" if sp > 1.0 else " "
        print(f"  {n:>3}  "
              f"{rows['zilver-metal']['min_ms']:>14.2f}  "
              f"{rows['zilver-accel']['min_ms']:>14.2f}  "
              f"{rows['mlx-legacy']['min_ms']:>14.2f}  "
              f"{rows['qiskit-aer']['min_ms']:>14.2f}  "
              f"   {marker} {sp:>10.2f}×")
        all_rows.append({"n_qubits": n, "rows": rows})

    body = {
        "bench_name": "apple_silicon_ceiling",
        "depth": args.depth,
        "qubits": qs,
        "trials": args.trials,
        "results": all_rows,
        "hardware": hw,
    }
    if args.out_dir:
        out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
        attestor = Attestor()
        json_path = attestor.write(out_dir / "apple_silicon_ceiling.json", body)
        print()
        print(f"  signed JSON: {json_path} [{attestor.algorithm}]")


if __name__ == "__main__":
    main()
