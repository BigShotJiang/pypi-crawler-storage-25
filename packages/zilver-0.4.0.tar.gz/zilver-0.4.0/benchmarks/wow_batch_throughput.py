#!/usr/bin/env python3
"""Wow #1 — QML Landscape Throughput Scaling.

A parameter landscape sweep is the canonical QML primitive: gradient steps,
barren-plateau analysis, VQE warmup, kernel methods — they all reduce to
"evaluate the cost surface at K parameter points."

We hold qubits fixed (8) and sweep the grid size K = 64, 256, 1024, 4096.
Each backend computes the loss landscape:
  - Qiskit Aer         : K sequential statevector + Z-sum evals (native API)
  - PennyLane Lightning: K sequential qnode calls (native API)
  - Zilver MLX         : a single mx.vmap dispatch on Apple GPU

Plot wall-time vs K (log-log). Aer/Lightning grow linearly. Zilver stays
near-flat — vectorized vmap on Metal amortizes the whole sweep.

Output: benchmarks/results/<dir>/batch_throughput.{json,png}  (SE-signed)
"""

from __future__ import annotations

import argparse
import json
import os
import resource
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from benchmarks._bench_attest import Attestor, hardware_summary


# --- Backend workers (subprocess-isolated) -----------------------------------

def _grid_params(n_params: int, K: int, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.uniform(-np.pi, np.pi, (K, n_params)).astype(np.float32)


def _worker_zilver(n_qubits: int, depth: int, K: int) -> dict:
    import time as _t
    import mlx.core as mx
    from zilver.circuit import hardware_efficient

    circuit = hardware_efficient(n_qubits, depth)
    P = circuit.n_params
    grid = mx.array(_grid_params(P, K))

    f = circuit.compile(observable="sum_z")
    # warmup
    _w = mx.vmap(f)(mx.array(_grid_params(P, 4)))
    mx.eval(_w)

    t0 = _t.perf_counter()
    out = mx.vmap(f)(grid)
    mx.eval(out)
    elapsed = _t.perf_counter() - t0
    return {"wall_time_s": elapsed, "K": K, "n_params": P}


def _worker_aer(n_qubits: int, depth: int, K: int) -> dict:
    import time as _t
    import numpy as _np
    from qiskit import QuantumCircuit
    from qiskit.circuit import Parameter
    from qiskit_aer import AerSimulator

    # Matches zilver.circuit.hardware_efficient: RY+RZ per qubit per layer,
    # (depth+1) single-qubit layers, depth linear-CNOT entanglement layers.
    P = 2 * n_qubits * (depth + 1)
    params_sym = [Parameter(f"p{i}") for i in range(P)]

    qc = QuantumCircuit(n_qubits)
    pi = 0
    for layer in range(depth + 1):
        for q in range(n_qubits):
            qc.ry(params_sym[pi], q); pi += 1
            qc.rz(params_sym[pi], q); pi += 1
        if layer < depth:
            for q in range(n_qubits - 1):
                qc.cx(q, q + 1)
    qc.save_statevector()

    sim = AerSimulator(method="statevector")
    grid = _grid_params(P, K).astype(_np.float64)

    # sum_i Z_i as diagonal vector: amplitude basis state |x> has eigenvalue
    # (n - 2 * popcount(x))  — popcount of 0 contributes +1, popcount of 1 -1
    n = 1 << n_qubits
    pop = _np.array([n_qubits - 2 * bin(i).count("1") for i in range(n)], dtype=_np.float64)

    t0 = _t.perf_counter()
    for k in range(K):
        bound = qc.assign_parameters({p: v for p, v in zip(params_sym, grid[k])})
        result = sim.run(bound).result()
        sv = _np.asarray(result.get_statevector())
        probs = (sv.conj() * sv).real
        _ = float((probs * pop).sum())
    elapsed = _t.perf_counter() - t0
    return {"wall_time_s": elapsed, "K": K, "n_params": P}


def _worker_lightning(n_qubits: int, depth: int, K: int) -> dict:
    import time as _t
    import numpy as _np
    import pennylane as qml

    P = 2 * n_qubits * (depth + 1)
    grid = _grid_params(P, K).astype(_np.float64)
    dev = qml.device("lightning.qubit", wires=n_qubits)

    @qml.qnode(dev, interface=None)
    def circuit(p):
        pi = 0
        for layer in range(depth + 1):
            for q in range(n_qubits):
                qml.RY(p[pi], wires=q); pi += 1
                qml.RZ(p[pi], wires=q); pi += 1
            if layer < depth:
                for q in range(n_qubits - 1):
                    qml.CNOT(wires=[q, q + 1])
        return tuple(qml.expval(qml.PauliZ(q)) for q in range(n_qubits))

    t0 = _t.perf_counter()
    for k in range(K):
        vals = circuit(grid[k])
        _ = float(sum(vals))
    elapsed = _t.perf_counter() - t0
    return {"wall_time_s": elapsed, "K": K, "n_params": P}


BACKEND_WORKERS = {
    "zilver-mlx":          _worker_zilver,
    "qiskit-aer":          _worker_aer,
    "pennylane-lightning": _worker_lightning,
}


# --- Driver ------------------------------------------------------------------

def _run_in_subprocess(backend: str, n_qubits: int, depth: int, K: int,
                      timeout_s: float) -> dict:
    cmd = [
        sys.executable, __file__, "--child",
        "--backend", backend,
        "--qubits", str(n_qubits),
        "--depth", str(depth),
        "--K", str(K),
    ]
    t0 = time.perf_counter()
    try:
        out = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout_s,
            env={**os.environ, "PYTHONWARNINGS": "ignore"},
        )
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "wall_time_s": timeout_s}
    wall = time.perf_counter() - t0
    if out.returncode != 0:
        err = (out.stderr or "").strip()
        err_last = err.splitlines()[-1] if err else "exit nonzero"
        return {"status": "error", "wall_time_s": wall, "error": err_last[:200]}
    try:
        payload = json.loads(out.stdout.strip().splitlines()[-1])
    except Exception:
        return {"status": "parse_error", "wall_time_s": wall, "error": out.stdout[:200]}
    payload["status"] = "ok"
    return payload


def run_sweep(K_list: list[int], n_qubits: int, depth: int,
              backends: list[str], timeout_s: float) -> list[dict]:
    rows = []
    for K in K_list:
        for be in backends:
            print(f"  [{be:>22s}]  K={K:>5d}  ...", end="", flush=True)
            row = _run_in_subprocess(be, n_qubits, depth, K, timeout_s)
            row["backend"] = be
            row["n_qubits"] = n_qubits
            row["depth"] = depth
            row["K"] = K
            if row["status"] == "ok":
                row["throughput_evals_s"] = K / max(row["wall_time_s"], 1e-9)
            rows.append(row)
            wt = row.get("wall_time_s", 0.0)
            tp = row.get("throughput_evals_s", 0.0)
            print(f"  {row['status']:>8s}  {wt:>7.2f}s   {tp:>10.1f} evals/s")
    return rows


def make_chart(rows: list[dict], out_path: Path, chip: str, n_qubits: int, depth: int) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5), dpi=140)
    colors = {
        "zilver-mlx":          "#0a84ff",
        "qiskit-aer":          "#ff453a",
        "pennylane-lightning": "#30d158",
    }
    markers = {"zilver-mlx": "o", "qiskit-aer": "s", "pennylane-lightning": "^"}

    for be, color in colors.items():
        pts = sorted([r for r in rows if r["backend"] == be and r["status"] == "ok"],
                     key=lambda r: r["K"])
        if not pts:
            continue
        xs = [r["K"]            for r in pts]
        ts = [r["wall_time_s"]  for r in pts]
        tp = [r["throughput_evals_s"] for r in pts]
        ax1.plot(xs, ts, marker=markers[be], color=color, lw=2.4, ms=9, label=be)
        ax2.plot(xs, tp, marker=markers[be], color=color, lw=2.4, ms=9, label=be)

    for ax, ylabel, title in [
        (ax1, "Total wall time (s)",       "Landscape compute time"),
        (ax2, "Throughput (evals / s)",    "Throughput"),
    ]:
        ax.set_xscale("log", base=2)
        ax.set_yscale("log")
        ax.set_xlabel("Grid evaluations  K", fontsize=11)
        ax.set_ylabel(ylabel, fontsize=11)
        ax.set_title(title, fontsize=12, fontweight="bold")
        ax.grid(True, alpha=0.25, which="both")
        ax.legend(loc="best", framealpha=0.95, fontsize=9)

    fig.suptitle(
        f"QML Landscape Throughput  —  {n_qubits}q · depth={depth} · ⟨ΣZ⟩  ·  {chip}",
        fontsize=14, fontweight="bold", y=1.02,
    )
    fig.text(0.99, 0.005, "zilver.dev — one vmap on Apple GPU",
             ha="right", fontsize=8, color="#666", style="italic")
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--backend", default="zilver-mlx")
    p.add_argument("--qubits", type=int, default=8)
    p.add_argument("--depth", type=int, default=2)
    p.add_argument("--K", type=int, default=64)
    p.add_argument("--K-list", default="64,256,1024,4096")
    p.add_argument("--timeout", type=float, default=600.0)
    p.add_argument("--out-dir", default=None)
    args = p.parse_args()

    if args.child:
        worker = BACKEND_WORKERS[args.backend]
        result = worker(args.qubits, args.depth, args.K)
        result["peak_rss_mb"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024 * 1024)
        print(json.dumps(result))
        return

    K_list = [int(x) for x in args.K_list.split(",")]
    backends = ["pennylane-lightning", "qiskit-aer", "zilver-mlx"]

    hw = hardware_summary()
    ts = time.strftime("%Y%m%d-%H%M%S")
    out_dir = Path(args.out_dir or f"benchmarks/results/{ts}")
    out_dir.mkdir(parents=True, exist_ok=True)

    print()
    print("=" * 78)
    print(f"  Wow #1 — QML Landscape Throughput   {hw['chip']}  ({hw['memory_gb']} GB)")
    print("=" * 78)
    print(f"  qubits={args.qubits}  depth={args.depth}  observable=ΣZ  K={K_list}")
    print(f"  output: {out_dir}/")
    print()

    rows = run_sweep(K_list, args.qubits, args.depth, backends, args.timeout)

    # Summary
    print()
    print("  SPEEDUP @ largest K (Zilver vs Aer)")
    print("  " + "-" * 60)
    K_max = max(K_list)
    aer_t = next((r["wall_time_s"] for r in rows
                  if r["backend"] == "qiskit-aer" and r["K"] == K_max and r["status"] == "ok"), None)
    zil_t = next((r["wall_time_s"] for r in rows
                  if r["backend"] == "zilver-mlx" and r["K"] == K_max and r["status"] == "ok"), None)
    light_t = next((r["wall_time_s"] for r in rows
                    if r["backend"] == "pennylane-lightning" and r["K"] == K_max and r["status"] == "ok"), None)
    if aer_t and zil_t:
        light_str = f"Lightning {light_t:.1f}s" if light_t else "Lightning failed"
        print(f"    at K={K_max}:  Aer {aer_t:.1f}s   {light_str}   Zilver {zil_t:.2f}s")
        print(f"    speedup vs Aer       : {aer_t / zil_t:>6.1f}×")
        if light_t:
            print(f"    speedup vs Lightning : {light_t / zil_t:>6.1f}×")
    print()

    body = {
        "bench_name": "landscape_throughput",
        "n_qubits": args.qubits,
        "depth": args.depth,
        "K_list": K_list,
        "rows": rows,
        "hardware": hw,
    }
    attestor = Attestor()
    json_path = attestor.write(out_dir / "batch_throughput.json", body)
    print(f"  signed JSON  : {json_path}  [{attestor.algorithm}]")

    chart_path = out_dir / "batch_throughput.png"
    make_chart(rows, chart_path, hw["chip"], args.qubits, args.depth)
    if chart_path.exists():
        print(f"  chart        : {chart_path}")
    print()


if __name__ == "__main__":
    main()
