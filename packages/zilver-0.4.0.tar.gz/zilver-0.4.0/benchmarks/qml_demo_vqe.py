#!/usr/bin/env python3
"""QML Demo A — VQE on the Transverse-Field Ising Model (4 qubits).

Minimize ⟨H⟩ for H = -J Σ Z_i Z_{i+1} - h Σ X_i  (J = h = 1, open BC) using a
hardware-efficient ansatz + Adam. The known exact ground state energy for
n = 4 is  E₀ = -4.758770.

This is the canonical QML proof-of-work: gradient descent on a parameterized
quantum circuit, converging to a known reference.

What's compared
---------------
Both implementations use the **same algorithm** (parameter-shift gradient,
Adam). The difference is the gradient-batching:

  - Qiskit Aer : 2*P sequential statevector calls per step (no vmap available).
  - Zilver MLX : 2*P shifted evals in a single `param_shift_gradient` vmap
                 dispatch on Apple GPU.

For P = 24 params this is a ~Px advantage per iteration before any compute-side
speedup.

Output: benchmarks/results/<dir>/qml_vqe.{json,png}  (SE-signed)
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from benchmarks._bench_attest import Attestor, hardware_summary


# --- Reference Hamiltonian (TFIM) --------------------------------------------

def tfim_hamiltonian(n: int, J: float = 1.0, h: float = 1.0) -> np.ndarray:
    """Build the dense 2^n × 2^n TFIM Hamiltonian with open boundary."""
    I = np.array([[1, 0], [0, 1]], dtype=np.complex64)
    X = np.array([[0, 1], [1, 0]], dtype=np.complex64)
    Z = np.array([[1, 0], [0, -1]], dtype=np.complex64)

    def kron_op(qubits_ops: dict[int, np.ndarray]) -> np.ndarray:
        ops = [qubits_ops.get(i, I) for i in range(n)]
        out = ops[0]
        for o in ops[1:]:
            out = np.kron(out, o)
        return out

    H = np.zeros((2 ** n, 2 ** n), dtype=np.complex64)
    for i in range(n - 1):
        H -= J * kron_op({i: Z, i + 1: Z})
    for i in range(n):
        H -= h * kron_op({i: X})
    return H


def exact_ground_state(n: int, J: float = 1.0, h: float = 1.0) -> float:
    H = tfim_hamiltonian(n, J, h)
    return float(np.linalg.eigvalsh(H)[0])


# --- Adam optimizer (pure NumPy state) ---------------------------------------

class Adam:
    def __init__(self, n_params: int, lr: float = 0.05,
                 beta1: float = 0.9, beta2: float = 0.999, eps: float = 1e-8):
        self.lr = lr; self.b1 = beta1; self.b2 = beta2; self.eps = eps
        self.m = np.zeros(n_params, dtype=np.float64)
        self.v = np.zeros(n_params, dtype=np.float64)
        self.t = 0

    def step(self, params: np.ndarray, grads: np.ndarray) -> np.ndarray:
        self.t += 1
        self.m = self.b1 * self.m + (1 - self.b1) * grads
        self.v = self.b2 * self.v + (1 - self.b2) * grads ** 2
        m_hat = self.m / (1 - self.b1 ** self.t)
        v_hat = self.v / (1 - self.b2 ** self.t)
        return params - self.lr * m_hat / (np.sqrt(v_hat) + self.eps)


# --- Zilver training ----------------------------------------------------------

def train_zilver(n: int, depth: int, n_steps: int,
                 H_dense: np.ndarray) -> dict:
    import mlx.core as mx
    from zilver.circuit import hardware_efficient
    from zilver.gradients import param_shift_gradient

    circuit = hardware_efficient(n, depth)
    P = circuit.n_params
    H_mlx = mx.array(H_dense)

    def loss_fn(params: mx.array) -> mx.array:
        state = circuit._run(params)
        Hpsi = mx.matmul(H_mlx, state)
        return mx.real(mx.sum(mx.conj(state) * Hpsi))

    rng = np.random.default_rng(7)
    params_np = rng.uniform(-0.1, 0.1, P).astype(np.float32)
    opt = Adam(P, lr=0.08)

    energies, step_times = [], []
    t_total0 = time.perf_counter()
    for step in range(n_steps):
        t0 = time.perf_counter()
        params_mx = mx.array(params_np)
        # forward
        e_val = float(loss_fn(params_mx).item())
        # gradient (batched vmap of 2P shifted evals)
        g = param_shift_gradient(loss_fn, params_mx)
        g_np = np.array(g.tolist(), dtype=np.float64)
        # update
        params_np = opt.step(params_np.astype(np.float64), g_np).astype(np.float32)
        step_times.append(time.perf_counter() - t0)
        energies.append(e_val)
    total = time.perf_counter() - t_total0

    return {
        "backend": "zilver-mlx",
        "n_params": P,
        "n_steps": n_steps,
        "energies": energies,
        "step_times": step_times,
        "total_time_s": total,
        "final_energy": energies[-1],
    }


# --- Aer training -------------------------------------------------------------

def train_aer(n: int, depth: int, n_steps: int, H_dense: np.ndarray) -> dict:
    from qiskit import QuantumCircuit
    from qiskit.circuit import Parameter
    from qiskit_aer import AerSimulator

    P = 2 * n * (depth + 1)
    params_sym = [Parameter(f"p{i}") for i in range(P)]
    qc = QuantumCircuit(n)
    pi = 0
    for layer in range(depth + 1):
        for q in range(n):
            qc.ry(params_sym[pi], q); pi += 1
            qc.rz(params_sym[pi], q); pi += 1
        if layer < depth:
            for q in range(n - 1):
                qc.cx(q, q + 1)
    qc.save_statevector()
    sim = AerSimulator(method="statevector")
    H = H_dense.astype(np.complex128)

    def expectation(params: np.ndarray) -> float:
        bound = qc.assign_parameters({p: float(v) for p, v in zip(params_sym, params)})
        result = sim.run(bound).result()
        psi = np.asarray(result.get_statevector())
        return float(np.real(psi.conj() @ H @ psi))

    rng = np.random.default_rng(7)
    params = rng.uniform(-0.1, 0.1, P).astype(np.float64)
    opt = Adam(P, lr=0.08)

    SHIFT = np.pi / 2
    energies, step_times = [], []
    t_total0 = time.perf_counter()
    for step in range(n_steps):
        t0 = time.perf_counter()
        # forward
        e_val = expectation(params)
        # parameter shift: 2P sequential evaluations
        grads = np.zeros(P, dtype=np.float64)
        for k in range(P):
            p_plus = params.copy();  p_plus[k]  += SHIFT
            p_minus = params.copy(); p_minus[k] -= SHIFT
            grads[k] = 0.5 * (expectation(p_plus) - expectation(p_minus))
        # update
        params = opt.step(params, grads)
        step_times.append(time.perf_counter() - t0)
        energies.append(e_val)
    total = time.perf_counter() - t_total0

    return {
        "backend": "qiskit-aer",
        "n_params": P,
        "n_steps": n_steps,
        "energies": energies,
        "step_times": step_times,
        "total_time_s": total,
        "final_energy": energies[-1],
    }


# --- Plot ---------------------------------------------------------------------

def make_chart(zil: dict, aer: dict, exact: float, out_path: Path, chip: str) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5), dpi=140)

    # Convergence
    iters = np.arange(1, len(zil["energies"]) + 1)
    ax1.axhline(exact, color="#888", lw=1.2, ls="--",
                label=f"exact  E₀ = {exact:.4f}", zorder=1)
    ax1.plot(iters, aer["energies"], color="#ff453a", lw=2.0, marker="s",
             ms=4, alpha=0.85, label=f"qiskit-aer  ({aer['total_time_s']:.1f}s)")
    ax1.plot(iters, zil["energies"], color="#0a84ff", lw=2.0, marker="o",
             ms=4, alpha=0.85, label=f"zilver-mlx  ({zil['total_time_s']:.1f}s)")
    ax1.set_xlabel("Adam step", fontsize=11)
    ax1.set_ylabel(r"⟨H⟩  (TFIM energy)", fontsize=11)
    ax1.set_title("VQE convergence — same algorithm, same answer", fontsize=12, fontweight="bold")
    ax1.legend(loc="upper right", framealpha=0.95, fontsize=10)
    ax1.grid(True, alpha=0.25); ax1.set_axisbelow(True)

    # Per-step time
    ax2.plot(iters, np.array(aer["step_times"]) * 1000.0, color="#ff453a", lw=2.0,
             marker="s", ms=4, label=f"qiskit-aer  ({aer['n_params']} param shifts/step)")
    ax2.plot(iters, np.array(zil["step_times"]) * 1000.0, color="#0a84ff", lw=2.0,
             marker="o", ms=4, label=f"zilver-mlx  (one vmap dispatch)")
    ax2.set_xlabel("Adam step", fontsize=11)
    ax2.set_ylabel("Time per step (ms)", fontsize=11)
    ax2.set_title("Per-step gradient time", fontsize=12, fontweight="bold")
    ax2.set_yscale("log")
    ax2.legend(loc="best", framealpha=0.95, fontsize=10)
    ax2.grid(True, alpha=0.25, which="both"); ax2.set_axisbelow(True)

    speedup = aer["total_time_s"] / zil["total_time_s"]
    fig.suptitle(
        f"VQE — TFIM(4q, J=h=1)  ·  {aer['n_params']} params  ·  Adam  ·  "
        f"{speedup:.0f}× faster on {chip}",
        fontsize=13, fontweight="bold", y=1.02,
    )
    fig.text(0.99, 0.005,
             "zilver.dev — same gradient algorithm, fused into one GPU dispatch",
             ha="right", fontsize=8, color="#666", style="italic")
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


# --- Main ---------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--qubits", type=int, default=4)
    p.add_argument("--depth",  type=int, default=2)
    p.add_argument("--steps",  type=int, default=120)
    p.add_argument("--out-dir", default=None)
    args = p.parse_args()

    hw = hardware_summary()
    ts = time.strftime("%Y%m%d-%H%M%S")
    out_dir = Path(args.out_dir or f"benchmarks/results/{ts}")
    out_dir.mkdir(parents=True, exist_ok=True)

    H = tfim_hamiltonian(args.qubits)
    exact = exact_ground_state(args.qubits)

    print()
    print("=" * 78)
    print(f"  QML Demo A — VQE on TFIM   {hw['chip']}  ({hw['memory_gb']} GB)")
    print("=" * 78)
    print(f"  qubits={args.qubits}  depth={args.depth}  steps={args.steps}")
    print(f"  exact ground state E₀ = {exact:.6f}")
    print()

    print(f"  Training Zilver MLX...", end="", flush=True)
    zil = train_zilver(args.qubits, args.depth, args.steps, H)
    print(f"  total={zil['total_time_s']:.2f}s  final E = {zil['final_energy']:.6f}  "
          f"(error {abs(zil['final_energy'] - exact):.2e})")

    print(f"  Training Qiskit Aer...", end="", flush=True)
    aer = train_aer(args.qubits, args.depth, args.steps, H)
    print(f"  total={aer['total_time_s']:.2f}s  final E = {aer['final_energy']:.6f}  "
          f"(error {abs(aer['final_energy'] - exact):.2e})")

    speedup = aer["total_time_s"] / zil["total_time_s"]
    print()
    print(f"  SPEEDUP (total wall time): {speedup:.1f}×")
    print(f"  per-step Aer median: {np.median(aer['step_times'])*1000:.1f} ms")
    print(f"  per-step Zil median: {np.median(zil['step_times'])*1000:.1f} ms")
    print()

    body = {
        "bench_name": "qml_vqe_tfim",
        "n_qubits": args.qubits,
        "depth": args.depth,
        "n_steps": args.steps,
        "exact_ground_state": exact,
        "zilver": zil,
        "aer": aer,
        "speedup_total_time": speedup,
        "hardware": hw,
    }
    attestor = Attestor()
    json_path = attestor.write(out_dir / "qml_vqe.json", body)
    print(f"  signed JSON  : {json_path}  [{attestor.algorithm}]")

    chart_path = out_dir / "qml_vqe.png"
    make_chart(zil, aer, exact, chart_path, hw["chip"])
    if chart_path.exists():
        print(f"  chart        : {chart_path}")
    print()


if __name__ == "__main__":
    main()
