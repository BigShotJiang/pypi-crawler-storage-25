#!/usr/bin/env python3
"""Wow Suite — run all three Zilver benchmarks back-to-back.

Produces one timestamped directory with:
  - batch_throughput.{json,png}    Wow #1  (landscape throughput scaling)
  - landscape_snap.{json,png}      Wow #2  (Aer vs Zilver side-by-side)
  - cost_card.{json,png,txt}       Wow #3  (cost vs cloud)
  - SUMMARY.txt                    keynote-style headlines for sharing

Every JSON is Ed25519 / Secure-Enclave signed and tied to the hardware UUID.

Usage
-----
  python benchmarks/wow_suite.py                  # safe defaults (M1 Pro / 16 GB)
  python benchmarks/wow_suite.py --quick          # tiny grid for smoke-test
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from benchmarks._bench_attest import hardware_summary  # noqa: E402


PY = sys.executable
BENCH_DIR = REPO_ROOT / "benchmarks"


def _run(label: str, script: str, args: list[str]) -> None:
    print()
    print("━" * 78)
    print(f"  ▶  {label}")
    print("━" * 78)
    cmd = [PY, str(BENCH_DIR / script), *args]
    rc = subprocess.run(cmd).returncode
    if rc != 0:
        print(f"  ✗ {script} exited {rc}", file=sys.stderr)
        sys.exit(rc)


def _safe_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def write_summary(out_dir: Path) -> None:
    hw = hardware_summary()

    b1 = _safe_json(out_dir / "batch_throughput.json").get("body", {})
    b2 = _safe_json(out_dir / "landscape_snap.json").get("body", {})
    b3 = _safe_json(out_dir / "cost_card.json").get("body", {})

    def speedup_at_kmax(b: dict) -> tuple[int, float, float] | None:
        if not b: return None
        rows = b.get("rows", [])
        K_list = b.get("K_list", [])
        if not K_list: return None
        Kmax = max(K_list)
        aer = next((r for r in rows if r["backend"] == "qiskit-aer"
                    and r["K"] == Kmax and r["status"] == "ok"), None)
        zil = next((r for r in rows if r["backend"] == "zilver-mlx"
                    and r["K"] == Kmax and r["status"] == "ok"), None)
        if not (aer and zil): return None
        return (Kmax, aer["wall_time_s"], zil["wall_time_s"])

    headline_1 = ""
    su = speedup_at_kmax(b1)
    if su:
        Kmax, at, zt = su
        headline_1 = (f"Wow #1 — At {Kmax:,} QML evals on {b1.get('n_qubits')}q: "
                      f"Aer {at:.1f}s,  Zilver {zt:.2f}s  →  {at/zt:.0f}× faster")

    headline_2 = ""
    if b2:
        s = b2.get("speedup", 0)
        headline_2 = (f"Wow #2 — 2D landscape {b2.get('resolution')}×{b2.get('resolution')} on "
                      f"{b2.get('n_qubits')}q: Zilver {b2.get('zilver',{}).get('wall_time_s',0):.2f}s "
                      f"vs Aer {b2.get('aer',{}).get('wall_time_s',0):.1f}s  →  {s:.0f}× faster")

    headline_3 = ""
    if b3:
        c = b3.get("projected_costs", {})
        zm = c.get("zilver_mac", {})
        sv1 = c.get("aws_braket_sv1", {})
        qpu = c.get("qpu_ionq_aria", {})
        if zm and sv1:
            headline_3 = (f"Wow #3 — {b3.get('n_evals',0):,} evals: your Mac in {zm['wall_time_s']:.1f}s "
                          f"for $0.   Braket SV1 same workload ≈ ${sv1['cost_usd']:.2f}.   "
                          f"IonQ QPU shots ≈ ${qpu['cost_usd']:.0f}.")

    text = []
    text.append("=" * 78)
    text.append(f"  ZILVER WOW SUITE — {hw['chip']} · {hw['memory_gb']:.0f} GB unified")
    text.append(f"  hardware UUID: {hw['hardware_uuid']}")
    text.append(f"  results dir   : {out_dir}")
    text.append("=" * 78)
    text.append("")
    for h in (headline_1, headline_2, headline_3):
        if h:
            text.append("  • " + h)
    text.append("")
    text.append("  Each JSON is signed with the hardware key (SE P-256 or Ed25519).")
    text.append("  Run `python benchmarks/verify.py <json>` to re-verify any result.")
    text.append("")

    summary = "\n".join(text)
    (out_dir / "SUMMARY.txt").write_text(summary)
    print()
    print(summary)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--quick", action="store_true",
                   help="Tiny grids for smoke-test (~30s total)")
    p.add_argument("--out-dir", default=None)
    args = p.parse_args()

    ts = time.strftime("%Y%m%d-%H%M%S")
    out_dir = Path(args.out_dir or f"benchmarks/results/wow_{ts}")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_dir_abs = out_dir.resolve()

    print()
    print("┌" + "─" * 76 + "┐")
    print(f"│{'  ZILVER WOW SUITE':<76}│")
    print(f"│{'  Three Apple-grade quantum simulator demos':<76}│")
    print("└" + "─" * 76 + "┘")
    print(f"  Output → {out_dir_abs}")

    if args.quick:
        # smoke
        _run("Wow #1 — QML Landscape Throughput", "wow_batch_throughput.py",
             ["--K-list", "64,256", "--qubits", "8", "--depth", "2",
              "--timeout", "180", "--out-dir", str(out_dir)])
        _run("Wow #2 — Landscape Snap (Aer vs Zilver)", "wow_landscape_snap.py",
             ["--qubits", "6", "--depth", "2", "--resolution", "16",
              "--out-dir", str(out_dir)])
        _run("Wow #3 — Cost Card", "wow_cost_card.py",
             ["--qubits", "8", "--depth", "2", "--n-evals", "1000",
              "--out-dir", str(out_dir)])
    else:
        _run("Wow #1 — QML Landscape Throughput", "wow_batch_throughput.py",
             ["--K-list", "64,256,1024,4096", "--qubits", "8", "--depth", "2",
              "--timeout", "600", "--out-dir", str(out_dir)])
        _run("Wow #2 — Landscape Snap (Aer vs Zilver)", "wow_landscape_snap.py",
             ["--qubits", "6", "--depth", "2", "--resolution", "32",
              "--out-dir", str(out_dir)])
        _run("Wow #3 — Cost Card", "wow_cost_card.py",
             ["--qubits", "10", "--depth", "3", "--n-evals", "10000",
              "--out-dir", str(out_dir)])

    write_summary(out_dir)


if __name__ == "__main__":
    main()
