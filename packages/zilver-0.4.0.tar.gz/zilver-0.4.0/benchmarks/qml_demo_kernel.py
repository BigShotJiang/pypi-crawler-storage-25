#!/usr/bin/env python3
"""QML Demo B — Quantum kernel classifier on the moons dataset.

Train a kernel SVM whose Gram matrix is the *quantum* fidelity kernel
K[i,j] = |⟨ψ(x_i)|ψ(x_j)⟩|² computed from a 4-qubit feature embedding.

Zilver computes the entire N×N kernel in a single `circuit.fidelity_kernel()`
call (vmap-prepares all N statevectors at once, then on-device matmul).
Qiskit Aer must loop N sequential statevector preps, then host-side matmul
for the kernel.

The decision boundary is plotted side-by-side with a classical RBF-kernel SVM
for context — same data, two kernels, similar accuracy on a 2-moons toy.

Output: benchmarks/results/<dir>/qml_kernel.{json,png}  (SE-signed)
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from benchmarks._bench_attest import Attestor, hardware_summary


N_QUBITS = 4


def _features_to_params(X: np.ndarray) -> np.ndarray:
    """Map each (x1, x2) row to a 4-param vector with nonlinear interactions:
    [x1, x2, x1*x2, (1-x1)*(1-x2)]  — Havliček-style ZZ feature map encoding."""
    x1, x2 = X[:, 0], X[:, 1]
    return np.stack([x1, x2, x1 * x2, (1 - x1) * (1 - x2)], axis=1).astype(np.float32)


def _build_encoder():
    """Havliček-style ZZ feature map: H + RZ + RZZ entanglers, 2 layers.
    n_params = 4 (the four nonlinear features of (x1, x2))."""
    from zilver.circuit import Circuit
    c = Circuit(N_QUBITS)
    for _ in range(2):
        for q in range(N_QUBITS):
            c.h(q)
        c.rz(0, 0); c.rz(1, 1); c.rz(2, 0); c.rz(3, 1)
        c.rzz(0, 1, 2); c.rzz(2, 3, 2); c.rzz(1, 2, 3)
    return c


# --- Zilver: build N statevectors with vmap + on-device matmul --------------

def kernel_zilver(X: np.ndarray) -> tuple[np.ndarray, float]:
    import mlx.core as mx

    c = _build_encoder()
    params_batch = mx.array(_features_to_params(X))
    # warmup
    _w = c.fidelity_kernel(params_batch[:4])

    t0 = time.perf_counter()
    K = c.fidelity_kernel(params_batch)
    elapsed = time.perf_counter() - t0
    return K, elapsed


# --- Aer: N sequential statevectors, host-side matmul -----------------------

def kernel_aer(X: np.ndarray) -> tuple[np.ndarray, float]:
    from qiskit import QuantumCircuit
    from qiskit.circuit import Parameter
    from qiskit_aer import AerSimulator

    # Same Havliček-style ZZ feature map as the Zilver encoder
    params_sym = [Parameter(f"x{i}") for i in range(4)]
    qc = QuantumCircuit(N_QUBITS)
    for _ in range(2):
        for q in range(N_QUBITS):
            qc.h(q)
        qc.rz(params_sym[0], 0); qc.rz(params_sym[1], 1)
        qc.rz(params_sym[0], 2); qc.rz(params_sym[1], 3)
        qc.rzz(params_sym[2], 0, 1)
        qc.rzz(params_sym[2], 2, 3)
        qc.rzz(params_sym[3], 1, 2)
    qc.save_statevector()
    sim = AerSimulator(method="statevector")

    feats = _features_to_params(X).astype(np.float64)
    N = X.shape[0]
    states = np.zeros((N, 2 ** N_QUBITS), dtype=np.complex128)

    t0 = time.perf_counter()
    for i in range(N):
        bound = qc.assign_parameters({p: float(v) for p, v in zip(params_sym, feats[i])})
        res = sim.run(bound).result()
        states[i] = np.asarray(res.get_statevector())
    # host-side overlap matrix
    overlaps = states.conj() @ states.T   # (N, N) complex
    K = (overlaps.real ** 2 + overlaps.imag ** 2).astype(np.float32)
    elapsed = time.perf_counter() - t0
    return K, elapsed


# --- Training & plotting -----------------------------------------------------

def train_and_plot(X_train, y_train, X_test, y_test,
                   K_train_zil, K_test_zil,
                   K_train_aer, K_test_aer,
                   zil_time: float, aer_time: float,
                   out_path: Path, chip: str) -> dict:
    from sklearn.svm import SVC
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    # Zilver quantum kernel SVM
    svm_zil = SVC(kernel="precomputed", C=2.0)
    svm_zil.fit(K_train_zil, y_train)
    acc_zil = float(svm_zil.score(K_test_zil, y_test))

    # Aer quantum kernel SVM (cross-check: same accuracy ⇒ same kernel computed)
    svm_aer = SVC(kernel="precomputed", C=2.0)
    svm_aer.fit(K_train_aer, y_train)
    acc_aer = float(svm_aer.score(K_test_aer, y_test))

    # Classical RBF baseline
    svm_rbf = SVC(kernel="rbf", C=2.0, gamma=2.0)
    svm_rbf.fit(X_train, y_train)
    acc_rbf = float(svm_rbf.score(X_test, y_test))

    # Decision-boundary grid for the quantum kernel SVM (Zilver)
    xx, yy = np.meshgrid(
        np.linspace(X_train[:, 0].min() - 0.4, X_train[:, 0].max() + 0.4, 80),
        np.linspace(X_train[:, 1].min() - 0.4, X_train[:, 1].max() + 0.4, 80),
    )
    grid = np.c_[xx.ravel(), yy.ravel()]
    K_grid_zil, _ = kernel_zilver(np.vstack([X_train, grid]))
    K_grid_pred = K_grid_zil[len(X_train):, :len(X_train)]
    Z_q = svm_zil.decision_function(K_grid_pred).reshape(xx.shape)

    Z_rbf = svm_rbf.decision_function(grid).reshape(xx.shape)

    fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.5), dpi=140)
    for ax, Z, title, color in [
        (axes[0], Z_q,   f"Quantum kernel SVM (Zilver)\n  acc={acc_zil:.2f} · kernel built in {zil_time*1000:.0f} ms", "#0a84ff"),
        (axes[1], Z_rbf, f"Classical RBF SVM\n  acc={acc_rbf:.2f} · for context",                                     "#ff453a"),
    ]:
        ax.contourf(xx, yy, Z, levels=[-1e9, 0, 1e9], colors=["#a8c8ff", "#ffc4be"], alpha=0.6)
        ax.contour(xx, yy, Z, levels=[0.0], colors=[color], linewidths=2.0)
        ax.scatter(X_train[y_train == 0, 0], X_train[y_train == 0, 1],
                   c="#1e3a8a", edgecolor="white", s=40, label="class 0")
        ax.scatter(X_train[y_train == 1, 0], X_train[y_train == 1, 1],
                   c="#7f1d1d", edgecolor="white", s=40, marker="^", label="class 1")
        ax.set_title(title, fontsize=12, fontweight="bold", color=color)
        ax.set_xticks([]); ax.set_yticks([])

    fig.suptitle(
        f"Quantum-kernel classifier on moons   ·   {N_QUBITS} qubits   ·   "
        f"Zilver kernel {zil_time*1000:.0f}ms vs Aer kernel {aer_time*1000:.0f}ms   ·   {chip}",
        fontsize=12.5, fontweight="bold", y=1.02,
    )
    fig.text(0.99, 0.005,
             "zilver.dev — vmap-prepared statevectors · on-device fidelity matrix",
             ha="right", fontsize=8, color="#666", style="italic")
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)

    return {
        "acc_zilver": acc_zil,
        "acc_aer": acc_aer,
        "acc_rbf_classical": acc_rbf,
        "kernel_agreement_max_abs_diff": float(np.max(np.abs(K_train_zil - K_train_aer))),
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--n-samples", type=int, default=120)
    p.add_argument("--noise", type=float, default=0.18)
    p.add_argument("--out-dir", default=None)
    args = p.parse_args()

    from sklearn.datasets import make_moons
    from sklearn.model_selection import train_test_split

    X, y = make_moons(n_samples=args.n_samples, noise=args.noise, random_state=7)
    X = ((X - X.mean(0)) / X.std(0)).astype(np.float32)  # standardize
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=7, stratify=y,
    )

    hw = hardware_summary()
    ts = time.strftime("%Y%m%d-%H%M%S")
    out_dir = Path(args.out_dir or f"benchmarks/results/{ts}")
    out_dir.mkdir(parents=True, exist_ok=True)

    print()
    print("=" * 78)
    print(f"  QML Demo B — Quantum-kernel classifier on moons   {hw['chip']}")
    print("=" * 78)
    N_full = X.shape[0]
    print(f"  N = {N_full}  ·  encoder = 4q, depth 2  ·  kernel = |⟨ψ(x)|ψ(y)⟩|²")
    print()

    # Compute kernels on [X_train, X_test] stacked so the index order matches
    # the post-shuffle split (otherwise we'd be feeding the SVM mismatched rows).
    X_stack = np.vstack([X_train, X_test])
    print(f"  Zilver fidelity_kernel({N_full})...", end="", flush=True)
    K_zil, t_zil = kernel_zilver(X_stack)
    print(f"  {t_zil * 1000:.1f} ms")

    print(f"  Aer sequential kernel({N_full})...", end="", flush=True)
    K_aer, t_aer = kernel_aer(X_stack)
    print(f"  {t_aer * 1000:.1f} ms")

    n_train = X_train.shape[0]
    K_train_zil = K_zil[:n_train, :n_train]
    K_test_zil  = K_zil[n_train:, :n_train]
    K_train_aer = K_aer[:n_train, :n_train]
    K_test_aer  = K_aer[n_train:, :n_train]

    print()
    print(f"  speedup: {t_aer / t_zil:.1f}× (Aer / Zilver)")
    print(f"  kernel agreement (max |diff|): {np.max(np.abs(K_zil - K_aer)):.2e}")

    chart_path = out_dir / "qml_kernel.png"
    results = train_and_plot(
        X_train, y_train, X_test, y_test,
        K_train_zil, K_test_zil, K_train_aer, K_test_aer,
        t_zil, t_aer, chart_path, hw["chip"],
    )

    print()
    print(f"  test accuracy:")
    print(f"    quantum kernel (Zilver)   : {results['acc_zilver']:.3f}")
    print(f"    quantum kernel (Aer x-chk): {results['acc_aer']:.3f}")
    print(f"    classical RBF (baseline)  : {results['acc_rbf_classical']:.3f}")
    print()

    body = {
        "bench_name": "qml_kernel_moons",
        "n_qubits": N_QUBITS,
        "n_samples": N_full,
        "zilver_kernel_time_s": t_zil,
        "aer_kernel_time_s": t_aer,
        "speedup": t_aer / max(t_zil, 1e-9),
        "results": results,
        "hardware": hw,
    }
    attestor = Attestor()
    json_path = attestor.write(out_dir / "qml_kernel.json", body)
    print(f"  signed JSON  : {json_path}  [{attestor.algorithm}]")
    if chart_path.exists():
        print(f"  chart        : {chart_path}")
    print()


if __name__ == "__main__":
    main()
