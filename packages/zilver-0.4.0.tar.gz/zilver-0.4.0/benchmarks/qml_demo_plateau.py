#!/usr/bin/env python3
"""QML Demo C — Barren plateau sweep.

The barren plateau theorem (McClean et al. 2018) predicts that for sufficiently
deep, random parameterized quantum circuits, the variance of any cost-function
gradient decays *exponentially* in the qubit count:

    Var[∂L/∂θ_k]  ~  2^{-n}

This is a foundational result for QML — it tells you which ansätze are
trainable at scale. Measuring it requires evaluating *many* gradients across
*many* random parameter samples — exactly the workload where Zilver's vmap
ate the others' lunch in Wow #1.

We sweep n_qubits ∈ {4, 6, 8, 10}, sample 50 random parameter vectors per
n, compute the gradient w.r.t. the first parameter, and report its variance.
Both backends compute the same thing; we record wall time per backend to show
the practical price of running this experiment.

Output: benchmarks/results/<dir>/qml_plateau.{json,png}  (SE-signed)
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from benchmarks._bench_attest import Attestor, hardware_summary


# --- Zilver: gradient variance via batched parameter shift -------------------

def variance_zilver(n_qubits: int, depth: int, n_samples: int,
                    seed: int = 0) -> dict:
    import mlx.core as mx
    from zilver.circuit import hardware_efficient

    circuit = hardware_efficient(n_qubits, depth)
    P = circuit.n_params
    f = circuit.compile(observable="z0")

    rng = np.random.default_rng(seed)
    samples = rng.uniform(-np.pi, np.pi, (n_samples, P)).astype(np.float32)
    samples_mx = mx.array(samples)

    # Apples-to-apples with Aer: only compute gradient w.r.t. param 0 per sample.
    # 2 forward passes per sample, fused into one vmap of (2 * n_samples) evals.
    SHIFT = np.pi / 2
    e0 = mx.zeros((P,), dtype=mx.float32)
    e0 = mx.concatenate([mx.array([SHIFT], dtype=mx.float32),
                         mx.zeros((P - 1,), dtype=mx.float32)])

    def first_param_grad(batch: mx.array) -> mx.array:
        plus  = batch + e0     # (B, P)
        minus = batch - e0     # (B, P)
        all_shifted = mx.concatenate([plus, minus], axis=0)  # (2B, P)
        vals = mx.vmap(f)(all_shifted)                       # (2B,)
        B = batch.shape[0]
        return 0.5 * (vals[:B] - vals[B:])                   # (B,)

    # warmup
    _ = first_param_grad(samples_mx[:4]); mx.eval(_)

    t0 = time.perf_counter()
    g0 = first_param_grad(samples_mx)
    mx.eval(g0)
    elapsed = time.perf_counter() - t0
    first_param_grads = np.array(g0.tolist(), dtype=np.float64)

    return {
        "backend": "zilver-mlx",
        "n_qubits": n_qubits, "depth": depth, "n_samples": n_samples,
        "n_params": P,
        "variance": float(np.var(first_param_grads)),
        "mean_abs": float(np.mean(np.abs(first_param_grads))),
        "wall_time_s": elapsed,
    }


# --- Aer: gradient variance via sequential parameter shift -------------------

def variance_aer(n_qubits: int, depth: int, n_samples: int,
                 seed: int = 0) -> dict:
    from qiskit import QuantumCircuit
    from qiskit.circuit import Parameter
    from qiskit_aer import AerSimulator

    P = 2 * n_qubits * (depth + 1)
    params_sym = [Parameter(f"p{i}") for i in range(P)]
    qc = QuantumCircuit(n_qubits)
    pi = 0
    for layer in range(depth + 1):
        for q in range(n_qubits):
            qc.ry(params_sym[pi], q); pi += 1
            qc.rz(params_sym[pi], q); pi += 1
        if layer < depth:
            for q in range(n_qubits - 1):
                qc.cx(q, q + 1)
    qc.save_statevector()
    sim = AerSimulator(method="statevector")

    # Z_0 signs: amplitudes with bit 0 == 0 contribute +1; bit 0 == 1 contribute -1
    n = 1 << n_qubits
    z0_signs = np.array([1.0 if ((i >> 0) & 1) == 0 else -1.0
                         for i in range(n)], dtype=np.float64)

    def expectation_z0(params: np.ndarray) -> float:
        bound = qc.assign_parameters({p: float(v) for p, v in zip(params_sym, params)})
        result = sim.run(bound).result()
        psi = np.asarray(result.get_statevector())
        probs = (psi.conj() * psi).real
        return float((probs * z0_signs).sum())

    rng = np.random.default_rng(seed)
    samples = rng.uniform(-np.pi, np.pi, (n_samples, P)).astype(np.float64)

    SHIFT = np.pi / 2
    t0 = time.perf_counter()
    first_param_grads = np.zeros(n_samples, dtype=np.float64)
    for i in range(n_samples):
        p_plus  = samples[i].copy();  p_plus[0]  += SHIFT
        p_minus = samples[i].copy();  p_minus[0] -= SHIFT
        first_param_grads[i] = 0.5 * (expectation_z0(p_plus) - expectation_z0(p_minus))
    elapsed = time.perf_counter() - t0

    return {
        "backend": "qiskit-aer",
        "n_qubits": n_qubits, "depth": depth, "n_samples": n_samples,
        "n_params": P,
        "variance": float(np.var(first_param_grads)),
        "mean_abs": float(np.mean(np.abs(first_param_grads))),
        "wall_time_s": elapsed,
    }


# --- Chart -------------------------------------------------------------------

def make_chart(rows: list[dict], out_path: Path, chip: str, depth_rule: str) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5), dpi=140)

    # group rows by backend
    bys = {"zilver-mlx": [], "qiskit-aer": []}
    for r in rows:
        bys[r["backend"]].append(r)
    for k in bys:
        bys[k].sort(key=lambda r: r["n_qubits"])

    # --- variance vs n_qubits (log y) -----------------------------------------
    for be, color, marker in [("zilver-mlx", "#0a84ff", "o"),
                              ("qiskit-aer",  "#ff453a", "s")]:
        rs = bys[be]
        xs = [r["n_qubits"] for r in rs]
        ys = [r["variance"] for r in rs]
        ax1.plot(xs, ys, marker=marker, color=color, lw=2.2, ms=9,
                 label=f"{be}  (measured)")
    # Theory reference: Var ~ 2^{-n} (normalized to first measured point)
    if bys["zilver-mlx"]:
        n0 = bys["zilver-mlx"][0]["n_qubits"]
        v0 = bys["zilver-mlx"][0]["variance"]
        ns = np.array([r["n_qubits"] for r in bys["zilver-mlx"]])
        theory = v0 * (2.0 ** (n0 - ns))
        ax1.plot(ns, theory, color="#888", lw=1.4, ls="--",
                 label=r"theory  $2^{-n}$  decay")
    ax1.set_yscale("log")
    ax1.set_xlabel("Qubits", fontsize=11)
    ax1.set_ylabel(r"Var$[\,\partial \langle Z_0\rangle / \partial\theta_0\,]$",
                   fontsize=11)
    ax1.set_title("Barren plateau scaling — gradient variance vs qubits",
                  fontsize=12, fontweight="bold")
    ax1.legend(loc="best", framealpha=0.95, fontsize=10)
    ax1.grid(True, alpha=0.25, which="both")

    # --- wall time vs n_qubits -----------------------------------------------
    for be, color, marker in [("zilver-mlx", "#0a84ff", "o"),
                              ("qiskit-aer",  "#ff453a", "s")]:
        rs = bys[be]
        xs = [r["n_qubits"]    for r in rs]
        ys = [r["wall_time_s"] for r in rs]
        ax2.plot(xs, ys, marker=marker, color=color, lw=2.2, ms=9, label=be)
    ax2.set_yscale("log")
    ax2.set_xlabel("Qubits", fontsize=11)
    ax2.set_ylabel("Wall time (s)", fontsize=11)
    ax2.set_title("Time to measure 50 random gradients", fontsize=12, fontweight="bold")
    ax2.legend(loc="best", framealpha=0.95, fontsize=10)
    ax2.grid(True, alpha=0.25, which="both")

    fig.suptitle(
        f"Barren-plateau experiment  ·  hardware-efficient ansatz · {depth_rule}  ·  {chip}",
        fontsize=13, fontweight="bold", y=1.02,
    )
    fig.text(0.99, 0.005,
             "zilver.dev — barren-plateau detection on your laptop",
             ha="right", fontsize=8, color="#666", style="italic")
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


# --- Main --------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--qubits-list", default="4,6,8,10")
    p.add_argument("--depth",       type=int, default=0,
                   help="0 = scale depth with qubits (depth = n_qubits) to "
                        "approach unitary 2-design; non-zero pins a fixed depth.")
    p.add_argument("--n-samples",   type=int, default=100)
    p.add_argument("--out-dir", default=None)
    args = p.parse_args()

    qs = [int(x) for x in args.qubits_list.split(",")]
    hw = hardware_summary()
    ts = time.strftime("%Y%m%d-%H%M%S")
    out_dir = Path(args.out_dir or f"benchmarks/results/{ts}")
    out_dir.mkdir(parents=True, exist_ok=True)

    print()
    print("=" * 78)
    print(f"  QML Demo C — Barren plateau sweep   {hw['chip']}  ({hw['memory_gb']} GB)")
    print("=" * 78)
    depth_rule = "depth = n_qubits" if args.depth == 0 else f"depth={args.depth}"
    print(f"  qubits in {qs}  ·  {depth_rule}  ·  {args.n_samples} samples per n")
    print()

    rows = []
    for n in qs:
        d = n if args.depth == 0 else args.depth
        print(f"  n={n:>2d} d={d:>2d}:  Zilver...", end="", flush=True)
        zil = variance_zilver(n, d, args.n_samples)
        print(f"  Var={zil['variance']:.3e}  t={zil['wall_time_s']:.2f}s", end="", flush=True)
        print("    Aer...", end="", flush=True)
        aer = variance_aer(n, d, args.n_samples)
        print(f"  Var={aer['variance']:.3e}  t={aer['wall_time_s']:.2f}s   speedup={aer['wall_time_s']/zil['wall_time_s']:.1f}×")
        rows.extend([zil, aer])
    print()

    body = {
        "bench_name": "qml_barren_plateau",
        "depth_rule": depth_rule,
        "n_samples": args.n_samples,
        "qubits": qs,
        "rows": rows,
        "hardware": hw,
    }
    attestor = Attestor()
    json_path = attestor.write(out_dir / "qml_plateau.json", body)
    print(f"  signed JSON  : {json_path}  [{attestor.algorithm}]")

    chart_path = out_dir / "qml_plateau.png"
    make_chart(rows, chart_path, hw["chip"], depth_rule)
    if chart_path.exists():
        print(f"  chart        : {chart_path}")
    print()


if __name__ == "__main__":
    main()
