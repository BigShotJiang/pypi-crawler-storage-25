"""Hardware-attested benchmark output.

Every bench result is signed with an Apple Silicon key:
  - Secure Enclave P-256 (ECDSA-SHA256) when available
  - Ed25519 fallback when SE is gated (e.g., unsigned Python interpreter)

The signed envelope binds: backend, qubits, wall time, peak RSS, hardware UUID,
and the SHA-256 of the result body. A verifier can detect any tampered field
without trusting the bench operator.
"""

from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import time
from pathlib import Path
from typing import Any

from zilver.security import (
    generate_node_keypair,
    se_available,
    se_generate_or_load,
    se_sign,
    sign_result,
)

SE_LABEL = "zilver.bench.v1"


def _detect_hardware_uuid() -> str:
    if platform.system() != "Darwin":
        return "non-darwin"
    try:
        out = subprocess.check_output(
            ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
            stderr=subprocess.DEVNULL, timeout=5,
        ).decode()
        for line in out.splitlines():
            if "IOPlatformUUID" in line:
                return line.split('"')[-2]
    except Exception:
        pass
    return "unknown"


def _detect_chip() -> str:
    try:
        return subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            stderr=subprocess.DEVNULL, timeout=5,
        ).decode().strip()
    except Exception:
        return "unknown"


def _detect_memory_gb() -> float:
    try:
        b = int(subprocess.check_output(
            ["sysctl", "-n", "hw.memsize"], stderr=subprocess.DEVNULL, timeout=5,
        ).decode().strip())
        return round(b / (1024 ** 3), 1)
    except Exception:
        return 0.0


class Attestor:
    """Holds a signing key and stamps benchmark results."""

    def __init__(self) -> None:
        self.hardware_uuid = _detect_hardware_uuid()
        self.chip = _detect_chip()
        self.memory_gb = _detect_memory_gb()
        self.algorithm: str
        self.pubkey_hex: str
        self._priv: bytes | None = None
        self._se_label: str | None = None

        # Try Secure Enclave first
        if se_available():
            try:
                pub = se_generate_or_load(SE_LABEL)
                # smoke-test signing capability (entitlements can gate SE on unsigned binaries)
                _ = se_sign(b"probe", SE_LABEL)
                self.algorithm = "secure-enclave-p256"
                self.pubkey_hex = pub.hex()
                self._se_label = SE_LABEL
                return
            except Exception:
                pass

        # Fallback: Ed25519
        priv, pub = generate_node_keypair()
        self.algorithm = "ed25519"
        self.pubkey_hex = pub.hex()
        self._priv = priv

    def attest(self, body: dict[str, Any]) -> dict[str, Any]:
        """Wrap a benchmark result body with a signed envelope."""
        canonical = json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
        digest = hashlib.sha256(canonical).hexdigest()
        signature = sign_result(digest, private_key_bytes=self._priv, se_label=self._se_label)
        return {
            "body": body,
            "attestation": {
                "algorithm": self.algorithm,
                "pubkey": self.pubkey_hex,
                "body_sha256": digest,
                "signature": signature,
                "hardware_uuid": self.hardware_uuid,
                "chip": self.chip,
                "memory_gb": self.memory_gb,
                "timestamp": time.time(),
                "zilver_version": _zilver_version(),
            },
        }

    def write(self, path: Path, body: dict[str, Any]) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        envelope = self.attest(body)
        path.write_text(json.dumps(envelope, indent=2))
        return path


def _zilver_version() -> str:
    try:
        import zilver
        return getattr(zilver, "__version__", "unknown")
    except Exception:
        return "unknown"


def hardware_summary() -> dict[str, Any]:
    return {
        "chip": _detect_chip(),
        "memory_gb": _detect_memory_gb(),
        "hardware_uuid": _detect_hardware_uuid(),
        "platform": platform.platform(),
        "se_available": se_available(),
    }
