#!/usr/bin/env python3
"""Wow #2 — Landscape in a Snap.

Compute a 2D VQE parameter landscape (R x R grid) on Qiskit Aer (per-tile loop,
the only thing Aer supports) and Zilver MLX (single vmap dispatch). Render both
panels side-by-side, with the wall-time gap as the headline.

The point: a research scientist scanning a parameter landscape on Aer waits
minutes per landscape. On Zilver, it materializes. Same Mac.

Output: benchmarks/results/<dir>/landscape_snap.{json,png}  (SE-signed JSON)
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from benchmarks._bench_attest import Attestor, hardware_summary


def _bench_zilver(n_qubits: int, depth: int, resolution: int) -> dict:
    import mlx.core as mx
    from zilver.circuit import hardware_efficient
    from zilver.landscape import LossLandscape

    circuit = hardware_efficient(n_qubits, depth)
    landscape = LossLandscape(circuit, sweep_params=(0, 1), resolution=resolution, seed=0)
    # warmup
    _ = landscape.compute()

    t0 = time.perf_counter()
    result = landscape.compute()
    elapsed = time.perf_counter() - t0
    return {
        "backend": "zilver-mlx",
        "wall_time_s": elapsed,
        "loss_landscape": result.loss_landscape,
        "resolution": resolution,
    }


def _bench_aer(n_qubits: int, depth: int, resolution: int) -> dict:
    from qiskit import QuantumCircuit
    from qiskit.circuit import Parameter
    from qiskit_aer import AerSimulator
    from qiskit.quantum_info import SparsePauliOp

    rng = np.random.default_rng(0)
    n_params = n_qubits * depth
    fixed = rng.uniform(-np.pi, np.pi, n_params).astype(np.float64)

    params = [Parameter(f"p{i}") for i in range(n_params)]
    qc = QuantumCircuit(n_qubits)
    pi = 0
    for _ in range(depth):
        for q in range(n_qubits):
            qc.ry(params[pi], q); pi += 1
        for q in range(n_qubits - 1):
            qc.cx(q, q + 1)
    qc.save_statevector()

    # Sum-Z observable
    obs_terms = [("I" * i + "Z" + "I" * (n_qubits - i - 1), 1.0) for i in range(n_qubits)]
    obs = SparsePauliOp.from_list(obs_terms)
    obs_mat = obs.to_matrix(sparse=False).astype(np.complex128)

    sim = AerSimulator(method="statevector")
    axis = np.linspace(-np.pi, np.pi, resolution)

    losses = np.zeros((resolution, resolution), dtype=np.float64)
    t0 = time.perf_counter()
    for i, a in enumerate(axis):
        for j, b in enumerate(axis):
            pvec = fixed.copy()
            pvec[0] = a
            pvec[1] = b
            bound = qc.assign_parameters({p: v for p, v in zip(params, pvec)})
            result = sim.run(bound).result()
            sv = np.asarray(result.get_statevector())
            losses[i, j] = float(np.real(sv.conj() @ obs_mat @ sv))
    elapsed = time.perf_counter() - t0
    return {
        "backend": "qiskit-aer",
        "wall_time_s": elapsed,
        "loss_landscape": losses.tolist(),
        "resolution": resolution,
    }


def make_chart(rows: dict, out_path: Path, chip: str, n_qubits: int, depth: int) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return

    aer = rows["aer"]
    zil = rows["zilver"]
    speedup = aer["wall_time_s"] / max(zil["wall_time_s"], 1e-9)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5.5), dpi=140)

    for ax, data, title, color in [
        (axes[0], np.array(aer["loss_landscape"]), f"Qiskit Aer\n{aer['wall_time_s']:.1f} s", "#ff453a"),
        (axes[1], np.array(zil["loss_landscape"]), f"Zilver MLX\n{zil['wall_time_s']:.2f} s", "#0a84ff"),
    ]:
        im = ax.imshow(data, extent=[-np.pi, np.pi, -np.pi, np.pi],
                       origin="lower", cmap="viridis", aspect="auto")
        ax.set_title(title, fontsize=14, fontweight="bold", color=color)
        ax.set_xlabel(r"$\theta_0$")
        ax.set_ylabel(r"$\theta_1$")
        fig.colorbar(im, ax=ax, shrink=0.85, label=r"$\langle \sum Z_i \rangle$")

    fig.suptitle(
        f"Landscape in a Snap — {n_qubits}q  depth={depth}  "
        f"{aer['resolution']}×{aer['resolution']} grid   "
        f"|   {speedup:.0f}× faster on {chip}",
        fontsize=13, fontweight="bold", y=1.02,
    )
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--qubits",     type=int, default=6)
    p.add_argument("--depth",      type=int, default=2)
    p.add_argument("--resolution", type=int, default=30)
    p.add_argument("--out-dir", default=None)
    args = p.parse_args()

    hw = hardware_summary()
    ts = time.strftime("%Y%m%d-%H%M%S")
    out_dir = Path(args.out_dir or f"benchmarks/results/{ts}")
    out_dir.mkdir(parents=True, exist_ok=True)

    print()
    print("=" * 72)
    print(f"  Wow #2 — Landscape in a Snap   {hw['chip']}  ({hw['memory_gb']} GB)")
    print("=" * 72)
    grid = args.resolution * args.resolution
    print(f"  {args.qubits}q  depth={args.depth}  grid={args.resolution}×{args.resolution} = {grid} evals")
    print()

    print(f"  [    qiskit-aer]  computing 2D landscape, tile-by-tile...", end="", flush=True)
    aer = _bench_aer(args.qubits, args.depth, args.resolution)
    print(f"  {aer['wall_time_s']:.2f}s")

    print(f"  [    zilver-mlx]  computing 2D landscape, single vmap dispatch...", end="", flush=True)
    zil = _bench_zilver(args.qubits, args.depth, args.resolution)
    print(f"  {zil['wall_time_s']:.3f}s")

    speedup = aer["wall_time_s"] / max(zil["wall_time_s"], 1e-9)
    print()
    print(f"  SPEEDUP: {speedup:.1f}×")
    print()

    body = {
        "bench_name": "landscape_snap",
        "n_qubits": args.qubits,
        "depth": args.depth,
        "resolution": args.resolution,
        "grid_evals": grid,
        "aer": {k: v for k, v in aer.items() if k != "loss_landscape"},
        "zilver": {k: v for k, v in zil.items() if k != "loss_landscape"},
        "speedup": speedup,
        "hardware": hw,
    }

    attestor = Attestor()
    json_path = attestor.write(out_dir / "landscape_snap.json", body)
    print(f"  signed JSON  : {json_path}  [{attestor.algorithm}]")

    chart_path = out_dir / "landscape_snap.png"
    make_chart({"aer": aer, "zilver": zil}, chart_path, hw["chip"], args.qubits, args.depth)
    if chart_path.exists():
        print(f"  chart        : {chart_path}")
    print()


if __name__ == "__main__":
    main()
