#!/usr/bin/env python3
"""2-qubit gate fidelity benchmark for Zilver's Metal kernels.

In quantum HARDWARE, 2q gate fidelity measures how close the physical gate
is to its ideal mathematical unitary (decoherence + control imperfections).
In SIMULATION, fidelity measures numerical precision — how well the
implementation realises the math, given finite floating-point arithmetic.

Three metrics:

1. **Process fidelity vs ideal U**:
       F_process = |Tr(U_ideal^† U_sim)|^2 / d^2     (d = 4 for 2-qubit gate)

   Built by applying the simulated gate to each of the 4 computational
   basis states (forming the columns of U_sim), then comparing to the
   exact mathematical matrix.

2. **State fidelity vs Aer (complex128)**:
       F_state = |⟨ψ_zilver | ψ_aer⟩|^2

   The "real" reference: Aer in double-precision is essentially exact
   for our purposes (~15-16 digits).

3. **Throughput (gates / sec)**:
   How many 2q gates per second can the implementation apply at qubit n.
   The universal yardstick that hardware folks quote (IBM Heron ≈ 25k 2q
   gates/sec on 156q; IonQ Aria ≈ 25 gates/sec via QPU shots).
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np
import mlx.core as mx

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def cnot_ideal() -> np.ndarray:
    return np.array([[1, 0, 0, 0],
                     [0, 1, 0, 0],
                     [0, 0, 0, 1],
                     [0, 0, 1, 0]], dtype=np.complex128)


def cz_ideal() -> np.ndarray:
    return np.diag([1, 1, 1, -1]).astype(np.complex128)


def rzz_ideal(theta: float) -> np.ndarray:
    p_neg = np.exp(-1j * theta * 0.5)
    p_pos = np.exp( 1j * theta * 0.5)
    return np.diag([p_neg, p_pos, p_pos, p_neg]).astype(np.complex128)


# ---------------------------------------------------------------------------
# Build U_sim for each gate by applying it to the 4 basis states
# ---------------------------------------------------------------------------

def build_u_sim_metal(gate_name: str, theta: float, qa: int, qb: int, n: int) -> np.ndarray:
    """Apply the simulated 2q gate on (qa, qb) of an n-qubit system, then
    extract the 4×4 unitary by inspecting the (qa, qb)-subspace of the
    resulting statevectors when we start from each of the 4 basis states."""
    from zilver import metal
    pa = n - 1 - qa
    pb = n - 1 - qb
    mask_a = 1 << pa
    mask_b = 1 << pb

    # 4 basis indices in the (qa, qb) subspace with all other qubits set to 0
    basis = [0,        mask_b,       mask_a,       mask_a | mask_b]
    # The full input statevector is |basis[i]⟩; output is U_sim e_i.
    # Stack the resulting 4 columns into U_sim.
    U_sim = np.zeros((4, 4), dtype=np.complex128)

    # Build a "circuit" of just the one gate via mx-level kernels for accuracy
    # (no other gates introduce error).
    for col, idx in enumerate(basis):
        init = np.zeros(2 * (1 << n), dtype=np.float32)
        init[2 * idx] = 1.0   # real part of amplitude `idx`
        state = mx.array(init)

        if gate_name == "cnot":
            state = metal.apply_cnot(state, qa, qb, n)
        elif gate_name == "cz":
            state = metal.apply_cz(state, qa, qb, n)
        elif gate_name == "rzz":
            state = metal.apply_rzz(state, theta, qa, qb, n)
        else:
            raise ValueError(gate_name)
        mx.eval(state)
        sv = metal._real_to_complex(state)
        for row, idx_out in enumerate(basis):
            U_sim[row, col] = sv[idx_out]
    return U_sim


def build_u_sim_accel(gate_name: str, theta: float, qa: int, qb: int, n: int) -> np.ndarray:
    """Build U_sim from the accel CPU path at complex128 precision."""
    from zilver.circuit import Circuit
    from zilver.accel import run_circuit_strided

    # Build a minimal circuit with just the target 2q gate
    c = Circuit(n)
    if gate_name == "cnot":
        c.cnot(qa, qb)
    elif gate_name == "cz":
        c.cz(qa, qb)
    elif gate_name == "rzz":
        c.rzz(qa, qb, 0)   # param_idx=0
    else:
        raise ValueError(gate_name)

    pa = n - 1 - qa
    pb = n - 1 - qb
    mask_a = 1 << pa
    mask_b = 1 << pb
    basis = [0, mask_b, mask_a, mask_a | mask_b]
    U_sim = np.zeros((4, 4), dtype=np.complex128)

    # The strided path always starts from |0…0⟩. To get U_sim's columns we
    # need to start from each of the 4 basis states. We pre-apply an X gate
    # to the relevant qubit(s) by manually constructing the initial state.
    from zilver.accel import _gate_matrix_np, _apply_1q_numpy_strided, _apply_2q_numpy_strided

    params = np.array([theta], dtype=np.float64) if gate_name == "rzz" else np.array([], dtype=np.float64)

    for col, idx in enumerate(basis):
        state = np.zeros(1 << n, dtype=np.complex128)
        state[idx] = 1.0
        for op in c._ops:
            M = _gate_matrix_np(op, params, dtype=np.complex128)
            if len(op.qubits) == 1:
                state = _apply_1q_numpy_strided(state, M, op.qubits[0], n)
            elif len(op.qubits) == 2:
                state = _apply_2q_numpy_strided(state, M, op.qubits[0], op.qubits[1], n)
        for row, idx_out in enumerate(basis):
            U_sim[row, col] = state[idx_out]
    return U_sim


def build_u_sim_aer(gate_name: str, theta: float, qa: int, qb: int, n: int) -> np.ndarray:
    """Build U_sim from Aer.

    Aer uses Qiskit's little-endian convention: qubit q is bit q (LSB-first),
    not bit (n-1-q) like zilver. So our 'qa=0, qb=1' basis states in Qiskit
    indexing live at bits (0, 1):  basis indices = [0, 2, 1, 3] for (qa, qb)
    in the order (00, 01, 10, 11).
    """
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator

    mask_a_q = 1 << qa   # Qiskit bit position for qubit qa
    mask_b_q = 1 << qb
    basis = [0,
             mask_b_q,                  # (qa=0, qb=1)
             mask_a_q,                  # (qa=1, qb=0)
             mask_a_q | mask_b_q]       # (qa=1, qb=1)

    U_sim = np.zeros((4, 4), dtype=np.complex128)
    sim = AerSimulator(method="statevector", precision="double")
    for col, idx in enumerate(basis):
        qc = QuantumCircuit(n)
        # Set basis state: bit q of idx ⇒ apply X on qubit q (Qiskit endianness)
        for q in range(n):
            if (idx >> q) & 1:
                qc.x(q)
        if gate_name == "cnot":
            qc.cx(qa, qb)
        elif gate_name == "cz":
            qc.cz(qa, qb)
        elif gate_name == "rzz":
            qc.rzz(theta, qa, qb)
        qc.save_statevector()
        result = sim.run(qc).result()
        sv = np.asarray(result.get_statevector())
        for row, idx_out in enumerate(basis):
            U_sim[row, col] = sv[idx_out]
    return U_sim


def process_fidelity(U_sim: np.ndarray, U_ideal: np.ndarray) -> float:
    """F = |Tr(U_ideal^† U_sim)|² / d²"""
    d = U_ideal.shape[0]
    overlap = np.trace(U_ideal.conj().T @ U_sim)
    return float(np.abs(overlap) ** 2 / (d * d))


# ---------------------------------------------------------------------------
# Throughput: gates per second
# ---------------------------------------------------------------------------

def throughput(n: int, depth: int) -> dict:
    """Measure how many 2q gates per second each backend can apply.
    Circuit: a linear-chain CNOT ladder, total depth*n−1 CNOTs."""
    from zilver.circuit import Circuit
    from zilver import metal

    # Build a circuit with only CNOTs to isolate 2q-gate cost
    n_gates = depth * (n - 1)
    c = Circuit(n)
    for layer in range(depth):
        for q in range(n - 1):
            c.cnot(q, q + 1)

    params = np.array([], dtype=np.float32)

    # Metal
    for _ in range(3): _ = metal.run_circuit(c, params, compile=True)
    ts_metal = []
    for _ in range(4):
        t0 = time.perf_counter()
        _ = metal.run_circuit(c, params, compile=True)
        ts_metal.append(time.perf_counter() - t0)
    metal_gps = n_gates / min(ts_metal)

    # Aer
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator
    qc = QuantumCircuit(n)
    for _ in range(depth):
        for q in range(n - 1):
            qc.cx(q, q + 1)
    qc.save_statevector()
    sim = AerSimulator(method="statevector")
    _ = sim.run(qc).result().get_statevector()
    ts_aer = []
    for _ in range(4):
        t0 = time.perf_counter()
        _ = sim.run(qc).result().get_statevector()
        ts_aer.append(time.perf_counter() - t0)
    aer_gps = n_gates / min(ts_aer)

    return {
        "n_qubits": n, "n_gates": n_gates,
        "metal_gates_per_sec": metal_gps,
        "aer_gates_per_sec": aer_gps,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=6,
                   help="Spectator qubit count for fidelity measurement (default 6)")
    p.add_argument("--throughput-n", default="12,16,20",
                   help="Qubit counts for the gates/sec throughput sweep")
    args = p.parse_args()

    print()
    print("=" * 80)
    print("  Zilver 2-qubit gate fidelity & throughput")
    print("=" * 80)

    # --- Process fidelity vs ideal (Metal complex64 / Accel complex128 / Aer)
    print()
    print(f"Process fidelity vs ideal unitary (n_spec={args.n}, qa=0, qb=1):")
    print(f"  {'gate':>8}  {'metal (cx64)':>14}  {'accel (cx128)':>14}  "
          f"{'aer (cx128)':>14}  {'1-F_metal':>14}  {'1-F_accel':>14}  {'1-F_aer':>14}")
    print(f"  {'-'*8}  {'-'*14}  {'-'*14}  {'-'*14}  "
          f"{'-'*14}  {'-'*14}  {'-'*14}")

    cases = [("cnot", 0.0, cnot_ideal()),
             ("cz",   0.0, cz_ideal()),
             ("rzz",  0.7853981634, rzz_ideal(0.7853981634))]  # theta = pi/4
    for name, theta, U_ideal in cases:
        U_metal = build_u_sim_metal(name, theta, 0, 1, args.n)
        U_accel = build_u_sim_accel(name, theta, 0, 1, args.n)
        U_aer   = build_u_sim_aer  (name, theta, 0, 1, args.n)
        F_metal = process_fidelity(U_metal, U_ideal)
        F_accel = process_fidelity(U_accel, U_ideal)
        F_aer   = process_fidelity(U_aer,   U_ideal)
        print(f"  {name:>8}  {F_metal:>14.12f}  {F_accel:>14.12f}  {F_aer:>14.12f}  "
              f"{1 - F_metal:>14.2e}  {1 - F_accel:>14.2e}  {1 - F_aer:>14.2e}")

    # --- 2q-gate throughput across qubit counts -----------------------------
    print()
    print("2q-gate throughput (CNOT chain, depth=4):")
    print(f"  {'n':>3}  {'gates/sec (metal)':>20}  {'gates/sec (aer)':>20}  {'ratio':>8}")
    print(f"  {'-'*3}  {'-'*20}  {'-'*20}  {'-'*8}")
    for n in [int(x) for x in args.throughput_n.split(",")]:
        r = throughput(n, depth=4)
        ratio = r["metal_gates_per_sec"] / r["aer_gates_per_sec"]
        print(f"  {n:>3}  {r['metal_gates_per_sec']:>20,.0f}  "
              f"{r['aer_gates_per_sec']:>20,.0f}  {ratio:>7.2f}×")

    print()
    print("Reference points (peak 2q gate throughput, hardware vs simulation):")
    print(f"  - IBM Heron r3 (156q chip)         : ~25,000 CNOTs/sec  [QPU]")
    print(f"  - IonQ Aria (32q QPU)              : ~25 gates/sec       [QPU]")
    print(f"  - cuQuantum A100 (≤30q sim)        : ~500,000 gates/sec  [GPU sim]")
    print()


if __name__ == "__main__":
    main()
