"""Security helpers: API keys, TLS certificates, macOS Keychain, node identity."""

from __future__ import annotations

import json
import secrets
import subprocess
from pathlib import Path


def generate_api_key() -> str:
    """Return a 32-byte random hex string suitable for use as an API key."""
    return secrets.token_hex(32)


def derive_node_id(public_key_bytes: bytes) -> str:
    """
    Derive a deterministic node_id from an Ed25519 public key.

    Takes the first 16 bytes of SHA-256(pubkey) and formats them as an
    uppercase UUID-style string, e.g. ``"D1AFC9E2-B46A-53BF-9C38-190C9135FDA0"``.

    This makes node_id cryptographically bound to the keypair — it cannot be
    self-reported or spoofed without controlling the private key.
    """
    import hashlib
    h = hashlib.sha256(public_key_bytes).hexdigest()[:32]
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}".upper()


def generate_node_keypair() -> tuple[bytes, bytes]:
    """
    Generate a fresh Ed25519 keypair for node identity.

    Returns
    -------
    tuple[bytes, bytes]
        ``(private_key_bytes, public_key_bytes)`` — raw 32-byte values.
        Store private key in Keychain; share public key during registration.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    private_key   = Ed25519PrivateKey.generate()
    private_bytes = private_key.private_bytes_raw()
    public_bytes  = private_key.public_key().public_bytes_raw()
    return private_bytes, public_bytes


def sign_registration(private_key_bytes: bytes, payload: dict) -> str:
    """
    Sign a registration payload with an Ed25519 private key.

    The payload is serialised as deterministic JSON (sorted keys, no spaces)
    and signed. Returns the signature as a hex string.

    Parameters
    ----------
    private_key_bytes:
        Raw 32-byte Ed25519 private key.
    payload:
        Registration dict — everything except the ``"signature"`` field.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    private_key = Ed25519PrivateKey.from_private_bytes(private_key_bytes)
    message = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return private_key.sign(message).hex()


def verify_registration_signature(
    public_key_hex: str,
    payload: dict,
    signature_hex: str,
) -> bool:
    """
    Verify an Ed25519 registration signature.

    Parameters
    ----------
    public_key_hex:
        Hex-encoded 32-byte Ed25519 public key.
    payload:
        Registration dict — everything except the ``"signature"`` field.
    signature_hex:
        Hex-encoded 64-byte Ed25519 signature.

    Returns
    -------
    bool
        ``True`` if the signature is valid, ``False`` otherwise.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature
    try:
        public_key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key_hex))
        message    = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        public_key.verify(bytes.fromhex(signature_hex), message)
        return True
    except Exception:
        # Fail closed — any parse error or invalid signature returns False
        return False


def generate_self_signed_cert(path: Path) -> tuple[Path, Path]:
    """
    Generate a self-signed TLS certificate and private key.

    Writes ``node.key`` (RSA-2048 private key, PEM) and ``node.crt``
    (self-signed X.509 cert, PEM) into *path*, creating the directory
    if it does not exist.  The certificate is valid for 365 days.

    Parameters
    ----------
    path:
        Directory to write the key and cert files into.

    Returns
    -------
    tuple[Path, Path]
        ``(key_path, cert_path)``
    """
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    import datetime

    path.mkdir(parents=True, exist_ok=True)
    key_path = path / "node.key"
    crt_path = path / "node.crt"

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, "zilver-node"),
    ])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
        .not_valid_after(
            datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=365)
        )
        .sign(key, hashes.SHA256())
    )

    key_path.write_bytes(key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    ))
    key_path.chmod(0o600)  # private key must not be world-readable
    crt_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))

    return key_path, crt_path


def keychain_store(service: str, account: str, password: str) -> None:
    """
    Store a password in the macOS Keychain.

    Uses the ``security add-generic-password -U`` command, which updates
    the entry if it already exists.

    Parameters
    ----------
    service:
        Keychain service name (e.g. ``"zilver"``).
    account:
        Keychain account name (e.g. node_id).
    password:
        Secret value to store.

    Raises
    ------
    subprocess.CalledProcessError
        If the ``security`` command fails (macOS only).
    """
    subprocess.run(
        [
            "security", "add-generic-password",
            "-U",
            "-s", service,
            "-a", account,
            "-w", password,
        ],
        check=True,
        stderr=subprocess.DEVNULL,
    )


SE_LABEL = "com.siriusquantum.zilver.node"


def se_available() -> bool:
    """True on Apple Silicon Mac (arm64, macOS 13+) with pyobjc Security framework installed."""
    import platform
    if platform.system() != "Darwin":
        return False
    try:
        chip = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"], stderr=subprocess.DEVNULL
        )
        if b"Apple" not in chip:
            return False
    except Exception:
        return False
    try:
        import Security  # noqa: F401
        return True
    except ImportError:
        return False


def se_get_public_key(label: str = SE_LABEL) -> bytes | None:
    """Retrieve SE public key (65-byte uncompressed P-256) from Keychain. None if not found."""
    try:
        from Security import (  # type: ignore[import]
            SecItemCopyMatching, SecKeyCopyPublicKey, SecKeyCopyExternalRepresentation,
            kSecClass, kSecClassKey, kSecAttrKeyClass, kSecAttrKeyClassPrivate,
            kSecAttrLabel, kSecReturnRef, kSecMatchLimit, kSecMatchLimitOne,
        )
        query = {
            kSecClass: kSecClassKey,
            kSecAttrKeyClass: kSecAttrKeyClassPrivate,
            kSecAttrLabel: label,
            kSecReturnRef: True,
            kSecMatchLimit: kSecMatchLimitOne,
        }
        status, key_ref = SecItemCopyMatching(query, None)
        if status != 0 or key_ref is None:
            return None
        pub_key = SecKeyCopyPublicKey(key_ref)
        pub_data, _ = SecKeyCopyExternalRepresentation(pub_key, None)
        return bytes(pub_data) if pub_data else None
    except Exception:
        return None


def se_generate_or_load(label: str = SE_LABEL) -> bytes:
    """
    Generate a P-256 key in the Secure Enclave (or return existing).
    The private key is hardware-bound and never leaves the device.
    Returns the 65-byte uncompressed public key (04 || x || y).
    """
    existing = se_get_public_key(label)
    if existing:
        return existing
    from Security import (  # type: ignore[import]
        SecKeyCreateRandomKey, SecKeyCopyPublicKey, SecKeyCopyExternalRepresentation,
        kSecAttrKeyTypeEC, kSecAttrTokenIDSecureEnclave, kSecAttrIsPermanent,
        kSecAttrLabel, kSecAttrKeyType, kSecAttrTokenID, kSecAttrKeySizeInBits,
        kSecPrivateKeyAttrs, kSecPublicKeyAttrs,
    )
    attrs = {
        kSecAttrKeyType: kSecAttrKeyTypeEC,
        kSecAttrKeySizeInBits: 256,
        kSecAttrTokenID: kSecAttrTokenIDSecureEnclave,
        kSecPrivateKeyAttrs: {kSecAttrIsPermanent: True, kSecAttrLabel: label},
        kSecPublicKeyAttrs: {},
    }
    private_key, error = SecKeyCreateRandomKey(attrs, None)
    if error:
        raise RuntimeError(f"Secure Enclave key generation failed: {error}")
    pub_key  = SecKeyCopyPublicKey(private_key)
    pub_data, _ = SecKeyCopyExternalRepresentation(pub_key, None)
    return bytes(pub_data)


def se_sign(message: bytes, label: str = SE_LABEL) -> bytes:
    """Sign message with SE P-256 key (ECDSA-SHA256). Returns DER-encoded signature."""
    from Security import (  # type: ignore[import]
        SecItemCopyMatching, SecKeyCreateSignature,
        kSecClass, kSecClassKey, kSecAttrKeyClass, kSecAttrKeyClassPrivate,
        kSecAttrLabel, kSecReturnRef, kSecMatchLimit, kSecMatchLimitOne,
        kSecKeyAlgorithmECDSASignatureMessageX962SHA256,
    )
    import Foundation  # type: ignore[import]
    query = {
        kSecClass: kSecClassKey,
        kSecAttrKeyClass: kSecAttrKeyClassPrivate,
        kSecAttrLabel: label,
        kSecReturnRef: True,
        kSecMatchLimit: kSecMatchLimitOne,
    }
    status, key_ref = SecItemCopyMatching(query, None)
    if status != 0 or key_ref is None:
        raise RuntimeError("SE key not found in Keychain")
    ns_data = Foundation.NSData.dataWithBytes_length_(message, len(message))
    sig_data, error = SecKeyCreateSignature(
        key_ref, kSecKeyAlgorithmECDSASignatureMessageX962SHA256, ns_data, None
    )
    if error:
        raise RuntimeError(f"SE signing failed: {error}")
    return bytes(sig_data)


def se_sign_registration(label: str, payload: dict) -> str:
    """Sign a registration payload with the SE key. Returns hex DER ECDSA signature."""
    message = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return se_sign(message, label).hex()


def verify_se_signature(public_key_hex: str, payload: dict, signature_hex: str) -> bool:
    """
    Verify a P-256 ECDSA-SHA256 DER signature from an SE key.

    Parameters
    ----------
    public_key_hex:
        130-char hex (65-byte uncompressed P-256 point: 04 || x || y).
    payload:
        Registration dict — everything except the ``"signature"`` field.
    signature_hex:
        Hex-encoded DER-encoded ECDSA signature.
    """
    from cryptography.hazmat.primitives.asymmetric.ec import (
        ECDSA, EllipticCurvePublicNumbers, SECP256R1,
    )
    from cryptography.hazmat.primitives.hashes import SHA256
    from cryptography.hazmat.backends import default_backend
    try:
        pub_bytes = bytes.fromhex(public_key_hex)
        if pub_bytes[0] != 0x04 or len(pub_bytes) != 65:
            return False
        x = int.from_bytes(pub_bytes[1:33], "big")
        y = int.from_bytes(pub_bytes[33:65], "big")
        pub_key = EllipticCurvePublicNumbers(x, y, SECP256R1()).public_key(default_backend())
        message = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        pub_key.verify(bytes.fromhex(signature_hex), message, ECDSA(SHA256()))
        return True
    except Exception:
        return False


def sign_result(
    proof: str,
    private_key_bytes: bytes | None = None,
    se_label: str | None = None,
) -> str:
    """Sign a job result proof with the node's key.

    Uses the Secure Enclave key (P-256 ECDSA-SHA256) when *se_label* is given,
    otherwise uses an Ed25519 *private_key_bytes*.  Returns the hex-encoded
    signature, or an empty string if neither key is available or signing fails.

    Parameters
    ----------
    proof:
        Hex string to sign (SHA-256 digest from :func:`~zilver.node_types._compute_proof`).
    private_key_bytes:
        Raw 32-byte Ed25519 private key.  Ignored when *se_label* is set.
    se_label:
        Secure Enclave key label (macOS only).  Takes priority over
        *private_key_bytes* if both are provided.
    """
    message = proof.encode()
    try:
        if se_label is not None:
            return se_sign(message, se_label).hex()
        if private_key_bytes is not None:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
            private_key = Ed25519PrivateKey.from_private_bytes(private_key_bytes)
            return private_key.sign(message).hex()
    except Exception:
        pass
    return ""


def keychain_get(service: str, account: str) -> str | None:
    """
    Retrieve a password from the macOS Keychain.

    Parameters
    ----------
    service:
        Keychain service name.
    account:
        Keychain account name.

    Returns
    -------
    str | None
        The stored password, or ``None`` if not found.
    """
    try:
        out = subprocess.check_output(
            [
                "security", "find-generic-password",
                "-s", service,
                "-a", account,
                "-w",
            ],
            stderr=subprocess.DEVNULL,
        )
        return out.decode().strip()
    except subprocess.CalledProcessError:
        return None
