"""Distributed batch dispatch — confidential, never push."""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    from .client import NetworkCoordinator

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Checkpoint helpers
# ---------------------------------------------------------------------------

def _load_ckpt(path: Path) -> dict[str, list[float]]:
    if path.exists():
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save_ckpt(path: Path, key: str, values: list[float], lock: threading.Lock) -> None:
    with lock:
        data = _load_ckpt(path)
        data[key] = values
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data))
        os.replace(tmp, path)


# ---------------------------------------------------------------------------
# Node selection
# ---------------------------------------------------------------------------

def _eligible(
    registry,
    backend:  str,
    n_qubits: int,
    exclude:  set[str],
) -> list[dict]:
    return [
        n for n in registry.nodes()
        if n.get("node_id") not in exclude
        and backend in n.get("backends", [])
        and n.get(f"{backend}_qubits_max", 0) >= n_qubits
    ]


# ---------------------------------------------------------------------------
# Main entry point — called from NetworkCoordinator.submit_batch
# ---------------------------------------------------------------------------

def submit_batch(
    coord:           "NetworkCoordinator",
    circuit:         Any,
    params_batch:    Any,
    backend:         str,
    observable:      str,
    checkpoint_path: str | Path | None,
    max_retries:     int,
    max_workers:     int,
):
    from .node import job_from_circuit
    from .batch_distributor import _split_indices, BatchResult, BatchSlice
    from .client import NodeClient

    if hasattr(params_batch, "ndim") and params_batch.ndim == 1:
        params_batch = params_batch[None, :]

    n_evals  = params_batch.shape[0]
    n_qubits = circuit.n_qubits

    ckpt_file    = Path(checkpoint_path) if checkpoint_path else None
    ckpt_lock    = threading.Lock()
    failed_nodes: set[str] = set()
    nodes_lock   = threading.Lock()

    def _dispatch(node_info: dict, start: int, end: int) -> BatchSlice:
        current = node_info
        ts      = time.perf_counter()

        for attempt in range(max_retries):
            nid     = current.get("node_id", "unknown")
            url     = current.get("url", "")
            api_key = current.get("node_execute_key") or coord.api_key

            try:
                expectations: list[float] = []
                with NodeClient(url, timeout=coord.timeout, api_key=api_key) as nc:
                    for i in range(start, end):
                        job    = job_from_circuit(circuit, params_batch[i],
                                                  observable=observable, backend=backend)
                        result = nc.execute(job)
                        expectations.append(result.expectation)

                return BatchSlice(
                    node_id=nid, start=start, end=end,
                    expectations=expectations,
                    elapsed_ms=(time.perf_counter() - ts) * 1000.0,
                )

            except (httpx.ConnectError, httpx.TimeoutException,
                    httpx.HTTPStatusError) as exc:
                _log.warning("slice [%d:%d] attempt %d failed on %s: %s",
                             start, end, attempt + 1, nid, exc)
                with nodes_lock:
                    failed_nodes.add(nid)

                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                    nxt = _eligible(coord._registry, backend, n_qubits, failed_nodes)
                    if not nxt:
                        raise RuntimeError(
                            f"No replacement node for slice [{start}:{end}] "
                            f"after {attempt + 1} failure(s)"
                        ) from exc
                    current = nxt[0]
                else:
                    raise RuntimeError(
                        f"Slice [{start}:{end}] exhausted {max_retries} retries"
                    ) from exc

        raise RuntimeError(f"Slice [{start}:{end}]: unreachable")  # pragma: no cover

    # -----------------------------------------------------------------------
    # Orchestrate
    # -----------------------------------------------------------------------
    nodes = _eligible(coord._registry, backend, n_qubits, set())
    if not nodes:
        raise RuntimeError(
            f"No eligible node for backend={backend!r} n_qubits={n_qubits}"
        )

    index_slices = _split_indices(n_evals, len(nodes))
    checkpoint   = _load_ckpt(ckpt_file) if ckpt_file else {}

    t0               = time.perf_counter()
    all_expectations: list[float] = [0.0] * n_evals
    result_slices:    list[BatchSlice] = []
    futures: dict[Any, tuple[int, int]] = {}

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        for node_info, (start, end) in zip(nodes, index_slices):
            if start == end:
                continue

            ck = f"{start}-{end}"
            if ck in checkpoint:
                cached = checkpoint[ck]
                for i, val in enumerate(cached):
                    all_expectations[start + i] = val
                result_slices.append(BatchSlice(
                    node_id=node_info.get("node_id", "cached"),
                    start=start, end=end,
                    expectations=cached, elapsed_ms=0.0,
                ))
                continue

            futures[pool.submit(_dispatch, node_info, start, end)] = (start, end)

        for future in as_completed(futures):
            start, end = futures[future]
            sl = future.result()
            for i, val in enumerate(sl.expectations):
                all_expectations[start + i] = val
            result_slices.append(sl)
            if ckpt_file:
                _save_ckpt(ckpt_file, f"{start}-{end}", sl.expectations, ckpt_lock)

    return BatchResult(
        expectations=all_expectations,
        n_evals=n_evals,
        n_nodes_used=len({sl.node_id for sl in result_slices}),
        slices=result_slices,
        elapsed_ms=(time.perf_counter() - t0) * 1000.0,
    )
