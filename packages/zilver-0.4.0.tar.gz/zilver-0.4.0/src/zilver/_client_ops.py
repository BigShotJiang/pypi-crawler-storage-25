"""Client-side signing operations (internal)."""
from __future__ import annotations

from datetime import datetime, timezone


def sign_registration_body(
    body: dict,
    node_url: str,
    private_key_bytes: bytes | None,
    public_key_bytes: bytes | None,
    se_label: str | None,
) -> None:
    """Add signature fields to a registration body dict in place."""
    if public_key_bytes is None:
        return

    pubkey_hex    = public_key_bytes.hex()
    timestamp_str = datetime.now(tz=timezone.utc).isoformat()
    signed_payload = {
        "caps":      body["caps"],
        "url":       node_url,
        "pubkey":    pubkey_hex,
        "timestamp": timestamp_str,
    }
    body["pubkey"]    = pubkey_hex
    body["timestamp"] = timestamp_str

    if se_label is not None:
        from .security import se_sign_registration
        body["signature"] = se_sign_registration(se_label, signed_payload)
    elif private_key_bytes is not None:
        from .security import sign_registration
        body["signature"] = sign_registration(private_key_bytes, signed_payload)
