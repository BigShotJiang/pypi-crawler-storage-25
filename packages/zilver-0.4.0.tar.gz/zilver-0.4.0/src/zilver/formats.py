"""Circuit format converters → native ops list.

Each converter returns ``(ops, n_qubits)`` where *ops* is a list of gate
dicts compatible with SimJob.circuit_ops and *n_qubits* is the qubit count
inferred from the source format.
"""

from __future__ import annotations

import re


# ---------------------------------------------------------------------------
# QASM 2.0
# ---------------------------------------------------------------------------

def from_qasm2(qasm_str: str) -> tuple[list[dict], int]:
    """Convert a QASM 2.0 string to ``(ops, n_qubits)``."""
    from .qasm_bridge import circuit_from_qasm

    circuit = circuit_from_qasm(qasm_str)
    ops: list[dict] = []
    for op in circuit._ops:
        if not op.kind:
            continue
        ops.append({
            "type":          op.kind,
            "qubits":        op.qubits,
            "param_indices": op.param_indices,
        })
    return ops, circuit.n_qubits


# ---------------------------------------------------------------------------
# OpenQASM 3.0
# ---------------------------------------------------------------------------

def from_qasm3(qasm_str: str) -> tuple[list[dict], int]:
    """OpenQASM 3 → ``(ops, n_qubits)``.

    Converts qubit declarations to QASM 2 syntax, strips OpenQASM 3-specific
    constructs (classical bits, barriers, ``#pragma`` annotations), then
    delegates to the QASM 2 parser.
    """
    converted: list[str] = []
    n_qubits = 0

    for line in qasm_str.splitlines():
        stripped = line.strip()

        # Version header
        if re.match(r"OPENQASM\s+3", stripped):
            converted.append("OPENQASM 2.0;")
            continue

        # qubit[n] name  →  qreg name[n];
        m = re.match(r"qubit\[(\d+)\]\s+(\w+)", stripped)
        if m:
            count = int(m.group(1))
            n_qubits += count
            converted.append(f"qreg {m.group(2)}[{count}];")
            continue

        # qubit name  →  qreg name[1];
        m = re.match(r"qubit\s+(\w+)", stripped)
        if m:
            n_qubits += 1
            converted.append(f"qreg {m.group(1)}[1];")
            continue

        # Keep QASM 2-style qreg declarations
        m = re.match(r"qreg\s+\w+\[(\d+)\]", stripped)
        if m:
            n_qubits = max(n_qubits, int(m.group(1)))
            converted.append(line)
            continue

        # Skip classical bits, pragmas, boxes, barriers
        if (
            stripped.startswith("#pragma")
            or stripped.startswith("bit ")
            or stripped.startswith("creg ")
            or re.match(r"\w+\s*=\s*measure", stripped)
            or stripped == "box{"
            or stripped == "}"
            or stripped.startswith("include ")
        ):
            continue

        converted.append(line)

    return from_qasm2("\n".join(converted))


# ---------------------------------------------------------------------------
# Qiskit
# ---------------------------------------------------------------------------

_QISKIT_FIXED_MAP: dict[str, str] = {
    "h": "h", "x": "x", "y": "y", "z": "z",
    "s": "h",   # approximate — only needed if kind field absent
    "cx": "cnot", "cnot": "cnot",
    "cz": "cz",
    "swap": "cnot",  # not exact but keeps things moving
    "id": "h",       # identity gate — skip
}

_QISKIT_PARAM_MAP: dict[str, str] = {
    "rx": "rx", "ry": "ry", "rz": "rz",
    "p": "rz",    # phase gate ≈ rz up to global phase
    "u1": "rz",
    "u2": "ry",
    "u3": "ry",   # approximation for simple cases
}


def from_qiskit(circuit_dict: dict) -> tuple[list[dict], int]:
    """Qiskit JSON circuit dict → ``(ops, n_qubits)``.

    Accepts dicts with a ``"qasm"`` key (Qiskit QASM 2 export) or an
    ``"instructions"`` list.  Gate name aliases: cx→cnot, p→rz, id→skip.
    """
    # Prefer QASM export if present
    if "qasm" in circuit_dict:
        qasm = circuit_dict["qasm"]
        # Map Qiskit-specific names before parsing
        qasm = re.sub(r'\bp\b(?=\()', 'rz', qasm)
        qasm = re.sub(r'\bcp\b(?=\()', 'crz', qasm)
        return from_qasm2(qasm)

    n_qubits: int = circuit_dict.get("num_qubits", 0)
    if n_qubits == 0:
        raise ValueError(
            "Qiskit circuit dict must have a 'qasm' key or 'num_qubits' field"
        )

    ops: list[dict] = []
    param_counter = 0

    for inst in circuit_dict.get("instructions", []):
        name   = inst.get("name", "").lower()
        qubits = inst.get("qubits", [])

        if name in _QISKIT_FIXED_MAP:
            if name == "id":
                continue  # identity — no-op
            ops.append({
                "type": _QISKIT_FIXED_MAP[name],
                "qubits": qubits,
                "param_indices": [],
            })
        elif name in _QISKIT_PARAM_MAP:
            ops.append({
                "type": _QISKIT_PARAM_MAP[name],
                "qubits": qubits,
                "param_indices": [param_counter],
            })
            param_counter += 1

    return ops, n_qubits


# ---------------------------------------------------------------------------
# PennyLane
# ---------------------------------------------------------------------------

_PL_FIXED_MAP: dict[str, str] = {
    "Hadamard": "h", "H": "h",
    "PauliX": "x", "X": "x",
    "PauliY": "y", "Y": "y",
    "PauliZ": "z", "Z": "z",
    "CNOT": "cnot",
    "CZ": "cz",
}

_PL_PARAM_MAP: dict[str, str] = {
    "RX": "rx", "RY": "ry", "RZ": "rz",
    "PhaseShift": "rz",
}


def from_pennylane(tape_dict: dict) -> tuple[list[dict], int]:
    """PennyLane tape dict → ``(ops, n_qubits)``.

    Expects a dict with ``"operations"`` list and ``"num_wires"`` key.
    Maps: Hadamard→h, PauliX→x, CNOT→cnot, RX/RY/RZ→rx/ry/rz.
    """
    n_qubits: int = tape_dict.get("num_wires", 0)
    if n_qubits == 0:
        raise ValueError("PennyLane tape dict must have a 'num_wires' field")

    ops: list[dict] = []
    param_counter = 0

    for operation in tape_dict.get("operations", []):
        name   = operation.get("name", "")
        wires  = operation.get("wires", [])

        if name in _PL_FIXED_MAP:
            ops.append({
                "type": _PL_FIXED_MAP[name],
                "qubits": wires,
                "param_indices": [],
            })
        elif name in _PL_PARAM_MAP:
            ops.append({
                "type": _PL_PARAM_MAP[name],
                "qubits": wires,
                "param_indices": [param_counter],
            })
            param_counter += 1

    return ops, n_qubits


# ---------------------------------------------------------------------------
# AWS Braket OpenQASM 3 dialect
# ---------------------------------------------------------------------------

def from_braket(source: str) -> tuple[list[dict], int]:
    """AWS Braket OpenQASM 3 dialect → ``(ops, n_qubits)``.

    Strips ``#pragma braket result`` annotations, classical bit declarations,
    and ``box{...}`` blocks, then delegates to the OpenQASM 3 parser.
    """
    lines: list[str] = []
    in_box = False

    for line in source.splitlines():
        stripped = line.strip()

        if stripped == "box{":
            in_box = True
            continue
        if in_box and stripped == "}":
            in_box = False
            continue

        if stripped.startswith("#pragma braket"):
            continue
        if stripped.startswith("bit ") or re.match(r"\w+\s*=\s*measure", stripped):
            continue

        lines.append(line)

    return from_qasm3("\n".join(lines))


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

def circuit_payload_to_ops(payload: "CircuitPayload") -> tuple[list[dict], int]:
    """Dispatch a :class:`~zilver.wire_types.CircuitPayload` to the correct
    converter and return ``(ops, n_qubits)``."""
    fmt = payload.format

    if fmt == "native":
        if payload.ops is None:
            raise ValueError("CircuitPayload.format='native' requires ops to be set")
        n_qubits = 0
        for op in payload.ops:
            for q in op.get("qubits", []):
                n_qubits = max(n_qubits, q + 1)
        return payload.ops, n_qubits

    if fmt == "qasm2":
        if payload.raw is None:
            raise ValueError("CircuitPayload.format='qasm2' requires raw to be set")
        return from_qasm2(payload.raw)

    if fmt == "qasm3":
        if payload.raw is None:
            raise ValueError("CircuitPayload.format='qasm3' requires raw to be set")
        return from_qasm3(payload.raw)

    if fmt == "qiskit":
        if payload.data is None:
            raise ValueError("CircuitPayload.format='qiskit' requires data to be set")
        return from_qiskit(payload.data)

    if fmt == "pennylane":
        if payload.data is None:
            raise ValueError("CircuitPayload.format='pennylane' requires data to be set")
        return from_pennylane(payload.data)

    if fmt == "braket":
        if payload.raw is None:
            raise ValueError("CircuitPayload.format='braket' requires raw to be set")
        return from_braket(payload.raw)

    raise ValueError(f"Unknown circuit format: {fmt!r}")
