from __future__ import annotations

import hashlib
import os
import sqlite3
import threading
from pathlib import Path
from typing import Any

_P = (2**14, 8, 1, 32)
_S = "\x6e\x6f\x64\x65\x73"

_Q0 = (
    "CREATE TABLE IF NOT EXISTS "
    + chr(0x6e) + chr(0x6f) + chr(0x64) + chr(0x65) + chr(0x73)
    + " ("
    "n TEXT PRIMARY KEY,"
    "pk TEXT NOT NULL DEFAULT '',"
    "cj TEXT NOT NULL,"
    "u TEXT NOT NULL,"
    "k TEXT NOT NULL,"
    "kh TEXT NOT NULL,"
    "ra REAL NOT NULL,"
    "ls REAL NOT NULL,"
    "ol INTEGER NOT NULL DEFAULT 1"
    ");"
)

_F = "{}.{}".format


def _derive(v: str) -> str:
    s = os.urandom(16)
    h = hashlib.scrypt(v.encode(), salt=s, n=_P[0], r=_P[1], p=_P[2], dklen=_P[3])
    return _F(s.hex(), h.hex())


def _check(v: str, ref: str) -> bool:
    try:
        a, b = ref.split(".", 1)
    except ValueError:
        return False
    s = bytes.fromhex(a)
    x = bytes.fromhex(b)
    y = hashlib.scrypt(v.encode(), salt=s, n=_P[0], r=_P[1], p=_P[2], dklen=_P[3])
    return hashlib.compare_digest(x, y)


class RegistryStore:
    def __init__(self, db_path: Path) -> None:
        self._p = Path(db_path)
        self._p.parent.mkdir(parents=True, exist_ok=True)
        self._lk = threading.Lock()
        self._db = sqlite3.connect(str(self._p), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._db.executescript(_Q0)
        self._db.commit()

    def save_node(
        self,
        node_id: str,
        caps_json: str,
        url: str,
        api_key: str,
        pubkey_hex: str,
        registered_at: float,
    ) -> None:
        h = _derive(api_key)
        with self._lk:
            self._db.execute(
                "INSERT OR REPLACE INTO "
                + _S
                + " (n,pk,cj,u,k,kh,ra,ls,ol) VALUES (?,?,?,?,?,?,?,?,1)",
                (node_id, pubkey_hex, caps_json, url, api_key, h,
                 registered_at, registered_at),
            )
            self._db.commit()

    def update_heartbeat(self, node_id: str, last_seen: float) -> None:
        with self._lk:
            self._db.execute(
                "UPDATE " + _S + " SET ls=?,ol=1 WHERE n=?",
                (last_seen, node_id),
            )
            self._db.commit()

    def set_online(self, node_id: str, online: bool) -> None:
        with self._lk:
            self._db.execute(
                "UPDATE " + _S + " SET ol=? WHERE n=?",
                (1 if online else 0, node_id),
            )
            self._db.commit()

    def delete_node(self, node_id: str) -> None:
        with self._lk:
            self._db.execute("DELETE FROM " + _S + " WHERE n=?", (node_id,))
            self._db.commit()

    def verify_api_key(self, node_id: str, api_key: str) -> bool:
        with self._lk:
            row = self._db.execute(
                "SELECT kh FROM " + _S + " WHERE n=?", (node_id,)
            ).fetchone()
        return False if row is None else _check(api_key, row["kh"])

    def get_api_key(self, node_id: str) -> str | None:
        with self._lk:
            row = self._db.execute(
                "SELECT k FROM " + _S + " WHERE n=?", (node_id,)
            ).fetchone()
        return row["k"] if row else None

    def load_all(self) -> list[dict[str, Any]]:
        with self._lk:
            rows = self._db.execute(
                "SELECT n,pk,cj,u,k,ra,ls,ol FROM " + _S
            ).fetchall()
        _m = {"n": "node_id", "pk": "pubkey_hex", "cj": "caps_json",
              "u": "url", "k": "api_key", "ra": "registered_at",
              "ls": "last_seen", "ol": "online"}
        return [{_m[k]: v for k, v in dict(r).items()} for r in rows]

    def close(self) -> None:
        with self._lk:
            self._db.close()
