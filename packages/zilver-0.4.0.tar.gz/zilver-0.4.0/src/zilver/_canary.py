from __future__ import annotations

import math
import random
import uuid
from typing import Any, Awaitable, Callable

import httpx

_P   = 0.1
_MF  = 2
_TO  = 8.0

_W = [
    {
        "circuit_ops": [],
        "n_qubits": 1, "n_params": 0, "params": [],
        "observable": "sum_z", "backend": "sv",
        "result_type": "expectation",
        "_a": 1.0, "_t": 1e-4,
    },
    {
        "circuit_ops": [{"type": "x", "qubits": [0], "param_idx": None}],
        "n_qubits": 1, "n_params": 0, "params": [],
        "observable": "sum_z", "backend": "sv",
        "result_type": "expectation",
        "_a": -1.0, "_t": 1e-4,
    },
    {
        "circuit_ops": [
            {"type": "x", "qubits": [0], "param_idx": None},
            {"type": "x", "qubits": [1], "param_idx": None},
        ],
        "n_qubits": 2, "n_params": 0, "params": [],
        "observable": "sum_z", "backend": "sv",
        "result_type": "expectation",
        "_a": -2.0, "_t": 1e-4,
    },
    {
        "circuit_ops": [
            {"type": "h", "qubits": [0], "param_idx": None},
            {"type": "cnot", "qubits": [0, 1], "param_idx": None},
            {"type": "cnot", "qubits": [0, 1], "param_idx": None},
            {"type": "h", "qubits": [0], "param_idx": None},
        ],
        "n_qubits": 2, "n_params": 0, "params": [],
        "observable": "sum_z", "backend": "sv",
        "result_type": "expectation",
        "_a": 2.0, "_t": 1e-4,
    },
]

MAX_FAILS = _MF


async def maybe_check(
    node_url: str,
    node_key: str,
    on_fail: Callable[[], Awaitable[None]] | None = None,
) -> bool:
    if random.random() > _P:
        return True

    tmpl    = random.choice(_W)
    exp_val = tmpl["_a"]
    tol     = tmpl["_t"]
    job: dict[str, Any] = {k: v for k, v in tmpl.items() if not k.startswith("_")}
    job["job_id"] = str(uuid.uuid4())

    hdrs = {"Authorization": f"Bearer {node_key}"} if node_key else {}
    ok = False
    try:
        async with httpx.AsyncClient(verify=False, timeout=_TO) as _c:
            r = await _c.post(f"{node_url}/execute", json=job, headers=hdrs)
        if r.status_code == 200:
            got = r.json().get("expectation", float("nan"))
            ok  = math.isfinite(got) and abs(got - exp_val) <= tol
    except Exception:
        ok = False

    if not ok and on_fail is not None:
        await on_fail()

    return ok
