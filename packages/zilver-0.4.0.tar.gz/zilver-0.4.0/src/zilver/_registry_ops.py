"""Registry verification operations (internal)."""
from __future__ import annotations


def new_api_key() -> str:
    """Generate a fresh API key for a node."""
    from .security import generate_api_key
    return generate_api_key()


def verify_registration(
    pubkey_hex: str,
    key_type: str,
    signed_payload: dict,
    signature_hex: str,
) -> bool:
    """Verify a node registration signature."""
    from .security import verify_registration_signature, verify_se_signature
    if key_type == "ed25519":
        return verify_registration_signature(pubkey_hex, signed_payload, signature_hex)
    return verify_se_signature(pubkey_hex, signed_payload, signature_hex)


def node_id_from_pubkey(pubkey_hex: str) -> str:
    """Derive node_id from a hex public key."""
    from .security import derive_node_id
    return derive_node_id(bytes.fromhex(pubkey_hex))
