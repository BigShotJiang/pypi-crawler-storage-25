"""Canonical typed wire-format dataclasses for everything that crosses the network."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from uuid import uuid4


@dataclass
class CircuitPayload:
    """A quantum circuit in one of several supported formats."""

    format: str  # "native" | "qasm2" | "qasm3" | "qiskit" | "pennylane" | "braket"
    ops:    list[dict] | None = None  # native ops
    raw:    str        | None = None  # qasm2 / qasm3 / braket: source string
    data:   dict       | None = None  # qiskit / pennylane: JSON dict


@dataclass
class PauliTerm:
    """A single term in a Pauli Hamiltonian."""

    coeff: float
    pauli: str  # e.g. "ZZI", "XIZ" — length must equal n_qubits


@dataclass
class JobRequest:
    """A job request submitted to the network."""

    circuit:     CircuitPayload
    n_qubits:    int
    n_params:    int
    params:      list[float]
    backend:     str            = "sv"           # "sv" | "dm" | "tn"
    result_type: str            = "expectation"  # "expectation" | "samples" | "statevector" | "pauli"
    observable:  str            = "sum_z"
    hamiltonian: list[PauliTerm] | None = None
    shots:       int   | None   = None
    client_id:   str   | None   = None
    max_credits: float | None   = None
    job_id:      str            = field(default_factory=lambda: str(uuid4()))


# ---------------------------------------------------------------------------
# Proof computation
# ---------------------------------------------------------------------------

def _compute_response_proof(
    job_id: str,
    params: list[float],
    result_type: str,
    primary: dict,
) -> str:
    """Compute a deterministic SHA-256 proof for a job response."""
    payload = json.dumps(
        {"job_id": job_id, "params": params, "result_type": result_type, **primary},
        sort_keys=True,
    )
    return hashlib.sha256(payload.encode()).hexdigest()


# ---------------------------------------------------------------------------
# JobResponse
# ---------------------------------------------------------------------------

@dataclass
class JobResponse:
    """Result returned by a node after executing a JobRequest."""

    job_id:             str
    node_id:            str
    result_type:        str
    expectation:        float | None               = None
    samples:            list[str] | None           = None
    sample_counts:      dict[str, int] | None      = None
    statevector:        list[list[float]] | None   = None
    pauli_expectations: dict[str, float] | None    = None
    proof:              str                        = ""
    node_signature:     str                        = ""
    node_pubkey:        str                        = ""
    elapsed_ms:         float                      = 0.0
    memory_used_mb:     float                      = 0.0
    credits_charged:    float                      = 0.0
    node_revenue:       float                      = 0.0

    def verify_proof(self, request: JobRequest) -> bool:
        """Recompute and check the proof hash against the request params."""
        if self.result_type == "expectation" and self.expectation is not None:
            primary: dict = {"expectation": round(self.expectation, 8)}
        elif self.result_type == "samples" and self.samples is not None:
            primary = {"samples": sorted(self.samples)}
        elif self.result_type == "statevector" and self.statevector is not None:
            sv_bytes = json.dumps(self.statevector, sort_keys=True).encode()
            primary = {"statevector_sha256": hashlib.sha256(sv_bytes).hexdigest()}
        elif self.result_type == "pauli" and self.pauli_expectations is not None:
            primary = {k: round(v, 8) for k, v in sorted(self.pauli_expectations.items())}
        else:
            return False
        expected = _compute_response_proof(
            self.job_id, request.params, self.result_type, primary
        )
        return self.proof == expected

    def verify_signature(self) -> bool:
        """Verify the node's signature over the proof. Returns False if any field is absent."""
        if not self.proof or not self.node_signature or not self.node_pubkey:
            return False
        from .node_types import verify_result_signature
        return verify_result_signature(self.proof, self.node_pubkey, self.node_signature)


# ---------------------------------------------------------------------------
# CreditEstimate
# ---------------------------------------------------------------------------

@dataclass
class CreditEstimate:
    """Estimated credit cost for a job before execution."""

    job_id:            str
    backend:           str
    n_qubits:          int
    shots:             int | None
    estimated_credits: float
    breakdown:         dict  # {"base": 0.01, "qubit_rate": 0.002, "shot_rate": 0.0001}
