"""Node identity and credential operations."""
from __future__ import annotations

from pathlib import Path


def load_identity() -> tuple[bytes | None, bytes | None, str | None, str | None]:
    """Load or generate node keypair and derive node_id.

    Returns (private_key_bytes, public_key_bytes, se_label, node_id).
    All None if identity cannot be established.
    """
    from .security import derive_node_id, se_available, SE_LABEL

    if se_available():
        try:
            from .security import se_generate_or_load, se_get_public_key
            pub = se_get_public_key(SE_LABEL)
            if pub is None:
                pub = se_generate_or_load(SE_LABEL)
                print("Node identity stored in macOS Keychain.")
            return None, pub, SE_LABEL, derive_node_id(pub)
        except Exception:
            pass  # fall through to Ed25519

    from .security import keychain_get, keychain_store, generate_node_keypair
    priv_hex = keychain_get("zilver-key-priv", "node")
    pub_hex  = keychain_get("zilver-key-pub",  "node")
    if priv_hex and pub_hex:
        priv = bytes.fromhex(priv_hex)
        pub  = bytes.fromhex(pub_hex)
    else:
        priv, pub = generate_node_keypair()
        keychain_store("zilver-key-priv", "node", priv.hex())
        keychain_store("zilver-key-pub",  "node", pub.hex())
        print("Node keypair stored in macOS Keychain.")
    return priv, pub, None, derive_node_id(pub)


def load_api_key(node_id: str) -> str | None:
    """Retrieve node API key from macOS Keychain."""
    from .security import keychain_get
    return keychain_get("zilver", node_id)


def store_api_key(node_id: str, api_key: str) -> None:
    """Store node API key in macOS Keychain."""
    from .security import keychain_store
    keychain_store("zilver", node_id, api_key)


def ensure_tls_cert(path: Path) -> None:
    """Generate self-signed TLS cert into path."""
    from .security import generate_self_signed_cert
    generate_self_signed_cert(path)
