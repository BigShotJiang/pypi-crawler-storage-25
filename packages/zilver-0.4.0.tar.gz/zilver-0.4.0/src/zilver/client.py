"""HTTP clients."""

from __future__ import annotations

import logging
from typing import Any

import httpx

from .node import NodeCapabilities, SimJob, JobResult
from .batch_distributor import BatchResult

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# NodeClient
# ---------------------------------------------------------------------------

class NodeClient:
    """
    HTTP client for a single remote Zilver node.

    Wraps the REST endpoints exposed by :func:`~zilver.server.make_app`.
    All methods are synchronous and raise ``httpx.HTTPStatusError`` on non-2xx
    responses and ``httpx.ConnectError`` / ``httpx.TimeoutException`` on
    network failures — callers should handle these as appropriate.

    Parameters
    ----------
    url:
        Base URL of the node server, e.g. ``"http://192.168.1.5:7700"``.
        No trailing slash required.
    timeout:
        Per-request timeout in seconds.  Defaults to 30 s, which is generous
        for large statevector jobs on remote hardware.
    api_key:
        Bearer token to include in ``Authorization`` headers.  When ``None``
        no auth header is sent.  The key is issued by the registry on node
        registration and should match the key configured on the node server.

    Example
    -------
    ::

        client = NodeClient("http://192.168.1.5:7700", api_key="abc123...")
        job = SimJob(circuit_ops=[], n_qubits=4, n_params=0, params=[])
        result = client.execute(job)
        assert result.verify(job)
    """

    def __init__(
        self,
        url:     str,
        timeout: float = 30.0,
        api_key: str | None = None,
    ) -> None:
        self.url = url.rstrip("/")
        self.api_key = api_key
        self._client = httpx.Client(timeout=timeout)

    def _auth_headers(self) -> dict[str, str]:
        key = getattr(self, "api_key", None)
        if key:
            return {"Authorization": f"Bearer {key}"}
        return {}

    def execute(self, job: SimJob) -> JobResult:
        """
        Submit a :class:`~zilver.node.SimJob` to the remote node.

        Parameters
        ----------
        job:
            The simulation job to execute.

        Returns
        -------
        JobResult
            The result including expectation value and SHA-256 proof.

        Raises
        ------
        httpx.HTTPStatusError
            If the node returns a 401 (bad API key), 422 (unsupported backend
            / over capacity) or any other non-2xx status.
        """
        resp = self._client.post(
            f"{self.url}/execute",
            json=job.to_dict(),
            headers=self._auth_headers(),
        )
        resp.raise_for_status()
        return JobResult(**resp.json())

    def caps(self) -> NodeCapabilities:
        """
        Retrieve the node's hardware capabilities.

        Returns
        -------
        NodeCapabilities
            Capabilities as advertised by the node at startup.
        """
        resp = self._client.get(f"{self.url}/caps")
        resp.raise_for_status()
        return NodeCapabilities(**resp.json())

    def health(self) -> dict[str, str]:
        """
        Quick health check.

        Returns
        -------
        dict
            ``{"status": "ok", "node_id": "<id>"}`` on success.

        Raises
        ------
        httpx.ConnectError
            If the node is unreachable.
        """
        resp = self._client.get(f"{self.url}/health")
        resp.raise_for_status()
        return resp.json()

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> "NodeClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"NodeClient(url={self.url!r})"


# ---------------------------------------------------------------------------
# RegistryClient
# ---------------------------------------------------------------------------

class RegistryClient:
    """
    HTTP client for the Zilver capability registry.

    Wraps the REST endpoints exposed by
    :func:`~zilver.registry_server.make_registry_app`.
    Used by node daemons for self-registration and by
    :class:`NetworkCoordinator` for node discovery.

    Parameters
    ----------
    url:
        Base URL of the registry server, e.g. ``"http://registry-host:7701"``.
    timeout:
        Per-request timeout in seconds.  Discovery calls are cheap and default
        to 10 s; adjust upward on unreliable networks.
    api_key:
        Bearer token to include on ``register`` and ``heartbeat`` calls.
        When ``None`` no auth header is sent.

    Example
    -------
    ::

        reg = RegistryClient("http://registry-host:7701")
        ok = reg.register(node.caps, node_url="http://my-mac:7700")
        api_key = reg.last_api_key   # store securely, e.g. Keychain
        # ... serve jobs ...
        reg.deregister(node.caps.node_id)
    """

    def __init__(
        self,
        url:     str,
        timeout: float = 10.0,
        api_key: str | None = None,
    ) -> None:
        self.url = url.rstrip("/")
        self.api_key = api_key
        self._client = httpx.Client(timeout=timeout)
        self.last_api_key: str | None = None

    def _auth_headers(self) -> dict[str, str]:
        key = getattr(self, "api_key", None)
        if key:
            return {"Authorization": f"Bearer {key}"}
        return {}

    def register(
        self,
        caps:              NodeCapabilities,
        node_url:          str,
        private_key_bytes: bytes | None = None,
        public_key_bytes:  bytes | None = None,
        se_label:          str  | None = None,
    ) -> bool:
        """
        Register (or re-register) a node with the registry.

        The registry issues a fresh API key on each registration.  After this
        call, the key is accessible via ``self.last_api_key``.  Callers
        (typically the CLI) should store it securely, e.g. in macOS Keychain.

        Parameters
        ----------
        caps:
            The node's hardware capabilities.
        node_url:
            The reachable HTTP base URL of the node server,
            e.g. ``"http://192.168.1.10:7700"``.
        private_key_bytes:
            Raw private key bytes.  Used when ``se_label`` is not set.
        public_key_bytes:
            Raw public key bytes.
        se_label:
            hardware key label.  When set, signing uses the hardware
            key and ``private_key_bytes`` is ignored.

        Returns
        -------
        bool
            ``True`` on success.

        Raises
        ------
        httpx.HTTPStatusError
            On 4xx / 5xx responses.
        """
        body: dict = {"caps": caps.to_dict(), "url": node_url}

        try:
            from . import _client_ops
            _client_ops.sign_registration_body(
                body, node_url, private_key_bytes, public_key_bytes, se_label
            )
        except ImportError:
            pass

        resp = self._client.post(
            f"{self.url}/nodes",
            json=body,
            headers=self._auth_headers(),
        )
        resp.raise_for_status()
        data = resp.json()
        self.last_api_key = data.get("api_key")
        return data.get("registered", False)

    def deregister(self, node_id: str) -> bool:
        """
        Mark a node offline in the registry.

        Parameters
        ----------
        node_id:
            The node's unique identifier.

        Returns
        -------
        bool
            ``True`` if the node was found and deregistered.
        """
        resp = self._client.delete(f"{self.url}/nodes/{node_id}")
        resp.raise_for_status()
        return resp.json().get("deregistered", False)

    def heartbeat(self, node_id: str) -> bool:
        """
        Refresh the last-seen timestamp for a node.

        Should be called on a regular interval (e.g. every 30 s) by the
        node daemon's background thread to prevent the registry from marking
        the node stale.

        Returns
        -------
        bool
            ``True`` on success, ``False`` if the node was not found.
        """
        resp = self._client.post(
            f"{self.url}/nodes/{node_id}/heartbeat",
            headers=self._auth_headers(),
        )
        if resp.status_code == 404:
            return False
        resp.raise_for_status()
        return True

    def _match_entry(
        self,
        backend:   str,
        n_qubits:  int,
        min_stake: int = 0,
    ) -> dict[str, Any] | None:
        """Return the full match response dict (with node_id and url), or None."""
        params: dict[str, Any] = {
            "backend": backend,
            "n_qubits": n_qubits,
            "min_stake": min_stake,
        }
        resp = self._client.get(f"{self.url}/match", params=params,
                                headers=self._auth_headers())
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    def match(
        self,
        backend:   str,
        n_qubits:  int,
        min_stake: int = 0,
    ) -> str | None:
        """
        Find the best available node for a job and return its URL.

        Parameters
        ----------
        backend:
            Requested simulator backend: ``"sv"``, ``"dm"``, or ``"tn"``.
        n_qubits:
            Number of qubits required.
        min_stake:
            Minimum stake threshold (default 0).

        Returns
        -------
        str | None
            The node's HTTP base URL, e.g. ``"http://192.168.1.5:7700"``,
            or ``None`` if no eligible node is available.
        """
        entry = self._match_entry(backend, n_qubits, min_stake)
        return entry.get("url") if entry is not None else None

    def contribute(
        self,
        node_id:        str,
        elapsed_ms:     float,
        memory_used_mb: float,
        proof:          str,
        job_token:      str = "",
    ) -> dict[str, Any]:
        """
        Report a completed job contribution and claim SQT rewards.

        Parameters
        ----------
        node_id:
            The node that executed the job.
        elapsed_ms:
            Wall-clock time of the job in milliseconds.
        memory_used_mb:
            Peak Metal memory used by the job.
        proof:
            SHA-256 hex digest from :class:`~zilver.node.JobResult`.
        job_token:
            Single-use token returned by ``GET /match``.  Required when the
            registry enforces contribution authorisation.

        Returns
        -------
        dict
            ``{"sqt_earned": float, "balance": float}``
        """
        body = {
            "job_token":      job_token,
            "elapsed_ms":     elapsed_ms,
            "memory_used_mb": memory_used_mb,
            "proof":          proof,
        }
        resp = self._client.post(
            f"{self.url}/nodes/{node_id}/contribute",
            json=body,
            headers=self._auth_headers(),
        )
        resp.raise_for_status()
        return resp.json()

    def nodes(self) -> list[dict[str, Any]]:
        """
        Return all currently online nodes.

        Returns
        -------
        list[dict]
            Each element is a ``NodeCapabilities.to_dict()`` extended with
            a ``"url"`` field and ``"node_execute_key"`` field.
        """
        resp = self._client.get(f"{self.url}/nodes", headers=self._auth_headers())
        resp.raise_for_status()
        return resp.json()

    def summary(self) -> dict[str, Any]:
        """
        Return aggregate registry statistics.

        Returns
        -------
        dict
            Keys: ``online``, ``total_registered``, ``backends``,
            ``max_sv_qubits``, ``max_dm_qubits``, ``total_stake``.
        """
        resp = self._client.get(f"{self.url}/summary")
        resp.raise_for_status()
        return resp.json()

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> "RegistryClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"RegistryClient(url={self.url!r})"


# ---------------------------------------------------------------------------
# NetworkCoordinator
# ---------------------------------------------------------------------------

class NetworkCoordinator:
    """
    High-level coordinator for distributed job submission.

    Resolves the best available node via the registry, submits a job to it,
    and returns the result.  For batch evaluation, it distributes parameter
    slices across multiple nodes and reassembles the results.

    Parameters
    ----------
    registry_url:
        Base URL of a running registry server.
    timeout:
        HTTP timeout forwarded to both :class:`RegistryClient` and
        :class:`NodeClient`.
    api_key:
        Bearer token for node ``/execute`` requests.  Passed through to
        :class:`NodeClient` on each job submission.

    Example
    -------
    ::

        from zilver.client import NetworkCoordinator
        from zilver.node import SimJob

        coord = NetworkCoordinator("http://registry-host:7701", api_key="abc...")

        job = SimJob(
            circuit_ops=[{"type": "h", "qubits": [0], "param_idx": None}],
            n_qubits=4, n_params=0, params=[], backend="sv",
        )
        result = coord.submit(job)
        print(result.expectation)
    """

    def __init__(
        self,
        registry_url:    str,
        timeout:         float = 30.0,
        api_key:         str | None = None,
        client_api_key:  str | None = None,
    ) -> None:
        self.registry_url = registry_url
        self.timeout = timeout
        self.api_key = api_key  # fallback for node /execute when no key in match response
        # client_api_key authenticates this coordinator to the registry (/match, /nodes, etc.)
        self._registry = RegistryClient(
            registry_url,
            timeout=min(timeout, 10.0),
            api_key=client_api_key,
        )

    def submit(self, job: SimJob) -> JobResult:
        """
        Submit a single job to the best available node.

        Performs registry lookup → node selection → remote execution in one
        call.  The returned :class:`~zilver.node.JobResult` includes a
        SHA-256 proof that the caller can verify with ``result.verify(job)``.

        Parameters
        ----------
        job:
            The simulation job to execute.

        Returns
        -------
        JobResult

        Raises
        ------
        RuntimeError
            If no eligible node is available in the registry.
        httpx.HTTPStatusError
            On node-side errors (wrong backend, over-capacity, etc.).
        """
        entry = self._registry._match_entry(job.backend, job.n_qubits)
        if entry is None:
            raise RuntimeError(
                f"No eligible node for backend={job.backend!r} "
                f"n_qubits={job.n_qubits}"
            )
        node_url         = entry.get("url", "")
        node_id          = entry.get("node_id", "")
        job_token        = entry.get("job_token", "")
        node_execute_key = entry.get("node_execute_key") or self.api_key
        with NodeClient(node_url, timeout=self.timeout, api_key=node_execute_key) as node_client:
            result = node_client.execute(job)
        # Best-effort contribution report — non-fatal if registry is unreachable
        try:
            self._registry.contribute(
                node_id=node_id,
                elapsed_ms=result.elapsed_ms,
                memory_used_mb=result.memory_used_mb,
                proof=result.proof,
                job_token=job_token,
            )
        except Exception as exc:
            _log.warning("contribute() failed for node %s: %s", node_id, exc)
        return result

    def submit_batch(
        self,
        circuit: Any,
        params_batch: Any,
        backend: str = "sv",
        observable: str = "sum_z",
        **kwargs,
    ) -> "BatchResult":
        """Evaluate a circuit at N parameter sets across available nodes."""
        from . import _batch_ops
        return _batch_ops.submit_batch(
            self, circuit, params_batch, backend, observable, **kwargs
        )

    def nodes(self) -> list[dict[str, Any]]:
        """Return all online nodes from the registry."""
        return self._registry.nodes()

    def summary(self) -> dict[str, Any]:
        """Return aggregate registry statistics."""
        return self._registry.summary()

    def __repr__(self) -> str:
        return f"NetworkCoordinator(registry={self.registry_url!r})"
