"""Per-job credit pricing engine.

Configurable rates, competitive with AWS Braket (~60% cheaper on statevector
simulation).  All prices are in SQT credits (Sirius Quantum Tokens).

AWS Braket SV1 reference pricing (for competitive positioning — internal):
  - $0.075 per task + $0.00075 per qubit-shot
Zilver target: ~60% cheaper — lower base, same per-qubit structure.
"""

from __future__ import annotations

from dataclasses import dataclass
from uuid import uuid4


@dataclass
class PricingConfig:
    """Credit pricing parameters.  All rates are in SQT credits per job."""

    # Base task fee (covers registry overhead)
    base_credits:     float = 0.01
    # Per-qubit rate per job
    sv_qubit_rate:    float = 0.002    # statevector (scales with 2^n memory)
    dm_qubit_rate:    float = 0.004    # density matrix (4x memory vs sv)
    tn_qubit_rate:    float = 0.001    # tensor network (sparse, cheaper)
    # Per-shot rate (for "samples" result_type)
    shot_rate:        float = 0.00005
    # Protocol fee kept by registry / Sirius Quantum
    protocol_fee_pct: float = 0.20     # 20% protocol, 80% to node


#: Singleton default config used by estimate helpers and registry endpoints.
DEFAULT_CONFIG = PricingConfig()


def estimate_credits(
    config: PricingConfig,
    backend: str,
    n_qubits: int,
    shots: int | None,
    job_id: str | None = None,
) -> "CreditEstimate":
    """Calculate the estimated job cost before execution.

    Parameters
    ----------
    config:
        Pricing configuration.
    backend:
        ``"sv"``, ``"dm"``, or ``"tn"``.
    n_qubits:
        Number of qubits in the circuit.
    shots:
        Number of measurement shots (``None`` for expectation-only jobs).
    job_id:
        Optional explicit job ID; a fresh UUID is generated if ``None``.

    Returns
    -------
    CreditEstimate
    """
    from .wire_types import CreditEstimate

    qubit_rate = {
        "sv": config.sv_qubit_rate,
        "dm": config.dm_qubit_rate,
        "tn": config.tn_qubit_rate,
    }.get(backend, config.sv_qubit_rate)

    qubit_cost = n_qubits * qubit_rate
    shot_cost  = (shots or 0) * config.shot_rate
    total      = config.base_credits + qubit_cost + shot_cost

    return CreditEstimate(
        job_id            = job_id or str(uuid4()),
        backend           = backend,
        n_qubits          = n_qubits,
        shots             = shots,
        estimated_credits = round(total, 6),
        breakdown         = {
            "base":       config.base_credits,
            "qubit_rate": round(qubit_cost, 6),
            "shot_rate":  round(shot_cost, 6),
        },
    )


def node_revenue(config: PricingConfig, credits_charged: float) -> float:
    """Credits earned by the executing node (80% of charged by default).

    Parameters
    ----------
    config:
        Pricing configuration.
    credits_charged:
        Total credits charged to the client for this job.

    Returns
    -------
    float
        Node's share of the credits.
    """
    return round(credits_charged * (1.0 - config.protocol_fee_pct), 6)
