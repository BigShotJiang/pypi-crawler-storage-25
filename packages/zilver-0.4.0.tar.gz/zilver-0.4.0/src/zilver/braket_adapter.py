"""AWS Braket compatibility layer.

Converts between Braket ``CreateQuantumTask`` JSON bodies and Zilver's native
``JobRequest`` / ``JobResponse`` wire types so existing Braket SDK users can
point at Zilver with minimal client-side changes.

Registry endpoints that use these helpers:
    POST   /braket/tasks              — submit a task (Braket format)
    GET    /braket/tasks/{task_id}    — poll task status
    GET    /braket/tasks/{task_id}/result — fetch result (Braket format)
"""

from __future__ import annotations

import re
from typing import Any


# ---------------------------------------------------------------------------
# Task body → JobRequest
# ---------------------------------------------------------------------------

def braket_task_to_job_request(body: dict[str, Any]) -> "JobRequest":
    """Parse a Braket ``CreateQuantumTask`` JSON body → :class:`~zilver.wire_types.JobRequest`.

    Braket relevant fields
    ~~~~~~~~~~~~~~~~~~~~~~
    - ``action``           — JSON-serialised OpenQASM 3 object ``{"source": "..."}``
                             OR a raw OpenQASM 3 string.
    - ``shots``            — number of measurement shots (``None`` → expectation value).
    - ``deviceParameters`` — ignored (Zilver determines backend automatically).
    """
    from .wire_types import JobRequest, CircuitPayload
    import json as _json

    action = body.get("action", {})
    if isinstance(action, str):
        try:
            action = _json.loads(action)
        except Exception:
            # Treat as raw OpenQASM string
            action = {"source": action}

    source: str = action.get("source", "")
    shots: int | None = body.get("shots") or None

    n_qubits = _count_qubits_from_qasm(source)
    result_type = "samples" if shots else "expectation"

    circuit = CircuitPayload(format="braket", raw=source)
    return JobRequest(
        circuit     = circuit,
        n_qubits    = n_qubits,
        n_params    = 0,
        params      = [],
        backend     = "sv",
        result_type = result_type,
        shots       = shots,
    )


def _count_qubits_from_qasm(source: str) -> int:
    """Estimate qubit count from qubit declarations in a QASM string.

    Handles both multi-line and semicolon-separated single-line QASM.
    """
    n = 0
    # Normalize: split on semicolons and newlines so single-line QASM works
    statements = re.split(r";|\n", source)
    for stmt in statements:
        stripped = stmt.strip()
        # qubit[n] name
        m = re.match(r"qubit\[(\d+)\]", stripped)
        if m:
            n += int(m.group(1))
            continue
        # qubit name  (single qubit)
        m = re.match(r"qubit\s+\w+", stripped)
        if m:
            n += 1
            continue
        # qreg name[n]
        m = re.match(r"qreg\s+\w+\[(\d+)\]", stripped)
        if m:
            n = max(n, int(m.group(1)))
    return max(n, 1)


# ---------------------------------------------------------------------------
# JobResponse → Braket result
# ---------------------------------------------------------------------------

def job_response_to_braket_result(resp: "JobResponse") -> dict[str, Any]:
    """Convert a :class:`~zilver.wire_types.JobResponse` to a
    Braket ``QuantumTaskResult`` JSON dict.

    Braket result fields
    ~~~~~~~~~~~~~~~~~~~~
    - ``measurements``             — (shots × qubits) array of 0/1 ints
    - ``measuredQubits``           — list of qubit indices
    - ``resultTypes``              — list of result type objects
    - ``measurementProbabilities`` — dict of bitstring → probability
    - ``taskMetadata``             — task ID, shots count, device ID
    """
    measurements: list[list[int]] = []
    measured_qubits: list[int]    = []
    measurement_probabilities: dict[str, float] = {}
    result_types: list[dict] = []

    # --- Samples ---
    if resp.samples:
        n_q = len(resp.samples[0]) if resp.samples else 0
        measured_qubits = list(range(n_q))
        for bitstring in resp.samples:
            measurements.append([int(b) for b in bitstring])
        total = len(resp.samples)
        counts: dict[str, int] = {}
        for s in resp.samples:
            counts[s] = counts.get(s, 0) + 1
        measurement_probabilities = {k: v / total for k, v in counts.items()}

    # --- Result types ---
    if resp.result_type == "expectation" and resp.expectation is not None:
        result_types.append({
            "type": {
                "name": "Expectation",
                "observable": ["z"],
                "targets": measured_qubits or list(range(1)),
            },
            "value": resp.expectation,
        })

    elif resp.result_type == "statevector" and resp.statevector is not None:
        result_types.append({
            "type": {"name": "StateVector"},
            "value": resp.statevector,
        })

    elif resp.result_type == "pauli" and resp.pauli_expectations is not None:
        for pauli_str, val in resp.pauli_expectations.items():
            result_types.append({
                "type": {
                    "name": "Expectation",
                    "observable": list(pauli_str.upper()),
                    "targets": list(range(len(pauli_str))),
                },
                "value": val,
            })

    return {
        "measurements":             measurements,
        "measuredQubits":           measured_qubits,
        "resultTypes":              result_types,
        "measurementProbabilities": measurement_probabilities,
        "taskMetadata": {
            "id":       resp.job_id,
            "shots":    len(measurements),
            "deviceId": f"arn:aws:braket:::device/quantum-simulator/zilver/{resp.node_id}",
        },
        "additionalMetadata": {
            "action":    {},
            "elapsedMs": resp.elapsed_ms,
        },
    }
