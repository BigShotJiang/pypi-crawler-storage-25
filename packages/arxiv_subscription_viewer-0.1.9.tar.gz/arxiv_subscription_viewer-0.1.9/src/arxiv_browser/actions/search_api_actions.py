# ruff: noqa: UP037
"""Extracted ArxivBrowser action handlers."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import httpx
from textual.css.query import NoMatches

from arxiv_browser.action_messages import build_actionable_error, build_actionable_warning
from arxiv_browser.actions.constants import BOOKMARK_NAME_MAX_LEN, logger
from arxiv_browser.cli import ARXIV_API_MIN_INTERVAL_SECONDS
from arxiv_browser.config import _coerce_arxiv_api_max_results, save_config
from arxiv_browser.models import ArxivSearchModeState, ArxivSearchRequest, Paper, SearchBookmark
from arxiv_browser.parsing import HISTORY_DATE_FORMAT
from arxiv_browser.query import truncate_text
from arxiv_browser.services.arxiv_api_service import ARXIV_API_TIMEOUT

if TYPE_CHECKING:
    from arxiv_browser.browser.core import ArxivBrowser


def action_toggle_search(app: "ArxivBrowser") -> None:
    """Toggle search input visibility."""
    omni = app._get_search_container_widget()
    if omni.is_open:
        omni.hide()
    else:
        omni.open()
        app.notify(
            'Search mode: try cat:cs.AI, author:hinton, review-due, or "large language".',
            title="Search",
        )
    app._update_footer()


def action_cancel_search(app: "ArxivBrowser") -> None:
    """Cancel search and hide input."""
    omni = app._get_search_container_widget()
    if omni.is_open:
        omni.close()
        app._apply_filter("")
        try:
            app._get_paper_list_widget().focus()
        except NoMatches:
            pass
        app._update_footer()
    if app._in_arxiv_api_mode:
        app.action_exit_arxiv_search_mode()

    # Cancel only true batch LLM operations (relevance scoring / batch auto-tagging).
    if app._relevance_scoring_active or app._auto_tag_progress is not None:
        app._cancel_batch_requested = True
        app.notify("Cancelling batch operation...", title="Cancel")


def action_exit_arxiv_search_mode(app: "ArxivBrowser") -> None:
    """Exit API search mode and restore local papers."""
    if not app._in_arxiv_api_mode:
        return

    # Invalidate in-flight responses from older requests.
    app._arxiv_api_request_token += 1

    app._in_arxiv_api_mode = False
    app._arxiv_search_state = None
    app._arxiv_api_fetch_inflight = False
    app._arxiv_api_loading = False
    app._restore_local_browse_snapshot()
    app._local_browse_snapshot = None
    app._update_header()
    app._update_subtitle()
    app.notify("Exited arXiv API mode", title="arXiv Search")


def action_arxiv_search(app: "ArxivBrowser") -> None:
    """Open OmniInput in arXiv API search mode."""
    omni = app._get_search_container_widget()
    default_query = ""
    if app._arxiv_search_state is not None:
        default_query = app._arxiv_search_state.request.query
    omni.open(f"@{default_query}")


def _format_arxiv_search_label(app: "ArxivBrowser", request: ArxivSearchRequest) -> str:
    """Build a human-readable query label for API mode UI."""
    return app._get_services().arxiv_api.format_query_label(request)


async def _apply_arxiv_rate_limit(app: "ArxivBrowser") -> None:
    """Sleep as needed to respect arXiv API rate limits."""
    loop = asyncio.get_running_loop()
    new_last_request_at, wait_seconds = await app._get_services().arxiv_api.enforce_rate_limit(
        last_request_at=app._last_arxiv_api_request_at,
        min_interval_seconds=ARXIV_API_MIN_INTERVAL_SECONDS,
        now=loop.time,
        sleep=asyncio.sleep,
    )
    if wait_seconds > 0:
        app.notify(
            f"Waiting {wait_seconds:.1f}s for arXiv API rate limit",
            title="arXiv Search",
        )
    app._last_arxiv_api_request_at = new_last_request_at


async def _fetch_arxiv_api_page(
    app,
    request: ArxivSearchRequest,
    start: int,
    max_results: int,
) -> list[Paper]:
    """Fetch one page of results from arXiv API."""
    await app._apply_arxiv_rate_limit()
    return await app._get_services().arxiv_api.fetch_page(
        client=app._http_client,
        request=request,
        start=start,
        max_results=max_results,
        timeout_seconds=ARXIV_API_TIMEOUT,
        user_agent="arxiv-subscription-viewer/1.0",
    )


def _resolve_bookmark_query(app: "ArxivBrowser") -> str:
    """Return the current local query, ignoring transient OmniInput modes."""
    active_query = app._get_active_query()
    try:
        live_query = app._get_search_input_widget().value.strip()
    except NoMatches:
        live_query = ""
    if live_query and not live_query.startswith(("@", ">")):
        return live_query
    return active_query


def _apply_arxiv_search_results(
    app,
    request: ArxivSearchRequest,
    start: int,
    max_results: int,
    papers: list[Paper],
) -> None:
    """Switch UI to API mode and render fetched papers."""
    was_in_api_mode = app._in_arxiv_api_mode
    if not was_in_api_mode and app._local_browse_snapshot is None:
        app._local_browse_snapshot = app._capture_local_browse_snapshot()

    app._advance_dataset_epoch()
    app._in_arxiv_api_mode = True
    app._arxiv_search_state = ArxivSearchModeState(
        request=request,
        start=start,
        max_results=max_results,
    )

    # API mode has its own paper set and selection state.
    app.all_papers = papers
    app.filtered_papers = papers.copy()
    app._reset_dataset_view_state()
    app._papers_by_id = {paper.arxiv_id: paper for paper in papers}
    app.selected_ids.clear()
    if not was_in_api_mode:
        # First API entry starts unfiltered; subsequent pages preserve user choice.
        app._watch_filter_active = False
    app._pending_query = ""
    app._applied_query = ""
    app._highlight_terms = {"title": [], "author": [], "abstract": []}
    app._match_scores.clear()
    try:
        app._get_search_input_widget().value = ""
    except NoMatches:
        pass

    app._compute_watched_papers()
    app._load_triage_predictions_for_current_dataset(refresh=False)
    if app._watch_filter_active:
        app.filtered_papers = [
            paper for paper in app.filtered_papers if paper.arxiv_id in app._watched_paper_ids
        ]
    app._sort_papers()
    app._refresh_list_view()
    app._update_header()
    app._update_subtitle()

    try:
        app._get_paper_list_widget().focus()
    except NoMatches:
        pass


async def _run_arxiv_search(app: "ArxivBrowser", request: ArxivSearchRequest, start: int) -> None:
    """Execute an arXiv API search and display one results page.

    Uses an incrementing ``_arxiv_api_request_token`` to discard stale
    responses: the token is captured before the network call and compared
    after it returns.  If the token changed while the request was in flight
    (because the user exited API mode or started a newer search), the
    response is silently dropped.  The ``finally`` block only clears the
    inflight/loading flags when the token still matches, so that a newer
    in-flight request is not prematurely un-flagged.

    Args:
        app: The running ``ArxivBrowser`` application instance.
        request: Encapsulates the query, field, and category to search.
        start: Zero-based result offset for pagination (0 for the first page).
    """
    if app._arxiv_api_fetch_inflight:
        app.notify("Search already in progress", title="arXiv Search")
        return

    start, max_results = _normalize_arxiv_search_page(app, start)
    request_token = _begin_arxiv_search_request(app)

    try:
        papers = await app._fetch_arxiv_api_page(request, start, max_results)
    except ValueError as exc:
        _notify_arxiv_value_error(app, exc)
        return
    except httpx.HTTPStatusError as exc:
        _notify_arxiv_status_error(app, exc)
        return
    except (httpx.HTTPError, OSError) as exc:
        _notify_arxiv_network_error(app, exc)
        return
    finally:
        _finish_arxiv_search_request(app, request_token)

    if _is_stale_arxiv_search_response(app, request_token):
        return

    if start > 0 and not papers:
        app.notify("No more results", title="arXiv Search")
        return

    app._apply_arxiv_search_results(request, start, max_results, papers)
    _notify_arxiv_search_success(app, start, max_results, papers)


def _normalize_arxiv_search_page(app: "ArxivBrowser", start: int) -> tuple[int, int]:
    max_results = _coerce_arxiv_api_max_results(app._config.arxiv_api_max_results)
    app._config.arxiv_api_max_results = max_results
    return max(0, start), max_results


def _begin_arxiv_search_request(app: "ArxivBrowser") -> int:
    """Mark an arXiv API request active and return its freshness token."""
    app._arxiv_api_request_token += 1
    request_token = app._arxiv_api_request_token
    app._arxiv_api_fetch_inflight = True
    app._arxiv_api_loading = True
    app._update_status_bar()
    return request_token


def _finish_arxiv_search_request(app: "ArxivBrowser", request_token: int) -> None:
    """Clear loading flags only when this request still owns them."""
    if request_token != app._arxiv_api_request_token:
        return
    app._arxiv_api_fetch_inflight = False
    app._arxiv_api_loading = False
    app._update_status_bar()


def _is_stale_arxiv_search_response(app: "ArxivBrowser", request_token: int) -> bool:
    return request_token != app._arxiv_api_request_token


def _notify_arxiv_value_error(app: "ArxivBrowser", exc: ValueError) -> None:
    app.notify(str(exc), title="arXiv Search", severity="error")


def _notify_arxiv_status_error(app: "ArxivBrowser", exc: httpx.HTTPStatusError) -> None:
    message = _arxiv_status_error_message(exc.response.status_code)
    app.notify(message, title="arXiv Search", severity="error", timeout=8)


def _arxiv_status_error_message(status_code: int) -> str:
    if status_code == 429:
        return build_actionable_error(
            "run arXiv API search",
            why="arXiv API rate limit reached (HTTP 429)",
            next_step="wait a few seconds and retry with A",
        )
    if status_code >= 500:
        return build_actionable_error(
            "run arXiv API search",
            why=f"arXiv API is unavailable right now (HTTP {status_code})",
            next_step="retry in a minute",
        )
    return build_actionable_error(
        "run arXiv API search",
        why=f"arXiv API rejected the request (HTTP {status_code})",
        next_step="refine the query and retry with A",
    )


def _notify_arxiv_network_error(
    app: "ArxivBrowser",
    exc: httpx.HTTPError | OSError,
) -> None:
    app.notify(
        build_actionable_error(
            "run arXiv API search",
            why="a network or I/O error occurred",
            next_step="check connectivity and retry with A",
        ),
        title="arXiv Search",
        severity="error",
        timeout=8,
    )
    logger.warning("arXiv search failed: %s", exc, exc_info=True)


def _notify_arxiv_search_success(
    app: "ArxivBrowser",
    start: int,
    max_results: int,
    papers: list[Paper],
) -> None:
    page_number = (start // max_results) + 1
    if papers:
        app.notify(
            f"Loaded {len(papers)} results (page {page_number}). Next: Ctrl+e exits search results.",
            title="arXiv Search",
        )
    else:
        app.notify("No results found", title="arXiv Search")


async def action_goto_bookmark(app: "ArxivBrowser", index: int) -> None:
    """Switch to a bookmarked search query."""
    if index < 0 or index >= len(app._config.bookmarks):
        return

    bookmark = app._config.bookmarks[index]
    app._active_bookmark_index = index

    # Update search input and apply filter
    search_input = app._get_search_input_widget()
    search_input.value = bookmark.query
    app._apply_filter(bookmark.query)
    app.notify(f"Bookmark: {bookmark.name}", title="Search")


async def action_add_bookmark(app: "ArxivBrowser") -> None:
    """Add current search query as a bookmark."""
    query = _resolve_bookmark_query(app)

    if not query:
        app.notify(
            build_actionable_warning(
                "Bookmark requires an active search query",
                next_step="type a query with /, then press Ctrl+b",
            ),
            title="Bookmark",
            severity="warning",
        )
        return

    if len(app._config.bookmarks) >= 9:
        app.notify(
            build_actionable_warning(
                "Maximum 9 bookmarks allowed",
                next_step="remove one with Ctrl+Shift+b, then add a new bookmark",
            ),
            title="Bookmark",
            severity="warning",
        )
        return

    # Generate a short name from the query
    name = truncate_text(query, BOOKMARK_NAME_MAX_LEN)

    bookmarks = app._config.bookmarks
    old_bookmarks = list(bookmarks)
    old_active_index = app._active_bookmark_index
    bookmark = SearchBookmark(name=name, query=query)
    bookmarks.append(bookmark)
    app._active_bookmark_index = len(bookmarks) - 1
    if not save_config(app._config):
        bookmarks[:] = old_bookmarks
        app._active_bookmark_index = old_active_index
        app.notify(
            "Failed to save bookmarks",
            title="Bookmark",
            severity="error",
        )
        return

    await app._update_bookmark_bar()
    app.notify(f"Added bookmark: {name}", title="Bookmark")


async def action_remove_bookmark(app: "ArxivBrowser") -> None:
    """Remove the currently active bookmark."""
    if app._active_bookmark_index < 0 or app._active_bookmark_index >= len(app._config.bookmarks):
        app.notify(
            build_actionable_warning(
                "No active bookmark is selected",
                next_step="press 1-9 to activate one, then press Ctrl+Shift+b",
            ),
            title="Bookmark",
            severity="warning",
        )
        return

    bookmarks = app._config.bookmarks
    old_bookmarks = list(bookmarks)
    old_active_index = app._active_bookmark_index
    removed = bookmarks.pop(app._active_bookmark_index)
    app._active_bookmark_index = -1
    if not save_config(app._config):
        bookmarks[:] = old_bookmarks
        app._active_bookmark_index = old_active_index
        app.notify(
            "Failed to save bookmarks",
            title="Bookmark",
            severity="error",
        )
        return

    await app._update_bookmark_bar()
    app.notify(f"Removed bookmark: {removed.name}", title="Bookmark")


def action_prev_date(app: "ArxivBrowser") -> None:
    """Navigate to previous (older) date file."""
    if app._in_arxiv_api_mode:
        app._track_task(app._change_arxiv_page(-1))
        return

    if not app._is_history_mode():
        app.notify("Not in history mode", title="Navigate", severity="warning")
        return

    if app._current_date_index >= len(app._history_files) - 1:
        app.notify("Already at oldest", title="Navigate")
        return

    if not app._set_history_index(app._current_date_index + 1):
        return
    current_date = app._get_current_date()
    if current_date:
        app.notify(f"Loaded {current_date.strftime(HISTORY_DATE_FORMAT)}", title="Navigate")


def action_next_date(app: "ArxivBrowser") -> None:
    """Navigate to next (newer) date file."""
    if app._in_arxiv_api_mode:
        app._track_task(app._change_arxiv_page(1))
        return

    if not app._is_history_mode():
        app.notify("Not in history mode", title="Navigate", severity="warning")
        return

    if app._current_date_index <= 0:
        app.notify("Already at newest", title="Navigate")
        return

    if not app._set_history_index(app._current_date_index - 1):
        return
    current_date = app._get_current_date()
    if current_date:
        app.notify(f"Loaded {current_date.strftime(HISTORY_DATE_FORMAT)}", title="Navigate")
