"""LLM summary, relevance scoring, auto-tagging — prompts, DB persistence, parsing."""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shlex
import sqlite3
import subprocess
from contextlib import closing
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from arxiv_browser.models import Paper, UserConfig

logger = logging.getLogger(__name__)
LLM_COMMAND_TIMEOUT = 120  # Seconds to wait for LLM CLI response
SUMMARY_DB_FILENAME = "summaries.db"
RELEVANCE_DB_FILENAME = "relevance.db"

# ============================================================================
# LLM Prompt Templates & Presets
# ============================================================================

DEFAULT_LLM_PROMPT = (
    "You are an expert science communicator who makes complex research accessible. "
    "Summarize the following arXiv paper for a Computer Science university student "
    "who may not be an expert in this specific subfield. "
    "Avoid jargon where possible; when technical terms are necessary, briefly "
    "explain them in parentheses. Keep the TOTAL response under 400 words.\n\n"
    "## Problem\n"
    "What real-world or theoretical problem does this paper address, and why does "
    "it matter? (2-3 sentences)\n\n"
    "## Approach\n"
    "Explain the key idea and methodology at a high level. Focus on the intuition — "
    "what makes the approach work? (3-5 sentences)\n\n"
    "## Results\n"
    "What did the authors demonstrate? Mention key experiments or findings and how "
    "they compare to previous work. (2-3 sentences)\n\n"
    "## Limitations\n"
    "What are the main limitations or open questions? (2-3 sentences)\n\n"
    "## Key Takeaway\n"
    "In one sentence, what should the reader remember about this paper?\n\n"
    "---\n"
    "Paper: {title}\n"
    "Authors: {authors}\n"
    "Categories: {categories}\n\n"
    "{paper_content}"
)

LLM_PRESETS: dict[str, str] = {
    "claude": "claude -p {prompt}",
    "codex": "codex exec {prompt}",
    "llm": "llm {prompt}",
    "copilot": "copilot --model gpt-5-mini -p {prompt}",
    "opencode": "opencode run -m zai-coding-plan/glm-4.7 -- {prompt}",
}

# Structured summary mode templates
SUMMARY_MODES: dict[str, tuple[str, str]] = {
    "default": (
        "Full summary (Problem / Approach / Results)",
        DEFAULT_LLM_PROMPT,
    ),
    "quick": (
        "Quick abstract-only summary",
        "Provide a concise 3-5 sentence summary focused on key contribution, method, "
        "and main result. Keep it direct and easy to scan.\n\n"
        "Paper: {title}\nAuthors: {authors}\nCategories: {categories}\n\n"
        "{paper_content}",
    ),
    "tldr": (
        "1-2 sentence TLDR",
        "Provide a 1-2 sentence TLDR summary of this paper. Be concise and capture "
        "the key contribution.\n\n"
        "Paper: {title}\nAuthors: {authors}\nCategories: {categories}\n\n"
        "{paper_content}",
    ),
    "methods": (
        "Technical methodology deep-dive",
        "Analyze the technical methodology of this paper in detail (~500 words). "
        "Focus on:\n"
        "1. The core algorithm or technique\n"
        "2. Key mathematical formulations or architectural choices\n"
        "3. Training/optimization details\n"
        "4. How it differs from prior approaches\n\n"
        "Paper: {title}\nAuthors: {authors}\nCategories: {categories}\n\n"
        "{paper_content}",
    ),
    "results": (
        "Key experimental results with numbers",
        "Summarize the key experimental results of this paper. Focus on:\n"
        "1. Main benchmarks and datasets used\n"
        "2. Quantitative results (accuracy, speedup, etc.) with specific numbers\n"
        "3. Comparisons with baselines and state-of-the-art\n"
        "4. Ablation study findings\n\n"
        "Paper: {title}\nAuthors: {authors}\nCategories: {categories}\n\n"
        "{paper_content}",
    ),
    "comparison": (
        "Comparison with related work",
        "Compare this paper with related work in the field. Focus on:\n"
        "1. What prior approaches exist for this problem\n"
        "2. How this paper's method differs from each\n"
        "3. Advantages and disadvantages vs alternatives\n"
        "4. Where this work fits in the broader research landscape\n\n"
        "Paper: {title}\nAuthors: {authors}\nCategories: {categories}\n\n"
        "{paper_content}",
    ),
    "eli5": (
        "Explain Like I'm 5",
        "Explain this arXiv paper like the reader is five years old, while "
        "staying faithful to what the paper actually says.\n"
        "Rules:\n"
        "1. Use everyday words and short sentences.\n"
        "2. Do not use jargon or unexplained acronyms.\n"
        "3. Include exactly one concrete analogy that captures the main idea.\n"
        "4. Explain why the paper matters without hype.\n"
        "5. Mention one limitation or open question in plain language.\n\n"
        "Use concise Markdown with these sections:\n"
        "## Big Idea\n"
        "## Analogy\n"
        "## What They Tried\n"
        "## What They Found\n"
        "## One Caveat\n\n"
        "Paper: {title}\nAuthors: {authors}\nCategories: {categories}\n\n"
        "{paper_content}",
    ),
    "phd": (
        "Explain to a PhD in another field",
        "Explain this arXiv paper to a PhD-level researcher in {phd_field} who "
        "is not an expert in this paper's specific subfield.\n"
        "Assume strong mathematical and scientific maturity, but translate "
        "subfield-specific jargon into concepts a {phd_field} researcher would "
        "likely know. Use analogies to {phd_field} only when they are accurate; "
        "avoid forced comparisons when they would mislead.\n\n"
        "Use concise Markdown with these sections:\n"
        "## Problem Translation\n"
        "## Core Method\n"
        "## Field Analogy\n"
        "## Evidence\n"
        "## Limitations\n"
        "## Takeaway\n\n"
        "Paper: {title}\nAuthors: {authors}\nCategories: {categories}\n\n"
        "{paper_content}",
    ),
}
DEFAULT_PHD_EXPLAINER_FIELD = "physics"
_PHD_EXPLAINER_FIELD_PLACEHOLDER = "{phd_field}"
_SUMMARY_MODE_DISPLAY_LABELS = {
    "default": "",
    "eli5": "ELI5",
    "phd": "PhD",
}

RELEVANCE_PROMPT_TEMPLATE = (
    "Rate this paper's relevance to the research interests below.\n"
    'Return ONLY valid JSON: {{"score": N, "reason": "..."}}\n'
    "- score: integer 1-10 (10 = highly relevant)\n"
    "- reason: 1 sentence explaining the rating\n\n"
    "Research interests: {interests}\n\n"
    "Title: {title}\n"
    "Authors: {authors}\n"
    "Categories: {categories}\n"
    "Abstract: {abstract}\n"
)

AUTO_TAG_PROMPT_TEMPLATE = (
    "Suggest tags for this academic paper based on the taxonomy below.\n"
    'Return ONLY valid JSON: {{"tags": ["tag1", "tag2", ...]}}\n'
    "- Use the namespace:value format (e.g. topic:llm, method:quantization)\n"
    "- Prefer existing tags from the taxonomy when they fit\n"
    "- Suggest 2-5 tags total\n"
    "- Tags should be lowercase, concise (1-3 words), and use hyphens for multi-word values\n\n"
    "Existing taxonomy: {taxonomy}\n\n"
    "Title: {title}\n"
    "Authors: {authors}\n"
    "Categories: {categories}\n"
    "Abstract: {abstract}\n"
)

PAPER_REMIX_PROMPT_TEMPLATE = (
    "You are a research ideation assistant. Propose one novel, testable research "
    "direction that synthesizes the papers below.\n"
    "Use only the supplied metadata and abstracts. Do not overclaim novelty; frame "
    "the idea as a hypothesis to investigate.\n"
    "Keep the response under 600 words and return concise Markdown with exactly "
    "these sections:\n"
    "# Synthesis Title\n"
    "## Core Idea\n"
    "## Why It Is Interesting\n"
    "## Concrete Experiment\n"
    "## Risks\n"
    "## Next Step\n\n"
    "Research interests: {research_interests}\n\n"
    "Papers:\n"
    "{papers}\n"
)

PAPER_COMPARISON_CONTENT_MAX_CHARS = 12_000
PAPER_COMPARISON_PROMPT_TEMPLATE = (
    "You are a careful research assistant comparing 2-3 arXiv papers.\n"
    "Use only the supplied metadata and paper context. If a method, result, or "
    "difference is not stated in the provided context, write "
    '"Not stated in provided context" instead of guessing.\n'
    "Keep the response under 700 words and return concise Markdown with exactly "
    "these sections:\n"
    "## Methods\n"
    "## Results\n"
    "## Key Differences\n"
    "## Bottom Line\n\n"
    "Papers:\n"
    "{papers}\n"
)

PAPER_DEBATE_CONTENT_MAX_CHARS = 12_000
PAPER_DEBATE_ADVOCATE_PROMPT_TEMPLATE = (
    "You are the enthusiastic advocate in a two-person research debate about "
    "one arXiv paper.\n"
    "Use only the supplied paper context. If evidence for a claim is missing, "
    'write "Not stated in provided context" instead of guessing.\n'
    "Make the strongest fair case for why this paper matters. Be excited, but "
    "do not overclaim beyond the context.\n"
    "Keep the response under 350 words and return concise Markdown with exactly "
    "these sections:\n"
    "## Why This Could Matter\n"
    "## Strongest Contributions\n"
    "## Best-Case Impact\n\n"
    "Paper:\n"
    "{paper_context}\n"
)
PAPER_DEBATE_REVIEWER_PROMPT_TEMPLATE = (
    "You are Reviewer 2 in a two-person research debate about one arXiv paper.\n"
    "Use only the supplied paper context and the advocate's claims. If evidence "
    'for a critique is missing, write "Not stated in provided context" instead '
    "of guessing.\n"
    "Be harsh, concrete, and useful. Focus on unfair baselines, inadequate sample "
    "size or evaluation, shaky assumptions, reproducibility gaps, missing "
    "ablations, unclear novelty, and threats to validity.\n"
    "Keep the response under 450 words and return concise Markdown with exactly "
    "these sections:\n"
    "## Main Objections\n"
    "## Baseline And Evaluation Concerns\n"
    "## Missing Evidence\n"
    "## Verdict\n\n"
    "Paper:\n"
    "{paper_context}\n\n"
    "Advocate claims:\n"
    "{advocate_response}\n"
)

CHAT_SYSTEM_PROMPT = (
    "You are a helpful research assistant. Answer questions about this paper.\n"
    "Be concise and specific. Reference paper details when relevant.\n\n"
    "Paper: {title}\nAuthors: {authors}\nCategories: {categories}\n\n"
    "{paper_content}"
)


@dataclass(slots=True, frozen=True)
class PaperDebateResult:
    """Role-separated output for a paper debate."""

    advocate: str
    reviewer: str


# ============================================================================
# LLM Summary Persistence (SQLite)
# ============================================================================


def get_summary_db_path() -> Path:
    """Get the path to the summary SQLite database."""
    from arxiv_browser.database import resolve_db_path

    return resolve_db_path(SUMMARY_DB_FILENAME)


def _init_summary_db(db_path: Path) -> None:
    """Create the summaries table with composite PK if it doesn't exist.

    Migrates from old single-PK schema (arxiv_id only) to composite PK
    (arxiv_id, command_hash) to support multiple summary modes per paper.

    Args:
        db_path: Filesystem path to the SQLite database file.  The parent
            directory is created with ``mkdir(parents=True, exist_ok=True)``
            if it does not already exist.

    Raises:
        sqlite3.OperationalError: If the parent directory cannot be created
            (e.g. permission denied).
    """
    try:
        db_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise sqlite3.OperationalError(f"Cannot create DB directory: {e}") from e
    with closing(sqlite3.connect(str(db_path))) as conn, conn:
        # Check if table exists with old schema (single PK on arxiv_id)
        row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='summaries'"
        ).fetchone()
        if row and "PRIMARY KEY (arxiv_id, command_hash)" not in row[0]:
            conn.execute("DROP TABLE summaries")
        conn.execute(
            "CREATE TABLE IF NOT EXISTS summaries ("
            "  arxiv_id TEXT NOT NULL,"
            "  command_hash TEXT NOT NULL,"
            "  summary TEXT NOT NULL,"
            "  created_at TEXT NOT NULL,"
            "  PRIMARY KEY (arxiv_id, command_hash)"
            ")"
        )


def _load_summary(db_path: Path, arxiv_id: str, command_hash: str) -> str | None:
    """Load a cached summary if it exists and the command hash matches.

    Args:
        db_path: Path to the summaries SQLite database.
        arxiv_id: Bare arXiv identifier (e.g. ``"2401.12345"``).
        command_hash: 16-character hex hash of the command+prompt templates,
            used to invalidate cached summaries when config changes.

    Returns:
        The cached summary string, or ``None`` if no matching row exists or
        the database cannot be read.
    """
    if not db_path.exists():
        return None
    try:
        with closing(sqlite3.connect(str(db_path))) as conn, conn:
            row = conn.execute(
                "SELECT summary FROM summaries WHERE arxiv_id = ? AND command_hash = ?",
                (arxiv_id, command_hash),
            ).fetchone()
            return row[0] if row else None
    except sqlite3.Error:
        logger.warning("Failed to load summary for %s", arxiv_id, exc_info=True)
        return None


def _save_summary(db_path: Path, arxiv_id: str, summary: str, command_hash: str) -> None:
    """Persist a summary to the SQLite database.

    Args:
        db_path: Path to the summaries SQLite database.
        arxiv_id: Bare arXiv identifier (e.g. ``"2401.12345"``).
        summary: Full summary text to store.
        command_hash: 16-character hex hash of the command+prompt templates
            (see ``_compute_command_hash``).
    """
    try:
        _init_summary_db(db_path)
        with closing(sqlite3.connect(str(db_path))) as conn, conn:
            conn.execute(
                "INSERT OR REPLACE INTO summaries (arxiv_id, summary, command_hash, created_at) "
                "VALUES (?, ?, ?, ?)",
                (arxiv_id, summary, command_hash, datetime.now(UTC).isoformat()),
            )
    except sqlite3.Error:
        logger.warning("Failed to save summary for %s", arxiv_id, exc_info=True)


def _compute_command_hash(command_template: str, prompt_template: str) -> str:
    """Hash the command + prompt templates to detect config changes.

    The hash is used as a secondary key in the summary and relevance databases
    so that cached results are automatically invalidated when either the LLM
    command or the prompt template changes.

    Args:
        command_template: The raw LLM CLI command string (may contain
            ``{prompt}`` placeholder).
        prompt_template: The prompt template string used to build the LLM
            input.

    Returns:
        A 16-character hexadecimal string (truncated SHA-256 digest of
        ``"{command_template}|{prompt_template}"``).
    """
    key = f"{command_template}|{prompt_template}"
    return hashlib.sha256(key.encode()).hexdigest()[:16]


# ============================================================================
# Relevance Scoring Persistence (SQLite)
# ============================================================================


def get_relevance_db_path() -> Path:
    """Get the path to the relevance scoring SQLite database."""
    from arxiv_browser.database import resolve_db_path

    return resolve_db_path(RELEVANCE_DB_FILENAME)


def _init_relevance_db(db_path: Path) -> None:
    """Create the relevance_scores table if it doesn't exist.

    Args:
        db_path: Filesystem path to the SQLite database file.  The parent
            directory is created with ``mkdir(parents=True, exist_ok=True)``
            if it does not already exist.

    Raises:
        sqlite3.OperationalError: If the parent directory cannot be created
            (e.g. permission denied).
    """
    try:
        db_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise sqlite3.OperationalError(f"Cannot create DB directory: {e}") from e
    with closing(sqlite3.connect(str(db_path))) as conn, conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS relevance_scores ("
            "  arxiv_id TEXT NOT NULL,"
            "  interests_hash TEXT NOT NULL,"
            "  score INTEGER NOT NULL,"
            "  reason TEXT NOT NULL,"
            "  created_at TEXT NOT NULL,"
            "  PRIMARY KEY (arxiv_id, interests_hash)"
            ")"
        )


def _load_relevance_score(
    db_path: Path, arxiv_id: str, interests_hash: str
) -> tuple[int, str] | None:
    """Load a cached relevance score if it exists.

    Args:
        db_path: Path to the relevance SQLite database.
        arxiv_id: Bare arXiv identifier (e.g. ``"2401.12345"``).
        interests_hash: 16-character hex hash of the user's research interests
            string, used to invalidate scores when interests change.

    Returns:
        A ``(score, reason)`` tuple where ``score`` is 1-10 and ``reason`` is
        the LLM's one-sentence explanation, or ``None`` if no matching row
        exists or the database cannot be read.
    """
    if not db_path.exists():
        return None
    try:
        with closing(sqlite3.connect(str(db_path))) as conn, conn:
            row = conn.execute(
                "SELECT score, reason FROM relevance_scores "
                "WHERE arxiv_id = ? AND interests_hash = ?",
                (arxiv_id, interests_hash),
            ).fetchone()
            return (row[0], row[1]) if row else None
    except sqlite3.Error:
        logger.warning("Failed to load relevance score for %s", arxiv_id, exc_info=True)
        return None


def _save_relevance_score(
    db_path: Path, arxiv_id: str, interests_hash: str, score: int, reason: str
) -> None:
    """Persist a relevance score to the SQLite database.

    Args:
        db_path: Path to the relevance SQLite database.
        arxiv_id: Bare arXiv identifier (e.g. ``"2401.12345"``).
        interests_hash: 16-character hex hash of the user's research interests.
        score: Integer relevance score in the range 1-10.
        reason: One-sentence explanation from the LLM.
    """
    try:
        _init_relevance_db(db_path)
        with closing(sqlite3.connect(str(db_path))) as conn, conn:
            conn.execute(
                "INSERT OR REPLACE INTO relevance_scores "
                "(arxiv_id, interests_hash, score, reason, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (arxiv_id, interests_hash, score, reason, datetime.now(UTC).isoformat()),
            )
    except sqlite3.Error:
        logger.warning("Failed to save relevance score for %s", arxiv_id, exc_info=True)


def _load_all_relevance_scores(db_path: Path, interests_hash: str) -> dict[str, tuple[int, str]]:
    """Bulk-load all relevance scores for a given interests hash.

    Args:
        db_path: Path to the relevance SQLite database.
        interests_hash: 16-character hex hash of the user's research interests,
            used to select only scores computed under the current interests.

    Returns:
        Mapping from bare arXiv ID to ``(score, reason)`` tuples.  Returns an
        empty dict if the database does not exist or cannot be read.
    """
    if not db_path.exists():
        return {}
    try:
        with closing(sqlite3.connect(str(db_path))) as conn, conn:
            rows = conn.execute(
                "SELECT arxiv_id, score, reason FROM relevance_scores WHERE interests_hash = ?",
                (interests_hash,),
            ).fetchall()
            return {row[0]: (row[1], row[2]) for row in rows}
    except sqlite3.Error:
        logger.warning("Failed to bulk-load relevance scores", exc_info=True)
        return {}


# ============================================================================
# Relevance Scoring Prompt & Response Parsing
# ============================================================================

# Pre-compiled patterns for parsing LLM relevance JSON responses
_RELEVANCE_SCORE_RE = re.compile(r'"score"\s*:\s*(\d+)')
_RELEVANCE_REASON_RE = re.compile(r'"reason"\s*:\s*"([^"]+)"')
_MARKDOWN_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)


def build_relevance_prompt(paper: Paper, interests: str) -> str:
    """Build a relevance scoring prompt for a paper.

    Uses the RELEVANCE_PROMPT_TEMPLATE, substituting paper fields and interests.
    """
    abstract = paper.abstract or paper.abstract_raw or "(no abstract)"
    return RELEVANCE_PROMPT_TEMPLATE.format(
        title=paper.title,
        authors=paper.authors,
        categories=paper.categories,
        abstract=abstract,
        interests=interests,
    )


def _parse_relevance_response(text: str) -> tuple[int, str] | None:
    """Parse the LLM's relevance scoring response.

    Tries multiple strategies:
    1. Direct JSON parse
    2. Strip markdown fences then JSON parse
    3. Regex fallback for score and reason fields

    Args:
        text: Raw LLM output string, expected to contain JSON like
            ``{"score": 7, "reason": "..."}``.

    Returns:
        ``(score, reason)`` tuple where ``score`` is clamped to 1-10, or
        ``None`` if all parsing strategies fail.
    """
    stripped = text.strip()

    # Strategy 1: direct JSON parse
    try:
        data = json.loads(stripped)
        if isinstance(data, dict) and "score" in data:
            score = max(1, min(10, int(data["score"])))
            reason = str(data.get("reason", ""))
            return (score, reason)
    except (json.JSONDecodeError, ValueError, TypeError):
        pass

    # Strategy 2: strip markdown fences
    fence_match = _MARKDOWN_FENCE_RE.search(stripped)
    if fence_match:
        try:
            data = json.loads(fence_match.group(1))
            if isinstance(data, dict) and "score" in data:
                score = max(1, min(10, int(data["score"])))
                reason = str(data.get("reason", ""))
                return (score, reason)
        except (json.JSONDecodeError, ValueError, TypeError):
            pass

    # Strategy 3: regex fallback
    score_match = _RELEVANCE_SCORE_RE.search(stripped)
    reason_match = _RELEVANCE_REASON_RE.search(stripped)
    if score_match:
        score = max(1, min(10, int(score_match.group(1))))
        reason = reason_match.group(1) if reason_match else ""
        return (score, reason)

    logger.debug("Relevance parse failed for response: %.300s", stripped)
    return None


# ============================================================================
# Auto-Tagging Prompt & Response Parsing
# ============================================================================

_AUTO_TAG_TAGS_RE = re.compile(r'"tags"\s*:\s*\[([^\]]*)\]')


def build_auto_tag_prompt(paper: Paper, existing_tags: list[str]) -> str:
    """Build an auto-tagging prompt for a paper.

    Uses AUTO_TAG_PROMPT_TEMPLATE, substituting paper fields and existing taxonomy.
    """
    abstract = paper.abstract or paper.abstract_raw or "(no abstract)"
    taxonomy = ", ".join(existing_tags) if existing_tags else "(no existing tags — create new ones)"
    return AUTO_TAG_PROMPT_TEMPLATE.format(
        title=paper.title,
        authors=paper.authors,
        categories=paper.categories,
        abstract=abstract,
        taxonomy=taxonomy,
    )


# ============================================================================
# Paper Remix Prompt
# ============================================================================


def _format_paper_remix_source(index: int, paper: Paper) -> str:
    abstract = paper.abstract or paper.abstract_raw or "(no abstract)"
    return (
        f"Paper {index}\n"
        f"Title: {paper.title}\n"
        f"Authors: {paper.authors}\n"
        f"Categories: {paper.categories}\n"
        f"Abstract: {abstract}"
    )


def build_paper_remix_prompt(papers: list[Paper], research_interests: str = "") -> str:
    """Build a prompt that asks the LLM to synthesize 2-3 papers into one idea."""
    if len(papers) not in {2, 3}:
        raise ValueError("Paper remix requires exactly 2 or 3 papers")
    interests = research_interests.strip() or "(not specified)"
    paper_blocks = "\n\n".join(
        _format_paper_remix_source(index, paper) for index, paper in enumerate(papers, start=1)
    )
    return PAPER_REMIX_PROMPT_TEMPLATE.format(
        research_interests=interests,
        papers=paper_blocks,
    )


def _format_paper_comparison_source(index: int, paper: Paper, content: str) -> str:
    context = (
        content.strip() or paper.abstract or paper.abstract_raw or "Not stated in provided context"
    )
    return (
        f"Paper {index}\n"
        f"arXiv: {paper.arxiv_id}\n"
        f"Title: {paper.title}\n"
        f"Authors: {paper.authors}\n"
        f"Date: {paper.date}\n"
        f"Categories: {paper.categories}\n"
        f"Comments: {paper.comments or 'None'}\n"
        f"Context:\n{context}"
    )


def build_paper_comparison_prompt(
    papers: list[Paper],
    paper_contents: list[str] | None = None,
    max_content_chars: int = PAPER_COMPARISON_CONTENT_MAX_CHARS,
) -> str:
    """Build a prompt that asks the LLM to compare 2-3 papers."""
    if len(papers) not in {2, 3}:
        raise ValueError("Paper comparison requires exactly 2 or 3 papers")
    contents = paper_contents or []
    clipped_contents = [
        (contents[index] if index < len(contents) else "")[:max_content_chars]
        for index in range(len(papers))
    ]
    paper_blocks = "\n\n".join(
        _format_paper_comparison_source(index, paper, clipped_contents[index - 1])
        for index, paper in enumerate(papers, start=1)
    )
    return PAPER_COMPARISON_PROMPT_TEMPLATE.format(papers=paper_blocks)


def _format_paper_debate_context(
    paper: Paper,
    paper_content: str,
    max_content_chars: int,
) -> str:
    context = (
        paper_content.strip()
        or paper.abstract
        or paper.abstract_raw
        or "Not stated in provided context"
    )
    return (
        f"arXiv: {paper.arxiv_id}\n"
        f"Title: {paper.title}\n"
        f"Authors: {paper.authors}\n"
        f"Date: {paper.date}\n"
        f"Categories: {paper.categories}\n"
        f"Comments: {paper.comments or 'None'}\n"
        f"Context:\n{context[:max_content_chars]}"
    )


def build_paper_debate_advocate_prompt(
    paper: Paper,
    paper_content: str,
    max_content_chars: int = PAPER_DEBATE_CONTENT_MAX_CHARS,
) -> str:
    """Build the first debate prompt: the strongest fair advocate case."""
    paper_context = _format_paper_debate_context(paper, paper_content, max_content_chars)
    return PAPER_DEBATE_ADVOCATE_PROMPT_TEMPLATE.format(paper_context=paper_context)


def build_paper_debate_reviewer_prompt(
    paper: Paper,
    paper_content: str,
    advocate_response: str,
    max_content_chars: int = PAPER_DEBATE_CONTENT_MAX_CHARS,
) -> str:
    """Build the second debate prompt: Reviewer 2 responds to the advocate."""
    paper_context = _format_paper_debate_context(paper, paper_content, max_content_chars)
    return PAPER_DEBATE_REVIEWER_PROMPT_TEMPLATE.format(
        paper_context=paper_context,
        advocate_response=advocate_response.strip(),
    )


def _extract_tags_from_json(data: Any) -> list[str] | None:
    """Extract and normalize tags from a parsed JSON object.

    Returns lowercased, stripped tag strings if data contains a valid "tags" list,
    or None otherwise.
    """
    if isinstance(data, dict) and "tags" in data:
        tags = data["tags"]
        if isinstance(tags, list):
            if not tags:
                return []
            normalized: list[str] = []
            seen: set[str] = set()
            for tag in tags:
                if not isinstance(tag, str):
                    continue
                cleaned = tag.strip().lower()
                if not cleaned or cleaned in seen:
                    continue
                seen.add(cleaned)
                normalized.append(cleaned)
            return normalized or None
    return None


def _parse_auto_tag_response(text: str) -> list[str] | None:
    """Parse the LLM's auto-tag response.

    Tries multiple strategies:
    1. Direct JSON parse
    2. Strip markdown fences then JSON parse
    3. Regex fallback for tags array

    Args:
        text: Raw LLM output string, expected to contain JSON like
            ``{"tags": ["topic:llm", "method:quantization"]}``.

    Returns:
        List of lowercased, stripped tag strings, or ``None`` if all parsing
        strategies fail.
    """
    stripped = text.strip()

    # Strategy 1: direct JSON parse
    try:
        result = _extract_tags_from_json(json.loads(stripped))
        if result is not None:
            return result
    except (json.JSONDecodeError, ValueError, TypeError):
        pass

    # Strategy 2: strip markdown fences
    fence_match = _MARKDOWN_FENCE_RE.search(stripped)
    if fence_match:
        try:
            result = _extract_tags_from_json(json.loads(fence_match.group(1)))
            if result is not None:
                return result
        except (json.JSONDecodeError, ValueError, TypeError):
            pass

    # Strategy 3: regex fallback
    tags_match = _AUTO_TAG_TAGS_RE.search(stripped)
    if tags_match:
        raw_items = tags_match.group(1)
        items = re.findall(r'"([^"]*)"', raw_items)
        if items:
            return [t.strip().lower() for t in items if t.strip()]

    logger.debug("Auto-tag parse failed for response: %.300s", stripped)
    return None


# ============================================================================
# LLM Prompt Building & Command Resolution
# ============================================================================

_LLM_PROMPT_FIELDS = frozenset(
    {
        "title",
        "authors",
        "categories",
        "abstract",
        "arxiv_id",
        "paper_content",
    }
)

# Match {name} but not {{ (escaped braces)
_TEMPLATE_FIELD_RE = re.compile(r"\{(?!\{)([^{}]+)\}(?!\})")


def validate_prompt_template(template: str) -> list[str]:
    """Validate that a prompt template only uses approved placeholders.

    Returns a list of invalid placeholder names found (empty if all valid).
    """
    found = set(_TEMPLATE_FIELD_RE.findall(template))
    invalid = sorted(found - _LLM_PROMPT_FIELDS)
    return invalid


def build_llm_prompt(paper: Paper, prompt_template: str = "", paper_content: str = "") -> str:
    """Build the full prompt by substituting paper data into the template.

    If paper_content is provided, it is included via the {paper_content}
    placeholder.  When the template does not contain that placeholder the
    content is appended automatically so that every prompt benefits from
    full-paper context when available.
    """
    template = prompt_template or DEFAULT_LLM_PROMPT
    abstract = paper.abstract or paper.abstract_raw or "(no abstract)"
    # When no full paper content is available, fall back to a labelled abstract
    # block so the LLM still receives meaningful context.
    content = paper_content or f"Abstract:\n{abstract}"
    values = {
        "title": paper.title,
        "authors": paper.authors,
        "categories": paper.categories,
        "abstract": abstract,
        "arxiv_id": paper.arxiv_id,
        "paper_content": content,
    }
    try:
        result = template.format(**values)
    except (KeyError, ValueError, IndexError) as e:
        raise ValueError(
            f"Invalid prompt template: {e}. "
            f"Valid placeholders: {', '.join(f'{{{k}}}' for k in sorted(_LLM_PROMPT_FIELDS))}"
        ) from e
    # Auto-append paper content if the template didn't include {paper_content}.
    # This ensures every prompt benefits from full-paper context even when the
    # user's custom template omits the placeholder.
    if "{paper_content}" not in template and content:
        result = result + "\n\n" + content
    return result


def resolve_summary_prompt_template(
    mode: str,
    *,
    custom_default_prompt: str = "",
    phd_explainer_field: str = DEFAULT_PHD_EXPLAINER_FIELD,
) -> str:
    """Return the effective prompt template for a built-in summary mode."""
    if mode == "default" and custom_default_prompt:
        return custom_default_prompt
    prompt_template = SUMMARY_MODES[mode][1]
    if mode != "phd":
        return prompt_template
    return prompt_template.replace(
        _PHD_EXPLAINER_FIELD_PLACEHOLDER,
        _escape_format_literal(_normalize_phd_explainer_field(phd_explainer_field)),
    )


def summary_mode_display_label(mode: str) -> str:
    return _SUMMARY_MODE_DISPLAY_LABELS.get(mode, mode.upper())


def _normalize_phd_explainer_field(value: str) -> str:
    if not isinstance(value, str):
        return DEFAULT_PHD_EXPLAINER_FIELD
    return value.strip() or DEFAULT_PHD_EXPLAINER_FIELD


def _escape_format_literal(value: str) -> str:
    return value.replace("{", "{{").replace("}", "}}")


def _resolve_llm_command(config: UserConfig) -> str:
    """Resolve the LLM command template from config (custom or preset).

    Args:
        config: The application's ``UserConfig`` instance.  Reads
            ``llm_command`` (checked first) and ``llm_preset`` (used as
            fallback via ``LLM_PRESETS`` lookup).

    Returns:
        The command template string (e.g. ``"llm {prompt}"``), or ``""`` if
        neither ``llm_command`` nor a recognised ``llm_preset`` is set.
    """
    if config.llm_command:
        return config.llm_command
    if config.llm_preset:
        if config.llm_preset in LLM_PRESETS:
            return LLM_PRESETS[config.llm_preset]
        valid = ", ".join(sorted(LLM_PRESETS))
        logger.warning("Unknown llm_preset %r. Valid presets: %s", config.llm_preset, valid)
    return ""


def _build_llm_shell_command(command_template: str, prompt: str) -> str:
    """Build the final shell command by substituting the prompt.

    Uses platform-native shell quoting (``shlex.quote`` on POSIX,
    ``subprocess.list2cmdline`` on Windows) to safely embed the prompt.

    Args:
        command_template: Raw command string containing a ``{prompt}``
            placeholder (e.g. ``"llm {prompt}"``).
        prompt: The resolved prompt text to embed in the command.

    Returns:
        A shell-safe command string ready for
        ``asyncio.create_subprocess_shell``.

    Raises:
        ValueError: If ``command_template`` does not contain ``{prompt}``.
    """
    if "{prompt}" not in command_template:
        raise ValueError(
            f"LLM command template must contain {{prompt}} placeholder, got: {command_template!r}"
        )
    # Use platform-native shell quoting semantics.
    # On Windows (os.name == "nt") use list2cmdline for cmd.exe; on POSIX use shlex.quote.
    # Use str.replace instead of str.format to avoid brace-collision with prompts that
    # themselves contain literal {…} characters.
    escaped_prompt = subprocess.list2cmdline([prompt]) if os.name == "nt" else shlex.quote(prompt)
    return command_template.replace("{prompt}", escaped_prompt)


__all__ = [
    "AUTO_TAG_PROMPT_TEMPLATE",
    "CHAT_SYSTEM_PROMPT",
    "DEFAULT_LLM_PROMPT",
    "LLM_PRESETS",
    "PAPER_COMPARISON_CONTENT_MAX_CHARS",
    "PAPER_COMPARISON_PROMPT_TEMPLATE",
    "PAPER_DEBATE_ADVOCATE_PROMPT_TEMPLATE",
    "PAPER_DEBATE_CONTENT_MAX_CHARS",
    "PAPER_DEBATE_REVIEWER_PROMPT_TEMPLATE",
    "PAPER_REMIX_PROMPT_TEMPLATE",
    "RELEVANCE_PROMPT_TEMPLATE",
    "SUMMARY_MODES",
    "PaperDebateResult",
    "build_auto_tag_prompt",
    "build_llm_prompt",
    "build_paper_comparison_prompt",
    "build_paper_debate_advocate_prompt",
    "build_paper_debate_reviewer_prompt",
    "build_paper_remix_prompt",
    "build_relevance_prompt",
    "get_relevance_db_path",
    "get_summary_db_path",
    "resolve_summary_prompt_template",
    "summary_mode_display_label",
    "validate_prompt_template",
]
