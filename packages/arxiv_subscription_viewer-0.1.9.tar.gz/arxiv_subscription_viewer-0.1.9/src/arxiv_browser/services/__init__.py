"""Internal service layer for app orchestration extraction."""

from arxiv_browser.services.arxiv_api_service import (
    enforce_rate_limit,
    fetch_page,
    format_query_label,
)
from arxiv_browser.services.download_service import download_pdf
from arxiv_browser.services.enrichment_service import (
    load_or_fetch_hf_daily_cached,
    load_or_fetch_hf_daily_result,
    load_or_fetch_s2_paper_cached,
    load_or_fetch_s2_paper_result,
    load_or_fetch_s2_recommendations_cached,
    load_or_fetch_s2_recommendations_result,
)
from arxiv_browser.services.interfaces import (
    AppServices,
    ArxivApiService,
    DownloadService,
    EnrichmentService,
    LlmService,
    build_default_app_services,
)
from arxiv_browser.services.llm_service import (
    compare_papers,
    generate_summary,
    score_relevance_once,
    suggest_tags_once,
)

__all__ = [
    "AppServices",
    "ArxivApiService",
    "DownloadService",
    "EnrichmentService",
    "LlmService",
    "build_default_app_services",
    "compare_papers",
    "download_pdf",
    "enforce_rate_limit",
    "fetch_page",
    "format_query_label",
    "generate_summary",
    "load_or_fetch_hf_daily_cached",
    "load_or_fetch_hf_daily_result",
    "load_or_fetch_s2_paper_cached",
    "load_or_fetch_s2_paper_result",
    "load_or_fetch_s2_recommendations_cached",
    "load_or_fetch_s2_recommendations_result",
    "score_relevance_once",
    "suggest_tags_once",
]
