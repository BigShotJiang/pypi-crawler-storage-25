"""Paper similarity — TF-IDF index, cosine + Jaccard similarity."""

from __future__ import annotations

import math
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from hashlib import sha256

from arxiv_browser.models import STOPWORDS, Paper, PaperMetadata, parse_arxiv_date

# ============================================================================
# Similarity Constants
# ============================================================================

SIMILARITY_TOP_N = 10  # Number of similar papers to show
SIMILARITY_RECENCY_WEIGHT = 0.08
SIMILARITY_STARRED_BOOST = 0.05
SIMILARITY_UNREAD_BOOST = 0.03
SIMILARITY_READ_PENALTY = 0.02
SIMILARITY_RECENCY_DAYS = 365
SIMILARITY_WEIGHT_CATEGORY = 0.30
SIMILARITY_WEIGHT_AUTHOR = 0.20
SIMILARITY_WEIGHT_TEXT = 0.50
SERENDIPITY_TOP_N = 5


@dataclass(frozen=True, slots=True)
class SerendipityRequest:
    """Inputs for ranking intentionally novel papers within a visible pool."""

    papers: list[Paper]
    metadata: dict[str, PaperMetadata] | None = None
    tfidf_index: TfidfIndex | None = None
    current_paper_id: str | None = None
    top_n: int = SERENDIPITY_TOP_N


@dataclass(frozen=True, slots=True)
class SerendipityCandidate:
    """One ranked paper surfaced by the serendipity engine."""

    paper: Paper
    score: float
    reason: str
    nearest_starred_anchor_id: str | None = None


# ============================================================================
# TF-IDF Index
# ============================================================================

_TFIDF_TOKEN_RE = re.compile(r"[a-z][a-z0-9]{2,}")


def _tokenize_for_tfidf(text: str | None) -> list[str]:
    """Tokenize text for TF-IDF, preserving term frequency.

    Tokens must be at least 3 characters, start with a letter, and not be
    in the stopword list.

    Args:
        text: Raw text to tokenize, or ``None``/empty string.

    Returns:
        List of lowercase alphanumeric tokens (may contain duplicates —
        duplicates are intentional to preserve raw term frequency).
    """
    if not text:
        return []
    return [tok for tok in _TFIDF_TOKEN_RE.findall(text.lower()) if tok not in STOPWORDS]


def _compute_tf(tokens: list[str]) -> dict[str, float]:
    """Compute sublinear term frequency: 1 + log(count)."""
    counts: dict[str, int] = {}
    for tok in tokens:
        counts[tok] = counts.get(tok, 0) + 1
    return {term: 1.0 + math.log(count) for term, count in counts.items()}


class TfidfIndex:
    """Sparse TF-IDF index for cosine similarity over a paper corpus."""

    __slots__ = ("_idf", "_norms", "_tfidf_vectors")

    def __init__(self) -> None:
        """Initialize an empty TF-IDF index."""
        self._idf: dict[str, float] = {}
        self._tfidf_vectors: dict[str, dict[str, float]] = {}
        self._norms: dict[str, float] = {}

    @staticmethod
    def build(papers: list[Paper], text_fn: Callable[[Paper], str]) -> TfidfIndex:
        """Build a TF-IDF index from a paper corpus.

        Uses sublinear TF (``1 + log(count)``) and a smoothed IDF formula
        (``log(1 + n / (1 + df))``).  L2 norms are pre-computed at build time
        so ``cosine_similarity`` only needs a dot-product and a lookup.

        Args:
            papers: Corpus of papers to index.
            text_fn: Callable that extracts the text to index from a paper
                (e.g. ``lambda p: f"{p.title} {p.abstract_raw}"``).

        Returns:
            A populated ``TfidfIndex``.  Returns an *empty* index (usable but
            all similarities will be ``0.0``) when fewer than 2 papers produce
            non-empty token lists — IDF requires at least 2 documents to be
            meaningful.
        """
        index = TfidfIndex()
        doc_tfs: dict[str, dict[str, float]] = {}
        df: dict[str, int] = {}
        for paper in papers:
            tokens = _tokenize_for_tfidf(text_fn(paper))
            if not tokens:
                continue
            tf = _compute_tf(tokens)
            doc_tfs[paper.arxiv_id] = tf
            for term in tf:
                df[term] = df.get(term, 0) + 1
        n = len(doc_tfs)
        if n < 2:
            # IDF requires at least 2 documents to be meaningful; return empty index
            return index
        # Smoothed IDF: log(1 + n / (1 + df)) prevents division by zero and
        # dampens the effect of very rare terms (the "+1" in the denominator).
        index._idf = {term: math.log(1 + n / (1 + freq)) for term, freq in df.items()}
        for arxiv_id, tf in doc_tfs.items():
            vec: dict[str, float] = {}
            norm_sq = 0.0
            for term, tf_val in tf.items():
                tfidf = tf_val * index._idf.get(term, 0.0)
                if tfidf > 0.0:
                    vec[term] = tfidf
                    norm_sq += tfidf * tfidf
            index._tfidf_vectors[arxiv_id] = vec
            # Pre-compute L2 norms so cosine_similarity only needs a dot product
            index._norms[arxiv_id] = math.sqrt(norm_sq) if norm_sq > 0.0 else 0.0
        return index

    def cosine_similarity(self, id_a: str, id_b: str) -> float:
        """Compute cosine similarity between two indexed papers.

        Iterates over the smaller of the two TF-IDF vectors for efficiency,
        using pre-computed L2 norms stored at build time.

        Args:
            id_a: arXiv ID of the first paper.
            id_b: arXiv ID of the second paper.

        Returns:
            Cosine similarity in ``[0.0, 1.0]``.  Returns ``0.0`` if either
            paper is not in the index or has a zero-norm vector.
        """
        vec_a = self._tfidf_vectors.get(id_a)
        vec_b = self._tfidf_vectors.get(id_b)
        if not vec_a or not vec_b:
            return 0.0
        norm_a = self._norms.get(id_a, 0.0)
        norm_b = self._norms.get(id_b, 0.0)
        if norm_a == 0.0 or norm_b == 0.0:
            return 0.0
        # Iterate over smaller vector for efficiency
        if len(vec_a) > len(vec_b):
            vec_a, vec_b = vec_b, vec_a
        dot = sum(w * vec_b.get(t, 0.0) for t, w in vec_a.items())
        return dot / (norm_a * norm_b)

    def __contains__(self, arxiv_id: str) -> bool:
        """Return True if the given arxiv_id is indexed."""
        return arxiv_id in self._tfidf_vectors

    def __len__(self) -> int:
        """Return the number of indexed papers."""
        return len(self._tfidf_vectors)


# ============================================================================
# Keyword & Author Extraction
# ============================================================================


def _extract_keywords(text: str | None, min_length: int = 4) -> set[str]:
    """Extract significant keywords from text, filtering stopwords."""
    if not text:
        return set()
    words = set()
    for word in text.lower().split():
        # Remove non-alphanumeric characters
        clean = "".join(c for c in word if c.isalnum())
        if len(clean) >= min_length and clean not in STOPWORDS:
            words.add(clean)
    return words


_AUTHOR_SPLIT_RE = re.compile(r",|(?:\s+and\s+)")


def _extract_author_lastnames(authors: str) -> set[str]:
    """Extract last names from author string."""
    lastnames = set()
    # Split by common separators
    for author in _AUTHOR_SPLIT_RE.split(authors):
        parts = author.strip().split()
        if parts:
            # Last word is typically the last name
            lastname = parts[-1].lower()
            # Remove non-alphanumeric
            lastname = "".join(c for c in lastname if c.isalnum())
            if lastname:
                lastnames.add(lastname)
    return lastnames


def _jaccard_similarity(set_a: set, set_b: set) -> float:
    """Calculate Jaccard similarity between two sets."""
    if not set_a and not set_b:
        return 0.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


# ============================================================================
# Paper Similarity Scoring
# ============================================================================


def compute_paper_similarity(
    paper_a: Paper,
    paper_b: Paper,
    abstract_a: str | None = None,
    abstract_b: str | None = None,
    tfidf_index: TfidfIndex | None = None,
) -> float:
    """Compute weighted similarity score between two papers.

    Two scoring modes are available depending on whether a TF-IDF index is
    provided:

    **TF-IDF mode** (when *tfidf_index* is given):
    ``SIMILARITY_WEIGHT_CATEGORY (0.30) * cat_sim``
    + ``SIMILARITY_WEIGHT_AUTHOR (0.20) * author_sim``
    + ``SIMILARITY_WEIGHT_TEXT (0.50) * cosine_sim``

    **Legacy Jaccard mode** (no index):
    ``0.40 * cat_sim + 0.30 * author_sim + 0.20 * title_kw_sim + 0.10 * abstract_kw_sim``

    Args:
        paper_a: First paper.
        paper_b: Second paper.
        abstract_a: Pre-cleaned abstract for *paper_a*.  Only used in legacy
            Jaccard mode; defaults to ``paper_a.abstract`` when ``None``.
        abstract_b: Pre-cleaned abstract for *paper_b*.  Only used in legacy
            Jaccard mode; defaults to ``paper_b.abstract`` when ``None``.
        tfidf_index: Pre-built TF-IDF index.  When provided, switches from
            pairwise Jaccard to TF-IDF cosine for the text component.

    Returns:
        Similarity score in ``[0.0, 1.0]``.  Returns ``1.0`` when both
        papers share the same arXiv ID.
    """
    if paper_a.arxiv_id == paper_b.arxiv_id:
        return 1.0

    # Category similarity
    cats_a = set(paper_a.categories.split())
    cats_b = set(paper_b.categories.split())
    cat_sim = _jaccard_similarity(cats_a, cats_b)

    # Author similarity
    authors_a = _extract_author_lastnames(paper_a.authors)
    authors_b = _extract_author_lastnames(paper_b.authors)
    author_sim = _jaccard_similarity(authors_a, authors_b)

    if tfidf_index is not None:
        # TF-IDF branch: text similarity from pre-built index
        text_sim = tfidf_index.cosine_similarity(paper_a.arxiv_id, paper_b.arxiv_id)
        # Weights: category 0.30, author 0.20, text 0.50
        return (
            SIMILARITY_WEIGHT_CATEGORY * cat_sim
            + SIMILARITY_WEIGHT_AUTHOR * author_sim
            + SIMILARITY_WEIGHT_TEXT * text_sim
        )

    # Legacy Jaccard branch: keyword overlap for title and abstract
    # Weights: category 0.40, author 0.30, title keywords 0.20, abstract keywords 0.10
    title_kw_a = _extract_keywords(paper_a.title)
    title_kw_b = _extract_keywords(paper_b.title)
    title_sim = _jaccard_similarity(title_kw_a, title_kw_b)

    if abstract_a is None:
        abstract_a = paper_a.abstract or ""
    if abstract_b is None:
        abstract_b = paper_b.abstract or ""
    abstract_kw_a = _extract_keywords(abstract_a)
    abstract_kw_b = _extract_keywords(abstract_b)
    abstract_sim = _jaccard_similarity(abstract_kw_a, abstract_kw_b)

    return 0.4 * cat_sim + 0.3 * author_sim + 0.2 * title_sim + 0.1 * abstract_sim


def build_similarity_corpus_key(papers: list[Paper]) -> str:
    """Build a deterministic fingerprint for a paper corpus.

    The fingerprint is used to detect when the corpus has changed (e.g. new
    papers loaded) so that a cached TF-IDF index can be invalidated.

    Args:
        papers: The corpus to fingerprint.

    Returns:
        First 16 hex characters of the SHA-256 digest over each paper's
        arXiv ID, title, and abstract (NUL-delimited).  The 16-character
        truncation is sufficient for cache-key purposes while keeping the
        string compact.
    """
    h = sha256()
    for paper in papers:
        abstract_text = paper.abstract if paper.abstract is not None else paper.abstract_raw
        h.update(paper.arxiv_id.encode("utf-8", errors="replace"))
        h.update(b"\x00")
        h.update(paper.title.encode("utf-8", errors="replace"))
        h.update(b"\x00")
        h.update((abstract_text or "").encode("utf-8", errors="replace"))
        h.update(b"\x00")
    return h.hexdigest()[:16]


def find_similar_papers(
    target: Paper,
    all_papers: list[Paper],
    top_n: int = SIMILARITY_TOP_N,
    metadata: dict[str, PaperMetadata] | None = None,
    abstract_lookup: Callable[[Paper], str] | None = None,
    tfidf_index: TfidfIndex | None = None,
) -> list[tuple[Paper, float]]:
    """Find the top N most similar papers to the target.

    Args:
        target: The paper to find similarities for
        all_papers: List of all papers to search
        top_n: Number of similar papers to return
        metadata: Per-paper metadata used for interest-based scoring boosts
            (starred/noted/tagged papers score higher)
        abstract_lookup: Callable returning abstract text for a paper; defaults
            to ``paper.abstract or ""``
        tfidf_index: Pre-built TF-IDF index for cosine similarity; when provided,
            switches from pairwise Jaccard to indexed TF-IDF scoring

    Returns:
        List of (paper, score) tuples, sorted by score descending
    """
    scored = []
    if abstract_lookup is None:

        def _default_abstract_lookup(paper: Paper) -> str:
            """Return the paper's abstract, defaulting to empty string."""
            return paper.abstract or ""

        abstract_lookup = _default_abstract_lookup

    use_tfidf = tfidf_index is not None
    target_abstract = abstract_lookup(target) if not use_tfidf else None

    newest_date = datetime.min
    for paper in all_papers:
        paper_date = parse_arxiv_date(paper.date)
        if paper_date > newest_date:
            newest_date = paper_date

    def metadata_boost(arxiv_id: str) -> float:
        """Compute a score boost from starred/read metadata signals."""
        if not metadata:
            return 0.0
        entry = metadata.get(arxiv_id)
        if not entry:
            return 0.0
        boost = 0.0
        if entry.starred:
            boost += SIMILARITY_STARRED_BOOST
        if entry.is_read:
            boost -= SIMILARITY_READ_PENALTY
        else:
            boost += SIMILARITY_UNREAD_BOOST
        return boost

    def recency_score(paper: Paper) -> float:
        """Compute a 0-1 recency score based on paper age relative to newest."""
        if newest_date == datetime.min:
            return 0.0
        paper_date = parse_arxiv_date(paper.date)
        if paper_date == datetime.min:
            return 0.0
        age_days = max(0, (newest_date - paper_date).days)
        return max(0.0, 1.0 - (age_days / SIMILARITY_RECENCY_DAYS))

    for paper in all_papers:
        if paper.arxiv_id == target.arxiv_id:
            continue
        paper_abstract = abstract_lookup(paper) if not use_tfidf else None
        score = compute_paper_similarity(
            target,
            paper,
            target_abstract,
            paper_abstract,
            tfidf_index=tfidf_index,
        )
        score += SIMILARITY_RECENCY_WEIGHT * recency_score(paper)
        score += metadata_boost(paper.arxiv_id)
        score = max(0.0, min(1.0, score))
        if score > 0:
            scored.append((paper, score))

    # Sort by score descending and take top N
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored[:top_n]


def _metadata_for(
    metadata: dict[str, PaperMetadata] | None,
    arxiv_id: str,
) -> PaperMetadata | None:
    return metadata.get(arxiv_id) if metadata else None


def _is_starred(metadata: dict[str, PaperMetadata] | None, paper: Paper) -> bool:
    entry = _metadata_for(metadata, paper.arxiv_id)
    return bool(entry and entry.starred)


def _is_read(metadata: dict[str, PaperMetadata] | None, paper: Paper) -> bool:
    entry = _metadata_for(metadata, paper.arxiv_id)
    return bool(entry and entry.is_read)


def _paper_categories(paper: Paper) -> set[str]:
    return set(paper.categories.split())


def _category_novelty_score(categories: set[str], reference_categories: set[str]) -> float:
    if not categories:
        return 0.0
    if not reference_categories:
        return 1.0
    familiar = len(categories & reference_categories) / len(categories)
    return max(0.0, 1.0 - familiar)


def _serendipity_candidate_pool(
    papers: list[Paper],
    metadata: dict[str, PaperMetadata] | None,
    current_paper_id: str | None,
) -> list[Paper]:
    candidates = list(papers)
    if current_paper_id and len(candidates) > 1:
        without_current = [paper for paper in candidates if paper.arxiv_id != current_paper_id]
        if without_current:
            candidates = without_current

    unread_unstarred = [
        paper
        for paper in candidates
        if not _is_read(metadata, paper) and not _is_starred(metadata, paper)
    ]
    if unread_unstarred:
        return unread_unstarred

    unstarred = [paper for paper in candidates if not _is_starred(metadata, paper)]
    if unstarred:
        return unstarred

    return candidates


def _nearest_starred_distance(
    candidate: Paper,
    starred_papers: list[Paper],
    tfidf_index: TfidfIndex | None,
) -> tuple[float, str | None]:
    nearest_id: str | None = None
    max_similarity = -1.0
    for anchor in starred_papers:
        if anchor.arxiv_id == candidate.arxiv_id:
            continue
        if tfidf_index is not None:
            similarity = tfidf_index.cosine_similarity(candidate.arxiv_id, anchor.arxiv_id)
        else:
            similarity = compute_paper_similarity(candidate, anchor)
        if similarity > max_similarity:
            max_similarity = similarity
            nearest_id = anchor.arxiv_id
    return max(0.0, 1.0 - max(0.0, max_similarity)), nearest_id


def _serendipity_reason_with_starred(
    paper: Paper,
    starred_categories: set[str],
    nearest_id: str | None,
) -> str:
    new_categories = sorted(_paper_categories(paper) - starred_categories)
    if new_categories:
        return f"Far from starred papers; new category {new_categories[0]}."
    if nearest_id:
        return f"Far from starred papers; nearest starred anchor {nearest_id}."
    return "Far from starred papers."


def _rank_with_starred_anchors(
    candidates: list[Paper],
    starred_papers: list[Paper],
    starred_categories: set[str],
    tfidf_index: TfidfIndex | None,
) -> list[SerendipityCandidate]:
    ranked: list[SerendipityCandidate] = []
    for paper in candidates:
        distance, nearest_id = _nearest_starred_distance(paper, starred_papers, tfidf_index)
        novelty = _category_novelty_score(_paper_categories(paper), starred_categories)
        score = (0.75 * distance) + (0.25 * novelty)
        ranked.append(
            SerendipityCandidate(
                paper=paper,
                score=max(0.0, min(1.0, score)),
                reason=_serendipity_reason_with_starred(paper, starred_categories, nearest_id),
                nearest_starred_anchor_id=nearest_id,
            )
        )
    return ranked


def _least_common_category_score(
    categories: set[str],
    category_counts: dict[str, int],
    total_papers: int,
) -> float:
    if not categories or total_papers <= 0:
        return 0.0
    least_common = min(category_counts.get(category, 0) for category in categories)
    return max(0.0, 1.0 - (least_common / total_papers))


def _serendipity_reason_without_starred(
    paper: Paper,
    represented_categories: set[str],
    category_counts: dict[str, int],
) -> str:
    categories = _paper_categories(paper)
    new_categories = sorted(categories - represented_categories)
    if new_categories:
        return f"New category {new_categories[0]}."
    if categories:
        rarest = min(categories, key=lambda category: (category_counts.get(category, 0), category))
        return f"Rare category {rarest}."
    return "Least familiar paper in visible set."


def _rank_without_starred_anchors(
    candidates: list[Paper],
    all_papers: list[Paper],
    metadata: dict[str, PaperMetadata] | None,
) -> list[SerendipityCandidate]:
    represented_categories: set[str] = set()
    category_counts: dict[str, int] = {}
    for paper in all_papers:
        categories = _paper_categories(paper)
        for category in categories:
            category_counts[category] = category_counts.get(category, 0) + 1
        if _is_read(metadata, paper) or _is_starred(metadata, paper):
            represented_categories.update(categories)

    ranked: list[SerendipityCandidate] = []
    total_papers = len(all_papers)
    for paper in candidates:
        categories = _paper_categories(paper)
        novelty = _category_novelty_score(categories, represented_categories)
        rarity = _least_common_category_score(categories, category_counts, total_papers)
        score = (0.70 * novelty) + (0.30 * rarity)
        ranked.append(
            SerendipityCandidate(
                paper=paper,
                score=max(0.0, min(1.0, score)),
                reason=_serendipity_reason_without_starred(
                    paper,
                    represented_categories,
                    category_counts,
                ),
            )
        )
    return ranked


def find_serendipitous_papers(request: SerendipityRequest) -> list[SerendipityCandidate]:
    """Rank visible papers by intentional novelty.

    Candidate selection is tiered before scoring: unread and unstarred papers
    are preferred, then all unstarred papers, then all visible papers.  Within
    the active tier, papers far from starred anchors score highest.  When there
    are no starred anchors, category novelty and rarity provide the fallback
    signal.
    """
    if request.top_n <= 0 or not request.papers:
        return []

    candidates = _serendipity_candidate_pool(
        request.papers,
        request.metadata,
        request.current_paper_id,
    )
    if not candidates:
        return []

    metadata = request.metadata
    starred_papers = [paper for paper in request.papers if _is_starred(metadata, paper)]
    if starred_papers:
        starred_categories: set[str] = set()
        for paper in starred_papers:
            starred_categories.update(_paper_categories(paper))
        ranked = _rank_with_starred_anchors(
            candidates,
            starred_papers,
            starred_categories,
            request.tfidf_index,
        )
    else:
        ranked = _rank_without_starred_anchors(candidates, request.papers, metadata)

    ranked.sort(key=lambda candidate: (-candidate.score, candidate.paper.arxiv_id))
    return ranked[: request.top_n]


__all__ = [
    "SERENDIPITY_TOP_N",
    "SIMILARITY_READ_PENALTY",
    "SIMILARITY_RECENCY_DAYS",
    "SIMILARITY_RECENCY_WEIGHT",
    "SIMILARITY_STARRED_BOOST",
    "SIMILARITY_TOP_N",
    "SIMILARITY_UNREAD_BOOST",
    "SIMILARITY_WEIGHT_AUTHOR",
    "SIMILARITY_WEIGHT_CATEGORY",
    "SIMILARITY_WEIGHT_TEXT",
    "SerendipityCandidate",
    "SerendipityRequest",
    "TfidfIndex",
    "build_similarity_corpus_key",
    "compute_paper_similarity",
    "find_serendipitous_papers",
    "find_similar_papers",
]
