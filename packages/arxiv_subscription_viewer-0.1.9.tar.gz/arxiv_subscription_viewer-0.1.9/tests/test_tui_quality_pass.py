#!/usr/bin/env python3
"""Focused TUI quality-pass tests for modal/widget coverage and hot-path behavior."""

from __future__ import annotations

from datetime import date as dt_date
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import httpx
import pytest
from textual.events import Click
from textual.widgets import Checkbox, Input, Label, ListView, Select, Static

from arxiv_browser.browser.core import ArxivBrowser
from arxiv_browser.citation_genealogy import GenealogyNode, GenealogyPaper, GenealogyRoot
from arxiv_browser.modals import (
    ArxivSearchModal,
    CitationGraphScreen,
    CollectionsModal,
    CommandPaletteModal,
    RecommendationsScreen,
    WatchListModal,
)
from arxiv_browser.modals.citations import _format_genealogy_label
from arxiv_browser.models import (
    MAX_COLLECTIONS,
    ArxivSearchRequest,
    PaperCollection,
    WatchListEntry,
)
from arxiv_browser.query import tokenize_query
from arxiv_browser.semantic_scholar import CitationEntry
from arxiv_browser.widgets.chrome import (
    DateNavigator,
    FilterPillBar,
)
from arxiv_browser.widgets.listing import PaperListItem
from tests.support.patch_helpers import patch_save_config


async def _open_modal(app: ArxivBrowser, pilot, modal) -> None:
    app.push_screen(modal)
    await pilot.pause(0.05)
    assert app.screen_stack[-1] is modal


def _click(widget) -> Click:
    return Click(
        widget=widget,
        x=0,
        y=0,
        delta_x=0,
        delta_y=0,
        button=1,
        shift=False,
        meta=False,
        ctrl=False,
    )


def _citation_entry(
    *,
    s2_paper_id: str,
    arxiv_id: str,
    title: str,
    url: str,
) -> CitationEntry:
    return CitationEntry(
        s2_paper_id=s2_paper_id,
        arxiv_id=arxiv_id,
        title=title,
        authors="Author One, Author Two",
        year=2024,
        citation_count=7,
        url=url,
    )


@pytest.mark.asyncio
async def test_collections_modal_create_rename_delete_flow(make_paper):
    papers = [make_paper(arxiv_id="2401.00001", title="First")]
    app = ArxivBrowser(papers, restore_session=False)
    base = PaperCollection(name="Reading", description="base", paper_ids=[papers[0].arxiv_id])
    modal = CollectionsModal([base], papers_by_id={papers[0].arxiv_id: papers[0]})

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            name_input = modal.query_one("#col-name", Input)
            desc_input = modal.query_one("#col-desc", Input)
            list_view = modal.query_one("#col-list", ListView)

            name_input.value = "Second"
            desc_input.value = "new desc"
            modal.on_create_pressed()
            assert [c.name for c in modal.collections] == ["Reading", "Second"]
            assert "Unsaved" in str(modal.query_one("#col-help", Static).content)

            list_view.index = 1
            name_input.value = "Renamed"
            desc_input.value = "updated"
            modal.on_rename_pressed()
            assert modal.collections[1].name == "Renamed"
            assert modal.collections[1].description == "updated"

            list_view.index = 1
            modal.on_delete_pressed()
            assert [c.name for c in modal.collections] == ["Reading"]


@pytest.mark.asyncio
async def test_collections_modal_validates_create_inputs(make_paper):
    papers = [make_paper(arxiv_id="2401.00001")]
    app = ArxivBrowser(papers, restore_session=False)
    base = PaperCollection(name="Reading", description="", paper_ids=[])
    modal = CollectionsModal([base])

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            name_input = modal.query_one("#col-name", Input)
            modal.notify = MagicMock()

            name_input.value = ""
            modal.on_create_pressed()
            assert "Collection name cannot be empty" in modal.notify.call_args[0][0]
            assert "Next step:" in modal.notify.call_args[0][0]

            modal.notify.reset_mock()
            name_input.value = "Reading"
            modal.on_create_pressed()
            assert "already exists" in modal.notify.call_args[0][0]


@pytest.mark.asyncio
async def test_collections_modal_enforces_max_collection_count(make_paper):
    papers = [make_paper(arxiv_id="2401.00001")]
    app = ArxivBrowser(papers, restore_session=False)
    collections = [
        PaperCollection(name=f"C{i}", description="", paper_ids=[]) for i in range(MAX_COLLECTIONS)
    ]
    modal = CollectionsModal(collections)

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            modal.notify = MagicMock()
            modal.query_one("#col-name", Input).value = "Overflow"
            modal.on_create_pressed()
            assert len(modal.collections) == MAX_COLLECTIONS
            assert "Collection limit reached" in modal.notify.call_args[0][0]


@pytest.mark.asyncio
async def test_collection_detail_view_remove_and_back(make_paper):
    papers = [
        make_paper(arxiv_id="2401.00001", title="A"),
        make_paper(arxiv_id="2401.00002", title="B"),
    ]
    collection = PaperCollection(
        name="Reading",
        description="",
        paper_ids=[papers[0].arxiv_id, papers[1].arxiv_id],
    )
    app = ArxivBrowser(papers, restore_session=False)
    modal = CollectionsModal([collection], papers_by_id={p.arxiv_id: p for p in papers})

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            # Switch to detail view via View button
            modal.on_view_pressed()
            assert modal._viewing_collection is not None
            assert modal._viewing_collection.paper_ids == [papers[0].arxiv_id, papers[1].arxiv_id]
            # Remove first paper
            modal.on_detail_remove_pressed()
            assert modal._viewing_collection.paper_ids == [papers[1].arxiv_id]
            # Back to manage
            modal.on_detail_back_pressed()
            assert modal._viewing_collection is None
            assert modal.collections[0].paper_ids == [papers[1].arxiv_id]


@pytest.mark.asyncio
async def test_collection_detail_view_requires_selection_for_remove(make_paper):
    papers = [make_paper(arxiv_id="2401.00001", title="A")]
    collection = PaperCollection(name="Reading", description="", paper_ids=[])
    app = ArxivBrowser(papers, restore_session=False)
    modal = CollectionsModal([collection], papers_by_id={papers[0].arxiv_id: papers[0]})

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            # Switch to detail view
            modal.on_view_pressed()
            modal.notify = MagicMock()
            modal.on_detail_remove_pressed()
            assert "No paper is selected" in modal.notify.call_args[0][0]


@pytest.mark.asyncio
async def test_pick_mode_select_and_cancel(make_paper):
    papers = [make_paper(arxiv_id="2401.00001")]
    app = ArxivBrowser(papers, restore_session=False)
    collections = [
        PaperCollection(name="A", description="", paper_ids=[]),
        PaperCollection(name="B", description="", paper_ids=[]),
    ]
    modal = CollectionsModal(collections, mode="pick")

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            list_view = modal.query_one("#pick-list", ListView)
            list_view.index = 1
            modal.dismiss = MagicMock()
            modal.on_pick_list_selected(SimpleNamespace())
            modal.dismiss.assert_called_once_with("B")

            modal.dismiss.reset_mock()
            modal.on_pick_cancel_pressed()
            modal.dismiss.assert_called_once_with(None)


def test_recommendations_screen_source_toggle_actions():
    """Test that RecommendationsScreen source toggle keybindings dismiss with sentinels."""
    from arxiv_browser.models import Paper

    paper = Paper(
        arxiv_id="2401.00001",
        date="2024-01-01",
        title="T",
        authors="A",
        categories="cs.AI",
        comments=None,
        abstract=None,
        url="",
    )
    modal = RecommendationsScreen(paper, [], source="local", s2_available=True)
    modal.dismiss = MagicMock()

    # Pressing s when source is local → switch:s2
    modal.action_switch_s2()
    modal.dismiss.assert_called_with("switch:s2")

    modal.dismiss.reset_mock()
    # Pressing l when source is already local → no-op
    modal.action_switch_local()
    modal.dismiss.assert_not_called()

    # Now test from s2 source
    modal2 = RecommendationsScreen(paper, [], source="s2", s2_available=True)
    modal2.dismiss = MagicMock()

    modal2.action_switch_local()
    modal2.dismiss.assert_called_with("switch:local")

    modal2.dismiss.reset_mock()
    modal2.action_switch_s2()
    modal2.dismiss.assert_not_called()

    # No toggle when s2_available is False
    modal3 = RecommendationsScreen(paper, [], source="local", s2_available=False)
    modal3.dismiss = MagicMock()
    modal3.action_switch_s2()
    modal3.dismiss.assert_not_called()


@pytest.mark.asyncio
async def test_recommendations_screen_select_cursor_and_cancel(make_paper):
    target = make_paper(arxiv_id="2401.00001", title="Target")
    p2 = make_paper(arxiv_id="2401.00002", title="Second")
    p3 = make_paper(arxiv_id="2401.00003", title="Third")
    app = ArxivBrowser([target, p2, p3], restore_session=False)
    modal = RecommendationsScreen(target, [(p2, 0.92), (p3, 0.70)])

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            list_view = modal.query_one("#recommendations-list", ListView)
            assert len(list_view.children) == 2

            modal.dismiss = MagicMock()
            modal.action_select()
            modal.dismiss.assert_called_with("2401.00002")

            modal.dismiss.reset_mock()
            modal.action_cursor_down()
            modal.action_select()
            modal.dismiss.assert_called_with("2401.00003")

            modal.dismiss.reset_mock()
            modal.action_cancel()
            modal.dismiss.assert_called_with(None)

            modal.dismiss.reset_mock()
            modal.on_list_selected(SimpleNamespace(item=list_view.children[0]))
            modal.dismiss.assert_called_with("2401.00002")


@pytest.mark.asyncio
async def test_recommendations_screen_select_empty_returns_none(make_paper):
    target = make_paper(arxiv_id="2401.00001", title="Target")
    app = ArxivBrowser([target], restore_session=False)
    modal = RecommendationsScreen(target, [])

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            modal.dismiss = MagicMock()
            modal.action_select()
            modal.dismiss.assert_called_once_with(None)


@pytest.mark.asyncio
async def test_citation_graph_switch_open_url_and_local_jump(make_paper):
    root = make_paper(arxiv_id="2401.00001", title="Root Paper")
    refs = [
        _citation_entry(
            s2_paper_id="s2:local",
            arxiv_id="2401.00002",
            title="Local Ref",
            url="https://arxiv.org/abs/2401.00002",
        )
    ]
    cites = [
        _citation_entry(
            s2_paper_id="s2:remote",
            arxiv_id="",
            title="Remote Cite",
            url="https://www.semanticscholar.org/paper/s2:remote",
        )
    ]

    async def _fetch(_paper_id: str):
        return [], []

    app = ArxivBrowser([root], restore_session=False)
    modal = CitationGraphScreen(
        root_title=root.title,
        root_paper_id=root.arxiv_id,
        references=refs,
        citations=cites,
        fetch_callback=_fetch,
        local_arxiv_ids=frozenset({"2401.00002"}),
    )

    with (
        patch_save_config(return_value=True),
        patch("arxiv_browser.modals.citations.webbrowser.open") as browser_open,
    ):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            assert modal._active_panel == "refs"

            modal.action_open_url()
            browser_open.assert_called_once_with("https://arxiv.org/abs/2401.00002")

            modal.dismiss = MagicMock()
            modal.action_go_to_local()
            modal.dismiss.assert_called_once_with("2401.00002")

            modal.action_switch_panel()
            assert modal._active_panel == "cites"


@pytest.mark.asyncio
async def test_citation_graph_drill_down_success_and_back(make_paper):
    root = make_paper(arxiv_id="2401.00001", title="Root Paper")
    child = _citation_entry(
        s2_paper_id="s2:child",
        arxiv_id="2401.00002",
        title="Child",
        url="https://arxiv.org/abs/2401.00002",
    )
    next_ref = _citation_entry(
        s2_paper_id="s2:grandchild",
        arxiv_id="2401.00003",
        title="Grandchild",
        url="https://arxiv.org/abs/2401.00003",
    )

    async def _fetch(_paper_id: str):
        return [next_ref], []

    app = ArxivBrowser([root], restore_session=False)
    modal = CitationGraphScreen(
        root_title=root.title,
        root_paper_id=root.arxiv_id,
        references=[child],
        citations=[],
        fetch_callback=_fetch,
        local_arxiv_ids=frozenset({"2401.00002", "2401.00003"}),
    )

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            await modal.action_drill_down()
            assert len(modal._stack) == 1
            assert modal._current_paper_id == "s2:child"
            assert len(modal._current_refs) == 1

            modal.action_back_or_close()
            assert modal._current_paper_id == root.arxiv_id
            assert modal._stack == []


@pytest.mark.asyncio
async def test_citation_graph_drill_down_failure_restores_state(make_paper):
    root = make_paper(arxiv_id="2401.00001", title="Root Paper")
    child = _citation_entry(
        s2_paper_id="s2:child",
        arxiv_id="2401.00002",
        title="Child",
        url="https://arxiv.org/abs/2401.00002",
    )

    async def _fetch(_paper_id: str):
        raise httpx.ConnectError("boom")

    app = ArxivBrowser([root], restore_session=False)
    modal = CitationGraphScreen(
        root_title=root.title,
        root_paper_id=root.arxiv_id,
        references=[child],
        citations=[],
        fetch_callback=_fetch,
        local_arxiv_ids=frozenset({"2401.00002"}),
    )

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            app.notify = MagicMock()
            await modal.action_drill_down()
            assert modal._stack == []
            assert modal._current_paper_id == root.arxiv_id
            app.notify.assert_called_once()
            assert "Could not load citation graph data." in app.notify.call_args[0][0]
            assert "Next step:" in app.notify.call_args[0][0]


@pytest.mark.asyncio
async def test_citation_graph_button_handlers_use_track_task(make_paper):
    root = make_paper(arxiv_id="2401.00001", title="Root Paper")
    child = _citation_entry(
        s2_paper_id="s2:child",
        arxiv_id="2401.00002",
        title="Child",
        url="https://arxiv.org/abs/2401.00002",
    )

    async def _fetch(_paper_id: str):
        return [], []

    app = ArxivBrowser([root], restore_session=False)
    modal = CitationGraphScreen(
        root_title=root.title,
        root_paper_id=root.arxiv_id,
        references=[child],
        citations=[],
        fetch_callback=_fetch,
        local_arxiv_ids=frozenset({"2401.00002"}),
    )

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            captured = []

            def _track_task(coro):
                captured.append(coro)
                coro.close()

            app._track_task = MagicMock(side_effect=_track_task)
            modal.on_drill_pressed()
            app._track_task.assert_called_once()
            assert len(captured) == 1

            modal.dismiss = MagicMock()
            modal.on_close_pressed()
            modal.dismiss.assert_called_once_with(None)


@pytest.mark.asyncio
async def test_citation_graph_genealogy_modes_go_open_and_cache(make_paper):
    root = make_paper(arxiv_id="2401.00001", title="Root Paper")
    local_ref = _citation_entry(
        s2_paper_id="s2:local",
        arxiv_id="2401.00002",
        title="Local Ref",
        url="https://arxiv.org/abs/2401.00002",
    )
    remote_cite = _citation_entry(
        s2_paper_id="s2:remote",
        arxiv_id="",
        title="Remote Cite",
        url="https://www.semanticscholar.org/paper/s2:remote",
    )
    calls: list[str] = []

    async def _fetch(paper_id: str):
        calls.append(paper_id)
        if paper_id == "s2:root":
            return [local_ref], [remote_cite]
        return [], []

    app = ArxivBrowser([root], restore_session=False)
    modal = CitationGraphScreen(
        root_title=root.title,
        root_paper_id="s2:root",
        references=[local_ref],
        citations=[remote_cite],
        fetch_callback=_fetch,
        local_arxiv_ids=frozenset({"2401.00002"}),
    )
    modal.configure_genealogy(
        GenealogyRoot("s2:root", root.title, arxiv_id=root.arxiv_id),
        frozenset({"2401.00002"}),
    )

    with (
        patch_save_config(return_value=True),
        patch("arxiv_browser.modals.citations.webbrowser.open") as browser_open,
    ):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            await modal.action_show_ancestors()
            assert modal._view_mode == "ancestors"
            assert modal.query_one("#genealogy-tree").display is True
            assert modal.query_one("#citation-graph-panels").display is False

            tree = modal.query_one("#genealogy-tree")
            local_node = tree.root.children[0].data
            modal.dismiss = MagicMock()
            modal._get_highlighted_genealogy_node = MagicMock(return_value=local_node)
            modal.action_go_to_local()
            modal.dismiss.assert_called_once_with("2401.00002")

            await modal.action_show_descendants()
            remote_node = modal.query_one("#genealogy-tree").root.children[0].data
            modal._get_highlighted_genealogy_node = MagicMock(return_value=remote_node)
            await modal.action_drill_down()
            browser_open.assert_called_once_with("https://www.semanticscholar.org/paper/s2:remote")

            await modal.action_show_descendants()
            assert calls.count("s2:root") == 2  # one ancestors build, one descendants build


@pytest.mark.asyncio
async def test_citation_graph_genealogy_fetch_error_restores_graph(make_paper):
    root = make_paper(arxiv_id="2401.00001", title="Root Paper")

    async def _fetch(_paper_id: str):
        raise httpx.ConnectError("boom")

    app = ArxivBrowser([root], restore_session=False)
    modal = CitationGraphScreen(
        root_title=root.title,
        root_paper_id="s2:root",
        references=[],
        citations=[],
        fetch_callback=_fetch,
        local_arxiv_ids=frozenset(),
    )

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            app.notify = MagicMock()
            await modal.action_show_ancestors()
            assert modal._view_mode == "graph"
            app.notify.assert_called_once()
            assert "Could not load citation genealogy data." in app.notify.call_args[0][0]


@pytest.mark.asyncio
async def test_citation_graph_genealogy_tree_controls_and_labels(make_paper):
    root = make_paper(arxiv_id="2401.00001", title="Root Paper")
    remote_cite = _citation_entry(
        s2_paper_id="s2:remote",
        arxiv_id="",
        title="Remote Cite",
        url="https://www.semanticscholar.org/paper/s2:remote",
    )

    async def _fetch(paper_id: str):
        if paper_id == "s2:root":
            return [], [remote_cite]
        return [], []

    app = ArxivBrowser([root], restore_session=False)
    modal = CitationGraphScreen(
        root_title=root.title,
        root_paper_id="s2:root",
        references=[],
        citations=[remote_cite],
        fetch_callback=_fetch,
        local_arxiv_ids=frozenset(),
    )

    labeled = GenealogyNode(
        GenealogyPaper("s2:label", "", "Label", None, 0, ""),
        repeated=True,
        truncated=True,
    )
    assert _format_genealogy_label(labeled).endswith("(repeat/more)")

    with (
        patch_save_config(return_value=True),
        patch("arxiv_browser.modals.citations.webbrowser.open") as browser_open,
    ):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            await modal.action_show_descendants()

            modal.action_switch_panel()
            modal.action_cursor_down()
            modal.action_cursor_up()
            modal._get_highlighted_genealogy_node = MagicMock(return_value=None)
            modal.action_open_url()
            browser_open.assert_not_called()

            remote_node = modal.query_one("#genealogy-tree").root.children[0].data
            modal._get_highlighted_genealogy_node = MagicMock(return_value=remote_node)
            modal.action_open_url()
            browser_open.assert_called_once_with("https://www.semanticscholar.org/paper/s2:remote")

            modal.dismiss = MagicMock()
            modal.action_back_or_close()
            modal.dismiss.assert_called_once_with(None)

            modal.dismiss.reset_mock()
            modal.action_show_graph()
            assert modal._view_mode == "graph"

            modal._loading = True
            await modal.action_show_ancestors()
            modal._loading = False
            assert modal._view_mode == "graph"

            captured = []

            def _track_task(coro):
                captured.append(coro)
                coro.close()

            app._track_task = MagicMock(side_effect=_track_task)
            modal.on_mode_graph_pressed()
            modal.on_mode_ancestors_pressed()
            modal.on_mode_descendants_pressed()
            assert len(captured) == 2


@pytest.mark.asyncio
async def test_arxiv_search_modal_validation_and_submit(make_paper):
    app = ArxivBrowser([make_paper()], restore_session=False)
    modal = ArxivSearchModal(initial_query="seed", initial_field="bad-field", initial_category="")

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            field_select = modal.query_one("#arxiv-search-field", Select)
            assert field_select.value == "all"

            modal.dismiss = MagicMock()
            modal.query_one("#arxiv-search-query", Input).value = "transformers"
            modal.query_one("#arxiv-search-category", Input).value = "cs.AI"
            field_select.value = "title"
            modal.action_search()

            request = modal.dismiss.call_args[0][0]
            assert isinstance(request, ArxivSearchRequest)
            assert request.query == "transformers"
            assert request.field == "title"
            assert request.category == "cs.AI"

            modal.dismiss.reset_mock()
            modal.notify = MagicMock()
            modal.query_one("#arxiv-search-query", Input).value = ""
            modal.query_one("#arxiv-search-category", Input).value = ""
            modal.action_search()
            modal.notify.assert_called_once()
            modal.dismiss.assert_not_called()


@pytest.mark.asyncio
async def test_command_palette_modal_filters_and_executes(make_paper):
    from arxiv_browser.palette import PaletteCommand

    commands = [
        PaletteCommand("Open Paper", "Open selected paper", "o", "open", "Core"),
        PaletteCommand("Toggle Watch", "Toggle watch filter", "w", "watch", "Organize"),
        PaletteCommand("Export CSV", "Export list as CSV", "E", "csv", "Core"),
    ]
    app = ArxivBrowser([make_paper()], restore_session=False)
    modal = CommandPaletteModal(commands)

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            results = modal.query_one("#palette-results")
            assert "Command palette" in str(modal.query_one(Label).content)
            assert results.option_count == 4
            assert "All commands" in str(results.get_option_at_index(0).prompt)
            assert "Esc/q close" in str(modal.query_one("#palette-footer", Static).content)

            modal._populate_results("watch")
            assert results.option_count >= 1

            modal.dismiss = MagicMock()
            modal.key_enter()
            assert modal.dismiss.called

            modal.dismiss.reset_mock()
            modal._populate_results("zzzzqzzzz")
            assert results.option_count == 1
            assert "No commands match" in str(results.get_option_at_index(0).prompt)
            modal.key_enter()
            modal.dismiss.assert_not_called()

            modal.dismiss.reset_mock()
            modal._on_option_selected(SimpleNamespace(option_id="csv"))
            modal.dismiss.assert_called_once_with("csv")

            modal.dismiss.reset_mock()
            modal.action_cancel()
            modal.dismiss.assert_called_once_with("")


def test_read_only_modals_support_q_close_binding():
    from arxiv_browser.modals import (
        CitationGraphScreen,
        CollectionsModal,
        ExportMenuModal,
        RecommendationsScreen,
        SectionToggleModal,
    )

    classes = [
        RecommendationsScreen,
        CitationGraphScreen,
        CollectionsModal,
        ExportMenuModal,
        SectionToggleModal,
    ]
    for modal_cls in classes:
        binding_keys = {binding.key for binding in modal_cls.BINDINGS}
        assert "q" in binding_keys


def test_help_screen_default_sections_reflect_simplified_shortcuts():
    from arxiv_browser.modals.help import HelpScreen

    entries = {(key, desc) for _, pairs in HelpScreen._DEFAULT_SECTIONS for key, desc in pairs}
    assert ("Ctrl+p", "Open commands") in entries
    assert ("Ctrl+b", "Save search as bookmark") in entries
    assert ("v", "Toggle detail density (scan/full)") in entries
    assert ("cat:cs.AI", "Category filter") in entries


def test_help_screen_default_footer_copy():
    from arxiv_browser.modals.help import HelpScreen

    modal = HelpScreen()
    assert modal._footer_note == "Close: ? / Esc / q"


def test_help_screen_filter_sections():
    """_filter_sections returns only entries matching the query."""
    from arxiv_browser.modals.help import HelpScreen

    modal = HelpScreen()

    # Empty query returns all sections unchanged
    assert modal._filter_sections("") is modal._sections

    # "search" matches entries in Getting Started and Search Syntax
    filtered = modal._filter_sections("search")
    all_entries = [(k, d) for _, entries in filtered for k, d in entries]
    assert len(all_entries) > 0
    for key, desc in all_entries:
        assert "search" in key.lower() or "search" in desc.lower()

    # Nonsense query returns empty
    assert modal._filter_sections("xyzzyplugh") == []


@pytest.mark.asyncio
async def test_help_screen_has_filter_input_and_filters(make_paper):
    """HelpScreen contains a filter Input and dynamically filters sections."""
    from textual.widgets import TabbedContent

    from arxiv_browser.modals.help import HelpScreen

    app = ArxivBrowser([make_paper()], restore_session=False)
    modal = HelpScreen()

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)

            # Input widget is present with the expected placeholder
            filter_input = modal.query_one("#help-filter", Input)
            assert "Filter help" in filter_input.placeholder

            # Initially tabs are visible and flat section container is hidden
            from textual.containers import Vertical

            tabs = modal.query_one("#help-tabs", TabbedContent)
            flat_container = modal.query_one("#help-sections", Vertical)
            assert "hidden" not in tabs.classes
            assert "hidden" in flat_container.classes
            assert tabs.display is True
            assert flat_container.display is False

            # The "All" tab has all sections
            all_body = modal.query_one("#help-tab-all", Vertical)
            all_titles = all_body.query(".help-section-title")
            assert len(all_titles) == len(modal._sections)

            # Type a filter that narrows results — flat container becomes visible
            filter_input.value = "bookmark"
            await pilot.pause(0.1)
            assert "hidden" in tabs.classes
            assert "hidden" not in flat_container.classes
            assert tabs.display is False
            assert flat_container.display is True
            section_titles = flat_container.query(".help-section-title")
            assert len(section_titles) >= 1
            keys_widgets = flat_container.query(".help-keys")
            for widget in keys_widgets:
                assert "bookmark" in widget.render().plain.lower()

            # Nonsense query shows "No matches" message
            filter_input.value = "xyzzyplugh"
            await pilot.pause(0.1)
            no_match = flat_container.query_one("#help-no-matches", Static)
            assert "No matches" in no_match.render().plain

            # Clearing filter restores tabs
            filter_input.value = ""
            await pilot.pause(0.1)
            assert "hidden" not in tabs.classes
            assert "hidden" in flat_container.classes
            assert tabs.display is True
            assert flat_container.display is False
            assert len(flat_container.children) == 0


def test_help_ui_helper_branches_cover_binding_resolution_and_ascii_mode():
    from textual.binding import Binding

    import arxiv_browser.help_ui as help_ui
    from arxiv_browser._ascii import set_ascii_mode

    assert help_ui._format_help_key("slash") == "/"
    assert help_ui._format_help_key("question_mark") == "?"
    assert help_ui._format_help_key("ctrl+shift+slash") == "Ctrl+Shift+slash"

    bindings = help_ui._iter_binding_definitions(
        [("ctrl+p", "command_palette", "Commands"), Binding("q", "show_help", "Help")]
    )
    assert [binding.action for binding in bindings] == ["command_palette", "show_help"]
    assert help_ui._binding_for_help_action(bindings, "command_palette").key == "ctrl+p"
    assert (
        help_ui._binding_for_help_action(
            [("x", "toggle_preview(extra)", "Preview")], "toggle_preview"
        ).action
        == "toggle_preview(extra)"
    )
    assert help_ui._binding_for_help_action(bindings, "missing") is None

    set_ascii_mode(True)
    try:
        sections = help_ui.build_help_sections(
            [Binding("ctrl+p", "command_palette", "Commands")],
            search_first=True,
        )
        section_names = [name for name, _ in sections]
        assert section_names[0] == "Getting Started"
        assert section_names[1] == "Search Syntax"
        assert any(name == "Standard - Organize" for name in section_names)
        core_entries = list(next(entries for name, entries in sections if name == "Core Actions"))
        assert ("Ctrl+p", "Search examples & operators") in core_entries
        assert ("Ctrl+p", "Commands") in core_entries

        sections_no_search = help_ui.build_help_sections(
            [Binding("ctrl+p", "command_palette", "Commands")],
            search_first=False,
        )
        assert sections_no_search[1][0] == "Search Syntax"
        assert any(name == "Power - Research Tools" for name, _ in sections_no_search)
    finally:
        set_ascii_mode(False)


@pytest.mark.asyncio
async def test_watch_list_modal_add_update_delete_and_save(make_paper):
    app = ArxivBrowser([make_paper()], restore_session=False)
    modal = WatchListModal(
        [WatchListEntry(pattern="Smith", match_type="author", case_sensitive=False)]
    )

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            pattern = modal.query_one("#watch-pattern", Input)
            match_type = modal.query_one("#watch-type", Select)
            case = modal.query_one("#watch-case", Checkbox)
            list_view = modal.query_one("#watch-list", ListView)
            empty_hint = modal.query_one("#watch-empty", Static)
            assert empty_hint.has_class("visible") is False

            modal.notify = MagicMock()
            pattern.value = ""
            modal.on_add_pressed()
            assert "Pattern cannot be empty" in modal.notify.call_args[0][0]

            pattern.value = "transformer"
            match_type.value = "title"
            case.value = True
            modal.on_add_pressed()
            assert len(modal._entries) == 2
            assert "Unsaved" in str(modal.query_one("#watch-help", Static).content)

            list_view.index = 1
            pattern.value = "diffusion"
            match_type.value = "keyword"
            case.value = False
            modal.on_update_pressed()
            assert modal._entries[1].pattern == "diffusion"
            assert modal._entries[1].match_type == "keyword"
            assert modal._entries[1].case_sensitive is False

            list_view.index = 1
            modal.on_delete_pressed()
            assert len(modal._entries) == 1

            modal.dismiss = MagicMock()
            modal.action_save()
            modal.dismiss.assert_called_once_with(modal._entries)


@pytest.mark.asyncio
async def test_watch_list_modal_update_delete_require_selection(make_paper):
    app = ArxivBrowser([make_paper()], restore_session=False)
    modal = WatchListModal([])

    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await _open_modal(app, pilot, modal)
            empty_hint = modal.query_one("#watch-empty", Static)
            assert "No watch entries yet." in str(empty_hint.content)
            assert "Try:" in str(empty_hint.content)
            assert empty_hint.has_class("visible")
            modal.notify = MagicMock()
            modal.on_update_pressed()
            assert "Select a watch entry to update" in modal.notify.call_args[0][0]

            modal.notify.reset_mock()
            modal.on_delete_pressed()
            assert "Select a watch entry to delete" in modal.notify.call_args[0][0]


@pytest.mark.asyncio
async def test_date_navigator_updates_in_place_when_window_unchanged(make_paper, tmp_path):
    f1 = tmp_path / "2026-01-01.txt"
    f2 = tmp_path / "2026-01-02.txt"
    f3 = tmp_path / "2026-01-03.txt"
    for idx, path in enumerate([f1, f2, f3], start=1):
        path.write_text(f"arXiv:2401.0000{idx}\n", encoding="utf-8")

    history_files = [
        (dt_date(2026, 1, 3), f3),
        (dt_date(2026, 1, 2), f2),
        (dt_date(2026, 1, 1), f1),
    ]

    app = ArxivBrowser([make_paper()], restore_session=False, history_files=history_files)
    with patch_save_config(return_value=True):
        async with app.run_test() as pilot:
            await pilot.pause(0.1)
            nav = app.query_one(DateNavigator)
            await nav.update_dates(history_files, 1)

            before = {
                child.id: child
                for child in nav.children
                if isinstance(child, Label) and child.id and "date-nav-item" in child.classes
            }

            await nav.update_dates(history_files, 2)
            after = {
                child.id: child
                for child in nav.children
                if isinstance(child, Label) and child.id and "date-nav-item" in child.classes
            }
            assert before.keys() == after.keys()
            for key in before:
                assert before[key] is after[key]


def test_date_navigator_click_messages():
    nav = DateNavigator([])
    nav.post_message = MagicMock()

    nav.on_click(_click(Label("<", id="date-nav-prev")))
    msg = nav.post_message.call_args[0][0]
    assert isinstance(msg, DateNavigator.NavigateDate)
    assert msg.direction == 1

    nav.post_message.reset_mock()
    nav.on_click(_click(Label(">", id="date-nav-next")))
    msg = nav.post_message.call_args[0][0]
    assert isinstance(msg, DateNavigator.NavigateDate)
    assert msg.direction == -1

    nav.post_message.reset_mock()
    nav.on_click(_click(Label("Jan 01", id="date-nav-4")))
    msg = nav.post_message.call_args[0][0]
    assert isinstance(msg, DateNavigator.JumpToDate)
    assert msg.index == 4


@pytest.mark.asyncio
async def test_filter_pill_bar_updates_in_place_and_click_events():
    from arxiv_browser.widgets.chrome import set_ascii_glyphs as set_ascii_chrome_glyphs

    bar = FilterPillBar()

    def fake_mount(widget: Label):
        bar._nodes._append(widget)

    async def fake_remove_children():
        for child in list(bar.children):
            bar._nodes._remove(child)

    bar.mount = fake_mount  # type: ignore[method-assign]
    bar.remove_children = fake_remove_children  # type: ignore[method-assign]

    tokens = tokenize_query("cat:cs.AI AND transformer")
    await bar.update_pills(tokens, watch_active=True)
    first_by_id = {child.id: child for child in bar.children if child.id is not None}
    assert "\u00d7" in str(first_by_id["pill-0"].content)
    assert "\u00d7" in str(first_by_id["pill-watch"].content)

    await bar.update_pills(tokens, watch_active=True)
    second_by_id = {child.id: child for child in bar.children if child.id is not None}
    assert first_by_id["pill-0"] is second_by_id["pill-0"]
    assert first_by_id["pill-2"] is second_by_id["pill-2"]
    assert first_by_id["pill-watch"] is second_by_id["pill-watch"]

    bar.post_message = MagicMock()
    bar.on_click(_click(second_by_id["pill-0"]))
    msg = bar.post_message.call_args[0][0]
    assert isinstance(msg, FilterPillBar.RemoveFilter)
    assert msg.token_index == 0

    bar.post_message.reset_mock()
    bar.on_click(_click(second_by_id["pill-watch"]))
    msg = bar.post_message.call_args[0][0]
    assert isinstance(msg, FilterPillBar.RemoveWatchFilter)

    set_ascii_chrome_glyphs(True)
    try:
        await bar.update_pills(tokens, watch_active=True)
        ascii_by_id = {child.id: child for child in bar.children if child.id is not None}
        assert "x" in str(ascii_by_id["pill-0"].content)
        assert "x" in str(ascii_by_id["pill-watch"].content)
    finally:
        set_ascii_chrome_glyphs(False)

    # Invalid pill index should be ignored safely.
    bar.post_message.reset_mock()
    bar.on_click(_click(Label("bad", id="pill-bad")))
    bar.post_message.assert_not_called()


def test_paper_list_item_update_methods_safe_before_mount(make_paper):
    paper = make_paper(arxiv_id="2401.00001")
    item = PaperListItem(paper, show_preview=True)
    item.set_abstract_text("Preview text")
    item.set_selected(True)
    item.set_selected(False)
    item.update_s2_data(None)
    item.update_hf_data(None)
    item.update_version_data((1, 2))
    item.update_relevance_data((8, "high"))
    assert item.paper.arxiv_id == "2401.00001"


def test_badge_refresh_indices_sparse_updates(make_paper):
    app = ArxivBrowser.__new__(ArxivBrowser)
    app.filtered_papers = [
        make_paper(arxiv_id="2401.00001"),
        make_paper(arxiv_id="2401.00002"),
        make_paper(arxiv_id="2401.00003"),
    ]
    app._s2_active = True
    app._s2_cache = {"2401.00003": object()}
    app._hf_active = True
    app._hf_cache = {"2401.00002": object()}
    app._version_updates = {"2401.00001": (1, 2)}

    assert app._badge_refresh_indices({"hf"}) == [1]
    assert app._badge_refresh_indices({"s2"}) == [2]
    assert app._badge_refresh_indices({"version"}) == [0]
    assert app._badge_refresh_indices({"hf", "version"}) == [0, 1]

    app._hf_active = False
    assert app._badge_refresh_indices({"hf"}) == [0, 1, 2]


def test_flush_badge_refresh_uses_computed_sparse_indices(make_paper):
    app = ArxivBrowser.__new__(ArxivBrowser)
    app.filtered_papers = [
        make_paper(arxiv_id="2401.00001"),
        make_paper(arxiv_id="2401.00002"),
        make_paper(arxiv_id="2401.00003"),
    ]
    app._s2_active = True
    app._s2_cache = {}
    app._hf_active = True
    app._hf_cache = {"2401.00002": object()}
    app._version_updates = {}
    app._badges_dirty = {"hf"}
    app._badge_timer = None
    app._update_option_at_index = MagicMock()

    app._flush_badge_refresh()
    app._update_option_at_index.assert_called_once_with(1)


@pytest.mark.asyncio
async def test_modal_tail_branches_cover_common_search_and_citation_edges(make_paper, tmp_path):
    from textual.css.query import NoMatches

    from arxiv_browser._ascii import set_ascii_mode
    from arxiv_browser.modals.citations import CitationGraphScreen
    from arxiv_browser.modals.common import (
        ConfirmModal,
        MetadataSnapshotPickerModal,
        SectionToggleModal,
    )
    from arxiv_browser.modals.help import HelpScreen
    from arxiv_browser.modals.search import ArxivSearchModal, CommandPaletteModal
    from arxiv_browser.modals.watchlist import WatchListModal

    class _PaletteListStub:
        def __init__(self) -> None:
            self.options: list[object] = []
            self.option_count = 0
            self.highlighted = None

        def clear_options(self) -> None:
            self.options.clear()
            self.option_count = 0

        def add_option(self, option: object) -> None:
            self.options.append(option)
            self.option_count = len(self.options)

        def get_option_at_index(self, index: int) -> object:
            return self.options[index]

    class _PanelStub:
        def __init__(self) -> None:
            self.classes: set[str] = set()
            self.focused = False

        def add_class(self, class_name: str) -> None:
            self.classes.add(class_name)

        def remove_class(self, class_name: str) -> None:
            self.classes.discard(class_name)

        def focus(self) -> None:
            self.focused = True

    set_ascii_mode(True)
    try:
        help_modal = HelpScreen()
        assert all("\u00b7" not in name for name, _ in help_modal._sections)
    finally:
        set_ascii_mode(False)

    confirm_modal = ConfirmModal("Proceed?")
    confirm_modal.dismiss = MagicMock()
    confirm_modal.action_confirm()
    confirm_modal.action_cancel()
    confirm_modal.on_yes()
    confirm_modal.on_no()
    assert confirm_modal.dismiss.call_args_list[0].args == (True,)
    assert confirm_modal.dismiss.call_args_list[1].args == (False,)

    snapshot = tmp_path / "arxiv-2026-03-07.json"
    snapshot.write_text("{}", encoding="utf-8")
    picker = MetadataSnapshotPickerModal([snapshot])
    picker.dismiss = MagicMock()
    picker.query_one = MagicMock(return_value=SimpleNamespace(highlighted_child=None))
    picker.action_choose()
    picker.dismiss.assert_called_once_with(None)
    picker.dismiss.reset_mock()
    with patch("pathlib.Path.stat", side_effect=OSError("boom")):
        label = picker._format_snapshot_label(snapshot)
    assert "unknown time" in label
    picker.on_list_selected(SimpleNamespace(item=object()))
    picker.dismiss.assert_not_called()

    watch_modal = WatchListModal(
        [WatchListEntry(pattern="graph", match_type="author", case_sensitive=False)]
    )
    watch_modal.query_one = MagicMock(
        side_effect=lambda selector, _type=None: {
            "#watch-pattern": SimpleNamespace(value="diffusion"),
            "#watch-type": SimpleNamespace(value="bogus"),
            "#watch-case": SimpleNamespace(value=True),
        }[selector]
    )
    entry = watch_modal._build_entry_from_form()
    assert entry is not None and entry.match_type == "author"

    section_modal = SectionToggleModal(["abstract"])
    section_modal.query_one = MagicMock(side_effect=NoMatches("missing"))
    section_modal.action_toggle_a()
    section_modal._toggle("z")
    assert section_modal._collapsed == {"abstract", "authors"}

    search_modal = ArxivSearchModal(initial_query="seed", initial_field="bad-field")
    search_modal.dismiss = MagicMock()
    search_modal.notify = MagicMock()
    search_modal.query_one = MagicMock(
        side_effect=lambda selector, _type=None: {
            "#arxiv-search-query": SimpleNamespace(value="graph"),
            "#arxiv-search-field": SimpleNamespace(value="title"),
            "#arxiv-search-category": SimpleNamespace(value="cs.AI"),
        }[selector]
    )
    search_modal.on_query_submitted()
    search_modal.on_category_submitted()
    search_modal.on_search_pressed()
    search_modal.on_cancel_pressed()
    assert search_modal.dismiss.call_args_list[-1].args == (None,)

    palette_modal = CommandPaletteModal([])
    palette_list = _PaletteListStub()
    palette_modal.query_one = MagicMock(return_value=palette_list)
    palette_modal._populate_results("")
    assert "No commands available" in str(palette_list.get_option_at_index(0).prompt)
    palette_modal._populate_results("watch")
    assert "No commands match" in str(palette_list.get_option_at_index(0).prompt)
    palette_modal.dismiss = MagicMock()
    palette_modal.key_enter()
    palette_modal.dismiss.assert_not_called()
    palette_modal.action_cancel()
    palette_modal.dismiss.assert_called_once_with("")
    palette_modal._highlight_first_enabled(
        SimpleNamespace(
            option_count=2,
            highlighted=None,
            get_option_at_index=lambda idx: SimpleNamespace(disabled=idx == 0),
        )
    )

    root = make_paper(arxiv_id="2401.00001", title="Root")
    refs = [
        SimpleNamespace(
            s2_paper_id="s2:ref",
            arxiv_id="2401.00002",
            title="Ref",
            authors="A. Author",
            year=2024,
            citation_count=1,
            url="https://arxiv.org/abs/2401.00002",
        )
    ]
    cites = []
    screen = CitationGraphScreen(
        root_title=root.title,
        root_paper_id=root.arxiv_id,
        references=refs,
        citations=cites,
        fetch_callback=MagicMock(return_value=([], [])),
        local_arxiv_ids=frozenset({"2401.00002"}),
    )
    screen.dismiss = MagicMock()
    screen._populate_lists = MagicMock()
    screen._update_breadcrumb = MagicMock()
    active_list = SimpleNamespace(focus=MagicMock())
    screen._get_active_list = MagicMock(return_value=active_list)
    screen._stack = [("s2:prev", "Prev", [], [])]
    screen.action_back_or_close()
    assert screen._current_paper_id == "s2:prev"
    screen._stack = []
    screen.action_back_or_close()
    screen.dismiss.assert_called_with(None)

    refs_panel = _PanelStub()
    cites_panel = _PanelStub()
    screen._active_panel = "refs"
    screen._update_status = MagicMock()
    screen.query_one = MagicMock(
        side_effect=lambda selector, _type=None: (
            refs_panel if selector == "#refs-list" else cites_panel
        )
    )
    screen.action_switch_panel()
    assert screen._active_panel == "cites"
    screen.action_switch_panel()
    assert screen._active_panel == "refs"

    screen._get_highlighted_entry = MagicMock(
        return_value=SimpleNamespace(
            entry=SimpleNamespace(url="https://example.com", arxiv_id="2401.00002"),
            is_local=True,
        )
    )
    with patch("arxiv_browser.modals.citations.webbrowser.open") as browser_open:
        screen.action_open_url()
        browser_open.assert_called_once_with("https://example.com")
    screen.dismiss = MagicMock()
    screen.action_go_to_local()
    screen.dismiss.assert_called_once_with("2401.00002")
