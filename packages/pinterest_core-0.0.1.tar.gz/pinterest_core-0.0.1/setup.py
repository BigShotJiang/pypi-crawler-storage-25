from setuptools import setup; setup(name='pinterest-core', version='0.0.1')
