"""Smoke tests for the autodynamics package."""

import autodynamics


def test_version_is_pinned() -> None:
    assert autodynamics.__version__ == "0.1.0a1"


def test_package_imports() -> None:
    import autodynamics  # noqa: F401


def test_public_api_is_exposed() -> None:
    assert hasattr(autodynamics, "ProfileTrajectory")
    assert hasattr(autodynamics, "ProfileSnapshot")
    assert hasattr(autodynamics, "ProfileDelta")
