"""
llm.py — minimal LLM client.

DESIGN NOTE:
Two functions only:
  - chat(messages, tools=None, json_mode=False) -> response dict
  - extract_text(response) / extract_tool_calls(response) -> typed accessors

Why not use openai-python or litellm?
  We support ANY OpenAI-compatible endpoint, including weird local ones
  whose pydantic schemas don't quite match. A 50-line raw-requests client
  is more portable than a fat SDK that breaks on minor protocol drift.
  When the project matures we can swap in litellm; for now, simple wins.

This is the executor's bridge to the world. Tool calling format follows the
OpenAI spec (Anthropic, OpenRouter, Mistral, DeepSeek all match it).

v1.4: `model=` parameter overrides config.MODEL per call (used by swarms
to mix cheap/expensive models per role). Retry/backoff wraps the POST to
absorb transient 5xx and ConnectionError — without it, long-running swarms
die on first hiccup.
"""

from __future__ import annotations
import json
import random
import time
from typing import Any

import requests

from . import config


# ---------- Retry / backoff ----------
#
# Used by both chat() and streaming.chat_stream(). Retries on transient
# failures (HTTP 429, HTTP 5xx, ConnectionError, Timeout). Does NOT retry
# on 4xx other than 429 — those are deterministic client errors.


# 529 = Anthropic 'overloaded'. Not in the OpenAI spec but Anthropic
# uses it under load. Treating it as retryable matches Hermes.
_RETRYABLE_STATUS = frozenset({429, 500, 502, 503, 504, 529})


def _backoff_sleep(attempt: int, *, provider_cooldown: float = 0.0) -> None:
    """Exponential backoff with jitter. attempt is 0-indexed (0 = first try).

    Sleep length: max(provider_cooldown, base * 2^attempt + uniform(0, base)).
    The provider_cooldown override (v1.14.0) lets the rate-limit tracker
    feed in 'this provider just rate-limited us, sleep at LEAST X seconds'
    so we don't burn retry attempts hammering a provider that already
    told us to slow down.
    Patched out in tests via monkeypatching `time.sleep`."""
    base = config.LLM_RETRY_BACKOFF_BASE_S
    delay = base * (2 ** attempt) + random.uniform(0, base)
    if provider_cooldown > delay:
        delay = provider_cooldown
    time.sleep(delay)


def _post_with_retry(
    url: str,
    *,
    headers: dict,
    json_payload: dict,
    timeout: int,
    stream: bool = False,
) -> requests.Response:
    """POST with bounded retry on transient failures.

    Returns the requests.Response. On the LAST attempt, returns whatever
    response we got (5xx included) so the caller's `raise_for_status()`
    surfaces the error normally. Raises ConnectionError/Timeout if the
    last attempt also fails to connect.

    v1.14.0: when the rate-limit tracker has a recent 429 cooldown for
    this provider+model, _backoff_sleep honors it as a floor. Avoids
    burning retry attempts hammering a provider that already told us
    to slow down.

    v1.14.0: 529 (Anthropic overloaded) added to retryable set.
    """
    post_kwargs: dict = {
        "headers": headers, "json": json_payload, "timeout": timeout,
    }
    if stream:
        post_kwargs["stream"] = True

    # Pull cooldown hint from rate_limit module (best-effort, no hard dep).
    provider_cooldown = 0.0
    try:
        from . import rate_limit
        provider = _provider_from_base(config.API_BASE)
        model = json_payload.get("model", "")
        provider_cooldown = rate_limit.cooldown_seconds(provider, model)
    except Exception:
        provider_cooldown = 0.0

    # If provider is in cooldown, sleep BEFORE the first attempt — the
    # caller's expectation is "succeed eventually", and trying immediately
    # would just return 429 again.
    if provider_cooldown > 0:
        time.sleep(provider_cooldown)

    last_exc: Exception | None = None
    for attempt in range(config.LLM_RETRY_MAX_ATTEMPTS):
        is_last_attempt = attempt + 1 == config.LLM_RETRY_MAX_ATTEMPTS
        try:
            r = requests.post(url, **post_kwargs)
        except (requests.exceptions.ConnectionError,
                requests.exceptions.Timeout) as e:
            last_exc = e
            if is_last_attempt:
                raise
            _backoff_sleep(attempt)
            continue
        if r.status_code in _RETRYABLE_STATUS and not is_last_attempt:
            r.close()
            # Re-pull cooldown — the just-failed call may have set it.
            try:
                from . import rate_limit
                provider = _provider_from_base(config.API_BASE)
                model = json_payload.get("model", "")
                cd = rate_limit.cooldown_seconds(provider, model)
            except Exception:
                cd = 0.0
            _backoff_sleep(attempt, provider_cooldown=cd)
            continue
        return r
    # Unreachable: loop body always returns or raises on last attempt.
    if last_exc is not None:
        raise last_exc
    raise RuntimeError("retry loop fell through")


# v1.35.1 — Phase 9.3: provider-detection helpers for prompt cache.
# The cache_control marker is Anthropic-flavored; providers that
# accept it: openrouter (forwards to Anthropic), api.anthropic.com
# direct, AWS Bedrock (via Anthropic models). Providers that ignore
# it harmlessly: OpenAI, Ollama, generic OpenAI-compatible endpoints
# (extra fields are dropped). Providers known to ERROR on extra
# fields: very strict OpenAI clones — unlikely in practice.
def detect_provider(api_base: str | None = None) -> str:
    """Return a coarse provider name from JANUS_API_BASE."""
    base = (api_base if api_base is not None else config.API_BASE) or ""
    base_lower = base.lower()
    if "openrouter.ai" in base_lower:
        return "openrouter"
    if "anthropic.com" in base_lower:
        return "anthropic"
    if "bedrock" in base_lower:
        return "bedrock"
    if "openai.com" in base_lower:
        return "openai"
    if "googleapis.com" in base_lower or "vertex" in base_lower:
        return "vertex"
    if "127.0.0.1" in base_lower or "localhost" in base_lower or ":11434" in base_lower:
        return "ollama"
    return "unknown"


# Providers that benefit from Anthropic-style cache_control markers
# (i.e., they forward to Anthropic's prompt cache). Used for the
# heads-up log when JANUS_PROMPT_CACHE=1 is set but the provider
# wouldn't actually save tokens.
CACHE_BENEFICIARIES: frozenset[str] = frozenset({
    "openrouter", "anthropic", "bedrock",
})


def cache_supported(provider: str) -> bool:
    """True iff `provider` is known to honor cache_control markers."""
    return provider in CACHE_BENEFICIARIES


def apply_cache_markers(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Wrap select messages in Anthropic-style content blocks with
    `cache_control: ephemeral`. OpenRouter forwards to Anthropic's
    prompt cache; OpenAI ignores extra fields.

    v1.14.0 — marks TWO points:
      1) the LAST system message (always — that's the big static prompt)
      2) the last user message (only if substantial, ≥1024 chars — the
         turn-context block where memory + state introspection live)

    Anthropic allows up to 4 cache breakpoints per message list, so two
    is well under the limit. The 1024-char threshold matches Anthropic's
    minimum cacheable size — anything shorter doesn't save tokens.

    No-op when:
      - JANUS_PROMPT_CACHE is off (default)
      - the message list has no system message
      - the message content is already a list (caller built blocks itself)
    """
    if not config.PROMPT_CACHE_MARKERS:
        return messages

    out: list[dict[str, Any]] = []
    last_system_idx = -1
    last_user_idx = -1
    for i, m in enumerate(messages):
        if m.get("role") == "system":
            last_system_idx = i
        elif m.get("role") == "user":
            last_user_idx = i

    for i, m in enumerate(messages):
        content = m.get("content")
        # Only string content is wrappable — already-list content was
        # constructed by a caller that knows what it's doing.
        if not isinstance(content, str):
            out.append(m)
            continue
        if i == last_system_idx:
            out.append({
                "role": "system",
                "content": [{
                    "type": "text",
                    "text": content,
                    "cache_control": {"type": "ephemeral"},
                }],
            })
        elif i == last_user_idx and len(content) >= 1024:
            out.append({
                "role": "user",
                "content": [{
                    "type": "text",
                    "text": content,
                    "cache_control": {"type": "ephemeral"},
                }],
            })
        else:
            out.append(m)
    return out


def _chat_attempt(
    chosen_model: str,
    messages: list[dict[str, Any]],
    *,
    tools: list[dict] | None = None,
    json_mode: bool = False,
    temperature: float = 0.7,
) -> dict:
    """Single attempt — one model, one POST. Extracted from ``chat()``
    in v1.28.3 so the public ``chat()`` can wrap this in a fallback
    loop. Behavior identical to the pre-1.28.3 ``chat()`` body."""
    url = f"{config.API_BASE}/chat/completions"
    headers = {
        "Authorization": f"Bearer {config.API_KEY}",
        "Content-Type": "application/json",
    }
    payload: dict[str, Any] = {
        "model": chosen_model,
        "messages": apply_cache_markers(messages),
        "temperature": temperature,
    }
    # v1.16.2: respect JANUS_NO_TOOLS for endpoints that 404 on the tools
    # payload (self-hosted vLLM without --enable-auto-tool-choice, or
    # models without function-calling support). Strips tools entirely.
    if tools and not config.NO_TOOLS:
        payload["tools"] = tools
        payload["tool_choice"] = "auto"
    if json_mode:
        payload["response_format"] = {"type": "json_object"}

    r = _post_with_retry(
        url, headers=headers, json_payload=payload, timeout=config.LLM_TIMEOUT,
    )
    # v1.11.0 — feed the rate-limit tracker BEFORE raise_for_status so
    # 429s are recorded even when the call ultimately fails.
    try:
        from . import rate_limit
        provider = _provider_from_base(config.API_BASE)
        rate_limit.record_request(
            provider=provider, model=chosen_model,
            tokens=0,
            ok=(200 <= r.status_code < 300),
            status_429=(r.status_code == 429),
        )
    except Exception:
        pass

    # v1.16.1 — turn opaque 404s into actionable errors.
    if r.status_code == 404:
        had_tools = bool(payload.get("tools"))
        raise _explain_404(chosen_model, config.API_BASE, r, had_tools=had_tools)

    r.raise_for_status()
    body = r.json()
    # Phase 13: feed token usage to the cost tracker.
    try:
        from . import cost
        cost.record(chosen_model, body.get("usage"))
    except Exception:
        pass
    # v1.11.0 — token count to the rate tracker on success.
    try:
        from . import rate_limit
        usage = body.get("usage") or {}
        total = int(usage.get("total_tokens") or 0)
        if total:
            rate_limit.record_request(
                provider=_provider_from_base(config.API_BASE),
                model=chosen_model, tokens=total, ok=True,
            )
    except Exception:
        pass
    return body["choices"][0]["message"]


def chat(
    messages: list[dict[str, Any]],
    tools: list[dict] | None = None,
    json_mode: bool = False,
    temperature: float = 0.7,
    model: str | None = None,
) -> dict:
    """Single chat completion. Returns the raw 'message' object from the response.

    `model` overrides config.MODEL for this call only. Used by swarm
    sub-agents to mix cheap/expensive models per role.

    v1.28.3 — multi-model fall-through. When ``JANUS_MODEL_FALLBACK``
    is set and the primary attempt fails with an infra-shaped error
    (5xx after retry exhaustion / ConnectionError / Timeout), Janus
    transparently retries on the next model in the chain. 4xx errors
    don't trigger fallback (switching model won't fix auth /
    context-length / unknown-model). See ``model_fallback.py``.
    """
    from . import model_fallback as _mfb

    primary = model or config.MODEL
    chain = _mfb.parse_chain(primary)
    if not chain:
        # Defensive — shouldn't happen but degrade gracefully
        chain = [primary]

    last_exc: BaseException | None = None
    for idx, attempt_model in enumerate(chain):
        try:
            return _chat_attempt(
                attempt_model, messages,
                tools=tools, json_mode=json_mode,
                temperature=temperature,
            )
        except BaseException as e:
            # KeyboardInterrupt / SystemExit must propagate immediately
            if not isinstance(e, Exception):
                raise
            last_exc = e
            if not _mfb.is_fallback_trigger(e):
                # Not a fallback-class error — let it bubble normally.
                raise
            # Try the next model in the chain
            if idx + 1 < len(chain):
                _mfb.record_fallback(
                    from_model=attempt_model,
                    to_model=chain[idx + 1],
                    reason=_mfb.reason_string(e),
                )
                continue
            # No next model — give up and raise the last error
            raise
    # Defensive — should be unreachable since we always raise on
    # exhausted chain. Provide a clear error if some future refactor
    # breaks the invariant.
    if last_exc is not None:
        raise last_exc
    raise RuntimeError("model_fallback: chain exhausted with no exception")


def _provider_from_base(api_base: str) -> str:
    """Best-effort provider name from API_BASE host. Used for grouping
    rate-limit / cost data without forcing the user to declare it."""
    try:
        from urllib.parse import urlparse
        host = urlparse(api_base).netloc.lower()
    except Exception:
        return "unknown"
    if "openrouter" in host:
        return "openrouter"
    if "anthropic" in host:
        return "anthropic"
    if "openai" in host:
        return "openai"
    if "ollama" in host or "localhost" in host or "127.0.0.1" in host:
        return "local"
    return host or "unknown"


# ---------- Helpful errors + endpoint introspection (v1.16.1) ----------


def _explain_404(
    model: str, api_base: str, response: requests.Response,
    *, had_tools: bool = False,
) -> RuntimeError:
    """Build an actionable error message for a 404 from /chat/completions.

    Includes:
      - what was tried (URL + model)
      - the most likely cause (provider-prefix mismatch on vLLM-shaped endpoint)
      - a concrete suggestion (the unprefixed model name)
      - how to verify (curl /v1/models)
      - v1.16.2: when the request had tools, suggest JANUS_NO_TOOLS=1
        (self-hosted vLLM without --enable-auto-tool-choice 404s on
        tools-bearing requests)
    """
    base = api_base.rstrip("/")
    provider = _provider_from_base(api_base)
    hints: list[str] = []

    parts = model.split("/")
    if len(parts) >= 2 and provider not in ("openrouter",):
        # 'openai/Foo' / 'meta/Bar' style prefix on a direct endpoint.
        # The first component looks like a namespace the endpoint doesn't
        # use. Suggest stripping it.
        unprefixed = "/".join(parts[1:])
        hints.append(
            f"the prefix {parts[0]!r}/ looks like an OpenRouter-style "
            f"namespace. {provider} endpoints usually serve the model as "
            f"just {unprefixed!r} (no prefix). Try setting "
            f"JANUS_MODEL={unprefixed}"
        )

    if had_tools:
        # The most common reason a self-hosted vLLM 404s on a request that
        # would otherwise succeed: tools payload sent to a vLLM that
        # wasn't started with --enable-auto-tool-choice. The non-tools
        # variant of the SAME request shape returns 200.
        hints.append(
            "the request included a `tools` payload — self-hosted vLLM "
            "endpoints 404 on tools unless started with "
            "`--enable-auto-tool-choice --tool-call-parser <parser>`. "
            "Either: (a) restart vLLM with those flags (recommended for "
            "agent use), or (b) set JANUS_NO_TOOLS=1 in ~/.janus/.env "
            "to send chat-only requests (degraded mode — no tool calls)"
        )

    hints.append(
        f"list what this endpoint actually serves: "
        f"`curl {base}/models`"
    )

    # Try to pull the server's error body too — vLLM sometimes lists the
    # available models in the 404 response. Best-effort.
    server_msg = ""
    try:
        body = response.json()
        if isinstance(body, dict):
            err = body.get("error") or body.get("detail") or body
            if isinstance(err, dict):
                server_msg = err.get("message") or err.get("msg") or ""
            elif isinstance(err, str):
                server_msg = err
    except Exception:
        pass
    if not server_msg:
        # Fall back to a snippet of raw text (capped).
        try:
            server_msg = (response.text or "")[:300].strip()
        except Exception:
            server_msg = ""

    msg_parts = [
        f"404 from {base}/chat/completions for model {model!r} — the "
        f"endpoint doesn't recognize this model id.",
    ]
    if server_msg:
        msg_parts.append(f"  server said: {server_msg}")
    msg_parts.append("  try:")
    for h in hints:
        msg_parts.append(f"    - {h}")
    return RuntimeError("\n".join(msg_parts))


def list_models(api_base: str | None = None,
                api_key: str | None = None,
                timeout: int = 10) -> list[str]:
    """Probe `<base>/models` and return the model ids the endpoint serves.

    Returns [] on any failure (network, auth, malformed body). Used by
    `janus doctor` to surface "what's actually loaded over there."
    """
    base = (api_base or config.API_BASE).rstrip("/")
    key = api_key if api_key is not None else config.API_KEY
    try:
        r = requests.get(
            f"{base}/models",
            headers={"Authorization": f"Bearer {key}"} if key else {},
            timeout=timeout,
        )
        if r.status_code != 200:
            return []
        data = r.json()
    except Exception:
        return []
    # OpenAI shape: {"data": [{"id": "...", ...}, ...]}
    items = data.get("data") if isinstance(data, dict) else None
    if items is None and isinstance(data, dict):
        items = data.get("models")
    if items is None and isinstance(data, list):
        items = data
    if not isinstance(items, list):
        return []
    out: list[str] = []
    for m in items:
        if isinstance(m, dict):
            mid = m.get("id") or m.get("name") or m.get("model")
            if mid:
                out.append(str(mid))
        elif isinstance(m, str):
            out.append(m)
    return out


def chat_stream(messages, tools=None, temperature=0.7, model: str | None = None):
    """Re-export of streaming.chat_stream so callers don't need to import
    a second module just to switch modes. See streaming.py for shape.

    `model` overrides config.MODEL for this call only.
    """
    from . import streaming
    return streaming.chat_stream(
        messages, tools=tools, temperature=temperature, model=model,
    )


def parse_json_loose(raw: str) -> Any:
    """Accept JSON even if the model wrapped it in markdown fences.

    Some smaller models ignore response_format=json_object and emit fenced
    blocks anyway. We strip the fences rather than fail.
    """
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("```", 2)[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.rsplit("```", 1)[0]
    return json.loads(raw.strip())
