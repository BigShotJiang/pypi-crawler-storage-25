"""Gives the module version."""
__version__ = "2.18"
