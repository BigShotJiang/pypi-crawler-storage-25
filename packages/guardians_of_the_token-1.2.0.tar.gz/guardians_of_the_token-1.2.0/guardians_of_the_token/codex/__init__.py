"""Codex CLI hook entrypoints."""
