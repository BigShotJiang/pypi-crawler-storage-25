"""Audition adapter assets."""
