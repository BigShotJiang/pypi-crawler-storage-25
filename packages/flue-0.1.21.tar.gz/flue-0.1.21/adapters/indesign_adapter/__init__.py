"""InDesign adapter assets."""
