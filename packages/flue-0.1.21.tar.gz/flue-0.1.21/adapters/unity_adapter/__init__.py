"""Unity adapter assets."""
