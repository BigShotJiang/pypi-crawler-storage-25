"""Premiere Pro adapter assets."""
