"""Word adapter assets."""
