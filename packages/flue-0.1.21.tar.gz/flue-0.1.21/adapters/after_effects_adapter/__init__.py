"""After Effects adapter assets."""
