"""Photoshop adapter assets."""
