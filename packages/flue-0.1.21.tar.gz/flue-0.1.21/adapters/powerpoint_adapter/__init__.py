"""PowerPoint adapter assets."""
