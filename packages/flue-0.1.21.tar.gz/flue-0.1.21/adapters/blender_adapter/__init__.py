"""Blender adapter assets."""
