"""Houdini adapter assets."""
