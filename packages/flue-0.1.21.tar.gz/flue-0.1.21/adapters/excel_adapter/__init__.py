"""Excel adapter assets."""
