"""Illustrator adapter assets."""
