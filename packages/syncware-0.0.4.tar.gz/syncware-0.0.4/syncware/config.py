#!/usr/bin/env python3
"""Configuration loading for syncware."""


class ConfigError(Exception):
    """Raised when configuration loading fails."""

    pass


def load_config(config_path="syncware.yml"):
    """Load syncware configuration from YAML file.

    Raises:
        ConfigError: If the config file does not exist or cannot be parsed.
    """
    from pathlib import Path

    import yaml

    path = Path(config_path)
    if not path.exists():
        raise ConfigError(f"Config file not found: {config_path}")
    with open(path) as f:
        return yaml.safe_load(f)