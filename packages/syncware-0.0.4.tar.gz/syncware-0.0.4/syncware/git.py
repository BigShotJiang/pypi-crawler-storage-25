#!/usr/bin/env python3
"""Git operations and remote repository handling."""

import shutil
import subprocess
from pathlib import Path

from syncware.logging_ import print_msg


def is_remote_url(path):
    """Check if path is a remote Git URL (GitHub, GitLab, etc.)."""
    if not isinstance(path, str):
        return False
    remote_prefixes = (
        "http://",
        "https://",
        "git://",
        "git@",
        "ssh://",
    )
    return any(path.startswith(p) for p in remote_prefixes)


def clone_repo(url, clone_dir):
    """Clone a remote repository to a local directory."""
    clone_path = Path(clone_dir)
    clone_path.mkdir(parents=True, exist_ok=True)

    try:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", url, str(clone_path)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print_msg(f"Clone failed: {result.stderr.strip()}", "error")
            return None
        return clone_path
    except Exception as e:
        print_msg(f"Clone error: {e}", "error")
        return None


def resolve_repo_path(repo_config, force_clone=False):
    """Resolve repo path: if URL, clone to cache and return local path."""
    path = repo_config["path"]
    name = repo_config.get("name", "remote")

    if is_remote_url(path):
        cache_dir = Path.home() / ".cache" / "syncware" / name
        if cache_dir.exists() and not force_clone:
            return cache_dir
        if cache_dir.exists():
            shutil.rmtree(cache_dir)
        print_msg(f"Cloning {path}...", "info")
        cloned = clone_repo(path, cache_dir)
        if cloned:
            return cloned
        return None
    return Path(path)


def get_git_commit(repo_path):
    """Get current git commit hash of a repo. Return None if not a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None
