#!/usr/bin/env python3
"""Core utilities for folder synchronization."""

import hashlib
from pathlib import Path


def get_all_folders(repo_path, source):
    """Get all subdirectories in source folder."""
    source_path = Path(repo_path) / source
    if not source_path.exists():
        return []
    return [d.name for d in source_path.iterdir() if d.is_dir()]


def dir_hash(path):
    """Compute a hash of all files in a directory (recursive)."""
    path = Path(path)
    if not path.exists():
        return None
    hasher = hashlib.sha256()
    for item in sorted(path.rglob("*")):
        if item.is_file():
            hasher.update(item.name.encode())
            hasher.update(item.read_bytes())
    return hasher.hexdigest()


def has_changed(src, dst):
    """Check if source directory has changed compared to destination."""
    src_hash = dir_hash(src)
    dst_hash = dir_hash(dst)
    if src_hash is None:
        return False
    if dst_hash is None:
        return True
    return src_hash != dst_hash


def resolve_folders(repo_config):
    """Resolve folder list from config, handling wildcard."""
    folders = repo_config.get("folders", [])
    if folders == "*" or (
        isinstance(folders, list) and "*" in folders and len(folders) == 1
    ):
        return get_all_folders(
            repo_config["path"], repo_config.get("source", repo_config.get("entry", ""))
        )
    return folders
