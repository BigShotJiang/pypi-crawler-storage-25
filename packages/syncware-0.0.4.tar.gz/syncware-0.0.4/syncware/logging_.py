#!/usr/bin/env python3
"""
Logging utilities for syncware CLI.
"""

import logging
import sys

try:
    from termcolor import colored

    HAS_TERMCOLOR = True
except ImportError:
    HAS_TERMCOLOR = False


LOGGER = logging.getLogger("syncware")


def c(text, c_name):
    """Colorize text if termcolor is available."""
    if not HAS_TERMCOLOR:
        return text
    colors_map = {
        "header": "\033[95m",
        "blue": "\033[94m",
        "cyan": "\033[96m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "red": "\033[91m",
        "bold": "\033[1m",
    }
    return f"{colors_map.get(c_name, '')}{text}\033[0m"


class ColoredFormatter(logging.Formatter):
    """Custom formatter with colored level prefixes."""

    LEVEL_COLORS = {
        "DEBUG": "cyan",
        "INFO": "blue",
        "WARNING": "yellow",
        "ERROR": "red",
        "CRITICAL": "red",
    }

    def format(self, record):
        levelname = record.levelname
        prefix = {
            "DEBUG": "[D]",
            "INFO": "[*]",
            "WARNING": "[!]",
            "ERROR": "[x]",
            "CRITICAL": "[X]",
        }.get(levelname, "[*]")
        color = self.LEVEL_COLORS.get(levelname, "blue")
        record.levelprefix = c(prefix, color)
        return f"{record.levelprefix} {record.getMessage()}"


def setup_logging(verbosity=0):
    """Configure logging based on verbosity level."""
    level = logging.DEBUG if verbosity >= 2 else logging.INFO

    LOGGER.setLevel(level)
    LOGGER.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    handler.setFormatter(ColoredFormatter("%(message)s"))
    LOGGER.addHandler(handler)

    return LOGGER


def print_msg(msg, level="info"):
    """Log a message at the specified level."""
    level_map = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "success": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
    }
    LOGGER.log(level_map.get(level, logging.INFO), msg)
