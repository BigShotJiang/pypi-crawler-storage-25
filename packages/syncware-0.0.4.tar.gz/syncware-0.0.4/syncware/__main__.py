from syncware import main

if __name__ == "__main__":
    main()
