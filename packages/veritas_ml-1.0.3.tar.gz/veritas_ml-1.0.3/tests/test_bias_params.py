"""Tests for bias_params.json protected attribute discovery."""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

from veritas.utils.bias_params import require_protected_attributes


class TestBiasParams(unittest.TestCase):
    def test_loads_from_current_working_directory_before_parameter(self):
        previous = os.getcwd()
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "bias_params.json").write_text(
                json.dumps({"protected_attributes": ["sex", "race"]}),
                encoding="utf-8",
            )
            os.chdir(tmp)
            try:
                attrs = require_protected_attributes(["fallback"])
            finally:
                os.chdir(previous)

        self.assertEqual(attrs, ["sex", "race"])

    def test_loads_from_main_script_directory(self):
        previous = os.getcwd()
        main_module = sys.modules["__main__"]
        had_main_file = hasattr(main_module, "__file__")
        old_main_file = getattr(main_module, "__file__", None)

        with tempfile.TemporaryDirectory() as cwd_tmp, tempfile.TemporaryDirectory() as script_tmp:
            Path(script_tmp, "bias_params.json").write_text(
                json.dumps({"protected_attributes": ["age"]}),
                encoding="utf-8",
            )
            main_module.__file__ = str(Path(script_tmp, "main.py"))
            os.chdir(cwd_tmp)
            try:
                attrs = require_protected_attributes()
            finally:
                os.chdir(previous)
                if had_main_file:
                    main_module.__file__ = old_main_file
                else:
                    delattr(main_module, "__file__")

        self.assertEqual(attrs, ["age"])

    def test_falls_back_to_constructor_parameter(self):
        previous = os.getcwd()
        with tempfile.TemporaryDirectory() as tmp:
            os.chdir(tmp)
            try:
                attrs = require_protected_attributes("gender")
            finally:
                os.chdir(previous)

        self.assertEqual(attrs, ["gender"])

    def test_invalid_json_raises_clear_error(self):
        previous = os.getcwd()
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "bias_params.json").write_text("{bad json", encoding="utf-8")
            os.chdir(tmp)
            try:
                with self.assertRaisesRegex(ValueError, "Invalid JSON"):
                    require_protected_attributes(["fallback"])
            finally:
                os.chdir(previous)


if __name__ == "__main__":
    unittest.main()
