"""Tests for BiasDetector."""

import json
import os
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression

from veritas import BiasDetector


@contextmanager
def bias_params_cwd(protected_attributes):
    previous = os.getcwd()
    with tempfile.TemporaryDirectory() as tmp:
        params_path = Path(tmp) / "bias_params.json"
        params_path.write_text(
            json.dumps({"protected_attributes": protected_attributes}),
            encoding="utf-8",
        )
        os.chdir(tmp)
        try:
            yield params_path
        finally:
            os.chdir(previous)


class TestBiasDetector(unittest.TestCase):
    """Test cases for BiasDetector."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        self.X_train = np.random.randn(200, 5)
        self.y_train = np.random.randint(0, 2, 200)
        self.sensitive_train = np.random.choice(["Male", "Female"], 200)

        self.X_test = np.random.randn(50, 5)
        self.y_test = np.random.randint(0, 2, 50)
        self.sensitive_test = np.random.choice(["Male", "Female"], 50)

    def test_detector_initialization(self):
        """Test detector can be initialized."""
        detector = BiasDetector(
            protected_attribute="gender",
            privileged_classes=[["Male"]]
        )
        self.assertEqual(detector.protected_attribute, "gender")
        self.assertEqual(detector.privileged_classes, [["Male"]])

    def test_audit_returns_report(self):
        """Test audit returns a report dict."""
        # Train a simple model
        model = LogisticRegression(max_iter=500)
        model.fit(self.X_train, self.y_train)

        detector = BiasDetector(
            protected_attribute="gender",
            privileged_classes=[["Male"]]
        )

        report = detector.audit(
            model, self.X_test, self.y_test, self.sensitive_test
        )

        self.assertIsInstance(report, dict)
        self.assertIn("dataset_metrics", report)
        self.assertIn("classification_metrics", report)
        self.assertIn("bias_issues", report)

    def test_report_has_required_fields(self):
        """Test report has all required fields."""
        model = LogisticRegression(max_iter=500)
        model.fit(self.X_train, self.y_train)

        with bias_params_cwd(["gender"]):
            detector = BiasDetector()
            report = detector.audit(model, self.X_test, self.y_test, self.sensitive_test)

        # Check dataset metrics
        dm = report["dataset_metrics"]
        self.assertIn("disparate_impact", dm)
        self.assertIn("statistical_parity_difference", dm)

        # Check classification metrics
        cm = report["classification_metrics"]
        self.assertIn("accuracy_overall", cm)
        self.assertIn("equal_opportunity_difference", cm)
        self.assertIn("average_odds_difference", cm)
        self.assertIn("theil_index", cm)


if __name__ == "__main__":
    unittest.main()
