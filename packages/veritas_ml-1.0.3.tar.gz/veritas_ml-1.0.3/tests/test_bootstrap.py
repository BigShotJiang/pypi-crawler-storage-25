"""Tests for import-time bootstrap behavior."""

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from veritas import _bootstrap


class TestBootstrap(unittest.TestCase):
    def test_skips_when_vector_store_path_exists(self):
        with tempfile.TemporaryDirectory() as tmp:
            vector_store = Path(tmp) / "vector_store"
            vector_store.mkdir()
            with patch.object(_bootstrap, "VECTOR_STORE_PATH", vector_store), patch(
                "veritas.knowledge.ingest.knowledge_base.ensure_default_knowledge_bases"
            ) as ensure:
                _bootstrap._ensure_initialized()
            ensure.assert_not_called()

    def test_delegates_first_run_ingestion_to_shared_service(self):
        with tempfile.TemporaryDirectory() as tmp:
            vector_store = Path(tmp) / "vector_store"
            with patch.object(_bootstrap, "VERITAS_HOME", Path(tmp)), patch.object(
                _bootstrap, "VECTOR_STORE_PATH", vector_store
            ), patch(
                "veritas.knowledge.ingest.knowledge_base.ensure_default_knowledge_bases",
                return_value={},
            ) as ensure:
                _bootstrap._ensure_initialized()
            ensure.assert_called_once_with(force=False)


if __name__ == "__main__":
    unittest.main()
