"""Tests for the simplified pipeline API."""

import unittest

import numpy as np
from sklearn.linear_model import LogisticRegression

from veritas import AuditConfig, PipelineResult, audit_predictions, run_pipeline


class TestPipelineAPI(unittest.TestCase):
    def setUp(self):
        np.random.seed(42)
        self.X = np.random.randn(80, 4)
        self.sensitive = np.r_[np.zeros(40, dtype=int), np.ones(40, dtype=int)]
        self.y = np.r_[np.random.binomial(1, 0.25, 40), np.random.binomial(1, 0.75, 40)]
        self.config = AuditConfig(protected_attributes=["sex"])

    def test_audit_predictions_returns_structured_result(self):
        result = audit_predictions(
            y_true=self.y,
            y_pred=self.y,
            sensitive=self.sensitive,
            config=self.config,
            X=self.X,
        )

        payload = result.to_dict()
        self.assertIn("dataset_metrics", payload)
        self.assertIn("classification_metrics", payload)
        self.assertIn("groups", payload)
        self.assertIn("reports_by_attribute", payload)

    def test_run_pipeline_returns_pipeline_result(self):
        result = run_pipeline(
            LogisticRegression(max_iter=500),
            self.X,
            self.y,
            self.sensitive,
            self.config,
            strategy="none",
            generate_report=False,
        )

        self.assertIsInstance(result, PipelineResult)
        payload = result.to_dict()
        self.assertIn("bias_report", payload)
        self.assertIn("rag_context", payload)
        self.assertIsNone(payload["report"])


if __name__ == "__main__":
    unittest.main()
