"""Report generation facade for the simplified Veritas pipeline."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .config import Config
from .core.llm import LLM
from .metrics import AuditResult
from .mitigation import MitigationResult
from .utils.report import build_report_messages, derive_ethics_concerns, format_bias_report


REQUIRED_REPORT_SECTIONS = [
    "Executive Summary",
    "Pipeline Summary",
    "Bias Found",
    "Mitigation Applied",
    "Compliance Status",
]


def build_report_context(
    audit: AuditResult,
    mitigation: Optional[MitigationResult] = None,
    rag_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build the structured report context shared by deterministic and LLM reports."""
    pre_report = audit.to_dict()
    post_report = mitigation.after.to_dict() if mitigation and mitigation.after else pre_report
    mitigation_payload = mitigation.to_dict() if mitigation else {}
    concerns = derive_ethics_concerns(
        pre_report.get("bias_issues", []),
        mitigation_payload.get("technique"),
    )

    if rag_context:
        law_matches = rag_context.get("law_matches", [])
        for concern, law_match in zip(concerns, law_matches):
            concern["rag_law_context"] = law_match.get("results")
        if concerns:
            concerns[0]["rag_algorithm_context"] = rag_context.get("algorithm_matches")
            concerns[0]["rag_algorithm_recommendation"] = rag_context.get("algorithm_recommendation")

    return {
        "dataset_name": audit.dataset_name,
        "model_name": audit.model_name or "model",
        "protected_attribute": audit.protected_attributes[0],
        "protected_attributes": audit.protected_attributes,
        "protected_groups": audit.groups,
        "pre_mitigation_report": pre_report,
        "post_mitigation_report": post_report,
        "mitigation_applied": bool(mitigation and mitigation.applied),
        "mitigation_result": mitigation_payload,
        "mitigation_summary": mitigation.message if mitigation else "No mitigation was applied.",
        "pipeline_steps": [
            "Normalized model features, labels, and protected attributes.",
            "Computed AIF360 dataset and classification fairness metrics.",
            "Retrieved AI ethics and mitigation context from the bundled knowledge base.",
            "Applied and re-audited mitigation when bias was detected.",
            "Generated the final report from structured pipeline results.",
        ],
        "ethics_concerns": concerns,
        "rag_retrieval": rag_context or {},
        "bias_examples": [],
        "mitigation_examples": [],
        "code_snippets": [],
    }


def generate_report(
    audit: AuditResult,
    mitigation: Optional[MitigationResult] = None,
    rag_context: Optional[Dict[str, Any]] = None,
    llm_provider: Optional[str] = None,
) -> str:
    """Generate an LLM report when possible, otherwise deterministic markdown."""
    context = build_report_context(audit, mitigation, rag_context)
    if llm_provider is not None:
        try:
            candidate = LLM(Config(llm_provider_override=llm_provider)).invoke(
                build_report_messages(context)
            )
            if all(section in candidate for section in REQUIRED_REPORT_SECTIONS):
                return candidate
        except Exception:
            pass

    pre_report = context["pre_mitigation_report"]
    post_report = context["post_mitigation_report"]
    mitigation_payload = context.get("mitigation_result", {})
    return format_bias_report(
        bias_report=pre_report,
        privileged_groups=audit.groups.get("privileged", {}),
        unprivileged_groups=audit.groups.get("unprivileged", {}),
        mitigation_applied=context["mitigation_applied"],
        mitigation_technique=mitigation_payload.get("technique"),
        pre_mitigation_metrics=pre_report,
        post_mitigation_metrics=post_report,
        dataset_name=audit.dataset_name,
        model_name=audit.model_name,
        protected_attribute=audit.protected_attributes[0],
        protected_attributes=audit.protected_attributes,
        ethics_concerns=context["ethics_concerns"],
        pipeline_steps=context["pipeline_steps"],
        mitigation_summary=context["mitigation_summary"],
        rag_context=rag_context or {},
    )
