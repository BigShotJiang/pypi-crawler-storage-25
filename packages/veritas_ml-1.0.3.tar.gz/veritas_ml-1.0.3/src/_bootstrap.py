"""Import-time knowledge-base initialization for Veritas."""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["ANONYMIZED_TELEMETRY"] = "False"
os.environ["CHROMADB_TELEMETRY"] = "False"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

VERITAS_HOME = Path.home() / ".veritas"
VECTOR_STORE_PATH = VERITAS_HOME / "vector_store"


def _ensure_initialized() -> None:
    """Ensure bundled knowledge bases exist without blocking normal imports on failure."""
    if VECTOR_STORE_PATH.exists():
        return

    try:
        VERITAS_HOME.mkdir(parents=True, exist_ok=True)
        from .knowledge.ingest import knowledge_base

        knowledge_base.ensure_default_knowledge_bases(force=False)
    except Exception as exc:
        print(
            f"[veritas] Warning: failed to initialize knowledge base: {exc}",
            file=sys.stderr,
        )
