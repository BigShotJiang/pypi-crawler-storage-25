"""Canonical mitigation execution for Veritas."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from inspect import signature
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, clone

from .core.tracing import make_json_safe, traceable
from .data import (
    AuditConfig,
    as_dataframe,
    as_sensitive_frame,
    as_series,
    build_standard_dataset,
    encode_sensitive_attribute,
    predict_with_optional_sensitive,
)
from .metrics import AuditResult, audit_model


@dataclass(frozen=True)
class MitigationTechnique:
    """Registry metadata for a mitigation technique."""

    name: str
    type: str
    requires_sample_weight: bool = False
    requires_predict_proba: bool = False


TECHNIQUES: Dict[str, MitigationTechnique] = {
    "reweighing": MitigationTechnique("reweighing", "preprocessing", requires_sample_weight=True),
    "prejudice_remover": MitigationTechnique("prejudice_remover", "inprocessing"),
    "reject_option": MitigationTechnique("reject_option", "postprocessing", requires_predict_proba=True),
    "eqodds": MitigationTechnique("eqodds", "postprocessing"),
    "calibrated_eqodds": MitigationTechnique("calibrated_eqodds", "postprocessing", requires_predict_proba=True),
    "disparate_impact_remover": MitigationTechnique("disparate_impact_remover", "preprocessing"),
    "learning_fair_representations": MitigationTechnique("learning_fair_representations", "preprocessing"),
    "meta_fair_classifier": MitigationTechnique("meta_fair_classifier", "inprocessing"),
}


@dataclass
class MitigationResult:
    """Structured result from mitigation."""

    technique: str
    status: str
    applied: bool
    estimator: Optional[Any] = None
    type: Optional[str] = None
    before: Optional[AuditResult] = None
    after: Optional[AuditResult] = None
    message: str = ""
    candidate_results: List[Dict[str, Any]] = field(default_factory=list)
    sample_weight_summary: Optional[Dict[str, Any]] = None
    fallback_reason: Optional[str] = None
    selection_score: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return make_json_safe({
            "technique": self.technique,
            "status": self.status,
            "applied": self.applied,
            "type": self.type,
            "message": self.message,
            "candidate_results": self.candidate_results,
            "sample_weight_summary": self.sample_weight_summary,
            "fallback_reason": self.fallback_reason,
            "selection_score": self.selection_score,
            "before_metrics": self.before.to_dict() if self.before else None,
            "after_metrics": self.after.to_dict() if self.after else None,
        })


def supports_sample_weight(estimator: Any) -> bool:
    """Return True when estimator.fit accepts sample_weight."""
    try:
        return "sample_weight" in signature(estimator.fit).parameters
    except (TypeError, ValueError):
        return False


def _with_python_on_path(callback: Any) -> Any:
    original_path = os.environ.get("PATH", "")
    python_dir = str(Path(sys.executable).parent)
    if python_dir not in original_path.split(os.pathsep):
        os.environ["PATH"] = python_dir + os.pathsep + original_path
    try:
        return callback()
    finally:
        os.environ["PATH"] = original_path


class AIF360EstimatorAdapter:
    """Expose AIF360 dataset-based estimators through sklearn-like predict APIs."""

    def __init__(self, model: Any, protected_attr: str, privileged_val: int):
        self.model = model
        self.protected_attr = protected_attr
        self.privileged_val = int(privileged_val)

    def _to_dataset(
        self,
        X: Union[pd.DataFrame, np.ndarray, List[List[float]]],
        sensitive_features: Union[pd.Series, pd.DataFrame, np.ndarray, List[Any]],
    ):
        X_df = as_dataframe(X)
        sensitive_df = as_sensitive_frame(sensitive_features, [self.protected_attr])
        sensitive_encoded, _ = encode_sensitive_attribute(sensitive_df[self.protected_attr])
        dummy_y = pd.Series(np.zeros(len(X_df), dtype=int), name="label")
        return build_standard_dataset(
            X_df,
            dummy_y,
            sensitive_encoded,
            self.protected_attr,
            [self.privileged_val],
        )

    def predict(self, X, sensitive_features=None) -> np.ndarray:
        if sensitive_features is None:
            raise ValueError("Mitigated estimator requires sensitive_features for prediction.")
        dataset = self._to_dataset(X, sensitive_features)
        return _with_python_on_path(
            lambda: self.model.predict(dataset).labels.ravel().astype(int)
        )

    def predict_proba(self, X, sensitive_features=None) -> np.ndarray:
        if sensitive_features is None:
            raise ValueError("Mitigated estimator requires sensitive_features for prediction.")
        dataset = self._to_dataset(X, sensitive_features)
        scores = np.asarray(
            _with_python_on_path(lambda: self.model.predict(dataset).scores)
        ).ravel()
        scores = np.clip(scores, 0.0, 1.0)
        return np.column_stack([1.0 - scores, scores])


class PostprocessedEstimatorAdapter:
    """Apply an AIF360 postprocessor on top of a base estimator."""

    def __init__(self, base_estimator: BaseEstimator, postprocessor: Any, protected_attr: str, privileged_val: int):
        self.base_estimator = base_estimator
        self.postprocessor = postprocessor
        self.protected_attr = protected_attr
        self.privileged_val = int(privileged_val)

    def _base_predictions(self, X) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
        X_df = as_dataframe(X)
        predictions = np.asarray(self.base_estimator.predict(X_df)).astype(int)
        if hasattr(self.base_estimator, "predict_proba"):
            scores = self.base_estimator.predict_proba(X_df)[:, 1]
        elif hasattr(self.base_estimator, "decision_function"):
            decision = self.base_estimator.decision_function(X_df)
            scores = 1.0 / (1.0 + np.exp(-np.asarray(decision)))
        else:
            scores = predictions.astype(float)
        return X_df, predictions, np.asarray(scores).ravel()

    def predict(self, X, sensitive_features=None) -> np.ndarray:
        if sensitive_features is None:
            raise ValueError("Postprocessed estimator requires sensitive_features for prediction.")
        X_df, base_predictions, base_scores = self._base_predictions(X)
        sensitive_df = as_sensitive_frame(sensitive_features, [self.protected_attr])
        sensitive_encoded, _ = encode_sensitive_attribute(sensitive_df[self.protected_attr])
        dataset = build_standard_dataset(
            X_df,
            pd.Series(base_predictions, name="label"),
            sensitive_encoded,
            self.protected_attr,
            [self.privileged_val],
        )
        dataset.scores = base_scores.reshape(-1, 1)
        return self.postprocessor.predict(dataset).labels.ravel().astype(int)

    def predict_proba(self, X, sensitive_features=None) -> np.ndarray:
        _, _, scores = self._base_predictions(X)
        scores = np.clip(scores, 0.0, 1.0)
        if sensitive_features is not None:
            adjusted = self.predict(X, sensitive_features=sensitive_features).astype(float)
            scores = 0.5 * scores + 0.5 * adjusted
        return np.column_stack([1.0 - scores, scores])


def candidate_names(estimator: Any, strategy: str = "auto") -> List[str]:
    """Return executable mitigation candidates for a strategy."""
    requested = (strategy or "auto").lower()
    if requested != "auto":
        return [requested] if requested in TECHNIQUES else []

    names: List[str] = []
    if supports_sample_weight(estimator):
        names.append("reweighing")
    names.append("prejudice_remover")
    if hasattr(estimator, "predict_proba"):
        names.extend(["reject_option", "calibrated_eqodds", "eqodds"])
    else:
        names.append("eqodds")
    return names


def mitigation_score(report: Optional[AuditResult]) -> float:
    """Lower scores represent fewer residual issues and smaller fairness penalties."""
    if report is None:
        return float("inf")
    payload = report.to_dict()
    dataset_metrics = payload.get("dataset_metrics", {})
    classification_metrics = payload.get("classification_metrics", {})
    issue_count = int(payload.get("issue_count", 0))
    di = dataset_metrics.get("disparate_impact")
    if di is None or not np.isfinite(float(di)) or float(di) <= 0:
        di_penalty = 2.0
    else:
        di_penalty = min(abs(np.log(float(di))), 2.0)
    fairness_penalty = (
        di_penalty
        + abs(float(dataset_metrics.get("statistical_parity_difference", 0.0) or 0.0))
        + abs(float(classification_metrics.get("equal_opportunity_difference", 0.0) or 0.0))
        + abs(float(classification_metrics.get("average_odds_difference", 0.0) or 0.0))
        + min(float(classification_metrics.get("theil_index", 0.0) or 0.0), 2.0)
    )
    accuracy = float(classification_metrics.get("accuracy_overall", 0.0) or 0.0)
    return round((issue_count * 10.0) + fairness_penalty + max(0.0, 1.0 - accuracy), 6)


def _fit_candidate(
    name: str,
    base_estimator: BaseEstimator,
    X_df: pd.DataFrame,
    y_series: pd.Series,
    sensitive_encoded: np.ndarray,
    protected_attr: str,
    privileged_val: int,
    unprivileged_val: int,
) -> Tuple[Optional[Any], Dict[str, Any]]:
    if name not in TECHNIQUES:
        return None, {"technique": name, "status": "unsupported", "applied": False}

    technique = TECHNIQUES[name]
    result = {
        "technique": name,
        "type": technique.type,
        "status": "failed",
        "applied": False,
    }
    privileged_groups = [{protected_attr: int(privileged_val)}]
    unprivileged_groups = [{protected_attr: int(unprivileged_val)}]

    if name in {"disparate_impact_remover", "learning_fair_representations", "meta_fair_classifier"}:
        result["status"] = "unsupported"
        result["fallback_reason"] = f"{name} is registered but not enabled in this simplified runtime."
        return None, result

    if name == "reweighing":
        from aif360.algorithms.preprocessing import Reweighing

        if not supports_sample_weight(base_estimator):
            result["fallback_reason"] = "base estimator does not support sample_weight."
            return None, result
        dataset = build_standard_dataset(
            X_df,
            y_series,
            sensitive_encoded,
            protected_attr,
            [privileged_val],
        )
        rw = Reweighing(
            unprivileged_groups=unprivileged_groups,
            privileged_groups=privileged_groups,
        )
        rw.fit(dataset)
        sample_weights = rw.transform(dataset).instance_weights
        estimator = clone(base_estimator)
        estimator.fit(X_df, y_series, sample_weight=sample_weights)
        result.update({
            "status": "success",
            "applied": True,
            "sample_weight_summary": {
                "min": float(np.min(sample_weights)),
                "max": float(np.max(sample_weights)),
                "unique_count": int(np.unique(np.round(sample_weights, 8)).size),
            },
        })
        return estimator, result

    if name == "prejudice_remover":
        from aif360.algorithms.inprocessing import PrejudiceRemover

        dataset = build_standard_dataset(
            X_df,
            y_series,
            sensitive_encoded,
            protected_attr,
            [privileged_val],
        )
        model = PrejudiceRemover(eta=1.0, sensitive_attr=protected_attr, class_attr="label")
        _with_python_on_path(lambda: model.fit(dataset))
        result.update({"status": "success", "applied": True})
        return AIF360EstimatorAdapter(model, protected_attr, privileged_val), result

    if name in {"reject_option", "eqodds", "calibrated_eqodds"}:
        from aif360.algorithms.postprocessing import (
            CalibratedEqOddsPostprocessing,
            EqOddsPostprocessing,
            RejectOptionClassification,
        )

        estimator = clone(base_estimator)
        estimator.fit(X_df, y_series)
        predictions = np.asarray(estimator.predict(X_df)).astype(int)
        if hasattr(estimator, "predict_proba"):
            scores = estimator.predict_proba(X_df)[:, 1]
        elif hasattr(estimator, "decision_function"):
            scores = 1.0 / (1.0 + np.exp(-np.asarray(estimator.decision_function(X_df))))
        else:
            scores = predictions.astype(float)

        truth_dataset = build_standard_dataset(
            X_df,
            y_series,
            sensitive_encoded,
            protected_attr,
            [privileged_val],
        )
        pred_dataset = build_standard_dataset(
            X_df,
            pd.Series(predictions, name="label"),
            sensitive_encoded,
            protected_attr,
            [privileged_val],
        )
        pred_dataset.scores = np.asarray(scores).reshape(-1, 1)

        if name == "reject_option":
            postprocessor = RejectOptionClassification(
                unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups,
                metric_name="Statistical parity difference",
                metric_lb=-0.05,
                metric_ub=0.05,
            )
        elif name == "eqodds":
            postprocessor = EqOddsPostprocessing(
                unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups,
            )
        else:
            postprocessor = CalibratedEqOddsPostprocessing(
                unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups,
            )

        postprocessor.fit(truth_dataset, pred_dataset)
        result.update({"status": "success", "applied": True})
        return PostprocessedEstimatorAdapter(estimator, postprocessor, protected_attr, privileged_val), result

    return None, result


@traceable(name="veritas_mitigate_model", run_type="chain", tags=["veritas", "mitigation"])
def mitigate_model(
    base_estimator: BaseEstimator,
    X: Union[pd.DataFrame, np.ndarray, List[List[float]]],
    y: Union[pd.Series, np.ndarray, List[Any]],
    sensitive: Union[pd.Series, pd.DataFrame, np.ndarray, List[Any]],
    config: AuditConfig,
    strategy: str = "auto",
) -> MitigationResult:
    """Fit mitigation candidates and return the best audited estimator."""
    X_df = as_dataframe(X)
    y_series = as_series(y)
    sensitive_df = as_sensitive_frame(sensitive, list(config.protected_attributes))
    protected_attr = config.primary_attribute
    sensitive_encoded, _ = encode_sensitive_attribute(sensitive_df[protected_attr])

    baseline = clone(base_estimator)
    baseline.fit(X_df, y_series)
    before = audit_model(baseline, X_df, y_series, sensitive_df, config)
    groups = before.groups
    privileged_val = int(groups.get("privileged", {}).get(protected_attr, [1])[0])
    unprivileged_val = int(groups.get("unprivileged", {}).get(protected_attr, [0])[0])

    candidates = candidate_names(base_estimator, strategy)
    result_rows: List[Dict[str, Any]] = []
    successful: List[Tuple[float, Any, Dict[str, Any], AuditResult]] = []

    if not candidates:
        return MitigationResult(
            technique=strategy,
            status="unsupported",
            applied=False,
            estimator=baseline,
            before=before,
            after=before,
            message=f"No mitigation candidates available for strategy `{strategy}`.",
            fallback_reason="No registered candidate matched the requested strategy.",
        )

    for candidate in candidates:
        try:
            estimator, row = _fit_candidate(
                candidate,
                base_estimator,
                X_df,
                y_series,
                sensitive_encoded,
                protected_attr,
                privileged_val,
                unprivileged_val,
            )
            if estimator is not None and row.get("applied"):
                after = audit_model(estimator, X_df, y_series, sensitive_df, config)
                score = mitigation_score(after)
                row["selection_score"] = score
                row["after_metrics"] = after.to_dict()
                successful.append((score, estimator, row, after))
            result_rows.append(row)
        except Exception as exc:
            result_rows.append({
                "technique": candidate,
                "status": "failed",
                "applied": False,
                "fallback_reason": str(exc),
            })

    if not successful:
        return MitigationResult(
            technique=strategy,
            status="failed",
            applied=False,
            estimator=baseline,
            before=before,
            after=before,
            message="No mitigation candidate completed successfully.",
            candidate_results=result_rows,
            fallback_reason="No mitigation candidate completed successfully.",
        )

    score, estimator, best_row, after = min(successful, key=lambda item: item[0])
    return MitigationResult(
        technique=best_row["technique"],
        status="success",
        applied=True,
        estimator=estimator,
        type=best_row.get("type"),
        before=before,
        after=after,
        message=f"Selected `{best_row['technique']}` from {len(successful)} successful candidate(s).",
        candidate_results=result_rows,
        sample_weight_summary=best_row.get("sample_weight_summary"),
        fallback_reason=best_row.get("fallback_reason"),
        selection_score=score,
    )
