"""Bias detection adapter over the canonical Veritas audit functions."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator

from .data import AuditConfig
from .metrics import audit_model


class BiasDetector:
    """Compatibility adapter for manual model audits."""

    def __init__(
        self,
        protected_attributes: List[str] = None,
        privileged_groups: Optional[Dict[str, List[Any]]] = None,
        unprivileged_groups: Optional[Dict[str, List[Any]]] = None,
        favorable_classes: Optional[List[Any]] = None,
        categorical_features: Optional[List[str]] = None,
        protected_attribute: Optional[str] = None,
        privileged_classes: Optional[List[Any]] = None,
        unprivileged_classes: Optional[List[Any]] = None,
        dataset_name: str = "dataset",
        model_name: Optional[str] = None,
    ):
        fallback_attrs = protected_attributes if protected_attributes is not None else protected_attribute
        resolved_privileged = privileged_groups
        resolved_unprivileged = unprivileged_groups

        if resolved_privileged is None and privileged_classes is not None and fallback_attrs is not None:
            primary = fallback_attrs[0] if isinstance(fallback_attrs, list) else fallback_attrs
            first_group = (
                privileged_classes[0]
                if privileged_classes and isinstance(privileged_classes[0], list)
                else privileged_classes
            )
            resolved_privileged = {primary: first_group}
        if resolved_unprivileged is None and unprivileged_classes is not None and fallback_attrs is not None:
            primary = fallback_attrs[0] if isinstance(fallback_attrs, list) else fallback_attrs
            first_group = (
                unprivileged_classes[0]
                if unprivileged_classes and isinstance(unprivileged_classes[0], list)
                else unprivileged_classes
            )
            resolved_unprivileged = {primary: first_group}

        self.config = AuditConfig(
            protected_attributes=fallback_attrs,
            privileged_groups=resolved_privileged,
            unprivileged_groups=resolved_unprivileged,
            favorable_classes=favorable_classes or [1, "1", "yes", "Yes", True],
            categorical_features=categorical_features or [],
            dataset_name=dataset_name,
            model_name=model_name,
        )
        self.protected_attributes = list(self.config.protected_attributes)
        self.protected_attribute = self.config.primary_attribute
        self.privileged_groups = self.config.privileged_groups
        self.unprivileged_groups = self.config.unprivileged_groups
        self.privileged_classes = privileged_classes
        self.unprivileged_classes = unprivileged_classes
        self.favorable_classes = self.config.favorable_classes
        self.categorical_features = self.config.categorical_features
        self._last_result = None

    def audit(
        self,
        model: BaseEstimator,
        X_test: Union[pd.DataFrame, np.ndarray],
        y_test: Union[pd.Series, np.ndarray],
        sensitive_features: Union[pd.Series, np.ndarray, pd.DataFrame],
        label_name: str = "label",
    ) -> Dict[str, Any]:
        del label_name
        self._last_result = audit_model(
            model=model,
            X=X_test,
            y=y_test,
            sensitive=sensitive_features,
            config=self.config,
        )
        return self._last_result.to_dict()

    def get_detected_groups(self) -> Optional[Dict[str, Dict[str, List[int]]]]:
        if self._last_result is None:
            return None
        return self._last_result.groups
