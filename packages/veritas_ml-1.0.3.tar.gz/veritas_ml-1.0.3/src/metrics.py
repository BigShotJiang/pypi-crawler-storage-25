"""Canonical fairness metric computation for Veritas."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd

from .data import (
    AuditConfig,
    as_dataframe,
    as_sensitive_frame,
    as_series,
    build_standard_dataset,
    choose_favorable_class,
    encode_sensitive_attribute,
    predict_with_optional_sensitive,
    resolve_groups,
)
from .core.tracing import make_json_safe, traceable


@dataclass
class AuditResult:
    """Structured result from a Veritas audit."""

    detected: bool
    metrics: Dict[str, Any]
    issues: List[Dict[str, Any]]
    groups: Dict[str, Dict[str, Any]]
    reports_by_attribute: Dict[str, Dict[str, Any]]
    protected_attributes: List[str]
    dataset_name: str = "dataset"
    model_name: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        primary_attr = self.protected_attributes[0]
        primary_report = self.reports_by_attribute.get(primary_attr, {})
        payload = {
            **primary_report,
            "timestamp": self.timestamp,
            "dataset": self.dataset_name,
            "model": self.model_name or primary_report.get("model", "model"),
            "detected": self.detected,
            "issue_count": len(self.issues),
            "metrics": self.metrics,
            "bias_issues": self.issues,
            "issues": self.issues,
            "groups": self.groups,
            "protected_groups": self.groups,
            "protected_attributes": self.protected_attributes,
            "protected_attribute": primary_report.get("protected_attribute", primary_attr),
            "reports_by_attribute": self.reports_by_attribute,
        }
        return make_json_safe(payload)


def assess_bias(metrics: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Convert fairness metrics into threshold-based issue objects."""
    dm = metrics["dataset_metrics"]
    cm = metrics["classification_metrics"]
    issues: List[Dict[str, Any]] = []

    def add(severity: str, metric: str, value: Any, threshold: str, explanation: str) -> None:
        issues.append({
            "severity": severity,
            "metric": metric,
            "value": round(float(value), 4) if isinstance(value, (float, np.floating)) else value,
            "threshold": threshold,
            "explanation": explanation,
        })

    di = dm["disparate_impact"]
    if di < 0.80:
        add(
            "CRITICAL",
            "Disparate Impact",
            di,
            "< 0.80 (80% rule violated)",
            "The positive-outcome rate for the unprivileged group is less than 80% of the privileged group.",
        )
    elif di < 0.90:
        add(
            "MODERATE",
            "Disparate Impact",
            di,
            "0.80-0.90 (approaching 80% rule)",
            "Disparate impact is approaching legally problematic levels.",
        )

    spd = dm["statistical_parity_difference"]
    if abs(spd) > 0.10:
        add(
            "HIGH",
            "Statistical Parity Difference",
            spd,
            "|SPD| > 0.10",
            "Protected groups receive materially different positive-decision rates.",
        )

    eod = cm["equal_opportunity_difference"]
    if abs(eod) > 0.10:
        add(
            "HIGH",
            "Equal Opportunity Difference",
            eod,
            "|EOD| > 0.10",
            "True positive rates differ substantially across protected groups.",
        )

    aod = cm["average_odds_difference"]
    if abs(aod) > 0.10:
        add(
            "HIGH",
            "Average Odds Difference",
            aod,
            "|AOD| > 0.10",
            "True-positive and false-positive behavior differs between protected groups.",
        )

    ti = cm["theil_index"]
    if ti > 0.10:
        add(
            "MODERATE",
            "Theil Index",
            ti,
            "> 0.10",
            "Positive predictions are distributed unevenly across individuals.",
        )

    acc_gap = abs(cm["accuracy_privileged"] - cm["accuracy_unprivileged"])
    if acc_gap > 0.03:
        add(
            "MODERATE",
            "Accuracy Gap",
            acc_gap,
            "> 3% gap",
            "Model accuracy is noticeably different between protected groups.",
        )

    return issues


def _compute_attribute_metrics(
    X: pd.DataFrame,
    y_true: pd.Series,
    y_pred: np.ndarray,
    sensitive_encoded: np.ndarray,
    protected_attr: str,
    privileged_values: List[int],
    unprivileged_values: List[int],
    favorable_class: Any,
    config: AuditConfig,
) -> Dict[str, Any]:
    from aif360.metrics import BinaryLabelDatasetMetric, ClassificationMetric

    dataset = build_standard_dataset(
        X,
        y_true,
        sensitive_encoded,
        protected_attr,
        privileged_values,
        favorable_class=favorable_class,
        categorical_features=config.categorical_features,
    )
    pred_dataset = dataset.copy()
    pred_dataset.labels = np.asarray(y_pred).reshape(-1, 1)

    privileged = [{protected_attr: int(v)} for v in privileged_values]
    unprivileged = [{protected_attr: int(v)} for v in unprivileged_values]
    dm = BinaryLabelDatasetMetric(
        dataset,
        unprivileged_groups=unprivileged,
        privileged_groups=privileged,
    )
    cm = ClassificationMetric(
        dataset,
        pred_dataset,
        unprivileged_groups=unprivileged,
        privileged_groups=privileged,
    )

    return {
        "dataset_metrics": {
            "disparate_impact": round(float(dm.disparate_impact()), 4),
            "statistical_parity_difference": round(float(dm.statistical_parity_difference()), 4),
            "base_rate_privileged": round(float(dm.base_rate(privileged=True)), 4),
            "base_rate_unprivileged": round(float(dm.base_rate(privileged=False)), 4),
        },
        "classification_metrics": {
            "accuracy_overall": round(float(cm.accuracy()), 4),
            "accuracy_privileged": round(float(cm.accuracy(privileged=True)), 4),
            "accuracy_unprivileged": round(float(cm.accuracy(privileged=False)), 4),
            "equal_opportunity_difference": round(float(cm.equal_opportunity_difference()), 4),
            "average_odds_difference": round(float(cm.average_odds_difference()), 4),
            "theil_index": round(float(cm.theil_index()), 4),
            "false_positive_rate_privileged": round(float(cm.false_positive_rate(privileged=True)), 4),
            "false_positive_rate_unprivileged": round(float(cm.false_positive_rate(privileged=False)), 4),
            "false_negative_rate_privileged": round(float(cm.false_negative_rate(privileged=True)), 4),
            "false_negative_rate_unprivileged": round(float(cm.false_negative_rate(privileged=False)), 4),
        },
    }


@traceable(name="veritas_audit_predictions", run_type="chain", tags=["veritas", "audit"])
def audit_predictions(
    y_true: Union[pd.Series, np.ndarray, List[Any]],
    y_pred: Union[pd.Series, np.ndarray, List[Any]],
    sensitive: Union[pd.Series, pd.DataFrame, np.ndarray, List[Any]],
    config: AuditConfig,
    X: Optional[Union[pd.DataFrame, np.ndarray, List[List[float]]]] = None,
) -> AuditResult:
    """Audit model predictions against protected attributes."""
    y_true_series = as_series(y_true)
    y_pred_array = np.asarray(as_series(y_pred)).ravel()
    X_df = as_dataframe(X if X is not None else np.zeros((len(y_true_series), 1)))
    sensitive_df = as_sensitive_frame(sensitive, list(config.protected_attributes))

    if len(X_df) != len(y_true_series) or len(sensitive_df) != len(y_true_series):
        raise ValueError("X, y_true, y_pred, and sensitive must contain the same number of rows.")

    favorable_class = choose_favorable_class(y_true_series, config.favorable_classes)
    reports: Dict[str, Dict[str, Any]] = {}
    all_issues: List[Dict[str, Any]] = []
    groups = {"privileged": {}, "unprivileged": {}, "base_rates": {}}

    for protected_attr in config.protected_attributes:
        sensitive_encoded, encoding_map = encode_sensitive_attribute(sensitive_df[protected_attr])
        privileged, unprivileged, base_rates = resolve_groups(
            config,
            protected_attr,
            y_true_series,
            sensitive_encoded,
            favorable_class,
            encoding_map,
        )
        metrics = _compute_attribute_metrics(
            X_df,
            y_true_series,
            y_pred_array,
            sensitive_encoded,
            protected_attr,
            privileged,
            unprivileged,
            favorable_class,
            config,
        )
        issues = assess_bias(metrics)
        for issue in issues:
            issue["protected_attribute"] = protected_attr

        groups["privileged"][protected_attr] = privileged
        groups["unprivileged"][protected_attr] = unprivileged
        groups["base_rates"][protected_attr] = base_rates
        reports[protected_attr] = {
            **metrics,
            "detected": bool(issues),
            "issue_count": len(issues),
            "bias_issues": issues,
            "issues": issues,
            "protected_attribute": f"{protected_attr} (privileged = {privileged[0]})",
            "protected_groups": {
                "privileged": {protected_attr: privileged},
                "unprivileged": {protected_attr: unprivileged},
                "base_rates": {protected_attr: base_rates},
            },
        }
        all_issues.extend(issues)

    primary = reports[config.primary_attribute]
    metric_payload = {
        "dataset_metrics": primary.get("dataset_metrics", {}),
        "classification_metrics": primary.get("classification_metrics", {}),
    }
    return AuditResult(
        detected=bool(all_issues),
        metrics=metric_payload,
        issues=all_issues,
        groups=groups,
        reports_by_attribute=reports,
        protected_attributes=list(config.protected_attributes),
        dataset_name=config.dataset_name,
        model_name=config.model_name,
    )


@traceable(name="veritas_audit_model", run_type="chain", tags=["veritas", "audit"])
def audit_model(
    model: Any,
    X: Union[pd.DataFrame, np.ndarray, List[List[float]]],
    y: Union[pd.Series, np.ndarray, List[Any]],
    sensitive: Union[pd.Series, pd.DataFrame, np.ndarray, List[Any]],
    config: AuditConfig,
) -> AuditResult:
    """Predict with a model and audit the resulting predictions."""
    y_pred = predict_with_optional_sensitive(model, X, sensitive)
    return audit_predictions(y, y_pred, sensitive, config, X=X)
