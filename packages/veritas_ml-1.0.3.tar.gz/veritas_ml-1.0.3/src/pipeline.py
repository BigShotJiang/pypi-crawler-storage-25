"""Plain-Python Veritas audit and mitigation pipeline."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Union, List

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, clone

from .config import config as package_config
from .core.tracing import make_json_safe, traceable
from .data import AuditConfig, as_dataframe, as_sensitive_frame, as_series
from .knowledge import knowledge_service
from .metrics import AuditResult, audit_model, audit_predictions
from .mitigation import MitigationResult, mitigate_model
from .reporting import generate_report as render_report


@dataclass
class PipelineResult:
    """Structured result from the full Veritas pipeline."""

    audit: AuditResult
    mitigation: Optional[MitigationResult]
    rag_context: Dict[str, Any]
    report: Optional[str]
    estimator: Any

    def to_dict(self) -> Dict[str, Any]:
        return make_json_safe({
            "audit": self.audit.to_dict(),
            "bias_report": self.audit.to_dict(),
            "mitigation": self.mitigation.to_dict() if self.mitigation else None,
            "mitigation_result": self.mitigation.to_dict() if self.mitigation else None,
            "rag_context": self.rag_context,
            "report": self.report,
            "final_report": self.report,
            "estimator": repr(self.estimator),
        })


def retrieve_rag_context(audit: AuditResult, mitigation: Optional[MitigationResult] = None) -> Dict[str, Any]:
    """Retrieve law and algorithm context for a completed audit."""
    payload = audit.to_dict()
    issues = payload.get("bias_issues", [])
    rag_context: Dict[str, Any] = {
        "knowledge_base_status": {},
        "law_matches": [],
        "algorithm_matches": None,
        "algorithm_recommendation": None,
    }
    try:
        rag_context["knowledge_base_status"] = knowledge_service.status()
    except Exception as exc:
        rag_context["knowledge_base_error"] = str(exc)

    for issue in issues:
        metric = issue.get("metric", "fairness issue")
        query = (
            f"{metric} {issue.get('explanation', '')} "
            "employment discrimination fairness law EU AI Act OECD UNESCO"
        )
        rag_context["law_matches"].append({
            "metric": metric,
            "query": query,
            "results": knowledge_service.search(package_config.collection_laws, query, k=3),
        })

    primary_metric = str(issues[0].get("metric", "disparate impact")) if issues else "disparate impact"
    metric_lower = primary_metric.lower()
    if "parity" in metric_lower or "impact" in metric_lower:
        constraint_type = "demographic_parity"
    elif "opportunity" in metric_lower:
        constraint_type = "equal_opportunity"
    else:
        constraint_type = "equalized_odds"
    technique = mitigation.technique if mitigation else "reweighing"
    query = f"{primary_metric} fairness mitigation {technique} {constraint_type} AIF360"
    rag_context["algorithm_matches"] = knowledge_service.search(
        package_config.collection_algorithms,
        query,
        k=3,
    )
    rag_context["algorithm_recommendation"] = knowledge_service.recommend_algorithm(
        primary_metric,
        constraint_type,
        can_retrain=True,
    )
    return rag_context


@traceable(name="veritas_run_pipeline", run_type="chain", tags=["veritas", "pipeline"])
def run_pipeline(
    base_estimator: BaseEstimator,
    X: Union[pd.DataFrame, np.ndarray, List[List[float]]],
    y: Union[pd.Series, np.ndarray, List[Any]],
    sensitive: Union[pd.Series, pd.DataFrame, np.ndarray, List[Any]],
    config: AuditConfig,
    strategy: str = "auto",
    generate_report: bool = True,
) -> PipelineResult:
    """Run model fit, fairness audit, optional mitigation, RAG retrieval, and reporting."""
    X_df = as_dataframe(X)
    y_series = as_series(y)
    sensitive_df = as_sensitive_frame(sensitive, list(config.protected_attributes))

    estimator = clone(base_estimator)
    estimator.fit(X_df, y_series)
    audit = audit_model(estimator, X_df, y_series, sensitive_df, config)

    mitigation = None
    final_estimator = estimator
    if audit.detected and (strategy or "auto").lower() not in {"none", "off", "disabled", "false"}:
        mitigation = mitigate_model(base_estimator, X_df, y_series, sensitive_df, config, strategy=strategy)
        if mitigation.estimator is not None:
            final_estimator = mitigation.estimator

    rag_context = retrieve_rag_context(audit, mitigation)
    report = None
    if generate_report:
        report = render_report(
            audit,
            mitigation,
            rag_context,
            llm_provider=config.llm_provider,
        )

    return PipelineResult(
        audit=audit,
        mitigation=mitigation,
        rag_context=rag_context,
        report=report,
        estimator=final_estimator,
    )


__all__ = [
    "PipelineResult",
    "audit_model",
    "audit_predictions",
    "mitigate_model",
    "run_pipeline",
]
