"""LangChain wrappers for the unified Veritas knowledge service."""

from __future__ import annotations

from langchain_core.tools import tool

from ..config import config
from ..core.tracing import traceable
from ..knowledge import knowledge_service


@tool
@traceable(name="search_ai_ethics_laws", run_type="retriever", tags=["veritas", "rag", "laws"])
def search_ai_ethics_laws(query: str, k: int = 5) -> str:
    """Search the AI ethics laws and regulations knowledge base."""
    return knowledge_service.search(config.collection_laws, query, k=k)


@tool
@traceable(name="search_aif360_algorithms", run_type="retriever", tags=["veritas", "rag", "algorithms"])
def search_aif360_algorithms(query: str, k: int = 5) -> str:
    """Search the AIF360 mitigation algorithm knowledge base."""
    return knowledge_service.search(config.collection_algorithms, query, k=k)


@tool
@traceable(name="select_mitigation_algorithm", run_type="tool", tags=["veritas", "rag", "algorithms"])
def select_mitigation_algorithm(
    bias_issue: str,
    constraint_type: str,
    can_retrain: bool = True,
) -> str:
    """Recommend mitigation algorithms from the knowledge service."""
    return knowledge_service.recommend_algorithm(bias_issue, constraint_type, can_retrain)
