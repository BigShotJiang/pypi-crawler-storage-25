"""LangChain wrappers for canonical Veritas bias detection."""

from __future__ import annotations

import json
from typing import List, Optional

from langchain_core.tools import tool

from ..core.tracing import json_dumps_safe, traceable
from ..data import AuditConfig
from ..metrics import audit_predictions


@tool
@traceable(name="detect_bias", run_type="tool", tags=["veritas", "bias", "tool"])
def detect_bias(
    X_test: List[List[float]],
    y_test: List[int],
    sensitive_features: List[int],
    protected_attribute_names: List[str],
    model_predictions: Optional[List[int]] = None,
    model_scores: Optional[List[float]] = None,
    favorable_class: int = 1,
) -> str:
    """Detect fairness issues in predictions using the canonical Veritas audit."""
    del model_scores
    try:
        config = AuditConfig(
            protected_attributes=protected_attribute_names,
            favorable_classes=[favorable_class],
        )
        result = audit_predictions(
            y_true=y_test,
            y_pred=model_predictions if model_predictions is not None else y_test,
            sensitive=sensitive_features,
            config=config,
            X=X_test,
        )
        return json_dumps_safe(result.to_dict(), indent=2)
    except Exception as exc:
        return json.dumps({"error": f"Bias detection failed: {exc}"}, indent=2)


@tool
@traceable(name="get_bias_summary", run_type="tool", tags=["veritas", "bias", "summary"])
def get_bias_summary(bias_report_json: str) -> str:
    """Return a compact human-readable summary for a Veritas audit JSON payload."""
    try:
        report = json.loads(bias_report_json)
    except json.JSONDecodeError:
        return f"Invalid JSON report: {bias_report_json[:200]}"

    if "error" in report:
        return f"Error in bias report: {report['error']}"

    lines = [
        "## Bias Detection Summary",
        "",
        f"**Protected Attributes:** {', '.join(report.get('protected_attributes', []))}",
        f"**Issues Found:** {report.get('issue_count', 0)}",
        "",
    ]
    for issue in report.get("bias_issues", []):
        lines.append(
            f"- **[{issue.get('severity', 'UNKNOWN')}]** "
            f"{issue.get('metric', 'Unknown')}: {issue.get('value', 'N/A')}"
        )

    if not report.get("bias_issues"):
        lines.append("No significant bias detected.")

    metrics = report.get("dataset_metrics", {})
    classification = report.get("classification_metrics", {})
    lines.extend([
        "",
        "### Key Metrics",
        f"- Disparate Impact: {metrics.get('disparate_impact', 'N/A')}",
        f"- Statistical Parity Difference: {metrics.get('statistical_parity_difference', 'N/A')}",
        f"- Equal Opportunity Difference: {classification.get('equal_opportunity_difference', 'N/A')}",
        f"- Average Odds Difference: {classification.get('average_odds_difference', 'N/A')}",
    ])
    return "\n".join(lines)
