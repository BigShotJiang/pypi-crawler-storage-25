"""LangChain wrappers for canonical Veritas mitigation."""

from __future__ import annotations

import json
from typing import List, Literal, Optional

from langchain_core.tools import tool
from sklearn.linear_model import LogisticRegression

from ..core.tracing import json_dumps_safe, traceable
from ..data import AuditConfig
from ..mitigation import mitigate_model


@tool
@traceable(name="mitigate_bias", run_type="tool", tags=["veritas", "mitigation", "tool"])
def mitigate_bias(
    X_train: List[List[float]],
    y_train: List[int],
    sensitive_train: List[int],
    X_test: List[List[float]],
    technique: Literal[
        "reweighing",
        "disparate_impact_remover",
        "learning_fair_representations",
        "prejudice_remover",
        "meta_fair_classifier",
        "calibrated_eqodds",
        "eqodds",
        "reject_option",
    ],
    protected_attribute: str = "protected",
    favorable_class: int = 1,
    repair_level: float = 1.0,
    reweighing_apply_to: Literal["train", "both"] = "train",
    y_test: Optional[List[int]] = None,
    sensitive_test: Optional[List[int]] = None,
    model_predictions: Optional[List[int]] = None,
    model_scores: Optional[List[float]] = None,
) -> str:
    """Apply a mitigation strategy through the canonical mitigation registry."""
    del X_test, repair_level, reweighing_apply_to, y_test, sensitive_test, model_predictions, model_scores
    try:
        config = AuditConfig(
            protected_attributes=[protected_attribute],
            favorable_classes=[favorable_class],
        )
        result = mitigate_model(
            LogisticRegression(max_iter=500),
            X_train,
            y_train,
            sensitive_train,
            config,
            strategy=technique,
        )
        return json_dumps_safe(result.to_dict(), indent=2)
    except Exception as exc:
        return json.dumps({
            "technique": technique,
            "status": "error",
            "applied": False,
            "message": f"Mitigation failed: {exc}",
        }, indent=2)


@tool
@traceable(name="get_mitigation_recommendation", run_type="tool", tags=["veritas", "mitigation", "recommendation"])
def get_mitigation_recommendation(
    bias_issue: str,
    can_retrain: bool = True,
    can_modify_features: bool = True,
) -> str:
    """Return a deterministic mitigation recommendation guide."""
    del can_modify_features
    if not can_retrain:
        return (
            "## Mitigation Recommendations\n\n"
            "- `reject_option`\n"
            "- `eqodds`\n"
            "- `calibrated_eqodds`\n"
        )
    issue = bias_issue.lower().replace(" ", "_")
    if "opportunity" in issue or "odds" in issue:
        preferred = ["eqodds", "calibrated_eqodds", "reweighing"]
    else:
        preferred = ["reweighing", "prejudice_remover", "reject_option"]
    return "## Mitigation Recommendations\n\n" + "\n".join(f"- `{name}`" for name in preferred)
