"""CLI entry point for Veritas."""

import argparse
import json
import sys

from .config import VERITAS_HOME
from .knowledge import knowledge_service


def cmd_init(args):
    """Initialize knowledge bases."""
    print("🔄 Initializing Veritas knowledge bases...")

    results = {}

    if args.laws:
        print(f"\n📚 Ingesting AI ethics laws from: {args.laws}")
        try:
            result = knowledge_service.ingest(laws_pdf=args.laws, force=args.force)["laws"]
            results["laws"] = result
            print(f"   ✅ {result['vectors']} vectors stored in '{result['collection']}'")
        except Exception as e:
            print(f"   ❌ Error: {e}")
            sys.exit(1)

    if args.algorithms:
        print(f"\n⚙️  Ingesting AIF360 algorithms from: {args.algorithms}")
        try:
            result = knowledge_service.ingest(algorithms_txt=args.algorithms, force=args.force)["algorithms"]
            results["algorithms"] = result
            print(f"   ✅ {result['vectors']} vectors stored in '{result['collection']}'")
        except Exception as e:
            print(f"   ❌ Error: {e}")
            sys.exit(1)

    if args.laws or args.algorithms:
        print("\n✅ Knowledge base initialization complete!")
        if args.json:
            print(json.dumps(results, indent=2))
    else:
        print("\n⚠️  No sources specified. Use --laws and/or --algorithms.")


def cmd_status(args):
    """Check knowledge base status."""
    status = knowledge_service.status()

    print("📊 Veritas Knowledge Base Status")
    print("=" * 50)
    print()

    for name, info in status.items():
        emoji = "✅" if info["ready"] else "❌"
        print(f"{emoji} {name}: {info['collection']}")

    print()
    print(f"Vector store location: {VERITAS_HOME}")

    if args.json:
        print(json.dumps(status, indent=2))


def cmd_query(args):
    """Query a knowledge base."""
    from .tools.rag_tools import search_ai_ethics_laws, search_aif360_algorithms

    if args.db == "laws":
        results = search_ai_ethics_laws.invoke({"query": args.query, "k": args.k})
    elif args.db == "algorithms":
        results = search_aif360_algorithms.invoke({"query": args.query, "k": args.k})
    else:
        print(f"Unknown database: {args.db}")
        sys.exit(1)

    print(results)


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="veritas",
        description="Veritas AI Ethics Compliance Agent - Bias detection and mitigation using AIF360"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # init command
    init_parser = subparsers.add_parser("init", help="Initialize knowledge bases")
    init_parser.add_argument("--laws", help="Path to AI ethics laws PDF")
    init_parser.add_argument("--algorithms", help="Path to AIF360 algorithms TXT")
    init_parser.add_argument("--force", action="store_true", help="Force re-initialization")
    init_parser.add_argument("--json", action="store_true", help="Output JSON")
    init_parser.set_defaults(func=cmd_init)

    # status command
    status_parser = subparsers.add_parser("status", help="Check knowledge base status")
    status_parser.add_argument("--json", action="store_true", help="Output JSON")
    status_parser.set_defaults(func=cmd_status)

    # query command
    query_parser = subparsers.add_parser("query", help="Query a knowledge base")
    query_parser.add_argument("--db", choices=["laws", "algorithms"], required=True,
                             help="Database to query")
    query_parser.add_argument("query", help="Search query")
    query_parser.add_argument("-k", type=int, default=5, help="Number of results")
    query_parser.set_defaults(func=cmd_query)

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
