"""Veritas - AI bias detection, mitigation, and ethics reporting."""

# Set environment variables before any imports
import os
import warnings
from pathlib import Path
os.environ["ANONYMIZED_TELEMETRY"] = "False"
os.environ["CHROMADB_TELEMETRY"] = "False"
os.environ["GRPC_VERBOSITY"] = "ERROR"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
_mpl_cache = Path(__file__).resolve().parents[1] / ".mpl-cache"
_mpl_cache.mkdir(exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(_mpl_cache))
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

from .core.tracing import configure_langsmith

configure_langsmith("veritas")

from ._bootstrap import _ensure_initialized

_ensure_initialized()

# Public API
from .data import AuditConfig
from .detector import BiasDetector
from .metrics import AuditResult, audit_model, audit_predictions
from .mitigation import MitigationResult, mitigate_model
from .models import VeritasClassifier
from .pipeline import PipelineResult, run_pipeline

__all__ = [
    "AuditConfig",
    "AuditResult",
    "MitigationResult",
    "PipelineResult",
    "audit_model",
    "audit_predictions",
    "mitigate_model",
    "run_pipeline",
    "BiasDetector",
    "VeritasClassifier",
]
__version__ = "1.0.3"
