"""Shared data normalization and AIF360 dataset helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from .utils.bias_params import require_protected_attributes


ProtectedAttributesInput = Optional[Union[str, Iterable[str]]]


@dataclass
class AuditConfig:
    """Configuration shared by audit, mitigation, pipeline, and wrapper APIs."""

    protected_attributes: ProtectedAttributesInput = None
    privileged_groups: Optional[Dict[str, List[Any]]] = None
    unprivileged_groups: Optional[Dict[str, List[Any]]] = None
    favorable_classes: List[Any] = field(default_factory=lambda: [1, "1", "yes", "Yes", True])
    categorical_features: List[str] = field(default_factory=list)
    dataset_name: str = "dataset"
    model_name: Optional[str] = None
    llm_provider: Optional[str] = None
    report_sample_count: int = 6

    def __post_init__(self) -> None:
        self.protected_attributes = require_protected_attributes(self.protected_attributes)

    @property
    def primary_attribute(self) -> str:
        return list(self.protected_attributes)[0]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "protected_attributes": list(self.protected_attributes),
            "privileged_groups": self.privileged_groups,
            "unprivileged_groups": self.unprivileged_groups,
            "favorable_classes": self.favorable_classes,
            "categorical_features": self.categorical_features,
            "dataset_name": self.dataset_name,
            "model_name": self.model_name,
            "llm_provider": self.llm_provider,
            "report_sample_count": self.report_sample_count,
        }


def as_dataframe(X: Union[pd.DataFrame, np.ndarray, List[List[float]]]) -> pd.DataFrame:
    """Return a feature matrix as a reset-index DataFrame."""
    if isinstance(X, pd.DataFrame):
        return X.reset_index(drop=True).copy()
    arr = np.asarray(X)
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)
    return pd.DataFrame(arr, columns=[f"feature_{i}" for i in range(arr.shape[1])])


def as_series(y: Union[pd.Series, pd.DataFrame, np.ndarray, List[Any]], name: str = "label") -> pd.Series:
    """Return labels as a reset-index one-dimensional Series."""
    if isinstance(y, pd.Series):
        return y.reset_index(drop=True).copy()
    if isinstance(y, pd.DataFrame):
        return y.iloc[:, 0].reset_index(drop=True).rename(name)
    return pd.Series(np.asarray(y).ravel(), name=name)


def as_sensitive_frame(
    sensitive: Union[pd.Series, pd.DataFrame, np.ndarray, List[Any]],
    protected_attributes: List[str],
) -> pd.DataFrame:
    """Return protected attributes as a DataFrame with requested columns."""
    if isinstance(sensitive, pd.DataFrame):
        frame = sensitive.reset_index(drop=True).copy()
    elif isinstance(sensitive, pd.Series):
        frame = sensitive.to_frame(name=protected_attributes[0]).reset_index(drop=True)
    else:
        arr = np.asarray(sensitive)
        if arr.ndim == 1:
            frame = pd.DataFrame({protected_attributes[0]: arr})
        else:
            if arr.shape[1] < len(protected_attributes):
                raise ValueError(
                    "sensitive has fewer columns than protected_attributes requires."
                )
            frame = pd.DataFrame(arr[:, : len(protected_attributes)], columns=protected_attributes)

    missing = [attr for attr in protected_attributes if attr not in frame.columns]
    if missing:
        raise ValueError(
            "Missing protected attribute columns in sensitive data: "
            + ", ".join(missing)
        )
    return frame[protected_attributes].reset_index(drop=True).copy()


def encode_sensitive_attribute(values: pd.Series) -> Tuple[np.ndarray, Dict[Any, int]]:
    """Encode a protected attribute as integer values accepted by AIF360."""
    numeric = pd.to_numeric(values, errors="coerce")
    if numeric.notna().all():
        encoded = numeric.astype(int).to_numpy()
        mapping = {int(v): int(v) for v in np.unique(encoded)}
        return encoded, mapping

    codes, uniques = pd.factorize(values.astype(str), sort=True)
    mapping = {str(value): int(index) for index, value in enumerate(uniques)}
    return codes.astype(int), mapping


def choose_favorable_class(y: pd.Series, configured: Optional[List[Any]] = None) -> Any:
    """Pick the favorable class from configured values or common binary labels."""
    values = np.asarray(y)
    for candidate in configured or []:
        if np.any(values == candidate):
            return candidate
    if np.any(values == 1):
        return 1
    if np.any(values == 0):
        return 0
    return values[0]


def determine_groups_by_base_rate(
    y: pd.Series,
    sensitive: np.ndarray,
    favorable_class: Any,
) -> Tuple[List[int], List[int], Dict[Any, float]]:
    """Detect privileged and unprivileged values from favorable outcome rates."""
    base_rates: Dict[Any, float] = {}
    y_values = np.asarray(y)

    for value in np.unique(sensitive):
        mask = sensitive == value
        key = int(value) if isinstance(value, (np.integer, int)) else value
        base_rates[key] = float(np.mean(y_values[mask] == favorable_class)) if mask.any() else 0.0

    if not base_rates:
        return [1], [0], {}

    privileged = int(max(base_rates, key=base_rates.get))
    unprivileged = int(min(base_rates, key=base_rates.get))
    return [privileged], [unprivileged], base_rates


def resolve_groups(
    config: AuditConfig,
    protected_attr: str,
    y: pd.Series,
    encoded_sensitive: np.ndarray,
    favorable_class: Any,
    encoding_map: Optional[Dict[Any, int]] = None,
) -> Tuple[List[int], List[int], Dict[Any, float]]:
    """Return privileged/unprivileged values for one protected attribute."""
    provided_priv = (config.privileged_groups or {}).get(protected_attr)
    provided_unpriv = (config.unprivileged_groups or {}).get(protected_attr)
    if provided_priv is not None and provided_unpriv is not None:
        def encode_value(value: Any) -> int:
            if encoding_map and value in encoding_map:
                return int(encoding_map[value])
            if encoding_map and str(value) in encoding_map:
                return int(encoding_map[str(value)])
            return int(value)

        return [encode_value(v) for v in provided_priv], [encode_value(v) for v in provided_unpriv], {}
    return determine_groups_by_base_rate(y, encoded_sensitive, favorable_class)


def build_standard_dataset(
    X: pd.DataFrame,
    y: pd.Series,
    sensitive: np.ndarray,
    protected_attr: str,
    privileged_values: List[int],
    favorable_class: Any = 1,
    categorical_features: Optional[List[str]] = None,
    label_name: str = "label",
) -> Any:
    """Build an AIF360 StandardDataset for one protected attribute."""
    from aif360.datasets import StandardDataset

    df = X.reset_index(drop=True).copy()
    df[label_name] = np.asarray(y).ravel()
    df[protected_attr] = np.asarray(sensitive).astype(int).ravel()
    return StandardDataset(
        df=df,
        label_name=label_name,
        favorable_classes=[favorable_class],
        protected_attribute_names=[protected_attr],
        privileged_classes=[list(map(int, privileged_values))],
        categorical_features=categorical_features or [],
    )


def predict_with_optional_sensitive(
    model: Any,
    X: Union[pd.DataFrame, np.ndarray, List[List[float]]],
    sensitive_features: Optional[Union[pd.Series, pd.DataFrame, np.ndarray, List[Any]]] = None,
) -> np.ndarray:
    """Predict with models that may require protected attributes at inference."""
    X_df = as_dataframe(X)
    try:
        return np.asarray(model.predict(X_df, sensitive_features=sensitive_features)).ravel()
    except TypeError:
        return np.asarray(model.predict(X_df)).ravel()
