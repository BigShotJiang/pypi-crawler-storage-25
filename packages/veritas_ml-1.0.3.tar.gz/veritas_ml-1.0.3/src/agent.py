"""Legacy orchestration adapters backed by the simplified pipeline."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
from sklearn.linear_model import LogisticRegression

from .data import AuditConfig
from .pipeline import run_pipeline
from .reporting import generate_report
from .metrics import AuditResult


class VeritasOrchestrator:
    """Thin adapter retained for callers that still import the old orchestrator."""

    def __init__(self, config: Optional[Any] = None):
        self.config = config

    def run(
        self,
        X_test: List[List[float]],
        y_test: List[int],
        sensitive_features: List[int],
        protected_attribute_names: List[str] = None,
        X_train: List[List[float]] = None,
        y_train: List[int] = None,
        sensitive_train: List[int] = None,
        model_predictions: List[int] = None,
        can_retrain: bool = True,
        protected_attributes: List[str] = None,
    ) -> Dict[str, Any]:
        del model_predictions
        attrs = protected_attribute_names if protected_attribute_names is not None else protected_attributes
        audit_config = AuditConfig(protected_attributes=attrs or ["protected"])
        X = X_train if X_train is not None else X_test
        y = y_train if y_train is not None else y_test
        sensitive = sensitive_train if sensitive_train is not None else sensitive_features
        result = run_pipeline(
            LogisticRegression(max_iter=500),
            X,
            y,
            sensitive,
            audit_config,
            strategy="auto" if can_retrain else "none",
            generate_report=True,
        )
        payload = result.to_dict()
        return {
            "bias_detected": payload["bias_report"].get("detected", False),
            "bias_report": payload["bias_report"],
            "privileged_groups": payload["bias_report"].get("protected_groups", {}).get("privileged", {}),
            "unprivileged_groups": payload["bias_report"].get("protected_groups", {}).get("unprivileged", {}),
            "mitigation_applied": bool(payload.get("mitigation_result", {}).get("applied")) if payload.get("mitigation_result") else False,
            "mitigation_result": payload.get("mitigation_result"),
            "final_report": payload.get("final_report"),
        }


class ComplianceAgent(VeritasOrchestrator):
    """Legacy report-only adapter."""

    def analyze(self, bias_report: Dict[str, Any]) -> str:
        audit = AuditResult(
            detected=bool(bias_report.get("detected") or bias_report.get("bias_issues")),
            metrics={
                "dataset_metrics": bias_report.get("dataset_metrics", {}),
                "classification_metrics": bias_report.get("classification_metrics", {}),
            },
            issues=bias_report.get("bias_issues", []),
            groups=bias_report.get("protected_groups", {}),
            reports_by_attribute={
                bias_report.get("protected_attribute", "protected"): bias_report
            },
            protected_attributes=[bias_report.get("protected_attribute", "protected")],
        )
        return generate_report(audit)
