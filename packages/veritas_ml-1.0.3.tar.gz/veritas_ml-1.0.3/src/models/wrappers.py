"""sklearn-compatible wrapper over the simplified Veritas pipeline."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.linear_model import LogisticRegression

from ..data import AuditConfig, as_dataframe
from ..pipeline import PipelineResult, run_pipeline
from ..utils.bias_params import require_protected_attributes


def _load_sensitive_features_from_json(protected_attributes: List[str]) -> Optional[pd.DataFrame]:
    sensitive_file = Path(os.getcwd()) / "sensitive_features.json"
    if not sensitive_file.exists():
        return None
    try:
        data = json.loads(sensitive_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    if not isinstance(data, dict):
        return None
    frame_data = {}
    for attr in protected_attributes:
        if attr not in data:
            return None
        frame_data[attr] = data[attr]
    return pd.DataFrame(frame_data)


def _extract_sensitive_features_from_X(X: pd.DataFrame, protected_attributes: List[str]) -> Optional[pd.DataFrame]:
    if all(attr in X.columns for attr in protected_attributes):
        return X[protected_attributes].copy()
    return None


class VeritasClassifier(BaseEstimator, ClassifierMixin):
    """sklearn-compatible classifier with optional Veritas audit and mitigation."""

    def __init__(
        self,
        base_estimator: Optional[BaseEstimator] = None,
        protected_attributes: List[str] = None,
        privileged_groups: Optional[Dict[str, List[Any]]] = None,
        unprivileged_groups: Optional[Dict[str, List[Any]]] = None,
        run_audit: bool = True,
        apply_mitigation: bool = True,
        generate_report: bool = True,
        llm_provider: Optional[str] = None,
        mitigation_technique: str = "auto",
        dataset_name: str = "dataset",
        report_sample_count: int = 6,
        protected_attribute: Optional[str] = None,
        privileged_classes: Optional[List[Any]] = None,
        unprivileged_classes: Optional[List[Any]] = None,
    ):
        fallback_attrs = protected_attributes if protected_attributes is not None else protected_attribute
        resolved_attrs = require_protected_attributes(
            fallback_attrs,
            include_callers=True,
        )
        resolved_privileged = privileged_groups
        resolved_unprivileged = unprivileged_groups

        if resolved_privileged is None and privileged_classes is not None:
            primary = resolved_attrs[0]
            first_group = (
                privileged_classes[0]
                if privileged_classes and isinstance(privileged_classes[0], list)
                else privileged_classes
            )
            resolved_privileged = {primary: first_group}
        if resolved_unprivileged is None and unprivileged_classes is not None:
            primary = resolved_attrs[0]
            first_group = (
                unprivileged_classes[0]
                if unprivileged_classes and isinstance(unprivileged_classes[0], list)
                else unprivileged_classes
            )
            resolved_unprivileged = {primary: first_group}

        self.base_estimator = base_estimator if base_estimator is not None else LogisticRegression(max_iter=500)
        self.protected_attributes = AuditConfig(
            protected_attributes=resolved_attrs,
            privileged_groups=resolved_privileged,
            unprivileged_groups=resolved_unprivileged,
            dataset_name=dataset_name,
            llm_provider=llm_provider,
            report_sample_count=report_sample_count,
        ).protected_attributes
        self.protected_attribute = list(self.protected_attributes)[0]
        self.privileged_groups = resolved_privileged
        self.unprivileged_groups = resolved_unprivileged
        self.privileged_classes = privileged_classes
        self.unprivileged_classes = unprivileged_classes
        self.run_audit = run_audit
        self.apply_mitigation = apply_mitigation
        self.generate_report = generate_report
        self.llm_provider = llm_provider
        self.mitigation_technique = mitigation_technique
        self.dataset_name = dataset_name
        self.report_sample_count = report_sample_count

        self.estimator_: Optional[Any] = None
        self.pipeline_result_: Optional[PipelineResult] = None
        self.bias_report_: Optional[Dict[str, Any]] = None
        self.bias_report_pre_mitigation_: Optional[Dict[str, Any]] = None
        self.bias_report_post_mitigation_: Optional[Dict[str, Any]] = None
        self.compliance_report_: Optional[str] = None
        self.classes_: Optional[np.ndarray] = None
        self._mitigation_applied: bool = False
        self._mitigation_result: Optional[Dict[str, Any]] = None
        self._detected_groups_: Optional[Dict[str, Dict[str, List[int]]]] = None
        self._report_context_: Dict[str, Any] = {}

    def __sklearn_clone__(self) -> "VeritasClassifier":
        """Clone without requiring unresolved protected-attribute constructor state."""
        return type(self)(
            base_estimator=clone(self.base_estimator),
            protected_attributes=list(self.protected_attributes),
            privileged_groups=self.privileged_groups,
            unprivileged_groups=self.unprivileged_groups,
            run_audit=self.run_audit,
            apply_mitigation=self.apply_mitigation,
            generate_report=self.generate_report,
            llm_provider=self.llm_provider,
            mitigation_technique=self.mitigation_technique,
            dataset_name=self.dataset_name,
            report_sample_count=self.report_sample_count,
            privileged_classes=self.privileged_classes,
            unprivileged_classes=self.unprivileged_classes,
        )

    def _config(self) -> AuditConfig:
        return AuditConfig(
            protected_attributes=self.protected_attributes,
            privileged_groups=self.privileged_groups,
            unprivileged_groups=self.unprivileged_groups,
            dataset_name=self.dataset_name,
            model_name=type(self.base_estimator).__name__,
            llm_provider=self.llm_provider,
            report_sample_count=self.report_sample_count,
        )

    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
        sensitive_train: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> "VeritasClassifier":
        X_df = as_dataframe(X)
        y_series = pd.Series(np.asarray(y).ravel(), name="label")
        self.classes_ = np.sort(y_series.unique())

        sensitive = sensitive_train if sensitive_train is not None else sensitive_features
        if sensitive is None:
            sensitive = _load_sensitive_features_from_json(list(self.protected_attributes))
        if sensitive is None:
            sensitive = _extract_sensitive_features_from_X(X_df, list(self.protected_attributes))

        if self.run_audit and sensitive is not None:
            strategy = self.mitigation_technique if self.apply_mitigation else "none"
            if not self.apply_mitigation:
                strategy = "none"
            result = run_pipeline(
                self.base_estimator,
                X_df,
                y_series,
                sensitive,
                self._config(),
                strategy=strategy,
                generate_report=self.generate_report,
            )
            if not self.apply_mitigation and result.mitigation is not None:
                result.mitigation = None
            self.pipeline_result_ = result
            self.estimator_ = result.estimator
            self.bias_report_pre_mitigation_ = result.audit.to_dict()
            self.bias_report_post_mitigation_ = (
                result.mitigation.after.to_dict()
                if result.mitigation and result.mitigation.after
                else result.audit.to_dict()
            )
            self.bias_report_ = self.bias_report_post_mitigation_
            self.compliance_report_ = result.report
            self._mitigation_applied = bool(result.mitigation and result.mitigation.applied)
            self._mitigation_result = result.mitigation.to_dict() if result.mitigation else None
            self._detected_groups_ = result.audit.groups
            self._report_context_ = {
                "rag_retrieval": result.rag_context,
                "pipeline_result": result.to_dict(),
            }
            return self

        self.estimator_ = clone(self.base_estimator)
        self.estimator_.fit(X_df, y_series)
        return self

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> np.ndarray:
        if self.estimator_ is None:
            raise ValueError("Classifier not fitted. Call fit() first.")
        try:
            return self.estimator_.predict(as_dataframe(X), sensitive_features=sensitive_features)
        except TypeError:
            return self.estimator_.predict(as_dataframe(X))

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> np.ndarray:
        if self.estimator_ is None:
            raise ValueError("Classifier not fitted. Call fit() first.")
        if not hasattr(self.estimator_, "predict_proba"):
            raise AttributeError("Underlying estimator does not support predict_proba.")
        try:
            return self.estimator_.predict_proba(as_dataframe(X), sensitive_features=sensitive_features)
        except TypeError:
            return self.estimator_.predict_proba(as_dataframe(X))

    def get_bias_report(self) -> Optional[Dict[str, Any]]:
        return self.bias_report_

    def get_bias_report_pre_mitigation(self) -> Optional[Dict[str, Any]]:
        return self.bias_report_pre_mitigation_

    def get_bias_report_post_mitigation(self) -> Optional[Dict[str, Any]]:
        return self.bias_report_post_mitigation_

    def get_mitigation_result(self) -> Optional[Dict[str, Any]]:
        return self._mitigation_result

    def get_compliance_report(self) -> Optional[str]:
        return self.compliance_report_

    def get_report_context(self) -> Dict[str, Any]:
        return self._report_context_

    def get_protected_groups(self) -> Optional[Dict[str, Dict[str, List[int]]]]:
        return self._detected_groups_

    def has_bias(self) -> bool:
        return bool(self.bias_report_ and self.bias_report_.get("detected"))

    def mitigation_applied(self) -> bool:
        return self._mitigation_applied

    def get_bias_summary(self) -> str:
        if not self.bias_report_:
            return "No bias report available."
        lines = [
            f"Detected {self.bias_report_.get('issue_count', 0)} bias issue(s).",
            f"Mitigation applied: {self._mitigation_applied}",
        ]
        if self._detected_groups_:
            lines.append(f"Privileged groups: {self._detected_groups_.get('privileged', {})}")
            lines.append(f"Unprivileged groups: {self._detected_groups_.get('unprivileged', {})}")
        if self._mitigation_result:
            lines.append(f"Technique: {self._mitigation_result.get('technique')}")
        return "\n".join(lines)
