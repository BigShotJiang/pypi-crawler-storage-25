"""Unified knowledge-base ingestion and search service."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from langchain_core.documents import Document
except ImportError:  # pragma: no cover
    from langchain.schema import Document
from pypdf import PdfReader

from ..config import config
from ..core.db import check_vector_store, get_vector_store
from .ingest import knowledge_base


KNOWLEDGE_DIR = Path(__file__).resolve().parent
DEFAULT_LAWS_PDF = KNOWLEDGE_DIR / "ai_ethics_knowledge_base.pdf"
DEFAULT_ALGORITHMS_TXT = KNOWLEDGE_DIR / "aif360_algorithms_documentation.txt"
COLLECTION_ALIASES = {
    "laws": config.collection_laws,
    "ai_ethics_laws": config.collection_laws,
    "algorithms": config.collection_algorithms,
    "aif360_algorithms": config.collection_algorithms,
}


def _tokenize(text: str) -> set[str]:
    return {
        token for token in re.findall(r"[a-zA-Z0-9_]+", text.lower())
        if len(token) > 2
    }


def _score_text(query: str, text: str) -> int:
    return len(_tokenize(query) & _tokenize(text))


def _fallback_pdf_search(query: str, k: int) -> str:
    if not DEFAULT_LAWS_PDF.exists():
        return "No relevant documents found in ai_ethics_laws."

    reader = PdfReader(str(DEFAULT_LAWS_PDF))
    scored_pages = []
    for page_index, page in enumerate(reader.pages):
        content = (page.extract_text() or "").strip()
        if not content:
            continue
        score = _score_text(query, content)
        if score > 0:
            excerpt = " ".join(content.split())[:900]
            scored_pages.append((score, page_index + 1, excerpt))

    if not scored_pages:
        return "No relevant documents found in ai_ethics_laws."

    scored_pages.sort(key=lambda item: item[0], reverse=True)
    return "\n\n---\n\n".join(
        f"[{rank}] Source: {DEFAULT_LAWS_PDF.name} (Page {page})\n{excerpt}"
        for rank, (_, page, excerpt) in enumerate(scored_pages[:k], start=1)
    )


def _fallback_algorithm_search(query: str, k: int) -> str:
    if not DEFAULT_ALGORITHMS_TXT.exists():
        return "No relevant documents found in aif360_algorithms."

    content = DEFAULT_ALGORITHMS_TXT.read_text(encoding="utf-8")
    sections = re.split(r"\n={3,}\n|\n##+ ", content)
    scored_sections = []
    for index, section in enumerate(sections, start=1):
        section = section.strip()
        if len(section) < 120:
            continue
        score = _score_text(query, section)
        if score > 0:
            excerpt = " ".join(section.split())[:1000]
            title = excerpt.split(".")[0][:100] or f"Section {index}"
            scored_sections.append((score, title, excerpt))

    if not scored_sections:
        return "No relevant documents found in aif360_algorithms."

    scored_sections.sort(key=lambda item: item[0], reverse=True)
    return "\n\n---\n\n".join(
        f"[{rank}] Source: {DEFAULT_ALGORITHMS_TXT.name} | Section: {title}\n{excerpt}"
        for rank, (_, title, excerpt) in enumerate(scored_sections[:k], start=1)
    )


def _format_docs(docs: List[Document], collection: str) -> str:
    if not docs:
        return f"No relevant documents found in {collection}."

    results = []
    for index, doc in enumerate(docs, start=1):
        source = doc.metadata.get("source", "Unknown")
        page = doc.metadata.get("page", "N/A")
        section = doc.metadata.get("section", "")
        if section and section != "N/A":
            header = f"[{index}] Source: {source} | Section: {section}"
        elif page != "N/A":
            header = f"[{index}] Source: {source} (Page {page})"
        else:
            header = f"[{index}] Source: {source}"
        results.append(f"{header}\n{doc.page_content.strip()}")
    return "\n\n---\n\n".join(results)


class KnowledgeService:
    """One service for Veritas RAG ingestion, status, and search."""

    def status(self) -> Dict[str, Any]:
        return knowledge_base.status()

    def ingest_defaults(self, force: bool = False) -> Dict[str, Any]:
        return knowledge_base.ensure_default_knowledge_bases(force=force)

    def ingest(
        self,
        laws_pdf: Optional[str] = None,
        algorithms_txt: Optional[str] = None,
        force: bool = False,
    ) -> Dict[str, Any]:
        return knowledge_base.init_all(
            laws_pdf=laws_pdf,
            algorithms_txt=algorithms_txt,
            force=force,
        )

    def search(self, collection: str, query: str, k: int = 5) -> str:
        resolved = COLLECTION_ALIASES.get(collection, collection)
        try:
            if check_vector_store(resolved):
                docs = get_vector_store(resolved).similarity_search(query, k=k)
                return _format_docs(docs, resolved)
        except Exception:
            pass

        if resolved == config.collection_algorithms:
            return _fallback_algorithm_search(query, k)
        return _fallback_pdf_search(query, k)

    def recommend_algorithm(
        self,
        bias_issue: str,
        constraint_type: str,
        can_retrain: bool = True,
    ) -> str:
        query_parts = [bias_issue, constraint_type]
        query_parts.append("preprocessing or inprocessing" if can_retrain else "postprocessing")
        results = self.search(config.collection_algorithms, f"best algorithm for {' '.join(query_parts)}", k=3)
        if results.startswith("No relevant documents found"):
            return "No algorithm recommendations found."
        return (
            "## Recommended Mitigation Algorithm(s)\n\n"
            + results
            + "\n\n**Usage:** Import from aif360.algorithms or aif360.sklearn modules."
        )


knowledge_service = KnowledgeService()

__all__ = ["KnowledgeService", "knowledge_service", "knowledge_base"]
