# Veritas - AI Bias Detection and Ethics Compliance

Veritas audits sklearn-compatible models for group fairness issues, applies AIF360 mitigation when requested, retrieves AI ethics context from bundled knowledge bases, and produces deterministic or LLM-assisted markdown reports.

## Features

- Canonical audit API for models and predictions
- AIF360 fairness metrics and threshold-based issue detection
- AIF360 mitigation registry with automatic strategy selection
- sklearn-compatible `VeritasClassifier`
- Bundled RAG knowledge bases with Chroma search and lexical fallback
- Import-time knowledge-base auto-initialization through `_bootstrap.py`
- CLI for knowledge-base init, status, and query

## Installation

```bash
pip install veritas-ml
```

For local development:

```bash
pip install -e .
```

Create `bias_params.json` beside your script or in the working directory:

```json
{
  "protected_attributes": ["sex", "race"]
}
```

## Quick Start

### Audit Predictions

```python
from veritas import AuditConfig, audit_predictions

config = AuditConfig(protected_attributes=["sex"])

result = audit_predictions(
    y_true=[0, 1, 1, 0],
    y_pred=[0, 1, 0, 0],
    sensitive=[0, 1, 1, 0],
    config=config,
    X=[[1.0], [2.0], [3.0], [4.0]],
)

print(result.to_dict()["bias_issues"])
```

### Audit a Trained Model

```python
from sklearn.linear_model import LogisticRegression
from veritas import AuditConfig, audit_model

model = LogisticRegression(max_iter=500).fit(X_train, y_train)
config = AuditConfig(protected_attributes=["sex"])

audit = audit_model(model, X_test, y_test, sensitive_test, config)
print(audit.to_dict()["dataset_metrics"])
```

### Run the Full Pipeline

```python
from sklearn.linear_model import LogisticRegression
from veritas import AuditConfig, run_pipeline

config = AuditConfig(
    protected_attributes=["sex", "race"],
    dataset_name="training dataset",
)

result = run_pipeline(
    LogisticRegression(max_iter=500),
    X_train,
    y_train,
    sensitive_train,
    config,
    strategy="auto",
    generate_report=True,
)

print(result.to_dict()["final_report"])
```

### Use the sklearn Wrapper

```python
from sklearn.ensemble import RandomForestClassifier
from veritas import VeritasClassifier

clf = VeritasClassifier(
    base_estimator=RandomForestClassifier(n_estimators=100),
    protected_attributes=["sex"],
    run_audit=True,
    apply_mitigation=True,
    generate_report=True,
)

clf.fit(X_train, y_train, sensitive_features=sensitive_train)
print(clf.get_bias_summary())
print(clf.get_compliance_report())
```

## Knowledge Bases

Veritas keeps import-time auto-initialization in `_bootstrap.py`. If `~/.veritas/vector_store/` does not exist, import-time bootstrap attempts to ingest the bundled knowledge assets. Search still works through bundled lexical fallback when Chroma is unavailable.

CLI:

```bash
veritas init --laws src/veritas/knowledge/ai_ethics_knowledge_base.pdf \
  --algorithms src/veritas/knowledge/aif360_algorithms_documentation.txt
veritas status
veritas query --db laws "gender discrimination in hiring algorithms"
veritas query --db algorithms "reweighing disparate impact"
```

## Public API

- `AuditConfig`
- `AuditResult`
- `MitigationResult`
- `PipelineResult`
- `audit_predictions(...)`
- `audit_model(...)`
- `mitigate_model(...)`
- `run_pipeline(...)`
- `VeritasClassifier`
- `BiasDetector` as a thin compatibility adapter over `audit_model`

## Testing

```bash
veritas_venv/bin/python -m unittest discover -v
```
