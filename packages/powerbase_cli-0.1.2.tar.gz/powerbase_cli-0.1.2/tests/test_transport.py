from __future__ import annotations

import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from urllib.error import HTTPError, URLError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from powerbase_cli.config import BUNDLED_CA_CERT_SENTINEL, AppConfig, AuthSession, AuthState, ConfigStore
from powerbase_cli.session import SessionManager
from powerbase_cli.transport import ApiError, PowerbaseTransport


class FakeResponse:
    def __init__(self, payload: dict[str, object]) -> None:
        self.payload = payload

    def read(self) -> bytes:
        return json.dumps(self.payload).encode("utf-8")


def build_http_error(status: int, payload: dict[str, object]) -> HTTPError:
    return HTTPError(
        url="https://console.example.com/functions/v1/instances",
        code=status,
        msg="error",
        hdrs=None,
        fp=io.BytesIO(json.dumps(payload).encode("utf-8")),
    )


class PowerbaseTransportTests(unittest.TestCase):
    def test_invoke_requires_login_when_session_missing(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            manager = SessionManager(store, "https://console.example.com", "anon")
            transport = PowerbaseTransport(AppConfig(base_url="https://console.example.com", anon_key="anon"), manager)

            with mock.patch("powerbase_cli.transport.request.urlopen") as urlopen_mock:
                with self.assertRaises(ApiError) as ctx:
                    transport.invoke("instances", method="GET")

        self.assertEqual(ctx.exception.status, 401)
        self.assertIn("No authentication session available", str(ctx.exception))
        self.assertIn("powerbase auth login --no-wait --json", str(ctx.exception))
        self.assertEqual(urlopen_mock.call_count, 0)

    def test_invoke_uses_unverified_tls_context_when_insecure(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            manager = SessionManager(store, "https://console.example.com", "anon", tls_insecure=True)
            transport = PowerbaseTransport(
                AppConfig(base_url="https://console.example.com", anon_key="anon", tls_insecure=True),
                manager,
            )

            with mock.patch(
                "powerbase_cli.transport.request.urlopen",
                return_value=FakeResponse({"success": True, "data": {"ok": True}}),
            ) as urlopen_mock:
                result = transport.invoke("instances", method="GET", requires_auth=False)

            self.assertEqual(result["data"]["ok"], True)
            context = urlopen_mock.call_args.kwargs["context"]
            self.assertFalse(context.check_hostname)

    def test_invoke_uses_ca_cert_context_when_configured(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            manager = SessionManager(store, "https://console.example.com", "anon", ca_cert_file="/tmp/test-ca.pem")
            transport = PowerbaseTransport(
                AppConfig(base_url="https://console.example.com", anon_key="anon", ca_cert_file="/tmp/test-ca.pem"),
                manager,
            )

            with mock.patch("powerbase_cli.transport.ssl.create_default_context") as context_factory:
                fake_context = object()
                context_factory.return_value = fake_context
                with mock.patch(
                    "powerbase_cli.transport.request.urlopen",
                    return_value=FakeResponse({"success": True, "data": {"ok": True}}),
                ) as urlopen_mock:
                    result = transport.invoke("instances", method="GET", requires_auth=False)

            self.assertEqual(result["data"]["ok"], True)
            context_factory.assert_called_once_with(cafile="/tmp/test-ca.pem")
            self.assertIs(urlopen_mock.call_args.kwargs["context"], fake_context)

    def test_invoke_uses_bundled_ca_cert_when_configured(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            manager = SessionManager(store, "https://console.example.com", "anon", ca_cert_file=BUNDLED_CA_CERT_SENTINEL)
            transport = PowerbaseTransport(
                AppConfig(base_url="https://console.example.com", anon_key="anon", ca_cert_file=BUNDLED_CA_CERT_SENTINEL),
                manager,
            )

            with mock.patch("powerbase_cli.transport.load_bundled_ca_cert", return_value="PEM DATA") as bundled_cert:
                with mock.patch("powerbase_cli.transport.ssl.create_default_context") as context_factory:
                    fake_context = object()
                    context_factory.return_value = fake_context
                    with mock.patch(
                        "powerbase_cli.transport.request.urlopen",
                        return_value=FakeResponse({"success": True, "data": {"ok": True}}),
                    ) as urlopen_mock:
                        result = transport.invoke("instances", method="GET", requires_auth=False)

            self.assertEqual(result["data"]["ok"], True)
            bundled_cert.assert_called_once_with()
            context_factory.assert_called_once_with(cadata="PEM DATA")
            self.assertIs(urlopen_mock.call_args.kwargs["context"], fake_context)

    def test_invoke_refreshes_and_retries_once_on_401(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            store.save_auth(
                AuthState(
                    source="login",
                    base_url="https://console.example.com",
                    anon_key="anon",
                    session=AuthSession(
                        access_token="stale-access",
                        refresh_token="refresh-token",
                        expires_at=9999999999,
                    ),
                )
            )
            manager = SessionManager(store, "https://console.example.com", "anon")
            transport = PowerbaseTransport(AppConfig(base_url="https://console.example.com", anon_key="anon"), manager)

            with mock.patch.object(manager, "refresh", return_value=AuthState(
                source="login",
                base_url="https://console.example.com",
                anon_key="anon",
                session=AuthSession(
                    access_token="fresh-access",
                    refresh_token="refresh-token",
                    expires_at=9999999999,
                ),
            )) as refresh_mock:
                with mock.patch("powerbase_cli.transport.request.urlopen") as urlopen_mock:
                    urlopen_mock.side_effect = [
                        build_http_error(401, {"error": "expired"}),
                        FakeResponse({"success": True, "data": {"ok": True}}),
                    ]

                    result = transport.invoke("instances", method="GET")

            self.assertEqual(result["data"]["ok"], True)
            self.assertEqual(refresh_mock.call_count, 1)
            self.assertEqual(urlopen_mock.call_count, 2)
            first_auth = urlopen_mock.call_args_list[0].args[0].headers["Authorization"]
            second_auth = urlopen_mock.call_args_list[1].args[0].headers["Authorization"]
            self.assertEqual(first_auth, "Bearer stale-access")
            self.assertEqual(second_auth, "Bearer fresh-access")

    def test_invoke_does_not_retry_401_without_refresh_token(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            store.save_auth(
                AuthState(
                    source="login",
                    base_url="https://console.example.com",
                    anon_key="anon",
                    session=AuthSession(access_token="stale-access", refresh_token=None, expires_at=9999999999),
                )
            )
            manager = SessionManager(store, "https://console.example.com", "anon")
            transport = PowerbaseTransport(AppConfig(base_url="https://console.example.com", anon_key="anon"), manager)

            with mock.patch.object(manager, "refresh") as refresh_mock:
                with mock.patch(
                    "powerbase_cli.transport.request.urlopen",
                    side_effect=build_http_error(401, {"error": "expired"}),
                ) as urlopen_mock:
                    with self.assertRaises(ApiError) as ctx:
                        transport.invoke("instances", method="GET")

            self.assertEqual(ctx.exception.status, 401)
            self.assertIn("powerbase auth login --no-wait --json", str(ctx.exception))
            self.assertEqual(refresh_mock.call_count, 0)
            self.assertEqual(urlopen_mock.call_count, 1)

    def test_invoke_wraps_url_errors(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            manager = SessionManager(store, "https://console.example.com", "anon")
            transport = PowerbaseTransport(AppConfig(base_url="https://console.example.com", anon_key="anon"), manager)

            with mock.patch("powerbase_cli.transport.request.urlopen", side_effect=URLError("tls failed")):
                with self.assertRaises(ApiError) as ctx:
                    transport.invoke("instances", method="GET", requires_auth=False)

            self.assertIn("tls failed", str(ctx.exception))
