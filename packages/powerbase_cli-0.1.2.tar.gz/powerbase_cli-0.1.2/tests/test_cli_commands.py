from __future__ import annotations

import json
import sys
import tempfile
import unittest
from argparse import Namespace
from io import StringIO
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from powerbase_cli.commands.auth import handle_auth_login as auth_handle_auth_login
from powerbase_cli.commands.agent import handle_agent_chat as agent_handle_agent_chat
from powerbase_cli.commands.shared import resolve_config as shared_resolve_config
from powerbase_cli.config import (
    BUNDLED_CA_CERT_SENTINEL,
    AppConfig,
    AuthSession,
    AuthState,
    ConfigStore,
    DEFAULT_ANON_KEY,
    DEFAULT_BASE_URL,
)


class FakeApiPending:
    def start_cli_login(self):
        return {
            "login_id": "login-pending",
            "login_url": "https://console.example.com/cli-auth/pending",
            "poll_interval": 2,
        }

    def poll_cli_login(self, login_id: str):
        return {"status": "pending", "poll_interval": 2}


class FakeApiNoWait:
    def start_cli_login(self):
        return {
            "login_id": "login-nowait",
            "login_url": "https://console.example.com/cli-auth/login-nowait",
            "poll_interval": 2,
        }

    def poll_cli_login(self, login_id: str):
        raise AssertionError("poll_cli_login should not be called when --no-wait is set")


class FakeApi:
    def start_cli_login(self):
        return {
            "login_id": "login-1",
            "login_url": "https://console.example.com/cli-auth/login-1",
            "poll_interval": 0,
        }

    def poll_cli_login(self, login_id: str):
        return {
            "status": "approved",
            "session": {
                "access_token": "new-access",
                "refresh_token": "new-refresh",
                "token_type": "bearer",
                "expires_at": 9999999999,
            },
            "user": {"id": "user-1", "email": "u@example.com"},
        }

    def agent_chat(self, instance_id: str, message: str, **kwargs):
        yield {
            "jsonrpc": "2.0",
            "method": "obaas/promptPart",
            "params": {"sessionId": kwargs.get("session_id"), "text": message, "instanceId": instance_id},
        }


class CliCommandTests(unittest.TestCase):
    def test_resolve_config_falls_back_to_builtin_service_defaults(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            args = Namespace(
                config_dir=temp_dir,
                base_url=None,
                anon_key=None,
                json=False,
                insecure=False,
                ca_cert_file=None,
            )
            resolved = shared_resolve_config(args, store)
            self.assertEqual(resolved.base_url, DEFAULT_BASE_URL)
            self.assertEqual(resolved.anon_key, DEFAULT_ANON_KEY)
            self.assertEqual(resolved.ca_cert_file, BUNDLED_CA_CERT_SENTINEL)

    def test_resolve_config_falls_back_to_saved_auth_values(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            store.save_auth(
                AuthState(
                    source="login",
                    base_url="https://console.example.com",
                    anon_key="anon",
                    session=AuthSession(access_token="token"),
                )
            )
            args = Namespace(config_dir=temp_dir, base_url=None, anon_key=None, json=False, insecure=False, ca_cert_file=None)
            resolved = shared_resolve_config(args, store)
            self.assertEqual(resolved.base_url, "https://console.example.com")
            self.assertEqual(resolved.anon_key, "anon")

    def test_auth_login_saves_polled_session(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            config = AppConfig(base_url="https://console.example.com", anon_key="anon")
            args = Namespace(
                config_dir=temp_dir,
                base_url=None,
                anon_key=None,
                json=True,
                login_timeout=300,
                no_wait_login=False,
                insecure=False,
            )

            with mock.patch("powerbase_cli.commands.auth.build_api", return_value=(store, config, None, None, FakeApi())):
                with mock.patch("powerbase_cli.commands.auth.time.sleep", return_value=None):
                    with mock.patch("sys.stdout", new=StringIO()):
                        exit_code = auth_handle_auth_login(args)

            self.assertEqual(exit_code, 0)
            saved = store.load_auth()
            assert saved is not None
            self.assertEqual(saved.session.access_token, "new-access")
            self.assertEqual(saved.user["id"], "user-1")

    def test_auth_login_no_wait_returns_login_url_without_polling(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            config = AppConfig(base_url="https://console.example.com", anon_key="anon")
            args = Namespace(
                config_dir=temp_dir,
                base_url=None,
                anon_key=None,
                json=True,
                login_timeout=300,
                no_wait_login=True,
                insecure=False,
            )

            with mock.patch("powerbase_cli.commands.auth.build_api", return_value=(store, config, None, None, FakeApiNoWait())):
                with mock.patch("sys.stdout", new=StringIO()) as stdout:
                    exit_code = auth_handle_auth_login(args)

            self.assertEqual(exit_code, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["status"], "pending")
            self.assertEqual(payload["login_id"], "login-nowait")
            self.assertEqual(payload["next_action"], "ask_user_to_open_url")
            self.assertIn("login_url", payload)
            self.assertIsNone(store.load_auth())

    def test_auth_login_times_out(self) -> None:
        clock = {"t": 0.0}

        def fake_monotonic() -> float:
            return clock["t"]

        def fake_sleep(delta: float) -> None:
            clock["t"] += delta

        with tempfile.TemporaryDirectory() as temp_dir:
            store = ConfigStore(Path(temp_dir))
            config = AppConfig(base_url="https://console.example.com", anon_key="anon")
            args = Namespace(
                config_dir=temp_dir,
                base_url=None,
                anon_key=None,
                json=False,
                login_timeout=5,
                no_wait_login=False,
                insecure=False,
            )

            with mock.patch("powerbase_cli.commands.auth.build_api", return_value=(store, config, None, None, FakeApiPending())):
                with mock.patch("powerbase_cli.commands.auth.time.monotonic", fake_monotonic):
                    with mock.patch("powerbase_cli.commands.auth.time.sleep", fake_sleep):
                        with mock.patch("sys.stdout", new=StringIO()):
                            with self.assertRaises(RuntimeError) as ctx:
                                auth_handle_auth_login(args)

            self.assertIn("timed out", str(ctx.exception).lower())
            self.assertIn("5", str(ctx.exception))
            self.assertIsNone(store.load_auth())

    def test_agent_chat_streams_jsonl(self) -> None:
        args = Namespace(
            config_dir=None,
            base_url=None,
            anon_key=None,
            json=False,
            insecure=False,
            instance_id="inst-1",
            provider="cursor",
            session_id="sess-1",
            model=None,
            agent_name=None,
            message="Build a todo app",
            message_file=None,
            first_user_message=None,
            first_user_message_file=None,
            stream_jsonl=True,
        )
        context = Namespace(instance_id="inst-1")
        with mock.patch("powerbase_cli.commands.agent.build_api", return_value=(None, None, context, None, FakeApi())):
            with mock.patch("sys.stdout", new=StringIO()) as stdout:
                exit_code = agent_handle_agent_chat(args)

        self.assertEqual(exit_code, 0)
        output = stdout.getvalue()
        self.assertIn("Build a todo app", output)
        self.assertIn("sess-1", output)
