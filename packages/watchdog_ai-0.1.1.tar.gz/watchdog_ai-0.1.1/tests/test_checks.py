#!/usr/bin/env python3
"""Tests for watchdog-ai checks, config, and runner."""

import json
import os
import shutil
import sys
import tempfile
import time

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from wdog.checks.base import BaseCheck, CheckResult
from wdog.checks.freshness import FreshnessCheck, parse_duration, _resolve_path, _format_age
from wdog.checks.log_scan import LogScanCheck
from wdog.checks.assertion import AssertionCheck, _evaluate, _resolve, _parse_literal
from wdog.checks.http import HttpCheck
from wdog.checks.custom import CustomCheck
from wdog.checks.process import ProcessCheck
from wdog.checks import create_check, REGISTRY
from wdog.config import load_config, find_config, _interpolate_env

passed = 0
failed = 0


def test(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print('  PASS: {}'.format(name))
    else:
        failed += 1
        print('  FAIL: {}'.format(name))


def make_temp_dir():
    return tempfile.mkdtemp(prefix='wdog_test_')


def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write(content)


# ============================================================
# CheckResult / BaseCheck
# ============================================================
print('Testing CheckResult and BaseCheck...')

r = CheckResult('test', 'healthy', 'OK', {'k': 1})
test('CheckResult stores fields', r.name == 'test' and r.status == 'healthy')
test('CheckResult to_dict has keys', set(r.to_dict().keys()) == {'name', 'status', 'message', 'detail', 'timestamp'})
test('CheckResult repr', 'test' in repr(r) and 'healthy' in repr(r))

r2 = CheckResult('x', 'critical', 'bad')
test('CheckResult default detail is empty dict', r2.detail == {})
test('CheckResult timestamp auto-set', r2.timestamp is not None)

# BaseCheck helpers
cfg = {'name': 'mycheck', 'severity': 'critical'}
bc = BaseCheck(cfg)
test('BaseCheck stores name', bc.name == 'mycheck')
test('BaseCheck stores severity', bc.severity == 'critical')

hr = bc._healthy('all good', {'x': 1})
test('_healthy returns healthy status', hr.status == 'healthy' and hr.message == 'all good')

fr = bc._fail('broken')
test('_fail uses configured severity', fr.status == 'critical' and fr.message == 'broken')

cfg_default = {'name': 'default_sev'}
bc2 = BaseCheck(cfg_default)
test('BaseCheck default severity is warning', bc2.severity == 'warning')

try:
    bc.run()
    test('BaseCheck.run raises NotImplementedError', False)
except NotImplementedError:
    test('BaseCheck.run raises NotImplementedError', True)


# ============================================================
# parse_duration
# ============================================================
print('Testing parse_duration...')

test('parse seconds', parse_duration('30s') == 30)
test('parse minutes', parse_duration('5m') == 300)
test('parse hours', parse_duration('2h') == 7200)
test('parse days', parse_duration('1d') == 86400)
test('parse float', parse_duration('1.5h') == 5400)
test('parse bare number', parse_duration('120') == 120)

try:
    parse_duration('abc')
    test('parse invalid raises ValueError', False)
except ValueError:
    test('parse invalid raises ValueError', True)


# ============================================================
# _format_age
# ============================================================
print('Testing _format_age...')

test('format seconds', _format_age(45) == '45s')
test('format minutes', _format_age(120) == '2m')
test('format hours', _format_age(7200) == '2.0h')
test('format days', _format_age(172800) == '2.0d')


# ============================================================
# _resolve_path (freshness JSON path resolver)
# ============================================================
print('Testing _resolve_path...')

data = {'a': {'b': {'c': 42}}, 'x': 'hello'}
test('dotted path resolves', _resolve_path(data, 'a.b.c') == 42)
test('dollar prefix resolves', _resolve_path(data, '$.a.b.c') == 42)
test('simple key resolves', _resolve_path(data, 'x') == 'hello')
test('missing key returns None', _resolve_path(data, 'a.b.missing') is None)
test('missing nested returns None', _resolve_path(data, 'z.y') is None)


# ============================================================
# FreshnessCheck
# ============================================================
print('Testing FreshnessCheck...')

tmpdir = make_temp_dir()
try:
    # Fresh file
    fresh_file = os.path.join(tmpdir, 'fresh.txt')
    write_file(fresh_file, 'data')

    cfg = {'name': 'freshness-test', 'type': 'freshness', 'path': fresh_file, 'max_age': '1h'}
    check = FreshnessCheck(cfg)
    result = check.run()
    test('fresh file is healthy', result.status == 'healthy')

    # Stale file (set mtime to 2 days ago)
    stale_file = os.path.join(tmpdir, 'stale.txt')
    write_file(stale_file, 'old data')
    old_time = time.time() - 200000
    os.utime(stale_file, (old_time, old_time))

    cfg = {'name': 'stale-test', 'type': 'freshness', 'path': stale_file, 'max_age': '1h', 'severity': 'critical'}
    check = FreshnessCheck(cfg)
    result = check.run()
    test('stale file fails', result.status == 'critical')
    test('stale message mentions stale', 'Stale' in result.message or 'stale' in result.message)

    # Missing file
    cfg = {'name': 'missing-test', 'type': 'freshness', 'path': '/nonexistent/file.txt', 'max_age': '1h'}
    check = FreshnessCheck(cfg)
    result = check.run()
    test('missing file fails', result.status == 'warning')
    test('missing file message', 'not found' in result.message.lower())

    # Invalid duration
    cfg = {'name': 'bad-dur', 'type': 'freshness', 'path': fresh_file, 'max_age': 'xyz'}
    check = FreshnessCheck(cfg)
    result = check.run()
    test('invalid duration fails', result.status == 'warning')

    # JSON field check
    json_file = os.path.join(tmpdir, 'state.json')
    write_file(json_file, json.dumps({'updated_at': '2020-01-01T00:00:00'}))

    cfg = {'name': 'json-field', 'type': 'freshness', 'path': json_file, 'max_age': '1h', 'json_field': 'updated_at'}
    check = FreshnessCheck(cfg)
    result = check.run()
    test('stale JSON field fails', result.status == 'warning')

    # JSON field not found
    cfg = {'name': 'json-missing', 'type': 'freshness', 'path': json_file, 'max_age': '1h', 'json_field': 'nonexistent'}
    check = FreshnessCheck(cfg)
    result = check.run()
    test('missing JSON field fails', result.status == 'warning')
    test('missing JSON field message', 'not found' in result.message.lower())

    # Malformed JSON
    bad_json = os.path.join(tmpdir, 'bad.json')
    write_file(bad_json, '{bad json!!!')
    cfg = {'name': 'bad-json', 'type': 'freshness', 'path': bad_json, 'max_age': '1h', 'json_field': 'x'}
    check = FreshnessCheck(cfg)
    result = check.run()
    test('malformed JSON fails', result.status == 'warning')

    # Relative path resolution
    subfile = os.path.join(tmpdir, 'sub', 'data.txt')
    write_file(subfile, 'relative')
    cfg = {'name': 'rel-path', 'type': 'freshness', 'path': 'sub/data.txt', 'max_age': '1h', '_config_dir': tmpdir}
    check = FreshnessCheck(cfg)
    result = check.run()
    test('relative path resolves', result.status == 'healthy')

finally:
    shutil.rmtree(tmpdir)


# ============================================================
# LogScanCheck
# ============================================================
print('Testing LogScanCheck...')

tmpdir = make_temp_dir()
try:
    # Log with errors
    log_file = os.path.join(tmpdir, 'app.log')
    lines = ['INFO: all good\n', 'ERROR: something broke\n', 'INFO: ok\n',
             'Traceback (most recent call last):\n', 'INFO: recovering\n']
    write_file(log_file, ''.join(lines))

    cfg = {'name': 'log-err', 'type': 'log_scan', 'path': log_file,
           'patterns': ['error', 'traceback'], 'tail': 50, 'threshold': 1}
    check = LogScanCheck(cfg)
    result = check.run()
    test('log scan detects errors', result.status == 'warning')
    test('log scan counts matches', result.detail['total_matches'] == 2)

    # Log with errors below threshold
    cfg = {'name': 'log-thresh', 'type': 'log_scan', 'path': log_file,
           'patterns': ['error'], 'tail': 50, 'threshold': 5}
    check = LogScanCheck(cfg)
    result = check.run()
    test('below threshold is healthy', result.status == 'healthy')

    # Clean log
    clean_log = os.path.join(tmpdir, 'clean.log')
    write_file(clean_log, 'INFO: started\nINFO: running\nINFO: done\n')

    cfg = {'name': 'log-clean', 'type': 'log_scan', 'path': clean_log,
           'patterns': ['error', 'traceback'], 'tail': 50, 'threshold': 1}
    check = LogScanCheck(cfg)
    result = check.run()
    test('clean log is healthy', result.status == 'healthy')
    test('clean log zero matches', result.detail['total_matches'] == 0)

    # Missing log file
    cfg = {'name': 'log-missing', 'type': 'log_scan', 'path': '/nonexistent/app.log',
           'patterns': ['error'], 'tail': 50, 'threshold': 1}
    check = LogScanCheck(cfg)
    result = check.run()
    test('missing log fails', result.status == 'warning')

    # No patterns configured
    cfg = {'name': 'log-nopat', 'type': 'log_scan', 'path': log_file,
           'patterns': [], 'tail': 50, 'threshold': 1}
    check = LogScanCheck(cfg)
    result = check.run()
    test('no patterns is healthy', result.status == 'healthy')

    # Empty log file
    empty_log = os.path.join(tmpdir, 'empty.log')
    write_file(empty_log, '')
    cfg = {'name': 'log-empty', 'type': 'log_scan', 'path': empty_log,
           'patterns': ['error'], 'tail': 50, 'threshold': 1}
    check = LogScanCheck(cfg)
    result = check.run()
    test('empty log is healthy', result.status == 'healthy')

    # Relative path resolution
    rel_log = os.path.join(tmpdir, 'sub', 'rel.log')
    write_file(rel_log, 'ERROR: boom\n')
    cfg = {'name': 'log-rel', 'type': 'log_scan', 'path': 'sub/rel.log',
           'patterns': ['error'], 'tail': 50, 'threshold': 1, '_config_dir': tmpdir}
    check = LogScanCheck(cfg)
    result = check.run()
    test('log relative path resolves', result.status == 'warning')

finally:
    shutil.rmtree(tmpdir)


# ============================================================
# AssertionCheck
# ============================================================
print('Testing AssertionCheck...')

tmpdir = make_temp_dir()
try:
    data_file = os.path.join(tmpdir, 'state.json')
    write_file(data_file, json.dumps({
        'balance': 1500,
        'trades': 42,
        'status': 'running',
        'nested': {'value': 10},
        'items': [{'name': 'first'}, {'name': 'second'}],
    }))

    # Passing condition
    cfg = {'name': 'assert-pass', 'type': 'assertion', 'source': data_file,
           'conditions': [{'expr': '$.balance > 1000'}]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('passing assertion is healthy', result.status == 'healthy')

    # Failing condition
    cfg = {'name': 'assert-fail', 'type': 'assertion', 'source': data_file,
           'conditions': [{'expr': '$.balance > 9999', 'message': 'Balance too low'}],
           'severity': 'critical'}
    check = AssertionCheck(cfg)
    result = check.run()
    test('failing assertion returns severity', result.status == 'critical')
    test('failure message present', 'Balance too low' in result.message)

    # Multiple conditions, some fail
    cfg = {'name': 'assert-multi', 'type': 'assertion', 'source': data_file,
           'conditions': [
               {'expr': '$.balance > 0'},
               {'expr': '$.balance < 100', 'message': 'too high'},
               {'expr': '$.trades > 0'},
           ]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('multi condition partial fail', result.status == 'warning')
    test('reports 1 failure', '1 condition' in result.message)

    # String comparison
    cfg = {'name': 'assert-str', 'type': 'assertion', 'source': data_file,
           'conditions': [{'expr': '$.status == "running"'}]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('string equality passes', result.status == 'healthy')

    # Not-equal check
    cfg = {'name': 'assert-ne', 'type': 'assertion', 'source': data_file,
           'conditions': [{'expr': '$.status != "stopped"'}]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('not-equal passes', result.status == 'healthy')

    # Nested path
    cfg = {'name': 'assert-nested', 'type': 'assertion', 'source': data_file,
           'conditions': [{'expr': '$.nested.value > 5'}]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('nested path resolves', result.status == 'healthy')

    # Contains check
    cfg = {'name': 'assert-contains', 'type': 'assertion', 'source': data_file,
           'conditions': [{'expr': '$.status contains "run"'}]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('contains check passes', result.status == 'healthy')

    # Missing source file
    cfg = {'name': 'assert-nosrc', 'type': 'assertion', 'source': '/nonexistent/data.json',
           'conditions': [{'expr': '$.x > 0'}]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('missing source fails', result.status == 'warning')

    # Malformed JSON source
    bad_json = os.path.join(tmpdir, 'bad.json')
    write_file(bad_json, 'not json{{{')
    cfg = {'name': 'assert-badjson', 'type': 'assertion', 'source': bad_json,
           'conditions': [{'expr': '$.x > 0'}]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('malformed JSON source fails', result.status == 'warning')

    # Empty conditions
    cfg = {'name': 'assert-empty', 'type': 'assertion', 'source': data_file,
           'conditions': []}
    check = AssertionCheck(cfg)
    result = check.run()
    test('empty conditions is healthy', result.status == 'healthy')

    # Critical severity override per condition
    cfg = {'name': 'assert-sev', 'type': 'assertion', 'source': data_file,
           'severity': 'warning',
           'conditions': [
               {'expr': '$.balance > 99999', 'severity': 'critical'},
           ]}
    check = AssertionCheck(cfg)
    result = check.run()
    test('per-condition severity override', result.status == 'critical')

finally:
    shutil.rmtree(tmpdir)


# ============================================================
# _evaluate / _resolve / _parse_literal (assertion internals)
# ============================================================
print('Testing assertion internals...')

data = {'a': 10, 'b': 20, 'items': [100, 200, 300]}

ok, err = _evaluate('$.a > 5', data)
test('evaluate > true', ok)

ok, err = _evaluate('$.a > 50', data)
test('evaluate > false', not ok)

ok, err = _evaluate('$.a >= 10', data)
test('evaluate >= true', ok)

ok, err = _evaluate('$.a <= 10', data)
test('evaluate <= true', ok)

ok, err = _evaluate('$.a < $.b', data)
test('evaluate field vs field', ok)

ok, err = _evaluate('$.a == 10', data)
test('evaluate == number', ok)

ok, err = _evaluate('$.missing > 0', data)
test('evaluate missing field', not ok and 'not found' in err.lower())

ok, err = _evaluate('nonsense expression', data)
test('evaluate unparseable returns false', not ok)

# _resolve with array index
val, found = _resolve(data, '$.items[0]')
test('resolve array index', found and val == 100)

val, found = _resolve(data, '$.items[99]')
test('resolve out-of-bounds array', not found)

# _parse_literal
val, found = _parse_literal('"hello"')
test('parse string literal', found and val == 'hello')

val, found = _parse_literal('42')
test('parse int literal', found and val == 42)

val, found = _parse_literal('3.14')
test('parse float literal', found and val == 3.14)

val, found = _parse_literal('null')
test('parse null literal', found and val is None)

val, found = _parse_literal('true')
test('parse true literal', found and val is True)


# ============================================================
# HttpCheck (mocked)
# ============================================================
print('Testing HttpCheck (mocked)...')

# Mock urlopen to avoid real HTTP requests
import wdog.checks.http as http_module

_original_urlopen = http_module.urlopen


class MockResponse:
    def __init__(self, status, body=''):
        self._status = status
        self._body = body

    def getcode(self):
        return self._status

    def read(self):
        return self._body.encode('utf-8')

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


def _mock_urlopen_200(req, timeout=10):
    return MockResponse(200, '{"status": "ok"}')


def _mock_urlopen_500(req, timeout=10):
    raise http_module.HTTPError(req.full_url, 500, 'Server Error', {}, None)


def _mock_urlopen_timeout(req, timeout=10):
    raise http_module.URLError('Connection timed out')


try:
    # Successful request
    http_module.urlopen = _mock_urlopen_200
    cfg = {'name': 'http-ok', 'type': 'http', 'url': 'http://localhost/health',
           'expect_status': 200}
    check = HttpCheck(cfg)
    result = check.run()
    test('http 200 is healthy', result.status == 'healthy')
    test('http status message', '200' in result.message)

    # Status mismatch
    cfg = {'name': 'http-mismatch', 'type': 'http', 'url': 'http://localhost/health',
           'expect_status': 201}
    check = HttpCheck(cfg)
    result = check.run()
    test('http status mismatch fails', result.status == 'warning')

    # Server error
    http_module.urlopen = _mock_urlopen_500
    cfg = {'name': 'http-500', 'type': 'http', 'url': 'http://localhost/health',
           'expect_status': 200, 'severity': 'critical'}
    check = HttpCheck(cfg)
    result = check.run()
    test('http 500 fails', result.status == 'critical')

    # Connection failure
    http_module.urlopen = _mock_urlopen_timeout
    cfg = {'name': 'http-timeout', 'type': 'http', 'url': 'http://localhost/health',
           'expect_status': 200}
    check = HttpCheck(cfg)
    result = check.run()
    test('http connection failure fails', result.status == 'warning')
    test('http failure mentions connection', 'connection' in result.message.lower() or 'Connection' in result.message)

    # Body content check
    http_module.urlopen = _mock_urlopen_200
    cfg = {'name': 'http-body-ok', 'type': 'http', 'url': 'http://localhost/health',
           'expect_status': 200, 'expect_body': 'ok'}
    check = HttpCheck(cfg)
    result = check.run()
    test('http body match is healthy', result.status == 'healthy')

    cfg = {'name': 'http-body-miss', 'type': 'http', 'url': 'http://localhost/health',
           'expect_status': 200, 'expect_body': 'nonexistent_string'}
    check = HttpCheck(cfg)
    result = check.run()
    test('http body mismatch fails', result.status == 'warning')
    test('http body failure message', 'missing' in result.message.lower())

finally:
    http_module.urlopen = _original_urlopen


# ============================================================
# CustomCheck (script)
# ============================================================
print('Testing CustomCheck...')

cfg = {'name': 'custom-ok', 'type': 'script', 'command': 'echo "all good"', 'timeout': 5}
check = CustomCheck(cfg)
result = check.run()
test('custom exit 0 is healthy', result.status == 'healthy')
test('custom captures stdout', 'all good' in result.message or 'all good' in result.detail.get('stdout', ''))

cfg = {'name': 'custom-warn', 'type': 'script', 'command': 'exit 1', 'timeout': 5}
check = CustomCheck(cfg)
result = check.run()
test('custom exit 1 is warning', result.status == 'warning')

cfg = {'name': 'custom-crit', 'type': 'script', 'command': 'exit 2', 'timeout': 5}
check = CustomCheck(cfg)
result = check.run()
test('custom exit 2 is critical', result.status == 'critical')

cfg = {'name': 'custom-nocommand', 'type': 'script', 'command': '', 'timeout': 5}
check = CustomCheck(cfg)
result = check.run()
test('custom empty command fails', result.status == 'warning')

cfg = {'name': 'custom-timeout', 'type': 'script', 'command': 'sleep 60', 'timeout': 1}
check = CustomCheck(cfg)
result = check.run()
test('custom timeout fails', result.status == 'warning')
test('custom timeout message', 'timed out' in result.message.lower())

# Config dir for script
tmpdir = make_temp_dir()
try:
    script = os.path.join(tmpdir, 'check.sh')
    write_file(script, '#!/bin/sh\necho "script ok"')
    os.chmod(script, 0o755)
    cfg = {'name': 'custom-cwd', 'type': 'script', 'command': './check.sh',
           'timeout': 5, '_config_dir': tmpdir}
    check = CustomCheck(cfg)
    result = check.run()
    test('custom script with config_dir', result.status == 'healthy')
finally:
    shutil.rmtree(tmpdir)


# ============================================================
# ProcessCheck
# ============================================================
print('Testing ProcessCheck...')

# ps fallback: match launchd (always running on macOS)
cfg = {'name': 'proc-self', 'type': 'process', 'match': 'launchd', 'platform': 'ps'}
check = ProcessCheck(cfg)
result = check.run()
test('process check finds launchd', result.status == 'healthy')

# Non-existent process
cfg = {'name': 'proc-missing', 'type': 'process', 'match': 'zzz_nonexistent_proc_12345',
       'platform': 'ps'}
check = ProcessCheck(cfg)
result = check.run()
test('missing process fails', result.status == 'warning')

# Auto platform detection (should not crash)
cfg = {'name': 'proc-auto', 'type': 'process', 'match': 'python', 'platform': 'auto'}
check = ProcessCheck(cfg)
result = check.run()
test('auto platform runs without error', result.status in ('healthy', 'warning', 'critical'))


# ============================================================
# create_check registry
# ============================================================
print('Testing check registry...')

test('registry has all types', set(REGISTRY.keys()) == {'process', 'freshness', 'log_scan', 'assertion', 'http', 'script'})

cfg = {'name': 'reg-test', 'type': 'freshness', 'path': '/tmp/x', 'max_age': '1h'}
check = create_check(cfg)
test('create_check returns correct type', isinstance(check, FreshnessCheck))

try:
    create_check({'name': 'bad', 'type': 'nonexistent'})
    test('unknown type raises ValueError', False)
except ValueError:
    test('unknown type raises ValueError', True)


# ============================================================
# Config loading
# ============================================================
print('Testing config loading...')

tmpdir = make_temp_dir()
try:
    # Valid config
    config_path = os.path.join(tmpdir, 'watchdog.yaml')
    write_file(config_path, """
project: test-project
interval: 5m
checks:
  - name: Test check
    type: process
    match: python
  - name: Another check
    type: freshness
    path: ./data.txt
    max_age: 1h
""")
    config = load_config(config_path)
    test('config loads project name', config.get('project') == 'test-project')
    test('config loads checks', len(config.get('checks', [])) == 2)
    test('config injects _config_dir', config.get('_config_dir') == tmpdir)
    test('check inherits _config_dir', config['checks'][0].get('_config_dir') == tmpdir)

    # Empty config
    empty_path = os.path.join(tmpdir, 'empty.yaml')
    write_file(empty_path, '')
    try:
        load_config(empty_path)
        test('empty config raises ValueError', False)
    except ValueError as e:
        test('empty config raises ValueError', 'Empty' in str(e) or 'empty' in str(e))

    # Config with no checks
    no_checks_path = os.path.join(tmpdir, 'nochecks.yaml')
    write_file(no_checks_path, 'project: x\nchecks: []\n')
    try:
        load_config(no_checks_path)
        test('no checks raises ValueError', False)
    except ValueError as e:
        test('no checks raises ValueError', 'No checks' in str(e))

    # Check missing name
    bad_name_path = os.path.join(tmpdir, 'badname.yaml')
    write_file(bad_name_path, 'checks:\n  - type: process\n    match: x\n')
    try:
        load_config(bad_name_path)
        test('missing name raises ValueError', False)
    except ValueError as e:
        test('missing name raises ValueError', 'name' in str(e).lower())

    # Check missing type
    bad_type_path = os.path.join(tmpdir, 'badtype.yaml')
    write_file(bad_type_path, 'checks:\n  - name: foo\n')
    try:
        load_config(bad_type_path)
        test('missing type raises ValueError', False)
    except ValueError as e:
        test('missing type raises ValueError', 'type' in str(e).lower())

finally:
    shutil.rmtree(tmpdir)


# ============================================================
# find_config
# ============================================================
print('Testing find_config...')

tmpdir = make_temp_dir()
try:
    # No config file
    result = find_config(tmpdir)
    test('find_config returns None when missing', result is None)

    # watchdog.yaml exists
    write_file(os.path.join(tmpdir, 'watchdog.yaml'), 'checks: []')
    result = find_config(tmpdir)
    test('find_config finds watchdog.yaml', result is not None and result.endswith('watchdog.yaml'))

finally:
    shutil.rmtree(tmpdir)


# ============================================================
# Environment variable interpolation
# ============================================================
print('Testing env interpolation...')

os.environ['WDOG_TEST_VAR'] = 'hello_world'
result = _interpolate_env('url: ${WDOG_TEST_VAR}/api')
test('env var interpolated', result == 'url: hello_world/api')

result = _interpolate_env('url: ${WDOG_NONEXISTENT_VAR_12345}/api')
test('missing env var left as-is', '${WDOG_NONEXISTENT_VAR_12345}' in result)

result = _interpolate_env('no vars here')
test('no vars unchanged', result == 'no vars here')
del os.environ['WDOG_TEST_VAR']


# ============================================================
# Runner orchestration
# ============================================================
print('Testing runner...')

tmpdir = make_temp_dir()
try:
    from wdog.runner import run_checks
    import io
    from contextlib import redirect_stdout

    fresh_file = os.path.join(tmpdir, 'data.txt')
    write_file(fresh_file, 'content')

    config = {
        'project': 'test',
        'checks': [
            {'name': 'Proc check', 'type': 'process', 'match': 'launchd', 'platform': 'ps'},
            {'name': 'Fresh check', 'type': 'freshness', 'path': fresh_file, 'max_age': '1h'},
        ],
        '_config_dir': tmpdir,
    }

    # Run with terminal output (capture stdout)
    buf = io.StringIO()
    with redirect_stdout(buf):
        exit_code = run_checks(config, output_format='terminal')
    test('runner returns exit code 0 for healthy', exit_code == 0)

    # Run with JSON output
    buf = io.StringIO()
    with redirect_stdout(buf):
        exit_code = run_checks(config, output_format='json')
    output = buf.getvalue()
    test('runner JSON output is valid', 'results' in output)
    parsed = json.loads(output)
    test('runner JSON has summary', 'summary' in parsed)
    test('runner JSON has project', parsed.get('project') == 'test')

    # Runner with a failing check
    config_fail = {
        'project': 'test-fail',
        'checks': [
            {'name': 'Missing proc', 'type': 'process', 'match': 'zzz_nonexist_99999',
             'platform': 'ps', 'severity': 'critical'},
        ],
        '_config_dir': tmpdir,
    }
    buf = io.StringIO()
    with redirect_stdout(buf):
        exit_code = run_checks(config_fail, output_format='terminal')
    test('runner returns 2 for critical', exit_code == 2)

    # Runner with warning
    config_warn = {
        'project': 'test-warn',
        'checks': [
            {'name': 'Missing proc', 'type': 'process', 'match': 'zzz_nonexist_99999',
             'platform': 'ps', 'severity': 'warning'},
        ],
        '_config_dir': tmpdir,
    }
    buf = io.StringIO()
    with redirect_stdout(buf):
        exit_code = run_checks(config_warn, output_format='terminal')
    test('runner returns 1 for warning', exit_code == 1)

    # Runner handles broken check gracefully
    config_broken = {
        'project': 'test-broken',
        'checks': [
            {'name': 'Bad check', 'type': 'nonexistent_type_xyz'},
        ],
        '_config_dir': tmpdir,
    }
    buf = io.StringIO()
    with redirect_stdout(buf):
        exit_code = run_checks(config_broken, output_format='terminal')
    test('runner handles broken check', exit_code == 2)

finally:
    shutil.rmtree(tmpdir)


# ============================================================
# Summary
# ============================================================
print('\n{}/{} tests passed.'.format(passed, passed + failed))
if failed:
    sys.exit(1)
