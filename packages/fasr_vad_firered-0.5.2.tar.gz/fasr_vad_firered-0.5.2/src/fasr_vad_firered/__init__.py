from fasr_vad_firered.firered import FireRedForVAD

__all__ = ["FireRedForVAD"]
