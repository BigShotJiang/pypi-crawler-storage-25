from __future__ import annotations

from pathlib import Path
from typing import Any, List

from pydantic import ConfigDict, Field
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioSpan, AudioSpanList
from fasr.model import VADModel


def _get_input_waveform(audio: AudioSpan):
    if audio.waveform is None:
        raise ValueError("VAD input audio must carry `waveform`.")
    return audio.waveform


def _bind_segment_to_input(audio: AudioSpan, segment: AudioSpan) -> AudioSpan:
    if segment.start_ms is None or segment.end_ms is None:
        raise ValueError("Detected segment must carry both `start_ms` and `end_ms`.")
    relative_start_ms = int(round(segment.start_ms))
    relative_end_ms = int(round(segment.end_ms))
    cloned = segment.model_copy(deep=True)
    offset_ms = int(round(audio.start_ms or 0))
    cloned.start_ms = offset_ms + relative_start_ms
    cloned.end_ms = offset_ms + relative_end_ms
    cloned.waveform = _get_input_waveform(audio).select_by_ms(
        relative_start_ms,
        relative_end_ms,
    )
    return cloned


class FireRedForVAD(VADModel):
    """FireRedVAD non-streaming voice activity detection.

    The checkpoint directory must contain ``cmvn.ark`` and ``model.pth.tar``,
    matching ``FireRedVad.from_pretrained(model_dir)``.
    """

    checkpoint: str = "FireRedTeam/FireRedVAD"
    endpoint: str = "modelscope"

    firered: Any | None = Field(
        default=None,
        exclude=True,
        description="Underlying FireRedVad handle populated by `load_checkpoint`.",
    )
    use_gpu: bool = Field(
        default=False, description="Whether to run FireRedVAD inference on GPU."
    )
    speech_threshold: float = Field(
        default=0.4,
        ge=0.0,
        le=1.0,
        description="Posterior threshold above which a frame is treated as speech.",
    )

    model_config = ConfigDict(arbitrary_types_allowed=True, validate_assignment=True)

    def detect(self, audio: AudioSpan) -> List[AudioSpan]:
        if self.firered is None:
            raise RuntimeError(
                "Model is not initialized, call load_checkpoint() first."
            )
        waveform = _get_input_waveform(audio)
        wav = waveform.resample(16000) if waveform.sample_rate != 16000 else waveform
        pcm = wav.to_int16_pcm()
        audio_input = (pcm, 16000)
        result, _ = self.firered.detect(audio_input)
        segments = AudioSpanList()
        for start_s, end_s in result["timestamps"]:
            start_ms = int(round(start_s * 1000))
            end_ms = int(round(end_s * 1000))
            if end_ms > start_ms:
                seg = AudioSpan(start_ms=start_ms, end_ms=end_ms)
                segments.append(_bind_segment_to_input(audio, seg))
        return segments

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the FireRed VAD model from a local checkpoint directory.

        If the resolved directory contains a ``VAD`` subfolder (as packaged in
        the upstream ModelScope release), that subfolder is used.
        """
        from fireredvad.vad import FireRedVad, FireRedVadConfig

        if checkpoint_dir is None:
            if self.checkpoint is None:
                raise ValueError(
                    "Either `checkpoint_dir` or `self.checkpoint` must be set."
                )
            self.download_checkpoint()
            checkpoint_dir = self.checkpoint_dir
        checkpoint_dir = Path(checkpoint_dir)
        vad_dir = checkpoint_dir / "VAD"
        if vad_dir.is_dir():
            checkpoint_dir = vad_dir
        if not checkpoint_dir.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_dir}")
        config = FireRedVadConfig(
            use_gpu=self.use_gpu,
            speech_threshold=self.speech_threshold,
        )
        self.firered = FireRedVad.from_pretrained(str(checkpoint_dir), config=config)
        return self

    def get_config(self) -> Config:
        return Config(
            data={
                "vad_model": {
                    "@vad_models": "firered",
                    "checkpoint": self.checkpoint,
                    "endpoint": self.endpoint,
                    "use_gpu": self.use_gpu,
                    "speech_threshold": self.speech_threshold,
                }
            }
        )


@registry.vad_models.register("firered")
def firered_entrypoint(
    use_gpu: bool = False,
    speech_threshold: float = 0.4,
    **kwargs,
) -> FireRedForVAD:
    return FireRedForVAD(
        use_gpu=use_gpu,
        speech_threshold=speech_threshold,
        **kwargs,
    )
