# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def persona_list(
    intents: str | None = None,
    is_preset: bool = False,
    search: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> str:
    """
    List Personas

    Args:
        intents: Filter by intent(s): benign, curious, adversarial, malicious
        is_preset: Filter by preset status
        search: Search in name, description, and role
        limit: Maximum number of results (default 10)
        offset: Number of results to skip for paging
    """
    args: dict[str, Any] = {}
    args["intents"] = intents
    args["is_preset"] = is_preset
    args["search"] = search
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("persona", "list", args)

@server.tool()
def persona_create(
    name: str,
    role: str,
    id: str | None = None,
    description: str | None = None,
    role_description: str | None = None,
    knowledge_level: str | None = None,
    skill_level: str | None = None,
    intent: str | None = None,
    language: str | None = None,
    access_permissions: str | None = None,
    is_preset: bool = False,
    preset_category: str | None = None,
    tags: str | None = None,
    icon_filename: str | None = None,
) -> str:
    """
    Create Persona

    Args:
        name: Name
        role: Role
        id: Id
        description: Description
        role_description: Role Description
        knowledge_level: Knowledge level of the persona. (one of: beginner, intermediate, advanced, expert)
        skill_level: Skill level of the persona. (one of: novice, competent, proficient, expert)
        intent: Intent type of the persona. (one of: benign, curious, adversarial, malicious)
        language: Language
        access_permissions: Access Permissions (JSON object string)
        is_preset: Is Preset
        preset_category: Preset Category
        tags: Tags (JSON array string)
        icon_filename: Icon Filename
    """
    args: dict[str, Any] = {}
    args["name"] = name
    args["role"] = role
    args["id"] = id
    args["description"] = description
    args["role_description"] = role_description
    args["knowledge_level"] = knowledge_level
    args["skill_level"] = skill_level
    args["intent"] = intent
    args["language"] = language
    args["access_permissions"] = access_permissions
    args["is_preset"] = is_preset
    args["preset_category"] = preset_category
    args["tags"] = tags
    args["icon_filename"] = icon_filename
    return run_vijil("persona", "create", args)

@server.tool()
def persona_get(id: str) -> str:
    """
    Get Persona

    Args:
        id: The id
    """
    return run_vijil("persona", "get", {}, positional=[id])

@server.tool()
def persona_update(
    id: str,
    name: str | None = None,
    description: str | None = None,
    role: str | None = None,
    role_description: str | None = None,
    knowledge_level: str | None = None,
    skill_level: str | None = None,
    intent: str | None = None,
    language: str | None = None,
    access_permissions: str | None = None,
    is_preset: bool = False,
    preset_category: str | None = None,
    tags: str | None = None,
    icon_filename: str | None = None,
) -> str:
    """
    Update Persona

    Args:
        id: The id
        name: Name
        description: Description
        role: Role
        role_description: Role Description
        knowledge_level: Knowledge level of the persona. (one of: beginner, intermediate, advanced, expert)
        skill_level: Skill level of the persona. (one of: novice, competent, proficient, expert)
        intent: Intent type of the persona. (one of: benign, curious, adversarial, malicious)
        language: Language
        access_permissions: Access Permissions (JSON object string)
        is_preset: Is Preset
        preset_category: Preset Category
        tags: Tags (JSON array string)
        icon_filename: Icon Filename
    """
    args: dict[str, Any] = {}
    args["name"] = name
    args["description"] = description
    args["role"] = role
    args["role_description"] = role_description
    args["knowledge_level"] = knowledge_level
    args["skill_level"] = skill_level
    args["intent"] = intent
    args["language"] = language
    args["access_permissions"] = access_permissions
    args["is_preset"] = is_preset
    args["preset_category"] = preset_category
    args["tags"] = tags
    args["icon_filename"] = icon_filename
    return run_vijil("persona", "update", args, positional=[id])

@server.tool()
def persona_delete(id: str) -> str:
    """
    Delete Persona

    Args:
        id: The id
    """
    return run_vijil("persona", "delete", {}, positional=[id], skip_confirm=True)

@server.tool()
def persona_preset_list(preset_category: str | None = None, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Presets

    Args:
        preset_category: Filter by preset category: professional, adversarial, support
        limit: Maximum number of results
        offset: Number of results to skip
    """
    args: dict[str, Any] = {}
    args["preset_category"] = preset_category
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("persona", "preset-list", args)

@server.tool()
def persona_from_preset(preset_id: str) -> str:
    """
    Create From Preset

    Args:
        preset_id: The preset id
    """
    return run_vijil("persona", "from-preset", {}, positional=[preset_id])
