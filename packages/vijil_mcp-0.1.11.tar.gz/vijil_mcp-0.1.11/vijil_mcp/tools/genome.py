# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def genome_list() -> str:
    """GET /v1/genomes/"""
    return run_vijil("genome", "list", {})

@server.tool()
def genome_get(genome_id: str) -> str:
    """
    GET /v1/genomes/{genome_id}

    Args:
        genome_id: The genome id
    """
    return run_vijil("genome", "get", {}, positional=[genome_id])

@server.tool()
def genome_create() -> str:
    """POST /v1/genomes/"""
    return run_vijil("genome", "create", {})

@server.tool()
def genome_update(genome_id: str) -> str:
    """
    PUT /v1/genomes/{genome_id}

    Args:
        genome_id: The genome id
    """
    return run_vijil("genome", "update", {}, positional=[genome_id])

@server.tool()
def genome_extract(agent_id: str) -> str:
    """
    GET /v1/genomes/{agent_id}/extract

    Args:
        agent_id: The agent id
    """
    return run_vijil("genome", "extract", {}, positional=[agent_id])
