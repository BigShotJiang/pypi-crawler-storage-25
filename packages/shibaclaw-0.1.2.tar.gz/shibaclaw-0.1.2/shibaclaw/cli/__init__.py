"""CLI module for shibaclaw."""
