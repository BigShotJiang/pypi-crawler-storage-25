"""Local SQLite store for fail-safe trace persistence."""

from __future__ import annotations

import json
import os
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


def _default_db_path() -> str:
    """Return the default database path (~/.agenteval/traces.db)."""
    base = os.environ.get("AGENTEVAL_DATA_DIR") or str(Path.home() / ".agenteval")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "traces.db")


class LocalStore:
    """Thread-safe SQLite store for traces.

    Every trace logged via the SDK is persisted here *before* the network
    call so that data is never lost, even when the central endpoint is
    unreachable.
    """

    _DDL = """
    CREATE TABLE IF NOT EXISTS traces (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        trace_id    TEXT NOT NULL,
        agent_name  TEXT DEFAULT '',
        agent_input TEXT DEFAULT '',
        agent_output TEXT DEFAULT '',
        latency_ms  INTEGER DEFAULT 0,
        tokens_used INTEGER DEFAULT 0,
        test_status TEXT DEFAULT 'NEW',
        error_message TEXT DEFAULT '',
        project_id  TEXT DEFAULT 'default',
        synced      INTEGER DEFAULT 0,
        created_at  TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_traces_synced ON traces(synced);
    CREATE INDEX IF NOT EXISTS idx_traces_trace_id ON traces(trace_id);
    """

    def __init__(self, db_path: Optional[str] = None) -> None:
        self._db_path = db_path or _default_db_path()
        self._lock = threading.Lock()
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _ensure_schema(self) -> None:
        with self._lock:
            conn = self._connect()
            try:
                conn.executescript(self._DDL)
            finally:
                conn.close()

    def save(self, trace: Dict[str, Any]) -> int:
        """Persist a trace dict locally. Returns the rowid."""
        with self._lock:
            conn = self._connect()
            try:
                cur = conn.execute(
                    """INSERT INTO traces
                       (trace_id, agent_name, agent_input, agent_output,
                        latency_ms, tokens_used, test_status, error_message,
                        project_id, synced)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)""",
                    (
                        trace.get("trace_id", ""),
                        trace.get("agent_name", ""),
                        trace.get("agent_input", ""),
                        trace.get("agent_output", ""),
                        trace.get("latency_ms", 0),
                        trace.get("tokens_used", 0),
                        trace.get("test_status", "NEW"),
                        trace.get("error_message", ""),
                        trace.get("project_id", "default"),
                    ),
                )
                conn.commit()
                return cur.lastrowid  # type: ignore[return-value]
            finally:
                conn.close()

    def mark_synced(self, rowid: int) -> None:
        """Mark a trace as successfully synced to the central endpoint."""
        with self._lock:
            conn = self._connect()
            try:
                conn.execute("UPDATE traces SET synced = 1 WHERE id = ?", (rowid,))
                conn.commit()
            finally:
                conn.close()

    def get_unsynced(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Return up to *limit* traces that haven't been synced yet."""
        with self._lock:
            conn = self._connect()
            try:
                rows = conn.execute(
                    "SELECT * FROM traces WHERE synced = 0 ORDER BY id ASC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()

    def get_recent(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Return the most recent *limit* traces (synced or not)."""
        with self._lock:
            conn = self._connect()
            try:
                rows = conn.execute(
                    "SELECT * FROM traces ORDER BY id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()

    def count(self, synced_only: bool = False) -> int:
        """Return total trace count."""
        clause = "WHERE synced = 1" if synced_only else ""
        with self._lock:
            conn = self._connect()
            try:
                row = conn.execute(f"SELECT COUNT(*) FROM traces {clause}").fetchone()
                return row[0] if row else 0
            finally:
                conn.close()

    def clear(self) -> int:
        """Delete all traces. Returns number of rows deleted."""
        with self._lock:
            conn = self._connect()
            try:
                cur = conn.execute("DELETE FROM traces")
                conn.commit()
                return cur.rowcount
            finally:
                conn.close()

    @property
    def path(self) -> str:
        return self._db_path
