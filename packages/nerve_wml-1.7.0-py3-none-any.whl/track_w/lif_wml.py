"""LifWML — a WML whose core is a population of LIF neurons.

Dynamics: v_mem ← v_mem + (dt / tau) · (−v_mem + i_in), then spike = (v_mem > v_thr),
with reset. A pattern-match decoder compares spikes to the local codebook to
emit a code when confidence exceeds a threshold; otherwise the WML stays silent
(N-1).

step() and emission are implemented in Tasks 10 and 11.
"""
from __future__ import annotations

from collections.abc import Iterable

import torch
from torch import Tensor, nn

from nerve_core.protocols import Nerve


class LifWML(nn.Module):
    v_mem: Tensor

    def __init__(
        self,
        id:            int,
        n_neurons:     int   = 100,
        alphabet_size: int   = 64,
        v_thr:         float = 1.0,
        tau_mem:       float = 20e-3,
        threshold_eps: float = 0.30,
        input_dim:     int | None = None,
        *,
        seed:          int | None = None,
    ) -> None:
        super().__init__()
        self.id            = id
        self.n_neurons     = n_neurons
        self.alphabet_size = alphabet_size
        self.v_thr         = v_thr
        self.tau_mem       = tau_mem
        self.threshold_eps = threshold_eps
        # v1.2: decouple task-input dim from population size. When None,
        # fall back to n_neurons for backward compatibility with v1.1.
        self.input_dim = input_dim if input_dim is not None else n_neurons

        gen = torch.Generator()
        if seed is not None:
            gen.manual_seed(seed)

        # Codebook: each code is a spike pattern (binary-like target).
        init = (torch.rand(alphabet_size, n_neurons, generator=gen) > 0.7).float()
        self.codebook = nn.Parameter(init)

        # Membrane state — re-init per episode via `.reset_state()`.
        self.register_buffer("v_mem", torch.zeros(n_neurons))

        # Save global RNG, re-init input_proj + emit_head_pi from local
        # generator, restore. emit_head_pi is a learned linear readout over
        # the spike pattern; symmetric to MlpWML.emit_head_pi. Used by the
        # polymorphism benchmarks so the LIF readout is trainable end-to-end
        # rather than a fixed cosine match against the codebook.
        saved_rng = torch.get_rng_state()
        try:
            self.input_proj = nn.Linear(self.input_dim, n_neurons)
            with torch.no_grad():
                self.input_proj.weight.data = torch.randn(
                    n_neurons, self.input_dim, generator=gen
                ) * 0.1
                self.input_proj.bias.data.zero_()

            self.emit_head_pi = nn.Linear(n_neurons, alphabet_size)
            with torch.no_grad():
                self.emit_head_pi.weight.data = torch.randn(
                    alphabet_size, n_neurons, generator=gen
                ) * 0.1
                self.emit_head_pi.bias.data.zero_()
        finally:
            torch.set_rng_state(saved_rng)

    def reset_state(self) -> None:
        self.v_mem.zero_()

    def step(self, nerve: Nerve, t: float, dt: float = 1e-3) -> None:
        from nerve_core.neuroletter import Neuroletter, Phase, Role
        from track_w._decode import embed_inbound
        from track_w._surrogate import spike_with_surrogate

        inbound = nerve.listen(self.id)
        pooled = embed_inbound(inbound, self.codebook)     # [n_neurons]
        i_in   = self.input_proj(pooled)

        # LIF integration.
        self.v_mem = self.v_mem + dt / self.tau_mem * (-self.v_mem + i_in)
        spikes     = spike_with_surrogate(self.v_mem, v_thr=self.v_thr)
        self.v_mem = self.v_mem * (1 - spikes)

        spike_count = spikes.sum().item()
        has_spikes = spike_count > 0

        # Pattern-match decoder (only if spikes exist).
        best = 0
        conf = 0.0
        if has_spikes:
            norms = self.codebook.norm(dim=-1) + 1e-6
            sims  = (self.codebook @ spikes) / (norms * (spikes.norm() + 1e-6))
            best  = int(sims.argmax().item())
            conf  = float(sims[best].item())

        # π path — fires on confident match.
        if has_spikes and conf >= 0.3:
            for dst in range(nerve.n_wmls):  # type: ignore[attr-defined]
                if dst == self.id:
                    continue
                if nerve.routing_weight(self.id, dst) == 1.0:
                    nerve.send(Neuroletter(
                        code=best, role=Role.PREDICTION, phase=Phase.GAMMA,
                        src=self.id, dst=dst, timestamp=t,
                    ))

        # ε path — mismatch = |spike_rate − expected| / expected.
        expected_rate = 0.3 * self.n_neurons
        mismatch = abs(spike_count - expected_rate) / max(expected_rate, 1)
        if mismatch > self.threshold_eps:
            for dst in range(nerve.n_wmls):  # type: ignore[attr-defined]
                if dst == self.id:
                    continue
                if nerve.routing_weight(self.id, dst) == 1.0:
                    nerve.send(Neuroletter(
                        code=best, role=Role.ERROR, phase=Phase.THETA,
                        src=self.id, dst=dst, timestamp=t,
                    ))

    def parameters(self, *args, **kwargs) -> Iterable[Tensor]:  # type: ignore[override]
        return super().parameters(*args, **kwargs)
