"""WML configuration presets."""
