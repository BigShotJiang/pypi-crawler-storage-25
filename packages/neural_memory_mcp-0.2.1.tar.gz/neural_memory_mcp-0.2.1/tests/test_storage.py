"""Tests for neural_memory.storage — SQLite-backed graph persistence."""

import pytest

from neural_memory.models import NeuralNode, NeuralEdge, NodeType, EdgeType, IndexState, IndexMode
from neural_memory.storage import Storage


def _node(id="n1", name="my_func", node_type=NodeType.FUNCTION, file_path="foo.py",
          line_start=1, line_end=5, importance=0.0) -> NeuralNode:
    return NeuralNode(
        id=id, name=name, node_type=node_type, file_path=file_path,
        line_start=line_start, line_end=line_end, importance=importance,
    )


def _edge(source_id="n1", target_id="n2", edge_type=EdgeType.CALLS) -> NeuralEdge:
    return NeuralEdge(source_id=source_id, target_id=target_id, edge_type=edge_type)


# ── Open / close / context manager ─────────────────────────────────────────────

def test_open_close(tmp_path):
    s = Storage(str(tmp_path))
    s.open()
    assert s.conn is not None
    s.close()
    assert s.conn is None


def test_context_manager(tmp_path):
    with Storage(str(tmp_path)) as s:
        assert s.conn is not None
    assert s.conn is None


# ── Node CRUD ──────────────────────────────────────────────────────────────────

def test_upsert_and_get_node(storage):
    n = _node()
    storage.upsert_node(n)
    got = storage.get_node("n1")
    assert got is not None
    assert got.id == "n1"
    assert got.name == "my_func"
    assert got.node_type == NodeType.FUNCTION


def test_get_node_returns_none_for_missing(storage):
    assert storage.get_node("nonexistent") is None


def test_upsert_is_idempotent(storage):
    n = _node(name="original")
    storage.upsert_node(n)
    n2 = _node(name="updated")
    storage.upsert_node(n2)
    got = storage.get_node("n1")
    assert got.name == "updated"


def test_get_nodes_by_file(storage):
    storage.upsert_node(_node(id="n1", file_path="a.py"))
    storage.upsert_node(_node(id="n2", name="other", file_path="b.py"))
    result = storage.get_nodes_by_file("a.py")
    assert len(result) == 1
    assert result[0].id == "n1"


def test_get_nodes_by_type(storage):
    storage.upsert_node(_node(id="n1", node_type=NodeType.FUNCTION))
    storage.upsert_node(_node(id="n2", name="MyClass", node_type=NodeType.CLASS))
    funcs = storage.get_nodes_by_type(NodeType.FUNCTION)
    assert all(n.node_type == NodeType.FUNCTION for n in funcs)
    assert len(funcs) == 1


def test_delete_nodes_by_file_returns_count(storage):
    storage.upsert_node(_node(id="n1", file_path="a.py"))
    storage.upsert_node(_node(id="n2", name="n2", file_path="a.py"))
    storage.upsert_node(_node(id="n3", name="n3", file_path="b.py"))
    count = storage.delete_nodes_by_file("a.py")
    assert count == 2
    assert storage.get_node("n1") is None
    assert storage.get_node("n3") is not None


def test_get_all_node_ids(storage):
    storage.upsert_node(_node(id="n1"))
    storage.upsert_node(_node(id="n2", name="n2"))
    ids = storage.get_all_node_ids()
    assert set(ids) == {"n1", "n2"}


def test_get_all_nodes_returns_all(storage):
    storage.upsert_node(_node(id="n1"))
    storage.upsert_node(_node(id="n2", name="n2"))
    nodes = storage.get_all_nodes()
    assert {n.id for n in nodes} == {"n1", "n2"}


# ── Search ─────────────────────────────────────────────────────────────────────

def test_search_nodes_by_name(storage):
    storage.upsert_node(_node(id="n1", name="parse_file"))
    storage.upsert_node(_node(id="n2", name="resolve_edges"))
    results = storage.search_nodes("parse")
    assert any(n.id == "n1" for n in results)
    assert all(n.id != "n2" or "resolve" in n.name for n in results)


def test_search_nodes_no_results(storage):
    storage.upsert_node(_node(id="n1", name="my_func"))
    results = storage.search_nodes("xyz_not_found")
    assert results == []


def test_search_nodes_respects_limit(storage):
    for i in range(10):
        storage.upsert_node(_node(id=f"n{i}", name=f"func_{i}"))
    results = storage.search_nodes("func", limit=3)
    assert len(results) <= 3


def test_search_nodes_ordered_by_importance(storage):
    storage.upsert_node(_node(id="n1", name="func_low", importance=0.1))
    storage.upsert_node(_node(id="n2", name="func_high", importance=0.9))
    results = storage.search_nodes("func", limit=10)
    importances = [n.importance for n in results]
    assert importances == sorted(importances, reverse=True)


# ── Edge operations ─────────────────────────────────────────────────────────────

def test_upsert_and_get_edges_from(storage):
    storage.upsert_node(_node(id="n1"))
    storage.upsert_node(_node(id="n2", name="n2"))
    storage.upsert_edge(_edge("n1", "n2", EdgeType.CALLS))
    edges = storage.get_edges_from("n1")
    assert len(edges) == 1
    assert edges[0].target_id == "n2"
    assert edges[0].edge_type == EdgeType.CALLS


def test_upsert_and_get_edges_to(storage):
    storage.upsert_node(_node(id="n1"))
    storage.upsert_node(_node(id="n2", name="n2"))
    storage.upsert_edge(_edge("n1", "n2", EdgeType.CALLS))
    edges = storage.get_edges_to("n2")
    assert len(edges) == 1
    assert edges[0].source_id == "n1"


def test_edge_upsert_no_duplicates(storage):
    storage.upsert_node(_node(id="n1"))
    storage.upsert_node(_node(id="n2", name="n2"))
    storage.upsert_edge(_edge("n1", "n2", EdgeType.CALLS))
    storage.upsert_edge(_edge("n1", "n2", EdgeType.CALLS))
    edges = storage.get_edges_from("n1")
    assert len(edges) == 1


def test_delete_edges_for_node(storage):
    storage.upsert_node(_node(id="n1"))
    storage.upsert_node(_node(id="n2", name="n2"))
    storage.upsert_edge(_edge("n1", "n2"))
    storage.delete_edges_for_node("n1")
    assert storage.get_edges_from("n1") == []
    assert storage.get_edges_to("n2") == []


def test_delete_edges_by_file(storage):
    storage.upsert_node(_node(id="n1", file_path="a.py"))
    storage.upsert_node(_node(id="n2", name="n2", file_path="b.py"))
    storage.upsert_edge(_edge("n1", "n2"))
    storage.delete_edges_by_file("a.py")
    assert storage.get_edges_from("n1") == []


# ── Index state ────────────────────────────────────────────────────────────────

def test_get_index_state_returns_default(storage):
    state = storage.get_index_state()
    assert isinstance(state, IndexState)
    assert state.total_nodes == 0


def test_save_and_get_index_state(storage):
    state = IndexState(total_nodes=42, total_edges=100, index_mode=IndexMode.AST_ONLY)
    storage.save_index_state(state)
    got = storage.get_index_state()
    assert got.total_nodes == 42
    assert got.total_edges == 100
    assert got.index_mode == IndexMode.AST_ONLY


# ── File hashes ────────────────────────────────────────────────────────────────

def test_save_and_get_file_hash(storage):
    storage.save_file_hash("foo.py", "abc123", "2026-01-01T00:00:00Z")
    got = storage.get_file_hash("foo.py")
    assert got == "abc123"


def test_get_file_hash_missing(storage):
    assert storage.get_file_hash("missing.py") is None


def test_get_all_indexed_files(storage):
    storage.save_file_hash("a.py", "hash1", "2026-01-01T00:00:00Z")
    storage.save_file_hash("b.py", "hash2", "2026-01-01T00:00:00Z")
    files = storage.get_all_indexed_files()
    assert files == {"a.py": "hash1", "b.py": "hash2"}


def test_delete_file_hash(storage):
    storage.save_file_hash("a.py", "h1", "2026-01-01T00:00:00Z")
    storage.delete_file_hash("a.py")
    assert storage.get_file_hash("a.py") is None


# ── Stats ──────────────────────────────────────────────────────────────────────

def test_get_stats_accuracy(storage):
    storage.upsert_node(_node(id="n1", file_path="a.py", node_type=NodeType.FUNCTION))
    storage.upsert_node(_node(id="n2", name="n2", file_path="a.py", node_type=NodeType.CLASS))
    storage.upsert_node(_node(id="n3", name="n3", file_path="b.py", node_type=NodeType.FUNCTION))
    storage.upsert_edge(_edge("n1", "n2"))

    stats = storage.get_stats()
    assert stats["total_nodes"] == 3
    assert stats["total_edges"] == 1
    assert stats["total_files"] == 2
    assert stats["nodes_by_type"]["function"] == 2
    assert stats["nodes_by_type"]["class"] == 1
