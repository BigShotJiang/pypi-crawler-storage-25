# Final Next-Step Recommendation

Date: 2026-03-13

## Answers

1. Is there one worthwhile next optimization target left?
- No clearly justified **low-risk** single target emerged from this pass.

2. If yes, what is it exactly?
- N/A in this pass.

3. If no, is the practical ceiling likely reached for current architecture on M1 Max?
- Yes, for the current dense V2-centered architecture, the repo appears close to its practical ceiling without larger runtime execution-model changes.

## Evidence Summary
- Dense decode/prefill are no longer dominated purely by kernel compute.
- Remaining cost is spread across:
  - orchestration/context overhead (`context_*` wrappers),
  - forced materialization boundaries,
  - path-specific maintenance (paged cache updates, Sage quantized-cache upkeep).
- Paged maintenance remains expensive but paged is broadly non-winning vs dense.
- Sage prefill matrix showed no clear auto-promotion regime (`0 wins / 21 neutral / 3 dense wins`).

## Practical Guidance
- Keep current production policy stable:
  - dense V2 as default,
  - paged/Sage advanced paths narrowly scoped,
  - Sage prefill explicit-only.
- Only revisit optimization if willing to take a larger runtime execution-model effort (beyond low-risk local patches).
