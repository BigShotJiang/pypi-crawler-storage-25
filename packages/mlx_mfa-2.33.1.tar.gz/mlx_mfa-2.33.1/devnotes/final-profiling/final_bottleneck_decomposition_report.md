# Final Bottleneck Decomposition Report (v2.9.2)

Date: 2026-03-13  
Inputs:
- `notes/runtime_profile_decode_latest.json`
- `notes/runtime_profile_prefill_latest.json`
- `notes/sage_prefill_matrix_latest.json`

Profiling mode:
- `MFA_PROFILE_RUNTIME=1`
- `MFA_PROFILE_RUNTIME_FORCE_EVAL=1`
- decode/prefill matrices run in separate processes

## 1) Top 3 Non-Kernel Contributors

### Dense decode (`dense_decode_runtime`)
1. `other_pct` ≈ 49.18%
2. `forced_materialization_pct` ≈ 28.91%
3. `cache_update_pct` ≈ 6.59%

### Dense prefill (`dense_prefill_runtime`)
1. `other_pct` ≈ 51.48%
2. `forced_materialization_pct` ≈ 36.20%
3. `cache_update_pct` ≈ 5.83%

### Paged decode (`paged_decode_runtime`)
1. `other_pct` ≈ 39.58%
2. `cache_update_pct` ≈ 33.22%
3. `forced_materialization_pct` ≈ 14.91%

### Paged prefill (`paged_prefill_runtime`)
1. `cache_update_pct` ≈ 40.67%
2. `other_pct` ≈ 38.23%
3. `forced_materialization_pct` ≈ 17.26%

### Sage decode (`sage_decode_runtime`)
1. `other_pct` ≈ 53.62%
2. `forced_materialization_pct` ≈ 33.76%
3. `quantized_cache_maintenance_pct` ≈ 7.87%

### Sage prefill (`sage_prefill_runtime`)
1. `other_pct` ≈ 54.15%
2. `forced_materialization_pct` ≈ 32.71%
3. `quantized_cache_maintenance_pct` ≈ 7.44%

## 2) What “other” Mostly Contains (stage-level decomposition)

The largest unclassified stages are runtime/context orchestration wrappers:
- dense decode: `context_prefill`, `context_step`, `context_build`
- dense prefill: `context_prefill`, `context_build`
- paged decode/prefill: `context_prefill` + `context_step` + `context_build`
- sage decode/prefill: `context_prefill` + `context_step` + `context_build`

Interpretation: the remaining non-kernel cost is spread across orchestration + graph/materialization boundaries, not one isolated pure compute operation.

## 3) Unavoidable vs Optimizable vs Not Worth It

### Structurally unavoidable (for current API/MLX execution model)
- Per-call materialization boundaries (`forced_materialization`) in decode/prefill workflows.
- Some context orchestration overhead (`context_*`) due stateful runtime layering.

### Probably optimizable
- Paged cache/page maintenance (`paged_cache_append`/`cache_update`) is large and consistent.
- Quantized-cache maintenance in Sage paths (~7–8%) can still be tuned.

### Probably not worth optimizing on M1 Max (for production default)
- Paged path dominates non-kernel cost but remains broadly slower than dense; broad investment has weak ROI unless paged becomes the primary serving mode.

## 4) One Final Candidate Target?

The data does **not** show one dominant low-risk non-kernel target that clearly beats alternatives for the production-default dense path.

The strongest technical signal is:
- dense/prefill materialization + orchestration overhead remains large,
- but reducing it likely requires runtime execution-model changes (not a small local patch).

## 5) Decision for Optional Final Optimization (Task 5)

No single low-risk optimization was implemented in this pass.

Reason:
- remaining overhead is diffuse between orchestration and materialization,
- the high-impact paged bottleneck is outside the default production path and still broadly losing.
