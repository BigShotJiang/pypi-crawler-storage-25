# Sage Prefill Decision Pass

Date: 2026-03-13  
Benchmark source: `notes/sage_prefill_matrix_latest.json`

## Matrix
- `D in {64, 128}`
- `N_prefill in {1024, 4096, 8192}`
- causal prefill
- profiles:
  - `realistic_gqa_b2_hq8_hkv4`
  - `under_occupied_b1_hq1_hkv1`
- dtype: `f16` + `bf16` (when supported)
- compared:
  - dense V2 context prefill
  - Sage context prefill
  - SDPA reference

## Result
- `sage_win`: 0
- `neutral`: 21
- `dense_win`: 3

Observed behavior:
- mostly near parity,
- several regressions (especially some bf16/under-occupied cases),
- no stable narrow region with repeated clear Sage-prefill dominance.

## Decision

`Option B — explicit non-promotion`

Sage prefill remains **explicit-only**.  
No auto-promotion policy is added in this pass.

Rationale:
- signal is not strong/consistent enough for production auto-routing,
- decode path remains the primary differentiated Sage value proposition,
- prefill auto-routing would increase policy complexity without robust benchmark backing.
