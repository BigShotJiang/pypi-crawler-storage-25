# End-to-End Runtime Bottleneck Report (v2.9.2)

Date: 2026-03-13  
Inputs:
- `notes/runtime_profile_decode_latest.json`
- `notes/runtime_profile_prefill_latest.json`
- Profiling mode: `MFA_PROFILE_RUNTIME=1`, `MFA_PROFILE_RUNTIME_FORCE_EVAL=1`
- Process model: decode and prefill matrices each run in separate processes

## Scope
This pass measured stage-level runtime cost around real decode/prefill flows:
- Scenario A: short decode (`N_q=1`)
- Scenario B: microbatch decode (`N_q in {2,4,8}`)
- Scenario C: prefill (`N in {1024,4096,8192}`)
- Scenario D: advanced flows (shared-prefix, splitfuse, rope append)

All scenarios used causal attention with `D in {64,128}`, plus realistic GQA and under-occupied head shapes.

## Aggregate Results
| Scenario | Path | Mean wall (ms) | Mean ratio vs dense | Kernel % | Cache update % | Runtime select % | Paged/shared bookkeeping % | RoPE prep % | Other % |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| A short decode | dense | 20.342 | 1.000 | 48.82 | 5.99 | 3.17 | 0.00 | 0.00 | 43.35 |
| A short decode | paged | 30.253 | 1.543 | 23.76 | 35.65 | 2.76 | 0.27 | 0.00 | 37.56 |
| A short decode | sage | 20.284 | 1.189 | 38.58 | 8.55 | 3.06 | 0.00 | 0.00 | 49.81 |
| B microbatch decode | dense | 17.293 | 1.000 | 44.57 | 7.33 | 3.18 | 0.00 | 0.00 | 44.93 |
| B microbatch decode | paged | 31.353 | 1.703 | 25.05 | 33.33 | 2.81 | 0.29 | 0.00 | 38.53 |
| B microbatch decode | sage | 16.910 | 1.094 | 40.14 | 8.52 | 3.41 | 0.00 | 0.00 | 47.93 |
| C prefill | dense | 12.301 | 1.000 | 42.56 | 6.56 | 5.52 | 0.00 | 0.00 | 45.37 |
| C prefill | paged | 26.544 | 1.940 | 18.81 | 45.12 | 3.48 | 0.00 | 0.00 | 32.60 |
| C prefill | sage | 11.324 | 0.918 | 38.43 | 7.17 | 6.53 | 0.00 | 0.00 | 47.86 |
| D advanced | shared-prefix runtime | 13.432 | n/a | 40.70 | 0.00 | 4.85 | 0.08 | 0.00 | 54.37 |
| D advanced | splitfuse runtime | 6.845 | n/a | 33.69 | 0.00 | 7.86 | 0.00 | 0.00 | 58.44 |
| D advanced | dense kvcache rope append | 4.351 | n/a | 11.97 | 10.62 | 0.00 | 0.00 | 20.73 | 56.68 |

## Win/Loss Classification vs Dense
Decode:
- `paged_decode_runtime`: 15 wins / 8 neutral / 81 losses (104 total)
- `sage_decode_runtime`: 31 wins / 12 neutral / 41 losses (84 total)

Prefill:
- `paged_prefill_runtime`: 4 wins / 0 neutral / 20 losses (24 total)
- `sage_prefill_runtime`: 13 wins / 4 neutral / 7 losses (24 total)

## Key Bottleneck Findings
1. Dense runtime is split between kernel and non-kernel cost, not kernel-only.
- Dense decode/prefill kernel share is ~43–49%.
- A similarly large ~43–45% remains in `other` (unattributed orchestration/materialization/path glue).

2. Paged path overhead is dominated by non-kernel work.
- Cache/page maintenance is ~33–45% of wall time.
- Kernel share is only ~19–25%.
- This explains why paged is often slower outside narrow regimes.

3. Sage decode remains mixed and narrow.
- It has meaningful wins in some decode cases, but still loses in many others.
- Average decode ratio is still >1.0 vs dense in this matrix.

4. RoPE prep is measurable when explicitly exercised.
- In the rope append scenario, RoPE prep is ~20.7% of wall time.

## Bottleneck Diagnosis
The remaining cost is **not purely dense kernel time**.  
For production-default dense flows, the biggest unresolved share outside the kernel is runtime-side orchestration/materialization (`other` bucket), with kernel and non-kernel cost now in the same order of magnitude.

For paged flows specifically, cache/page update and history handling dominates over kernel execution.

## Single Next Optimization Target (Recommended)
Prioritize **dense decode runtime-side orchestration reduction** before new kernel redesign:
- reduce per-step non-kernel `other` overhead in the dense decode loop,
- keep paged auto-routing narrow (given high cache/bookkeeping tax),
- treat paged optimizations as a separate serving-focused follow-up.

This is the highest-ROI next step consistent with the data from this pass.
