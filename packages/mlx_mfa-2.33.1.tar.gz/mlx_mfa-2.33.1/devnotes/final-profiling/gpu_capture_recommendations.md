# GPU Capture Recommendations (Manual Xcode/Metal)

Date: 2026-03-13  
Purpose: targeted manual capture after end-to-end profiling pass.

## 1) Clear Winning Scenario
- Shape: `B=1, H_q=8, H_kv=4, D=64, N_q=1, N_cache=2048`
- Dtype: `float16`
- Runtime/backend path: `sage_decode_runtime` (Scenario A short decode)
- Why interesting:
  - Best realistic f16 Sage decode win observed (`ratio_vs_dense ~= 0.47`).
  - Good candidate to verify where Sage saves time (kernel vs surrounding overhead).

## 2) Neutral Scenario
- Shape: `B=1, H_q=8, H_kv=4, D=64, N_q=4, N_cache=4096`
- Dtype: `float16`
- Runtime/backend path: `sage_decode_runtime` (Scenario B microbatch decode)
- Why interesting:
  - Near parity (`ratio_vs_dense ~= 1.00`).
  - Useful to inspect whether overhead and kernel balance cancel each other.

## 3) Disappointing Scenario
- Shape: `B=1, H_q=8, H_kv=4, D=128, N_q=8, N_cache=1024`
- Dtype: `float16`
- Runtime/backend path: `paged_decode_runtime` (Scenario B microbatch decode)
- Why interesting:
  - Worst realistic f16 paged decode regression observed (`ratio_vs_dense ~= 4.50`).
  - Profiling indicates large non-kernel share (cache/page bookkeeping + other orchestration), making it ideal for root-cause capture.

## Capture Notes
- Run each scenario in its own process with warm cache and fixed seed.
- Keep `MFA_PROFILE_RUNTIME=1` and `MFA_PROFILE_RUNTIME_FORCE_EVAL=1` enabled for correlation with stage logs.
- Collect one capture per scenario with identical shapes to keep comparisons clean.
