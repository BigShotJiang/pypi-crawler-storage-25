# Benchmark Archive

This directory stores historical benchmark artifacts that are no longer used as
current production-policy inputs.

## Archived set: `benchmarks_v2.0.0/`

Contains older benchmark JSON snapshots retained for historical reference only.
Do not treat these files as current decision evidence.
