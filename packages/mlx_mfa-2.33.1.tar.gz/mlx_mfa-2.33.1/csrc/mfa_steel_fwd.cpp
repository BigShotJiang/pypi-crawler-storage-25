/// mfa_steel_fwd.cpp — STEEL-style cooperative forward attention kernel generator.
///
/// Generates a self-contained Metal shader source with:
///  - BlockLoaderT: all threads cooperate to load one tile from device → threadgroup
///  - MMATile / BaseMMAFrag / tile_matmad: simdgroup matrix wrappers
///  - mlx_mfa_attention kernel: Q@K^T, softmax, P@V, writes O + L (logsumexp)
///
/// The generated source has NO #include directives; all templates are inlined.
/// Tile sizes are injected via #define substitution at generation time.

#include "mfa_steel_fwd.hpp"
#include "mfa_steel_fwd_v2.hpp"  // select_steel_v2_block_config for D=64/128 flash decode
#include <sstream>

namespace mlx_mfa {

// ---------------------------------------------------------------------------
// Tile config selection
// ---------------------------------------------------------------------------

SteelBlockConfig select_steel_block_config(int head_dim, bool is_low_prec,
                                           bool is_m3_plus) {
  // STEEL tile config rules:
  //   TQ = BQ / (WM * 8)  must be >= 1  →  BQ >= WM * 8
  //   TGP_SIZE = WM * WN * 32
  //
  // f16/bf16 (low_prec=true): can use larger tiles (smaller register footprint).
  // f32 (low_prec=false): must use smaller tiles to avoid register spill pushing
  //   threadgroup memory over the 32 KB Metal limit.
  if (!is_low_prec) {
    // f32: small tiles to control threadgroup memory incl. spill space.
    // BQ=16, WM=2 → TQ=1, TGP_SIZE=64.
    if (head_dim <= 128) {
      return {16, 16, head_dim, 2, 1, 4};
    } else {
      return {16, 16, head_dim, 2, 1, 4};
    }
  }
  // f16 / bf16 ─────────────────────────────────────────────────────────────
  //
  // M1/M2 (is_m3_plus=false):
  //   D=64  → BQ=32, BK=32, WM=4 (TGP=~22KB)
  //   D=128 → BQ=32, BK=16, WM=4 (TGP=~22KB)  BK=32 tested: 0.71x SDPA (worse)
  //   D=256 → BQ=32, BK=16, WM=4 (TGP=29184B < 32KB)
  //
  // M3/M4 (is_m3_plus=true) — dynamic register allocation avoids peak spill:
  //   D=64  → same as M1/M2 (already optimal at BK=32)
  //   D=128 → BQ=32, BK=32, WM=4 (TGP=29696B < 32KB) — wider K tile, try larger
  //   D=256 → same tile sizes; STEEL_PRAGMA_UNROLL enabled in shader gen
  //
  // Note: BQ=64 BK=32 D=128 = 41984B → exceeds 32 KB limit, rejected.
  if (head_dim <= 64) {
    // D=64: BK=32 optimal on all gens
    return {32, 32, head_dim, 4, 1, 8};
  }
  if (head_dim <= 128) {
    int BK = (is_m3_plus) ? 32 : 16;
    // M3+: BK=32 → TGP=29696B < 32KB, fewer K-iterations (may improve pipeline)
    // M1/M2: BK=16 → tested; BK=32 gives 0.71x SDPA on M1 (register spill)
    return {32, BK, head_dim, 4, 1, 8};
  } else if (head_dim <= 256) {
    // D=256: same tile sizes on all gens; M3+ enables unroll in shader source
    return {32, 16, head_dim, 4, 1, 8};
  } else {
    // D=512: D-split (BD_HALF=128, D_SPLITS=4); same block sizes — TGP fits 32KB with split
    return {32, 16, head_dim, 4, 1, 8};
  }
}

// ---------------------------------------------------------------------------
// Metal source generator
// ---------------------------------------------------------------------------

std::string generate_steel_forward_source(const ShaderCache::KernelKey& key) {
  const int BD = key.head_dim;
  const int BQ = key.block_q;
  const int BK = key.block_k;
  const int WM = key.n_warps;  // n_warps = BQ/8; for BQ=32,WM=4; BQ=16,WM=2
  const int WN = 1;
  const bool causal = key.causal;
  const bool sparse = key.sparse;
  const bool is_m3_plus        = key.is_m3_plus;
  const bool has_rope          = key.has_rope;
  const bool rope_interleaved  = key.rope_interleaved; // true=LLaMA, false=GPT-NeoX
  const bool has_alibi         = key.has_alibi;
  const bool has_window        = key.has_window;
  // Double-buffer: separate K_smem / V_smem so V-load can overlap K-GEMM
  // and K[n+1]-load can overlap P@V. Only valid when TGP budget allows:
  //   2*kv_s + Q_smem < 32KB → only D≤128. Also excluded: RoPE (modifies K_smem
  //   before GEMM, requires extra barrier ordering), sparse (continue skips loads).
  const bool double_buf = (BD <= 128 && !has_rope && !sparse);

  // D-split: D=512 exceeds 32KB TGP with full-width Q/KV smem.
  // Process head_dim in D_SPLITS chunks of BD_HALF=128; Q/O arrays in registers.
  // For BD<=256: d_split=false, BD_HALF=BD, D_SPLITS=1 — path unchanged.
  const bool d_split  = (BD > 256);
  const int  BD_HALF  = d_split ? 128 : BD;
  const int  D_SPLITS = BD / BD_HALF;
  const int  TD_HALF  = BD_HALF / 8;

  // dtype string for Metal
  const char* dtype_str = "half";
  if (key.dtype == 1)      dtype_str = "bfloat";
  else if (key.dtype == 2) dtype_str = "float";

  // Architecture gen constant for conditional Metal code (13=M1,14=M2,15=M3,16=M4)
  const int arch_gen = is_m3_plus ? 15 : 13;

  std::ostringstream ss;

  // ── Preamble ────────────────────────────────────────────────────────────
  // STEEL_PRAGMA_UNROLL:
  //   D<=128 (TD=8/16): full unroll on all gens — loop is short (8 or 16 iters).
  //   D=256 (TD=32):
  //     M1/M2: any unroll hint causes register spill or Metal AIR code bloat → empty.
  //     M3/M4: dynamic register allocation handles peak pressure → full unroll.
  ss << R"MFA(
#include <metal_stdlib>
#include <metal_simdgroup>
#include <metal_simdgroup_matrix>
using namespace metal;

#define STEEL_CONST static constant constexpr const
)MFA";
  // ARCHITECTURE_GEN: injected as a compile-time constant for Metal shader code.
  ss << "#define ARCHITECTURE_GEN " << arch_gen << "\n";
  ss << "#define STEEL_PRAGMA_UNROLL";
  bool enable_unroll = (key.head_dim <= 128) || is_m3_plus;
  if (enable_unroll) ss << R"MFA( _Pragma("clang loop unroll(full)")
)MFA";
  else ss << "\n";
  ss << "\n";

  // ── MFASteelParams struct ────────────────────────────────────────────────
  ss << R"MFA(
struct MFASteelParams {
  int B, H, D;
  int qL, kL;
  int gqa_factor;
  float scale;
  int NQ, NK;
  int NQ_aligned;
  int NK_aligned;
  int qL_rem;
  int kL_rem;
  int qL_off;
  // RoPE fusion params (present in all variants; unused when has_rope=false)
  int rope_q_base;
  int rope_cos_stride;
  long Q_strides[3];
  long K_strides[3];
  long V_strides[3];
  long O_strides[3];
  long L_strides[2];
  // Optional features (appended for backward compat; defaults 0.0f / 0)
  float softcap;    // 0.0 = disabled; >0 = tanh(S/cap)*cap before softmax
  int   has_alibi;  // 0 = disabled; 1 = ALiBi bias from buffer(9)
  int   window_left;  // -1 = disabled; >=0 = sliding window left radius (tokens)
  int   window_right; // -1 = disabled; >=0 = sliding window right radius (tokens)
  // Block-sparse mask strides: 0 = broadcast this dimension.
  // 2D [NQ,NK]: both 0; 3D [H,NQ,NK]: batch=0; 4D [B,H,NQ,NK]: both set.
  long  mask_batch_stride;
  long  mask_head_stride;
  int   has_attn_bias;      // 0 = disabled; 1 = additive bias from buffer(10)
  int   attn_bias_mode;     // 0=[B,H,Nq,Nkv], 1=[1,1,1,Nkv], 2=[1,H,1,Nkv]
  int   attn_bias_nkv;      // N_kv for bias stride computation
};

)MFA";

  // ── BlockLoaderT template ────────────────────────────────────────────────
  ss << R"MFA(
template <
    typename T,
    short BROWS,
    short BCOLS,
    short kDstStrRow,
    short kDstStrCol,
    short reduction_dim,
    short tgp_size,
    short n_reads = (BCOLS * BROWS) / tgp_size,
    short TCOLS = BCOLS / n_reads,
    short TROWS = tgp_size / TCOLS>
struct MFABlockLoaderT {
  STEEL_CONST short vec_size = n_reads;

  const int src_ld;
  const int tile_stride;
  const short thread_idx;
  const short bi;
  const short bj;

  threadgroup T* dst;
  const device T* src;

  METAL_FUNC MFABlockLoaderT(
      const device T* src_,
      const int src_ld_,
      threadgroup T* dst_,
      ushort simd_group_id,
      ushort simd_lane_id)
      : src_ld(src_ld_),
        tile_stride(reduction_dim ? BCOLS : BROWS * src_ld_),
        thread_idx(simd_group_id * 32 + simd_lane_id),
        bi(thread_idx / TCOLS),
        bj(vec_size * (thread_idx % TCOLS)),
        dst(dst_ + bi * kDstStrRow + bj * kDstStrCol),
        src(src_ + bi * src_ld_ + bj) {}

  METAL_FUNC void load_unsafe() const {
    // Vectorize for row-major loaders (kDstStrCol==1) when vec_size is a
    // multiple of 4 — 4× f16 = 8 bytes = one 64-bit coalesced transaction.
    // The K loader has kDstStrCol=BK+pad > 1 (transposed layout) and is
    // excluded at compile time by can_vectorize = false.
    constexpr bool can_vectorize = (kDstStrCol == 1) && (vec_size % 4 == 0);
    if constexpr (can_vectorize) {
      using vec4_t = vec<T, 4>;
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j += 4) {
          *(threadgroup vec4_t*)(dst + i * kDstStrRow + j) =
              *(const device vec4_t*)(src + i * src_ld + j);
        }
      }
    } else {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j++) {
          dst[i * kDstStrRow + j * kDstStrCol] = src[i * src_ld + j];
        }
      }
    }
  }

  METAL_FUNC void load_safe(short2 src_tile_dim) const {
    src_tile_dim = src_tile_dim - short2(bj, bi);
    if (src_tile_dim.x <= 0 || src_tile_dim.y <= 0) {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j++) {
          dst[i * kDstStrRow + j * kDstStrCol] = T(0);
        }
      }
      return;
    }
    bool tmp_idx[vec_size];
    T tmp_val[vec_size];
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_idx[j] = (i < src_tile_dim.y) && (j < src_tile_dim.x);
      }
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_val[j] = src[(tmp_idx[j] ? i * src_ld + j : 0)];
      }
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_val[j] = tmp_idx[j] ? tmp_val[j] : T(0);
      }
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        dst[i * kDstStrRow + j * kDstStrCol] = tmp_val[j];
      }
    }
  }

  METAL_FUNC void next() { src += tile_stride; }
};

)MFA";

  // ── BaseMMAFrag / MMATile / tile_matmad ─────────────────────────────────
  ss << R"MFA(
template <typename T>
struct MFAMMAFrag {
  STEEL_CONST int kFragRows = 8;
  STEEL_CONST int kFragCols = 8;
  STEEL_CONST int kElemsPerFrag = 2;  // (8*8)/32
  STEEL_CONST int kElemRows = 1;
  STEEL_CONST int kElemCols = 2;

  typedef simdgroup_matrix<T, 8, 8> mat_type;
  typedef vec<T, 2> frag_type;
  typedef vec<T, 1> row_frag_type;

  METAL_FUNC static short2 get_coord(ushort lane_id) {
    const short qid = lane_id / 4;
    const short fm  = (qid & 4) + ((lane_id / 2) % 4);
    const short fn  = (qid & 2) * 2 + (lane_id % 2) * 2;
    return short2{fn, fm};
  }

  template <typename SrcPtr, typename StrX, typename StrY>
  METAL_FUNC static void load(thread frag_type& dst,
                              SrcPtr src, StrX str_x, StrY str_y) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kElemRows; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kElemCols; j++) {
        dst[i * kElemCols + j] = static_cast<T>(src[i * str_x + j * str_y]);
      }
    }
  }

  template <typename Op>
  METAL_FUNC static void row_reduce(thread const frag_type& inp,
                                    thread T* out) {
    T thr = Op::apply(inp.x, inp.y);
    T qr  = Op::apply(thr, simd_shuffle_xor(thr, ushort(1)));
    T sr  = Op::apply(qr,  simd_shuffle_xor(qr,  ushort(8)));
    out[0] = Op::apply(out[0], sr);
  }

  template <typename Op>
  METAL_FUNC static void row_bin_op(thread frag_type& inp,
                                    thread T* row_vals) {
    STEEL_PRAGMA_UNROLL
    for (short j = 0; j < kElemCols; j++) {
      inp[j] = Op::apply(inp[j], row_vals[0]);
    }
  }

  METAL_FUNC static void mma(thread frag_type& D,
                             thread frag_type& A,
                             thread frag_type& B,
                             thread frag_type& C) {
    mat_type Dm, Am, Bm, Cm;
    reinterpret_cast<thread frag_type&>(Am.thread_elements()) = A;
    reinterpret_cast<thread frag_type&>(Bm.thread_elements()) = B;
    reinterpret_cast<thread frag_type&>(Cm.thread_elements()) = C;
    simdgroup_multiply_accumulate(Dm, Am, Bm, Cm);
    D = reinterpret_cast<thread frag_type&>(Dm.thread_elements());
  }
};

template <typename T, int kTileRows_, int kTileCols_>
struct MFAMMATile {
  using Frag = MFAMMAFrag<T>;
  STEEL_CONST int kFragRows    = 8;
  STEEL_CONST int kFragCols    = 8;
  STEEL_CONST int kElemsPerFrag = 2;
  STEEL_CONST int kTileRows    = kTileRows_;
  STEEL_CONST int kTileCols    = kTileCols_;
  STEEL_CONST int kNumFrags    = kTileRows_ * kTileCols_;
  STEEL_CONST int kElemsPerTile = kNumFrags * 2;
  STEEL_CONST int kRowsPerThread = kTileRows_;  // kElemRows=1 per frag

  typedef typename Frag::frag_type frag_type;

  frag_type val_frags[kNumFrags];

  METAL_FUNC MFAMMATile() thread {}

  METAL_FUNC void clear() {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kNumFrags; i++) val_frags[i] = frag_type(0);
  }

  METAL_FUNC thread frag_type& frag_at(short i, short j) {
    return val_frags[i * kTileCols_ + j];
  }
  METAL_FUNC const thread frag_type& frag_at(short i, short j) const {
    return val_frags[i * kTileCols_ + j];
  }

  METAL_FUNC thread T* elems() {
    return reinterpret_cast<thread T*>(val_frags);
  }

  template <typename Op>
  METAL_FUNC void row_reduce(thread T vals[kTileRows_]) const {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        Frag::template row_reduce<Op>(frag_at(i, j), &vals[i]);
      }
    }
  }

  template <typename Op>
  METAL_FUNC void row_bin_op(thread T vals[kTileRows_]) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        Frag::template row_bin_op<Op>(frag_at(i, j), &vals[i]);
      }
    }
  }

  // Load from threadgroup.
  // str_row = stride between rows in threadgroup (e.g. LDQ for Q, LDK for K^T)
  // str_col = stride between cols (1 for row-major, LDK for K^T transposed)
  template <typename U, int w_x, int w_y>
  METAL_FUNC void load(const threadgroup U* src, int str_row, int str_col) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        Frag::load(frag_at(i, j),
                   &src[(i * kFragRows) * w_x * str_row +
                        (j * kFragCols) * w_y * str_col],
                   str_row, str_col);
      }
    }
  }

  // Store to device (row-major, ld = leading dimension)
  template <typename U, int w_x, int w_y>
  METAL_FUNC void store(device U* dst, const int ld) const {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        const int base = (i * kFragRows) * w_x * ld + (j * kFragCols) * w_y;
        dst[base + 0 * ld + 0] = static_cast<U>(frag_at(i, j)[0]);
        dst[base + 0 * ld + 1] = static_cast<U>(frag_at(i, j)[1]);
      }
    }
  }

  // Bounded store (dims.x = cols remaining, dims.y = rows remaining)
  template <typename U, int w_x, int w_y>
  METAL_FUNC void store_safe(device U* dst, const int ld,
                             const short2 dims) const {
    STEEL_PRAGMA_UNROLL
    for (int i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (int j = 0; j < kTileCols_; j++) {
        const int off_row = (i * kFragRows) * w_x;
        const int off_col = (j * kFragCols) * w_y;
        // kElemRows=1, kElemCols=2
        if (off_row < (int)dims.y) {
          if (off_col     < (int)dims.x) dst[off_row * ld + off_col]     = static_cast<U>(frag_at(i, j)[0]);
          if (off_col + 1 < (int)dims.x) dst[off_row * ld + off_col + 1] = static_cast<U>(frag_at(i, j)[1]);
        }
      }
    }
  }
};

template <typename T, int M, int N, int K>
METAL_FUNC void mfa_tile_matmad(
    thread MFAMMATile<T, M, N>& D,
    thread MFAMMATile<T, M, K>& A,
    thread MFAMMATile<T, K, N>& B,
    thread MFAMMATile<T, M, N>& C) {
  STEEL_PRAGMA_UNROLL
  for (short m = 0; m < M; m++) {
    STEEL_PRAGMA_UNROLL
    for (short n = 0; n < N; n++) {
      short n_serp = (m % 2) ? (N - 1 - n) : n;
      STEEL_PRAGMA_UNROLL
      for (short k = 0; k < K; k++) {
        MFAMMAFrag<T>::mma(D.frag_at(m, n_serp),
                           A.frag_at(m, k),
                           B.frag_at(k, n_serp),
                           C.frag_at(m, n_serp));
      }
    }
  }
}

)MFA";

  // ── Arithmetic op structs ────────────────────────────────────────────────
  ss << R"MFA(
struct MFAMaxOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return metal::max(x, y); }
};
struct MFASumOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return x + y; }
};
struct MFAMulOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return x * y; }
};
struct MFADivOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return x / y; }
};
struct MFAExpSubOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return fast::exp2(x - y); }
};

)MFA";

  // ── Compile-time tile constants ──────────────────────────────────────────
  // These are injected as Metal preprocessor defines so the compiler can
  // fully unroll all loops at compile time.
  ss << "#define MFA_BQ  " << BQ  << "\n";
  ss << "#define MFA_BK  " << BK  << "\n";
  ss << "#define MFA_BD  " << BD  << "\n";
  ss << "#define MFA_WM  " << WM  << "\n";
  ss << "#define MFA_WN  " << WN  << "\n";
  ss << "#define MFA_TGP_SIZE  " << (WM * WN * 32) << "\n";
  ss << "#define MFA_DTYPE  " << dtype_str << "\n";
  ss << "\n";

  // Derived tile counts
  const int TD = BD / 8;   // head-dim frags per warp
  const int TK = BK / 8;   // K-seq frags per K tile
  const int TQ = BQ / (WM * WN * 8); // Q-seq frags per warp (must be 1)
  const int kRowsPT = TQ;  // rows per thread in S tile

  ss << "#define MFA_TD  " << TD << "\n";
  ss << "#define MFA_TK  " << TK << "\n";
  ss << "#define MFA_TQ  " << TQ << "\n";
  ss << "#define MFA_ROWS_PT  " << kRowsPT << "\n";
  ss << "#define MFA_BD_HALF  " << BD_HALF  << "\n";
  ss << "#define MFA_D_SPLITS " << D_SPLITS << "\n";
  ss << "#define MFA_TD_HALF  " << TD_HALF  << "\n";
  ss << "\n";

  // ── Main kernel ──────────────────────────────────────────────────────────
  // We emit the kernel as a template-specialized free function to allow the
  // Metal compiler to unroll all inner loops at the concrete tile sizes.
  ss << "[[kernel, max_total_threads_per_threadgroup(MFA_TGP_SIZE)]]\n";
  ss << "void mlx_mfa_attention(\n";
  ss << "    const device MFA_DTYPE* Q    [[buffer(0)]],\n";
  ss << "    const device MFA_DTYPE* K    [[buffer(1)]],\n";
  ss << "    const device MFA_DTYPE* V    [[buffer(2)]],\n";
  ss << "    device MFA_DTYPE*       O    [[buffer(3)]],\n";
  ss << "    device float*           L    [[buffer(4)]],\n";
  ss << "    const constant MFASteelParams* p [[buffer(5)]],\n";
  if (sparse)
    ss << "    const device uchar* block_mask   [[buffer(6)]],\n";
  if (has_rope) {
    ss << "    const device float* rotary_cos   [[buffer(7)]],\n";
    ss << "    const device float* rotary_sin   [[buffer(8)]],\n";
  }
  if (has_alibi)
    ss << "    const device float* alibi_slopes [[buffer(9)]],\n";
  ss << "    uint simd_lane_id  [[thread_index_in_simdgroup]],\n";
  ss << "    uint simd_group_id [[simdgroup_index_in_threadgroup]],\n";
  ss << "    uint3 tid          [[threadgroup_position_in_grid]])\n";
  ss << "{\n";
  ss << "  typedef MFA_DTYPE T;\n";
  ss << "  typedef float     AccT;\n";
  ss << "\n";

  // Pointer offsets: tid.x=Q-block, tid.y=head, tid.z=batch
  ss << "  const ulong boff = (ulong)tid.z * p->Q_strides[0]\n";
  ss << "                   + (ulong)tid.y * p->Q_strides[1];\n";
  ss << "  const ulong kv_head = (uint)tid.y / (uint)p->gqa_factor;\n";
  ss << "  const ulong kv_boff_k = (ulong)tid.z * p->K_strides[0]\n";
  ss << "                        + kv_head      * p->K_strides[1];\n";
  ss << "  const ulong kv_boff_v = (ulong)tid.z * p->V_strides[0]\n";
  ss << "                        + kv_head      * p->V_strides[1];\n";
  ss << "\n";
  ss << "  Q += boff;        // qb-block offset applied inside persistent loop\n";
  ss << "  K += kv_boff_k;  // K loader walks K-seq; no per-block offset\n";
  ss << "  V += kv_boff_v;\n";
  ss << "  O += (ulong)tid.z * p->O_strides[0]\n";
  ss << "     + (ulong)tid.y * p->O_strides[1];\n"; // qb offset applied inside loop
  ss << "\n";

  // Threadgroup memory
  ss << "  constexpr short padQ  = 16 / sizeof(T);\n";
  ss << "  constexpr short padK  = 16 / sizeof(T);\n";
  ss << "  constexpr short padV  = 16 / sizeof(T);\n";
  // d_split: Q/V smem sized to BD_HALF; K transposed smem stride (LDK) unchanged.
  if (!d_split) {
    ss << "  constexpr short LDQ   = MFA_BD + padQ;\n";
    ss << "  constexpr short LDK   = MFA_BK + padK;\n";
    ss << "  constexpr short LDV   = MFA_BD + padV;\n";
    ss << "  constexpr short kv_s0 = (MFA_BK + padK) * MFA_BD;\n";
    ss << "  constexpr short kv_s1 = MFA_BK * (MFA_BD + padV);\n";
  } else {
    ss << "  constexpr short LDQ   = MFA_BD_HALF + padQ;\n";
    ss << "  constexpr short LDK   = MFA_BK + padK;\n";
    ss << "  constexpr short LDV   = MFA_BD_HALF + padV;\n";
    ss << "  constexpr short kv_s0 = (MFA_BK + padK) * MFA_BD_HALF;\n";
    ss << "  constexpr short kv_s1 = MFA_BK * (MFA_BD_HALF + padV);\n";
  }
  ss << "  constexpr short kv_s  = kv_s0 > kv_s1 ? kv_s0 : kv_s1;\n";
  ss << "\n";
  if (!d_split)
    ss << "  threadgroup T Q_smem[MFA_BQ * (MFA_BD + 16/sizeof(T))];\n";
  else
    ss << "  threadgroup T Q_smem[MFA_BQ * (MFA_BD_HALF + 16/sizeof(T))];\n";
  if (double_buf) {
    // Separate K_smem / V_smem allows K-load to overlap P@V and V-load to
    // overlap K-GEMM at the hardware level (load + SIMD are separate units).
    // Reduces barriers from 4 → 2 per K-tile. Valid for D≤128 (TGP < 32KB).
    ss << "  threadgroup T K_smem[kv_s0];\n";
    ss << "  threadgroup T V_smem[kv_s1];\n";
    ss << "  threadgroup T* Qs = Q_smem;\n";
    ss << "  threadgroup T* Ks = K_smem;\n";
    ss << "  threadgroup T* Vs = V_smem;\n";
  } else {
    ss << "  threadgroup T KV_smem[kv_s];\n";
    ss << "  threadgroup T* Qs = Q_smem;\n";
    ss << "  threadgroup T* Ks = KV_smem;\n";
    ss << "  threadgroup T* Vs = KV_smem;\n";
  }
  ss << "\n";

  // Block loaders — d_split: all loaders use BD_HALF cols (one D-chunk at a time)
  if (!d_split) {
    ss << "  // Q loader: row-major (kDstStrRow=LDQ, kDstStrCol=1, reduction_dim=1)\n";
    ss << "  using QLoader = MFABlockLoaderT<T, MFA_BQ, MFA_BD,\n";
    ss << "      /*kDstStrRow=*/ MFA_BD + 16/sizeof(T),\n";
    ss << "      /*kDstStrCol=*/ 1,\n";
    ss << "      /*reduction_dim=*/ 1,\n";
    ss << "      /*tgp_size=*/ MFA_TGP_SIZE>;\n";
    ss << "  // K loader: transposed into tgp (kDstStrRow=1, kDstStrCol=LDK, reduction_dim=0)\n";
    ss << "  using KLoader = MFABlockLoaderT<T, MFA_BK, MFA_BD,\n";
    ss << "      /*kDstStrRow=*/ 1,\n";
    ss << "      /*kDstStrCol=*/ MFA_BK + 16/sizeof(T),\n";
    ss << "      /*reduction_dim=*/ 0,\n";
    ss << "      /*tgp_size=*/ MFA_TGP_SIZE>;\n";
    ss << "  // V loader: row-major (kDstStrRow=LDV, kDstStrCol=1, reduction_dim=0)\n";
    ss << "  using VLoader = MFABlockLoaderT<T, MFA_BK, MFA_BD,\n";
    ss << "      /*kDstStrRow=*/ MFA_BD + 16/sizeof(T),\n";
    ss << "      /*kDstStrCol=*/ 1,\n";
    ss << "      /*reduction_dim=*/ 0,\n";
    ss << "      /*tgp_size=*/ MFA_TGP_SIZE>;\n";
  } else {
    // d_split loaders: BD_HALF-wide tiles; loaders re-instantiated per D-chunk in Metal
    ss << "  using QLoader = MFABlockLoaderT<T, MFA_BQ, MFA_BD_HALF,\n";
    ss << "      MFA_BD_HALF + 16/sizeof(T), 1, 1, MFA_TGP_SIZE>;\n";
    ss << "  using KLoader = MFABlockLoaderT<T, MFA_BK, MFA_BD_HALF,\n";
    ss << "      1, MFA_BK + 16/sizeof(T), 0, MFA_TGP_SIZE>;\n";
    ss << "  using VLoader = MFABlockLoaderT<T, MFA_BK, MFA_BD_HALF,\n";
    ss << "      MFA_BD_HALF + 16/sizeof(T), 1, 0, MFA_TGP_SIZE>;\n";
  }
  ss << "\n";
  // MMA tile declarations — loop-invariant, declared outside the persistent loop
  ss << "  const AccT scale = p->scale * M_LOG2E_F;\n";
  ss << "\n";
  ss << "  // Warp offset within Q tile\n";
  ss << "  const short2 simd_coord = MFAMMAFrag<AccT>::get_coord((ushort)simd_lane_id);\n";
  ss << "  const short sm = simd_coord.y;\n";
  ss << "  const short sn = simd_coord.x;\n";
  ss << "  const short tm = 8 * MFA_TQ * (short)simd_group_id;\n";
  ss << "\n";
  ss << "  const short Qs_off = (tm + sm) * LDQ + sn;\n";
  ss << "  const short Ks_off = sm * LDK + sn;\n";
  ss << "  const short Vs_off = sm * LDV + sn;\n";
  ss << "\n";
  // Qtile is TQ×TD (or TQ×TD_HALF × D_SPLITS) so Q is hoisted into registers.
  // Ktile stays 1×TK (one D-slice per DD iteration) to avoid register pressure.
  // Tile and state arrays declared outside loop; reset inside per qb.
  if (!d_split) {
    ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD> Qtile;\n";
    ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD> Otile;\n";
  } else {
    ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD_HALF> Qtile[MFA_D_SPLITS];\n";
    ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD_HALF> Otile[MFA_D_SPLITS];\n";
  }
  ss << "  MFAMMATile<AccT, 1,     MFA_TK>  Ktile;\n";
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TK> Stile;\n";
  ss << "  MFAMMATile<AccT, 1,    1>       Vtile;\n";
  ss << "  AccT max_score[MFA_ROWS_PT];\n";
  ss << "  AccT sum_score[MFA_ROWS_PT];\n";
  ss << "\n";

  // Persistent kernel: each threadgroup processes 4 consecutive Q-blocks.
  // Grid dims shrink from (NQ,H,B) to (ceil(NQ/4),H,B).
  ss << "  const int qb_start = (int)tid.x * 4;\n";
  ss << "  const int qb_end   = min(qb_start + 4, p->NQ);\n";
  ss << "  for (int qb = qb_start; qb < qb_end; qb++) {\n";
  // Per-qb source/destination pointers
  ss << "  const device T* Q_qb = Q + (long)qb * MFA_BQ * p->Q_strides[2];\n";
  ss << "  device T*       O_qb = O + (long)qb * MFA_BQ * p->O_strides[2];\n";
  if (!d_split) {
    // Re-instantiate loaders each iteration: QLoader advances in Q; KLoader/VLoader rewind
    ss << "  QLoader loader_q(Q_qb, (int)p->Q_strides[2], Qs,\n";
    ss << "                   (ushort)simd_group_id, (ushort)simd_lane_id);\n";
    ss << "  KLoader loader_k(K, (int)p->K_strides[2], Ks,\n";
    ss << "                   (ushort)simd_group_id, (ushort)simd_lane_id);\n";
    ss << "  VLoader loader_v(V, (int)p->V_strides[2], Vs,\n";
    ss << "                   (ushort)simd_group_id, (ushort)simd_lane_id);\n";
  }
  // d_split: loaders created inline per D-chunk; no persistent loader_k / loader_v.
  // Reset accumulator and softmax state for this Q-block
  if (!d_split)
    ss << "  Otile.clear();\n";
  else {
    ss << "  STEEL_PRAGMA_UNROLL\n";
    ss << "  for (short dh = 0; dh < MFA_D_SPLITS; dh++) Otile[dh].clear();\n";
  }
  ss << "  STEEL_PRAGMA_UNROLL\n";
  ss << "  for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "    max_score[i] = -INFINITY;\n";
  ss << "    sum_score[i] = 0.0f;\n";
  ss << "  }\n";
  ss << "\n";

  // Cooperative Q load: device → threadgroup SRAM
  if (!d_split) {
    ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "  if (qb == p->NQ_aligned) {\n";
    ss << "    loader_q.load_safe(short2(MFA_BD, p->qL_rem));\n";
    ss << "  } else {\n";
    ss << "    loader_q.load_unsafe();\n";
    ss << "  }\n";
  }
  // Q SRAM ready.  Optionally apply RoPE to Q in SRAM before register load.
  // Each thread handles a non-overlapping slice of (Q_row, D_pair) tuples;
  // no race conditions.  The existing barrier below synchronises writes.
  ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  if (has_rope) {
    ss << "  {\n";
    ss << "    const uint local_id = simd_group_id * 32 + simd_lane_id;\n";
    ss << "    const int qabs_base = p->rope_q_base + qb * MFA_BQ;\n";
    ss << "    for (int ri = (int)local_id; ri < MFA_BQ * (MFA_BD/2);\n";
    ss << "         ri += MFA_TGP_SIZE) {\n";
    ss << "      const int row  = ri / (MFA_BD/2);\n";
    ss << "      const int pair = ri % (MFA_BD/2);\n";
    ss << "      const int cos_idx = (qabs_base + row) * p->rope_cos_stride + pair;\n";
    ss << "      const float cos_v = rotary_cos[cos_idx];\n";
    ss << "      const float sin_v = rotary_sin[cos_idx];\n";
    if (rope_interleaved) {
      // LLaMA-style: pairs are adjacent (d=2*pair, d=2*pair+1)
      ss << "      const int si0 = row * LDQ + pair * 2;\n";
      ss << "      const float q0 = (float)Qs[si0];\n";
      ss << "      const float q1 = (float)Qs[si0 + 1];\n";
      ss << "      Qs[si0]     = (T)(q0 * cos_v - q1 * sin_v);\n";
      ss << "      Qs[si0 + 1] = (T)(q0 * sin_v + q1 * cos_v);\n";
    } else {
      // GPT-NeoX style: pair d maps to d and d + D/2
      ss << "      const int si0 = row * LDQ + pair;\n";
      ss << "      const int si1 = row * LDQ + pair + MFA_BD/2;\n";
      ss << "      const float q0 = (float)Qs[si0];\n";
      ss << "      const float q1 = (float)Qs[si1];\n";
      ss << "      Qs[si0] = (T)(q0 * cos_v - q1 * sin_v);\n";
      ss << "      Qs[si1] = (T)(q0 * sin_v + q1 * cos_v);\n";
    }
    ss << "    }\n";
    ss << "  }\n";
    ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  }
  // Load Q from TGP into registers ONCE (key STEEL optimization: Q stays in
  // registers across all K-tile iterations; only K/V stream through TGP).
  if (!d_split) {
    ss << "  Qtile.template load<T, 1, 1>(&Qs[Qs_off], LDQ, 1);\n";
  } else {
    // d_split: hoist each BD_HALF-wide chunk into Qtile[dh]
    ss << "  STEEL_PRAGMA_UNROLL\n";
    ss << "  for (short dh = 0; dh < MFA_D_SPLITS; dh++) {\n";
    ss << "    QLoader loader_q_dh(Q_qb + dh * MFA_BD_HALF, (int)p->Q_strides[2], Qs,\n";
    ss << "                        (ushort)simd_group_id, (ushort)simd_lane_id);\n";
    ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "    if (qb == p->NQ_aligned) loader_q_dh.load_safe(short2(MFA_BD_HALF, p->qL_rem));\n";
    ss << "    else                     loader_q_dh.load_unsafe();\n";
    ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "    Qtile[dh].template load<T, 1, 1>(&Qs[Qs_off], LDQ, 1);\n";
    ss << "  }\n";
  }
  ss << "\n";

  // K-loop limit (causal or full)
  if (causal) {
    ss << "  int q_max = (qb + 1) * MFA_BQ + p->qL_off;\n";
    ss << "  int kb_lim = (q_max + MFA_BK - 1) / MFA_BK;\n";
    ss << "  if (kb_lim > p->NK) kb_lim = p->NK;\n";
  } else {
    ss << "  int kb_lim = p->NK;\n";
  }
  // Sliding window: compute kb_start/kb_lim per Q-block (different qb → different window).
  // kb_start (left bound):  skip K-tiles entirely before the left window boundary.
  // kb_last_win (left boundary zone): last tile with any left-boundary elements.
  // kb_right_lim (right bound): clamp kb_lim so we stop past the right window boundary.
  // kb_first_right (right boundary zone): first tile with any right-masked elements.
  // All must be recomputed per Q-block since different qb → different window positions.
  if (has_window) {
    ss << "  int q_min = qb * MFA_BQ + p->qL_off;\n";
    // Left bound: only when window_left is enabled (-1 means disabled).
    ss << "  int kb_start, kb_last_win;\n";
    ss << "  if (p->window_left >= 0) {\n";
    ss << "    int win_start = q_min - p->window_left;\n";
    ss << "    kb_start = win_start > 0 ? win_start / MFA_BK : 0;\n";
    ss << "    kb_last_win = (q_min + MFA_BQ - 1 > p->window_left)\n";
    ss << "                    ? (q_min + MFA_BQ - 1 - p->window_left) / MFA_BK : -1;\n";
    ss << "  } else {\n";
    ss << "    kb_start = 0;\n";
    ss << "    kb_last_win = -1; // no left masking\n";
    ss << "  }\n";
    // d_split uses absolute kb-indexed loaders (no persistent loader to advance).
    if (!d_split) {
      ss << "  for (int _kf = 0; _kf < kb_start; _kf++) {\n";
      ss << "    loader_k.next();\n";
      ss << "    loader_v.next();\n";
      ss << "  }\n";
    }
    // Right bound: clamp kb_lim and track first tile needing per-element right masking.
    ss << "  int kb_first_right;\n";
    ss << "  if (p->window_right >= 0) {\n";
    ss << "    // First tile where ALL elements are out-of-window for the largest row.\n";
    ss << "    int kb_right_lim = (q_min + MFA_BQ - 1 + p->window_right) / MFA_BK + 1;\n";
    ss << "    if (kb_right_lim < kb_lim) kb_lim = kb_right_lim;\n";
    ss << "    if (kb_lim < kb_start) kb_lim = kb_start; // empty range guard\n";
    ss << "    // First tile where col > row + window_right for the smallest row (q_min).\n";
    ss << "    kb_first_right = (q_min + p->window_right + 1) / MFA_BK;\n";
    ss << "    if (kb_first_right < kb_start) kb_first_right = kb_start;\n";
    ss << "  } else {\n";
    ss << "    kb_first_right = kb_lim; // right masking disabled\n";
    ss << "  }\n";
  } else {
    ss << "  const int kb_start = 0;\n";
    ss << "  const int kb_last_win = -1;\n";
    ss << "  const int kb_first_right = p->NK; // no window\n";
  }
  ss << "\n";

  // Double-buffer Phase 0: preload K[kb_start] into K_smem before the loop so the
  // first iteration can immediately issue V[0]-load while computing Q@K[0]^T.
  if (double_buf) {
    ss << "  // Phase 0 (double-buffer): preload K[kb_start] into K_smem.\n";
    ss << "  if (kb_lim > kb_start) {\n";
    ss << "    if (kb_start == p->NK_aligned) {\n";
    ss << "      loader_k.load_safe(short2(MFA_BD, p->kL_rem));\n";
    ss << "    } else {\n";
    ss << "      loader_k.load_unsafe();\n";
    ss << "    }\n";
    ss << "    loader_k.next();\n";
    ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "  }\n";
    ss << "\n";
  }

  // Main K/V loop
  ss << "  for (int kb = kb_start; kb < kb_lim; kb++) {\n";
  // Block-sparse: skip K-tiles where block_mask[q_tile][kb] == 0.
  // All threads in a threadgroup share tid.x and kb, so this is a
  // uniform branch — no warp divergence, just skips the barriers and math.
  if (sparse) {
    // 2D broadcast: mask_batch_stride=0, mask_head_stride=0 → same tile for all B,H.
    // 3D [H,NQ,NK]: mask_batch_stride=0, mask_head_stride=NQ*NK.
    // 4D [B,H,NQ,NK]: both strides set.
    ss << "    if (!block_mask[(long)tid.z * p->mask_batch_stride\n";
    ss << "                  + (long)tid.y * p->mask_head_stride\n";
    ss << "                  + (long)qb * p->NK + kb]) {\n";
    ss << "      loader_k.next();\n";
    ss << "      loader_v.next();\n";
    ss << "      continue;\n";
    ss << "    }\n";
  }
  // Non-double-buf: K is loaded here (4-barrier path, shared KV_smem).
  // Double-buf: K[kb] was already preloaded; skip to K-GEMM directly.
  // d_split: K loaded per D-chunk inline in S accumulation below; skip here.
  if (!double_buf && !d_split) {
    ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "    if (kb == p->NK_aligned) {\n";
    ss << "      loader_k.load_safe(short2(MFA_BD, p->kL_rem));\n";
    ss << "    } else {\n";
    ss << "      loader_k.load_unsafe();\n";
    ss << "    }\n";
    ss << "\n";
  }
  // Optional RoPE fusion for K.
  // K SRAM is transposed: element [k_row, d_col] stored at Ks[d_col*LDK+k_row].
  // RoPE pair (d0=2*pair, d1=2*pair+1) maps to Ks[d0*LDK+k_row] / Ks[d1*LDK+k_row].
  // Each thread handles a unique (pair, k_row) slice — no race conditions.
  // A barrier before the RoPE block ensures all cooperative K-loader writes to
  // SRAM are visible to every thread before any thread starts the RoPE reads.
  // The second barrier (after Stile.clear()) protects the subsequent GEMM.
  if (has_rope) {
    ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "    {\n";
    ss << "      const uint local_id = simd_group_id * 32 + simd_lane_id;\n";
    ss << "      const int kabs_base = kb * MFA_BK;\n";
    ss << "      for (int ri = (int)local_id; ri < MFA_BK * (MFA_BD/2);\n";
    ss << "           ri += MFA_TGP_SIZE) {\n";
    ss << "        const int k_row = ri % MFA_BK;\n";
    ss << "        const int pair  = ri / MFA_BK;\n";
    ss << "        const int cos_idx = (kabs_base + k_row) * p->rope_cos_stride + pair;\n";
    ss << "        const float cos_v = rotary_cos[cos_idx];\n";
    ss << "        const float sin_v = rotary_sin[cos_idx];\n";
    if (rope_interleaved) {
      // LLaMA-style: K SRAM is transposed [d_col, k_row]; pair d maps to d*2, d*2+1
      ss << "        const int si0 = pair * 2       * LDK + k_row;\n";
      ss << "        const int si1 = (pair * 2 + 1) * LDK + k_row;\n";
    } else {
      // GPT-NeoX style: pair d maps to d, d+D/2 (column offsets in transposed K SRAM)
      ss << "        const int si0 = pair              * LDK + k_row;\n";
      ss << "        const int si1 = (pair + MFA_BD/2) * LDK + k_row;\n";
    }
    ss << "        const float k0 = (float)Ks[si0];\n";
    ss << "        const float k1 = (float)Ks[si1];\n";
    ss << "        Ks[si0] = (T)(k0 * cos_v - k1 * sin_v);\n";
    ss << "        Ks[si1] = (T)(k0 * sin_v + k1 * cos_v);\n";
    ss << "      }\n";
    ss << "    }\n";
  }
  // S = Q @ K^T  (Q is in registers; only K is loaded from TGP per DD slice)
  ss << "    Stile.clear();\n";
  if (!d_split) {
    // double_buf: K[kb] was synced by barrier-2 at end of prev iter (or Phase-0 barrier).
    // No additional barrier needed here — K_smem is already fully visible.
    if (!double_buf) {
      ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    }
    ss << "    STEEL_PRAGMA_UNROLL\n";
    ss << "    for (short dd = 0; dd < MFA_TD; dd++) {\n";
    ss << "      Ktile.template load<T, 1, 1>(\n";
    ss << "          &Ks[Ks_off + (short)(dd * 8) * LDK], LDK, 1);\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short iq = 0; iq < MFA_TQ; iq++) {\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short ik = 0; ik < MFA_TK; ik++) {\n";
    ss << "          MFAMMAFrag<AccT>::mma(\n";
    ss << "              Stile.frag_at(iq, ik),\n";
    ss << "              Qtile.frag_at(iq, dd),\n";
    ss << "              Ktile.frag_at(0, ik),\n";
    ss << "              Stile.frag_at(iq, ik));\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
  } else {
    // d_split: loop over D_SPLITS K chunks; load each BD_HALF-wide K tile
    ss << "    STEEL_PRAGMA_UNROLL\n";
    ss << "    for (short dh = 0; dh < MFA_D_SPLITS; dh++) {\n";
    ss << "      KLoader loader_k_dh(K + (long)kb * MFA_BK * p->K_strides[2] + dh * MFA_BD_HALF,\n";
    ss << "                          (int)p->K_strides[2], Ks,\n";
    ss << "                          (ushort)simd_group_id, (ushort)simd_lane_id);\n";
    ss << "      threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "      if (kb == p->NK_aligned) loader_k_dh.load_safe(short2(MFA_BD_HALF, p->kL_rem));\n";
    ss << "      else                     loader_k_dh.load_unsafe();\n";
    ss << "      threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short dd = 0; dd < MFA_TD_HALF; dd++) {\n";
    ss << "        Ktile.template load<T, 1, 1>(\n";
    ss << "            &Ks[Ks_off + (short)(dd * 8) * LDK], LDK, 1);\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short iq = 0; iq < MFA_TQ; iq++)\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short ik = 0; ik < MFA_TK; ik++)\n";
    ss << "            MFAMMAFrag<AccT>::mma(\n";
    ss << "                Stile.frag_at(iq, ik),\n";
    ss << "                Qtile[dh].frag_at(iq, dd),\n";
    ss << "                Ktile.frag_at(0, ik),\n";
    ss << "                Stile.frag_at(iq, ik));\n";
    ss << "      }\n";
    ss << "    }\n";
  }
  ss << "\n";
  // Double-buf: issue V[kb] load into V_smem right after K-GEMM.
  // K_smem ≠ V_smem → no conflict with the just-completed K reads.
  // The load-store unit can process the V-writes while the ALU runs
  // scale/softcap/masks/softmax below; barrier-1 (at P@V) captures them.
  if (double_buf) {
    ss << "    // Double-buf: issue V[kb] load (overlaps softmax compute)\n";
    ss << "    if (kb == p->NK_aligned) {\n";
    ss << "      loader_v.load_safe(short2(MFA_BD, p->kL_rem));\n";
    ss << "    } else {\n";
    ss << "      loader_v.load_unsafe();\n";
    ss << "    }\n";
    ss << "    loader_v.next();\n";
    ss << "\n";
  }
  ss << "    // Apply scale (log2-domain)\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short ii = 0; ii < MFA_TQ * MFA_TK * 2; ii++) {\n";
  ss << "      Stile.elems()[ii] *= scale;\n";
  ss << "    }\n";
  ss << "\n";

  // Softcapping (Gemma 2 / Grok) — operates in natural-log domain
  if (key.has_softcap) {
    ss << "    // Softcapping: tanh(S_nat / cap) * cap, convert log2 <-> natural\n";
    ss << "    {\n";
    ss << "      constexpr AccT log2e = 1.4426950408889634f;\n";
    ss << "      constexpr AccT ln2   = 0.6931471805599453f;\n";
    ss << "      const AccT cap   = p->softcap;\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short ii = 0; ii < MFA_TQ * MFA_TK * 2; ii++) {\n";
    ss << "        AccT s_nat = Stile.elems()[ii] * ln2;   // log2 → natural\n";
    ss << "        s_nat = precise::tanh(s_nat / cap) * cap;\n";
    ss << "        Stile.elems()[ii] = s_nat * log2e;       // natural → log2\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }

  // ALiBi (Attention with Linear Biases) — per-head slope × (k_pos - q_pos)
  // Added to scores in log2 domain: bias_log2 = slope * (k - q) * log2e
  if (has_alibi) {
    ss << "    // ALiBi: add per-head linear position bias to scores\n";
    ss << "    {\n";
    ss << "      constexpr AccT log2e = 1.4426950408889634f;\n";
    ss << "      const AccT slope = alibi_slopes[(int)tid.y] * log2e;\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int q_pos = qb * MFA_BQ + p->qL_off + (int)tm + (int)sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int k_base = kb * MFA_BK + (int)sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            Stile.frag_at(i, j)[jj] += slope * (float)(k_base + jj - q_pos);\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }

  // K-boundary mask
  ss << "    // Mask padded K positions\n";
  ss << "    if (kb == p->NK_aligned) {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
  ss << "          const short col = sn + j * 8;\n";
  ss << "          STEEL_PRAGMA_UNROLL\n";
  ss << "          for (short jj = 0; jj < 2; jj++) {\n";
  ss << "            if ((col + jj) >= p->kL_rem)\n";
  ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
  ss << "          }\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "\n";

  // Causal mask
  if (causal) {
    ss << "    // Causal mask: mask k > q\n";
    ss << "    if (kb >= (kb_lim - (MFA_BQ + MFA_BK - 1) / MFA_BK)) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = qb * MFA_BQ + p->qL_off\n";
    ss << "                      + tm + sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if (row < (col + jj))\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }
  // Sliding window left boundary: mask k < q - window_left for all tiles in the
  // boundary zone [kb_start, kb_last_win].  Different rows within the Q-block have
  // their window boundaries in different K-tiles, so we must check all boundary tiles.
  if (has_window) {
    ss << "    // Window left boundary: mask k < q - window_left\n";
    ss << "    // Apply for all tiles in [kb_start, kb_last_win] (per-element check).\n";
    ss << "    if (kb <= kb_last_win) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = qb * MFA_BQ + p->qL_off\n";
    ss << "                      + tm + sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if ((col + jj) < row - p->window_left)\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
    // Window right boundary: mask k > q + window_right for tiles >= kb_first_right.
    ss << "    // Window right boundary: mask k > q + window_right\n";
    ss << "    // Apply for all tiles in [kb_first_right, kb_lim) (per-element check).\n";
    ss << "    if (kb >= kb_first_right) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = qb * MFA_BQ + p->qL_off\n";
    ss << "                      + tm + sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if ((col + jj) > row + p->window_right)\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }

  // Load V while doing softmax.
  // !double_buf: V shares KV_smem with K, so K-GEMM must finish (barrier) before
  //              we overwrite that buffer with V data.
  // double_buf:  V already issued right after K-GEMM into separate V_smem; skip.
  // d_split:     V is loaded per D-chunk inline in P@V loop below; skip here.
  if (!double_buf && !d_split) {
    ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "    if (kb == p->NK_aligned) {\n";
    ss << "      loader_v.load_safe(short2(MFA_BD, p->kL_rem));\n";
    ss << "    } else {\n";
    ss << "      loader_v.load_unsafe();\n";
    ss << "    }\n";
    ss << "\n";
  }

  // Online softmax update (NaN-safe version).
  // When all tile elements for row i are masked (-INFINITY), new_max[i] stays -inf.
  // naive: factor = exp2(-inf - (-inf)) = exp2(nan) = nan → corrupts accumulation.
  // Fix: when new_max[i] has not improved (still -inf), use factor=1 and a finite
  // sentinel for ExpSubOp so exp2(-inf - 0) = 0 (no contribution, no NaN).
  ss << "    // Online softmax (NaN-safe: handles all-masked tiles)\n";
  ss << "    AccT new_max[MFA_ROWS_PT];\n";
  ss << "    AccT factor[MFA_ROWS_PT];\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) new_max[i] = max_score[i];\n";
  ss << "    Stile.template row_reduce<MFAMaxOp>(new_max);\n";
  ss << "    // Compute factor and update max_score; use finite sentinel for ExpSubOp.\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      if (new_max[i] > max_score[i]) {\n";
  ss << "        factor[i] = fast::exp2(max_score[i] - new_max[i]);\n";
  ss << "        max_score[i] = new_max[i];\n";
  ss << "      } else {\n";
  ss << "        factor[i] = 1.0f;\n";
  ss << "        // If max_score is -inf (no valid element seen), use sentinel 0 so\n";
  ss << "        // exp2(-inf - 0) = 0 (correct zero contribution, no NaN).\n";
  ss << "        new_max[i] = metal::isinf(max_score[i]) ? (AccT)0.0f : max_score[i];\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "    Stile.template row_bin_op<MFAExpSubOp>(new_max);\n";
  ss << "    AccT sum_tmp[MFA_ROWS_PT] = {0};\n";
  ss << "    Stile.template row_reduce<MFASumOp>(sum_tmp);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      sum_score[i] = sum_score[i] * factor[i] + sum_tmp[i];\n";
  ss << "    }\n";
  if (!d_split)
    ss << "    Otile.template row_bin_op<MFAMulOp>(factor);\n";
  else {
    ss << "    STEEL_PRAGMA_UNROLL\n";
    ss << "    for (short dh = 0; dh < MFA_D_SPLITS; dh++)\n";
    ss << "      Otile[dh].template row_bin_op<MFAMulOp>(factor);\n";
  }
  ss << "\n";

  // P @ V accumulation
  ss << "    // O += P @ V\n";
  if (!d_split)
    ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  // Loop order: iq → ik → id (innermost)
  // ik is the K-sequence tile (ik*8*LDV: large stride in V_smem).
  // id is the D tile (id*8: small stride = 16-byte step in V_smem).
  // With id innermost, each ik block does a sequential D-scan (cache-friendly).
  // Stile[iq][ik] stays live for all TD id iterations (saves re-load vs id-outer).
  if (!d_split) {
    ss << "    STEEL_PRAGMA_UNROLL\n";
    ss << "    for (short iq = 0; iq < MFA_TQ; iq++) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short ik = 0; ik < MFA_TK; ik++) {\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short id = 0; id < MFA_TD; id++) {\n";
    ss << "          Vtile.template load<T, 1, 1>(\n";
    ss << "              &Vs[Vs_off + ik*8*LDV + id*8], LDV, 1);\n";
    ss << "          MFAMMAFrag<AccT>::mma(\n";
    ss << "              Otile.frag_at(iq, id),\n";
    ss << "              Stile.frag_at(iq, ik),\n";
    ss << "              Vtile.frag_at(0, 0),\n";
    ss << "              Otile.frag_at(iq, id));\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
  } else {
    // d_split P@V: loop over D_SPLITS V chunks; Otile[dh] accumulates per D chunk
    ss << "    STEEL_PRAGMA_UNROLL\n";
    ss << "    for (short dh = 0; dh < MFA_D_SPLITS; dh++) {\n";
    ss << "      VLoader loader_v_dh(V + (long)kb * MFA_BK * p->V_strides[2] + dh * MFA_BD_HALF,\n";
    ss << "                          (int)p->V_strides[2], Vs,\n";
    ss << "                          (ushort)simd_group_id, (ushort)simd_lane_id);\n";
    ss << "      threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "      if (kb == p->NK_aligned) loader_v_dh.load_safe(short2(MFA_BD_HALF, p->kL_rem));\n";
    ss << "      else                     loader_v_dh.load_unsafe();\n";
    ss << "      threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short iq = 0; iq < MFA_TQ; iq++)\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short ik = 0; ik < MFA_TK; ik++)\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short id = 0; id < MFA_TD_HALF; id++) {\n";
    ss << "            Vtile.template load<T, 1, 1>(&Vs[Vs_off + ik*8*LDV + id*8], LDV, 1);\n";
    ss << "            MFAMMAFrag<AccT>::mma(\n";
    ss << "                Otile[dh].frag_at(iq, id),\n";
    ss << "                Stile.frag_at(iq, ik),\n";
    ss << "                Vtile.frag_at(0, 0),\n";
    ss << "                Otile[dh].frag_at(iq, id));\n";
    ss << "          }\n";
    ss << "    }\n";
  }
  if (double_buf) {
    // Double-buf barrier-2: preload K[kb+1] into K_smem while P@V (above) ran.
    // P@V reads V_smem; K-load writes K_smem — separate TGP regions, no conflict.
    // The barrier ensures K_smem is fully visible before the next K-GEMM.
    // Skipped on the last iteration (kb+1 == kb_lim) — no next tile needed.
    ss << "    // Double-buf: preload K[kb+1] (ran concurrently with P@V)\n";
    ss << "    if (kb + 1 < kb_lim) {\n";
    ss << "      if ((kb + 1) == p->NK_aligned) {\n";
    ss << "        loader_k.load_safe(short2(MFA_BD, p->kL_rem));\n";
    ss << "      } else {\n";
    ss << "        loader_k.load_unsafe();\n";
    ss << "      }\n";
    ss << "      loader_k.next();\n";
    ss << "      threadgroup_barrier(mem_flags::mem_threadgroup);\n";
    ss << "    }\n";
  } else if (!d_split) {
    // Non-split: advance persistent loaders to next K/V tile
    ss << "    loader_k.next();\n";
    ss << "    loader_v.next();\n";
  }
  // d_split: no persistent loaders to advance; offsets computed from kb directly.
  ss << "  } // end kb loop\n";
  ss << "\n";

  // Normalize + store O
  if (!d_split)
    ss << "  Otile.template row_bin_op<MFADivOp>(sum_score);\n";
  else {
    ss << "  STEEL_PRAGMA_UNROLL\n";
    ss << "  for (short dh = 0; dh < MFA_D_SPLITS; dh++)\n";
    ss << "    Otile[dh].template row_bin_op<MFADivOp>(sum_score);\n";
  }
  ss << "  threadgroup_barrier(mem_flags::mem_none);\n";
  ss << "\n";
  if (!d_split) {
    // Non-split: single Otile covers full BD columns.
    ss << "  device T* O_write = O_qb + (long)(tm + sm) * p->O_strides[2] + sn;\n";
    ss << "  if (qb == p->NQ_aligned) {\n";
    ss << "    auto dims = short2((short)(MFA_BD - sn),\n";
    ss << "                       (short)(p->qL_rem - (tm + sm)));\n";
    ss << "    if (dims.x > 0 && dims.y > 0)\n";
    ss << "      Otile.template store_safe<T, 1, 1>(O_write, (int)p->O_strides[2], dims);\n";
    ss << "  } else {\n";
    ss << "    Otile.template store<T, 1, 1>(O_write, (int)p->O_strides[2]);\n";
    ss << "  }\n";
  } else {
    // d_split: store each BD_HALF-wide Otile[dh] at offset dh*MFA_BD_HALF.
    // dims.x uses MFA_BD_HALF (always positive since D%BD_HALF==0).
    ss << "  STEEL_PRAGMA_UNROLL\n";
    ss << "  for (short dh = 0; dh < MFA_D_SPLITS; dh++) {\n";
    ss << "    device T* O_write = O_qb + (long)(tm + sm) * p->O_strides[2]\n";
    ss << "                        + dh * MFA_BD_HALF + sn;\n";
    ss << "    if (qb == p->NQ_aligned) {\n";
    ss << "      auto dims = short2((short)(MFA_BD_HALF - sn),\n";
    ss << "                         (short)(p->qL_rem - (tm + sm)));\n";
    ss << "      if (dims.x > 0 && dims.y > 0)\n";
    ss << "        Otile[dh].template store_safe<T, 1, 1>(O_write, (int)p->O_strides[2], dims);\n";
    ss << "    } else {\n";
    ss << "      Otile[dh].template store<T, 1, 1>(O_write, (int)p->O_strides[2]);\n";
    ss << "    }\n";
    ss << "  }\n";
  }
  ss << "\n";

  // Write L (logsumexp): only thread with sn==0 writes
  ss << "  // Write L = max_score + log2(sum_score)  (log2-domain logsumexp)\n";
  ss << "  // Only threads with sn==0 (first column of each frag row) write.\n";
  ss << "  if (sn == 0) {\n";
  ss << "    const long l_boff = (long)tid.z * p->L_strides[0]\n";
  ss << "                      + (long)tid.y * p->L_strides[1];\n";
  ss << "    const long q_base = (long)qb * MFA_BQ + tm + sm;\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      const long q_idx = q_base + i * 8;\n";
  ss << "      if (q_idx < p->qL) {\n";
  ss << "        L[l_boff + q_idx] = max_score[i] + metal::log2(sum_score[i]);\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "  }\n";
  ss << "  } // end qb loop\n";
  ss << "}\n";

  return ss.str();
}

// =========================================================================
// Flash Decoding helpers
// =========================================================================

int compute_num_splits(int kL, int BK) {
  // Target ~2*BK keys per split so each split has at least 2 K-tile iterations
  // to amortize TGP setup.  Cap at 32 splits.
  int NK = (kL + BK - 1) / BK;
  int ideal = NK / 2;   // at least 2 tiles per split
  return std::max(1, std::min(ideal, 32));
}

// Append shared Metal template code (BlockLoaderT, MMA tiles, op structs).
// Both Phase 1 and Phase 2 use the same STEEL_PRAGMA_UNROLL / Metal headers.
void append_metal_headers_and_defines(
    std::ostringstream& ss,
    bool enable_unroll,
    int arch_gen,
    const char* dtype_str) {
  ss << R"MFA(
#include <metal_stdlib>
#include <metal_simdgroup>
#include <metal_simdgroup_matrix>
using namespace metal;

#define STEEL_CONST static constant constexpr const
)MFA";
  ss << "#define ARCHITECTURE_GEN " << arch_gen << "\n";
  ss << "#define STEEL_PRAGMA_UNROLL";
  if (enable_unroll) ss << R"MFA( _Pragma("clang loop unroll(full)")
)MFA";
  else ss << "\n";
  ss << "\n";
  (void)dtype_str;  // may be used by caller after this
}

// Append BlockLoaderT + MMA tile templates + Op structs (identical for all kernels).
void append_steel_shared_templates(std::ostringstream& ss) {
  ss << R"MFA(
template <
    typename T,
    short BROWS,
    short BCOLS,
    short kDstStrRow,
    short kDstStrCol,
    short reduction_dim,
    short tgp_size,
    short n_reads = (BCOLS * BROWS) / tgp_size,
    short TCOLS = BCOLS / n_reads,
    short TROWS = tgp_size / TCOLS>
struct MFABlockLoaderT {
  STEEL_CONST short vec_size = n_reads;
  const int src_ld;
  const int tile_stride;
  const short thread_idx;
  const short bi;
  const short bj;
  threadgroup T* dst;
  const device T* src;

  METAL_FUNC MFABlockLoaderT(
      const device T* src_, const int src_ld_,
      threadgroup T* dst_, ushort simd_group_id, ushort simd_lane_id)
      : src_ld(src_ld_),
        tile_stride(reduction_dim ? BCOLS : BROWS * src_ld_),
        thread_idx(simd_group_id * 32 + simd_lane_id),
        bi(thread_idx / TCOLS),
        bj(vec_size * (thread_idx % TCOLS)),
        dst(dst_ + bi * kDstStrRow + bj * kDstStrCol),
        src(src_ + bi * src_ld_ + bj) {}

  METAL_FUNC void load_unsafe() const {
    constexpr bool can_vectorize = (kDstStrCol == 1) && (vec_size % 4 == 0);
    if constexpr (can_vectorize) {
      using vec4_t = vec<T, 4>;
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j += 4) {
          *(threadgroup vec4_t*)(dst + i * kDstStrRow + j) =
              *(const device vec4_t*)(src + i * src_ld + j);
        }
      }
    } else {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j++)
          dst[i * kDstStrRow + j * kDstStrCol] = src[i * src_ld + j];
      }
    }
  }

  METAL_FUNC void load_safe(short2 src_tile_dim) const {
    src_tile_dim = src_tile_dim - short2(bj, bi);
    if (src_tile_dim.x <= 0 || src_tile_dim.y <= 0) {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j++)
          dst[i * kDstStrRow + j * kDstStrCol] = T(0);
      }
      return;
    }
    bool tmp_idx[vec_size];
    T    tmp_val[vec_size];
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++)
        tmp_idx[j] = (i < src_tile_dim.y) && (j < src_tile_dim.x);
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++)
        tmp_val[j] = src[(tmp_idx[j] ? i * src_ld + j : 0)];
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++)
        tmp_val[j] = tmp_idx[j] ? tmp_val[j] : T(0);
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++)
        dst[i * kDstStrRow + j * kDstStrCol] = tmp_val[j];
    }
  }

  METAL_FUNC void next() { src += tile_stride; }
};

)MFA";

  ss << R"MFA(
template <typename T>
struct MFAMMAFrag {
  STEEL_CONST int kFragRows = 8;
  STEEL_CONST int kFragCols = 8;
  STEEL_CONST int kElemsPerFrag = 2;
  STEEL_CONST int kElemRows = 1;
  STEEL_CONST int kElemCols = 2;

  typedef simdgroup_matrix<T, 8, 8> mat_type;
  typedef vec<T, 2> frag_type;
  typedef vec<T, 1> row_frag_type;

  METAL_FUNC static short2 get_coord(ushort lane_id) {
    const short qid = lane_id / 4;
    const short fm  = (qid & 4) + ((lane_id / 2) % 4);
    const short fn  = (qid & 2) * 2 + (lane_id % 2) * 2;
    return short2{fn, fm};
  }

  template <typename SrcPtr, typename StrX, typename StrY>
  METAL_FUNC static void load(thread frag_type& dst,
                              SrcPtr src, StrX str_x, StrY str_y) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kElemRows; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kElemCols; j++)
        dst[i * kElemCols + j] = static_cast<T>(src[i * str_x + j * str_y]);
    }
  }

  template <typename Op>
  METAL_FUNC static void row_reduce(thread const frag_type& inp, thread T* out) {
    T thr = Op::apply(inp.x, inp.y);
    T qr  = Op::apply(thr, simd_shuffle_xor(thr, ushort(1)));
    T sr  = Op::apply(qr,  simd_shuffle_xor(qr,  ushort(8)));
    out[0] = Op::apply(out[0], sr);
  }

  template <typename Op>
  METAL_FUNC static void row_bin_op(thread frag_type& inp, thread T* row_vals) {
    STEEL_PRAGMA_UNROLL
    for (short j = 0; j < kElemCols; j++)
      inp[j] = Op::apply(inp[j], row_vals[0]);
  }

  // Vectorized 2-element load for contiguous (str_col==1) memory access.
  // src[0] and src[1] are loaded as a single vec<U,2> instruction.
  // Requires 2-byte alignment (guaranteed: sn coordinate is always even).
  template <typename U>
  METAL_FUNC static void load_vec2(thread frag_type& dst,
                                    const threadgroup U* src) {
    vec<U, 2> v = *(const threadgroup vec<U, 2>*)(src);
    dst[0] = static_cast<T>(v[0]);
    dst[1] = static_cast<T>(v[1]);
  }
  template <typename U>
  METAL_FUNC static void load_vec2(thread frag_type& dst,
                                    const device U* src) {
    vec<U, 2> v = *(const device vec<U, 2>*)(src);
    dst[0] = static_cast<T>(v[0]);
    dst[1] = static_cast<T>(v[1]);
  }
  // Vectorized 2-element store for contiguous output.
  template <typename U>
  METAL_FUNC static void store_vec2(thread const frag_type& src,
                                     device U* dst) {
    *(device vec<U, 2>*)(dst) =
        vec<U, 2>(static_cast<U>(src[0]), static_cast<U>(src[1]));
  }

  METAL_FUNC static void mma(thread frag_type& D, thread frag_type& A,
                             thread frag_type& B, thread frag_type& C) {
    mat_type Dm, Am, Bm, Cm;
    reinterpret_cast<thread frag_type&>(Am.thread_elements()) = A;
    reinterpret_cast<thread frag_type&>(Bm.thread_elements()) = B;
    reinterpret_cast<thread frag_type&>(Cm.thread_elements()) = C;
    simdgroup_multiply_accumulate(Dm, Am, Bm, Cm);
    D = reinterpret_cast<thread frag_type&>(Dm.thread_elements());
  }
};

template <typename T, int kTileRows_, int kTileCols_>
struct MFAMMATile {
  using Frag = MFAMMAFrag<T>;
  STEEL_CONST int kTileRows    = kTileRows_;
  STEEL_CONST int kTileCols    = kTileCols_;
  STEEL_CONST int kNumFrags    = kTileRows_ * kTileCols_;

  typedef typename Frag::frag_type frag_type;
  frag_type val_frags[kNumFrags];

  METAL_FUNC MFAMMATile() thread {}

  METAL_FUNC void clear() {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kNumFrags; i++) val_frags[i] = frag_type(0);
  }

  METAL_FUNC thread frag_type& frag_at(short i, short j) {
    return val_frags[i * kTileCols_ + j];
  }
  METAL_FUNC const thread frag_type& frag_at(short i, short j) const {
    return val_frags[i * kTileCols_ + j];
  }
  METAL_FUNC thread T* elems() {
    return reinterpret_cast<thread T*>(val_frags);
  }

  template <typename Op>
  METAL_FUNC void row_reduce(thread T vals[kTileRows_]) const {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++)
        Frag::template row_reduce<Op>(frag_at(i, j), &vals[i]);
    }
  }

  template <typename Op>
  METAL_FUNC void row_bin_op(thread T vals[kTileRows_]) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++)
        Frag::template row_bin_op<Op>(frag_at(i, j), &vals[i]);
    }
  }

  template <typename U, int w_x, int w_y>
  METAL_FUNC void load(const threadgroup U* src, int str_row, int str_col) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        Frag::load(frag_at(i, j),
                   &src[(i * 8) * w_x * str_row + (j * 8) * w_y * str_col],
                   str_row, str_col);
      }
    }
  }

  // Device-memory overload: same logic, device address space.
  // Used by V4 to load K fragments directly from device memory.
  template <typename U, int w_x, int w_y>
  METAL_FUNC void load(const device U* src, int str_row, int str_col) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        Frag::load(frag_at(i, j),
                   &src[(i * 8) * w_x * str_row + (j * 8) * w_y * str_col],
                   str_row, str_col);
      }
    }
  }

  template <typename U, int w_x, int w_y>
  METAL_FUNC void store(device U* dst, const int ld) const {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        const int base = (i * 8) * w_x * ld + (j * 8) * w_y;
        dst[base + 0] = static_cast<U>(frag_at(i, j)[0]);
        dst[base + 1] = static_cast<U>(frag_at(i, j)[1]);
      }
    }
  }

  // Contiguous (str_col==1) load: uses vec<U,2> to halve load instruction count.
  template <typename U, int w_x, int w_y>
  METAL_FUNC void load_contiguous(const threadgroup U* src, int str_row) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        Frag::template load_vec2<U>(
            frag_at(i, j),
            &src[(i * 8) * w_x * str_row + (j * 8) * w_y]);
      }
    }
  }
  template <typename U, int w_x, int w_y>
  METAL_FUNC void load_contiguous(const device U* src, int str_row) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        Frag::template load_vec2<U>(
            frag_at(i, j),
            &src[(i * 8) * w_x * str_row + (j * 8) * w_y]);
      }
    }
  }
  // Contiguous store: uses vec<U,2> for 2-element aligned write (no bounds check).
  template <typename U, int w_x, int w_y>
  METAL_FUNC void store_contiguous(device U* dst, const int ld) const {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        const int base = (i * 8) * w_x * ld + (j * 8) * w_y;
        Frag::template store_vec2<U>(frag_at(i, j), &dst[base]);
      }
    }
  }

  template <typename U, int w_x, int w_y>
  METAL_FUNC void store_safe(device U* dst, const int ld,
                             const short2 dims) const {
    STEEL_PRAGMA_UNROLL
    for (int i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (int j = 0; j < kTileCols_; j++) {
        const int off_row = (i * 8) * w_x;
        const int off_col = (j * 8) * w_y;
        if (off_row < (int)dims.y) {
          if (off_col     < (int)dims.x) dst[off_row * ld + off_col]     = static_cast<U>(frag_at(i, j)[0]);
          if (off_col + 1 < (int)dims.x) dst[off_row * ld + off_col + 1] = static_cast<U>(frag_at(i, j)[1]);
        }
      }
    }
  }
};

struct MFAMaxOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return metal::max(x, y); }
};
struct MFASumOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return x + y; }
};
struct MFAMulOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return x * y; }
};
struct MFADivOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return x / y; }
};
struct MFAExpSubOp {
  template <typename T>
  METAL_FUNC static T apply(T x, T y) { return fast::exp2(x - y); }
};

)MFA";
}

// =========================================================================
// Flash Decoding Phase 1: generate_flash_decode_partial_source
//
// Kernel "mlx_mfa_flash_decode_partial"
// Grid: (NQ * num_splits, H, B)
//   tid.x = split_id * NQ + q_tile_id
//   tid.y = head index
//   tid.z = batch index
//
// For each split, iterates K-tiles [kb_start, kb_end) and accumulates
// partial O and L using the same online softmax as the STEEL forward.
// =========================================================================

std::string generate_flash_decode_partial_source(const ShaderCache::KernelKey& key) {
  // CP2: use V2 tile sizes (larger BK) for D=64/128 to reduce K-tile iterations.
  // D=256/512: keep V1 tiles (V2 BQ=16/WM=2 for D=256 halves occupancy in V1 kernel).
  int BQ, BK, WM, WN;
  if (key.head_dim <= 128) {
    auto cfgv2 = select_steel_v2_block_config(key.head_dim, key.is_m3_plus);
    BQ = cfgv2.BQ; BK = cfgv2.BK; WM = cfgv2.WM; WN = cfgv2.WN;
  } else {
    auto cfgv1 = select_steel_block_config(key.head_dim, /*is_low_prec=*/(key.dtype != 2),
                                           key.is_m3_plus);
    BQ = cfgv1.BQ; BK = cfgv1.BK; WM = cfgv1.WM; WN = cfgv1.WN;
  }
  const int BD = key.head_dim;
  const int TGP_SIZE = WM * WN * 32;
  const int TD = BD / 8;
  const int TK = BK / 8;
  const int TQ = BQ / (WM * WN * 8);

  const bool causal    = key.causal;
  const bool has_alibi = key.has_alibi;
  const bool has_window = key.has_window;
  const char* dtype_str = "half";
  if (key.dtype == 1)      dtype_str = "bfloat";
  else if (key.dtype == 2) dtype_str = "float";

  const bool is_m3_plus = key.is_m3_plus;
  const int arch_gen = is_m3_plus ? 15 : 13;
  const bool enable_unroll = (key.head_dim <= 128) || is_m3_plus;

  std::ostringstream ss;

  // ── Metal includes + defines ─────────────────────────────────────────────
  append_metal_headers_and_defines(ss, enable_unroll, arch_gen, dtype_str);

  // ── MFAFlashDecodePartialParams struct ───────────────────────────────────
  ss << R"MFAP(
struct MFAFlashDecodePartialParams {
  int B, H, D;
  int qL, kL;
  int gqa_factor;
  float scale;
  int NQ, NQ_aligned;
  int qL_rem;
  int qL_off;
  int NK_total;
  int NK_aligned;
  int kL_rem;
  int num_splits;
  int NK_per_split;
  long Q_strides[3];
  long K_strides[3];
  long V_strides[3];
  long pO_split_stride;
  long pO_batch_stride;
  long pO_head_stride;
  long pL_split_stride;
  long pL_batch_stride;
  long pL_head_stride;
  // Optional features — appended at end for backward compatibility.
  float softcap;
  int   window_left;  // -1 = disabled; >=0 = sliding window left radius
  int   window_right; // -1 = disabled; >=0 = sliding window right radius
};

)MFAP";

  // ── Shared templates ─────────────────────────────────────────────────────
  append_steel_shared_templates(ss);

  // ── Compile-time tile constants ──────────────────────────────────────────
  ss << "#define MFA_BQ  " << BQ  << "\n";
  ss << "#define MFA_BK  " << BK  << "\n";
  ss << "#define MFA_BD  " << BD  << "\n";
  ss << "#define MFA_WM  " << WM  << "\n";
  ss << "#define MFA_WN  " << WN  << "\n";
  ss << "#define MFA_TGP_SIZE  " << TGP_SIZE << "\n";
  ss << "#define MFA_DTYPE  " << dtype_str << "\n";
  ss << "#define MFA_TD  " << TD << "\n";
  ss << "#define MFA_TK  " << TK << "\n";
  ss << "#define MFA_TQ  " << TQ << "\n";
  ss << "#define MFA_ROWS_PT  " << TQ << "\n";
  ss << "\n";

  // ── Kernel function ──────────────────────────────────────────────────────
  ss << "[[kernel, max_total_threads_per_threadgroup(MFA_TGP_SIZE)]]\n";
  ss << "void mlx_mfa_flash_decode_partial(\n";
  ss << "    const device MFA_DTYPE* Q  [[buffer(0)]],\n";
  ss << "    const device MFA_DTYPE* K  [[buffer(1)]],\n";
  ss << "    const device MFA_DTYPE* V  [[buffer(2)]],\n";
  ss << "    device MFA_DTYPE*       pO [[buffer(3)]],\n";
  ss << "    device float*           pL [[buffer(4)]],\n";
  ss << "    const constant MFAFlashDecodePartialParams* p [[buffer(5)]],\n";
  if (has_alibi)
    ss << "    const device float* alibi_slopes [[buffer(6)]],\n";
  ss << "    uint simd_lane_id  [[thread_index_in_simdgroup]],\n";
  ss << "    uint simd_group_id [[simdgroup_index_in_threadgroup]],\n";
  ss << "    uint3 tid          [[threadgroup_position_in_grid]])\n";
  ss << "{\n";
  ss << "  typedef MFA_DTYPE T;\n";
  ss << "  typedef float     AccT;\n";
  ss << "\n";

  // Extract split_id and q_tile_id from tid.x
  ss << "  // tid.x = split_id * NQ + q_tile_id\n";
  ss << "  const uint split_id  = (uint)tid.x / (uint)p->NQ;\n";
  ss << "  const uint q_tile_id = (uint)tid.x % (uint)p->NQ;\n";
  ss << "\n";

  // Pointer offsets: q_tile_id for Q/O, head+batch for K/V
  ss << "  const ulong boff = (ulong)tid.z * p->Q_strides[0]\n";
  ss << "                   + (ulong)tid.y * p->Q_strides[1];\n";
  ss << "  const ulong kv_head = (uint)tid.y / (uint)p->gqa_factor;\n";
  ss << "  const ulong kv_boff_k = (ulong)tid.z * p->K_strides[0]\n";
  ss << "                        + kv_head      * p->K_strides[1];\n";
  ss << "  const ulong kv_boff_v = (ulong)tid.z * p->V_strides[0]\n";
  ss << "                        + kv_head      * p->V_strides[1];\n";
  ss << "\n";
  ss << "  Q += boff + (ulong)q_tile_id * MFA_BQ * p->Q_strides[2];\n";
  ss << "  K += kv_boff_k;\n";
  ss << "  V += kv_boff_v;\n";
  ss << "\n";

  // pO and pL output pointers with split offset
  ss << "  pO += (long)split_id     * p->pO_split_stride\n";
  ss << "      + (long)tid.z        * p->pO_batch_stride\n";
  ss << "      + (long)tid.y        * p->pO_head_stride\n";
  ss << "      + (long)q_tile_id    * MFA_BQ * p->D;\n";
  ss << "  pL += (long)split_id     * p->pL_split_stride\n";
  ss << "      + (long)tid.z        * p->pL_batch_stride\n";
  ss << "      + (long)tid.y        * p->pL_head_stride\n";
  ss << "      + (long)q_tile_id    * MFA_BQ;\n";
  ss << "\n";

  // Threadgroup memory (same as STEEL)
  ss << "  constexpr short padQ  = 16 / sizeof(T);\n";
  ss << "  constexpr short padK  = 16 / sizeof(T);\n";
  ss << "  constexpr short padV  = 16 / sizeof(T);\n";
  ss << "  constexpr short LDQ   = MFA_BD + padQ;\n";
  ss << "  constexpr short LDK   = MFA_BK + padK;\n";
  ss << "  constexpr short LDV   = MFA_BD + padV;\n";
  ss << "  constexpr short kv_s0 = (MFA_BK + padK) * MFA_BD;\n";
  ss << "  constexpr short kv_s1 = MFA_BK * (MFA_BD + padV);\n";
  ss << "  constexpr short kv_s  = kv_s0 > kv_s1 ? kv_s0 : kv_s1;\n";
  ss << "  threadgroup T Q_smem[MFA_BQ * (MFA_BD + 16/sizeof(T))];\n";
  ss << "  threadgroup T KV_smem[kv_s];\n";
  ss << "  threadgroup T* Qs = Q_smem;\n";
  ss << "  threadgroup T* Ks = KV_smem;\n";
  ss << "  threadgroup T* Vs = KV_smem;\n";
  ss << "\n";

  // Loaders
  ss << "  using QLoader = MFABlockLoaderT<T, MFA_BQ, MFA_BD,\n";
  ss << "      /*kDstStrRow=*/ MFA_BD + 16/sizeof(T),\n";
  ss << "      /*kDstStrCol=*/ 1, /*reduction_dim=*/ 1,\n";
  ss << "      /*tgp_size=*/ MFA_TGP_SIZE>;\n";
  ss << "  using KLoader = MFABlockLoaderT<T, MFA_BK, MFA_BD,\n";
  ss << "      /*kDstStrRow=*/ 1,\n";
  ss << "      /*kDstStrCol=*/ MFA_BK + 16/sizeof(T), /*reduction_dim=*/ 0,\n";
  ss << "      /*tgp_size=*/ MFA_TGP_SIZE>;\n";
  ss << "  using VLoader = MFABlockLoaderT<T, MFA_BK, MFA_BD,\n";
  ss << "      /*kDstStrRow=*/ MFA_BD + 16/sizeof(T),\n";
  ss << "      /*kDstStrCol=*/ 1, /*reduction_dim=*/ 0,\n";
  ss << "      /*tgp_size=*/ MFA_TGP_SIZE>;\n";
  ss << "\n";
  ss << "  QLoader loader_q(Q, (int)p->Q_strides[2], Qs,\n";
  ss << "                   (ushort)simd_group_id, (ushort)simd_lane_id);\n";
  ss << "  KLoader loader_k(K, (int)p->K_strides[2], Ks,\n";
  ss << "                   (ushort)simd_group_id, (ushort)simd_lane_id);\n";
  ss << "  VLoader loader_v(V, (int)p->V_strides[2], Vs,\n";
  ss << "                   (ushort)simd_group_id, (ushort)simd_lane_id);\n";
  ss << "\n";

  // MMA tile state
  ss << "  const AccT scale = p->scale * M_LOG2E_F;\n";
  ss << "  const short2 simd_coord = MFAMMAFrag<AccT>::get_coord((ushort)simd_lane_id);\n";
  ss << "  const short sm = simd_coord.y;\n";
  ss << "  const short sn = simd_coord.x;\n";
  ss << "  const short tm = 8 * MFA_TQ * (short)simd_group_id;\n";
  ss << "  const short Qs_off = (tm + sm) * LDQ + sn;\n";
  ss << "  const short Ks_off = sm * LDK + sn;\n";
  ss << "  const short Vs_off = sm * LDV + sn;\n";
  ss << "\n";
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD> Qtile;\n";
  ss << "  MFAMMATile<AccT, 1,     MFA_TK>  Ktile;\n";
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TK> Stile;\n";
  ss << "  MFAMMATile<AccT, 1,    1>        Vtile;\n";
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD> Otile;\n";
  ss << "  Otile.clear();\n";
  ss << "\n";

  // Online softmax state
  ss << "  AccT max_score[MFA_ROWS_PT];\n";
  ss << "  AccT sum_score[MFA_ROWS_PT];\n";
  ss << "  STEEL_PRAGMA_UNROLL\n";
  ss << "  for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "    max_score[i] = -INFINITY;\n";
  ss << "    sum_score[i] = 0.0f;\n";
  ss << "  }\n";
  ss << "\n";

  // Load Q (safe for boundary tile, unsafe otherwise)
  ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "  if ((int)q_tile_id == p->NQ_aligned) {\n";
  ss << "    loader_q.load_safe(short2(MFA_BD, p->qL_rem));\n";
  ss << "  } else {\n";
  ss << "    loader_q.load_unsafe();\n";
  ss << "  }\n";
  ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "  Qtile.template load<T, 1, 1>(&Qs[Qs_off], LDQ, 1);\n";
  ss << "\n";

  // K-loop bounds: [kb_start, kb_lim) where kb_lim respects causal + split end + window.
  ss << "  const int kb_split_start = (int)split_id * p->NK_per_split;\n";
  ss << "  const int kb_end   = min(kb_split_start + p->NK_per_split, p->NK_total);\n";
  if (causal) {
    // qL_off positions the query globally; causal mask: col <= row
    ss << "  const int q_max    = (int)q_tile_id * MFA_BQ + p->qL_off + MFA_BQ;\n";
    ss << "  const int kb_causal_lim = (q_max + MFA_BK - 1) / MFA_BK;\n";
    ss << "  int kb_lim   = min(kb_causal_lim, kb_end);\n";
  } else {
    ss << "  int kb_lim   = kb_end;\n";
  }
  // Sliding window: per-Q-tile kb_start (left) and kb_lim clamp (right).
  if (has_window) {
    ss << "  const int q_min = (int)q_tile_id * MFA_BQ + p->qL_off;\n";
    // Left bound
    ss << "  int kb_start, kb_last_win;\n";
    ss << "  if (p->window_left >= 0) {\n";
    ss << "    const int win_start = q_min - p->window_left;\n";
    ss << "    const int kb_win_start = win_start > 0 ? win_start / MFA_BK : 0;\n";
    ss << "    kb_start = max(kb_split_start, kb_win_start);\n";
    ss << "    kb_last_win = (q_min + MFA_BQ - 1 > p->window_left)\n";
    ss << "                    ? (q_min + MFA_BQ - 1 - p->window_left) / MFA_BK : -1;\n";
    ss << "  } else {\n";
    ss << "    kb_start = kb_split_start;\n";
    ss << "    kb_last_win = -1;\n";
    ss << "  }\n";
    // Right bound
    ss << "  int kb_first_right;\n";
    ss << "  if (p->window_right >= 0) {\n";
    ss << "    int kb_right_lim = (q_min + MFA_BQ - 1 + p->window_right) / MFA_BK + 1;\n";
    ss << "    if (kb_right_lim < kb_lim) kb_lim = kb_right_lim;\n";
    ss << "    if (kb_lim < kb_start) kb_lim = kb_start;\n";
    ss << "    kb_first_right = (q_min + p->window_right + 1) / MFA_BK;\n";
    ss << "    if (kb_first_right < kb_start) kb_first_right = kb_start;\n";
    ss << "  } else {\n";
    ss << "    kb_first_right = kb_lim;\n";
    ss << "  }\n";
  } else {
    ss << "  const int kb_start = kb_split_start;\n";
    ss << "  const int kb_last_win = -1;\n";
    ss << "  const int kb_first_right = kb_lim;\n";
  }
  ss << "\n";

  // Advance K/V loaders to kb_start
  ss << "  // Advance K/V loaders to kb_start (split offset + window offset).\n";
  ss << "  for (int kb = 0; kb < kb_start; kb++) {\n";
  ss << "    loader_k.next();\n";
  ss << "    loader_v.next();\n";
  ss << "  }\n";
  ss << "\n";

  // Main K/V loop
  ss << "  for (int kb = kb_start; kb < kb_lim; kb++) {\n";
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    if (kb == p->NK_aligned) {\n";
  ss << "      loader_k.load_safe(short2(MFA_BD, p->kL_rem));\n";
  ss << "    } else {\n";
  ss << "      loader_k.load_unsafe();\n";
  ss << "    }\n";
  ss << "\n";
  // Q @ K^T
  ss << "    Stile.clear();\n";
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short dd = 0; dd < MFA_TD; dd++) {\n";
  ss << "      Ktile.template load<T, 1, 1>(\n";
  ss << "          &Ks[Ks_off + (short)(dd * 8) * LDK], LDK, 1);\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short iq = 0; iq < MFA_TQ; iq++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short ik = 0; ik < MFA_TK; ik++) {\n";
  ss << "          MFAMMAFrag<AccT>::mma(\n";
  ss << "              Stile.frag_at(iq, ik),\n";
  ss << "              Qtile.frag_at(iq, dd),\n";
  ss << "              Ktile.frag_at(0, ik),\n";
  ss << "              Stile.frag_at(iq, ik));\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "    // Scale (log2-domain)\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short ii = 0; ii < MFA_TQ * MFA_TK * 2; ii++)\n";
  ss << "      Stile.elems()[ii] *= scale;\n";
  ss << "\n";

  // Softcapping (Gemma 2 / Grok) — same log2↔natural conversion as STEEL fwd
  if (key.has_softcap) {
    ss << "    // Softcapping: tanh(S_nat / cap) * cap, convert log2 <-> natural\n";
    ss << "    {\n";
    ss << "      constexpr AccT log2e = 1.4426950408889634f;\n";
    ss << "      constexpr AccT ln2   = 0.6931471805599453f;\n";
    ss << "      const AccT cap   = p->softcap;\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short ii = 0; ii < MFA_TQ * MFA_TK * 2; ii++) {\n";
    ss << "        AccT s_nat = Stile.elems()[ii] * ln2;   // log2 → natural\n";
    ss << "        s_nat = precise::tanh(s_nat / cap) * cap;\n";
    ss << "        Stile.elems()[ii] = s_nat * log2e;       // natural → log2\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }

  // ALiBi per-head position bias (same formula as STEEL fwd)
  if (has_alibi) {
    ss << "    // ALiBi: add per-head linear position bias to scores\n";
    ss << "    {\n";
    ss << "      constexpr AccT log2e = 1.4426950408889634f;\n";
    ss << "      const AccT slope = alibi_slopes[(int)tid.y] * log2e;\n";
    // q_tile_id is already defined earlier in flash decode partial as (tid.x % NQ)
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int q_pos = (int)q_tile_id * MFA_BQ + p->qL_off + (int)tm + (int)sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int k_base = kb * MFA_BK + (int)sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            Stile.frag_at(i, j)[jj] += slope * (float)(k_base + jj - q_pos);\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }

  // Mask padding in last K-tile
  ss << "    if (kb == p->NK_aligned) {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
  ss << "          const short col = sn + j * 8;\n";
  ss << "          STEEL_PRAGMA_UNROLL\n";
  ss << "          for (short jj = 0; jj < 2; jj++) {\n";
  ss << "            if ((col + jj) >= p->kL_rem)\n";
  ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
  ss << "          }\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "\n";

  // Causal mask
  if (causal) {
    ss << "    if (kb >= (kb_causal_lim - (MFA_BQ + MFA_BK - 1) / MFA_BK)) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = (int)q_tile_id * MFA_BQ + p->qL_off\n";
    ss << "                      + tm + sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if (row < (col + jj))\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }
  // Window boundary masks for flash decode partial
  if (has_window) {
    // Left: mask k < q - window_left for tiles in [kb_start, kb_last_win]
    ss << "    if (kb <= kb_last_win) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = (int)q_tile_id * MFA_BQ + p->qL_off\n";
    ss << "                      + tm + sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if ((col + jj) < row - p->window_left)\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
    // Right: mask k > q + window_right for tiles >= kb_first_right
    ss << "    if (kb >= kb_first_right) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = (int)q_tile_id * MFA_BQ + p->qL_off\n";
    ss << "                      + tm + sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if ((col + jj) > row + p->window_right)\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }

  // Load V during softmax
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    if (kb == p->NK_aligned) {\n";
  ss << "      loader_v.load_safe(short2(MFA_BD, p->kL_rem));\n";
  ss << "    } else {\n";
  ss << "      loader_v.load_unsafe();\n";
  ss << "    }\n";
  ss << "\n";

  // Online softmax update
  ss << "    AccT new_max[MFA_ROWS_PT];\n";
  ss << "    AccT factor[MFA_ROWS_PT];\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) new_max[i] = max_score[i];\n";
  ss << "    Stile.template row_reduce<MFAMaxOp>(new_max);\n";
  ss << "    Stile.template row_bin_op<MFAExpSubOp>(new_max);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      factor[i] = fast::exp2(max_score[i] - new_max[i]);\n";
  ss << "      max_score[i] = new_max[i];\n";
  ss << "    }\n";
  ss << "    AccT sum_tmp[MFA_ROWS_PT] = {0};\n";
  ss << "    Stile.template row_reduce<MFASumOp>(sum_tmp);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      sum_score[i] = sum_score[i] * factor[i] + sum_tmp[i];\n";
  ss << "    }\n";
  ss << "\n";

  // Rescale O and accumulate P@V  (same loop structure as original STEEL kernel)
  // Loop order: iq → ik → id (id innermost: D scan with cache-friendly V_smem access)
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    Otile.template row_bin_op<MFAMulOp>(factor);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short iq = 0; iq < MFA_TQ; iq++) {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short ik = 0; ik < MFA_TK; ik++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short id = 0; id < MFA_TD; id++) {\n";
  ss << "          Vtile.template load<T, 1, 1>(\n";
  ss << "              &Vs[Vs_off + ik*8*LDV + id*8], LDV, 1);\n";
  ss << "          MFAMMAFrag<AccT>::mma(\n";
  ss << "              Otile.frag_at(iq, id),\n";
  ss << "              Stile.frag_at(iq, ik),\n";
  ss << "              Vtile.frag_at(0, 0),\n";
  ss << "              Otile.frag_at(iq, id));\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "\n";
  ss << "    loader_k.next();\n";
  ss << "    loader_v.next();\n";
  ss << "  } // end kb loop\n";
  ss << "\n";

  // Normalize pO and store
  ss << "  Otile.template row_bin_op<MFADivOp>(sum_score);\n";
  ss << "  threadgroup_barrier(mem_flags::mem_none);\n";
  ss << "\n";
  ss << "  pO += (long)(tm + sm) * p->D + sn;\n";
  ss << "  if ((int)q_tile_id == p->NQ_aligned) {\n";
  ss << "    auto dims = short2((short)(MFA_BD - sn),\n";
  ss << "                       (short)(p->qL_rem - (tm + sm)));\n";
  ss << "    if (dims.x > 0 && dims.y > 0)\n";
  ss << "      Otile.template store_safe<T, 1, 1>(pO, (int)p->D, dims);\n";
  ss << "  } else {\n";
  ss << "    Otile.template store<T, 1, 1>(pO, (int)p->D);\n";
  ss << "  }\n";
  ss << "\n";

  // Write pL (log2-domain logsumexp)
  ss << "  if (sn == 0) {\n";
  ss << "    const long q_base = (long)q_tile_id * MFA_BQ + tm + sm;\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      const long q_idx = q_base + i * 8;\n";
  ss << "      if (q_idx < p->qL) {\n";
  ss << "        pL[q_idx] = max_score[i] + metal::log2(sum_score[i]);\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "  }\n";
  ss << "}\n";

  return ss.str();
}

// =========================================================================
// Flash Decoding Phase 2: generate_flash_decode_reduce_source
//
// Kernel "mlx_mfa_flash_decode_reduce"
// Grid: (N, H, B) — one thread-column per query position, head, batch.
// Threadgroup: reduce_tgp_size threads (= min(D, 128)) parallelize over D.
//
// Combines partial outputs pO[s] and LSE pL[s] via:
//   lse_max = max_s(pL_s)
//   w_s     = exp2(pL_s - lse_max)
//   sum_w   = Σ w_s
//   O_final = Σ (w_s / sum_w) * pO_s    (in D-parallel threads)
//   L_final = lse_max + log2(sum_w)      (written by thread 0)
// =========================================================================

std::string generate_flash_decode_reduce_source(const ShaderCache::KernelKey& key) {
  const int BD = key.head_dim;
  const char* dtype_str = "half";
  if (key.dtype == 1)      dtype_str = "bfloat";
  else if (key.dtype == 2) dtype_str = "float";

  const int reduce_tgp = std::min(BD, 128);

  std::ostringstream ss;

  ss << "#include <metal_stdlib>\n";
  ss << "using namespace metal;\n\n";

  ss << "struct MFAFlashDecodeReduceParams {\n";
  ss << "  int B, H, D;\n";
  ss << "  int qL;\n";
  ss << "  int num_splits;\n";
  ss << "  long pO_split_stride;\n";
  ss << "  long pO_batch_stride;\n";
  ss << "  long pO_head_stride;\n";
  ss << "  long pL_split_stride;\n";
  ss << "  long pL_batch_stride;\n";
  ss << "  long pL_head_stride;\n";
  ss << "  long O_batch_stride;\n";
  ss << "  long O_head_stride;\n";
  ss << "  long L_batch_stride;\n";
  ss << "  long L_head_stride;\n";
  ss << "  int reduce_tgp_size;\n";
  ss << "};\n\n";

  ss << "#define MFA_DTYPE " << dtype_str << "\n";
  ss << "#define REDUCE_TGP " << reduce_tgp << "\n\n";

  ss << "[[kernel]]\n";
  ss << "void mlx_mfa_flash_decode_reduce(\n";
  ss << "    const device MFA_DTYPE*  pO [[buffer(0)]],\n";
  ss << "    const device float*      pL [[buffer(1)]],\n";
  ss << "    device MFA_DTYPE*         O [[buffer(2)]],\n";
  ss << "    device float*             L [[buffer(3)]],\n";
  ss << "    const constant MFAFlashDecodeReduceParams* p [[buffer(4)]],\n";
  ss << "    uint3 tid [[threadgroup_position_in_grid]],\n";
  ss << "    uint  d   [[thread_index_in_threadgroup]])\n";
  ss << "{\n";
  ss << "  // tid.x = q_idx, tid.y = head_idx, tid.z = batch_idx\n";
  ss << "  const long q_idx = (long)tid.x;\n";
  ss << "  const long h_idx = (long)tid.y;\n";
  ss << "  const long b_idx = (long)tid.z;\n";
  ss << "\n";
  ss << "  if (q_idx >= p->qL) return;\n";
  ss << "\n";
  ss << "  // Per-position base offsets in pL: stride over (split, batch, head, qL)\n";
  ss << "  const long pL_bh_base = b_idx * p->pL_batch_stride\n";
  ss << "                        + h_idx * p->pL_head_stride\n";
  ss << "                        + q_idx;\n";
  ss << "  const long pO_bh_base = b_idx * p->pO_batch_stride\n";
  ss << "                        + h_idx * p->pO_head_stride\n";
  ss << "                        + q_idx * p->D;\n";
  ss << "\n";
  ss << "  // Pass 1: find max logsumexp across splits\n";
  ss << "  float lse_max = -INFINITY;\n";
  ss << "  for (int s = 0; s < p->num_splits; s++) {\n";
  ss << "    float lse = pL[s * p->pL_split_stride + pL_bh_base];\n";
  ss << "    lse_max = metal::max(lse_max, lse);\n";
  ss << "  }\n";
  ss << "\n";
  ss << "  // Pass 2: compute sum of weights\n";
  ss << "  float sum_w = 0.0f;\n";
  ss << "  for (int s = 0; s < p->num_splits; s++) {\n";
  ss << "    float lse = pL[s * p->pL_split_stride + pL_bh_base];\n";
  ss << "    sum_w += metal::exp2(lse - lse_max);\n";
  ss << "  }\n";
  ss << "\n";
  ss << "  // Pass 3: accumulate weighted pO across splits (parallelized over D)\n";
  ss << "  for (int dd = (int)d; dd < p->D; dd += REDUCE_TGP) {\n";
  ss << "    float acc = 0.0f;\n";
  ss << "    for (int s = 0; s < p->num_splits; s++) {\n";
  ss << "      float lse = pL[s * p->pL_split_stride + pL_bh_base];\n";
  ss << "      float w   = metal::exp2(lse - lse_max) / sum_w;\n";
  ss << "      long  src = s * p->pO_split_stride + pO_bh_base + dd;\n";
  ss << "      acc += w * (float)pO[src];\n";
  ss << "    }\n";
  ss << "    long dst = b_idx * p->O_batch_stride\n";
  ss << "             + h_idx * p->O_head_stride\n";
  ss << "             + q_idx * p->D + dd;\n";
  ss << "    O[dst] = (MFA_DTYPE)acc;\n";
  ss << "  }\n";
  ss << "\n";
  ss << "  // Thread 0 writes final L = lse_max + log2(sum_w)\n";
  ss << "  if (d == 0) {\n";
  ss << "    long l_dst = b_idx * p->L_batch_stride\n";
  ss << "               + h_idx * p->L_head_stride\n";
  ss << "               + q_idx;\n";
  ss << "    L[l_dst] = lse_max + metal::log2(sum_w);\n";
  ss << "  }\n";
  ss << "}\n";

  return ss.str();
}

// =========================================================================
// STEEL Varlen Forward
// =========================================================================
// Grid: (total_q_tiles, H, 1) — one threadgroup per Q-tile across ALL seqs.
// tile_offsets[s] = cumulative Q-tile count for sequences 0..s-1.
// Each threadgroup linearly scans tile_offsets[] to find its sequence.
std::string generate_steel_varlen_forward_source(const ShaderCache::KernelKey& key) {
  const int BD = key.head_dim;
  const int BQ = key.block_q;
  const int BK = key.block_k;
  const int WM = key.n_warps;
  const bool causal = key.causal;
  const bool is_m3_plus = key.is_m3_plus;

  const char* dtype_str = "half";
  if (key.dtype == 1)      dtype_str = "bfloat";
  else if (key.dtype == 2) dtype_str = "float";

  const int arch_gen = is_m3_plus ? 15 : 13;
  const int TGP_SIZE = WM * 32;
  const int ROWS_PT = BQ / (WM * 8);

  std::ostringstream ss;

  // ── Preamble ────────────────────────────────────────────────────────────
  ss << R"MFA(
#include <metal_stdlib>
#include <metal_simdgroup>
#include <metal_simdgroup_matrix>
using namespace metal;
#define STEEL_CONST static constant constexpr const
)MFA";
  ss << "#define ARCHITECTURE_GEN " << arch_gen << "\n";
  ss << "#define STEEL_PRAGMA_UNROLL";
  if ((BD <= 128) || is_m3_plus) ss << R"MFA( _Pragma("clang loop unroll(full)")
)MFA";
  else ss << "\n";
  ss << "\n";

  // ── Params struct ────────────────────────────────────────────────────────
  ss << R"MFA(
struct MFASteelVarlenParams {
  int H, D;
  int gqa_factor;
  int num_seqs;
  int total_q;
  int total_kv;
  int total_q_tiles;
  float scale;
  float softcap;
  long Q_head_stride;
  long K_head_stride;
};
)MFA";

  // ── Shared templates ─────────────────────────────────────────────────────
  append_steel_shared_templates(ss);

  // ── Compile-time constants ───────────────────────────────────────────────
  ss << "#define MFA_DTYPE  " << dtype_str << "\n";
  ss << "#define MFA_BQ     " << BQ << "\n";
  ss << "#define MFA_BK     " << BK << "\n";
  ss << "#define MFA_BD     " << BD << "\n";
  ss << "#define MFA_PAD    (16/sizeof(MFA_DTYPE))\n";
  ss << "#define MFA_TGP    " << TGP_SIZE << "\n";
  ss << "#define MFA_TQ     " << (BQ / (WM * 8)) << "\n";  // rows per warp (= ROWS_PT)
  ss << "#define MFA_TK     " << (BK / 8) << "\n";
  ss << "#define MFA_TD     " << (BD / 8) << "\n";
  ss << "#define MFA_ROWS_PT " << ROWS_PT << "\n\n";

  // ── Kernel signature ──────────────────────────────────────────────────────
  ss << "kernel void mlx_mfa_steel_varlen_forward(\n";
  ss << "    const device MFA_DTYPE* Q   [[buffer(0)]],\n";
  ss << "    const device MFA_DTYPE* K   [[buffer(1)]],\n";
  ss << "    const device MFA_DTYPE* V   [[buffer(2)]],\n";
  ss << "    device MFA_DTYPE*       O   [[buffer(3)]],\n";
  ss << "    device float*           L   [[buffer(4)]],\n";
  ss << "    const constant MFASteelVarlenParams* p [[buffer(5)]],\n";
  ss << "    const device int* cu_seqlens_q  [[buffer(6)]],\n";
  ss << "    const device int* cu_seqlens_k  [[buffer(7)]],\n";
  ss << "    const device int* tile_offsets  [[buffer(8)]],\n";
  ss << "    uint simd_lane_id  [[thread_index_in_simdgroup]],\n";
  ss << "    uint simd_group_id [[simdgroup_index_in_threadgroup]],\n";
  ss << "    uint3 tid          [[threadgroup_position_in_grid]])\n";
  ss << "{\n";
  ss << "  typedef MFA_DTYPE T;\n";
  ss << "  typedef float     AccT;\n\n";

  // ── Find sequence for this Q-tile ─────────────────────────────────────────
  ss << "  const int global_q_tile = (int)tid.x;\n";
  ss << "  int seq_id = p->num_seqs - 1;\n";
  ss << "  for (int s = 0; s < p->num_seqs - 1; s++) {\n";
  ss << "    if (global_q_tile < tile_offsets[s + 1]) { seq_id = s; break; }\n";
  ss << "  }\n";
  ss << "  const int local_tile_id = global_q_tile - tile_offsets[seq_id];\n";
  ss << "  const int q_start = cu_seqlens_q[seq_id];\n";
  ss << "  const int q_end   = cu_seqlens_q[seq_id + 1];\n";
  ss << "  const int k_start = cu_seqlens_k[seq_id];\n";
  ss << "  const int k_end   = cu_seqlens_k[seq_id + 1];\n";
  ss << "  const int qL_local   = q_end - q_start;\n";
  ss << "  const int kL_local   = k_end - k_start;\n";
  ss << "  const int NK_local   = (kL_local + MFA_BK - 1) / MFA_BK;\n";
  ss << "  const int NK_aligned = kL_local / MFA_BK;\n";
  ss << "  const int kL_rem     = kL_local % MFA_BK;\n";
  ss << "  const int NQ_aligned = qL_local / MFA_BQ;\n";
  ss << "  const int qL_rem     = qL_local % MFA_BQ;\n\n";

  // ── Pointer setup ──────────────────────────────────────────────────────────
  ss << "  const int kv_head = (int)tid.y / p->gqa_factor;\n";
  ss << "  Q += (long)tid.y  * p->Q_head_stride + (long)(q_start + local_tile_id * MFA_BQ) * MFA_BD;\n";
  ss << "  K += (long)kv_head * p->K_head_stride + (long)k_start * MFA_BD;\n";
  ss << "  V += (long)kv_head * p->K_head_stride + (long)k_start * MFA_BD;\n";
  ss << "  O += (long)tid.y  * p->Q_head_stride + (long)(q_start + local_tile_id * MFA_BQ) * MFA_BD;\n";
  ss << "  L += (long)tid.y  * p->total_q + q_start;\n\n";

  // ── Thread layout (mirrors reference STEEL forward) ────────────────────────
  ss << "  const AccT scale = p->scale * M_LOG2E_F;\n";
  ss << "  const short2 simd_coord = MFAMMAFrag<AccT>::get_coord((ushort)simd_lane_id);\n";
  ss << "  const short sm = simd_coord.y;\n";
  ss << "  const short sn = simd_coord.x;\n";
  ss << "  const short tm = 8 * MFA_TQ * (short)simd_group_id;\n\n";

  // ── SMEM — K transposed, V row-major (shared buffer) ─────────────────────
  ss << "  constexpr short padQ  = MFA_PAD;\n";
  ss << "  constexpr short padKV = MFA_PAD;\n";
  ss << "  constexpr short LDQ   = MFA_BD  + padQ;\n";
  ss << "  constexpr short LDK   = MFA_BK  + padKV;\n"; // transposed K: stride = BK+pad
  ss << "  constexpr short LDV   = MFA_BD  + padKV;\n"; // row-major V: stride = BD+pad
  ss << "  constexpr short kv_s0 = (MFA_BK + padKV) * MFA_BD;\n";  // transposed K size
  ss << "  constexpr short kv_s1 = MFA_BK * (MFA_BD + padKV);\n";  // row-major V size
  ss << "  constexpr short kv_s  = kv_s0 > kv_s1 ? kv_s0 : kv_s1;\n";
  ss << "  threadgroup T Q_smem[MFA_BQ * (MFA_BD + padQ)];\n";
  ss << "  threadgroup T KV_smem[kv_s];\n";
  ss << "  threadgroup T* Qs = Q_smem;\n";
  ss << "  threadgroup T* Ks = KV_smem;\n";
  ss << "  threadgroup T* Vs = KV_smem;\n\n";

  // ── Block loaders (same template params as reference STEEL forward) ────────
  ss << "  // Q loader: row-major into TGP\n";
  ss << "  using QLoader = MFABlockLoaderT<T, MFA_BQ, MFA_BD,\n";
  ss << "      MFA_BD + padQ, 1, 1, MFA_TGP>;\n";
  ss << "  // K loader: transposed into TGP (column-major K, d_col-first)\n";
  ss << "  using KLoader = MFABlockLoaderT<T, MFA_BK, MFA_BD,\n";
  ss << "      1, MFA_BK + padKV, 0, MFA_TGP>;\n";
  ss << "  // V loader: row-major into TGP\n";
  ss << "  using VLoader = MFABlockLoaderT<T, MFA_BK, MFA_BD,\n";
  ss << "      MFA_BD + padKV, 1, 0, MFA_TGP>;\n";
  ss << "  QLoader loader_q(Q, MFA_BD, Qs, simd_group_id, simd_lane_id);\n";
  ss << "  KLoader loader_k(K, MFA_BD, Ks, simd_group_id, simd_lane_id);\n";
  ss << "  VLoader loader_v(V, MFA_BD, Vs, simd_group_id, simd_lane_id);\n\n";

  // ── Load Q into TGP → registers ────────────────────────────────────────────
  ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "  if (local_tile_id == NQ_aligned && qL_rem > 0) {\n";
  ss << "    loader_q.load_safe(short2(MFA_BD, (short)qL_rem));\n";
  ss << "  } else {\n";
  ss << "    loader_q.load_unsafe();\n";
  ss << "  }\n";
  ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n\n";

  // ── Thread coordinates (same as reference STEEL forward) ──────────────────
  ss << "  const short Qs_off = (tm + sm) * LDQ + sn;\n";
  ss << "  const short Ks_off = sm * LDK + sn;\n";
  ss << "  const short Vs_off = sm * LDV + sn;\n\n";
  // ── Register tiles ────────────────────────────────────────────────────────
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD> Qtile;\n";
  ss << "  MFAMMATile<AccT, 1,      MFA_TK> Ktile;\n";
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TK> Stile;\n";
  ss << "  MFAMMATile<AccT, 1,      1>      Vtile;\n";
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD> Otile;\n\n";

  // Load Q into registers (single tile load — MFAMMATile::load iterates over all frags)
  ss << "  Otile.clear();\n";
  ss << "  Qtile.template load<T, 1, 1>(&Qs[Qs_off], LDQ, 1);\n\n";

  // Online softmax state
  ss << "  AccT max_score[MFA_ROWS_PT];\n";
  ss << "  AccT sum_score[MFA_ROWS_PT];\n";
  ss << "  STEEL_PRAGMA_UNROLL\n";
  ss << "  for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "    max_score[i] = -INFINITY; sum_score[i] = 0.0f;\n";
  ss << "  }\n\n";

  // ── K-loop ────────────────────────────────────────────────────────────────
  ss << "  for (int kb = 0; kb < NK_local; kb++) {\n";
  // Barrier at the START of each iteration ensures the previous iteration's P@V
  // reads from KV_smem (V) are complete before we overwrite KV_smem with new K.
  // This matches the reference STEEL forward's barrier pattern exactly.
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    // Load K tile\n";
  ss << "    if (kb == NK_aligned) {\n";
  ss << "      loader_k.load_safe(short2(MFA_BD, (short)kL_rem));\n";
  ss << "    } else {\n";
  ss << "      loader_k.load_unsafe();\n";
  ss << "    }\n";
  // Stile.clear() here runs in parallel with K loading by other SIMDs.
  // The barrier below ensures K is fully written before S computation reads it.

  // S = Q @ K^T  (Q in registers; K loaded one D-slice at a time from TGP)
  ss << "    // S = Q @ K^T\n";
  ss << "    Stile.clear();\n";
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short dd = 0; dd < MFA_TD; dd++) {\n";
  ss << "      Ktile.template load<T, 1, 1>(\n";
  ss << "          &Ks[Ks_off + (short)(dd * 8) * LDK], LDK, 1);\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short iq = 0; iq < MFA_TQ; iq++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short ik = 0; ik < MFA_TK; ik++) {\n";
  ss << "          MFAMMAFrag<AccT>::mma(\n";
  ss << "              Stile.frag_at(iq, ik),\n";
  ss << "              Qtile.frag_at(iq, dd),\n";
  ss << "              Ktile.frag_at(0, ik),\n";
  ss << "              Stile.frag_at(iq, ik));\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "    // Apply scale (log2 domain)\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short ii = 0; ii < MFA_TQ * MFA_TK * 2; ii++) {\n";
  ss << "      Stile.elems()[ii] *= scale;\n";
  ss << "    }\n\n";

  // K-boundary mask: mask padded K positions in the last (partial) K-tile.
  // Without this, zero-filled K rows produce S=0 scores that contribute
  // exp(0 - max_score) to sum_score, corrupting normalization for all Q rows.
  ss << "    // KBOUNDARY_MASK_V1: Mask padded K positions\n";
  ss << "    if (kb == NK_aligned && kL_rem > 0) {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
  ss << "          const short col = (short)(sn + j * 8);\n";
  ss << "          STEEL_PRAGMA_UNROLL\n";
  ss << "          for (short jj = 0; jj < 2; jj++) {\n";
  ss << "            if ((col + jj) >= kL_rem)\n";
  ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
  ss << "          }\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n\n";

  // Causal mask
  if (causal) {
    ss << "    // Causal mask (local positions within sequence)\n";
    ss << "    {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = local_tile_id * MFA_BQ + (int)tm + (int)sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + (int)sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if (row < (col + jj))\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n\n";
  }

  // Load V while doing softmax
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    if (kb == NK_aligned) {\n";
  ss << "      loader_v.load_safe(short2(MFA_BD, (short)kL_rem));\n";
  ss << "    } else {\n";
  ss << "      loader_v.load_unsafe();\n";
  ss << "    }\n\n";

  // Online softmax update
  ss << "    // Online softmax\n";
  ss << "    AccT new_max[MFA_ROWS_PT], factor[MFA_ROWS_PT];\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) new_max[i] = max_score[i];\n";
  ss << "    Stile.template row_reduce<MFAMaxOp>(new_max);\n";
  ss << "    Stile.template row_bin_op<MFAExpSubOp>(new_max);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      factor[i] = fast::exp2(max_score[i] - new_max[i]);\n";
  ss << "      max_score[i] = new_max[i];\n";
  ss << "    }\n";
  ss << "    AccT sum_tmp[MFA_ROWS_PT] = {0};\n";
  ss << "    Stile.template row_reduce<MFASumOp>(sum_tmp);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      sum_score[i] = sum_score[i] * factor[i] + sum_tmp[i];\n";
  ss << "    }\n";
  ss << "    Otile.template row_bin_op<MFAMulOp>(factor);\n\n";

  // P @ V
  ss << "    // O += P @ V\n";
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short iq = 0; iq < MFA_TQ; iq++) {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short ik = 0; ik < MFA_TK; ik++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short id = 0; id < MFA_TD; id++) {\n";
  ss << "          Vtile.template load<T, 1, 1>(\n";
  ss << "              &Vs[Vs_off + ik*8*LDV + id*8], LDV, 1);\n";
  ss << "          MFAMMAFrag<AccT>::mma(\n";
  ss << "              Otile.frag_at(iq, id),\n";
  ss << "              Stile.frag_at(iq, ik),\n";
  ss << "              Vtile.frag_at(0, 0),\n";
  ss << "              Otile.frag_at(iq, id));\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "    loader_k.next();\n";
  ss << "    loader_v.next();\n";
  ss << "  } // end kb loop\n\n";

  // Normalize + store O
  ss << "  Otile.template row_bin_op<MFADivOp>(sum_score);\n";
  ss << "  threadgroup_barrier(mem_flags::mem_none);\n\n";
  ss << "  O += (long)(tm + sm) * MFA_BD + sn;\n";
  ss << "  if (local_tile_id == NQ_aligned && qL_rem > 0) {\n";
  ss << "    auto dims = short2((short)(MFA_BD - sn), (short)(qL_rem - (tm + sm)));\n";
  ss << "    if (dims.x > 0 && dims.y > 0)\n";
  ss << "      Otile.template store_safe<T, 1, 1>(O, MFA_BD, dims);\n";
  ss << "  } else {\n";
  ss << "    Otile.template store<T, 1, 1>(O, MFA_BD);\n";
  ss << "  }\n\n";

  // Write L (logsumexp)
  ss << "  if (sn == 0) {\n";
  ss << "    const long q_base = (long)(local_tile_id * MFA_BQ + tm + sm);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      const long q_idx = q_base + i * 8;\n";
  ss << "      if (q_idx < qL_local) {\n";
  ss << "        L[q_idx] = max_score[i] + metal::log2(sum_score[i]);\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "  }\n";
  ss << "}\n";

  return ss.str();
}

// ===========================================================================
// generate_paged_steel_forward_source — Track FD
// ===========================================================================
//
// Generates Metal kernel "mlx_mfa_paged_attention".
// Key differences vs generate_steel_forward_source:
//   • buffer(1)/buffer(2) = k_pool/v_pool [num_blocks, block_size, H_kv, D]
//   • buffer(3) = block_table [B, max_blocks] int32
//   • buffer(4) = seq_lens [B] int32 (per-batch effective kL)
//   • K/V loading: per-token cooperative gather; K transposed, V row-major
//   • Double-buffer disabled (per-token gather cannot pipeline)
//   • kL_batch = seq_lens[b_idx] drives masking; kL in params = global max

std::string generate_paged_steel_forward_source(const ShaderCache::KernelKey& key) {
  const int BD = key.head_dim;
  const int BQ = key.block_q;
  const int BK = key.block_k;
  const int WM = key.n_warps;
  const int WN = 1;
  const int TGP_SIZE = WM * WN * 32;
  const bool causal     = key.causal;
  const bool has_window = key.has_window;
  // elems per thread for BK×BD cooperative K/V gather
  const int kv_tile_elems    = BK * BD;
  const int elems_per_thread = (kv_tile_elems + TGP_SIZE - 1) / TGP_SIZE;

  const char* dtype_str = "half";
  if (key.dtype == 1)      dtype_str = "bfloat";
  else if (key.dtype == 2) dtype_str = "float";
  const int arch_gen = key.is_m3_plus ? 15 : 13;

  std::ostringstream ss;

  // ── Preamble ─────────────────────────────────────────────────────────────
  ss << R"MFA(
#include <metal_stdlib>
#include <metal_simdgroup>
#include <metal_simdgroup_matrix>
using namespace metal;

#define STEEL_CONST static constant constexpr const
)MFA";
  ss << "#define ARCHITECTURE_GEN " << arch_gen << "\n";
  ss << "#define STEEL_PRAGMA_UNROLL";
  bool enable_unroll = (BD <= 128) || key.is_m3_plus;
  if (enable_unroll) ss << R"MFA( _Pragma("clang loop unroll(full)")
)MFA";
  else ss << "\n";
  ss << "\n";

  // ── MFAPagedSteelParams (Metal side — layout MUST match C++ struct) ───
  ss << R"MFA(
struct MFAPagedSteelParams {
  int B, H, D;
  int qL, kL;
  int gqa_factor;
  float scale;
  int NQ, NK;
  int NQ_aligned;
  int NK_aligned;
  int qL_rem;
  int kL_rem;
  int qL_off;
  int rope_q_base;
  int rope_cos_stride;
  long Q_strides[3];
  long O_strides[3];
  long L_strides[2];
  float softcap;
  int   has_alibi;
  int   window_left;
  int   window_right;
  int block_size;
  int max_blocks;
  int pool_block_stride;
  int pool_tok_stride;
  int H_kv;
};

)MFA";

  // ── Op structs ────────────────────────────────────────────────────────
  ss << R"MFA(
struct MFAMaxOp {
  template <typename T> METAL_FUNC static T apply(T x, T y) { return metal::max(x, y); }
};
struct MFASumOp {
  template <typename T> METAL_FUNC static T apply(T x, T y) { return x + y; }
};
struct MFAMulOp {
  template <typename T> METAL_FUNC static T apply(T x, T y) { return x * y; }
};
struct MFADivOp {
  template <typename T> METAL_FUNC static T apply(T x, T y) { return x / y; }
};
struct MFAExpSubOp {
  template <typename T> METAL_FUNC static T apply(T x, T y) { return fast::exp2(x - y); }
};

)MFA";

  // ── Compile-time tile constants ───────────────────────────────────────
  ss << "#define MFA_BQ  " << BQ  << "\n";
  ss << "#define MFA_BK  " << BK  << "\n";
  ss << "#define MFA_BD  " << BD  << "\n";
  ss << "#define MFA_WM  " << WM  << "\n";
  ss << "#define MFA_WN  " << WN  << "\n";
  ss << "#define MFA_TGP_SIZE  " << TGP_SIZE << "\n";
  ss << "#define MFA_DTYPE  " << dtype_str << "\n";
  ss << "\n";

  const int TD = BD / 8;
  const int TK = BK / 8;
  const int TQ = BQ / (WM * WN * 8);
  const int kRowsPT = TQ;

  ss << "#define MFA_TD  " << TD << "\n";
  ss << "#define MFA_TK  " << TK << "\n";
  ss << "#define MFA_TQ  " << TQ << "\n";
  ss << "#define MFA_ROWS_PT  " << kRowsPT << "\n";
  ss << "\n";

  // ── MFABlockLoaderT (Q only) ──────────────────────────────────────────
  ss << R"MFA(
template <
    typename T, short BROWS, short BCOLS,
    short kDstStrRow, short kDstStrCol, short reduction_dim, short tgp_size,
    short n_reads = (BCOLS * BROWS) / tgp_size,
    short TCOLS = BCOLS / n_reads,
    short TROWS = tgp_size / TCOLS>
struct MFABlockLoaderT {
  STEEL_CONST short vec_size = n_reads;
  const int src_ld;
  const int tile_stride;
  const short thread_idx;
  const short bi, bj;
  threadgroup T* dst;
  const device T* src;

  METAL_FUNC MFABlockLoaderT(const device T* src_, const int src_ld_,
      threadgroup T* dst_, ushort simd_group_id, ushort simd_lane_id)
      : src_ld(src_ld_),
        tile_stride(reduction_dim ? BCOLS : BROWS * src_ld_),
        thread_idx(simd_group_id * 32 + simd_lane_id),
        bi(thread_idx / TCOLS),
        bj(vec_size * (thread_idx % TCOLS)),
        dst(dst_ + bi * kDstStrRow + bj * kDstStrCol),
        src(src_ + bi * src_ld_ + bj) {}

  METAL_FUNC void load_unsafe() const {
    constexpr bool can_vectorize = (kDstStrCol == 1) && (vec_size % 4 == 0);
    if constexpr (can_vectorize) {
      using vec4_t = vec<T, 4>;
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j += 4)
          *(threadgroup vec4_t*)(dst + i * kDstStrRow + j) =
              *(const device vec4_t*)(src + i * src_ld + j);
      }
    } else {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j++)
          dst[i * kDstStrRow + j * kDstStrCol] = src[i * src_ld + j];
      }
    }
  }

  METAL_FUNC void load_safe(short2 src_tile_dim) const {
    src_tile_dim = src_tile_dim - short2(bj, bi);
    if (src_tile_dim.x <= 0 || src_tile_dim.y <= 0) {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j++)
          dst[i * kDstStrRow + j * kDstStrCol] = T(0);
      }
      return;
    }
    bool tmp_idx[vec_size];
    T tmp_val[vec_size];
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++)
        tmp_idx[j] = (i < src_tile_dim.y) && (j < src_tile_dim.x);
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++)
        tmp_val[j] = src[(tmp_idx[j] ? i * src_ld + j : 0)];
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++)
        tmp_val[j] = tmp_idx[j] ? tmp_val[j] : T(0);
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++)
        dst[i * kDstStrRow + j * kDstStrCol] = tmp_val[j];
    }
  }

  METAL_FUNC void next() { src += tile_stride; }
};

)MFA";

  // ── MFAMMAFrag / MFAMMATile / tile_matmad ────────────────────────────
  ss << R"MFA(
template <typename T>
struct MFAMMAFrag {
  STEEL_CONST int kElemRows = 1;
  STEEL_CONST int kElemCols = 2;
  typedef simdgroup_matrix<T, 8, 8> mat_type;
  typedef vec<T, 2> frag_type;

  METAL_FUNC static short2 get_coord(ushort lane_id) {
    const short qid = lane_id / 4;
    const short fm  = (qid & 4) + ((lane_id / 2) % 4);
    const short fn  = (qid & 2) * 2 + (lane_id % 2) * 2;
    return short2{fn, fm};
  }
  template <typename SrcPtr, typename StrX, typename StrY>
  METAL_FUNC static void load(thread frag_type& dst, SrcPtr src, StrX str_x, StrY str_y) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kElemRows; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kElemCols; j++)
        dst[i * kElemCols + j] = static_cast<T>(src[i * str_x + j * str_y]);
    }
  }
  template <typename Op>
  METAL_FUNC static void row_reduce(thread const frag_type& inp, thread T* out) {
    T thr = Op::apply(inp.x, inp.y);
    T qr  = Op::apply(thr, simd_shuffle_xor(thr, ushort(1)));
    T sr  = Op::apply(qr,  simd_shuffle_xor(qr,  ushort(8)));
    out[0] = Op::apply(out[0], sr);
  }
  template <typename Op>
  METAL_FUNC static void row_bin_op(thread frag_type& inp, thread T* row_vals) {
    STEEL_PRAGMA_UNROLL
    for (short j = 0; j < kElemCols; j++)
      inp[j] = Op::apply(inp[j], row_vals[0]);
  }
  METAL_FUNC static void mma(thread frag_type& D, thread frag_type& A,
                              thread frag_type& B, thread frag_type& C) {
    mat_type Dm, Am, Bm, Cm;
    reinterpret_cast<thread frag_type&>(Am.thread_elements()) = A;
    reinterpret_cast<thread frag_type&>(Bm.thread_elements()) = B;
    reinterpret_cast<thread frag_type&>(Cm.thread_elements()) = C;
    simdgroup_multiply_accumulate(Dm, Am, Bm, Cm);
    D = reinterpret_cast<thread frag_type&>(Dm.thread_elements());
  }
};

template <typename T, int kTileRows_, int kTileCols_>
struct MFAMMATile {
  using Frag = MFAMMAFrag<T>;
  STEEL_CONST int kTileRows = kTileRows_;
  STEEL_CONST int kTileCols = kTileCols_;
  STEEL_CONST int kNumFrags  = kTileRows_ * kTileCols_;
  typedef typename Frag::frag_type frag_type;
  frag_type val_frags[kNumFrags];

  METAL_FUNC MFAMMATile() thread {}
  METAL_FUNC void clear() {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kNumFrags; i++) val_frags[i] = frag_type(0);
  }
  METAL_FUNC thread frag_type& frag_at(short i, short j) { return val_frags[i * kTileCols_ + j]; }
  METAL_FUNC const thread frag_type& frag_at(short i, short j) const { return val_frags[i * kTileCols_ + j]; }
  METAL_FUNC thread T* elems() { return reinterpret_cast<thread T*>(val_frags); }

  template <typename Op>
  METAL_FUNC void row_reduce(thread T vals[kTileRows_]) const {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++)
        Frag::template row_reduce<Op>(frag_at(i, j), &vals[i]);
    }
  }
  template <typename Op>
  METAL_FUNC void row_bin_op(thread T vals[kTileRows_]) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++)
        Frag::template row_bin_op<Op>(frag_at(i, j), &vals[i]);
    }
  }
  template <typename U, int w_x, int w_y>
  METAL_FUNC void load(const threadgroup U* src, int str_row, int str_col) {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++)
        Frag::load(frag_at(i, j),
                   &src[(i * 8) * w_x * str_row + (j * 8) * w_y * str_col],
                   str_row, str_col);
    }
  }
  template <typename U, int w_x, int w_y>
  METAL_FUNC void store(device U* dst, const int ld) const {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < kTileCols_; j++) {
        const int base = (i * 8) * w_x * ld + (j * 8) * w_y;
        dst[base] = static_cast<U>(frag_at(i, j)[0]);
        dst[base + 1] = static_cast<U>(frag_at(i, j)[1]);
      }
    }
  }
  template <typename U, int w_x, int w_y>
  METAL_FUNC void store_safe(device U* dst, const int ld, const short2 dims) const {
    STEEL_PRAGMA_UNROLL
    for (int i = 0; i < kTileRows_; i++) {
      STEEL_PRAGMA_UNROLL
      for (int j = 0; j < kTileCols_; j++) {
        const int off_row = (i * 8) * w_x;
        const int off_col = (j * 8) * w_y;
        if (off_row < (int)dims.y) {
          if (off_col     < (int)dims.x) dst[off_row * ld + off_col]     = static_cast<U>(frag_at(i, j)[0]);
          if (off_col + 1 < (int)dims.x) dst[off_row * ld + off_col + 1] = static_cast<U>(frag_at(i, j)[1]);
        }
      }
    }
  }
};

)MFA";

  // ── Kernel function ───────────────────────────────────────────────────
  ss << "[[kernel, max_total_threads_per_threadgroup(MFA_TGP_SIZE)]]\n";
  ss << "void mlx_mfa_paged_attention(\n";
  ss << "    const device MFA_DTYPE* Q              [[buffer(0)]],\n";
  ss << "    const device MFA_DTYPE* k_pool         [[buffer(1)]],\n";
  ss << "    const device MFA_DTYPE* v_pool         [[buffer(2)]],\n";
  ss << "    const device int*       block_table    [[buffer(3)]],\n";
  ss << "    const device int*       seq_lens       [[buffer(4)]],\n";
  ss << "    device MFA_DTYPE*       O              [[buffer(5)]],\n";
  ss << "    device float*           L              [[buffer(6)]],\n";
  ss << "    const constant MFAPagedSteelParams* p  [[buffer(7)]],\n";
  ss << "    uint simd_lane_id  [[thread_index_in_simdgroup]],\n";
  ss << "    uint simd_group_id [[simdgroup_index_in_threadgroup]],\n";
  ss << "    uint3 tid          [[threadgroup_position_in_grid]])\n";
  ss << "{\n";
  ss << "  typedef MFA_DTYPE T;\n";
  ss << "  typedef float     AccT;\n";
  ss << "\n";

  // Indices
  ss << "  const int b_idx   = (int)tid.z;\n";
  ss << "  const int h_idx   = (int)tid.y;\n";
  ss << "  const int kv_head = h_idx / p->gqa_factor;\n";
  ss << "\n";
  // Per-batch KV length
  ss << "  const int kL_batch = seq_lens[b_idx];\n";
  ss << "  const int NK_batch = (kL_batch + MFA_BK - 1) / MFA_BK;\n";
  ss << "\n";
  // Q/O base pointers
  ss << "  const ulong boff = (ulong)b_idx * p->Q_strides[0]\n";
  ss << "                   + (ulong)h_idx * p->Q_strides[1];\n";
  ss << "  Q += boff;\n";
  ss << "  O += (ulong)b_idx * p->O_strides[0]\n";
  ss << "     + (ulong)h_idx * p->O_strides[1];\n";
  ss << "\n";
  // Threadgroup memory
  ss << "  constexpr short padQ  = 16 / sizeof(T);\n";
  ss << "  constexpr short LDQ   = MFA_BD + padQ;\n";
  ss << "  constexpr short LDK   = MFA_BK + 16/sizeof(T);\n";
  ss << "  constexpr short LDV   = MFA_BD + 16/sizeof(T);\n";
  ss << "  constexpr short kv_s0 = LDK * MFA_BD;\n";
  ss << "  constexpr short kv_s1 = MFA_BK * LDV;\n";
  ss << "  constexpr short kv_s  = kv_s0 > kv_s1 ? kv_s0 : kv_s1;\n";
  ss << "\n";
  ss << "  threadgroup T Q_smem[MFA_BQ * LDQ];\n";
  ss << "  threadgroup T KV_smem[kv_s];\n";
  ss << "  threadgroup T* Qs = Q_smem;\n";
  ss << "  threadgroup T* Ks = KV_smem;\n";
  ss << "  threadgroup T* Vs = KV_smem;\n";
  ss << "\n";
  // Q loader
  ss << "  using QLoader = MFABlockLoaderT<T, MFA_BQ, MFA_BD,\n";
  ss << "      /*kDstStrRow=*/ MFA_BD + 16/sizeof(T),\n";
  ss << "      /*kDstStrCol=*/ 1,\n";
  ss << "      /*reduction_dim=*/ 1,\n";
  ss << "      /*tgp_size=*/ MFA_TGP_SIZE>;\n";
  ss << "\n";
  // MMA coordinates
  ss << "  const AccT scale_v = p->scale * M_LOG2E_F;\n";
  ss << "  const short2 simd_coord = MFAMMAFrag<AccT>::get_coord((ushort)simd_lane_id);\n";
  ss << "  const short sm = simd_coord.y;\n";
  ss << "  const short sn = simd_coord.x;\n";
  ss << "  const short tm = 8 * MFA_TQ * (short)simd_group_id;\n";
  ss << "  const short Qs_off = (tm + sm) * LDQ + sn;\n";
  ss << "  const short Ks_off = sm * LDK + sn;\n";
  ss << "  const short Vs_off = sm * LDV + sn;\n";
  ss << "  const int thread_idx = (int)simd_group_id * 32 + (int)simd_lane_id;\n";
  ss << "\n";
  // Tile register declarations
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD> Qtile;\n";
  ss << "  MFAMMATile<AccT, 1,     MFA_TK>  Ktile;\n";
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TK> Stile;\n";
  ss << "  MFAMMATile<AccT, 1,    1>        Vtile;\n";
  ss << "  MFAMMATile<AccT, MFA_TQ, MFA_TD> Otile;\n";
  ss << "  AccT max_score[MFA_ROWS_PT];\n";
  ss << "  AccT sum_score[MFA_ROWS_PT];\n";
  ss << "\n";
  // Persistent Q-block loop (4 Q-blocks per threadgroup)
  ss << "  const int qb_start = (int)tid.x * 4;\n";
  ss << "  const int qb_end   = min(qb_start + 4, p->NQ);\n";
  ss << "  for (int qb = qb_start; qb < qb_end; qb++) {\n";
  ss << "\n";
  ss << "  const device T* Q_qb = Q + (long)qb * MFA_BQ * p->Q_strides[2];\n";
  ss << "  device T*       O_qb = O + (long)qb * MFA_BQ * p->O_strides[2];\n";
  ss << "  QLoader loader_q(Q_qb, (int)p->Q_strides[2], Qs,\n";
  ss << "                   (ushort)simd_group_id, (ushort)simd_lane_id);\n";
  // Reset accumulator
  ss << "  Otile.clear();\n";
  ss << "  STEEL_PRAGMA_UNROLL\n";
  ss << "  for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "    max_score[i] = -INFINITY;\n";
  ss << "    sum_score[i] = 0.0f;\n";
  ss << "  }\n";
  ss << "\n";
  // Load Q
  ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "  if (qb == p->NQ_aligned) {\n";
  ss << "    loader_q.load_safe(short2(MFA_BD, p->qL_rem));\n";
  ss << "  } else {\n";
  ss << "    loader_q.load_unsafe();\n";
  ss << "  }\n";
  ss << "  threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "  Qtile.template load<T, 1, 1>(&Qs[Qs_off], LDQ, 1);\n";
  ss << "\n";
  // K-loop limit
  if (causal) {
    ss << "  int q_max = (qb + 1) * MFA_BQ + p->qL_off;\n";
    ss << "  int kb_lim = min((q_max + MFA_BK - 1) / MFA_BK, NK_batch);\n";
  } else {
    ss << "  int kb_lim = NK_batch;\n";
  }
  // Sliding window: per-Q-block kb_start (left) and kb_lim clamp (right).
  if (has_window) {
    ss << "  int q_min = qb * MFA_BQ + p->qL_off;\n";
    // Left bound
    ss << "  int kb_start, kb_last_win;\n";
    ss << "  if (p->window_left >= 0) {\n";
    ss << "    int win_start = q_min - p->window_left;\n";
    ss << "    kb_start = win_start > 0 ? win_start / MFA_BK : 0;\n";
    ss << "    kb_last_win = (q_min + MFA_BQ - 1 > p->window_left)\n";
    ss << "                    ? (q_min + MFA_BQ - 1 - p->window_left) / MFA_BK : -1;\n";
    ss << "  } else {\n";
    ss << "    kb_start = 0;\n";
    ss << "    kb_last_win = -1;\n";
    ss << "  }\n";
    // Right bound
    ss << "  int kb_first_right;\n";
    ss << "  if (p->window_right >= 0) {\n";
    ss << "    int kb_right_lim = (q_min + MFA_BQ - 1 + p->window_right) / MFA_BK + 1;\n";
    ss << "    if (kb_right_lim < kb_lim) kb_lim = kb_right_lim;\n";
    ss << "    if (kb_lim < kb_start) kb_lim = kb_start;\n";
    ss << "    kb_first_right = (q_min + p->window_right + 1) / MFA_BK;\n";
    ss << "    if (kb_first_right < kb_start) kb_first_right = kb_start;\n";
    ss << "  } else {\n";
    ss << "    kb_first_right = kb_lim;\n";
    ss << "  }\n";
  } else {
    ss << "  const int kb_start = 0;\n";
    ss << "  const int kb_last_win = -1;\n";
    ss << "  const int kb_first_right = kb_lim;\n";
  }
  ss << "\n";

  // ── Main K-tile loop ──────────────────────────────────────────────────
  ss << "  for (int kb = kb_start; kb < kb_lim; kb++) {\n";

  // ── Paged K gather (transposed: K_smem[d*LDK+t]) ──────────────────────
  ss << "    {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short ei = 0; ei < " << elems_per_thread << "; ei++) {\n";
  ss << "        const int slot = thread_idx + (int)ei * MFA_TGP_SIZE;\n";
  ss << "        if (slot < MFA_BK * MFA_BD) {\n";
  ss << "          const int t = slot % MFA_BK;\n";  // K-seq within tile (transposed)
  ss << "          const int d = slot / MFA_BK;\n";  // head-dim index
  ss << "          const int global_tok = kb * MFA_BK + t;\n";
  ss << "          T val = T(0);\n";
  ss << "          if (global_tok < kL_batch) {\n";
  ss << "            const int blk_idx    = global_tok / p->block_size;\n";
  ss << "            const int tok_in_blk = global_tok % p->block_size;\n";
  ss << "            const int phys = block_table[b_idx * p->max_blocks + blk_idx];\n";
  ss << "            val = k_pool[(long)phys * p->pool_block_stride\n";
  ss << "                        + tok_in_blk * p->pool_tok_stride\n";
  ss << "                        + kv_head * p->D + d];\n";
  ss << "          }\n";
  ss << "          Ks[d * LDK + t] = val;\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "\n";

  // ── Q@K^T GEMM → Stile ────────────────────────────────────────────────
  ss << "    Stile.clear();\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short dd = 0; dd < MFA_TD; dd++) {\n";
  ss << "      Ktile.template load<T, 1, 1>(\n";
  ss << "          &Ks[Ks_off + (short)(dd * 8) * LDK], LDK, 1);\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short iq = 0; iq < MFA_TQ; iq++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short ik = 0; ik < MFA_TK; ik++) {\n";
  ss << "          MFAMMAFrag<AccT>::mma(\n";
  ss << "              Stile.frag_at(iq, ik),\n";
  ss << "              Qtile.frag_at(iq, dd),\n";
  ss << "              Ktile.frag_at(0, ik),\n";
  ss << "              Stile.frag_at(iq, ik));\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "\n";

  // Scale
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short ii = 0; ii < MFA_TQ * MFA_TK * 2; ii++) {\n";
  ss << "      Stile.elems()[ii] *= scale_v;\n";
  ss << "    }\n";
  ss << "\n";

  // K-boundary mask (per-batch: positions >= kL_batch)
  ss << "    if ((kb + 1) * MFA_BK > kL_batch) {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
  ss << "          const int k_base = kb * MFA_BK + sn + j * 8;\n";
  ss << "          STEEL_PRAGMA_UNROLL\n";
  ss << "          for (short jj = 0; jj < 2; jj++) {\n";
  ss << "            if ((k_base + jj) >= kL_batch)\n";
  ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
  ss << "          }\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "\n";

  // Causal mask: mask k > q (where q position includes qL_off)
  // The first K-tile requiring causal masking is the one containing the
  // first query's causal boundary: (qb * BQ + qL_off) / BK.
  // For the paged kernel, qL_off accounts for N_q < S_kv positioning.
  if (causal) {
    ss << "    {\n";
    ss << "      const int first_causal_kb = (qb * MFA_BQ + p->qL_off) / MFA_BK;\n";
    ss << "      if (kb >= first_causal_kb) {\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "          const int row = qb * MFA_BQ + p->qL_off + tm + sm + i * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "            const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "            STEEL_PRAGMA_UNROLL\n";
    ss << "            for (short jj = 0; jj < 2; jj++) {\n";
    ss << "              if (row < (col + jj)) Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "            }\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }
  // Window boundary masks
  if (has_window) {
    // Left: mask k < q - window_left
    ss << "    if (kb <= kb_last_win) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = qb * MFA_BQ + p->qL_off + tm + sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if ((col + jj) < row - p->window_left)\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
    // Right: mask k > q + window_right
    ss << "    if (kb >= kb_first_right) {\n";
    ss << "      STEEL_PRAGMA_UNROLL\n";
    ss << "      for (short i = 0; i < MFA_TQ; i++) {\n";
    ss << "        const int row = qb * MFA_BQ + p->qL_off + tm + sm + i * 8;\n";
    ss << "        STEEL_PRAGMA_UNROLL\n";
    ss << "        for (short j = 0; j < MFA_TK; j++) {\n";
    ss << "          const int col = kb * MFA_BK + sn + j * 8;\n";
    ss << "          STEEL_PRAGMA_UNROLL\n";
    ss << "          for (short jj = 0; jj < 2; jj++) {\n";
    ss << "            if ((col + jj) > row + p->window_right)\n";
    ss << "              Stile.frag_at(i,j)[jj] = -INFINITY;\n";
    ss << "          }\n";
    ss << "        }\n";
    ss << "      }\n";
    ss << "    }\n";
    ss << "\n";
  }

  // Barrier before V load (K-GEMM done; safe to overwrite KV_smem)
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "\n";

  // ── Paged V gather (row-major: V_smem[t*LDV+d]) ──────────────────────
  ss << "    {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short ei = 0; ei < " << elems_per_thread << "; ei++) {\n";
  ss << "        const int slot = thread_idx + (int)ei * MFA_TGP_SIZE;\n";
  ss << "        if (slot < MFA_BK * MFA_BD) {\n";
  ss << "          const int t = slot / MFA_BD;\n";  // K-seq within tile
  ss << "          const int d = slot % MFA_BD;\n";  // head-dim index
  ss << "          const int global_tok = kb * MFA_BK + t;\n";
  ss << "          T val = T(0);\n";
  ss << "          if (global_tok < kL_batch) {\n";
  ss << "            const int blk_idx    = global_tok / p->block_size;\n";
  ss << "            const int tok_in_blk = global_tok % p->block_size;\n";
  ss << "            const int phys = block_table[b_idx * p->max_blocks + blk_idx];\n";
  ss << "            val = v_pool[(long)phys * p->pool_block_stride\n";
  ss << "                        + tok_in_blk * p->pool_tok_stride\n";
  ss << "                        + kv_head * p->D + d];\n";
  ss << "          }\n";
  ss << "          Vs[t * LDV + d] = val;\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "\n";

  // Online softmax (NaN-safe)
  ss << "    AccT new_max[MFA_ROWS_PT];\n";
  ss << "    AccT factor[MFA_ROWS_PT];\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) new_max[i] = max_score[i];\n";
  ss << "    Stile.template row_reduce<MFAMaxOp>(new_max);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      if (new_max[i] > max_score[i]) {\n";
  ss << "        factor[i] = fast::exp2(max_score[i] - new_max[i]);\n";
  ss << "        max_score[i] = new_max[i];\n";
  ss << "      } else {\n";
  ss << "        factor[i] = 1.0f;\n";
  ss << "        new_max[i] = metal::isinf(max_score[i]) ? (AccT)0.0f : max_score[i];\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "    Stile.template row_bin_op<MFAExpSubOp>(new_max);\n";
  ss << "    AccT sum_tmp[MFA_ROWS_PT] = {0};\n";
  ss << "    Stile.template row_reduce<MFASumOp>(sum_tmp);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      sum_score[i] = sum_score[i] * factor[i] + sum_tmp[i];\n";
  ss << "    }\n";
  ss << "    Otile.template row_bin_op<MFAMulOp>(factor);\n";
  ss << "\n";

  // P @ V
  ss << "    threadgroup_barrier(mem_flags::mem_threadgroup);\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short iq = 0; iq < MFA_TQ; iq++) {\n";
  ss << "      STEEL_PRAGMA_UNROLL\n";
  ss << "      for (short ik = 0; ik < MFA_TK; ik++) {\n";
  ss << "        STEEL_PRAGMA_UNROLL\n";
  ss << "        for (short id = 0; id < MFA_TD; id++) {\n";
  ss << "          Vtile.template load<T, 1, 1>(\n";
  ss << "              &Vs[Vs_off + ik*8*LDV + id*8], LDV, 1);\n";
  ss << "          MFAMMAFrag<AccT>::mma(\n";
  ss << "              Otile.frag_at(iq, id),\n";
  ss << "              Stile.frag_at(iq, ik),\n";
  ss << "              Vtile.frag_at(0, 0),\n";
  ss << "              Otile.frag_at(iq, id));\n";
  ss << "        }\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "\n";
  ss << "  } // end kb loop\n";
  ss << "\n";

  // Normalize O and store
  ss << "  Otile.template row_bin_op<MFADivOp>(sum_score);\n";
  ss << "  threadgroup_barrier(mem_flags::mem_none);\n";
  ss << "\n";
  ss << "  device T* O_write = O_qb + (long)(tm + sm) * p->O_strides[2] + sn;\n";
  ss << "  if (qb == p->NQ_aligned) {\n";
  ss << "    auto dims = short2((short)(MFA_BD - sn), (short)(p->qL_rem - (tm + sm)));\n";
  ss << "    if (dims.x > 0 && dims.y > 0)\n";
  ss << "      Otile.template store_safe<T, 1, 1>(O_write, (int)p->O_strides[2], dims);\n";
  ss << "  } else {\n";
  ss << "    Otile.template store<T, 1, 1>(O_write, (int)p->O_strides[2]);\n";
  ss << "  }\n";
  ss << "\n";

  // Write L (log2-domain logsumexp)
  ss << "  if (sn == 0) {\n";
  ss << "    const long l_boff = (long)b_idx * p->L_strides[0]\n";
  ss << "                      + (long)h_idx * p->L_strides[1];\n";
  ss << "    const long q_base = (long)qb * MFA_BQ + tm + sm;\n";
  ss << "    STEEL_PRAGMA_UNROLL\n";
  ss << "    for (short i = 0; i < MFA_ROWS_PT; i++) {\n";
  ss << "      const long q_idx = q_base + i * 8;\n";
  ss << "      if (q_idx < p->qL) {\n";
  ss << "        L[l_boff + q_idx] = max_score[i] + metal::log2(sum_score[i]);\n";
  ss << "      }\n";
  ss << "    }\n";
  ss << "  }\n";
  ss << "\n";

  ss << "  } // end qb loop\n";
  ss << "}\n";

  return ss.str();
}

}  // namespace mlx_mfa
