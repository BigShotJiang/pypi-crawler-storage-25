"""MCP server for moodle-study-kit.

Exposes tools:
    - list_courses
    - get_deadlines
    - get_course_contents
    - get_week_materials
    - search_course_content
    - get_weekly_summary

Requires the ``mcp`` extra: pip install moodle-study-kit[mcp]
"""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from moodle_study_kit.client import MoodleClient
from moodle_study_kit.config import MoodleConfig
from moodle_study_kit.deadlines import get_upcoming_deadlines
from moodle_study_kit.extraction import extract_file_text
from moodle_study_kit.materials import (
    get_section_materials,
    search_course_content as _search_content,
)
from moodle_study_kit.summaries import (
    build_summary,
    find_best_section,
    format_bullets,
    get_downloadable_files,
)

mcp = FastMCP("moodle-study-kit")

# Lazily initialised so the server module can be imported without
# credentials (e.g. for tests or tooling introspection).
_client: MoodleClient | None = None


def _get_client() -> MoodleClient:
    global _client
    if _client is None:
        _client = MoodleClient(MoodleConfig.load())
    return _client


@mcp.tool()
def list_courses() -> str:
    """List all Moodle courses the authenticated user is enrolled in."""
    courses = _get_client().get_courses()
    return json.dumps(courses, indent=2)


@mcp.tool()
def get_deadlines(lookahead_days: int = 14) -> str:
    """Return upcoming assignment and quiz deadlines sorted by due date.

    Parameters
    ----------
    lookahead_days : int
        How many days ahead to look (default 14).
    """
    deadlines = get_upcoming_deadlines(_get_client(), lookahead_days=lookahead_days)
    return json.dumps(deadlines, indent=2)


@mcp.tool()
def get_course_contents(course_id: int) -> str:
    """Return all sections and modules for a specific course.

    Parameters
    ----------
    course_id : int
        The Moodle course ID.
    """
    contents = _get_client().get_course_contents(course_id)
    return json.dumps(contents, indent=2)


@mcp.tool()
def get_week_materials(course_id: int, week: str) -> str:
    """Discover downloadable materials for a specific teaching week of a course.

    Parameters
    ----------
    course_id : int
        The Moodle course ID.
    week : str
        Week number (e.g. "1") or a substring to match against section names
        (e.g. "Revision"). Numeric matching is based on explicit week-like
        labels in section names, not Moodle's raw section slot number.
    """
    sections = _get_client().get_course_contents(course_id)
    materials = get_section_materials(sections, course_id, week)
    return json.dumps(materials, indent=2)


@mcp.tool()
def search_course_content(course_id: int, query: str) -> str:
    """Search section and module names within a course.

    Useful for finding where a topic lives without knowing the week number.

    Parameters
    ----------
    course_id : int
        The Moodle course ID.
    query : str
        Case-insensitive search term to match against section and module names.
    """
    sections = _get_client().get_course_contents(course_id)
    results = _search_content(sections, query)
    return json.dumps(results, indent=2)


@mcp.tool()
def get_weekly_summary(course_id: int, week: int) -> str:
    """Generate a study summary for a specific teaching week of a course.

    Finds the best matching section, extracts text from downloadable
    materials, and returns deterministic bullet-point study notes with
    appropriate fallbacks for reading weeks, revision weeks, exam periods,
    and weeks with no materials.

    Parameters
    ----------
    course_id : int
        The Moodle course ID.
    week : int
        The teaching week number.
    """
    client = _get_client()
    sections = client.get_course_contents(course_id)
    section, section_type, section_name = find_best_section(sections, week)

    file_texts: list[tuple[str, str]] = []
    if section and section.get("modules"):
        files = get_downloadable_files(section["modules"])
        for finfo in files:
            url = finfo["fileurl"]
            if not url:
                continue
            data = client.download_file(url)
            if data:
                text = extract_file_text(data, finfo["filename"], clean=True)
                if text:
                    file_texts.append((finfo["filename"], text))

    result = build_summary(file_texts, section_type=section_type)
    result["section_name"] = section_name
    result["week"] = week
    result["course_id"] = course_id
    result["formatted"] = format_bullets(result["bullets"])
    return json.dumps(result, indent=2)


def main() -> None:
    """Entry point when running ``python -m moodle_study_kit.mcp_server``."""
    mcp.run()


if __name__ == "__main__":
    main()
