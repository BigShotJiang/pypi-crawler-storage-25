"""moodle-study-kit — Read-only Moodle toolkit."""

__version__ = "0.2.2"

from moodle_study_kit.client import (
    ALLOWED_FUNCTIONS,
    BLOCKED_PATTERNS,
    MoodleClient,
    MoodleWriteAttemptError,
)
from moodle_study_kit.config import DEFAULT_CONFIG_PATH, MoodleConfig, test_connection
from moodle_study_kit.deadlines import get_upcoming_deadlines
from moodle_study_kit.extraction import (
    FILE_PRIORITY,
    SUPPORTED_EXTENSIONS,
    clean_text,
    extract_file_text,
    is_boilerplate,
    strip_html,
)
from moodle_study_kit.materials import (
    extract_materials,
    get_section_materials,
    match_section,
    search_course_content,
)
from moodle_study_kit.summaries import (
    build_deterministic_summary,
    build_summary,
    classify_section,
    fallback_bullets,
    find_best_section,
    format_bullets,
    get_downloadable_files,
    score_section_match,
    summarize_modules,
)

__all__ = [
    "__version__",
    "ALLOWED_FUNCTIONS",
    "BLOCKED_PATTERNS",
    "DEFAULT_CONFIG_PATH",
    "FILE_PRIORITY",
    "MoodleClient",
    "MoodleConfig",
    "MoodleWriteAttemptError",
    "SUPPORTED_EXTENSIONS",
    "build_deterministic_summary",
    "build_summary",
    "classify_section",
    "clean_text",
    "extract_file_text",
    "extract_materials",
    "fallback_bullets",
    "find_best_section",
    "format_bullets",
    "get_downloadable_files",
    "get_section_materials",
    "get_upcoming_deadlines",
    "is_boilerplate",
    "match_section",
    "score_section_match",
    "search_course_content",
    "strip_html",
    "summarize_modules",
    "test_connection",
]
