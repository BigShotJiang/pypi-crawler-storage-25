"""Course content traversal and material discovery.

Navigates Moodle course sections/modules and extracts structured,
agent-friendly metadata for downloadable files and resources.

All operations are read-only — no Moodle writes, no file downloads.
"""

from __future__ import annotations

import re


# ── Week / section matching ──────────────────────────────────────

_WEEK_PATTERNS = [
    re.compile(r"\bweek\s*0*(\d+)\b", re.IGNORECASE),
    re.compile(r"\bwk\s*0*(\d+)\b", re.IGNORECASE),
    re.compile(r"\btopic\s*0*(\d+)\b", re.IGNORECASE),
    re.compile(r"\bsession\s*0*(\d+)\b", re.IGNORECASE),
    re.compile(r"\blecture\s*0*(\d+)\b", re.IGNORECASE),
]


def extract_week_number(section_name: str) -> int | None:
    """Extract a week/topic number from a section name, or None."""
    for pattern in _WEEK_PATTERNS:
        m = pattern.search(section_name)
        if m:
            return int(m.group(1))
    return None


def match_section(section: dict, query: int | str) -> bool:
    """Test whether *section* matches a week-like query.

    Parameters
    ----------
    section : dict
        A Moodle section dict (from ``core_course_get_contents``).
    query : int | str
        * ``int`` or numeric ``str`` — matches a week/topic number extracted
          from the section name.
        * non-numeric ``str`` — case-insensitive substring match on the
          section name.

    Notes
    -----
    For numeric queries we intentionally do *not* match Moodle's raw
    ``section`` index. In real courses those indices often represent layout
    order rather than teaching week, which can make ``week=1`` pull unrelated
    sections like "Using Generative AI" simply because they sit in slot 1.
    """
    name = section.get("name", "")

    if isinstance(query, str):
        stripped = query.strip()
        if not stripped:
            return False
        try:
            query = int(stripped)
        except ValueError:
            return stripped.lower() in name.lower()

    extracted = extract_week_number(name)
    return extracted is not None and extracted == query


# ── Material record builder ──────────────────────────────────────


def _build_material(
    course_id: int,
    section: dict,
    module: dict,
    file_info: dict | None = None,
) -> dict:
    """Build one structured material record.

    If *file_info* is provided the record describes a specific file
    inside a module's ``contents`` array.  Otherwise it describes the
    module itself (e.g. a URL resource with no file list).
    """
    module_id = module.get("id", 0)

    if file_info:
        file_name = file_info.get("filename", "")
        file_url = file_info.get("fileurl", "")
        file_size = file_info.get("filesize", 0)
        mime_type = file_info.get("mimetype", "")
        time_modified = file_info.get("timemodified", 0)
        dedupe_key = f"{module_id}:{file_name}"
    else:
        file_name = ""
        file_url = module.get("url", "")
        file_size = 0
        mime_type = ""
        time_modified = module.get("added", 0)
        dedupe_key = f"{module_id}:"

    return {
        "course_id": course_id,
        "section_id": section.get("id", 0),
        "section_name": section.get("name", ""),
        "section_num": section.get("section", 0),
        "module_id": module_id,
        "module_name": module.get("name", ""),
        "module_type": module.get("modname", ""),
        "file_name": file_name,
        "file_url": file_url,
        "file_size": file_size,
        "mime_type": mime_type,
        "time_modified": time_modified,
        "dedupe_key": dedupe_key,
    }


# ── Extraction helpers ───────────────────────────────────────────


def extract_materials(
    sections: list[dict],
    course_id: int,
    *,
    dedupe: bool = True,
) -> list[dict]:
    """Extract material records from Moodle course sections.

    Parameters
    ----------
    sections : list[dict]
        Raw sections from ``core_course_get_contents``.
    course_id : int
        Included in every record for cross-course context.
    dedupe : bool
        Suppress duplicates sharing the same ``dedupe_key``.

    Returns
    -------
    list[dict]
        Material records in section order.
    """
    materials: list[dict] = []
    seen: set[str] = set()

    for section in sections:
        for module in section.get("modules", []):
            contents = module.get("contents", [])

            if contents:
                for file_info in contents:
                    # Moodle contents can be type "file", "url", or "content".
                    # We want files and URL entries, not raw HTML bodies.
                    if file_info.get("type", "") not in ("file", "url"):
                        continue

                    record = _build_material(course_id, section, module, file_info)

                    if dedupe and record["dedupe_key"] in seen:
                        continue
                    seen.add(record["dedupe_key"])
                    materials.append(record)

            elif module.get("modname", "") in ("url", "page"):
                # Module has no contents array but is itself a link or page.
                record = _build_material(course_id, section, module)

                if dedupe and record["dedupe_key"] in seen:
                    continue
                seen.add(record["dedupe_key"])
                materials.append(record)

    return materials


def get_section_materials(
    sections: list[dict],
    course_id: int,
    week: int | str,
    *,
    dedupe: bool = True,
) -> list[dict]:
    """Get materials for sections matching *week*.

    Combines :func:`match_section` filtering with :func:`extract_materials`.
    """
    matching = [s for s in sections if match_section(s, week)]
    return extract_materials(matching, course_id, dedupe=dedupe)


def search_course_content(
    sections: list[dict],
    query: str,
) -> list[dict]:
    """Search section and module names for *query* (case-insensitive).

    Returns lightweight module-level dicts with section context.
    Useful for agents that need to locate a topic without knowing the
    week number.
    """
    needle = query.lower()
    results: list[dict] = []
    seen_ids: set[int] = set()

    for section in sections:
        sec_name = section.get("name", "")
        sec_hit = needle in sec_name.lower()

        for module in section.get("modules", []):
            mod_id = module.get("id", 0)
            mod_name = module.get("name", "")

            if sec_hit or needle in mod_name.lower():
                if mod_id not in seen_ids:
                    seen_ids.add(mod_id)
                    results.append({
                        "section_name": sec_name,
                        "section_num": section.get("section", 0),
                        "module_id": mod_id,
                        "module_name": mod_name,
                        "module_type": module.get("modname", ""),
                        "module_url": module.get("url", ""),
                    })

    return results
