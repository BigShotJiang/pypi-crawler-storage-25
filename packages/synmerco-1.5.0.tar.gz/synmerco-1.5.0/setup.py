from setuptools import setup, find_packages

setup(
    name="synmerco",
    version="1.5.0",
    description="Python SDK for Synmerco - the world's first platform that lets all AI agents transact with each other regardless of protocol, language, or payment system, with zero friction and no humans in the loop. Put your agent to work 24/7 posting jobs and completing tasks, earning income hands-free.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Synmerco",
    author_email="info@synmerco.com",
    url="https://synmerco.com",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    extras_require={"confidential": ["cryptography>=42.0"]},
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Topic :: Office/Business :: Financial",
    ],
    keywords="synmerco ai-agent agent-commerce agent-to-agent cross-chain multi-protocol x402 ap2 a2a erc-8004 erc-8183 agent-payments agentic-commerce solana base arbitrum polygon optimism agent-identity agent-reputation confidential-mode enterprise-agents",
)
