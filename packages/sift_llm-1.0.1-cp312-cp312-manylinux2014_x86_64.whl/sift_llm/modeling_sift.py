"""
SIFT — Selective Intelligence Filtering Transformer
HuggingFace Modeling
"""

import torch
import torch.nn as nn
from transformers import PreTrainedModel
from transformers.modeling_outputs import CausalLMOutputWithPast

# Kendi yazdığımız dosyaları içeri aktarıyoruz
from .configuration_sift import SiftConfig
from .model import SIFTModel


class SiftPreTrainedModel(PreTrainedModel):
    """
    Tüm SIFT modelleri için temel sınıf. 
    Ağırlıkların başlatılması ve temel HuggingFace işlevlerini devralır.
    """
    config_class = SiftConfig
    base_model_prefix = "model"
    supports_gradient_checkpointing = True

    def _init_weights(self, module):
        std = self.config.initializer_range
        if isinstance(module, nn.Linear):
            module.weight.data.normal_(mean=0.0, std=std)
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.Embedding):
            module.weight.data.normal_(mean=0.0, std=std)
            if module.padding_idx is not None:
                module.weight.data[module.padding_idx].zero_()


class SiftForCausalLM(SiftPreTrainedModel):
    """
    Dil modellemesi (Metin Üretimi) için SIFT modeli.
    LlamaForCausalLM veya PhiForCausalLM gibi çalışır.
    """
    def __init__(self, config: SiftConfig):
        super().__init__(config)
        
        # Orijinal SIFT çekirdek mimarisini config'den gelen değerlerle başlatıyoruz
        self.model = SIFTModel(
            vocab_size=config.vocab_size,
            hidden_dim=config.hidden_dim,
            num_layers=config.num_layers,
            num_heads=config.num_heads,
            num_kv_heads=config.num_kv_heads,
            max_seq_len=config.max_seq_len,
            ffn_mult=config.ffn_mult,
            rope_theta=config.rope_theta,
            yarn_scale_factor=config.yarn_scale_factor,
            yarn_beta_fast=config.yarn_beta_fast,
            yarn_beta_slow=config.yarn_beta_slow,
        )
        
        # Hugging Face ağırlık ilklendirme fonksiyonunu çağırır
        self.post_init()

    def get_input_embeddings(self):
        return self.model.embedding

    def set_input_embeddings(self, value):
        self.model.embedding = value

    def get_output_embeddings(self):
        return self.model.lm_head

    def set_output_embeddings(self, new_embeddings):
        self.model.lm_head = new_embeddings

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: torch.Tensor = None,
        labels: torch.LongTensor = None,
        keep_ratio: float = None,
        return_dict: bool = None,
        **kwargs
    ):
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict
        
        # keep_ratio belirtilmemişse config'den al
        if keep_ratio is None:
            keep_ratio = self.config.keep_ratio

        # SIFTModel'e veriyi gönder
        # (Orijinal model.py'de target olarak alınıyor, HF'de labels olarak geçer)
        logits, loss = self.model(
            input_ids=input_ids,
            targets=labels,
            keep_ratio=keep_ratio
        )

        if not return_dict:
            return (loss, logits) if loss is not None else (logits,)

        # Hugging Face'in generate() fonksiyonu ile uyumlu çıktı formatı
        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=None, # SIFT sparse olduğu için şimdilik KV cache kapalı
            hidden_states=None,
            attentions=None,
        )
    
    def prepare_inputs_for_generation(self, input_ids, **kwargs):
        # generate() fonksiyonu çalışırken modele gidecek argümanları ayarlar
        return {
            "input_ids": input_ids,
            "keep_ratio": kwargs.get("keep_ratio", self.config.keep_ratio),
        }
