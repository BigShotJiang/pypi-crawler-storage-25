"""
SIFT — Selective Intelligence Filtering Transformer
HuggingFace Configuration

Register:
    from transformers import AutoConfig
    AutoConfig.register("sift", SiftConfig)
"""

from transformers import PretrainedConfig


class SiftConfig(PretrainedConfig):
    """
    Configuration class for the SIFT (Selective Intelligence Filtering Transformer) model.

    Inherits from :class:`~transformers.PretrainedConfig` and supports all standard
    HuggingFace serialisation helpers (``from_pretrained``, ``save_pretrained``,
    ``push_to_hub``, etc.).

    Args:
        vocab_size (:obj:`int`, *optional*, defaults to 32000):
            Vocabulary size.  Determines the size of the embedding matrix and the
            output lm_head projection.
        hidden_dim (:obj:`int`, *optional*, defaults to 512):
            Dimensionality of every hidden representation.
        num_layers (:obj:`int`, *optional*, defaults to 8):
            Number of stacked SIFTLayer blocks.
        num_heads (:obj:`int`, *optional*, defaults to 8):
            Number of query attention heads.  Must divide ``hidden_dim`` evenly.
        num_kv_heads (:obj:`int`, *optional*, defaults to ``num_heads``):
            Number of key/value heads for Grouped-Query Attention (GQA).
            Must divide ``num_heads`` evenly.  Set equal to ``num_heads`` for
            standard Multi-Head Attention.
        max_seq_len (:obj:`int`, *optional*, defaults to 512):
            Maximum sequence length the model was trained with.  Used to
            pre-compute the YaRN RoPE inv_freq buffer.
        ffn_mult (:obj:`int`, *optional*, defaults to 4):
            Feed-forward network expansion multiplier.  The effective SwiGLU inner
            dimension is ``int(hidden_dim * ffn_mult * 2/3)`` rounded up to the
            nearest multiple of 8.
        keep_ratio (:obj:`float`, *optional*, defaults to 0.25):
            Fraction of tokens selected by the DeltaModule at each layer during
            inference.  During training this is controlled by the sparsity warmup
            scheduler in ``train.py``.
        rope_theta (:obj:`float`, *optional*, defaults to 10000.0):
            Base value for Rotary Position Embedding (RoPE).
        yarn_scale_factor (:obj:`float`, *optional*, defaults to 1.0):
            Context extension factor for YaRN RoPE.  ``1.0`` means no extension
            (equivalent to standard RoPE).  Increase this when fine-tuning on
            sequences longer than ``max_seq_len``.
        yarn_beta_fast (:obj:`int`, *optional*, defaults to 32):
            YaRN high-frequency boundary (number of rotations).
        yarn_beta_slow (:obj:`int`, *optional*, defaults to 1):
            YaRN low-frequency boundary (number of rotations).
        entropy_loss_weight (:obj:`float`, *optional*, defaults to 0.01):
            Coefficient applied to the per-layer Delta entropy regularisation
            loss before adding it to the language-modelling loss.
        initializer_range (:obj:`float`, *optional*, defaults to 0.02):
            Standard deviation for weight initialisation (normal distribution).
        pad_token_id (:obj:`int`, *optional*, defaults to 0):
        bos_token_id (:obj:`int`, *optional*, defaults to 2):
        eos_token_id (:obj:`int`, *optional*, defaults to 3):

    Example::

        >>> from sift import SiftConfig, SiftForCausalLM
        >>> config = SiftConfig(vocab_size=32000, hidden_dim=512, num_layers=8)
        >>> model  = SiftForCausalLM(config)
        >>> model.save_pretrained("./my-sift-model")

        >>> # reload
        >>> model2 = SiftForCausalLM.from_pretrained("./my-sift-model")
    """

    model_type = "sift"

    def __init__(
        self,
        vocab_size: int          = 32_000,
        hidden_dim: int          = 512,
        num_layers: int          = 8,
        num_heads: int           = 8,
        num_kv_heads: int | None = None,
        max_seq_len: int         = 512,
        ffn_mult: int            = 4,
        keep_ratio: float        = 0.25,
        rope_theta: float        = 10_000.0,
        yarn_scale_factor: float = 1.0,
        yarn_beta_fast: int      = 32,
        yarn_beta_slow: int      = 1,
        entropy_loss_weight: float = 0.01,
        initializer_range: float   = 0.02,
        # tokenizer / special tokens
        pad_token_id: int  = 0,
        bos_token_id: int  = 2,
        eos_token_id: int  = 3,
        **kwargs,
    ):
        # ── architecture ──────────────────────────────────────────────────
        self.vocab_size   = vocab_size
        self.hidden_dim   = hidden_dim
        self.num_layers   = num_layers
        self.num_heads    = num_heads
        self.num_kv_heads = num_kv_heads if num_kv_heads is not None else num_heads
        self.max_seq_len  = max_seq_len
        self.ffn_mult     = ffn_mult
        self.keep_ratio   = keep_ratio

        # ── positional encoding ───────────────────────────────────────────
        self.rope_theta        = rope_theta
        self.yarn_scale_factor = yarn_scale_factor
        self.yarn_beta_fast    = yarn_beta_fast
        self.yarn_beta_slow    = yarn_beta_slow

        # ── training ──────────────────────────────────────────────────────
        self.entropy_loss_weight = entropy_loss_weight
        self.initializer_range   = initializer_range

        super().__init__(
            pad_token_id = pad_token_id,
            bos_token_id = bos_token_id,
            eos_token_id = eos_token_id,
            **kwargs,
        )

    # ── convenience helpers ───────────────────────────────────────────────────
    @property
    def head_dim(self) -> int:
        """Derived: dimensionality of a single attention head."""
        return self.hidden_dim // self.num_heads

    @property
    def num_gqa_groups(self) -> int:
        """Derived: GQA replication factor (num_heads / num_kv_heads)."""
        return self.num_heads // self.num_kv_heads

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"SiftConfig("
            f"vocab={self.vocab_size}, "
            f"dim={self.hidden_dim}, "
            f"layers={self.num_layers}, "
            f"heads={self.num_heads}/{self.num_kv_heads} [GQA], "
            f"seq={self.max_seq_len}, "
            f"keep={self.keep_ratio}, "
            f"yarn_scale={self.yarn_scale_factor})"
        )