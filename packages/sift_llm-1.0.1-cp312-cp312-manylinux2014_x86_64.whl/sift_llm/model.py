"""
SIFT - Selective Intelligence Filtering Transformer
"Attend to What Matters"

Delta filtreler → Attention ilişkilendirir

Modernizasyon:
  - YaRN RoPE   : uzun context için geliştirilmiş pozisyon kodlaması
  - SwiGLU      : LLaMA tarzı FFN (GELU yerine SiLU-gated)
  - GQA         : Grouped Query Attention (daha az KV kafası, daha hızlı)
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# ── RMSNorm ───────────────────────────────────────────────────────────────────
class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-8):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        rms = x.norm(2, dim=-1, keepdim=True) * (x.shape[-1] ** -0.5)
        return (x / (rms + self.eps)) * self.weight


# ── YaRN RoPE ────────────────────────────────────────────────────────────────
def rotate_half(x: torch.Tensor) -> torch.Tensor:
    x1, x2 = x[..., : x.shape[-1] // 2], x[..., x.shape[-1] // 2 :]
    return torch.cat([-x2, x1], dim=-1)


def _yarn_find_correction_dim(
    num_rotations: float,
    head_dim: int,
    base: float,
    max_position: int,
) -> float:
    """YaRN: compute the correction boundary dimension."""
    return (head_dim * math.log(max_position / (num_rotations * 2 * math.pi))) / (
        2 * math.log(base)
    )


def _yarn_linear_ramp(low: float, high: float, dim: int) -> torch.Tensor:
    """Smooth linear ramp from low-frequency to high-frequency boundary."""
    if low == high:
        high += 0.001
    linear = torch.linspace(0, 1, dim)
    return torch.clamp((linear - low / dim) / ((high - low) / dim), 0, 1)


def compute_yarn_inv_freq(
    head_dim: int,
    base: float = 10000.0,
    scale_factor: float = 1.0,
    beta_fast: int = 32,
    beta_slow: int = 1,
    max_position: int = 2048,
) -> torch.Tensor:
    """
    YaRN inv_freq: updates standard RoPE frequencies with dynamic scaling.
    Low-frequency dimensions are interpolated; high-frequency ones are kept.

    Args:
        head_dim:      attention head dimension (must be even)
        base:          RoPE base (default 10000)
        scale_factor:  context extension factor (1.0 = standard RoPE, no change)
        beta_fast:     fast-boundary rotation count (high-freq cutoff)
        beta_slow:     slow-boundary rotation count (low-freq cutoff)
        max_position:  maximum sequence length the model was trained on

    Returns:
        inv_freq tensor of shape (head_dim // 2,)
    """
    inv_freq = 1.0 / (
        base ** (torch.arange(0, head_dim, 2, dtype=torch.float32) / head_dim)
    )

    if scale_factor == 1.0:
        return inv_freq

    low = max(
        math.floor(
            _yarn_find_correction_dim(beta_slow, head_dim, base, max_position)
        ),
        0,
    )
    high = min(
        math.ceil(
            _yarn_find_correction_dim(beta_fast, head_dim, base, max_position)
        ),
        head_dim // 2 - 1,
    )

    ramp = _yarn_linear_ramp(low, high, head_dim // 2)          # (head_dim//2,)
    inv_freq_interp = inv_freq / scale_factor                    # interpolated (shrinks)
    inv_freq_extrap = inv_freq                                   # extrapolated (unchanged)
    return inv_freq_interp * (1 - ramp) + inv_freq_extrap * ramp


def apply_yarn_rope(
    x: torch.Tensor,
    positions: torch.Tensor,
    inv_freq: torch.Tensor,
) -> torch.Tensor:
    """
    Apply YaRN RoPE rotary embeddings to query or key tensors.

    Args:
        x:          (batch, num_heads, k, head_dim)
        positions:  (batch, k)  — original token positions in the full sequence
        inv_freq:   (head_dim // 2,)  — output of compute_yarn_inv_freq

    Returns:
        Rotated tensor of same shape as x.
    """
    inv_freq = inv_freq.to(x.device)
    freqs = torch.einsum("bi,j->bij", positions.float(), inv_freq)  # (b, k, d//2)
    emb   = torch.cat([freqs, freqs], dim=-1)                       # (b, k, d)
    cos   = emb.cos().unsqueeze(1)                                  # (b, 1, k, d)
    sin   = emb.sin().unsqueeze(1)
    return x * cos + rotate_half(x) * sin


# ── SwiGLU FFN ───────────────────────────────────────────────────────────────
class SwiGLU(nn.Module):
    """
    LLaMA / PaLM-style SwiGLU Feed-Forward Network.
    gate(x) * SiLU(x) + up(x)  →  down projection.

    Scales the inner dimension to 2/3 of the nominal ffn_mult expansion so
    total parameter count stays comparable to a plain GELU FFN.
    """

    def __init__(self, hidden_dim: int, ffn_mult: int = 4):
        super().__init__()
        ffn_dim = int(hidden_dim * ffn_mult * 2 / 3)
        ffn_dim = (ffn_dim + 7) // 8 * 8   # round up to nearest multiple of 8

        self.gate = nn.Linear(hidden_dim, ffn_dim, bias=False)
        self.up   = nn.Linear(hidden_dim, ffn_dim, bias=False)
        self.down = nn.Linear(ffn_dim, hidden_dim, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down(F.silu(self.gate(x)) * self.up(x))


# ── Delta Module ─── (CORE — DO NOT MODIFY) ───────────────────────────────────
class DeltaModule(nn.Module):
    """
    Inspired by Mamba's selective state-space mechanism.
    Assigns an importance score to every token; the top keep_ratio fraction
    is selected for sparse attention. The language-modelling loss gradually
    teaches Delta to choose the correct tokens.

    ⚠️  DO NOT MODIFY — this is the core identity of SIFT.
    """

    def __init__(self, hidden_dim: int):
        super().__init__()
        self.scorer = nn.Linear(hidden_dim, 1, bias=False)

    def forward(
        self,
        x: torch.Tensor,
        keep_ratio: float = 0.25,
    ):
        # x: (batch, seq_len, hidden_dim)
        scores  = torch.sigmoid(self.scorer(x).squeeze(-1))   # (batch, seq_len)
        k       = max(1, int(x.shape[1] * keep_ratio))
        _, indices = torch.topk(scores, k, dim=-1)
        indices, _ = torch.sort(indices, dim=-1)               # preserve causal order
        return indices, scores                                 # (batch, k), (batch, seq_len)


# ── SIFT Attention — GQA + YaRN RoPE ─────────────────────────────────────────
class SIFTAttention(nn.Module):
    """
    Full attention over the sparse token subset selected by DeltaModule.

    Improvements over baseline:
      • GQA  — fewer KV heads for lower memory and faster inference
      • YaRN — better long-context positional extrapolation

    ⚠️  Sparse-attention logic (gather / scatter / causal mask) is part of the
        SIFT core and must NOT be changed.
    """

    def __init__(
        self,
        hidden_dim: int,
        num_heads: int,
        num_kv_heads: int | None = None,
        rope_theta: float = 10000.0,
        yarn_scale_factor: float = 1.0,
        yarn_beta_fast: int = 32,
        yarn_beta_slow: int = 1,
        max_seq_len: int = 512,
    ):
        super().__init__()
        assert hidden_dim % num_heads == 0, "hidden_dim must be divisible by num_heads"

        num_kv_heads = num_kv_heads or num_heads
        assert num_heads % num_kv_heads == 0, "num_heads must be divisible by num_kv_heads"

        self.num_heads    = num_heads
        self.num_kv_heads = num_kv_heads
        self.num_groups   = num_heads // num_kv_heads
        self.head_dim     = hidden_dim // num_heads
        self.hidden_dim   = hidden_dim
        self.scale        = math.sqrt(self.head_dim)

        # GQA projections: Q uses full heads, K/V use fewer KV heads
        self.q_proj   = nn.Linear(hidden_dim, num_heads    * self.head_dim, bias=False)
        self.k_proj   = nn.Linear(hidden_dim, num_kv_heads * self.head_dim, bias=False)
        self.v_proj   = nn.Linear(hidden_dim, num_kv_heads * self.head_dim, bias=False)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim,                   bias=False)

        # Pre-compute and cache YaRN inv_freq (moved with model to any device)
        inv_freq = compute_yarn_inv_freq(
            head_dim      = self.head_dim,
            base          = rope_theta,
            scale_factor  = yarn_scale_factor,
            beta_fast     = yarn_beta_fast,
            beta_slow     = yarn_beta_slow,
            max_position  = max_seq_len,
        )
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    def forward(
        self,
        x_selected: torch.Tensor,
        original_positions: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            x_selected:         (batch, k, hidden_dim)
            original_positions: (batch, k)  — true indices in the full sequence

        Returns:
            (batch, k, hidden_dim)
        """
        batch, k, _ = x_selected.shape

        # Project
        q  = self.q_proj(x_selected)    # (b, k, num_heads    * head_dim)
        kk = self.k_proj(x_selected)    # (b, k, num_kv_heads * head_dim)
        v  = self.v_proj(x_selected)    # (b, k, num_kv_heads * head_dim)

        # Reshape to (b, heads, k, head_dim)
        q  = q.view(batch, k, self.num_heads,    self.head_dim).transpose(1, 2)
        kk = kk.view(batch, k, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v  = v.view(batch, k, self.num_kv_heads,  self.head_dim).transpose(1, 2)

        # YaRN RoPE using original (pre-selection) positions
        q  = apply_yarn_rope(q,  original_positions, self.inv_freq)
        kk = apply_yarn_rope(kk, original_positions, self.inv_freq)

        # GQA: expand KV heads to match Q heads
        if self.num_groups > 1:
            kk = kk.repeat_interleave(self.num_groups, dim=1)  # (b, num_heads, k, head_dim)
            v  = v.repeat_interleave(self.num_groups, dim=1)

        # Attention scores
        attn = torch.matmul(q, kk.transpose(-2, -1)) / self.scale  # (b, h, k, k)

        # ── CORE: causal mask based on original positions (DO NOT MODIFY) ──
        pos_i = original_positions.unsqueeze(2)     # (b, k, 1)
        pos_j = original_positions.unsqueeze(1)     # (b, 1, k)
        causal_mask = (pos_j > pos_i).unsqueeze(1)  # (b, 1, k, k)
        attn = attn.masked_fill(causal_mask, float("-inf"))
        # ────────────────────────────────────────────────────────────────────

        attn = F.softmax(attn, dim=-1)
        attn = torch.nan_to_num(attn, nan=0.0)     # guard against full-mask rows

        out = torch.matmul(attn, v)                                 # (b, h, k, d)
        out = out.transpose(1, 2).contiguous().view(batch, k, self.hidden_dim)
        return self.out_proj(out)


# ── SIFT Layer ─── (sparse logic CORE — DO NOT MODIFY) ───────────────────────
class SIFTLayer(nn.Module):
    """
    One SIFT transformer layer.

    Forward pass:
      1. DeltaModule selects the top-k important tokens.
      2. Sparse attention runs only on those k tokens.
      3. Attention output is scatter-added back to the full sequence.
      4. SwiGLU FFN is applied to all tokens (dense).
      5. Entropy loss encourages Delta to diversify its selections.

    ⚠️  Steps 1–3 and 5 are the SIFT core and must NOT be changed.
    """

    def __init__(
        self,
        hidden_dim: int,
        num_heads: int,
        num_kv_heads: int | None = None,
        ffn_mult: int = 4,
        rope_theta: float = 10000.0,
        yarn_scale_factor: float = 1.0,
        yarn_beta_fast: int = 32,
        yarn_beta_slow: int = 1,
        max_seq_len: int = 512,
    ):
        super().__init__()
        self.delta = DeltaModule(hidden_dim)
        self.attn  = SIFTAttention(
            hidden_dim       = hidden_dim,
            num_heads        = num_heads,
            num_kv_heads     = num_kv_heads,
            rope_theta       = rope_theta,
            yarn_scale_factor= yarn_scale_factor,
            yarn_beta_fast   = yarn_beta_fast,
            yarn_beta_slow   = yarn_beta_slow,
            max_seq_len      = max_seq_len,
        )
        self.norm1 = RMSNorm(hidden_dim)
        self.norm2 = RMSNorm(hidden_dim)
        self.ffn   = SwiGLU(hidden_dim, ffn_mult)

    def forward(
        self,
        x: torch.Tensor,
        keep_ratio: float = 0.25,
    ):
        batch, seq_len, hidden_dim = x.shape

        # ── CORE: Delta selection (DO NOT MODIFY) ─────────────────────────
        indices, scores = self.delta(x, keep_ratio=keep_ratio)
        k   = indices.shape[1]
        idx = indices.unsqueeze(-1).expand(-1, -1, hidden_dim)

        # Gather selected tokens after pre-norm
        x_sel = torch.gather(self.norm1(x), 1, idx)              # (b, k, d)

        # Weight by selection scores so Delta receives gradients
        sel_scores = torch.gather(scores, 1, indices)
        x_sel = x_sel * sel_scores.unsqueeze(-1)

        # Sparse attention over selected tokens only
        attn_out = self.attn(x_sel, indices)                      # (b, k, d)

        # Scatter-add back to full sequence (unselected positions unchanged)
        x = x.scatter_add(1, idx, attn_out)
        # ──────────────────────────────────────────────────────────────────

        # Dense FFN over all tokens (SwiGLU replaces GELU FFN)
        x = x + self.ffn(self.norm2(x))

        # ── CORE: Entropy loss to encourage diverse Delta selections ───────
        eps = 1e-8
        entropy = -(
            scores * (scores + eps).log()
            + (1 - scores) * (1 - scores + eps).log()
        )
        entropy_loss = -entropy.mean()
        # ──────────────────────────────────────────────────────────────────

        return x, entropy_loss


# ── SIFT Model ────────────────────────────────────────────────────────────────
class SIFTModel(nn.Module):
    """
    Raw backbone of SIFT — used internally by SiftForCausalLM.
    """

    def __init__(
        self,
        vocab_size: int,
        hidden_dim: int = 512,
        num_layers: int = 8,
        num_heads: int = 8,
        num_kv_heads: int | None = None,
        max_seq_len: int = 512,
        ffn_mult: int = 4,
        rope_theta: float = 10000.0,
        yarn_scale_factor: float = 1.0,
        yarn_beta_fast: int = 32,
        yarn_beta_slow: int = 1,
    ):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, hidden_dim)
        self.layers = nn.ModuleList([
            SIFTLayer(
                hidden_dim        = hidden_dim,
                num_heads         = num_heads,
                num_kv_heads      = num_kv_heads,
                ffn_mult          = ffn_mult,
                rope_theta        = rope_theta,
                yarn_scale_factor = yarn_scale_factor,
                yarn_beta_fast    = yarn_beta_fast,
                yarn_beta_slow    = yarn_beta_slow,
                max_seq_len       = max_seq_len,
            )
            for _ in range(num_layers)
        ])
        self.norm    = RMSNorm(hidden_dim)
        self.lm_head = nn.Linear(hidden_dim, vocab_size, bias=False)
        self.lm_head.weight = self.embedding.weight   # weight tying

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, std=0.02)
            elif isinstance(m, nn.Embedding):
                nn.init.normal_(m.weight, std=0.02)

    def forward(
        self,
        input_ids: torch.Tensor,
        targets: torch.Tensor | None = None,
        keep_ratio: float = 0.25,
    ):
        x = self.embedding(input_ids)
        total_entropy_loss = torch.tensor(0.0, device=input_ids.device)

        for layer in self.layers:
            x, entropy_loss = layer(x, keep_ratio=keep_ratio)
            total_entropy_loss = total_entropy_loss + entropy_loss

        x      = self.norm(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            lm_loss = F.cross_entropy(
                logits.view(-1, logits.size(-1)),
                targets.view(-1),
                ignore_index=-1,
            )
            loss = lm_loss + 0.01 * total_entropy_loss

        return logits, loss

    def count_params(self) -> int:
        total  = sum(p.numel() for p in self.parameters())
        unique = sum(p.numel() for p in set(self.parameters()))
        print(f"Total parameters  : {total:,}")
        print(f"Unique parameters : {unique:,}")
        return unique