"""Centralized version resolution for pytest-dag.

Primary source of truth is ``pyproject.toml`` in repository/development mode.
Installed-wheel/runtime mode falls back to package metadata.
"""

from __future__ import annotations

import re
from functools import lru_cache
from importlib import metadata
from pathlib import Path


@lru_cache(maxsize=1)
def get_version() -> str:
    package_dir = Path(__file__).resolve().parent
    pyproject = package_dir.parent / "pyproject.toml"

    if pyproject.exists():
        text = pyproject.read_text(encoding="utf-8")
        match = re.search(r'(?m)^version\s*=\s*"([^"]+)"\s*$', text)
        if match:
            return match.group(1)

    try:
        return metadata.version("pytest-dag")
    except Exception:
        return "0.0.0"
