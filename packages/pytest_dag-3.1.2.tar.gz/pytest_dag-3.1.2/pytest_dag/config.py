"""
Configuration helpers for pytest-dag.

Handles CLI options, ini options, and the DagState data container that
is stored on the pytest ``config`` object as ``config._pytest_dag_state``.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Dict, Optional, Set


# ---------------------------------------------------------------------------
# Outcome enum
# ---------------------------------------------------------------------------

class Outcome(str, enum.Enum):
    """Possible outcomes stored for a nodeid after it has run."""

    PASSED = "PASSED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    DAG_SKIPPED = "DAG_SKIPPED"  # skipped by the plugin itself (always cascades)
    XFAILED = "XFAILED"
    XPASSED = "XPASSED"
    ERROR = "ERROR"  # setup/teardown error


# ---------------------------------------------------------------------------
# DagState – single shared mutable state object on config
# ---------------------------------------------------------------------------

@dataclass
class DagState:
    """All mutable DAG state kept on ``config._pytest_dag_state``."""

    # nodeid -> set of nodeids this test *directly* depends on
    deps: Dict[str, Set[str]] = field(default_factory=dict)

    # nodeid -> set of nodeids that depend on this test (reverse edges)
    reverse_deps: Dict[str, Set[str]] = field(default_factory=dict)

    # Final per-test outcome recorded via pytest_runtest_makereport
    results: Dict[str, Outcome] = field(default_factory=dict)

    # Sorted execution order produced by topo sort (list of nodeids)
    ordered: list = field(default_factory=list)

    def add_dependency(self, dependent: str, dependency: str) -> None:
        """Record that *dependent* requires *dependency* to run first."""
        self.deps.setdefault(dependent, set()).add(dependency)
        self.reverse_deps.setdefault(dependency, set()).add(dependent)
        # Ensure both nodes appear in deps (even if they have no further deps)
        self.deps.setdefault(dependency, set())
        self.reverse_deps.setdefault(dependent, set())

    def blocking_deps(self, nodeid: str, block_on: Set[Outcome]) -> list[str]:
        """
        Return a list of dependency nodeids whose outcome blocks *nodeid*.

        ``DAG_SKIPPED`` always blocks regardless of ``--dag-block-on-outcomes``:
        a test skipped by the plugin itself (because *its* dep failed) must
        cascade automatically, otherwise the chain breaks silently.

        User-initiated skips (``SKIPPED``) only block when ``skip`` is in
        ``--dag-block-on-outcomes``.

        An empty list means the test is not blocked.
        """
        # DAG_SKIPPED always cascades — it is not controlled by --dag-block-on-outcomes.
        effective = block_on | {Outcome.DAG_SKIPPED}
        blocked: list[str] = []
        for dep in self.deps.get(nodeid, set()):
            outcome = self.results.get(dep)
            if outcome is not None and outcome in effective:
                blocked.append(dep)
        return blocked


# ---------------------------------------------------------------------------
# Helpers: parse the --dag-block-on-outcomes option
# ---------------------------------------------------------------------------

_OUTCOME_ALIASES: Dict[str, Outcome] = {
    "fail": Outcome.FAILED,
    "failed": Outcome.FAILED,
    "skip": Outcome.SKIPPED,
    "skipped": Outcome.SKIPPED,
    "xfail": Outcome.XFAILED,
    "xfailed": Outcome.XFAILED,
    "error": Outcome.ERROR,
}


def parse_block_on(raw: str) -> Set[Outcome]:
    """
    Parse a comma-separated string like ``"fail,skip"`` into a set of
    :class:`Outcome` values.

    Raises ``ValueError`` for unrecognised tokens.
    """
    outcomes: Set[Outcome] = set()
    for token in raw.split(","):
        token = token.strip().lower()
        if not token:
            continue
        if token not in _OUTCOME_ALIASES:
            raise ValueError(
                f"pytest-dag: unknown --dag-block-on-outcomes value {token!r}. "
                f"Allowed: {', '.join(sorted(_OUTCOME_ALIASES))}"
            )
        outcomes.add(_OUTCOME_ALIASES[token])
    return outcomes


def get_block_on(config) -> Set[Outcome]:
    """Read the resolved *block_on* set from the live pytest config."""
    raw: str = config.getoption("--dag-block-on-outcomes", default="fail")
    try:
        return parse_block_on(raw)
    except ValueError as exc:
        from pytest import UsageError
        raise UsageError(str(exc)) from exc


def is_strict(config) -> bool:
    _ = config
    return True


def get_dag_file(config) -> Optional[str]:
    return config.getini("dag_file") or None


def dump_enabled(config) -> bool:
    return bool(config.getoption("--dag-print-graph", default=False))
