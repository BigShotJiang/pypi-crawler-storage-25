"""
DAG construction, cycle detection, and topological sort for pytest-dag.

Public API
----------
build_dag(items, config)  ->  DagState
    Reads markers + optional YAML, resolves dependency strings,
    detects cycles, returns a fully-populated DagState.

topo_sort(items, state)  ->  list[Item]
    Returns *items* reordered so every dependency precedes its dependents
    while preserving the original relative order among unconstrained tests.
"""
from __future__ import annotations

import os
from collections import deque
from pathlib import Path
from typing import Dict, List, Optional, Set

import pytest

from .config import DagState, get_dag_file, is_strict


# ---------------------------------------------------------------------------
# Internal helpers – nodeid resolution
# ---------------------------------------------------------------------------

def _module_of(item) -> str:
    """Return the file path component of the item's nodeid (before ``::``).

    Examples::

        "tests/test_foo.py::test_a"  ->  "tests/test_foo.py"
        "tests/test_foo.py::TestClass::test_a"  ->  "tests/test_foo.py"
    """
    return item.nodeid.split("::")[0]


def _build_lookup_tables(items) -> tuple[Dict[str, str], Dict[str, List[str]]]:
    """
    Build two lookup tables over all collected items.

    Returns
    -------
    nodeid_map : dict[nodeid, nodeid]
        Identity map (lets us normalise/validate full nodeids quickly).
    short_name_map : dict[(module, short_name), list[nodeid]]
        Maps ``(module_path, function_name)`` -> list of full nodeids.
        The list allows us to detect ambiguity (parametrised tests etc.).
    """
    nodeid_map: Dict[str, str] = {}
    short_name_map: Dict[tuple, List[str]] = {}

    for item in items:
        nodeid_map[item.nodeid] = item.nodeid
        module = _module_of(item)
        # The "short name" within a module is the last ``::``-separated segment.
        short = item.nodeid.rsplit("::", 1)[-1]
        key = (module, short)
        short_name_map.setdefault(key, []).append(item.nodeid)

    return nodeid_map, short_name_map


def _resolve_dep(
    dep_str: str,
    item,
    nodeid_map: Dict[str, str],
    short_name_map: Dict[tuple, List[str]],
) -> Optional[str]:
    """
    Resolve a dependency string to a full nodeid.

    Rules
    -----
    1. If *dep_str* contains ``"::"`` treat it as a (possibly relative) nodeid.
       Normalise the path separator and match against *nodeid_map*.
    2. Otherwise treat it as a function/class name within the same module.

    Returns ``None`` if resolution fails (caller decides strict vs. lenient).
    """
    if "::" in dep_str:
        # Normalise path separators
        normalised = dep_str.replace("\\", "/")
        if normalised in nodeid_map:
            return normalised
        # Try matching just by suffix (allows "test_file.py::test_b" to match
        # "tests/test_file.py::test_b")
        for known in nodeid_map:
            if known.endswith(normalised) or known == normalised:
                return known
        return None
    else:
        # Resolve by short name within the same module
        module = _module_of(item)
        key = (module, dep_str)
        candidates = short_name_map.get(key, [])
        if len(candidates) == 1:
            return candidates[0]
        if len(candidates) > 1:
            # Ambiguous – return first and emit warning (caller can warn)
            return candidates[0]
        return None


# ---------------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------------

def _load_yaml_deps(dag_file: str, rootdir: Path) -> Dict[str, List[str]]:
    """
    Load the external YAML DAG file.

    Returns dict mapping nodeid -> list of dependency nodeids.
    """
    try:
        import yaml
    except ImportError:
        raise pytest.UsageError(
            "pytest-dag: dag_file requires PyYAML. Install with: pip install pyyaml"
        )

    yaml_path = Path(dag_file)
    if not yaml_path.is_absolute():
        yaml_path = rootdir / yaml_path

    if not yaml_path.exists():
        raise pytest.UsageError(
            f"pytest-dag: dag_file not found: {yaml_path}"
        )

    with open(yaml_path) as fh:
        data = yaml.safe_load(fh)

    if not isinstance(data, dict) or "nodes" not in data:
        raise pytest.UsageError(
            f"pytest-dag: dag_file must have a top-level 'nodes' key: {yaml_path}"
        )

    result: Dict[str, List[str]] = {}
    for node in data["nodes"]:
        if not isinstance(node, dict) or "id" not in node:
            raise pytest.UsageError(
                f"pytest-dag: each node in dag_file must have an 'id' key: {yaml_path}"
            )
        nid = node["id"]
        deps = node.get("depends", [])
        if isinstance(deps, str):
            deps = [deps]
        result[nid] = list(deps)

    return result


# ---------------------------------------------------------------------------
# Public: build_dag
# ---------------------------------------------------------------------------

def build_dag(items, config) -> DagState:
    """
    Construct and validate the dependency DAG from collected items.

    Steps
    -----
    1. Build lookup tables over all items.
    2. Collect raw dependency strings from ``@pytest.mark.dag(depends=…)``
       markers and from the optional YAML file.
    3. Resolve dependency strings to nodeids; missing deps are collection errors.
    4. Run cycle detection; raise ``UsageError`` on cycle.
    5. Return a populated :class:`DagState`.
    """
    state = DagState()
    strict = is_strict(config)
    nodeid_map, short_name_map = _build_lookup_tables(items)

    # --- 1. Gather raw deps from markers ---------------------------------
    raw_marker_deps: Dict[str, List[str]] = {}
    for item in items:
        marker = item.get_closest_marker("dag")
        if marker is None:
            continue
        depends = marker.kwargs.get("depends", marker.args[0] if marker.args else [])
        if isinstance(depends, str):
            depends = [depends]
        raw_marker_deps[item.nodeid] = list(depends)

    # --- 2. Gather raw deps from YAML ------------------------------------
    raw_yaml_deps: Dict[str, List[str]] = {}
    dag_file = get_dag_file(config)
    if dag_file:
        rootdir = config.rootpath if hasattr(config, "rootpath") else Path(config.rootdir)
        raw_yaml_deps = _load_yaml_deps(dag_file, Path(str(rootdir)))

    # --- 3. Resolve all dependency strings --------------------------------
    errors: List[str] = []

    def _resolve_and_add(dependent_nodeid, dep_str, item_for_resolution):
        resolved = _resolve_dep(dep_str, item_for_resolution, nodeid_map, short_name_map)
        if resolved is None:
            msg = (
                f"pytest-dag: dependency not found: {dep_str!r} "
                f"(required by {dependent_nodeid!r})"
            )
            if strict:
                errors.append(msg)
        else:
            state.add_dependency(dependent_nodeid, resolved)

    # Marker deps
    item_map = {it.nodeid: it for it in items}
    for dependent_nodeid, dep_list in raw_marker_deps.items():
        item = item_map[dependent_nodeid]
        for dep_str in dep_list:
            _resolve_and_add(dependent_nodeid, dep_str, item)

    # YAML deps (use any item as context for module-relative resolution;
    # full nodeids in YAML should use :: so the module path matters less)
    first_item = items[0] if items else None
    for dependent_nodeid, dep_list in raw_yaml_deps.items():
        item = item_map.get(dependent_nodeid, first_item)
        for dep_str in dep_list:
            _resolve_and_add(dependent_nodeid, dep_str, item)

    if errors:
        raise pytest.UsageError("\n".join(errors))

    # --- 4. Cycle detection -----------------------------------------------
    _detect_cycles(state)

    return state


# ---------------------------------------------------------------------------
# Cycle detection
# ---------------------------------------------------------------------------

def _detect_cycles(state: DagState) -> None:
    """Detect cycles using DFS; raise UsageError with cycle path if found."""
    # DFS states: 0=unvisited, 1=in-stack, 2=done
    color: Dict[str, int] = {}
    parent: Dict[str, Optional[str]] = {}

    def dfs(node: str) -> None:
        color[node] = 1
        for neighbour in state.deps.get(node, set()):
            nc = color.get(neighbour, 0)
            if nc == 1:
                # Cycle found – reconstruct path
                cycle: List[str] = [neighbour, node]
                cur = node
                while cur != neighbour and cur is not None:
                    cur = parent.get(cur)
                    if cur is not None:
                        cycle.append(cur)
                cycle.reverse()
                raise pytest.UsageError(
                    "pytest-dag: dependency cycle detected:\n  "
                    + " -> ".join(cycle)
                )
            elif nc == 0:
                parent[neighbour] = node
                dfs(neighbour)
        color[node] = 2

    all_nodes: Set[str] = set(state.deps) | set(state.reverse_deps)
    for node in all_nodes:
        if color.get(node, 0) == 0:
            parent[node] = None
            dfs(node)


# ---------------------------------------------------------------------------
# Public: topo_sort
# ---------------------------------------------------------------------------

def topo_sort(items, state: DagState) -> List:
    """
    Reorder *items* using Kahn's algorithm (BFS topo sort).

    Items with no ordering constraints retain their *original* relative order
    (stable topological sort).

    Parameters
    ----------
    items :
        The list of collected pytest items (in original collection order).
    state :
        Populated :class:`DagState` (deps / reverse_deps already set).

    Returns
    -------
    list
        A reordered copy of *items*.
    """
    if not items:
        return list(items)

    # Map nodeid -> original index (for stable tie-breaking)
    original_order: Dict[str, int] = {item.nodeid: i for i, item in enumerate(items)}
    item_by_id: Dict[str, object] = {item.nodeid: item for item in items}

    # Build in-degree count over *collected* items only (ignore virtual nodes)
    collected_ids: Set[str] = set(item_by_id)

    in_degree: Dict[str, int] = {nid: 0 for nid in collected_ids}
    # adjacency: dependency -> list of dependents (only among collected)
    adj: Dict[str, List[str]] = {nid: [] for nid in collected_ids}

    for nid in collected_ids:
        for dep in state.deps.get(nid, set()):
            if dep in collected_ids:
                in_degree[nid] += 1
                adj[dep].append(nid)

    # Kahn's BFS with priority queue ordered by original index
    import heapq
    ready: list = []
    for nid, deg in in_degree.items():
        if deg == 0:
            heapq.heappush(ready, (original_order[nid], nid))

    result: List = []
    while ready:
        _, nid = heapq.heappop(ready)
        result.append(item_by_id[nid])
        for dependent in adj.get(nid, []):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                heapq.heappush(ready, (original_order[dependent], dependent))

    if len(result) != len(items):
        # Should not happen after cycle detection, but be safe.
        raise pytest.UsageError(
            "pytest-dag: topological sort failed – remaining cycle in graph."
        )

    return result
