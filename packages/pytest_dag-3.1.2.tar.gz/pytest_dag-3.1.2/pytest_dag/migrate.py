"""
pytest-dag migration helper: --migrate-from-pytest-dependency

Scans an existing test suite for ``pytest.mark.dependency(...)`` markers,
emits a pytest-dag-compatible ``dag.yaml``, and removes the markers from
source files.

Usage::

    pytest --migrate-from-pytest-dependency [--migrate-dry-run] \\
           [--dag-file-out tests/dag.yaml]
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import pytest


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class _MarkerInfo:
    """Parsed args from a single ``@pytest.mark.dependency(...)`` marker."""
    name: Optional[str]   # name= kwarg (None → use default)
    depends: List[str]    # depends= kwarg entries (may be empty)
    scope: str            # scope= kwarg value (default: "module")


@dataclass
class _MigrationConfig:
    dag_file_out: Path
    dry_run: bool


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def get_migration_config(config: pytest.Config) -> _MigrationConfig:
    """Resolve all migration options from a live pytest Config."""
    rootdir = Path(str(getattr(config, "rootpath", config.rootdir)))

    out = config.getoption("--dag-file-out", default=None)
    if out:
        dag_file_out = Path(out)
        if not dag_file_out.is_absolute():
            dag_file_out = rootdir / dag_file_out
    else:
        ini_val = (config.getini("dag_file") or "").strip()
        if ini_val:
            p = Path(ini_val)
            dag_file_out = p if p.is_absolute() else rootdir / p
        else:
            dag_file_out = rootdir / "tests" / "dag.yaml"

    return _MigrationConfig(
        dag_file_out=dag_file_out,
        dry_run=bool(config.getoption("--migrate-dry-run", default=False)),
    )


# ---------------------------------------------------------------------------
# Marker extraction
# ---------------------------------------------------------------------------

def _parse_marker(marker: pytest.Mark) -> _MarkerInfo:
    """Extract (name, depends, scope) from a ``pytest.mark.dependency(...)`` mark."""
    kwargs = marker.kwargs
    name: Optional[str] = kwargs.get("name", None)
    scope: str = str(kwargs.get("scope", "module"))

    depends_raw = kwargs.get("depends", [])
    if isinstance(depends_raw, str):
        depends_raw = [depends_raw]
    depends: List[str] = list(depends_raw)

    return _MarkerInfo(name=name, depends=depends, scope=scope)


# ---------------------------------------------------------------------------
# Name-index building
# ---------------------------------------------------------------------------

def _item_func_name(item) -> str:
    """Last segment of nodeid, stripped of parametrize brackets."""
    last = item.nodeid.rsplit("::", 1)[-1]
    if "[" in last:
        last = last[: last.index("[")]
    return last


def _build_name_index(
    items: list,
    marker_infos: Dict[str, _MarkerInfo],
) -> Dict[str, Set[str]]:
    """
    Build a global name lookup for dependency resolution.

    Key: dependency reference string.
    Value: set of matching nodeids.
    """
    index: Dict[str, Set[str]] = {}

    for item in items:
        nodeid = item.nodeid
        func_name = _item_func_name(item)
        info = marker_infos.get(nodeid)
        custom_name: Optional[str] = info.name if info else None

        names = {nodeid, func_name}
        if custom_name:
            names.add(custom_name)
        for name in names:
            index.setdefault(name, set()).add(nodeid)

    return index


# ---------------------------------------------------------------------------
# Dependency resolution
# ---------------------------------------------------------------------------

def _looks_like_nodeid(ref: str) -> bool:
    """Return True if *ref* looks like a full/partial nodeid (contains '::')."""
    return "::" in ref


def _resolve_ref(
    ref: str,
    name_index: Dict[str, Set[str]],
    all_nodeids: Set[str],
) -> Optional[str]:
    """
    Resolve a dependency reference string to a full nodeid.

    Resolution order:
    1) If *ref* looks like a nodeid: exact/suffix match if unique.
    2) Otherwise global lookup by name if unique.
    """
    # Step 1: nodeid-like ref (path::name)
    if _looks_like_nodeid(ref):
        if ref in all_nodeids:
            return ref
        norm = ref.replace("\\", "/")
        matches = [
            nid for nid in all_nodeids
            if nid == norm or nid.endswith("/" + norm) or nid.endswith(norm)
        ]
        if len(matches) == 1:
            return matches[0]
        return None

    # Step 2: bare-name global lookup (must be unique).
    matches = sorted(name_index.get(ref, set()))
    if len(matches) == 1:
        return matches[0]
    return None


# ---------------------------------------------------------------------------
# YAML generation
# ---------------------------------------------------------------------------

def _generate_yaml(
    items: list,
    resolved_deps: Dict[str, List[str]],
) -> str:
    """
    Generate a pytest-dag-compatible YAML string.

    All collected test items become nodes. Items with resolved dependencies
    get a ``depends:`` list.
    """
    buf: List[str] = ["nodes:"]

    for item in items:
        nid = item.nodeid
        resolved = resolved_deps.get(nid, [])
        buf.append(f"  - id: {nid}")

        if resolved:
            if len(resolved) == 1:
                buf.append(f"    depends: [{resolved[0]}]")
            else:
                buf.append("    depends:")
                for dep in resolved:
                    buf.append(f"      - {dep}")

    buf.append("")   # trailing newline
    return "\n".join(buf)


# ---------------------------------------------------------------------------
# Marker removal from source files (AST-based, minimal diff)
# ---------------------------------------------------------------------------

def _is_dependency_decorator(node: ast.expr) -> bool:
    """Return True if *node* is ``@pytest.mark.dependency(...)``."""
    # Unwrap Call → get the function expression
    inner = node.func if isinstance(node, ast.Call) else node

    # Match: pytest.mark.dependency
    if (
        isinstance(inner, ast.Attribute)
        and inner.attr == "dependency"
        and isinstance(inner.value, ast.Attribute)
        and inner.value.attr == "mark"
        and isinstance(inner.value.value, ast.Name)
        and inner.value.value.id == "pytest"
    ):
        return True

    # Match: mark.dependency (when `from pytest import mark` is used)
    if (
        isinstance(inner, ast.Attribute)
        and inner.attr == "dependency"
        and isinstance(inner.value, ast.Name)
        and inner.value.id == "mark"
    ):
        return True

    return False


def _find_decorator_line_ranges(source: str) -> List[Tuple[int, int]]:
    """
    Find ``(start_line, end_line)`` ranges (1-indexed, inclusive) for all
    ``@pytest.mark.dependency(...)`` decorators in *source*.

    Uses the AST so multi-line decorators are handled correctly.
    ``end_lineno`` is available on Python 3.8+; we require 3.9+.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    ranges: List[Tuple[int, int]] = []

    for node in ast.walk(tree):
        if not isinstance(
            node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
        ):
            continue
        for dec in node.decorator_list:
            if _is_dependency_decorator(dec):
                start = dec.lineno
                end = getattr(dec, "end_lineno", dec.lineno)
                ranges.append((start, end))

    return ranges


def remove_dependency_decorators(source: str) -> str:
    """
    Remove all ``@pytest.mark.dependency(...)`` decorator lines from
    *source*, preserving all other content and formatting.

    Handles:
    * single-line decorators
    * multi-line decorator arguments
    * stacked decorators (only the dependency decorator is removed)
    """
    ranges = _find_decorator_line_ranges(source)
    if not ranges:
        return source

    source_lines = source.splitlines(keepends=True)
    to_remove: Set[int] = set()
    for start, end in ranges:
        # Convert to 0-indexed line numbers
        for i in range(start - 1, end):
            to_remove.add(i)

    return "".join(
        line for i, line in enumerate(source_lines) if i not in to_remove
    )


# ---------------------------------------------------------------------------
# Summary / reporting
# ---------------------------------------------------------------------------

def _separator(char: str = "-", width: int = 60) -> str:
    return char * width


def _print_summary(
    items: list,
    marker_count: int,
    resolved_deps: Dict[str, List[str]],
    files_modified: List[Path],
    cfg: _MigrationConfig,
    yaml_content: str,
) -> None:
    """Print a human-readable migration summary to stdout."""
    edge_count = sum(len(v) for v in resolved_deps.values())

    print()
    print(_separator("="))
    print("pytest-dag: Migration from pytest-dependency")
    print(_separator("="))
    print(f"  Tests scanned     : {len(items)}")
    print(f"  Markers found     : {marker_count}")
    print(f"  Dependency edges  : {edge_count}")

    print()
    print(_separator())
    if cfg.dry_run:
        print(f"DRY RUN - output would be written to: {cfg.dag_file_out}")
        print()
        print("YAML preview:")
        print(_separator())
        # Indent the preview for readability
        for line in yaml_content.splitlines():
            print(f"  {line}")
    else:
        print(f"YAML written to: {cfg.dag_file_out}")
        if files_modified:
            print()
            print("Source files modified (dependency markers removed):")
            for p in files_modified:
                print(f"  {p}")
        else:
            print("(no source files needed modification)")

    print(_separator("="))
    print()


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_migration(items: list, config: pytest.Config) -> None:
    """
    Main entry point called from the plugin's collection hook.

    Workflow
    --------
    1. Scan all collected items for ``pytest.mark.dependency(...)`` markers.
    2. Build a global name index.
    3. Resolve dependency references to full nodeids.
    4. Preflight-fail if any dependency cannot be resolved uniquely.
    5. Generate YAML in pytest-dag format.
    6. Write YAML and strip markers from source files (unless dry-run).
    7. Print a summary report.
    """
    cfg = get_migration_config(config)
    all_nodeids: Set[str] = {item.nodeid for item in items}

    # ------------------------------------------------------------------
    # Step 1: scan markers
    # ------------------------------------------------------------------
    marker_infos: Dict[str, _MarkerInfo] = {}
    for item in items:
        # Use iter_markers so unregistered markers are still found
        for mark in item.iter_markers():
            if mark.name == "dependency":
                marker_infos[item.nodeid] = _parse_marker(mark)
                break

    marker_count = len(marker_infos)

    # ------------------------------------------------------------------
    # Step 2: build name index
    # ------------------------------------------------------------------
    name_index = _build_name_index(items, marker_infos)

    # ------------------------------------------------------------------
    # Step 3: resolve dependencies
    # ------------------------------------------------------------------
    resolved_deps: Dict[str, List[str]] = {}
    unresolved_flat: List[Tuple[str, str]] = []

    for nodeid, info in marker_infos.items():
        if not info.depends:
            continue

        resolved_list: List[str] = []

        for ref in info.depends:
            result = _resolve_ref(ref, name_index, all_nodeids)
            if result is None:
                unresolved_flat.append((nodeid, ref))
            else:
                resolved_list.append(result)

        if resolved_list:
            resolved_deps[nodeid] = resolved_list

    # ------------------------------------------------------------------
    # Step 4: preflight validation before any writes
    # ------------------------------------------------------------------
    if unresolved_flat:
        lines = [
            "pytest-dag migration failed preflight: unresolved or ambiguous dependency references found.",
            "No files were changed.",
            "",
            "References:",
        ]
        for nodeid, ref in unresolved_flat:
            lines.append(f"  - {nodeid!r} depends on {ref!r}")
        raise pytest.UsageError("\n".join(lines))

    # ------------------------------------------------------------------
    # Step 5: generate YAML
    # ------------------------------------------------------------------
    yaml_content = _generate_yaml(items, resolved_deps)

    # ------------------------------------------------------------------
    # Step 6: write YAML / modify source files
    # ------------------------------------------------------------------
    files_modified: List[Path] = []

    if not cfg.dry_run:
        # Write YAML
        cfg.dag_file_out.parent.mkdir(parents=True, exist_ok=True)
        cfg.dag_file_out.write_text(yaml_content, encoding="utf-8")

        # Strip markers from source files.
        if marker_infos:
            rootdir = Path(str(getattr(config, "rootpath", config.rootdir)))

            # Group nodeids by their source file
            files_with_markers: Set[str] = set()
            for nodeid in marker_infos:
                files_with_markers.add(nodeid.split("::")[0])

            for rel_path in sorted(files_with_markers):
                abs_path = rootdir / rel_path
                if not abs_path.exists():
                    continue

                source = abs_path.read_text(encoding="utf-8")
                new_source = remove_dependency_decorators(source)

                if new_source != source:
                    abs_path.write_text(new_source, encoding="utf-8")
                    files_modified.append(abs_path)

    # ------------------------------------------------------------------
    # Step 7: report
    # ------------------------------------------------------------------
    _print_summary(
        items=items,
        marker_count=marker_count,
        resolved_deps=resolved_deps,
        files_modified=files_modified,
        cfg=cfg,
        yaml_content=yaml_content,
    )
