"""pytest-dag: dependency-driven test ordering and skip propagation."""

from ._version import get_version

__version__ = get_version()
