from __future__ import annotations

import base64
import io
import json
import urllib.error

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from pytest_dag import __version__ as package_version
from pytest_dag import _pytest_dag_core as core


def _pub_pem_from_private_key(sk: Ed25519PrivateKey) -> str:
    return (
        sk.public_key()
        .public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo)
        .decode("utf-8")
    )


class _Resp:
    def __init__(self, body: str):
        self._body = body

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self) -> bytes:
        return self._body.encode("utf-8")


def test_debug_and_simple_helpers(monkeypatch, capsys):
    core._debug("silent")
    assert capsys.readouterr().err == ""

    monkeypatch.setenv("PYTEST_DAG_DEBUG", "1")
    core._debug("hello")
    assert "pytest-dag [DEBUG] hello" in capsys.readouterr().err

    assert str(core._license_error("x")) == "x"
    assert str(core._internal_error("y")) == "y"

    monkeypatch.setenv("T_TRUE", "YES")
    assert core._env_true("T_TRUE")
    monkeypatch.setenv("T_TRUE", "0")
    assert not core._env_true("T_TRUE")

    assert core._normalize_endpoint(" https://x/ ") == "https://x"
    assert core._is_local_or_private_host("localhost")
    assert core._is_local_or_private_host("127.0.0.1")
    assert not core._is_local_or_private_host("example.com")


def test_resolve_endpoint_branches(monkeypatch):
    monkeypatch.setattr(core, "OFFICIAL_LICENSE_ENDPOINT", "https://pytest-dag.slrsoft.ca")
    assert core._resolve_endpoint() == "https://pytest-dag.slrsoft.ca"
    monkeypatch.setattr(core, "OFFICIAL_LICENSE_ENDPOINT", "http://pytest-dag.slrsoft.ca")
    with pytest.raises(RuntimeError, match="Official license endpoint must use HTTPS"):
        core._resolve_endpoint()
    monkeypatch.setattr(core, "OFFICIAL_LICENSE_ENDPOINT", "https:///missing-host")
    with pytest.raises(RuntimeError, match="missing host"):
        core._resolve_endpoint()
    monkeypatch.setattr(core, "OFFICIAL_LICENSE_ENDPOINT", "__UNSET_OFFICIAL_LICENSE_ENDPOINT__")
    with pytest.raises(RuntimeError, match="not configured in this build"):
        core._resolve_endpoint()


def test_key_loading_and_verifying_key_selection(monkeypatch):
    monkeypatch_pem = (
        "-----BEGIN PUBLIC KEY-----\n"
        "MCowBQYDK2VwAyEAKqbNyhvNCjZDuwUYe7QB5C2arQvX6qRmys7pHly/8Lk=\n"
        "-----END PUBLIC KEY-----\n"
    )
    monkeypatch.setattr(core, "OFFICIAL_SIGNING_PUBLIC_KEY_PEM", monkeypatch_pem)

    assert isinstance(core._builtin_public_key(), core.Ed25519PublicKey)
    with pytest.raises(RuntimeError, match="Failed to load custom public key"):
        core._load_pem_public_key("bad pem")
    sk = Ed25519PrivateKey.generate()
    pub_pem = _pub_pem_from_private_key(sk)
    assert isinstance(core._load_pem_public_key(pub_pem), core.Ed25519PublicKey)

    assert isinstance(core._verifying_key_for_endpoint("https://pytest-dag.slrsoft.ca"), core.Ed25519PublicKey)
    assert isinstance(core._verifying_key_for_endpoint("http://dev.local"), core.Ed25519PublicKey)


def test_nonce_json_base64_and_verify(monkeypatch):
    nonce = core._generate_nonce()
    assert isinstance(nonce, str) and len(nonce) >= 20

    assert core._canonical_json({"z": 1, "a": 2}) == b'{"a":2,"z":1}'

    monkeypatch.setattr(core.json, "dumps", lambda *a, **k: (_ for _ in ()).throw(ValueError("x")))
    with pytest.raises(RuntimeError, match="canonical_json serialisation failed"):
        core._canonical_json({"a": 1})

    assert core._b64url_decode("dGVzdA") == b"test"
    monkeypatch.setattr(
        core.base64,
        "urlsafe_b64decode",
        lambda value: (_ for _ in ()).throw(ValueError("bad b64")),
    )
    with pytest.raises(RuntimeError, match="Base64 decode failed"):
        core._b64url_decode("dGVzdA")

    sk = Ed25519PrivateKey.generate()
    pk = sk.public_key()
    msg = b"hello"
    sig = sk.sign(msg)
    core._verify_ed25519(pk, msg, sig)
    with pytest.raises(RuntimeError, match="Invalid Ed25519 signature length"):
        core._verify_ed25519(pk, msg, b"short")
    with pytest.raises(RuntimeError, match="Ed25519 signature verification failed"):
        core._verify_ed25519(pk, b"x", sig)


def test_user_agent_and_http_json(monkeypatch):
    monkeypatch.delenv("PYTEST_DAG_USER_AGENT", raising=False)
    assert core._user_agent() == core.DEFAULT_USER_AGENT
    monkeypatch.setenv("PYTEST_DAG_USER_AGENT", "ua")
    assert core._user_agent() == "ua"

    monkeypatch.setattr(core.urllib.request, "urlopen", lambda req, timeout: _Resp('{"ok": true}'))
    assert core._http_json("GET", "http://x", {}) == {"ok": True}
    assert core._http_json("POST", "http://x", {}, {"a": 1}) == {"ok": True}

    def _raise_urlerr(req, timeout):
        raise urllib.error.URLError("down")

    monkeypatch.setattr(core.urllib.request, "urlopen", _raise_urlerr)
    with pytest.raises(RuntimeError, match="License server unreachable"):
        core._http_json("GET", "http://x", {})
    with pytest.raises(RuntimeError, match="support@slrsoft.ca"):
        core._http_json("GET", "http://x", {})
    with pytest.raises(RuntimeError, match="during validation"):
        core._http_json("POST", "http://x", {}, {"a": 1})
    with pytest.raises(RuntimeError, match="support@slrsoft.ca"):
        core._http_json("POST", "http://x", {}, {"a": 1})

    monkeypatch.setattr(
        core.urllib.request,
        "urlopen",
        lambda req, timeout: (_ for _ in ()).throw(Exception("boom")),
    )
    with pytest.raises(RuntimeError, match="HTTP GET failed"):
        core._http_json("GET", "http://x", {})

    monkeypatch.setattr(core.urllib.request, "urlopen", lambda req, timeout: _Resp("{bad"))
    with pytest.raises(RuntimeError, match="JSON parse failed"):
        core._http_json("GET", "http://x", {})

    monkeypatch.setattr(core.urllib.request, "urlopen", lambda req, timeout: _Resp("[]"))
    with pytest.raises(RuntimeError, match="not a JSON object"):
        core._http_json("GET", "http://x", {})


def test_required_and_build_signed_payload():
    data = {"x": "y", "n": 1}
    assert core._required_str(data, "x") == "y"
    assert core._required_i64(data, "n") == 1
    with pytest.raises(RuntimeError, match="Missing or invalid signed field: x"):
        core._required_str({"x": ""}, "x")
    with pytest.raises(RuntimeError, match="Missing or invalid signed field: n"):
        core._required_i64({"n": True}, "n")
    with pytest.raises(RuntimeError, match="Missing or invalid signed field: n"):
        core._required_i64({"n": "1"}, "n")

    common = {
        "sig_v": 1,
        "sig_alg": "Ed25519",
        "sig_kid": "k1",
        "sig_ts": 1,
        "sig_exp": 2,
        "sig_nonce": "abc",
    }
    ff = dict(common, paywall_enabled=True)
    out = core._build_signed_payload("feature-flag", ff)
    assert out["paywall_enabled"] is True

    val = dict(common, valid=True, reason="r", expiry="e", user_count=1, license_type="L")
    out = core._build_signed_payload("validate", val)
    assert out["valid"] is True and out["reason"] == "r"
    plan = dict(
        common,
        plan_session_id="sid",
        execution_order=["a", "b"],
        protocol_version="1",
        server_version="1",
    )
    out = core._build_signed_payload("plan-start", plan)
    assert out["plan_session_id"] == "sid"

    with pytest.raises(RuntimeError, match="paywall_enabled"):
        core._build_signed_payload("feature-flag", common)
    with pytest.raises(RuntimeError, match="valid"):
        core._build_signed_payload("validate", common)
    with pytest.raises(RuntimeError, match="execution_order"):
        core._build_signed_payload("plan-start", dict(common, plan_session_id="sid"))
    with pytest.raises(RuntimeError, match="Unknown signature context"):
        core._build_signed_payload("nope", common)


def test_verify_signed_response_branches(monkeypatch):
    base = {
        "sig": "dGVzdA",
        "sig_alg": "Ed25519",
        "sig_v": 1,
        "sig_nonce": "n",
        "sig_ts": 100,
        "sig_exp": 200,
        "sig_kid": "kid",
        "paywall_enabled": False,
    }
    monkeypatch.setattr(core, "_now_unix", lambda: 120)
    monkeypatch.setattr(core, "_build_signed_payload", lambda ctx, data: {"a": 1})
    monkeypatch.setattr(core, "_canonical_json", lambda data: b"{}")
    monkeypatch.setattr(core, "_b64url_decode", lambda s: b"x" * 64)
    monkeypatch.setattr(core, "_verifying_key_for_endpoint", lambda ep: object())
    calls = {"n": 0}
    monkeypatch.setattr(
        core, "_verify_ed25519", lambda key, msg, sig: calls.__setitem__("n", calls["n"] + 1)
    )
    core._verify_signed_response("feature-flag", dict(base), "n", "http://x")
    assert calls["n"] == 1

    bad = dict(base, sig_alg="RSA")
    with pytest.raises(RuntimeError, match="algorithm"):
        core._verify_signed_response("feature-flag", bad, "n", "http://x")
    bad = dict(base, sig_v=2)
    with pytest.raises(RuntimeError, match="version"):
        core._verify_signed_response("feature-flag", bad, "n", "http://x")
    bad = dict(base, sig_nonce="other")
    with pytest.raises(RuntimeError, match="nonce mismatch"):
        core._verify_signed_response("feature-flag", bad, "n", "http://x")
    bad = dict(base, sig_ts=2000)
    with pytest.raises(RuntimeError, match="in the future"):
        core._verify_signed_response("feature-flag", bad, "n", "http://x")
    bad = dict(base, sig_exp=10)
    with pytest.raises(RuntimeError, match="has expired"):
        core._verify_signed_response("feature-flag", bad, "n", "http://x")


def test_enforce_license_paths(monkeypatch):
    monkeypatch.setattr(core, "_resolve_endpoint", lambda: "http://ep")
    monkeypatch.setattr(core, "_generate_nonce", lambda: "nonce")

    monkeypatch.setattr(core, "_http_json", lambda method, url, headers, payload=None: {"paywall_enabled": False})
    monkeypatch.setattr(core, "_verify_signed_response", lambda *a, **k: None)
    assert core._enforce_license(None) is False

    monkeypatch.setattr(core, "_http_json", lambda method, url, headers, payload=None: {"paywall_enabled": True})
    with pytest.raises(RuntimeError, match="License key not provided"):
        core._enforce_license(None)

    seq = [{"paywall_enabled": True}, {"valid": True}]

    def _http_seq(method, url, headers, payload=None):
        return seq.pop(0)

    monkeypatch.setattr(core, "_http_json", _http_seq)
    monkeypatch.setattr(core, "_verify_signed_response", lambda *a, **k: None)
    assert core._enforce_license("k") is True

    seq = [{"paywall_enabled": True}, {"valid": False, "reason": "bad", "expiry": "2026-01-01"}]
    monkeypatch.setattr(core, "_http_json", _http_seq)
    with pytest.raises(RuntimeError, match="Reason: bad"):
        core._enforce_license("k")

    seq = [{"paywall_enabled": True}, {"valid": False}]
    monkeypatch.setattr(core, "_http_json", _http_seq)
    with pytest.raises(RuntimeError, match="unknown error"):
        core._enforce_license("k")

    seq = [{"paywall_enabled": True}]
    monkeypatch.setattr(core, "_http_json", _http_seq)

    def _verify_fail(ctx, *args, **kwargs):
        raise RuntimeError("sig fail")

    monkeypatch.setattr(core, "_verify_signed_response", _verify_fail)
    with pytest.raises(RuntimeError, match="invalid response"):
        core._enforce_license("k")

    seq = [{"paywall_enabled": True}, {"valid": True}]
    monkeypatch.setattr(core, "_http_json", _http_seq)
    state = {"i": 0}

    def _verify_mixed(ctx, *args, **kwargs):
        state["i"] += 1
        if ctx == "validate":
            raise RuntimeError("sig fail")

    monkeypatch.setattr(core, "_verify_signed_response", _verify_mixed)
    with pytest.raises(RuntimeError, match="invalid validation response"):
        core._enforce_license("k")


def test_enforce_and_session_and_state(monkeypatch):
    monkeypatch.setattr(core, "_resolve_endpoint", lambda: "https://pytest-dag.slrsoft.ca")
    monkeypatch.setattr(core, "_enforce_license", lambda k: True)
    monkeypatch.setattr(
        core,
        "_load_local_test_mode_adapter",
        lambda: (
            lambda *, token, license_key, session_cls, enforce_license, resolve_endpoint: session_cls(
                token,
                license_checked=True,
                paywall_was_active=enforce_license(license_key),
                license_key=license_key,
                endpoint=resolve_endpoint(),
            )
        ),
    )
    monkeypatch.setenv("PYTEST_DAG_TEST_MODE", "1")
    s2 = core.enforce_and_init("k")
    assert s2.license_checked is True and s2.paywall_was_active is True
    assert s2.license_key == "k"
    assert s2.endpoint == "https://pytest-dag.slrsoft.ca"
    assert s2.test_count == 0
    assert "DagSession" in repr(s2)

    s2.add_dependency("b", "a")
    s2.record("a", "FAILED", overwrite=False)
    assert s2.blocking_deps("b", "FAILED") == ["a"]
    s2.record("a", "PASSED", overwrite=False)
    assert s2.results["a"] == "FAILED"
    s2.record("a", "PASSED", overwrite=True)
    assert s2.results["a"] == "PASSED"
    s2.record("c", "NOPE", overwrite=True)
    assert s2.results["c"] == "FAILED"

    sv = core._StateView(s2)
    assert sv.deps is s2.deps and sv.reverse_deps is s2.reverse_deps


def test_test_mode_fails_hard_without_local_adapter(monkeypatch):
    monkeypatch.setenv("PYTEST_DAG_TEST_MODE", "1")
    import importlib

    real_import_module = importlib.import_module

    def _blocked_import(name, package=None):
        if name == "test_support.pytest_dag_local_test_mode":
            raise ModuleNotFoundError(name)
        return real_import_module(name, package)

    monkeypatch.setattr(core.importlib, "import_module", _blocked_import)
    with pytest.raises(RuntimeError, match="Disable PYTEST_DAG_TEST_MODE"):
        core.enforce_and_init("k")


def test_build_dag_topo_and_public_helpers(monkeypatch, tmp_path):
    session = core.DagSession(b"x" * 32, True, False)
    items = [
        {"nodeid": "t.py::test_a", "raw_deps": []},
        {"nodeid": "t.py::test_b", "raw_deps": ["test_a"]},
    ]
    monkeypatch.setattr(core, "_detect_cycles", lambda state: None)
    core.build_dag(session, items, strict=True)
    assert "t.py::test_a" in session.deps["t.py::test_b"]

    session2 = core.DagSession(b"x" * 32, True, False)
    with pytest.raises(RuntimeError, match="dependency not found"):
        core.build_dag(
            session2,
            [{"nodeid": "t.py::test_b", "raw_deps": ["missing"]}],
            strict=True,
        )

    session3 = core.DagSession(b"x" * 32, True, False)
    core.build_dag(
        session3,
        [{"nodeid": "t.py::test_b", "raw_deps": ["missing"]}],
        strict=False,
    )
    assert "<missing:missing>" in session3.results

    session4 = core.DagSession(b"x" * 32, True, False)
    monkeypatch.setattr(core, "_load_yaml_deps", lambda dag_file, root: {"t.py::test_b": ["test_a"]})
    core.build_dag(session4, items, dag_file=str(tmp_path / "dag.yaml"), rootdir=str(tmp_path), strict=True)
    assert "t.py::test_a" in session4.deps["t.py::test_b"]

    monkeypatch.setattr(core, "_detect_cycles", lambda state: (_ for _ in ()).throw(Exception("cycle!")))
    with pytest.raises(RuntimeError, match="cycle!"):
        core.build_dag(session4, items)

    assert core.topo_sort(session4, []) == []
    session5 = core.DagSession(b"x" * 32, True, False)
    session5.add_dependency("t.py::test_b", "t.py::test_a")
    ordered = core.topo_sort(session5, items)
    assert ordered == ["t.py::test_a", "t.py::test_b"]

    session6 = core.DagSession(b"x" * 32, True, False)
    session6.add_dependency("t.py::test_a", "t.py::test_b")
    session6.add_dependency("t.py::test_b", "t.py::test_a")
    with pytest.raises(RuntimeError, match="topological sort failed"):
        core.topo_sort(session6, items)

    blocked, reason = core.check_block(session5, "t.py::test_b", "FAILED")
    assert blocked is False and reason == ""
    core.record_outcome(session5, "t.py::test_a", "FAILED")
    blocked, reason = core.check_block(session5, "t.py::test_b", "FAILED")
    assert blocked is True and "blocked by" in reason

    core.set_ordered(session5, ordered)
    assert core.get_ordered(session5) == ordered
    deps = core.get_deps(session5)
    assert "t.py::test_b" in deps
    assert core.get_outcome(session5, "t.py::test_a") == "FAILED"
    assert core.get_outcome(session5, "t.py::missing") is None
    assert core.get_version() == package_version


def test_server_authoritative_plan_helpers(monkeypatch):
    items = [
        {"nodeid": "t.py::test_a", "raw_deps": []},
        {"nodeid": "t.py::test_b", "raw_deps": []},
    ]
    session = core.DagSession(
        b"x" * 32,
        license_checked=True,
        paywall_was_active=True,
        license_key="k",
        endpoint="https://pytest-dag.slrsoft.ca",
    )
    session.add_dependency("t.py::test_b", "t.py::test_a")

    monkeypatch.setattr(core, "_generate_nonce", lambda: "nonce")
    monkeypatch.setattr(core, "_verify_signed_response", lambda *a, **k: None)
    monkeypatch.setattr(
        core,
        "_http_json",
        lambda method, url, headers, payload=None: {
            "plan_session_id": "sid",
            "execution_order": ["t.py::test_a", "t.py::test_b"],
            "protocol_version": "1",
            "server_version": "1",
            "sig": "x",
            "sig_alg": "Ed25519",
            "sig_v": 1,
            "sig_nonce": "nonce",
            "sig_ts": 1,
            "sig_exp": 2,
            "sig_kid": "kid",
        },
    )
    ordered = core.topo_sort(session, items)
    assert ordered == ["t.py::test_a", "t.py::test_b"]
    assert session.plan_session_id == "sid"

    report_calls = []
    monkeypatch.setattr(
        core,
        "_http_json",
        lambda method, url, headers, payload=None: report_calls.append((url, payload)) or {"accepted": True},
    )
    core.record_outcome(session, "t.py::test_a", "FAILED")
    core.finalize_session(session)
    assert report_calls[0][0].endswith("/api/pytest-dag/v1/plan/report")
    assert report_calls[1][0].endswith("/api/pytest-dag/v1/plan/finish")
    assert session.plan_session_id is None

    # report failures should be debug-only and not break local result recording
    session.plan_session_id = "sid-2"
    monkeypatch.setattr(core, "_http_json", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("down")))
    core.record_outcome(session, "t.py::test_b", "PASSED")
    assert session.results["t.py::test_b"] == "PASSED"
    with pytest.raises(RuntimeError, match="down"):
        core.finalize_session(session)
    assert session.plan_session_id is None
    core.finalize_session(session)


def test_remaining_branches_for_100(monkeypatch, tmp_path):
    assert core._is_local_or_private_host("::1")

    monkeypatch.setattr(core, "OFFICIAL_LICENSE_ENDPOINT", "http://pytest-dag.slrsoft.ca")
    with pytest.raises(RuntimeError, match="Official license endpoint must use HTTPS"):
        core._resolve_endpoint()
    monkeypatch.setattr(core, "OFFICIAL_SIGNING_PUBLIC_KEY_PEM", "__UNSET_OFFICIAL_SIGNING_PUBLIC_KEY_PEM__")
    with pytest.raises(RuntimeError, match="not configured in this build"):
        core._builtin_public_key()

    monkeypatch.setattr(
        core,
        "load_pem_public_key",
        lambda data: (_ for _ in ()).throw(ValueError("boom")),
    )
    monkeypatch.setattr(core, "OFFICIAL_SIGNING_PUBLIC_KEY_PEM", "not-empty")
    with pytest.raises(RuntimeError, match="Failed to load built-in public key"):
        core._builtin_public_key()

    class _FakeKey:
        pass

    monkeypatch.setattr(core, "load_pem_public_key", lambda data: _FakeKey())
    with pytest.raises(RuntimeError, match="not Ed25519"):
        core._builtin_public_key()
    with pytest.raises(RuntimeError, match="not Ed25519"):
        core._load_pem_public_key("whatever")

    assert isinstance(core._now_unix(), int)

    session = core.DagSession(b"x" * 32, True, False)
    items = [
        {"nodeid": "t.py::test_a", "raw_deps": []},
        {"nodeid": "t.py::test_b", "raw_deps": ["t.py::test_a"]},
    ]
    monkeypatch.setattr(core, "_detect_cycles", lambda state: None)
    core.build_dag(session, items, strict=True)

    # protocol and order mismatch branches in plan/start
    remote = core.DagSession(
        b"x" * 32,
        license_checked=True,
        paywall_was_active=True,
        license_key="k",
        endpoint="https://pytest-dag.slrsoft.ca",
    )
    monkeypatch.setattr(core, "_generate_nonce", lambda: "nonce")
    monkeypatch.setattr(core, "_verify_signed_response", lambda *a, **k: None)
    monkeypatch.setattr(
        core,
        "_http_json",
        lambda *a, **k: {
            "plan_session_id": "sid",
            "execution_order": "bad-order",
            "protocol_version": "1",
            "server_version": "1",
            "sig": "x",
            "sig_alg": "Ed25519",
            "sig_v": 1,
            "sig_nonce": "nonce",
            "sig_ts": 1,
            "sig_exp": 2,
            "sig_kid": "kid",
        },
    )
    with pytest.raises(RuntimeError, match="Invalid execution_order"):
        core._start_remote_plan(remote, items)

    monkeypatch.setattr(
        core,
        "_http_json",
        lambda *a, **k: {
            "plan_session_id": "sid",
            "execution_order": ["t.py::test_a"],
            "protocol_version": "1",
            "server_version": "1",
            "sig": "x",
            "sig_alg": "Ed25519",
            "sig_v": 1,
            "sig_nonce": "nonce",
            "sig_ts": 1,
            "sig_exp": 2,
            "sig_kid": "kid",
        },
    )
    with pytest.raises(RuntimeError, match="does not match collected tests"):
        core._start_remote_plan(remote, items)

    monkeypatch.setattr(
        core,
        "_http_json",
        lambda *a, **k: {
            "plan_session_id": "sid",
            "execution_order": ["t.py::test_a", "t.py::test_b"],
            "protocol_version": "2",
            "server_version": "1",
            "sig": "x",
            "sig_alg": "Ed25519",
            "sig_v": 1,
            "sig_nonce": "nonce",
            "sig_ts": 1,
            "sig_exp": 2,
            "sig_kid": "kid",
        },
    )
    with pytest.raises(RuntimeError, match="Protocol mismatch"):
        core._start_remote_plan(remote, items)
