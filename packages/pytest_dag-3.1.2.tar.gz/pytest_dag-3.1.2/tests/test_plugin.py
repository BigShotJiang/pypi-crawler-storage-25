"""
Comprehensive tests for pytest-dag.

Each test uses ``pytester`` (formerly ``testdir``) to spin up a real
isolated pytest session, so we exercise the full plugin hook chain.

We use ``pytester.runpytest_subprocess`` so that each sub-session is a
genuine child process.  Because our package is installed in editable mode
and registered via ``pytest11``, the plugin is auto-loaded without any
extra conftest – which avoids the double-registration error that occurs
with ``inline_run``.
"""
from __future__ import annotations

import textwrap

import pytest


# ===========================================================================
# 1.  Basic ordering
# ===========================================================================

class TestOrdering:
    def test_simple_chain(self, pytester):
        """A -> B -> C must run in that order."""
        pytester.makepyfile(
            test_chain=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_c():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=3)
        
        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1
        
        pos_a = line_of("test_a")
        pos_b = line_of("test_b")
        pos_c = line_of("test_c")
        assert 0 <= pos_a < pos_b < pos_c

    def test_fan_out(self, pytester):
        """A -> B -> (C, D): C and D may run in any order but after B."""
        pytester.makepyfile(
            test_fanout=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_c():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_d():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=4)
        
        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1
        
        pos_b = line_of("test_b")
        pos_c = line_of("test_c")
        pos_d = line_of("test_d")
        assert pos_b < pos_c
        assert pos_b < pos_d

    def test_multi_parent(self, pytester):
        """E depends on C and D; all must complete before E runs."""
        pytester.makepyfile(
            test_multiparent=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_c():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_d():
                    pass

                @pytest.mark.dag(depends=["test_c", "test_d"])
                def test_e():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=5)
        
        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1
        
        pos_c = line_of("test_c")
        pos_d = line_of("test_d")
        pos_e = line_of("test_e")
        assert pos_c < pos_e
        assert pos_d < pos_e

    def test_independent_tests_preserved(self, pytester):
        """Tests with no deps keep their original relative order."""
        pytester.makepyfile(
            test_independent=textwrap.dedent("""\
                def test_one():
                    pass

                def test_two():
                    pass

                def test_three():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=3)
        
        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1
        
        pos_one = line_of("test_one")
        pos_two = line_of("test_two")
        pos_three = line_of("test_three")
        assert 0 <= pos_one < pos_two < pos_three


# ===========================================================================
# 2.  Failure propagation
# ===========================================================================

class TestFailurePropagation:
    def test_dependent_skipped_when_dep_fails(self, pytester):
        """If test_a fails, test_b (which depends on it) must be skipped."""
        pytester.makepyfile(
            test_prop=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False, "intentional failure"

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "-rs")
        result.assert_outcomes(failed=1, skipped=1)
        result.stdout.fnmatch_lines(["*pytest-dag: blocked by*test_a*(FAILED)*"])

    def test_cascade_skip(self, pytester):
        """A fails -> B skipped -> C skipped (cascade with --dag-block-on-outcomes fail,skip)."""
        pytester.makepyfile(
            test_cascade=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_c():
                    pass
            """)
        )
        # cascade requires --dag-block-on-outcomes to include "skip" so that
        # C (depends on B) is also blocked when B is skipped
        result = pytester.runpytest_subprocess("-v", "--dag-block-on-outcomes", "fail,skip")
        result.assert_outcomes(failed=1, skipped=2)

    def test_sibling_still_runs_when_dep_fails(self, pytester):
        """B and C both depend on A; if A fails both skip, but test_d is unaffected."""
        pytester.makepyfile(
            test_sibling=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_c():
                    pass

                def test_d():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(failed=1, skipped=2, passed=1)

    def test_passing_dep_does_not_skip_dependent(self, pytester):
        """Sanity: passing dependency → dependent runs normally."""
        pytester.makepyfile(
            test_pass=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=2)


# ===========================================================================
# 3.  block-on configuration
# ===========================================================================

class TestBlockOn:
    def test_block_on_skip(self, pytester):
        """With --dag-block-on-outcomes fail,skip a skipped dep blocks the dependent."""
        pytester.makepyfile(
            test_blockon=textwrap.dedent("""\
                import pytest

                @pytest.mark.skip(reason="skipped on purpose")
                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "--dag-block-on-outcomes", "fail,skip")
        result.assert_outcomes(skipped=2)

    def test_default_block_on_does_not_block_skipped_dep(self, pytester):
        """Default --dag-block-on-outcomes fail: a skipped dep does NOT block the dependent."""
        pytester.makepyfile(
            test_skipnoblocking=textwrap.dedent("""\
                import pytest

                @pytest.mark.skip(reason="skipped on purpose")
                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(skipped=1, passed=1)

    def test_block_on_xfail(self, pytester):
        """With --dag-block-on-outcomes fail,xfail an xfailed dep blocks the dependent."""
        pytester.makepyfile(
            test_xfail=textwrap.dedent("""\
                import pytest

                @pytest.mark.xfail(reason="known bug")
                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "--dag-block-on-outcomes", "fail,xfail")
        # test_a is xfailed, test_b is blocked (skipped)
        result.assert_outcomes(xfailed=1, skipped=1)


# ===========================================================================
# 4.  Cycle detection
# ===========================================================================

class TestCycleDetection:
    def test_two_node_cycle(self, pytester):
        """A depends on B and B depends on A – should raise UsageError."""
        pytester.makepyfile(
            test_cycle=textwrap.dedent("""\
                import pytest

                @pytest.mark.dag(depends=["test_b"])
                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.stderr.fnmatch_lines(["*cycle detected*"])
        assert result.ret != 0

    def test_self_loop(self, pytester):
        """A depends on itself – cycle."""
        pytester.makepyfile(
            test_selfloop=textwrap.dedent("""\
                import pytest

                @pytest.mark.dag(depends=["test_a"])
                def test_a():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.stderr.fnmatch_lines(["*cycle detected*"])
        assert result.ret != 0

    def test_three_node_cycle(self, pytester):
        """A->B->C->A cycle."""
        pytester.makepyfile(
            test_three_cycle=textwrap.dedent("""\
                import pytest

                @pytest.mark.dag(depends=["test_c"])
                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_c():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.stderr.fnmatch_lines(["*cycle detected*"])
        assert result.ret != 0


# ===========================================================================
# 5.  Missing dependencies
# ===========================================================================

class TestMissingDependencies:
    def test_strict_mode_errors_on_missing(self, pytester):
        """Missing dependencies raise a collection error."""
        pytester.makepyfile(
            test_missing=textwrap.dedent("""\
                import pytest

                @pytest.mark.dag(depends=["test_does_not_exist"])
                def test_x():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.stderr.fnmatch_lines(["*dependency not found*"])
        assert result.ret != 0

# ===========================================================================
# 6.  Full nodeid references
# ===========================================================================

class TestFullNodeidReferences:
    def test_cross_file_full_nodeid(self, pytester):
        """Dependency specified as full nodeid across two test files."""
        pytester.makepyfile(
            test_first=textwrap.dedent("""\
                def test_alpha():
                    pass
            """)
        )
        pytester.makepyfile(
            test_second=textwrap.dedent("""\
                import pytest

                @pytest.mark.dag(depends=["test_first.py::test_alpha"])
                def test_beta():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=2)
        
        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1
        
        pos_alpha = line_of("test_alpha")
        pos_beta = line_of("test_beta")
        assert 0 <= pos_alpha < pos_beta


# ===========================================================================
# 7.  YAML-based external DAG
# ===========================================================================

class TestYamlDag:
    def test_yaml_dag_basic(self, pytester):
        """External YAML file drives ordering."""
        pytester.makepyfile(
            test_yaml=textwrap.dedent("""\
                def test_a():
                    pass

                def test_b():
                    pass

                def test_c():
                    pass
            """)
        )
        pytester.makefile(
            ".yaml",
            dag=textwrap.dedent("""\
                nodes:
                  - id: test_yaml.py::test_a
                  - id: test_yaml.py::test_b
                    depends: [test_yaml.py::test_a]
                  - id: test_yaml.py::test_c
                    depends: [test_yaml.py::test_b]
            """),
        )
        pytester.makeini("[pytest]\ndag_file = dag.yaml\n")
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=3)
        
        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1
        
        pos_a = line_of("test_a")
        pos_b = line_of("test_b")
        pos_c = line_of("test_c")
        assert 0 <= pos_a < pos_b < pos_c

    def test_yaml_plus_marker_union(self, pytester):
        """Marker deps and YAML deps are unioned, not replaced."""
        pytester.makepyfile(
            test_union=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                def test_b():
                    pass

                # marker says depends on test_a; yaml adds test_b
                @pytest.mark.dag(depends=["test_a"])
                def test_c():
                    pass
            """)
        )
        pytester.makefile(
            ".yaml",
            dag=textwrap.dedent("""\
                nodes:
                  - id: test_union.py::test_c
                    depends: [test_union.py::test_b]
            """),
        )
        pytester.makeini("[pytest]\ndag_file = dag.yaml\n")
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=3)
        
        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1
        
        pos_a = line_of("test_a")
        pos_b = line_of("test_b")
        pos_c = line_of("test_c")
        assert pos_a < pos_c
        assert pos_b < pos_c

    def test_yaml_failure_propagation(self, pytester):
        """Failure propagation works through YAML-defined deps."""
        pytester.makepyfile(
            test_yamlfail=textwrap.dedent("""\
                def test_a():
                    assert False

                def test_b():
                    pass
            """)
        )
        pytester.makefile(
            ".yaml",
            dag=textwrap.dedent("""\
                nodes:
                  - id: test_yamlfail.py::test_a
                  - id: test_yamlfail.py::test_b
                    depends: [test_yamlfail.py::test_a]
            """),
        )
        pytester.makeini("[pytest]\ndag_file = dag.yaml\n")
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(failed=1, skipped=1)


# ===========================================================================
# 8.  --dag-print-graph
# ===========================================================================

class TestDagPrintGraph:
    def test_dump_output(self, pytester):
        """--dag-print-graph prints execution order to stdout."""
        pytester.makepyfile(
            test_dump=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "--dag-print-graph")
        result.stdout.fnmatch_lines(["*pytest-dag: computed execution order*"])


# ===========================================================================
# 9.  Skip reason message format
# ===========================================================================

class TestSkipReason:
    def test_skip_reason_contains_dep_nodeid(self, pytester):
        """The skip reason must name the blocking dependency."""
        pytester.makepyfile(
            test_reason=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "-rs")
        result.stdout.fnmatch_lines(["*pytest-dag: blocked by*test_a*FAILED*"])

    def test_skip_reason_multi_blockers(self, pytester):
        """Skip reason lists all blocking deps when multiple fail."""
        pytester.makepyfile(
            test_multireason=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                def test_b():
                    assert False

                @pytest.mark.dag(depends=["test_a", "test_b"])
                def test_c():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "-rs")
        out = result.stdout.str()
        assert "test_a" in out
        assert "test_b" in out


# ===========================================================================
# 10.  depends as string (not list)
# ===========================================================================

class TestDependsFormats:
    def test_depends_string(self, pytester):
        """@pytest.mark.dag(depends='test_a') (single string) works."""
        pytester.makepyfile(
            test_strformat=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dag(depends="test_a")
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=2)

    def test_depends_list(self, pytester):
        """@pytest.mark.dag(depends=['test_a', 'test_b']) works."""
        pytester.makepyfile(
            test_listformat=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_a", "test_b"])
                def test_c():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=3)


# ===========================================================================
# 11.  Unit tests for internal graph logic (no pytest subprocess)
# ===========================================================================

class TestGraphUnit:
    """Unit tests against graph.py helpers directly (no subprocess)."""

    def test_parse_block_on_valid(self):
        from pytest_dag.config import Outcome, parse_block_on

        result = parse_block_on("fail,skip")
        assert Outcome.FAILED in result
        assert Outcome.SKIPPED in result

    def test_parse_block_on_single(self):
        from pytest_dag.config import Outcome, parse_block_on

        result = parse_block_on("fail")
        assert result == {Outcome.FAILED}

    def test_parse_block_on_invalid(self):
        from pytest_dag.config import parse_block_on

        with pytest.raises(ValueError, match="unknown --dag-block-on-outcomes"):
            parse_block_on("nonsense")

    def test_dag_state_add_dependency(self):
        from pytest_dag.config import DagState

        state = DagState()
        state.add_dependency("b", "a")
        assert "a" in state.deps["b"]
        assert "b" in state.reverse_deps["a"]

    def test_dag_state_blocking_deps(self):
        from pytest_dag.config import DagState, Outcome

        state = DagState()
        state.add_dependency("b", "a")
        state.results["a"] = Outcome.FAILED
        blocked = state.blocking_deps("b", {Outcome.FAILED})
        assert blocked == ["a"]

    def test_dag_state_not_blocked_when_passed(self):
        from pytest_dag.config import DagState, Outcome

        state = DagState()
        state.add_dependency("b", "a")
        state.results["a"] = Outcome.PASSED
        blocked = state.blocking_deps("b", {Outcome.FAILED})
        assert blocked == []

    def test_topo_sort_simple(self):
        """graph.topo_sort returns items in dependency order."""
        from pytest_dag.config import DagState
        from pytest_dag.graph import topo_sort

        class FakeItem:
            def __init__(self, nid):
                self.nodeid = nid

        items = [FakeItem("c"), FakeItem("b"), FakeItem("a")]
        state = DagState()
        state.add_dependency("b", "a")
        state.add_dependency("c", "b")

        sorted_items = topo_sort(items, state)
        ids = [it.nodeid for it in sorted_items]
        assert ids.index("a") < ids.index("b")
        assert ids.index("b") < ids.index("c")

    def test_detect_cycles_raises(self):
        """graph._detect_cycles raises UsageError on a cycle."""
        from pytest_dag.config import DagState
        from pytest_dag.graph import _detect_cycles

        state = DagState()
        state.add_dependency("a", "b")
        state.add_dependency("b", "a")

        with pytest.raises(pytest.UsageError, match="cycle"):
            _detect_cycles(state)

    def test_dag_skipped_always_blocks_regardless_of_block_on(self):
        """DAG_SKIPPED blocks dependents even when block_on only contains FAILED."""
        from pytest_dag.config import DagState, Outcome

        state = DagState()
        state.add_dependency("c", "b")
        state.results["b"] = Outcome.DAG_SKIPPED

        # With only FAILED in block_on, DAG_SKIPPED must still block.
        blocked = state.blocking_deps("c", {Outcome.FAILED})
        assert blocked == ["b"]

    def test_user_skipped_does_not_block_by_default(self):
        """Plain SKIPPED (user skip) does NOT block with default block_on={FAILED}."""
        from pytest_dag.config import DagState, Outcome

        state = DagState()
        state.add_dependency("b", "a")
        state.results["a"] = Outcome.SKIPPED

        blocked = state.blocking_deps("b", {Outcome.FAILED})
        assert blocked == []

    def test_dag_skipped_blocks_with_empty_block_on(self):
        """DAG_SKIPPED blocks even when block_on is an empty set."""
        from pytest_dag.config import DagState, Outcome

        state = DagState()
        state.add_dependency("b", "a")
        state.results["a"] = Outcome.DAG_SKIPPED

        # block_on is empty but DAG_SKIPPED is always added internally
        blocked = state.blocking_deps("b", set())
        assert "a" in blocked

    def test_blocking_deps_no_result_yet(self):
        """A dep with no result recorded yet does not block the dependent."""
        from pytest_dag.config import DagState, Outcome

        state = DagState()
        state.add_dependency("b", "a")
        # No result recorded for "a" yet

        blocked = state.blocking_deps("b", {Outcome.FAILED})
        assert blocked == []


# ===========================================================================
# 12.  DAG_SKIPPED cascade (the core new behaviour)
# ===========================================================================

class TestDagSkipCascade:
    """Tests for the DAG_SKIPPED outcome introduced to fix silent cascade breaks.

    A test skipped BY THE PLUGIN (because its dep failed/was dag-skipped) is
    recorded as DAG_SKIPPED, which always cascades to its own dependents
    regardless of --dag-block-on-outcomes.  This is distinct from a user-initiated
    pytest.skip() call (SKIPPED), which only cascades when the user opts in
    via --dag-block-on-outcomes fail,skip.
    """

    def test_dag_skip_cascades_automatically(self, pytester):
        """A fails -> B dag-skipped -> C dag-skipped with DEFAULT settings.

        This is the core regression test for the bug where test_yaml_end ran
        even though test_yaml_middle was dag-skipped.  No extra flags needed.
        """
        pytester.makepyfile(
            test_cascade_auto=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False, "intentional failure"

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_c():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        # test_a fails, test_b dag-skipped, test_c must also be dag-skipped —
        # no --dag-block-on-outcomes flag required.
        result.assert_outcomes(failed=1, skipped=2)

    def test_dag_skip_cascades_three_levels_deep(self, pytester):
        """A fails -> B dag-skipped -> C dag-skipped -> D dag-skipped (3 hops)."""
        pytester.makepyfile(
            test_deepcascade=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_c():
                    pass

                @pytest.mark.dag(depends=["test_c"])
                def test_d():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(failed=1, skipped=3)

    def test_user_skip_does_not_cascade_by_default(self, pytester):
        """A manually skipped -> B should still run (user skip != dag skip)."""
        pytester.makepyfile(
            test_userskip=textwrap.dedent("""\
                import pytest

                @pytest.mark.skip(reason="intentional manual skip")
                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        # test_a is user-skipped (SKIPPED, not DAG_SKIPPED); test_b must run.
        result.assert_outcomes(skipped=1, passed=1)

    def test_user_skip_cascades_with_block_on_flag(self, pytester):
        """A manually skipped -> B blocked only when --dag-block-on-outcomes includes skip."""
        pytester.makepyfile(
            test_userskipblock=textwrap.dedent("""\
                import pytest

                @pytest.mark.skip(reason="manual skip")
                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "--dag-block-on-outcomes", "fail,skip")
        result.assert_outcomes(skipped=2)

    def test_dag_skip_reason_names_dag_skipped_outcome(self, pytester):
        """When C is blocked by dag-skipped B, the reason mentions DAG_SKIPPED."""
        pytester.makepyfile(
            test_dagskreason=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_b"])
                def test_c():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "-rs")
        # test_c is blocked by test_b which has DAG_SKIPPED outcome
        result.stdout.fnmatch_lines(["*pytest-dag: blocked by*test_b*DAG_SKIPPED*"])

    def test_sibling_not_affected_by_cascade(self, pytester):
        """A fails -> B dag-skipped, but C (sibling, no dep on B) still runs."""
        pytester.makepyfile(
            test_siblingcascade=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                # test_c depends on test_a too, so it's also dag-skipped
                @pytest.mark.dag(depends=["test_a"])
                def test_c():
                    pass

                # test_d has no dependency at all — must run freely
                def test_d():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(failed=1, skipped=2, passed=1)

    def test_mixed_cascade_fan_in(self, pytester):
        """D depends on B (dag-skipped) AND C (passed): D is blocked by B."""
        pytester.makepyfile(
            test_fanin=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                def test_c():
                    pass

                @pytest.mark.dag(depends=["test_b", "test_c"])
                def test_d():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        # test_a fails, test_b dag-skipped, test_c passes, test_d blocked by test_b
        result.assert_outcomes(failed=1, skipped=2, passed=1)


# ===========================================================================
# 13.  YAML DAG cascade (regression for reported bug)
# ===========================================================================

class TestYamlDagCascade:
    def test_yaml_dag_skip_cascade_two_hops(self, pytester):
        """YAML: start fails -> middle dag-skipped -> end dag-skipped.

        This is the exact scenario the user reported: running only test_yaml.py
        with start→middle→end chain; end was incorrectly running even though
        middle was dag-skipped.
        """
        pytester.makepyfile(
            test_yaml_chain=textwrap.dedent("""\
                def test_yaml_start():
                    assert False, "start failed"

                def test_yaml_middle():
                    pass

                def test_yaml_end():
                    pass
            """)
        )
        pytester.makefile(
            ".yaml",
            dag=textwrap.dedent("""\
                nodes:
                  - id: test_yaml_chain.py::test_yaml_start
                  - id: test_yaml_chain.py::test_yaml_middle
                    depends: [test_yaml_chain.py::test_yaml_start]
                  - id: test_yaml_chain.py::test_yaml_end
                    depends: [test_yaml_chain.py::test_yaml_middle]
            """),
        )
        pytester.makeini("[pytest]\ndag_file = dag.yaml\n")
        result = pytester.runpytest_subprocess("-v")
        # start fails, middle dag-skipped, end must also be dag-skipped
        result.assert_outcomes(failed=1, skipped=2)

    def test_yaml_dag_skip_cascade_three_hops(self, pytester):
        """YAML: 4-node linear chain; root fails, remaining three dag-skipped."""
        pytester.makepyfile(
            test_yaml_long=textwrap.dedent("""\
                def test_s1():
                    assert False

                def test_s2():
                    pass

                def test_s3():
                    pass

                def test_s4():
                    pass
            """)
        )
        pytester.makefile(
            ".yaml",
            dag=textwrap.dedent("""\
                nodes:
                  - id: test_yaml_long.py::test_s1
                  - id: test_yaml_long.py::test_s2
                    depends: [test_yaml_long.py::test_s1]
                  - id: test_yaml_long.py::test_s3
                    depends: [test_yaml_long.py::test_s2]
                  - id: test_yaml_long.py::test_s4
                    depends: [test_yaml_long.py::test_s3]
            """),
        )
        pytester.makeini("[pytest]\ndag_file = dag.yaml\n")
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(failed=1, skipped=3)


# ===========================================================================
# 14.  Edge cases
# ===========================================================================

class TestEdgeCases:
    def test_diamond_dependency_all_pass(self, pytester):
        """Diamond: A -> B, A -> C, B+C -> D.  All pass, D runs last."""
        pytester.makepyfile(
            test_diamond=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_c():
                    pass

                @pytest.mark.dag(depends=["test_b", "test_c"])
                def test_d():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=4)

        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1

        pos_a = line_of("test_a")
        pos_b = line_of("test_b")
        pos_c = line_of("test_c")
        pos_d = line_of("test_d")
        assert pos_a < pos_b
        assert pos_a < pos_c
        assert pos_b < pos_d
        assert pos_c < pos_d

    def test_diamond_root_fails_all_cascade(self, pytester):
        """Diamond: A fails -> B dag-skipped, C dag-skipped, D dag-skipped."""
        pytester.makepyfile(
            test_diamond_fail=textwrap.dedent("""\
                import pytest

                def test_a():
                    assert False

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                @pytest.mark.dag(depends=["test_a"])
                def test_c():
                    pass

                @pytest.mark.dag(depends=["test_b", "test_c"])
                def test_d():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(failed=1, skipped=3)

    def test_dep_on_later_defined_test(self, pytester):
        """test_b is listed first in the file but depends on test_a (listed after).

        The DAG reorder must place test_a before test_b regardless of file order.
        """
        pytester.makepyfile(
            test_reorder=textwrap.dedent("""\
                import pytest

                # test_b comes first in the file but must run second
                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass

                def test_a():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=2)

        def line_of(name):
            for i, l in enumerate(result.outlines):
                if "PASSED" in l and f"::{name} " in l:
                    return i
            return -1

        assert line_of("test_a") < line_of("test_b")

    def test_empty_depends_list_does_not_crash(self, pytester):
        """@pytest.mark.dag(depends=[]) is equivalent to no marker — no crash."""
        pytester.makepyfile(
            test_emptydeps=textwrap.dedent("""\
                import pytest

                @pytest.mark.dag(depends=[])
                def test_x():
                    pass

                def test_y():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        result.assert_outcomes(passed=2)

    def test_multiple_independent_chains(self, pytester):
        """Two separate chains run correctly without interfering with each other."""
        pytester.makepyfile(
            test_twochains=textwrap.dedent("""\
                import pytest

                # Chain 1: A1 -> B1
                def test_a1():
                    pass

                @pytest.mark.dag(depends=["test_a1"])
                def test_b1():
                    pass

                # Chain 2: A2 -> B2 (independent)
                def test_a2():
                    assert False

                @pytest.mark.dag(depends=["test_a2"])
                def test_b2():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v")
        # Chain 1: both pass; Chain 2: a2 fails, b2 dag-skipped
        result.assert_outcomes(passed=2, failed=1, skipped=1)

    def test_error_outcome_blocks_with_block_on_error(self, pytester):
        """A teardown error records ERROR; --dag-block-on-outcomes fail,error blocks dependent."""
        pytester.makepyfile(
            test_teardown_err=textwrap.dedent("""\
                import pytest

                @pytest.fixture
                def broken_teardown():
                    yield
                    raise RuntimeError("teardown exploded")

                def test_a(broken_teardown):
                    pass  # call phase passes; teardown will error

                @pytest.mark.dag(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess("-v", "--dag-block-on-outcomes", "fail,error")
        # test_a call passes but teardown errors → ERROR outcome → test_b blocked
        result.assert_outcomes(passed=1, errors=1, skipped=1)

    def test_no_tests_collected_does_not_crash(self, pytester):
        """An empty test file must not raise any plugin errors.

        pytest exits with code 5 (NO_TESTS_COLLECTED) — that is expected and
        not a plugin error.  We just ensure no crash (exit code 3/4) occurred.
        """
        pytester.makepyfile(test_empty="# no tests here\n")
        result = pytester.runpytest_subprocess("-v")
        # Exit code 5 = NO_TESTS_COLLECTED — acceptable; 0 also fine.
        # Any other code would indicate an unexpected crash.
        assert result.ret in (0, 5)


# ===========================================================================
# 15.  --migrate-from-pytest-dependency
# ===========================================================================

class TestMigration:
    """Integration and unit tests for the pytest-dependency → pytest-dag migration."""

    # -----------------------------------------------------------------------
    # Unit tests (no subprocess) for migrate.py helpers
    # -----------------------------------------------------------------------

    def test_parse_marker_defaults(self):
        """_parse_marker extracts name/depends/scope with correct defaults."""
        from pytest_dag.migrate import _parse_marker

        mark = pytest.mark.dependency(depends=["test_a"])
        info = _parse_marker(mark)
        assert info.name is None
        assert info.depends == ["test_a"]
        assert info.scope == "module"

    def test_parse_marker_full_kwargs(self):
        """_parse_marker handles name=, depends=, scope= kwargs."""
        from pytest_dag.migrate import _parse_marker

        mark = pytest.mark.dependency(
            name="my_test", depends=["other"], scope="session"
        )
        info = _parse_marker(mark)
        assert info.name == "my_test"
        assert info.depends == ["other"]
        assert info.scope == "session"

    def test_parse_marker_string_depends(self):
        """depends= as a plain string (not list) is normalised to a list."""
        from pytest_dag.migrate import _parse_marker

        mark = pytest.mark.dependency(depends="test_a")
        info = _parse_marker(mark)
        assert info.depends == ["test_a"]

    def test_remove_dependency_decorators_single_line(self, tmp_path):
        """Single-line @pytest.mark.dependency(...) is removed cleanly."""
        from pytest_dag.migrate import remove_dependency_decorators

        source = textwrap.dedent("""\
            import pytest

            @pytest.mark.dependency(name="a")
            def test_a():
                pass
        """)
        result = remove_dependency_decorators(source)
        assert "@pytest.mark.dependency" not in result
        assert "def test_a():" in result

    def test_remove_dependency_decorators_multiline(self, tmp_path):
        """Multi-line decorator is fully removed, other code preserved."""
        from pytest_dag.migrate import remove_dependency_decorators

        source = textwrap.dedent("""\
            import pytest

            @pytest.mark.dependency(
                name="b",
                depends=["test_a"],
            )
            def test_b():
                pass
        """)
        result = remove_dependency_decorators(source)
        assert "@pytest.mark.dependency" not in result
        assert "def test_b():" in result

    def test_remove_dependency_decorators_stacked(self):
        """Only @pytest.mark.dependency is removed; other decorators survive."""
        from pytest_dag.migrate import remove_dependency_decorators

        source = textwrap.dedent("""\
            import pytest

            @pytest.mark.slow
            @pytest.mark.dependency(depends=["test_a"])
            @pytest.mark.parametrize("x", [1, 2])
            def test_b(x):
                pass
        """)
        result = remove_dependency_decorators(source)
        assert "@pytest.mark.dependency" not in result
        assert "@pytest.mark.slow" in result
        assert "@pytest.mark.parametrize" in result
        assert "def test_b(x):" in result

    def test_remove_dependency_decorators_no_markers(self):
        """Source without dependency markers is returned unchanged."""
        from pytest_dag.migrate import remove_dependency_decorators

        source = textwrap.dedent("""\
            import pytest

            def test_a():
                pass

            @pytest.mark.slow
            def test_b():
                pass
        """)
        result = remove_dependency_decorators(source)
        assert result == source

    # -----------------------------------------------------------------------
    # Integration tests via pytester subprocess
    # -----------------------------------------------------------------------

    def test_dry_run_prints_yaml_preview(self, pytester):
        """--migrate-dry-run prints a YAML preview and does not write files."""
        pytester.makepyfile(
            test_migrate=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dependency(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--migrate-dry-run",
        )
        # Should exit cleanly
        assert result.ret == 0
        out = result.stdout.str()
        # Preview heading
        assert "DRY RUN" in out
        # YAML nodes must appear
        assert "nodes:" in out
        assert "test_migrate.py::test_a" in out
        assert "test_migrate.py::test_b" in out
        # test_b depends on test_a
        assert "test_migrate.py::test_a" in out
        # Summary line
        assert "Markers found" in out

    def test_dry_run_does_not_write_yaml(self, pytester):
        """--migrate-dry-run must NOT write the dag.yaml file."""
        pytester.makepyfile(
            test_nodisk=textwrap.dedent("""\
                import pytest

                def test_x():
                    pass
            """)
        )
        pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--migrate-dry-run",
            "--dag-file-out", "output_dag.yaml",
        )
        # File must NOT exist
        assert not (pytester.path / "output_dag.yaml").exists()

    def test_writes_yaml_file(self, pytester):
        """Without --migrate-dry-run the YAML is written to disk."""
        pytester.makepyfile(
            test_write=textwrap.dedent("""\
                import pytest

                def test_first():
                    pass

                @pytest.mark.dependency(depends=["test_first"])
                def test_second():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_out.yaml",
        )
        assert result.ret == 0

        yaml_path = pytester.path / "dag_out.yaml"
        assert yaml_path.exists()
        content = yaml_path.read_text()
        assert "nodes:" in content
        assert "test_write.py::test_first" in content
        assert "test_write.py::test_second" in content
        # Dependency edge must be present
        assert "test_write.py::test_first" in content

    def test_module_scope_resolution(self, pytester):
        """Bare name is resolved within the same module (default scope=module)."""
        pytester.makepyfile(
            test_modscope=textwrap.dedent("""\
                import pytest

                def test_alpha():
                    pass

                @pytest.mark.dependency(depends=["test_alpha"], scope="module")
                def test_beta():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_modscope.yaml",
        )
        assert result.ret == 0
        content = (pytester.path / "dag_modscope.yaml").read_text()
        # test_beta depends on test_alpha (resolved to nodeid)
        assert "test_modscope.py::test_alpha" in content
        assert "test_modscope.py::test_beta" in content
        # Verify dependency edge
        lines = content.splitlines()
        beta_idx = next(i for i, l in enumerate(lines) if "test_beta" in l)
        # The depends entry should come after test_beta's id line
        region = "\n".join(lines[beta_idx: beta_idx + 4])
        assert "test_alpha" in region

    def test_nodeid_ref_resolved_directly(self, pytester):
        """A depends= entry that already looks like a nodeid is mapped directly."""
        pytester.makepyfile(
            test_nid=textwrap.dedent("""\
                import pytest

                def test_base():
                    pass

                @pytest.mark.dependency(
                    depends=["test_nid.py::test_base"]
                )
                def test_derived():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_nid.yaml",
        )
        assert result.ret == 0
        content = (pytester.path / "dag_nid.yaml").read_text()
        assert "test_nid.py::test_base" in content
        assert "test_nid.py::test_derived" in content

    def test_session_scope_cross_file(self, pytester):
        """session scope can resolve a name defined in another file."""
        pytester.makepyfile(
            test_provider=textwrap.dedent("""\
                import pytest

                @pytest.mark.dependency(name="global_setup")
                def test_setup():
                    pass
            """)
        )
        pytester.makepyfile(
            test_consumer=textwrap.dedent("""\
                import pytest

                @pytest.mark.dependency(
                    depends=["global_setup"], scope="session"
                )
                def test_use():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_session.yaml",
        )
        assert result.ret == 0
        content = (pytester.path / "dag_session.yaml").read_text()
        # test_use's depends should resolve to test_provider.py::test_setup
        assert "test_provider.py::test_setup" in content

    def test_unresolved_dep_fails_preflight_and_writes_nothing(self, pytester):
        """Unresolvable refs fail preflight and no files are modified."""
        pytester.makepyfile(
            test_ghost=textwrap.dedent("""\
                import pytest

                @pytest.mark.dependency(depends=["nonexistent_test"])
                def test_consumer():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_ghost.yaml",
        )
        assert result.ret != 0
        assert not (pytester.path / "dag_ghost.yaml").exists()
        assert "@pytest.mark.dependency" in (pytester.path / "test_ghost.py").read_text()
        assert "failed preflight" in result.stderr.str().lower()

    def test_ambiguous_dep_fails_preflight_and_writes_nothing(self, pytester):
        """Ambiguous bare refs fail preflight and no files are modified."""
        pytester.makepyfile(
            test_a=textwrap.dedent("""\
                import pytest

                @pytest.mark.dependency(name="shared")
                def test_one():
                    pass
            """),
            test_b=textwrap.dedent("""\
                import pytest

                @pytest.mark.dependency(name="shared")
                def test_two():
                    pass
            """),
            test_c=textwrap.dedent("""\
                import pytest

                @pytest.mark.dependency(depends=["shared"])
                def test_consumer():
                    pass
            """),
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_ambiguous.yaml",
        )
        assert result.ret != 0
        assert not (pytester.path / "dag_ambiguous.yaml").exists()
        assert "@pytest.mark.dependency" in (pytester.path / "test_c.py").read_text()

    def test_migration_removes_markers(self, pytester):
        """Successful migration removes dependency markers from source files."""
        pytester.makepyfile(
            test_inplace=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.dependency(depends=["test_a"])
                def test_b():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_inplace.yaml",
        )
        assert result.ret == 0

        src = (pytester.path / "test_inplace.py").read_text()
        assert "@pytest.mark.dependency" not in src
        # Other code must be preserved
        assert "def test_a():" in src
        assert "def test_b():" in src

    def test_migration_preserves_other_decorators(self, pytester):
        """Stacked decorators: only @pytest.mark.dependency is removed."""
        pytester.makepyfile(
            test_stacked=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                @pytest.mark.slow
                @pytest.mark.dependency(depends=["test_a"])
                @pytest.mark.parametrize("x", [1])
                def test_b(x):
                    pass
            """)
        )
        pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_stacked.yaml",
        )
        src = (pytester.path / "test_stacked.py").read_text()
        assert "@pytest.mark.dependency" not in src
        assert "@pytest.mark.slow" in src
        assert "@pytest.mark.parametrize" in src

    def test_no_tests_run_in_migration_mode(self, pytester):
        """Migration mode exits without executing any test functions."""
        pytester.makepyfile(
            test_norun=textwrap.dedent("""\
                import pytest

                def test_should_not_run():
                    assert False, "This must not be executed in migration mode"

                @pytest.mark.dependency(depends=["test_should_not_run"])
                def test_dependent():
                    assert False
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--migrate-dry-run",
        )
        # Must succeed (no test failures) even though tests would fail
        assert result.ret == 0
        out = result.stdout.str()
        # Confirm no test was actually run
        assert "failed" not in out.lower() or "Markers found" in out

    def test_empty_depends_list_handled(self, pytester):
        """@pytest.mark.dependency(name="x") with no depends is valid."""
        pytester.makepyfile(
            test_namedonly=textwrap.dedent("""\
                import pytest

                @pytest.mark.dependency(name="named_root")
                def test_root():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag_namedonly.yaml",
        )
        assert result.ret == 0
        content = (pytester.path / "dag_namedonly.yaml").read_text()
        assert "test_namedonly.py::test_root" in content

    def test_generated_yaml_is_structurally_valid(self, pytester):
        """The generated dag.yaml has correct structure loadable by _load_yaml_deps."""
        import yaml as _yaml

        pytester.makepyfile(
            test_roundtrip=textwrap.dedent("""\
                import pytest

                def test_start():
                    pass

                @pytest.mark.dependency(depends=["test_start"])
                def test_middle():
                    pass

                @pytest.mark.dependency(depends=["test_middle"])
                def test_end():
                    pass
            """)
        )
        pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--dag-file-out", "dag.yaml",
        )
        yaml_path = pytester.path / "dag.yaml"
        assert yaml_path.exists()

        # Verify the YAML is structurally valid (parseable, has nodes key)
        content = yaml_path.read_text()
        data = _yaml.safe_load(content)
        assert isinstance(data, dict), "YAML root must be a mapping"
        assert "nodes" in data, "YAML must have a 'nodes' key"
        assert isinstance(data["nodes"], list), "'nodes' must be a list"

        # Every node must have an 'id' key
        for node in data["nodes"]:
            assert isinstance(node, dict), "each node must be a mapping"
            assert "id" in node, "each node must have an 'id'"

        # Collect all node ids for dependency-edge validation
        node_ids = {n["id"] for n in data["nodes"]}
        assert "test_roundtrip.py::test_start" in node_ids
        assert "test_roundtrip.py::test_middle" in node_ids
        assert "test_roundtrip.py::test_end" in node_ids

        # Verify dependency edges
        node_by_id = {n["id"]: n for n in data["nodes"]}
        middle = node_by_id["test_roundtrip.py::test_middle"]
        end = node_by_id["test_roundtrip.py::test_end"]
        assert "depends" in middle, "test_middle must have depends"
        assert "test_roundtrip.py::test_start" in middle["depends"]
        assert "depends" in end, "test_end must have depends"
        assert "test_roundtrip.py::test_middle" in end["depends"]

    def test_migration_summary_counts(self, pytester):
        """Migration summary reports correct tests scanned / markers / edges."""
        pytester.makepyfile(
            test_counts=textwrap.dedent("""\
                import pytest

                def test_a():
                    pass

                def test_b():
                    pass

                @pytest.mark.dependency(depends=["test_a"])
                def test_c():
                    pass

                @pytest.mark.dependency(depends=["test_a", "test_b"])
                def test_d():
                    pass
            """)
        )
        result = pytester.runpytest_subprocess(
            "--migrate-from-pytest-dependency",
            "--migrate-dry-run",
        )
        assert result.ret == 0
        out = result.stdout.str()
        # 4 tests scanned, 2 markers found, 3 dependency edges
        assert "Tests scanned" in out
        assert "Markers found" in out
        assert "Dependency edges" in out
