"""Platform-dependent code."""
