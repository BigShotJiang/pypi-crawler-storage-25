# windows/guest_window.py
from . import BaseWindow

class GuestWindow(BaseWindow):
    def __init__(self, user, conn, auth_window):
        super().__init__(user, conn, auth_window)

    def add_buttons(self, layout, table_name, table_widget):
        """Гость не имеет кнопок действий."""
        pass