# windows/__init__.py
from PyQt5.QtWidgets import (
    QMainWindow, QTabWidget, QWidget, QVBoxLayout,
    QTableWidget, QTableWidgetItem, QLineEdit,
    QPushButton, QHBoxLayout, QComboBox, QMessageBox,
    QToolBar
)
from PyQt5.QtCore import Qt
import sqlite3
from dialogs.record_dialog import RecordDialog

class BaseWindow(QMainWindow):
    def __init__(self, user, conn, auth_window):
        super().__init__()
        self.user = user
        self.conn = conn
        self.auth_window = auth_window
        self.setWindowTitle(f"{user['name_role'].capitalize()}: {user['fio']}")
        self.setGeometry(100, 100, 900, 600)

        # Панель инструментов с кнопкой "Назад"
        self.toolbar = QToolBar("Main Toolbar")
        self.addToolBar(self.toolbar)
        back_btn = QPushButton("⬅ Назад")
        back_btn.clicked.connect(self.back_to_auth)
        self.toolbar.addWidget(back_btn)

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.load_tables()

    def back_to_auth(self):
        self.close()
        self.auth_window.show()

    def load_tables(self):
        """Загружает таблицы из БД."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type = 'table'
            AND name NOT IN ('sqlite_sequence')
        """)
        tables = [row[0] for row in cursor.fetchall()]

        # Исключаем таблицы Users и Roles для всех, кроме админа
        if self.user['name_role'] != 'admin':
            tables = [t for t in tables if t not in ('Users', 'Roles')]

        for table in tables:
            self.tabs.addTab(self.create_tab(table), table)

    def create_tab(self, table_name):
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        # Поиск и фильтрация
        search_layout = QHBoxLayout()
        search_layout.setSpacing(10)

        search_input = QLineEdit()
        search_input.setPlaceholderText("Поиск по всем столбцам...")
        search_input.textChanged.connect(
            lambda text, t=table_name: self.filter_table(t, text, None)
        )

        filter_combo = QComboBox()
        filter_combo.addItem("Все столбцы")
        cursor = self.conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = [row[1] for row in cursor.fetchall()]

        for col in columns:
            filter_combo.addItem(col)

        filter_combo.currentTextChanged.connect(
            lambda col, t=table_name: self.update_filter_column(t, col, search_input)
        )

        search_layout.addWidget(search_input)
        search_layout.addWidget(filter_combo)
        layout.addLayout(search_layout)

        # Таблица
        table_widget = QTableWidget()
        table_widget.setSortingEnabled(True)
        table_widget.setEditTriggers(QTableWidget.NoEditTriggers)
        table_widget.verticalHeader().setVisible(False)
        table_widget.setAlternatingRowColors(True)
        table_widget.setSelectionBehavior(QTableWidget.SelectRows)

        # Кнопки (переопределяются в дочерних классах)
        self.add_buttons(layout, table_name, table_widget)

        layout.addWidget(table_widget)
        widget.setLayout(layout)
        self.load_table_data(table_name, table_widget)
        return widget

    def add_buttons(self, layout, table_name, table_widget):
        """Добавляет кнопки действия (переопределяется в дочерних классах)."""
        pass

    def load_table_data(self, table_name, table_widget):
        cursor = self.conn.cursor()
        cursor.execute(f"SELECT * FROM {table_name}")
        rows = cursor.fetchall()
        cols = [desc[0] for desc in cursor.description]

        table_widget.setRowCount(len(rows))
        table_widget.setColumnCount(len(cols))
        table_widget.setHorizontalHeaderLabels(cols)

        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                table_widget.setItem(i, j, QTableWidgetItem(str(val)))

    def filter_table(self, table_name, text, filter_column=None):
        tab = self.find_tab_by_table(table_name)
        if not tab:
            return

        table_widget = tab.findChild(QTableWidget)
        if not table_widget:
            return

        cursor = self.conn.cursor()

        if text:
            if filter_column and filter_column != "Все столбцы":
                query = f"SELECT * FROM {table_name} WHERE LOWER({filter_column}) LIKE ?"
                cursor.execute(query, (f"%{text.lower()}%",))
            else:
                cursor.execute(f"PRAGMA table_info({table_name})")
                columns = [row[1] for row in cursor.fetchall()]
                conditions = " OR ".join([f"LOWER({col}) LIKE ?" for col in columns])
                query = f"SELECT * FROM {table_name} WHERE {conditions}"
                cursor.execute(query, (f"%{text.lower()}%",) * len(columns))
        else:
            cursor.execute(f"SELECT * FROM {table_name}")

        rows = cursor.fetchall()
        table_widget.setRowCount(len(rows))
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                table_widget.setItem(i, j, QTableWidgetItem(str(val)))

    def update_filter_column(self, table_name, column, search_input):
        self.filter_table(table_name, search_input.text(), column)

    def find_tab_by_table(self, table_name):
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == table_name:
                return self.tabs.widget(i)
        return None

    def open_record_dialog(self, table_name, table_widget, record_data=None):
        """Открывает диалог добавления/редактирования записи."""
        cursor = self.conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = [row[1] for row in cursor.fetchall()]
        pk_col = next((col for col in columns if col.lower().startswith("id")), None)

        dialog = RecordDialog(self.conn, table_name, columns, record_data, pk_col)
        if dialog.exec():
            self.load_table_data(table_name, table_widget)

    # --- ДОБАВЛЕННЫЙ МЕТОД ---
    def open_edit_dialog(self, table_name, table_widget):
        """Открывает диалог редактирования (только если строка выбрана)."""
        row = table_widget.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Ошибка", "Выберите запись для редактирования!")
            return

        cursor = self.conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = [row[1] for row in cursor.fetchall()]

        record_data = {}
        for j, col in enumerate(columns):
            item = table_widget.item(row, j)
            record_data[col] = item.text() if item else ""

        self.open_record_dialog(table_name, table_widget, record_data)
    # -----------------------

    def delete_record(self, table_name, table_widget):
        row = table_widget.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Ошибка", "Выберите запись для удаления!")
            return

        confirm = QMessageBox.question(
            self, "Удаление", "Удалить выбранную запись?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm != QMessageBox.Yes:
            return

        cursor = self.conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name})")
        pk_col = cursor.fetchall()[0][1]

        pk_value = table_widget.item(row, 0).text()
        cursor.execute(f"DELETE FROM {table_name} WHERE {pk_col} = ?", (pk_value,))
        self.conn.commit()
        self.load_table_data(table_name, table_widget)