# windows/manager_window.py
from . import BaseWindow
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QLabel,
    QLineEdit, QHBoxLayout, QPushButton, QMessageBox
)


class ManagerWindow(BaseWindow):
    def __init__(self, user, conn, auth_window):
        super().__init__(user, conn, auth_window)

    def add_buttons(self, layout, table_name, table_widget):
        """Добавляет кнопки для менеджера (без удаления)."""
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)

        btn_add = QPushButton("Добавить")
        btn_add.clicked.connect(lambda: self.open_record_dialog(table_name, table_widget, None))

        btn_edit = QPushButton("Редактировать")
        btn_edit.clicked.connect(lambda: self.open_edit_dialog(table_name, table_widget))

        btn_layout.addWidget(btn_add)
        btn_layout.addWidget(btn_edit)
        layout.addLayout(btn_layout)