# register_window.py
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from PyQt5.QtCore import Qt
import requests

class RegisterWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Регистрация")
        self.setFixedSize(400, 450)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        title_label = QLabel("Регистрация")
        title_label.setStyleSheet("font-size: 20px; font-weight: bold; color: #4a90e2;")
        title_label.setAlignment(Qt.AlignCenter)

        self.fio_input = QLineEdit()
        self.fio_input.setPlaceholderText("ФИО")

        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("Email")

        self.phone_input = QLineEdit()
        self.phone_input.setPlaceholderText("Телефон")

        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText("Логин")

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Пароль")
        self.password_input.setEchoMode(QLineEdit.Password)

        self.repeat_password_input = QLineEdit()
        self.repeat_password_input.setPlaceholderText("Повторите пароль")
        self.repeat_password_input.setEchoMode(QLineEdit.Password)

        register_btn = QPushButton("Зарегистрироваться")
        register_btn.clicked.connect(self.register_user)
        register_btn.setFixedHeight(35)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: red; font-size: 14px;")
        self.status_label.setAlignment(Qt.AlignCenter)

        layout.addWidget(title_label)
        layout.addWidget(self.fio_input)
        layout.addWidget(self.email_input)
        layout.addWidget(self.phone_input)
        layout.addWidget(self.login_input)
        layout.addWidget(self.password_input)
        layout.addWidget(self.repeat_password_input)
        layout.addWidget(register_btn)
        layout.addWidget(self.status_label)

        self.setLayout(layout)

    def register_user(self):
        fio = self.fio_input.text().strip()
        email = self.email_input.text().strip()
        phone = self.phone_input.text().strip()
        login = self.login_input.text().strip()
        password = self.password_input.text().strip()
        repeat_password = self.repeat_password_input.text().strip()

        if not fio or not email or not phone or not login or not password:
            self.status_label.setText("Заполните все поля!")
            return

        if password != repeat_password:
            self.status_label.setText("Пароли не совпадают!")
            return

        try:
            response = requests.post(
                "http://127.0.0.1:8000/register",
                json={
                    "fio": fio,
                    "email": email,
                    "phone": phone,
                    "login": login,
                    "password": password
                }
            )
            if response.status_code == 200:
                QMessageBox.information(self, "Успех", "Регистрация прошла успешно!")
                self.accept()
            else:
                self.status_label.setText(response.json().get("detail", "Ошибка сервера!"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось подключиться к серверу: {e}")