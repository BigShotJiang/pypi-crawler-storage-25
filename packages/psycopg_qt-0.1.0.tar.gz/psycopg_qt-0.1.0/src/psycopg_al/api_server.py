# api_server.py
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import sqlite3
from hashlib import md5
import secrets
import re  # Для проверки email

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATABASE = "app.db"

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# --- Проверки (все на месте!) ---
def validate_fio(fio: str) -> bool:
    """Проверяет, что в ФИО нет цифр."""
    return not any(char.isdigit() for char in fio)

def validate_email(email: str) -> bool:
    """Проверяет корректность email."""
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(pattern, email) is not None

def validate_phone(phone: str) -> bool:
    """Проверяет, что телефон содержит только цифры."""
    return phone.isdigit() and len(phone) >= 10

def validate_password(password: str) -> bool:
    """Проверяет, что пароль не короче 4 символов."""
    return len(password) >= 4

# --- Инициализация БД ---
def init_db():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Roles (
            id_role INTEGER PRIMARY KEY AUTOINCREMENT,
            name_role TEXT UNIQUE NOT NULL
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Users (
            id_users INTEGER PRIMARY KEY AUTOINCREMENT,
            fio TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            login TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            id_role INTEGER NOT NULL,
            FOREIGN KEY (id_role) REFERENCES Roles(id_role)
        )
    """)
    cursor.execute("INSERT OR IGNORE INTO Roles (name_role) VALUES ('admin')")
    cursor.execute("INSERT OR IGNORE INTO Roles (name_role) VALUES ('manager')")
    cursor.execute("INSERT OR IGNORE INTO Roles (name_role) VALUES ('guest')")
    hashed_password = md5("123".encode()).hexdigest()
    cursor.execute("""
        INSERT OR IGNORE INTO Users (fio, email, phone, login, password, id_role)
        VALUES ('Администратор', 'admin@mail.com', '111', 'admin', ?, 1)
    """, (hashed_password,))
    conn.commit()
    conn.close()

# --- Модели данных ---
class LoginRequest(BaseModel):
    login: str
    password: str

class RegisterRequest(BaseModel):
    fio: str
    email: str
    phone: str
    login: str
    password: str

# --- Эндпоинты ---
@app.post("/login")
async def login(request: LoginRequest):
    login = request.login
    password = request.password
    conn = get_db()
    cursor = conn.cursor()
    hashed_password = md5(password.encode()).hexdigest()
    cursor.execute("""
        SELECT Users.*, Roles.name_role
        FROM Users
        JOIN Roles ON Users.id_role = Roles.id_role
        WHERE login = ? AND password = ?
    """, (login, hashed_password))
    user = cursor.fetchone()
    conn.close()
    if user:
        return {"success": True, "user": dict(user)}
    else:
        raise HTTPException(status_code=401, detail="Неверный логин или пароль!")

@app.post("/register")
async def register(request: RegisterRequest):
    """Регистрация с проверками (ФИО без цифр + остальные опционально)."""
    # --- Проверка ФИО (обязательная) ---
    if not validate_fio(request.fio):
        raise HTTPException(status_code=400, detail="ФИО не должно содержать цифры!")

    # --- Остальные проверки (закомментированы, но можно раскомментировать) ---
    # if not validate_email(request.email):
    #     raise HTTPException(status_code=400, detail="Некорректный email!")
    # if not validate_phone(request.phone):
    #     raise HTTPException(status_code=400, detail="Телефон должен содержать только цифры!")
    # if not validate_password(request.password):
    #     raise HTTPException(status_code=400, detail="Пароль должен быть не короче 4 символов!")

    conn = get_db()
    cursor = conn.cursor()

    # Проверяем уникальность логина
    cursor.execute("SELECT 1 FROM Users WHERE login = ?", (request.login,))
    if cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Логин уже занят!")

    # Хешируем пароль
    hashed_password = md5(request.password.encode()).hexdigest()
    cursor.execute("""
        INSERT INTO Users (fio, email, phone, login, password, id_role)
        VALUES (?, ?, ?, ?, ?, 3)
    """, (request.fio, request.email, request.phone, request.login, hashed_password))
    conn.commit()
    conn.close()
    return {"success": True, "message": "Регистрация успешна!"}

@app.get("/captcha")
async def get_captcha(login: str = Query(...)):
    captcha_text = ''.join(secrets.choice('0123456789') for _ in range(4))
    return {"captcha": captcha_text}

init_db()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)