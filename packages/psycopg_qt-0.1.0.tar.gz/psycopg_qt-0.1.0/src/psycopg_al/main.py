# main.py
import sys
import os
from PyQt5.QtWidgets import QApplication
from auth_window import AuthWindow
from db import init_db

def load_style_sheet():
    """Загружает стили из файла style.css."""
    style_path = os.path.join("styles", "style.css")
    if not os.path.exists(style_path):
        print(f"Файл стилей не найден: {style_path}")
        return ""
    try:
        with open(style_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        print(f"Ошибка чтения файла стилей: {e}")
        return ""

if __name__ == "__main__":
    init_db()  # Инициализируем БД
    app = QApplication(sys.argv)
    app.setStyleSheet(load_style_sheet())  # Применяем стили
    auth_window = AuthWindow()  # Создаём окно авторизации
    auth_window.show()
    sys.exit(app.exec_())