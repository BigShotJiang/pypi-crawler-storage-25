# dialogs/record_dialog.py
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit,
    QPushButton, QMessageBox
)

class RecordDialog(QDialog):
    def __init__(self, conn, table_name, columns, record_data=None, pk_col=None):
        """
        Универсальный диалог для добавления/редактирования записей.
        Args:
            conn: Соединение с БД.
            table_name: Имя таблицы.
            columns: Список столбцов.
            record_data: Данные для редактирования (если None — режим добавления).
            pk_col: Имя первичного ключа текущей таблицы.
        """
        super().__init__()
        self.conn = conn
        self.table_name = table_name
        self.columns = columns
        self.record_data = record_data
        self.pk_col = pk_col
        self.inputs = {}

        self.setWindowTitle(
            "Редактирование записи" if record_data else "Добавление записи"
        )
        self.setFixedWidth(400)
        self.setup_ui()

    def setup_ui(self):
        """Настраивает интерфейс диалога."""
        layout = QVBoxLayout()
        form = QFormLayout()

        for col in self.columns:
            # Пропускаем только первичный ключ текущей таблицы
            if col == self.pk_col:
                continue

            line_edit = QLineEdit()
            if self.record_data and col in self.record_data:
                line_edit.setText(str(self.record_data[col]))

            self.inputs[col] = line_edit
            form.addRow(col, line_edit)

        # Если редактируем запись, добавляем скрытое поле для PK
        if self.record_data and self.pk_col:
            pk_value = str(self.record_data.get(self.pk_col, ""))
            hidden_edit = QLineEdit(pk_value)
            hidden_edit.setVisible(False)
            self.inputs[self.pk_col] = hidden_edit

        # Кнопки
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(self.save)
        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(self.reject)

        btn_layout = QVBoxLayout()
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)

        layout.addLayout(form)
        layout.addLayout(btn_layout)
        self.setLayout(layout)

    def save(self):
        """Сохраняет данные в БД."""
        try:
            cursor = self.conn.cursor()

            if self.record_data:
                # Редактирование записи
                pk_value = self.inputs[self.pk_col].text() if self.pk_col else None
                set_clause = []
                values = []

                for col, widget in self.inputs.items():
                    if col == self.pk_col:
                        continue
                    set_clause.append(f"{col} = ?")
                    values.append(widget.text())

                query = f"""
                    UPDATE {self.table_name}
                    SET {', '.join(set_clause)}
                    WHERE {self.pk_col} = ?
                """
                values.append(pk_value)
                cursor.execute(query, values)
            else:
                # Добавление новой записи (исключаем только pk_col)
                cols = [col for col in self.inputs.keys() if col != self.pk_col]
                placeholders = ", ".join(["?"] * len(cols))
                query = f"""
                    INSERT INTO {self.table_name} ({', '.join(cols)})
                    VALUES ({placeholders})
                """
                values = [self.inputs[col].text() for col in cols]
                cursor.execute(query, values)

            self.conn.commit()
            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить: {e}")