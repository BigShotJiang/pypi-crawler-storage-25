import sqlite3
import os
from hashlib import md5

DB_PATH = "app.db"

def get_connection():
    """Возвращает соединение с БД."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Чтобы обращаться к столбцам по имени
    return conn

def init_db():
    """Инициализирует БД и создаёт таблицы."""
    conn = get_connection()
    cursor = conn.cursor()

    # Таблица ролей
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Roles (
            id_role INTEGER PRIMARY KEY AUTOINCREMENT,
            name_role TEXT UNIQUE NOT NULL
        )
    """)

    # Таблица пользователей
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Users (
            id_users INTEGER PRIMARY KEY AUTOINCREMENT,
            fio TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            login TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            id_role INTEGER NOT NULL,
            FOREIGN KEY (id_role) REFERENCES Roles(id_role)
        )
    """)

    # Пример таблиц
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Products (
            id_product INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL,
            quantity INTEGER DEFAULT 0
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Orders (
            id_order INTEGER PRIMARY KEY AUTOINCREMENT,
            id_product INTEGER NOT NULL,
            id_user INTEGER NOT NULL,
            order_date TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            FOREIGN KEY (id_product) REFERENCES Products(id_product),
            FOREIGN KEY (id_user) REFERENCES Users(id_users)
        )
    """)

    # Добавляем роли
    cursor.execute("INSERT OR IGNORE INTO Roles (name_role) VALUES ('admin')")
    cursor.execute("INSERT OR IGNORE INTO Roles (name_role) VALUES ('manager')")
    cursor.execute("INSERT OR IGNORE INTO Roles (name_role) VALUES ('guest')")

    # Добавляем тестового админа (login: admin, password: 123)
    hashed_password = md5("123".encode()).hexdigest()
    cursor.execute("""
        INSERT OR IGNORE INTO Users (fio, email, phone, login, password, id_role)
        VALUES ('Администратор', 'admin@mail.com', '111', 'admin', ?, 1)
    """, (hashed_password,))

    conn.commit()
    conn.close()

def execute_query(query, params=(), fetch=True):
    """Выполняет SQL-запрос и возвращает результат (если fetch=True)."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    if fetch:
        result = cursor.fetchall()
    else:
        result = None
    conn.commit()
    conn.close()
    return result