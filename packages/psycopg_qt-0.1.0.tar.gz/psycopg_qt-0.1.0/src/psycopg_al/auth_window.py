# auth_window.py
from PyQt5.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QDialog
from PyQt5.QtCore import Qt
import requests
import sqlite3
from captcha_dialog import SliderCaptcha

API_URL = "http://127.0.0.1:8000"

class AuthWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Авторизация")
        self.setFixedSize(350, 300)
        self.failed_attempts = 0
        self.captcha_required = False
        self.setup_ui()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        title_label = QLabel("Авторизация")
        title_label.setStyleSheet("font-size: 20px; font-weight: bold; color: #4a90e2;")
        title_label.setAlignment(Qt.AlignCenter)

        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText("Логин")

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Пароль")
        self.password_input.setEchoMode(QLineEdit.Password)

        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)

        login_btn = QPushButton("Войти")
        login_btn.setObjectName("login_btn")
        login_btn.clicked.connect(self.authorize)
        login_btn.setFixedHeight(35)

        register_btn = QPushButton("Зарегистрироваться")
        register_btn.clicked.connect(self.open_register_window)
        register_btn.setFixedHeight(35)

        btn_layout.addWidget(login_btn)
        btn_layout.addWidget(register_btn)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: red; font-size: 14px;")
        self.status_label.setAlignment(Qt.AlignCenter)

        layout.addWidget(title_label)
        layout.addWidget(self.login_input)
        layout.addWidget(self.password_input)
        layout.addLayout(btn_layout)
        layout.addWidget(self.status_label)

        central_widget.setLayout(layout)

    def open_register_window(self):
        from register_window import RegisterWindow
        register_window = RegisterWindow(self)
        if register_window.exec():
            self.status_label.setText("Регистрация успешна! Войдите в систему.")

    def authorize(self):
        login = self.login_input.text().strip()
        password = self.password_input.text().strip()

        if not login or not password:
            self.status_label.setText("Введите логин и пароль!")
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль!")
            return

        # Проверяем, нужно ли капчу
        if self.failed_attempts >= 3 or self.captcha_required:
            if not self.show_captcha_and_block():
                return  # Пользователь не прошёл капчу или отменил
            # Капча пройдена: обнуляем счётчик и флаг
            self.failed_attempts = 0
            self.captcha_required = False

        # Пытаемся авторизоваться
        self.try_login(login, password)

    def try_login(self, login, password):
        """Пытается авторизовать пользователя."""
        try:
            response = requests.post(
                f"{API_URL}/login",
                json={"login": login, "password": password}
            )
            if response.status_code == 200:
                user_data = response.json()["user"]
                self.open_main_window(user_data)
            elif response.status_code == 401:
                self.failed_attempts += 1
                self.status_label.setText(f"Неверный логин или пароль! ({self.failed_attempts}/3)")
                QMessageBox.warning(self, "Ошибка", f"Неверный логин или пароль! (Попытка {self.failed_attempts}/3)")
                if self.failed_attempts >= 3:
                    self.captcha_required = True
            else:
                self.status_label.setText("Ошибка сервера!")
                QMessageBox.critical(self, "Ошибка", "Ошибка сервера!")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось подключиться к серверу: {e}")

    def show_captcha_and_block(self):
        """Показывает слайдер-капчу и блокирует окно авторизации."""
        self.login_input.setEnabled(False)
        self.password_input.setEnabled(False)
        login_btn = self.findChild(QPushButton, "login_btn")
        if login_btn:
            login_btn.setEnabled(False)

        captcha_dialog = SliderCaptcha(self)
        result = captcha_dialog.exec_() == QDialog.Accepted

        self.login_input.setEnabled(True)
        self.password_input.setEnabled(True)
        if login_btn:
            login_btn.setEnabled(True)

        return result

    def open_main_window(self, user_data):
        from windows.admin_window import AdminWindow
        from windows.manager_window import ManagerWindow
        from windows.guest_window import GuestWindow
        conn = sqlite3.connect("app.db")
        if user_data["name_role"] == "admin":
            self.main_window = AdminWindow(user_data, conn, self)
        elif user_data["name_role"] == "manager":
            self.main_window = ManagerWindow(user_data, conn, self)
        else:
            self.main_window = GuestWindow(user_data, conn, self)
        self.main_window.show()
        self.hide()