/* Общие стили для всех окон */
QMainWindow {
    background-color: #f5f5f5;
}

/* Стили для панели инструментов */
QToolBar {
    background-color: #f5f5f5;
    border-bottom: 1px solid #e0e0e0;
}

/* Стили для кнопок в панели инструментов */
QToolBar QPushButton {
    background-color: #4a90e2;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 6px 12px;
    font-size: 14px;
}

QToolBar QPushButton:hover {
    background-color: #357abd;
}

/* Стили для вкладок */
QTabWidget {
    background-color: #f5f5f5;
    border: none;
}

QTabWidget::pane {
    background-color: white;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
    margin-top: -1px;
}

QTabBar {
    qproperty-drawBase: 0;
    border-bottom: 1px solid #e0e0e0;
}

QTabBar::tab {
    background-color: #e0e0e0;
    color: #333;
    padding: 8px 15px;
    border: none;
    border-radius: 5px 5px 0 0;
    margin-right: 2px;
}

QTabBar::tab:selected {
    background-color: #4a90e2;
    color: white;
}

/* Стили для таблиц */
QTableWidget {
    background-color: white;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
    gridline-color: #e0e0e0;
}

QHeaderView {
    background-color: #4a90e2;
    color: white;
    font-weight: bold;
    padding: 6px;
    border: none;
    border-radius: 0;
}

QHeaderView::section {
    background-color: #4a90e2;
    color: white;
    padding: 8px;
    border: none;
    border-right: 1px solid #357abd;
}

QHeaderView::section:last {
    border-right: none;
}

/* Стили для кнопок */
QPushButton {
    background-color: #4a90e2;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 8px 16px;
    font-size: 14px;
    min-width: 100px;
}

QPushButton:hover {
    background-color: #357abd;
}

QPushButton:pressed {
    background-color: #2a6aa0;
}

/* Стили для полей ввода */
QLineEdit {
    background-color: white;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
    padding: 6px 10px;
    font-size: 14px;
}

QLineEdit:focus {
    border: 1px solid #4a90e2;
}

/* Стили для выпадающего списка */
QComboBox {
    background-color: white;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
    padding: 6px 10px;
    font-size: 14px;
}

QComboBox:focus {
    border: 1px solid #4a90e2;
}

QComboBox QAbstractItemView {
    background-color: white;
    border: 1px solid #e0e0e0;
    selection-background-color: #4a90e2;
    selection-color: white;
}

/* Стили для меток (QLabel) */
QLabel {
    font-size: 14px;
    color: #333;
    margin-bottom: 5px;
}

QLabel#title {
    font-size: 20px;
    font-weight: bold;
    color: #4a90e2;
    margin-bottom: 15px;
}

/* Стили для диалоговых окон */
QDialog {
    background-color: #f5f5f5;
}

QMessageBox {
    background-color: #f5f5f5;
}

QMessageBox QLabel {
    font-size: 14px;
    color: #333;
}

QMessageBox QPushButton {
    min-width: 80px;
}