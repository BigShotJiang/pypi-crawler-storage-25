# captcha_dialog.py
from PyQt5.QtWidgets import (
    QDialog, QWidget, QVBoxLayout, QHBoxLayout, QSpacerItem, QSizePolicy,
    QGraphicsView, QGraphicsScene, QGraphicsPixmapItem, QSlider, QPushButton, QMessageBox
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPen, QColor, QPixmap

class SliderCaptcha(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("⚙️ Подтвердите, что вы не робот")
        self.setFixedSize(750, 500)
        self.part_size = 150
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)  # Layout напрямую для QDialog
        main_layout.setContentsMargins(10, 10, 10, 10)

        # Сцена для капчи
        self.scene = QGraphicsScene()
        self.view = QGraphicsView(self.scene)
        self.view.setFixedSize(300, 300)
        self.scene.setSceneRect(0, 0, 300, 300)

        # Загружаем изображения из папки images
        static_parts = ["images/part_0.png", "images/part_1.png", "images/part_2.png"]
        moving_part = "images/part_3.png"

        for i, part in enumerate(static_parts):
            pixmap = QPixmap(part).scaled(self.part_size, self.part_size)
            item = QGraphicsPixmapItem(pixmap)
            item.setPos((i % 2) * self.part_size, (i // 2) * self.part_size)
            self.scene.addItem(item)

        self.moving_pixmap = QPixmap(moving_part).scaled(self.part_size, self.part_size)
        self.moving_item = QGraphicsPixmapItem(self.moving_pixmap)
        self.moving_item.setPos(-self.part_size, self.part_size)
        self.scene.addItem(self.moving_item)

        # Подсказка (зелёная рамка)
        self.correct_indicator = self.scene.addRect(
            self.part_size, self.part_size, self.part_size, self.part_size,
            QPen(QColor(0, 255, 0, 150), 3)
        )
        self.correct_indicator.setVisible(False)

        # Ползунок
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, self.part_size * 2)
        self.slider.setFixedWidth(400)
        self.slider.valueChanged.connect(self.update_moving_part)

        # Кнопки
        self.check_button = QPushButton("Проверить")
        self.check_button.clicked.connect(self.check_assembly)
        self.check_button.setStyleSheet("""
            QPushButton { background-color: #4a90e2; color: white; border: none; border-radius: 5px; padding: 8px 16px; }
            QPushButton:hover { background-color: #357abd; }
        """)

        self.cancel_button = QPushButton("Отмена")
        self.cancel_button.clicked.connect(self.reject)
        self.cancel_button.setStyleSheet("""
            QPushButton { background-color: #f8f9fa; color: #4a90e2; border: 1px solid #4a90e2; border-radius: 5px; padding: 8px 16px; }
        """)

        # Layout
        captcha_layout = QHBoxLayout()
        captcha_layout.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))
        captcha_layout.addWidget(self.view)
        captcha_layout.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))

        slider_layout = QHBoxLayout()
        slider_layout.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))
        slider_layout.addWidget(self.slider)
        slider_layout.addWidget(self.check_button)
        slider_layout.addWidget(self.cancel_button)
        slider_layout.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))

        main_layout.addSpacerItem(QSpacerItem(20, 50, QSizePolicy.Minimum, QSizePolicy.Expanding))
        main_layout.addLayout(captcha_layout)
        main_layout.addLayout(slider_layout)
        main_layout.addSpacerItem(QSpacerItem(20, 50, QSizePolicy.Minimum, QSizePolicy.Expanding))

    def update_moving_part(self):
        value = self.slider.value()
        new_x = value - self.part_size
        self.moving_item.setPos(new_x, self.part_size)
        self.correct_indicator.setVisible(abs(new_x - self.part_size) < 5)

    def check_assembly(self):
        if abs(self.moving_item.x() - self.part_size) < 5:
            self.accept()  # Закрывает диалог с успехом
        else:
            QMessageBox.warning(self, "Ошибка", "Попробуйте ещё раз!")