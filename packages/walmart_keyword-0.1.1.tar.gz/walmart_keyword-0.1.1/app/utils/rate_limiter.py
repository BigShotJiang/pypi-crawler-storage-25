#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
请求频率限制器
基于令牌桶算法，避免短时间内大量请求触发反爬检测
"""

import time
import random
import logging
from collections import deque
from threading import Lock

logger = logging.getLogger(__name__)


class RateLimiter:
    """
    请求频率限制器（令牌桶算法）

    功能：
    - 限制每分钟最大请求数
    - 限制每小时最大请求数
    - 自动退避（请求失败时延长间隔）
    - 线程安全

    工作原理：
    1. 维护两个时间戳队列（分钟级、小时级）
    2. 每次请求前检查队列是否已满
    3. 如果已满，等待直到最旧的请求超时
    4. 失败时触发指数退避

    Examples:
        >>> # 创建限制器：每分钟最多15次，每小时最多500次
        >>> limiter = RateLimiter(max_per_minute=15, max_per_hour=500)

        >>> # 请求前获取许可（会阻塞）
        >>> limiter.acquire()

        >>> # 请求失败时触发退避
        >>> limiter.report_failure()
    """

    def __init__(self, max_per_minute: int = 15, max_per_hour: int = 500):
        """
        初始化频率限制器

        Args:
            max_per_minute: 每分钟最大请求数
            max_per_hour: 每小时最大请求数
        """
        self.max_per_minute = max_per_minute
        self.max_per_hour = max_per_hour

        # 请求时间戳队列（使用 deque 自动限制长度）
        self.minute_queue = deque(maxlen=max_per_minute)
        self.hour_queue = deque(maxlen=max_per_hour)

        # 线程锁（保证线程安全）
        self.lock = Lock()

        # 退避时间（秒）
        self.backoff_seconds = 0

        logger.info(f"频率限制器初始化: {max_per_minute}/分钟, {max_per_hour}/小时")

    def acquire(self) -> None:
        """
        获取请求许可（阻塞直到可以请求）

        内部逻辑：
        1. 检查分钟限制（最旧请求是否超过60秒）
        2. 检查小时限制（最旧请求是否超过3600秒）
        3. 应用退避时间（如果之前有失败）
        4. 记录当前请求时间
        """
        with self.lock:
            now = time.time()

            # ========== 1. 检查分钟限制 ==========
            if len(self.minute_queue) >= self.max_per_minute:
                oldest_minute = self.minute_queue[0]
                wait_time = 60 - (now - oldest_minute)

                if wait_time > 0:
                    # 添加随机抖动（0.5-2秒），避免多个实例同步
                    jitter = random.uniform(0.5, 2.0)
                    total_wait = wait_time + jitter

                    logger.info(
                        f"分钟限制已满 ({self.max_per_minute}/分钟)，"
                        f"等待 {total_wait:.1f}秒"
                    )
                    time.sleep(total_wait)
                    now = time.time()

            # ========== 2. 检查小时限制 ==========
            if len(self.hour_queue) >= self.max_per_hour:
                oldest_hour = self.hour_queue[0]
                wait_time = 3600 - (now - oldest_hour)

                if wait_time > 0:
                    # 小时限制等待时间较长，添加更大的随机抖动
                    jitter = random.uniform(5, 15)
                    total_wait = wait_time + jitter

                    logger.warning(
                        f"小时限制已满 ({self.max_per_hour}/小时)，"
                        f"等待 {total_wait:.1f}秒"
                    )
                    time.sleep(total_wait)
                    now = time.time()

            # ========== 3. 应用退避时间 ==========
            if self.backoff_seconds > 0:
                logger.info(f"退避等待 {self.backoff_seconds:.1f}秒")
                time.sleep(self.backoff_seconds)

                # 退避时间衰减（每次减少1秒，避免永久退避）
                self.backoff_seconds = max(0, self.backoff_seconds - 1)
                now = time.time()

            # ========== 4. 记录请求时间 ==========
            self.minute_queue.append(now)
            self.hour_queue.append(now)

    def report_failure(self) -> None:
        """
        报告请求失败（触发退避）

        退避策略：
        - 指数退避：backoff = backoff * 1.5 + 3
        - 最大退避时间：60秒
        - 目的：请求失败时自动减速，给服务器"降温"时间
        """
        with self.lock:
            # 指数退避公式
            new_backoff = self.backoff_seconds * 1.5 + 3

            # 限制最大退避时间（避免无限增长）
            self.backoff_seconds = min(60, new_backoff)

            logger.warning(
                f"请求失败，触发退避 (当前退避: {self.backoff_seconds:.1f}秒)"
            )

    def report_success(self) -> None:
        """
        报告请求成功（重置退避）

        成功时快速重置退避，恢复正常速度
        """
        with self.lock:
            if self.backoff_seconds > 0:
                self.backoff_seconds = max(0, self.backoff_seconds - 2)
                logger.debug(f"请求成功，退避减少 (剩余: {self.backoff_seconds:.1f}秒)")

    def get_stats(self) -> dict:
        """
        获取当前统计信息

        Returns:
            dict: 统计数据
                - minute_requests: 最近1分钟请求数
                - hour_requests: 最近1小时请求数
                - backoff_seconds: 当前退避时间
        """
        with self.lock:
            now = time.time()

            # 清理过期请求（分钟级）
            minute_requests = sum(
                1 for t in self.minute_queue
                if now - t < 60
            )

            # 清理过期请求（小时级）
            hour_requests = sum(
                1 for t in self.hour_queue
                if now - t < 3600
            )

            return {
                'minute_requests': minute_requests,
                'hour_requests': hour_requests,
                'backoff_seconds': self.backoff_seconds,
            }

    def reset(self) -> None:
        """
        重置限制器（清空所有记录）

        使用场景：
        - 测试时清空历史
        - IP切换后重新计数
        """
        with self.lock:
            self.minute_queue.clear()
            self.hour_queue.clear()
            self.backoff_seconds = 0
            logger.info("频率限制器已重置")


if __name__ == '__main__':
    # 测试频率限制器
    logging.basicConfig(level=logging.INFO)

    print("测试频率限制器（每分钟最多3次）:")
    limiter = RateLimiter(max_per_minute=3, max_per_hour=10)

    # 模拟10次请求
    for i in range(10):
        print(f"\n请求 {i+1}:")
        limiter.acquire()
        print(f"  已允许 (统计: {limiter.get_stats()})")

        # 模拟失败（每3次触发1次）
        if (i + 1) % 3 == 0:
            print("  [模拟失败] 触发退避")
            limiter.report_failure()

    print("\n测试完成")
