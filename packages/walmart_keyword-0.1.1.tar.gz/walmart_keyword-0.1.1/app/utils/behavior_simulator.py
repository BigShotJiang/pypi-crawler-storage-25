#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
行为模拟工具
模拟真实人类浏览行为，降低被检测为机器人的概率
"""

import time
import random
import logging
from typing import Literal

logger = logging.getLogger(__name__)

# 延迟分布类型
DelayDistribution = Literal['normal', 'exponential', 'uniform']
# 滚动类型
ScrollType = Literal['read', 'scan', 'search']


def human_like_delay(
    min_sec: float = 2.0,
    max_sec: float = 5.0,
    distribution: DelayDistribution = 'normal'
) -> float:
    """
    模拟真实人类延迟（非均匀分布）

    真实用户的操作间隔不是均匀分布的，而是符合特定的统计规律：
    - normal（正态分布）：大多数延迟集中在中间值附近
    - exponential（指数分布）：短延迟概率高，长延迟概率低（快速浏览模式）
    - uniform（均匀分布）：所有延迟概率相同（最简单但最不真实）

    Args:
        min_sec: 最小延迟（秒）
        max_sec: 最大延迟（秒）
        distribution: 延迟分布类型

    Returns:
        float: 实际延迟的秒数

    Examples:
        >>> # SKU之间的间隔：平均5秒，范围3-8秒
        >>> delay = human_like_delay(3, 8, 'normal')

        >>> # 页面加载后等待：平均2秒，范围1-3秒
        >>> delay = human_like_delay(1, 3, 'normal')

        >>> # 快速浏览模式：短延迟概率高
        >>> delay = human_like_delay(0.5, 3, 'exponential')
    """
    if distribution == 'normal':
        # 正态分布（高斯分布）
        # 中间值概率最高，两端概率逐渐降低
        mean = (min_sec + max_sec) / 2
        std = (max_sec - min_sec) / 4  # 标准差取范围的1/4
        delay = random.normalvariate(mean, std)

    elif distribution == 'exponential':
        # 指数分布
        # 短延迟概率高，长延迟概率低（符合快速浏览行为）
        lambda_param = 1 / min_sec
        delay = random.expovariate(lambda_param) + min_sec

    else:  # uniform
        # 均匀分布（传统随机延迟）
        delay = random.uniform(min_sec, max_sec)

    # 限制范围（避免超出预期）
    delay = max(min_sec, min(max_sec, delay))

    logger.debug(f"延迟 {delay:.2f}秒 (分布: {distribution})")
    time.sleep(delay)
    return delay


def human_like_scroll(page, scroll_type: ScrollType = 'read') -> None:
    """
    模拟真实人类滚动（非均匀速度、有暂停）

    真实用户的滚动行为有明显特征：
    - 不是一次性滚动到底部
    - 速度不均匀（快慢交替）
    - 有多次暂停（"阅读"内容）
    - 有时会回滚（重新查看）

    Args:
        page: DrissionPage 页面对象
        scroll_type: 滚动模式
            - 'read': 阅读模式（慢速滚动，多次暂停）
            - 'scan': 扫描模式（快速滚动到底部，然后回滚）
            - 'search': 搜索模式（跳跃式滚动）

    Examples:
        >>> # 商品页加载后：模拟阅读商品信息
        >>> human_like_scroll(page, 'read')

        >>> # 价格提取失败时：模拟查找价格
        >>> human_like_scroll(page, 'search')
    """
    try:
        if scroll_type == 'read':
            # 阅读模式：慢速滚动，有多次暂停
            logger.debug("滚动模式: 阅读")

            # 随机滚动2-4次
            scroll_count = random.randint(2, 4)
            for i in range(scroll_count):
                # 滚动一小段（200-400像素）
                scroll_amount = random.randint(200, 400)
                page.scroll.down(scroll_amount)

                # 暂停"阅读"（0.5-1.5秒）
                time.sleep(random.uniform(0.5, 1.5))

            # 30%概率回滚（真实用户会回看）
            if random.random() < 0.3:
                scroll_back = random.randint(100, 200)
                page.scroll.up(scroll_back)
                logger.debug(f"回滚 {scroll_back}px")
                time.sleep(random.uniform(0.3, 0.8))

        elif scroll_type == 'scan':
            # 扫描模式：快速滚动到底部，然后回滚
            logger.debug("滚动模式: 扫描")

            page.scroll.to_bottom()
            time.sleep(random.uniform(0.2, 0.5))

            # 回滚到中间位置
            target_position = random.randint(300, 600)
            page.scroll.to_location(target_position)
            time.sleep(random.uniform(0.3, 0.6))

        elif scroll_type == 'search':
            # 搜索模式：跳跃式滚动（模拟查找特定内容）
            logger.debug("滚动模式: 搜索")

            # 随机跳转到几个位置
            positions = [0.2, 0.4, 0.6, 0.8]
            random.shuffle(positions)

            # 访问2-3个位置
            visit_count = random.randint(2, 3)
            for pos in positions[:visit_count]:
                page.scroll.to_see(pos)
                time.sleep(random.uniform(0.3, 0.8))

        else:
            logger.warning(f"未知滚动类型: {scroll_type}，使用默认滚动")
            page.scroll.to_half()
            time.sleep(0.5)

    except Exception as e:
        logger.debug(f"滚动操作失败: {e}")


def move_mouse_randomly(page, num_moves: int = 3) -> None:
    """
    随机移动鼠标（模拟真实用户）

    真实用户在浏览页面时，鼠标会随机移动：
    - 可能触发元素的 hover 事件
    - 可能激活懒加载
    - 增加行为真实性

    Args:
        page: DrissionPage 页面对象
        num_moves: 移动次数

    Examples:
        >>> # 页面加载后：随机移动2次
        >>> move_mouse_randomly(page, 2)

        >>> # 验证处理前：随机移动1次
        >>> move_mouse_randomly(page, 1)

    Note:
        DrissionPage 支持 page.actions.move_to(x, y) 移动鼠标
    """
    try:
        for i in range(num_moves):
            # 生成随机页面位置（避免边缘）
            x = random.randint(100, 1200)
            y = random.randint(100, 800)

            # 移动鼠标
            try:
                page.actions.move_to((x, y))
                logger.debug(f"鼠标移动到 ({x}, {y})")
                time.sleep(random.uniform(0.1, 0.3))
            except AttributeError:
                # DrissionPage 版本可能不支持 move_to
                logger.debug("当前版本不支持鼠标移动")
                break
            except Exception as e:
                logger.debug(f"鼠标移动失败: {e}")

    except Exception as e:
        logger.debug(f"鼠标移动操作失败: {e}")


if __name__ == '__main__':
    # 测试延迟分布
    logging.basicConfig(level=logging.DEBUG)

    print("测试延迟分布（各执行5次）:")
    print("\n1. 正态分布（范围 2-5秒）:")
    for _ in range(5):
        start = time.time()
        human_like_delay(2, 5, 'normal')
        print(f"  实际延迟: {time.time() - start:.2f}秒")

    print("\n2. 指数分布（范围 1-4秒）:")
    for _ in range(5):
        start = time.time()
        human_like_delay(1, 4, 'exponential')
        print(f"  实际延迟: {time.time() - start:.2f}秒")

    print("\n3. 均匀分布（范围 1-3秒）:")
    for _ in range(5):
        start = time.time()
        human_like_delay(1, 3, 'uniform')
        print(f"  实际延迟: {time.time() - start:.2f}秒")
