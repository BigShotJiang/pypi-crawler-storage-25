#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数据模型模块"""

from .ranking_result import RankingResult

__all__ = ['RankingResult']
