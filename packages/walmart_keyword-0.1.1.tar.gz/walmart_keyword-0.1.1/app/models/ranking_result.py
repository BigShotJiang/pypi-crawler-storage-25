#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
排名结果数据模型
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional


@dataclass
class RankingResult:
    keyword: str
    keyword_group: str
    ad_positions: List[int] = field(default_factory=list)
    ad_skus: List[str] = field(default_factory=list)
    organic_positions: List[int] = field(default_factory=list)
    organic_skus: List[str] = field(default_factory=list)
    status: str = "success"  # "success" | "error" | "no_result"
    error_message: Optional[str] = None
    detected_at: datetime = field(default_factory=datetime.now)

    @property
    def has_young_electric(self) -> bool:
        return len(self.ad_positions) > 0 or len(self.organic_positions) > 0

    def format_ad_positions(self) -> str:
        return '&'.join(str(p) for p in self.ad_positions) if self.ad_positions else '-'

    def format_ad_skus(self) -> str:
        return '/'.join(self.ad_skus) if self.ad_skus else '-'

    def format_organic_positions(self) -> str:
        return '&'.join(str(p) for p in self.organic_positions) if self.organic_positions else '-'

    def format_organic_skus(self) -> str:
        return '/'.join(self.organic_skus) if self.organic_skus else '-'

    def to_dict(self) -> dict:
        return {
            'keyword': self.keyword,
            'keyword_group': self.keyword_group,
            'ad_positions': self.ad_positions,
            'ad_skus': self.ad_skus,
            'organic_positions': self.organic_positions,
            'organic_skus': self.organic_skus,
            'status': self.status,
            'error_message': self.error_message,
            'detected_at': self.detected_at.isoformat(),
        }
