#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""选择器模块"""

from .walmart_selectors import WalmartSelectors, WalmartTimeouts
from .walmart_search_selectors import WalmartSearchSelectors, WalmartSearchTimeouts

__all__ = [
    'WalmartSelectors',
    'WalmartTimeouts',
    'WalmartSearchSelectors',
    'WalmartSearchTimeouts',
]
