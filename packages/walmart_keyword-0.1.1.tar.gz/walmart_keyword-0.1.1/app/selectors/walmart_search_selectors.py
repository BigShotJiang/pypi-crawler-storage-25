#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
沃尔玛搜索结果页面选择器
基于 2026-04-14 Chrome 实测验证

DrissionPage 选择器语法：
  - @attr=value  → 属性选择器
  - tag:name     → 标签选择器
  - css:selector → CSS 选择器
  - text=xxx     → 文本精确匹配
  - text:xxx     → 文本包含匹配

Chrome 实测要点（2026-04-14）：
  - 主搜索结果通过 data-testid="item-stack" 容器区分（共 2 个，19 + 33 = 52 张卡片）
  - 推荐区（"4 stars and above"、"Shop trending items"）卡片不在 item-stack 内
  - 推荐区 section 嵌套在外层主 section 内，closest('section') 不可靠
  - item-stack 内所有卡片都有 data-automation-id="product-title"
  - 推荐区卡片没有 product-title
  - Sponsored 文本检测通过 card.text 正常工作
"""


class WalmartSearchSelectors:
    """搜索结果页选择器（DrissionPage 原生语法）"""

    # === 主搜索结果容器 ===
    # data-testid="item-stack" 是区分主搜索结果与推荐区的最可靠标记
    # 页面通常有 2 个 item-stack（第1段 ~19项 + 第2段 ~33项）
    ITEM_STACK = '@data-testid=item-stack'

    # === 商品卡片 ===
    ALL_PRODUCT_CARDS = 'css:[data-item-id]'
    PRODUCT_TITLE = '@data-automation-id=product-title'
    PRODUCT_PRICE = '@data-automation-id=product-price'
    PRODUCT_IMAGE = '@data-testid=productTileImage'
    PRODUCT_LINK = 'css:a[link-identifier]'

    # === 卡片属性名（用于 ele.attr() 读取） ===
    ATTR_DCA_ID = 'data-dca-id'
    ATTR_ITEM_ID = 'data-item-id'

    # === 广告标识 ===
    SPONSORED_TEXT = 'Sponsored'

    # === 页面状态 ===
    # 2026-04-14 Chrome 验证：搜索框无 data-testid="search-box"
    # 实际搜索表单 data-testid="search-form"，输入框 <input type="search" name="q">
    SEARCH_FORM = '@data-testid=search-form'
    SEARCH_INPUT = 'css:input[type="search"][name="q"]'
    NO_RESULTS = 'text=No results'
    NEXT_PAGE = '@data-testid=NextPage'

    # === 反爬检测（复用 WalmartAbby） ===
    HEADER_LOGO = 'css:a.header-logo'
    SPARK_ICON = 'css:span.elc-icon-spark'


class WalmartSearchTimeouts:
    """超时常量（秒）"""
    QUICK = 0.5
    SHORT = 1
    NORMAL = 2
    LONG = 5
    PAGE_LOAD = 15
