#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
关键词读取器
从钉钉表格的「关键词」Sheet 读取关键词分组
"""

import logging
from typing import Dict, List

from app.dingtalk_doc_reader import DingTalkDocReader
from app.config import settings

logger = logging.getLogger(__name__)


class KeywordReader:
    """从钉钉表格读取关键词分组

    表格结构（「关键词」Sheet）：
        - 第1行: 关键词组名称（Bike Rack, Power Jack, ...）
        - 第2行起: 该组下的搜索关键词
        - 遇到空单元格停止读取该列

    返回: Dict[str, List[str]]
        如 {"Bike Rack": ["bicycles rack", "bike rack for hitch", ...]}
    """

    def __init__(self, doc_reader: DingTalkDocReader = None):
        self.doc_reader = doc_reader or DingTalkDocReader()
        self.sheet_name = settings.KEYWORD_SHEET_NAME

    def read(self) -> Dict[str, List[str]]:
        """读取关键词分组"""
        if not self.doc_reader.is_enabled():
            logger.warning("钉钉文档功能未启用")
            return {}

        try:
            doc_info = self.doc_reader.extract_doc_info()
            if not doc_info or not doc_info.get('workbook_id'):
                logger.error("无法获取文档信息")
                return {}

            workbook_id = doc_info['workbook_id']

            sheet_id = self.doc_reader._find_sheet_by_name(workbook_id, self.sheet_name)
            if not sheet_id:
                logger.error(f"未找到工作表: {self.sheet_name}")
                return {}

            logger.info(f"读取关键词工作表: {self.sheet_name}")

            # 读取整个 sheet 数据（A1:Z100 足够覆盖）
            data = self.doc_reader._read_sheet_range_single(
                workbook_id, sheet_id, "A1:Z100"
            )

            if not data or not data[0]:
                logger.warning("关键词工作表数据为空")
                return {}

            return self._parse_keyword_groups(data)

        except Exception as e:
            logger.error(f"读取关键词失败: {e}")
            return {}

    def _parse_keyword_groups(self, data: List[List[str]]) -> Dict[str, List[str]]:
        """解析关键词分组数据"""
        keyword_groups = {}
        header_row = data[0]

        for col_idx, group_name in enumerate(header_row):
            if not group_name or not str(group_name).strip():
                continue

            group_name = str(group_name).strip()
            keywords = []

            for row_idx in range(1, len(data)):
                row = data[row_idx]
                if col_idx >= len(row):
                    break

                cell = row[col_idx]
                if not cell or not str(cell).strip():
                    break  # 遇到空单元格停止

                keywords.append(str(cell).strip())

            if keywords:
                keyword_groups[group_name] = keywords
                logger.info(f"关键词组 '{group_name}': {len(keywords)} 个关键词")
            else:
                logger.warning(f"关键词组 '{group_name}' 没有关键词，跳过")

        logger.info(f"共读取 {len(keyword_groups)} 个关键词组")
        return keyword_groups
