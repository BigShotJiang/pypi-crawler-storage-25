#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SKU 映射表读取器
从钉钉表格的「SKU映射表」Sheet 读取 data-dca-id 到 SKU 的映射
"""

import logging
from typing import Dict

from app.dingtalk_doc_reader import DingTalkDocReader
from app.config import settings

logger = logging.getLogger(__name__)


class SKUMappingReader:
    """从钉钉表格读取 SKU 映射表

    表格结构（「SKU映射表」Sheet）：
        - A列: data-dca-id（= usItemId）
        - B列: 内部 SKU 编号
        - 第1行起即为数据（无标题行）

    返回: Dict[str, str]
        如 {"10693716730": "SKU-001", ...}
    """

    def __init__(self, doc_reader: DingTalkDocReader = None):
        self.doc_reader = doc_reader or DingTalkDocReader()
        self.sheet_name = settings.SKU_MAPPING_SHEET_NAME

    def read(self) -> Dict[str, str]:
        """读取 SKU 映射表"""
        if not self.doc_reader.is_enabled():
            logger.warning("钉钉文档功能未启用")
            return {}

        try:
            doc_info = self.doc_reader.extract_doc_info()
            if not doc_info or not doc_info.get('workbook_id'):
                logger.error("无法获取文档信息")
                return {}

            workbook_id = doc_info['workbook_id']

            sheet_id = self.doc_reader._find_sheet_by_name(workbook_id, self.sheet_name)
            if not sheet_id:
                logger.error(f"未找到工作表: {self.sheet_name}")
                return {}

            logger.info(f"读取 SKU 映射表: {self.sheet_name}")

            data = self.doc_reader._read_sheet_range_single(
                workbook_id, sheet_id, "A1:B1000"
            )

            if not data:
                logger.warning("SKU 映射表数据为空")
                return {}

            return self._parse_mapping(data)

        except Exception as e:
            logger.error(f"读取 SKU 映射表失败: {e}")
            return {}

    def _parse_mapping(self, data) -> Dict[str, str]:
        """解析映射数据"""
        mapping = {}
        skip_count = 0

        for row_idx, row in enumerate(data, start=1):
            if not row or len(row) < 1:
                continue

            dca_id = str(row[0]).strip() if row[0] else ""
            sku = str(row[1]).strip() if len(row) > 1 and row[1] else ""

            if not dca_id:
                continue

            if not sku:
                skip_count += 1
                continue

            mapping[dca_id] = sku

        logger.info(f"SKU 映射表: {len(mapping)} 条映射, {skip_count} 条跳过(无SKU)")
        return mapping
