#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
沃尔玛关键词排名监控 - 统一启动入口

运行模式：
- 默认: 定时任务模式（使用 CRON_EXPRESSION 配置）
- --once: 单次执行模式
"""

import os
import sys
import time
import signal
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from dotenv import load_dotenv


def load_env_config():
    """加载环境变量配置（优先级：当前目录 > 用户目录 > 系统环境变量）"""
    cwd_env = Path.cwd() / ".env"
    if cwd_env.exists():
        load_dotenv(cwd_env, override=True)
        print(f"[配置] 已加载: {cwd_env}")
        return

    home_env = Path.home() / ".walmart-keyword" / ".env"
    if home_env.exists():
        load_dotenv(home_env, override=True)
        print(f"[配置] 已加载: {home_env}")
        return

    print("[配置] 未找到 .env 文件，使用系统环境变量")
    print(f"[提示] 可在以下位置创建 .env 文件:")
    print(f"       - {cwd_env}")
    print(f"       - {home_env}")


load_env_config()

CRON_EXPRESSION = os.getenv("CRON_EXPRESSION", "0 8 * * *")


def setup_logging():
    """配置日志"""
    log_dir = "data"
    os.makedirs(log_dir, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(log_dir, 'app.log'), encoding='utf-8'),
            logging.StreamHandler()
        ]
    )


def run_keyword_monitor_task():
    """执行关键词排名监控任务"""
    logger = logging.getLogger(__name__)

    from app.readers.keyword_reader import KeywordReader
    from app.readers.sku_mapping_reader import SKUMappingReader
    from app.recorders.ranking_recorder import RankingRecorder
    from app.spiders.walmart_search_spider import WalmartSearchSpider
    from app.notifier import ding_talk_notifier
    from app.dingtalk_doc_reader import DingTalkDocReader
    from app.config import settings

    start_time = datetime.now()
    logger.info("=" * 60)
    logger.info(f"关键词排名监控任务开始: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info("=" * 60)

    # 在外层声明，确保异常时也能保存部分进度
    all_results = {}
    doc_reader = None
    spider_warnings = []

    try:
        # 共享 DingTalk 文档读取器
        doc_reader = DingTalkDocReader()

        # 1. 读取关键词分组
        keyword_reader = KeywordReader(doc_reader)
        keyword_groups = keyword_reader.read()

        if not keyword_groups:
            logger.warning("没有读取到关键词，任务结束")
            return

        total_keywords = sum(len(kws) for kws in keyword_groups.values())
        logger.info(f"读取到 {len(keyword_groups)} 个关键词组，共 {total_keywords} 个关键词")

        # 2. 读取 SKU 映射表
        sku_reader = SKUMappingReader(doc_reader)
        sku_mapping = sku_reader.read()
        logger.info(f"读取到 {len(sku_mapping)} 条 SKU 映射")

        # 3. 发送开始通知
        title = "沃尔玛关键词排名监控启动"
        text = f"""### 沃尔玛关键词排名监控启动

**启动时间**: {start_time.strftime('%Y-%m-%d %H:%M:%S')}

**关键词组数**: {len(keyword_groups)}

**关键词总数**: {total_keywords}

---

正在搜索关键词排名..."""
        ding_talk_notifier.send_markdown(title, text, is_at_all=False)

        # 4. 执行搜索爬取
        user_data_path = settings.CHROME_USER_DATA_PATH or None

        with WalmartSearchSpider(user_data_path=user_data_path) as spider:
            all_results = spider.run(keyword_groups, sku_mapping)
            spider_warnings = spider.fallback_warnings  # 收集降级告警

        # 5. 写入钉钉表格
        recorder = RankingRecorder(doc_reader)
        write_success = 0
        write_fail = 0

        for group_name, results in all_results.items():
            keywords = keyword_groups.get(group_name, [])
            success = recorder.write_group_results(group_name, keywords, results)
            if success:
                write_success += 1
            else:
                write_fail += 1

        # 本地备份
        recorder.save_local_backup(all_results)

        # 6. 发送完成通知
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()

        # 统计
        total_success = 0
        total_error = 0
        total_ye_found = 0
        total_rankings = 0
        group_summaries = []
        failed_keywords_list = []

        for group_name, results in all_results.items():
            group_ye_count = 0
            group_ranking_count = 0
            group_kw_total = len(results)

            for r in results:
                if r.status == 'success':
                    total_success += 1
                    if r.has_young_electric:
                        group_ye_count += 1
                        group_ranking_count += len(r.ad_positions) + len(r.organic_positions)
                else:
                    total_error += 1
                    failed_keywords_list.append(f"- {r.keyword}: {r.error_message or '未知错误'}")

            total_ye_found += group_ye_count
            total_rankings += group_ranking_count

            if group_ye_count > 0:
                group_summaries.append(
                    f"- **{group_name}**: {group_ye_count}/{group_kw_total} 个关键词发现 Young Electric"
                    f"（共 {group_ranking_count} 个排名）"
                )

        # 构建通知消息
        summary_text = "\n".join(group_summaries) if group_summaries else "- 未发现任何 Young Electric 排名"
        failed_text = ""
        if failed_keywords_list:
            failed_text = "\n\n#### 失败关键词\n" + "\n".join(failed_keywords_list[:10])
            if len(failed_keywords_list) > 10:
                failed_text += f"\n...(还有 {len(failed_keywords_list) - 10} 个)"

        # 降级告警
        warning_text = ""
        if spider_warnings:
            warning_text = "\n\n#### 告警\n" + "\n".join(f"- {w}" for w in spider_warnings)

        title = "沃尔玛关键词排名监控完成"
        text = f"""### 沃尔玛关键词排名监控

**执行时间**: {start_time.strftime('%Y-%m-%d %H:%M:%S')}

**关键词组数**: {len(keyword_groups)}

**关键词总数**: {total_keywords}

**成功**: {total_success} | **失败**: {total_error}

#### 排名发现摘要
{summary_text}
{failed_text}{warning_text}
---

数据已更新至钉钉表格"""

        ding_talk_notifier.send_markdown(title, text, is_at_all=False)

        logger.info("关键词排名监控任务完成")
        logger.info(f"成功: {total_success}, 失败: {total_error}, "
                     f"发现排名: {total_rankings}, 耗时: {duration:.0f}秒")

    except Exception as e:
        logger.error(f"关键词排名监控任务失败: {e}", exc_info=True)

        # 保存已完成的部分进度
        if all_results:
            try:
                recorder = RankingRecorder(doc_reader)
                recorder.save_local_backup(all_results)
                logger.info(f"已保存 {len(all_results)} 个关键词组的部分进度到本地备份")
            except Exception:
                pass

        title = "沃尔玛关键词排名监控失败"
        text = f"""### 沃尔玛关键词排名监控失败

**错误信息**: {str(e)}

**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

**已完成进度**: {len(all_results)} 个关键词组（已保存本地备份）

请检查日志获取详细信息。"""

        try:
            ding_talk_notifier.send_markdown(title, text, is_at_all=True)
        except Exception:
            pass


def run_scheduler():
    """启动定时任务调度器"""
    try:
        from croniter import croniter
    except ImportError:
        print("错误: 请先安装 croniter 库: pip install croniter")
        sys.exit(1)

    logger = logging.getLogger(__name__)
    logger.info("启动定时任务调度器")
    logger.info(f"Cron 表达式: {CRON_EXPRESSION}")

    running = True

    def signal_handler(signum, frame):
        nonlocal running
        logger.info("收到停止信号，正在退出...")
        running = False

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    cron = croniter(CRON_EXPRESSION, datetime.now())

    def get_next_run_time():
        return cron.get_next(datetime)

    next_run = get_next_run_time()
    logger.info(f"下次执行时间: {next_run.strftime('%Y-%m-%d %H:%M:%S')}")

    while running:
        now = datetime.now()

        if now >= next_run:
            try:
                run_keyword_monitor_task()
            except Exception as e:
                logger.error(f"定时任务执行失败: {e}", exc_info=True)

            cron = croniter(CRON_EXPRESSION, datetime.now())
            next_run = get_next_run_time()
            logger.info(f"下次执行时间: {next_run.strftime('%Y-%m-%d %H:%M:%S')}")

        time.sleep(1)

    logger.info("定时任务调度器已停止")


def run_setup():
    """浏览器位置设置

    两种模式：
    - 配置了 WALMART_ZIP_CODE → 自动设置（通过 store-finder 页面）
    - 未配置 → 打开浏览器让用户手动设置

    设置后的位置保存在 data/chrome_user_data 中，后续运行自动复用。
    """
    import time as _time
    from app.spiders.base_spider import BaseSpider
    from app.config import settings

    user_data_path = settings.CHROME_USER_DATA_PATH or None

    class SetupSpider(BaseSpider):
        def check_product_page(self, url): return {}
        def _get_site_config(self, url): return {}

    spider = SetupSpider(user_data_path=user_data_path, concurrency=1)

    try:
        zip_code = settings.WALMART_ZIP_CODE

        if zip_code:
            # 自动模式：通过 store-finder 设置邮编
            print()
            print(f"自动设置 Walmart 位置: ZIP {zip_code}")
            print()

            spider.page.get('https://www.walmart.com/store-finder')
            _time.sleep(3)

            zip_input = spider.page.ele('@name=zipCodeOrCityState', timeout=10)
            if not zip_input:
                print("错误: 未找到 ZIP 输入框，请手动设置")
                spider.page.get('https://www.walmart.com')
                input("手动设置后按 Enter 退出...")
                return

            zip_input.input(zip_code, clear=True)
            _time.sleep(0.5)

            find_btn = spider.page.ele('text=Find store', timeout=5)
            if find_btn:
                find_btn.click()
                _time.sleep(3)

            make_btn = spider.page.ele('text=Make this my store', timeout=5)
            if make_btn:
                make_btn.click()
                _time.sleep(2)
                print(f"位置已设置为 ZIP {zip_code}，后续运行自动复用。")
            else:
                print("未找到门店，请检查邮编是否正确")

        else:
            # 手动模式：打开浏览器让用户操作
            print()
            print("=" * 60)
            print(" 浏览器位置设置向导")
            print("=" * 60)
            print()
            print("沃尔玛搜索结果高度依赖地理位置（邮编/ZIP Code）。")
            print()
            print("方式一（推荐）: 在 .env 中配置 WALMART_ZIP_CODE=90017，再运行 --setup 自动设置")
            print()
            print("方式二: 在打开的浏览器中手动设置：")
            print("  1. 点击左上角 'Pickup or delivery?'")
            print("  2. 选择 Shipping 标签 → Add address")
            print("  3. 或访问 walmart.com/store-finder 搜索邮编")
            print()

            spider.page.get('https://www.walmart.com')
            print(f"浏览器已打开。")
            print()
            input("设置完成后，按 Enter 保存并退出...")
            print()
            print("位置设置已保存！")

    finally:
        spider.close()


def main():
    """主入口"""
    setup_logging()
    logger = logging.getLogger(__name__)

    logger.info("=" * 60)
    logger.info("沃尔玛关键词排名监控工具 v0.1.0")
    logger.info("=" * 60)

    if len(sys.argv) > 1 and sys.argv[1] == "--setup":
        logger.info("运行模式: 浏览器设置")
        run_setup()
    elif len(sys.argv) > 1 and sys.argv[1] == "--once":
        logger.info("运行模式: 单次执行")
        run_keyword_monitor_task()
    else:
        logger.info("运行模式: 定时任务")
        run_scheduler()


if __name__ == "__main__":
    main()
