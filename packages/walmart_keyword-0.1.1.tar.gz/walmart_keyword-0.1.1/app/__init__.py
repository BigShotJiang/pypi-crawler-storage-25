"""
沃尔玛关键词排名监控工具

自动监控 Young Electric 产品在沃尔玛搜索结果中的广告和自然排名
"""

__version__ = "0.1.1"
__author__ = "Leo"
