#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
排名记录器
将排名结果写入钉钉表格

优化策略：
- 表头批量写入：所有新关键词的 Row1+Row2 合成一次 API 调用
- 数据行批量写入：整行数据一次 API 调用写入
- 合并单元格去掉 sleep，依赖 API 自身的串行处理
"""

import os
import json
import time
import logging
from datetime import datetime
from typing import List, Optional, Dict, Tuple

from app.models.ranking_result import RankingResult
from app.dingtalk_doc_reader import DingTalkDocReader

try:
    from alibabacloud_dingtalk.doc_1_0.client import Client as dingtalkdoc_1_0Client
    from alibabacloud_dingtalk.doc_1_0 import models as dingtalkdoc_1_0_models
    from alibabacloud_tea_openapi import models as open_api_models
    from alibabacloud_tea_util import models as util_models
    DINGTALK_SDK_AVAILABLE = True
except ImportError:
    DINGTALK_SDK_AVAILABLE = False

logger = logging.getLogger(__name__)

COLS_PER_KEYWORD = 4


class RankingRecorder:
    """排名记录器"""

    def __init__(self, doc_reader: DingTalkDocReader = None):
        self.doc_reader = doc_reader or DingTalkDocReader()
        self._doc_client = None
        if DINGTALK_SDK_AVAILABLE:
            self._doc_client = self._create_doc_client()
        self.backup_dir = 'data/ranking_records'
        os.makedirs(self.backup_dir, exist_ok=True)

    def _create_doc_client(self):
        if not DINGTALK_SDK_AVAILABLE:
            return None
        try:
            config = open_api_models.Config()
            config.protocol = 'https'
            config.region_id = 'central'
            return dingtalkdoc_1_0Client(config)
        except Exception as e:
            logger.error(f"创建钉钉文档客户端失败: {e}")
            return None

    # ================================================================
    # 公开方法
    # ================================================================

    def write_group_results(self, group_name: str, keywords: List[str],
                            results: List[RankingResult]) -> bool:
        """将一个关键词组的结果写入对应 Sheet"""
        if not self.doc_reader.is_enabled() or not self._doc_client:
            logger.warning("钉钉文档功能未启用，跳过写入")
            return False

        try:
            doc_info = self.doc_reader.extract_doc_info()
            if not doc_info or not doc_info.get('workbook_id'):
                logger.error("无法获取文档信息")
                return False

            workbook_id = doc_info['workbook_id']

            sheet_id = self.doc_reader._find_sheet_by_name(workbook_id, group_name)
            if not sheet_id:
                logger.error(f"未找到工作表: {group_name}")
                return False

            # Step 1: 读取已有表头
            existing_mapping = self._read_existing_headers(workbook_id, sheet_id)
            logger.info(f"Sheet '{group_name}' 已有关键词: {list(existing_mapping.keys())}")

            # Step 2: 为新增关键词创建表头（批量写入 + 合并）
            col_mapping = self._ensure_keyword_headers(
                workbook_id, sheet_id, keywords, existing_mapping
            )
            logger.info(f"最终列映射: { {kw: self._col_num_to_letter(col) for kw, col in col_mapping.items()} }")

            # Step 3: 确定写入行
            target_row = self._find_target_row(workbook_id, sheet_id)
            logger.info(f"写入目标行: {target_row} (Sheet: {group_name})")

            # Step 4: 批量写入数据行（一次 API 调用）
            result_map = {r.keyword: r for r in results}
            return self._write_data_row(
                workbook_id, sheet_id, target_row, keywords, result_map, col_mapping
            )

        except Exception as e:
            logger.error(f"写入关键词组 '{group_name}' 失败: {e}", exc_info=True)
            return False

    def save_local_backup(self, all_results: Dict[str, List[RankingResult]]):
        """保存本地 JSON 备份"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_file = f"{self.backup_dir}/rankings_{timestamp}.json"

            backup_data = {
                'timestamp': datetime.now().isoformat(),
                'groups': {}
            }

            for group_name, results in all_results.items():
                backup_data['groups'][group_name] = [r.to_dict() for r in results]

            with open(backup_file, 'w', encoding='utf-8') as f:
                json.dump(backup_data, f, ensure_ascii=False, indent=2)

            logger.info(f"本地备份已保存: {backup_file}")

        except Exception as e:
            logger.warning(f"保存本地备份失败: {e}")

    # ================================================================
    # 表头管理
    # ================================================================

    def _read_existing_headers(self, workbook_id: str, sheet_id: str) -> Dict[str, int]:
        """读取 Sheet 第1行已有的关键词表头"""
        try:
            data = self.doc_reader._read_sheet_range_single(
                workbook_id, sheet_id, "B1:ZZ1"
            )

            if not data or not data[0]:
                return {}

            mapping = {}
            for col_offset, cell in enumerate(data[0]):
                if cell and str(cell).strip():
                    mapping[str(cell).strip()] = 2 + col_offset

            return mapping

        except Exception as e:
            logger.warning(f"读取表头失败: {e}")
            return {}

    def _ensure_keyword_headers(self, workbook_id: str, sheet_id: str,
                                keywords: List[str],
                                existing_mapping: Dict[str, int]) -> Dict[str, int]:
        """确保所有关键词都有表头，返回完整的列映射"""
        col_mapping = {}

        if not existing_mapping:
            self._ensure_date_header(workbook_id, sheet_id)

        max_used_col = 1
        for start_col in existing_mapping.values():
            max_used_col = max(max_used_col, start_col + COLS_PER_KEYWORD - 1)

        next_available_col = max_used_col + 1
        new_keywords = []

        for keyword in keywords:
            if keyword in existing_mapping:
                col_mapping[keyword] = existing_mapping[keyword]
            else:
                col_mapping[keyword] = next_available_col
                new_keywords.append((keyword, next_available_col))
                next_available_col += COLS_PER_KEYWORD

        if new_keywords:
            logger.info(f"新增 {len(new_keywords)} 个关键词表头: {[kw for kw, _ in new_keywords]}")
            self._create_keyword_headers_batch(workbook_id, sheet_id, new_keywords)

        return col_mapping

    def _create_keyword_headers_batch(self, workbook_id: str, sheet_id: str,
                                      new_keywords: List[Tuple[str, int]]):
        """批量创建所有新关键词的表头

        优化：所有新关键词的 Row1 + Row2 合成一次 write API 调用，
        然后逐个调用 merge（无法批量，但去掉 sleep）。
        """
        access_token = self.doc_reader._get_access_token()
        if not access_token:
            logger.error("无法获取访问令牌，跳过表头创建")
            return

        # 计算写入范围：从第一个新关键词到最后一个新关键词
        first_col = new_keywords[0][1]
        last_col = new_keywords[-1][1] + COLS_PER_KEYWORD - 1
        total_cols = last_col - first_col + 1

        # 构建 Row1 和 Row2 的批量数据
        row1 = [""] * total_cols
        row2 = [""] * total_cols

        for keyword, start_col in new_keywords:
            offset = start_col - first_col
            row1[offset] = keyword
            row2[offset] = "广告排名"
            row2[offset + 2] = "自然排名"

        # 一次写入所有表头文本
        col_start = self._col_num_to_letter(first_col)
        col_end = self._col_num_to_letter(last_col)
        header_range = f"{col_start}1:{col_end}2"

        try:
            self._write_range(workbook_id, sheet_id, header_range, [row1, row2], access_token)
            logger.info(f"表头批量写入成功: {header_range} ({len(new_keywords)} 个关键词)")
        except Exception as e:
            logger.error(f"批量写入表头失败: {e}")
            return

        # 逐个合并单元格（API 不支持批量合并，但去掉 sleep）
        for keyword, start_col in new_keywords:
            c1 = self._col_num_to_letter(start_col)
            c2 = self._col_num_to_letter(start_col + 1)
            c3 = self._col_num_to_letter(start_col + 2)
            c4 = self._col_num_to_letter(start_col + 3)

            self._merge_cells(workbook_id, sheet_id, f"{c1}1:{c4}1", access_token)
            self._merge_cells(workbook_id, sheet_id, f"{c1}2:{c2}2", access_token)
            self._merge_cells(workbook_id, sheet_id, f"{c3}2:{c4}2", access_token)

    def _merge_cells(self, workbook_id: str, sheet_id: str,
                     range_address: str, access_token: str):
        """合并单元格"""
        try:
            headers = dingtalkdoc_1_0_models.MergeRangeHeaders()
            headers.x_acs_dingtalk_access_token = access_token

            request = dingtalkdoc_1_0_models.MergeRangeRequest(
                operator_id=self.doc_reader.operator_id
            )

            self._doc_client.merge_range_with_options(
                workbook_id, sheet_id, range_address,
                request, headers, util_models.RuntimeOptions()
            )
            logger.debug(f"合并单元格成功: {range_address}")

        except Exception as e:
            logger.warning(f"合并单元格失败 ({range_address}): {e}")

    def _ensure_date_header(self, workbook_id: str, sheet_id: str):
        """确保 A1 有"日期"标题"""
        try:
            access_token = self.doc_reader._get_access_token()
            if access_token:
                self._write_range(workbook_id, sheet_id, "A1:A1",
                                  [["日期"]], access_token)
        except Exception:
            pass

    def _write_range(self, workbook_id: str, sheet_id: str,
                     range_address: str, values: List[List],
                     access_token: str):
        """写入指定范围的数据"""
        headers = dingtalkdoc_1_0_models.UpdateRangeHeaders()
        headers.x_acs_dingtalk_access_token = access_token

        request = dingtalkdoc_1_0_models.UpdateRangeRequest(
            operator_id=self.doc_reader.operator_id,
            values=values
        )

        self._doc_client.update_range_with_options(
            workbook_id, sheet_id, range_address,
            request, headers, util_models.RuntimeOptions()
        )

    # ================================================================
    # 数据行写入
    # ================================================================

    def _find_target_row(self, workbook_id: str, sheet_id: str) -> int:
        """确定写入的目标行号"""
        today = datetime.now()
        today_str = f"{today.month}月{today.day}"

        try:
            data = self.doc_reader._read_sheet_range_single(
                workbook_id, sheet_id, "A3:A200"
            )

            if not data:
                return 3

            last_data_row = 2

            for row_idx, row in enumerate(data, start=3):
                if not row or not row[0] or not str(row[0]).strip():
                    continue

                cell_value = str(row[0]).strip()
                last_data_row = row_idx

                if cell_value == today_str:
                    logger.info(f"找到今天的日期 '{today_str}' 在第 {row_idx} 行，覆盖写入")
                    return row_idx

            next_row = last_data_row + 1
            logger.info(f"未找到今天日期，追加到第 {next_row} 行")
            return next_row

        except Exception as e:
            logger.warning(f"查找目标行失败: {e}，默认第3行")
            return 3

    def _write_data_row(self, workbook_id: str, sheet_id: str,
                        row_num: int, keywords: List[str],
                        result_map: Dict[str, RankingResult],
                        col_mapping: Dict[str, int]) -> bool:
        """批量写入数据行（一次 API 调用）

        构建完整行数组 [日期, kw1_ad_pos, kw1_ad_sku, kw1_org_pos, kw1_org_sku, ...],
        一次性写入 A{row}:{max_col}{row}。
        """
        today = datetime.now()
        date_str = f"{today.month}月{today.day}"

        # 计算最大列号
        max_col = 1
        for kw in keywords:
            if kw in col_mapping:
                max_col = max(max_col, col_mapping[kw] + COLS_PER_KEYWORD - 1)

        # 构建整行数据
        row_data = [""] * max_col
        row_data[0] = date_str

        for keyword in keywords:
            if keyword not in col_mapping:
                continue

            col_idx = col_mapping[keyword] - 1  # 转 0-based

            result = result_map.get(keyword)
            if result and result.status == 'success':
                row_data[col_idx] = result.format_ad_positions()
                row_data[col_idx + 1] = result.format_ad_skus()
                row_data[col_idx + 2] = result.format_organic_positions()
                row_data[col_idx + 3] = result.format_organic_skus()
            else:
                row_data[col_idx] = '-'
                row_data[col_idx + 1] = '-'
                row_data[col_idx + 2] = '-'
                row_data[col_idx + 3] = '-'

        # 一次写入整行
        end_col_letter = self._col_num_to_letter(max_col)
        range_address = f"A{row_num}:{end_col_letter}{row_num}"

        for attempt in range(3):
            try:
                access_token = self.doc_reader._get_access_token()
                if not access_token:
                    if attempt < 2:
                        time.sleep(2)
                        continue
                    return False

                self._write_range(workbook_id, sheet_id, range_address,
                                  [row_data], access_token)
                logger.info(f"数据写入成功: {range_address} ({len(keywords)} 个关键词)")
                return True

            except Exception as e:
                logger.error(f"写入数据失败 (尝试 {attempt + 1}/3): {e}")
                if attempt < 2:
                    time.sleep(2)

        logger.error(f"写入失败，已重试 3 次: {range_address}")
        return False

    # ================================================================
    # 工具方法
    # ================================================================

    @staticmethod
    def _col_num_to_letter(col: int) -> str:
        """列号转字母 (1=A, 2=B, ..., 27=AA)"""
        result = ""
        while col > 0:
            col, remainder = divmod(col - 1, 26)
            result = chr(65 + remainder) + result
        return result
