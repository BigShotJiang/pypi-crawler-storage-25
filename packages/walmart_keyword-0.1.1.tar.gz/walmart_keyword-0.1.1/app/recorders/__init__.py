#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数据记录模块"""

from .ranking_recorder import RankingRecorder

__all__ = ['RankingRecorder']
