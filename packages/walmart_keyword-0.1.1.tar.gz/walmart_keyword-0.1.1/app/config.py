#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置模块
管理所有环境变量配置
"""

import os
import random
import logging
from typing import List, Optional
from dotenv import load_dotenv

load_dotenv()


def setup_logging(log_file: str = "data/app.log") -> None:
    """统一配置日志系统"""
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )


logger = logging.getLogger(__name__)


class Settings:
    """加载所有环境变量配置"""

    # === 钉钉通知配置 ===
    DINGTALK_WEBHOOK: str = os.getenv("DINGTALK_WEBHOOK", "")
    DINGTALK_SECRET: str = os.getenv("DINGTALK_SECRET", "")
    DINGTALK_AT_MOBILES: str = os.getenv("DINGTALK_AT_MOBILES", "")

    # === Chrome 配置 ===
    CHROME_USER_DATA_PATH: str = os.getenv("CHROME_USER_DATA_PATH", "")

    # === 定时任务配置 ===
    CRON_EXPRESSION: str = os.getenv("CRON_EXPRESSION", "0 8 * * *")

    # === 钉钉文档配置 ===
    DINGTALK_DOC_ENABLED: bool = os.getenv(
        "DINGTALK_DOC_ENABLED", "false").lower() in ("true", "1")
    DINGTALK_DOC_URL: str = os.getenv("DINGTALK_DOC_URL", "")
    DINGTALK_APP_KEY: str = os.getenv("DINGTALK_APP_KEY", "")
    DINGTALK_APP_SECRET: str = os.getenv("DINGTALK_APP_SECRET", "")
    DINGTALK_OPERATOR_ID: str = os.getenv("DINGTALK_OPERATOR_ID", "")

    # === Sheet 名称配置 ===
    KEYWORD_SHEET_NAME: str = os.getenv("KEYWORD_SHEET_NAME", "关键词")
    SKU_MAPPING_SHEET_NAME: str = os.getenv("SKU_MAPPING_SHEET_NAME", "SKU映射表")

    # === 沃尔玛位置配置 ===
    # 用于 --setup 自动设置 Walmart 配送位置（通过 store-finder）
    # 设置后 Cookie 保存在 chrome_user_data 中，后续运行自动复用
    WALMART_ZIP_CODE: str = os.getenv("WALMART_ZIP_CODE", "")

    # === 反爬配置 ===
    RATE_LIMIT_PER_MINUTE: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "15"))
    RATE_LIMIT_PER_HOUR: int = int(os.getenv("RATE_LIMIT_PER_HOUR", "500"))

    # === 多实例配置 ===
    INSTANCE_ID: int = int(os.getenv("INSTANCE_ID", "0"))
    CHROME_PORT_BASE: int = int(os.getenv("CHROME_PORT_BASE", "9333"))

    @property
    def chrome_port(self) -> int:
        return self.CHROME_PORT_BASE + self.INSTANCE_ID

    @property
    def chrome_user_data_suffix(self) -> str:
        if self.INSTANCE_ID == 0:
            return ""
        return f"_{self.INSTANCE_ID}"


class ProxyConfig:
    """代理配置"""
    enabled: bool = os.getenv('PROXY_ENABLED', 'false').lower() in ('true', '1')
    pool: List[str] = []

    def __init__(self):
        proxy_pool_str = os.getenv('PROXY_POOL', '')
        if self.enabled and proxy_pool_str:
            self.pool = [proxy.strip() for proxy in proxy_pool_str.split(',') if proxy.strip()]


def get_random_proxy() -> Optional[str]:
    config = ProxyConfig()
    if config.enabled and config.pool:
        return random.choice(config.pool)
    return None


settings = Settings()
