#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
沃尔玛搜索结果爬虫
搜索关键词并提取 Young Electric 产品的广告和自然排名
"""

import time
import random
import logging
from typing import List, Dict, Tuple
from urllib.parse import quote_plus
from datetime import datetime

from app.spiders.base_spider import BaseSpider
from app.spiders.walmart_bot_handler import WalmartBotHandler, BotDetectionType
from app.selectors.walmart_search_selectors import WalmartSearchSelectors, WalmartSearchTimeouts
from app.utils.behavior_simulator import human_like_delay, human_like_scroll
from app.utils.rate_limiter import RateLimiter
from app.models.ranking_result import RankingResult
from app.config import settings

logger = logging.getLogger(__name__)

BRAND_NAME = "young electric"


class WalmartSearchSpider(BaseSpider):
    """沃尔玛搜索排名爬虫

    对每个关键词：
    1. 打开搜索页 https://www.walmart.com/search?q={keyword}
    2. 处理反爬验证
    3. 分步滚动加载全部结果
    4. 通过 data-testid="item-stack" 容器筛选主搜索结果
    5. 在主搜索结果中查找 Young Electric 产品
    6. 区分广告（Sponsored）和自然排名
    7. 记录排名位置和 SKU
    """

    def __init__(self, user_data_path: str = None):
        super().__init__(user_data_path=user_data_path, concurrency=1)
        self.bot_handler = WalmartBotHandler(self.page)
        self.rate_limiter = RateLimiter(
            max_per_minute=settings.RATE_LIMIT_PER_MINUTE,
            max_per_hour=settings.RATE_LIMIT_PER_HOUR
        )
        self.fallback_warnings = []

        # 如果配置了邮编，自动设置 Walmart 位置
        if settings.WALMART_ZIP_CODE:
            self._set_walmart_location(settings.WALMART_ZIP_CODE)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # === BaseSpider 抽象方法的最小实现 ===
    def check_product_page(self, url: str) -> dict:
        return {}

    def _get_site_config(self, url: str) -> dict:
        return {'site': 'walmart', 'domain': 'www.walmart.com'}

    # === 位置设置 ===

    def _set_walmart_location(self, zip_code: str):
        """通过 store-finder 页面自动设置 Walmart 配送位置

        流程：导航到 /store-finder → JS注入邮编 → Find store → Make this my store

        注意：store-finder 使用 React，普通 input() 可能无法触发状态更新，
        必须通过 JS 的 nativeInputValueSetter + dispatchEvent 才能让 React 感知到值变化。
        """
        logger.info(f"自动设置 Walmart 位置: ZIP {zip_code}")
        try:
            self.page.get(f'https://www.walmart.com/store-finder?location={zip_code}')
            time.sleep(3)

            # 等待门店列表加载
            make_btn = self.page.ele('text=Make this my store', timeout=10)
            if make_btn:
                make_btn.click()
                time.sleep(2)
                logger.info(f"Walmart 位置已设置: ZIP {zip_code}")
            else:
                logger.warning("未找到 'Make this my store' 按钮")
        except Exception as e:
            logger.warning(f"自动设置位置失败: {e}")

    # === 核心搜索逻辑 ===

    def search_and_extract(self, keyword: str, group_name: str,
                           sku_mapping: Dict[str, str]) -> RankingResult:
        """搜索单个关键词并提取 Young Electric 排名"""
        url = f"https://www.walmart.com/search?q={quote_plus(keyword)}"
        logger.info(f"搜索关键词: '{keyword}' (组: {group_name})")
        logger.info(f"URL: {url}")

        try:
            # 速率控制
            self.rate_limiter.acquire()

            # 导航到搜索页（含重试：最多 3 次尝试）
            page_loaded = False
            for attempt in range(3):
                self.page.get(url)
                time.sleep(random.uniform(2, 4))

                if self._wait_for_page_load():
                    page_loaded = True
                    break

                if attempt < 2:
                    logger.warning(f"页面加载超时，重试 ({attempt + 1}/2)")
                    time.sleep(random.uniform(3, 5))

            if not page_loaded:
                return RankingResult(
                    keyword=keyword, keyword_group=group_name,
                    status='error', error_message='页面加载超时(已重试2次)'
                )

            # 处理反爬检测
            if self._detect_and_handle_bot():
                time.sleep(2)

            # 检查是否为无结果页
            if self._is_no_results_page():
                logger.info(f"关键词 '{keyword}' 无搜索结果")
                self.rate_limiter.report_success()
                return RankingResult(
                    keyword=keyword, keyword_group=group_name,
                    status='no_result'
                )

            # 滚动加载全部内容 + 等待 item-stack 卡片数稳定
            self._scroll_and_wait_for_stable()

            # 提取排名数据
            ad_positions, ad_skus, organic_positions, organic_skus = \
                self._extract_rankings(sku_mapping)

            self.rate_limiter.report_success()
            self.stats['successful_detections'] += 1
            self.stats['total_pages'] += 1

            result = RankingResult(
                keyword=keyword,
                keyword_group=group_name,
                ad_positions=ad_positions,
                ad_skus=ad_skus,
                organic_positions=organic_positions,
                organic_skus=organic_skus,
                status='success'
            )

            if result.has_young_electric:
                logger.info(
                    f"  发现 Young Electric: "
                    f"广告={result.format_ad_positions()} SKU={result.format_ad_skus()}, "
                    f"自然={result.format_organic_positions()} SKU={result.format_organic_skus()}"
                )
            else:
                logger.info(f"  未发现 Young Electric 产品")

            return result

        except Exception as e:
            logger.error(f"搜索关键词 '{keyword}' 失败: {e}", exc_info=True)
            self.rate_limiter.report_failure()
            self.stats['failed_detections'] += 1
            self.stats['total_pages'] += 1
            return RankingResult(
                keyword=keyword, keyword_group=group_name,
                status='error', error_message=str(e)
            )

    def run(self, keyword_groups: Dict[str, List[str]],
            sku_mapping: Dict[str, str]) -> Dict[str, List[RankingResult]]:
        """批量搜索所有关键词组"""
        all_results = {}
        total_keywords = sum(len(kws) for kws in keyword_groups.values())
        processed = 0
        failed_keywords = []

        for group_name, keywords in keyword_groups.items():
            logger.info(f"\n{'='*50}")
            logger.info(f"处理关键词组: {group_name} ({len(keywords)} 个关键词)")
            logger.info(f"{'='*50}")

            group_results = []
            for keyword in keywords:
                processed += 1
                logger.info(f"[{processed}/{total_keywords}] 搜索: {keyword}")

                result = self.search_and_extract(keyword, group_name, sku_mapping)
                group_results.append(result)

                if result.status == 'error':
                    failed_keywords.append((keyword, group_name))

                # 关键词间随机延迟
                if processed < total_keywords:
                    human_like_delay(3, 8, 'normal')

                    # 每10个关键词额外休息
                    if processed % 10 == 0:
                        rest_time = random.uniform(15, 30)
                        logger.info(f"已处理 {processed} 个，休息 {rest_time:.0f} 秒...")
                        time.sleep(rest_time)

            all_results[group_name] = group_results

        # 失败重试（一轮）
        if failed_keywords:
            logger.info(f"\n{'='*50}")
            logger.info(f"重试 {len(failed_keywords)} 个失败关键词")
            logger.info(f"{'='*50}")

            time.sleep(random.uniform(30, 60))

            for keyword, group_name in failed_keywords:
                logger.info(f"重试: {keyword} (组: {group_name})")
                result = self.search_and_extract(keyword, group_name, sku_mapping)

                group_results = all_results[group_name]
                for i, r in enumerate(group_results):
                    if r.keyword == keyword and r.status == 'error':
                        group_results[i] = result
                        break

                human_like_delay(5, 10, 'normal')

        return all_results

    # === 内部方法 ===

    def _wait_for_page_load(self, timeout: int = 15) -> bool:
        """等待搜索结果页加载完成

        检测搜索表单（data-testid="search-form"）是否存在。
        注意：搜索输入框本身没有 data-testid，但搜索表单有。
        """
        start = time.time()
        while time.time() - start < timeout:
            search_form = self.page.ele(WalmartSearchSelectors.SEARCH_FORM, timeout=1)
            if search_form:
                return True
            time.sleep(0.5)
        logger.warning("页面加载超时")
        return False

    def _detect_and_handle_bot(self) -> bool:
        """检测并处理反爬验证，返回是否遇到了验证

        WalmartBotHandler API：
        - detect() → BotDetectionType（无参，使用 self.page）
        - handle(detection_type) → bool（无 page 参数）
        """
        try:
            detection_type = self.bot_handler.detect()
            if detection_type and detection_type != BotDetectionType.NONE:
                logger.warning(f"检测到反爬验证: {detection_type.name}")
                self.stats['captcha_encounters'] += 1
                self.bot_handler.handle(detection_type)
                return True
        except Exception as e:
            logger.debug(f"反爬检测过程出错: {e}")
        return False

    def _is_no_results_page(self) -> bool:
        """检测是否为无结果页面"""
        no_result = self.page.ele(WalmartSearchSelectors.NO_RESULTS, timeout=1)
        return bool(no_result)

    def _scroll_and_wait_for_stable(self):
        """分步滚动并等待 item-stack 内卡片数稳定

        问题：Next.js 页面的懒加载内容需要滚动触发，但 scrollBy 后 DOM 不会立即就绪。
        如果滚动后立即提取，可能只拿到部分卡片（如 40/52）。

        策略：
        1. 分步滚动到底部（触发懒加载）
        2. 滚回顶部
        3. 轮询 item-stack 内卡片数，连续 3 次相同则认为稳定
        """
        try:
            # Step 1: 分步滚动到底部
            for _ in range(6):
                self.page.scroll.down(800)
                time.sleep(random.uniform(0.4, 0.8))

            self.page.scroll.to_bottom()
            time.sleep(random.uniform(1.0, 2.0))

            # Step 2: 回到顶部
            self.page.scroll.to_top()
            time.sleep(random.uniform(0.5, 1.0))

        except Exception as e:
            logger.debug(f"滚动操作失败: {e}")

        # Step 3: 等待 item-stack 内卡片数稳定
        self._wait_for_cards_stable()

    def _wait_for_cards_stable(self, timeout: int = 15):
        """等待 item-stack 内卡片数稳定（连续 3 次读取相同）

        解决的问题：
        - 旧方法只检查全局 [data-item-id] > 5 就返回，阈值太低
        - Next.js hydration 可能导致 DOM 还在变化
        - 不同关键词的 item-stack 结构不同（1个或2个 stack）
        """
        start = time.time()
        last_count = 0
        stable_ticks = 0

        while time.time() - start < timeout:
            # 统计 item-stack 内的卡片数
            item_stacks = self.page.eles(WalmartSearchSelectors.ITEM_STACK)
            current_count = 0
            for stack in item_stacks:
                cards = stack.eles(WalmartSearchSelectors.ALL_PRODUCT_CARDS)
                current_count += len(cards)

            if current_count > 0 and current_count == last_count:
                stable_ticks += 1
                if stable_ticks >= 3:
                    logger.debug(
                        f"卡片数稳定: {current_count} 张 "
                        f"({len(item_stacks)} 个 item-stack)"
                    )
                    return
            else:
                stable_ticks = 0

            last_count = current_count
            time.sleep(0.5)

        # 超时但仍有卡片
        if last_count > 0:
            logger.warning(f"卡片数未完全稳定（当前 {last_count} 张），继续提取")
        else:
            logger.warning("等待商品卡片超时，未找到 item-stack 内的卡片")

    def _extract_rankings(self, sku_mapping: Dict[str, str]) -> Tuple[list, list, list, list]:
        """从页面提取 Young Electric 排名

        核心策略（基于 2026-04-14 Chrome 实测）：
        - 使用 data-testid="item-stack" 容器筛选主搜索结果
        - item-stack 内的卡片全部有 product-title，无需额外过滤
        - 推荐区卡片不在 item-stack 内，天然排除
        - 同一 dca_id 允许同时出现在广告和自然排名中（按类型分别去重）
        """
        ad_positions = []
        ad_skus = []
        organic_positions = []
        organic_skus = []

        main_cards = self._get_main_result_cards()
        logger.info(f"主搜索结果卡片: {len(main_cards)} 个")

        if not main_cards:
            return ad_positions, ad_skus, organic_positions, organic_skus

        # 按广告/自然分别去重
        seen_ad_dca_ids = set()
        seen_organic_dca_ids = set()

        for index, card in enumerate(main_cards):
            title_el = card.ele(WalmartSearchSelectors.PRODUCT_TITLE, timeout=0)
            if not title_el:
                continue

            title = title_el.text or ""
            if BRAND_NAME not in title.lower():
                continue

            dca_id = card.attr(WalmartSearchSelectors.ATTR_DCA_ID)
            if not dca_id:
                logger.warning(f"卡片缺少 data-dca-id，跳过 (位置 {index + 1})")
                continue

            position = index + 1
            sku = sku_mapping.get(dca_id, dca_id)

            card_text = card.text or ""
            is_sponsored = WalmartSearchSelectors.SPONSORED_TEXT in card_text

            if is_sponsored:
                if dca_id in seen_ad_dca_ids:
                    continue
                seen_ad_dca_ids.add(dca_id)
                ad_positions.append(position)
                ad_skus.append(sku)
                logger.debug(f"  广告位 #{position}: {sku} - {title[:50]}")
            else:
                if dca_id in seen_organic_dca_ids:
                    continue
                seen_organic_dca_ids.add(dca_id)
                organic_positions.append(position)
                organic_skus.append(sku)
                logger.debug(f"  自然位 #{position}: {sku} - {title[:50]}")

        return ad_positions, ad_skus, organic_positions, organic_skus

    def _get_main_result_cards(self) -> list:
        """获取主搜索结果卡片（通过 item-stack 容器，top-down 方式）

        Chrome 实测结论：
        - 主搜索结果在 data-testid="item-stack" 容器中
        - 推荐区卡片不在 item-stack 内
        - 多个 item-stack 的卡片按顺序拼接，位置连续编号
        """
        item_stacks = self.page.eles(WalmartSearchSelectors.ITEM_STACK)

        if item_stacks:
            main_cards = []
            for stack in item_stacks:
                cards = stack.eles(WalmartSearchSelectors.ALL_PRODUCT_CARDS)
                main_cards.extend(cards)

            if main_cards:
                logger.debug(
                    f"通过 item-stack 找到 {len(main_cards)} 张主搜索结果卡片 "
                    f"({len(item_stacks)} 个 item-stack)"
                )
                return main_cards

        # 降级：找不到 item-stack
        logger.warning(
            "未找到 data-testid='item-stack' 容器，页面结构可能已变化。"
            "降级为遍历所有有 product-title 的卡片"
        )
        self.fallback_warnings.append("item-stack 容器未找到，已降级处理")

        all_cards = self.page.eles(WalmartSearchSelectors.ALL_PRODUCT_CARDS)
        main_cards = []
        for card in all_cards:
            title_el = card.ele(WalmartSearchSelectors.PRODUCT_TITLE, timeout=0)
            if title_el:
                main_cards.append(card)

        return main_cards
