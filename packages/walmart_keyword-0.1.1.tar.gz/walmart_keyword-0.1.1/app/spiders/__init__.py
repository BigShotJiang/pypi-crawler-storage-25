#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""爬虫模块"""

from .base_spider import BaseSpider, TabWorker, set_thread_page, clear_thread_page
from .walmart_bot_handler import WalmartBotHandler, BotDetectionType
from .walmart_search_spider import WalmartSearchSpider

__all__ = [
    'BaseSpider',
    'TabWorker',
    'set_thread_page',
    'clear_thread_page',
    'WalmartBotHandler',
    'BotDetectionType',
    'WalmartSearchSpider',
]
