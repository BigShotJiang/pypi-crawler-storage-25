import builtins

def asc(LISTA):
    if not isinstance(LISTA, list):   # type check
        return None
    if not LISTA:   # empty list
        return []

    try:
        LISTA.sort()
    except TypeError:   # mixed data types
        return None

    return LISTA


def desc(LISTB):
    if not isinstance(LISTB, list):   
        return None
    if not LISTB:   
        return []

    try:
        LISTB.sort(reverse=True)
    except TypeError:   
        return None

    return LISTB


def min(LISTC, spec=""):
    if not LISTC:  
        return None

    if spec.lower() == 'even':
        EVEN_LIST = []
        for i in LISTC:
            if isinstance(i, (int, float)) and i % 2 == 0:
                EVEN_LIST.append(i)
        if not EVEN_LIST:  
            return None
        MIN_VAR = builtins.min(EVEN_LIST)
        return MIN_VAR  

    if spec.lower() == 'odd' or spec.startswith("od"):
        ODD_LIST = []
        for i in LISTC:
            if isinstance(i, (int, float)) and i % 2 != 0:
                ODD_LIST.append(i)
        if not ODD_LIST:   
            return None
        MIN_VAR = builtins.min(ODD_LIST)
        return MIN_VAR    

    MIN_VAR = builtins.min(LISTC)
    return MIN_VAR


def max(LISTC, spec=""):
    if not LISTC:  
        return None

    if spec.lower() == 'even' or spec.startswith("ev"):
        EVEN_LIST = []
        for i in LISTC:
            if isinstance(i, (int, float)) and i % 2 == 0:
                EVEN_LIST.append(i)
        if not EVEN_LIST:   
            return None
        MAX_VAR = builtins.max(EVEN_LIST)
        return MAX_VAR  

    if spec.lower() == 'odd' or spec.startswith("od"):
        ODD_LIST = []
        for i in LISTC:
            if isinstance(i, (int, float)) and i % 2 != 0:
                ODD_LIST.append(i)
        if not ODD_LIST:   
            return None
        MAX_VAR = builtins.max(ODD_LIST)
        return MAX_VAR    

    MAX_VAR = builtins.max(LISTC)
    return MAX_VAR


def sum(LISTD, spec=""):
    if not LISTD:
        return None
    
    if spec.lower() == 'even' or spec.startswith("ev"):
        EVEN_LIST = []
        for i in LISTD:
            if isinstance(i, (int, float)) and i % 2 == 0:
                EVEN_LIST.append(i)
        if not EVEN_LIST:
            return None
        SUM_VAR = builtins.sum(EVEN_LIST)
        return SUM_VAR
    
    if spec.lower() == 'odd' or spec.startswith("odd"):
        ODD_LIST = []
        for i in LISTD:
            if isinstance(i, (int, float)) and i % 2 != 0:
                ODD_LIST.append(i)
        if not ODD_LIST:
            return None
        SUM_VAR = builtins.sum(ODD_LIST)
        return SUM_VAR
    
    SUM_VAR = builtins.sum(LISTD)
    return SUM_VAR


def remv(LISTE, spec="", n=1):
    if not LISTE:
        return None

    elif isinstance(spec, str) and (spec.lower() == "min" or spec.startswith("mi")):
        min_var = builtins.min(LISTE)
        LISTE.remove(min_var)
        return LISTE

    elif isinstance(spec, str) and (spec.lower() == "max" or spec.startswith("ma")):
        max_var = builtins.max(LISTE)
        LISTE.remove(max_var)
        return LISTE

    elif isinstance(spec, str) and spec.lower() == "multipleof":
        LIST = []
        for i in LISTE:
            if i % n == 0:
                LIST.append(i)
        for i in LIST:
            LISTE.remove(i)
        return LISTE

    elif isinstance(spec, str) and spec.startswith("index-"):
        try:
            idx = int(spec.split("-")[1])
            if 0 <= idx < len(LISTE):
                LISTE.pop(idx)
        except:
            return None
        return LISTE

    elif isinstance(spec, list):
        for i in spec:
            if i in LISTE:
                LISTE.remove(i)
        return LISTE


def empty(LISTF):
    if not isinstance(LISTF, list):   # type check
        return None
    if not LISTF:   # empty list
        return []
    try:
         LISTF.clear()
    except TypeError:
        return None

    return LISTF


def count(LISTE, spec=""):
    if not LISTE:
        return 0

    elif isinstance(spec, str) and (spec.lower() == "even" or spec.startswith("ev")):
        COUNT = 0
        for i in LISTE:
            if isinstance(i, (int, float)) and i % 2 == 0:
                COUNT += 1
        return COUNT

    elif isinstance(spec, str) and (spec.lower() == "odd" or spec.startswith("od")):
        COUNT = 0
        for i in LISTE:
            if isinstance(i, (int, float)) and i % 2 != 0:
                COUNT += 1
        return COUNT

    elif spec != "":
        COUNT = 0
        for i in LISTE:
            if i == spec:
                COUNT += 1
        return COUNT

    else:
        return len(LISTE)


def append(LISTE, VALUES, spec=""):
    if not isinstance(LISTE, list) or not isinstance(VALUES, list):
        return None

    if isinstance(spec, str) and (spec.lower() == "even" or spec.startswith("ev")):
        for i in VALUES:
            if isinstance(i, (int, float)) and i % 2 == 0:
                LISTE.append(i)
        return LISTE

    elif isinstance(spec, str) and (spec.lower() == "odd" or spec.startswith("od")):
        for i in VALUES:
            if isinstance(i, (int, float)) and i % 2 != 0:
                LISTE.append(i)
            else:
                LISTE.append(i)   # non-numbers also added
        return LISTE

    else:
        for i in VALUES:
            LISTE.append(i)
        return LISTE


def insert(LISTE, VALUE, INDEX):
    if not isinstance(LISTE, list):
        return None

    if not isinstance(INDEX, int):
        return None

    if INDEX < 0:
        INDEX = 0

    while len(LISTE) < INDEX:
        LISTE.append(None)

    LISTE.insert(INDEX, VALUE)
    return LISTE

def index(LISTE, VALUE):
    if not isinstance(LISTE, list):
        return None

    COUNT = 0
    for i in LISTE:
        if i == VALUE:
            return COUNT
        COUNT += 1

    return -1   # if not found

