from setuptools import setup, find_packages

setup(
    name="manjeet-list-functions",
    version="0.1",
    packages=find_packages(),
    description="Custom list utility functions by Manjeet",
    author="Manjeet Yadav",
)