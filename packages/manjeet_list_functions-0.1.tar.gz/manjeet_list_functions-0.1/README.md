# manjeet-list-functions

Custom Python list utility functions by Manjeet 🚀

## Features
- asc() → sort ascending
- desc() → sort descending
- min(), max(), sum() → with even/odd support
- remv() → remove by min/max/index/multipleof
- count() → count values / even / odd
- append() → append with filter
- insert() → insert with auto None fill
- index() → find index

## Installation
```bash
pip install manjeet-list-functions