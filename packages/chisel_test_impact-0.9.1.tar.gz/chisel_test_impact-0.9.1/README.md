# Chisel

Test impact analysis and code intelligence built for AI coding agents. Zero external dependencies, open source, MIT licensed.

Chisel maps tests to code, code to git history, and answers: **what to run, what’s risky, and who touched it.** It runs as an MCP server alongside your agent — Claude Code, Cursor, Windsurf, Cline, or any MCP-compatible client.

![Chisel analyzing a real project — risk map, churn, ownership, test gaps, and agent interpretation](docs/chisel-demo.png)

## What it does

Chisel builds a graph connecting your code, tests, and git history, then answers three questions:

### 1. What to run

You change `engine.py:store_document()`. Instead of running all 287 tests or guessing with `-k “test_store”`, Chisel tells the agent exactly which tests are impacted — through direct edges and transitive import-chain coupling.

### 2. What’s risky

Risk scores per file based on churn rate, coupling breadth, test coverage gaps, author concentration, and test instability. A file that changes often, has one author, and no tests? That’s your highest risk.

### 3. Who touched it

Blame-based ownership (who wrote it) and commit-activity-based reviewer suggestions (who maintains it). Useful when multiple agents or developers work on the same codebase and you need to understand lineage.

## Why it exists

When multiple LLM agents (or agents + humans) work on the same codebase, changes in one area can silently break another.

Chisel gives AI coding assistants the intelligence to understand the blast radius of their changes before they commit. One agent’s refactor doesn’t silently regress another agent’s work — automated code quality checks that work at the speed of your agent.

## Install

Available on [PyPI](https://pypi.org/project/chisel-test-impact/):

```bash
pip install chisel-test-impact
```

Or from source:

```bash
git clone https://github.com/IronAdamant/Chisel.git
cd Chisel
pip install -e .
```

## Use with Claude Code (MCP)

Add to your Claude Code MCP config (`~/.claude/settings.json` or project `.mcp.json`):

```json
{
  “mcpServers”: {
    “chisel”: {
      “command”: “chisel-mcp”,
      “env”: {
        “CHISEL_PROJECT_DIR”: “/path/to/your/project”
      }
    }
  }
}
```

Run `analyze` first to build the project graph, then `diff_impact` after edits to see which tests to run. For large repos, `analyze` with `force=True` automatically falls back to a background job so you don't hit MCP timeouts. Working-tree analysis (`--working-tree`) reuses a cached static import index and falls back to fast stem-matching for untracked files to stay within timeout budgets.

**Monorepo sharding:** Split large codebases across multiple SQLite databases with the `CHISEL_SHARDS` environment variable or `.chisel/shards.toml`. Query tools automatically aggregate across shards; writes route to the correct shard by file path.

After running tests, call `record_result` so Chisel can track failure rates and test instability over time. Or use `chisel run -- pytest tests/` to run tests and record results automatically.

## Use with Cursor, Windsurf, Cline, or other MCP clients

Chisel exposes a standard MCP interface. For stdio-based clients:

```bash
pip install chisel-test-impact[mcp]
chisel-mcp
```

For HTTP-based clients:

```bash
chisel serve --port 8377
```

## Quickstart (CLI)

```bash
# Analyze a project (builds the graph)
chisel analyze .

# What tests are impacted by my current changes?
chisel diff-impact

# What tests should I run for this file?
chisel suggest-tests engine.py

# Risk heatmap across the project
chisel risk-map

# Find code with no test coverage, sorted by risk
chisel test-gaps

# Who owns this code?
chisel ownership engine.py

# Incremental update (only re-process changed files)
chisel update
```

## Try it on this repo

```bash
git clone https://github.com/IronAdamant/Chisel.git
cd Chisel
pip install -e .

chisel analyze .
chisel risk-map
chisel diff-impact
chisel test-gaps
```

## MCP Tools

20 functional tools plus 6 advisory file-lock helpers for multi-agent coordination.

| Tool | What it does |
|------|-------------|
| `analyze` | Full project scan — builds the code/test/git graph. Optional `shard` param for sharded monorepos |
| `update` | Incremental re-analysis of changed files only. Optional `shard` param for sharded monorepos |
| `diff_impact` | Detects your changes from `git diff` and returns impacted tests. `working_tree=true` enables full static import scanning for untracked files. `auto_update=true` refreshes stale DB inline |
| `suggest_tests` | Ranks tests by relevance for a given file. Prefers same-directory tests via stem matching. `auto_update=true` refreshes stale DB inline |
| `impact` | Which tests cover these files or functions? |
| `risk_map` | Risk scores for all files (churn + coupling + coverage gaps). `working_tree=true` includes untracked files. `exclude_new_file_boost=true` suppresses the temporary boost. `auto_update=true` refreshes stale DB inline |
| `test_gaps` | Code with zero test coverage, sorted by risk. `working_tree=true` elevates uncommitted files to the top. `auto_update=true` refreshes stale DB inline |
| `triage` | Top risks + gaps + stale tests in one call. Supports `exclude_new_file_boost` and `auto_update` |
| `churn` | How often does this file or function change? |
| `coupling` | Files that change together or import each other |
| `ownership` | Blame-based — who wrote this code? |
| `who_reviews` | Commit-activity-based — who maintains this code? |
| `stale_tests` | Tests pointing at code that no longer exists |
| `history` | Commit history for a file |
| `record_result` | Log test pass/fail outcomes for future prioritization |
| `run` | CLI-only: run tests and auto-record results (pytest, Jest) |
| `stats` | Database summary and diagnostic counts |
| `start_job` | Run analyze/update in background (avoids MCP timeouts) |
| `job_status` | Poll a background job until complete |

## Features

- **Zero dependencies** — stdlib only, Python 3.11+, works anywhere
- **Multi-language** — Python, JavaScript/TypeScript, Go, Rust, C#, Java, Kotlin, C/C++, Swift, PHP, Ruby, Dart
- **Framework-aware** — pytest, Jest, Go test, Rust #[test], Playwright, xUnit/NUnit/MSTest, JUnit, XCTest, PHPUnit, RSpec, Minitest, gtest, Dart test
- **Incremental** — only re-processes changed files, not the whole repo
- **Branch-aware** — `diff_impact` auto-detects feature branch vs main
- **Multi-agent safe** — cross-process locks so parallel agents don’t corrupt the graph
- **MCP + CLI** — stdio and HTTP MCP servers, plus a full CLI with 28 subcommands
- **Monorepo sharding** — split analysis across per-directory SQLite databases (`CHISEL_SHARDS`)
- **Custom extractors** — plug in tree-sitter or LSP via `register_extractor()` if you need it

## Ecosystem

Chisel sits in the agent loop: impact -> tests -> record results -> refresh analysis. It works standalone or alongside [Stele](https://github.com/IronAdamant/Stele) for semantic code context.

**Docs:** [Agent playbook](docs/AGENT_PLAYBOOK.md) | [Zero-dependency policy](docs/ZERO_DEPS.md) | [Custom extractors](docs/CUSTOM_EXTRACTORS.md)

## License

MIT
