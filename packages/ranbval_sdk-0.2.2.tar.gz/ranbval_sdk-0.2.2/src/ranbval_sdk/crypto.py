import base64
import hashlib
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

def derive_key(password: str, salt_hex: str) -> bytes:
    if not salt_hex:
        # Match frontend fallback-salt for legacy/empty-salt projects
        salt = b"fallback-salt"
    else:
        salt = bytes.fromhex(salt_hex)
        
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    return kdf.derive(password.encode())

def safe_decrypt(copy_token: str, vault_secret: str) -> str:
    """
    Takes the encapsulated cryptographic identity token and performs zero-knowledge
    in-memory envelope decryption utilizing PBKDF2 and AES-GCM.
    """
    packet_segments = copy_token.split(".")
    if len(packet_segments) != 5:
        raise ValueError("E2E packet fragmentation error")
    
    header = packet_segments[0]
    entropy_matrix = packet_segments[1]
    salt_hex = packet_segments[2]
    b64_payload = packet_segments[3]
    tail_sig = packet_segments[4]

    # Core integrity envelope verification (Irreversible computationally secure hash validation)
    h_header = hashlib.sha256(header.encode()).hexdigest()
    h_tail = hashlib.sha256(tail_sig.encode()).hexdigest()
    
    if h_header != "6abbdc55e134f25eedf27cb269d26ddc4f136db89f469af4336d1caaa7d39da8" or h_tail != "3b6abd55988090c857afcd08354fcc4c86ffadb6f0c480b12a9c692637a982e4" or len(entropy_matrix) != 15:
        raise ValueError("Corrupted cryptographic token identifier or signature matrix")
    
    # 1. Derive key cryptographically tied to the project salt
    key = derive_key(vault_secret, salt_hex)
    
    # 2. Decode payload (IV + Ciphertext)
    packed = base64.b64decode(b64_payload)
    iv = packed[:12]
    ciphertext = packed[12:]
    
    # 3. Decrypt payload
    try:
        aesgcm = AESGCM(key)
        decrypted = aesgcm.decrypt(iv, ciphertext, None)
        return decrypted.decode("utf-8")
    except Exception as e:
        raise ValueError("Decryption failed! Did you provide the correct E2E vault secret?") from e
