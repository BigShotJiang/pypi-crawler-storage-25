import os
import openai
from ranbval_sdk.crypto import safe_decrypt

class SecureOpenAI(openai.OpenAI):
    """
    A drop-in replacement for `openai.OpenAI` that intercepts
    Ranbval (rbv1.*) encoded API keys from .env or args, decrypts
    them entirely in-memory at runtime, and seamlessly initializes
    the standard OpenAI client.
    """
    def __init__(self, api_key=None, vault_secret=None, **kwargs):
        encoded_key = api_key or os.environ.get("OPENAI_API_KEY")
        secret = vault_secret or os.environ.get("RANBVAL_VAULT_SECRET")
        
        if not encoded_key:
            raise ValueError("No OPENAI_API_KEY found or provided.")
            
        if encoded_key.startswith("ranbval."):
            if not secret:
                raise ValueError(
                    "You supplied an Encrypted Ranbval Token but no RANBVAL_VAULT_SECRET "
                    "was found in .env or passed as an argument."
                )
            
            # Runtime blind-decryption hook!
            decrypted_key = safe_decrypt(encoded_key, secret)
            
            # Call openai.OpenAI constructor with the real raw string entirely in-memory
            super().__init__(api_key=decrypted_key, **kwargs)
            self._ranbval_salt = encoded_key.split(".")[2] # Extract salt for telemetry
            self._patch_completions()
        else:
            # Fallback if standard (sk-...) api_key is given natively.
            super().__init__(api_key=encoded_key, **kwargs)
            self._ranbval_salt = None

    def _patch_completions(self):
        original_create = self.chat.completions.create
        
        def patched_create(*args, **kwargs):
            res = original_create(*args, **kwargs)
            self._send_telemetry_async(kwargs.get("model", "unknown"), res)
            return res
            
        self.chat.completions.create = patched_create

    def _send_telemetry_async(self, model, response):
        if not self._ranbval_salt:
            return
            
        import threading
        import urllib.request
        import json
        import socket
        import os
        
        prompt_tokens = getattr(getattr(response, "usage", None), "prompt_tokens", 0)
        completion_tokens = getattr(getattr(response, "usage", None), "completion_tokens", 0)
        repo_path = os.getcwd()
        machine_name = socket.gethostname()
        
        def fire():
            try:
                host = os.environ.get("RANBVAL_HOST", "http://localhost:8006")
                payload = {
                    "client_salt": self._ranbval_salt,
                    "machine_name": machine_name,
                    "repo_path": repo_path,
                    "model_used": model,
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens
                }
                
                req = urllib.request.Request(
                    f"{host}/api/telemetry",
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST"
                )
                with urllib.request.urlopen(req, timeout=2) as f:
                    pass
            except Exception:
                pass
                
        # Send telemetry non-blocking
        threading.Thread(target=fire, daemon=True).start()

