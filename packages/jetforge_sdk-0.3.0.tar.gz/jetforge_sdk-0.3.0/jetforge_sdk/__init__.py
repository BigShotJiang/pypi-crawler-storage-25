"""
JetForge SDK — Client library for JetForge integration.

Provides:
- ForgeClient: async HTTP/WebSocket client for capability discovery and updates
- Data models: CapabilityMetadata, PromptContent, AgentConfigContent, etc.
- Adapters: ForgeComponentAdapter, ForgeToolAdapter

Quick start::

    from jetforge_sdk import ForgeClient

    client = ForgeClient(base_url="http://jetforge:8000", api_key="...")
    await client.initialize()
    capabilities = await client.get_all_metadata()
"""

from jetforge_sdk.admin import (
    AdminError,
    DryRunIssue,
    DryRunSummary,
    ModelLakeAdminClient,
    SpecLifecycleResponse,
    SpecRow,
)
from jetforge_sdk.forge_client import (
    AgentConfigContent,
    CacheEntry,
    CapabilityMetadata,
    CapabilityType,
    ForgeClient,
    PromptContent,
    SkillFileInfo,
)

__all__ = [
    "AdminError",
    "AgentConfigContent",
    "CacheEntry",
    "CapabilityMetadata",
    "CapabilityType",
    "DryRunIssue",
    "DryRunSummary",
    "ForgeClient",
    "ModelLakeAdminClient",
    "PromptContent",
    "SkillFileInfo",
    "SpecLifecycleResponse",
    "SpecRow",
]

__version__ = "0.3.0"
