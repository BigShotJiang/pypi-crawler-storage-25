# SPDX-FileCopyrightText: 2026-present wkambale <spartanwk@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.0"
