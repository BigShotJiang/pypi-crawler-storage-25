# jax-gemini

[![PyPI - Version](https://img.shields.io/pypi/v/jax-gemini.svg)](https://pypi.org/project/jax-gemini)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/jax-gemini.svg)](https://pypi.org/project/jax-gemini)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install jax-gemini
```

## License

`jax-gemini` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
