"""Lightweight CLI entrypoint focused on fast parser startup."""

# pylint: disable=import-outside-toplevel
from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path
from typing import TYPE_CHECKING

from tuochat.__about__ import __version__
from tuochat.cli.utils.cli_suggestions import SmartParser

if TYPE_CHECKING:
    from tuochat.cli.command_models import GlobalOptions
    from tuochat.config import TuochatConfig


def build_parser() -> SmartParser:
    """Build the root argparse parser without importing the full REPL stack."""
    parser = SmartParser(
        prog="tuochat",
        description="GitLab Duo Chat client with local conversation tools",
        epilog=(
            "Many REPL slash commands also have top-level equivalents. "
            "Use `tuochat convo ...`, `tuochat archive ...`, `tuochat context ...`, and `tuochat headless ...`."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    parser.add_argument(
        "--config",
        metavar="PATH",
        help="Path to config file",
    )
    parser.add_argument(
        "--no-banner",
        "--no-logo",
        action="store_true",
        dest="no_banner",
        help="Suppress the startup banner",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress repeated interactive instructions and use terse prompts",
    )
    parser.add_argument(
        "--blind",
        action="store_true",
        help="Enable blind-friendly mode: suppress logo, simplify help/context, and avoid clear-screen behavior",
    )

    def add_format_argument(command_parser: argparse.ArgumentParser, *, markdown: bool = False) -> None:
        choices = ("text", "json", "markdown") if markdown else ("text", "json")
        command_parser.add_argument("--format", choices=choices, default="text", help="Output format")

    def add_chat_session_arguments(command_parser: argparse.ArgumentParser) -> None:
        command_parser.add_argument("--prompt", "-p", help="System prompt for this conversation")
        command_parser.add_argument("--resource-id", "-r", help="GitLab project/group GID for context")
        command_parser.add_argument("--no-stream", action="store_true", help="Use polling instead of streaming")
        command_parser.add_argument("--timeout", type=int, help="Override request timeout for this chat session")

    def add_headless_arguments(command_parser: argparse.ArgumentParser, *, include_system_prompt: bool) -> None:
        command_parser.add_argument("message", nargs="?", help="Prompt text")
        command_parser.add_argument("--file", type=Path, help="Read the prompt body from a file")
        command_parser.add_argument("--stdin", action="store_true", help="Read the prompt body from stdin")
        command_parser.add_argument("--include", action="append", type=Path, default=[], help="Attach a local file")
        command_parser.add_argument(
            "--web", action="append", default=[], metavar="URL", help="Fetch a web page and attach it"
        )
        command_parser.add_argument("--skill", help="Attach a discovered skill by name or path")
        command_parser.add_argument("--template", help="Render a discovered template by name or path")
        command_parser.add_argument("--var", action="append", default=[], help="Template variable as NAME=value")
        command_parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON")
        command_parser.add_argument("--output-file", type=Path, help="Write the final response text to a file")
        command_parser.add_argument("--no-stream", action="store_true", help="Disable stdout streaming")
        command_parser.add_argument("--timeout", type=int, help="Override the provider timeout")
        command_parser.add_argument("--model", choices=("duo", "eliza"), default="duo", help="Model to use")
        if include_system_prompt:
            command_parser.add_argument("--system-prompt", help="System prompt for the new conversation")
            command_parser.add_argument("--resource-id", help="GitLab project/group GID for context")

    subparsers = parser.add_subparsers(dest="command", title="commands")

    chat_parser = subparsers.add_parser(
        "chat",
        help="Start an interactive chat",
        description="Chat and local tools",
    )
    chat_parser.set_defaults(command_key="chat")
    add_chat_session_arguments(chat_parser)

    gui_parser = subparsers.add_parser("gui", help="Start the minimal Tkinter chat window")
    gui_parser.set_defaults(command_key="gui")
    add_chat_session_arguments(gui_parser)

    config_parser = subparsers.add_parser("config", help="Show active configuration")
    config_parser.set_defaults(command_key="config")
    config_parser.add_argument(
        "format",
        nargs="?",
        default="markdown",
        choices=("markdown", "json"),
        help="Output format",
    )

    init_parser = subparsers.add_parser("init", help="Create a starter config file")
    init_parser.set_defaults(command_key="init")
    init_parser.add_argument("--force", action="store_true", help="Overwrite an existing config file")

    auth_parser = subparsers.add_parser("auth", help="Manage GitLab credentials (PAT or OAuth)")
    auth_subparsers = auth_parser.add_subparsers(dest="auth_action")
    for action, helptext in (
        ("login", "Sign in via PAT or OAuth, store credentials in keyring or config"),
        ("status", "Show the credential type, expiry, and storage location"),
        ("logout", "Remove stored credentials for the active GitLab host"),
        ("refresh", "Trade the stored OAuth refresh token for a fresh access token"),
    ):
        sub = auth_subparsers.add_parser(action, help=helptext)
        sub.set_defaults(command_key="auth", auth_action=action)
    auth_parser.set_defaults(command_key="auth", auth_action="login")

    doctor_parser = subparsers.add_parser("doctor", help="Run local config and path checks")
    doctor_parser.set_defaults(command_key="doctor")
    add_format_argument(doctor_parser)

    usage_parser = subparsers.add_parser("usage", help="Show weekly token and cost usage")
    usage_parser.set_defaults(command_key="usage")
    add_format_argument(usage_parser)

    observability_parser = subparsers.add_parser(
        "observability",
        help="Show 30-day Duo response performance and outcome data",
    )
    observability_parser.set_defaults(command_key="observability")
    add_format_argument(observability_parser)

    convo_parser = subparsers.add_parser("convo", help="Manage saved conversations")
    convo_subparsers = convo_parser.add_subparsers(dest="convo_command")

    convo_list_parser = convo_subparsers.add_parser("list", help="List saved conversations")
    convo_list_parser.set_defaults(command_key="convo-list")
    convo_list_parser.add_argument("--limit", "-n", type=int, default=20, help="Max conversations to show")
    convo_list_parser.add_argument("--archived", action="store_true", help="Show archived conversations")
    add_format_argument(convo_list_parser)

    convo_resume_parser = convo_subparsers.add_parser("resume", help="Resume a saved conversation")
    convo_resume_parser.set_defaults(command_key="convo-resume")
    convo_resume_parser.add_argument("id", nargs="?", help="Conversation ID (or prefix)")

    convo_search_parser = convo_subparsers.add_parser("search", help="Search saved conversations")
    convo_search_parser.set_defaults(command_key="convo-search")
    convo_search_parser.add_argument("query", nargs="+", help="Full-text search query")
    convo_search_parser.add_argument("--limit", "-n", type=int, default=20, help="Max search results to show")
    convo_search_parser.add_argument("--title", help="Filter results by conversation title")
    convo_search_parser.add_argument(
        "--after", help="Only include conversations updated on or after this ISO timestamp"
    )
    convo_search_parser.add_argument(
        "--before", help="Only include conversations updated on or before this ISO timestamp"
    )

    convo_export_parser = convo_subparsers.add_parser("export", help="Export a conversation")
    convo_export_parser.set_defaults(command_key="convo-export")
    convo_export_parser.add_argument("id", nargs="?", help="Conversation ID (or prefix)")

    convo_open_parser = convo_subparsers.add_parser("open", help="Open a conversation export path")
    convo_open_parser.set_defaults(command_key="convo-open")
    convo_open_parser.add_argument("id", nargs="?", help="Conversation ID (or prefix)")

    convo_archive_parser = convo_subparsers.add_parser("archive", help="Archive a saved conversation")
    convo_archive_parser.set_defaults(command_key="convo-archive")
    convo_archive_parser.add_argument("id", nargs="?", help="Conversation ID (or prefix)")

    convo_unarchive_parser = convo_subparsers.add_parser("unarchive", help="Unarchive one or all conversations")
    convo_unarchive_parser.set_defaults(command_key="convo-unarchive")
    convo_unarchive_parser.add_argument("id", nargs="?", help="Conversation ID (or prefix)")
    convo_unarchive_parser.add_argument("--all", action="store_true", help="Unarchive every archived conversation")

    convo_delete_parser = convo_subparsers.add_parser("delete", help="Delete a saved conversation")
    convo_delete_parser.set_defaults(command_key="convo-delete")
    convo_delete_parser.add_argument("id", nargs="?", help="Conversation ID (or prefix)")

    archive_parser = subparsers.add_parser("archive", help="Manage saved archive metadata")
    archive_subparsers = archive_parser.add_subparsers(dest="archive_command")

    archive_bagit_update = archive_subparsers.add_parser(
        "bagit-update", help="Refresh archive-change hashes and metadata"
    )
    archive_bagit_update.set_defaults(command_key="archive-bagit-update")

    archive_bagit_check = archive_subparsers.add_parser(
        "bagit-check", help="Check whether archives changed since the last BagIt update"
    )
    archive_bagit_check.set_defaults(command_key="archive-bagit-check")
    add_format_argument(archive_bagit_check)

    context_parser = subparsers.add_parser("context", help="Discover local context sources")
    context_subparsers = context_parser.add_subparsers(dest="context_command")

    context_files = context_subparsers.add_parser("files", help="List include-able local files")
    context_files.set_defaults(command_key="context-files")
    add_format_argument(context_files)

    context_skills = context_subparsers.add_parser("skills", help="List discovered skills")
    context_skills.set_defaults(command_key="context-skills")
    add_format_argument(context_skills)

    context_templates = context_subparsers.add_parser("templates", help="List discovered templates")
    context_templates.set_defaults(command_key="context-templates")
    add_format_argument(context_templates)

    context_custom = context_subparsers.add_parser("custom-instructions", help="List discovered custom instructions")
    context_custom.set_defaults(command_key="context-custom-instructions")
    add_format_argument(context_custom)

    headless_parser = subparsers.add_parser("headless", help="Run non-interactive chat flows")
    headless_subparsers = headless_parser.add_subparsers(dest="headless_command")

    headless_ask = headless_subparsers.add_parser("ask", help="Start a new non-interactive conversation")
    headless_ask.set_defaults(command_key="headless-ask")
    add_headless_arguments(headless_ask, include_system_prompt=True)

    headless_continue = headless_subparsers.add_parser("continue", help="Continue a saved conversation")
    headless_continue.set_defaults(command_key="headless-continue")
    headless_continue.add_argument("id", help="Conversation ID (or prefix)")
    add_headless_arguments(headless_continue, include_system_prompt=False)

    history_parser = subparsers.add_parser("history", help="Alias for `convo list`")
    history_parser.set_defaults(command_key="history")
    history_parser.add_argument("--limit", "-n", type=int, default=20, help="Max conversations to show")
    add_format_argument(history_parser)

    resume_parser = subparsers.add_parser("resume", help="Alias for `convo resume`")
    resume_parser.set_defaults(command_key="resume")
    resume_parser.add_argument("id", nargs="?", help="Conversation ID (or prefix)")

    search_parser = subparsers.add_parser("search", help="Alias for `convo search`")
    search_parser.set_defaults(command_key="search")
    search_parser.add_argument("query", nargs="+", help="Full-text search query")
    search_parser.add_argument("--limit", "-n", type=int, default=20, help="Max search results to show")
    search_parser.add_argument("--title", help="Filter results by conversation title")
    search_parser.add_argument("--after", help="Only include conversations updated on or after this ISO timestamp")
    search_parser.add_argument("--before", help="Only include conversations updated on or before this ISO timestamp")

    export_parser = subparsers.add_parser("export", help="Alias for `convo export`")
    export_parser.set_defaults(command_key="export")
    export_parser.add_argument("id", nargs="?", help="Conversation ID (or prefix)")

    selfcheck_parser = subparsers.add_parser(
        "selfcheck",
        help="Supply-chain safety: check for updates, audit, self-upgrade",
    )
    selfcheck_parser.set_defaults(command_key="selfcheck")
    selfcheck_parser.add_argument(
        "selfcheck_argv",
        nargs=argparse.REMAINDER,
        help="Arguments passed through to tuochat.self_pkg_mgmt CLI",
    )
    return parser


def global_options_from_args(args: argparse.Namespace) -> GlobalOptions:
    """Translate argparse output into global options."""
    # Keep bootstrap imports lazy so --help/--version avoid the full CLI stack.
    from tuochat.cli import bootstrap  # noqa: E402
    from tuochat.cli.command_models import GlobalOptions  # noqa: E402

    return GlobalOptions(
        debug=getattr(args, "debug", False),
        config_path=bootstrap.config_path_for(args),
        no_banner=getattr(args, "no_banner", False),
        quiet=getattr(args, "quiet", False),
        blind=getattr(args, "blind", False),
    )


def load_config(config_path: Path | str | None = None) -> TuochatConfig:
    """Load config from the requested path or default locations."""
    # Delay config loading helpers until a real command needs configuration.
    from tuochat.config import load_config as config_load_config  # noqa: E402

    return config_load_config(str(config_path) if config_path is not None else None)


def load_config_with_cli_overrides(config_path: Path | str | GlobalOptions | None = None) -> TuochatConfig:
    """Load config from the requested path or default locations."""
    # Logging and config overrides are only needed after argument parsing succeeds.
    from tuochat.cli import bootstrap  # noqa: E402
    from tuochat.cli.command_models import GlobalOptions  # noqa: E402
    from tuochat.logging_config import setup_logging  # noqa: E402

    if isinstance(config_path, GlobalOptions):
        global_options = config_path
    else:
        global_options = GlobalOptions(config_path=Path(config_path) if config_path else None)

    cfg = load_config(global_options.config_path)
    cfg = bootstrap.apply_global_overrides(cfg, global_options)
    setup_logging(
        log_dir=cfg.log_dir,
        debug=global_options.debug,
        enable_file_logging=not bootstrap.no_write_enabled(cfg),
    )
    return cfg


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entrypoint."""
    parser = build_parser()
    args = parser.parse_args(argv)
    global_options = global_options_from_args(args)
    cfg = load_config_with_cli_overrides(global_options)

    if getattr(args, "command_key", None) is None:
        # First-run helpers are only needed for the bare interactive entrypoint.
        from tuochat.cli.setup import is_first_run, run_init_wizard  # noqa: E402

        if is_first_run(
            cfg, config_path=str(global_options.config_path) if global_options.config_path is not None else None
        ):
            run_init_wizard(
                config_path=str(global_options.config_path) if global_options.config_path is not None else None,
                force=True,
            )
            print("Setup complete. Start chatting with `tuochat chat`.")
            return 0
        parser.print_help()
        return 0

    # Delay command dispatch imports until we know which command is actually running.
    from tuochat.cli import dispatch as cli_dispatch  # noqa: E402

    command = cli_dispatch.command_from_args(args)
    if command is None:
        parser.print_help()
        return 0

    from tuochat.security.startup_audit import run_startup_audit  # noqa: E402

    if not run_startup_audit(cfg):
        return 1

    return cli_dispatch.dispatch_command(cfg, global_options, command)
