"""
Constants for the Xplainable client.
"""

URL_PREFIX = "/v1"

# Authentication endpoints
AUTH_ENDPOINTS = {
    "connect": f"{URL_PREFIX}/connect",
}

# Model endpoints
MODEL_ENDPOINTS = {
    "create": f"{URL_PREFIX}/models/create",
    "add_version": f"{URL_PREFIX}/models/add-version",
    "list_team_models": f"{URL_PREFIX}/models/teams",
    "get_model": f"{URL_PREFIX}/models/{{model_id}}",
    "list_versions": f"{URL_PREFIX}/models/versions/{{model_id}}",
    "list_partitions": f"{URL_PREFIX}/models/partitions/{{version_id}}",
    "link_preprocessor": f"{URL_PREFIX}/preprocessors/link-preprocessor",
}

# Deployment endpoints
DEPLOYMENT_ENDPOINTS = {
    "create": f"{URL_PREFIX}/deployments/create",
    "create_deploy_key": f"{URL_PREFIX}/deployments/create-deploy-key",
    "list_team_deployments": f"{URL_PREFIX}/deployments/teams/{{team_id}}",
    "list_deploy_keys": f"{URL_PREFIX}/deployments/{{deployment_id}}",
    "list_active_team_keys": f"{URL_PREFIX}/deployments/teams/{{team_id}}/active-keys",
    "revoke_key": f"{URL_PREFIX}/deployments/revoke-key",
    "delete": f"{URL_PREFIX}/deployments/{{deployment_id}}",
    "activate": f"{URL_PREFIX}/deployments/{{deployment_id}}/activate",
    "deactivate": f"{URL_PREFIX}/deployments/{{deployment_id}}/deactivate",
    "payload": f"{URL_PREFIX}/deployments/{{deployment_id}}/payload",
}

# Preprocessor endpoints
PREPROCESSOR_ENDPOINTS = {
    "create": f"{URL_PREFIX}/preprocessors/create",
    "add_version": f"{URL_PREFIX}/preprocessors/add",
    "update_version": f"{URL_PREFIX}/preprocessors/update-version",
    "list_team_preprocessors": f"{URL_PREFIX}/preprocessors/teams/{{team_id}}",
    "get": f"{URL_PREFIX}/preprocessors/{{preprocessor_id}}",
    "get_version": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}",
    "get_pipeline": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}/pipeline",
    "preview": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}/preview",
    "fit": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}/fit",
    "check_signature": f"{URL_PREFIX}/preprocessors/check-signature",
    "delete_version": f"{URL_PREFIX}/preprocessors/versions/{{version_id}}",
    "delete_preprocessor": f"{URL_PREFIX}/preprocessors/{{preprocessor_id}}",
}

# Collection endpoints
COLLECTION_ENDPOINTS = {
    "create": f"{URL_PREFIX}/collections/create",
    "get_model_collections": f"{URL_PREFIX}/collections/model/{{model_id}}",
    "get_team_collections": f"{URL_PREFIX}/collections/team",
    "get_team_collections_by_id": f"{URL_PREFIX}/collections/team/{{team_id}}",
    "get_collection": f"{URL_PREFIX}/collections/{{collection_id}}",
    "update_name": f"{URL_PREFIX}/collections/{{collection_id}}/name",
    "update_description": f"{URL_PREFIX}/collections/{{collection_id}}/description",
    "delete": f"{URL_PREFIX}/collections/{{collection_id}}",
    "create_scenarios": f"{URL_PREFIX}/collections/{{collection_id}}/scenarios",
    "get_scenarios": f"{URL_PREFIX}/collections/{{collection_id}}/scenarios",
    "get_scenario": f"{URL_PREFIX}/collections/scenarios/{{scenario_id}}",
    "delete_scenario": f"{URL_PREFIX}/collections/scenarios/{{scenario_id}}",
}

# Inference endpoints
INFERENCE_ENDPOINTS = {
    "predict": f"{URL_PREFIX}/predict",
}

# Autotrain endpoints
AUTOTRAIN_ENDPOINTS = {
    "summarize": f"{URL_PREFIX}/autotrain/summarize",
    "generate_goals": f"{URL_PREFIX}/autotrain/generate_goals",
    "generate_labels": f"{URL_PREFIX}/autotrain/generate_labels",
    "generate_feature_engineering": f"{URL_PREFIX}/autotrain/generate_feature_engineering",
    "start_autotrain": f"{URL_PREFIX}/autotrain/start_autotrain",
    "check_training_status": f"{URL_PREFIX}/autotrain/check_training_status",
    "train_manual": f"{URL_PREFIX}/autotrain/train_manual",
}

# GPT endpoints
GPT_ENDPOINTS = {
    "generate_report": f"{URL_PREFIX}/models/report/generate",
    "explain_model": f"{URL_PREFIX}/models/explain",
}

# Run Endpoints
RUN_ENDPOINTS = {
    "create": f"{URL_PREFIX}/runs",
    "get": f"{URL_PREFIX}/runs/{{run_id}}",
}

# Combine all endpoints for backward compatibility
URL_PATHS = {
    **AUTH_ENDPOINTS,
    **{f"models_{k}": v for k, v in MODEL_ENDPOINTS.items()},
    **{f"deployments_{k}": v for k, v in DEPLOYMENT_ENDPOINTS.items()},
    **{f"preprocessors_{k}": v for k, v in PREPROCESSOR_ENDPOINTS.items()},
    **{f"collections_{k}": v for k, v in COLLECTION_ENDPOINTS.items()},
    **AUTOTRAIN_ENDPOINTS,
    **GPT_ENDPOINTS,
}
