"""
Spec-based preprocessing client using xplainable-preprocessing.
"""
from typing import Any, Dict, List, Optional, Tuple
import math
import pandas as pd
import base64

from .base import BaseClient, XplainableAPIError
from .utils.mcp_markers import mcp_tool, MCPCategory
from .py_models.preprocessing import (
    CreatePreprocessorResponse,
    AddPreprocessorVersionResponse,
    UpdatePreprocessorVersionResponse,
    PreprocessorInfo,
    PreprocessorVersionInfo,
)
from .utils.constants import PREPROCESSOR_ENDPOINTS


def _df_to_records(df: pd.DataFrame) -> list:
    """Convert DataFrame to JSON-safe list of dicts (NaN/Inf -> None)."""
    records = df.to_dict("records")
    return [
        {
            k: None if isinstance(v, float) and (math.isnan(v) or math.isinf(v)) else v
            for k, v in row.items()
        }
        for row in records
    ]


class PreprocessingClient(BaseClient):
    """Client for managing data preprocessing pipelines."""

    def create_preprocessor(
        self,
        name: str,
        description: str,
        spec: dict,
        sample_df: Optional[pd.DataFrame] = None,
    ) -> Tuple[str, str]:
        """
        Create a new preprocessor from a PipelineSpec dict.

        Args:
            name: Name of the preprocessor
            description: Description of the preprocessor
            spec: PipelineSpec dict ({"version": "2.0", "steps": [...]})
            sample_df: Optional sample dataframe for fitting

        Returns:
            Tuple of (preprocessor_id, version_id)

        Raises:
            XplainableAPIError: If preprocessor creation fails
            ValueError: If a preprocessor with the same name already exists
        """
        request_data = {
            "preprocessor_name": name,
            "preprocessor_description": description,
            "spec": spec,
            "sample_data": _df_to_records(sample_df.head(100)) if sample_df is not None else None,
            "python_version": self.session.python_version,
            "xplainable_version": self.session.xplainable_version,
        }

        try:
            response = self.post(
                PREPROCESSOR_ENDPOINTS["create"],
                data=request_data,
                response_model=CreatePreprocessorResponse,
            )
            return response.preprocessor_id, response.version_id
        except XplainableAPIError as e:
            if e.status_code == 409:
                raise ValueError(f"A preprocessor with the name '{name}' already exists.")
            raise

    def create_from_pipeline(
        self,
        name: str,
        description: str,
        pipeline,
        df: pd.DataFrame,
    ) -> Tuple[str, str]:
        """
        Create a preprocessor from a fitted DataFramePipeline.

        Args:
            name: Name of the preprocessor
            description: Description of the preprocessor
            pipeline: A fitted DataFramePipeline instance
            df: Sample dataframe (used for schema inference)

        Returns:
            Tuple of (preprocessor_id, version_id)
        """
        from xplainable_preprocessing import save_pipeline
        from xplainable_preprocessing.preview import infer_schema

        pipeline_binary = base64.b64encode(save_pipeline(pipeline)).decode("utf-8")
        input_schema = infer_schema(df)
        result_df = pipeline.transform(df)
        output_schema = infer_schema(result_df)

        request_data = {
            "preprocessor_name": name,
            "preprocessor_description": description,
            "spec": None,
            "pipeline_binary": pipeline_binary,
            "input_schema": input_schema,
            "output_schema": output_schema,
            "python_version": self.session.python_version,
            "xplainable_version": self.session.xplainable_version,
        }

        try:
            response = self.post(
                PREPROCESSOR_ENDPOINTS["create"],
                data=request_data,
                response_model=CreatePreprocessorResponse,
            )
            return response.preprocessor_id, response.version_id
        except XplainableAPIError as e:
            if e.status_code == 409:
                raise ValueError(f"A preprocessor with the name '{name}' already exists.")
            raise

    def add_version(
        self,
        preprocessor_id: str,
        spec: dict,
        sample_df: Optional[pd.DataFrame] = None,
        parent_version_id: Optional[str] = None,
    ) -> str:
        """
        Add a new version to an existing preprocessor.

        Args:
            preprocessor_id: ID of the existing preprocessor
            spec: PipelineSpec dict
            sample_df: Optional sample dataframe for fitting
            parent_version_id: Optional parent version for lineage tracking

        Returns:
            The new version_id
        """
        request_data = {
            "preprocessor_id": preprocessor_id,
            "spec": spec,
            "sample_data": _df_to_records(sample_df.head(100)) if sample_df is not None else None,
            "parent_version_id": parent_version_id,
            "python_version": self.session.python_version,
            "xplainable_version": self.session.xplainable_version,
        }

        response = self.post(
            PREPROCESSOR_ENDPOINTS["add_version"],
            data=request_data,
            response_model=AddPreprocessorVersionResponse,
        )
        return response.version_id

    def update_version(
        self,
        version_id: str,
        spec: dict,
        sample_df: Optional[pd.DataFrame] = None,
    ) -> str:
        """
        Update an existing preprocessor version with a new spec.

        Args:
            version_id: ID of the version to update
            spec: Updated PipelineSpec dict
            sample_df: Optional sample dataframe for re-fitting

        Returns:
            The updated version_id
        """
        request_data = {
            "version_id": version_id,
            "spec": spec,
            "sample_data": _df_to_records(sample_df.head(100)) if sample_df is not None else None,
        }

        response = self.post(
            PREPROCESSOR_ENDPOINTS["update_version"],
            data=request_data,
            response_model=UpdatePreprocessorVersionResponse,
        )
        return response.version_id

    def get_version(self, version_id: str) -> dict:
        """
        Get metadata for a preprocessor version.

        Args:
            version_id: The version ID

        Returns:
            Version info dict with spec, schemas, etc.
        """
        return self.get(
            PREPROCESSOR_ENDPOINTS["get_version"],
            version_id=version_id,
        )

    def load_pipeline(self, version_id: str):
        """
        Load a fitted pipeline ready to .transform().

        Args:
            version_id: The version ID to load

        Returns:
            A fitted DataFramePipeline instance
        """
        from xplainable_preprocessing.serialization import load_pipeline

        response = self.get(
            PREPROCESSOR_ENDPOINTS["get_pipeline"],
            version_id=version_id,
        )

        pipeline_b64 = response.get("pipeline_binary")
        if not pipeline_b64:
            raise ValueError(f"No fitted pipeline found for version {version_id}")

        return load_pipeline(base64.b64decode(pipeline_b64))

    def fit_version(
        self,
        version_id: str,
        df: pd.DataFrame,
    ) -> dict:
        """
        Fit a preprocessor version with sample data.

        Args:
            version_id: The version ID to fit
            df: Dataframe to fit on

        Returns:
            Fit result dict with schemas and status
        """
        request_data = {
            "sample_data": _df_to_records(df.head(100)),
        }

        return self.post(
            PREPROCESSOR_ENDPOINTS["fit"],
            data=request_data,
            version_id=version_id,
        )

    def preview(
        self,
        version_id: str,
        df: pd.DataFrame,
    ) -> dict:
        """
        Preview pipeline transformation on sample data.

        Args:
            version_id: The version ID to preview
            df: Sample dataframe

        Returns:
            Preview dict with deltas, schemas, and samples
        """
        request_data = {
            "sample_data": _df_to_records(df.head(100)),
        }

        return self.post(
            PREPROCESSOR_ENDPOINTS["preview"],
            data=request_data,
            version_id=version_id,
        )

    @mcp_tool(category=MCPCategory.READ)
    def list_preprocessors(self, team_id: Optional[str] = None) -> List[PreprocessorInfo]:
        """
        List all preprocessors for a team.

        Args:
            team_id: Optional team ID (uses session team_id if not provided)

        Returns:
            List of preprocessor information
        """
        if not team_id:
            team_id = self.session.team_id

        response = self.get(
            PREPROCESSOR_ENDPOINTS["list_team_preprocessors"],
            team_id=team_id,
        )

        return [PreprocessorInfo(**item) for item in response]

    @mcp_tool(category=MCPCategory.READ)
    def get_preprocessor(self, preprocessor_id: str) -> PreprocessorInfo:
        """
        Get detailed information about a preprocessor.

        Args:
            preprocessor_id: ID of the preprocessor

        Returns:
            Preprocessor information
        """
        return self.get(
            PREPROCESSOR_ENDPOINTS["get"],
            response_model=PreprocessorInfo,
            preprocessor_id=preprocessor_id,
        )

    def check_signature(
        self,
        version_id: str,
        columns: List[str],
    ) -> dict:
        """
        Check if a preprocessor version's output schema matches expected columns.

        Args:
            version_id: The version ID to check
            columns: Expected output column names

        Returns:
            Signature check result dict
        """
        request_data = {
            "version_id": version_id,
            "columns": columns,
        }

        return self.post(
            PREPROCESSOR_ENDPOINTS["check_signature"],
            data=request_data,
        )

    def delete_version(self, version_id: str) -> dict:
        """
        Delete a preprocessor version.

        Args:
            version_id: The version ID to delete

        Returns:
            Deletion result dict
        """
        return self.delete(
            PREPROCESSOR_ENDPOINTS["delete_version"],
            version_id=version_id,
        )

    def delete_preprocessor(self, preprocessor_id: str) -> dict:
        """
        Delete a preprocessor and all its versions.

        Args:
            preprocessor_id: The preprocessor ID to delete

        Returns:
            Deletion result dict
        """
        return self.delete(
            PREPROCESSOR_ENDPOINTS["delete_preprocessor"],
            preprocessor_id=preprocessor_id,
        )
