# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-04-12

### Security

- Raised minimum dependency floor for `mcp[cli]` to `>=1.23.0`.
- Raised minimum dependency floor for `mkdocs-material` to `>=9.5.32`.
- Updated security workflows for manual Safety scanning in Azure Pipelines and GitHub Actions.

## [1.0.0] - 2026-04-12

### Added

- Public distribution and CLI branding as `kicad-mcp-pro`.
- Src-based `kicad_mcp` package layout.
- Config-driven project discovery and cross-platform KiCad CLI lookup.
- MCP resources, prompts, profiles, and refactored project/PCB/schematic/export tooling.
- Packaging, CI, docs, registry metadata, and Docker assets.
