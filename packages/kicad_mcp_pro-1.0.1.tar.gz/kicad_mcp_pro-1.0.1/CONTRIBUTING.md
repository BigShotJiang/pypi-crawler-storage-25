# Contributing

## Setup
```bash
uv sync --all-extras
uv run pytest
```

## Development Guidelines
- Keep user-facing messages in English.
- Use typed tool parameters and bounded validation.
- Prefer project-safe path resolution over raw filesystem access.
- Add tests for new tools or behavior changes.

## Pull Requests
- Describe the user-facing impact.
- Include tests or explain why tests were not feasible.
- Keep unrelated refactors out of the same pull request.
