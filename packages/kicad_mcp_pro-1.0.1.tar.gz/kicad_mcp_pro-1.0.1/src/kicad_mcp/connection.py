"""Thread-safe KiCad IPC connection management."""
# mypy: disable-error-code="attr-defined,call-arg"

from __future__ import annotations

import threading
from collections.abc import Generator
from contextlib import contextmanager

import structlog
from kipy.board import Board
from kipy.kicad import KiCad

from .config import get_config


class KiCadConnectionError(RuntimeError):
    """Raised when KiCad IPC connection fails."""


logger = structlog.get_logger(__name__)
_lock = threading.Lock()
_kicad: KiCad | None = None


def get_kicad() -> KiCad:
    """Return a thread-safe KiCad connection."""
    global _kicad
    with _lock:
        if _kicad is None:
            cfg = get_config()
            try:
                _kicad = KiCad(
                    socket_path=str(cfg.kicad_socket_path) if cfg.kicad_socket_path else None,
                    kicad_token=cfg.kicad_token,
                    timeout_ms=int(cfg.ipc_connection_timeout * 1000),
                    headless=cfg.kicad_headless,
                    kicad_cli_path=str(cfg.kicad_cli) if cfg.kicad_cli else None,
                    file_path=str(cfg.project_file or cfg.project_dir) if cfg.project_dir else None,
                )
            except Exception as exc:
                raise KiCadConnectionError(
                    "Could not connect to KiCad. Ensure KiCad is running with the IPC API "
                    "enabled, or configure headless mode with a valid kicad-cli path."
                ) from exc
    return _kicad


def get_board() -> Board:
    """Return the active board from KiCad."""
    try:
        return get_kicad().get_board()
    except Exception as exc:
        raise KiCadConnectionError("KiCad is connected but no board is currently open.") from exc


def reset_connection() -> None:
    """Force reconnect on next use."""
    global _kicad
    with _lock:
        if _kicad is not None:
            try:
                _kicad.close()
            except Exception as exc:
                logger.debug("kicad_close_failed", error=str(exc))
        _kicad = None


@contextmanager
def board_transaction() -> Generator[Board, None, None]:
    """Context manager for board operations."""
    board = get_board()
    try:
        yield board
    except KiCadConnectionError:
        reset_connection()
        raise
