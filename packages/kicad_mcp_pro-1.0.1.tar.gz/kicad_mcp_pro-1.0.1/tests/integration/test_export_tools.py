from __future__ import annotations

import json

import pytest

from kicad_mcp.server import build_server
from tests.conftest import call_tool_text


@pytest.mark.anyio
async def test_export_gerber_uses_cli_variants(sample_project, monkeypatch) -> None:
    out_dir = sample_project / "output" / "gerber"

    def fake_run(cmd, capture_output, text, timeout, check):
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "demo-F_Cu.gbr").write_text("gerber", encoding="utf-8")

        class Result:
            returncode = 0
            stdout = ""
            stderr = ""

        return Result()

    monkeypatch.setattr("kicad_mcp.tools.export.subprocess.run", fake_run)
    monkeypatch.setattr("kicad_mcp.discovery.subprocess.run", fake_run)
    server = build_server("manufacturing")
    text = await call_tool_text(server, "export_gerber", {"output_subdir": "gerber", "layers": []})
    assert "Gerber export completed" in text


@pytest.mark.anyio
async def test_run_drc_reads_json_report(sample_project, monkeypatch) -> None:
    report_path = sample_project / "output" / "drc_report.json"

    def fake_run(cmd, capture_output, text, timeout, check):
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(
            json.dumps(
                {
                    "violations": [{"severity": "error", "description": "Clearance"}],
                    "unconnected_items": [],
                    "items_not_passing_courtyard": [],
                }
            ),
            encoding="utf-8",
        )

        class Result:
            returncode = 0
            stdout = ""
            stderr = ""

        return Result()

    monkeypatch.setattr("kicad_mcp.tools.export.subprocess.run", fake_run)
    monkeypatch.setattr("kicad_mcp.discovery.subprocess.run", fake_run)
    server = build_server("manufacturing")
    text = await call_tool_text(server, "run_drc", {"save_report": True})
    assert "DRC summary" in text
