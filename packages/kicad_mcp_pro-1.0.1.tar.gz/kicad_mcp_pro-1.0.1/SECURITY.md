# Security Policy

## Reporting a Vulnerability
Please report suspected vulnerabilities through a private channel such as GitHub private
vulnerability reporting or a direct Azure DevOps security discussion.

Include:
- A clear description of the issue
- Reproduction steps
- Potential impact
- Any suggested mitigation

Do not open a public issue for undisclosed security problems.
