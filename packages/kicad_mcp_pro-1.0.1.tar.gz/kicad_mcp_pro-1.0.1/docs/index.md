# KiCad MCP Pro

KiCad MCP Pro is a project-aware Model Context Protocol server for KiCad PCB and schematic workflows.

Use the documentation in this folder for installation, client configuration, tool reference, and development notes.

## Documentation

- [Installation](installation.md)
- [Client Configuration](client-configuration.md)
- [Configuration](configuration.md)
- [Tools Reference](tools-reference.md)
- [First PCB Workflow](workflows/first-pcb.md)
- [Schematic To PCB Workflow](workflows/schematic-to-pcb.md)
- [Manufacturing Export Workflow](workflows/manufacturing-export.md)
- [Architecture](development/architecture.md)
- [Contributing](development/contributing.md)
