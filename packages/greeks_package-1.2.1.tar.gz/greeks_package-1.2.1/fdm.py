"""greeks_package.fdm – American option pricing via Finite Difference Method (Crank–Nicolson + PSOR)

Two entry points are provided:

``FDM`` – scalar solver
    Prices a single American call or put given explicit inputs.  Returns an
    ``_FDMResult`` object with ``price``, ``delta``, ``gamma``, ``theta_day``,
    ``S`` (asset grid), and ``V`` (option value vector).

``fdm_row`` – vectorized DataFrame wrapper
    Reads ``strike``, ``Days to Expiry``, and ``impliedVolatility`` from a
    DataFrame row (as produced by ``download_options``).  Designed for use
    with ``DataFrame.apply(axis=1)``.  Returns a ``pd.Series`` with
    ``FDM_Price``, ``FDM_Delta``, ``FDM_Gamma``, and ``FDM_Theta``.

Usage::

    import greeks_package as gp

    # --- Scalar (one option) ---
    res = gp.FDM(685.74, 685.0, 0.1743, 0.0402, 321/365)
    res.price
    res.delta
    res.gamma
    res.theta_day

    res = gp.FDM(685.74, 685.0, 0.1743, 0.0402, 321/365, option_type="put")
    res = gp.FDM(685.74, 685.0, 0.1743, 0.0402, 321/365, bs=True)

    # --- Vectorized (option chain) ---
    calls  = gp.download_options("AAPL", opt_type='c', max_days=30)
    fdm_df = calls.apply(gp.fdm_row, axis=1,
                         ticker="AAPL", option_type="call")
    full   = gp.comb(calls, fdm_df)
"""

import numpy as np
import pandas as pd
from scipy.stats import norm
from .core import _get_spot


class _FDMResult:
    """
    Return object for FDM(). Access results as attributes::

        res = FDM(...)
        res.price       # option price at S0
        res.delta       # ∂V/∂S
        res.gamma       # ∂²V/∂S²
        res.theta_day   # -∂V/∂t per calendar day
        res.S           # asset price grid (alias: res.S_grid)
        res.V           # option value vector at t=0 (alias: res.V_grid)
    """
    def __init__(self, price, delta, gamma, theta_day, S, V):
        self.price     = price
        self.delta     = delta
        self.gamma     = gamma
        self.theta_day = theta_day
        self.S = self.S_grid = S
        self.V = self.V_grid = V

    def __repr__(self):
        return (f"FDMResult(price={self.price:.4f}, delta={self.delta:.6f}, "
                f"gamma={self.gamma:.6f}, theta_day={self.theta_day:.6f})")


def FDM(S0, K, sigma, r, T,
        NAS=200, NTS=2000, S_max_mult=4.0, rannacher=4,
        omega=1.2, tol=1e-8, max_iter=5000,
        bs=False, option_type="call", silent=False,
        cn=True, psor=True, return_surface=False):
    """
    Price an American or European option via Finite Difference Method.

    The time-stepping scheme and inner solver are each independently
    controllable via ``cn`` and ``psor``, giving four modes:

    +---------+--------+-----------------------------------------------+
    | cn      | psor   | Scheme                                        |
    +=========+========+===============================================+
    | True    | True   | Crank-Nicolson + PSOR  (American, default)    |
    +---------+--------+-----------------------------------------------+
    | True    | False  | Crank-Nicolson + Thomas (European via FDM)    |
    +---------+--------+-----------------------------------------------+
    | False   | True   | Explicit + payoff projection  (American)      |
    +---------+--------+-----------------------------------------------+
    | False   | False  | Pure explicit  (European via explicit FDM)    |
    +---------+--------+-----------------------------------------------+

    Prints results automatically unless ``silent=True``.
    Returns an ``_FDMResult`` object.

    Required inputs
    ---------------
    S0         : float — current spot price
    K          : float — strike price
    sigma      : float — annualised volatility (e.g. 0.1743 for 17.43%)
    r          : float — risk-free rate (continuously compounded)
    T          : float — time to expiry in years

    Optional inputs
    ---------------
    NAS        : int   — asset-price grid steps          (default 200)
    NTS        : int   — time steps                      (default 2000)
    S_max_mult : float — S_max = mult × K                (default 4.0)
    rannacher  : int   — fully-implicit CN warm-up steps (default 4;
                         ignored when cn=False)
    omega      : float — PSOR over-relaxation factor     (default 1.2)
    tol        : float — PSOR convergence tolerance      (default 1e-8)
    max_iter   : int   — PSOR max iterations per step    (default 5000)
    bs         : bool  — print Black-Scholes benchmark   (default False)
    option_type: str   — "call" or "put"                 (default "call")
    silent     : bool  — suppress all printed output     (default False)
    cn         : bool  — use Crank-Nicolson (True) or explicit (False)
                         (default True).  Explicit FDM requires a fine
                         time grid for stability; a warning is raised if
                         the Von Neumann condition is violated.
    psor         : bool  — enforce early-exercise constraint via PSOR
                           (True = American, False = European) (default True).
                           When False, the tridiagonal system is solved
                           directly with the Thomas algorithm.
    return_surface: bool — if True, return the full price surface alongside the
                           result (default False). See Returns below.

    Returns
    -------
    return_surface=False (default):
        FDMResult with attributes: price, delta, gamma, theta_day, S / S_grid, V / V_grid

    return_surface=True:
        (FDMResult, S_grid, V_surface) where
        S_grid    : np.ndarray, shape (NAS+1,) — asset price axis
        V_surface : np.ndarray, shape (NTS+1, NAS+1)
            V_surface[k] is the option-value vector at tau = k*dt from expiry.
            V_surface[0] = payoff at expiry; V_surface[NTS] = current price.

    Examples
    --------
    res = FDM(685.74, 685.0, 0.1743, 0.0402, 321/365)                  # American call, CN+PSOR
    res = FDM(685.74, 685.0, 0.1743, 0.0402, 321/365, option_type="put")
    res = FDM(685.74, 685.0, 0.1743, 0.0402, 321/365, bs=True)
    res = FDM(685.74, 685.0, 0.1743, 0.0402, 321/365, cn=True,  psor=False)  # European, CN
    res = FDM(685.74, 685.0, 0.1743, 0.0402, 321/365, cn=False, psor=True)   # American, explicit
    res = FDM(685.74, 685.0, 0.1743, 0.0402, 321/365, cn=False, psor=False)  # European, explicit
    res.price
    res.delta
    """

    option_type = option_type.strip().lower()
    if option_type not in ("call", "put"):
        raise ValueError("option_type must be 'call' or 'put'")

    # ── Grid ──────────────────────────────────────────────────────────────────
    S_max  = S_max_mult * K
    dS     = S_max / NAS
    dt     = T / NTS
    S      = np.linspace(0, S_max, NAS + 1)
    if option_type == "call":
        Payoff = np.maximum(S - K, 0)
    else:
        Payoff = np.maximum(K - S, 0)

    # ── Tridiagonal Coefficients ───────────────────────────────────────────────
    S_int = S[1:NAS]
    a     = 0.5 * sigma**2 * S_int**2 / dS**2
    d     = r * S_int / (2 * dS)

    def _build(theta):
        A_lo = -theta     * dt * (a - d)
        A_di =  1 + theta * dt * (2*a + r)
        A_up = -theta     * dt * (a + d)
        B_lo =  (1-theta) * dt * (a - d)
        B_di =  1 - (1-theta) * dt * (2*a + r)
        B_up =  (1-theta) * dt * (a + d)
        return A_lo, A_di, A_up, B_lo, B_di, B_up

    A_lo_cn, A_di_cn, A_up_cn, B_lo_cn, B_di_cn, B_up_cn = _build(0.5)
    A_lo_im, A_di_im, A_up_im, B_lo_im, B_di_im, B_up_im = _build(1.0)

    # Explicit coefficients: theta=0 → A is the identity, B holds all the work.
    # Pre-built once and reused for every time step when cn=False.
    _, _, _, B_lo_ex, B_di_ex, B_up_ex = _build(0.0)

    # ── Stability check for explicit scheme ───────────────────────────────────
    # Von Neumann condition: the largest diffusion number must stay ≤ 0.5.
    # Violation doesn't raise an error — the user may intentionally accept
    # some numerical diffusion — but we do warn so they can increase NTS.
    if not cn:
        stab = float(np.max(a) * dt)
        if stab > 0.5 and not silent:
            import warnings as _w
            _w.warn(
                f"Explicit FDM may be unstable: max diffusion number = {stab:.4f} "
                f"(should be ≤ 0.5).  Increase NTS or switch to cn=True.",
                RuntimeWarning, stacklevel=2,
            )

    # ── PSOR (American, iterative) ────────────────────────────────────────────
    def _psor(A_lo, A_di, A_up, rhs, V_init, g):
        V = V_init.copy()
        for _ in range(max_iter):
            V_prev = V.copy()
            for j in range(len(rhs)):
                left  = V[j-1] if j > 0          else 0.0
                right = V[j+1] if j < len(rhs)-1 else 0.0
                V_gs  = (rhs[j] - A_lo[j]*left - A_up[j]*right) / A_di[j]
                V_sor = V[j] + omega * (V_gs - V[j])
                V[j]  = V_sor if V_sor > g[j] else g[j]
            if np.max(np.abs(V - V_prev)) < tol:
                break
        return V

    # ── Thomas algorithm (European, direct O(n) tridiagonal solve) ────────────
    def _thomas(A_lo, A_di, A_up, rhs):
        n   = len(rhs)
        di  = A_di.copy()
        rhs = rhs.copy()
        # Forward elimination
        for i in range(1, n):
            m      = A_lo[i] / di[i - 1]
            di[i] -= m * A_up[i - 1]
            rhs[i] -= m * rhs[i - 1]
        # Back substitution
        x     = np.empty(n)
        x[-1] = rhs[-1] / di[-1]
        for i in range(n - 2, -1, -1):
            x[i] = (rhs[i] - A_up[i] * x[i + 1]) / di[i]
        return x

    # ── Time March ────────────────────────────────────────────────────────────
    # Rannacher warm-up only applies to CN (uses implicit steps to damp
    # oscillations near the payoff kink). Ignored when cn=False.
    _rannacher = rannacher if cn else 0

    V = Payoff.copy()

    if return_surface:
        # surface[k] = V at tau = k*dt from expiry (surface[0]=payoff, surface[NTS]=current)
        surface = np.zeros((NTS + 1, NAS + 1))
        surface[0] = Payoff.copy()

    for k in range(NTS):
        tau_new = (k + 1) * dt

        if not cn:
            # Explicit: A = identity, so we only need the B coefficients.
            B_lo, B_di, B_up = B_lo_ex, B_di_ex, B_up_ex
        elif k < _rannacher:
            A_lo, A_di, A_up = A_lo_im, A_di_im, A_up_im
            B_lo, B_di, B_up = B_lo_im, B_di_im, B_up_im
        else:
            A_lo, A_di, A_up = A_lo_cn, A_di_cn, A_up_cn
            B_lo, B_di, B_up = B_lo_cn, B_di_cn, B_up_cn

        if option_type == "call":
            V_lower = 0.0
            V_upper = S_max - K * np.exp(-r * tau_new)
        else:
            V_lower = K * np.exp(-r * tau_new)
            V_upper = 0.0

        rhs      = B_lo * V[0:NAS-1] + B_di * V[1:NAS] + B_up * V[2:NAS+1]
        # Boundary adjustments: terms are zero for explicit (A_lo=A_up=0)
        # but kept here for a unified code path.
        if cn:
            rhs[0]  -= A_lo[0]  * V_lower
            rhs[-1] -= A_up[-1] * V_upper

        if not cn:
            # Explicit time step — no system to solve.
            if psor:
                # American: project onto early-exercise floor.
                V[1:NAS] = np.maximum(rhs, Payoff[1:NAS])
            else:
                # European: accept the explicit update directly.
                V[1:NAS] = rhs
        elif psor:
            # CN + PSOR: American, iterative solve with projection.
            V[1:NAS] = _psor(A_lo, A_di, A_up, rhs, V[1:NAS], Payoff[1:NAS])
        else:
            # CN + Thomas: European, direct tridiagonal solve.
            V[1:NAS] = _thomas(A_lo, A_di, A_up, rhs)

        V[0]   = V_lower
        V[NAS] = V_upper

        if return_surface:
            surface[k + 1] = V.copy()

    # ── Greeks ────────────────────────────────────────────────────────────────
    idx       = int(np.clip(np.argmin(np.abs(S - S0)), 1, NAS - 1))
    price     = V[idx]
    delta     = (V[idx+1] - V[idx-1]) / (2 * dS)
    gamma     = (V[idx+1] - 2*V[idx] + V[idx-1]) / dS**2
    theta_yr  = -(0.5*sigma**2*S[idx]**2*gamma + r*S[idx]*delta - r*price)
    theta_day = theta_yr / 365

    # ── Black-Scholes (nested, computed only if bs=True) ──────────────────────
    def _black_scholes():
        d1   = (np.log(S0/K) + (r + 0.5*sigma**2)*T) / (sigma*np.sqrt(T))
        d2   = d1 - sigma*np.sqrt(T)
        if option_type == "call":
            bs_p = S0*norm.cdf(d1) - K*np.exp(-r*T)*norm.cdf(d2)
            bs_d = norm.cdf(d1)
            bs_t = (-(S0*norm.pdf(d1)*sigma)/(2*np.sqrt(T))
                    - r*K*np.exp(-r*T)*norm.cdf(d2)) / 365
        else:
            bs_p = K*np.exp(-r*T)*norm.cdf(-d2) - S0*norm.cdf(-d1)
            bs_d = norm.cdf(d1) - 1.0
            bs_t = (-(S0*norm.pdf(d1)*sigma)/(2*np.sqrt(T))
                    + r*K*np.exp(-r*T)*norm.cdf(-d2)) / 365
        bs_g = norm.pdf(d1) / (S0*sigma*np.sqrt(T))
        return bs_p, bs_d, bs_g, bs_t

    # ── Print ─────────────────────────────────────────────────────────────────
    if not silent:
        days = round(T * 365)
        exercise  = "AMERICAN" if psor else "EUROPEAN"
        opt_label = "CALL" if option_type == "call" else "PUT"
        scheme    = ("Crank-Nicolson" if cn else "Explicit") + (" + PSOR" if psor else " + Thomas")
        print("=" * 62)
        print(f"  {exercise} {opt_label} — {scheme}")
        print("=" * 62)
        print(f"\n  Option Parameters:")
        print(f"    Spot (S₀):           ${S0:.2f}")
        print(f"    Strike (K):          ${K:.2f}")
        print(f"    Volatility (σ):       {sigma*100:.2f}%")
        print(f"    Risk-free rate:       {r*100:.2f}%")
        print(f"    Time to expiry:       {T:.4f} yrs ({days} days)")
        print(f"\n{'─'*62}")

        if bs:
            bs_p, bs_d, bs_g, bs_t = _black_scholes()
            print(f"  {'':28s} {'FDM':>10s}  {'Black-Scholes':>12s}")
            print(f"{'─'*62}")
            print(f"  Option Price:          {'${:.4f}'.format(price):>10s}  {'${:.4f}'.format(bs_p):>12s}")
            print(f"  Delta:                 {delta:>+10.6f}  {bs_d:>+12.6f}")
            print(f"  Gamma:                 {gamma:>+10.6f}  {bs_g:>+12.6f}")
            print(f"  Theta (per day):       {theta_day:>+10.6f}  {bs_t:>+12.6f}")
            print(f"{'─'*62}")
            print(f"\n  Error vs Black-Scholes:")
            print(f"    Price: ${abs(price-bs_p):.4f}  ({abs(price-bs_p)/bs_p*100:.3f}%)")
        else:
            print(f"  Option Price:    ${price:.4f}")
            print(f"{'─'*62}")
            print(f"  Delta:           {delta:>+.6f}")
            print(f"  Gamma:           {gamma:>+.6f}")
            print(f"  Theta (per day): {theta_day:>+.6f}")

        print("=" * 62)

    result = _FDMResult(price, delta, gamma, theta_day, S, V)
    if return_surface:
        return result, S, surface
    return result


def fdm_row(
    row: pd.Series,
    ticker: str,
    option_type: str = 'call',
    r: float = 0.05,
    NAS: int = 200,
    NTS: int = 2000,
    S_max_mult: float = 4.0,
    rannacher: int = 4,
    omega: float = 1.2,
    tol: float = 1e-8,
    max_iter: int = 5000,
    cn: bool = True,
    psor: bool = True,
) -> pd.Series:
    """
    Row-level FDM wrapper — price one option from a DataFrame row.

    Designed to be used with ``DataFrame.apply(axis=1)``, following the same
    row-based interface as the European Greek functions (``first_order``,
    ``greeks``, etc.).  Reads ``strike``, ``Days to Expiry``, and
    ``impliedVolatility`` from the row; fetches the spot price once per ticker
    (cached via ``_get_spot``).

    Returns ``FDM_Price``, ``FDM_Delta``, ``FDM_Gamma``, and ``FDM_Theta``
    — prefixed so the columns don't collide with Black-Scholes Greeks when
    you combine results with ``gp.comb()``.

    Parameters
    ----------
    row : pd.Series
        One row from a ``download_options`` DataFrame.  Must contain
        ``'strike'``, ``'Days to Expiry'``, and ``'impliedVolatility'``.
    ticker : str
        Stock ticker symbol (e.g. ``"AAPL"``).
    option_type : str
        ``'call'`` or ``'put'`` (default: ``'call'``).
    r : float
        Continuously-compounded risk-free rate (default: 0.05).
    NAS : int
        Number of asset-price grid steps (default: 200).
        Reduce to ~100 for faster but slightly less accurate results on
        large chains.
    NTS : int
        Number of time steps (default: 2000).
        Reduce to ~500–1000 for faster results on large chains.
    S_max_mult : float
        Upper asset-price boundary as a multiple of the strike (default: 4.0).
    rannacher : int
        Number of fully-implicit warm-up steps to damp early oscillations
        (default: 4; ignored when cn=False).
    omega : float
        PSOR over-relaxation factor (default: 1.2).
    tol : float
        PSOR convergence tolerance (default: 1e-8).
    max_iter : int
        Maximum PSOR iterations per time step (default: 5000).
    cn : bool
        Use Crank-Nicolson (True) or explicit (False) time-stepping
        (default: True).
    psor : bool
        Enforce early-exercise constraint via PSOR — True for American
        options, False for European (default: True).

    Returns
    -------
    pd.Series
        Four values: ``FDM_Price``, ``FDM_Delta``, ``FDM_Gamma``,
        ``FDM_Theta`` (theta is per calendar day).
        All values are ``NaN`` if ``Days to Expiry`` or
        ``impliedVolatility`` are non-positive.

    Notes
    -----
    FDM is computationally intensive — each row runs a full PDE solve.
    For chains with many rows, consider lowering ``NAS`` and ``NTS``
    to balance speed against accuracy:

    .. code-block:: python

        df.apply(gp.fdm_row, axis=1, ticker="AAPL",
                 option_type="call", NAS=100, NTS=500)

    Examples
    --------
    ::

        import greeks_package as gp

        # American calls (default: CN + PSOR)
        calls  = gp.download_options("AAPL", opt_type='c', max_days=30)
        fdm_df = calls.apply(gp.fdm_row, axis=1,
                             ticker="AAPL", option_type="call")
        full = gp.comb(calls, fdm_df)

        # European calls via CN + Thomas
        fdm_df = calls.apply(gp.fdm_row, axis=1,
                             ticker="AAPL", option_type="call",
                             cn=True, psor=False)

        # American calls via explicit FDM (increase NTS for stability)
        fdm_df = calls.apply(gp.fdm_row, axis=1,
                             ticker="AAPL", option_type="call",
                             cn=False, psor=True, NTS=10000)

        # Side-by-side with Black-Scholes Greeks
        bs_df  = calls.apply(gp.first_order, axis=1,
                             ticker="AAPL", option_type='c')
        fdm_df = calls.apply(gp.fdm_row, axis=1,
                             ticker="AAPL", option_type="call")
        full = gp.comb(calls, bs_df, fdm_df)
    """
    _NAN = pd.Series({
        'FDM_Price': float('nan'),
        'FDM_Delta': float('nan'),
        'FDM_Gamma': float('nan'),
        'FDM_Theta': float('nan'),
    })

    T = row['Days to Expiry'] / 365
    sigma = row['impliedVolatility']
    if not (np.isfinite(T) and T > 0 and np.isfinite(sigma) and sigma > 0):
        return _NAN

    S0 = _get_spot(ticker)
    K  = row['strike']

    try:
        res = FDM(
            S0, K, sigma, r, T,
            NAS=NAS, NTS=NTS, S_max_mult=S_max_mult,
            rannacher=rannacher, omega=omega, tol=tol,
            max_iter=max_iter, option_type=option_type,
            cn=cn, psor=psor, silent=True,
        )
        return pd.Series({
            'FDM_Price': round(res.price,     4),
            'FDM_Delta': round(res.delta,     6),
            'FDM_Gamma': round(res.gamma,     6),
            'FDM_Theta': round(res.theta_day, 6),
        })
    except Exception:
        return _NAN


__all__ = [
    "FDM",
    "fdm_row",
]