"""greeks_package.backtest – Delta-hedge backtesting via FDM repricing

Simulates a single GBM stock-price path and runs a discrete delta-hedge
backtest, repricing the American option at each step with the FDM solver.

Public functions
----------------
simulate_gbm   – Generate a single GBM price path.
run_backtest   – Run a delta-hedge backtest and return all time-series data.
plot_backtest  – Plot stock price path and FDM-repriced option value.
plot_greeks    – Plot delta, gamma, theta, and hedge shares over the period.

Typical usage::

    import greeks_package as gp

    res = gp.run_backtest(
        S0=685.74, K=685.0, sigma=0.1743, r=0.0402, T=321/365,
        sigma_real=0.22, seed=42,
    )
    gp.plot_backtest(res)
    gp.plot_greeks(res)
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

from .fdm import FDM

# Reduced grid settings used for every intra-backtest reprice.
# Keeps runtime reasonable without sacrificing meaningful accuracy.
# Override by passing fdm_nas / fdm_nts to run_backtest.
_BACKTEST_NAS = 200
_BACKTEST_NTS = 1000


# ────────────────────────────── GBM PATH ──────────────────────────────────────

def simulate_gbm(S0: float, sigma: float, r: float, T: float,
                 dt: float, seed: int = None) -> np.ndarray:
    """
    Simulate a single GBM stock-price path.

    This is **not** a Monte Carlo simulation — it generates one path only.
    Use a fixed ``seed`` for reproducibility while tuning backtest parameters.

    Parameters
    ----------
    S0    : float — initial stock price
    sigma : float — annualised volatility (e.g. 0.22 for 22%)
    r     : float — continuously-compounded risk-free rate
    T     : float — total time horizon in years
    dt    : float — time step size in years (e.g. 1/365 for daily)
    seed  : int, optional — random seed for reproducibility

    Returns
    -------
    np.ndarray of length int(T/dt) + 1, starting at S0.
    """
    if seed is not None:
        np.random.seed(seed)
    N = int(round(T / dt))
    Z = np.random.standard_normal(N)
    increments = np.exp((r - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * Z)
    return S0 * np.concatenate([[1.0], np.cumprod(increments)])


# ────────────────────────────── BACKTEST ──────────────────────────────────────

def run_backtest(
    S0: float,
    K: float,
    sigma: float,
    r: float,
    T: float,
    sigma_real: float = None,
    dt: float = 1 / 365,
    rebal_freq: int = 1,
    cost_per_share: float = 0.00003,
    seed: int = 42,
    cn: bool = True,
    psor: bool = True,
    fdm_nas: int = _BACKTEST_NAS,
    fdm_nts: int = _BACKTEST_NTS,
    verbose: bool = True,
    precompute: bool = True,
) -> dict:
    """
    Run a discrete delta-hedge backtest on a single GBM path.

    The strategy buys the option at t=0, immediately shorts ``delta`` shares
    to be delta-neutral, then rebalances every ``rebal_freq`` steps. The
    option is repriced at each step using the FDM solver.

    ``sigma`` is the implied volatility used for pricing and hedging.
    ``sigma_real`` (optional) is the realised volatility used to simulate the
    stock path — set it higher or lower than ``sigma`` to study the effect of
    vol mismatch on hedge P&L.

    Parameters
    ----------
    S0            : float — initial spot price
    K             : float — strike price
    sigma         : float — implied volatility for pricing / hedging
    r             : float — continuously-compounded risk-free rate
    T             : float — option tenor in years
    sigma_real    : float, optional — realised vol for GBM path (default: sigma)
    dt            : float — time step in years (default: 1/365 = daily)
    rebal_freq    : int   — rebalance every N steps (default: 1 = every step)
    cost_per_share: float — transaction cost per share traded (default: 0.00003)
    seed          : int   — random seed for GBM path (default: 42)
    cn            : bool  — use Crank-Nicolson in FDM (default: True)
    psor          : bool  — use PSOR / American pricing in FDM (default: True)
    fdm_nas       : int   — asset-grid steps for intra-backtest reprice (default: 200)
    fdm_nts       : int   — time steps for intra-backtest reprice (default: 1000,
                            only used when precompute=False)
    verbose       : bool  — print summary table (default: True)
    precompute    : bool  — build the full FDM price surface once and look up values
                            by interpolation instead of re-solving at every step.
                            Reduces N FDM solves to 1 — strongly recommended for
                            long-dated options or fine dt. (default: True)

    Returns
    -------
    dict with keys:
        times, S, option_vals, deltas, gammas, thetas,
        hedge_shares, cash, port_val, daily_pnl, trans_costs,
        pnl_gamma, pnl_theta, final_pnl, total_costs,
        pnl_std, pnl_mean, N, S0, K

    Notes
    -----
    * Dividends are not yet modelled — cash grows at the risk-free rate only.
    * ``precompute=True`` (default) runs one FDM solve with NTS = number of
      backtest steps, then looks up values by interpolation. This is ~300× faster
      than the original per-step approach for long-dated options. The ``fdm_nts``
      parameter is ignored when ``precompute=True``.
    * For hourly rebalancing (``dt=1/(365*6.5)``) use ``precompute=False`` and
      increase ``fdm_nts`` to maintain FDM stability.
    * Pass ``precompute=False`` to restore the original per-step behaviour for
      research or comparison purposes.
    """
    if sigma_real is None:
        sigma_real = sigma

    S_path = simulate_gbm(S0, sigma_real, r, T, dt, seed=seed)
    N      = len(S_path) - 1
    times  = np.arange(N + 1) * dt

    option_vals  = np.zeros(N + 1)
    deltas       = np.zeros(N + 1)
    gammas       = np.zeros(N + 1)
    thetas       = np.zeros(N + 1)
    hedge_shares = np.zeros(N + 1)
    cash         = np.zeros(N + 1)
    port_val     = np.zeros(N + 1)
    daily_pnl    = np.zeros(N)
    trans_costs  = np.zeros(N + 1)
    pnl_gamma    = np.zeros(N)
    pnl_theta    = np.zeros(N)

    # ── Build price surface (one FDM solve covers all time steps) ─────────────
    # surface[k] = V(S) at tau = k*dt from expiry.
    # Backtest step i has tau = (N-i)*dt → surface index N-i.
    if precompute:
        _, S_grid, surface = FDM(S0, K, sigma, r, T,
                                  NAS=fdm_nas, NTS=N, cn=cn, psor=psor,
                                  option_type='call', silent=True, return_surface=True)
        dS_grid = S_grid[1] - S_grid[0]

        def _lookup(step_i, S_val):
            surf_idx = N - step_i
            V_slice  = surface[surf_idx]
            idx = int(np.clip(np.searchsorted(S_grid, S_val) - 1, 1, fdm_nas - 1))
            price = float(np.interp(S_val, S_grid, V_slice))
            d = (V_slice[idx + 1] - V_slice[idx - 1]) / (2 * dS_grid)
            g = (V_slice[idx + 1] - 2 * V_slice[idx] + V_slice[idx - 1]) / dS_grid ** 2
            t_yr = -(0.5 * sigma**2 * S_grid[idx]**2 * g + r * S_grid[idx] * d - r * price)
            return price, d, g, t_yr / 365
    else:
        _fdm_kw = dict(NAS=fdm_nas, NTS=fdm_nts, cn=cn, psor=psor, silent=True)

    # ── t = 0: buy option, immediately short delta shares ─────────────────────
    if precompute:
        V_0, d_0, g_0, t_0 = _lookup(0, S_path[0])
    else:
        res0 = FDM(S_path[0], K, sigma, r, T, **_fdm_kw)
        V_0, d_0, g_0, t_0 = res0.price, res0.delta, res0.gamma, res0.theta_day

    option_vals[0]  = V_0
    deltas[0]       = d_0
    gammas[0]       = g_0
    thetas[0]       = t_0
    hedge_shares[0] = d_0

    cost_0         = abs(d_0) * S_path[0] * cost_per_share
    trans_costs[0] = cost_0
    cash[0]        = d_0 * S_path[0] - V_0 - cost_0
    port_val[0]    = V_0 - hedge_shares[0] * S_path[0] + cash[0]

    # ── Daily loop: reprice, rebalance, record ─────────────────────────────────
    for i in range(1, N + 1):
        tau_i = max(T - i * dt, 0.0)

        # Cash earns the risk-free rate between steps
        cash[i] = cash[i - 1] * np.exp(r * dt)

        if tau_i <= 0:
            # Expiry: option collapses to intrinsic value
            V_i = max(S_path[i] - K, 0.0)
            d_i = 1.0 if S_path[i] > K else 0.0
            g_i = 0.0
            t_i = 0.0
        elif precompute:
            V_i, d_i, g_i, t_i = _lookup(i, S_path[i])
        else:
            res_i = FDM(S_path[i], K, sigma, r, tau_i, **_fdm_kw)
            V_i, d_i, g_i, t_i = res_i.price, res_i.delta, res_i.gamma, res_i.theta_day

        option_vals[i] = V_i
        deltas[i]      = d_i
        gammas[i]      = g_i
        thetas[i]      = t_i

        # Rebalance on schedule
        if i % rebal_freq == 0:
            d_trade      = d_i - hedge_shares[i - 1]
            cost_i       = abs(d_trade) * S_path[i] * cost_per_share
            cash[i]     += d_trade * S_path[i] - cost_i
            hedge_shares[i] = d_i
            trans_costs[i]  = trans_costs[i - 1] + cost_i
        else:
            hedge_shares[i] = hedge_shares[i - 1]
            trans_costs[i]  = trans_costs[i - 1]

        # Portfolio value = option − hedge shares + cash
        port_val[i]    = option_vals[i] - hedge_shares[i] * S_path[i] + cash[i]
        daily_pnl[i-1] = port_val[i] - port_val[i - 1]

        dS              = S_path[i] - S_path[i - 1]
        pnl_gamma[i-1]  = 0.5 * gammas[i - 1] * dS**2
        pnl_theta[i-1]  = thetas[i - 1] * dt * 365   # theta_day × fraction of day

    final_pnl  = port_val[-1] - port_val[0]
    total_costs = trans_costs[-1]
    pnl_std    = np.std(daily_pnl)
    pnl_mean   = np.mean(daily_pnl)

    # ── Summary print ─────────────────────────────────────────────────────────
    if verbose:
        days       = round(T * 365)
        cost_label = "No Transaction Costs" if cost_per_share == 0 else "With Transaction Costs"
        scheme     = ("Crank-Nicolson" if cn else "Explicit") + (" + PSOR" if psor else " + Thomas")
        print("=" * 60)
        print("  DELTA HEDGE BACKTEST")
        print(f"  Single GBM Path · Rebal every {rebal_freq} step(s) · {cost_label}")
        print(f"  FDM Scheme: {scheme}")
        print("=" * 60)
        print(f"\n  Option Parameters:")
        print(f"    Spot (S₀):         ${S0:.2f}")
        print(f"    Strike (K):        ${K:.2f}")
        print(f"    Volatility (σ):     {sigma*100:.2f}%")
        if sigma_real != sigma:
            print(f"    Realised vol:       {sigma_real*100:.2f}%")
        print(f"    Risk-free rate:     {r*100:.2f}%")
        print(f"    Time to expiry:     {T:.4f} yrs ({days} days)")
        print(f"    Rebal frequency:    every {rebal_freq} step(s)")
        print(f"    Cost per share:    ${cost_per_share:.4f}")
        print(f"\n{'─'*60}")
        print(f"  Path Outcome:")
        print(f"    Terminal S:         ${S_path[-1]:.2f}")
        print(f"    Option payoff:      ${max(S_path[-1]-K, 0):.4f}")
        print(f"    Initial option V:   ${option_vals[0]:.4f}")
        print(f"\n  Hedge Performance:")
        print(f"    Initial portfolio:  ${port_val[0]:.4f}   (≈ 0 by construction)")
        print(f"    Final portfolio:    ${port_val[-1]:.4f}")
        print(f"    Total P&L:          ${final_pnl:+.4f}  (≈ 0 for perfect hedge)")
        print(f"    Total trans costs:  ${total_costs:.4f}")
        print(f"\n  Daily P&L Statistics:")
        print(f"    Mean:               ${pnl_mean:+.6f}  (≈ 0 for perfect hedge)")
        print(f"    Std dev:            ${pnl_std:.6f}  ← hedging error")
        print(f"    Min / Max:          ${daily_pnl.min():+.4f}  /  ${daily_pnl.max():+.4f}")
        print(f"\n  P&L Decomposition (theory: ½Γ·ΔS² + Θ·dt ≈ 0):")
        print(f"    Cumulative gamma:   ${pnl_gamma.sum():+.4f}")
        print(f"    Cumulative theta:   ${pnl_theta.sum():+.4f}")
        print(f"    Gamma + Theta:      ${pnl_gamma.sum()+pnl_theta.sum():+.4f}  (residual = hedging error)")
        print("=" * 60)

    return {
        "times"        : times,
        "S"            : S_path,
        "option_vals"  : option_vals,
        "deltas"       : deltas,
        "gammas"       : gammas,
        "thetas"       : thetas,
        "hedge_shares" : hedge_shares,
        "cash"         : cash,
        "port_val"     : port_val,
        "daily_pnl"    : daily_pnl,
        "trans_costs"  : trans_costs,
        "pnl_gamma"    : pnl_gamma,
        "pnl_theta"    : pnl_theta,
        "final_pnl"    : final_pnl,
        "total_costs"  : total_costs,
        "pnl_std"      : pnl_std,
        "pnl_mean"     : pnl_mean,
        "N"            : N,
        "S0"           : S0,
        "K"            : K,
    }


# ────────────────────────────── PLOTS ─────────────────────────────────────────

def plot_backtest(res: dict, return_fig: bool = False):
    """
    Plot stock price path and FDM-repriced option value from a backtest result.

    Parameters
    ----------
    res        : dict returned by ``run_backtest``
    return_fig : bool — if True, returns the Figure instead of calling plt.show()

    Returns
    -------
    None, or matplotlib.figure.Figure if return_fig=True.

    Example
    -------
    ::

        res = gp.run_backtest(S0=685.74, K=685.0, sigma=0.1743,
                              r=0.0402, T=321/365)
        gp.plot_backtest(res)
        fig = gp.plot_backtest(res, return_fig=True)
        fig.savefig("backtest.png", dpi=150)
    """
    days = res["times"] * 365

    fig = plt.figure(figsize=(14, 5))
    gs  = gridspec.GridSpec(1, 2, figure=fig)

    ax1 = fig.add_subplot(gs[0])
    ax1.plot(days, res["S"], color="blue", linewidth=1)
    ax1.axhline(res["K"], color="gray", linewidth=0.8, linestyle="--",
                label=f"Strike ${res['K']:.0f}")
    ax1.set_xlabel("Days")
    ax1.set_ylabel("Stock Price")
    ax1.legend()
    ax1.set_title("GBM Stock Price")

    ax2 = fig.add_subplot(gs[1])
    ax2.plot(days, res["option_vals"], color="orange", linewidth=1.2)
    ax2.set_title("FDM Reprice")
    ax2.set_xlabel("Days")
    ax2.set_ylabel("Option Price")

    plt.suptitle("Delta Hedge Backtest", fontsize=12, fontweight="bold")
    plt.tight_layout()

    if return_fig:
        return fig
    plt.show()


def plot_greeks(res: dict, return_fig: bool = False):
    """
    Plot delta, gamma, theta, and hedge shares over the backtest period.

    Parameters
    ----------
    res        : dict returned by ``run_backtest``
    return_fig : bool — if True, returns the Figure instead of calling plt.show()

    Returns
    -------
    None, or matplotlib.figure.Figure if return_fig=True.

    Example
    -------
    ::

        res = gp.run_backtest(S0=685.74, K=685.0, sigma=0.1743,
                              r=0.0402, T=321/365)
        gp.plot_greeks(res)
        fig = gp.plot_greeks(res, return_fig=True)
        fig.savefig("greeks.png", dpi=150)
    """
    days = res["times"] * 365

    fig = plt.figure(figsize=(14, 10))
    gs  = gridspec.GridSpec(2, 2, figure=fig)

    ax1 = fig.add_subplot(gs[0, 0])
    ax1.plot(days, res["deltas"], color="steelblue", linewidth=1.2)
    ax1.set_title("Delta")
    ax1.set_xlabel("Days")

    ax2 = fig.add_subplot(gs[0, 1])
    ax2.plot(days, res["gammas"], color="darkorange", linewidth=1.2)
    ax2.set_title("Gamma")
    ax2.set_xlabel("Days")

    ax3 = fig.add_subplot(gs[1, 0])
    ax3.plot(days, res["thetas"], color="seagreen", linewidth=1.2)
    ax3.set_title("Theta (per day)")
    ax3.set_xlabel("Days")

    ax4 = fig.add_subplot(gs[1, 1])
    ax4.plot(days, res["hedge_shares"], color="mediumpurple", linewidth=1.2)
    ax4.set_title("Hedge Shares Held")
    ax4.set_xlabel("Days")
    ax4.set_ylabel("Shares")

    plt.suptitle("Greeks Over Time", fontsize=13, fontweight="bold")
    plt.tight_layout()

    if return_fig:
        return fig
    plt.show()


__all__ = [
    "simulate_gbm",
    "run_backtest",
    "plot_backtest",
    "plot_greeks",
]
