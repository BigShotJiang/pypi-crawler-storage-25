"""Runtime configuration parsed from environment variables.

ptm-mcp is a stdio server started by an MCP client (Claude Desktop, Goose,
etc.) which passes env vars through to the spawned process. We fail fast on
missing or malformed required values so the client surfaces a clear error
instead of a cryptic 401 on the first tool call.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

MIN_BACKEND_VERSION = "1.9.0"


@dataclass(frozen=True)
class Settings:
    ptm_api_base_url: str
    ptm_api_token: str
    read_only: bool = True
    timeout_seconds: int = 120
    log_level: str = "INFO"


class ConfigError(RuntimeError):
    """Raised when required env vars are missing or malformed."""


def load_settings() -> Settings:
    """Load ptm-mcp settings from environment. Fail fast on missing required vars."""
    base = os.environ.get("PTM_API_BASE_URL", "").strip()
    token = os.environ.get("PTM_API_TOKEN", "").strip()
    if not base:
        raise ConfigError("PTM_API_BASE_URL is required")
    if not token:
        raise ConfigError("PTM_API_TOKEN is required")

    read_only_env = os.environ.get("PTM_MCP_READ_ONLY", "true").strip().lower()
    read_only = read_only_env not in ("false", "0", "no", "")

    try:
        timeout = int(os.environ.get("PTM_MCP_TIMEOUT_SECONDS", "120"))
    except ValueError as exc:
        raise ConfigError("PTM_MCP_TIMEOUT_SECONDS must be an integer") from exc
    if timeout < 1 or timeout > 600:
        raise ConfigError("PTM_MCP_TIMEOUT_SECONDS must be in 1..600")

    log_level = os.environ.get("PTM_MCP_LOG_LEVEL", "INFO").upper()
    if log_level not in ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"):
        raise ConfigError(f"PTM_MCP_LOG_LEVEL invalid: {log_level}")

    return Settings(
        ptm_api_base_url=base,
        ptm_api_token=token,
        read_only=read_only,
        timeout_seconds=timeout,
        log_level=log_level,
    )
