"""pyclopse A2A (Agent-to-Agent) protocol integration."""
