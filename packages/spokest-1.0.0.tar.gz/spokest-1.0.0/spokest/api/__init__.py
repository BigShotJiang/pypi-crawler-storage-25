# flake8: noqa

# import apis into api package
from spokest.api.api_keys_api import APIKeysApi
from spokest.api.crud_api import CRUDApi
from spokest.api.chat_api import ChatApi
from spokest.api.events_api import EventsApi
from spokest.api.import_api import ImportApi
from spokest.api.memory_api import MemoryApi
from spokest.api.status_api import StatusApi
from spokest.api.webhooks_api import WebhooksApi

