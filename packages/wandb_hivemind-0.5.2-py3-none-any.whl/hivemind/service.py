"""Cross-platform daemon service management.

Provides start/stop/restart/status operations using the best available
service manager for the current platform:
1. Homebrew services (macOS and Linux Homebrew installs)
2. systemd user services (Linux with systemd)
3. Direct process management (universal fallback)
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import signal
import subprocess
import sys
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from hivemind.config import get_endpoint_override
from hivemind.logging_config import DEFAULT_LOG_FILE
from hivemind.state import DEFAULT_STATE_DIR, find_daemon_pid, is_daemon_running

logger = logging.getLogger(__name__)


@dataclass
class ServiceStatus:
    """Status of the daemon service."""

    running: bool
    pid: int | None = None
    uptime: str | None = None
    method: str = "unknown"
    service_name: str | None = None
    brew_desync: bool = False


class ServicePlatform(Enum):
    """Available service management platforms."""

    HOMEBREW = "homebrew"
    SYSTEMD = "systemd"
    DIRECT = "direct"


def _format_uptime(seconds: float) -> str:
    """Format seconds into a human-readable uptime string."""
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m {seconds % 60}s"
    hours = minutes // 60
    remaining_min = minutes % 60
    if hours < 24:
        return f"{hours}h {remaining_min}m"
    days = hours // 24
    remaining_hours = hours % 24
    return f"{days}d {remaining_hours}h"


def detect_platform() -> ServicePlatform:
    """Detect the best available service management platform.

    Checks in order:
    1. Homebrew: hivemind executable under a Homebrew prefix and formula installed
    2. systemd: systemctl available and unit file exists
    3. Direct: universal fallback
    """
    # Check for Homebrew
    if _is_homebrew_available():
        return ServicePlatform.HOMEBREW

    # Check for systemd
    if _is_systemd_available():
        return ServicePlatform.SYSTEMD

    return ServicePlatform.DIRECT


def _is_homebrew_available() -> bool:
    """Check if hivemind is installed via Homebrew."""
    brew_path = shutil.which("brew")
    if not brew_path:
        return False

    # Check if our formula is installed
    try:
        result = subprocess.run(
            ["brew", "list", "wandb/taps/hivemind"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def _is_systemd_available() -> bool:
    """Check if systemd user services are available with our unit file."""
    unit_path = Path.home() / ".config" / "systemd" / "user" / "hivemind.service"
    if not unit_path.exists():
        return False

    try:
        result = subprocess.run(
            ["systemctl", "--user", "show-environment"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


class ServiceManager(ABC):
    """Abstract base class for service managers."""

    @abstractmethod
    def start(self, **kwargs: object) -> tuple[bool, str]:
        """Start the daemon service.

        Returns:
            Tuple of (success, message).
        """

    @abstractmethod
    def stop(self, force: bool = False) -> tuple[bool, str]:
        """Stop the daemon service.

        Args:
            force: If True, forcefully kill the process.

        Returns:
            Tuple of (success, message).
        """

    @abstractmethod
    def restart(self, **kwargs: object) -> tuple[bool, str]:
        """Restart the daemon service.

        Returns:
            Tuple of (success, message).
        """

    @abstractmethod
    def status(self) -> ServiceStatus:
        """Get the current service status.

        Returns:
            ServiceStatus with current state information.
        """


class HomebrewServiceManager(ServiceManager):
    """Manage the daemon via Homebrew services."""

    FORMULA = "wandb/taps/hivemind"

    def start(self, **kwargs: object) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["brew", "services", "start", self.FORMULA],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Started {self.FORMULA} via Homebrew services"
            return False, output or f"Failed to start {self.FORMULA}"
        except subprocess.TimeoutExpired:
            return False, "Timed out starting Homebrew service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run brew: {e}"

    def stop(self, force: bool = False) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["brew", "services", "stop", self.FORMULA],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Stopped {self.FORMULA} via Homebrew services"
            return False, output or f"Failed to stop {self.FORMULA}"
        except subprocess.TimeoutExpired:
            return False, "Timed out stopping Homebrew service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run brew: {e}"

    def restart(self, **kwargs: object) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["brew", "services", "restart", self.FORMULA],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Restarted {self.FORMULA} via Homebrew services"
            return False, output or f"Failed to restart {self.FORMULA}"
        except subprocess.TimeoutExpired:
            return False, "Timed out restarting Homebrew service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run brew: {e}"

    def status(self) -> ServiceStatus:
        running = False
        pid = None
        try:
            result = subprocess.run(
                ["brew", "services", "info", self.FORMULA, "--json"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                data = json.loads(result.stdout)
                # brew services info --json returns a list
                info = data[0] if isinstance(data, list) else data
                running = info.get("status") == "started"
                pid = info.get("pid")
            else:
                # brew command ran but returned non-zero or empty output
                running = is_daemon_running()
                pid = find_daemon_pid() if running else None
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            OSError,
            json.JSONDecodeError,
            KeyError,
            IndexError,
        ):
            # Fallback: use lock-file detection
            running = is_daemon_running()
            pid = find_daemon_pid() if running else None

        # Cross-check: brew may report "stopped" while the daemon is actually
        # running (e.g., brew service state got out of sync after a crash or
        # manual restart).  Trust the lock file as ground truth.
        brew_desync = False
        if not running and is_daemon_running():
            running = True
            brew_desync = True
            pid = pid or find_daemon_pid()

        uptime = _uptime_from_pid(pid) if running and pid else None
        return ServiceStatus(
            running=running,
            pid=pid,
            uptime=uptime,
            method="homebrew",
            service_name=self.FORMULA,
            brew_desync=brew_desync,
        )


class SystemdServiceManager(ServiceManager):
    """Manage the daemon via systemd user services."""

    UNIT = "hivemind.service"

    def start(self, **kwargs: object) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["systemctl", "--user", "start", self.UNIT],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Started {self.UNIT} via systemd"
            return False, output or f"Failed to start {self.UNIT}"
        except subprocess.TimeoutExpired:
            return False, "Timed out starting systemd service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run systemctl: {e}"

    def stop(self, force: bool = False) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["systemctl", "--user", "stop", self.UNIT],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Stopped {self.UNIT} via systemd"
            return False, output or f"Failed to stop {self.UNIT}"
        except subprocess.TimeoutExpired:
            return False, "Timed out stopping systemd service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run systemctl: {e}"

    def restart(self, **kwargs: object) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["systemctl", "--user", "restart", self.UNIT],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Restarted {self.UNIT} via systemd"
            return False, output or f"Failed to restart {self.UNIT}"
        except subprocess.TimeoutExpired:
            return False, "Timed out restarting systemd service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run systemctl: {e}"

    def status(self) -> ServiceStatus:
        try:
            result = subprocess.run(
                [
                    "systemctl",
                    "--user",
                    "show",
                    self.UNIT,
                    "--property=ActiveState,MainPID,ExecMainStartTimestamp",
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                props: dict[str, str] = {}
                for line in result.stdout.strip().splitlines():
                    if "=" in line:
                        key, _, value = line.partition("=")
                        props[key.strip()] = value.strip()

                running = props.get("ActiveState") == "active"
                pid_str = props.get("MainPID", "0")
                pid = int(pid_str) if pid_str and pid_str != "0" else None

                uptime = None
                start_ts = props.get("ExecMainStartTimestamp", "")
                if running and start_ts:
                    try:
                        # systemd returns timestamps like "Mon 2024-01-15 10:30:00 PST"
                        # Use subprocess to get epoch seconds for reliability
                        ts_result = subprocess.run(
                            [
                                "systemctl",
                                "--user",
                                "show",
                                self.UNIT,
                                "--property=ExecMainStartTimestampMonotonic",
                            ],
                            capture_output=True,
                            text=True,
                            timeout=5,
                        )
                        if ts_result.returncode == 0:
                            for ts_line in ts_result.stdout.strip().splitlines():
                                if "=" in ts_line:
                                    _, _, ts_val = ts_line.partition("=")
                                    mono_usec = int(ts_val.strip())
                                    if mono_usec > 0:
                                        # mono_usec is ExecMainStartTimestampMonotonic (CLOCK_MONOTONIC
                                        # at service start, in microseconds). Subtract from current
                                        # monotonic time to get elapsed seconds since start.
                                        uptime_sec = mono_usec / 1_000_000
                                        uptime = _format_uptime(time.monotonic() - uptime_sec)
                    except (ValueError, OSError):
                        pass

                return ServiceStatus(
                    running=running,
                    pid=pid,
                    uptime=uptime,
                    method="systemd",
                    service_name=self.UNIT,
                )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            pass

        return ServiceStatus(running=False, method="systemd", service_name=self.UNIT)


class DirectServiceManager(ServiceManager):
    """Manage the daemon as a direct background process."""

    def __init__(self, state_dir: Path | None = None) -> None:
        self.state_dir = state_dir or DEFAULT_STATE_DIR

    def start(self, **kwargs: object) -> tuple[bool, str]:
        if is_daemon_running(self.state_dir):
            pid = find_daemon_pid(self.state_dir)
            return True, f"Daemon is already running (PID {pid})"

        # Find the hivemind executable
        exe = shutil.which("hivemind")
        if not exe:
            # Try using the current Python interpreter's entry point
            exe = shutil.which("hivemind", path=str(Path(sys.executable).parent))
        if not exe:
            return False, "Cannot find 'hivemind' executable on PATH"

        # Build the command
        cmd = [exe, "run"]

        # Pass through endpoint override flags
        endpoint_override = get_endpoint_override()
        if endpoint_override:
            cmd.extend(["--endpoint", endpoint_override])

        cmd.extend(["--state-dir", str(self.state_dir)])

        # Set up log file for stdout/stderr
        log_file = DEFAULT_LOG_FILE

        try:
            log_file.parent.mkdir(parents=True, exist_ok=True)
            log_fd = open(log_file, "a")

            proc = subprocess.Popen(
                cmd,
                stdout=log_fd,
                stderr=log_fd,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )

            # Wait briefly to check if it started successfully
            time.sleep(1.0)

            if proc.poll() is not None:
                log_fd.close()
                return False, f"Daemon exited immediately with code {proc.returncode}"

            log_fd.close()
            return True, f"Daemon started (PID {proc.pid}), logging to {log_file}"

        except OSError as e:
            return False, f"Failed to start daemon: {e}"

    def stop(self, force: bool = False) -> tuple[bool, str]:
        if not is_daemon_running(self.state_dir):
            return True, "Daemon is not running"

        pid = find_daemon_pid(self.state_dir)
        if pid is None:
            return False, "Daemon is running but PID could not be determined"

        try:
            if force:
                os.kill(pid, signal.SIGKILL)
                return True, f"Sent SIGKILL to daemon (PID {pid})"

            # Graceful shutdown with SIGTERM
            os.kill(pid, signal.SIGTERM)

            # Wait up to 10 seconds for graceful shutdown
            for _ in range(20):
                time.sleep(0.5)
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    return True, f"Daemon stopped (PID {pid})"

            # Process still running after timeout - force kill
            logger.warning(f"Daemon (PID {pid}) did not stop after 10s, sending SIGKILL")
            os.kill(pid, signal.SIGKILL)
            time.sleep(0.5)

            try:
                os.kill(pid, 0)
                return False, f"Failed to stop daemon (PID {pid}) even with SIGKILL"
            except ProcessLookupError:
                return True, f"Daemon force-killed (PID {pid})"

        except ProcessLookupError:
            return True, f"Daemon (PID {pid}) already stopped"
        except PermissionError:
            return False, f"No permission to stop daemon (PID {pid})"
        except OSError as e:
            return False, f"Failed to stop daemon: {e}"

    def restart(self, **kwargs: object) -> tuple[bool, str]:
        if is_daemon_running(self.state_dir):
            success, msg = self.stop()
            if not success:
                return False, f"Failed to stop daemon for restart: {msg}"
        return self.start(**kwargs)

    def status(self) -> ServiceStatus:
        running = is_daemon_running(self.state_dir)
        pid = find_daemon_pid(self.state_dir) if running else None
        uptime = _uptime_from_pid(pid) if running and pid else None

        return ServiceStatus(
            running=running,
            pid=pid,
            uptime=uptime,
            method="direct",
        )


def _uptime_from_pid(pid: int) -> str | None:
    """Get human-readable uptime for a process by PID using ps."""
    try:
        result = subprocess.run(
            ["ps", "-o", "etime=", "-p", str(pid)],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return _parse_ps_etime(result.stdout.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return None


def _parse_ps_etime(etime: str) -> str | None:
    """Parse ps elapsed time format into human-readable uptime.

    ps etime formats: "MM:SS", "HH:MM:SS", "D-HH:MM:SS"
    """
    etime = etime.strip()
    if not etime:
        return None

    try:
        days = 0
        if "-" in etime:
            day_part, etime = etime.split("-", 1)
            days = int(day_part)

        parts = etime.split(":")
        if len(parts) == 2:
            minutes, seconds = int(parts[0]), int(parts[1])
            total_seconds = days * 86400 + minutes * 60 + seconds
        elif len(parts) == 3:
            hours, minutes, seconds = int(parts[0]), int(parts[1]), int(parts[2])
            total_seconds = days * 86400 + hours * 3600 + minutes * 60 + seconds
        else:
            return etime  # Return as-is if unparseable

        return _format_uptime(total_seconds)
    except (ValueError, IndexError):
        return etime


def get_service_manager(state_dir: Path | None = None) -> ServiceManager:
    """Detect platform and return the appropriate service manager.

    Args:
        state_dir: State directory for DirectServiceManager. Defaults to ~/.hivemind.

    Returns:
        A ServiceManager instance for the current platform.
    """
    platform = detect_platform()

    if platform == ServicePlatform.HOMEBREW:
        return HomebrewServiceManager()
    elif platform == ServicePlatform.SYSTEMD:
        return SystemdServiceManager()
    else:
        return DirectServiceManager(state_dir=state_dir)
