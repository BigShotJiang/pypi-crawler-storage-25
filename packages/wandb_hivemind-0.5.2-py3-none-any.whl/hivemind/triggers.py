"""File-based trigger mechanism for daemon state reset signaling.

This module provides a mechanism for external tools (like resync commands)
to signal the daemon to reset state for specific agent types. Triggers are
communicated via JSON files in the triggers directory.

Trigger workflow:
1. External tool creates a trigger file (e.g., reset-cursor.trigger)
2. Daemon checks for triggers at the start of each sync cycle
3. Daemon processes each trigger by clearing sessions for that agent type
4. Daemon deletes the trigger file as acknowledgment
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hivemind.state import VALID_AGENT_TYPES

logger = logging.getLogger(__name__)


def get_trigger_directory() -> Path:
    """Get the directory for trigger files.

    Returns:
        Path to ~/.hivemind/triggers/
    """
    return Path.home() / ".hivemind" / "triggers"


def check_for_triggers() -> list[dict[str, Any]]:
    """Check for pending reset triggers.

    Scans the trigger directory for reset-*.trigger files and parses them.
    Invalid triggers (malformed JSON, missing required fields, unknown agent_type)
    are logged and skipped but not deleted (to allow debugging).

    Returns:
        List of valid trigger data dictionaries. Each dict contains:
        - agent_type: The agent type to reset (e.g., "cursor")
        - requested_at: ISO timestamp when trigger was created
        - requested_by: Identifier of what created the trigger
        - _file_path: Path object to the trigger file (for deletion after processing)
    """
    trigger_dir = get_trigger_directory()
    if not trigger_dir.exists():
        return []

    triggers: list[dict[str, Any]] = []
    for trigger_file in trigger_dir.glob("reset-*.trigger"):
        try:
            data = json.loads(trigger_file.read_text())

            # Validate required fields
            if not isinstance(data, dict):
                logger.warning(f"Invalid trigger file {trigger_file}: not a JSON object")
                continue

            agent_type = data.get("agent_type")
            if not agent_type:
                logger.warning(f"Invalid trigger file {trigger_file}: missing agent_type")
                continue

            if agent_type not in VALID_AGENT_TYPES:
                logger.warning(
                    f"Invalid trigger file {trigger_file}: unknown agent_type '{agent_type}'. "
                    f"Valid types: {sorted(VALID_AGENT_TYPES)}"
                )
                continue

            # Add file path for later deletion
            data["_file_path"] = trigger_file
            triggers.append(data)
            logger.debug(f"Found valid trigger: {trigger_file.name} for agent_type={agent_type}")

        except json.JSONDecodeError as e:
            logger.warning(f"Invalid trigger file {trigger_file}: malformed JSON: {e}")
            continue
        except OSError as e:
            logger.warning(f"Error reading trigger file {trigger_file}: {e}")
            continue

    return triggers


def create_trigger(agent_type: str, requested_by: str = "unknown") -> Path:
    """Create a reset trigger file for an agent type.

    This is primarily for testing, but can also be used by other tools
    that need to signal a state reset.

    Args:
        agent_type: The agent type to reset (must be in VALID_AGENT_TYPES)
        requested_by: Identifier for what created the trigger

    Returns:
        Path to the created trigger file

    Raises:
        ValueError: If agent_type is not valid
    """
    if agent_type not in VALID_AGENT_TYPES:
        raise ValueError(
            f"Invalid agent_type '{agent_type}'. Valid types: {sorted(VALID_AGENT_TYPES)}"
        )

    trigger_dir = get_trigger_directory()
    trigger_dir.mkdir(parents=True, exist_ok=True)

    trigger_file = trigger_dir / f"reset-{agent_type}.trigger"
    trigger_data = {
        "agent_type": agent_type,
        "requested_at": datetime.now(timezone.utc).isoformat(),
        "requested_by": requested_by,
    }
    trigger_file.write_text(json.dumps(trigger_data, indent=2))
    logger.info(f"Created trigger file: {trigger_file}")
    return trigger_file


def delete_trigger(trigger_file: Path) -> bool:
    """Delete a trigger file after processing.

    Args:
        trigger_file: Path to the trigger file to delete

    Returns:
        True if deleted successfully, False otherwise
    """
    try:
        trigger_file.unlink()
        logger.debug(f"Deleted trigger file: {trigger_file}")
        return True
    except OSError as e:
        logger.warning(f"Failed to delete trigger file {trigger_file}: {e}")
        return False
