"""Remote agent session syncing.

This module provides web session syncing functionality that integrates the
agentstream library's remote session discovery with the daemon's sync pipeline.

The core remote session discovery (credentials, API client) lives in the
agentstream library. This module only contains the daemon-specific sync logic.
"""

# Re-export from agentstream library for convenience
from agentstream.remote import (
    ClaudeCredentials,
    WebSession,
    WebSessionPoller,
    WebSessionsClient,
    has_claude_credentials,
    read_claude_credentials,
)

# Daemon-specific sync logic
from hivemind.remote.web_sync import (
    WebSessionSyncer,
    sync_web_sessions,
)

__all__ = [
    # From agentstream library
    "ClaudeCredentials",
    "read_claude_credentials",
    "has_claude_credentials",
    "WebSession",
    "WebSessionsClient",
    "WebSessionPoller",
    # Daemon-specific
    "WebSessionSyncer",
    "sync_web_sessions",
]
