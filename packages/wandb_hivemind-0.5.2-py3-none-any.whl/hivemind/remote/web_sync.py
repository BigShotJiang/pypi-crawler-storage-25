"""Web session synchronization with AgentStream backend.

This module handles syncing web/cloud sessions to the AgentStream backend
in the same way that local sessions are synced.
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any

# Import web session types from the agentstream library
from agentstream.remote import WebSession, WebSessionsClient

from hivemind import __version__ as DAEMON_VERSION
from hivemind.state import DaemonState, ServerState, SessionSyncState
from hivemind.sync import SyncOutcome, SyncResult, repo_matches
from hivemind.uploader import SessionIngestRequest, SourceEntryInput, Uploader

logger = logging.getLogger(__name__)

# Minimum entries required to upload a session on initial sync
# (same threshold as local sessions)
MIN_ENTRIES_FOR_INITIAL_UPLOAD = 2


class WebSessionSyncer:
    """Handles syncing web sessions to the AgentStream backend.

    Works similarly to SessionSyncer for local sessions, but fetches
    session data from the Anthropic API instead of local files.
    """

    def __init__(
        self,
        state: DaemonState,
        endpoint: str,
        auth_token: str,
        web_client: WebSessionsClient,
        user_id: str = "",
        device_id: str = "",
        email: str = "",
        github_user: str = "",
        credential_created_at: int | None = None,
        private_sessions: bool = False,
        org_repos: list[str] | None = None,
        private_repos: list[str] | None = None,
    ):
        """Initialize the web session syncer.

        Args:
            state: DaemonState for tracking sync progress.
            endpoint: AgentStream ingest endpoint URL.
            auth_token: Auth token for AgentStream API.
            web_client: WebSessionsClient for fetching session data.
            user_id: User ID for metadata.
            device_id: Device ID for metadata.
            email: User email for metadata.
            github_user: GitHub username for metadata.
            credential_created_at: Unix timestamp when credentials were created.
            private_sessions: When True, tag sessions as private (personal org only).
            org_repos: Repos always treated as non-private (eligible for org attribution).
            private_repos: Repos always treated as private (personal workspace only).
        """
        self.state = state
        self.endpoint = endpoint
        self.auth_token = auth_token
        self.web_client = web_client
        self.user_id = user_id
        self.device_id = device_id
        self.email = email
        self.github_user = github_user
        self.private_sessions = private_sessions
        self.org_repos = org_repos or []
        self.private_repos = private_repos or []
        self._uploader = Uploader(
            endpoint=endpoint,
            auth_token=auth_token,
            credential_created_at=credential_created_at,
        )
        self._server_state: ServerState = state.get_server_state(endpoint)

    async def sync_session(self, session: WebSession) -> SyncOutcome:
        """Sync a web session to the backend.

        Fetches events from the API and uploads them incrementally.

        Args:
            session: WebSession to sync.

        Returns:
            SyncOutcome with result status and token refresh signal.
        """
        session_id = f"web:{session.id}"  # Prefix to distinguish from local sessions

        # Get or create session sync state
        if session_id not in self._server_state.sessions:
            self._server_state.sessions[session_id] = SessionSyncState(
                file_path=f"web://{session.id}",  # Virtual path for web sessions
                last_entry_idx=-1,
                last_mtime=0,
            )

        session_state = self._server_state.sessions[session_id]

        # Fetch all events from API (pagination is handled automatically)
        try:
            all_events = await self.web_client.get_session_events(session.id)
        except Exception as e:
            logger.error(f"Failed to fetch events for web session {session.id[:16]}...: {e}")
            return SyncOutcome(SyncResult.FAILED)

        if not all_events:
            logger.debug(f"No events for web session {session.id[:16]}...")
            return SyncOutcome(SyncResult.SKIPPED)  # Not a failure, just nothing to sync

        # Filter to only new events (events after our last synced count)
        # We track by entry index since the API doesn't support pagination
        last_idx = session_state.last_entry_idx
        if last_idx >= 0:
            # We've synced some events before, only take new ones
            events = all_events[last_idx + 1 :]
        else:
            events = all_events

        if not events:
            logger.debug(f"No new events for web session {session.id[:16]}...")
            return SyncOutcome(SyncResult.SKIPPED)

        # Skip trivial sessions on initial sync
        # NOTE: We do NOT update last_entry_idx here - we only update it after
        # a successful upload. This ensures we retry trivial sessions if they
        # later get more events and the upload fails.
        is_initial_sync = last_idx < 0
        if is_initial_sync and len(all_events) < MIN_ENTRIES_FOR_INITIAL_UPLOAD:
            logger.debug(
                f"Skipping trivial web session {session.id[:16]}... (only {len(all_events)} events)"
            )
            # Only skip, do NOT update last_entry_idx - session will be retried
            # when it has enough events for a meaningful upload
            return SyncOutcome(SyncResult.SKIPPED)

        logger.info(
            f"Syncing web session {session.id[:16]}... "
            f"({len(events)} new events, total {len(all_events)})"
        )

        # Build metadata
        metadata = self._build_metadata(session)

        # Convert events to source entry format
        source_entries = []
        start_idx = last_idx + 1  # Start indexing after last synced

        # First pass: extract all known timestamps from events
        # env_manager_log events have timestamps, user/assistant do not
        event_timestamps = self._extract_event_timestamps(all_events, session)

        for i, event in enumerate(events):
            entry_index = start_idx + i
            # Use pre-computed timestamp (accounts for interpolation)
            actual_idx = start_idx + i
            timestamp_ms = event_timestamps.get(actual_idx, int(time.time() * 1000))

            # Inject timestamp into event so adapter can use it
            # (adapter only sees JSON content, not SourceEntryInput.entry_timestamp_ms)
            event_with_ts = dict(event)
            event_with_ts["_timestamp_ms"] = timestamp_ms

            source_entries.append(
                SourceEntryInput(
                    entry_index=entry_index,
                    entry_content=json.dumps(event_with_ts),
                    entry_timestamp_ms=timestamp_ms,
                )
            )

        # Build and upload request
        request = SessionIngestRequest(
            agent_session_id=session_id,
            source_format="claude_web",  # Web sessions use web-specific adapter
            metadata=metadata,
            source_entries=source_entries,
        )

        upload_result = await self._uploader.upload_session(request)

        if upload_result.success:
            # Track position by total event count - ONLY on confirmed success
            old_idx = session_state.last_entry_idx
            session_state.last_entry_idx = len(all_events) - 1
            session_state.last_mtime = time.time()
            logger.info(
                f"Web session {session.id[:16]}... synced to index {session_state.last_entry_idx} "
                f"(was {old_idx}, uploaded {len(events)} events)"
            )
            return SyncOutcome(
                SyncResult.SYNCED, needs_token_refresh=upload_result.needs_token_refresh
            )

        # Upload failed - do NOT update last_entry_idx, will retry on next cycle
        logger.warning(
            f"Web session {session.id[:16]}... upload failed, "
            f"last_entry_idx stays at {session_state.last_entry_idx}"
        )
        return SyncOutcome(SyncResult.FAILED, needs_token_refresh=upload_result.needs_token_refresh)

    def _extract_event_timestamps(self, events: list[dict], session: WebSession) -> dict[int, int]:
        """Extract timestamps for events, using last known for events without.

        The web API only provides timestamps for env_manager_log events.
        For other events, we carry forward the last known timestamp.
        This maintains event ordering while keeping the code simple.

        Note: active_duration_ms comes from the authoritative result.duration_ms
        event, not from these timestamps.

        Args:
            events: List of all events for the session.
            session: WebSession with created_at as fallback.

        Returns:
            Dict mapping event index to timestamp_ms.
        """
        timestamps: dict[int, int] = {}

        # Use session start as initial fallback
        last_known_ts = int(time.time() * 1000)
        if session.created_at:
            last_known_ts = int(session.created_at.timestamp() * 1000)

        # Single pass: use known timestamps or carry forward last known
        for i, event in enumerate(events):
            ts_ms = self._parse_event_timestamp(event)
            if ts_ms is not None:
                last_known_ts = ts_ms
            timestamps[i] = last_known_ts

        return timestamps

    def _parse_event_timestamp(self, event: dict) -> int | None:
        """Parse timestamp from an event if available.

        Args:
            event: Event dict from API.

        Returns:
            Timestamp in milliseconds, or None if no timestamp found.
        """
        # Check data.timestamp (env_manager_log events)
        if "data" in event and isinstance(event["data"], dict):
            ts_str = event["data"].get("timestamp")
            if ts_str:
                try:
                    dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                    return int(dt.timestamp() * 1000)
                except (ValueError, AttributeError):
                    pass

        # Check message._timestamp_ms (some events may have this)
        if "_timestamp_ms" in event:
            return event["_timestamp_ms"]

        return None

    def _build_metadata(self, session: WebSession) -> dict[str, Any]:
        """Build metadata dict for a web session."""
        meta: dict[str, Any] = {
            "agent_type": "claude_web",  # Use web-specific adapter/normalizer
            "agent_version": "web",  # TODO: extract from system event if available
            "daemon_version": DAEMON_VERSION,
            "git_commit": "",
            "git_repo": session.git_repo or "",
            "git_branch": session.git_branch or "",
            "cwd": session.project_path or "",
            "model": session.model or "",
            "import_time": datetime.now(timezone.utc).isoformat(),
            "session_name": session.name or "",
            "user_id": self.user_id,
            "device_id": self.device_id,
            "email": self.email,
            "github_user": self.github_user,
        }
        # Repo-level overrides take precedence over global setting.
        git_repo = meta.get("git_repo", "")
        if git_repo and repo_matches(git_repo, self.private_repos):
            meta["private"] = True
        elif git_repo and repo_matches(git_repo, self.org_repos):
            meta["private"] = False
        elif self.private_sessions:
            meta["private"] = True
        return meta


async def sync_web_sessions(
    sessions: list[WebSession],
    syncer: WebSessionSyncer,
) -> dict[str, Any]:
    """Sync multiple web sessions.

    Args:
        sessions: List of WebSession objects to sync.
        syncer: WebSessionSyncer instance.

    Returns:
        Stats dict with success/failed counts and needs_token_refresh flag.
    """
    success_count = 0
    failed_count = 0
    needs_token_refresh = False

    for session in sessions:
        try:
            outcome = await syncer.sync_session(session)
            if outcome.needs_token_refresh:
                needs_token_refresh = True
            if outcome.result == SyncResult.SYNCED:
                success_count += 1
            elif outcome.result == SyncResult.FAILED:
                failed_count += 1
            # SKIPPED counts as success (nothing to sync)
            else:
                success_count += 1
        except Exception as e:
            logger.error(f"Error syncing web session {session.id[:16]}...: {e}")
            failed_count += 1

    return {
        "total": len(sessions),
        "success": success_count,
        "failed": failed_count,
        "needs_token_refresh": needs_token_refresh,
    }
