"""Configuration management for hivemind daemon.

Provides priority-based configuration loading with the following precedence:
1. Runtime override (set via --dev/--dev-worktree flags or set_endpoint_override()) - highest priority
2. Config file (~/.hivemind/config.toml)
3. Environment variables (HIVEMIND_ENDPOINT)
4. Hardcoded defaults - lowest priority

This design allows users to override Homebrew-set environment variables
by creating a config file with their preferred settings.
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import tomli_w

# Default values
DEFAULT_ENDPOINT = "https://hivemind.wandb.tools"
DEV_ENDPOINT = "http://localhost:8080"
DEV_WORKTREE_ENDPOINT = "http://api-w{n}.hivemind.local"
QA_ENDPOINT = "https://hivemind.qa.wandb.tools"
PROD_ENDPOINT = "https://hivemind.wandb.tools"
DEFAULT_STATE_DIR = Path.home() / ".hivemind"
DEFAULT_CONFIG_PATH = DEFAULT_STATE_DIR / "config.toml"

# Module-level endpoint override (set by --dev flag or programmatically)
# When set, this takes precedence over all other configuration sources
_endpoint_override: str | None = None


def set_endpoint_override(endpoint: str | None) -> None:
    """Set a runtime endpoint override.

    When set, this takes precedence over config file, env vars, and defaults.
    Used by --dev flag to force localhost endpoint or --dev-worktree=N for OrbStack worktree endpoints.

    Args:
        endpoint: Override endpoint URL, or None to clear the override.
    """
    global _endpoint_override
    _endpoint_override = endpoint


def get_endpoint_override() -> str | None:
    """Get the current endpoint override, if any."""
    return _endpoint_override


@dataclass
class ServerConfig:
    """Server connection configuration."""

    endpoint: str = DEFAULT_ENDPOINT
    auth_method: str | None = (
        None  # Preferred auth method: ssh_signature, credential_helper, gh_cli, device_flow
    )


@dataclass
class DevConfig:
    """Development mode configuration."""

    repo: str | None = None
    debug: bool = False


@dataclass
class WebSessionsConfig:
    """Web/remote session sync configuration."""

    # Enable web session polling (default: True if Claude credentials exist)
    enabled: bool = True

    # Polling interval in seconds (default: 30 minutes)
    poll_interval: int = 1800


@dataclass
class ImportConfig:
    """Historic session import configuration."""

    # Maximum age in days for historic import (default: 90 days)
    # Set to 0 to import all sessions regardless of age
    max_age_days: int = 90


@dataclass
class SessionsConfig:
    """Session visibility configuration."""

    # When True, new sessions are always assigned to the user's personal
    # workspace instead of the GitHub org associated with the repo.
    # This makes sessions private (visible only to the author).
    private: bool = False

    # Repos always treated as non-private (eligible for org attribution).
    # Overrides global private and user-level privacy settings.
    # Each entry is "host/org/repo" or "org/repo" shorthand, matched case-insensitively.
    org_repos: list[str] = field(default_factory=list)

    # Repos always treated as private (personal workspace only).
    # Highest priority — overrides org_repos and all other settings.
    private_repos: list[str] = field(default_factory=list)


@dataclass
class HivemindConfig:
    """Root configuration object for hivemind."""

    server: ServerConfig = field(default_factory=ServerConfig)
    dev: DevConfig = field(default_factory=DevConfig)
    web_sessions: WebSessionsConfig = field(default_factory=WebSessionsConfig)
    import_: ImportConfig = field(default_factory=ImportConfig)
    sessions: SessionsConfig = field(default_factory=SessionsConfig)


def validate_dev_repo(path: str) -> tuple[bool, str]:
    """Validate that a path is a valid dev repo checkout.

    A valid dev repo must have:
    - The path exists
    - .venv/bin/python exists (virtual environment)
    - daemon/src exists (source directory)

    Args:
        path: Path to the dev repo checkout.

    Returns:
        A tuple of (is_valid, message). If invalid, message describes the issue.
    """
    repo_path = Path(path).expanduser().resolve()

    if not repo_path.exists():
        return False, f"Path does not exist: {repo_path}"

    venv_python = repo_path / ".venv" / "bin" / "python"
    if not venv_python.exists():
        return False, f"Virtual environment not found: {venv_python}"

    daemon_src = repo_path / "daemon" / "src"
    if not daemon_src.exists():
        return False, f"Source directory not found: {daemon_src}"

    return True, f"Valid dev repo: {repo_path}"


def load_config(path: Path | None = None) -> HivemindConfig:
    """Load configuration from a TOML file.

    Args:
        path: Path to the config file. Defaults to ~/.hivemind/config.toml.

    Returns:
        HivemindConfig with values from file, or defaults if file doesn't exist.
    """
    if path is None:
        path = DEFAULT_CONFIG_PATH

    if not path.exists():
        return HivemindConfig()

    with open(path, "rb") as f:
        data = tomllib.load(f)

    return _dict_to_config(data)


def _dict_to_config(data: dict[str, Any]) -> HivemindConfig:
    """Convert a dictionary (from TOML) to HivemindConfig.

    Ignores unrecognized keys for forward compatibility.
    """
    server_data = data.get("server", {})
    server = ServerConfig(
        endpoint=server_data.get("endpoint", DEFAULT_ENDPOINT),
        auth_method=server_data.get("auth_method"),
    )

    dev_data = data.get("dev", {})
    dev = DevConfig(
        repo=dev_data.get("repo"),
        debug=dev_data.get("debug", False),
    )

    web_sessions_data = data.get("web_sessions", {})
    web_sessions = WebSessionsConfig(
        enabled=web_sessions_data.get("enabled", True),
        poll_interval=web_sessions_data.get("poll_interval", 1800),
    )

    import_data = data.get("import", {})
    import_ = ImportConfig(
        max_age_days=import_data.get("max_age_days", 90),
    )

    sessions_data = data.get("sessions", {})
    # Fall back to legacy key "public_repos" for configs from older daemon versions.
    org_repos = (
        sessions_data.get("org_repos")
        if "org_repos" in sessions_data
        else sessions_data.get("public_repos", [])
    )
    sessions = SessionsConfig(
        private=sessions_data.get("private", False),
        org_repos=org_repos,
        private_repos=sessions_data.get("private_repos", []),
    )

    return HivemindConfig(
        server=server, dev=dev, web_sessions=web_sessions, import_=import_, sessions=sessions
    )


def save_config(config: HivemindConfig, path: Path | None = None) -> None:
    """Save configuration to a TOML file.

    WARNING: This overwrites the file with only known fields, dropping any
    unrecognized keys. Prefer ``update_config`` for targeted changes.

    Creates parent directories if they don't exist.

    Args:
        config: Configuration to save.
        path: Path to save to. Defaults to ~/.hivemind/config.toml.
    """
    if path is None:
        path = DEFAULT_CONFIG_PATH

    # Ensure parent directory exists
    path.parent.mkdir(parents=True, exist_ok=True)

    data = _config_to_dict(config)

    with open(path, "wb") as f:
        tomli_w.dump(data, f)


def update_config(key: str, value: Any, path: Path | None = None) -> None:
    """Update a single config value, preserving unknown keys and comments.

    Uses ``tomlkit`` for style-preserving TOML round-trips. Validates the
    key against the dataclass schema before writing.

    Args:
        key: Dotted key path (e.g., "server.auth_method").
        value: Value to set. Use ``None`` to remove the key.
        path: Path to config file. Defaults to ~/.hivemind/config.toml.

    Raises:
        KeyError: If the key path is not a valid config key.
    """
    import tomlkit

    if path is None:
        path = DEFAULT_CONFIG_PATH

    # Validate that the key is recognized
    config = load_config(path)
    set_value(key, value, config)

    # Read with tomlkit to preserve comments and formatting
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        with open(path) as f:
            doc = tomlkit.parse(f.read())
    else:
        doc = tomlkit.document()

    # Navigate to parent section, creating tables as needed.
    # tomlkit containers support dict-like operations but ty cannot infer
    # their types, so we operate through the untyped ``dict`` interface.
    parts = key.split(".")
    current: dict[str, Any] = doc  # TOMLDocument is dict-like
    for part in parts[:-1]:
        if part not in current:
            current[part] = tomlkit.table()
        current = current[part]  # type: ignore[assignment]

    if value is None:
        current.pop(parts[-1], None)
    else:
        current[parts[-1]] = value

    with open(path, "w") as f:
        f.write(tomlkit.dumps(doc))


def _config_to_dict(config: HivemindConfig) -> dict[str, Any]:
    """Convert HivemindConfig to a dictionary for TOML serialization."""
    server_dict: dict[str, Any] = {
        "endpoint": config.server.endpoint,
    }
    if config.server.auth_method:
        server_dict["auth_method"] = config.server.auth_method
    result: dict[str, Any] = {
        "server": server_dict,
    }

    # Include dev section if repo or debug is set
    if config.dev.repo is not None or config.dev.debug:
        result["dev"] = {}
        if config.dev.repo is not None:
            result["dev"]["repo"] = config.dev.repo
        if config.dev.debug:
            result["dev"]["debug"] = config.dev.debug

    # Always include web_sessions section to preserve user-set values
    result["web_sessions"] = {
        "enabled": config.web_sessions.enabled,
        "poll_interval": config.web_sessions.poll_interval,
    }

    # Include import section if non-default
    if config.import_.max_age_days != 90:
        result["import"] = {
            "max_age_days": config.import_.max_age_days,
        }

    # Include sessions section if non-default
    sessions_dict: dict[str, Any] = {}
    if config.sessions.private:
        sessions_dict["private"] = config.sessions.private
    if config.sessions.org_repos:
        sessions_dict["org_repos"] = config.sessions.org_repos
    if config.sessions.private_repos:
        sessions_dict["private_repos"] = config.sessions.private_repos
    if sessions_dict:
        result["sessions"] = sessions_dict

    return result


def get_effective_endpoint(config_path: Path | None = None) -> str:
    """Get the endpoint URL using priority chain.

    Priority (highest to lowest):
    1. Runtime override (set via set_endpoint_override() or --dev flag)
    2. Config file (if endpoint is explicitly set)
    3. HIVEMIND_ENDPOINT environment variable
    4. Default value

    Args:
        config_path: Path to config file. Defaults to ~/.hivemind/config.toml.

    Returns:
        The effective endpoint URL.
    """
    # Check runtime override first (e.g., --dev flag)
    if _endpoint_override is not None:
        return _endpoint_override

    if config_path is None:
        config_path = DEFAULT_CONFIG_PATH

    # Check if config file exists and has endpoint explicitly set
    if config_path.exists():
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
        server_data = data.get("server", {})
        if "endpoint" in server_data:
            return server_data["endpoint"]

    # Config file doesn't have endpoint, check env var
    env_endpoint = os.environ.get("HIVEMIND_ENDPOINT")
    if env_endpoint:
        return env_endpoint

    # Fall back to default
    return DEFAULT_ENDPOINT


# TOML key names that are Python keywords and need trailing underscore on the attribute
_TOML_TO_ATTR = {"import"}


def get_value(key: str, config: HivemindConfig) -> Any:
    """Get a configuration value by dotted key path.

    Args:
        key: Dotted key path (e.g., "server.endpoint").
        config: Configuration object to read from.

    Returns:
        The value at the specified path.

    Raises:
        KeyError: If the key path doesn't exist.
    """
    parts = key.split(".")
    current: Any = config

    for part in parts:
        # Map TOML key names to Python attribute names (e.g., "import" -> "import_")
        attr = f"{part}_" if part in _TOML_TO_ATTR else part
        if hasattr(current, attr):
            current = getattr(current, attr)
        else:
            raise KeyError(f"Configuration key not found: {key}")

    return current


def set_value(key: str, value: Any, config: HivemindConfig) -> None:
    """Set a configuration value by dotted key path.

    Args:
        key: Dotted key path (e.g., "server.endpoint").
        value: Value to set.
        config: Configuration object to modify.

    Raises:
        KeyError: If the key path doesn't exist.
    """
    parts = key.split(".")

    if len(parts) == 1:
        # Single key - set directly on config
        attr = f"{parts[0]}_" if parts[0] in _TOML_TO_ATTR else parts[0]
        if not hasattr(config, attr):
            raise KeyError(f"Configuration key not found: {key}")
        setattr(config, attr, value)
        return

    # Navigate to parent of target
    current: Any = config
    for part in parts[:-1]:
        attr = f"{part}_" if part in _TOML_TO_ATTR else part
        if hasattr(current, attr):
            current = getattr(current, attr)
        else:
            raise KeyError(f"Configuration key not found: {key}")

    # Set the final value
    final_key = parts[-1]
    attr = f"{final_key}_" if final_key in _TOML_TO_ATTR else final_key
    if not hasattr(current, attr):
        raise KeyError(f"Configuration key not found: {key}")
    setattr(current, attr, value)
