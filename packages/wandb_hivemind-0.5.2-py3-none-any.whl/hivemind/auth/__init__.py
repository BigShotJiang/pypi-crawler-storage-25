"""Authentication module for agentstream daemon."""

from hivemind.auth.credentials import StoredCredentials, CredentialStore
from hivemind.auth.discovery import (
    AuthDiscovery,
    SSHAuthMethod,
    TokenAuthMethod,
    DeviceFlowAuthMethod,
    Credential,
)
from hivemind.auth.ssh_sign import create_ssh_signature, SSHSignError
from hivemind.auth.manager import AuthManager, AuthError
from hivemind.auth.device_flow import DeviceFlowAuth

__all__ = [
    "StoredCredentials",
    "CredentialStore",
    "AuthDiscovery",
    "SSHAuthMethod",
    "TokenAuthMethod",
    "DeviceFlowAuthMethod",
    "Credential",
    "create_ssh_signature",
    "SSHSignError",
    "AuthManager",
    "AuthError",
    "DeviceFlowAuth",
]
