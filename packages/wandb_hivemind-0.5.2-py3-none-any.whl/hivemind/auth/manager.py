"""Authentication manager for Hivemind daemon."""

from __future__ import annotations

import logging
import subprocess
import time
import uuid

import httpx

from hivemind.auth.credentials import StoredCredentials, CredentialStore
from hivemind.auth.discovery import (
    AuthDiscovery,
    SSHAuthMethod,
    TokenAuthMethod,
    DeviceFlowAuthMethod,
)
from hivemind.auth.hardware import HardwareInfo, collect_hardware_info
from hivemind.auth.ssh_sign import create_ssh_signature

logger = logging.getLogger(__name__)


def _get_git_email() -> str | None:
    """Get the user's email from git config."""
    try:
        result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return None


class AuthError(Exception):
    """Authentication error."""

    pass


class PermanentAuthError(AuthError):
    """Auth error that should not be retried (e.g., org membership restriction).

    Used when the server returns 403 indicating the user is not authorized
    to use the service at all, not just a temporary auth failure.
    """

    pass


class AuthManager:
    """Manages daemon authentication lifecycle."""

    def __init__(
        self,
        endpoint: str,
        credential_store: CredentialStore | None = None,
    ):
        self.endpoint = endpoint.rstrip("/")
        self.store = credential_store or CredentialStore()
        self.discovery = AuthDiscovery()
        self._device_id: str | None = None
        self._hardware_info: HardwareInfo | None = None

    @property
    def device_id(self) -> str:
        """Get or create persistent device ID."""
        if self._device_id:
            return self._device_id

        device_file = self.store.config_dir / "device_id"

        if device_file.exists():
            self._device_id = device_file.read_text().strip()
        else:
            self._device_id = str(uuid.uuid4())
            self.store._ensure_config_dir()
            device_file.write_text(self._device_id)
            device_file.chmod(0o600)

        return self._device_id

    @property
    def hardware_info(self) -> HardwareInfo:
        """Get cached hardware information."""
        if self._hardware_info is None:
            self._hardware_info = collect_hardware_info()
        return self._hardware_info

    async def get_token(
        self,
        force_method: str | None = None,
        force_refresh: bool = False,
        preferred_method: str | None = None,
    ) -> str:
        """Get a valid authentication token, refreshing if needed.

        Args:
            force_method: If set, force a specific auth method instead of auto-detect.
                         Values: "ssh", "device", "credential", "gh"
            force_refresh: If True, force re-authentication even if token is still valid.
                          Used when server signals token needs refresh (secret rotation).
            preferred_method: If set, try this method first when auto-detecting.
                            Used to skip slower methods that previously failed.
        """
        # Try loading existing credentials for this endpoint (skip if forcing)
        if not force_method and not force_refresh:
            creds = self.store.load(self.endpoint)
            if creds and not self.store.is_expired(creds):
                return creds.token

            if creds:
                logger.info(f"Token expired for {creds.github_user}, re-authenticating...")
                # Use previously successful method as preference for re-auth
                if not preferred_method:
                    preferred_method = creds.auth_method
        else:
            creds = self.store.load(self.endpoint) if force_refresh else None
            if force_refresh and creds:
                logger.info(f"Force refreshing token for {creds.github_user}...")
                if not preferred_method:
                    preferred_method = creds.auth_method

        new_creds = await self._authenticate(force_method, preferred_method=preferred_method)
        self.store.save(new_creds, self.endpoint)

        return new_creds.token

    async def _authenticate(
        self, force_method: str | None = None, preferred_method: str | None = None
    ) -> StoredCredentials:
        """Perform authentication using discovered or forced method.

        Args:
            force_method: If set, use this specific method instead of auto-detect.
                         Values: "ssh", "device", "credential", "gh"
            preferred_method: If set, try this method first when auto-detecting.
        """
        if force_method:
            return await self._authenticate_forced(force_method)

        auth_methods = self.discovery.discover_all(preferred=preferred_method)
        last_error: AuthError | None = None

        for auth_method in auth_methods:
            try:
                if isinstance(auth_method, SSHAuthMethod):
                    return await self._auth_via_ssh(auth_method)
                elif isinstance(auth_method, TokenAuthMethod):
                    return await self._auth_via_token_exchange(auth_method)
                elif isinstance(auth_method, DeviceFlowAuthMethod):
                    return await self._auth_via_device_flow()
            except PermanentAuthError:
                raise
            except AuthError as e:
                logger.info(f"Auth method failed, trying next: {e}")
                last_error = e
                continue

        if last_error:
            raise last_error
        raise AuthError("No authentication method available")

    async def _authenticate_forced(self, method: str) -> StoredCredentials:
        """Authenticate using a specific forced method."""
        if method == "ssh":
            ssh_method = self._try_ssh_method()
            if not ssh_method:
                raise AuthError("SSH authentication not available (no SSH key or GitHub user)")
            return await self._auth_via_ssh(ssh_method)

        elif method == "device":
            return await self._auth_via_device_flow()

        elif method == "credential":
            token_method = self._try_credential_method()
            if not token_method:
                raise AuthError("Git credential helper not available or no stored credentials")
            return await self._auth_via_token_exchange(token_method)

        elif method == "gh":
            token_method = self._try_gh_method()
            if not token_method:
                raise AuthError("GitHub CLI (gh) not available or not authenticated")
            return await self._auth_via_token_exchange(token_method)

        else:
            raise AuthError(f"Unknown authentication method: {method}")

    def _try_ssh_method(self) -> SSHAuthMethod | None:
        """Try to get SSH auth method."""
        if ssh_key := self.discovery._find_ssh_key():
            if github_user := self.discovery._get_username_via_ssh():
                return SSHAuthMethod(key_path=ssh_key, github_user=github_user)
        return None

    def _try_credential_method(self) -> TokenAuthMethod | None:
        """Try to get git credential helper method."""
        if cred := self.discovery._get_git_credential():
            if github_user := self.discovery._get_username_via_api(cred.password):
                return TokenAuthMethod(
                    token=cred.password, github_user=github_user, source="credential_helper"
                )
        return None

    def _try_gh_method(self) -> TokenAuthMethod | None:
        """Try to get gh CLI method."""
        if gh_token := self.discovery._get_gh_token():
            if github_user := self.discovery._get_username_via_api(gh_token):
                return TokenAuthMethod(token=gh_token, github_user=github_user, source="gh_cli")
        return None

    def _get_github_token_locally(self) -> str | None:
        """Try to get a GitHub token from local sources.

        Probes gh CLI and git credential helper for a token. The token is
        included in the signed SSH payload so the server can query the GitHub
        API for org memberships server-side. This is more secure than sending
        pre-fetched org lists, which a manipulated client could spoof.

        Returns:
            GitHub token string, or None if no token available.
        """
        token = self.discovery._get_gh_token()
        if not token:
            cred = self.discovery._get_git_credential()
            if cred:
                token = cred.password

        if token:
            logger.debug("Found local GitHub token for SSH auth enrichment")

        return token

    async def _auth_via_ssh(self, method: SSHAuthMethod) -> StoredCredentials:
        """Authenticate using SSH signature."""
        git_email = _get_git_email()
        hw = self.hardware_info

        # Include a GitHub token in the signed payload (if available) so the
        # server can query the GitHub API for org memberships directly. This
        # replaces the previous approach of sending pre-fetched org lists,
        # which was vulnerable to spoofing by a manipulated client.
        github_token = self._get_github_token_locally()

        sig_data = create_ssh_signature(
            key_path=method.key_path,
            github_user=method.github_user,
            device_id=self.device_id,
            git_email=git_email,
            github_token=github_token,
        )

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.endpoint}/v1/auth/ssh",
                json={
                    "github_user": method.github_user,
                    "payload": sig_data["payload"],
                    "signature": sig_data["signature"],
                    "git_email": git_email,
                    **hw.to_dict(),
                },
                timeout=30,
            )

        if response.status_code == 403:
            # Permanent auth failure - user not authorized (e.g., org restriction)
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise PermanentAuthError(f"Access denied: {detail}")

        if response.status_code != 200:
            raise AuthError(f"SSH auth failed: {response.text}")

        data = response.json()

        return StoredCredentials(
            token=data["token"],
            user_id=data["user_id"],
            github_user=data["github_user"],
            email=data["email"],
            expires_at=data["expires_at"],
            auth_method="ssh_signature",
            device_id=self.device_id,
            created_at=int(time.time()),
        )

    async def _auth_via_token_exchange(self, method: TokenAuthMethod) -> StoredCredentials:
        """Authenticate by exchanging GitHub token."""
        git_email = _get_git_email()
        hw = self.hardware_info
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.endpoint}/v1/auth/exchange",
                json={
                    "github_token": method.token,
                    "auth_method": method.source,
                    "device_id": self.device_id,
                    "git_email": git_email,
                    **hw.to_dict(),
                },
                timeout=30,
            )

        if response.status_code == 403:
            # Permanent auth failure - user not authorized (e.g., org restriction)
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise PermanentAuthError(f"Access denied: {detail}")

        if response.status_code != 200:
            raise AuthError(f"Token exchange failed: {response.text}")

        data = response.json()

        return StoredCredentials(
            token=data["token"],
            user_id=data["user_id"],
            github_user=data["github_user"],
            email=data["email"],
            expires_at=data["expires_at"],
            auth_method=method.source,
            device_id=self.device_id,
            created_at=int(time.time()),
        )

    async def _auth_via_device_flow(self) -> StoredCredentials:
        """Authenticate using OAuth device flow."""
        # Import here to avoid circular imports
        from hivemind.auth.device_flow import DeviceFlowAuth

        device_flow = DeviceFlowAuth(endpoint=self.endpoint)
        method = await device_flow.authenticate()

        return await self._auth_via_token_exchange(method)

    def get_auth_header(self, token: str) -> dict[str, str]:
        """Get Authorization header for requests."""
        return {"Authorization": f"Bearer {token}"}

    async def whoami(self) -> dict | None:
        """Return current authenticated user info for this endpoint."""
        creds = self.store.load(self.endpoint)
        if not creds:
            return None

        return {
            "user_id": creds.user_id,
            "github_user": creds.github_user,
            "email": creds.email,
            "auth_method": creds.auth_method,
            "expires_at": creds.expires_at,
            "expired": self.store.is_expired(creds, buffer_seconds=0),
            "endpoint": self.endpoint,
        }

    def logout(self) -> None:
        """Clear stored credentials for this endpoint."""
        self.store.clear(self.endpoint)
        logger.info(f"Logged out from {self.endpoint}, credentials cleared")
