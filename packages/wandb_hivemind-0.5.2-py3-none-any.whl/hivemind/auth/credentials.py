"""Secure credential storage for Hivemind daemon."""

from __future__ import annotations

import json
import logging
import stat
import time
from pathlib import Path
from urllib.parse import urlparse

from pydantic import BaseModel, ValidationError

logger = logging.getLogger(__name__)

# Current credentials file format version
CREDENTIALS_VERSION = 2


class StoredCredentials(BaseModel):
    """Persisted authentication credentials."""

    token: str
    user_id: str
    github_user: str
    email: str
    expires_at: int  # Unix timestamp
    auth_method: str  # ssh_signature, credential_helper, gh_cli, device_flow
    device_id: str
    created_at: int


def _normalize_endpoint(endpoint: str) -> str:
    """Normalize endpoint URL for consistent key usage.

    Removes trailing slashes and path components, keeping only scheme://host:port.
    Falls back to the original endpoint (sans trailing slashes) if it cannot
    be parsed into a scheme and netloc.
    """
    # Normalize basic whitespace first
    endpoint = endpoint.strip()
    if not endpoint:
        # Empty endpoint; nothing to normalize
        return ""

    parsed = urlparse(endpoint)

    # If parsing did not produce a usable scheme and netloc, avoid constructing
    # malformed values like "://". Fall back to the original endpoint.
    if not parsed.scheme or not parsed.netloc:
        logger.warning("Unable to normalize endpoint %r: missing scheme or netloc", endpoint)
        return endpoint.rstrip("/")
    # Reconstruct with just scheme and netloc (host:port)
    normalized = f"{parsed.scheme}://{parsed.netloc}"
    return normalized.rstrip("/")


class CredentialStore:
    """Secure local storage for Hivemind credentials.

    Credentials are stored per-server to support switching between
    different backends (e.g., localhost vs production) without
    credential conflicts.

    File format (v2):
    {
        "version": 2,
        "servers": {
            "https://hivemind.wandb.tools": {
                "token": "...",
                "user_id": "...",
                ...
            },
            "http://localhost:8080": {
                ...
            }
        }
    }

    Legacy format (v1, auto-migrated):
    {
        "token": "...",
        "user_id": "...",
        ...
    }
    """

    def __init__(self, config_dir: Path | None = None):
        self.config_dir = config_dir or Path.home() / ".hivemind"
        self.creds_file = self.config_dir / "credentials.json"
        self._cache: dict | None = None

    def _ensure_config_dir(self) -> None:
        """Create config directory with secure permissions."""
        if not self.config_dir.exists():
            self.config_dir.mkdir(mode=0o700, parents=True)
        else:
            # Check if permissions need fixing (only chmod if necessary)
            # This avoids issues on macOS where extended attributes can
            # prevent chmod even when you own the directory
            current_mode = self.config_dir.stat().st_mode & 0o777
            if current_mode != 0o700:
                try:
                    self.config_dir.chmod(0o700)
                except PermissionError:
                    # On macOS with com.apple.provenance or other extended
                    # attributes, chmod may fail even for owned directories.
                    # Log and continue if permissions are at least restrictive.
                    if current_mode & (stat.S_IRWXG | stat.S_IRWXO):
                        logger.warning(
                            f"Cannot fix permissions on {self.config_dir} "
                            f"(mode {oct(current_mode)}). Directory may be insecure."
                        )
                    else:
                        logger.debug(
                            f"Cannot chmod {self.config_dir} but permissions "
                            f"are acceptably restrictive ({oct(current_mode)})"
                        )

    def _reset_file(self, reason: str) -> dict:
        """Delete the credentials file and return an empty structure.

        This forces re-authentication on the next login attempt.
        """
        logger.warning(f"Resetting credentials file ({reason}), re-authentication required")
        try:
            self.creds_file.unlink(missing_ok=True)
        except OSError as e:
            logger.warning(f"Could not delete credentials file: {e}")
        self._cache = None
        return {"version": CREDENTIALS_VERSION, "servers": {}}

    def _read_file(self) -> dict:
        """Read and parse credentials file, handling migration."""
        if not self.creds_file.exists():
            return {"version": CREDENTIALS_VERSION, "servers": {}}

        # Check file permissions
        try:
            file_stat = self.creds_file.stat()
            if file_stat.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
                try:
                    self.creds_file.chmod(0o600)
                    logger.info(f"Fixed insecure permissions on {self.creds_file}")
                except PermissionError:
                    logger.warning(
                        f"Credentials file {self.creds_file} has insecure permissions "
                        f"({oct(file_stat.st_mode & 0o777)}) but cannot be fixed."
                    )
        except OSError:
            return self._reset_file("cannot stat file")

        try:
            with open(self.creds_file) as f:
                data = json.load(f)
        except (json.JSONDecodeError, ValueError, OSError) as e:
            return self._reset_file(f"cannot parse: {e}")

        if not isinstance(data, dict):
            return self._reset_file("file content is not a JSON object")

        # Check if migration needed (no version = legacy v1 format)
        if "version" not in data:
            logger.info("Migrating credentials from v1 to v2 format")
            # Legacy format has creds at top level
            # Store as __pending_migration__ until we know the endpoint
            return {
                "version": CREDENTIALS_VERSION,
                "servers": {},
                "__pending_migration__": data,
            }

        # Validate v2 format structure - must have "servers" dict
        if not isinstance(data.get("servers"), dict):
            return self._reset_file("invalid v2 structure (missing servers)")

        return data

    def _write_file(self, data: dict) -> None:
        """Write credentials file securely."""
        self._ensure_config_dir()
        temp_file = self.creds_file.with_suffix(".tmp")
        try:
            with open(temp_file, "w") as f:
                json.dump(data, f, indent=2)
            temp_file.chmod(0o600)
            temp_file.rename(self.creds_file)
            self._cache = data
        except Exception:
            temp_file.unlink(missing_ok=True)
            raise

    def save(self, creds: StoredCredentials, endpoint: str) -> None:
        """Save credentials for a specific server endpoint."""
        key = _normalize_endpoint(endpoint)
        data = self._read_file()

        # Clear pending migration if we're saving for any endpoint
        data.pop("__pending_migration__", None)

        data["servers"][key] = creds.model_dump()
        self._write_file(data)
        logger.debug(f"Saved credentials for {key}")

    def load(self, endpoint: str) -> StoredCredentials | None:
        """Load credentials for a specific server endpoint.

        If legacy credentials exist (from v1 format) and no credentials
        exist for this endpoint, the legacy credentials are migrated
        to this endpoint.
        """
        key = _normalize_endpoint(endpoint)
        data = self._read_file()

        # Check for existing credentials for this endpoint
        if key in data.get("servers", {}):
            try:
                return StoredCredentials(**data["servers"][key])
            except (ValidationError, ValueError, TypeError):
                self._reset_file(f"corrupted credentials for {key}")
                return None

        # Check for pending migration from v1 format
        pending = data.get("__pending_migration__")
        if pending:
            logger.info(f"Migrating legacy credentials to endpoint: {key}")
            try:
                creds = StoredCredentials(**pending)
                # Save migrated credentials to this endpoint
                data["servers"][key] = pending
                data.pop("__pending_migration__")
                self._write_file(data)
                return creds
            except (ValidationError, ValueError, TypeError):
                self._reset_file("corrupted legacy credentials")
                return None

        return None

    def clear(self, endpoint: str | None = None) -> None:
        """Remove stored credentials.

        Args:
            endpoint: If provided, clear only credentials for this endpoint.
                     If None, clear all credentials.
        """
        if endpoint is None:
            self.creds_file.unlink(missing_ok=True)
            self._cache = None
        else:
            key = _normalize_endpoint(endpoint)
            data = self._read_file()
            if key in data.get("servers", {}):
                del data["servers"][key]
                self._write_file(data)
                logger.debug(f"Cleared credentials for {key}")

    def is_expired(self, creds: StoredCredentials, buffer_seconds: int = 3600) -> bool:
        """Check if credentials are expired or expiring soon."""
        return time.time() >= (creds.expires_at - buffer_seconds)

    def list_endpoints(self) -> list[str]:
        """List all endpoints with stored credentials."""
        data = self._read_file()
        return list(data.get("servers", {}).keys())
