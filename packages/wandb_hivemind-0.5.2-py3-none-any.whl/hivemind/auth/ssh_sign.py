"""SSH signature creation for AgentStream daemon."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
from pathlib import Path


class SSHSignError(Exception):
    """Error during SSH signing."""

    pass


def create_ssh_signature(
    key_path: Path,
    github_user: str,
    device_id: str,
    git_email: str | None = None,
    github_token: str | None = None,
) -> dict:
    """Create a signed authentication payload.

    Args:
        key_path: Path to SSH private key
        github_user: GitHub username
        device_id: Device identifier
        git_email: Email from git config (preferred over GitHub noreply)
        github_token: Optional GitHub token (from gh CLI or credential helper).
                      Included in the signed payload so the server can query
                      the GitHub API for org memberships server-side. This is
                      more secure than sending pre-fetched org lists, which
                      a manipulated client could spoof.

    Returns:
        Dict with 'payload' and 'signature' keys
    """
    # Payload includes timestamp to prevent replay attacks
    payload = {
        "github_user": github_user,
        "device_id": device_id,
        "timestamp": int(time.time()),
        "nonce": hashlib.sha256(os.urandom(32)).hexdigest()[:16],
    }
    if git_email:
        payload["git_email"] = git_email
    if github_token:
        payload["github_token"] = github_token
    payload_bytes = json.dumps(payload, sort_keys=True).encode()

    # Sign using ssh-keygen -Y sign (OpenSSH 8.0+)
    try:
        result = subprocess.run(
            [
                "ssh-keygen",
                "-Y",
                "sign",
                "-f",
                str(key_path),
                "-n",
                "agentstream",
            ],
            input=payload_bytes,
            capture_output=True,
            timeout=30,
        )

        if result.returncode != 0:
            raise SSHSignError(f"SSH signing failed: {result.stderr.decode()}")

        signature = result.stdout.decode()

    except subprocess.TimeoutExpired:
        raise SSHSignError("SSH signing timed out")
    except FileNotFoundError:
        raise SSHSignError("ssh-keygen not found")

    return {
        "payload": payload,
        "signature": signature,
    }
