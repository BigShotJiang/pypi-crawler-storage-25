"""Credential discovery for AgentStream daemon."""

from __future__ import annotations

import logging
import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

import httpx

logger = logging.getLogger(__name__)


@dataclass
class SSHAuthMethod:
    """Authentication via SSH key signing."""

    key_path: Path
    github_user: str


@dataclass
class TokenAuthMethod:
    """Authentication via token exchange."""

    token: str
    github_user: str
    source: str  # credential_helper, gh_cli, device_flow


@dataclass
class DeviceFlowAuthMethod:
    """Authentication via OAuth device flow."""

    pass


@dataclass
class Credential:
    """Git credential helper result."""

    username: str
    password: str


class AuthDiscovery:
    """Discover available authentication methods."""

    def __init__(self, ssh_dir: Path | None = None):
        self.ssh_dir = ssh_dir or Path.home() / ".ssh"

    def discover(self) -> SSHAuthMethod | TokenAuthMethod | DeviceFlowAuthMethod:
        """Discover the best available authentication method.

        Priority:
        1. SSH key + GitHub username via ssh -T
        2. Git credential helper
        3. gh CLI token
        4. Device flow (fallback)
        """
        methods = self.discover_all()
        return methods[0]

    def discover_all(
        self, preferred: str | None = None
    ) -> list[SSHAuthMethod | TokenAuthMethod | DeviceFlowAuthMethod]:
        """Discover all available authentication methods in priority order.

        Returns a list of methods to try. Device flow is always included as a
        fallback option, but the exact order may change if a preferred method
        is specified.

        Args:
            preferred: Preferred auth method to try first. Maps stored auth_method
                      values to discovery types: "ssh_signature" -> SSH,
                      "credential_helper" -> credential, "gh_cli" -> gh CLI,
                      "device" / "device_flow" -> device flow.

        Priority (default, before applying any preference reordering):
        1. SSH key + GitHub username via ssh -T
        2. Git credential helper
        3. gh CLI token
        4. Device flow (fallback)
        """
        methods: list[SSHAuthMethod | TokenAuthMethod | DeviceFlowAuthMethod] = []

        # 1. Check for SSH key + GitHub username
        if ssh_key := self._find_ssh_key():
            if github_user := self._get_username_via_ssh():
                logger.info(f"Found SSH key: {ssh_key}, GitHub user: {github_user}")
                methods.append(SSHAuthMethod(key_path=ssh_key, github_user=github_user))

        # 2. Check git credential helper (preferred over gh)
        if cred := self._get_git_credential():
            if github_user := self._get_username_via_api(cred.password):
                logger.info(f"Found git credential for: {github_user}")
                methods.append(
                    TokenAuthMethod(
                        token=cred.password, github_user=github_user, source="credential_helper"
                    )
                )

        # 3. Check gh CLI
        if gh_token := self._get_gh_token():
            if github_user := self._get_username_via_api(gh_token):
                logger.info(f"Found gh CLI token for: {github_user}")
                methods.append(
                    TokenAuthMethod(token=gh_token, github_user=github_user, source="gh_cli")
                )

        # 4. Always include device flow as fallback
        methods.append(DeviceFlowAuthMethod())

        # Reorder if a preferred method is specified
        if preferred:
            methods = self._reorder_by_preference(methods, preferred)

        return methods

    @staticmethod
    def _reorder_by_preference(
        methods: list[SSHAuthMethod | TokenAuthMethod | DeviceFlowAuthMethod],
        preferred: str,
    ) -> list[SSHAuthMethod | TokenAuthMethod | DeviceFlowAuthMethod]:
        """Move the preferred method to the front of the list.

        Args:
            methods: List of discovered auth methods.
            preferred: Preferred method identifier. Accepts both config-style
                      values (ssh, credential, gh, device) and stored auth_method
                      values (ssh_signature, credential_helper, gh_cli).
        """
        # Map stored auth_method values and config values to match criteria
        preference_map: dict[str, type | str] = {
            "ssh": SSHAuthMethod,
            "ssh_signature": SSHAuthMethod,
            "credential": "credential_helper",
            "credential_helper": "credential_helper",
            "gh": "gh_cli",
            "gh_cli": "gh_cli",
            "device": DeviceFlowAuthMethod,
            "device_flow": DeviceFlowAuthMethod,
        }

        match = preference_map.get(preferred)
        if not match:
            return methods

        preferred_methods = []
        rest = []
        for m in methods:
            if isinstance(match, type) and isinstance(m, match):
                preferred_methods.append(m)
            elif isinstance(match, str) and isinstance(m, TokenAuthMethod) and m.source == match:
                preferred_methods.append(m)
            else:
                rest.append(m)

        return preferred_methods + rest

    def _find_ssh_key(self) -> Path | None:
        """Find a usable SSH private key."""
        candidates = ["id_ed25519", "id_rsa", "id_ecdsa"]

        for name in candidates:
            key_path = self.ssh_dir / name
            pub_path = self.ssh_dir / f"{name}.pub"
            if key_path.exists() and pub_path.exists():
                return key_path

        return None

    def _get_username_via_ssh(self) -> str | None:
        """Get GitHub username by SSH'ing to github.com."""
        try:
            result = subprocess.run(
                [
                    "ssh",
                    "-T",
                    "-o",
                    "StrictHostKeyChecking=accept-new",
                    "-o",
                    "BatchMode=yes",
                    "git@github.com",
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = result.stderr or result.stdout
            match = re.search(r"Hi ([^!]+)!", output)
            if match:
                return match.group(1)
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.debug(f"SSH username check failed: {e}")
        return None

    def _get_git_credential(self) -> Credential | None:
        """Query git credential helper for GitHub PAT."""
        try:
            result = subprocess.run(
                ["git", "credential", "fill"],
                input="protocol=https\nhost=github.com\n",
                capture_output=True,
                text=True,
                timeout=5,
                env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
            )
            if result.returncode == 0:
                creds = dict(
                    line.split("=", 1) for line in result.stdout.strip().split("\n") if "=" in line
                )
                if creds.get("password"):
                    return Credential(
                        username=creds.get("username", ""), password=creds["password"]
                    )
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.debug(f"Git credential check failed: {e}")
        return None

    def _get_gh_token(self) -> str | None:
        """Get token from gh CLI if authenticated."""
        try:
            result = subprocess.run(
                ["gh", "auth", "token"], capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.debug(f"gh CLI check failed: {e}")
        return None

    def _get_username_via_api(self, token: str) -> str | None:
        """Get GitHub username by calling API with token."""
        try:
            response = httpx.get(
                "https://api.github.com/user",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10,
            )
            if response.status_code == 200:
                return response.json().get("login")
        except httpx.RequestError as e:
            logger.debug(f"GitHub API check failed: {e}")
        return None
