"""Logging configuration for hivemind daemon.

Provides syslog integration with fallback to file-based logging.
"""

from __future__ import annotations

import logging
import logging.handlers
import os
import platform
import sys
from pathlib import Path

# Daemon identifier for syslog
DAEMON_NAME = "hivemind"


def get_default_log_path() -> Path:
    """Get the platform-appropriate default log file path.

    Priority:
    1. HIVEMIND_LOG_FILE environment variable (already works for Homebrew)
    2. Platform-specific default:
       - macOS: ~/Library/Logs/hivemind/hivemind.log
       - Linux: ~/.local/state/hivemind/hivemind.log (XDG_STATE_HOME)
       - Fallback: ~/.hivemind/hivemind.log
    """
    env_path = os.environ.get("HIVEMIND_LOG_FILE")
    if env_path:
        return Path(env_path)

    system = platform.system().lower()
    if system == "darwin":
        return Path.home() / "Library" / "Logs" / "hivemind" / "hivemind.log"
    elif system == "linux":
        xdg_state = os.environ.get("XDG_STATE_HOME", str(Path.home() / ".local" / "state"))
        return Path(xdg_state) / "hivemind" / "hivemind.log"
    else:
        return Path.home() / ".hivemind" / "hivemind.log"


# For backward compatibility - computed on first access
DEFAULT_LOG_FILE = get_default_log_path()
DEFAULT_ERR_FILE = Path("/tmp/hivemind.err")


def _get_syslog_address() -> str | tuple[str, int] | None:
    """Get the appropriate syslog address for the current platform.

    Returns:
        Syslog socket path (str), (host, port) tuple, or None if unavailable.
    """
    system = platform.system().lower()

    if system == "darwin":
        # macOS unified logging doesn't reliably show SysLogHandler messages
        # from Python, so we use file-based logging instead
        return None
    elif system == "linux":
        # Linux typically uses /dev/log
        for path in ["/dev/log", "/var/run/syslog"]:
            if os.path.exists(path):
                return path

    return None


def _create_syslog_handler() -> logging.Handler | None:
    """Create a syslog handler if available.

    Returns:
        SysLogHandler or None if syslog is not available.
    """
    address = _get_syslog_address()
    if not address:
        return None

    try:
        handler = logging.handlers.SysLogHandler(
            address=address,
            facility=logging.handlers.SysLogHandler.LOG_DAEMON,
        )
        # Format with daemon name for syslog
        handler.setFormatter(logging.Formatter(f"{DAEMON_NAME}: %(levelname)s %(message)s"))
        return handler
    except (OSError, ConnectionError) as e:
        # Syslog socket exists but we can't connect
        print(f"Warning: Could not connect to syslog: {e}", file=sys.stderr)
        return None


def _create_file_handler(log_file: Path) -> logging.Handler:
    """Create a file handler with rotation.

    Args:
        log_file: Path to the log file.

    Returns:
        RotatingFileHandler configured for the log file.
    """
    # Ensure parent directory exists
    log_file.parent.mkdir(parents=True, exist_ok=True)

    handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=3,
    )
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    return handler


def configure_logging(
    level: int = logging.INFO,
    log_file: Path | None = None,
    force_file: bool = False,
) -> str:
    """Configure logging for the daemon.

    Attempts to use syslog first, falling back to file-based logging.

    Args:
        level: Logging level (default: INFO).
        log_file: Path to log file for fallback (default: /tmp/hivemind.log).
        force_file: If True, skip syslog and use file logging directly.

    Returns:
        String indicating the logging destination ("syslog" or file path).
    """
    log_file = log_file or DEFAULT_LOG_FILE
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Remove any existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Try syslog first (unless forced to use file)
    if not force_file:
        syslog_handler = _create_syslog_handler()
        if syslog_handler:
            root_logger.addHandler(syslog_handler)
            # Also add a minimal console handler for immediate feedback
            console = logging.StreamHandler(sys.stderr)
            console.setLevel(logging.WARNING)  # Only warnings and above to console
            console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
            root_logger.addHandler(console)
            return "syslog"

    # Fall back to file logging
    file_handler = _create_file_handler(log_file)
    root_logger.addHandler(file_handler)

    # Console handler for warnings and errors only (avoid noise in foreground)
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.WARNING)
    console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    root_logger.addHandler(console)

    return str(log_file)


def get_log_source() -> str:
    """Get a description of where logs are being written.

    Returns:
        Human-readable description of log destination.
    """
    address = _get_syslog_address()
    if address:
        return f"syslog ({address})"
    return str(get_default_log_path())
