"""AgentStream Daemon - Sync agentic coding sessions to AgentStream Enterprise."""

from importlib.metadata import PackageNotFoundError, version as get_package_version

try:
    __version__ = get_package_version("wandb-hivemind")
except PackageNotFoundError:
    try:
        __version__ = get_package_version("hivemind")
    except PackageNotFoundError:
        __version__ = "0.0.0"  # Fallback for development
