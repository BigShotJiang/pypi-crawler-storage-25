"""Command-line interface for hivemind daemon."""

from __future__ import annotations

import asyncio
import difflib
import getpass
import json
import logging
import os
import platform
import signal
import socket
import subprocess
import sys
import tempfile
import textwrap
import time
from collections import OrderedDict, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import click
import httpx

# Import remote modules from the agentstream library
from agentstream.git_utils import normalize_git_url, resolve_git_repo
from agentstream.remote import (
    WebSessionPoller,
    WebSessionsClient,
    has_claude_credentials,
)

from hivemind import __version__
from hivemind.auth.credentials import StoredCredentials
from hivemind.auth.hardware import collect_hardware_info
from hivemind.auth.manager import AuthError, AuthManager, PermanentAuthError
from hivemind.config import (
    DEFAULT_CONFIG_PATH,
    DEV_ENDPOINT,
    DEV_WORKTREE_ENDPOINT,
    PROD_ENDPOINT,
    QA_ENDPOINT,
    get_effective_endpoint,
    get_endpoint_override,
    get_value,
    load_config,
    set_endpoint_override,
    update_config,
    validate_dev_repo,
)
from hivemind.logging_config import (
    DEFAULT_LOG_FILE,
    configure_logging,
    get_default_log_path,
)

# Local web sync module (uses library's client)
from hivemind.remote.web_sync import WebSessionSyncer, sync_web_sessions
from hivemind.session_importer import (
    build_metadata_for_file,
    discover_all_sessions,
    extract_session_metadata,
    read_source_entries,
)
from hivemind.state import (
    VALID_AGENT_TYPES,
    DaemonState,
    _normalize_endpoint,
    acquire_lock,
    clear_sessions_by_agent_type,
    find_daemon_pid,
    is_daemon_running,
    load_state,
    locked_state_update,
    save_state,
)
from hivemind.sync import (
    SessionSyncer,
    SyncResult,
    build_composer_workspace_map,
    get_recent_cursor_composer_ids,
    repo_matches,
)
from hivemind.triggers import create_trigger
from hivemind.uploader import SessionIngestRequest, SourceEntryInput, Uploader
from hivemind.watcher import (
    HotSessionTracker,
    SessionWatcher,
    get_watch_paths,
)

# Default paths
DEFAULT_STATE_DIR = Path.home() / ".hivemind"
DEFAULT_STATE_FILE = DEFAULT_STATE_DIR / "state.json"
DEFAULT_LOCK_FILE = DEFAULT_STATE_DIR / "daemon.lock"

# Command organization for --help output
COMMAND_SECTIONS = OrderedDict(
    {
        "Daemon": [
            "start",
            "stop",
            "restart",
            "status",
            "logs",
            "doctor",
            "install-service",
            "run",
        ],
        "Auth": ["login", "logout", "whoami"],
        "Sessions": ["import", "transcript", "search", "fork", "insights", "export"],
        "Config": ["config"],
    }
)

DEV_COMMANDS = {"hup", "resync", "web-sessions", "api", "dump"}

PLATFORM_COMMANDS = {"install-service": "linux"}


class HivemindGroup(click.Group):
    """Custom Click group that renders commands in named sections."""

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        # ctx.params is empty during help rendering, so check sys.argv
        show_dev = any(arg.startswith("--dev") for arg in sys.argv)
        commands = self.list_commands(ctx)

        for section, section_cmds in COMMAND_SECTIONS.items():
            rows = []
            for name in section_cmds:
                if name not in commands:
                    continue
                # Hide platform-specific commands on other platforms
                if name in PLATFORM_COMMANDS and sys.platform != PLATFORM_COMMANDS[name]:
                    continue
                cmd = self.get_command(ctx, name)
                if cmd is None:
                    continue
                help_text = cmd.get_short_help_str(limit=150)
                rows.append((name, help_text))
            if rows:
                with formatter.section(section):
                    formatter.write_dl(rows)

        if show_dev:
            rows = []
            for name in sorted(DEV_COMMANDS):
                if name not in commands:
                    continue
                cmd = self.get_command(ctx, name)
                if cmd is None:
                    continue
                help_text = cmd.get_short_help_str(limit=150)
                rows.append((name, help_text))
            if rows:
                with formatter.section("Development"):
                    formatter.write_dl(rows)


def get_base_endpoint(endpoint: str) -> str:
    """Normalize endpoint to base URL (for backwards compatibility).

    Strips trailing slashes and known path suffixes so users can pass
    either 'https://example.com' or 'https://example.com/v1/ingest'.
    """
    base = endpoint.rstrip("/")
    # Strip known suffixes for backwards compatibility
    for suffix in ["/v1/ingest/sessions", "/v1/ingest"]:
        if base.endswith(suffix):
            base = base[: -len(suffix)]
            break
    return base


def get_git_email() -> str:
    """Get the user's email from git config.

    Returns:
        Git email or empty string if not configured.
    """
    try:
        result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return ""


def get_git_username() -> str:
    """Get the user's name from git config.

    Returns:
        Git user.name or empty string if not configured.
    """
    try:
        result = subprocess.run(
            ["git", "config", "--global", "user.name"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return ""


def get_default_email() -> str:
    """Get the default email for user identification.

    Tries in order:
    1. Git user.email
    2. username@hostname.local (fallback)

    Returns:
        Email string.
    """
    email = get_git_email()
    if email:
        return email

    # Fallback: construct pseudo-email from username@hostname
    username = getpass.getuser()
    hostname = socket.gethostname()
    return f"{username}@{hostname}.local"


def get_default_username() -> str:
    """Get the default username for display.

    Tries in order:
    1. Git user.name
    2. System username

    Returns:
        Username string.
    """
    username = get_git_username()
    if username:
        return username
    return getpass.getuser()


def get_default_device_id() -> str:
    """Get the default device ID from hostname.

    Returns:
        Device identifier string (hostname).
    """
    return socket.gethostname()


# Logger is configured in run() for daemon mode, or uses defaults for CLI commands
logger = logging.getLogger(__name__)


def _detect_source_format(file_path: Path) -> str | None:
    """Detect agent source format from file path.

    Uses library adapters for consistent detection.

    Args:
        file_path: Path to the session file.

    Returns:
        Source format string (claude, codex, cursor, gemini) or None if unknown.
    """
    from agentstream.adapters import get_adapter_for_path

    adapter = get_adapter_for_path(file_path)
    return adapter.name if adapter else None


# Token refresh threshold in seconds (refresh when <10 minutes remaining)
TOKEN_REFRESH_THRESHOLD = 600

# Maximum time (in seconds) a single session sync is allowed to take.
# This is a hard cap that aborts the entire sync attempt (entry reading +
# a single upload cycle including its internal retries). If upload retries
# alone exceed this budget the sync is cancelled mid-retry — the session
# will be retried on the next daemon cycle with a fresh timeout.
PER_SESSION_SYNC_TIMEOUT = 120

# How often to save state during bulk operations (historic import, catch-up).
# Saving after every N successful syncs prevents losing all progress if the
# daemon hangs or is killed mid-import.
BULK_SYNC_SAVE_INTERVAL = 5

# Map stored auth_method values to force_method values used by AuthManager
_AUTH_METHOD_TO_FORCE = {
    "ssh_signature": "ssh",
    "credential_helper": "credential",
    "gh_cli": "gh",
}


def _get_preferred_methods(default_order: list[str]) -> list[str]:
    """Reorder auth methods list to try the preferred method first.

    Reads the preferred method from config and maps stored auth_method
    values (e.g., 'ssh_signature') to force_method values (e.g., 'ssh').

    Args:
        default_order: Default ordered list of method keys (e.g., ["ssh", "credential", "gh"]).

    Returns:
        Reordered list with preferred method first.
    """
    config = load_config()
    preferred = config.server.auth_method
    preferred_key = _AUTH_METHOD_TO_FORCE.get(preferred or "", preferred)
    if preferred_key and preferred_key in default_order:
        methods = list(default_order)
        methods.remove(preferred_key)
        methods.insert(0, preferred_key)
        return methods
    return default_order


def _create_syncer(
    creds: StoredCredentials,
    endpoint: str,
    state: DaemonState,
    private_sessions: bool = False,
    org_repos: list[str] | None = None,
    private_repos: list[str] | None = None,
) -> SessionSyncer:
    """Create a SessionSyncer from credentials.

    Extracts device identification from hardware info and builds
    the syncer with all required authentication details.

    Args:
        creds: Stored credentials with auth token and user info.
        endpoint: Base API endpoint URL.
        state: Daemon state for session tracking.
        private_sessions: When True, tag sessions as private (personal org only).
        org_repos: Repos always treated as non-private (eligible for org attribution).
        private_repos: Repos always treated as private (personal workspace only).

    Returns:
        Configured SessionSyncer instance.
    """
    hw = collect_hardware_info()
    device_id = hw.hardware_uuid or hw.hostname
    base = get_base_endpoint(endpoint)
    ingest_endpoint = f"{base}/v1/ingest/sessions"

    return SessionSyncer(
        state=state,
        endpoint=ingest_endpoint,
        auth_token=creds.token,
        user_id=creds.user_id,
        device_id=device_id,
        email=creds.email,
        github_user=creds.github_user,
        credential_created_at=creds.created_at,
        private_sessions=private_sessions,
        org_repos=org_repos,
        private_repos=private_repos,
    )


def _create_web_syncer(
    creds: StoredCredentials,
    endpoint: str,
    state: DaemonState,
    web_client: WebSessionsClient,
    private_sessions: bool = False,
    org_repos: list[str] | None = None,
    private_repos: list[str] | None = None,
) -> WebSessionSyncer:
    """Create a WebSessionSyncer from credentials.

    Args:
        creds: Stored credentials with auth token and user info.
        endpoint: Base API endpoint URL.
        state: Daemon state for session tracking.
        web_client: WebSessionsClient for fetching web sessions.
        private_sessions: When True, tag sessions as private (personal org only).
        org_repos: Repos always treated as non-private (eligible for org attribution).
        private_repos: Repos always treated as private (personal workspace only).

    Returns:
        Configured WebSessionSyncer instance.
    """
    hw = collect_hardware_info()
    device_id = hw.hardware_uuid or hw.hostname
    base = get_base_endpoint(endpoint)
    ingest_endpoint = f"{base}/v1/ingest/sessions"

    return WebSessionSyncer(
        state=state,
        endpoint=ingest_endpoint,
        auth_token=creds.token,
        web_client=web_client,
        user_id=creds.user_id,
        device_id=device_id,
        email=creds.email,
        github_user=creds.github_user,
        credential_created_at=creds.created_at,
        private_sessions=private_sessions,
        org_repos=org_repos,
        private_repos=private_repos,
    )


async def _try_refresh_token(auth: AuthManager) -> bool:
    """Try to refresh token using non-interactive methods.

    Attempts SSH, credential helper, and gh CLI in order, preferring
    the previously successful method from config.
    Does not attempt device flow since it requires browser interaction.

    Args:
        auth: AuthManager instance for authentication.

    Returns:
        True if refresh succeeded, False otherwise.
    """
    for method in _get_preferred_methods(["ssh", "credential", "gh"]):
        try:
            await auth.get_token(force_method=method)
            return True
        except AuthError:
            continue
    return False


async def _maybe_refresh_token(
    auth: AuthManager,
    syncer: SessionSyncer | None,
    state: DaemonState,
    endpoint: str,
) -> SessionSyncer | None:
    """Check token expiry and refresh if needed.

    Proactively refreshes the token when it's close to expiring
    to avoid sync failures. Uses non-interactive auth methods only.

    Args:
        auth: AuthManager instance for authentication.
        syncer: Current SessionSyncer instance (may be None).
        state: Daemon state for session tracking.
        endpoint: Base ingest endpoint URL.

    Returns:
        Updated SessionSyncer if token was refreshed, original syncer
        if still valid, or None if refresh failed.
    """
    creds = auth.store.load(auth.endpoint)

    if not creds:
        return syncer

    time_remaining = creds.expires_at - time.time()
    if time_remaining > TOKEN_REFRESH_THRESHOLD:
        return syncer  # Still valid

    logger.info(f"Token expires in {time_remaining:.0f}s, refreshing...")

    if await _try_refresh_token(auth):
        new_creds = auth.store.load(auth.endpoint)
        if new_creds:
            return _create_syncer(
                new_creds,
                endpoint,
                state,
                private_sessions=syncer.private_sessions if syncer else False,
                org_repos=syncer.org_repos if syncer else None,
                private_repos=syncer.private_repos if syncer else None,
            )

    logger.warning("Token refresh failed, syncing disabled")
    return None


async def _run_sync_cycle(
    state: DaemonState,
    hot_tracker: HotSessionTracker,
    syncer: SessionSyncer,
) -> dict:
    """Run a single sync cycle, processing all hot sessions.

    Args:
        state: Daemon state for persistence.
        hot_tracker: Tracker with recently-changed sessions.
        syncer: SessionSyncer for uploading.

    Returns:
        Stats dict with processed, success, failed counts.
    """
    # Drain hot sessions atomically
    sessions_to_sync = hot_tracker.drain()

    if not sessions_to_sync:
        return {
            "processed": 0,
            "success": 0,
            "skipped": 0,
            "failed": 0,
            "needs_token_refresh": False,
        }

    logger.info(f"Sync cycle: processing {len(sessions_to_sync)} sessions")

    success_count = 0
    skipped_count = 0
    failed_count = 0
    needs_token_refresh = False
    synced_by_agent: dict[str, int] = defaultdict(int)

    for session_id, file_path in sessions_to_sync.items():
        file_path = Path(file_path)

        # Determine source format from path
        source_format = _detect_source_format(file_path)
        if not source_format:
            logger.warning(f"Unknown format for {file_path}, skipping")
            failed_count += 1
            continue

        # Build metadata - unified for all formats (including Cursor)
        try:
            metadata = build_metadata_for_file(file_path, source_format, session_id)
        except ValueError as e:
            # Session doesn't have a valid cwd yet (e.g., Claude session with only
            # file-history-snapshot entries). Only re-add to hot tracker if the file
            # was recently modified - this prevents old abandoned sessions from
            # accumulating forever in the hot tracker.
            try:
                mtime = file_path.stat().st_mtime
                age_seconds = time.time() - mtime
                # Only defer if modified in last hour
                if age_seconds < 3600:
                    logger.debug(f"Deferring sync for {session_id[:16]}...: {e}")
                    hot_tracker.add(session_id, str(file_path))
                else:
                    logger.debug(
                        f"Dropping stale session {session_id[:16]}... "
                        f"(no cwd, last modified {age_seconds / 3600:.1f}h ago)"
                    )
            except OSError:
                pass  # File disappeared, don't re-add
            skipped_count += 1
            continue

        try:
            outcome = await asyncio.wait_for(
                syncer.sync_session(
                    session_id=session_id,
                    file_path=file_path,
                    source_format=source_format,
                    metadata=metadata,
                ),
                timeout=PER_SESSION_SYNC_TIMEOUT,
            )
            if outcome.needs_token_refresh:
                needs_token_refresh = True
            if outcome.result == SyncResult.SYNCED:
                success_count += 1
                synced_by_agent[source_format] += 1
            elif outcome.result == SyncResult.SKIPPED:
                skipped_count += 1
            else:
                failed_count += 1
        except asyncio.TimeoutError:
            logger.error(
                f"Sync timed out for {session_id[:16]}... after {PER_SESSION_SYNC_TIMEOUT}s"
            )
            failed_count += 1
        except Exception as e:
            logger.error(f"Error syncing {session_id[:16]}...: {e}")
            failed_count += 1

    # Prune inactive sessions from hot tracker periodically
    hot_tracker.prune_inactive()

    return {
        "processed": len(sessions_to_sync),
        "success": success_count,
        "skipped": skipped_count,
        "failed": failed_count,
        "needs_token_refresh": needs_token_refresh,
        "synced_by_agent": dict(synced_by_agent),
    }


def _enqueue_mtime_backstop_sessions(
    state: DaemonState,
    hot_tracker: HotSessionTracker,
    endpoint: str,
    agent_types: tuple[str, ...] = ("codex",),
) -> dict[str, int]:
    """Enqueue sessions whose files advanced without a watcher event.

    This backstop catches platforms/agents where file watcher events are sparse
    (for example, writes flushed during an open file handle and emitted only on
    close). We currently scope this to Codex to keep scan cost low.
    """
    server_state = state.get_server_state(endpoint)
    target_agents = set(agent_types)
    enqueued_by_agent: dict[str, int] = defaultdict(int)

    for session_id, session_state in server_state.sessions.items():
        # Only backstop sessions that have been successfully synced at least once.
        # Sessions with last_mtime == 0 were never synced (trivial/new) and would
        # match every cycle since any real mtime > 0.
        if session_state.last_mtime == 0:
            continue

        file_path = Path(session_state.file_path)
        source_format = _detect_source_format(file_path)
        if source_format not in target_agents:
            continue

        try:
            current_mtime = file_path.stat().st_mtime
        except OSError:
            continue

        if current_mtime > session_state.last_mtime:
            hot_tracker.add(session_id, str(file_path))
            enqueued_by_agent[source_format] += 1

    return dict(enqueued_by_agent)


def _get_import_max_age_days() -> int:
    """Get the historic import max age in days.

    Priority (highest to lowest):
    1. HIVEMIND_IMPORT_MAX_AGE_DAYS environment variable
    2. Config file ([import] max_age_days)
    3. Default: 90 days

    Returns:
        Max age in days, or 0 for unlimited.
    """
    env_val = os.environ.get("HIVEMIND_IMPORT_MAX_AGE_DAYS")
    if env_val is not None:
        try:
            return int(env_val)
        except ValueError:
            logger.warning(
                f"Invalid HIVEMIND_IMPORT_MAX_AGE_DAYS={env_val!r}, using config default"
            )

    config = load_config()
    return config.import_.max_age_days


async def _run_historic_import(
    syncer: SessionSyncer,
    state: DaemonState,
    endpoint: str,
    state_file: Path | None = None,
) -> dict:
    """Import historic sessions on first boot.

    By default, only imports sessions from the last 90 days. This can be
    configured via the [import] max_age_days config option or the
    HIVEMIND_IMPORT_MAX_AGE_DAYS environment variable. Set to 0 for unlimited.

    Args:
        syncer: SessionSyncer instance for uploading.
        state: DaemonState for tracking sync progress.
        endpoint: Server endpoint (used to get server-scoped state).
        state_file: Path to state file for periodic saving (optional).

    Returns:
        Stats dict with discovered, success, failed, skipped counts.
    """
    max_age_days = _get_import_max_age_days()

    if max_age_days > 0:
        since_ts = time.time() - (max_age_days * 86400)
        click.echo(f"Importing historic sessions (last {max_age_days} days)...")
        logger.info(f"Starting historic session import (max_age_days={max_age_days})")
    else:
        since_ts = None
        click.echo("Importing historic sessions (all time)...")
        logger.info("Starting historic session import (unlimited)")

    # Get server-scoped state for session tracking
    server_state = state.get_server_state(endpoint)

    # Discover sessions from home directory (searches all agent paths)
    all_sessions = discover_all_sessions(Path.home(), since_ts=since_ts)

    if not all_sessions:
        click.echo("  No historic sessions found.")
        logger.info("No historic sessions found")
        return {"discovered": 0, "success": 0, "failed": 0, "skipped": 0}

    click.echo(f"  Found {len(all_sessions)} sessions to import...")

    success_count = 0
    failed_count = 0
    skipped_count = 0
    unsaved_syncs = 0

    for session in all_sessions:
        session_id = session["id"]
        file_path = Path(session["path"])
        source_format = session["format"]

        # Skip if we've already fully synced this session
        if session_id in server_state.sessions:
            session_state = server_state.sessions[session_id]
            # Check if file has been modified since last sync
            try:
                current_mtime = file_path.stat().st_mtime
                if current_mtime <= session_state.last_mtime:
                    skipped_count += 1
                    continue
            except OSError:
                skipped_count += 1
                continue
        else:
            # Skip sessions below the pruning horizon (already synced, then pruned from state)
            session_mtime = session.get("modified_at", 0)
            if 0 < session_mtime <= server_state.pruned_before_ts:
                skipped_count += 1
                continue

        # Build metadata - unified for all formats (including Cursor)
        try:
            metadata = extract_session_metadata(session)
        except ValueError as e:
            logger.warning(f"Failed to extract metadata for {session_id[:16]}...: {e}")
            failed_count += 1
            continue

        try:
            outcome = await asyncio.wait_for(
                syncer.sync_session(
                    session_id=session_id,
                    file_path=file_path,
                    source_format=source_format,
                    metadata=metadata,
                ),
                timeout=PER_SESSION_SYNC_TIMEOUT,
            )
            if outcome.result == SyncResult.SYNCED:
                success_count += 1
                unsaved_syncs += 1
            elif outcome.result == SyncResult.SKIPPED:
                skipped_count += 1
            else:
                failed_count += 1
        except asyncio.TimeoutError:
            logger.warning(
                f"Historic import timed out for {session_id[:16]}... "
                f"after {PER_SESSION_SYNC_TIMEOUT}s, skipping"
            )
            failed_count += 1
        except Exception as e:
            logger.warning(f"Historic import failed for {session_id[:16]}...: {e}")
            failed_count += 1

        # Save state periodically so progress isn't lost if daemon hangs or is killed
        if state_file and unsaved_syncs >= BULK_SYNC_SAVE_INTERVAL:
            save_state(state, state_file)
            unsaved_syncs = 0

    # Final save for any remaining unsaved progress
    if state_file and unsaved_syncs > 0:
        save_state(state, state_file)

    # Log summary
    click.echo(
        f"  Historic import complete: {success_count} synced, "
        f"{skipped_count} skipped, {failed_count} failed"
    )
    logger.info(
        f"Historic import complete: {success_count} synced, "
        f"{skipped_count} skipped, {failed_count} failed"
    )

    return {
        "discovered": len(all_sessions),
        "success": success_count,
        "failed": failed_count,
        "skipped": skipped_count,
    }


async def _run_catchup_sync(
    syncer: SessionSyncer,
    state: DaemonState,
    endpoint: str,
    state_file: Path | None = None,
) -> dict:
    """Sync sessions modified while daemon was stopped.

    This "catch-up sync" discovers all sessions and syncs any that have new
    entries. Per-session mtime/entry_idx checks handle dedup, so we don't need
    a time-based discovery filter.

    Args:
        syncer: SessionSyncer instance for uploading.
        state: DaemonState for tracking sync progress.
        endpoint: Server endpoint (used to get server-scoped state).
        state_file: Path to state file for periodic saving (optional).

    Returns:
        Stats dict with discovered, success, failed, skipped counts.
    """
    server_state = state.get_server_state(endpoint)

    logger.info("Running catch-up sync for all discoverable sessions")

    # Discover all sessions — rely on per-session mtime/entry_idx for dedup
    all_sessions = discover_all_sessions(Path.home())

    if not all_sessions:
        logger.info("No sessions found for catch-up sync")
        return {"discovered": 0, "success": 0, "failed": 0, "skipped": 0}

    click.echo(f"  Catch-up: found {len(all_sessions)} sessions modified since last run...")

    success_count = 0
    failed_count = 0
    skipped_count = 0
    unsaved_syncs = 0

    for session in all_sessions:
        session_id = session["id"]
        file_path = Path(session["path"])
        source_format = session["format"]

        # Check if already tracked and unchanged
        if session_id in server_state.sessions:
            session_state = server_state.sessions[session_id]
            try:
                current_mtime = file_path.stat().st_mtime
                if current_mtime <= session_state.last_mtime and session_state.last_entry_idx >= 0:
                    # File unchanged AND previously synced successfully — skip
                    skipped_count += 1
                    continue
            except OSError:
                skipped_count += 1
                continue
        else:
            # Skip sessions below the pruning horizon (already synced, then pruned from state)
            session_mtime = session.get("modified_at", 0)
            if 0 < session_mtime <= server_state.pruned_before_ts:
                skipped_count += 1
                continue

        # Build metadata - unified for all formats (including Cursor)
        try:
            metadata = extract_session_metadata(session)
        except ValueError as e:
            logger.warning(f"Catch-up: failed to extract metadata for {session_id[:16]}...: {e}")
            failed_count += 1
            continue

        try:
            outcome = await asyncio.wait_for(
                syncer.sync_session(
                    session_id=session_id,
                    file_path=file_path,
                    source_format=source_format,
                    metadata=metadata,
                ),
                timeout=PER_SESSION_SYNC_TIMEOUT,
            )
            if outcome.result == SyncResult.SYNCED:
                success_count += 1
                unsaved_syncs += 1
            elif outcome.result == SyncResult.SKIPPED:
                skipped_count += 1
            else:
                failed_count += 1
        except asyncio.TimeoutError:
            logger.warning(
                f"Catch-up sync timed out for {session_id[:16]}... "
                f"after {PER_SESSION_SYNC_TIMEOUT}s, skipping"
            )
            failed_count += 1
        except Exception as e:
            logger.warning(f"Catch-up sync failed for {session_id[:16]}...: {e}")
            failed_count += 1

        # Save state periodically so progress isn't lost
        if state_file and unsaved_syncs >= BULK_SYNC_SAVE_INTERVAL:
            save_state(state, state_file)
            unsaved_syncs = 0

    # Final save for any remaining unsaved progress
    if state_file and unsaved_syncs > 0:
        save_state(state, state_file)

    logger.info(
        f"Catch-up sync complete: {success_count} synced, "
        f"{skipped_count} skipped, {failed_count} failed"
    )

    return {
        "discovered": len(all_sessions),
        "success": success_count,
        "failed": failed_count,
        "skipped": skipped_count,
    }


def parse_since(value: str | None) -> float | None:
    """Parse --since value into a Unix timestamp.

    Accepts:
    - ISO 8601 datetime: "2024-01-15T10:30:00"
    - Date only: "2024-01-15"
    - Relative: "1d", "2h", "30m" (days, hours, minutes ago)
    - Unix timestamp: "1705312200"
    """
    if not value:
        return None

    import time

    # Try relative format first (e.g., "1d", "2h", "30m")
    if value[-1] in "dhm" and value[:-1].isdigit():
        num = int(value[:-1])
        unit = value[-1]
        seconds = {"d": 86400, "h": 3600, "m": 60}[unit]
        return time.time() - (num * seconds)

    # Try Unix timestamp
    if value.isdigit():
        return float(value)

    # Try ISO 8601 / date formats
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.replace(tzinfo=timezone.utc).timestamp()
        except ValueError:
            continue

    raise click.BadParameter(
        f"Invalid date format: {value}. Use ISO 8601 (2024-01-15T10:30:00), "
        "date (2024-01-15), relative (1d, 2h, 30m), or Unix timestamp."
    )


async def _dev_mode_authenticate(auth: AuthManager) -> bool:
    """Attempt DEV_MODE authentication by calling GET /v1/auth/me on the local API.

    In DEV_MODE, the API auto-creates a dev user and returns a JWT cookie
    without requiring GitHub OAuth. This enables the daemon to authenticate
    in environments without GitHub credentials (e.g., CI, Claude Code web).

    Args:
        auth: AuthManager instance (endpoint should be localhost).

    Returns:
        True if authentication succeeded, False otherwise.
    """
    endpoint = auth.endpoint.rstrip("/")
    url = f"{endpoint}/v1/auth/me"
    logger.info(f"DEV_MODE: Attempting auto-login via {url}")

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, timeout=10)
            if resp.status_code != 200:
                logger.warning(f"DEV_MODE: /v1/auth/me returned {resp.status_code}")
                return False

            # Extract JWT from set-cookie header
            token = None
            for cookie_header in resp.headers.get_list("set-cookie"):
                if cookie_header.startswith("agentstream_token="):
                    token = cookie_header.split("=", 1)[1].split(";")[0]
                    break

            if not token:
                logger.warning("DEV_MODE: No agentstream_token cookie in response")
                return False

            data = resp.json()
            creds = StoredCredentials(
                token=token,
                user_id=data.get("user_id", "dev-user"),
                github_user=data.get("username", "dev"),
                email=data.get("email", "dev@localhost"),
                expires_at=int(time.time()) + 30 * 86400,  # 30 days
                auth_method="dev_mode",
                device_id="dev-device",
                created_at=int(time.time()),
            )
            auth.store.save(creds, auth.endpoint)
            logger.info(f"DEV_MODE: Authenticated as {creds.github_user}")
            return True

    except Exception as e:
        logger.warning(f"DEV_MODE: Auto-login failed: {e}")
        return False


async def _ensure_authenticated(auth: AuthManager) -> tuple[bool, bool]:
    """Ensure the daemon has valid credentials, attempting auto-login if needed.

    Tries non-interactive authentication methods only (SSH, git credential, gh CLI).
    Device flow is skipped since it requires browser interaction.

    In dev mode (env var HIVEMIND_DEV_MODE=true), bypasses GitHub auth and
    instead calls the local API's /v1/auth/me endpoint which auto-creates a
    dev user and returns a JWT.

    Args:
        auth: AuthManager instance.

    Returns:
        Tuple of (authenticated, permanent_failure).
        - (True, False) if successfully authenticated
        - (False, True) if permanent auth failure (e.g., org restriction)
        - (False, False) if temporary auth failure (can retry later)
    """
    existing = await auth.whoami()
    if existing and not existing["expired"]:
        logger.info(f"Authenticated as {existing['github_user']} (via {existing['auth_method']})")
        return True, False

    if existing and existing["expired"]:
        logger.info(f"Token expired for {existing['github_user']}, attempting re-authentication...")

    # DEV_MODE bypass: authenticate via the API's dev auto-login
    dev_mode = os.environ.get("HIVEMIND_DEV_MODE", "").lower() in ("1", "true", "yes")
    if dev_mode:
        if await _dev_mode_authenticate(auth):
            return True, False
        logger.warning("DEV_MODE: Auto-login failed, falling back to standard auth methods")

    for method in _get_preferred_methods(["ssh", "credential", "gh"]):
        try:
            logger.debug(f"Trying authentication method: {method}")
            await auth.get_token(force_method=method)
            info = await auth.whoami()
            if info:
                logger.info(f"Authenticated as {info['github_user']} (via {info['auth_method']})")
                return True, False
        except PermanentAuthError as e:
            # Permanent failure - user is not authorized to use this service
            logger.error(f"Permanent auth failure: {e}")
            return False, True
        except AuthError as e:
            logger.debug(f"Auth method {method} failed: {e}")
            continue

    logger.warning("Authentication required. Run 'hivemind login' to authenticate this device.")
    logger.warning("The daemon will continue running but syncing is disabled until authenticated.")
    return False, False


async def _pre_start_auth_check_async(state_path: Path) -> None:
    """Verify authentication before starting the daemon.

    Checks for valid credentials and attempts non-interactive auth methods.
    Falls back to interactive device flow if a TTY is available.

    Args:
        state_path: Path to the state directory (used to resolve endpoint).

    Raises:
        SystemExit: If authentication fails and no TTY is available,
            or if a permanent auth failure occurs.
    """
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)

    # Check existing valid credentials
    info = await auth.whoami()
    if info and not info["expired"]:
        click.secho(f"✓ Authenticated as {info['github_user']} ({base_endpoint})", fg="green")
        return

    # Try non-interactive methods
    for method in ["ssh", "credential", "gh"]:
        try:
            await auth.get_token(force_method=method)
            info = await auth.whoami()
            if info:
                click.secho(
                    f"✓ Authenticated as {info['github_user']} ({base_endpoint})", fg="green"
                )
                return
        except PermanentAuthError as e:
            click.echo("\n" + "=" * 60, err=True)
            click.echo("ACCESS DENIED", err=True)
            click.echo("=" * 60, err=True)
            click.echo(str(e), err=True)
            click.echo("\nYour GitHub account is not authorized to use this service.", err=True)
            click.echo("Contact your administrator if you believe this is an error.", err=True)
            click.echo("=" * 60 + "\n", err=True)
            raise SystemExit(1)
        except AuthError:
            continue

    # All non-interactive methods failed
    if sys.stdin.isatty():
        click.echo("No valid credentials found. Starting interactive login...")
        try:
            await auth.get_token(force_method="device")
            info = await auth.whoami()
            if info:
                click.secho(
                    f"✓ Authenticated as {info['github_user']} ({base_endpoint})", fg="green"
                )
                return
        except PermanentAuthError as e:
            click.echo("\n" + "=" * 60, err=True)
            click.echo("ACCESS DENIED", err=True)
            click.echo("=" * 60, err=True)
            click.echo(str(e), err=True)
            click.echo("\nYour GitHub account is not authorized to use this service.", err=True)
            click.echo("Contact your administrator if you believe this is an error.", err=True)
            click.echo("=" * 60 + "\n", err=True)
            raise SystemExit(1)
        except AuthError as e:
            click.echo(f"Authentication failed: {e}", err=True)
            raise SystemExit(1)
    else:
        click.echo("Authentication required. Run 'hivemind login' to authenticate.", err=True)
        raise SystemExit(1)


def _pre_start_auth_check(state_path: Path) -> None:
    """Sync wrapper for _pre_start_auth_check_async. Skips in test mode."""
    if os.environ.get("HIVEMIND_TEST_MODE") == "1":
        return
    asyncio.run(_pre_start_auth_check_async(state_path))


async def _run_daemon(
    interval: int,
    state_path: Path,
    skip_historic_import: bool = False,
    skip_catchup: bool = False,
    test_mode: bool = False,
) -> None:
    """Run the daemon main loop.

    Args:
        interval: Sync interval in seconds.
        state_path: Path to state directory.
        skip_historic_import: If True, skip importing historic sessions on first boot.
        skip_catchup: If True, skip catch-up sync for sessions modified while daemon was stopped.
        test_mode: If True, skip authentication and syncing. Used in CI to verify
            the daemon process lifecycle without requiring credentials.
    """
    from watchdog.events import FileCreatedEvent, FileModifiedEvent, FileSystemEventHandler
    from watchdog.observers import Observer

    state_file = state_path / "state.json"

    # Configure logging (dev.debug in config enables DEBUG level)
    config = load_config()
    log_level = logging.DEBUG if config.dev.debug else logging.INFO
    log_dest = configure_logging(level=log_level)
    # When in debug, suppress noisy library logs that clutter our debug output.
    # - watchdog/fsevents: File system events for state.json, .state_*.tmp in .hivemind
    # - httpcore/httpx: Low-level HTTP connection details
    if config.dev.debug:
        logging.getLogger("watchdog").setLevel(logging.WARNING)
        logging.getLogger("fsevents").setLevel(logging.WARNING)
        logging.getLogger("httpcore").setLevel(logging.WARNING)
        logging.getLogger("httpx").setLevel(logging.INFO)

    # Determine effective endpoint (config module priority chain: config file > env var > default)
    config_path = DEFAULT_CONFIG_PATH
    effective_endpoint = get_effective_endpoint(config_path)
    endpoint_source = _get_endpoint_source(config_path)

    # Print startup banner
    click.echo("Hivemind daemon starting...")
    click.echo(f"  Version:   {__version__}")
    click.echo(f"  Logging to: {log_dest}")
    if config.dev.debug:
        click.echo("  Debug:     on (verbose logging)")
    click.echo(f"  State dir:  {state_path}")
    click.echo(f"  Endpoint:   {effective_endpoint} ({endpoint_source})")
    click.echo(f"  Interval:   {interval}s")

    # Check for test mode (CLI flag or env var)
    test_mode = test_mode or os.environ.get("HIVEMIND_TEST_MODE") == "1"
    if test_mode:
        click.echo("  Test mode:  ENABLED (auth and sync skipped)")

    # Check for dev mode (env var)
    dev_mode_env = os.environ.get("HIVEMIND_DEV_MODE", "").lower() in ("1", "true", "yes")
    if dev_mode_env and not test_mode:
        click.echo("  Dev mode:   ENABLED (auto-login via API)")

    logger.info("Hivemind daemon starting...")
    logger.info(f"Version: {__version__}")
    logger.info(f"Logging to: {log_dest}")
    logger.info(f"State directory: {state_path}")
    logger.info(f"Endpoint: {effective_endpoint} ({endpoint_source})")
    logger.info(f"Sync interval: {interval}s")
    if test_mode:
        logger.info("Test mode enabled - authentication and syncing skipped")

    # Auto-install/update the @hivemind agent across supported platforms
    if not test_mode:
        try:
            from hivemind.agent import install_agent

            if install_agent(quiet=True):
                logger.info("Installed/updated @hivemind agent")
        except Exception:
            logger.debug("Failed to install @hivemind agent", exc_info=True)

    # Setup auth and authenticate
    base_endpoint = get_base_endpoint(effective_endpoint)
    creds = None

    if test_mode:
        authenticated = True
        permanent_failure = False
    else:
        auth = AuthManager(endpoint=base_endpoint)
        authenticated, permanent_failure = await _ensure_authenticated(auth)

        if permanent_failure:
            click.echo("\n" + "=" * 60)
            click.echo("ACCESS DENIED")
            click.echo("=" * 60)
            click.echo("Your GitHub account is not authorized to use this service.")
            click.echo("Contact your administrator if you believe this is an error.")
            click.echo("=" * 60 + "\n")
            return  # Exit cleanly without starting the daemon loop

        # Get credentials for syncer setup (keyed by endpoint)
        creds = auth.store.load(auth.endpoint)

    # Load state and get server-specific state
    state = load_state(state_file)
    server_state = state.get_server_state(base_endpoint)
    logger.info(f"Loaded state: {len(server_state.sessions)} tracked sessions for {base_endpoint}")

    # Set up HotSessionTracker
    hot_tracker = HotSessionTracker(max_size=250, inactive_timeout=3600.0)

    # Load config for session privacy and web session settings
    config = load_config()

    # Set up SessionSyncer (only if authenticated and not in test mode)
    syncer = None
    if not test_mode and creds and not auth.store.is_expired(creds):
        syncer = _create_syncer(
            creds,
            effective_endpoint,
            state,
            private_sessions=config.sessions.private,
            org_repos=config.sessions.org_repos,
            private_repos=config.sessions.private_repos,
        )
        logger.info(f"Syncer initialized for user {creds.github_user}")

    # Set up web session polling (if enabled, not in test mode, and Claude credentials exist)
    web_poller: WebSessionPoller | None = None
    web_syncer: WebSessionSyncer | None = None
    web_client: WebSessionsClient | None = None

    if not test_mode and config.web_sessions.enabled and has_claude_credentials():
        try:
            web_client = WebSessionsClient()
            web_poller = WebSessionPoller(
                client=web_client,
                poll_interval=float(config.web_sessions.poll_interval),
            )
            # Skip initial poll if daemon ran recently (within poll interval)
            # This prevents scanning all web sessions on every dev reload
            time_since_last_run = time.time() - server_state.last_daemon_run_ts
            if (
                server_state.last_daemon_run_ts > 0
                and time_since_last_run < web_poller._poll_interval
            ):
                web_poller._last_poll_time = time.monotonic()
                logger.debug(
                    f"Skipping initial web poll (daemon ran {time_since_last_run:.0f}s ago)"
                )
            if creds and not auth.store.is_expired(creds):
                web_syncer = _create_web_syncer(
                    creds,
                    effective_endpoint,
                    state,
                    web_client,
                    private_sessions=config.sessions.private,
                    org_repos=config.sessions.org_repos,
                    private_repos=config.sessions.private_repos,
                )
            click.echo(
                f"  Web sync:   Enabled (poll interval: {config.web_sessions.poll_interval}s)"
            )
            logger.info(
                f"Web session polling enabled (interval: {config.web_sessions.poll_interval}s)"
            )
        except Exception as e:
            logger.warning(f"Failed to initialize web session polling: {e}")
            web_poller = None
            web_syncer = None
    elif config.web_sessions.enabled:
        click.echo("  Web sync:   Disabled (no Claude credentials)")
        logger.info("Web session polling disabled: no Claude credentials found")
    else:
        click.echo("  Web sync:   Disabled (config)")
        logger.info("Web session polling disabled by configuration")

    # Run historic import on first boot (if authenticated and not skipped)
    if syncer and not server_state.historic_import_completed and not skip_historic_import:
        try:
            await _run_historic_import(syncer, state, base_endpoint, state_file=state_file)
            server_state.historic_import_ts = int(time.time())
            save_state(state, state_file)
        except Exception as e:
            logger.error(f"Historic import failed: {e}")
            # Continue anyway - we'll try again on next boot
    elif skip_historic_import and not server_state.historic_import_completed:
        click.echo("  Skipping historic import (--skip-historic-import)")
        logger.info("Historic import skipped via CLI flag")

    # Run catch-up sync if historic import already completed (daemon was restarted)
    # This syncs sessions modified while the daemon was stopped
    if syncer and server_state.historic_import_completed and not skip_catchup:
        try:
            # Force token refresh before catch-up so the server has fresh
            # github_orgs for org resolution.  Without this, sessions synced
            # during catch-up may fall back to the personal org if the user's
            # github_orgs_updated_at is stale (> ORG_FRESHNESS_DAYS).
            try:
                await auth.get_token(force_refresh=True)
                new_creds = auth.store.load(auth.endpoint)
                if new_creds:
                    syncer = _create_syncer(
                        new_creds,
                        effective_endpoint,
                        state,
                        private_sessions=config.sessions.private,
                        org_repos=config.sessions.org_repos,
                        private_repos=config.sessions.private_repos,
                    )
                    logger.info("Pre-catchup token refresh succeeded")
            except Exception as refresh_err:
                logger.warning(f"Pre-catchup token refresh failed: {refresh_err}")

            stats = await _run_catchup_sync(syncer, state, base_endpoint, state_file=state_file)
            click.echo(f"  Catch-up: {stats['success']} synced, {stats['skipped']} skipped")
            # Update last_daemon_run_ts after catch-up
            server_state.last_daemon_run_ts = int(time.time())
            save_state(state, state_file)
        except Exception as e:
            logger.error(f"Catch-up sync failed: {e}")
            # Continue anyway - live sync will catch changes
    elif skip_catchup and server_state.historic_import_completed:
        click.echo("  Skipping catch-up sync (--skip-catchup)")
        logger.info("Catch-up sync skipped via CLI flag")

    # Set up shutdown and reload events
    shutdown_event = asyncio.Event()
    reload_event = asyncio.Event()

    def handle_shutdown(signum: int) -> None:
        logger.info(f"Received signal {signum}, shutting down...")
        shutdown_event.set()

    def handle_reload(signum: int) -> None:
        logger.info(f"Received SIGHUP (signal {signum}), will reload config...")
        reload_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, handle_shutdown, sig)
    loop.add_signal_handler(signal.SIGHUP, handle_reload, signal.SIGHUP)

    # Start watcher for session files
    watch_paths = get_watch_paths()

    # If in dev mode, show the repo we're running from
    if os.environ.get("HIVEMIND_DEV_MODE") == "1":
        config = load_config()
        if config.dev.repo:
            dev_repo_path = Path(config.dev.repo).expanduser().resolve()
            click.echo(f"  Dev repo:   {dev_repo_path}")
            logger.info(f"Running from dev repo: {dev_repo_path}")

    click.echo(f"  Watching:   {len(watch_paths)} directories")
    logger.info(f"Watching paths: {[str(p) for p in watch_paths]}")

    # Watcher collects changed paths - expensive processing happens in the main loop
    watcher = SessionWatcher(watch_paths=watch_paths)
    watcher.start()

    # Set up config file watcher
    config_observer = None

    class ConfigEventHandler(FileSystemEventHandler):
        def __init__(self, config_file: Path, reload_evt: asyncio.Event):
            self.config_file = config_file
            self.reload_evt = reload_evt

        def _is_config_file(self, event_path: str | bytes) -> bool:
            # Handle both str and bytes from watchdog
            path_str = os.fsdecode(event_path) if isinstance(event_path, bytes) else event_path
            return Path(path_str).resolve() == self.config_file.resolve()

        def on_modified(  # type: ignore[override]
            self, event: FileModifiedEvent
        ) -> None:
            if not event.is_directory and self._is_config_file(event.src_path):
                logger.info("Config file changed, will reload...")
                self.reload_evt.set()

        def on_created(  # type: ignore[override]
            self, event: FileCreatedEvent
        ) -> None:
            if not event.is_directory and self._is_config_file(event.src_path):
                logger.info("Config file created, will reload...")
                self.reload_evt.set()

    if config_path.parent.exists():
        config_observer = Observer()
        config_handler = ConfigEventHandler(config_path, reload_event)
        try:
            config_observer.schedule(config_handler, str(config_path.parent), recursive=False)
            config_observer.start()
            logger.info(f"Watching config file: {config_path}")
        except OSError as e:
            logger.warning(f"Could not watch config file: {e}")
            config_observer = None

    click.echo("Daemon ready. Press Ctrl+C to stop.")

    # Flush stdout so banner text is written to the log file immediately.
    # When running as a background service, stdout is redirected to a file
    # and Python uses full buffering, so click.echo output may not appear
    # on disk until the buffer fills or the process exits.
    sys.stdout.flush()

    loop_count = 0
    heartbeat_every = max(1, 300 // interval)  # every ~5 minutes
    watcher_events_seen: dict[str, int] = defaultdict(int)
    mtime_backstop_enqueues: dict[str, int] = defaultdict(int)
    synced_sessions: dict[str, int] = defaultdict(int)

    try:
        while not shutdown_event.is_set():
            loop_count += 1

            # Periodic heartbeat log so operators can confirm the daemon is alive
            if loop_count % heartbeat_every == 0:
                tracked = len(server_state.sessions) if server_state else 0
                logger.info(
                    "Heartbeat: alive, %s sessions tracked | watcher_events=%s | "
                    "mtime_backstop=%s | synced=%s",
                    tracked,
                    dict(watcher_events_seen),
                    dict(mtime_backstop_enqueues),
                    dict(synced_sessions),
                )

            # Check for config reload (SIGHUP or config file change)
            if reload_event.is_set():
                reload_event.clear()

                # Reload config
                config = load_config(config_path)
                new_endpoint = get_effective_endpoint(config_path)
                new_source = _get_endpoint_source(config_path)

                # Update session privacy on existing syncers
                if syncer:
                    syncer.private_sessions = config.sessions.private
                    syncer.org_repos = config.sessions.org_repos
                    syncer.private_repos = config.sessions.private_repos
                if web_syncer:
                    web_syncer.private_sessions = config.sessions.private
                    web_syncer.org_repos = config.sessions.org_repos
                    web_syncer.private_repos = config.sessions.private_repos

                if new_endpoint != effective_endpoint:
                    logger.info(
                        f"Endpoint changed: {effective_endpoint} -> {new_endpoint} ({new_source})"
                    )
                    effective_endpoint = new_endpoint

                    # Update server_state to track the new endpoint
                    base_endpoint = get_base_endpoint(effective_endpoint)
                    server_state = state.get_server_state(base_endpoint)

                    if not test_mode:
                        # Recreate auth manager with new endpoint
                        auth = AuthManager(endpoint=base_endpoint)

                        # Force token refresh so the new server has fresh
                        # github_orgs for org resolution during catch-up.
                        try:
                            await auth.get_token(force_refresh=True)
                            logger.info("Token refreshed for new endpoint")
                        except Exception as refresh_err:
                            logger.warning(f"Token refresh for new endpoint failed: {refresh_err}")

                        # Recreate syncer if authenticated (using new endpoint's credentials)
                        creds = auth.store.load(auth.endpoint)
                        if creds and not auth.store.is_expired(creds):
                            syncer = _create_syncer(
                                creds,
                                effective_endpoint,
                                state,
                                private_sessions=config.sessions.private,
                                org_repos=config.sessions.org_repos,
                                private_repos=config.sessions.private_repos,
                            )
                            logger.info(
                                f"Syncer recreated with new endpoint for {creds.github_user}"
                            )
                            # Also recreate web syncer if enabled
                            if web_client:
                                web_syncer = _create_web_syncer(
                                    creds,
                                    effective_endpoint,
                                    state,
                                    web_client,
                                    private_sessions=config.sessions.private,
                                    org_repos=config.sessions.org_repos,
                                    private_repos=config.sessions.private_repos,
                                )
                                logger.info("Web syncer recreated with new endpoint")

                            # Run catch-up sync for the new endpoint
                            # This ensures sessions are synced to the new server,
                            # not just forwarding live changes
                            try:
                                stats = await _run_catchup_sync(
                                    syncer, state, base_endpoint, state_file=state_file
                                )
                                click.echo(
                                    f"  Catch-up: {stats['success']} synced, "
                                    f"{stats['skipped']} skipped"
                                )
                                server_state.last_daemon_run_ts = int(time.time())
                                save_state(state, state_file)
                            except Exception as e:
                                logger.error(f"Catch-up sync after endpoint change failed: {e}")
                        else:
                            syncer = None
                            web_syncer = None
                            logger.warning(
                                "No valid credentials after config reload, syncing disabled"
                            )
                else:
                    logger.info(f"Config reloaded, endpoint unchanged: {effective_endpoint}")

            # Check for reset triggers at the start of each sync cycle
            from hivemind.state import clear_sessions_by_agent_type
            from hivemind.triggers import check_for_triggers, delete_trigger

            triggers = check_for_triggers()
            for trigger in triggers:
                agent_type = trigger["agent_type"]
                trigger_file = trigger["_file_path"]
                requested_by = trigger.get("requested_by", "unknown")

                try:
                    cleared_count = clear_sessions_by_agent_type(state, agent_type)
                    logger.info(
                        f"Reset trigger processed: cleared {cleared_count} {agent_type} sessions "
                        f"(requested by: {requested_by})"
                    )
                    # Delete trigger file as acknowledgment
                    delete_trigger(trigger_file)
                    # Save state immediately after clearing
                    if cleared_count > 0:
                        save_state(state, state_file)

                    # Re-discover and sync sessions directly (bypass hot tracker's 100 limit)
                    # This ensures ALL sessions are re-synced, not just 100
                    all_sessions = discover_all_sessions(Path.home(), since_ts=None)
                    matching_sessions = [s for s in all_sessions if s.get("format") == agent_type]
                    if matching_sessions and syncer:
                        logger.info(
                            f"Re-discovered {len(matching_sessions)} {agent_type} sessions, "
                            f"syncing directly..."
                        )
                        # Sync each session directly instead of through hot tracker
                        success = 0
                        skipped = 0
                        failed = 0
                        for session in matching_sessions:
                            session_id = session["id"]
                            file_path = Path(session["path"])
                            source_format = session.get("format", agent_type)
                            try:
                                # Build metadata - unified for all formats (including Cursor)
                                metadata = extract_session_metadata(session)
                                outcome = await asyncio.wait_for(
                                    syncer.sync_session(
                                        session_id=session_id,
                                        file_path=file_path,
                                        source_format=source_format,
                                        metadata=metadata,
                                    ),
                                    timeout=PER_SESSION_SYNC_TIMEOUT,
                                )
                                if outcome.result == SyncResult.SYNCED:
                                    success += 1
                                elif outcome.result == SyncResult.SKIPPED:
                                    skipped += 1
                                else:
                                    failed += 1
                            except asyncio.TimeoutError:
                                logger.debug(
                                    f"Resync timed out for {session_id[:16]}... "
                                    f"after {PER_SESSION_SYNC_TIMEOUT}s"
                                )
                                failed += 1
                            except Exception as e:
                                logger.debug(f"Resync error for {session_id[:16]}...: {e}")
                                failed += 1
                        logger.info(
                            f"Resync complete: {success} synced, {skipped} skipped, {failed} failed"
                        )
                        save_state(state, state_file)
                    elif matching_sessions:
                        logger.warning(
                            f"Found {len(matching_sessions)} {agent_type} sessions but no syncer "
                            f"(not authenticated?)"
                        )
                    else:
                        logger.info(f"No {agent_type} sessions found on disk to re-sync")
                except Exception as e:
                    logger.error(f"Failed to process reset trigger for {agent_type}: {e}")

            # Proactive token refresh
            if syncer:
                syncer = await _maybe_refresh_token(auth, syncer, state, effective_endpoint)

            # Process pending file changes from watcher
            # This moves expensive work (SQLite queries, JSON parsing) out of
            # the watchdog callback thread and into the main async loop
            from agentstream.adapters import extract_sessions_from_path

            pending_paths = watcher.drain_pending()
            if pending_paths:
                logger.debug(f"Processing {len(pending_paths)} pending file changes")
                for path in pending_paths:
                    logger.debug(f"  File changed: {path}")
                    try:
                        # Cursor bubbles are written to globalStorage/state.vscdb; that file
                        # doesn't list composers, so we need to check which Cursor sessions
                        # have new entries. Use incremental scan to avoid processing all 400+
                        # sessions on every change.
                        #
                        # Note: SQLite WAL mode writes may not trigger FSEvents reliably on
                        # macOS, but state.vscdb.options.json does get updated. We trigger on
                        # any state.vscdb* file change to catch updates.
                        if "globalStorage" in path.parts and path.name.startswith("state.vscdb"):
                            watcher_events_seen["cursor"] += 1
                            # Normalize path to the main database file for querying
                            global_db_path = path.parent / "state.vscdb"
                            logger.debug(
                                f"globalStorage change detected: {path} (using {global_db_path.name})"
                            )
                            server_state = state.get_server_state(effective_endpoint)
                            last_scan_ts = server_state.cursor_last_global_scan_ts
                            logger.debug(f"  cursor_last_global_scan_ts={last_scan_ts}")

                            # Get composerIds with bubbles created after our last scan
                            scan_result = get_recent_cursor_composer_ids(
                                global_db_path, since_ts_ms=last_scan_ts
                            )
                            logger.debug(
                                f"  scan_result: {len(scan_result.composer_ids)} composers, "
                                f"max_bubble_ts={scan_result.max_bubble_ts}"
                            )

                            if scan_result.composer_ids:
                                # Build mapping from composerId to workspace state.vscdb
                                cursor_user = global_db_path.parent.parent  # globalStorage -> User
                                workspace_map = build_composer_workspace_map(
                                    cursor_user / "workspaceStorage", scan_result.composer_ids
                                )
                                logger.debug(f"  workspace_map has {len(workspace_map)} entries")
                                added_count = 0
                                for composer_id, (state_path, folder_path) in workspace_map.items():
                                    hot_tracker.add(composer_id, str(state_path))
                                    added_count += 1

                                if added_count > 0:
                                    logger.debug(
                                        f"Added {added_count} Cursor sessions with new bubbles "
                                        f"(queried {len(scan_result.composer_ids)} composerIds)"
                                    )
                            else:
                                logger.debug("  No recent composerIds found")

                            # Update scan timestamp to max bubble timestamp we found
                            # (not current time, to avoid race conditions with in-flight writes)
                            server_state.cursor_last_global_scan_ts = scan_result.max_bubble_ts
                            continue
                        source_format = _detect_source_format(path)
                        if source_format:
                            watcher_events_seen[source_format] += 1
                        sessions = extract_sessions_from_path(path)
                        if sessions:
                            logger.debug(
                                f"  extract_sessions_from_path returned {len(sessions)} sessions"
                            )
                        for session in sessions:
                            session_id = session["id"]
                            hot_tracker.add(session_id, str(path))
                    except Exception as e:
                        logger.warning(f"Error processing {path}: {e}")

            # Run sync cycle if we have a syncer
            if syncer:
                try:
                    backstop_enqueues = _enqueue_mtime_backstop_sessions(
                        state=state,
                        hot_tracker=hot_tracker,
                        endpoint=effective_endpoint,
                    )
                    for agent_type, count in backstop_enqueues.items():
                        mtime_backstop_enqueues[agent_type] += count
                    if backstop_enqueues:
                        logger.info("Mtime backstop enqueued sessions: %s", backstop_enqueues)

                    stats = await _run_sync_cycle(
                        state=state,
                        hot_tracker=hot_tracker,
                        syncer=syncer,
                    )
                    for agent_type, count in stats.get("synced_by_agent", {}).items():
                        synced_sessions[agent_type] += count
                    if stats["processed"] > 0:
                        logger.info(
                            f"Sync cycle: {stats['success']} succeeded, "
                            f"{stats['skipped']} skipped, {stats['failed']} failed "
                            f"({stats['processed']} processed)"
                        )
                        # Persist last_entry_idx immediately so we don't re-send the same
                        # source entries if the process dies before end of iteration.
                        if stats.get("success", 0) > 0:
                            save_state(state, state_file)
                    else:
                        logger.debug("Sync cycle: 0 sessions (no file changes this interval)")
                    # Handle token refresh signal (server header or 401 with stale creds)
                    if stats.get("needs_token_refresh"):
                        logger.info("Token refresh needed, re-authenticating...")
                        try:
                            await auth.get_token(force_refresh=True)
                            new_creds = auth.store.load(auth.endpoint)
                            if new_creds:
                                syncer = _create_syncer(
                                    new_creds,
                                    effective_endpoint,
                                    state,
                                    private_sessions=config.sessions.private,
                                    org_repos=config.sessions.org_repos,
                                    private_repos=config.sessions.private_repos,
                                )
                                logger.info(f"Re-authenticated as {new_creds.github_user}")
                        except Exception as refresh_err:
                            logger.warning(f"Re-authentication failed: {refresh_err}")
                except Exception as e:
                    logger.error(f"Sync cycle error: {e}")

            # Poll and sync web sessions (if enabled)
            if web_poller and web_syncer and web_poller.should_poll:
                try:
                    web_sessions = await web_poller.poll()
                    if web_sessions:
                        web_stats = await sync_web_sessions(web_sessions, web_syncer)
                        if web_stats["total"] > 0:
                            logger.info(
                                f"Web sync: {web_stats['success']}/{web_stats['total']} succeeded"
                            )
                        # Handle token refresh signal (server header or 401 with stale creds)
                        if web_stats.get("needs_token_refresh"):
                            logger.info("Token refresh needed, re-authenticating...")
                            try:
                                await auth.get_token(force_refresh=True)
                                new_creds = auth.store.load(auth.endpoint)
                                if new_creds and web_client:
                                    syncer = _create_syncer(
                                        new_creds,
                                        effective_endpoint,
                                        state,
                                        private_sessions=config.sessions.private,
                                        org_repos=config.sessions.org_repos,
                                        private_repos=config.sessions.private_repos,
                                    )
                                    web_syncer = _create_web_syncer(
                                        new_creds,
                                        effective_endpoint,
                                        state,
                                        web_client,
                                        private_sessions=config.sessions.private,
                                        org_repos=config.sessions.org_repos,
                                        private_repos=config.sessions.private_repos,
                                    )
                                    logger.info(f"Re-authenticated as {new_creds.github_user}")
                            except Exception as refresh_err:
                                logger.warning(f"Re-authentication failed: {refresh_err}")
                except Exception as e:
                    logger.error(f"Web session sync error: {e}")
            # Update last_daemon_run_ts to track when daemon was last active
            # This is used by catch-up sync on next startup
            server_state.last_daemon_run_ts = int(time.time())

            # Prune old sessions to bound state file growth
            pruned = server_state.prune_old_sessions()
            if pruned:
                logger.info(f"Pruned {pruned} sessions older than 6 months from state")

            # Save state
            save_state(state, state_file)

            # Wait for interval or shutdown signal
            try:
                await asyncio.wait_for(shutdown_event.wait(), timeout=interval)
                break  # Shutdown requested
            except asyncio.TimeoutError:
                pass  # Normal timeout, continue loop

    finally:
        watcher.stop()
        if config_observer is not None:
            config_observer.stop()
            config_observer.join(timeout=5)
        # Update last_daemon_run_ts on shutdown for accurate catch-up sync on restart
        server_state.last_daemon_run_ts = int(time.time())
        save_state(state, state_file)
        logger.info(f"Daemon stopped. Final state: {len(state.sessions)} sessions tracked")


def _compare_versions(version1: str, version2: str) -> int:
    """Compare two PEP 440 versions.

    Returns:
        -1 if version1 < version2
        0 if version1 == version2
        1 if version1 > version2
    """
    from packaging.version import Version

    try:
        v1, v2 = Version(version1), Version(version2)
        return -1 if v1 < v2 else (1 if v1 > v2 else 0)
    except Exception:
        return 0  # Can't compare, assume equal


def _version_callback(ctx: click.Context, param: click.Parameter, value: bool) -> None:
    """Custom version callback that checks for updates."""
    if not value or ctx.resilient_parsing:
        return

    import httpx
    from rich.console import Console

    console = Console()

    # Show current version
    console.print(f"hivemind [cyan]{__version__}[/cyan]")

    # Try to check for updates from the server
    endpoint = get_effective_endpoint()
    try:
        with httpx.Client(timeout=5) as client:
            response = client.get(f"{endpoint}/health")
            if response.status_code == 200:
                data = response.json()
                min_version = data.get("min_daemon_version", "")

                if min_version and _compare_versions(__version__, min_version) < 0:
                    console.print()
                    console.print(
                        f"[yellow]A new version is available (v{min_version}). "
                        "Upgrade with:[/yellow]"
                    )
                    console.print(
                        "[dim]  brew upgrade wandb/taps/hivemind && "
                        "brew services restart wandb/taps/hivemind[/dim]"
                    )
    except Exception:
        # Silently fail if we can't reach the server
        pass

    ctx.exit()


@click.group(cls=HivemindGroup)
@click.option(
    "--version",
    "-V",
    is_flag=True,
    callback=_version_callback,
    expose_value=False,
    is_eager=True,
    help="Show version and check for updates.",
)
@click.option(
    "--dev",
    is_flag=True,
    hidden=True,
    help=f"Use local development server ({DEV_ENDPOINT})",
)
@click.option(
    "--qa",
    is_flag=True,
    hidden=True,
    help=f"Use QA server ({QA_ENDPOINT})",
)
@click.option(
    "--prod",
    is_flag=True,
    hidden=True,
    help=f"Use production server ({PROD_ENDPOINT})",
)
@click.option(
    "--dev-worktree",
    "dev_worktree",
    type=click.IntRange(1, 9),
    hidden=True,
    help=(
        "Use OrbStack worktree dev server (1-9), "
        f"e.g. --dev-worktree=1 → {DEV_WORKTREE_ENDPOINT.format(n=1)}"
    ),
)
@click.pass_context
def main(ctx: click.Context, dev: bool, qa: bool, prod: bool, dev_worktree: int | None):
    """Hivemind — sync agentic coding sessions to the cloud.

    \b
    Use 'hivemind start' to run the daemon and 'hivemind login' to authenticate.
    Run 'hivemind doctor' if something isn't working.
    """
    ctx.ensure_object(dict)
    ctx.obj["dev"] = dev or dev_worktree is not None

    # Check for mutually exclusive flags
    flags_set = sum([dev, qa, prod, dev_worktree is not None])
    if flags_set > 1:
        click.echo(
            "Error: --dev, --dev-worktree, --qa, and --prod are mutually exclusive",
            err=True,
        )
        raise SystemExit(1)

    if dev:
        set_endpoint_override(DEV_ENDPOINT)
    elif dev_worktree is not None:
        set_endpoint_override(DEV_WORKTREE_ENDPOINT.format(n=dev_worktree))
    elif qa:
        set_endpoint_override(QA_ENDPOINT)
    elif prod:
        set_endpoint_override(PROD_ENDPOINT)


@main.command()
@click.option("--interval", default=30, help="Sync interval in seconds")
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.option(
    "--skip-historic-import",
    is_flag=True,
    help="Skip importing historic sessions on first boot",
)
@click.option(
    "--skip-catchup",
    is_flag=True,
    help="Skip catch-up sync for sessions modified while daemon was stopped",
)
@click.option(
    "--test-mode",
    is_flag=True,
    help="Run without authentication or syncing (for CI lifecycle tests). "
    "Also enabled by HIVEMIND_TEST_MODE=1 env var.",
)
@click.pass_context
def run(
    ctx: click.Context,
    interval: int,
    state_dir: str,
    skip_historic_import: bool,
    skip_catchup: bool,
    test_mode: bool,
):
    """Run the daemon in the foreground (not daemonized).

    The endpoint is determined by (highest to lowest priority):
    1. --dev flag (http://localhost:8080) or --dev-worktree=N (http://api-wN.hivemind.local)
    2. Config file (~/.hivemind/config.toml)
    3. HIVEMIND_ENDPOINT environment variable
    4. Default endpoint

    When dev.repo is configured, the daemon will re-exec using the dev repo's
    Python interpreter. Use 'hivemind hup' to manually reload after code changes.
    """
    # Check for dev mode exec early, before any other initialization
    # This may call os.execve() and never return
    _maybe_exec_dev_mode()

    # If we're in dev mode (re-exec'd), set up hupper for auto-reload
    if os.environ.get("HIVEMIND_DEV_MODE") == "1":
        config = load_config()
        if config.dev.repo and _run_with_hupper(config.dev.repo):
            # hupper started the reloader, return and let hupper take over
            return

    state_path = Path(state_dir)
    lock_file = state_path / "daemon.lock"

    try:
        with acquire_lock(lock_file):
            asyncio.run(
                _run_daemon(
                    interval=interval,
                    state_path=state_path,
                    skip_historic_import=skip_historic_import,
                    skip_catchup=skip_catchup,
                    test_mode=test_mode,
                )
            )
    except RuntimeError as e:
        logger.error(str(e))
        sys.exit(1)


@main.command()
@click.option("--foreground", "-f", is_flag=True, help="Run in foreground (same as 'hivemind run')")
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.pass_context
def start(ctx, foreground, state_dir):
    """Start the daemon as a background process.

    Automatically uses the best available method:
    - Homebrew services (if installed via brew)
    - systemd user service (if installed on Linux)
    - Background process (fallback)

    Use --foreground to run in the foreground (equivalent to 'hivemind run').
    """
    from hivemind.service import get_service_manager

    state_path = Path(state_dir)

    if foreground:
        ctx.invoke(run, state_dir=state_dir)
        return

    _pre_start_auth_check(state_path)

    if is_daemon_running(state_path):
        pid = find_daemon_pid(state_path)
        click.echo(f"Daemon is already running (PID {pid}).")
        return

    mgr = get_service_manager(state_dir=state_path)
    success, message = mgr.start()
    click.echo(message)
    if not success:
        raise SystemExit(1)


@main.command()
@click.option("--force", is_flag=True, help="Force stop (SIGKILL)")
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
def stop(force, state_dir):
    """Stop the running daemon."""
    from hivemind.service import get_service_manager

    state_path = Path(state_dir)
    mgr = get_service_manager(state_dir=state_path)
    success, message = mgr.stop(force=force)
    click.echo(message)
    if not success:
        raise SystemExit(1)


@main.command()
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.pass_context
def restart(ctx, state_dir):
    """Restart the daemon."""
    from hivemind.service import get_service_manager

    state_path = Path(state_dir)
    _pre_start_auth_check(state_path)
    mgr = get_service_manager(state_dir=state_path)
    success, message = mgr.restart()
    click.echo(message)
    if not success:
        raise SystemExit(1)


@main.command()
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def status(state_dir, as_json):
    """Show daemon status and sync info."""
    from hivemind.service import get_service_manager

    state_path = Path(state_dir)
    state_file = state_path / "state.json"
    mgr = get_service_manager(state_dir=state_path)
    svc_status = mgr.status()

    # Gather additional info
    endpoint = get_effective_endpoint()
    log_location = str(_get_log_file_path() or DEFAULT_LOG_FILE)
    auth_user = None
    try:
        base = get_base_endpoint(endpoint)
        auth = AuthManager(endpoint=base)
        creds = auth.store.load(auth.endpoint)
        if creds and not auth.store.is_expired(creds):
            auth_user = creds.github_user
    except Exception:
        pass

    total_sessions = 0
    sessions_24h = 0
    last_sync = 0
    pending_events = 0
    cutoff_24h = time.time() - 86400
    if state_file.exists():
        state = load_state(state_file)
        # Use the current endpoint's server state for session counts
        norm_endpoint = _normalize_endpoint(endpoint)
        server_state = state.servers.get(norm_endpoint)
        if server_state:
            total_sessions = len(server_state.sessions)
            for sess in server_state.sessions.values():
                if sess.last_mtime >= cutoff_24h:
                    sessions_24h += 1
            last_sync = server_state.last_sync_ts
            pending_events = len(server_state.pending_buffer)

    # Fetch server health for version info
    min_daemon_version = None
    server_version = None
    server_build_sha = None
    try:
        import httpx

        resp = httpx.get(f"{endpoint}/health", timeout=3)
        if resp.status_code == 200:
            health = resp.json()
            server_version = health.get("version")
            server_build_sha = health.get("build_sha")
            min_daemon_version = health.get("min_daemon_version")
    except Exception:
        pass

    if as_json:
        data = {
            "running": svc_status.running,
            "pid": svc_status.pid,
            "uptime": svc_status.uptime,
            "method": svc_status.method,
            "endpoint": endpoint,
            "authenticated": auth_user is not None,
            "auth_user": auth_user,
            "version": __version__,
            "server_version": server_version,
            "server_build_sha": server_build_sha,
            "min_daemon_version": min_daemon_version,
            "sessions_tracked": total_sessions,
            "sessions_last_24h": sessions_24h,
            "last_sync_ts": last_sync,
            "pending_events": pending_events,
            "log_file": log_location,
            "brew_desync": svc_status.brew_desync,
        }
        click.echo(json.dumps(data, indent=2))
        return

    from rich.console import Console
    from rich.table import Table

    console = Console()

    # Status header
    if svc_status.running:
        status_str = "[bold green]Running[/bold green]"
        if svc_status.pid:
            status_str += f" (PID {svc_status.pid})"
    else:
        status_str = "[bold red]Stopped[/bold red]"

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="bold")
    table.add_column("Value")

    table.add_row("Status", status_str)
    if svc_status.uptime:
        table.add_row("Uptime", svc_status.uptime)
    table.add_row("Method", svc_status.method)
    table.add_row("Endpoint", endpoint)
    table.add_row(
        "Auth", f"[green]{auth_user}[/green]" if auth_user else "[red]Not authenticated[/red]"
    )

    # Version with upgrade warning
    version_str = __version__
    needs_upgrade = False
    if min_daemon_version:
        needs_upgrade = _compare_versions(__version__, min_daemon_version) < 0
    if needs_upgrade:
        if svc_status.method == "homebrew":
            upgrade_cmd = "brew upgrade wandb/taps/hivemind"
        else:
            upgrade_cmd = "uv tool upgrade wandb-hivemind"
        version_str = f"[bold red]{__version__}[/bold red] (run {upgrade_cmd})"
    if server_version:
        server_info = f"  server {server_version}"
        if server_build_sha:
            server_info += f" ({server_build_sha})"
        version_str += server_info
    table.add_row("Version", version_str)

    table.add_row("Sessions", f"{total_sessions} ({sessions_24h} in last 24h)")
    if last_sync > 0:
        sync_dt = datetime.fromtimestamp(last_sync / 1000, tz=timezone.utc)
        table.add_row("Last sync", sync_dt.strftime("%Y-%m-%d %H:%M:%S UTC"))
    if pending_events > 0:
        table.add_row("Pending", str(pending_events))
    table.add_row("Log file", log_location)

    console.print()
    console.print(table)

    if svc_status.brew_desync:
        console.print()
        console.print(
            "[yellow]Warning: Homebrew thinks the service is stopped but the daemon "
            "is running outside Homebrew's control.[/yellow]"
        )
        console.print(
            "[yellow]  This may cause issues with 'brew services stop/restart' and "
            "'brew upgrade'.[/yellow]"
        )
        console.print("[dim]  Fix: brew services restart wandb/taps/hivemind[/dim]")

    console.print()


@main.command()
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
def hup(state_dir: str):
    """Send reload signal to the running daemon.

    Sends SIGHUP to the running daemon, causing it to restart and pick up
    code changes. This is useful when developing with dev.repo configured.

    The daemon must be running with dev.repo for this to trigger a full
    code reload. Without dev.repo, SIGHUP only reloads the config file.
    """
    state_path = Path(state_dir)

    if not is_daemon_running(state_path):
        click.echo("Daemon is not running.", err=True)
        raise SystemExit(1)

    pid = find_daemon_pid(state_path)
    if pid is None:
        click.echo(
            "Daemon is running but PID could not be determined.\nTry: hivemind doctor --fix",
            err=True,
        )
        raise SystemExit(1)

    # Send SIGHUP to trigger reload
    try:
        os.kill(pid, signal.SIGHUP)
        click.echo(f"Sent SIGHUP to daemon (PID {pid}). Reloading...")
    except PermissionError:
        click.echo(f"No permission to signal daemon process {pid}.", err=True)
        raise SystemExit(1)
    except OSError as e:
        click.echo(f"Failed to send SIGHUP to daemon: {e}", err=True)
        raise SystemExit(1)


def _check_auth_for_post_install(state_path: Path) -> tuple[str, str]:
    """Check auth status without modifying credentials or making network calls.

    Performs a read-only check of local credential and tool availability.
    Used by ``doctor --post-install`` so the Homebrew formula never writes
    to ``credentials.json`` during install/upgrade.

    Returns:
        (status, detail) where status is one of:
        - "authenticated": valid credentials exist (detail = github username)
        - "auto_ssh": SSH key pair found (detail = key type e.g. "ED25519")
        - "auto_gh": gh CLI has a stored token (detail = "GitHub CLI")
        - "auto_git": git credential helper configured (detail = helper name)
        - "none": no auth method detected
    """
    creds_file = state_path / "credentials.json"

    # 1. Check existing credentials (read-only — no CredentialStore to avoid
    #    v1->v2 migration writes)
    if creds_file.exists():
        try:
            data = json.loads(creds_file.read_text())
            if isinstance(data, dict) and isinstance(data.get("servers"), dict):
                for server_data in data["servers"].values():
                    if isinstance(server_data, dict) and server_data.get("github_user"):
                        expires_at = server_data.get("expires_at", 0)
                        # Same 1-hour buffer as CredentialStore.is_expired
                        if time.time() < (expires_at - 3600):
                            return ("authenticated", server_data["github_user"])
        except (json.JSONDecodeError, ValueError, OSError):
            pass

    # 2. Check for SSH keys (local file check only, no network)
    ssh_dir = Path.home() / ".ssh"
    for name in ["id_ed25519", "id_rsa", "id_ecdsa"]:
        if (ssh_dir / name).exists() and (ssh_dir / f"{name}.pub").exists():
            return ("auto_ssh", name.replace("id_", "").upper())

    # 3. Check gh CLI token (local only, no network)
    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return ("auto_gh", "GitHub CLI")
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    # 4. Check git credential helper configuration
    try:
        result = subprocess.run(
            ["git", "config", "--get", "credential.helper"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return ("auto_git", result.stdout.strip())
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    return ("none", "")


def _count_health_issues_silent(state_path: Path) -> int:
    """Count health issues without printing anything.

    Only checks for conditions that ``doctor --fix`` can repair:
    corrupted credentials, stale lock files, and empty lock files.
    """
    creds_file = state_path / "credentials.json"
    lock_file = state_path / "daemon.lock"
    issues = 0

    # Corrupted credentials
    if creds_file.exists():
        try:
            data = json.loads(creds_file.read_text())
            if not isinstance(data, dict):
                issues += 1
            elif "version" in data and not isinstance(data.get("servers"), dict):
                issues += 1
        except (json.JSONDecodeError, ValueError, OSError):
            issues += 1

    # Stale lock file
    if lock_file.exists() and not is_daemon_running(state_path):
        issues += 1

    # Empty lock with running daemon
    if lock_file.exists() and is_daemon_running(state_path):
        try:
            if not lock_file.read_text().strip():
                issues += 1
        except OSError:
            pass

    return issues


def _is_service_installed() -> bool:
    """Check if the hivemind service was previously configured (upgrade hint)."""
    if platform.system() == "Darwin":
        plist = Path.home() / "Library/LaunchAgents/com.wandb.hivemind.plist"
        return plist.exists()
    else:
        unit = Path.home() / ".config/systemd/user/hivemind.service"
        return unit.exists()


def _doctor_post_install(state_path: Path) -> None:
    """Print post-install summary designed for Homebrew formula output.

    This is the primary user-facing output after ``brew install`` or
    ``brew upgrade``.  It checks auth availability (read-only), runs a
    silent health check, and prints service start/restart guidance.
    """
    is_upgrade = _is_service_installed() or is_daemon_running(state_path)

    click.echo()
    click.echo(f"  Hivemind v{__version__}")
    click.echo()

    # --- Auth status ---
    auth_status, auth_detail = _check_auth_for_post_install(state_path)
    if auth_status == "authenticated":
        click.echo(f"  Auth:     \u2713 Authenticated as {auth_detail}")
    elif auth_status.startswith("auto_"):
        method_name = {
            "auto_ssh": f"SSH key ({auth_detail})",
            "auto_gh": "GitHub CLI (gh)",
            "auto_git": f"Git credentials ({auth_detail})",
        }.get(auth_status, auth_detail)
        click.echo(
            f"  Auth:     \u2713 {method_name} detected \u2014 will auto-authenticate on first sync"
        )
    else:
        click.echo("  Auth:     \u2717 No authentication method detected")
        click.echo("            \u2192 Run: hivemind login")

    # --- Health summary ---
    issues = _count_health_issues_silent(state_path)
    if issues > 0:
        noun = "issue" if issues == 1 else "issues"
        click.echo(f"  Health:   \u2717 {issues} {noun} found \u2014 run `hivemind doctor --fix`")
    else:
        click.echo("  Health:   \u2713 No issues detected")

    click.echo()

    # --- Service guidance ---
    if is_upgrade:
        click.echo("  To apply the update:")
        click.echo("    hivemind restart")
    else:
        click.echo("  To get started:")
        click.echo("    hivemind start")

    click.echo()
    click.echo("  Other commands:")
    click.echo("    hivemind status             Check daemon status")
    click.echo("    hivemind logs               View daemon logs")
    click.echo("    hivemind doctor             Diagnose issues")
    click.echo()


@main.command()
@click.option("--fix", is_flag=True, help="Attempt to auto-fix detected issues")
@click.option(
    "--post-install",
    is_flag=True,
    hidden=True,
    help="Post-install summary for Homebrew formula (always exits 0)",
)
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
def doctor(fix: bool, post_install: bool, state_dir: str):
    """Diagnose and fix common issues."""
    state_path = Path(state_dir)

    if post_install:
        _doctor_post_install(state_path)
        return

    lock_file = state_path / "daemon.lock"
    creds_file = state_path / "credentials.json"

    issues_found = 0
    fixes_applied = 0

    # --- Check 1: Lock file health (empty lock + daemon running) ---
    daemon_running = is_daemon_running(state_path)
    lock_exists = lock_file.exists()
    lock_pid_str = ""
    if lock_exists:
        try:
            lock_pid_str = lock_file.read_text().strip()
        except OSError:
            pass

    if daemon_running and not lock_pid_str:
        # Lock held but PID empty — the old truncate-on-open bug
        issues_found += 1
        recovered_pid = find_daemon_pid(state_path)
        if recovered_pid is not None:
            click.echo(
                f"  \u2717 Lock file is empty but daemon is running (recovered PID: {recovered_pid})"
            )
            if fix:
                try:
                    lock_file.write_text(str(recovered_pid))
                    click.echo(f"    \u2192 Fixed: wrote PID {recovered_pid} to lock file")
                    fixes_applied += 1
                except OSError as e:
                    click.echo(f"    \u2192 Could not fix: {e}")
            else:
                click.echo("    \u2192 Run with --fix to write recovered PID to lock file")
        else:
            click.echo("  \u2717 Lock file is empty and daemon PID could not be recovered")
            click.echo("    \u2192 Restart the daemon to fix this")
    elif daemon_running and lock_pid_str:
        click.echo(f"  \u2713 Lock file healthy (PID: {lock_pid_str})")
    elif not daemon_running and not lock_exists:
        click.echo("  \u2713 No lock file (daemon not running)")
    # else: handled by stale lock check below

    # --- Check 2: Stale lock file ---
    if lock_exists and not daemon_running:
        issues_found += 1
        click.echo("  \u2717 Stale lock file (daemon not running, lock not held)")
        if fix:
            try:
                lock_file.unlink()
                click.echo("    \u2192 Fixed: removed stale lock file")
                fixes_applied += 1
            except OSError as e:
                click.echo(f"    \u2192 Could not fix: {e}")
        else:
            click.echo("    \u2192 Run with --fix to remove stale lock file")

    # --- Check 3: Credentials health ---
    try:
        if creds_file.exists():
            content = creds_file.read_text()
            data = json.loads(content)
            if not isinstance(data, dict):
                raise ValueError("credentials file is not a JSON object")
            if "version" in data and not isinstance(data.get("servers"), dict):
                raise ValueError("invalid v2 structure")
            click.echo("  \u2713 Credentials file healthy")
        else:
            click.echo("  \u2713 No credentials file (not yet authenticated)")
    except (json.JSONDecodeError, ValueError, OSError) as e:
        issues_found += 1
        click.echo(f"  \u2717 Credentials file corrupted: {e}")
        if fix:
            try:
                creds_file.unlink(missing_ok=True)
                click.echo(
                    "    \u2192 Fixed: removed corrupted credentials (re-authentication required)"
                )
                fixes_applied += 1
            except OSError as e2:
                click.echo(f"    \u2192 Could not fix: {e2}")
        else:
            click.echo("    \u2192 Run with --fix to reset credentials")

    # --- Check 4: Service sync (macOS only) ---
    if platform.system() == "Darwin":
        try:
            # Try the full tap name first (wandb/taps/hivemind), then fall back
            # to bare "hivemind". The bare name resolves to homebrew.mxcl.hivemind
            # which is a different (empty) formula from the tap's com.wandb.hivemind.
            svc = None
            for formula_name in ["wandb/taps/hivemind", "hivemind"]:
                result = subprocess.run(
                    ["brew", "services", "info", formula_name, "--json"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode == 0:
                    svc_info = json.loads(result.stdout)
                    candidate = svc_info[0] if isinstance(svc_info, list) else svc_info
                    # Use this result if the service is actually registered/loaded
                    if candidate.get("loaded") or candidate.get("status") not in (
                        "none",
                        None,
                    ):
                        svc = candidate
                        break
                    # Keep as fallback if we haven't found anything better
                    if svc is None:
                        svc = candidate

            if svc is not None:
                svc_status = svc.get("status", "unknown")
                if svc_status == "started":
                    if daemon_running:
                        click.echo("  \u2713 Homebrew service running and daemon lock held")
                    else:
                        issues_found += 1
                        click.echo(
                            "  \u2717 Homebrew service reports running but daemon lock not held"
                        )
                        click.echo("    \u2192 Try: brew services restart wandb/taps/hivemind")
                elif svc_status in ("none", "stopped"):
                    if daemon_running:
                        issues_found += 1
                        click.echo(
                            "  \u2717 Daemon running but Homebrew thinks the service is stopped"
                        )
                        if fix:
                            # Kill the orphan process so brew can take over cleanly
                            orphan_pid = find_daemon_pid(state_path)
                            orphan_stopped = False
                            if orphan_pid:
                                try:
                                    os.kill(orphan_pid, signal.SIGTERM)
                                    # Wait briefly for graceful shutdown
                                    for _ in range(10):
                                        time.sleep(0.5)
                                        try:
                                            os.kill(orphan_pid, 0)
                                        except ProcessLookupError:
                                            orphan_stopped = True
                                            break
                                    if not orphan_stopped:
                                        # Escalate to SIGKILL
                                        os.kill(orphan_pid, signal.SIGKILL)
                                        time.sleep(0.5)
                                        try:
                                            os.kill(orphan_pid, 0)
                                        except ProcessLookupError:
                                            orphan_stopped = True
                                except ProcessLookupError:
                                    orphan_stopped = True
                                except PermissionError:
                                    pass
                            else:
                                orphan_stopped = True

                            if not orphan_stopped:
                                click.echo(
                                    "    \u2192 Could not fix: failed to stop orphan "
                                    f"daemon (PID {orphan_pid})"
                                )
                            else:
                                result = subprocess.run(
                                    ["brew", "services", "restart", "wandb/taps/hivemind"],
                                    capture_output=True,
                                    text=True,
                                    timeout=10,
                                )
                                if result.returncode == 0:
                                    click.echo("    \u2192 Fixed: restarted service via Homebrew")
                                    fixes_applied += 1
                                else:
                                    click.echo(
                                        "    \u2192 Could not fix: brew services restart failed"
                                    )
                        else:
                            click.echo(
                                "    \u2192 Run with --fix, or: "
                                "brew services restart wandb/taps/hivemind"
                            )
                    else:
                        click.echo("  \u2713 Homebrew service stopped (daemon not running)")
                else:
                    click.echo(f"  \u2713 Homebrew service status: {svc_status}")
            else:
                click.echo(
                    "  \u2713 Homebrew hivemind formula not installed (skipping service check)"
                )
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
            click.echo("  \u2713 Homebrew not available (skipping service check)")

    # --- Summary ---
    click.echo()
    if issues_found == 0:
        click.echo("All checks passed.")
    elif fix:
        unfixed = issues_found - fixes_applied
        if unfixed == 0:
            click.echo(f"Fixed {fixes_applied} issue(s).")
        else:
            click.echo(f"Fixed {fixes_applied} issue(s), {unfixed} remaining.")
            raise SystemExit(1)
    else:
        click.echo(f"Found {issues_found} issue(s). Run with --fix to attempt repairs.")
        raise SystemExit(1)


def _find_git_root(start_path: Path) -> Path | None:
    """Find the git repository root from start_path, or None if not in a repo."""
    current = start_path.resolve()
    while current != current.parent:
        if (current / ".git").exists():
            return current
        current = current.parent
    return None


@main.command("import")
@click.option(
    "--since",
    envvar="HIVEMIND_IMPORT_SINCE",
    help="Import sessions modified after this time (e.g., '1d', '2h', '2024-01-15')",
)
@click.option(
    "--path",
    type=click.Path(exists=True),
    multiple=True,
    help="Paths to search for sessions (default: git repo root or current directory)",
)
@click.option(
    "--all",
    "import_all",
    is_flag=True,
    help="Import ALL sessions from all agent directories (bypasses path filtering)",
)
@click.option("--dry-run", is_flag=True, help="Show what would be imported without uploading")
@click.option(
    "--agents",
    help="Comma-separated list of agent types to import (e.g., 'claude,cursor'). Default: all agents",
)
@click.pass_context
def import_sessions(
    ctx: click.Context,
    since: str | None,
    path: tuple[str, ...],
    import_all: bool,
    dry_run: bool,
    agents: str | None,
):
    """Import sessions from local agent history.

    Requires authentication. Run 'hivemind login' first.

    By default, imports sessions from the current git repository (or current directory
    if not in a repo). Use --all to import from all agent directories.

    Examples:

        # Import to local dev server
        hivemind --dev import --since 1d

        # Import sessions from current git repo
        hivemind import --since 1d

        # Import ALL sessions from all agent directories
        hivemind import --all --since 1d

        # Import only specific agent types
        hivemind import --agents claude,cursor

        # Import sessions since a specific date
        hivemind import --since 2024-01-15

        # Dry run to see what would be imported
        hivemind import --dry-run

        # Import from specific paths
        hivemind import --path ~/projects/myapp --path ~/projects/other
    """
    # Determine effective endpoint
    effective_endpoint = get_effective_endpoint()

    # Require authentication
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            "Error: Not authenticated. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    user_id = creds.user_id
    auth_token = creds.token
    username = creds.github_user
    email = creds.email

    # Get device ID from hardware info
    from hivemind.auth.hardware import collect_hardware_info

    hardware_info = collect_hardware_info()
    # Prefer hardware_uuid, fallback to hostname
    device_id = hardware_info.hardware_uuid or hardware_info.hostname
    logger.info(f"Device ID: {device_id}")

    # Log user and device identification
    logger.info(f"Authenticated as: {username} ({email})")
    logger.info(f"User ID: {user_id}")

    # Parse since filter
    since_ts = parse_since(since)
    if since_ts:
        since_dt = datetime.fromtimestamp(since_ts, tz=timezone.utc)
        logger.info(f"Importing sessions modified since {since_dt.isoformat()}")
    else:
        logger.info("Importing ALL sessions (no --since filter)")

    # Determine search paths
    if path:
        # Explicit paths provided
        search_paths = [Path(p) for p in path]
    elif import_all:
        # --all flag: search from home to find all sessions
        search_paths = [Path.home()]
    else:
        # Default: use git root or current directory
        git_root = _find_git_root(Path.cwd())
        if git_root:
            logger.info(f"Using git repository root: {git_root}")
            search_paths = [git_root]
        else:
            search_paths = [Path.cwd()]

    # Parse agents filter
    allowed_agents = None
    if agents:
        allowed_agents = set(a.strip().lower() for a in agents.split(","))
        logger.info(f"Filtering to agents: {', '.join(sorted(allowed_agents))}")

    all_sessions = []

    for search_path in search_paths:
        logger.info(f"Searching {search_path}...")
        sessions = discover_all_sessions(search_path, since_ts=since_ts)
        all_sessions.extend(sessions)

    # Filter by agent type if specified
    if allowed_agents:
        all_sessions = [s for s in all_sessions if s["format"] in allowed_agents]

    logger.info(f"Found {len(all_sessions)} sessions")

    if not all_sessions:
        click.echo("No sessions to import.")
        return

    # Show summary by agent type using Rich
    from collections import Counter

    from rich.console import Console
    from rich.table import Table

    console = Console()
    agent_counts = Counter(s["format"] for s in all_sessions)

    # Summary table
    summary_table = Table(
        title=f"[bold]Found {len(all_sessions)} sessions[/bold]", show_header=True
    )
    summary_table.add_column("Agent", style="cyan")
    summary_table.add_column("Count", justify="right")
    for agent_type, count in sorted(agent_counts.items()):
        summary_table.add_row(agent_type, str(count))
    console.print()
    console.print(summary_table)

    # Recent sessions table
    recent_table = Table(title="[bold]Recent Sessions[/bold]", show_header=True)
    recent_table.add_column("Agent", style="cyan", width=8)
    recent_table.add_column("Session ID", style="dim")
    recent_table.add_column("Modified", style="green")
    for session in all_sessions[:10]:  # Show first 10
        mod_time = datetime.fromtimestamp(session["modified_at"], tz=timezone.utc)
        recent_table.add_row(
            session["format"],
            session["id"][:40] + "...",
            mod_time.strftime("%Y-%m-%d %H:%M"),
        )
    if len(all_sessions) > 10:
        recent_table.add_row("...", f"({len(all_sessions) - 10} more sessions)", "")
    console.print()
    console.print(recent_table)

    if dry_run:
        click.echo("\n--dry-run: No changes made.")
        return

    # Upload sessions
    # Use new server-side normalization endpoint
    base = get_base_endpoint(effective_endpoint)
    ingest_endpoint = f"{base}/v1/ingest/sessions"

    from rich.console import Console
    from rich.progress import (
        BarColumn,
        MofNCompleteColumn,
        Progress,
        SpinnerColumn,
        TaskProgressColumn,
        TextColumn,
        TimeElapsedColumn,
    )
    from rich.table import Table

    console = Console()
    console.print(f"\n[bold]Uploading to[/bold] {ingest_endpoint}")
    console.print(f"[bold]User:[/bold] {username}\n")

    uploader = Uploader(endpoint=ingest_endpoint, auth_token=auth_token)

    # Import the minimum entries threshold
    from hivemind.sync import MIN_ENTRIES_FOR_INITIAL_UPLOAD

    success_count = 0
    skip_count = 0
    error_count = 0
    errors: list[tuple[str, str, str]] = []  # (session_id, agent_type, error_msg)

    # Rich progress bar with multiple columns
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("[cyan]Importing sessions...", total=len(all_sessions))

        for session in all_sessions:
            session_desc = f"[dim]{session['format']}[/dim] {session['id'][:16]}..."
            progress.update(task, description=f"[cyan]Importing[/cyan] {session_desc}")

            try:
                # Read raw source entries
                source_entries = read_source_entries(session)

                # Skip trivial sessions (likely just initialized but never used)
                if len(source_entries) < MIN_ENTRIES_FOR_INITIAL_UPLOAD:
                    skip_count += 1
                    logger.debug(
                        f"Skipping trivial session {session['id'][:20]}... "
                        f"(only {len(source_entries)} entries)"
                    )
                    progress.advance(task)
                    continue

                # Extract metadata
                metadata = extract_session_metadata(session)
                metadata["user_id"] = user_id
                metadata["device_id"] = device_id
                metadata["email"] = email
                metadata["github_user"] = username

                # Build request
                request = SessionIngestRequest(
                    agent_session_id=session["id"],
                    source_format=session["format"],
                    metadata=metadata,
                    source_entries=[
                        SourceEntryInput(
                            entry_index=entry["entry_index"],
                            entry_content=entry["entry_content"],
                            entry_timestamp_ms=entry["entry_timestamp_ms"],
                        )
                        for entry in source_entries
                    ],
                )

                # Upload
                upload_result = asyncio.run(uploader.upload_session(request))
                if upload_result.success:
                    success_count += 1
                    logger.debug(
                        f"Imported {session['id'][:20]}... ({len(source_entries)} entries)"
                    )
                else:
                    error_count += 1
                    errors.append((session["id"][:16], session["format"], "Upload failed"))
                    logger.error(f"Failed to import {session['id'][:20]}...")

            except Exception as e:
                error_count += 1
                errors.append((session["id"][:16], session["format"], str(e)[:50]))
                logger.error(f"Error importing {session['id'][:20]}...: {e}")

            progress.advance(task)

    # Summary
    console.print()
    skip_msg = f", [dim]{skip_count} skipped[/dim]" if skip_count > 0 else ""
    if error_count == 0:
        console.print(
            f"[bold green]✓ Import complete:[/bold green] {success_count} sessions{skip_msg}"
        )
    else:
        console.print(
            f"[bold yellow]Import complete:[/bold yellow] "
            f"[green]{success_count} succeeded[/green], [red]{error_count} failed[/red]{skip_msg}"
        )

        # Show error table if there are errors
        if errors:
            console.print()
            error_table = Table(title="[red]Failed Sessions[/red]", show_header=True)
            error_table.add_column("Session ID", style="dim")
            error_table.add_column("Agent", style="cyan")
            error_table.add_column("Error", style="red")
            for sid, agent, err in errors[:10]:  # Show first 10 errors
                error_table.add_row(sid, agent, err)
            if len(errors) > 10:
                error_table.add_row("...", "...", f"({len(errors) - 10} more)")
            console.print(error_table)


@main.command("dump")
@click.option(
    "--agent",
    "-a",
    type=click.Choice(["claude", "cursor", "gemini", "codex"], case_sensitive=False),
    required=True,
    help="Agent type to dump session from",
)
@click.option(
    "--session-id",
    "-s",
    help="Specific session ID to dump (defaults to most recent)",
)
@click.option(
    "--path",
    type=click.Path(exists=True),
    help="Search path for sessions (defaults to current directory)",
)
def dump_session(agent: str, session_id: str | None, path: str | None):
    """Dump raw session data as JSONL.

    Outputs JSONL to stdout where each line contains:
    {"entry_index": N, "entry_content": "{...}", "entry_timestamp_ms": ...}

    This is useful for creating test fixtures or debugging normalization.

    Examples:
        # Dump most recent Claude session in current directory
        hivemind dump -a claude > tests/fixtures/claude/source_events.jsonl

        # Dump specific session
        hivemind dump -a cursor -s abc123... > cursor_session.jsonl
    """
    from hivemind.session_importer import discover_all_sessions, read_source_entries

    # Determine search path
    search_path = Path(path) if path else Path.cwd()

    # Discover sessions for this agent type
    sessions = discover_all_sessions(search_path, since_ts=None)

    # Filter by agent type
    sessions = [s for s in sessions if s["format"] == agent.lower()]

    if not sessions:
        click.echo(f"No {agent} sessions found in {search_path}", err=True)
        raise SystemExit(1)

    # Select session
    if session_id:
        # Find by ID
        session = next((s for s in sessions if s["id"] == session_id), None)
        if not session:
            click.echo(f"Session {session_id} not found", err=True)
            raise SystemExit(1)
    else:
        # Use most recent
        sessions.sort(key=lambda s: s["modified_at"], reverse=True)
        session = sessions[0]

    # Read source entries
    try:
        source_entries = read_source_entries(session)
    except Exception as e:
        click.echo(f"Error reading session: {e}", err=True)
        raise SystemExit(1)

    # Extract daemon metadata (same as what gets sent to API)
    from hivemind.session_importer import extract_session_metadata

    try:
        daemon_metadata = extract_session_metadata(session)
    except Exception as e:
        click.echo(f"Error extracting metadata: {e}", err=True)
        raise SystemExit(1)

    # Output as JSONL (same format as sent to API)

    # First, output synthetic daemon_metadata entry (entry_index: -1)
    # This represents the SESSION_METADATA custom event created by the API
    metadata_entry = {
        "entry_index": -1,
        "entry_content": json.dumps(
            {
                "type": "daemon_metadata",
                "metadata": daemon_metadata,
            }
        ),
        "entry_timestamp_ms": source_entries[0]["entry_timestamp_ms"] if source_entries else 0,
    }
    click.echo(json.dumps(metadata_entry))

    # Then output all source entries
    for entry in source_entries:
        json_line = json.dumps(
            {
                "entry_index": entry["entry_index"],
                "entry_content": entry["entry_content"],
                "entry_timestamp_ms": entry["entry_timestamp_ms"],
            }
        )
        click.echo(json_line)

    # Log metadata to stderr so it doesn't interfere with stdout
    click.echo(
        f"# Dumped {len(source_entries)} source entries + 1 metadata entry from {agent} session {session['id'][:16]}... "
        f"(modified: {datetime.fromtimestamp(session['modified_at'], tz=timezone.utc).isoformat()})",
        err=True,
    )


@main.command("transcript")
@click.argument("session_id")
@click.option(
    "--event-types",
    default=None,
    help=(
        "Comma-separated event categories to include: user, assistant, reasoning, tools, files, errors. "
        'Use "all" to include everything.'
    ),
)
@click.option(
    "--verbose/--no-verbose",
    default=False,
    help="Show request details (default: false)",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["markdown", "jsonl", "atif"]),
    default="markdown",
    help="Output format (default: markdown)",
)
@click.pass_context
def transcript(
    ctx: click.Context,
    session_id: str,
    event_types: str | None,
    verbose: bool,
    output_format: str,
):
    """Fetch and display a session transcript.

    Retrieves the transcript from the backend API and outputs it to stdout.
    The transcript is formatted for LLM consumption with conversation turns.

    SESSION_ID is the agent session ID (the full UUID or a prefix).

    Examples:

        # Get markdown transcript for a session
        hivemind transcript abc12345-...

        # Only user and assistant messages
        hivemind transcript abc12345 --event-types user,assistant

        # Include everything
        hivemind transcript abc12345 --event-types all

        # Output as JSONL (raw source entries)
        hivemind transcript abc12345 --format jsonl

        # Output as ATIF (Agent Trajectory Interchange Format)
        hivemind transcript abc12345 --format atif

        # Save to file
        hivemind transcript abc12345 > session.md
    """
    # Determine effective endpoint
    effective_endpoint = get_effective_endpoint()

    # Require authentication
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            "Error: Not authenticated. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    # Expand "all" shorthand for event_types
    all_event_types = "user,assistant,reasoning,tools,files,errors"
    effective_event_types = all_event_types if event_types == "all" else event_types

    # Build the API URL
    url = f"{base_endpoint}/v1/sessions/{session_id}/llm"
    params: dict[str, Any] = {
        "format": output_format,
    }
    if effective_event_types:
        params["event_types"] = effective_event_types

    if verbose:
        click.echo(f"GET {url}", err=True)
        click.echo(f"  params: {params}", err=True)

    try:
        with httpx.Client(timeout=60.0) as client:
            response = client.get(
                url,
                params=params,
                headers={"Authorization": f"Bearer {creds.token}"},
            )
            response.raise_for_status()

            data = response.json()

            if output_format == "markdown":
                # Output the markdown content
                markdown = data.get("markdown", "")
                if markdown:
                    click.echo(markdown)
                else:
                    click.echo("No transcript content available.", err=True)
                    raise SystemExit(1)
            elif output_format == "atif":
                # ATIF format - output the trajectory as pretty-printed JSON
                trajectory = data.get("trajectory", {})
                if trajectory:
                    click.echo(json.dumps(trajectory, indent=2))
                else:
                    click.echo("No ATIF trajectory available.", err=True)
                    raise SystemExit(1)
            else:
                # JSONL format - output each entry as a JSON line
                entries = data.get("entries", [])
                for entry in entries:
                    click.echo(json.dumps(entry))

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            click.echo(f"Error: Session '{session_id}' not found.", err=True)
        else:
            click.echo(f"HTTP error: {e.response.status_code} - {e.response.text}", err=True)
        raise SystemExit(1)
    except httpx.RequestError as e:
        click.echo(f"Connection error: {e}", err=True)
        raise SystemExit(1)


def _fork_command_options(fn):
    fn = click.argument("session_id")(fn)
    fn = click.option(
        "--agent",
        type=click.Choice(["claude", "codex", "cursor-agent"]),
        default=None,
        help="Agent to use for the forked session. Defaults to the original session's agent.",
    )(fn)
    fn = click.option(
        "--no-checkout",
        is_flag=True,
        default=False,
        help="Skip git branch checkout.",
    )(fn)
    fn = click.option(
        "--dry-run",
        is_flag=True,
        default=False,
        help="Print the fork context without launching an agent.",
    )(fn)
    fn = click.option(
        "--full-history",
        is_flag=True,
        default=False,
        help="Request the full unsummarized transcript instead of server-compacted context.",
    )(fn)
    fn = click.pass_context(fn)
    return fn


def _get_fork_request_timeout_seconds() -> float:
    """Return the timeout for fork-context fetches."""
    raw_value = os.getenv("HIVEMIND_FORK_TIMEOUT_SECONDS", "").strip()
    if not raw_value:
        return 600.0

    try:
        parsed = float(raw_value)
    except ValueError:
        logger.warning(
            "Invalid HIVEMIND_FORK_TIMEOUT_SECONDS=%r; using default=600",
            raw_value,
        )
        return 600.0

    return max(parsed, 30.0)


def _run_fork(
    ctx: click.Context,
    session_id: str,
    agent: str | None,
    no_checkout: bool,
    dry_run: bool,
    full_history: bool,
):
    """Fork work from a previous Hivemind session.

    Fetches the session's fork context and launches an interactive
    agent session with that context pre-loaded.

    SESSION_ID is the session UUID (full or prefix).

    Examples:

        # Fork a session with the same agent type
        hivemind fork abc12345-...

        # Fork with a specific agent
        hivemind fork abc12345 --agent codex

        # Preview the compacted fork context without launching an agent
        hivemind fork abc12345 --dry-run

        # Request the full, unsummarized transcript
        hivemind fork abc12345 --full-history

        # Fork without checking out the session's branch
        hivemind fork abc12345 --no-checkout
    """
    # --- Authenticate ---
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            "Error: Not authenticated. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    # --- Fetch fork context ---
    click.echo(f"Fetching fork context for session {session_id}...", err=True)

    url = f"{base_endpoint}/v1/sessions/{session_id}/fork-context"
    params = {"full_history": "true"} if full_history else None
    fork_timeout_seconds = _get_fork_request_timeout_seconds()
    try:
        with httpx.Client(timeout=fork_timeout_seconds) as client:
            response = client.get(
                url,
                params=params,
                headers={"Authorization": f"Bearer {creds.token}"},
            )
            response.raise_for_status()
            data = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            click.echo(f"Error: Session '{session_id}' not found.", err=True)
        else:
            click.echo(
                f"HTTP error: {e.response.status_code} - {e.response.text}",
                err=True,
            )
        raise SystemExit(1)
    except httpx.RequestError as e:
        click.echo(f"Connection error: {e}", err=True)
        raise SystemExit(1)

    fork_context = data.get("fork_context") or data.get("compaction_summary", "")
    context_mode = data.get("context_mode", "compacted")
    system_prompt = data.get("system_prompt", "")
    git_repo = data.get("git_repo", "")
    git_branch = data.get("git_branch", "")
    session_agent = data.get("agent_type", "claude")
    title = data.get("title", "")
    token_count = data.get("token_count", 0)

    # Resolve which agent to use
    if agent:
        target_agent = agent
    elif not dry_run:
        # Interactive prompt — detect available agents
        agents = []
        for cmd in ("claude", "codex", "cursor-agent"):
            check = subprocess.run(["which", cmd], capture_output=True, text=True, timeout=5)
            if check.returncode == 0:
                agents.append(cmd)

        if not agents:
            click.echo(
                "Error: No supported agent found on PATH (claude, codex, cursor-agent). "
                "Install one first.",
                err=True,
            )
            raise SystemExit(1)
        elif len(agents) == 1:
            target_agent = agents[0]
        else:
            # Both available — ask the user
            click.echo(f"\n  Session: {title or session_id}", err=True)
            click.echo(f"  Context: ~{token_count} tokens\n", err=True)
            choice = click.prompt(
                "Fork with",
                type=click.Choice(agents, case_sensitive=False),
                default=session_agent if session_agent in agents else agents[0],
            )
            target_agent = choice
    else:
        target_agent = (
            session_agent if session_agent in ("claude", "codex", "cursor-agent") else "claude"
        )

    click.echo(f"  Session: {title or session_id}", err=True)
    click.echo(f"  Agent: {target_agent}", err=True)
    click.echo(f"  Context: ~{token_count} tokens ({context_mode})", err=True)

    # --- Dry run: just print the context ---
    if dry_run:
        click.echo("\n--- Fork Context ---\n")
        click.echo(fork_context)
        return

    # --- Validate git state ---
    # Check we're in a git repo
    git_check = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if git_check.returncode != 0:
        click.echo(
            "Error: Not inside a git repository. "
            "Please run this command from within the repository.",
            err=True,
        )
        raise SystemExit(1)

    # Check that we're in the same repo
    if git_repo:
        local_repo_result = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if local_repo_result.returncode == 0:
            local_repo_url = local_repo_result.stdout.strip()
            local_repo_normalized = normalize_git_url(local_repo_url)
            session_repo_normalized = normalize_git_url(git_repo)
            if (
                local_repo_normalized
                and session_repo_normalized
                and local_repo_normalized != session_repo_normalized
            ):
                click.echo(
                    f"Error: Repository mismatch.\n"
                    f"  Session repo: {git_repo}\n"
                    f"  Local repo:   {local_repo_url}\n"
                    f"Please run this command from the correct repository.",
                    err=True,
                )
                raise SystemExit(1)

    # --- Git branch checkout ---
    if not no_checkout and git_branch:
        # Check if the branch exists locally or remotely
        branch_exists_local = subprocess.run(
            ["git", "rev-parse", "--verify", f"refs/heads/{git_branch}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        branch_exists_remote = subprocess.run(
            ["git", "rev-parse", "--verify", f"refs/remotes/origin/{git_branch}"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if branch_exists_local.returncode == 0 or branch_exists_remote.returncode == 0:
            # Branch exists - check it out
            current_branch = subprocess.run(
                ["git", "branch", "--show-current"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            current = current_branch.stdout.strip() if current_branch.returncode == 0 else ""

            if current != git_branch:
                # Check for uncommitted changes
                status = subprocess.run(
                    ["git", "status", "--porcelain"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if status.stdout.strip():
                    click.echo(
                        f"Warning: You have uncommitted changes. "
                        f"Skipping checkout of branch '{git_branch}'.",
                        err=True,
                    )
                else:
                    click.echo(f"  Checking out branch '{git_branch}'...", err=True)
                    checkout = subprocess.run(
                        ["git", "checkout", git_branch],
                        capture_output=True,
                        text=True,
                        timeout=15,
                    )
                    if checkout.returncode != 0:
                        click.echo(
                            f"Warning: Failed to checkout branch '{git_branch}': "
                            f"{checkout.stderr.strip()}",
                            err=True,
                        )
            else:
                click.echo(f"  Already on branch '{git_branch}'.", err=True)
        else:
            # Branch doesn't exist - check if it was merged
            click.echo(
                f"  Branch '{git_branch}' not found. "
                f"It may have been merged or deleted. Using current branch.",
                err=True,
            )

    # --- Write fork context to temp file ---
    context_file = tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".md",
        prefix="hivemind-fork-",
        delete=False,
    )
    context_file.write(fork_context)
    context_file.close()
    context_path = context_file.name

    click.echo(f"  Fork context written to {context_path}", err=True)

    # --- Launch agent ---
    # Note: os.execvp replaces the current process, so the temp file
    # in /tmp will persist until the OS cleans it up. This is intentional
    # since the agent needs the file to be readable during its session.
    if target_agent == "claude":
        _launch_claude(context_path, system_prompt)
    elif target_agent == "codex":
        _launch_codex(context_path, system_prompt)
    elif target_agent == "cursor-agent":
        _launch_cursor_agent(context_path, system_prompt)


@main.command("fork")
@_fork_command_options
def fork(
    ctx: click.Context,
    session_id: str,
    agent: str | None,
    no_checkout: bool,
    dry_run: bool,
    full_history: bool,
):
    """Fork work from a previous Hivemind session."""
    return _run_fork(ctx, session_id, agent, no_checkout, dry_run, full_history)


@main.command("resume", hidden=True)
@_fork_command_options
def resume(
    ctx: click.Context,
    session_id: str,
    agent: str | None,
    no_checkout: bool,
    dry_run: bool,
    full_history: bool,
):
    """Deprecated alias for `hivemind fork`."""
    click.echo("Warning: 'hivemind resume' is deprecated; use 'hivemind fork'.", err=True)
    return _run_fork(ctx, session_id, agent, no_checkout, dry_run, full_history)


def _launch_claude(context_path: str, system_prompt: str) -> None:
    """Launch an interactive Claude Code session with fork context."""
    claude_check = subprocess.run(
        ["which", "claude"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if claude_check.returncode != 0:
        click.echo(
            "Error: 'claude' command not found. Please install Claude Code first.",
            err=True,
        )
        raise SystemExit(1)

    click.echo("\nLaunching Claude Code with fork context...\n", err=True)

    # Pass the system prompt and explicitly instruct Claude to read the
    # context file so the handoff is actually consumed.
    prompt = (
        system_prompt + f"\n\nRead the file at {context_path} to load the prior session handoff."
    )
    cmd = ["claude", "--append-system-prompt", prompt]

    # exec replaces the current process so claude gets full terminal control
    os.execvp("claude", cmd)


def _launch_codex(context_path: str, system_prompt: str) -> None:
    """Launch an interactive Codex session with fork context."""
    codex_check = subprocess.run(
        ["which", "codex"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if codex_check.returncode != 0:
        click.echo(
            "Error: 'codex' command not found. Please install Codex CLI first.",
            err=True,
        )
        raise SystemExit(1)

    click.echo("\nLaunching Codex with fork context...\n", err=True)

    # Codex takes a prompt as the first positional argument
    prompt = (
        f"Read the file at {context_path} — it contains a handoff from a prior session "
        f"you are forking from. Then continue if the next step is obvious, otherwise ask what to work on next."
    )
    cmd = ["codex", prompt]

    os.execvp("codex", cmd)


def _launch_cursor_agent(context_path: str, system_prompt: str) -> None:
    """Launch an interactive Cursor Agent session with fork context."""
    cursor_check = subprocess.run(
        ["which", "cursor-agent"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if cursor_check.returncode != 0:
        click.echo(
            "Error: 'cursor-agent' command not found. Please install Cursor Agent first.",
            err=True,
        )
        raise SystemExit(1)

    click.echo("\nLaunching Cursor Agent with fork context...\n", err=True)

    prompt = (
        f"Read the file at {context_path} — it contains a handoff from a prior session "
        f"you are forking from. Then continue if the next step is obvious, otherwise ask what to work on next."
    )
    cmd = ["cursor-agent", prompt]

    os.execvp("cursor-agent", cmd)


@main.command()
@click.option(
    "--method",
    type=click.Choice(["auto", "ssh", "device", "credential", "gh"]),
    default="auto",
    help="Authentication method: auto (detect), ssh (SSH key), device (browser OAuth), credential (git credential helper), gh (GitHub CLI)",
)
def login(method: str):
    """Authenticate with GitHub.

    Automatically detects the best authentication method:
    - SSH key signing (if SSH key exists)
    - Git credential helper (if PAT is stored)
    - GitHub CLI token (if gh is authenticated)
    - OAuth device flow (fallback, requires browser)

    Use --method to force a specific authentication method.
    """
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)

    # Check if already authenticated (unless forcing a specific method)
    if method == "auto":
        existing = asyncio.run(auth.whoami())
        if existing and not existing["expired"]:
            click.echo(f"Already authenticated as {existing['github_user']}")
            if not click.confirm("Re-authenticate?"):
                return
            auth.logout()

    # Authenticate
    force_method = None if method == "auto" else method
    # Use preferred auth method from config when auto-detecting
    preferred_method = None
    if method == "auto":
        config = load_config()
        preferred_method = config.server.auth_method
    try:
        if method == "auto":
            if preferred_method:
                click.echo(f"Discovering authentication method (preferring {preferred_method})...")
            else:
                click.echo("Discovering authentication method...")
        else:
            click.echo(f"Authenticating via {method}...")
        asyncio.run(auth.get_token(force_method=force_method, preferred_method=preferred_method))
        info = asyncio.run(auth.whoami())
        if info:
            click.echo(f"Authenticated as {info['github_user']} via {info['auth_method']}")
            # Save the successful auth method to config for future logins without
            # rewriting the entire config file (which could drop unknown keys).
            update_config("server.auth_method", info["auth_method"])
    except PermanentAuthError as e:
        click.echo("\n" + "=" * 60, err=True)
        click.echo("ACCESS DENIED", err=True)
        click.echo("=" * 60, err=True)
        click.echo(str(e), err=True)
        click.echo("\nYour GitHub account is not authorized to use this service.", err=True)
        click.echo("Contact your administrator if you believe this is an error.", err=True)
        click.echo("=" * 60 + "\n", err=True)
        raise SystemExit(1)
    except AuthError as e:
        click.echo(f"Authentication failed: {e}", err=True)
        raise SystemExit(1)


@main.command()
def whoami():
    """Show authenticated user and device info."""
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    info = asyncio.run(auth.whoami())

    # Always show device info, even if not authenticated
    hw = collect_hardware_info()

    click.echo("Device Information:")
    click.echo(f"  Hostname:      {hw.hostname}")
    click.echo(f"  OS:            {hw.os} {hw.os_version}")
    if hw.serial_number:
        click.echo(f"  Serial:        {hw.serial_number}")
    if hw.hardware_uuid:
        click.echo(f"  Hardware UUID: {hw.hardware_uuid}")
    if hw.machine_id:
        click.echo(f"  Machine ID:    {hw.machine_id}")
    if hw.mac_addresses:
        click.echo(f"  MAC Addresses: {', '.join(hw.mac_addresses[:3])}")
        if len(hw.mac_addresses) > 3:
            click.echo(f"                 (+{len(hw.mac_addresses) - 3} more)")

    click.echo()

    if not info:
        click.echo("Authentication: Not authenticated")
        click.echo("Run 'hivemind login' to authenticate.")
        return

    click.echo("Authentication:")
    click.echo(f"  User:        {info['github_user']}")
    click.echo(f"  Email:       {info['email']}")
    click.echo(f"  User ID:     {info['user_id']}")
    click.echo(f"  Auth Method: {info['auth_method']}")
    expires_dt = datetime.fromtimestamp(info["expires_at"])
    click.echo(f"  Expires:     {expires_dt.strftime('%Y-%m-%d %H:%M:%S')}")
    if info["expired"]:
        click.echo("  Status:      EXPIRED (will refresh on next request)")
    else:
        click.echo("  Status:      Valid")


@main.command()
def logout():
    """Clear stored credentials."""
    auth = AuthManager(endpoint="")  # Endpoint not needed for logout
    auth.logout()
    click.echo("Logged out successfully.")


@main.command("dev-token", hidden=True)
def dev_token():
    """Get a dev-mode JWT for local frontend development.

    Authenticates via GitHub CLI (gh) and exchanges for a token
    with dev:true in the payload. Prints the token to stdout.
    """
    import subprocess

    import httpx

    # Get GitHub token from gh CLI
    try:
        result = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, timeout=5)
        if result.returncode != 0:
            click.echo(
                "Error: GitHub CLI (gh) not authenticated. Run 'gh auth login' first.", err=True
            )
            raise SystemExit(1)
        gh_token = result.stdout.strip()
    except FileNotFoundError:
        click.echo(
            "Error: GitHub CLI (gh) not found. Install it from https://cli.github.com", err=True
        )
        raise SystemExit(1)
    except subprocess.TimeoutExpired:
        click.echo("Error: GitHub CLI (gh) timed out. Check your network connection.", err=True)
        raise SystemExit(1)

    # Exchange for dev token
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    hw = collect_hardware_info()

    try:
        response = httpx.post(
            f"{base_endpoint}/v1/auth/exchange",
            json={
                "github_token": gh_token,
                "auth_method": "gh_cli",
                "device_id": hw.hardware_uuid or hw.hostname or "dev",
                "dev": True,
                "hostname": hw.hostname,
                "os": hw.os,
                "os_version": hw.os_version,
            },
            timeout=30,
        )
    except (httpx.RequestError, httpx.TimeoutException) as exc:
        click.echo(f"Error: Failed to connect to {base_endpoint}: {exc}", err=True)
        raise SystemExit(1)

    if response.status_code != 200:
        click.echo(
            f"Error: Token exchange failed ({response.status_code}): {response.text}", err=True
        )
        raise SystemExit(1)

    # Print just the token (for use in scripts/Makefile)
    click.echo(response.json()["token"])


@main.command()
@click.argument(
    "agent_type",
    type=click.Choice(sorted(VALID_AGENT_TYPES)),
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be deleted without making changes",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    help="Skip confirmation prompt",
)
@click.option(
    "--state-dir",
    type=click.Path(),
    default=str(DEFAULT_STATE_DIR),
    help="State directory path",
)
def resync(
    agent_type: str,
    dry_run: bool,
    yes: bool,
    state_dir: str,
) -> None:
    """Force re-sync all sessions for an agent type.

    Deletes all sessions for the specified agent type from both the backend
    server and local daemon state, allowing them to be re-discovered and
    re-synced from scratch.

    Examples:

        # Preview what would be deleted
        hivemind resync cursor --dry-run

        # Delete and re-sync cursor sessions (with confirmation)
        hivemind resync cursor

        # Delete without confirmation
        hivemind resync cursor --yes
    """
    import httpx

    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    state_path = Path(state_dir)
    state_file = state_path / "state.json"

    # Check authentication
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo("Not authenticated. Run 'hivemind login' first.", err=True)
        raise SystemExit(1)

    # Dry run: just show preview
    if dry_run:
        preview_url = f"{base_endpoint}/v1/sessions/cleanup/preview"
        try:
            response = httpx.get(
                preview_url,
                params={"agent_type": agent_type},
                headers={"Authorization": f"Bearer {creds.token}"},
                timeout=30.0,
            )

            if response.status_code == 401:
                click.echo("Not authenticated. Run 'hivemind login' first.", err=True)
                raise SystemExit(1)

            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After", "60")
                click.echo(f"Rate limited. Please try again in {retry_after} seconds.", err=True)
                raise SystemExit(1)

            response.raise_for_status()
            data = response.json()

            click.echo(f"\nDry run: resync {agent_type} sessions for {creds.email}")
            click.echo(f"\nBackend cleanup preview ({base_endpoint}):")
            click.echo(f"  Sessions:       {data.get('session_count', 0):,}")
            click.echo(f"  Events:         {data.get('event_count', 0):,}")
            click.echo(f"  Source entries: {data.get('source_entry_count', 0):,}")

            # Count local sessions
            if state_file.exists():
                state = load_state(state_file)
                local_count = _count_local_sessions_by_agent_type(state, agent_type)
                click.echo("\nLocal state preview:")
                click.echo(f"  Sessions:       {local_count:,}")

            click.echo("\nNo changes made. Run without --dry-run to proceed.")
            return

        except httpx.HTTPStatusError as e:
            click.echo(f"HTTP error: {e.response.status_code} - {e.response.text}", err=True)
            raise SystemExit(1)
        except httpx.RequestError as e:
            click.echo(f"Connection error: {e}", err=True)
            raise SystemExit(1)

    # Get preview counts for confirmation
    preview_url = f"{base_endpoint}/v1/sessions/cleanup/preview"
    try:
        response = httpx.get(
            preview_url,
            params={"agent_type": agent_type},
            headers={"Authorization": f"Bearer {creds.token}"},
            timeout=30.0,
        )

        if response.status_code == 401:
            click.echo("Not authenticated. Run 'hivemind login' first.", err=True)
            raise SystemExit(1)

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After", "60")
            click.echo(f"Rate limited. Please try again in {retry_after} seconds.", err=True)
            raise SystemExit(1)

        response.raise_for_status()
        preview_data = response.json()
        session_count = preview_data.get("session_count", 0)

    except httpx.HTTPStatusError as e:
        click.echo(f"HTTP error: {e.response.status_code} - {e.response.text}", err=True)
        raise SystemExit(1)
    except httpx.RequestError as e:
        click.echo(f"Connection error: {e}", err=True)
        raise SystemExit(1)

    # Confirm with user (only if there are sessions to delete)
    if not yes and session_count > 0:
        if not click.confirm(
            f"This will delete {session_count:,} {agent_type} sessions. Continue?"
        ):
            click.echo("Aborted.")
            return

    # Output summary header
    click.echo(f"\nResync {agent_type} sessions for {creds.email}")
    click.echo()

    # Call backend DELETE endpoint (only if there are sessions to delete)
    cleanup_data: dict[str, int] = {}
    if session_count > 0:
        cleanup_url = f"{base_endpoint}/v1/sessions/cleanup"
        try:
            response = httpx.request(
                "DELETE",
                cleanup_url,
                json={"agent_type": agent_type},
                headers={"Authorization": f"Bearer {creds.token}"},
                timeout=60.0,
            )

            if response.status_code == 401:
                click.echo("Not authenticated. Run 'hivemind login' first.", err=True)
                raise SystemExit(1)

            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After", "60")
                click.echo(f"Rate limited. Please try again in {retry_after} seconds.", err=True)
                raise SystemExit(1)

            response.raise_for_status()
            cleanup_data = response.json()

        except httpx.HTTPStatusError as e:
            click.echo(f"HTTP error: {e.response.status_code} - {e.response.text}", err=True)
            raise SystemExit(1)
        except httpx.RequestError as e:
            click.echo(f"Connection error: {e}", err=True)
            raise SystemExit(1)

        # Backend cleanup summary
        click.echo("Backend cleanup:")
        click.echo(f"  ✓ Deleted {cleanup_data.get('deleted_sessions', 0):,} sessions")
        click.echo(f"  ✓ Deleted {cleanup_data.get('deleted_events', 0):,} events")
        click.echo(f"  ✓ Deleted {cleanup_data.get('deleted_source_entries', 0):,} source entries")
        click.echo()
    else:
        click.echo("Backend cleanup:")
        click.echo(f"  ✓ No {agent_type} sessions to delete")
        click.echo()

    # Update local state
    click.echo("Local state:")
    daemon_running = is_daemon_running(state_path)
    local_state_error = False

    if daemon_running:
        # Create trigger file for daemon to pick up
        try:
            trigger_path = create_trigger(agent_type, "resync-command")
            click.echo(f"  ✓ Signaled daemon to reset {agent_type} state")

            # Poll for trigger deletion (daemon acknowledgment)
            acknowledged = _poll_for_trigger_deletion(trigger_path, timeout=30.0)

            if acknowledged:
                click.echo("  ✓ Daemon acknowledged reset")
            else:
                click.echo(
                    "  ! Daemon did not acknowledge within 30s (trigger may still be processed)",
                    err=True,
                )
        except Exception as e:
            local_state_error = True
            click.echo(f"  ! Error signaling daemon: {e}", err=True)
            click.echo(f"    You may need to manually clear state from {state_file}")
    else:
        # Daemon not running, update state directly
        try:
            with locked_state_update(state_path):
                state = load_state(state_file)
                cleared_count = clear_sessions_by_agent_type(
                    state, agent_type, server_url=base_endpoint
                )
                save_state(state, state_file)
                click.echo(f"  ✓ Cleared {cleared_count:,} {agent_type} sessions from local state")
        except RuntimeError as e:
            # This shouldn't happen since we checked is_daemon_running
            local_state_error = True
            click.echo(f"  ! Error updating local state: {e}", err=True)
            click.echo(f"    State file: {state_file}")
        except Exception as e:
            local_state_error = True
            click.echo(f"  ! Error updating local state: {e}", err=True)
            click.echo(f"    State file: {state_file}")

    click.echo()
    if local_state_error:
        click.echo(
            "Warning: Backend cleanup succeeded but local state update failed.\n"
            "Consider restarting the daemon to ensure clean state."
        )
    else:
        click.echo(f"Next: Daemon will re-discover and sync {agent_type} sessions automatically.")


def _count_local_sessions_by_agent_type(state: DaemonState, agent_type: str) -> int:
    """Count sessions matching an agent type across all servers."""
    from agentstream.adapters import get_adapter_for_path

    count = 0
    for server_state in state.servers.values():
        for session_sync_state in server_state.sessions.values():
            file_path = Path(session_sync_state.file_path)
            adapter = get_adapter_for_path(file_path)
            if adapter is not None and adapter.name == agent_type:
                count += 1
    return count


def _poll_for_trigger_deletion(trigger_file: Path, timeout: float = 30.0) -> bool:
    """Poll for trigger file deletion (daemon acknowledgment).

    Args:
        trigger_file: Path to the trigger file to watch.
        timeout: Maximum time to wait in seconds.

    Returns:
        True if trigger was deleted (daemon acknowledged), False if timeout.
    """
    import time

    start_time = time.time()
    poll_interval = 0.1  # 100ms

    while time.time() - start_time < timeout:
        if not trigger_file.exists():
            return True
        time.sleep(poll_interval)

    return False


@main.command()
@click.argument("path")
@click.option(
    "-X",
    "--method",
    default="GET",
    type=click.Choice(["GET", "POST", "PUT", "DELETE", "PATCH"], case_sensitive=False),
    help="HTTP method (default: GET)",
)
@click.option(
    "-d",
    "--data",
    help="Request body (JSON string)",
)
@click.option(
    "-q",
    "--query",
    multiple=True,
    help="Query parameter as key=value (can be repeated)",
)
@click.option(
    "--raw",
    is_flag=True,
    help="Output raw JSON without pretty printing",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    help="Show request details",
)
def api(
    path: str,
    method: str,
    data: str | None,
    query: tuple[str, ...],
    raw: bool,
    verbose: bool,
):
    """Make authenticated API requests (curl-like).

    PATH is the API endpoint path. It will be prefixed with /v1 if it doesn't
    start with /v1. Examples:

    \b
        # Get a session
        hivemind api /sessions/5144a9f9-abc8-5c7e-811d-24964af1eb06

        # List sessions with query params
        hivemind api /sessions -q limit=10

        # Get session summary
        hivemind api /sessions/abc123/summary

        # Trigger enrichment (PUT request)
        hivemind api -X PUT /sessions/abc123/summary

        # Get stats
        hivemind api /stats/active-users

    The command automatically uses your stored authentication token.
    """

    import httpx

    # Determine effective endpoint
    effective_endpoint = get_effective_endpoint()

    # Get authentication
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        # Attempt dev-mode auto-login for localhost endpoints
        if "localhost" in base_endpoint or "127.0.0.1" in base_endpoint:
            import asyncio

            if asyncio.run(_dev_mode_authenticate(auth)):
                creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo(
            f"Error: Not authenticated for {base_endpoint}. Run 'hivemind login' first.", err=True
        )
        raise SystemExit(1)

    # Build URL
    # Normalize path - add /v1 prefix if needed (except for root-level endpoints)
    if not path.startswith("/"):
        path = "/" + path
    # Don't add /v1 prefix for root-level endpoints like /health
    if not path.startswith("/v1") and path not in ("/health",):
        path = "/v1" + path

    url = base_endpoint + path

    # Parse query parameters
    params = {}
    for q in query:
        if "=" in q:
            key, value = q.split("=", 1)
            params[key] = value
        else:
            click.echo(f"Invalid query parameter: {q} (expected key=value)", err=True)
            raise SystemExit(1)

    # Parse request body
    body = None
    if data:
        try:
            body = json.loads(data)
        except json.JSONDecodeError as e:
            click.echo(f"Invalid JSON data: {e}", err=True)
            raise SystemExit(1)

    # Build headers
    headers = {
        "Authorization": f"Bearer {creds.token}",
        "Content-Type": "application/json",
    }

    if verbose:
        click.echo(f"{method.upper()} {url}", err=True)
        if params:
            click.echo(f"Query: {params}", err=True)
        if body:
            click.echo(f"Body: {json.dumps(body)}", err=True)
        click.echo("", err=True)

    # Make request
    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.request(
                method=method.upper(),
                url=url,
                params=params if params else None,
                json=body,
                headers=headers,
            )

        # Output response
        if verbose:
            click.echo(f"Status: {response.status_code}", err=True)
            click.echo("", err=True)

        # Try to parse as JSON
        try:
            result = response.json()
            if raw:
                click.echo(json.dumps(result))
            else:
                click.echo(json.dumps(result, indent=2))
        except json.JSONDecodeError:
            # Not JSON, output as text
            click.echo(response.text)

        # Exit with error code if not 2xx
        if not response.is_success:
            raise SystemExit(1)

    except httpx.RequestError as e:
        click.echo(f"Request failed: {e}", err=True)
        raise SystemExit(1)


@main.command()
@click.option("-f", "--follow", is_flag=True, help="Follow log output (like tail -f)")
@click.option("-n", "--lines", default=50, help="Number of lines to show (default: 50)")
def logs(follow: bool, lines: int):
    """View or follow the daemon log file.

    Reads from the daemon log file at /tmp/hivemind.log.
    On Linux with systemd, also checks journalctl.

    Examples:

        # View recent logs
        hivemind logs

        # Follow logs in real-time
        hivemind logs -f

        # Show last 100 lines
        hivemind logs -n 100
    """
    system = platform.system().lower()

    if system == "linux":
        _logs_linux(follow, lines)
    else:
        # macOS and others: use log file directly
        _logs_fallback(follow, lines)


def _logs_linux(follow: bool, lines: int):
    """View logs on Linux using journalctl or syslog."""
    # Try journalctl first (systemd)
    try:
        if follow:
            click.echo("Streaming logs (Ctrl+C to stop)...")
            click.echo("-" * 60)

            try:
                process = subprocess.Popen(
                    [
                        "journalctl",
                        "-t",
                        "hivemind",
                        "-f",
                        "--no-pager",
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )

                if process.stdout:
                    for line in process.stdout:
                        click.echo(line.rstrip())

            except KeyboardInterrupt:
                process.terminate()
                click.echo("\nStopped.")
        else:
            click.echo(f"Showing last {lines} log entries...")
            click.echo("-" * 60)

            result = subprocess.run(
                [
                    "journalctl",
                    "-t",
                    "hivemind",
                    "-n",
                    str(lines),
                    "--no-pager",
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode == 0 and result.stdout.strip():
                click.echo(result.stdout)
            else:
                click.echo("No journalctl entries found, checking syslog...")
                _logs_syslog(follow, lines)
        return

    except FileNotFoundError:
        # journalctl not available, try syslog
        _logs_syslog(follow, lines)


def _logs_syslog(follow: bool, lines: int):
    """View logs from /var/log/syslog on Linux."""
    syslog_paths = ["/var/log/syslog", "/var/log/messages"]

    for syslog_path in syslog_paths:
        if Path(syslog_path).exists():
            _tail_file(Path(syslog_path), follow, lines, filter_pattern="hivemind")
            return

    # No syslog found, fall back to our log file
    _logs_fallback(follow, lines)


def _get_log_file_path() -> Path | None:
    """Find the hivemind log file, checking multiple locations.

    Checks in order:
    1. HIVEMIND_LOG_FILE env var (if set explicitly)
    2. Platform-appropriate default from get_default_log_path()
    3. Homebrew managed location (macOS) - where brew services logs
    4. Legacy /tmp location (fallback for manual runs)

    If multiple log files exist, returns the most recently modified one
    to ensure we're showing the active daemon's logs.

    Returns:
        Path to log file if found, None otherwise.
    """
    candidates: list[Path] = []

    # If HIVEMIND_LOG_FILE is explicitly set, prioritize it
    env_log_file = os.environ.get("HIVEMIND_LOG_FILE")
    if env_log_file:
        env_path = Path(env_log_file)
        if env_path.exists():
            candidates.append(env_path)

    # Check platform-appropriate default path
    default_path = get_default_log_path()
    if default_path.exists() and default_path not in candidates:
        candidates.append(default_path)

    # Check Homebrew locations (where brew services logs)
    homebrew_paths = [
        Path("/opt/homebrew/var/log/hivemind.log"),  # Apple Silicon
        Path("/usr/local/var/log/hivemind.log"),  # Intel Mac
    ]
    for path in homebrew_paths:
        if path.exists() and path not in candidates:
            candidates.append(path)

    # Check legacy /tmp fallback (for manual runs without env var)
    tmp_log = Path("/tmp/hivemind.log")
    if tmp_log.exists() and tmp_log not in candidates:
        candidates.append(tmp_log)

    if not candidates:
        return None

    # Return the most recently modified log file
    return max(candidates, key=lambda p: p.stat().st_mtime)


def _logs_fallback(follow: bool, lines: int):
    """View logs from the fallback log file."""
    log_file = _get_log_file_path()

    if log_file is None:
        default_path = get_default_log_path()
        click.echo("No log file found. Checked:")
        click.echo(f"  - {default_path} (default)")
        click.echo("  - /opt/homebrew/var/log/hivemind.log (Homebrew Apple Silicon)")
        click.echo("  - /usr/local/var/log/hivemind.log (Homebrew Intel)")
        click.echo("  - /tmp/hivemind.log (legacy)")
        click.echo("\nThe daemon may not have been started yet.")
        return

    click.echo(f"Log file: {log_file}")
    _tail_file(log_file, follow, lines)


def _tail_file(file_path: Path, follow: bool, lines: int, filter_pattern: str | None = None):
    """Tail a log file, optionally filtering by pattern.

    Args:
        file_path: Path to the file to tail.
        follow: If True, follow the file like 'tail -f'.
        lines: Number of lines to show initially.
        filter_pattern: Optional pattern to filter lines.
    """
    if not file_path.exists():
        click.echo(f"File not found: {file_path}")
        return

    if follow:
        click.echo(f"Following {file_path} (Ctrl+C to stop)...")
        click.echo("-" * 60)

        try:
            # Build tail command
            cmd = ["tail", "-f", "-n", str(lines), str(file_path)]

            if filter_pattern:
                # Pipe through grep
                tail_proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )
                grep_proc = subprocess.Popen(
                    ["grep", "--line-buffered", filter_pattern],
                    stdin=tail_proc.stdout,
                    stdout=subprocess.PIPE,
                    text=True,
                )

                if grep_proc.stdout:
                    for line in grep_proc.stdout:
                        click.echo(line.rstrip())

                tail_proc.terminate()
                grep_proc.terminate()
            else:
                process = subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True)
                if process.stdout:
                    for line in process.stdout:
                        click.echo(line.rstrip())
                process.terminate()

        except KeyboardInterrupt:
            click.echo("\nStopped.")
    else:
        click.echo(f"Showing last {lines} lines from {file_path}...")
        click.echo("-" * 60)

        try:
            if filter_pattern:
                # grep then tail
                grep_proc = subprocess.Popen(
                    ["grep", filter_pattern, str(file_path)],
                    stdout=subprocess.PIPE,
                    text=True,
                )
                result = subprocess.run(
                    ["tail", "-n", str(lines)],
                    stdin=grep_proc.stdout,
                    capture_output=True,
                    text=True,
                )
                grep_proc.wait()
                if result.stdout:
                    click.echo(result.stdout.rstrip())
            else:
                result = subprocess.run(
                    ["tail", "-n", str(lines), str(file_path)],
                    capture_output=True,
                    text=True,
                )
                if result.stdout:
                    click.echo(result.stdout.rstrip())
        except FileNotFoundError:
            # tail/grep not available, read manually
            with open(file_path) as f:
                all_lines = f.readlines()
                if filter_pattern:
                    all_lines = [line for line in all_lines if filter_pattern in line]
                for line in all_lines[-lines:]:
                    click.echo(line.rstrip())


@main.command("install-service")
@click.option("--enable/--no-enable", default=True, help="Enable service to start on login")
@click.option("--uninstall", is_flag=True, help="Remove installed service file")
def install_service(enable: bool, uninstall: bool):
    """Install systemd user service (Linux only).

    Installs a systemd user unit file so hivemind starts automatically
    on login. On macOS, use 'brew services start wandb/taps/hivemind' instead.

    Examples:

        # Install and enable the service
        hivemind install-service

        # Install without enabling
        hivemind install-service --no-enable

        # Remove the service
        hivemind install-service --uninstall
    """
    import shutil

    system = platform.system().lower()

    if system == "darwin":
        click.echo("On macOS, use Homebrew to manage the hivemind service:")
        click.echo()
        click.echo("  brew services start wandb/taps/hivemind")
        click.echo("  brew services stop wandb/taps/hivemind")
        click.echo("  brew services restart wandb/taps/hivemind")
        return

    if system != "linux":
        click.echo(f"Service installation is not supported on {platform.system()}.")
        return

    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_file = unit_dir / "hivemind.service"

    if uninstall:
        # Stop and disable the service, then remove the unit file
        subprocess.run(
            ["systemctl", "--user", "stop", "hivemind"],
            capture_output=True,
        )
        subprocess.run(
            ["systemctl", "--user", "disable", "hivemind"],
            capture_output=True,
        )
        if unit_file.exists():
            unit_file.unlink()
            click.echo(f"Removed {unit_file}")
        else:
            click.echo("Service file not found, nothing to remove.")
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True,
        )
        click.echo("Hivemind service uninstalled.")
        return

    # Find the hivemind executable
    hivemind_bin = shutil.which("hivemind")
    if not hivemind_bin:
        click.echo("Error: Could not find 'hivemind' executable on PATH.", err=True)
        click.echo(
            "Install hivemind first (e.g., pip install hivemind or pipx install hivemind).",
            err=True,
        )
        raise SystemExit(1)

    # Generate unit file content with the actual executable path
    unit_content = f"""\
[Unit]
Description=Hivemind - Sync agentic coding sessions
Documentation=https://github.com/wandb/agentstream-py
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={hivemind_bin} run
ExecReload=/bin/kill -HUP $MAINPID
Restart=on-failure
RestartSec=10

# Logging - let journald handle it (hivemind also writes to file)
StandardOutput=journal
StandardError=journal
SyslogIdentifier=hivemind

# Security hardening (user service, minimal restrictions)
NoNewPrivileges=true

[Install]
WantedBy=default.target
"""

    # Write the unit file
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_file.write_text(unit_content)
    click.echo(f"Installed service file: {unit_file}")

    # Reload systemd
    result = subprocess.run(
        ["systemctl", "--user", "daemon-reload"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        click.echo(f"Warning: daemon-reload failed: {result.stderr.strip()}", err=True)

    if enable:
        result = subprocess.run(
            ["systemctl", "--user", "enable", "hivemind"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            click.echo("Service enabled (will start on login).")
        else:
            click.echo(f"Warning: enable failed: {result.stderr.strip()}", err=True)

    click.echo()
    click.echo("To start the service now:")
    click.echo("  systemctl --user start hivemind")
    click.echo()
    click.echo("To check status:")
    click.echo("  systemctl --user status hivemind")
    click.echo()
    click.echo("To view logs:")
    click.echo("  journalctl --user -t hivemind -f")


@main.command("web-sessions")
@click.option("--sync", "do_sync", is_flag=True, help="Sync unsynced web sessions now.")
def web_sessions(do_sync: bool):
    """List web sessions from Claude Code cloud.

    Shows sessions available in the cloud with their sync status.
    Web sessions are discovered from Claude Code web (claude.ai) using
    the same API as the --teleport feature.

    Requires Claude Code to be installed and authenticated with claude.ai.

    To configure web session syncing:
        hivemind config set web_sessions.enabled true
        hivemind config set web_sessions.poll_interval 900

    Examples:

        # List web sessions
        hivemind web-sessions

        # Sync unsynced web sessions now
        hivemind web-sessions --sync
    """
    from agentstream.remote import (
        WebSessionsClient,
        read_claude_credentials,
    )

    # Check for credentials
    if not has_claude_credentials():
        click.echo("\nNo Claude credentials found.")
        click.echo("Web sessions require Claude Code to be installed and authenticated.")
        click.echo("\nTo authenticate:")
        click.echo("  1. Install Claude Code: https://claude.ai/code")
        click.echo("  2. Run: claude login")
        return

    creds = read_claude_credentials()
    if not creds:
        click.echo("\nFailed to read Claude credentials.")
        return

    if creds.is_expired:
        click.echo("\nClaude credentials are expired.")
        click.echo("Please re-authenticate with: claude login")
        return

    # Load state to check sync status
    state_file = DEFAULT_STATE_FILE
    state = load_state(state_file) if state_file.exists() else DaemonState()
    config = load_config()
    endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(endpoint)
    server_state = state.get_server_state(base_endpoint)

    # Get synced session IDs (web sessions have "web:" prefix).
    # Only consider sessions with last_entry_idx >= 0 as synced — sessions with -1
    # had their initial upload fail or were skipped as trivial.
    synced_ids = {
        sid.replace("web:", "")
        for sid, ss in server_state.sessions.items()
        if sid.startswith("web:") and ss.last_entry_idx >= 0
    }

    # Fetch sessions
    click.echo("\nFetching web sessions from Claude API...")

    web_client = WebSessionsClient(credentials=creds)

    async def fetch_sessions():
        return await web_client.list_sessions(limit=50)

    try:
        sessions = asyncio.run(fetch_sessions())
    except Exception as e:
        click.echo(f"\nError fetching sessions: {e}", err=True)
        return

    if not sessions:
        click.echo("No web sessions found.")
        return

    # Show config status
    click.echo(
        f"\nWeb sync: {'enabled' if config.web_sessions.enabled else 'disabled'} "
        f"(poll every {config.web_sessions.poll_interval // 60} min)"
    )
    click.echo(f"\nWeb Sessions ({len(sessions)} total):")
    click.echo("-" * 72)

    for session in sessions:
        # Format timestamps
        updated = ""
        if session.updated_at:
            updated = session.updated_at.strftime("%Y-%m-%d %H:%M")
        elif session.created_at:
            updated = session.created_at.strftime("%Y-%m-%d %H:%M")

        # Sync status
        is_synced = session.id in synced_ids
        status = click.style("✓", fg="green") if is_synced else click.style("○", fg="yellow")

        # Session name (truncated)
        name = session.name or "(unnamed)"
        if len(name) > 28:
            name = name[:25] + "..."

        # Project path (truncated)
        project = session.project_path or ""
        if len(project) > 24:
            project = "..." + project[-21:]

        click.echo(f"  {status}  {updated}  {name:<28}  {project}")

    click.echo("-" * 72)
    synced_count = len([s for s in sessions if s.id in synced_ids])
    click.echo(f"  {synced_count}/{len(sessions)} sessions synced")

    if not config.web_sessions.enabled:
        click.echo("\n  To enable web sync: hivemind config set web_sessions.enabled true")

    # Manual sync
    if do_sync:
        unsynced = [s for s in sessions if s.id not in synced_ids]
        if not unsynced:
            click.echo("\nAll sessions already synced.")
            return

        # Load hivemind credentials for backend auth
        auth = AuthManager(endpoint=base_endpoint)
        hm_creds = auth.store.load(auth.endpoint)
        if not hm_creds:
            click.echo("\nNot authenticated with AgentStream. Run: hivemind login", err=True)
            return

        syncer = _create_web_syncer(hm_creds, endpoint, state, web_client)

        click.echo(f"\nSyncing {len(unsynced)} sessions...")

        async def run_sync():
            from hivemind.remote.web_sync import sync_web_sessions

            return await sync_web_sessions(unsynced, syncer)

        try:
            stats = asyncio.run(run_sync())
            click.echo(
                f"  Done: {stats['success']} synced, {stats['failed']} failed "
                f"(of {stats['total']} total)"
            )
            # Save state so daemon picks up the new sync positions
            save_state(state, state_file)
        except Exception as e:
            click.echo(f"\nSync error: {e}", err=True)


# =============================================================================
# Dev mode exec and hupper support
# =============================================================================


def _maybe_exec_dev_mode() -> None:
    """Check for dev mode configuration and re-exec using the dev repo Python.

    This function is called early in the 'run' command to allow the Homebrew-installed
    daemon to transparently switch to using the development repo code.

    The flow is:
    1. Check if HIVEMIND_DEV_MODE=1 env var is set (already re-exec'd)
    2. Load config and check for dev.repo setting
    3. Validate the dev repo path
    4. If valid, exec to the dev Python with updated PYTHONPATH

    This uses os.execve() to replace the current process (same PID), which is
    important for launchd/brew services compatibility.
    """
    # Skip if already re-exec'd (prevents infinite loop)
    if os.environ.get("HIVEMIND_DEV_MODE") == "1":
        return

    # Load config to check for dev.repo
    config = load_config()
    dev_repo = config.dev.repo
    if not dev_repo:
        return

    # Validate the dev repo path
    is_valid, message = validate_dev_repo(dev_repo)
    if not is_valid:
        logger.warning(f"Dev mode disabled: {message}")
        return

    # Build paths for the dev repo
    dev_repo_path = Path(dev_repo).expanduser().resolve()
    dev_python = dev_repo_path / ".venv" / "bin" / "python"
    daemon_src = dev_repo_path / "daemon" / "src"

    # Build new environment with dev mode flag and PYTHONPATH
    new_env = os.environ.copy()
    new_env["HIVEMIND_DEV_MODE"] = "1"

    # Set PYTHONPATH to include both daemon/src and the repo root (for agentstream)
    pythonpath_parts = [str(daemon_src), str(dev_repo_path)]
    existing_pythonpath = os.environ.get("PYTHONPATH")
    if existing_pythonpath:
        pythonpath_parts.append(existing_pythonpath)
    new_env["PYTHONPATH"] = os.pathsep.join(pythonpath_parts)

    # Build the command line args: python -m hivemind.cli <original args>
    # sys.argv[0] is typically 'hivemind' or the script path
    # We want to pass all the original arguments after the command name
    new_args = [str(dev_python), "-m", "hivemind.cli"] + sys.argv[1:]

    # Log before exec (this is the last thing that runs in the original process)
    click.echo(f"Dev mode: switching to {dev_repo_path}")

    # Replace the current process with the dev Python
    os.execve(str(dev_python), new_args, new_env)


def _run_with_hupper(dev_repo: str) -> bool:
    """Set up hupper process supervisor for dev mode.

    This function is called when running in dev mode (HIVEMIND_DEV_MODE=1) to
    enable manual restart via 'hivemind hup' command.

    Note: Automatic file watching is disabled. Use 'hivemind hup' to manually
    trigger a reload after making code changes.

    Args:
        dev_repo: Path to the dev repo checkout.

    Returns:
        True if hupper started a reloader (caller should return immediately).
        False if already in a hupper worker process (caller should continue).
    """
    try:
        import hupper
    except ImportError:
        click.echo(
            "Warning: 'hupper' package not installed. Manual reload disabled.",
            err=True,
        )
        return False

    # Check if we're already in a reloader worker process
    if hupper.is_active():
        return False

    click.echo("Starting dev server (use 'hivemind hup' to reload after code changes)...")

    # Start the reloader, which will re-exec this process
    # Note: We intentionally do NOT watch files for automatic reload.
    # Use 'hivemind hup' to manually trigger a reload.
    hupper.start_reloader(
        "hivemind.cli.main",
        reload_interval=1,
    )

    # Return True to indicate caller should return (hupper takes over)
    return True


# =============================================================================
# Config command group
# =============================================================================


def _get_endpoint_source(config_path: Path) -> str:
    """Determine the source of the effective endpoint value.

    Args:
        config_path: Path to the config file.

    Returns:
        Source string: "dev mode", "config file", "env var", or "default".
    """
    import tomllib

    # Check runtime override first (--dev flag)
    if get_endpoint_override() is not None:
        return "dev mode"

    # Check config file (highest priority after override)
    if config_path.exists():
        try:
            with open(config_path, "rb") as f:
                data = tomllib.load(f)
            file_endpoint = data.get("server", {}).get("endpoint")
            if file_endpoint and file_endpoint != CONFIG_DEFAULTS.get("server.endpoint"):
                return "config file"
        except Exception:
            pass

    # Check environment variable
    if os.environ.get("HIVEMIND_ENDPOINT"):
        return "env var"

    return "default"


def _signal_daemon_reload() -> bool:
    """Signal running daemon to reload config via SIGHUP.

    Reads PID from lock file and sends SIGHUP signal.
    Returns True if signal was sent, False otherwise.
    """
    lock_file = DEFAULT_LOCK_FILE

    if not lock_file.exists():
        return False

    try:
        pid = int(lock_file.read_text().strip())
        os.kill(pid, signal.SIGHUP)
        return True
    except (ValueError, ProcessLookupError, PermissionError, OSError):
        return False


# List of valid config keys for error messages
VALID_CONFIG_KEYS = [
    "server.endpoint",
    "server.auth_method",
    "dev.repo",
    "dev.debug",
    "web_sessions.enabled",
    "web_sessions.poll_interval",
    "import.max_age_days",
    "sessions.private",
    "sessions.org_repos",
    "sessions.private_repos",
]

# Config keys that hold lists (comma-separated on input, stored as TOML arrays)
LIST_CONFIG_KEYS = {"sessions.org_repos", "sessions.private_repos"}

# Default values for config keys (for showing in config show)
CONFIG_DEFAULTS: dict[str, Any] = {
    "server.endpoint": "https://hivemind.wandb.tools",
    "dev.repo": None,
    "dev.debug": False,
    "web_sessions.enabled": True,
    "web_sessions.poll_interval": 1800,
    "import.max_age_days": 90,
    "sessions.private": False,
    "sessions.org_repos": [],
    "sessions.private_repos": [],
}


def _check_claude_cli() -> bool:
    """Check if the Claude CLI is available and logged in."""
    # Cannot nest Claude Code sessions
    if os.environ.get("CLAUDECODE"):
        return False
    try:
        result = subprocess.run(
            ["claude", "auth", "status"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            data = json.loads(result.stdout)
            return data.get("loggedIn", False)
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError):
        pass
    return False


def _check_codex_cli() -> bool:
    """Check if the Codex CLI is available and logged in."""
    try:
        result = subprocess.run(
            ["codex", "login", "status"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return "Logged in" in result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return False


def _check_cursor_cli() -> bool:
    """Check if the Cursor Agent CLI is available and authenticated."""
    try:
        # --version only checks install, not auth. Run a trivial prompt
        # in print mode to verify the agent can actually start.
        result = subprocess.run(
            ["cursor-agent", "-p", "say ok"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def _find_llm_provider() -> str:
    """Find an available LLM provider.

    Checks in order: Claude CLI, Codex CLI, Cursor Agent CLI.
    Returns "claude-cli", "codex-cli", or "cursor-cli", or raises SystemExit.
    """
    if _check_claude_cli():
        return "claude-cli"

    if _check_codex_cli():
        return "codex-cli"

    if _check_cursor_cli():
        return "cursor-cli"

    click.echo(
        "  Error: No agent CLI available for smart merge.\n"
        "  Install and log in to one of:\n"
        "    1. Claude Code    — claude auth login\n"
        "    2. Codex CLI      — codex login\n"
        "    3. Cursor Agent   — cursor-agent login",
        err=True,
    )
    raise SystemExit(1)


def _llm_merge_cli(provider: str, suggested_content: str, file_path: Path) -> bool:
    """Use an agent CLI to merge a suggestion directly into a file.

    The CLI agent reads the file itself, merges the suggestion, and writes it back.
    Returns True if the file was modified.
    """
    prompt = (
        f"Read the file {file_path} and merge the following suggestion into it. "
        f"If the suggestion is already covered (even if worded differently), "
        f"leave the file unchanged. Otherwise, find the best section to place it "
        f"and match the existing formatting style.\n\n"
        f"SUGGESTION TO MERGE IN:\n{suggested_content}"
    )

    if provider == "claude-cli":
        cmd = [
            "claude",
            "-p",
            "--model",
            "sonnet",
            "--permission-mode",
            "bypassPermissions",
            "--allowedTools",
            "Edit,Read",
        ]
        # If file is outside cwd, grant access to its parent directory
        try:
            file_path.relative_to(Path.cwd())
        except ValueError:
            cmd.extend(["--add-dir", str(file_path.parent)])
        result = subprocess.run(
            cmd,
            input=prompt,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            raise SystemExit(1)
    elif provider == "codex-cli":
        result = subprocess.run(
            ["codex", "exec", "--full-auto", prompt],
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            raise SystemExit(1)
    elif provider == "cursor-cli":
        result = subprocess.run(
            ["cursor-agent", "-p", "--force", prompt],
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            raise SystemExit(1)

    return True


@main.group()
def insights():
    """Manage contextual intelligence suggestions."""
    pass


@insights.command("list")
@click.option("--status", type=click.Choice(["pending", "applied", "dismissed"]), default="pending")
@click.option(
    "--repo", default=None, help="Filter by git repo (defaults to current directory's repo)"
)
def insights_list(status: str, repo: str | None):
    """List insights suggestions for the current project."""
    import httpx

    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo("Error: Not authenticated. Run 'hivemind login' first.", err=True)
        raise SystemExit(1)

    # Auto-detect git repo if not specified
    if repo is None:
        detected = resolve_git_repo(Path.cwd())
        if detected:
            repo = detected

    headers = {
        "Authorization": f"Bearer {creds.token}",
        "Content-Type": "application/json",
    }

    params: dict[str, str] = {"status": status, "limit": "50"}
    if repo:
        params["git_repo"] = repo

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                f"{base_endpoint}/v1/insights/items",
                params=params,
                headers=headers,
            )

        if not response.is_success:
            click.echo(f"Error: {response.status_code} {response.text}", err=True)
            raise SystemExit(1)

        data = response.json()
        items = data.get("items", [])

        if not items:
            click.echo(f"No {status} suggestions found.")
            if repo:
                click.echo(f"  (filtered to repo: {repo})")
            return

        # Group by repo
        by_repo: dict[str, list] = {}
        for item in items:
            r = item.get("git_repo", "Unknown")
            if r not in by_repo:
                by_repo[r] = []
            by_repo[r].append(item)

        for repo_name, repo_items in by_repo.items():
            click.echo(f"\n  Insights — {repo_name}")
            click.echo(f"  {len(repo_items)} {status} suggestion(s)\n")

            for i, item in enumerate(repo_items, 1):
                category = item.get("category", "").capitalize()
                title = item.get("title", "")
                confidence = item.get("confidence", 0)
                evidence = item.get("evidence_count", 0)
                apply_cmd = item.get("apply_command", "")

                conf_label = (
                    "High" if confidence >= 0.8 else "Medium" if confidence >= 0.5 else "Low"
                )

                click.echo(
                    f"  {i}. [{category}] {title} ({conf_label} confidence, {evidence} sessions)"
                )
                if apply_cmd and status == "pending":
                    click.secho(f"     $ {apply_cmd}", fg="cyan")
                click.echo()

    except httpx.RequestError as e:
        click.echo(f"Request failed: {e}", err=True)
        raise SystemExit(1)


AGENT_CONTEXT_FILES: dict[str, dict[str, list[str]]] = {
    "claude": {
        "project": ["CLAUDE.md", "AGENTS.md"],
        "personal": ["~/.claude/CLAUDE.md"],
    },
    "cursor": {
        "project": [".cursorrules", ".cursor/rules"],
        "personal": [".cursorrules"],
    },
    "codex": {
        "project": ["AGENTS.md", "codex.md"],
        "personal": ["~/.codex/AGENTS.md"],
    },
    "generic": {
        "project": ["AGENTS.md"],
        "personal": ["AGENTS.md"],
    },
}


def _resolve_context_file(scope: str) -> Path | None:
    """Ask the user which agent and find the appropriate context file."""
    agents = ["claude", "cursor", "codex", "generic"]
    click.echo("\n  Which agent is this for?")
    for i, agent in enumerate(agents, 1):
        click.echo(f"    {i}. {agent.capitalize()}")

    choice = click.prompt("  Choice", type=int, default=1)
    if choice < 1 or choice > len(agents):
        click.echo("  Invalid choice.", err=True)
        return None
    agent = agents[choice - 1]

    candidates = AGENT_CONTEXT_FILES[agent].get(scope, AGENT_CONTEXT_FILES[agent]["project"])

    # Resolve paths: ~ expands to home dir, others are relative to cwd
    cwd = Path.cwd()
    for candidate in candidates:
        path = Path(candidate).expanduser() if candidate.startswith("~") else cwd / candidate
        if path.exists():
            click.echo(f"  Found existing: {path}")
            return path

    # No existing file — use first candidate
    first = candidates[0]
    target = Path(first).expanduser() if first.startswith("~") else cwd / first
    click.echo(f"  Will create: {target}")
    return target


@insights.command("apply")
@click.argument("suggestion_id")
@click.option("--yes", "-y", is_flag=True, help="Apply without confirmation")
def insights_apply(suggestion_id: str, yes: bool):
    """Apply a suggestion to a context file.

    SUGGESTION_ID is the short ID from 'hivemind insights list'.
    Interactively asks which agent and finds the appropriate context file.
    """
    import httpx

    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo("Error: Not authenticated. Run 'hivemind login' first.", err=True)
        raise SystemExit(1)

    headers = {
        "Authorization": f"Bearer {creds.token}",
        "Content-Type": "application/json",
    }

    # Fetch suggestion details
    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                f"{base_endpoint}/v1/insights/items",
                params={"status": "pending", "limit": "200"},
                headers=headers,
            )

        if not response.is_success:
            click.echo(f"Error fetching suggestions: {response.status_code}", err=True)
            raise SystemExit(1)

        data = response.json()
        items = data.get("items", [])

        matching = [item for item in items if item.get("item_id", "").startswith(suggestion_id)]

        if not matching:
            click.echo(f"No pending suggestion found matching '{suggestion_id}'", err=True)
            raise SystemExit(1)
        if len(matching) > 1:
            click.echo(
                f"Ambiguous ID '{suggestion_id}' matches {len(matching)} items. Use a longer prefix.",
                err=True,
            )
            raise SystemExit(1)

        item = matching[0]

    except httpx.RequestError as e:
        click.echo(f"Request failed: {e}", err=True)
        raise SystemExit(1)

    # Get the suggestion content
    item_content = item.get("content", {})
    suggested_content = item_content.get("suggested_content", "")
    reasoning = item_content.get("reasoning", "")
    scope = item_content.get("scope", "project")

    if not suggested_content:
        click.echo("Error: Suggestion has no content to apply.", err=True)
        raise SystemExit(1)

    click.echo(f"\n  Suggestion: {item.get('title', '')}")
    click.echo(f"  Category:   {item.get('category', '').capitalize()}")
    click.echo(f"  Scope:      {scope.capitalize()}")
    if reasoning:
        reason_lines = textwrap.wrap(
            reasoning, width=68, initial_indent="  Reason:     ", subsequent_indent="              "
        )
        for rl in reason_lines:
            click.echo(rl)

    inner_width = 68
    click.echo("\n  Content:")
    click.echo(f"  ┌{'─' * inner_width}┐")
    for line in suggested_content.split("\n"):
        wrapped = textwrap.wrap(line, width=inner_width - 2) or [""]
        for wl in wrapped:
            click.echo(f"  │ {wl:<{inner_width - 2}} │")
    click.echo(f"  └{'─' * inner_width}┘")

    # Ask where to apply
    target_path = _resolve_context_file(scope)
    if not target_path:
        return

    try:
        target_file = str(target_path.relative_to(Path.cwd()))
    except ValueError:
        # Path is outside cwd (e.g. ~/.claude/CLAUDE.md)
        target_file = str(target_path)

    # Use LLM to intelligently merge
    provider = _find_llm_provider()
    provider_labels = {
        "claude-cli": "Claude CLI",
        "codex-cli": "Codex CLI",
        "cursor-cli": "Cursor Agent",
    }
    provider_label = provider_labels.get(provider, provider.split("/")[-1])
    click.echo(f"  Merging with AI ({provider_label})...")

    # Snapshot file before merge
    current_content = target_path.read_text() if target_path.exists() else ""

    # CLI agents read and edit the file themselves
    target_path.parent.mkdir(parents=True, exist_ok=True)
    if not target_path.exists():
        target_path.write_text("")
    _llm_merge_cli(provider, suggested_content, target_path)
    new_content = target_path.read_text()

    # Show diff
    diff_lines = list(
        difflib.unified_diff(
            current_content.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{target_file}",
            tofile=f"b/{target_file}",
            n=3,
        )
    )
    if diff_lines:
        click.echo()
        for line in diff_lines:
            line = line.rstrip("\n")
            if line.startswith("+") and not line.startswith("+++"):
                click.secho(f"  {line}", fg="green")
            elif line.startswith("-") and not line.startswith("---"):
                click.secho(f"  {line}", fg="red")
            else:
                click.echo(f"  {line}")
        click.echo()
    else:
        click.echo("  No changes needed — suggestion is already covered. Resolving.")
        try:
            with httpx.Client(timeout=30.0) as client:
                resp = client.patch(
                    f"{base_endpoint}/v1/insights/items/{item['item_id']}",
                    json={"status": "applied"},
                    headers=headers,
                )
                resp.raise_for_status()
        except Exception as exc:
            click.echo(f"  Warning: failed to mark suggestion as applied: {exc}", err=True)
        return

    # Mark as applied via API
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.patch(
                f"{base_endpoint}/v1/insights/items/{item['item_id']}",
                json={"status": "applied"},
                headers=headers,
            )
            resp.raise_for_status()
    except Exception as exc:
        click.echo(f"  Warning: failed to mark suggestion as applied: {exc}", err=True)

    click.echo(f"  Applied to {target_file}")


@main.group()
def config():
    """View and manage configuration settings."""
    pass


def _get_config_source(key: str, config_path: Path) -> str:
    """Determine the source of a config value.

    Args:
        key: The config key (e.g., "server.endpoint").
        config_path: Path to the config file.

    Returns:
        Source string: one of "dev mode", "config file", "env var", or "default".
        "env var" and "dev mode" are only used for the "server.endpoint" key; other
        keys return either "config file" or "default".
    """
    import tomllib

    # Special handling for server.endpoint (supports env var and dev mode)
    if key == "server.endpoint":
        return _get_endpoint_source(config_path)

    # For other keys, check if they're explicitly set in the config file
    # to a non-default value
    if config_path.exists():
        try:
            with open(config_path, "rb") as f:
                data = tomllib.load(f)

            # Navigate the dotted path
            parts = key.split(".")
            current = data
            for part in parts[:-1]:
                current = current.get(part, {})

            if parts[-1] in current:
                # Key exists in config file — only report "config file" if
                # the value differs from the default
                file_value = current[parts[-1]]
                default_value = CONFIG_DEFAULTS.get(key)
                if file_value != default_value:
                    return "config file"
        except Exception:
            # If the config file cannot be read or parsed, treat it as absent
            # and fall back to reporting the value as coming from "default".
            pass

    return "default"


@config.command("show")
def config_show():
    """Show current configuration.

    Displays all configuration values with their sources
    (config file, environment variable, or default).

    Examples:

        hivemind config show
    """
    from rich.console import Console
    from rich.text import Text

    console = Console()
    config_path = DEFAULT_CONFIG_PATH
    cfg = load_config(config_path)

    console.print("[bold]Configuration:[/bold]")

    for key in VALID_CONFIG_KEYS:
        # Get effective value
        if key == "server.endpoint":
            value = get_effective_endpoint(config_path)
        else:
            value = get_value(key, cfg)

        # Get source
        source = _get_config_source(key, config_path)

        # Build styled output
        line = Text()
        line.append("  ")
        line.append(key, style="cyan")
        line.append(" = ")

        # Format and style value
        if value is None:
            line.append("(not set)", style="dim")
        elif isinstance(value, list):
            if value:
                line.append(", ".join(value), style="yellow")
            else:
                line.append("[]", style="dim")
        elif isinstance(value, bool):
            line.append(str(value).lower(), style="green" if value else "red")
        elif isinstance(value, int):
            line.append(str(value), style="magenta")
        else:
            line.append(str(value), style="yellow")

        # Only show source label for defaults
        if source == "default":
            line.append("  (default)", style="dim italic")

        console.print(line)

    console.print()
    console.print(f"[bold]Config file:[/bold] {config_path}")
    if config_path.exists():
        console.print("  Status: [green]exists[/green]")
    else:
        console.print("  Status: [dim]not created (using defaults)[/dim]")


@config.command("get")
@click.argument("key")
def config_get(key: str):
    """Get a configuration value by key.

    KEY is the dotted path to the configuration value (e.g., server.endpoint).

    Outputs just the value for easy scripting. Exits with code 1 if key not found.

    Examples:

        # Get the endpoint URL
        hivemind config get server.endpoint

        # Use in scripts
        ENDPOINT=$(hivemind config get server.endpoint)
    """
    config_path = DEFAULT_CONFIG_PATH

    # For server.endpoint, use the effective endpoint (respects priority chain)
    if key == "server.endpoint":
        click.echo(get_effective_endpoint(config_path))
        return

    # For other keys, load config and get value
    cfg = load_config(config_path)
    try:
        value = get_value(key, cfg)
        if isinstance(value, list):
            click.echo(",".join(value) if value else "")
        else:
            click.echo(value)
    except KeyError:
        click.echo(f"Unknown config key: {key}", err=True)
        click.echo(f"Valid keys: {', '.join(VALID_CONFIG_KEYS)}", err=True)
        raise SystemExit(1)


@config.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str):
    """Set a configuration value.

    KEY is the dotted path to the configuration value (e.g., server.endpoint).
    VALUE is the new value to set.

    Updates the config file (creates it if needed) and signals the running
    daemon to reload configuration via SIGHUP.

    Examples:

        # Set a custom endpoint
        hivemind config set server.endpoint https://custom.example.com

        # Reset to default by setting the default value
        hivemind config set server.endpoint https://hivemind.wandb.tools
    """
    config_path = DEFAULT_CONFIG_PATH

    # Coerce string values to the appropriate type
    config_value: str | bool | int | list[str] = value
    if key in ("dev.debug", "web_sessions.enabled", "sessions.private"):
        config_value = value.lower() in ("true", "1", "yes")
    elif key in ("web_sessions.poll_interval", "import.max_age_days"):
        try:
            config_value = int(value)
        except ValueError:
            click.echo(f"Invalid integer value for {key}: {value}", err=True)
            raise SystemExit(1)
    elif key in LIST_CONFIG_KEYS:
        # Comma-separated string → list (empty string clears the list)
        if value.strip() == "":
            config_value = []
        else:
            config_value = [v.strip() for v in value.split(",") if v.strip()]

    # Update the single value while preserving unknown keys
    try:
        update_config(key, config_value, config_path)
    except KeyError:
        click.echo(f"Unknown config key: {key}", err=True)
        click.echo(f"Valid keys: {', '.join(VALID_CONFIG_KEYS)}", err=True)
        raise SystemExit(1)

    click.echo(f"Set {key} = {config_value}")
    click.echo(f"Saved to {config_path}")

    # Signal daemon to reload
    if _signal_daemon_reload():
        click.echo("Sent SIGHUP to running daemon.")
        click.echo("Note: Daemon will reload config if it has a SIGHUP handler.")
    else:
        click.echo("No running daemon found (or could not signal).")


@config.command("add")
@click.argument("key")
@click.argument("value")
def config_add(key: str, value: str):
    """Add a value to a list configuration key.

    KEY must be a list config key (sessions.org_repos or sessions.private_repos).
    VALUE is the repo to add (e.g., "github.com/org/repo" or "org/repo").

    Examples:

        # Always share a repo with your org (overrides global private)
        hivemind config add sessions.org_repos github.com/myorg/public-repo

        # Always keep a repo private
        hivemind config add sessions.private_repos myorg/secret-repo
    """
    config_path = DEFAULT_CONFIG_PATH

    if key not in LIST_CONFIG_KEYS:
        click.echo(
            f"'config add' only works with list keys: {', '.join(sorted(LIST_CONFIG_KEYS))}",
            err=True,
        )
        raise SystemExit(1)

    cfg = load_config(config_path)
    current: list[str] = get_value(key, cfg)
    value = value.strip()

    # Check for duplicates using normalized matching (not just verbatim)
    if value in current:
        click.echo(f"'{value}' is already in {key}")
        return
    for existing in current:
        if repo_matches(value, [existing]):
            click.echo(f"'{value}' already matches existing entry '{existing}' in {key}")
            return

    # Warn if the repo is in the opposite list
    opposite_key = "sessions.private_repos" if key == "sessions.org_repos" else "sessions.org_repos"
    opposite: list[str] = get_value(opposite_key, cfg)
    if repo_matches(value, opposite):
        click.echo(
            f"Warning: '{value}' also matches an entry in {opposite_key}. "
            f"{'private_repos' if 'private' in opposite_key else 'org_repos'} takes precedence.",
            err=True,
        )

    current.append(value)
    update_config(key, current, config_path)
    click.echo(f"Added '{value}' to {key}")
    click.echo(f"Current list: {', '.join(current)}")

    if _signal_daemon_reload():
        click.echo("Sent SIGHUP to running daemon.")
    else:
        click.echo("No running daemon found (or could not signal).")


@config.command("remove")
@click.argument("key")
@click.argument("value")
def config_remove(key: str, value: str):
    """Remove a value from a list configuration key.

    KEY must be a list config key (sessions.org_repos or sessions.private_repos).
    VALUE is the repo to remove.

    Examples:

        hivemind config remove sessions.org_repos github.com/myorg/public-repo
    """
    config_path = DEFAULT_CONFIG_PATH

    if key not in LIST_CONFIG_KEYS:
        click.echo(
            f"'config remove' only works with list keys: {', '.join(sorted(LIST_CONFIG_KEYS))}",
            err=True,
        )
        raise SystemExit(1)

    cfg = load_config(config_path)
    current: list[str] = get_value(key, cfg)
    value = value.strip()

    # Find the entry to remove using normalized matching (not just verbatim)
    match = None
    if value in current:
        match = value
    else:
        for existing in current:
            if repo_matches(value, [existing]):
                match = existing
                break

    if match is None:
        click.echo(f"'{value}' is not in {key}", err=True)
        click.echo(f"Current list: {', '.join(current) if current else '(empty)'}", err=True)
        raise SystemExit(1)

    current.remove(match)
    update_config(key, current, config_path)
    click.echo(f"Removed '{value}' from {key}")
    if current:
        click.echo(f"Current list: {', '.join(current)}")
    else:
        click.echo(f"{key} is now empty")

    if _signal_daemon_reload():
        click.echo("Sent SIGHUP to running daemon.")
    else:
        click.echo("No running daemon found (or could not signal).")


@config.command("reset")
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    help="Skip confirmation prompt",
)
def config_reset(yes: bool):
    """Reset configuration to defaults.

    Removes the config file, causing all settings to revert to defaults.
    Use --yes/-y to skip the confirmation prompt.

    Examples:

        # Reset with confirmation
        hivemind config reset

        # Reset without confirmation
        hivemind config reset -y
    """
    config_path = DEFAULT_CONFIG_PATH

    if not config_path.exists():
        click.echo("No config file exists. Already using defaults.")
        return

    if not yes:
        click.confirm(
            f"Remove config file at {config_path}? This will reset all settings to defaults",
            abort=True,
        )

    try:
        config_path.unlink()
        click.echo(f"Removed {config_path}")
        click.echo("Configuration reset to defaults.")

        # Signal daemon to reload
        if _signal_daemon_reload():
            click.echo("Sent SIGHUP to running daemon.")
            click.echo("Note: Daemon will reload config if it has a SIGHUP handler.")
    except OSError as e:
        click.echo(f"Error removing config file: {e}", err=True)
        raise SystemExit(1)


@config.command("path")
def config_path():
    """Show the config file path.

    Useful for debugging or locating the config file.

    Examples:

        hivemind config path
    """
    click.echo(DEFAULT_CONFIG_PATH)


@config.command("reset-server")
@click.argument("server")
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    help="Skip confirmation prompt",
)
@click.option(
    "--state-dir",
    type=click.Path(),
    default=str(DEFAULT_STATE_DIR),
    help="State directory (default: ~/.hivemind)",
)
def config_reset_server(server: str, yes: bool, state_dir: str):
    """Reset sync state for a specific server.

    SERVER is the endpoint URL (e.g., http://localhost:8080).

    This removes all tracked session state for the specified server from
    the state file, causing the daemon to re-import all sessions on next
    sync. Useful when you've blown away your local dev database.

    This does NOT delete your sessions from the server - it only clears
    the local tracking state.

    Examples:

        # Reset localhost dev server state
        hivemind config reset-server http://localhost:8080

        # Skip confirmation
        hivemind config reset-server http://localhost:8080 -y
    """
    state_path = Path(state_dir)
    state_file = state_path / "state.json"

    if not state_file.exists():
        click.echo(f"No state file found at {state_file}", err=True)
        raise SystemExit(1)

    # Load state
    state = load_state(state_file)

    # Normalize the server URL for lookup
    normalized = _normalize_endpoint(server)

    # Check if server exists in state
    if normalized not in state.servers:
        click.echo(f"Error: No state found for server '{normalized}'", err=True)
        click.echo("\nKnown servers:", err=True)
        if state.servers:
            for endpoint in sorted(state.servers.keys()):
                server_state = state.servers[endpoint]
                click.echo(f"  - {endpoint} ({len(server_state.sessions)} sessions)", err=True)
        else:
            click.echo("  (none)", err=True)
        raise SystemExit(1)

    # Show what will be deleted
    server_state = state.servers[normalized]
    session_count = len(server_state.sessions)
    click.echo(f"Server: {normalized}")
    click.echo(f"  Sessions tracked: {session_count}")
    click.echo(
        f"  Historic import: {'completed' if server_state.historic_import_completed else 'not done'}"
    )

    if not yes:
        click.confirm(
            f"\nReset all sync state for '{normalized}'? "
            "This will cause sessions to be re-imported on next sync",
            abort=True,
        )

    # Delete the server state
    del state.servers[normalized]

    # Save state
    save_state(state, state_file)

    click.echo(f"\n✓ Removed state for '{normalized}' ({session_count} sessions cleared)")
    click.echo("The daemon will re-import sessions on next sync cycle.")


@main.command("install-agent")
@click.option("--force", is_flag=True, help="Overwrite even if already at current version")
def install_agent_cmd(force: bool):
    """Install the @hivemind agent for supported platforms.

    Writes the agent definition to <platform>/agents/wandb-hivemind.md for each
    platform directory (~/.claude, ~/.codex, ~/.cursor) that exists on disk.

    The agent is automatically updated when a newer version is available.
    """
    from hivemind.agent import AGENT_VERSION, _AGENT_FILENAME, _PLATFORM_DIRS, install_agent

    written = install_agent(force=force)
    if written:
        targets = [
            f"~/{d.name}/agents/{_AGENT_FILENAME}"
            for d in _PLATFORM_DIRS
            if (d / "agents" / _AGENT_FILENAME).exists()
        ]
        click.echo(f"Installed @hivemind agent v{AGENT_VERSION} to:")
        for t in targets:
            click.echo(f"  {t}")
    else:
        has_any = any(d.is_dir() for d in _PLATFORM_DIRS)
        if not has_any:
            click.echo("No supported platform found (~/.claude, ~/.codex, ~/.cursor).")
            click.echo("Install Claude Code, Codex, or Cursor first, then re-run this command.")
            raise SystemExit(1)
        click.echo(f"@hivemind agent is already at v{AGENT_VERSION}")


@main.command("uninstall-agent")
def uninstall_agent_cmd():
    """Remove the @hivemind agent from all platforms.

    Removes wandb-hivemind.md from each platform's agents directory.
    Only removes files that were installed by hivemind (verified by content).
    """
    from hivemind.agent import _AGENT_FILENAME, _PLATFORM_DIRS, uninstall_agent

    # Capture which agent files exist before uninstall so we only report those
    existing_targets = [
        f"~/{d.name}/agents/{_AGENT_FILENAME}"
        for d in _PLATFORM_DIRS
        if (d / "agents" / _AGENT_FILENAME).exists()
    ]

    removed = uninstall_agent()
    if removed:
        click.echo("Removed @hivemind agent from:")
        for target in existing_targets:
            click.echo(f"  {target}")
    else:
        click.echo("No @hivemind agent files found to remove.")


@main.command("search")
@click.argument("query", required=False, default=None)
@click.option("--limit", default=5, help="Maximum sessions to return (default: 5)")
@click.option(
    "--repo",
    default=None,
    help='Filter by git repository. Auto-detected from git remote if not specified. Pass "all" to disable filtering.',
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["json", "markdown"]),
    default="markdown",
    help="Output format (default: markdown)",
)
@click.option(
    "--include-transcript/--no-transcript",
    default=True,
    help="Include session transcripts (default: true)",
)
@click.option(
    "--event-types",
    default=None,
    help=(
        "Comma-separated event categories to include in transcript (default: user,assistant). "
        "Categories: user (prompts), assistant (responses), reasoning (thinking blocks), "
        "tools (tool calls with args and results), files (file read/write with content/diffs), "
        'errors (error events). Use "all" to include everything.'
    ),
)
@click.option(
    "--verbose/--no-verbose",
    default=False,
    help="Show all intermediate assistant messages per turn, not just the final response (default: false)",
)
@click.option(
    "--users",
    default="me",
    help='Filter by user. "me" = authenticated user, "all" = no filter, or a username. (default: me)',
)
@click.option(
    "--org",
    "org_id",
    default=None,
    help="Organization ID to scope the search to (sets X-Org-Id header).",
)
@click.option(
    "--order",
    default=None,
    help=(
        "Sort order: relevance (default with query), started_at, last_activity_at. "
        "Prefix with +/- for ASC/DESC (default DESC)."
    ),
)
@click.option(
    "--subagents/--no-subagents",
    default=None,
    help="Filter sub-agent sessions. --subagents = only sub-agents, --no-subagents = exclude them. (default: all)",
)
@click.pass_context
def search(
    ctx: click.Context,
    query: str | None,
    limit: int,
    repo: str | None,
    output_format: str,
    include_transcript: bool,
    event_types: str | None,
    verbose: bool,
    users: str,
    org_id: str | None,
    order: str | None,
    subagents: bool | None,
):
    """Search previous coding sessions or list recent sessions.

    Returns session transcripts formatted for LLM consumption with
    metadata about modified files, tool usage, and decisions made.

    When QUERY is omitted, lists sessions by last activity (list mode).

    By default, results are filtered to the authenticated user (--users me)
    and the current git repository (auto-detected from the git remote URL).
    Use --users all to search across all users, or --repo all to search
    across all repositories.

    QUERY uses the hivemind search syntax:

    \b
      Simple terms:    "authentication bug"
      File filter:     "file:cli.py"
      Repo filter:     "repo:agentstream"
      Exact phrase:    '"session importer"'
      OR operator:     "fix OR improve"
      Combined:        "improve file:daemon.py"

    \b
    Transcript detail is controlled by --event-types (default: user,assistant):
      user,assistant   Prompts and final responses only (compact)
      +reasoning       Add thinking/reasoning blocks (as blockquotes)
      +files           Add file read/write operations with content/diffs
      +tools           Add tool calls with arguments and results
      all              Everything including errors

    \b
    Examples:
        hivemind search
        hivemind search "authentication"
        hivemind search "file:cli.py"
        hivemind search "refactor file:daemon" --limit 3
        hivemind search "error handling" --repo all
        hivemind search "error handling" --users all
        hivemind search --event-types user,assistant,files
        hivemind search "query" --order -started_at
    """
    # Determine effective endpoint
    effective_endpoint = get_effective_endpoint()

    # Require authentication
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            "Error: Not authenticated. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    headers: dict[str, str] = {"Authorization": f"Bearer {creds.token}"}

    # Set org header if specified
    if org_id:
        headers["X-Org-Id"] = org_id

    # Resolve --users filter: send username(s) to API
    user_filter: list[str] | None = None
    if users == "me":
        user_filter = [creds.github_user]
    elif users == "all":
        user_filter = None
    else:
        # Treat as comma-separated usernames
        user_filter = [u.strip() for u in users.split(",") if u.strip()]

    # Colorize stderr when connected to a TTY
    use_color = sys.stderr.isatty()

    def _info(msg: str) -> None:
        click.echo(click.style(msg, dim=True) if use_color else msg, err=True)

    def _label(label: str, value: str, extra: str = "") -> None:
        if use_color:
            msg = click.style(label, fg="cyan") + " " + value
            if extra:
                msg += " " + click.style(extra, dim=True)
        else:
            msg = f"{label} {value}"
            if extra:
                msg += f" {extra}"
        click.echo(msg, err=True)

    def _warn(msg: str) -> None:
        click.echo(click.style(msg, fg="yellow") if use_color else msg, err=True)

    def _err(msg: str) -> None:
        click.echo(click.style(msg, fg="red") if use_color else msg, err=True)

    # Expand "all" shorthand for event_types
    all_event_types = "user,assistant,reasoning,tools,files,errors"
    effective_event_types = all_event_types if event_types == "all" else event_types

    # Resolve git_repo filter
    git_repo: str | None = None
    if repo == "all" or repo == "*":
        # Explicit: no repo filtering (accept both "all" and legacy "*")
        _label("Repo filter:", "disabled", "(--repo all)")
    elif repo is not None:
        # Normalize user-provided repo (handles full URLs, credentials, .git suffix)
        normalized = normalize_git_url(repo)
        if normalized:
            git_repo = normalized
        elif "/" in repo and "." in repo.split("/")[0]:
            # Already in host/org/repo format (e.g., github.com/org/repo)
            git_repo = repo
        else:
            _err(
                f"Error: Invalid repository '{repo}'. Expected a git URL or host/org/repo format.\n"
                f"Examples: github.com/org/repo, https://github.com/org/repo, git@github.com:org/repo"
            )
            raise SystemExit(1)
        _label("Repo filter:", git_repo)
    else:
        # Auto-detect from current directory
        detected = resolve_git_repo(Path.cwd())
        if detected:
            git_repo = detected
            _label("Repo filter:", git_repo, "(auto-detected)")
        else:
            _label("Repo filter:", "none", "(not in a git repository)")

    try:
        with httpx.Client(timeout=30.0) as client:
            # Step 1: Search for matching sessions
            _label("Endpoint:", base_endpoint)

            # Determine mode and default order
            if query is None:
                _info("No query provided, listing sessions")
                effective_order = order or "-last_activity_at"
            else:
                _label("Searching for:", query)
                effective_order = order

            # Show order info
            if effective_order:
                _label("Order:", effective_order)
            elif query is not None:
                _label("Order:", "relevance")

            search_params: dict[str, Any] = {
                "limit": limit,
            }
            if query is not None:
                search_params["q"] = query
            if git_repo:
                search_params["git_repo"] = git_repo
            if user_filter:
                search_params["users"] = user_filter
            if effective_order:
                search_params["order"] = effective_order
            if subagents is not None:
                search_params["subagents"] = str(subagents).lower()

            search_url = f"{base_endpoint}/v1/search"
            search_response = client.get(
                search_url,
                params=search_params,
                headers=headers,
            )
            search_response.raise_for_status()
            search_data = search_response.json()

            results = search_data.get("results", [])
            total_count = search_data.get("total_count", 0)

            if not results:
                _warn("No matching sessions found.")
                raise SystemExit(1)

            _info(f"Found {total_count} matches, returning top {len(results)}")

            # Step 2: Fetch transcripts for each result
            sessions = []
            for result in results:
                session_id = result["session_id"]
                session_entry: dict[str, Any] = {
                    "session_id": session_id,
                    "title": result.get("title", ""),
                    "username": result.get("username", ""),
                    "display_name": result.get("display_name", ""),
                    "author_name": result.get("author_name", "")
                    or result.get("display_name")
                    or result.get("username", "")
                    or result.get("user_id", ""),
                    "started_at": result.get("started_at", ""),
                    "last_activity_at": result.get("last_activity_at", ""),
                    "agent_type": result.get("agent_type", ""),
                    "model": result.get("model", ""),
                    "git_repo": result.get("git_repo", ""),
                    "git_branch": result.get("git_branch", ""),
                    "turn_count": result.get("turn_count", 0),
                    "tool_call_count": result.get("tool_call_count", 0),
                    "active_duration_ms": result.get("active_duration_ms", 0),
                    "total_additions": result.get("total_additions", 0),
                    "total_deletions": result.get("total_deletions", 0),
                    "matched_files": result.get("matched_files", []),
                    "files_modified": result.get("modified_files", []),
                    "matched_prompts": [
                        s.get("text", s) if isinstance(s, dict) else s
                        for s in result.get("matched_prompts", [])
                    ],
                }

                if include_transcript:
                    _info(f"Fetching transcript for {session_id}...")
                    try:
                        transcript_params: dict[str, str] = {
                            "format": "markdown",
                        }
                        if verbose:
                            transcript_params["verbose"] = "true"
                        if effective_event_types:
                            transcript_params["event_types"] = effective_event_types
                        transcript_url = f"{base_endpoint}/v1/sessions/{session_id}/llm"
                        transcript_response = client.get(
                            transcript_url,
                            params=transcript_params,
                            headers=headers,
                        )
                        transcript_response.raise_for_status()
                        transcript_data = transcript_response.json()
                        session_entry["transcript"] = transcript_data.get("markdown", "")
                        session_entry["transcript_tokens"] = transcript_data.get("token_count", 0)
                        transcript_meta = transcript_data.get("metadata", {})
                        session_entry["files_read"] = transcript_meta.get("files_read", [])
                        session_entry["files_modified"] = transcript_meta.get("files_modified", [])
                    except httpx.HTTPStatusError as e:
                        _warn(
                            f"Could not fetch transcript for {session_id[:12]}: {e.response.status_code}"
                        )
                        session_entry["transcript"] = ""
                        session_entry["transcript_tokens"] = 0

                sessions.append(session_entry)

            # Report token counts to stderr
            total_tokens = 0
            for s in sessions:
                tokens = s.get("transcript_tokens", 0)
                total_tokens += tokens
                title = s.get("title") or "Untitled"
                sid = s["session_id"][:12]
                if use_color:
                    click.echo(
                        f"  {click.style(sid, dim=True)}  "
                        f"{click.style(f'{tokens:,} tokens', fg='cyan')}  "
                        f"{title}",
                        err=True,
                    )
                else:
                    click.echo(f"  {sid}  {tokens:,} tokens  {title}", err=True)
            if len(sessions) > 1:
                if use_color:
                    click.echo(
                        f"  {'total':<12}  "
                        f"{click.style(f'{total_tokens:,} tokens', fg='cyan', bold=True)}",
                        err=True,
                    )
                else:
                    click.echo(f"  {'total':<12}  {total_tokens:,} tokens", err=True)

            # Step 3: Output
            if output_format == "json":
                output = {
                    "query": query,
                    "total_matches": total_count,
                    "sessions": sessions,
                }
                click.echo(json.dumps(output, indent=2))
            else:
                # Markdown format: only output concatenated transcripts
                transcripts = []
                for s in sessions:
                    t = s.get("transcript", "")
                    if t:
                        transcripts.append(t)
                if transcripts:
                    click.echo("\n\n<!-- session_boundary -->\n\n".join(transcripts))
                else:
                    _warn("No transcripts found.")

    except httpx.HTTPStatusError as e:
        _err(f"HTTP error: {e.response.status_code} - {e.response.text}")
        raise SystemExit(1)
    except httpx.RequestError as e:
        _err(f"Connection error: {e}")
        raise SystemExit(1)


@main.command("export")
@click.option(
    "--dir",
    "output_dir",
    default=None,
    help="Output directory (default: ~/.hivemind/exports/me)",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["duckdb", "parquet"]),
    default="duckdb",
    help="Export format (default: duckdb)",
)
@click.option(
    "-i",
    "--interactive",
    is_flag=True,
    help="Drop into a DuckDB shell after export (requires duckdb format)",
)
@click.option(
    "--poll-interval",
    default=3,
    hidden=True,
    help="Seconds between status polls (default: 3)",
)
@click.pass_context
def export_cmd(
    ctx: click.Context,
    output_dir: str | None,
    output_format: str,
    interactive: bool,
    poll_interval: int,
):
    """Export all your session data as Parquet or DuckDB.

    Downloads your source entries, events, sessions, and session summaries
    from the API as Parquet files. Optionally converts them into a single
    DuckDB database for easy querying.

    \b
    Examples:
        hivemind export                        # Export as DuckDB to ~/.hivemind/exports/me
        hivemind export --format parquet        # Export as raw Parquet files
        hivemind export -i                      # Export and open DuckDB shell
        hivemind export --dir ~/my-export       # Custom output directory
    """
    import time
    from datetime import UTC, datetime

    import httpx

    try:
        from rich.console import Console
        from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
    except ImportError:
        click.echo("Error: rich is required. Install with: pip install rich", err=True)
        raise SystemExit(1)

    console = Console(stderr=True)

    if interactive and output_format != "duckdb":
        click.echo("Error: --interactive requires --format duckdb", err=True)
        raise SystemExit(1)

    # Resolve output directory
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    if output_dir is None:
        output_dir = str(Path.home() / ".hivemind" / "exports" / "me")
    out_path = Path(output_dir).resolve()

    # Authenticate
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        if "localhost" in base_endpoint or "127.0.0.1" in base_endpoint:
            import asyncio

            if asyncio.run(_dev_mode_authenticate(auth_manager)):
                creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            f"Error: Not authenticated for {base_endpoint}. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    headers = {"Authorization": f"Bearer {creds.token}"}
    api_base = base_endpoint + "/v1"

    with httpx.Client(timeout=60.0) as client:
        # Step 1: Check for existing export or trigger a new one
        console.print("[bold]Checking export status...[/bold]")
        resp = client.get(f"{api_base}/users/me/data-export", headers=headers)

        # Detect non-JSON responses (e.g. frontend catch-all serving HTML)
        content_type = resp.headers.get("content-type", "")
        if resp.is_success and "application/json" not in content_type:
            click.echo(
                f"Error: Expected JSON response but got {content_type or 'unknown content type'}.\n"
                f"The server at {base_endpoint} may not support this endpoint yet.\n"
                f"If testing locally, use: hivemind --dev export ...",
                err=True,
            )
            raise SystemExit(1)

        needs_trigger = False
        if resp.status_code == 404:
            needs_trigger = True
        elif resp.is_success:
            status_data = resp.json()
            if status_data["status"] == "failed":
                needs_trigger = True
            elif status_data["status"] == "completed":
                # Check if the completed export is from today
                if status_data.get("export_date", "") != today:
                    needs_trigger = True
                # else: reuse the completed export
        else:
            click.echo(f"Error checking export status: {resp.status_code} - {resp.text}", err=True)
            raise SystemExit(1)

        if needs_trigger:
            console.print("[bold]Requesting data export...[/bold]")
            resp = client.post(f"{api_base}/users/me/data-export", headers=headers)
            if resp.status_code == 429:
                click.echo(
                    "An export has already been requested today. Try again tomorrow.", err=True
                )
                raise SystemExit(1)
            if not resp.is_success:
                click.echo(f"Error triggering export: {resp.status_code} - {resp.text}", err=True)
                raise SystemExit(1)

        # Step 2: Poll until export completes with a progress bar
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total} tables"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            # We export 4 tables: source_entries, events, sessions, session_summary_analyses
            task = progress.add_task("Exporting...", total=4)

            while True:
                resp = client.get(f"{api_base}/users/me/data-export", headers=headers)
                if not resp.is_success:
                    console.print(f"[red]Error polling status: {resp.text}[/red]")
                    raise SystemExit(1)

                status_data = resp.json()
                status = status_data["status"]
                phase = status_data.get("phase", "")

                if status == "completed":
                    progress.update(task, completed=4, description="[green]Export complete!")
                    break
                elif status == "failed":
                    console.print(
                        f"[red]Export failed: {status_data.get('error_message', 'Unknown error')}[/red]"
                    )
                    raise SystemExit(1)
                else:
                    # Map phase to progress
                    phase_map = {
                        "counting": 0,
                        "exporting_source_entries": 0,
                        "uploading_source_entries": 0,
                        "exporting_events": 1,
                        "uploading_events": 1,
                        "exporting_sessions": 2,
                        "uploading_sessions": 2,
                        "exporting_session_summary_analyses": 3,
                        "uploading_session_summary_analyses": 3,
                    }
                    completed = phase_map.get(phase, 0)
                    desc = phase.replace("_", " ").capitalize() if phase else "Waiting..."
                    progress.update(task, completed=completed, description=desc)

                time.sleep(poll_interval)

        # Step 3: Collect file info and download if needed
        files = status_data.get("files", [])
        if not files:
            console.print("[yellow]Export completed but no files found.[/yellow]")
            raise SystemExit(1)

        out_path.mkdir(parents=True, exist_ok=True)

        # For DuckDB format, create views pointing directly at the parquet URLs
        # (no download needed). For parquet format, download files to disk.
        if output_format == "duckdb":
            try:
                import duckdb
            except ImportError:
                console.print(
                    "[red]Error: duckdb package is not installed.[/red]\n"
                    'Install with: [bold]pip install "wandb-hivemind[export]"[/bold]'
                )
                raise SystemExit(1)

            db_path = out_path / "export.duckdb"
            console.print(f"\n[bold]Creating DuckDB database: {db_path}[/bold]")

            table_info: list[tuple[str, int]] = []
            con = duckdb.connect(str(db_path))
            try:
                con.execute("INSTALL httpfs")
                con.execute("LOAD httpfs")

                for file_info in files:
                    name = file_info["name"]
                    table_name = name.replace(".parquet", "")
                    download_url = file_info.get("download_url")
                    file_bytes = file_info.get("bytes", 0)

                    if not download_url:
                        console.print(
                            f"  [yellow]⚠[/yellow] {table_name} - no download URL available"
                        )
                        continue

                    escaped_url = download_url.replace("'", "''")
                    con.execute(
                        f"CREATE OR REPLACE VIEW {table_name} AS SELECT * FROM read_parquet('{escaped_url}')",
                    )
                    row_count = con.execute(f"SELECT count(*) FROM {table_name}").fetchone()[0]
                    table_info.append((table_name, row_count))
                    console.print(
                        f"  [green]✓[/green] {table_name}: {row_count:,} rows "
                        f"({file_bytes:,} bytes)"
                    )
            finally:
                con.close()

            db_size = db_path.stat().st_size
            console.print(f"\n[bold green]Done![/bold green] {db_path} ({db_size:,} bytes)")

        else:
            # Parquet format: download files to disk
            downloaded = 0
            console.print(f"\n[bold]Downloading {len(files)} files to {out_path}[/bold]")
            for file_info in files:
                name = file_info["name"]
                download_url = file_info.get("download_url")
                file_bytes = file_info.get("bytes", 0)

                if not download_url:
                    console.print(f"  [yellow]⚠[/yellow] {name} - no download URL available")
                    continue

                dest = out_path / name
                with client.stream("GET", download_url) as dl_resp:
                    if not dl_resp.is_success:
                        console.print(
                            f"  [red]✗[/red] {name} - download failed: {dl_resp.status_code}"
                        )
                        continue
                    with open(dest, "wb") as f:
                        for chunk in dl_resp.iter_bytes(chunk_size=65536):
                            f.write(chunk)

                actual_size = dest.stat().st_size
                console.print(f"  [green]✓[/green] {name} ({actual_size:,} bytes)")
                downloaded += 1

            if not downloaded:
                console.print("[red]No files were downloaded successfully.[/red]")
                raise SystemExit(1)

            console.print(f"\n[bold green]Done![/bold green] Parquet files saved to {out_path}")
            db_path = None

    # Step 5: Drop into DuckDB shell if interactive
    if interactive and db_path:
        # Build banner with table info and expiry note
        banner_lines = ["\n[bold]Opening DuckDB shell...[/bold]"]
        if table_info:
            banner_lines.append("[dim]Available tables:[/dim]")
            for tname, tcount in table_info:
                banner_lines.append(f"  [dim]- {tname} ({tcount:,} rows)[/dim]")
        banner_lines.append(
            "\n[yellow]Note:[/yellow] [dim]Views read from signed URLs valid for 24 hours."
        )
        banner_lines.append("Re-run [bold]hivemind export[/bold] to refresh.[/dim]")
        banner_lines.append("[dim]Type .quit to exit, .tables to list tables[/dim]\n")
        console.print("\n".join(banner_lines))

        import subprocess

        # Try the duckdb CLI first, fall back to Python REPL
        try:
            subprocess.run(["duckdb", str(db_path)])
        except FileNotFoundError:
            # No duckdb CLI installed, use Python interactive mode
            try:
                import duckdb

                con = duckdb.connect(str(db_path))
                import code

                code.interact(
                    banner=f"DuckDB interactive shell — connected to {db_path}",
                    local={"con": con, "duckdb": duckdb},
                )
                con.close()
            except ImportError:
                click.echo("Error: duckdb not available for interactive mode", err=True)


if __name__ == "__main__":
    main()
