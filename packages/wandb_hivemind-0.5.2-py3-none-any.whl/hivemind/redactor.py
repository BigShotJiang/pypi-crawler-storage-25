"""Secrets detection and redaction."""

from __future__ import annotations

import re
from typing import Any

REDACTED = "[REDACTED]"

# Known secret patterns
SECRET_PATTERNS = [
    # OpenAI - sk-proj- prefix with any alphanumeric characters
    (r"sk-proj-[a-zA-Z0-9_-]+", "OpenAI Project API Key"),
    # OpenAI - generic sk- prefix (but not sk-ant- or sk-proj-)
    (r"sk-(?!ant-|proj-)[a-zA-Z0-9]{20,}", "OpenAI API Key"),
    # Anthropic - sk-ant- prefix
    (r"sk-ant-[a-zA-Z0-9_-]+", "Anthropic API Key"),
    # AWS — \b prefix prevents matching inside base64 image blobs
    (r"\bAKIA[0-9A-Z]{16}", "AWS Access Key"),
    (r"\bASIA[0-9A-Z]{16}", "AWS Temp Access Key"),
    # GitHub - tokens have varying lengths, match 20+ characters
    (r"ghp_[a-zA-Z0-9]{20,}", "GitHub PAT"),
    (r"gho_[a-zA-Z0-9]{20,}", "GitHub OAuth"),
    (r"ghs_[a-zA-Z0-9]{20,}", "GitHub App Token"),
    (r"ghr_[a-zA-Z0-9]{20,}", "GitHub Refresh Token"),
    (r"github_pat_[a-zA-Z0-9_]{20,}", "GitHub Fine-grained PAT"),
    (r"pat_[a-zA-Z0-9_]{20,}", "Generic PAT"),
    (r"glpat-[a-zA-Z0-9_-]{20,}", "GitLab PAT"),
    (r"npm_[a-zA-Z0-9]{36}", "NPM Token"),
    # Google — \b prefix prevents matching inside base64 image blobs
    (r"\bAIza[0-9A-Za-z_-]{35}", "Google API Key"),
    (r"sk_live_[0-9a-zA-Z]{16,}", "Stripe Secret Key"),
    (r"rk_live_[0-9a-zA-Z]{16,}", "Stripe Restricted Key"),
    (r"hf_[a-zA-Z0-9]{20,}", "Hugging Face Token"),
    # Slack
    (r"xox[baprs]-[0-9a-zA-Z-]{10,}", "Slack Token"),
    (r"xoxc-[0-9a-zA-Z-]{10,}", "Slack Session Token"),
    # Generic assignment patterns — \b(?!\s*[.(]) after the value prevents
    # matching function calls like `get_api_key(args)` and property access
    # like `authentication_bearer.credentials`.
    (r'api[_-]?key["\']?\s*[:=]\s*["\']?([a-zA-Z0-9_-]{20,})\b(?!\s*[.(])["\']?', "API Key"),
    (
        r'aws[_-]?secret[_-]?access[_-]?key["\']?\s*[:=]\s*["\']?([A-Za-z0-9/+=]{40})["\']?',
        "AWS Secret Access Key",
    ),
    # Password and Secret assignment patterns are handled by
    # CONTEXT_SECRET_ASSIGNMENT_PATTERN which has better heuristics (requires
    # a digit in the value, excludes parens/brackets, skips function calls).
    (r'token["\']?\s*[:=]\s*["\']?([a-zA-Z0-9_-]{20,})\b(?!\s*[.(])["\']?', "Token"),
]

# Compile patterns
COMPILED_PATTERNS = [(re.compile(p, re.IGNORECASE), name) for p, name in SECRET_PATTERNS]
CREDENTIAL_URL_PATTERN = re.compile(r"(https?://[^/\s:@]+:)([^@/\s]+)(@)")
SCHEMELESS_GITHUB_CREDENTIAL_PATTERN = re.compile(
    r"([a-zA-Z0-9._-]+:)([^@/\s]{8,})(@github\.com)",
    re.IGNORECASE,
)
BEARER_TOKEN_PATTERN = re.compile(
    r"(authorization\s*[:=]\s*bearer\s+)([a-zA-Z0-9._~+/=-]{16,})",
    re.IGNORECASE,
)
JWT_PATTERN = re.compile(r"\beyJ[a-zA-Z0-9_-]{8,}\.[a-zA-Z0-9._-]{8,}\.[a-zA-Z0-9._-]{8,}\b")
# Match secret-looking assignments like `API_KEY=sk-xxxx` or `password: "hunter2"`.
# The value must look like a credential, not a code expression. We require at least
# one digit in the value and exclude parens/brackets and similar punctuation to
# distinguish secrets from code identifiers like `re.compile`, `auth_token`, `data.get`.
CONTEXT_SECRET_ASSIGNMENT_PATTERN = re.compile(
    r"(?P<prefix>"
    r"(?<!/)\b[A-Za-z0-9_.-]*"
    r"(?:api[_-]?key|access[_-]?token|refresh[_-]?token|id[_-]?token|"
    r"auth(?:orization)?[_-]?token|session[_-]?token|client[_-]?secret|"
    r"private[_-]?key|password|passwd|secret)"
    r"[A-Za-z0-9_.-]*\s*[:=]\s*[\"']?"
    r")(?P<value>(?=[^\s\"'`;,(){}\[\]=]*[0-9])[^\s\"'`;,(){}\[\]=]{8,})",
    re.IGNORECASE,
)
QUERY_SECRET_PARAM_PATTERN = re.compile(
    r"(?P<prefix>[?&](?:api[_-]?key|access[_-]?token|refresh[_-]?token|id[_-]?token|"
    r"auth[_-]?token|client[_-]?secret|password|secret)=)(?P<value>[^&\s]{8,})",
    re.IGNORECASE,
)
PRIVATE_KEY_BLOCK_PATTERN = re.compile(
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]+?-----END [A-Z ]*PRIVATE KEY-----",
    re.MULTILINE,
)


def _subn(pattern: re.Pattern[str], repl: str, text: str) -> tuple[str, int]:
    """Apply pattern substitution and return (result, substitution_count)."""
    return pattern.subn(repl, text)


_FILE_EXT_BEFORE_COLON_RE = re.compile(r"\.\w{1,5}\s*:\s*$")


def _context_secret_repl(m: re.Match[str]) -> str:
    """Replacement callback for CONTEXT_SECRET_ASSIGNMENT_PATTERN.

    Skips matches where:
    - the captured value is immediately followed by ``(``, indicating a
      function call (e.g. ``auth_token = base64.b64encode(...)``), or
    - the prefix ends with a file extension before the colon, indicating a
      file path listing (e.g. ``30-secrets.sh: content-sha256=...``).
    """
    rest = m.string[m.end() :]
    if rest.lstrip().startswith("("):
        return m.group(0)  # leave unchanged — function call
    prefix = m.group("prefix")
    if _FILE_EXT_BEFORE_COLON_RE.search(prefix):
        return m.group(0)  # leave unchanged — file path listing
    return prefix + REDACTED


def _credential_url_repl(m: re.Match[str]) -> str:
    """Replacement callback for credential URL patterns.

    Skips matches where the password portion is already ``[REDACTED]`` so that
    re-processing previously redacted text doesn't inflate the count.
    """
    password = m.group(2)
    if password == REDACTED:
        return m.group(0)  # already redacted — leave unchanged
    return m.group(1) + REDACTED + m.group(3)


def redact_secrets_counted(text: str) -> tuple[str, int]:
    """Redact secrets from text and return the count of redactions.

    Returns:
        Tuple of (redacted_text, number_of_secrets_redacted).
    """
    result = text
    count = 0

    # Redact private key blocks and common auth token wrappers first.
    result, n = _subn(PRIVATE_KEY_BLOCK_PATTERN, REDACTED, result)
    count += n
    result, n = _subn(BEARER_TOKEN_PATTERN, rf"\1{REDACTED}", result)
    count += n
    result, n = _subn(JWT_PATTERN, REDACTED, result)
    count += n

    # Context secret assignments — use callback to skip function calls.
    new_result = CONTEXT_SECRET_ASSIGNMENT_PATTERN.sub(_context_secret_repl, result)
    # Count how many replacements actually happened (callback returns
    # the original text for skipped matches, so compare).
    if new_result != result:
        count += new_result.count(REDACTED) - result.count(REDACTED)
        result = new_result

    result, n = _subn(QUERY_SECRET_PARAM_PATTERN, rf"\g<prefix>{REDACTED}", result)
    count += n

    # Redact URL-embedded credentials but keep the URL structure.
    # Use callback to skip already-redacted passwords (idempotency).
    # Count by comparing REDACTED occurrences since the callback may leave
    # matches unchanged.
    for url_pattern in (CREDENTIAL_URL_PATTERN, SCHEMELESS_GITHUB_CREDENTIAL_PATTERN):
        new_result = url_pattern.sub(_credential_url_repl, result)
        if new_result != result:
            count += new_result.count(REDACTED) - result.count(REDACTED)
            result = new_result

    # Apply known patterns
    for pattern, _ in COMPILED_PATTERNS:
        result, n = pattern.subn(REDACTED, result)
        count += n

    return result, count


def redact_secrets(text: str) -> str:
    """Redact secrets from text."""
    result, _ = redact_secrets_counted(text)
    return result


# Keys whose values are opaque binary blobs (encrypted content, cryptographic
# signatures).  Substring matches inside these are always false positives.
OPAQUE_BLOB_KEYS = frozenset(
    {
        "encrypted_content",
        "signature",
    }
)


def redact_dict_counted(data: Any) -> tuple[Any, int]:
    """Recursively redact secrets from a dictionary structure, counting redactions.

    Returns:
        Tuple of (redacted_data, number_of_secrets_redacted).
    """
    if isinstance(data, str):
        return redact_secrets_counted(data)
    elif isinstance(data, dict):
        count = 0
        out = {}
        for k, v in data.items():
            if k in OPAQUE_BLOB_KEYS:
                out[k] = v  # skip — opaque blob, never user-supplied secrets
            else:
                redacted, n = redact_dict_counted(v)
                out[k] = redacted
                count += n
        return out, count
    elif isinstance(data, list):
        count = 0
        out_list = []
        for item in data:
            redacted, n = redact_dict_counted(item)
            out_list.append(redacted)
            count += n
        return out_list, count
    else:
        return data, 0


def redact_dict(data: Any) -> Any:
    """Recursively redact secrets from a dictionary structure."""
    result, _ = redact_dict_counted(data)
    return result
