# Copyright (c) 2026 Said Borna. All rights reserved.
# Proprietary — see LICENSE for terms.
"""MCP server entry point — CodeTrust Layers 1-4 + SARIF + Deep Scan tools."""

import json
import logging
import os
import pathlib
import sys
import time

import httpx
import structlog
from mcp.server.fastmcp import FastMCP

from src.config import settings
from src.formatters.sarif import findings_to_sarif
from src.models.enums import Language, Severity, VerifyStatus
from src.models.requests import DockerImageInput
from src.models.responses import DockerImageResult, Finding, PackageResult, SandboxResponse
from src.rules.anti_patterns import ANTI_PATTERNS
from src.services.ast_analyzer import SUPPORTED_LANGUAGES as AST_LANGUAGES
from src.services.ast_analyzer import AstAnalyzer
from src.services.cache import CacheService
from src.services.docker_verify import DockerVerifyService
from src.services.registry import RegistryService
from src.services.runtime_taint_verifier import (
    RuntimeTaintVerifier,
    VerificationSummary,
)
from src.services.sandbox import SandboxService
from src.services.static_analyzer import StaticAnalyzer
from src.services.taint_analyzer import TaintAnalyzer
from src.telemetry_client import send_telemetry
from src.utils.parsers import (
    extract_go_imports,
    extract_js_imports,
    extract_python_imports,
    extract_rust_imports,
    parse_dockerfile_from,
)


def _configure_mcp_stdio_logging() -> None:
    """Route structured logs to stderr to keep stdout clean for JSON-RPC."""
    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.add_log_level,
            structlog.processors.KeyValueRenderer(key_order=["event"]),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


_configure_mcp_stdio_logging()
logger = structlog.get_logger()


def _emit_mcp_tool_invoked(
    *,
    tool: str,
    ok: bool,
    duration_ms: int,
    payload: dict[str, object],
) -> None:
    """Best-effort anonymous telemetry for MCP tool usage."""

    safe_payload: dict[str, object] = {
        "tool": tool,
        "ok": ok,
        "duration_ms": duration_ms,
        **payload,
    }

    send_telemetry(
        event_type="mcp_tool_invoked",
        source="mcp",
        version=settings.version,
        payload=safe_payload,
    )

mcp = FastMCP("codetrust")
analyzer = StaticAnalyzer()
ast_analyzer = AstAnalyzer()
sandbox = SandboxService()

# License status — validated lazily on first tool invocation
_license_status: object | None = None


async def _get_license_status() -> object:
    """Lazily validate license on first MCP tool use."""
    global _license_status
    if _license_status is not None:
        return _license_status

    from src.services.license_guard import validate_license

    _license_status = await validate_license(settings.api_key)
    if not _license_status.valid:
        logger.warning(
            "mcp_license_limited",
            plan=_license_status.plan,
            max_rules=_license_status.max_rules,
        )
    return _license_status

# Lazy-initialized shared resources for Layer 2
_cache: CacheService | None = None
_http_client: httpx.AsyncClient | None = None
_registry: RegistryService | None = None
_docker: DockerVerifyService | None = None


async def _get_registry() -> RegistryService:
    """Lazily initialize shared cache, HTTP client, and registry service."""
    global _cache, _http_client, _registry, _docker

    if _registry is not None:
        return _registry

    _cache = CacheService(settings.redis_url)
    await _cache.connect()

    _http_client = httpx.AsyncClient(
        timeout=settings.http_timeout,
        limits=httpx.Limits(
            max_connections=settings.http_max_connections,
            max_keepalive_connections=settings.http_max_keepalive,
        ),
    )

    _registry = RegistryService(_cache, _http_client)
    _docker = DockerVerifyService(_cache, _http_client)
    return _registry


async def _get_docker() -> DockerVerifyService:
    """Lazily initialize and return Docker verification service."""
    global _docker

    if _docker is not None:
        return _docker

    # Calling _get_registry initializes all shared resources including _docker
    await _get_registry()
    assert _docker is not None
    return _docker


def _safe_severity_counts(findings: list[Finding] | None) -> dict[str, int]:
    """Count findings by severity, returning zero counts if findings is None."""
    if not findings:
        return {"total": 0, "BLOCK": 0, "WARN": 0, "INFO": 0}
    return {
        "total": len(findings),
        "BLOCK": sum(1 for f in findings if f.severity == Severity.BLOCK),
        "WARN": sum(1 for f in findings if f.severity == Severity.WARN),
        "INFO": sum(1 for f in findings if f.severity == Severity.INFO),
    }


def _parse_ast_language(language: str) -> Language | None:
    """Parse language string to Language enum, returning None if invalid."""
    try:
        return Language(language)
    except ValueError:
        return None


@mcp.tool(name="codetrust_static_scan")
async def codetrust_static_scan(
    code: str,
    filename: str = "untitled",
    language: str | None = None,
) -> str:
    """Scan code for anti-patterns, security issues, and quality problems.

    Args:
        code: Source code to analyze.
        filename: Name of the file being scanned.
        language: Programming language (optional, for future use).

    Returns:
        Markdown-formatted report of findings.
    """
    logger.info("mcp_static_scan", filename=filename)
    started = time.monotonic()
    ok = False
    findings: list[Finding] | None = None
    try:
        findings = analyzer.scan_code(code, filename)
        ok = True
        return analyzer.build_report(findings, title="Static Analysis Report")
    finally:
        _emit_static_scan_telemetry(
            ok=ok, started=started, code_len=len(code),
            language_provided=bool(language), findings=findings,
        )


def _emit_static_scan_telemetry(
    *, ok: bool, started: float, code_len: int,
    language_provided: bool, findings: list[Finding] | None,
) -> None:
    """Emit telemetry for static scan tool invocation."""
    duration_ms = int((time.monotonic() - started) * 1000)
    counts = _safe_severity_counts(findings)
    _emit_mcp_tool_invoked(
        tool="codetrust_static_scan",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "code_len": code_len,
            "language_provided": language_provided,
            "total_findings": counts["total"],
            "findings_by_severity": {
                "BLOCK": counts["BLOCK"],
                "WARN": counts["WARN"],
                "INFO": counts["INFO"],
            },
        },
    )


@mcp.tool(name="codetrust_pre_action")
async def codetrust_pre_action(
    task_description: str,
    proposed_stack: str | None = None,
    proposed_files: list[str] | None = None,
    has_user_specified_stack: bool = False,
    has_user_specified_structure: bool = False,
) -> str:
    """Validate the plan BEFORE writing any code.

    Checks whether requirements are clear enough to proceed. Flags assumptions
    about tech stack, project structure, or scope that the user didn't confirm.

    Args:
        task_description: Description of the task to validate.
        proposed_stack: Proposed technology stack.
        proposed_files: List of proposed files to create/modify.
        has_user_specified_stack: Whether the user confirmed the stack.
        has_user_specified_structure: Whether the user confirmed the structure.

    Returns:
        Validation report with PASS/WARN/BLOCK verdict.
    """
    logger.info("mcp_pre_action", task=task_description[:80])
    started = time.monotonic()
    ok = False
    findings: list[Finding] = []
    try:
        findings = _validate_plan(
            task_description, proposed_stack, proposed_files,
            has_user_specified_stack, has_user_specified_structure,
        )
        ok = True
        report = analyzer.build_report(findings, title="Pre-Action Validation")
        governance_briefing = _build_governance_briefing()
        return report + governance_briefing
    finally:
        _emit_pre_action_telemetry(
            ok=ok, started=started, task_description=task_description,
            proposed_stack=proposed_stack, proposed_files=proposed_files,
            has_user_specified_stack=has_user_specified_stack,
            has_user_specified_structure=has_user_specified_structure, findings=findings,
        )


def _emit_pre_action_telemetry(
    *, ok: bool, started: float,
    task_description: str,
    proposed_stack: str | None,
    proposed_files: list[str] | None,
    has_user_specified_stack: bool,
    has_user_specified_structure: bool,
    findings: list[Finding],
) -> None:
    """Emit telemetry for pre-action tool invocation."""
    duration_ms = int((time.monotonic() - started) * 1000)
    counts = _safe_severity_counts(findings)
    _emit_mcp_tool_invoked(
        tool="codetrust_pre_action",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "task_description_len": len(task_description),
            "proposed_stack_provided": bool(proposed_stack),
            "proposed_files_count": len(proposed_files) if proposed_files else 0,
            "has_user_specified_stack": bool(has_user_specified_stack),
            "has_user_specified_structure": bool(has_user_specified_structure),
            "findings_total": counts["total"],
            "findings_by_severity": {
                "BLOCK": counts["BLOCK"],
                "WARN": counts["WARN"],
                "INFO": counts["INFO"],
            },
        },
    )


@mcp.tool(name="codetrust_post_action")
async def codetrust_post_action(
    repo_root: str,
    task_description: str,
    files_changed: list[str] | None = None,
    verify_imports: bool = False,
) -> str:
    """Validate the completed work against enterprise standards.

    Checks repo structure, required files, and scans all changed files for issues.

    Args:
        repo_root: Path to the repository root.
        task_description: Description of completed task.
        files_changed: List of files that were changed.
        verify_imports: Whether to verify imports (Phase 2 feature).

    Returns:
        Enterprise readiness report with PASS/WARN/BLOCK verdict.
    """
    logger.info("mcp_post_action", repo_root=repo_root, task=task_description[:80])
    started = time.monotonic()
    ok = False
    all_findings: list[Finding] = []
    try:
        all_findings = analyzer.check_repo_structure(repo_root)
        if files_changed:
            all_findings.extend(_scan_changed_files(repo_root, files_changed))
        ok = True
        return analyzer.build_report(all_findings, title="Post-Action Validation")
    finally:
        _emit_post_action_telemetry(
            ok=ok, started=started, task_description=task_description,
            files_changed=files_changed, verify_imports=verify_imports,
            findings=all_findings,
        )


def _scan_changed_files(
    repo_root: str, files_changed: list[str],
) -> list[Finding]:
    """Scan all changed files and return aggregated findings."""
    findings: list[Finding] = []
    real_root = os.path.realpath(repo_root)
    for filepath in files_changed:
        full_path = os.path.realpath(os.path.join(repo_root, filepath))
        if not full_path.startswith(real_root + os.sep) and full_path != real_root:
            logger.warning(
                "path_traversal_blocked",
                filepath=filepath,
                resolved=full_path,
                repo_root=real_root,
            )
            continue
        if os.path.isfile(full_path):
            findings.extend(_scan_file(full_path, filepath))
    return findings


def _emit_post_action_telemetry(
    *, ok: bool, started: float,
    task_description: str,
    files_changed: list[str] | None,
    verify_imports: bool,
    findings: list[Finding],
) -> None:
    """Emit telemetry for post-action tool invocation."""
    duration_ms = int((time.monotonic() - started) * 1000)
    counts = _safe_severity_counts(findings)
    _emit_mcp_tool_invoked(
        tool="codetrust_post_action",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "task_description_len": len(task_description),
            "files_changed_count": len(files_changed) if files_changed else 0,
            "verify_imports": bool(verify_imports),
            "findings_total": counts["total"],
            "findings_by_severity": {
                "BLOCK": counts["BLOCK"],
                "WARN": counts["WARN"],
                "INFO": counts["INFO"],
            },
        },
    )


@mcp.tool(name="codetrust_list_rules")
async def codetrust_list_rules() -> str:
    """List all anti-pattern rules, structure requirements, and their severities.

    Returns:
        Complete rule catalog in markdown format.
    """
    logger.info("mcp_list_rules")
    started = time.monotonic()
    out = _build_rule_catalog()
    duration_ms = int((time.monotonic() - started) * 1000)
    _emit_mcp_tool_invoked(
        tool="codetrust_list_rules",
        ok=True,
        duration_ms=duration_ms,
        payload={"anti_pattern_rules_count": len(ANTI_PATTERNS)},
    )
    return out


def _build_rule_catalog() -> str:
    """Build the complete rule catalog as a markdown string."""
    lines: list[str] = [
        "## CodeTrust Rule Catalog",
        "",
        f"**Total rules: {_count_all_rules()}**",
        "",
        "### Anti-Pattern Rules (regex-based, all languages)",
        "",
        f"**Count: {len(ANTI_PATTERNS)}**",
        "",
        "| ID | Severity | Description |",
        "|---|---|---|",
    ]
    for rule in ANTI_PATTERNS:
        lines.append(f"| {rule['id']} | {rule['severity']} | {rule['message']} |")

    lines.extend([
        "",
        "### Structure Rules",
        "",
        "| ID | Severity | Description |",
        "|---|---|---|",
        "| missing_required_file | BLOCK | Required files must exist |",
        "| missing_recommended_file | WARN | Recommended files should exist |",
        "| missing_recommended_dir | WARN | Recommended directories should exist |",
        "| forbidden_file | WARN | Sensitive files should not be committed |",
    ])

    # Gateway interception rules
    lines.extend(_build_gateway_rule_section())

    # Taint analysis rules
    lines.extend(_build_taint_rule_section())

    # AST analysis rules
    lines.extend([
        "",
        "### AST Analysis Rules (tree-sitter, 10 languages)",
        "",
        "| ID | Severity | Description |",
        "|---|---|---|",
        "| cyclomatic_complexity | WARN | Function exceeds complexity threshold |",
        "| unused_variable | INFO | Variable assigned but never referenced |",
        "| unreachable_code | WARN | Code after return/raise/break is unreachable |",
        "| deep_nesting | WARN | Nesting depth exceeds threshold |",
    ])

    return "\n".join(lines)


def _count_all_rules() -> int:
    """Count total rules across all sources."""
    gateway_count = _get_gateway_rule_count()
    taint_count = _get_taint_rule_count()
    ast_count = 4  # complexity, unused vars, unreachable, deep nesting
    structure_count = 4  # missing required/recommended, forbidden
    return len(ANTI_PATTERNS) + gateway_count + taint_count + ast_count + structure_count


def _get_gateway_rule_count() -> int:
    """Get the number of gateway interception rules."""
    try:
        import inspect
        import re

        from src.gateway.interceptor import CommandInterceptor
        src = inspect.getsource(CommandInterceptor)
        return len(set(re.findall(r'"id":\s*"(gateway_[^"]+)"', src)))
    except ImportError:
        return 0


def _get_taint_rule_count() -> int:
    """Get the number of taint analysis definitions."""
    try:
        from src.rules.taint_rules import (
            TAINT_SANITIZERS,
            TAINT_SINKS,
            TAINT_SOURCES,
        )
        return len(TAINT_SOURCES) + len(TAINT_SINKS) + len(TAINT_SANITIZERS)
    except ImportError:
        return 0


def _build_gateway_rule_section() -> list[str]:
    """Build the gateway rules section for the catalog."""
    lines: list[str] = ["", "### Gateway Interception Rules (pre-execution enforcement)", ""]
    try:
        import inspect
        import re

        from src.gateway.interceptor import CommandInterceptor
        src = inspect.getsource(CommandInterceptor)
        ids = sorted(set(re.findall(r'"id":\s*"(gateway_[^"]+)"', src)))
        lines.append(f"**Count: {len(ids)}**")
        lines.extend(["", "| ID | Category |", "|---|---|"])
        for rule_id in ids:
            category = rule_id.replace("gateway_", "").replace("_", " ")
            lines.append(f"| {rule_id} | {category} |")
    except ImportError:
        lines.append("Gateway rules unavailable (gateway module not installed).")
    return lines


def _build_taint_rule_section() -> list[str]:
    """Build the taint rules section for the catalog."""
    lines: list[str] = ["", "### Taint Analysis Rules (data-flow tracking)", ""]
    try:
        from src.rules.taint_rules import (
            TAINT_SANITIZERS,
            TAINT_SINKS,
            TAINT_SOURCES,
        )
        lines.append(
            f"**Sources: {len(TAINT_SOURCES)} | "
            f"Sinks: {len(TAINT_SINKS)} | "
            f"Sanitizers: {len(TAINT_SANITIZERS)}**",
        )
        lines.extend(["", "**Sources** (user input entry points):"])
        for src_item in TAINT_SOURCES:
            name = getattr(src_item, "name", str(src_item))
            lines.append(f"- {name}")
        lines.extend(["", "**Sinks** (dangerous operations):"])
        for sink in TAINT_SINKS:
            name = getattr(sink, "name", str(sink))
            lines.append(f"- {name}")
        lines.extend(["", "**Sanitizers** (taint breakers):"])
        for san in TAINT_SANITIZERS:
            name = getattr(san, "name", str(san))
            lines.append(f"- {name}")
    except ImportError:
        lines.append("Taint rules unavailable.")
    return lines


TOP_GOVERNANCE_RULES: list[dict[str, str]] = [
    {
        "id": "no_heredoc",
        "enforcement": "BLOCK",
        "description": "Never use heredoc (<<). Use Write tool or git commit -F instead.",
    },
    {
        "id": "no_git_push",
        "enforcement": "BLOCK",
        "description": "Never run git push. User pushes manually.",
    },
    {
        "id": "validate_before_write",
        "enforcement": "BLOCK",
        "description": "Call codetrust_validate_file_write before writing any file.",
    },
    {
        "id": "validate_before_command",
        "enforcement": "BLOCK",
        "description": "Call codetrust_validate_command before running any terminal command.",
    },
    {
        "id": "no_governance_weakening",
        "enforcement": "BLOCK",
        "description": "Never expand skip lists, downgrade severities, or disable scans.",
    },
]


def _build_governance_briefing() -> str:
    """Build governance rules briefing section for pre_action response.

    Returns top 5 governance rules that the agent must follow during this session.
    This ensures every AI agent session starts with explicit governance awareness.
    """
    lines: list[str] = [
        "",
        "",
        "### Governance Rules (top 5)",
        "",
    ]
    for rule in TOP_GOVERNANCE_RULES:
        lines.append(
            f"- **[{rule['enforcement']}]** `{rule['id']}`: {rule['description']}"
        )
    lines.append("")
    lines.append(
        "*These rules are enforced by CodeTrust Gateway. "
        "Violations are logged and blocked automatically.*"
    )
    return "\n".join(lines)


def _validate_plan(
    task_description: str,
    proposed_stack: str | None,
    proposed_files: list[str] | None,
    has_user_specified_stack: bool,
    has_user_specified_structure: bool,
) -> list[Finding]:
    """Validate a plan before code is written."""

    findings: list[Finding] = []

    if len(task_description) < 20:
        findings.append(Finding(
            rule_id="vague_task",
            severity=Severity.WARN,
            message="Task description is very short. Consider adding more detail.",
            suggestion="Describe what should be built, for whom, and key requirements.",
        ))

    if proposed_stack and not has_user_specified_stack:
        findings.append(Finding(
            rule_id="unconfirmed_stack",
            severity=Severity.WARN,
            message=f"Tech stack '{proposed_stack}' was not confirmed by the user.",
            suggestion="Ask the user to confirm the proposed technology stack.",
        ))

    if proposed_files and not has_user_specified_structure:
        file_count = len(proposed_files)
        if file_count > 10:
            findings.append(Finding(
                rule_id="large_scope",
                severity=Severity.WARN,
                message=f"Plan involves {file_count} files. Consider breaking into phases.",
                suggestion="Split into smaller, testable increments.",
            ))

    return findings


def _scan_file(full_path: str, relative_path: str) -> list[Finding]:
    """Read and scan a single file for anti-patterns."""

    try:
        with open(full_path, encoding="utf-8") as f:
            code = f.read()
        return analyzer.scan_code(code, relative_path)
    except (OSError, UnicodeDecodeError):
        return [Finding(
            rule_id="file_read_error",
            severity=Severity.WARN,
            message=f"Could not read file '{relative_path}' for scanning.",
            file=relative_path,
        )]


@mcp.tool(name="codetrust_verify_imports")
async def codetrust_verify_imports(
    code: str,
    language: str = "python",
    filename: str = "untitled",
    requirements: str = "",
) -> str:
    """Verify that all imports in code exist in package registries.

    Extracts imports from code, then checks each against the appropriate
    registry (PyPI for Python, npm for JavaScript/TypeScript).

    Args:
        code: Source code to extract imports from.
        language: Programming language (python, javascript, typescript).
        filename: Name of the file being checked.
        requirements: Optional requirements.txt content for version pinning.

    Returns:
        Markdown-formatted verification report.
    """
    logger.info("mcp_verify_imports", filename=filename, language=language)
    started = time.monotonic()
    ok = False
    metrics: dict[str, int] = {}
    try:
        report, metrics = await _perform_import_verification(
            code, language, requirements, started,
        )
        ok = True
        return report
    finally:
        _emit_verify_imports_telemetry(
            ok=ok, started=started, language=language,
            code_len=len(code), metrics=metrics,
        )


async def _perform_import_verification(
    code: str, language: str, requirements: str, started: float,
) -> tuple[str, dict[str, int]]:
    """Execute import verification and return report with metrics."""
    lang = Language(language)
    imports = _extract_imports(code, lang)
    empty_metrics: dict[str, int] = {
        "imports_count": 0, "verified": 0, "failed": 0, "warnings": 0,
    }
    if not imports:
        return "## Import Verification\n\nNo third-party imports found.\n", empty_metrics
    registry = await _get_registry()
    results = await registry.verify_packages(lang, imports, requirements)
    verified, failed, warnings = _count_import_results(results)
    elapsed_ms = int((time.monotonic() - started) * 1000)
    metrics: dict[str, int] = {
        "imports_count": len(imports), "verified": verified,
        "failed": failed, "warnings": warnings,
    }
    return _format_import_report(results, elapsed_ms), metrics


def _count_import_results(
    results: list[PackageResult],
) -> tuple[int, int, int]:
    """Count verified, failed, and warning results."""
    verified = sum(1 for r in results if r.status == VerifyStatus.VERIFIED)
    failed = sum(
        1 for r in results
        if r.status in (VerifyStatus.NOT_FOUND, VerifyStatus.VERSION_MISMATCH)
    )
    warnings = sum(
        1 for r in results
        if r.status in (VerifyStatus.DEPRECATED, VerifyStatus.TIMEOUT, VerifyStatus.ERROR)
    )
    return verified, failed, warnings


def _emit_verify_imports_telemetry(
    *, ok: bool, started: float, language: str,
    code_len: int, metrics: dict[str, int],
) -> None:
    """Emit telemetry for import verification."""
    duration_ms = int((time.monotonic() - started) * 1000)
    _emit_mcp_tool_invoked(
        tool="codetrust_verify_imports",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "language": language,
            "code_len": code_len,
            "total_imports_checked": metrics.get("imports_count", 0),
            "verified": metrics.get("verified", 0),
            "failed": metrics.get("failed", 0),
            "warnings": metrics.get("warnings", 0),
        },
    )


def _extract_imports(code: str, language: Language) -> list[str]:
    """Extract imports based on language."""
    if language == Language.PYTHON:
        return extract_python_imports(code)
    if language in (Language.JAVASCRIPT, Language.TYPESCRIPT):
        return extract_js_imports(code)
    if language == Language.GO:
        return extract_go_imports(code)
    if language == Language.RUST:
        return extract_rust_imports(code)
    return []


def _format_import_report(
    results: list[PackageResult], elapsed_ms: int
) -> str:
    """Format package verification results as markdown."""
    verified = sum(1 for r in results if r.status == VerifyStatus.VERIFIED)
    failed = sum(
        1 for r in results
        if r.status in (VerifyStatus.NOT_FOUND, VerifyStatus.VERSION_MISMATCH)
    )
    warnings = sum(
        1 for r in results
        if r.status in (VerifyStatus.DEPRECATED, VerifyStatus.TIMEOUT, VerifyStatus.ERROR)
    )

    lines: list[str] = [
        "## Import Verification Report",
        "",
        f"**{verified} verified** | **{failed} failed** | **{warnings} warnings** | {elapsed_ms}ms",
        "",
    ]

    _append_failed_imports(lines, results)
    _append_warning_imports(lines, results)
    _append_verified_imports(lines, results)

    return "\n".join(lines)


def _append_failed_imports(
    lines: list[str], results: list[PackageResult],
) -> None:
    """Append failed import results to the report lines."""
    failed = [r for r in results if r.status in (VerifyStatus.NOT_FOUND, VerifyStatus.VERSION_MISMATCH)]
    if not failed:
        return
    lines.append("### Failed")
    for r in failed:
        sug = f" -> {r.suggestion}" if r.suggestion else ""
        lines.append(f"- **{r.package}**: {r.message}{sug}")
    lines.append("")


def _append_warning_imports(
    lines: list[str], results: list[PackageResult],
) -> None:
    """Append warning import results to the report lines."""
    warned = [r for r in results if r.status in (VerifyStatus.DEPRECATED, VerifyStatus.TIMEOUT, VerifyStatus.ERROR)]
    if not warned:
        return
    lines.append("### Warnings")
    for r in warned:
        lines.append(f"- **{r.package}**: {r.message}")
    lines.append("")


def _append_verified_imports(
    lines: list[str], results: list[PackageResult],
) -> None:
    """Append verified import results to the report lines."""
    verified = [r for r in results if r.status == VerifyStatus.VERIFIED]
    if not verified:
        return
    lines.append("### Verified")
    for r in verified:
        cached_tag = " (cached)" if r.cached else ""
        lines.append(f"- {r.package} {r.latest_version}{cached_tag}")
    lines.append("")


@mcp.tool(name="codetrust_verify_dockerfile")
async def codetrust_verify_dockerfile(
    dockerfile_content: str,
) -> str:
    """Verify Docker base images and tags exist on Docker Hub.

    Parses FROM statements from Dockerfile content and verifies
    each image:tag combination against Docker Hub.

    Args:
        dockerfile_content: Raw Dockerfile content to parse and verify.

    Returns:
        Markdown-formatted verification report.
    """
    logger.info("mcp_verify_dockerfile")
    started = time.monotonic()
    ok = False
    images_checked = 0
    try:
        parsed = parse_dockerfile_from(dockerfile_content)
        images_checked = len(parsed)
        if not parsed:
            ok = True
            return "## Docker Image Verification\n\nNo FROM statements found in Dockerfile.\n"
        docker = await _get_docker()
        inputs = [DockerImageInput(image=img, tag=tag) for img, tag in parsed]
        results = await docker.verify_images(inputs)
        ok = True
        return _format_docker_report(results, int((time.monotonic() - started) * 1000))
    finally:
        _emit_dockerfile_telemetry(
            ok=ok, started=started,
            dockerfile_len=len(dockerfile_content), images_checked=images_checked,
        )


def _emit_dockerfile_telemetry(
    *, ok: bool, started: float,
    dockerfile_len: int, images_checked: int,
) -> None:
    """Emit telemetry for Dockerfile verification."""
    duration_ms = int((time.monotonic() - started) * 1000)
    _emit_mcp_tool_invoked(
        tool="codetrust_verify_dockerfile",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "dockerfile_len": dockerfile_len,
            "images_checked": images_checked,
        },
    )


def _format_docker_report(
    results: list[DockerImageResult], elapsed_ms: int
) -> str:
    """Format Docker verification results as markdown."""
    verified = sum(1 for r in results if r.status == VerifyStatus.VERIFIED)
    failed = len(results) - verified

    lines: list[str] = [
        "## Docker Image Verification Report",
        "",
        f"**{verified} verified** | **{failed} failed** | {elapsed_ms}ms",
        "",
    ]

    if failed:
        lines.append("### Failed")
        for r in results:
            if r.status != VerifyStatus.VERIFIED:
                sug = f" -> {r.suggestion}" if r.suggestion else ""
                lines.append(f"- **{r.image}:{r.tag}**: {r.message}{sug}")
        lines.append("")

    if verified:
        lines.append("### Verified")
        for r in results:
            if r.status == VerifyStatus.VERIFIED:
                lines.append(f"- {r.image}:{r.tag}")
        lines.append("")

    return "\n".join(lines)


@mcp.tool(name="codetrust_ast_scan")
async def codetrust_ast_scan(
    code: str,
    filename: str = "untitled",
    language: str = "python",
    max_nesting: int = 4,
    complexity_threshold: int = 10,
) -> str:
    """Run AST-based code analysis using tree-sitter.

    Analyzes source code structure for cyclomatic complexity,
    unused variables, unreachable code, and deep nesting.

    Args:
        code: Source code to analyze.
        filename: Name of the file being scanned.
        language: Programming language (python, javascript, typescript, go, rust).
        max_nesting: Maximum allowed nesting depth (default: 4).
        complexity_threshold: Maximum allowed cyclomatic complexity (default: 10).

    Returns:
        Markdown-formatted AST analysis report.
    """
    logger.info("mcp_ast_scan", filename=filename, language=language)
    started = time.monotonic()
    ok = False
    supported = False
    findings_count = 0
    try:
        report, supported, findings_count = _perform_ast_scan(
            code, filename, language, max_nesting, complexity_threshold,
        )
        ok = True
        return report
    finally:
        _emit_ast_scan_telemetry(
            ok=ok, started=started, language=language, code_len=len(code),
            supported=supported, findings_count=findings_count,
            max_nesting=max_nesting, complexity_threshold=complexity_threshold,
        )


def _perform_ast_scan(
    code: str, filename: str, language: str,
    max_nesting: int, complexity_threshold: int,
) -> tuple[str, bool, int]:
    """Run AST analysis and return (report, supported, findings_count)."""
    lang = _parse_ast_language(language)
    if lang is None:
        return f"Unsupported language for AST analysis: {language}", False, 0
    if lang not in AST_LANGUAGES:
        return f"AST analysis not available for: {language}", False, 0
    findings = ast_analyzer.analyze(
        code, lang, filename, max_nesting, complexity_threshold,
    )
    return ast_analyzer.build_report(findings), True, len(findings)


def _emit_ast_scan_telemetry(
    *, ok: bool, started: float, language: str, code_len: int,
    supported: bool, findings_count: int,
    max_nesting: int, complexity_threshold: int,
) -> None:
    """Emit telemetry for AST scan tool invocation."""
    duration_ms = int((time.monotonic() - started) * 1000)
    _emit_mcp_tool_invoked(
        tool="codetrust_ast_scan",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "language": language,
            "code_len": code_len,
            "ast_available": supported,
            "findings_total": findings_count,
            "max_nesting": int(max_nesting),
            "complexity_threshold": int(complexity_threshold),
        },
    )


@mcp.tool(name="codetrust_sandbox_run")
async def codetrust_sandbox_run(
    code: str,
    language: str = "python",
    timeout: int = 10,
) -> str:
    """Execute code in an isolated Docker sandbox.

    Runs code in a short-lived container with no network access,
    read-only filesystem, and strict memory/CPU limits.

    Args:
        code: Source code to execute.
        language: Programming language (python, javascript, typescript, go, rust).
        timeout: Maximum execution time in seconds (1-30).

    Returns:
        Markdown-formatted sandbox execution result.
    """
    logger.info("mcp_sandbox_run", language=language, timeout=timeout)
    started = time.monotonic()
    ok = False
    supported = False
    result: SandboxResponse | None = None
    try:
        report, supported, result = await _perform_sandbox_run(code, language, timeout)
        ok = True
        return report
    finally:
        _emit_sandbox_telemetry(
            ok=ok, started=started, language=language,
            code_len=len(code), timeout=timeout,
            supported=supported, result=result,
        )


async def _perform_sandbox_run(
    code: str, language: str, timeout: int,
) -> tuple[str, bool, SandboxResponse | None]:
    """Execute sandbox run and return (report, supported, result)."""
    lang = _parse_ast_language(language)
    if lang is None:
        return f"Unsupported language for sandbox: {language}", False, None
    result = await sandbox.execute_code(code, lang, timeout)
    return _format_sandbox_report(result), True, result


def _emit_sandbox_telemetry(
    *, ok: bool, started: float, language: str,
    code_len: int, timeout: int,
    supported: bool, result: SandboxResponse | None,
) -> None:
    """Emit telemetry for sandbox execution."""
    duration_ms = int((time.monotonic() - started) * 1000)
    _emit_mcp_tool_invoked(
        tool="codetrust_sandbox_run",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "language": language,
            "code_len": code_len,
            "sandbox_available": supported,
            "timeout_seconds": int(timeout),
            "success": bool(result.success) if result else False,
            "timed_out": bool(result.timed_out) if result else False,
            "exit_code": int(result.exit_code) if result else -1,
        },
    )


def _format_sandbox_report(result: SandboxResponse) -> str:
    """Format a SandboxResponse as markdown."""
    lines: list[str] = ["## Sandbox Execution Report", ""]

    if result.error:
        lines.append(f"**Error:** {result.error}")
        return "\n".join(lines)

    status = "TIMEOUT" if result.timed_out else (
        "PASS" if result.exit_code == 0 else "FAIL"
    )
    lines.append(f"**Status: {status}** | Exit code: {result.exit_code}")
    lines.append(f"Latency: {result.latency_ms}ms")
    lines.append("")

    if result.stdout:
        lines.extend(["### stdout", "```", result.stdout.rstrip(), "```", ""])

    if result.stderr:
        lines.extend(["### stderr", "```", result.stderr.rstrip(), "```", ""])

    return "\n".join(lines)


@mcp.tool(name="codetrust_sarif_export")
async def codetrust_sarif_export(
    code: str,
    filename: str = "untitled",
    language: str = "python",
) -> str:
    """Run static analysis and export results as SARIF JSON.

    SARIF (Static Analysis Results Interchange Format) output is
    compatible with GitHub Security tab and other SARIF tools.

    Args:
        code: Source code to analyze.
        filename: Name of the file being scanned.
        language: Programming language.

    Returns:
        SARIF JSON string.
    """
    logger.info("mcp_sarif_export", filename=filename)
    started = time.monotonic()
    ok = False
    total_findings = 0
    used_ast = False
    try:
        sarif_json, total_findings, used_ast = _perform_sarif_scan(
            code, filename, language,
        )
        ok = True
        return sarif_json
    finally:
        _emit_sarif_telemetry(
            ok=ok, started=started, language=language,
            code_len=len(code), used_ast=used_ast, total_findings=total_findings,
        )


def _perform_sarif_scan(
    code: str, filename: str, language: str,
) -> tuple[str, int, bool]:
    """Run static + AST scan and return (sarif_json, total_findings, used_ast)."""
    findings = analyzer.scan_code(code, filename)
    lang = _parse_ast_language(language)
    used_ast = False
    if lang is not None and lang in AST_LANGUAGES:
        used_ast = True
        findings.extend(ast_analyzer.analyze(code, lang, filename))
    sarif = findings_to_sarif(findings)
    return json.dumps(sarif, indent=2), len(findings), used_ast


def _emit_sarif_telemetry(
    *, ok: bool, started: float, language: str,
    code_len: int, used_ast: bool, total_findings: int,
) -> None:
    """Emit telemetry for SARIF export."""
    duration_ms = int((time.monotonic() - started) * 1000)
    _emit_mcp_tool_invoked(
        tool="codetrust_sarif_export",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "language": language,
            "code_len": code_len,
            "used_ast": used_ast,
            "findings_total": total_findings,
        },
    )


@mcp.tool(name="codetrust_deep_scan")
async def codetrust_deep_scan(
    code: str,
    filename: str = "untitled",
    language: str = "python",
    verify_imports: bool = True,
    verify_docker: bool = False,
    sandbox_run: bool = False,
    dockerfile_content: str = "",
    requirements_content: str = "",
    additional_files_json: str = "",
) -> str:
    """Run all validation layers and return a Markdown report with verdict.

    Includes static analysis, AST analysis, import verification, Docker
    verification, sandbox execution, hallucination-aware taint analysis,
    and optionally cross-file and cross-language taint analysis when
    additional_files_json is provided.

    Args:
        code: Source code to scan.
        filename: Name of the file being scanned.
        language: Programming language.
        verify_imports: Whether to verify package imports against registries.
        verify_docker: Whether to verify Docker images.
        sandbox_run: Whether to execute code in sandbox.
        dockerfile_content: Dockerfile content for Docker verification.
        requirements_content: requirements.txt content for import verification.
        additional_files_json: Optional JSON object of {filepath: code} for
            cross-file and cross-language taint analysis. When provided,
            enables multi-file taint tracking across import boundaries
            and HTTP/gRPC boundaries between languages.
    """
    logger.info("mcp_deep_scan", filename=filename, language=language)
    started = time.monotonic()
    ok = False
    static_count = 0
    ast_count = 0
    try:
        findings = analyzer.scan_code(code, filename)
        static_count = len(findings)
        ast_findings = _deep_scan_ast_findings(code, language, filename)
        ast_count = len(ast_findings) if ast_findings is not None else 0
        sections = await _build_deep_scan_sections(
            findings, ast_findings, code, language,
            requirements_content, verify_imports,
            dockerfile_content, verify_docker,
            sandbox_run, started, filename,
            additional_files_json,
        )
        ok = True
        return "\n".join(sections)
    finally:
        _emit_deep_scan_telemetry(
            ok=ok, started=started, language=language, code_len=len(code),
            verify_imports=verify_imports, verify_docker=verify_docker,
            sandbox_run=sandbox_run, static_count=static_count, ast_count=ast_count,
        )


def _emit_deep_scan_telemetry(
    *, ok: bool, started: float, language: str, code_len: int,
    verify_imports: bool, verify_docker: bool, sandbox_run: bool,
    static_count: int, ast_count: int,
) -> None:
    """Emit telemetry for deep scan tool invocation."""
    duration_ms = int((time.monotonic() - started) * 1000)
    _emit_mcp_tool_invoked(
        tool="codetrust_deep_scan",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "language": language,
            "code_len": code_len,
            "verify_imports": bool(verify_imports),
            "verify_docker": bool(verify_docker),
            "sandbox_run": bool(sandbox_run),
            "static_findings": static_count,
            "ast_findings": ast_count,
        },
    )


async def _build_deep_scan_sections(
    findings: list[Finding],
    ast_findings: list[Finding] | None,
    code: str,
    language: str,
    requirements_content: str,
    verify_imports: bool,
    dockerfile_content: str,
    verify_docker: bool,
    sandbox_run: bool,
    start: float,
    filename: str = "untitled",
    additional_files_json: str = "",
) -> list[str]:
    """Build all report sections for the deep scan."""
    sections: list[str] = ["# CodeTrust Deep Scan Report", ""]

    static_report = analyzer.build_report(findings, title="Static Analysis")
    sections.extend([static_report, ""])

    if ast_findings is not None:
        sections.extend([ast_analyzer.build_report(ast_findings), ""])

    import_report = await _deep_scan_imports(
        code, language, requirements_content, verify_imports,
    )
    if import_report:
        sections.extend([import_report, ""])

    docker_report = await _deep_scan_docker(dockerfile_content, verify_docker)
    if docker_report:
        sections.extend([docker_report, ""])

    sandbox_report = await _deep_scan_sandbox(code, language, sandbox_run)
    if sandbox_report:
        sections.extend([sandbox_report, ""])

    # Hallucination taint — always runs (single-file)
    hall_findings = _deep_scan_hallucination(code, language, filename)
    if hall_findings:
        sections.extend([hall_findings, ""])

    # Cross-file + cross-language taint — only when additional files provided
    cf_findings = ""
    cl_findings = ""
    if additional_files_json.strip():
        cf_findings, cl_findings = _deep_scan_multi_file_taint(
            code, filename, additional_files_json,
        )
        if cf_findings:
            sections.extend([cf_findings, ""])
        if cl_findings:
            sections.extend([cl_findings, ""])

    sections.append(_deep_scan_verdict_line(
        findings, ast_findings, import_report,
        docker_report, sandbox_report, start,
        hall_findings, cf_findings, cl_findings,
    ))
    return sections


def _deep_scan_verdict_line(
    findings: list[Finding],
    ast_findings: list[Finding] | None,
    import_report: str,
    docker_report: str,
    sandbox_report: str,
    start: float,
    hall_report: str = "",
    cf_report: str = "",
    cl_report: str = "",
) -> str:
    """Compute final verdict and format the summary line."""
    elapsed_ms = int((time.monotonic() - start) * 1000)
    all_findings = findings + (ast_findings or [])
    verdict = _compute_deep_verdict(
        all_findings, import_report, docker_report, sandbox_report,
        hall_report, cf_report, cl_report,
    )
    return f"## Overall Verdict: **{verdict}** ({elapsed_ms}ms)"


async def _deep_scan_sandbox(
    code: str, language: str, sandbox_run: bool,
) -> str:
    """Run sandbox execution as part of deep scan."""
    if not sandbox_run:
        return ""
    result = await sandbox.execute_code(code, Language(language))
    return _format_sandbox_report(result)


def _deep_scan_ast_findings(
    code: str,
    language: str,
    filename: str,
) -> list[Finding] | None:
    """Run AST analysis as part of deep scan, returns None if unsupported."""
    try:
        lang = Language(language)
    except ValueError:
        return None

    if lang not in AST_LANGUAGES:
        return None

    return ast_analyzer.analyze(code, lang, filename)


def _deep_scan_hallucination(
    code: str,
    language: str,
    filename: str,
) -> str:
    """Run hallucination-aware taint analysis as part of deep scan."""
    try:
        lang = Language(language.lower())
    except ValueError:
        return ""

    from src.services.hallucination_taint import HallucinationTaintAnalyzer

    hall = HallucinationTaintAnalyzer()
    result = hall.analyze(code, lang, filename)

    if not result.findings and not result.hallucinated_sanitizers:
        return ""

    lines: list[str] = ["## Hallucination-Aware Taint Analysis"]
    if result.hallucinated_sanitizers:
        lines.append(
            f"\n**{len(result.hallucinated_sanitizers)} hallucinated "
            f"sanitizer(s) detected:**",
        )
        for s in result.hallucinated_sanitizers:
            lines.append(f"- `{s}` — fake, taint chain NOT broken")

    for finding in result.findings:
        lines.append(
            f"- **[{finding.severity.value}]** {finding.rule_id}: "
            f"{finding.message} (line {finding.line})",
        )

    verdict = "BLOCK" if result.hallucinated_sanitizers else "WARN"
    lines.append(f"\n**Verdict: {verdict}**")
    return "\n".join(lines)


def _deep_scan_multi_file_taint(
    primary_code: str,
    primary_filename: str,
    additional_files_json: str,
) -> tuple[str, str]:
    """Run cross-file and cross-language taint as part of deep scan.

    Returns:
        Tuple of (cross_file_report, cross_language_report).
    """
    try:
        additional: dict[str, str] = json.loads(additional_files_json)
    except json.JSONDecodeError:
        return "", ""

    if not additional:
        return "", ""

    # Merge primary file into the set
    file_contents = {primary_filename: primary_code, **additional}

    # Cross-file taint
    cf_report = ""
    try:
        from src.services.cross_file_taint import CrossFileTaintAnalyzer

        cf = CrossFileTaintAnalyzer()
        cf_result = cf.analyze(file_contents)
        if cf_result.findings or cf_result.cross_file_flows > 0:
            lines = [
                "## Cross-File Taint Analysis",
                f"\n**Files:** {cf_result.total_files} | "
                f"**Flows:** {cf_result.cross_file_flows} | "
                f"**Findings:** {len(cf_result.findings)}",
            ]
            for f in cf_result.findings:
                lines.append(
                    f"- **[{f.severity.value}]** {f.rule_id}: "
                    f"{f.message} (line {f.line})",
                )
            verdict = "BLOCK" if any(
                f.severity == Severity.BLOCK for f in cf_result.findings
            ) else "WARN" if cf_result.findings else "PASS"
            lines.append(f"\n**Verdict: {verdict}**")
            cf_report = "\n".join(lines)
    except Exception:
        logger.exception("cross_file_taint_error")

    # Cross-language taint
    cl_report = ""
    try:
        from src.services.cross_language_taint import CrossLanguageTaintAnalyzer

        cl = CrossLanguageTaintAnalyzer()
        cl_result = cl.analyze(file_contents)
        if cl_result.findings or cl_result.cross_language_flows > 0:
            lines = [
                "## Cross-Language Taint Analysis",
                f"\n**Languages:** {cl_result.languages_analyzed} | "
                f"**Routes:** {cl_result.routes_discovered} | "
                f"**Calls:** {cl_result.http_calls_discovered} | "
                f"**Flows:** {cl_result.cross_language_flows} | "
                f"**Findings:** {len(cl_result.findings)}",
            ]
            for f in cl_result.findings:
                lines.append(
                    f"- **[{f.severity.value}]** {f.rule_id}: "
                    f"{f.message} (line {f.line})",
                )
            verdict = "BLOCK" if any(
                f.severity == Severity.BLOCK for f in cl_result.findings
            ) else "WARN" if cl_result.findings else "PASS"
            lines.append(f"\n**Verdict: {verdict}**")
            cl_report = "\n".join(lines)
    except Exception:
        logger.exception("cross_language_taint_error")

    return cf_report, cl_report


async def _deep_scan_imports(
    code: str,
    language: str,
    requirements_content: str,
    verify_imports: bool,
) -> str:
    """Run import verification as part of deep scan."""
    if not verify_imports:
        return ""

    lang = Language(language)
    imports = _extract_imports(code, lang)

    if not imports:
        return "## Import Verification\n\nNo third-party imports found."

    registry = await _get_registry()
    results = await registry.verify_packages(lang, imports, requirements_content)
    elapsed_ms = 0  # timing is rolled into the parent
    return _format_import_report(results, elapsed_ms)


async def _deep_scan_docker(
    dockerfile_content: str,
    verify_docker: bool,
) -> str:
    """Run Docker verification as part of deep scan."""
    if not verify_docker or not dockerfile_content:
        return ""

    parsed = parse_dockerfile_from(dockerfile_content)
    if not parsed:
        return "## Docker Image Verification\n\nNo FROM statements found."

    docker = await _get_docker()
    inputs = [DockerImageInput(image=img, tag=tag) for img, tag in parsed]
    results = await docker.verify_images(inputs)
    return _format_docker_report(results, 0)


def _compute_deep_verdict(
    findings: list[Finding],
    import_report: str,
    docker_report: str,
    sandbox_report: str = "",
    hall_report: str = "",
    cf_report: str = "",
    cl_report: str = "",
) -> str:
    """Compute the overall deep scan verdict."""
    has_block = any(f.severity == Severity.BLOCK for f in findings)
    has_warn = any(f.severity == Severity.WARN for f in findings)

    if has_block:
        return "BLOCK"

    # Check import failures
    if import_report and "### Failed" in import_report:
        return "BLOCK"

    # Check docker failures
    if docker_report and "### Failed" in docker_report:
        return "BLOCK"

    # Hallucinated sanitizers = BLOCK
    if hall_report and "Verdict: BLOCK" in hall_report:
        return "BLOCK"

    # Cross-file taint BLOCK findings
    if cf_report and "Verdict: BLOCK" in cf_report:
        return "BLOCK"

    # Cross-language taint BLOCK findings
    if cl_report and "Verdict: BLOCK" in cl_report:
        return "BLOCK"

    # Check sandbox failures
    if sandbox_report and "**Status: FAIL**" in sandbox_report:
        return "BLOCK"
    if sandbox_report and "**Status: TIMEOUT**" in sandbox_report:
        return "BLOCK"
    if sandbox_report and "**Error:**" in sandbox_report:
        return "WARN"

    if has_warn:
        return "WARN"

    if import_report and "### Warnings" in import_report:
        return "WARN"

    return "PASS"


_TAINT_SUPPORTED_LANGS: set[str] = {"python", "javascript", "typescript"}

# Lazy-initialized taint analyzer for MCP tools
_taint_analyzer: TaintAnalyzer | None = None


def _get_taint_analyzer() -> TaintAnalyzer:
    """Lazily initialize the shared TaintAnalyzer instance."""
    global _taint_analyzer
    if _taint_analyzer is None:
        _taint_analyzer = TaintAnalyzer()
    return _taint_analyzer


@mcp.tool(name="codetrust_taint_verify")
async def codetrust_taint_verify(
    code: str,
    filename: str = "untitled",
    language: str = "python",
) -> str:
    """Run taint analysis with runtime exploit verification.

    Performs static taint analysis to find data-flow vulnerabilities,
    then attempts to confirm each finding by executing proof-of-concept
    exploits in an isolated Docker sandbox. Verified findings are
    confirmed exploitable with high confidence (~0.95).

    Args:
        code: Source code to analyze.
        filename: Name of the file being scanned.
        language: Programming language (python, javascript, typescript).

    Returns:
        Markdown-formatted report with verified taint findings.
    """
    logger.info("mcp_taint_verify", filename=filename, language=language)
    started = time.monotonic()
    ok = False
    taint_count = 0
    verified_count = 0
    try:
        report, taint_count, verified_count = await _perform_taint_verify(
            code, filename, language,
        )
        ok = True
        return report
    finally:
        _emit_taint_verify_telemetry(
            ok=ok, started=started, language=language,
            code_len=len(code), taint_count=taint_count,
            verified_count=verified_count,
        )


async def _perform_taint_verify(
    code: str, filename: str, language: str,
) -> tuple[str, int, int]:
    """Run taint analysis and runtime verification.

    Args:
        code: Source code to analyze.
        filename: File name for reporting.
        language: Programming language string.

    Returns:
        Tuple of (markdown_report, taint_finding_count, verified_count).
    """
    if language not in _TAINT_SUPPORTED_LANGS:
        return (
            f"## Taint Verified Scan\n\n"
            f"Taint analysis not available for: {language}",
            0, 0,
        )

    lang = _parse_ast_language(language)
    if lang is None:
        return (
            f"## Taint Verified Scan\n\n"
            f"Unsupported language: {language}",
            0, 0,
        )

    taint_anal = _get_taint_analyzer()
    findings = taint_anal.analyze(code, lang, filename)
    if not findings:
        return "## Taint Verified Scan\n\n**Verdict: PASS** — No taint flows detected.", 0, 0

    verifier = RuntimeTaintVerifier(sandbox=sandbox)
    summary = await verifier.verify_findings(findings, language=lang)
    report = _format_taint_verify_report(findings, summary)
    return report, summary.total, summary.verified


def _format_taint_verify_report(
    findings: list[Finding],
    summary: VerificationSummary,
) -> str:
    """Format taint verification results as Markdown.

    Args:
        findings: Original taint findings.
        summary: Runtime verification summary.

    Returns:
        Markdown-formatted report string.
    """
    lines: list[str] = ["## Taint Verified Scan", ""]

    if summary.sandbox_unavailable:
        lines.append("**Note:** Sandbox unavailable — findings are unverified.")
        lines.append("")

    lines.append(f"**Total findings:** {summary.total}")
    lines.append(f"**Verified (exploitable):** {summary.verified}")
    lines.append(f"**Unverified:** {summary.unverified}")
    lines.append("")

    for vf in summary.results:
        status = "VERIFIED" if vf.verified else "unverified"
        confidence = f"{vf.confidence:.0%}"
        lines.append(
            f"- [{status}] **{vf.finding.rule_id}** "
            f"(L{vf.finding.line}, {vf.finding.severity.value}) "
            f"— confidence {confidence}"
        )
        lines.append(f"  {vf.finding.message}")
        if vf.exploit_payload:
            lines.append(f"  Exploit: `{vf.exploit_payload}`")
        if vf.finding.suggestion:
            lines.append(f"  Fix: {vf.finding.suggestion}")
        lines.append("")

    has_blocks = any(f.severity == Severity.BLOCK for f in findings)
    verdict = "BLOCK" if (has_blocks or summary.verified > 0) else "WARN"
    lines.append(f"**Verdict: {verdict}**")
    return "\n".join(lines)


def _emit_taint_verify_telemetry(
    *, ok: bool, started: float, language: str, code_len: int,
    taint_count: int, verified_count: int,
) -> None:
    """Emit telemetry for taint verify tool invocation."""
    duration_ms = int((time.monotonic() - started) * 1000)
    _emit_mcp_tool_invoked(
        tool="codetrust_taint_verify",
        ok=ok,
        duration_ms=duration_ms,
        payload={
            "language": language,
            "code_len": code_len,
            "taint_findings": taint_count,
            "verified_findings": verified_count,
        },
    )


# ── Vulnerability Scanning (CVE/GHSA via OSV) ──────────────────────────────

@mcp.tool(name="codetrust_vulnerability_scan")
async def codetrust_vulnerability_scan(
    packages: str,
    language: str = "python",
    versions: str = "",
) -> str:
    """Scan packages for known CVEs and security advisories via OSV.

    Checks packages against Google's Open Source Vulnerability database.
    Supports all ecosystems: PyPI, npm, crates.io, Go, Maven, NuGet, RubyGems, Packagist.

    Args:
        packages: Comma-separated package names (e.g. "flask,requests,django").
        language: Programming language (python, javascript, typescript, go, rust, java, csharp, ruby, php).
        versions: Optional comma-separated versions matching packages (e.g. "2.0.1,2.31.0,4.2").

    Returns:
        Markdown-formatted vulnerability report.
    """
    logger.info("mcp_vulnerability_scan", language=language, package_count=len(packages.split(",")))
    started = time.monotonic()
    ok = False
    try:
        lang = Language(language.lower())
        pkg_list = [p.strip() for p in packages.split(",") if p.strip()]
        if not pkg_list:
            return "No packages provided."

        version_map: dict[str, str] | None = None
        if versions.strip():
            ver_list = [v.strip() for v in versions.split(",")]
            if len(ver_list) == len(pkg_list):
                version_map = dict(zip(pkg_list, ver_list, strict=True))

        from src.services.vulnerability import VulnerabilityService

        cache = CacheService()
        async with httpx.AsyncClient(timeout=15.0) as client:
            vuln_service = VulnerabilityService(cache=cache, http_client=client)
            result = await vuln_service.check_packages(
                language=lang,
                packages=pkg_list,
                versions=version_map,
            )

        lines: list[str] = [
            "## Vulnerability Scan Results\n",
            f"**Packages scanned:** {result.total_packages}",
            f"**Vulnerable:** {result.vulnerable_count}",
            f"**Clean:** {result.clean_count}",
            f"**Total vulnerabilities:** {result.total_vulnerabilities}",
            f"**Critical:** {result.critical_count} | **High:** {result.high_count} "
            f"| **Medium:** {result.medium_count} | **Low:** {result.low_count}",
            f"**Scan time:** {result.latency_ms}ms\n",
        ]

        if result.vulnerable_count == 0:
            lines.append("All packages are clean. No known vulnerabilities found.")
        else:
            for pkg_result in result.results:
                if pkg_result.is_vulnerable:
                    lines.append(f"### {pkg_result.package} ({pkg_result.version or 'latest'})")
                    for vuln in pkg_result.vulnerabilities:
                        fixed = f" (fixed in {vuln.fixed_version})" if vuln.fixed_version else ""
                        lines.append(f"- **{vuln.id}** [{vuln.severity}]: {vuln.summary}{fixed}")
                        if vuln.reference_url:
                            lines.append(f"  Ref: {vuln.reference_url}")
                    lines.append("")

        verdict = "BLOCK" if result.critical_count > 0 or result.high_count > 0 else "WARN" if result.vulnerable_count > 0 else "PASS"
        lines.append(f"\n**Verdict: {verdict}**")
        ok = True
        return "\n".join(lines)
    except ValueError as exc:
        return f"Error: Unsupported language '{language}'. {exc}"
    except httpx.HTTPError as exc:
        return f"Error: OSV API request failed — {exc}"
    finally:
        _emit_mcp_tool_invoked(
            tool="codetrust_vulnerability_scan",
            ok=ok,
            duration_ms=int((time.monotonic() - started) * 1000),
            payload={"language": language, "package_count": len(packages.split(","))},
        )


# ── License Compliance ──────────────────────────────────────────────────────

@mcp.tool(name="codetrust_license_check")
async def codetrust_license_check(
    packages: str,
    language: str = "python",
) -> str:
    """Check dependency licenses for compliance risks.

    Classifies licenses as permissive, weak copyleft, strong copyleft,
    network copyleft, or unknown. Flags packages that may be incompatible
    with commercial use.

    Args:
        packages: Comma-separated package names (e.g. "flask,requests,django").
        language: Programming language (python, javascript, go, rust, java, ruby, php).

    Returns:
        Markdown-formatted license compliance report.
    """
    logger.info("mcp_license_check", language=language, package_count=len(packages.split(",")))
    started = time.monotonic()
    ok = False
    try:
        lang = Language(language.lower())
        pkg_list = [p.strip() for p in packages.split(",") if p.strip()]
        if not pkg_list:
            return "No packages provided."

        from src.services.license_checker import LicenseRisk, LicenseService

        cache = CacheService()
        async with httpx.AsyncClient(timeout=15.0) as client:
            license_service = LicenseService(cache=cache, http_client=client)
            result = await license_service.check_packages(
                language=lang,
                packages=pkg_list,
            )

        lines: list[str] = [
            "## License Compliance Report\n",
            f"**Packages checked:** {result.total_packages}",
            f"**Permissive:** {result.permissive_count}",
            f"**Weak copyleft (LGPL/MPL):** {result.weak_copyleft_count}",
            f"**Strong copyleft (GPL):** {result.strong_copyleft_count}",
            f"**Network copyleft (AGPL):** {result.network_copyleft_count}",
            f"**Unknown:** {result.unknown_count}",
            f"**Compliant:** {'Yes' if result.compliant else 'No'}",
            f"**Scan time:** {result.latency_ms}ms\n",
        ]

        if result.compliant and result.unknown_count == 0:
            lines.append("All packages use permissive licenses. No compliance risks.")
        else:
            risk_packages = [li for li in result.all_licenses if li.risk != LicenseRisk.PERMISSIVE]
            if risk_packages:
                lines.append("### Packages requiring review\n")
                for li in risk_packages:
                    spdx = f" ({li.spdx_id})" if li.spdx_id else ""
                    lines.append(f"- **{li.package}**: {li.license_name}{spdx} — {li.risk.value}")
                lines.append("")

        verdict = "BLOCK" if result.network_copyleft_count > 0 else "WARN" if not result.compliant else "PASS"
        lines.append(f"\n**Verdict: {verdict}**")
        ok = True
        return "\n".join(lines)
    except ValueError as exc:
        return f"Error: Unsupported language '{language}'. {exc}"
    except httpx.HTTPError as exc:
        return f"Error: Registry API request failed — {exc}"
    finally:
        _emit_mcp_tool_invoked(
            tool="codetrust_license_check",
            ok=ok,
            duration_ms=int((time.monotonic() - started) * 1000),
            payload={"language": language, "package_count": len(packages.split(","))},
        )


# ── Hallucination-Aware Taint Analysis ──────────────────────────────────────

@mcp.tool(name="codetrust_hallucination_scan")
async def codetrust_hallucination_scan(
    code: str,
    language: str = "python",
    filename: str = "untitled",
) -> str:
    """Detect hallucinated sanitizers in AI-generated code.

    Verifies that every sanitizer function used in taint chains actually
    exists. Catches fake modules like 'ai_utils.sanitize_html' that AI
    models hallucinate — code that looks safe but provides zero protection.

    Args:
        code: Source code to analyze.
        language: Programming language (python, javascript, go).
        filename: Filename for context in findings.

    Returns:
        Markdown-formatted hallucination analysis report.
    """
    logger.info("mcp_hallucination_scan", language=language, filename=filename)
    started = time.monotonic()
    ok = False
    try:
        lang = Language(language.lower())
        from src.services.hallucination_taint import HallucinationTaintAnalyzer

        hall_analyzer = HallucinationTaintAnalyzer()
        result = hall_analyzer.analyze(code, lang, filename)

        lines: list[str] = [
            "## Hallucination-Aware Taint Analysis\n",
            f"**Verified sanitizers:** {len(result.verified_sanitizers)}",
            f"**Hallucinated sanitizers:** {len(result.hallucinated_sanitizers)}",
            f"**Findings:** {len(result.findings)}\n",
        ]

        if result.hallucinated_sanitizers:
            lines.append("### Hallucinated (fake) sanitizers\n")
            for s in result.hallucinated_sanitizers:
                lines.append(f"- `{s}` — does not exist, taint chain NOT broken")
            lines.append("")

        if result.verified_sanitizers:
            lines.append("### Verified (real) sanitizers\n")
            for s in result.verified_sanitizers:
                lines.append(f"- `{s}`")
            lines.append("")

        for finding in result.findings:
            lines.append(
                f"- **[{finding.severity.value}]** {finding.rule_id}: "
                f"{finding.message} (line {finding.line})",
            )

        verdict = "BLOCK" if result.hallucinated_sanitizers else "PASS"
        lines.append(f"\n**Verdict: {verdict}**")
        ok = True
        return "\n".join(lines)
    except ValueError as exc:
        return f"Error: Unsupported language '{language}'. {exc}"
    finally:
        _emit_mcp_tool_invoked(
            tool="codetrust_hallucination_scan",
            ok=ok,
            duration_ms=int((time.monotonic() - started) * 1000),
            payload={"language": language, "filename": filename},
        )


# ── Cross-File Taint Analysis ──────────────────────────────────────────────

@mcp.tool(name="codetrust_cross_file_taint")
async def codetrust_cross_file_taint(
    files_json: str,
) -> str:
    """Track tainted data flowing across file import boundaries.

    Detects when user input in file A propagates through imports to
    reach a dangerous sink in file B. Requires multiple files.

    Args:
        files_json: JSON object mapping relative file paths to source code.
            Example: {"app.py": "from flask import...", "db.py": "import sqlite3..."}

    Returns:
        Markdown-formatted cross-file taint report.
    """
    logger.info("mcp_cross_file_taint")
    started = time.monotonic()
    ok = False
    try:
        file_contents: dict[str, str] = json.loads(files_json)
        if not file_contents:
            return "No files provided. Pass a JSON object of {filepath: code}."

        from src.services.cross_file_taint import CrossFileTaintAnalyzer

        cf_analyzer = CrossFileTaintAnalyzer()
        result = cf_analyzer.analyze(file_contents)

        lines: list[str] = [
            "## Cross-File Taint Analysis\n",
            f"**Files analyzed:** {result.total_files}",
            f"**Exports found:** {result.total_exports}",
            f"**Tainted exports:** {result.tainted_exports}",
            f"**Cross-file flows:** {result.cross_file_flows}",
            f"**Findings:** {len(result.findings)}\n",
        ]

        if not result.findings:
            lines.append("No cross-file taint flows detected.")
        else:
            for finding in result.findings:
                lines.append(
                    f"- **[{finding.severity.value}]** {finding.rule_id}: "
                    f"{finding.message} (line {finding.line})",
                )
                if finding.suggestion:
                    lines.append(f"  Fix: {finding.suggestion}")

        verdict = "BLOCK" if any(
            f.severity == Severity.BLOCK for f in result.findings
        ) else "WARN" if result.findings else "PASS"
        lines.append(f"\n**Verdict: {verdict}**")
        ok = True
        return "\n".join(lines)
    except json.JSONDecodeError as exc:
        return f"Error: Invalid JSON — {exc}"
    finally:
        _emit_mcp_tool_invoked(
            tool="codetrust_cross_file_taint",
            ok=ok,
            duration_ms=int((time.monotonic() - started) * 1000),
            payload={"file_count": len(file_contents) if "file_contents" in dir() else 0},
        )


# ── Cross-Language Taint Analysis ───────────────────────────────────────────

@mcp.tool(name="codetrust_cross_language_taint")
async def codetrust_cross_language_taint(
    files_json: str,
) -> str:
    """Track tainted data across HTTP/gRPC boundaries between languages.

    The capability no other security tool has. Detects when:
    - A JS frontend sends user input via fetch() to a Python backend
    - A Python service forwards data to a Go microservice
    - Unsanitized data reaches a SQL query across 3+ language hops

    Supports 20+ frameworks: Flask, FastAPI, Django, Express, NestJS,
    Gin, Fiber, Echo, Chi, and gRPC across all languages.

    Args:
        files_json: JSON object mapping relative file paths to source code.
            Must include files from 2+ languages for cross-language analysis.
            Example: {"frontend/api.js": "fetch('/users'...)", "backend/app.py": "@app.route..."}

    Returns:
        Markdown-formatted cross-language taint report with full attack chain.
    """
    logger.info("mcp_cross_language_taint")
    started = time.monotonic()
    ok = False
    try:
        file_contents: dict[str, str] = json.loads(files_json)
        if not file_contents:
            return "No files provided. Pass a JSON object of {filepath: code}."

        from src.services.cross_language_taint import CrossLanguageTaintAnalyzer

        cl_analyzer = CrossLanguageTaintAnalyzer()
        result = cl_analyzer.analyze(file_contents)

        lines: list[str] = [
            "## Cross-Language Taint Analysis\n",
            f"**Files analyzed:** {result.total_files}",
            f"**Languages detected:** {result.languages_analyzed}",
            f"**HTTP routes discovered:** {result.routes_discovered}",
            f"**HTTP calls discovered:** {result.http_calls_discovered}",
            f"**Cross-language flows:** {result.cross_language_flows}",
            f"**gRPC services:** {result.grpc_services_discovered}",
            f"**gRPC calls:** {result.grpc_calls_discovered}",
            f"**gRPC flows:** {result.grpc_flows}",
            f"**Findings:** {len(result.findings)}\n",
        ]

        if not result.findings:
            lines.append("No cross-language taint flows detected.")
        else:
            for finding in result.findings:
                lines.append(
                    f"### [{finding.severity.value}] {finding.rule_id}",
                )
                lines.append(f"{finding.message}")
                if finding.suggestion:
                    lines.append(f"**Fix:** {finding.suggestion}")
                lines.append(f"**Line:** {finding.line}\n")

        verdict = "BLOCK" if any(
            f.severity == Severity.BLOCK for f in result.findings
        ) else "WARN" if result.findings else "PASS"
        lines.append(f"**Verdict: {verdict}**")
        ok = True
        return "\n".join(lines)
    except json.JSONDecodeError as exc:
        return f"Error: Invalid JSON — {exc}"
    finally:
        _emit_mcp_tool_invoked(
            tool="codetrust_cross_language_taint",
            ok=ok,
            duration_ms=int((time.monotonic() - started) * 1000),
            payload={"file_count": len(file_contents) if "file_contents" in dir() else 0},
        )


# ─────────────────────────────────────────────────────────────────
#  AI Observability & Attribution Tools
# ─────────────────────────────────────────────────────────────────


@mcp.tool(name="codetrust_mcp_audit")
async def codetrust_mcp_audit(
    workspace: str = "",
    include_project_local: bool = True,
) -> str:
    """Discover and audit all MCP servers configured across IDEs.

    Scans Claude Desktop, Claude Code, Cursor, VS Code, Cline, and
    project-local configs. Classifies each server as vetted or unvetted.

    Args:
        workspace: Project root for local config scanning. Empty = skip local.
        include_project_local: Whether to scan .mcp.json etc.
    """
    from src.services.mcp_discovery import MCPDiscoveryService

    svc = MCPDiscoveryService()
    ws = pathlib.Path(workspace) if workspace else None
    result = svc.audit(workspace=ws, include_project_local=include_project_local)
    return svc.build_report(result)


@mcp.tool(name="codetrust_shadow_scan")
async def codetrust_shadow_scan(
    approved_tools: str = "",
) -> str:
    """Detect installed AI coding tools on this machine.

    Scans for Copilot, Cursor, Cline, Aider, Windsurf, Claude Code, etc.

    Args:
        approved_tools: Comma-separated tool IDs that are approved.
                       Empty = no filtering (all shown as approved).
    """
    from src.services.shadow_ai import ShadowAIScanner

    scanner = ShadowAIScanner()
    approved = frozenset(approved_tools.split(",")) if approved_tools else None
    result = scanner.scan(approved_tools=approved)
    return scanner.build_report(result)


@mcp.tool(name="codetrust_attribute")
async def codetrust_attribute(
    filepath: str,
    workspace: str = "",
) -> str:
    """Analyze a file for AI model attribution.

    Three-tier detection: IDE hook data (0.95), git trailers (0.6-0.9),
    code heuristics (0.25-0.9).

    Args:
        filepath: Path to file to analyze.
        workspace: Project root. Empty = derive from filepath.
    """
    from src.services.ai_attribution import AIAttributor

    attributor = AIAttributor()
    fp = pathlib.Path(filepath)
    ws = pathlib.Path(workspace) if workspace else fp.parent
    result = attributor.analyze_file(fp, workspace=ws)
    return attributor.build_report([result])


@mcp.tool(name="codetrust_risk_profile")
async def codetrust_risk_profile(
    workspace: str = ".",
    max_commits: int = 200,
) -> str:
    """Compute developer risk profiles for a repository.

    Scores developers based on BLOCK rate, AI usage ratio, and model choices.

    Args:
        workspace: Repository root.
        max_commits: Max commits to analyze per author.
    """
    from src.services.developer_risk import DeveloperRiskService

    svc = DeveloperRiskService()
    result = svc.assess(pathlib.Path(workspace), max_commits=max_commits)
    return svc.build_report(result)


@mcp.tool(name="codetrust_benchmark")
async def codetrust_benchmark(
    workspace: str = ".",
) -> str:
    """Show LLM security benchmark — per-model code quality statistics.

    Aggregates scan data correlated with AI model attribution.

    Args:
        workspace: Project root containing .codetrust/benchmark.jsonl.
    """
    from src.services.llm_benchmark import LLMBenchmarkService

    svc = LLMBenchmarkService()
    result = svc.aggregate(pathlib.Path(workspace))
    return svc.build_report(result)


@mcp.tool(name="codetrust_compliance_report")
async def codetrust_compliance_report(
    framework: str = "owasp-asi-2026",
) -> str:
    """Generate a compliance mapping report for a security framework.

    Maps CodeTrust governance capabilities to recognized frameworks with
    verified evidence (file paths, function names, line numbers).

    Args:
        framework: Framework identifier. Use 'list' to see all supported.
                   Supported: owasp-asi-2026, eu-ai-act, nist-ai-rmf.

    Returns:
        Markdown-formatted compliance report with coverage levels and evidence.
    """
    from src.services.compliance import get_compliance_report, list_frameworks

    logger.info("mcp_compliance_report", framework=framework)

    if framework == "list":
        frameworks = list_frameworks()
        lines = ["# Supported Compliance Frameworks", ""]
        for fid, fname in frameworks.items():
            lines.append(f"- `{fid}`: {fname}")
        return "\n".join(lines)

    try:
        report = get_compliance_report(framework)
    except ValueError as exc:
        return f"## Error\n\n{exc}"

    return report.to_markdown()


if __name__ == "__main__":
    mcp.run()
