"""tiferet_kb Assets"""
