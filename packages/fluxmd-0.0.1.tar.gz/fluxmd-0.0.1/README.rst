
FluxMD
======

Modern fully differentiable molecular dynamics code written in JAX.
