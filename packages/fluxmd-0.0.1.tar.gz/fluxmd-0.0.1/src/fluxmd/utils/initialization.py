import jax
import jax.numpy as jnp

from fluxmd.core.state import SimulationState


def initialize_velocities(
    state: SimulationState, temperature: float, k_b: float = 1.0
) -> SimulationState:
    """
    Initializes velocities for the system based on a Maxwell-Boltzmann distribution.
    Also removes the center-of-mass velocity to prevent system drift.

    Args:
        state: The current simulation state.
        temperature: Target temperature.
        k_b: Boltzmann constant (defaults to 1.0 for reduced units).
    Returns:
        New simulation state with updated velocities and updated RNG key.
    """
    key, subkey = jax.random.split(state.rng_key)
    n_atoms = state.system.positions.shape[0]

    # Standard deviation for each component: sqrt(kBT / m)
    # sigma = sqrt(kBT / m)
    # Masses has shape (N,) -> (N, 1) for broadcasting
    masses = state.system.masses[:, None]
    stddev = jnp.sqrt(k_b * temperature / masses)

    # Sample from normal distribution
    velocities = jax.random.normal(subkey, (n_atoms, 3)) * stddev

    # Remove center of mass velocity to prevent linear momentum
    total_mass = jnp.sum(state.system.masses)
    com_vel = jnp.sum(velocities * masses, axis=0) / total_mass
    velocities = velocities - com_vel

    new_sys = state.system._replace(velocities=velocities)
    return state._replace(system=new_sys, rng_key=key)
