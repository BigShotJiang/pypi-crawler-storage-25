from flax import nnx
import jax
import jax.numpy as jnp

from fluxmd.core.space import Space
from fluxmd.core.state import OverflowReport

__all__ = ("NeighborList",)


class NeighborList(nnx.Module):
    """
    Neighbor list implementation with multi-image search and overflow detection.
    Delegates geometric operations to a Space object.
    """

    indices: jnp.ndarray | None = nnx.data()
    mask: jnp.ndarray | None = nnx.data()
    shifts: jnp.ndarray | None = nnx.data()
    last_positions: jnp.ndarray | None = nnx.data()
    overflow: nnx.Variable[bool]
    n_found: nnx.Variable[jnp.ndarray]  # High-water mark for neighbors found
    n_req: nnx.Variable[jnp.ndarray]  # High-water mark for images required

    def __init__(
        self,
        cutoff: float,
        skin: float = 0.5,
        max_neighbors: int = 100,
        space: Space | None = None,
    ):
        self.cutoff = cutoff
        self.skin = skin
        self.max_neighbors = max_neighbors
        self.search_radius = cutoff + skin
        self.space = space

        # Initialize variables explicitly
        self.indices = None
        self.mask = None
        self.shifts = None
        self.last_positions = None
        self.overflow = nnx.Variable(jnp.array(False))
        self.n_found = nnx.Variable(jnp.array(0, dtype=int))
        self.n_req = nnx.Variable(jnp.array(0, dtype=int))

    def needs_update(self, positions: jnp.ndarray) -> jnp.ndarray:
        """
        Check if the neighbor list needs to be rebuilt based on atomic displacements.
        """
        if self.last_positions is None:
            return jnp.array(True)

        # Calculate max displacement since last update
        displacement = positions - self.last_positions
        max_dist = jnp.max(jnp.sqrt(jnp.sum(displacement**2, axis=-1)))

        # Standard Verlet List criteria: update if max_dist > skin / 2
        return max_dist > (self.skin / 2.0)

    def update(self, positions: jnp.ndarray, cell: jnp.ndarray) -> OverflowReport:
        """
        Rebuilds the neighbor list by searching across all required images in the space.
        Returns an OverflowReport.
        """
        # pylint: disable=too-many-locals

        self.last_positions = positions

        if self.space is None:
            raise ValueError("Space must be provided at least once to update.")

        n_atoms = positions.shape[0]

        # 1. Get required image shifts from the space
        shifts, active_mask, n_req = self.space.get_image_shifts(cell, self.search_radius)
        self.shifts = shifts
        self.n_req[...] = n_req

        # 2. Get all image positions: (M*N, 3)
        all_images = self.space.apply_shifts(positions, cell, shifts)

        # 3. Compute all-to-all squared distances from primary atoms to all images
        # Memory-efficient calculation: |r1 - r2|^2 = r1^2 + r2^2 - 2*r1*r2
        r1_sq = jnp.sum(positions**2, axis=-1, keepdims=True)  # (N, 1)
        r2_sq = jnp.sum(all_images**2, axis=-1)[None, :]  # (1, MN)
        r1_r2 = jnp.matmul(positions, all_images.T)  # (N, MN)
        dist_sq = r1_sq + r2_sq - 2 * r1_r2

        # 4. Identify valid neighbors and mask out self-interactions
        # Self-interaction occurs at the (0,0,0) shift image for the diagonal elements
        center_shift_idx = jnp.argmin(jnp.sum(jnp.abs(shifts), axis=-1))
        self_mask = jnp.ones_like(dist_sq, dtype=bool)
        diag_indices = jnp.arange(n_atoms)
        self_mask = self_mask.at[diag_indices, center_shift_idx * n_atoms + diag_indices].set(False)

        # Apply distance cutoff
        mask_all = (dist_sq < self.search_radius**2) & self_mask

        # 5. Filter by active_mask (the images actually needed for this space/geometry)
        active_mask_flat = jnp.repeat(active_mask, n_atoms)  # (MN,)
        mask_all = mask_all & active_mask_flat[None, :]

        # 6. Overflow detection
        total_neighbors = jnp.sum(mask_all, axis=1)
        max_found = jnp.max(total_neighbors)
        self.n_found[...] = max_found

        neighbor_overflow = max_found > self.max_neighbors
        range_overflow = n_req > self.space.max_range
        overflow_occurred = jnp.logical_or(neighbor_overflow, range_overflow)
        self.overflow[...] = overflow_occurred

        # 7. Extract top K indices (referencing indices in the 'all_images' array)
        large_dist = 1e10
        dist_sq_masked = jnp.where(mask_all, dist_sq, large_dist)
        neg_dist = -dist_sq_masked

        n_candidates = neg_dist.shape[1]
        k = min(self.max_neighbors, n_candidates)

        _, neighbor_indices = jax.lax.top_k(neg_dist, k)

        # Pad to fixed size
        pad_width = self.max_neighbors - k
        neighbor_indices = jnp.pad(neighbor_indices, ((0, 0), (0, pad_width)), constant_values=0)

        rows = jnp.arange(n_atoms)[:, None]

        valid_mask = mask_all[rows, neighbor_indices[:, :k]]

        final_mask = jnp.pad(valid_mask, ((0, 0), (0, pad_width)), constant_values=False)

        safe_indices = jnp.where(final_mask, neighbor_indices, 0)

        self.indices = safe_indices
        self.mask = final_mask

        return OverflowReport(
            max_neighbors_found=max_found,
            max_range_required=n_req,
            neighbor_overflow=neighbor_overflow,
            range_overflow=range_overflow,
            overflow_occurred=overflow_occurred,
        )

    def expand(self, report: OverflowReport):
        """
        Expands the neighbor list capacity based on the provided report.
        Usually called from Python outside the JIT loop.
        """
        if report.neighbor_overflow:
            # Expand with 20% headroom to avoid frequent re-allocations
            self.max_neighbors = int(report.max_neighbors_found * 1.2)
            print(f"NeighborList: Expanding max_neighbors to {self.max_neighbors}")

        if report.range_overflow and hasattr(self.space, "max_range"):
            self.space.max_range = int(report.max_range_required)
            print(f"PeriodicSpace: Expanding max_range to {self.space.max_range}")

        # Reset buffers to trigger re-allocation with new shapes
        self.indices = None
        self.mask = None
        self.shifts = None

    def get_neighbors(self, positions: jnp.ndarray, cell: jnp.ndarray):
        """
        Returns the displacements and distances for all active neighbors.
        """
        if self.space is None:
            raise ValueError("Space must be provided to get_neighbors.")

        if self.indices is None or self.mask is None or self.shifts is None:
            raise RuntimeError("Neighbor list must be updated before querying.")

        # Reconstruct all image positions used during update
        all_images = self.space.apply_shifts(positions, cell, self.shifts)

        # Index into all_images to get neighbor positions: (N, K, 3)
        neighbor_pos = all_images[self.indices]

        # Compute displacements: (N, K, 3)
        diff = neighbor_pos - positions[:, None, :]
        dist = jnp.linalg.norm(diff, axis=-1, keepdims=True)
        return diff, dist, self.mask
