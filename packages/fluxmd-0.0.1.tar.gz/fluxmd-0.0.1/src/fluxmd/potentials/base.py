from typing import Any

from flax import nnx
import jax
from jax import Array
from jaxtyping import Float

from fluxmd.core.state import SystemState


class Potential(nnx.Module):
    """
    Base interface for interaction potentials.
    """

    def energy(self, system: SystemState, neighbor_list: Any | None = None) -> Float[Array, ""]:
        raise NotImplementedError

    def forces(self, system: SystemState, neighbor_list: Any | None = None) -> Float[Array, "N 3"]:
        # Use JAX autodiff to compute forces from energy
        # Note: we wrap the energy call to target the positions
        # We pass the neighbor_list along so it can be used for distance calculations
        grad_fn = jax.grad(lambda pos: self.energy(system._replace(positions=pos), neighbor_list))
        return -grad_fn(system.positions)


class CompositePotential(Potential):
    """
    Allows combining multiple potentials into one.
    """

    def __init__(self, potentials: list[Potential]):
        self.potentials = nnx.List(potentials)

    def energy(self, system: SystemState, neighbor_list: Any | None = None) -> Float[Array, ""]:
        return sum(p.energy(system, neighbor_list) for p in self.potentials)

    def forces(self, system: SystemState, neighbor_list: Any | None = None) -> Float[Array, "N 3"]:
        return sum(p.forces(system, neighbor_list) for p in self.potentials)
