from flax import nnx
from jax import Array
import jax.numpy as jnp
from jaxtyping import Float

from fluxmd.core.state import SystemState
from fluxmd.potentials.base import Potential

from .. import neighbors


class PairPotential(Potential):
    """
    Base class for potentials that depend only on pairwise distances.
    Utilizes a NeighborList to efficiently compute interactions.
    """

    def energy(
        self, system: SystemState, neighbor_list: neighbors.NeighborList = None
    ) -> Float[Array, ""]:
        if neighbor_list is None:
            raise ValueError("Neighbor list is required for PairPotential")

        # Get neighbor information
        # diff: (N, K, 3), dist: (N, K, 1), mask: (N, K)
        # Note: dist is (N, K, 1), mask is (N, K)
        _, dist, mask = neighbor_list.get_neighbors(system.positions, system.cell)

        # Flatten dist for the pair_energy function if needed, or just let it handle it
        # dist has shape (N, K, 1)

        # Compute pairwise energies
        # We want to avoid division by zero for masked-out neighbors (dist=0 or padded)
        # We can use jnp.where to handle actual distances vs padding
        safe_dist = jnp.where(mask[..., None], dist, 1.0)  # 1.0 is safe placeholder

        pair_energies = self.pair_energy(safe_dist)

        # Apply mask and sum.
        # We divide by 2 because each pair (i, j) is counted twice in the list:
        # once as j being a neighbor of i, and once as i being a neighbor of j.
        masked_energies = jnp.where(mask[..., None], pair_energies, 0.0)
        return jnp.sum(masked_energies) / 2.0

    def pair_energy(self, dist: Float[Array, "N K 1"]) -> Float[Array, "N K 1"]:
        """
        Compute the pair interaction energy for the given distances.
        """
        raise NotImplementedError


class LennardJones(PairPotential):
    """
    Standard 12-6 Lennard-Jones potential.
    V(r) = 4 * epsilon * [(sigma/r)^12 - (sigma/r)^6]
    """

    def __init__(self, sigma: float = 1.0, epsilon: float = 1.0):
        self.sigma = nnx.Param(jnp.array(sigma))
        self.epsilon = nnx.Param(jnp.array(epsilon))

    def pair_energy(self, dist: Float[Array, "N K 1"]) -> Float[Array, "N K 1"]:
        # E = 4 * epsilon * [(sigma/r)^12 - (sigma/r)^6]
        inv_r_sigma = self.sigma / dist
        inv_r_sigma6 = inv_r_sigma**6
        inv_r_sigma12 = inv_r_sigma6**2

        return 4.0 * self.epsilon * (inv_r_sigma12 - inv_r_sigma6)
