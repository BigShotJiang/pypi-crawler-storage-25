from flax import nnx
import jax
import jax.numpy as jnp

from fluxmd.core.state import SimulationState


class Langevin(nnx.Module):
    """
    Langevin thermostat for NVT simulations.
    Implements a stochastic velocity update to maintain a constant temperature.
    """

    def __init__(self, temperature: float, gamma: float, dt: float, k_b: float = 1.0):
        self.temperature = nnx.Variable(jnp.array(temperature))
        self.gamma = nnx.Variable(jnp.array(gamma))
        self.dt = nnx.Variable(jnp.array(dt))
        self.k_b = k_b

    def apply(self, state: SimulationState) -> SimulationState:
        """
        Applies the Langevin velocity update.
        Uses the Ornstein-Uhlenbeck process for velocity rescaling.
        """
        key, subkey = jax.random.split(state.rng_key)
        sys = state.system

        temp = self.temperature[...]
        gamma = self.gamma[...]
        dt = self.dt[...]

        # Discretized OU process constants
        # c1 is the friction factor
        c1 = jnp.exp(-gamma * dt)

        # c2 is the random noise scale factor: sqrt((1 - c1^2) * kBT / m)
        masses = sys.masses[:, None]
        c2 = jnp.sqrt(1.0 - c1**2) * jnp.sqrt(self.k_b * temp / masses)

        # Sample random noise
        noise = jax.random.normal(subkey, sys.velocities.shape)

        # Update velocities
        new_v = sys.velocities * c1 + noise * c2

        new_sys = sys._replace(velocities=new_v)
        return state._replace(system=new_sys, rng_key=key)
