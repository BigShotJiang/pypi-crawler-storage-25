from typing import Any

from flax import nnx
import jax
import jax.numpy as jnp

from fluxmd.core.state import OverflowReport, SimulationState, Trajectory
from fluxmd.engine import Simulation


class Runner(nnx.Module):
    """
    Handles simulation execution logic: chunking, JIT-compilation,
    and automatic overflow recovery.
    """

    def __init__(self, sim: Simulation, chunk_size: int = 100):
        self.sim = sim
        self.chunk_size = chunk_size

    def run(self, state: SimulationState, n_steps: int) -> tuple[SimulationState, Trajectory]:
        """
        Runs the simulation for n_steps, using chunking and adaptive retry logic.
        """
        history = []
        for _ in range(n_steps // self.chunk_size):
            state, aux_history = self.run_chunk_with_retry(state)
            history.append(aux_history)

        # Concatenate history chunks if any
        full_history = {}
        if history:
            for key in history[0].keys():
                full_history[key] = jnp.concatenate([h[key] for h in history], axis=0)

        return state, Trajectory(aux=full_history)

    def run_chunk_with_retry(
        self, state: SimulationState
    ) -> tuple[SimulationState, dict[str, Any]]:
        """
        Executes a fixed-size chunk of steps, retrying with expanded buffers if an overflow occurs.
        """
        max_retries = 5
        for attempt in range(max_retries):
            initial_state = state

            # 1. Run the JIT-compiled chunk
            next_state, aux_history = self._run_chunk_jit(state, self.chunk_size)

            # 2. Check for overflows in the entire chunk
            overflows = aux_history["nl_overflow"]
            if jnp.any(overflows):
                # Find the first step that overflowed to get the report data
                idx = jnp.argmax(overflows)

                # Reconstruct report from flattened history
                report = OverflowReport(
                    max_neighbors_found=int(aux_history["nl_max_neighbors"][idx]),
                    max_range_required=int(aux_history["nl_max_range"][idx]),
                    neighbor_overflow=bool(aux_history["nl_neighbor_overflow"][idx]),
                    range_overflow=bool(aux_history["nl_range_overflow"][idx]),
                    overflow_occurred=True,
                )

                step_num = int(initial_state.step + idx + 1)
                print(f"\n[Runner] Overflow detected at step {step_num}")

                # Expand buffers
                self.sim.neighbor_list.expand(report)

                # Re-initialize the buffers with new shapes outside JIT
                self.sim.neighbor_list.update(state.system.positions, state.system.cell)

                # Retry from the initial state of this chunk
                print(
                    f"[Runner] Retrying chunk (attempt {attempt + 1}/{max_retries}) with expanded "
                    f"buffers..."
                )
                state = initial_state
                continue

            # Success!
            return next_state, aux_history

        raise RuntimeError(f"Simulation failed to resolve overflow after {max_retries} retries.")

    @nnx.jit(static_argnums=(2,))
    def _run_chunk_jit(
        self, state: SimulationState, n: int
    ) -> tuple[SimulationState, dict[str, Any]]:
        """
        Internal JIT-compiled lax.scan loop.
        """
        graphdef, sim_state = nnx.split(self.sim)

        def body(carry, _):
            curr_state, curr_sim_state = carry
            curr_sim = nnx.merge(graphdef, curr_sim_state)
            next_state = curr_sim.step(curr_state)
            _, next_sim_state = nnx.split(curr_sim)
            return (next_state, next_sim_state), next_state.aux

        (final_state, final_sim_state), aux_history = jax.lax.scan(
            body, (state, sim_state), None, length=n
        )

        nnx.update(self.sim, final_sim_state)
        return final_state, aux_history
