from flax import nnx
from jax import Array
import jax.numpy as jnp
from jaxtyping import Float


class Space(nnx.Module):
    """
    Abstract base class for simulation spaces.
    Handles all geometric and boundary logic.
    """

    def displacement(
        self, r1: Float[Array, "... 3"], r2: Float[Array, "... 3"], cell: Float[Array, "3 3"]
    ) -> Float[Array, "... 3"]:
        """Returns r2 - r1 accounting for boundaries."""
        raise NotImplementedError

    def distance(
        self, r1: Float[Array, "... 3"], r2: Float[Array, "... 3"], cell: Float[Array, "3 3"]
    ) -> Float[Array, "... 1"]:
        """Returns ||r2 - r1|| accounting for boundaries."""
        diff = self.displacement(r1, r2, cell)
        return jnp.linalg.norm(diff, axis=-1, keepdims=True)

    def wrap(
        self, positions: Float[Array, "N 3"], cell: Float[Array, "3 3"]
    ) -> Float[Array, "N 3"]:
        """Wraps positions into the primary simulation cell."""
        raise NotImplementedError

    def shift(
        self, positions: Float[Array, "N 3"], dr: Float[Array, "N 3"], cell: Float[Array, "3 3"]
    ) -> Float[Array, "N 3"]:
        """Updates positions by dr, usually with wrapping."""
        return self.wrap(positions + dr, cell)

    def get_image_shifts(
        self, cell: Float[Array, "3 3"], cutoff: float
    ) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
        """Returns periodic images (shifts, active_mask, max_range_required)."""
        raise NotImplementedError

    def apply_shifts(
        self, positions: jnp.ndarray, cell: jnp.ndarray, shifts: jnp.ndarray
    ) -> jnp.ndarray:
        """Generates all image positions for given shifts."""
        real_shifts = jnp.matmul(shifts.astype(float), cell)
        all_images = positions[None, :, :] + real_shifts[:, None, :]
        return all_images.reshape(-1, 3)


class FreeSpace(Space):
    """
    Non-periodic simulation space.
    """

    def displacement(self, r1, r2, cell):
        return r2 - r1

    def wrap(self, positions, cell):
        return positions

    def get_image_shifts(self, cell, cutoff):
        # Only the primary image
        shifts = jnp.zeros((1, 3), dtype=int)
        active_mask = jnp.array([True])
        return shifts, active_mask, jnp.zeros((), dtype=int)


class PeriodicSpace(Space):
    """
    Periodic simulation space with support for triclinic cells and multi-image search.
    """

    def __init__(self, max_range: int = 1):
        self.max_range = max_range

    def displacement(self, r1, r2, cell):
        """Minimum Image Convention (MIC) displacement."""
        diff = r2 - r1
        inv_cell = jnp.linalg.inv(cell)
        diff_frac = jnp.matmul(diff, inv_cell)
        diff_frac = diff_frac - jnp.round(diff_frac)
        return jnp.matmul(diff_frac, cell)

    def wrap(self, positions, cell):
        """Wraps positions to [0, 1) fractional coordinates, then back to real."""
        inv_cell = jnp.linalg.inv(cell)
        frac_pos = jnp.matmul(positions, inv_cell)
        frac_pos = frac_pos % 1.0
        return jnp.matmul(frac_pos, cell)

    def get_image_shifts(self, cell, cutoff):
        r = jnp.arange(-self.max_range, self.max_range + 1)
        shifts = jnp.stack(jnp.meshgrid(r, r, r, indexing="ij"), axis=-1).reshape(-1, 3)

        # 1. Calculate reciprocal lattice vectors norms to find heights
        inv_cell = jnp.linalg.inv(cell)
        recip_norms = jnp.linalg.norm(inv_cell, axis=0)  # Norms of columns of inv(cell)
        heights = 1.0 / recip_norms

        # 2. Number of images required in each direction
        n_req = jnp.ceil(cutoff / heights - 1e-6).astype(int)

        # 3. Create mask for images within the required range
        active_mask = jnp.all(jnp.abs(shifts) <= n_req[None, :], axis=1)

        # 4. Return the maximum n_req found across all directions as the report value
        return shifts, active_mask, jnp.max(n_req)
