from typing import Any, NamedTuple

from jax import Array
from jaxtyping import Float, Integer


class System(NamedTuple):
    """
    Static description of a physical system.
    Used for initialization before creating a runtime SimulationState.
    """

    positions: Float[Array, "N 3"]
    cell: Float[Array, "3 3"]
    masses: Float[Array, "N"] | None = None
    species: Integer[Array, "N"] | None = None


class SystemState(NamedTuple):
    """
    Minimal representation of a physical system.
    PyTree-compatible and immutable.
    """

    positions: Float[Array, "N 3"]
    velocities: Float[Array, "N 3"]
    forces: Float[Array, "N 3"]
    species: Integer[Array, "N"]
    masses: Float[Array, "N"]
    cell: Float[Array, "3 3"] | None = None


class OverflowReport(NamedTuple):
    """
    Structured report containing overflow information.
    Used for dynamic neighbor list expansion.
    """

    max_neighbors_found: int
    max_range_required: int
    neighbor_overflow: bool
    range_overflow: bool
    overflow_occurred: bool


class SimulationState(NamedTuple):
    """
    Wraps system state with simulation metadata.
    """

    system: SystemState
    step: Integer[Array, ""]
    rng_key: Any
    aux: dict[str, Any]  # May contain OverflowReport


class Trajectory(NamedTuple):
    """
    Encapsulates simulation history.
    """

    aux: dict[str, Array]
    states: SimulationState | None = None
