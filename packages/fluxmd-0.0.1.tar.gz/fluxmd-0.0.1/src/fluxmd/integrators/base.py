from flax import nnx
from jax import Array
import jax.numpy as jnp
from jaxtyping import Float

from fluxmd.core.state import SimulationState


class Integrator(nnx.Module):
    """
    Base interface for dynamics integrators.
    """

    def pre_step(self, state: SimulationState, forces: Float[Array, "N 3"]) -> SimulationState:
        """First half of the integration step."""
        raise NotImplementedError

    def post_step(self, state: SimulationState, forces: Float[Array, "N 3"]) -> SimulationState:
        """Second half of the integration step."""
        raise NotImplementedError


class VelocityVerlet(Integrator):
    """
    Standard Velocity Verlet implementation.
    """

    def __init__(self, dt: float):
        self.dt = nnx.Variable(jnp.array(dt))

    def pre_step(self, state: SimulationState, forces: Float[Array, "N 3"]) -> SimulationState:
        # 1. v(t + dt/2) = v(t) + 0.5 * a(t) * dt
        sys = state.system
        dt = self.dt[...]

        accel = forces / sys.masses[:, None]
        v_half = sys.velocities + 0.5 * accel * dt

        # 2. r(t + dt) = r(t) + v(t + dt/2) * dt
        r_next = sys.positions + v_half * dt

        new_sys = sys._replace(positions=r_next, velocities=v_half)
        return state._replace(system=new_sys)

    def post_step(self, state: SimulationState, forces: Float[Array, "N 3"]) -> SimulationState:
        # 3. v(t + dt) = v(t + dt/2) + 0.5 * a(t + dt) * dt
        sys = state.system
        dt = self.dt[...]

        # Note: v_half is stored in sys.velocities from pre_step
        accel_next = forces / sys.masses[:, None]
        v_next = sys.velocities + 0.5 * accel_next * dt

        new_sys = sys._replace(velocities=v_next, forces=forces)  # Store the new forces
        return state._replace(system=new_sys)
