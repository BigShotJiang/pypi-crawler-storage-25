from jax import Array
import jax.numpy as jnp
from jaxtyping import Float

from fluxmd.core.state import SystemState


def kinetic_energy(system: SystemState) -> Float[Array, ""]:
    """
    Computes the instantaneous kinetic energy of the system.
    K = sum(0.5 * m * v^2)
    """
    # masses: (N,), velocities: (N, 3)
    # v_sq: (N,)
    v_sq = jnp.sum(system.velocities**2, axis=-1)
    return 0.5 * jnp.sum(system.masses * v_sq)
