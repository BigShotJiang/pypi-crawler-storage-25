from jax import Array
from jaxtyping import Float

from fluxmd.core.state import SystemState
from fluxmd.observables.energy import kinetic_energy


def compute_temperature(system: SystemState, k_b: float = 1.0) -> Float[Array, ""]:
    """
    Computes the instantaneous temperature of the system.
    Based on the equipartition theorem: K = (dof / 2) * kB * T
    Assumes 3 degrees of freedom per atom.
    """
    n_atoms = system.positions.shape[0]
    ke = kinetic_energy(system)

    # Degrees of freedom (dof) = 3N
    # In a real simulation, one might subtract 3 for CoM removal,
    # but 3N is the standard approximation for large systems.
    dof = 3.0 * n_atoms

    return (2.0 * ke) / (dof * k_b)
