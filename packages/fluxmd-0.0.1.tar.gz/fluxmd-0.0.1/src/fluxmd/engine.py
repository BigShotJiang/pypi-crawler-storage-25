from typing import Any

from flax import nnx
import jax
import jax.numpy as jnp

from fluxmd.core.space import Space
from fluxmd.core.state import SimulationState, System, SystemState
from fluxmd.integrators.base import Integrator
from fluxmd.observables.energy import kinetic_energy
from fluxmd.observables.thermo import compute_temperature
from fluxmd.potentials.base import Potential
from fluxmd.utils.initialization import initialize_velocities


class Simulation(nnx.Module):
    """
    The main Simulation engine.
    """

    potential: Potential
    integrator: Integrator
    space: Space
    neighbor_list: Any | None
    thermostat: nnx.Module | None

    def __init__(
        self,
        potential: Potential,
        integrator: Integrator,
        space: Space,
        neighbor_list: Any | None = None,
        thermostat: nnx.Module | None = None,
    ):
        self.potential = potential
        self.integrator = integrator
        self.space = space
        self.neighbor_list = neighbor_list
        self.thermostat = thermostat

    def create_state(
        self, system: System, temperature: float | None = None, rng_key: Any | None = None
    ) -> SimulationState:
        """
        High-level entry point to create a ready-to-run SimulationState from a System description.
        Hides internal aux structure and automatically bootstraps physics.
        """
        # 1. Initialize SystemState internals
        n_atoms = system.positions.shape[0]
        masses = system.masses if system.masses is not None else jnp.ones(n_atoms)
        species = (
            system.species if system.species is not None else jnp.zeros(n_atoms, dtype=jnp.int32)
        )

        system_state = SystemState(
            positions=system.positions,
            velocities=jnp.zeros_like(system.positions),
            forces=jnp.zeros_like(system.positions),
            species=species,
            masses=masses,
            cell=system.cell,
        )

        # 2. Build initial SimulationState with default aux keys
        if rng_key is None:
            rng_key = jax.random.PRNGKey(0)

        state = SimulationState(
            system=system_state,
            step=jnp.array(0),
            rng_key=rng_key,
            aux={
                "kinetic_energy": jnp.array(0.0),
                "potential_energy": jnp.array(0.0),
                "total_energy": jnp.array(0.0),
                "temperature": jnp.array(0.0),
                "nl_overflow": jnp.array(False),
                "nl_neighbor_overflow": jnp.array(False),
                "nl_range_overflow": jnp.array(False),
                "nl_max_neighbors": jnp.array(0, dtype=jnp.int32),
                "nl_max_range": jnp.array(0, dtype=jnp.int32),
            },
        )

        # 3. Apply temperature if requested
        if temperature is not None:
            state = initialize_velocities(state, temperature)

        # 4. Bootstrap neighbor list and compute initial forces
        return self.initialize(state)

    def initialize(self, state: SimulationState) -> SimulationState:
        """
        Bootstrap the simulation: rebuilds neighbor list and computes initial forces.
        Returns a state ready for integration.
        """
        # 1. Update neighbor list if present
        if self.neighbor_list is not None:
            self.neighbor_list.update(state.system.positions, state.system.cell)

        # 2. Compute initial forces
        forces = self.potential.forces(state.system, self.neighbor_list)

        # 3. Return updated state
        system = state.system._replace(forces=forces)
        return state._replace(system=system)

    @nnx.jit
    def step(self, state: SimulationState) -> SimulationState:
        # 0. Use current forces from state
        forces = state.system.forces

        # 1. Pre-step (velocity half-step + position update)
        state = self.integrator.pre_step(state, forces)

        # 2. Apply boundary wrapping to keep positions canonical BEFORE neighbor list update
        wrapped_positions = self.space.wrap(state.system.positions, state.system.cell)
        state = state._replace(system=state.system._replace(positions=wrapped_positions))

        # 3. Update neighbor list if present and capture report (Lazy Rebuild)
        report = None
        if self.neighbor_list is not None:
            # Split neighbor list to handle functional state update in lax.cond
            nl_def, nl_state = nnx.split(self.neighbor_list)

            def rebuild_fn(state_in):
                nl = nnx.merge(nl_def, state_in)
                rep = nl.update(state.system.positions, state.system.cell)
                _, state_out = nnx.split(nl)
                return state_out, rep

            def skip_fn(state_in):
                nl = nnx.merge(nl_def, state_in)
                # Return cached info
                from fluxmd.core.state import OverflowReport

                rep = OverflowReport(
                    max_neighbors_found=nl.n_found.get_value(),
                    max_range_required=nl.n_req.get_value(),
                    neighbor_overflow=nl.overflow.get_value(),
                    range_overflow=jnp.array(False),
                    overflow_occurred=nl.overflow.get_value(),
                )
                return state_in, rep

            new_nl_state, report = jax.lax.cond(
                self.neighbor_list.needs_update(state.system.positions),
                rebuild_fn,
                skip_fn,
                nl_state,
            )
            nnx.update(self.neighbor_list, new_nl_state)

        # 4. Compute new forces at updated positions
        forces_next = self.potential.forces(state.system, self.neighbor_list)

        # 5. Post-step (velocity second half-step)
        state = self.integrator.post_step(state, forces_next)

        # 6. Apply thermostat if present
        if self.thermostat is not None:
            state = self.thermostat.apply(state)

        # 7. Compute observables
        ke = kinetic_energy(state.system)
        pe = self.potential.energy(state.system, self.neighbor_list)
        temp = compute_temperature(state.system)

        # Update aux dictionary with flat keys for better JAX-compatibility
        new_aux = state.aux.copy()
        new_aux.update(
            {
                "kinetic_energy": ke,
                "potential_energy": pe,
                "total_energy": ke + pe,
                "temperature": temp,
                "nl_overflow": report.overflow_occurred if report is not None else False,
                "nl_neighbor_overflow": report.neighbor_overflow if report is not None else False,
                "nl_range_overflow": report.range_overflow if report is not None else False,
                "nl_max_neighbors": report.max_neighbors_found if report is not None else 0,
                "nl_max_range": report.max_range_required if report is not None else 0,
            }
        )

        return state._replace(step=state.step + 1, aux=new_aux)
