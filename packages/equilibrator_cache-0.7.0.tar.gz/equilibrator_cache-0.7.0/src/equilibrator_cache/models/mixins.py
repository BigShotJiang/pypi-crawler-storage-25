"""A module for columns that are to be mixed in other tables."""

# The MIT License (MIT)
#
# Copyright (c) 2018 Institute for Molecular Systems Biology, ETH Zurich
# Copyright (c) 2018 Novo Nordisk Foundation Center for Biosustainability,
# Technical University of Denmark
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.


from datetime import datetime, timezone

from sqlalchemy import Column, DateTime
from sqlalchemy.orm import Mapped


def timezone_aware_now():
    """Return the date and time in this moment in the universal timezone."""
    return datetime.now(timezone.utc)


class TimeStampMixin:
    """
    Define creation and update time columns to be mixed in with other tables.

    Attributes
    ----------
    created_on : datetime
        By default this value is populated at instantiation with the time of
        the moment.
    updated_on : datetime
        The time is automatically populated whenever the database model is
        updated.

    """

    created_on: Mapped[datetime] = Column(
        DateTime(timezone=True), nullable=False, default=timezone_aware_now
    )
    updated_on: Mapped[datetime] = Column(
        DateTime(timezone=True), nullable=True, onupdate=timezone_aware_now
    )
