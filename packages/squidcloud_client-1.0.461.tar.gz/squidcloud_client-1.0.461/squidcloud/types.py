"""Type definitions for the Squid Python client SDK.

All types use camelCase field names to match the platform API.
TypedDict is used so dicts serialize directly to JSON without conversion.
"""

from __future__ import annotations

from typing import Any, Literal, TypedDict, Union

# --- Primitive aliases ---

AiAgentId = str
AiKnowledgeBaseId = str
IntegrationId = str

AiChatModelName = str
"""LLM model name string, e.g. 'gemini-3-flash', 'claude-sonnet-4-5-20250929'."""

AiChatModelSelection = Union[AiChatModelName, "IntegrationModelSpec"]
"""Either a model name string or an IntegrationModelSpec dict."""

AiReasoningEffort = Literal["minimal", "low", "medium", "high"]
AiVerbosityLevel = Literal["low", "medium", "high"]
AiRerankProvider = Literal["cohere"]
AiMemoryMode = Literal["read-write", "read-only", "write-only", "disabled"]


# --- AI Chat Options ---


class IntegrationModelSpec(TypedDict):
    """Specifies a model from a specific integration."""

    integrationId: str
    model: str


class AiAgentMemoryOptions(TypedDict, total=False):
    """Memory/session configuration for agent chat."""

    memoryId: str
    """Unique memory ID. Reuse to continue a conversation."""
    memoryMode: AiMemoryMode
    """How memory is used: 'read-write', 'read-only', 'write-only', 'disabled'."""


class AiConnectedAgentMetadata(TypedDict):
    """Metadata for a connected agent."""

    agentId: str
    description: str


class AiConnectedIntegrationMetadata(TypedDict, total=False):
    """Metadata for a connected integration."""

    integrationId: str
    description: str


class AiConnectedKnowledgeBaseMetadata(TypedDict, total=False):
    """Metadata for a connected knowledge base."""

    knowledgeBaseId: str
    description: str
    includeMetadata: bool


class AiFileUrl(TypedDict, total=False):
    """File URL to include in chat context."""

    id: str
    type: str
    purpose: str
    url: str
    description: str
    fileName: str


class AiStructuredOutputFormat(TypedDict):
    """Structured output format for JSON responses."""

    type: Literal["json_schema"]
    schema: dict[str, Any]


AiAgentResponseFormat = Union[Literal["text", "json_object"], AiStructuredOutputFormat]


class AiChatPromptQuotas(TypedDict, total=False):
    """Budget for nested/recursive AI chat calls."""

    maxNestedCalls: int


class AiAgentExecutionPlanOptions(TypedDict, total=False):
    """Options for AI agent execution plan."""

    enabled: bool


class GuardrailsOptions(TypedDict, total=False):
    """Guardrail options for agent responses."""

    custom: str
    """A custom guardrail instruction."""
    disablePii: bool
    """Disables personally identifiable information if true."""
    professionalTone: bool
    """Enforces a professional tone if true."""
    offTopicAnswers: bool
    """Prevents off-topic answers if true."""
    disableProfanity: bool
    """Disables profanity if true."""


class AiAudioCreateSpeechOptions(TypedDict, total=False):
    """Options for text-to-speech."""

    modelName: str
    """'tts-1' or 'tts-1-hd'."""
    voice: str
    """'alloy'|'ash'|'ballad'|'coral'|'echo'|'fable'|'onyx'|'nova'|'sage'|'shimmer'|'verse'."""
    responseFormat: str
    """Audio output format."""
    instructions: str
    """Extra instructions for speech generation."""
    speed: float
    """Speech speed."""


class AiChatOptions(TypedDict, total=False):
    """Full chat options for AI agent ask/chat operations.

    Mirrors BaseAiChatOptions from the TypeScript SDK.
    All fields are optional.
    """

    model: AiChatModelSelection
    """LLM model to use. String name or IntegrationModelSpec."""
    maxTokens: int
    """Max input tokens for the AI model."""
    maxOutputTokens: int
    """Max output tokens from the AI model."""
    temperature: float
    """Sampling temperature (default 0.5)."""
    instructions: str
    """Extra instructions to include with the prompt."""
    functions: list[str]
    """AI function IDs to expose to the agent."""
    memoryOptions: AiAgentMemoryOptions
    """Memory/session configuration."""
    responseFormat: AiAgentResponseFormat
    """Response format: 'text', 'json_object', or structured output."""
    includeReference: bool
    """Include source references from context."""
    smoothTyping: bool
    """Smooth typing effect for UI display (default true)."""
    disableContext: bool
    """Disable the whole context for this request."""
    enablePromptRewriteForRag: bool
    """Rewrite prompt for RAG (default false)."""
    agentContext: dict[str, Any]
    """Global context passed to agent and all AI functions."""
    connectedAgents: list[AiConnectedAgentMetadata]
    """Connected agents that can be called."""
    connectedIntegrations: list[AiConnectedIntegrationMetadata]
    """Connected integrations."""
    connectedKnowledgeBases: list[AiConnectedKnowledgeBaseMetadata]
    """Connected knowledge bases."""
    guardrails: GuardrailsOptions
    """Guardrail options."""
    contextMetadataFilterForKnowledgeBase: dict[str, Any]
    """Metadata filters per knowledge base ID."""
    voiceOptions: AiAudioCreateSpeechOptions
    """Options for voice response."""
    quotas: AiChatPromptQuotas
    """Budget for nested AI calls."""
    executionPlanOptions: AiAgentExecutionPlanOptions
    """Execution plan options."""
    fileUrls: list[AiFileUrl]
    """File URLs to include in context."""
    fileIds: list[str]
    """File IDs from AI provider's Files API."""
    reasoningEffort: AiReasoningEffort
    """Reasoning effort level."""
    verbosity: AiVerbosityLevel
    """Response verbosity level."""
    useCodeInterpreter: Literal["none", "llm"]
    """Enable LLM's built-in code interpreter."""
    rerankProvider: AiRerankProvider
    """Reranker provider for context (default 'cohere')."""
    includeMetadata: bool
    """Include metadata in context (deprecated)."""
    timeoutMs: int
    """Request timeout in milliseconds (default 240000)."""


# --- AI Query Options ---


AiQueryCollectionsSelectionRunMode = Literal["default", "force", "disable"]


class AiSessionContext(TypedDict, total=False):
    """Session context for AI query execution.

    Mirrors the TypeScript ``AiSessionContext`` type. All fields optional
    here because the query endpoint accepts a partial context (``agentId``
    may be omitted).
    """

    clientId: str
    agentId: str
    jobId: str


class AiQuerySelectCollectionsOptions(TypedDict, total=False):
    """Options for the collection-selection stage of AI query."""

    collectionsToUse: list[str]
    """Restrict query to these collections. Defaults to all collections."""
    runMode: AiQueryCollectionsSelectionRunMode
    """Stage behavior: 'default', 'force', or 'disable'."""
    aiOptions: AiChatOptions
    """Customize AI agent behavior used by the stage."""


class AiQueryGenerateQueryOptions(TypedDict, total=False):
    """Options for the query-generation stage of AI query."""

    aiOptions: AiChatOptions
    """Customize AI agent behavior used by the stage."""
    maxErrorCorrections: int
    """Number of retries due to errors in a generated AI query (default 2)."""
    agentId: AiAgentId
    """If set, use this agent to generate the query."""
    allowClarification: bool
    """When true, allow the AI to ask a clarifying question instead of
    generating a query for ambiguous prompts (default false)."""


class AiQueryAnalyzeResultsOptions(TypedDict, total=False):
    """Options for the result-analysis stage of AI query."""

    disabled: bool
    """When true, skip analysis and return raw results only."""
    enableCodeInterpreter: bool
    """Enable code interpreter mode (default false)."""
    aiOptions: AiChatOptions
    """Customize AI agent behavior used by the stage."""
    agentId: AiAgentId
    """If set, use this agent to analyze results and produce the final answer."""


class AiQueryValidateWithAiOptions(TypedDict, total=False):
    """Options for AI-based validation of generated queries."""

    enabled: bool
    """Whether AI validation is enabled."""
    aiOptions: AiChatOptions
    """Defaults to the same model used for query generation."""


class AiQueryOptions(TypedDict, total=False):
    """Options for configuring AI query execution.

    Mirrors ``AiQueryOptions`` from the TypeScript SDK. All fields optional.
    """

    instructions: str
    """Custom instructions applied to all stages unless overridden per-stage."""
    enableRawResults: bool
    """Enable raw results output."""
    selectCollectionsOptions: AiQuerySelectCollectionsOptions
    """Collection-selection stage options."""
    generateQueryOptions: AiQueryGenerateQueryOptions
    """Query-generation stage options."""
    analyzeResultsOptions: AiQueryAnalyzeResultsOptions
    """Result-analysis stage options."""
    sessionContext: AiSessionContext
    """Session information (``agentId`` may be omitted)."""
    memoryOptions: AiAgentMemoryOptions
    """Memory/session configuration."""
    generateQueriesOnly: bool
    """If true, return generated queries without executing or analyzing them."""
    validateWithAiOptions: AiQueryValidateWithAiOptions
    """Optional AI validation of generated queries."""


# --- Agent management types ---


class UpsertAgentOptions(TypedDict, total=False):
    """Options for creating/updating an agent."""

    description: str
    """Description of the agent's purpose."""
    isPublic: bool
    """Whether the agent is publicly accessible."""
    auditLog: bool
    """Enable audit logging."""
    apiKey: str
    """API key for this agent."""
    options: AiChatOptions
    """Default chat options."""


# --- Knowledge base types ---


class AiKnowledgeBaseMetadataField(TypedDict, total=False):
    """Metadata field definition for a knowledge base."""

    name: str
    dataType: str
    required: bool
    description: str


class AiContextTextOptions(TypedDict, total=False):
    """Options for text context processing."""

    chunkOverlap: int
    """Amount of chunk overlap in characters."""
    ragType: str
    """The type of RAG to use."""


class TextContextRequest(TypedDict, total=False):
    """Request to upsert a text context."""

    contextId: str
    type: Literal["text"]
    title: str
    text: str
    metadata: dict[str, Any]
    options: AiContextTextOptions


class AiContextFileOptions(TypedDict, total=False):
    """Options for file context processing."""

    chunkOverlap: int
    ragType: str


class FileContextRequest(TypedDict, total=False):
    """Request to upsert a file context."""

    contextId: str
    type: Literal["file"]
    metadata: dict[str, Any]
    extractImages: bool
    imageMinSizePixels: int
    extractionModel: AiChatModelSelection
    options: AiContextFileOptions
    preferredExtractionMethod: str
    discardOriginalFile: bool


ContextRequest = Union[TextContextRequest, FileContextRequest]


class KnowledgeBaseSearchOptions(TypedDict, total=False):
    """Options for knowledge base search."""

    prompt: str
    """The search prompt."""
    limit: int
    """Max number of results to return."""
    chunkLimit: int
    """How many chunks to search over (default 100)."""
    rerankProvider: AiRerankProvider
    """Reranker provider (default 'cohere')."""
    chatModel: AiChatModelSelection
    """Model to use for answering."""


# --- Image generation types ---


class DallEOptions(TypedDict, total=False):
    """Options for DALL-E image generation."""

    modelName: Literal["dall-e-3"]
    quality: Literal["hd", "standard"]
    size: Literal["1024x1024", "1792x1024", "1024x1792"]
    numberOfImagesToGenerate: Literal[1]


class FluxOptions(TypedDict, total=False):
    """Options for Flux image generation."""

    modelName: Literal["flux-pro-1.1", "flux-kontext-pro"]
    width: int
    """Must be multiple of 32, min 256, max 1440."""
    height: int
    """Must be multiple of 32, min 256, max 1440."""
    prompt_upsampling: bool
    seed: int
    safety_tolerance: int
    """1 (strict) to 5 (permissive)."""


class StableDiffusionOptions(TypedDict, total=False):
    """Options for Stable Diffusion Core image generation."""

    modelName: Literal["stable-diffusion-core"]
    aspectRatio: Literal["16:9", "1:1", "21:9", "2:3", "3:2", "4:5", "5:4", "9:16", "9:21"]
    negativePrompt: str
    seed: int
    stylePreset: str
    outputFormat: str


ImageGenerateOptions = Union[DallEOptions, FluxOptions, StableDiffusionOptions]


# --- Matchmaking types ---


class MmCategory(TypedDict):
    """Matchmaking category."""

    id: str
    description: str


class MmEntity(TypedDict, total=False):
    """Matchmaking entity."""

    id: str
    content: str
    categoryId: str
    metadata: dict[str, Any]


class MmFindMatchesOptions(TypedDict, total=False):
    """Options for finding matches."""

    metadataFilter: dict[str, Any]
    """AiContextMetadataFilter conditions."""
    limit: int
    """Max matches to return (default 100, max 100)."""
    matchToCategoryId: str
    """Category to match against."""


class MmListEntitiesOptions(TypedDict, total=False):
    """Options for listing entities."""

    metadataFilter: dict[str, Any]
    limit: int


# --- Extraction types ---


class CreatePdfFormatOptions(TypedDict):
    """PDF output options by format."""

    type: Literal["format"]
    format: Literal[
        "letter",
        "legal",
        "tabloid",
        "ledger",
        "a0",
        "a1",
        "a2",
        "a3",
        "a4",
        "a5",
        "a6",
    ]


class CreatePdfDimensionsOptions(TypedDict):
    """PDF output options by custom dimensions."""

    type: Literal["dimensions"]
    width: int
    """Width in pixels."""
    height: int
    """Height in pixels."""


CreatePdfOutputOptions = Union[CreatePdfFormatOptions, CreatePdfDimensionsOptions]


class ExtractDataFromDocumentOptions(TypedDict, total=False):
    """Options for document data extraction."""

    extractImages: bool
    """Whether to extract embedded images."""
    imageMinSizePixels: int
    """Minimum image size to extract."""
    pageIndexes: list[int]
    """Specific pages to extract (0-based)."""
    preferredExtractionMethod: str
    discardOriginalFile: bool


# --- Web types ---


class WebShortUrlResponse(TypedDict):
    """Response from creating a short URL."""

    id: str
    shortUrl: str
    expiry: str


class WebShortUrlBulkResponse(TypedDict):
    """Response from creating bulk short URLs."""

    ids: list[str]
    shortUrls: list[str]
    expiry: str


class WebAiSearchResponse(TypedDict):
    """Response from AI web search."""

    markdownText: str
    citedUrls: list[dict[str, str]]
