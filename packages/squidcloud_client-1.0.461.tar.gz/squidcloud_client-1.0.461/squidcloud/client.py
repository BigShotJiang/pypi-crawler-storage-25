"""Main Squid client class.

Mirrors the TypeScript Squid class from typescript-client/src/squid.ts.
Provides access to all sub-clients (AI, web, extraction, matchmaking)
and direct operations (execute function, execute webhook).
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from squidcloud.ai import AiClient, execute_ai_query
from squidcloud.extraction import ExtractionClient
from squidcloud.http import HttpTransport, build_url
from squidcloud.matchmaking import MatchmakingClient
from squidcloud.web import WebClient

if TYPE_CHECKING:
    from squidcloud.types import AiQueryOptions


class Squid:
    """Squid Cloud Python client.

    The main entry point for interacting with the Squid Cloud platform.
    Provides access to AI agents, knowledge bases, web utilities,
    matchmaking, document extraction, backend functions, and webhooks.

    Usage::

        squid = Squid(
            app_id="my-app",
            api_key="sk-...",
            region="us-east-1.aws",
            environment_id="dev",
        )

        # AI agent
        response = await squid.ai().agent("my-agent").ask("Hello!")

        # Execute backend function
        result = await squid.execute_function("MyService:greet", "World")

        # Web search
        results = await squid.web().ai_search("latest news")

        # Cleanup
        await squid.close()

    Can also be used as an async context manager::

        async with Squid(app_id="my-app", api_key="sk-...", region="us-east-1.aws") as squid:
            result = await squid.ai().agent("my-agent").ask("Hello!")
    """

    def __init__(
        self,
        app_id: str,
        region: str,
        api_key: str | None = None,
        environment_id: str | None = None,
        squid_developer_id: str | None = None,
    ) -> None:
        """Initialize the Squid client.

        Args:
            app_id: The Squid application ID.
            region: The deployment region (e.g., 'us-east-1.aws', 'local').
            api_key: API key for authentication. Required for most operations.
            environment_id: Environment identifier (e.g., 'dev', 'prod').
                Appended to app_id as '{app_id}-{environment_id}'.
            squid_developer_id: Developer identifier for local development.
                Appended to app_id as '{app_id}-{environment_id}-{developer_id}'.
        """
        self._app_id = app_id
        self._region = region
        self._environment_id = environment_id
        self._squid_developer_id = squid_developer_id

        full_app_id = app_id
        if environment_id:
            full_app_id = f"{app_id}-{environment_id}"
        if squid_developer_id:
            full_app_id = f"{full_app_id}-{squid_developer_id}"

        self._full_app_id = full_app_id
        self._http = HttpTransport(
            app_id=full_app_id,
            region=region,
            api_key=api_key,
        )

    @property
    def app_id(self) -> str:
        """The application ID (without environment/developer suffix)."""
        return self._app_id

    @property
    def region(self) -> str:
        """The deployment region."""
        return self._region

    @property
    def client_id(self) -> str:
        """The unique client instance ID (UUID generated per Squid instance)."""
        return self._http.client_id

    # --- Sub-clients ---

    def ai(self) -> AiClient:
        """Access AI operations.

        Provides access to AI agents, knowledge bases, image generation,
        and audio transcription/synthesis.

        Returns:
            An :class:`AiClient` instance.

        Example::

            agent = squid.ai().agent("my-agent")
            response = await agent.ask("What is the weather?")

            kb = squid.ai().knowledge_base("my-kb")
            results = await kb.search("query")
        """
        return AiClient(self._http)

    def web(self) -> WebClient:
        """Access web utilities.

        Provides AI-powered web search, URL content extraction,
        and short URL management.

        Returns:
            A :class:`WebClient` instance.

        Example::

            content = await squid.web().get_url_content("https://example.com")
            results = await squid.web().ai_search("latest AI news")
        """
        return WebClient(self._http)

    def matchmaking(self) -> MatchmakingClient:
        """Access AI-powered matchmaking.

        Provides match maker management, entity CRUD,
        and AI-powered entity matching.

        Returns:
            A :class:`MatchmakingClient` instance.

        Example::

            mm = squid.matchmaking()
            await mm.create_match_maker("jobs", "Job matching", categories=[...])
            matches = await mm.find_matches("jobs", "entity-1")
        """
        return MatchmakingClient(self._http)

    def extraction(self) -> ExtractionClient:
        """Access document extraction and PDF creation.

        Provides PDF generation from HTML or URLs, and structured data
        extraction from documents (PDF, DOCX, images, etc.).

        Returns:
            An :class:`ExtractionClient` instance.

        Example::

            pdf = await squid.extraction().create_pdf_from_html("<h1>Hello</h1>")
            data = await squid.extraction().extract_data_from_document_url(
                "https://example.com/doc.pdf"
            )
        """
        return ExtractionClient(self._http)

    # --- Execute backend function ---

    async def execute_function(
        self,
        function_name: str,
        *params: Any,
    ) -> Any:
        """Execute a backend function by name.

        Calls a function defined in a Squid backend service using the
        ``@executable()`` decorator.

        Args:
            function_name: The service function name in the format
                ``"ClassName:methodName"`` (e.g., ``"MyService:greet"``).
            *params: Positional arguments to pass to the function.
                Must be JSON-serializable.

        Returns:
            The function's return value, deserialized from JSON.

        Raises:
            SquidHttpError: If the function is not found or throws an error.

        Example::

            result = await squid.execute_function("MyService:greet", "World")
            # result == "Hello, World!"

            data = await squid.execute_function("MyService:getData", 42, True)
        """
        result = await self._http.post(
            f"backend-function/execute?{function_name}",
            {
                "functionName": function_name,
                "paramsArrayStr": json.dumps(list(params)),
            },
        )
        if isinstance(result, dict):
            payload = result.get("payload")
            if isinstance(payload, str):
                return json.loads(payload)
            return payload
        return result

    # --- Execute webhook ---

    async def execute_webhook(
        self,
        webhook_id: str,
        *,
        body: Any = None,
        headers: dict[str, str] | None = None,
        method: str = "POST",
    ) -> Any:
        """Execute a webhook.

        Calls a webhook endpoint defined in a Squid backend service
        using the ``@webhook()`` decorator.

        Args:
            webhook_id: The webhook ID as defined in the ``@webhook("id")`` decorator.
            body: The request body to send. Must be JSON-serializable.
            headers: Extra HTTP headers to include in the request.
            method: The HTTP method to use (default ``"POST"``).

        Returns:
            The webhook's response body, deserialized from JSON.

        Raises:
            SquidHttpError: If the webhook is not found or returns an error.

        Example::

            result = await squid.execute_webhook("my-hook", body={"key": "value"})
        """
        return await self._http.post(
            f"webhooks/{webhook_id}",
            body,
            extra_headers=headers,
        )

    def get_webhook_url(self, webhook_id: str) -> str:
        """Get the full URL for a webhook endpoint.

        Useful for providing the webhook URL to external services that
        need to send HTTP requests to your Squid backend.

        Args:
            webhook_id: The webhook ID.

        Returns:
            The full URL string (e.g.,
            ``"https://myapp.us-east-1.aws.squid.cloud/webhooks/my-hook"``).

        Example::

            url = squid.get_webhook_url("stripe-events")
            # url == "https://myapp-dev.us-east-1.aws.squid.cloud/webhooks/stripe-events"
        """
        return build_url(self._region, self._full_app_id, f"webhooks/{webhook_id}")

    # --- AI Query ---

    async def execute_ai_query(
        self,
        integration_id: str,
        prompt: str,
        *,
        options: AiQueryOptions | None = None,
        response_format: dict[str, Any] | None = None,
    ) -> dict:
        """Execute an AI-powered database query.

        Uses AI to generate and execute database queries based on a
        natural language prompt.

        Args:
            integration_id: The database integration ID to query against.
            prompt: A natural language description of the data you want.
            options: Optional :class:`AiQueryOptions` controlling collection
                selection, query generation (including ``allowClarification``),
                result analysis (including ``enableCodeInterpreter``), memory,
                AI validation, per-stage model overrides via ``aiOptions``,
                and custom instructions.
            response_format: Optional structured output format, e.g.,
                ``{"type": "json_schema", "schema": {...}}``.

        Returns:
            An ``AiQueryResponse`` dict containing:
                - ``answer`` (str): The AI-generated answer.
                - ``explanation`` (str): How the answer was derived.
                - ``executedQueries`` (list): The actual queries that were run.
                - ``success`` (bool): Whether the query succeeded.
                - ``usedCodeInterpreter`` (bool): Whether the code
                  interpreter was used to analyze results.
                - ``clarificationQuestion`` (str): If the AI needs more info.

        Example::

            result = await squid.execute_ai_query(
                "my-database",
                "How many users signed up last week?",
                options={
                    "selectCollectionsOptions": {"collectionsToUse": ["users"]},
                    "analyzeResultsOptions": {"enableCodeInterpreter": True},
                },
            )
            print(result["answer"])
        """
        return await execute_ai_query(
            self._http,
            integration_id,
            prompt,
            options=options,
            response_format=response_format,
        )

    # --- Lifecycle ---

    async def close(self) -> None:
        """Close the HTTP client and release resources.

        Should be called when the Squid client is no longer needed.
        Alternatively, use the client as an async context manager.
        """
        await self._http.close()

    async def __aenter__(self) -> Squid:
        """Enter async context manager."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context manager and close resources."""
        await self.close()
