"""Matchmaking client.

Covers all /squid-api/v1/ai/matchmaking/* endpoints from the OpenAPI spec.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from squidcloud.http import HttpTransport
    from squidcloud.types import (
        MmCategory,
        MmEntity,
        MmFindMatchesOptions,
        MmListEntitiesOptions,
    )


class MatchmakingClient:
    """AI-powered matchmaking: match makers, entities, matching."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    # --- Match makers ---

    async def create_match_maker(
        self,
        match_maker_id: str,
        description: str,
        categories: list[MmCategory],
    ) -> dict:
        """Create a new match maker."""
        return await self._http.post(
            "squid-api/v1/ai/matchmaking/createMatchMaker",
            {"id": match_maker_id, "description": description, "categories": categories},
        )

    async def get_match_maker(self, match_maker_id: str) -> dict | None:
        """Get a match maker by ID."""
        result = await self._http.get(f"squid-api/v1/ai/matchmaking/getMatchMaker/{match_maker_id}")
        return result.get("matchMaker") if result else None

    async def list_match_makers(self) -> list[dict]:
        """List all match makers."""
        result = await self._http.get("squid-api/v1/ai/matchmaking/listMatchMakers")
        return result.get("matchMakers", []) if result else []

    async def delete_match_maker(self, match_maker_id: str) -> None:
        """Delete a match maker."""
        await self._http.post(
            "squid-api/v1/ai/matchmaking/deleteMatchMaker",
            {"matchMakerId": match_maker_id},
        )

    # --- Entities ---

    async def insert_entities(self, match_maker_id: str, entities: list[MmEntity]) -> None:
        """Insert entities into a match maker."""
        await self._http.post(
            "squid-api/v1/ai/matchmaking/insertEntities",
            {"matchMakerId": match_maker_id, "entities": entities},
        )

    async def delete_entity(self, match_maker_id: str, entity_id: str) -> None:
        """Delete an entity."""
        await self._http.post(
            "squid-api/v1/ai/matchmaking/deleteEntity",
            {"matchMakerId": match_maker_id, "entityId": entity_id},
        )

    async def get_entity(self, match_maker_id: str, entity_id: str) -> dict | None:
        """Get a specific entity."""
        result = await self._http.get(
            f"squid-api/v1/ai/matchmaking/getEntity/{match_maker_id}/{entity_id}"
        )
        return result.get("entity") if result else None

    async def list_entities(
        self,
        match_maker_id: str,
        category_id: str,
        options: MmListEntitiesOptions | None = None,
    ) -> list[dict]:
        """List entities in a category."""
        result = await self._http.post(
            "squid-api/v1/ai/matchmaking/listEntities",
            {
                "matchMakerId": match_maker_id,
                "categoryId": category_id,
                "options": options or {},
            },
        )
        return result.get("entities", []) if result else []

    # --- Matching ---

    async def find_matches(
        self,
        match_maker_id: str,
        entity_id: str,
        options: MmFindMatchesOptions | None = None,
    ) -> list[dict]:
        """Find matches for an existing entity.

        Returns list of MmEntityMatch dicts with:
        id, content, categoryId, metadata, score, reasoning.
        """
        result = await self._http.post(
            "squid-api/v1/ai/matchmaking/findMatches",
            {
                "matchMakerId": match_maker_id,
                "entityId": entity_id,
                "options": options or {},
            },
        )
        return result.get("matches", []) if result else []

    async def find_matches_for_entity(
        self,
        match_maker_id: str,
        entity: MmEntity,
        options: MmFindMatchesOptions | None = None,
    ) -> list[dict]:
        """Find matches for a new entity (not yet inserted)."""
        result = await self._http.post(
            "squid-api/v1/ai/matchmaking/findMatchesForEntity",
            {
                "matchMakerId": match_maker_id,
                "entity": entity,
                "options": options or {},
            },
        )
        return result.get("matches", []) if result else []
