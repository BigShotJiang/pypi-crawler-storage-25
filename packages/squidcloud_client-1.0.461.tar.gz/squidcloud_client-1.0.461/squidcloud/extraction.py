"""Extraction client — PDF creation and document data extraction.

Covers all /squid-api/v1/extraction/* endpoints from the OpenAPI spec.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from squidcloud.http import HttpTransport
    from squidcloud.types import CreatePdfOutputOptions, ExtractDataFromDocumentOptions


class ExtractionClient:
    """Document extraction and PDF creation."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    async def create_pdf_from_html(
        self,
        inner_html: str,
        *,
        title: str | None = None,
        css_url: str | None = None,
        output_options: CreatePdfOutputOptions | None = None,
    ) -> dict:
        """Create a PDF from HTML content.

        Returns CreatePdfResponse with 'url' and 'fileName'.
        """
        body: dict[str, Any] = {"type": "html", "innerHtml": inner_html}
        if title is not None:
            body["title"] = title
        if css_url is not None:
            body["cssUrl"] = css_url
        if output_options is not None:
            body["outputOptions"] = output_options
        return await self._http.post("squid-api/v1/extraction/createPdf", body)

    async def create_pdf_from_url(
        self,
        url: str,
        *,
        title: str | None = None,
        output_options: CreatePdfOutputOptions | None = None,
    ) -> dict:
        """Create a PDF from a URL.

        Returns CreatePdfResponse with 'url' and 'fileName'.
        """
        body: dict[str, Any] = {"type": "url", "url": url}
        if title is not None:
            body["title"] = title
        if output_options is not None:
            body["outputOptions"] = output_options
        return await self._http.post("squid-api/v1/extraction/createPdf", body)

    async def extract_data_from_document_url(
        self,
        url: str,
        options: ExtractDataFromDocumentOptions | None = None,
    ) -> dict:
        """Extract structured data from a document URL.

        Returns ExtractDataFromDocumentResponse with 'pages' and optional 'longTermStoragePath'.
        """
        body: dict[str, Any] = {"url": url}
        if options is not None:
            body["options"] = options
        return await self._http.post("squid-api/v1/extraction/extractDataFromDocumentUrl", body)

    async def extract_data_from_document_file(
        self,
        file_data: bytes,
        filename: str,
        content_type: str = "application/pdf",
        options: ExtractDataFromDocumentOptions | None = None,
    ) -> dict:
        """Extract structured data from a document file.

        Returns ExtractDataFromDocumentResponse with 'pages' and optional 'longTermStoragePath'.
        """
        request: dict[str, Any] = {}
        if options is not None:
            request["options"] = options
        form_data = {"request": json.dumps(request)}

        return await self._http.post_form(
            "squid-api/v1/extraction/extractDataFromDocumentFile",
            data=form_data,
            files=[("file", (filename, file_data, content_type))],
        )
