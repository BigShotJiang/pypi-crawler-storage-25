"""Squid Cloud Python client SDK.

Usage::

    from squidcloud import Squid

    squid = Squid(
        app_id="my-app",
        api_key="my-api-key",
        region="us-east-1.aws",
        environment_id="dev",
    )

    # AI agents
    response = await squid.ai().agent("my-agent").ask("Hello!")

    # Execute backend function
    result = await squid.execute_function("MyService:greet", "World")

    # Web utilities
    content = await squid.web().get_url_content("https://example.com")
"""

from squidcloud.client import Squid
from squidcloud.types import (
    AiAgentExecutionPlanOptions,
    AiAgentMemoryOptions,
    AiAgentResponseFormat,
    AiAudioCreateSpeechOptions,
    AiChatModelSelection,
    AiChatOptions,
    AiChatPromptQuotas,
    AiConnectedAgentMetadata,
    AiConnectedIntegrationMetadata,
    AiConnectedKnowledgeBaseMetadata,
    AiContextFileOptions,
    AiContextTextOptions,
    AiFileUrl,
    AiKnowledgeBaseMetadataField,
    AiQueryAnalyzeResultsOptions,
    AiQueryCollectionsSelectionRunMode,
    AiQueryGenerateQueryOptions,
    AiQueryOptions,
    AiQuerySelectCollectionsOptions,
    AiQueryValidateWithAiOptions,
    AiSessionContext,
    AiStructuredOutputFormat,
    ContextRequest,
    CreatePdfDimensionsOptions,
    CreatePdfFormatOptions,
    CreatePdfOutputOptions,
    DallEOptions,
    ExtractDataFromDocumentOptions,
    FileContextRequest,
    FluxOptions,
    GuardrailsOptions,
    ImageGenerateOptions,
    IntegrationModelSpec,
    KnowledgeBaseSearchOptions,
    MmCategory,
    MmEntity,
    MmFindMatchesOptions,
    MmListEntitiesOptions,
    StableDiffusionOptions,
    TextContextRequest,
    UpsertAgentOptions,
    WebAiSearchResponse,
    WebShortUrlBulkResponse,
    WebShortUrlResponse,
)

__all__ = [
    "AiAgentExecutionPlanOptions",
    "AiAgentMemoryOptions",
    "AiAgentResponseFormat",
    "AiAudioCreateSpeechOptions",
    "AiChatModelSelection",
    # AI Chat
    "AiChatOptions",
    "AiChatPromptQuotas",
    "AiConnectedAgentMetadata",
    "AiConnectedIntegrationMetadata",
    "AiConnectedKnowledgeBaseMetadata",
    "AiContextFileOptions",
    "AiContextTextOptions",
    "AiFileUrl",
    # Knowledge Base
    "AiKnowledgeBaseMetadataField",
    # AI Query
    "AiQueryAnalyzeResultsOptions",
    "AiQueryCollectionsSelectionRunMode",
    "AiQueryGenerateQueryOptions",
    "AiQueryOptions",
    "AiQuerySelectCollectionsOptions",
    "AiQueryValidateWithAiOptions",
    "AiSessionContext",
    "AiStructuredOutputFormat",
    "ContextRequest",
    "CreatePdfDimensionsOptions",
    "CreatePdfFormatOptions",
    # Extraction
    "CreatePdfOutputOptions",
    "DallEOptions",
    "ExtractDataFromDocumentOptions",
    "FileContextRequest",
    "FluxOptions",
    "GuardrailsOptions",
    # Image
    "ImageGenerateOptions",
    "IntegrationModelSpec",
    "KnowledgeBaseSearchOptions",
    # Matchmaking
    "MmCategory",
    "MmEntity",
    "MmFindMatchesOptions",
    "MmListEntitiesOptions",
    "Squid",
    "StableDiffusionOptions",
    "TextContextRequest",
    "UpsertAgentOptions",
    # Web
    "WebAiSearchResponse",
    "WebShortUrlBulkResponse",
    "WebShortUrlResponse",
]
