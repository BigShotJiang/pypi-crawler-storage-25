"""Web utilities client.

Covers all /squid-api/v1/web/* endpoints from the OpenAPI spec.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from squidcloud.http import HttpTransport
    from squidcloud.types import WebAiSearchResponse, WebShortUrlBulkResponse, WebShortUrlResponse


class WebClient:
    """Web utilities: AI search, URL content, short URLs."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    async def ai_search(self, query: str) -> WebAiSearchResponse:
        """Perform an AI-powered web search.

        Returns WebAiSearchResponse with 'markdownText' and 'citedUrls'.
        """
        return await self._http.post("squid-api/v1/web/aiSearch", {"query": query})

    async def get_url_content(self, url: str) -> str:
        """Fetch and extract content from a URL as markdown."""
        result = await self._http.post("squid-api/v1/web/getUrlContent", {"url": url})
        if isinstance(result, dict):
            return result.get("markdownText", "")
        return str(result) if result else ""

    async def create_short_url(
        self,
        url: str,
        *,
        seconds_to_live: int | None = None,
        file_extension: str | None = None,
    ) -> WebShortUrlResponse:
        """Create a short URL.

        Returns WebShortUrlResponse with 'id', 'shortUrl', 'expiry'.
        """
        body: dict = {"url": url}
        if seconds_to_live is not None:
            body["secondsToLive"] = seconds_to_live
        if file_extension is not None:
            body["fileExtension"] = file_extension
        return await self._http.post("squid-api/v1/web/createShortUrl", body)

    async def create_short_urls(
        self,
        urls: list[str],
        *,
        seconds_to_live: int | None = None,
        file_extension: str | None = None,
    ) -> WebShortUrlBulkResponse:
        """Create multiple short URLs in bulk.

        Returns WebShortUrlBulkResponse with 'ids', 'shortUrls', 'expiry'.
        """
        body: dict = {"urls": urls}
        if seconds_to_live is not None:
            body["secondsToLive"] = seconds_to_live
        if file_extension is not None:
            body["fileExtension"] = file_extension
        return await self._http.post("squid-api/v1/web/createShortUrls", body)

    async def delete_short_url(self, url_id: str) -> None:
        """Delete a short URL."""
        await self._http.post("squid-api/v1/web/deleteShortUrl", {"id": url_id})

    async def delete_short_urls(self, url_ids: list[str]) -> None:
        """Delete multiple short URLs."""
        await self._http.post("squid-api/v1/web/deleteShortUrls", {"ids": url_ids})
