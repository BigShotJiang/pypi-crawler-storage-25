# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

"""Bundle persistence for FEModel — schema v1.

Round-trips an FEModel through a single zip file::

    <name>_v1.zip
    ├── manifest.json   schema version, gmsh version, timestamp, model name
    ├── geometry.brep   OCC BREP — present iff the model has OCC entities
    ├── mesh.msh        gmsh native v4 (preserves entity/node/element tags)
    └── state.json      Python-side dicts (loads, materials, sections, ...)

Use :func:`save_bundle` and :func:`load_bundle`.

Limitations of v1:
    * Only the active gmsh model is captured. If ``FEModel._models`` lists
      multiple gmsh models, only the current one is round-tripped — the
      remaining names survive in ``state.json`` for reference but their
      geometry/mesh is not restored.
"""
from __future__ import annotations

import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Tuple, cast

import gmsh
from gmsh import model as gmsh_model
from pydantic import BaseModel

from pycivil.EXAGeometry.geometry import Point3dMdl, Vector3dMdl

from .fe_types import (
    Elem,
    FEMaterial,
    LoadType,
    NodalSpringsDir,
    NodalSpringsTp,
    PlateFaceLoad,
    PlateFaceSupport,
    SectionShape,
)

if TYPE_CHECKING:
    from .fe import FEModel


SCHEMA_VERSION = 1
BUNDLE_SUFFIX = "_v1.zip"

_MANIFEST = "manifest.json"
_GEOMETRY = "geometry.brep"
_MESH = "mesh.msh"
_STATE = "state.json"


class _Manifest(BaseModel):
    schema_version: int
    gmsh_version: str
    created_at: str
    model_name: str
    has_geometry: bool
    has_mesh: bool


class FEModelStateV1(BaseModel):
    """Serialisable Python-side state of an FEModel."""

    description: str
    log_level: int
    models: List[str]

    load_case: Dict[str, Tuple[str, str]]
    loads: Dict[str, Dict[str, Any]]
    load_combinations: Dict[str, List[float]]

    section_shapes: Dict[int, SectionShape]
    material_library: Dict[int, FEMaterial]

    initial_temperatures: Dict[str, float]
    inertial_acceleration: Dict[str, Tuple[float, float, float]]
    group_tree: Dict[str, str]

    node_supports: Dict[int, Tuple[bool, bool, bool, bool, bool, bool]]
    node_springs: Dict[int, Dict[NodalSpringsTp, Dict[NodalSpringsDir, float]]]
    node_temperatures: Dict[str, Dict[int, Dict[str, float]]]
    macro_element_node: Dict[int, Point3dMdl]

    frame_temperatures: Dict[str, Dict[int, Dict[str, Tuple[float, float]]]]
    frames_springs: Dict[int, Tuple[float, float, bool]]
    macro_element_frame: Dict[int, Tuple[int, int]]
    frames_local_2: Dict[int, Vector3dMdl]
    frames_shapes: Dict[int, int]
    frames_material: Dict[int, int]
    frames_physical_names: Dict[int, List[str]]

    plates_local_1: Dict[int, Vector3dMdl]
    macro_element_plate: Dict[int, Tuple[int, ...]]
    tag_to_group_for_rename: Dict[str, Dict[int, int]]
    plates_physical_names: Dict[int, List[str]]
    plates_material: Dict[int, int]
    plates_thicknesses: Dict[int, Tuple[float, float]]
    plates_face_supports: Dict[int, PlateFaceSupport]


def _int_keys(d: Dict[Any, Any]) -> Dict[int, Any]:
    return {int(k): v for k, v in d.items()}


def _serialise_loads(
    loads: Dict[str, Dict[LoadType, Any]],
) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for lc, by_tp in loads.items():
        out[lc] = {}
        for tp, payload in by_tp.items():
            tp_str = tp.value if isinstance(tp, LoadType) else str(tp)
            if tp == LoadType.PLATE_FACE_LOAD:
                out[lc][tp_str] = {
                    str(int(k)): v.model_dump() for k, v in payload.items()
                }
            elif tp == LoadType.SELF_WEIGHT:
                out[lc][tp_str] = list(payload)
            elif tp == LoadType.FRAME_LOAD:
                out[lc][tp_str] = {
                    str(int(tag)): {
                        sub_tp: dict(by_dir) for sub_tp, by_dir in by_sub.items()
                    }
                    for tag, by_sub in payload.items()
                }
            elif tp == LoadType.NODE_LOAD:
                out[lc][tp_str] = {
                    str(int(tag)): dict(v) for tag, v in payload.items()
                }
            else:
                out[lc][tp_str] = payload
    return out


def _deserialise_loads(
    loads: Dict[str, Dict[str, Any]],
) -> Dict[str, Dict[LoadType, Any]]:
    out: Dict[str, Dict[LoadType, Any]] = {}
    for lc, by_tp in loads.items():
        out[lc] = {}
        for tp_str, payload in by_tp.items():
            tp = LoadType(tp_str)
            if tp == LoadType.PLATE_FACE_LOAD:
                out[lc][tp] = {int(k): PlateFaceLoad(**v) for k, v in payload.items()}
            elif tp == LoadType.SELF_WEIGHT:
                out[lc][tp] = tuple(payload)
            elif tp == LoadType.FRAME_LOAD:
                out[lc][tp] = {
                    int(tag): {
                        sub_tp: dict(by_dir) for sub_tp, by_dir in by_sub.items()
                    }
                    for tag, by_sub in payload.items()
                }
            elif tp == LoadType.NODE_LOAD:
                out[lc][tp] = {int(tag): dict(v) for tag, v in payload.items()}
            else:
                out[lc][tp] = payload
    return out


def _build_state(model: "FEModel") -> FEModelStateV1:
    return FEModelStateV1(
        description=model._description,
        log_level=model._logLevel,
        models=list(model._models),
        load_case=model._loadCase,
        loads=_serialise_loads(model._loads),
        load_combinations=model._loadCombinations,
        section_shapes=model._sectionShapes,
        material_library=model._materialLibrary,
        initial_temperatures=model._initialTemperatures,
        inertial_acceleration=model._inertialAcceleration,
        group_tree=model._groupTree,
        node_supports=_int_keys(model._nodeSupports),
        node_springs=_int_keys(model._nodeSprings),
        node_temperatures=model._nodeTemperatures,
        macro_element_node={
            int(k): Point3dMdl.from_obj(v)
            for k, v in model._macro_element_node.items()
        },
        frame_temperatures=model._frameTemperatures,
        frames_springs=_int_keys(model._framesSprings),
        macro_element_frame=model._macro_element_frame,
        frames_local_2={
            int(k): Vector3dMdl.from_obj(v) for k, v in model._framesLocal2.items()
        },
        frames_shapes=_int_keys(model._framesShapes),
        frames_material=_int_keys(model._framesMaterial),
        frames_physical_names=_int_keys(model._framesPhysicalNames),
        plates_local_1={
            int(k): Vector3dMdl.from_obj(v) for k, v in model._platesLocal1.items()
        },
        macro_element_plate=cast(
            Dict[int, Tuple[int, ...]], model._macro_element_plate
        ),
        tag_to_group_for_rename={
            elem.name: dict(d) for elem, d in model._tagToGroupForRename.items()
        },
        plates_physical_names=_int_keys(model._platesPhysicalNames),
        plates_material=_int_keys(model._platesMaterial),
        plates_thicknesses=_int_keys(model._platesThicknesses),
        plates_face_supports=_int_keys(model._platesFaceSupports),
    )


def _restore_state(model: "FEModel", state: FEModelStateV1) -> None:
    model._description = state.description
    model._logLevel = state.log_level  # type: ignore[assignment]
    model._models = list(state.models)
    model._loadCase = {
        k: cast(Tuple[str, str], tuple(v)) for k, v in state.load_case.items()
    }
    model._loads = _deserialise_loads(state.loads)
    model._loadCombinations = dict(state.load_combinations)
    model._sectionShapes = dict(state.section_shapes)
    model._materialLibrary = dict(state.material_library)
    model._initialTemperatures = dict(state.initial_temperatures)
    model._inertialAcceleration = {
        k: cast(Tuple[float, float, float], tuple(v))
        for k, v in state.inertial_acceleration.items()
    }
    model._groupTree = dict(state.group_tree)
    model._nodeSupports = {
        k: cast(Tuple[bool, bool, bool, bool, bool, bool], tuple(v))
        for k, v in state.node_supports.items()
    }
    model._nodeSprings = dict(state.node_springs)  # type: ignore[arg-type]
    model._nodeTemperatures = dict(state.node_temperatures)
    model._macro_element_node = {
        k: v.to_obj() for k, v in state.macro_element_node.items()
    }
    model._frameTemperatures = dict(state.frame_temperatures)
    model._framesSprings = {
        k: cast(Tuple[float, float, bool], tuple(v))
        for k, v in state.frames_springs.items()
    }
    model._macro_element_frame = {
        k: cast(Tuple[int, int], tuple(v))
        for k, v in state.macro_element_frame.items()
    }
    model._framesLocal2 = {k: v.to_obj() for k, v in state.frames_local_2.items()}
    model._framesShapes = dict(state.frames_shapes)  # type: ignore[arg-type]
    model._framesMaterial = dict(state.frames_material)  # type: ignore[arg-type]
    model._framesPhysicalNames = dict(state.frames_physical_names)  # type: ignore[arg-type]
    model._platesLocal1 = {k: v.to_obj() for k, v in state.plates_local_1.items()}
    model._macro_element_plate = {
        k: cast(
            "Tuple[int, int, int, int] | Tuple[int, int, int]", tuple(v)
        )
        for k, v in state.macro_element_plate.items()
    }
    rename: Dict[Elem, Dict[int, int]] = {
        Elem.ELEM_POINT: {},
        Elem.ELEM_LINE: {},
        Elem.ELEM_TRIA: {},
        Elem.ELEM_QUAD: {},
    }
    for name, d in state.tag_to_group_for_rename.items():
        rename[Elem[name]] = dict(d)
    model._tagToGroupForRename = rename
    model._platesPhysicalNames = dict(state.plates_physical_names)  # type: ignore[arg-type]
    model._platesMaterial = dict(state.plates_material)  # type: ignore[arg-type]
    model._platesThicknesses = {
        k: cast(Tuple[float, float], tuple(v))
        for k, v in state.plates_thicknesses.items()
    }
    model._platesFaceSupports = dict(state.plates_face_supports)  # type: ignore[arg-type]


def _ensure_bundle_path(path: str | Path) -> Path:
    p = Path(path)
    if str(p).endswith(BUNDLE_SUFFIX):
        return p
    if p.suffix == ".zip":
        p = p.with_suffix("")
    return p.parent / (p.name + BUNDLE_SUFFIX)


def _has_occ_entities() -> bool:
    try:
        return len(gmsh_model.occ.getEntities()) > 0
    except Exception:
        return False


def _has_mesh() -> bool:
    try:
        node_tags, _, _ = gmsh_model.mesh.getNodes()
        return len(node_tags) > 0
    except Exception:
        return False


def save_bundle(model: "FEModel", path: str | Path) -> Path:
    """Save FEModel to a single-file zip bundle.

    Args:
        model: FEModel with an active gmsh session.
        path: Output path. ``_v1.zip`` is appended if not already present.

    Returns:
        Path of the written zip.
    """
    out_path = _ensure_bundle_path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    has_geom = _has_occ_entities()
    has_mesh = _has_mesh()

    state = _build_state(model)
    state_json = state.model_dump_json()

    manifest = _Manifest(
        schema_version=SCHEMA_VERSION,
        gmsh_version=getattr(gmsh, "__version__", "unknown"),
        created_at=datetime.now(timezone.utc).isoformat(),
        model_name=model._models[0] if model._models else "default",
        has_geometry=has_geom,
        has_mesh=has_mesh,
    )

    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        if has_geom:
            gmsh_model.occ.synchronize()
            gmsh.write(str(td_path / _GEOMETRY))
        if has_mesh:
            previous = gmsh.option.getNumber("Mesh.MshFileVersion")
            gmsh.option.setNumber("Mesh.MshFileVersion", 4.1)
            try:
                gmsh.write(str(td_path / _MESH))
            finally:
                gmsh.option.setNumber("Mesh.MshFileVersion", previous)

        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(_MANIFEST, manifest.model_dump_json(indent=2))
            zf.writestr(_STATE, state_json)
            if has_geom:
                zf.write(td_path / _GEOMETRY, _GEOMETRY)
            if has_mesh:
                zf.write(td_path / _MESH, _MESH)

    return out_path


def load_bundle(path: str | Path) -> "FEModel":
    """Load an FEModel from a v1 bundle.

    Args:
        path: Path to the bundle zip.

    Returns:
        Reconstructed FEModel with gmsh model loaded and state restored.

    Raises:
        ValueError: If the bundle's schema version is not supported.
    """
    from .fe import FEModel

    p = Path(path)
    with zipfile.ZipFile(p, "r") as zf:
        manifest = _Manifest.model_validate_json(
            zf.read(_MANIFEST).decode("utf-8")
        )
        if manifest.schema_version != SCHEMA_VERSION:
            raise ValueError(
                f"Unsupported schema version {manifest.schema_version}, "
                f"expected {SCHEMA_VERSION}"
            )

        state = FEModelStateV1.model_validate_json(
            zf.read(_STATE).decode("utf-8")
        )

        model = FEModel(descr=state.description, modelName=manifest.model_name)

        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            if manifest.has_geometry:
                geom_path = td_path / _GEOMETRY
                geom_path.write_bytes(zf.read(_GEOMETRY))
                gmsh.merge(str(geom_path))
                gmsh_model.occ.synchronize()
            if manifest.has_mesh:
                mesh_path = td_path / _MESH
                mesh_path.write_bytes(zf.read(_MESH))
                gmsh.merge(str(mesh_path))

    _restore_state(model, state)
    return model