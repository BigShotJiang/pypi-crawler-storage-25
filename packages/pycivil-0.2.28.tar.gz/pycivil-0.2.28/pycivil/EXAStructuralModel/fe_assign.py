# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

import numpy as np

from pycivil.EXAGeometry.geometry import Point3d, Vector3d
from pycivil.EXAUtils import EXAExceptions as Ex

from .fe_types import (
    Dim,
    FEMaterial,
    PlateFaceSupport,
    SectionShape,
    ShapeRect,
)
from pycivil.EXAGeometry.shapes import ShapesEnum

if TYPE_CHECKING:
    from .fe import FEModel

myInt64 = Union[int, np.uint64, np.int32]


def addMaterialToLibrary(
    model: "FEModel",
    idMaterial: int,
    modulus: float,  # Mpa
    poisson: float,  # ...
    name: str,
    density: float = 0.0,  # kg/mc
    thermal_expansion: float = 0.0,  # 1/C
    conductivity: float = 0.0,  # KJ/s/m/C
    specific_heat: float = 0.0,  # KJ/kg/C
) -> None:
    """Register a material in the model material library.

    Args:
        idMaterial: Unique integer identifier for the material.
        modulus: Young's modulus [MPa].
        poisson: Poisson's ratio [-].
        name: Human-readable material name.
        density: Mass density [kg/m³]. Default is 0.0.
        thermal_expansion: Coefficient of thermal expansion [1/°C]. Default is 0.0.
        conductivity: Thermal conductivity [kJ/s/m/°C]. Default is 0.0.
        specific_heat: Specific heat capacity [kJ/kg/°C]. Default is 0.0.
    """
    model._materialLibrary[idMaterial] = FEMaterial(
        name=name,
        modulus=modulus,
        poisson=poisson,
        density=density,
        thermal_expansion=thermal_expansion,
        conductivity=conductivity,
        specific_heat=specific_heat,
    )


def addSectionShape(
    model: "FEModel",
    idShape: int,
    name: str,
    tp: ShapesEnum,
    dim: Optional[List[float]] = None,
) -> None:
    """Register a cross-section shape in the model section library.

    Args:
        idShape: Unique integer identifier for the section shape.
            Must not already exist in the library.
        name: Human-readable name for the section.
        tp: Cross-section type from :class:`ShapesEnum`.
            Currently only ``ShapesEnum.SHAPE_RECT`` is supported.
        dim: Dimensions of the cross-section as a list of floats.
            For ``SHAPE_RECT`` exactly 2 values are required:
            ``[width, height]``.

    Raises:
        EXAExceptions: If ``idShape`` is already in use, if ``idShape`` is
            not an ``int``, if ``tp`` is not a ``ShapesEnum``, if ``dim``
            contains non-float values, or if the dimension list length does
            not match the shape type requirements.
    """
    _dim: List[float] = dim if dim is not None else []

    if idShape in model._sectionShapes.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0007", "idShape for shape must be unique", idShape
        )

    if not isinstance(idShape, int):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004", "idShape must be a int", type(idShape)
        )

    if not isinstance(tp, ShapesEnum):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004", "tp must be a ShapesEnum", type(tp)
        )

    if not all(isinstance(n, float) for n in _dim):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0009", "dim must be float list", type(_dim)
        )

    if tp == ShapesEnum.SHAPE_RECT:
        if len(_dim) != 2:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "For *RECTANGULAR* dim must have a two dim array",
                len(_dim),
            )

        model._sectionShapes[idShape] = ShapeRect(name=name, param=_dim)


def sectionShapes(model: "FEModel") -> Dict[int, SectionShape]:
    """Return the section-shape library."""
    return model._sectionShapes


def sectionMaterials(model: "FEModel") -> Dict[int, FEMaterial]:
    """Return the material library."""
    return model._materialLibrary


def getFrameLocal3(model: "FEModel", tagFrame: myInt64) -> Vector3d:
    """Return the local axis-3 (longitudinal) unit vector of a frame element."""
    nodes = model.framesConnectivity().get(tagFrame, None)
    if nodes is None:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004", "tagFrame is not present", type(tagFrame)
        )
    n1 = model.nodeCoords(nodes[0])
    n2 = model.nodeCoords(nodes[1])

    return Vector3d(Point3d(*n1), Point3d(*n2)).normalize()


def getPlateLocal3(model: "FEModel", tagPlate: myInt64) -> Vector3d:
    """Return the local axis-3 (normal) unit vector of a plate element."""
    nodes = model.platesConnectivity().get(tagPlate, None)
    if nodes is None:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004", "tagPlate is not present", type(tagPlate)
        )
    n1 = model.nodeCoords(nodes[0])
    n2 = model.nodeCoords(nodes[1])
    n3 = model.nodeCoords(nodes[2])
    v1 = Vector3d(Point3d(*n1), Point3d(*n2))
    v2 = Vector3d(Point3d(*n2), Point3d(*n3))
    return v1.cross(v2).normalize()


def getPlateLocal1(model: "FEModel", tagPlate: myInt64) -> Vector3d:
    """Return the local axis-1 unit vector of a plate element."""
    if model._platesLocal1.get(tagPlate) is None:
        return _getPlateLocal1Default(model, tagPlate)
    ax = model._platesLocal1.get(tagPlate)
    assert ax is not None
    return ax


def getPlateLocal2(model: "FEModel", tagPlate: myInt64) -> Vector3d:
    """Return the local axis-2 unit vector of a plate element."""
    return getPlateLocal3(model, tagPlate).cross(getPlateLocal1(model, tagPlate))


def _getPlateLocal1Default(model: "FEModel", tagPlate: myInt64) -> Vector3d:
    """Compute the default local axis-1 direction for a plate element."""
    nodes = model.platesConnectivity().get(tagPlate, None)
    if nodes is None:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004", "tagPlate is not present", type(tagPlate)
        )
    assert isinstance(nodes, tuple) and nodes is not None
    p1 = Point3d(*model.nodeCoords(nodes[0]))
    p2 = Point3d(*model.nodeCoords(nodes[1]))
    p3 = Point3d(*model.nodeCoords(nodes[2]))
    m2 = p2.midpoint(p3)
    if len(nodes) == 3:
        return Vector3d(p1, m2).normalize()
    elif len(nodes) == 4:
        p4 = Point3d(*model.nodeCoords(nodes[3]))
        m1 = p1.midpoint(p4)
        return Vector3d(m1, m2).normalize()
    else:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004", "len(nodes) must be 3 or 4", len(nodes)
        )


def _getFrameLocal2Default(model: "FEModel", tagFrame: myInt64) -> Vector3d:
    """Compute the default local axis-2 direction for a frame element."""
    local_3 = getFrameLocal3(model, tagFrame)
    if local_3.cross(Vector3d(0.0, 0.0, 1.0)).norm() < 1e-16:
        return Vector3d(0.0, 1.0, 0.0)

    return Vector3d(0.0, 0.0, 1.0).cross(local_3)


def getFrameLocal2(model: "FEModel", tagFrame: myInt64) -> Vector3d:
    """Return the local axis-2 unit vector of a frame element."""
    if model._framesLocal2.get(tagFrame) is None:
        return _getFrameLocal2Default(model, tagFrame)
    ax = model._framesLocal2.get(tagFrame)
    assert ax is not None
    return ax


def getFrameLocal1(model: "FEModel", tagFrame: myInt64) -> Vector3d:
    """Return the local axis-1 unit vector of a frame element."""
    return getFrameLocal2(model, tagFrame).cross(getFrameLocal3(model, tagFrame))


def assignPlateLocal1(model: "FEModel", tagPlate: myInt64, axis: Vector3d) -> None:
    """Assign a custom local axis-1 direction to a single plate element."""
    if not isinstance(tagPlate, (int, np.uint64, np.int32)):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "tagPlate must be a int, np.uint64 or np.int32",
            type(tagPlate),
        )
    if not isinstance(axis, Vector3d):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "axis must be a Vector3d instance !!!",
            type(axis),
        )
    if getPlateLocal3(model, tagPlate).cross(axis).norm() == 0.0:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "axis must not null and not parallel to local axis 3 !!!",
        )
    axis_3 = getPlateLocal3(model, tagPlate)
    tmp_axis = axis_3.cross(axis).normalize()

    model._platesLocal1[tagPlate] = tmp_axis.cross(axis_3).normalize()


def assignMultiPlateLocal1(
    model: "FEModel",
    axis: Vector3d,
    tagsMacro: Optional[List[myInt64]] = None,
    tagsPlate: Optional[List[myInt64]] = None,
) -> None:
    """Assign a custom local axis-1 direction to multiple plate elements."""
    _assignMultiElement(
        model, Dim.DIM_2D, lambda t, a: assignPlateLocal1(model, t, a), axis, tagsMacro, tagsPlate
    )


def assignMultiPlateMaterial(
    model: "FEModel",
    idMaterial: int,
    tagsMacro: Optional[List[myInt64]] = None,
    tagsPlate: Optional[List[myInt64]] = None,
) -> None:
    """Assign a material to multiple plate elements."""
    _assignMultiElement(
        model, Dim.DIM_2D, lambda t, m: assignPlateMaterial(model, t, m), idMaterial, tagsMacro, tagsPlate
    )


def assignMultiPlateThicknesses(
    model: "FEModel",
    thicknesses: tuple[float, float],
    tagsMacro: Optional[List[myInt64]] = None,
    tagsPlate: Optional[List[myInt64]] = None,
) -> None:
    """Assign bending and membrane thicknesses to multiple plate elements."""
    _assignMultiElement(
        model, Dim.DIM_2D, lambda t, th: assignPlateThicknesses(model, t, th), thicknesses, tagsMacro, tagsPlate
    )


def assignFrameLocal2(model: "FEModel", tagFrame: myInt64, axis: Vector3d) -> None:
    """Assign a custom local axis-2 direction to a single frame element."""
    if not isinstance(tagFrame, (int, np.uint64, np.int32)):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "tagFrame must be a int, np.uint64 or np.int32",
            type(tagFrame),
        )
    if not isinstance(axis, Vector3d):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "axis must be a Vector3d instance !!!",
            type(tagFrame),
        )
    if getFrameLocal3(model, tagFrame).cross(axis).norm() == 0.0:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "axis must not null and not parallel to local axis 3 !!!",
            type(tagFrame),
        )
    axis_3 = getFrameLocal3(model, tagFrame)
    tmp_axis = axis.cross(axis_3).normalize()

    model._framesLocal2[tagFrame] = axis_3.cross(tmp_axis).normalize()


def assignMultiFrameLocal2(
    model: "FEModel",
    axis: Vector3d,
    tagsMacro: Optional[List[myInt64]] = None,
    tagsFrames: Optional[List[myInt64]] = None,
) -> None:
    """Assign a custom local axis-2 direction to multiple frame elements."""
    _assignMultiElement(
        model, Dim.DIM_1D, lambda t, a: assignFrameLocal2(model, t, a), axis, tagsMacro, tagsFrames
    )


def _check_material_assign(model: "FEModel", tagElement: myInt64, idMaterial: int) -> None:
    """Validate arguments before assigning a material to an element."""
    if not isinstance(tagElement, np.uint64):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "tagElement must be a int, nsignedinteger[_64Bit] or nsignedinteger[_32Bit]",
            type(tagElement),
        )

    if not isinstance(idMaterial, int):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "idMaterial must be a int",
            type(idMaterial),
        )

    if idMaterial not in model._materialLibrary.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "idMaterial unknown in materialLibrary table",
            idMaterial,
        )


def assignFrameSectionShape(model: "FEModel", tagFrame: myInt64, idShape: int) -> None:
    """Assign a cross-section shape to a single frame element."""
    if not isinstance(tagFrame, (int, np.uint64, np.int32)):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "tagFrame must be a int, np.uint64 or np.int32",
            type(tagFrame),
        )

    if not isinstance(idShape, int):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004", "idShape must be a int", type(idShape)
        )

    if idShape not in model._sectionShapes.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "idShape unknown in sectionShapes table",
            idShape,
        )

    model._framesShapes[tagFrame] = idShape


def assignFrameMaterial(model: "FEModel", tagFrame: myInt64, idMaterial: int) -> None:
    """Assign a material to a single frame element."""
    _check_material_assign(model, tagFrame, idMaterial)
    model._framesMaterial[tagFrame] = idMaterial


def assignPlateMaterial(model: "FEModel", tagPlate: myInt64, idMaterial: int) -> None:
    """Assign a material to a single plate element."""
    _check_material_assign(model, tagPlate, idMaterial)
    model._platesMaterial[tagPlate] = idMaterial


def assignPlateThicknesses(
    model: "FEModel", tagPlate: myInt64, thicknesses: tuple[float, float]
) -> None:
    """Assign bending and membrane thicknesses to a single plate element."""
    if not isinstance(tagPlate, (int, np.uint64, np.int32)):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "tagPlate must be a int, np.uint64 or np.int32",
            type(tagPlate),
        )

    if not isinstance(thicknesses, tuple):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "thicknesses must be tuple",
            type(thicknesses),
        )

    if not len(thicknesses) == 2:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "len(thicknesses) must be tuple with len = 2",
            len(thicknesses),
        )

    if not isinstance(thicknesses[0], float) or not isinstance(
        thicknesses[0], float
    ):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "thicknesses must be tuple only of floats",
            len(thicknesses),
        )

    model._platesThicknesses[tagPlate] = thicknesses


def assignPlateFaceSupport(
    model: "FEModel", tagPlate: myInt64, support: PlateFaceSupport
) -> None:
    """Assign a face (Winkler-type) support to a single plate element."""
    if not isinstance(tagPlate, (int, np.uint64, np.int32)):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "tagPlate must be a int, np.uint64 or np.int32",
            type(tagPlate),
        )

    if not isinstance(support, PlateFaceSupport):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "support must a PlateFaceSupport instance",
            type(PlateFaceSupport),
        )

    model._platesFaceSupports[tagPlate] = support


def assignMultiPlateFaceSupport(
    model: "FEModel",
    support: PlateFaceSupport,
    tagsMacro: Optional[List[myInt64]] = None,
    tagsPlate: Optional[List[myInt64]] = None,
) -> None:
    """Assign a face support to multiple plate elements."""
    _assignMultiElement(
        model, Dim.DIM_2D, lambda t, s: assignPlateFaceSupport(model, t, s), support, tagsMacro, tagsPlate
    )


def assignFrameWinklerSupport(
    model: "FEModel",
    tagFrame: myInt64,
    winkler_supports: Tuple[float, float, bool],
) -> None:
    """Assign a Winkler-type distributed support to a single frame element."""
    model._framesSprings[tagFrame] = winkler_supports


def assignMultiFrameWinklerSupport(
    model: "FEModel",
    winkler_supports: Tuple[float, float, bool],
    tagsMacro: Optional[List[myInt64]] = None,
    tagsFrames: Optional[List[myInt64]] = None,
) -> None:
    """Assign a Winkler-type distributed support to multiple frame elements."""
    _assignMultiElement(
        model,
        Dim.DIM_1D,
        lambda t, w: assignFrameWinklerSupport(model, t, w),
        winkler_supports,
        tagsMacro,
        tagsFrames,
    )


def frameSectionShape(model: "FEModel") -> Dict[myInt64, int]:
    """Return the section-shape assignment for frame elements."""
    return model._framesShapes


def frameMaterial(model: "FEModel") -> Dict[myInt64, int]:
    """Return the material assignment for frame elements."""
    return model._framesMaterial


def plateMaterial(model: "FEModel") -> Dict[myInt64, int]:
    """Return the material assignment for plate elements."""
    return model._platesMaterial


def plateThicknesses(model: "FEModel") -> Dict[myInt64, Tuple[float, float]]:
    """Return the thickness assignment for plate elements."""
    return model._platesThicknesses


def _checkTagMacroAndElements(
    tagsMacro: Optional[List[myInt64]] = None,
    tagsElement: Optional[List[myInt64]] = None,
) -> None:
    assert tagsMacro is not None
    assert isinstance(tagsMacro, list)

    assert tagsElement is not None
    assert isinstance(tagsElement, list)

    if len(tagsMacro) == 0 and len(tagsElement) == 0:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "tagsMacro or tagsElements must be null",
            len(tagsMacro),
        )

    if len(tagsMacro) != 0 and len(tagsElement) != 0:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004",
            "tagsMacro or tagsElements must be not null",
            len(tagsMacro),
        )


def assignMultiElement(*args, **kwargs):
    """Public alias for ``_assignMultiElement``."""
    _assignMultiElement(*args, **kwargs)


def _assignMultiElement(
    model: "FEModel",
    dimension: Dim,
    assign_fn: Callable[..., None],
    assign_value: Any,
    tagsMacro: Optional[List[myInt64]] = None,
    tagsElement: Optional[List[myInt64]] = None,
    assign_extra_args: tuple[Any, ...] = (),
) -> None:
    """Apply a single-element assignment function to a collection of elements.

    This is the shared implementation used by all ``assignMulti*`` functions.
    Exactly one of *tagsMacro* or *tagsElement* must be non-empty.

    When *tagsMacro* is provided, the helper resolves each macro-element
    (geometric object) to its set of mesh elements for the given
    *dimension* and calls *assign_fn* for each one.

    Args:
        model: The :class:`FEModel` whose mesh resolves macro tags.
        dimension: Spatial dimension of the elements
            (``Dim.DIM_1D`` for frames, ``Dim.DIM_2D`` for plates).
        assign_fn: Callable with signature
            ``assign_fn(element_tag, assign_value, *assign_extra_args) -> None``.
        assign_value: The value to pass as the second argument to
            *assign_fn* for every targeted element.
        tagsMacro: List of macro-element (geometric entity) tags.
            Mutually exclusive with *tagsElement*.
        tagsElement: List of individual mesh element tags.
            Mutually exclusive with *tagsMacro*.
        assign_extra_args: Additional positional arguments forwarded to
            *assign_fn* after *assign_value*. Defaults to an empty tuple.

    Raises:
        EXAExceptions: If both lists are non-empty or both are empty.
    """
    _tagsMacro: List[myInt64] = tagsMacro if tagsMacro is not None else []
    _tagsElement: List[myInt64] = tagsElement if tagsElement is not None else []

    _checkTagMacroAndElements(_tagsMacro, _tagsElement)

    if len(_tagsMacro) != 0:
        elementsTags = model.getElementsFromMacroTags(dimension)
        assert isinstance(elementsTags, dict)
        for tag in _tagsMacro:
            for t in elementsTags[tag]:
                assign_fn(t, assign_value, *assign_extra_args)
    else:
        for t in _tagsElement:
            assign_fn(t, assign_value, *assign_extra_args)


def assignMultiFrameSectionShape(
    model: "FEModel",
    idShape: int,
    tagsMacro: Optional[List[myInt64]] = None,
    tagsFrames: Optional[List[myInt64]] = None,
) -> None:
    """Assign a cross-section shape to multiple frame elements."""
    _assignMultiElement(
        model, Dim.DIM_1D, lambda t, i: assignFrameSectionShape(model, t, i), idShape, tagsMacro, tagsFrames
    )


def assignMultiFrameMaterial(
    model: "FEModel",
    idMaterial: int,
    tagsMacro: Optional[List[myInt64]] = None,
    tagsFrames: Optional[List[myInt64]] = None,
) -> None:
    """Assign a material to multiple frame elements."""
    _assignMultiElement(
        model, Dim.DIM_1D, lambda t, i: assignFrameMaterial(model, t, i), idMaterial, tagsMacro, tagsFrames
    )


def framesSupports(model: "FEModel") -> Dict[myInt64, Tuple[float, float, bool]]:
    """Return the Winkler support assignment for frame elements."""
    return model._framesSprings


def platesFaceSupports(model: "FEModel") -> Dict[myInt64, PlateFaceSupport]:
    """Return the face support assignment for plate elements."""
    return model._platesFaceSupports
