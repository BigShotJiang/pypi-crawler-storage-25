# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from typing import Any, Dict, List, Literal, Tuple, Union

import gmsh
import numpy as np
from gmsh import model as gmsh_model

from pycivil.EXAGeometry.geometry import Point3d, Vector3d
from pycivil.EXAUtils import logging as log

from .fe_types import (
    Dim,
    Elem,
    FEMaterial,
    LoadType,
    NodalSpringsDir,
    NodalSpringsTp,
    PlateFaceSupport,
    SectionShape,
    ShapeRect,
)
from .fe_mesh import _FEMeshMixin
from .fe_geometry import _FEGeometryMixin
from . import fe_assign, fe_loads

myInt64 = Union[int, np.uint64, np.int32]


class FEModel(_FEGeometryMixin, _FEMeshMixin):
    """Finite-element model builder backed by GMSH and exported to Midas MGT.

    ``FEModel`` wraps a GMSH session and adds a structural-analysis layer on
    top: materials, cross-section shapes, load cases, distributed and
    concentrated loads, nodal springs, Winkler supports, temperature loads,
    and physical-group management.  After the model is assembled it can be
    exported to the Midas GEN ``.mgt`` text format via :meth:`save`.

    Typical workflow::

        model = FEModel(descr="My bridge", modelName="bridge")
        model.addMaterialToLibrary(1, modulus=210000.0, poisson=0.3, name="Steel")
        model.addSectionShape(1, name="HEB300", tp=ShapesEnum.SHAPE_RECT, dim=[0.3, 0.3])
        n1 = model.addNode(...)
        f1 = model.addFrame(...)
        model.addLoadCase("LC1", tp="D", descr="Dead load")
        model.addFrameLoad("LC1", tagFrame=f1, tp="force", GCZ1=[0.0, -10.0])
        model.save("bridge.mgt")

    Note:
        Only one GMSH model can be active at a time within a process.
        Use :meth:`addModel` / :meth:`setCurrentModel` to switch contexts.
    """

    configData = {
        "LoadCaseType": [
            {"id": "U", "description": "User Defined Load"},
            {"id": "D", "description": "Dead Load"},
            {"id": "L", "description": "Live Load"},
            {"id": "R", "description": "Roof Live Load"},
            {"id": "W", "description": "Wind Load on Structure"},
            {"id": "E", "description": "Earthquake"},
            {"id": "T", "description": "Temperature"},
            {"id": "S", "description": "Snow Load"},
            {"id": "R", "description": "Rain Load"},
            {"id": "IL", "description": "Live Load Impact"},
            {"id": "EP", "description": "Earth Pressure"},
            {"id": "B", "description": "Buoyancy"},
            {"id": "WP", "description": "Ground Water Pressure"},
            {"id": "FP", "description": "Fluid Pressure"},
            {"id": "IP", "description": "Ice Pressure"},
            {"id": "WL", "description": "Wind Load on Live Load"},
            {"id": "BK", "description": "Longitudinal Force from Live Load"},
            {"id": "CF", "description": "Centrifugal Force"},
            {"id": "RS", "description": "Rib Shortening"},
            {"id": "SH", "description": "Shrinkage"},
            {"id": "CR", "description": "Creep"},
            {"id": "PS", "description": "Pre-stressing force"},
            {"id": "ER", "description": "Erection Load"},
            {"id": "CO", "description": "Collision Load"},
            {"id": "CS", "description": "Construction Stage Load"},
            {"id": "BL", "description": "Braking Load"},
            {"id": "STL", "description": "Settlement"},
            {"id": "WPL", "description": "Wave Pressure"},
            {"id": "CL", "description": "Crowd Load"},
            {"id": "TG", "description": "Temperature Gradient"},
            {"id": "SW", "description": "Self Weight"},
        ]
    }

    def __init__(self, descr: str = "", modelName: str = "default"):
        """Initialize the FEM model and the underlying GMSH session.

        Starts the GMSH library, creates an OCC (OpenCASCADE) geometry kernel,
        and registers the first model. Internal dictionaries for load cases,
        loads, combinations, supports, springs, materials, and section shapes
        are all created empty (or with a default rect section assigned as id=1).

        Note:
            **Default local axes for beam elements (Strand7 convention):**
            If the beam is parallel to the global Z axis the 2-direction is
            always in the positive global Y direction.  Otherwise the
            2-direction is given by the cross product of the global Z axis
            and the N1→N2 vector; the 3-direction runs from N1 to N2, and
            the 1-direction completes the right-hand system.

            **Default local axes for plate elements (Strand7 convention):**
            For a quadrilateral the positive local x joins the mid-sides of
            (N1,N4) and (N2,N3); for a triangle it goes from N1 to the
            midpoint of (N2,N3).  Positive local y is perpendicular to local
            x, directed away from side (N1,N2), lying in the plate plane.
            Positive local z is normal to the plate surface completing the
            right-hand system.

        Args:
            descr: Human-readable description of the model.
            modelName: Name used to identify the GMSH model; also stored as
                the first entry in the internal models list.
        """
        self._logLevel: Literal[0, 1, 2, 3] = 3

        # GMSH init
        gmsh.initialize()

        # Using OCC as BREP for geometry
        self._cad = gmsh_model.occ

        # Adding model and make current
        gmsh_model.add(modelName)
        gmsh_model.setCurrent(modelName)

        self._models = [modelName]
        self._description: str = descr

        # Load cases and combinations
        # Dict[load_case_key, (type_str, description)]
        #
        self._loadCase: Dict[str, Tuple[str, str]] = {}

        # Loads
        # Dict[load_case_key, (type_str, description)]
        #
        # load case | LoadType | tagFrame | tp force | direction | value
        self._loads: Dict[str, Dict[LoadType, Any]] = {}

        self._loadCombinations: Dict[str, List[float]] = {}

        # Body constraints
        self._bodyConstraints: tuple[bool, bool, bool, bool, bool, bool] = \
            (False, False,False,False,False,False)

        # Libraries for shapes and materials
        #
        self._sectionShapes: Dict[int, SectionShape] = {
            1: ShapeRect(param=[1.0, 0.3], name="default")
        }
        self._materialLibrary: Dict[int, FEMaterial] = {}

        # Values that don't depend on geometry or mesh
        #
        # [Load Case] = value
        self._initialTemperatures: Dict[str, float] = {}
        self._inertialAcceleration: Dict[str, Tuple[float, float, float]] = {}

        # [group tree name, physical]
        #
        self._groupTree: Dict[str, str] = {}

        # ---------------------------------------------------------------------
        #                                 NODES
        # ---------------------------------------------------------------------
        #
        # Supports
        #
        self._nodeSupports: Dict[
            myInt64, Tuple[bool, bool, bool, bool, bool, bool]
        ] = {}
        #
        # Springs
        #
        self._nodeSprings: Dict[
            myInt64, Dict[NodalSpringsTp, Dict[NodalSpringsDir, float]]
        ] = {}
        #
        # Temperature
        #
        # [Load Case][Node Tag][Tp]
        self._nodeTemperatures: Dict[str, Dict[int, Dict[str, float]]] = {}
        #
        # Macro elements
        #
        self._macro_element_node: dict[int, Point3d] = {}

        # ---------------------------------------------------------------------
        #                                FRAMES
        # ---------------------------------------------------------------------
        #
        # Temperature
        #
        # [Load Case][Frame Tag][Tp]
        self._frameTemperatures: Dict[
            str, Dict[int, Dict[str, Tuple[float, float]]]
        ] = {}
        #
        # Springs evenly distribuited in local direction
        #
        # Dict[id_frame, Tuple[LCDIR1, LCDIR2, ONLYCOMPRESSION]]
        self._framesSprings: Dict[myInt64, Tuple[float, float, bool]] = {}
        #
        # Macro elements
        #
        # Dict[id_frame, Tuple[id_node_i, id_node_i]]
        self._macro_element_frame: dict[int, tuple[int, int]] = {}
        #
        # Local axes supports
        #
        # Dict[id_frame, axis]
        self._framesLocal2: Dict[myInt64, Vector3d] = {}
        #
        # Shape
        #
        self._framesShapes: Dict[myInt64, int] = {}
        #
        # Material
        #
        self._framesMaterial: Dict[myInt64, int] = {}
        #
        # Link between Frames and phisical Names
        #
        self._framesPhysicalNames: Dict[myInt64, List[str]] = {}

        # ---------------------------------------------------------------------
        #                                PLATES
        # ---------------------------------------------------------------------
        #
        # Local axes supports
        #
        self._platesLocal1: Dict[myInt64, Vector3d] = {}
        #
        # Macro elements
        #
        self._macro_element_plate: dict[
            int, tuple[int, int, int, int] | tuple[int, int, int]
        ] = {}
        #
        # Mapping custom ID with macro elements composed of one element in
        # mesh space
        self._tagToGroupForRename: Dict[Elem, Dict[int, int]] = {
            Elem.ELEM_POINT: {},
            Elem.ELEM_LINE: {},
            Elem.ELEM_TRIA: {},
            Elem.ELEM_QUAD: {},
        }
        #
        # Link between Plates and phisical Names
        #
        self._platesPhysicalNames: Dict[myInt64, List[str]] = {}
        #
        # Material
        #
        self._platesMaterial: Dict[myInt64, int] = {}
        #
        # Plate thicknesses
        #
        # Dict[id_plate, Tuple[bending_thick, membrane_thick]]
        self._platesThicknesses: Dict[myInt64, Tuple[float, float]] = {}
        #
        # Plate Face supports
        #
        self._platesFaceSupports: Dict[myInt64, PlateFaceSupport] = {}

    def _log(self, tp: Literal["INF", "WRN", "ERR"], msg: str) -> None:
        """Emit a log message at the configured log level.

        Args:
            tp: Message type tag — one of ``"INF"``, ``"WRN"``, or ``"ERR"``.
            msg: Message text.
        """
        log.log(tp, msg, self._logLevel)

    def save(self, fileName: str, fileType: str = ".msh") -> None:
        """Save the model mesh to file.

        Args:
            fileName: Output file path without extension.
            fileType: File format extension. Supported values:

                * ``".msh"`` — GMSH native mesh format (default).
                * ``".med"`` — MED/Salome format.

        Note:
            All mesh elements are saved regardless of physical group membership
            (``Mesh.SaveAll`` is set to 1 before writing).

            To export a MIDAS Gen ``.mgt`` file use
            :func:`pycivil.EXAStructuralModel.fe_connector_to_midas.save_mgt`.
        """
        print("Write ", fileName + fileType)
        gmsh.option.setNumber("Mesh.SaveAll", 1)
        if fileType == ".msh":
            gmsh.write(fileName + fileType)
        elif fileType == ".med":
            gmsh.write(fileName + fileType)
        else:
            self._log("ERR", f"File type unknoun *{fileType}*. None file saved !!!")

    def getCad(self):
        """Return the underlying OpenCASCADE (OCC) geometry kernel instance.

        Returns:
            The ``gmsh.model.occ`` object used to build and modify geometry.
        """
        return self._cad

    @staticmethod
    def getModeler():
        """Main object that shapes geometry and mesh

        Returns:
            A gmsh modeler
        """
        return gmsh_model

    def addModel(self, name: str) -> bool:
        """Add a new GMSH model and register it in the session.

        Args:
            name: Non-empty unique name for the new model.

        Returns:
            ``True`` if the model was created successfully, ``False`` if *name*
            is empty or already registered.
        """
        if len(name) == 0:
            self._log("ERR", "Arg must be a str not null !!!")
            return False
        else:
            if name in self._models:
                self._log("ERR", f"Model *{name}* is present !!!")
                return False
            else:
                gmsh_model.add(name)
                self._models.append(name)
                self._log("INF", f"Model *{name}* added !!!")
                return True

    def getModels(self) -> List[str]:
        """Return the list of GMSH model names registered in this session.

        Returns:
            A list of model name strings in the order they were added,
            starting with the name passed to ``__init__``.
        """
        return self._models

    def setCurrentModel(self, name: str) -> bool:
        """Switch the active GMSH model.

        Args:
            name: Name of a previously registered model.

        Returns:
            ``True`` if the model was found and set as current, ``False``
            if *name* is not registered.
        """
        if name not in self._models:
            self._log("ERR", f"Model *{name}* not present !!!")
            return False
        else:
            gmsh_model.setCurrent(name)
            return True

    # ------------------------------------------------------------------
    # Cross-cutting methods (geometry + mesh / state).  These were
    # previously in _FEGeometryMixin but reach into mesh queries; they
    # live on the model so the geometry mixin stays mesh-free.
    # ------------------------------------------------------------------

    def addFramesToGroup(
        self,
        tags: List[Union[int, np.uint64, np.int32]] | int,
        tagGroup: Union[int, np.uint64, np.int32],
        physicalName: str = "",
    ) -> None:
        """Add one or more 1D macro-elements (curves) to a physical group.

        Records *physicalName* per mesh frame element so it can be retrieved
        later via :meth:`getPhysicalNamesForFrame`.
        """
        _tags: List[myInt64] = [tags] if isinstance(tags, int) else tags

        self._addElementToGroup(_tags, tagGroup, Dim.DIM_1D, physicalName)
        for t in self.getFramesFromMacroTags(_tags):
            if self._framesPhysicalNames.get(t) is None:
                self._framesPhysicalNames[t] = [physicalName]
            else:
                self._framesPhysicalNames[t].append(physicalName)

    def addPlatesToGroup(
        self,
        tags: List[Union[int, np.uint64, np.int32]] | int,
        tagGroup: Union[int, np.uint64, np.int32],
        physicalName: str = "",
    ) -> None:
        """Add one or more 2D macro-elements (surfaces) to a physical group."""
        _tags: List[myInt64] = [tags] if isinstance(tags, int) else tags

        self._addElementToGroup(_tags, tagGroup, Dim.DIM_2D, physicalName)
        for t in self.getPlatesFromMacroTags(_tags):
            if self._platesPhysicalNames.get(t) is None:
                self._platesPhysicalNames[t] = [physicalName]
            else:
                self._platesPhysicalNames[t].append(physicalName)

    def assignGroupTreeToPhysical(
        self, treePath: List[str | None], physicalName: str
    ) -> None:
        """Map a hierarchical group-tree path to an existing physical group name."""
        if len(treePath) == 0:
            raise ValueError("treePath has len 0 !!!")

        if treePath[0] is None:
            raise ValueError("treePath starts with None type !!!")

        if physicalName == "":
            raise ValueError("physicalName has len 0 !!!")

        pn = self.getPhisicalNames()
        if physicalName not in pn:
            raise ValueError(f'physicalName given "{physicalName}" not in {pn} !!!')

        hashStr = ""
        isNone = False
        for cols in treePath:
            if isNone:
                if cols is not None:
                    raise ValueError("None type within not none type !!!")
            if cols is None:
                isNone = True
            else:
                hashStr += cols + "/"

        self._groupTree[hashStr] = physicalName

    def getGroupTreeToPhysical(self) -> Dict[str, str]:
        """Return the group-tree to physical-name mapping."""
        return self._groupTree

    # ------------------------------------------------------------------
    # Section / material / local-axes assignment wrappers
    # (delegate to fe_assign module functions)
    # ------------------------------------------------------------------

    def addMaterialToLibrary(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.addMaterialToLibrary(self, *args, **kwargs)

    def addSectionShape(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.addSectionShape(self, *args, **kwargs)

    def sectionShapes(self) -> Dict[int, SectionShape]:
        return fe_assign.sectionShapes(self)

    def sectionMaterials(self) -> Dict[int, FEMaterial]:
        return fe_assign.sectionMaterials(self)

    def getFrameLocal3(self, tagFrame: Union[int, np.uint64, np.int32]) -> Vector3d:
        return fe_assign.getFrameLocal3(self, tagFrame)

    def getPlateLocal3(self, tagPlate: Union[int, np.uint64, np.int32]) -> Vector3d:
        return fe_assign.getPlateLocal3(self, tagPlate)

    def getPlateLocal1(self, tagPlate: Union[int, np.uint64, np.int32]) -> Vector3d:
        return fe_assign.getPlateLocal1(self, tagPlate)

    def getPlateLocal2(self, tagPlate: Union[int, np.uint64, np.int32]) -> Vector3d:
        return fe_assign.getPlateLocal2(self, tagPlate)

    def getFrameLocal2(self, tagFrame: Union[int, np.uint64, np.int32]) -> Vector3d:
        return fe_assign.getFrameLocal2(self, tagFrame)

    def getFrameLocal1(self, tagFrame: Union[int, np.uint64, np.int32]) -> Vector3d:
        return fe_assign.getFrameLocal1(self, tagFrame)

    def assignPlateLocal1(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignPlateLocal1(self, *args, **kwargs)

    def assignMultiPlateLocal1(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignMultiPlateLocal1(self, *args, **kwargs)

    def assignMultiPlateMaterial(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignMultiPlateMaterial(self, *args, **kwargs)

    def assignMultiPlateThicknesses(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignMultiPlateThicknesses(self, *args, **kwargs)

    def assignFrameLocal2(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignFrameLocal2(self, *args, **kwargs)

    def assignMultiFrameLocal2(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignMultiFrameLocal2(self, *args, **kwargs)

    def assignFrameSectionShape(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignFrameSectionShape(self, *args, **kwargs)

    def assignFrameMaterial(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignFrameMaterial(self, *args, **kwargs)

    def assignPlateMaterial(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignPlateMaterial(self, *args, **kwargs)

    def assignPlateThicknesses(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignPlateThicknesses(self, *args, **kwargs)

    def assignPlateFaceSupport(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignPlateFaceSupport(self, *args, **kwargs)

    def assignMultiPlateFaceSupport(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignMultiPlateFaceSupport(self, *args, **kwargs)

    def assignFrameWinklerSupport(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignFrameWinklerSupport(self, *args, **kwargs)

    def assignMultiFrameWinklerSupport(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignMultiFrameWinklerSupport(self, *args, **kwargs)

    def frameSectionShape(self) -> Dict[Union[int, np.uint64, np.int32], int]:
        return fe_assign.frameSectionShape(self)

    def frameMaterial(self) -> Dict[Union[int, np.uint64, np.int32], int]:
        return fe_assign.frameMaterial(self)

    def plateMaterial(self) -> Dict[Union[int, np.uint64, np.int32], int]:
        return fe_assign.plateMaterial(self)

    def plateThicknesses(self) -> Dict[Union[int, np.uint64, np.int32], Tuple[float, float]]:
        return fe_assign.plateThicknesses(self)

    def assignMultiElement(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign._assignMultiElement(self, *args, **kwargs)

    def assignMultiFrameSectionShape(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignMultiFrameSectionShape(self, *args, **kwargs)

    def assignMultiFrameMaterial(self, *args: Any, **kwargs: Any) -> None:
        return fe_assign.assignMultiFrameMaterial(self, *args, **kwargs)

    def framesSupports(self) -> Dict[Union[int, np.uint64, np.int32], Tuple[float, float, bool]]:
        return fe_assign.framesSupports(self)

    def platesFaceSupports(self) -> Dict[Union[int, np.uint64, np.int32], PlateFaceSupport]:
        return fe_assign.platesFaceSupports(self)

    # ------------------------------------------------------------------
    # Loads / supports / springs / temperatures wrappers
    # (delegate to fe_loads module functions)
    # ------------------------------------------------------------------

    def getNodeTemperatures(self) -> Dict[str, Dict[int, Dict[str, float]]]:
        return fe_loads.getNodeTemperatures(self)

    def getFrameTemperatures(self) -> Dict[str, Dict[int, Dict[str, Tuple[float, float]]]]:
        return fe_loads.getFrameTemperatures(self)

    def getInitialTemperatures(self) -> Dict[str, float]:
        return fe_loads.getInitialTemperatures(self)

    def getInertialAcceleration(self) -> Dict[str, Tuple[float, float, float]]:
        return fe_loads.getInertialAcceleration(self)

    def setInertialAcceleration(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.setInertialAcceleration(self, *args, **kwargs)

    def setInitialTemperature(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.setInitialTemperature(self, *args, **kwargs)

    def setBodyConstraints(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.setBodyConstraints(self, *args, **kwargs)

    def getBodyConstraints(self) -> tuple[bool, bool, bool, bool, bool, bool]:
        return fe_loads.getBodyConstraints(self)

    def assignNodeTemperature(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.assignNodeTemperature(self, *args, **kwargs)

    def assignFrameTemperature(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.assignFrameTemperature(self, *args, **kwargs)

    def addLoadCombination(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addLoadCombination(self, *args, **kwargs)

    def getLoadCombinations(self) -> Dict[str, List[float]]:
        return fe_loads.getLoadCombinations(self)

    def addLoadCase(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addLoadCase(self, *args, **kwargs)

    def getLoadCases(self) -> Dict[str, Tuple[str, str]]:
        return fe_loads.getLoadCases(self)

    def getLoads(self) -> Dict[str, Dict[LoadType, Any]]:
        return fe_loads.getLoads(self)

    def addSelfWeight(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addSelfWeight(self, *args, **kwargs)

    def addMultiFrameWinklerSpring(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addMultiFrameWinklerSpring(self, *args, **kwargs)

    def addMultiFrameLoadHydro(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addMultiFrameLoadHydro(self, *args, **kwargs)

    def addMacroFrameLoadLine(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addMacroFrameLoadLine(self, *args, **kwargs)

    def addMultiFrameLoad(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addMultiFrameLoad(self, *args, **kwargs)

    def addPlateFaceLoad(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addPlateFaceLoad(self, *args, **kwargs)

    def addMultiPlateFaceLoad(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addMultiPlateFaceLoad(self, *args, **kwargs)

    def addFrameLoad(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addFrameLoad(self, *args, **kwargs)

    def addMultiNodeLoad(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addMultiNodeLoad(self, *args, **kwargs)

    def assignNodeLoad(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.assignNodeLoad(self, *args, **kwargs)

    def addMultiNodeContraints(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addMultiNodeContraints(self, *args, **kwargs)

    def addNodeContraints(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addNodeContraints(self, *args, **kwargs)

    def getNodeContraints(self) -> Dict[Union[int, np.uint64, np.int32], Tuple[bool, bool, bool, bool, bool, bool]]:
        return fe_loads.getNodeContraints(self)

    def addMultiNodeSpring(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addMultiNodeSpring(self, *args, **kwargs)

    def addNodeSpring(self, *args: Any, **kwargs: Any) -> None:
        return fe_loads.addNodeSpring(self, *args, **kwargs)

    def getNodeSprings(self) -> Dict[Union[int, np.uint64, np.int32], Dict[NodalSpringsTp, Dict[NodalSpringsDir, float]]]:
        return fe_loads.getNodeSprings(self)

    def __str__(self):
        s = f"Model Description: {self._description:s}"
        return s
