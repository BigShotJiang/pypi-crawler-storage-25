# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

import math
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Tuple, Union, cast

import numpy as np

from pycivil.EXAUtils import EXAExceptions as Ex

from .fe_types import Dim, LoadType, NodalSpringsDir, NodalSpringsTp, PlateFaceLoad
from . import fe_assign

if TYPE_CHECKING:
    from .fe import FEModel

myInt64 = Union[int, np.uint64, np.int32]


def getNodeTemperatures(model: "FEModel") -> Dict[str, Dict[int, Dict[str, float]]]:
    """Return the node temperature assignments."""
    return model._nodeTemperatures


def getFrameTemperatures(model: "FEModel") -> Dict[str, Dict[int, Dict[str, Tuple[float, float]]]]:
    """Return the frame temperature (gradient) assignments."""
    return model._frameTemperatures


def getInitialTemperatures(model: "FEModel") -> Dict[str, float]:
    """Return the uniform initial temperature assigned to each load case."""
    return model._initialTemperatures


def getInertialAcceleration(model: "FEModel") -> Dict[str, Tuple[float, float, float]]:
    """Return the inertial acceleration (body-force) assigned to each load case."""
    return model._inertialAcceleration


def setInertialAcceleration(
    model: "FEModel", loadCase: str, acc: Tuple[float, float, float]
) -> None:
    """Set the inertial (body-force) acceleration for a load case."""
    if not isinstance(loadCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0018",
            "loadCase arg must be a string",
            type(loadCase),
        )

    if loadCase not in model._loadCase.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0019", "loadCase case unknown", loadCase
        )

    if not isinstance(acc, tuple):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0021", "acc must be float tuple", type(acc)
        )

    if len(acc) != 3:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0021", "acc must have len = 3", len(acc)
        )
    model._inertialAcceleration[loadCase] = acc

def setBodyConstraints(model: "FEModel", constraints: tuple[bool, bool, bool, bool, bool, bool]) -> None:
    model._bodyConstraints = constraints

def getBodyConstraints(model: "FEModel")\
        -> tuple[bool, bool, bool, bool, bool, bool]:
    return model._bodyConstraints

def setInitialTemperature(model: "FEModel", loadCase: str, temp: float) -> None:
    """Set the uniform initial (reference) temperature for a load case."""
    if not isinstance(loadCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0018",
            "First arg must be a string",
            type(loadCase),
        )

    if loadCase not in model._loadCase.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0019", "Load case unknown", loadCase
        )

    if not isinstance(temp, float):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0021", "temp must be float list", type(temp)
        )

    model._initialTemperatures[loadCase] = temp


def assignNodeTemperature(
    model: "FEModel",
    loadCase: str,
    tagNode: int,
    temp: float,
    tpTemp: Literal["fixed", "reference", "initial"] = "fixed",
) -> None:
    """Assign a temperature value to a single mesh node for a given load case."""
    if not isinstance(loadCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0018",
            "First arg must be a string",
            type(loadCase),
        )

    if loadCase not in model._loadCase.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0019", "Load case unknown", loadCase
        )

    if tagNode not in model.nodesTags():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0020", "Nodes tag unknown", tagNode
        )

    if not isinstance(temp, float):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0021", "temp must be float list", type(temp)
        )

    if not isinstance(tpTemp, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0021", "tpTemp must be str", type(tpTemp)
        )

    if loadCase not in model._nodeTemperatures:
        model._nodeTemperatures[loadCase] = {}

    if tagNode not in model._nodeTemperatures[loadCase]:
        model._nodeTemperatures[loadCase][tagNode] = {}

    model._nodeTemperatures[loadCase][tagNode][tpTemp] = temp


def assignFrameTemperature(
    model: "FEModel",
    loadCase: str,
    tagFrame: int,
    temp: Tuple[float, float],
    tpTemp: Literal["gradient"] = "gradient",
) -> None:
    """Assign a temperature gradient to a single frame element for a given load case."""
    if not isinstance(loadCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0018",
            "First arg must be a string",
            type(loadCase),
        )

    if loadCase not in model._loadCase:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0019", "loadCase unknown", loadCase
        )

    if tagFrame not in model.framesTags():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0013", "tagFrame unknown", tagFrame
        )

    if not isinstance(tpTemp, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0014", "tpTemp arg must be a string", type(tpTemp)
        )

    if tpTemp not in ["gradient"]:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0014",
            f"tpTemp arg not in {['gradient']}",
            type(tpTemp),
        )

    if not isinstance(temp, tuple):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0014", "temp arg must be a tuple", type(temp)
        )

    if len(temp) != 2:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0014", "temp arg must have len=2", len(temp)
        )

    if loadCase not in model._frameTemperatures:
        model._frameTemperatures[loadCase] = {}

    if tagFrame not in model._frameTemperatures[loadCase]:
        model._frameTemperatures[loadCase][tagFrame] = {}

    model._frameTemperatures[loadCase][tagFrame][tpTemp] = temp


def addLoadCombination(model: "FEModel", keyCombination: str, combination: List[float]) -> None:
    """Register a load combination."""
    model._loadCombinations[keyCombination] = combination


def getLoadCombinations(model: "FEModel") -> Dict[str, List[float]]:
    """Return all registered load combinations."""
    return model._loadCombinations


def addLoadCase(model: "FEModel", idCase: str, tp: str = "U", descr: str = "") -> None:
    """Register a new load case."""
    if not isinstance(idCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0002", "First arg must be a string", idCase
        )
    if not isinstance(tp, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0003", "Second arg must be a string", tp
        )
    else:
        find = False
        for v in model.configData["LoadCaseType"]:
            if v["id"] == tp:
                find = True
                print(
                    "Type *{}* of load case generic *{}*: {} ---> {}".format(
                        idCase, v["id"], v["description"], descr
                    )
                )
                break
        if not find:
            raise Ex.EXAExceptions("(EXAStructuralModel)-0005", "Type unknown", tp)

    if not isinstance(tp, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0004", "Third arg must be a string", descr
        )

    if idCase in model._loadCase.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0006", "Load case must be unique", idCase
        )

    model._loadCase[idCase] = (tp, descr)


def getLoadCases(model: "FEModel") -> Dict[str, Tuple[str, str]]:
    """Return all registered load cases."""
    return model._loadCase


def getLoads(model: "FEModel") -> Dict[str, Dict[LoadType, Any]]:
    """Return all load data organised by load case."""
    return model._loads


def addSelfWeight(model: "FEModel", loadCase: str, GCS: List[float]) -> None:
    """Add a self-weight (gravity) load to a load case."""
    if not isinstance(loadCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0007", "First arg must be a string", loadCase
        )

    if loadCase not in model._loadCase.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0008", "Load case unknown", loadCase
        )

    if not all(isinstance(n, float) for n in GCS):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0009", "GCS must be float list", GCS
        )

    if len(GCS) != 3:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0010", "GCS must have len 3", len(GCS)
        )

    if loadCase not in model._loads:
        model._loads[loadCase] = {}

    model._loads[loadCase][LoadType.SELF_WEIGHT] = GCS


def addMultiFrameWinklerSpring(
    model: "FEModel",
    tagsMacro: List[myInt64],
    tp: NodalSpringsTp,
    dirSprings: NodalSpringsDir,
    subgradeModulus: float,
    Bref: int,
) -> None:
    """Convert a Winkler subgrade modulus into nodal springs for multiple frame macro-elements."""
    if not isinstance(tagsMacro, list):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0011", "tagsMacro must be a list", type(tagsMacro)
        )

    nodesTags = model.nodesTags()
    nodesCoords = model.nodesCoords()
    framesTags = model.getFramesFromMacroTags()
    assert isinstance(framesTags, dict)
    frameNodes = model.getFrameNodesFromMacro()
    assert isinstance(frameNodes, dict)

    for tag in tagsMacro:
        for i, _t in enumerate(framesTags[tag]):
            n1 = frameNodes[tag][i][0]
            n2 = frameNodes[tag][i][1]
            n1_coords = nodesCoords[nodesTags.index(n1)]
            n2_coords = nodesCoords[nodesTags.index(n2)]

            if "DX" in dirSprings:
                idxDir1 = 1
                idxDir2 = 2
            elif "DY" in dirSprings:
                idxDir1 = 0
                idxDir2 = 2
            else:  # "DZ" in dir:
                idxDir1 = 0
                idxDir2 = 0

            tributaryLength = math.sqrt(
                pow(n2_coords[idxDir1] - n1_coords[idxDir1], 2)
                + pow(n2_coords[idxDir2] - n1_coords[idxDir2], 2)
            )

            stiffness = tributaryLength * subgradeModulus * Bref

            addNodeSpring(model, n1, tp, dirSprings, stiffness, add=True)
            addNodeSpring(model, n2, tp, dirSprings, stiffness, add=True)


def addMultiFrameLoadHydro(
    model: "FEModel",
    loadCase: str,
    tagsMacro: List[myInt64],
    dirLoad: Literal["GCX", "GCY", "GCZ"],
    gamma: float,
    K: float,
    H0: float,
    p0: float,
    Bref: float,
    local: bool = False,
    coordVariation: Literal["X", "Y", "Z"] = "Z",
    oneSignPositive: bool | None = None,
    constValue: bool = False,
) -> None:
    """Add a linear hydrostatic load on macro-elements."""
    if not isinstance(loadCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0011",
            "First arg must be a string",
            type(loadCase),
        )

    if not isinstance(tagsMacro, list):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0011", "tagsMacro must be a list", type(tagsMacro)
        )

    if dirLoad not in ("GCX", "GCY", "GCZ"):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0022",
            "Third arg *dir* must be GCX, GCY, GCZ",
            dirLoad,
        )

    nodesTags = model.nodesTags()
    nodesCoords = model.nodesCoords()
    framesTags = model.getFramesFromMacroTags()
    assert isinstance(framesTags, dict)
    frameNodes = model.getFrameNodesFromMacro()
    assert isinstance(frameNodes, dict)

    if coordVariation == "X":
        coords_idx = 0
    elif coordVariation == "Y":
        coords_idx = 1
    else:  # coordVariation == 'Z'
        coords_idx = 2

    for tag in tagsMacro:
        for i, t in enumerate(framesTags[tag]):
            n1 = frameNodes[tag][i][0]
            n2 = frameNodes[tag][i][1]
            n1_coords = nodesCoords[nodesTags.index(n1)]
            n2_coords = nodesCoords[nodesTags.index(n2)]
            press_1 = ((H0 - n1_coords[coords_idx]) * gamma * K + p0) * Bref
            press_2 = ((H0 - n2_coords[coords_idx]) * gamma * K + p0) * Bref
            rel_dist_from_I_node_I = 0.0
            rel_dist_from_I_node_J = 1.0
            if not constValue:
                if oneSignPositive is not None and press_1 != 0.0 or press_2 != 0.0:
                    zero_rel_dist_from_I = abs(
                        press_1 / (abs(press_1) + abs(press_2))
                    )
                    if oneSignPositive:
                        if press_1 <= 0.0 and press_2 <= 0.0:
                            press_1 = 0.0
                            press_2 = 0.0
                        elif press_1 * press_2 < 0.0:
                            if press_1 < 0.0:
                                press_1 = 0.0
                                rel_dist_from_I_node_I = 1 - zero_rel_dist_from_I
                            else:  # press_2 < 0.0:
                                press_2 = 0.0
                                rel_dist_from_I_node_J = zero_rel_dist_from_I
                        else:
                            pass
                    else:  # not oneSignPositive
                        if press_1 >= 0.0 and press_2 >= 0.0:
                            press_1 = 0.0
                            press_2 = 0.0
                        elif press_1 * press_2 < 0.0:
                            if press_1 > 0.0:
                                press_1 = 0.0
                                rel_dist_from_I_node_I = zero_rel_dist_from_I
                            else:  # press_2 < 0.0:
                                press_2 = 0.0
                                rel_dist_from_I_node_J = 1 - zero_rel_dist_from_I
                        else:
                            pass

            else:  # constValue == True
                press_1 = p0 * Bref
                press_2 = press_1
                lenght = math.sqrt(
                    (n1_coords[coords_idx] - n2_coords[coords_idx]) ** 2
                )
                if n1_coords[coords_idx] >= H0 and n2_coords[coords_idx] >= H0:
                    rel_dist_from_I_node_I = 0.0
                    rel_dist_from_I_node_J = 1.0
                    press_1 = 0.0
                    press_2 = 0.0
                else:
                    if n1_coords[coords_idx] <= H0 and n2_coords[coords_idx] <= H0:
                        rel_dist_from_I_node_I = 0.0
                        rel_dist_from_I_node_J = 1.0
                    else:
                        zero_rel_dist_from_I = (
                            abs(abs(H0) - abs(n1_coords[coords_idx])) / lenght
                        )
                        if n1_coords[coords_idx] < H0 <= n2_coords[coords_idx]:
                            rel_dist_from_I_node_I = 0.0
                            rel_dist_from_I_node_J = 1.0 - zero_rel_dist_from_I
                        else:
                            rel_dist_from_I_node_I = zero_rel_dist_from_I
                            rel_dist_from_I_node_J = 1.0

            if dirLoad == "GCX":
                addFrameLoad(
                    model,
                    loadCase,
                    t,
                    tp="force",
                    GCX1=[rel_dist_from_I_node_I, press_1],
                    GCX2=[rel_dist_from_I_node_J, press_2],
                    local=local,
                )
            elif dirLoad == "GCY":
                addFrameLoad(
                    model,
                    loadCase,
                    t,
                    tp="force",
                    GCY1=[rel_dist_from_I_node_I, press_1],
                    GCY2=[rel_dist_from_I_node_J, press_2],
                    local=local,
                )
            elif dirLoad == "GCZ":
                addFrameLoad(
                    model,
                    loadCase,
                    t,
                    tp="force",
                    GCZ1=[rel_dist_from_I_node_I, press_1],
                    GCZ2=[rel_dist_from_I_node_J, press_2],
                    local=local,
                )
            else:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0011",
                    "unknown error in dirLoad",
                    type(dirLoad),
                )


def addMacroFrameLoadLine(
    model: "FEModel",
    loadCase: str,
    tagsMacro: List[myInt64],
    tp: Literal["force", "moment"],
    direction: Literal["X", "Y", "Z"],
    load_value_1: List[float],
    load_value_2: List[float],
    load_position_absolute: bool = True,
    local: bool = False,
) -> None:
    """Apply a linearly-varying distributed load over a macro-frame alignment."""
    if not len(load_value_1) == 2:
        raise Ex.EXAExceptions(
            "(FEModel)", "load_value_1 must have len == 2", load_value_1)

    macro_list = cast(List[myInt64], model.getElementsFromMacroTags(Dim.DIM_1D, tagsMacro))

    _, conn_inverse = model._elementConnectivity(Dim.DIM_1D)

    axis_3 = model.getFrameLocal3(macro_list[0])

    nodes_from_macro = cast(List[myInt64], model.getFrameNodesFromMacro(tagsMacro, unique=True))
    components_alog_axis = []
    coords = []
    for node in nodes_from_macro:
        _xn, _yn, _zn = model.nodeCoords(node)
        coords.append((_xn, _yn, _zn))
        components_alog_axis.append(axis_3.vx * _xn + axis_3.vy * _yn + axis_3.vz * _zn)

    ordered_nodes = [list(x) for x in sorted(zip(nodes_from_macro, components_alog_axis, coords), key=lambda x: x[1])]
    shift = cast(float, ordered_nodes[0][1])
    for i in range(len(ordered_nodes)):
        ordered_nodes[i][1] = cast(float, ordered_nodes[i][1]) - shift

    macro_lenght = abs(cast(float, ordered_nodes[len(ordered_nodes) - 1][1]))

    if load_position_absolute:
        load_value_1[0] = load_value_1[0] / macro_lenght
        load_value_2[0] = load_value_2[0] / macro_lenght

    if not (0.0 <= load_value_1[0] < 1.0):
        raise Ex.EXAExceptions("(FEModel)", "load_value_1[0] must be in [0.0, 1.0)", load_value_1)

    if not (load_value_1[0] < load_value_2[0] <= 1.0):
        raise Ex.EXAExceptions("(FEModel)", "load_value_2[0] must be in (load_value_1[0], 1.0]", load_value_2)

    load_coord_left_on_macro = macro_lenght * load_value_1[0]
    load_coord_right_on_macro = macro_lenght * load_value_2[0]

    resolve_dir = {
        "X": ("GCX1", "GCX2"),
        "Y": ("GCY1", "GCY2"),
        "Z": ("GCZ1", "GCZ2"),
    }
    for i_node in range(len(ordered_nodes) - 1):
        node_i_tag, node_i_coord_on_macro, _ = ordered_nodes[i_node]
        node_j_tag, node_j_coord_on_macro, _ = ordered_nodes[i_node + 1]
        node_i_coord_on_macro = cast(float, node_i_coord_on_macro)
        node_j_coord_on_macro = cast(float, node_j_coord_on_macro)
        frame = conn_inverse[(node_i_tag, node_j_tag)]
        frame_lenght = abs(node_j_coord_on_macro - node_i_coord_on_macro)

        load_left_coord = (load_coord_left_on_macro - node_i_coord_on_macro) / frame_lenght
        load_right_coord = (load_coord_right_on_macro - node_i_coord_on_macro) / frame_lenght

        out_of_load_condition_1 = node_i_coord_on_macro > load_coord_right_on_macro or math.isclose(node_i_coord_on_macro, load_coord_right_on_macro)
        out_of_load_condition_2 = node_j_coord_on_macro < load_coord_left_on_macro or math.isclose(node_j_coord_on_macro, load_coord_left_on_macro)
        if out_of_load_condition_1 or out_of_load_condition_2:
            load_left_value = 0.0
            load_right_value = 0.0
            load_left_coord = 0.0
            load_right_coord = 1.0
        else:

            def _loadValue(_x):
                x1 = load_coord_left_on_macro
                x2 = load_coord_right_on_macro
                y1 = load_value_1[1]
                y2 = load_value_2[1]
                _y = (_x - x1) / (x2 - x1) * (y2 - y1) + y1
                return _y

            if (load_coord_left_on_macro > node_i_coord_on_macro and
                    load_coord_right_on_macro > node_j_coord_on_macro):
                load_left_value = load_value_1[1]
                load_right_value = _loadValue(node_j_coord_on_macro)
                load_right_coord = 1.0

            elif (load_coord_left_on_macro < node_i_coord_on_macro and
                  load_coord_right_on_macro < node_j_coord_on_macro):
                load_left_value = _loadValue(node_i_coord_on_macro)
                load_right_value = load_value_2[1]
                load_left_coord = 0.0
            elif (load_coord_left_on_macro > node_i_coord_on_macro and
                    load_coord_right_on_macro < node_j_coord_on_macro):
                load_left_value = load_value_1[1]
                load_right_value = load_value_2[1]
                load_left_coord = 0.0
                load_right_coord = 1.0
            else:
                load_left_value = _loadValue(node_i_coord_on_macro)
                load_right_value = _loadValue(node_j_coord_on_macro)
                load_left_coord = 0.0
                load_right_coord = 1.0

        load_args = {
            "loadCase": loadCase,
            "tagFrame": frame,
            "tp": tp,
            "local": local,
            resolve_dir[direction][0]: [load_left_coord, load_left_value],
            resolve_dir[direction][1]: [load_right_coord, load_right_value]
        }
        addFrameLoad(model, **load_args)  # type: ignore[arg-type]


def addMultiFrameLoad(
    model: "FEModel",
    loadCase: str,
    tagsFrames: List[myInt64],
    tp: Literal["force", "moment"],
    GCX1: Optional[List[float]] = None,
    GCX2: Optional[List[float]] = None,
    GCY1: Optional[List[float]] = None,
    GCY2: Optional[List[float]] = None,
    GCZ1: Optional[List[float]] = None,
    GCZ2: Optional[List[float]] = None,
    local: bool = False,
) -> None:
    """Apply a distributed load or moment to multiple frame mesh elements."""
    if GCX1 is None:
        GCX1 = []
    if GCX2 is None:
        GCX2 = []
    if GCY1 is None:
        GCY1 = []
    if GCY2 is None:
        GCY2 = []
    if GCZ1 is None:
        GCZ1 = []
    if GCZ2 is None:
        GCZ2 = []

    if not isinstance(tagsFrames, list):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0011",
            "tagsFrames must be a list",
            type(tagsFrames),
        )

    for tag in tagsFrames:
        addFrameLoad(
            model, loadCase, tag, tp, GCX1, GCX2, GCY1, GCY2, GCZ1, GCZ2, local
        )


def addPlateFaceLoad(
    model: "FEModel",
    tagPlate: myInt64,
    load: PlateFaceLoad,
) -> None:
    """Apply a per-plate face load to a single plate element."""
    if load.loadCase not in model._loadCase.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0035", "Load case unknown", load.loadCase
        )
    if tagPlate not in model.platesTags():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0036", "Plate tag unknown", tagPlate
        )

    n_nodes = len(model.platesConnectivity().get(tagPlate, ()))
    if n_nodes > len(load.x) or n_nodes > len(load.y) or n_nodes > len(load.z):
        load = load.model_copy(update={
            "x": load.x + (load.x[-1],) * (n_nodes - len(load.x)) if n_nodes > len(load.x) else load.x,
            "y": load.y + (load.y[-1],) * (n_nodes - len(load.y)) if n_nodes > len(load.y) else load.y,
            "z": load.z + (load.z[-1],) * (n_nodes - len(load.z)) if n_nodes > len(load.z) else load.z,
        })

    if load.loadCase not in model._loads:
        model._loads[load.loadCase] = {}
    if LoadType.PLATE_FACE_LOAD not in model._loads[load.loadCase]:
        model._loads[load.loadCase][LoadType.PLATE_FACE_LOAD] = {}
    model._loads[load.loadCase][LoadType.PLATE_FACE_LOAD][tagPlate] = load


def addMultiPlateFaceLoad(
    model: "FEModel",
    load: PlateFaceLoad,
    tagsMacro: Optional[List[myInt64]] = None,
    tagsPlate: Optional[List[myInt64]] = None,
) -> None:
    """Apply a face load to multiple plate elements."""
    fe_assign.assignMultiElement(
        model, Dim.DIM_2D, lambda t, l: addPlateFaceLoad(model, t, l), load, tagsMacro, tagsPlate
    )


def addFrameLoad(
    model: "FEModel",
    loadCase: str,
    tagFrame: myInt64,
    tp: Literal["force", "moment"],
    GCX1: Optional[List[float]] = None,
    GCX2: Optional[List[float]] = None,
    GCY1: Optional[List[float]] = None,
    GCY2: Optional[List[float]] = None,
    GCZ1: Optional[List[float]] = None,
    GCZ2: Optional[List[float]] = None,
    local: bool = False,
) -> None:
    """Apply a distributed load or moment to a single frame mesh element."""
    if GCX1 is None:
        GCX1 = []
    if GCX2 is None:
        GCX2 = []
    if GCY1 is None:
        GCY1 = []
    if GCY2 is None:
        GCY2 = []
    if GCZ1 is None:
        GCZ1 = []
    if GCZ2 is None:
        GCZ2 = []

    if not isinstance(loadCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0011",
            "First arg must be a string",
            type(loadCase),
        )

    if loadCase not in model._loadCase.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0012", "Load case unknown", loadCase
        )

    if tagFrame not in model.framesTags():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0013", "Frames tag unknown", tagFrame
        )

    if not isinstance(tp, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0014", "Third arg must be a string", type(tp)
        )

    if all(["force" != tp, "moment" != tp]):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0015", "tp option *force* or *moment*", tp
        )

    if (
        not isinstance(GCX1, list)
        or not isinstance(GCX2, list)
        or not isinstance(GCY1, list)
        or not isinstance(GCY2, list)
        or not isinstance(GCZ1, list)
        or not isinstance(GCZ2, list)
    ):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0016", "GCX1 ... GCZ2 arg must be lists", type(tp)
        )

    cond_null_X = all([len(GCX1) == 0, len(GCX2) == 0])
    cond_null_Y = all([len(GCY1) == 0, len(GCY2) == 0])
    cond_null_Z = all([len(GCZ1) == 0, len(GCZ2) == 0])

    def _check(s_dir, val_1, val_2):
        if len(val_1) != 2:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0016", f"GC{s_dir}1 must have len 2", len(val_1)
            )

        if not all(isinstance(n, float) for n in val_1):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0017", f"GC{s_dir} must be float list", val_1
            )

        if len(val_2) != 2 and len(val_2) != 0:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018", f"GC{s_dir}2 must have len 2 or 0", val_2
            )

        if len(val_2) == 0:
            val_2 = val_1[:]
            val_2[0] = 1.0

    if not cond_null_X:
        _check("X", GCX1, GCX2)

    if not cond_null_Y:
        _check("Y", GCY1, GCY2)

    if not cond_null_Z:
        _check("Z", GCZ1, GCZ2)

    if loadCase not in model._loads:
        model._loads[loadCase] = {}

    if LoadType.FRAME_LOAD not in model._loads[loadCase]:
        model._loads[loadCase][LoadType.FRAME_LOAD] = {}

    if tagFrame not in model._loads[loadCase][LoadType.FRAME_LOAD].keys():
        model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame] = {}

    if tp not in model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame].keys():
        model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp] = {}

    sfx = "G"
    if local:
        sfx = "L"

    def _add_load(s_dir, load_val):
        if len(model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp]) <= 0:
            model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][s_dir] = load_val
            return

        if len(model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp]) > 0:
            load_old = model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp].get(s_dir)
            if load_old is not None:
                if "1" in s_dir:
                    limit_pos = min(load_val[0], load_old[0])
                else:
                    limit_pos = max(load_val[0], load_old[0])

                model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][s_dir] = [limit_pos,
                                                                                    load_val[1] + load_old[1]]
            else:
                model._loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][s_dir] = load_val

    if not cond_null_X:
        _add_load(sfx + "CX1", GCX1)
        _add_load(sfx + "CX2", GCX2)

    if not cond_null_Y:
        _add_load(sfx + "CY1", GCY1)
        _add_load(sfx + "CY2", GCY2)

    if not cond_null_Z:
        _add_load(sfx + "CZ1", GCZ1)
        _add_load(sfx + "CZ2", GCZ2)


def addMultiNodeLoad(
    model: "FEModel", loadCase: str, tagsNodes: List[myInt64], NCS: List[float]
) -> None:
    """Apply a nodal load to multiple mesh nodes."""
    if not isinstance(tagsNodes, list):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0018", "tagsNodes arg must be a list", tagsNodes
        )

    for tag in tagsNodes:
        assignNodeLoad(model, loadCase, tag, NCS)


def assignNodeLoad(
    model: "FEModel", loadCase: str, tagNode: myInt64, NCS: List[float]
) -> None:
    """Apply a nodal load to a single mesh node."""
    if not isinstance(loadCase, str):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0018", "First arg must be a string", loadCase
        )

    if loadCase not in model._loadCase.keys():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0019", "Load case unknown", loadCase
        )

    if tagNode not in model.nodesTags():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0020", "Nodes tag unknown", tagNode
        )

    if not all(isinstance(n, float) for n in NCS):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0021", "NCS must be float list", NCS
        )

    if len(NCS) != 6:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0022", "NCS must have len 6", len(NCS)
        )

    if loadCase not in model._loads:
        model._loads[loadCase] = {}

    if LoadType.NODE_LOAD not in model._loads[loadCase]:
        model._loads[loadCase][LoadType.NODE_LOAD] = {}

    model._loads[loadCase][LoadType.NODE_LOAD][tagNode] = {"NCS": NCS}


def addMultiNodeContraints(
    model: "FEModel", tagsNodes: List[myInt64], dof: List[bool]
) -> None:
    """Apply boundary condition constraints to multiple mesh nodes."""
    if not isinstance(tagsNodes, list):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0018", "tagsNodes arg must be a list", tagsNodes
        )

    for tag in tagsNodes:
        addNodeContraints(model, tag, dof)


def addNodeContraints(model: "FEModel", tagNode: myInt64, dof: List[bool]) -> None:
    """Apply boundary condition constraints to a single mesh node."""
    if tagNode not in model.nodesTags():
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0034", "Nodes tag unknown", tagNode
        )

    if not all(isinstance(n, bool) for n in dof):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0021", "dof must be bool list", dof
        )

    if len(dof) != 6:
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0022", "dof must have len 6", len(dof)
        )

    model._nodeSupports[tagNode] = cast(Tuple[bool, bool, bool, bool, bool, bool], tuple(dof))


def getNodeContraints(
    model: "FEModel",
) -> Dict[myInt64, Tuple[bool, bool, bool, bool, bool, bool]]:
    """Return all nodal boundary condition constraints."""
    return model._nodeSupports


def addMultiNodeSpring(
    model: "FEModel",
    tagsNodes: List[myInt64],
    tp: NodalSpringsTp,
    dirSpring: NodalSpringsDir,
    stiffness: float,
) -> None:
    """Add a nodal spring to multiple mesh nodes."""
    if not isinstance(tagsNodes, list):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0018", "tagsNodes arg must be a list", tagsNodes
        )

    for tag in tagsNodes:
        addNodeSpring(model, tag, tp, dirSpring, stiffness)


def addNodeSpring(
    model: "FEModel",
    tagNode: myInt64 | int,
    tp: NodalSpringsTp,
    dirSpring: NodalSpringsDir,
    stiffness: float,
    add: bool = False,
) -> None:
    """Add or accumulate a nodal spring on a single mesh node."""
    if not (isinstance(tagNode, int) or isinstance(tagNode, np.uint64)):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0022",
            "First arg *tagNode* must be int or numpy.uint64",
            tagNode,
        )

    if not isinstance(tp, NodalSpringsTp):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0022",
            "Second arg *tp* must be NodalSpringsTp",
            type(tp),
        )

    if not isinstance(dirSpring, NodalSpringsDir):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0022",
            "Third arg *dir* must be NodalSpringsDir",
            type(tp),
        )

    if not isinstance(stiffness, float):
        raise Ex.EXAExceptions(
            "(EXAStructuralModel)-0022",
            "Fourth arg *stiffness* must be float",
            stiffness,
        )

    if tagNode not in model._nodeSprings.keys():
        model._nodeSprings[tagNode] = {}

    if tp not in model._nodeSprings[tagNode].keys():
        model._nodeSprings[tagNode][tp] = {}

    if dirSpring in model._nodeSprings[tagNode][tp] and add:
        model._nodeSprings[tagNode][tp][dirSpring] += stiffness
    else:
        model._nodeSprings[tagNode][tp][dirSpring] = stiffness


def getNodeSprings(
    model: "FEModel",
) -> Dict[myInt64, Dict[NodalSpringsTp, Dict[NodalSpringsDir, float]]]:
    """Return all nodal spring assignments."""
    return model._nodeSprings
