# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from copy import deepcopy
from typing import Any, Dict, List, Literal, Union, cast

import numpy as np
from gmsh import model as gmsh_model

from pycivil.EXAGeometry.geometry import Point3d

from .fe_types import Dim, Elem

myInt64 = Union[int, np.uint64, np.int32]


class _FEGeometryMixin:
    # ------------------------------------------------------------------
    # Attribute stubs — values initialised by FEModel.__init__.
    # ------------------------------------------------------------------
    _cad: Any
    _macro_element_node: dict[int, Point3d]
    _macro_element_frame: dict[int, tuple[int, int]]
    _macro_element_plate: dict[int, tuple[int, int, int, int] | tuple[int, int, int]]
    _tagToGroupForRename: Dict[Elem, Dict[int, int]]
    _framesPhysicalNames: Dict[myInt64, List[str]]
    _platesPhysicalNames: Dict[myInt64, List[str]]
    _groupTree: Dict[str, str]

    def _log(self, tp: Literal["INF", "WRN", "ERR"], msg: str) -> None: ...

    def getMacroElementNode(self) -> dict[int, Point3d]:
        """Return a deep copy of the macro-element node dictionary.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more underlying mesh entities after meshing.

        Returns:
            A dict mapping each node macro-tag to its ``Point3d`` coordinates.
        """
        return deepcopy(self._macro_element_node)

    def getMacroElementFrame(self) -> dict[int, tuple[int, int]]:
        """Return a deep copy of the macro-element frame dictionary.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more underlying mesh entities after meshing.

        Returns:
            A dict mapping each frame macro-tag to the tuple
            ``(start_node_tag, end_node_tag)``.
        """
        return deepcopy(self._macro_element_frame)

    def getMacroElementPlate(self) -> dict[int, tuple[int, int, int, int] | tuple[int, int, int]]:
        """Return a deep copy of the macro-element plate dictionary.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more underlying mesh entities after meshing.

        Returns:
            A dict mapping each plate macro-tag to the tuple of corner node
            tags (3 values for triangles, 4 for quads).
        """
        return deepcopy(self._macro_element_plate)

    def getCustomIdForTag(self, tag: int, elem_type: Elem) -> int | None:
        """Return the custom physical-group id mapped to a mesh element tag.

        This lookup uses the internal ``tagToGroupForRename`` table, which is
        populated when elements are added with ``groupForRename=True``. It
        allows the caller to map a mesh-space tag back to a user-defined
        physical group id.

        Args:
            tag: Mesh element tag to look up.
            elem_type: Element type (``ELEM_POINT``, ``ELEM_LINE``,
                ``ELEM_TRIA``, or ``ELEM_QUAD``).

        Returns:
            The physical group id if a mapping exists, otherwise ``None``.
        """
        return self._tagToGroupForRename[elem_type].get(tag)

    def addNodesToGroup(
        self, tags: List[myInt64], tagGroup: myInt64, physicalName: str = ""
    ) -> None:
        """Add 0D (point) entities to a physical group.

        Args:
            tags: List of 0D entity tags to add to the group.
            tagGroup: Physical group tag to assign.
            physicalName: Optional name to assign to the physical group.
        """
        self._addElementToGroup(tags, tagGroup, Dim.DIM_0D, physicalName)

    @staticmethod
    def _addElementToGroup(
        tags: List[myInt64], tagGroup: myInt64, dim: Dim, physicalName: str = ""
    ) -> None:
        """Add entities to a GMSH physical group.

        Args:
            tags: List of entity tags to add to the group.
            tagGroup: Physical group tag to assign.
            dim: Spatial dimension of the entities.
            physicalName: Optional name to assign to the physical group.
        """
        gmsh_model.addPhysicalGroup(dim.value, tags, tagGroup)
        if len(physicalName) > 0:
            gmsh_model.setPhysicalName(dim.value, tagGroup, physicalName)

    def getPhysicalNamesForFrame(self, tag: myInt64) -> List[str] | None:
        """Return the physical group names associated with a mesh frame element.

        Args:
            tag: Mesh frame element tag.

        Returns:
            List of physical group name strings the element belongs to,
            or ``None`` if the element has no recorded group.
        """
        return self._framesPhysicalNames.get(tag)

    def getPhysicalNamesForPlate(self, tag: myInt64) -> List[str] | None:
        """Return the physical group names associated with a mesh plate element.

        Args:
            tag: Mesh plate element tag.

        Returns:
            List of physical group name strings the element belongs to,
            or ``None`` if the element has no recorded group.
        """
        return self._platesPhysicalNames.get(tag)

    def addNode(
        self,
        x: Union[int, float] | None = None,
        y: Union[int, float] | None = None,
        z: Union[int, float] | None = None,
        point: Point3d | None = None,
        tag: int = -1,
        group: bool = False,
        tagGroup: int = -1,
        groupForRename: bool = False,
        meshSize: float = 0.0,
    ) -> int:
        """Create a 0D geometric point (node) and optionally add it to a physical group.

        Args:
            x: X coordinate.
            y: Y coordinate.
            z: Z coordinate.
            point: Alternative way to assign coordinate
            tag: Desired GMSH entity tag. -1 lets GMSH choose automatically.
            group: If ``True``, add the point to a physical group.
            tagGroup: Physical group tag. Used only when *group* is ``True``.
            groupForRename: If ``True``, record the mapping between the mesh
                element tag and *tagGroup* in the internal rename table.
                Useful when the model is pre-meshed and tags need to be
                resolved back to user-defined ids.
            meshSize: Target mesh element size at this point. 0.0 inherits
                from the global mesh size setting.

        Returns:
            The GMSH entity tag of the created point.
        """
        cond_no_point = point is None
        cond_yes_point = point is not None
        cond_no_coordinates = any([x is None, y is None, z is None])
        cond_yes_coordinates = all([
            isinstance(x, (int, float)),
            isinstance(y, (int, float)),
            isinstance(z, (int, float)),
        ])

        if all([cond_no_point, cond_no_coordinates]):
            raise ValueError(f"Args must have either coordinates or point")

        if all([cond_yes_point, cond_yes_coordinates]):
            raise ValueError(f"Args must have either coordinates or point")

        if point is not None:
            x = point.x
            y = point.y
            z = point.z

        tag = self._cad.addPoint(x, y, z, meshSize=meshSize, tag=tag)
        self._cad.synchronize()
        if group:
            # There are cases that tagGroup already exists e.g. using slice in 2d elements in pyvista
            #
            # noinspection PyBroadException
            try:
                gmsh_model.addPhysicalGroup(Dim.DIM_0D.value, [tag], tag=tagGroup)
            except Exception:
                self._log("ERR", "addPhysicalGroup error !!!")

            if groupForRename:
                self._log("INF", "Direct map node element to node meshed !!!")
                _, meshTags, _ = gmsh_model.mesh.getElements(Dim.DIM_0D.value, tag)
                if len(meshTags) == 1:
                    if len(meshTags[0]) == 1:
                        self._tagToGroupForRename[Elem.ELEM_POINT][
                            meshTags[0][0]
                        ] = tagGroup
                    else:
                        self._log(
                            "WRN",
                            "meshTags can't be linked with tagGroup because has len != 1 !!!",
                        )

        self._macro_element_node[tag] = Point3d(x=x, y=y, z=z)
        return tag

    def addFrame(
        self,
        tagStart: int,
        tagEnd: int,
        tag: int = -1,
        group: bool = False,
        tagGroup: int = -1,
        nb: int = 1,
        groupForRename: bool = False,
        transfiniteCurve: bool = True,
    ) -> int:
        """Create a 1D straight frame element between two existing points.

        Args:
            tagStart: GMSH entity tag of the start point (node).
            tagEnd: GMSH entity tag of the end point (node).
            tag: Desired GMSH entity tag for the curve. -1 lets GMSH choose.
            group: If ``True``, add the curve to a physical group.
            tagGroup: Physical group tag. Used only when *group* is ``True``.
            nb: Number of mesh elements along the frame. The transfinite
                algorithm places ``nb + 1`` nodes on the curve.
            groupForRename: If ``True``, record the mapping between the mesh
                element tag and *tagGroup* in the internal rename table.
                Only meaningful when *nb* = 1 (single-element frame).
            transfiniteCurve: If ``True``, apply a structured (transfinite)
                meshing algorithm and immediately generate the 1D mesh.

        Returns:
            The GMSH entity tag of the created curve.
        """
        tag = self._cad.addLine(tagStart, tagEnd, tag=tag)
        self._cad.synchronize()

        # mesh frame to have underlying mesh
        mesh = gmsh_model.mesh
        if transfiniteCurve:
            mesh.setTransfiniteCurve(tag, nb + 1)
            mesh.generate(1)

        if group:
            # noinspection PyBroadException
            try:
                gmsh_model.addPhysicalGroup(Dim.DIM_1D.value, [tag], tag=tagGroup)
            except Exception:
                self._log("ERR", "addPhysicalGroup error !!!")

            if groupForRename:
                self._log("INF", "Direct map frame element to frame meshed !!!")
                # getElements return mesh tag under model tag. meshTags has one elements because
                #
                _, meshTags, _ = gmsh_model.mesh.getElements(Dim.DIM_1D.value, tag)
                if len(meshTags) == 1:
                    if len(meshTags[0]) == 1:
                        self._tagToGroupForRename[Elem.ELEM_LINE][
                            meshTags[0][0]
                        ] = tagGroup
                    else:
                        self._log(
                            "WRN",
                            "meshTags can't be linked with tagGroup because has len != 1 !!!",
                        )

        self._macro_element_frame[tag] = (tagStart, tagEnd)
        return tag

    def addPlate(
        self,
        tagLine_1: int | None = None,
        tagLine_2: int | None = None,
        tagLine_3: int | None = None,
        tagLine_4: int | None = None,
        tag: int = -1,
        group: bool = False,
        tagGroup: int = -1,
        groupForRename: bool = False,
        elType: Elem = Elem.ELEM_QUAD,
        transfiniteSurface: bool = True,
        nodes: list[int] | None = None,
        lines: list[int] | None = None,
        nb: int | None = None,
    ) -> int:
        """Create a planar surface bounded by 3 or 4 curves and generate its mesh.

        The boundary can be specified in three mutually exclusive ways:

        **Positional line args** — pass 3 or 4 pre-existing curve tags directly::

            plate = am.addPlate(f1, f2, f3, f4)
            plate = am.addPlate(f1, f2, f3)

        **Line list** (keyword ``lines``) — same as above but as a single list::

            plate = am.addPlate(lines=[f1, f2, f3, f4])
            plate = am.addPlate(lines=[f1, f2, f3])

        In both line modes, mesh density and transfinite settings are controlled
        by the nb/transfiniteCurve parameters used when those curves were created
        with addFrame.  Setting nb=1 on every boundary curve yields exactly one
        element covering the whole surface::

            f1 = am.addFrame(n1, n2, nb=1, transfiniteCurve=True)
            ...
            plate = am.addPlate(lines=[f1, f2, f3, f4])

        **Node list** (keyword ``nodes``) — pass 3 or 4 node tags; boundary
        curves are created internally as plain lines.  Use this when the
        boundary curves do not need to be referenced independently::

            plate = am.addPlate(nodes=[n1, n2, n3, n4])
            plate = am.addPlate(nodes=[n1, n2, n3])

        To force a single-element mesh in node mode, combine with ``nb=1``
        and ``transfiniteSurface=True``.  ``nb`` sets the number of elements
        per boundary edge (same convention as addFrame: nb+1 nodes per edge
        via setTransfiniteCurve), so ``nb=1`` places only the two endpoint
        nodes on each edge::

            plate = am.addPlate(nodes=[n1, n2, n3, n4], nb=1)
            plate = am.addPlate(nodes=[n1, n2, n3], nb=1, elType=Elem.ELEM_TRIA)

        Args:
            tagLine_1: Tag of the first boundary curve (positional line mode).
            tagLine_2: Tag of the second boundary curve (positional line mode).
            tagLine_3: Tag of the third boundary curve (positional line mode).
            tagLine_4: Tag of the fourth boundary curve (positional line mode),
                or None for a triangular surface.
            tag: Gmsh tag to assign to the surface.  -1 lets gmsh choose.
            group: If True, add the surface to a physical group.
            tagGroup: Physical group tag. Used only when group=True.
            groupForRename: If True, will be add tag to special maps that link
                model tag to mesh tag. This is usefull when you have to build
                a model that is already meshed.
            elType: Element type for the surface mesh.  ELEM_QUAD triggers
                setRecombine so triangles are merged into quads; ELEM_TRIA
                leaves the triangulation unchanged.
            transfiniteSurface: If True, apply setTransfiniteSurface for a
                structured mesh.  Set to False for an unstructured Delaunay
                mesh (required when embedding interior nodes via addNodesToPlate).
            nodes: List of 3 or 4 node tags (node mode).
            lines: List of 3 or 4 line tags (line list mode).
            nb: Number of elements per boundary edge, applied only in node
                mode (ignored for line modes).  Follows the same convention as
                addFrame: gmsh receives nb+1 nodes per edge via
                setTransfiniteCurve.  Use nb=1 to force a single-element mesh.
                When None (default) no transfinite setting is applied to the
                boundary curves.

        Returns:
            The gmsh surface tag of the created plate.

        Raises:
            ValueError: If the supplied list has a count other than 3 or 4,
                or if no boundary input is provided.
        """
        if nodes is not None:
            if len(nodes) not in (3, 4):
                raise ValueError(f"nodes must have 3 or 4 entries, got {len(nodes)}")
            resolved_lines = [
                self._cad.addLine(nodes[i], nodes[(i + 1) % len(nodes)])
                for i in range(len(nodes))
            ]
            resolved_nodes = nodes
            if nb is not None:
                self._cad.synchronize()
                for line_tag in resolved_lines:
                    gmsh_model.mesh.setTransfiniteCurve(line_tag, nb + 1)
        elif lines is not None:
            if len(lines) not in (3, 4):
                raise ValueError(f"lines must have 3 or 4 entries, got {len(lines)}")
            resolved_lines = lines
            resolved_nodes = []
            for l in resolved_lines:
                resolved_nodes.append(self._macro_element_frame[l][0])
                resolved_nodes.append(self._macro_element_frame[l][1])
            resolved_nodes = list(set(resolved_nodes))
        else:
            if tagLine_1 is None or tagLine_2 is None or tagLine_3 is None:
                raise ValueError(
                    "Provide boundary via nodes=[...], lines=[...], or tagLine_1/2/3"
                )
            resolved_lines = (
                [tagLine_1, tagLine_2, tagLine_3]
                if tagLine_4 is None
                else [tagLine_1, tagLine_2, tagLine_3, tagLine_4]
            )
            resolved_nodes = []
            for l in resolved_lines:
                resolved_nodes.append(self._macro_element_frame[l][0])
                resolved_nodes.append(self._macro_element_frame[l][1])
            resolved_nodes = list(set(resolved_nodes))

        wireId = self._cad.addCurveLoop(resolved_lines)

        plateId = self._cad.addPlaneSurface(wireTags=[wireId], tag=tag)
        self._cad.synchronize()
        mesh = gmsh_model.mesh
        if transfiniteSurface:
            mesh.setTransfiniteSurface(tag=plateId, arrangement="left")
        if elType == Elem.ELEM_QUAD:
            mesh.setRecombine(dim=2, tag=plateId)

        mesh.generate(2)
        mesh.removeDuplicateNodes()

        if group:
            # noinspection PyBroadException
            try:
                gmsh_model.addPhysicalGroup(Dim.DIM_2D.value, [plateId], tag=tagGroup)
            except Exception:
                self._log("ERR", "addPhysicalGroup error !!!")

            if groupForRename:
                self._log("INF", "Direct map plate element to plate meshed !!!")
                # getElements return mesh tag under model tag. meshTags has one elements because
                #
                _, meshTags, _ = gmsh_model.mesh.getElements(Dim.DIM_2D, tag)
                if len(meshTags) == 1:
                    if len(meshTags[0]) == 1:
                        tp_element = (
                            Elem.ELEM_TRIA
                            if len(resolved_lines) == 3
                            else Elem.ELEM_QUAD
                        )
                        self._tagToGroupForRename[tp_element][
                            meshTags[0][0]
                        ] = tagGroup
                    else:
                        self._log(
                            "WRN",
                            "meshTags can't be linked with tagGroup because has len != 1 !!!",
                        )

        self._macro_element_plate[plateId] = cast(
            "tuple[int, int, int, int] | tuple[int, int, int]", tuple(resolved_nodes)
        )
        return plateId

    @staticmethod
    def addNodesToPlate(tags: list[int], tagMacro: int) -> None:
        """Embed existing nodes inside a plate surface and regenerate its mesh.

        Embedded nodes are forced to appear as vertices in the resulting
        triangulation, enabling mesh refinement around interior points.
        The plate must have been created with ``transfiniteSurface=False``
        to allow an unstructured mesh that can accommodate interior nodes.

        Args:
            tags: List of 0D entity (point) tags to embed in the surface.
            tagMacro: GMSH surface entity tag of the target plate.
        """
        gmsh_model.mesh.embed(0, tags, 2, tagMacro)
        gmsh_model.mesh.generate(2)

    def addArc(
        self,
        tagStart: int,
        tagMid: int,
        tagEnd: int,
        tag: int = -1,
        group: bool = False,
        tagGroup: int = -1,
        nb: int = 10,
    ) -> int:
        """Create a circular arc through three existing points.

        Args:
            tagStart: GMSH entity tag of the arc start point.
            tagMid: GMSH entity tag of a point on the arc (used to define
                the circle; does not need to be the midpoint).
            tagEnd: GMSH entity tag of the arc end point.
            tag: Desired GMSH entity tag for the curve. -1 lets GMSH choose.
            group: If ``True``, add the arc to a physical group.
            tagGroup: Physical group tag. Used only when *group* is ``True``.
            nb: Number of mesh elements along the arc. The transfinite
                algorithm places ``nb + 1`` nodes on the curve. Default is 10.

        Returns:
            The GMSH entity tag of the created arc curve.
        """
        tag = self._cad.addCircleArc(tagStart, tagMid, tagEnd, tag=tag)
        self._cad.synchronize()

        # mesh frame to have underlying mesh
        mesh = gmsh_model.mesh
        mesh.setTransfiniteCurve(tag, nb + 1)
        mesh.generate(1)

        if group:
            gmsh_model.addPhysicalGroup(Dim.DIM_1D.value, [tag], tag=tagGroup)
            # self._cad.synchronize()
        return tag

