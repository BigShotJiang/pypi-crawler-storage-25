# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

from pycivil.EXAUtils import EXAExceptions as Ex
from pycivil.settings import ServerSettings

from .fe_types import LoadType

if TYPE_CHECKING:
    from .fe import FEModel


_template_path = ServerSettings().midas_templates_path
_file_loader = FileSystemLoader(searchpath=_template_path)
_env = Environment(loader=_file_loader)
_template = _env.get_template("template-box.mgt")


def save_mgt(model: "FEModel", fileName: str) -> None:
    """Serialise a :class:`FEModel` to a MIDAS Gen MGT text file.

    Collects nodes, beam elements, section shapes, load cases, constraints,
    nodal springs, and load data, renders them via the Jinja2 template
    ``template-box.mgt``, and writes the result to ``<fileName>.mgt``.

    Args:
        model: The finite-element model to serialise.
        fileName: Output file path without extension.
    """
    # ----------------
    # *NODE    ; Nodes
    # ; iNO, X, Y, Z
    # ----------------
    nodes = []
    nodesTags = model.nodesTags()
    nodesCoords = model.nodesCoords()
    for i, n in enumerate(nodesTags):
        strFormat = "{id:d},{x:.6f},{y:.6f},{z:.6f}"
        formatted = strFormat.format(
            id=n, x=nodesCoords[i][0], y=nodesCoords[i][1], z=nodesCoords[i][2]
        )
        nodes.append(formatted)

    # ------------------------------------------------------------------------------------
    # *ELEMENT    ; Elements
    # ; iEL, TYPE, iMAT, iPRO, iN1, iN2, ANGLE, iSUB,                     ; Frame  Element
    # ; iEL, TYPE, iMAT, iPRO, iN1, iN2, ANGLE, iSUB, EXVAL, EXVAL2, bLMT ; Comp/Tens Truss
    # ; iEL, TYPE, iMAT, iPRO, iN1, iN2, iN3, iN4, iSUB, iWID , LCAXIS    ; Planar Element
    # ; iEL, TYPE, iMAT, iPRO, iN1, iN2, iN3, iN4, iN5, iN6, iN7, iN8     ; Solid  Element
    # ------------------------------------------------------------------------------------
    frames = []
    framesTags = model.framesTags()
    framesNodeTags = model.framesNodeTags()

    for i, f in enumerate(framesTags):
        if f in model._framesShapes.keys():
            idShape = model._framesShapes[f]
        else:
            idShape = 1
        strFormat = "{id:d},BEAM,1,{iPRO:d},{idStart:d},{idEnd:d},0,0"
        formatted = strFormat.format(
            id=f,
            iPRO=idShape,
            idStart=framesNodeTags[i][0],
            idEnd=framesNodeTags[i][1],
        )
        frames.append(formatted)

    sections = []
    for k, v in model._sectionShapes.items():
        strFormat = "{idShape:>8d},DBUSER,{name:>16s}, CC, 0, 0, 0, 0, 0, 0, YES, NO, SB, 2,{width:>8.3f},{height:>8.3f},0,0,0,0,0,0,0,0"
        formatted = strFormat.format(
            idShape=k,
            name=v.name,
            width=v.param[0],
            height=v.param[1],
        )
        sections.append(formatted)

        # --------------------------------
    # *STLDCASE    ; Static Load Cases
    # ; LCNAME, LCTYPE, DESC
    # --------------------------------
    loadCases = []
    for key_load in model._loadCase.keys():
        load = model._loadCase[key_load]
        strFormat = "{LCNAME:>8s},{LCTYPE:>3s},{DESC:>40s}"
        formatted = strFormat.format(LCNAME=key_load, LCTYPE=load[0], DESC=load[1])
        loadCases.append(formatted)

    # --------------------------------------------
    # *CONSTRAINT    ; Supports
    # ; NODE_LIST, CONST(Dx,Dy,Dz,Rx,Ry,Rz), GROUP
    # --------------------------------------------
    nodeContraints = []
    if len(model._nodeSupports) > 0:
        nodeContraints.append("*CONSTRAINT")
        for k_node, v_supp in model._nodeSupports.items():
            strFormat = "{tag:d},{TX:d}{TY:d}{TZ:d}{RX:d}{RY:d}{RZ:d}"
            formatted = strFormat.format(
                tag=k_node,
                TX=int(v_supp[0]),
                TY=int(v_supp[1]),
                TZ=int(v_supp[2]),
                RX=int(v_supp[3]),
                RY=int(v_supp[4]),
                RZ=int(v_supp[5]),
            )
            nodeContraints.append(formatted)

    # -----------------------------------------------------------------------------------------------------------------
    # *SPRING    ; Point Spring Supports
    # ; NODE_LIST, Type, F_SDx, F_SDy, F_SDz, F_SRx, F_SRy, F_SRz, SDx, SDy, SDz, SRx, SRy, SRz ...
    # ;                  DAMPING, Cx, Cy, Cz, CRx, CRy, CRz, GROUP, [DATA1]                                ; LINEAR
    # ; NODE_LIST, Type, Direction, Vx, Vy, Vz, Stiffness, GROUP, [DATA1]                                  ; COMP, TENS
    # ; NODE_LIST, Type, Direction, Vx, Vy, Vz, FUNCTION, GROUP, [DATA1]                                   ; MULTI
    # ; [DATA1] EFFAREA, Kx, Ky, Kz
    # -----------------------------------------------------------------------------------------------------------------
    springs = []
    if len(model._nodeSprings) > 0:
        springs.append("*SPRING")
        for k_spring, v_spring in model._nodeSprings.items():
            for kk, vv in v_spring.items():
                if kk == "COMP":
                    Type = "COMP"
                elif kk == "TENS":
                    Type = "TENS"
                elif kk == "LINEAR":
                    Type = "LINEAR"
                else:
                    raise Ex.EXAExceptions(
                        "(EXAStructuralModel)-0026", "key error in Type", kk
                    )
                for kkk, vvv in vv.items():
                    if kkk == "DX+":
                        Direction = 0
                    elif kkk == "DX-":
                        Direction = 1
                    elif kkk == "DY+":
                        Direction = 2
                    elif kkk == "DY-":
                        Direction = 3
                    elif kkk == "DZ+":
                        Direction = 4
                    elif kkk == "DZ-":
                        Direction = 5
                    else:
                        raise Ex.EXAExceptions(
                            "(EXAStructuralModel)-0026",
                            "key error in Direction",
                            kkk,
                        )
                    strFormat = "{tag:d},{Type:s},{Direction:d},0,0,0,{Stiffness:.6f}, , 0, 0, 0, 0, 0"
                    formatted = strFormat.format(
                        tag=k_spring, Type=Type, Direction=Direction, Stiffness=vvv
                    )
                    springs.append(formatted)
        springs.append("")

    # -----------------
    # *USE-STLD, <name>
    # -----------------
    loadCasesUsed = []
    for k_load, v_load in model._loads.items():
        strFormat = "*USE-STLD, {key:s}"
        formatted = strFormat.format(key=k_load)
        loadCasesUsed.append(formatted)
        loadCasesUsed.append("")
        for kk_load, vv_load in v_load.items():
            if kk_load == LoadType.FRAME_LOAD:
                loadCasesUsed.append("*BEAMLOAD")
                # *BEAMLOAD    ; Element Beam Loads
                # ; ELEM_LIST, CMD, TYPE, DIR, bPROJ, [ECCEN], [VALUE], GROUP
                # ; ELEM_LIST, CMD, TYPE, TYPE, DIR, VX, VY, VZ, bPROJ, [ECCEN], [VALUE], GROUP
                # ; [VALUE]       : D1, P1, D2, P2, D3, P3, D4, P4
                # ; [ECCEN]       : bECCEN, ECCDIR, I-END, J-END, bJ-END
                # ; [ADDITIONAL]  : bADDITIONAL, ADDITIONAL_I-END, ADDITIONAL_J-END, bADDITIONAL_J-END
                for kkk_load, vvv_load in vv_load.items():
                    for kkkk_load, vvvv_load in vvv_load.items():
                        if kkkk_load == "force":
                            tp = "UNILOAD"
                        elif kkkk_load == "moment":
                            tp = "UNIMOMENT"
                        else:
                            raise Ex.EXAExceptions(
                                "(EXAStructuralModel)-0026",
                                "key error in tp",
                                kkkk_load,
                            )

                        if (
                            "GCX1" in vvvv_load.keys()
                            and "GCX2" in vvvv_load.keys()
                        ):
                            strFormat = "{tag: d}, BEAM   , {tp}, GX, NO , NO, aDir[1], , , , {GCX1D:.6f}, {GCX1P:.6f}, {GCX2D:.6f}, {GCX2P:.6f}, 0, 0, 0, 0, , NO, 0, 0, NO,"
                            formatted = strFormat.format(
                                tag=kkk_load,
                                tp=tp,
                                GCX1D=vvvv_load["GCX1"][0],
                                GCX1P=vvvv_load["GCX1"][1],
                                GCX2D=vvvv_load["GCX2"][0],
                                GCX2P=vvvv_load["GCX2"][1],
                            )
                            loadCasesUsed.append(formatted)
                        if (
                            "GCY1" in vvvv_load.keys()
                            and "GCY2" in vvvv_load.keys()
                        ):
                            strFormat = "{tag: d}, BEAM   , {tp}, GY, NO , NO, aDir[1], , , , {GCY1D:.6f}, {GCY1P:.6f}, {GCY2D:.6f}, {GCY2P:.6f}, 0, 0, 0, 0, , NO, 0, 0, NO,"
                            formatted = strFormat.format(
                                tag=kkk_load,
                                tp=tp,
                                GCY1D=vvvv_load["GCY1"][0],
                                GCY1P=vvvv_load["GCY1"][1],
                                GCY2D=vvvv_load["GCY2"][0],
                                GCY2P=vvvv_load["GCY2"][1],
                            )
                            loadCasesUsed.append(formatted)
                        if (
                            "GCZ1" in vvvv_load.keys()
                            and "GCZ2" in vvvv_load.keys()
                        ):
                            strFormat = "{tag: d}, BEAM   , {tp}, GZ, NO , NO, aDir[1], , , , {GCZ1D:.6f}, {GCZ1P:.6f}, {GCZ2D:.6f}, {GCZ2P:.6f}, 0, 0, 0, 0, , NO, 0, 0, NO,"
                            formatted = strFormat.format(
                                tag=kkk_load,
                                tp=tp,
                                GCZ1D=vvvv_load["GCZ1"][0],
                                GCZ1P=vvvv_load["GCZ1"][1],
                                GCZ2D=vvvv_load["GCZ2"][0],
                                GCZ2P=vvvv_load["GCZ2"][1],
                            )
                            loadCasesUsed.append(formatted)

                loadCasesUsed.append("")

            elif kk_load == LoadType.NODE_LOAD:
                loadCasesUsed.append("*CONLOAD")
                # *CONLOAD    ; Nodal Loads
                # ; NODE_LIST, FX, FY, FZ, MX, MY, MZ, GROUP
                for kkk_load, vvv_load in vv_load.items():
                    strFormat = "{tag: d}, {FX:.6f}, {FY:.6f}, {FZ:.6f}, {MX:.6f}, {MY:.6f}, {MZ:.6f},"
                    formatted = strFormat.format(
                        tag=kkk_load,
                        FX=vvv_load["NCS"][0],
                        FY=vvv_load["NCS"][1],
                        FZ=vvv_load["NCS"][2],
                        MX=vvv_load["NCS"][3],
                        MY=vvv_load["NCS"][4],
                        MZ=vvv_load["NCS"][5],
                    )
                    loadCasesUsed.append(formatted)

                loadCasesUsed.append("")

            elif kk_load == LoadType.SELF_WEIGHT:
                loadCasesUsed.append("*SELFWEIGHT")
                strFormat = "{DIRX: .6f}, {DIRY: .6f}, {DIRZ: .6f},"
                formatted = strFormat.format(
                    DIRX=vv_load[0], DIRY=vv_load[1], DIRZ=vv_load[2]
                )
                loadCasesUsed.append(formatted)
                loadCasesUsed.append("")
            else:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0025",
                    "key error in loadCasesUsed",
                    kk_load,
                )

        loadCasesUsed.append(
            f"; End of data for load case {k_load} -------------------------"
        )

    output = _template.render(
        udm="KN,M, BTU, C",
        nodes=nodes,
        elements=frames,
        loadCases=loadCases,
        loadCasesUsed=loadCasesUsed,
        contraints=nodeContraints,
        springs=springs,
        sections=sections,
    )

    with open(fileName + ".mgt", "w") as fn:
        fn.write(output)