# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

import typing
from typing import Any, Dict, List, Literal, Set, Tuple, Union, cast

import gmsh
import numpy as np
from gmsh import model as gmsh_model

from pycivil.EXAUtils import EXAExceptions as Ex

from .fe_types import Dim

myInt64 = Union[int, np.uint64, np.int32]


class _FEMeshMixin:

    @staticmethod
    def _elementConnectivity(
        dimension: Dim, elTag: myInt64 = -1
    ) -> Tuple[Dict[Any, Tuple[Any, ...]], Dict[Any, Tuple[Any, ...]]]:
        """Return a connectivity dictionary for mesh elements of a given dimension.

        Args:
            dimension: Spatial dimension of the elements to query (0D, 1D, 2D, or 3D).
            elTag: GMSH entity tag to restrict the query to. -1 queries all entities
                of the given dimension.

        Returns:
            A dict mapping each mesh element tag to a tuple of its node tags.
            For example, a line element returns ``(node_i, node_j)`` and a
            triangle returns ``(node_i, node_j, node_k)``.
        """
        elementTypes, elementTags, nodeTags = gmsh_model.mesh.getElements(
            dimension.value, elTag
        )
        el_type_node_nb_map = {0: 1, 1: 2, 2: 3, 3: 4}  # node  # line  # tria  # quad
        connectivity = {}
        connectivity_inverse = {}
        for t, tp_element in enumerate(elementTypes):
            node_nb = el_type_node_nb_map[tp_element]
            for i, tag in enumerate(elementTags[t]):
                node_list = []
                for n in range(node_nb):
                    node_list.append(nodeTags[t][i * node_nb + n])
                connectivity[tag] = tuple(node_list)
                connectivity_inverse[tuple(node_list)] = tag
        return connectivity, connectivity_inverse

    @staticmethod
    def framesConnectivity(frameTag: myInt64 = -1) -> Dict[Any, Tuple[Any, ...]]:
        """Return connectivity for 1D (frame/beam) mesh elements.

        Args:
            frameTag: GMSH entity tag to restrict the query to. -1 queries all
                1D entities.

        Returns:
            A dict mapping each frame mesh element tag to a 2-tuple of its
            node tags ``(node_i, node_j)``.
        """
        return _FEMeshMixin._elementConnectivity(Dim.DIM_1D, frameTag)[0]

    @staticmethod
    def platesConnectivity(plateTag: myInt64 = -1) -> Dict[Any, Tuple[Any, ...]]:
        """Return connectivity for 2D (plate/shell) mesh elements.

        Args:
            plateTag: GMSH entity tag to restrict the query to. -1 queries all
                2D entities.

        Returns:
            A dict mapping each plate mesh element tag to a tuple of its node
            tags (3 values for triangles, 4 for quads).
        """
        return _FEMeshMixin._elementConnectivity(Dim.DIM_2D, plateTag)[0]

    @staticmethod
    def nodeCoords(nodeTags: myInt64) -> Tuple[float, float, float]:
        """Return the (x, y, z) coordinates of a single mesh node.

        Args:
            nodeTags: Tag of the mesh node to query.

        Returns:
            A 3-tuple ``(x, y, z)`` with the node coordinates.
        """
        coord, _, _, _ = gmsh_model.mesh.getNode(nodeTags)
        return coord

    @staticmethod
    def elementsTags(dimension: Dim) -> List[myInt64]:
        """Return a flat list of all mesh element tags for a given dimension.

        Args:
            dimension: Spatial dimension of the elements to query
                (e.g. ``Dim.DIM_1D`` for frames, ``Dim.DIM_2D`` for plates).

        Returns:
            A flat list of mesh element tags across all entities of the
            requested dimension.
        """
        ft = []
        entities = gmsh_model.getEntities(dimension.value)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            # Get the mesh nodes for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            for et in elemTags:
                ft += list(et)
        return ft

    @staticmethod
    def framesTags() -> List[myInt64]:
        """Return a flat list of all 1D (frame/beam) mesh element tags.

        Returns:
            A flat list of mesh element tags for every frame element in the model.
        """
        return _FEMeshMixin.elementsTags(Dim.DIM_1D)

    @staticmethod
    def platesTags() -> List[myInt64]:
        """Return a flat list of all 2D (plate/shell) mesh element tags.

        Returns:
            A flat list of mesh element tags for every plate element in the model.
        """
        return _FEMeshMixin.elementsTags(Dim.DIM_2D)

    @staticmethod
    def getFrameNodesFromMacro(
        macroTags: List[myInt64] | List[List[myInt64]] | None = None,
        unique: bool = False,
    ) -> (
        Dict[myInt64, List[Tuple[myInt64, myInt64]]]
        | List[Tuple[myInt64, myInt64]]
        | List[myInt64]
    ):
        """Return node-tag pairs for all mesh frames belonging to macro-elements.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more underlying mesh entities after meshing.

        Args:
            macroTags: Controls which macro-elements to query.

                * ``None`` or empty list — return the full connectivity dict
                  ``{macro_tag: [(n1, n2), ...]}``.
                * A flat ``List[myInt64]`` — return a flat list of
                  ``(node_i, node_j)`` pairs for those macro-elements.
                * A ``List[List[myInt64]]`` — lists are merged into a single
                  flat list before querying.

            unique: When *macroTags* is provided, if ``True`` return a flat
                deduplicated list of individual node tags instead of pairs.
                Default is ``False``.

        Returns:
            * Full dict ``{macro_tag: [(n1, n2), ...]}`` when no *macroTags* are given.
            * List of ``(node_i, node_j)`` tuples when *macroTags* are given and
              *unique* is ``False``.
            * Flat list of unique node tags when *macroTags* are given and
              *unique* is ``True``.
        """
        _mt: List[Any]
        if macroTags is None:
            _mt = []
        elif not isinstance(macroTags, list):
            _mt = [macroTags]
        elif len(macroTags) == 0:
            return []
        elif isinstance(macroTags[0], list):
            _mt = []
            for m in macroTags:
                assert isinstance(m, list)
                _mt.extend(m)
        else:
            _mt = macroTags

        ft: Dict[myInt64, List[Tuple[myInt64, myInt64]]] = {}
        entities = gmsh_model.getEntities(1)
        unique_tags: Set[myInt64] = set()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            # Get the mesh nodes for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            nt = []
            for a in elemNodeTags[0].reshape(round(len(elemNodeTags[0]) / 2), 2):
                nt += [tuple(a)]
            ft[tag] = nt

        if len(_mt) == 0:
            return ft
        else:
            tags: List[Tuple[myInt64, myInt64]] = []
            assert isinstance(ft, dict)
            for i in _mt:
                type(i)
                assert isinstance(i, typing.get_args(myInt64))
                tags += ft[i]

            if unique:
                for n in tags:
                    unique_tags.add(n[0])
                    unique_tags.add(n[1])
                return list(unique_tags)

            return tags

    @staticmethod
    def _elementsNodeTags(dimension: Dim) -> List[List[myInt64]]:
        """Return node tags for every mesh element of a given dimension.

        Args:
            dimension: Spatial dimension of the elements to query.

        Returns:
            A list of lists, where each inner list contains the node tags of
            one mesh element (ordered as returned by GMSH).
        """
        ft = []
        element_node_dict, _ = _FEMeshMixin._elementConnectivity(dimension)
        for el in element_node_dict:
            ft.append(list(element_node_dict[el]))
        return ft

    @staticmethod
    def framesNodeTags() -> List[List[myInt64]]:
        """Return node tags for every 1D (frame/beam) mesh element.

        Returns:
            A list of 2-element lists ``[node_i, node_j]``, one per frame
            element, in the same order as :meth:`framesTags`.
        """
        return _FEMeshMixin._elementsNodeTags(Dim.DIM_1D)

    @staticmethod
    def platesNodeTags() -> List[List[myInt64]]:
        """Return node tags for every 2D (plate/shell) mesh element.

        Returns:
            A list of 3- or 4-element lists of node tags, one per plate
            element, in the same order as :meth:`platesTags`.
        """
        return _FEMeshMixin._elementsNodeTags(Dim.DIM_2D)

    @staticmethod
    def nodesCoords() -> List[List[float]]:
        """Return the coordinates of all mesh nodes in the model.

        Returns:
            A list of ``[x, y, z]`` coordinate lists, one per mesh node,
            across all entities and dimensions.
        """
        nc = []
        entities = gmsh_model.getEntities()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]

            # Get the mesh nodes for the entity (dim, tag):
            nodeTags, nodeCoords, nodeParams = gmsh.model.mesh.getNodes(dim, tag)
            nc += nodeCoords.reshape(round(len(nodeCoords) / 3), 3).tolist()
        return nc

    @staticmethod
    def nodesGroups() -> Dict[Any, List[int]]:
        """Return the physical groups associated with each 0D (point) entity.

        Returns:
            A dict mapping each point entity tag to the list of physical group
            tags it belongs to.
        """
        ng = {}
        entities = gmsh_model.getEntities(0)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            ng[tag] = list(gmsh_model.getPhysicalGroupsForEntity(dim, tag))
        return ng

    @staticmethod
    def framesGroups():
        """Return the physical groups associated with each 1D (line) entity.

        Returns:
            A dict mapping each line entity tag to the list of physical group
            tags it belongs to.
        """
        fg = {}
        entities = gmsh_model.getEntities(1)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            fg[tag] = list(gmsh_model.getPhysicalGroupsForEntity(dim, tag))
        return fg

    @staticmethod
    def printNodes() -> None:
        """Print all mesh node tags, coordinates, and physical groups to stdout.

        Iterates over every entity in the model and prints the node tags,
        their coordinates, and the physical groups they belong to.
        Intended for debugging purposes.
        """
        print("** start Nodes **")
        entities = gmsh_model.getEntities()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]

            # Get the mesh nodes for the entity (dim, tag):
            nodeTags, nodeCoords, nodeParams = gmsh.model.mesh.getNodes(dim, tag)
            print("nodeTags", nodeTags)
            print("nodeCoords", nodeCoords)
            print("phisicalGroup", gmsh_model.getPhysicalGroupsForEntity(dim, tag))
        print("** end Nodes **")

    @staticmethod
    def printFrames() -> None:
        """Print all 1D mesh element types, tags, node tags, and physical groups to stdout.

        Iterates over every 1D entity in the model and prints element types,
        element tags, node tags per element, and the physical groups they belong to.
        Intended for debugging purposes.
        """
        print("** start Frames **")
        entities = gmsh_model.getEntities(1)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]

            # Get the mesh elements for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            print("elemTypes", elemTypes)
            print("elemTags", elemTags)
            print("elemNodeTags", elemNodeTags)
            print("phisicalGroup", gmsh_model.getPhysicalGroupsForEntity(dim, tag))
        print("** end Frames **")

    @staticmethod
    def printElements() -> None:
        """Print all mesh element types, tags, node tags, and physical groups to stdout.

        Iterates over every entity in the model (all dimensions) and prints
        element types, element tags, node tags per element, and the physical
        groups they belong to. Intended for debugging purposes.
        """
        entities = gmsh_model.getEntities()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]

            # Get the mesh elements for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            print("elemTypes", elemTypes)
            print("elemTags", elemTags)
            print("elemNodeTags", elemNodeTags)
            print("phisicalGroup", gmsh_model.getPhysicalGroupsForEntity(dim, tag))

    @staticmethod
    def show() -> None:
        """Open the GMSH FLTK graphical interface to visualise the current model."""
        gmsh.fltk.run()

    @staticmethod
    def clear() -> None:
        """Clear all GMSH data and finalise the GMSH session.

        Calls ``gmsh.clear()`` to remove all models and then ``gmsh.finalize()``
        to shut down the library. The :class:`FEModel` instance should not be
        used after this call.
        """
        gmsh.clear()
        gmsh.finalize()

    @staticmethod
    def nodesTags() -> List[myInt64]:
        """Return a flat list of all mesh node tags in the model.

        Returns:
            A flat list of node tags across all entities and dimensions.
        """
        nt = []
        entities = gmsh_model.getEntities()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            # Get the mesh nodes for the entity (dim, tag):
            nodeTags, nodeCoords, nodeParams = gmsh.model.mesh.getNodes(dim, tag)
            nt += list(nodeTags)
        return nt

    @staticmethod
    def getElementsFromMacroTags(
        dimension: Dim,
        macroTags: List[myInt64] | None = None,
    ) -> Dict[myInt64, List[myInt64]] | List[myInt64]:
        """Resolve macro-element tags to their underlying mesh element tags.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            dimension: Spatial dimension of the elements to query.
            macroTags: If ``None`` or empty, return the full mapping dict
                ``{macro_tag: [mesh_tag, ...]}``.  If a non-empty list of
                macro-element tags, return a flat list of all their mesh tags.

        Returns:
            * Full dict ``{macro_tag: [mesh_tag, ...]}`` when *macroTags* is empty.
            * Flat list of mesh element tags for the specified macro-elements.

        Raises:
            EXAExceptions: If *macroTags* is not a list.
        """
        if (macroTags is not None) and (not isinstance(macroTags, list)):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0002",
                "First arg must be a string",
                type(macroTags),
            )

        if macroTags is None:
            macroTags = []

        ft: Dict[myInt64, List[myInt64]] = {}
        entities = gmsh_model.getEntities(dimension.value)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            # Get the mesh nodes for the entity (dim, tag).
            # gmsh.model.mesh.getElements returns one tag-array per element type
            # present on the entity (e.g. one for triangles and one for quads on
            # a mixed surface), so concatenate all of them — taking only
            # elemTags[0] silently dropped every type after the first.
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            ft[tag] = [t for et in elemTags for t in et]

        assert isinstance(macroTags, list)
        if len(macroTags) == 0:
            return ft
        else:
            tags = []
            for i in macroTags:
                tags += ft[i]
            return tags

    @staticmethod
    def getPlatesFromMacroTags(
        macroTags: List[myInt64] | None = None,
    ) -> Dict[myInt64, List[myInt64]] | List[myInt64]:
        """Retrieve mesh plate element tags from macro-element tags.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            macroTags: If ``None`` or empty, return a dict mapping every
                2D macro-element tag to its list of mesh plate tags.
                If a non-empty list, return a flat list of mesh plate tags
                for those macro-elements only.

        Returns:
            * Full dict ``{macro_tag: [mesh_tag, ...]}`` when *macroTags* is empty.
            * Flat list of mesh plate tags for the specified macro-elements.
        """
        return _FEMeshMixin.getElementsFromMacroTags(Dim.DIM_2D, macroTags)

    @staticmethod
    def getFramesFromMacroTags(
        macroTags: List[myInt64] | None = None,
    ) -> Dict[myInt64, List[myInt64]] | List[myInt64]:
        """Retrieve mesh frame element tags from macro-element tags.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            macroTags: If ``None`` or empty, return a dict mapping every
                1D macro-element tag to its list of mesh frame tags.
                If a non-empty list, return a flat list of mesh frame tags
                for those macro-elements only.

        Returns:
            * Full dict ``{macro_tag: [mesh_tag, ...]}`` when *macroTags* is empty.
            * Flat list of mesh frame tags for the specified macro-elements.
        """
        return _FEMeshMixin.getElementsFromMacroTags(Dim.DIM_1D, macroTags)

    @staticmethod
    def getNodesFromMacroTags(
        macroTags: List[myInt64] | None = None,
    ) -> Dict[myInt64, List[myInt64]] | List[myInt64]:
        """Retrieve mesh frame element tags from macro-element tags.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            macroTags: If ``None`` or empty, return a dict mapping every
                1D macro-element tag to its list of mesh frame tags.
                If a non-empty list, return a flat list of mesh frame tags
                for those macro-elements only.

        Returns:
            * Full dict ``{macro_tag: [mesh_tag, ...]}`` when *macroTags* is empty.
            * Flat list of mesh frame tags for the specified macro-elements.
        """
        return _FEMeshMixin.getElementsFromMacroTags(Dim.DIM_0D, macroTags)

    @staticmethod
    def getNodesPhysicalName() -> List[str]:
        """Return the names of all physical groups defined on 0D (point) entities.

        Returns:
            A list of physical group name strings for all 0D groups,
            preserving duplicates if multiple groups share the same name.
        """
        groups = gmsh_model.getPhysicalGroups(0)
        names = []
        for g in groups:
            names.append(gmsh_model.getPhysicalName(g[0], g[1]))
        return names

    @staticmethod
    def getPhisicalNames() -> List[str]:
        """
        Get unique physical names defined.
        If many groups exist with same name returns unique values

        Returns:
            List of unique group names
        """
        groups = gmsh_model.getPhysicalGroups()
        names = []
        for g in groups:
            names.append(gmsh_model.getPhysicalName(g[0], g[1]))
        return list(set(names))

    @staticmethod
    def getFramesPhysicalName() -> List[str]:
        """Return the names of all physical groups defined on 1D (curve) entities.

        Returns:
            A list of physical group name strings for all 1D groups,
            preserving duplicates if multiple groups share the same name.
        """
        groups = gmsh_model.getPhysicalGroups(1)
        names = []
        for g in groups:
            names.append(gmsh_model.getPhysicalName(g[0], g[1]))
        return names

    @staticmethod
    def getNodesByPhysicalName(name: str) -> List[int]:
        """Return the entity tags of 0D entities belonging to a named physical group.

        Args:
            name: Physical group name to search for.

        Returns:
            List of 0D entity (point) tags in the matching group,
            or an empty list if the name is not found.
        """
        groups = gmsh_model.getPhysicalGroups(0)
        for g in groups:
            if name == gmsh_model.getPhysicalName(g[0], g[1]):
                return list(gmsh_model.getEntitiesForPhysicalGroup(g[0], g[1]))
        return []

    @staticmethod
    def getNodesByPhysicalGroup(tagGroup: int) -> List[int]:
        """Return the entity tags of 0D entities belonging to a physical group by tag.

        Args:
            tagGroup: Physical group tag to search for.

        Returns:
            List of 0D entity (point) tags in the matching group,
            or an empty list if the tag is not found.
        """
        groups = gmsh_model.getPhysicalGroups(0)
        for g in groups:
            if g[1] == tagGroup:
                return list(gmsh_model.getEntitiesForPhysicalGroup(g[0], g[1]))
        return []

    @staticmethod
    def getMacroFramesByPhysicalName(name: str) -> List[myInt64]:
        """Return macro-element (curve entity) tags belonging to a named physical group.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            name: Physical group name to search for.

        Returns:
            List of 1D entity (curve) tags in the matching group,
            or an empty list if the name is not found.
        """
        groups = gmsh_model.getPhysicalGroups(1)
        for g in groups:
            if name == gmsh_model.getPhysicalName(g[0], g[1]):
                return list(gmsh_model.getEntitiesForPhysicalGroup(g[0], g[1]))
        return []

    @staticmethod
    def getFramesByPhysicalGroup(tagGroup: int) -> List[int]:
        """Return the entity tags of 1D entities belonging to a physical group by tag.

        Args:
            tagGroup: Physical group tag to search for.

        Returns:
            List of 1D entity (curve) tags in the matching group,
            or an empty list if the tag is not found.
        """
        groups = gmsh_model.getPhysicalGroups(1)
        for g in groups:
            if g[1] == tagGroup:
                return list(gmsh_model.getEntitiesForPhysicalGroup(g[0], g[1]))
        return []

    @staticmethod
    def renumberFramesByNodeCoords(
        macroTags: List[myInt64], dirRule: Literal["+X", "+Y", "+Z", "-X", "-Y", "-Z"]
    ) -> Tuple[Any, Any]:
        """Sort mesh frame tags by their midpoint coordinate along a given axis.

        Produces the old and new tag ordering needed by :meth:`renumberArrange`
        to physically renumber elements in GMSH.

        Args:
            macroTags: List of macro-element tags whose mesh frames are sorted.
            dirRule: Sorting axis and direction.  The sign (``+`` / ``-``)
                controls ascending or descending order; the letter selects the
                coordinate axis (``X``, ``Y``, or ``Z``).

        Returns:
            A 2-tuple ``(old_frame_tags, new_frame_tags)`` where both are
            lists of mesh frame tags — *old* in original GMSH order and *new*
            in the sorted order.
        """
        oldFrameTags = _FEMeshMixin.getFramesFromMacroTags(macroTags)
        oldNodesTags = _FEMeshMixin.getFrameNodesFromMacro(macroTags)

        idxCoord = ["X", "Y", "Z"].index(dirRule[1])
        oldMediumCoord = np.zeros(len(oldFrameTags), dtype=np.float64)
        assert isinstance(oldNodesTags, list)
        _nodePairs: List[Tuple[myInt64, myInt64]] = cast(List[Tuple[myInt64, myInt64]], oldNodesTags)

        for i, t in enumerate(_nodePairs):
            assert isinstance(t, tuple)
            assert len(t) == 2
            i_coord = _FEMeshMixin.nodeCoords(t[0])[idxCoord]
            j_coord = _FEMeshMixin.nodeCoords(t[1])[idxCoord]
            oldMediumCoord[i] = (
                i_coord + j_coord
            ) / 2

        oldTagCoords = zip(oldFrameTags, oldMediumCoord)

        rev = False
        if dirRule[0] == "-":
            rev = True

        oldTagCoordsSorted = sorted(oldTagCoords, key=lambda tc: tc[1], reverse=rev)

        newFrameTags = [0] * len(oldTagCoordsSorted)
        for i, tagCoord in enumerate(oldTagCoordsSorted):
            assert isinstance(i, int)
            newFrameTags[i] = int(tagCoord[0])

        return oldFrameTags, newFrameTags

    @staticmethod
    def renumberArrange(
        oldMacroTags: List[List[int]], newMacroTags: List[List[int]]
    ) -> None:
        """Apply an element renumbering to the GMSH mesh.

        Flattens *oldMacroTags* and *newMacroTags* into compact lists and
        calls ``gmsh.model.mesh.renumberElements`` to reassign element ids.

        Args:
            oldMacroTags: List of lists of current (old) mesh element tags,
                one inner list per macro-element group.
            newMacroTags: List of lists of desired (new) mesh element tags,
                in the same structure as *oldMacroTags*.
        """
        compactOldTags = oldMacroTags[0]
        for i in range(len(oldMacroTags) - 1):
            compactOldTags.extend(oldMacroTags[i + 1])

        compactNewTags = newMacroTags[0]
        for i in range(len(newMacroTags) - 1):
            compactNewTags.extend(newMacroTags[i + 1])

        gmsh.model.mesh.renumberElements(compactOldTags, compactNewTags)
