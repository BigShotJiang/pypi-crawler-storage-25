# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from enum import Enum, IntEnum
from typing import List

from pydantic import BaseModel, field_validator

from pycivil.EXAGeometry.shapes import ShapesEnum


class Dim(IntEnum):
    """Spatial dimension of a GMSH entity or mesh element."""

    DIM_0D = 0
    DIM_1D = 1
    DIM_2D = 2
    DIM_3D = 3


class Elem(IntEnum):
    """Mesh element type."""

    ELEM_POINT = 1
    ELEM_LINE = 2
    ELEM_TRIA = 3
    ELEM_QUAD = 4


class LoadType(str, Enum):
    """Category of load stored per load case."""

    FRAME_LOAD = "frameLoad"
    NODE_LOAD = "nodeLoad"
    PLATE_FACE_LOAD = "plateFaceLoad"
    SELF_WEIGHT = "selfWeight"


class NodalSpringsTp(str, Enum):
    """Behaviour type of a nodal spring support."""

    LINEAR = "LINEAR"  #: Linear (bilateral) spring.
    COMP = "COMP"      #: Compression-only spring.
    TENS = "TENS"      #: Tension-only spring.


class NodalSpringsDir(str, Enum):
    """Global direction of a nodal spring support."""

    DXP = "DX+"  #: Positive X direction.
    DXN = "DX-"  #: Negative X direction.
    DYP = "DY+"  #: Positive Y direction.
    DYN = "DY-"  #: Negative Y direction.
    DZP = "DZ+"  #: Positive Z direction.
    DZN = "DZ-"  #: Negative Z direction.


class SectionShape(BaseModel):
    """Base Pydantic model for a cross-section shape definition."""

    type: ShapesEnum
    param: List[float]
    name: str


class ShapeRect(SectionShape):
    """Rectangular cross-section shape.

    Attributes:
        param: ``[width, height]`` in model length units.
        name: Human-readable section name.
    """

    type: ShapesEnum = ShapesEnum.SHAPE_RECT
    param: List[float] = [0, 0]
    name: str = ""


class PlateFaceLoad(BaseModel):
    loadCase: str
    local: bool
    x: tuple[float, ...]
    y: tuple[float, ...]
    z: tuple[float, ...]

    @field_validator("x", "y", "z")
    @classmethod
    def must_have_length_3_or_4(cls, v: tuple[float, ...]) -> tuple[float, ...]:
        if len(v) not in (3, 4):
            raise ValueError(f"must have 3 or 4 elements, got {len(v)}")
        return v


class FEMaterial(BaseModel):
    """Material properties used by the FE model.

    Attributes:
        name: Human-readable material name.
        modulus: Young's modulus [MPa].
        poisson: Poisson's ratio [-].
        density: Mass density [kg/m³].
        thermal_expansion: Coefficient of thermal expansion [1/°C].
        conductivity: Thermal conductivity [kJ/s/m/°C].
        specific_heat: Specific heat capacity [kJ/kg/°C].
    """

    name: str = ""
    modulus: float = 0.0
    poisson: float = 0.0
    density: float = 0.0
    thermal_expansion: float = 0.0
    conductivity: float = 0.0
    specific_heat: float = 0.0


class PlateFaceSupport(BaseModel):
    """Winkler-type elastic foundation acting on a plate face.

    Attributes:
        k_normal: Normal (out-of-plane) subgrade stiffness [force/length³].
        k_lateral: Lateral (in-plane) subgrade stiffness [force/length³].
        compression_only: If ``True``, the support reacts only in compression.
        gap: Initial gap before the support activates [length units].
        local_3_direction: If ``True``, the normal direction is the plate
            local axis 3; otherwise the global Z axis is used.
    """

    k_normal: float
    k_lateral: float = 0.0
    compression_only: bool = False
    gap: float = 0.0
    local_3_direction: bool = True