### Elemento strutturale e classe di acciaio

| Descrizione | Valore |
|-------------|--------|
| Elemento strutturale | **{{ elementDescr }}** |
| Norma utilizzata | **{{ keyCode }}** |
| Classe di acciaio | **{{ steelClass }}** |

### Valori medi e caratteristici $[N/mm^2]$

| Caratteristica | Valore | Rif. |
|----------------|--------|------|
| Resistenza caratteristica a snervamento | $f_{yk}={{ value_fyk }}$ | Tab. 11.3.1a/b |
| Resistenza caratteristica a rottura | $f_{tk}={{ value_ftk }}$ | Tab. 11.3.1a/b |
| Modulo elastico | $E_s={{ value_Es }}$ | C4.1.2.2.5 |

### Valori di progetto $[N/mm^2]$

| Caratteristica | Valore | Rif. |
|----------------|--------|------|
| Coefficiente di sicurezza SLU | $\gamma_{s}={{ value_gammas }}$ | 4.1.2.1.1.3 |
| Resistenza a trazione di progetto | $f_{yd}=\frac{f_{yk}}{\gamma_{s}}={{ value_fyd }}$ | [4.1.5] |
| Limite di tensione in combinazione rara | $\sigma_{s,max}^{car}=0.80 \cdot f_{yk} = {{ value_sigmaCar }}$ | [4.1.17] |
