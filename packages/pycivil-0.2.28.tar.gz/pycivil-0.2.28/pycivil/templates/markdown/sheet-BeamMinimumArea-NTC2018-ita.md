### Dati generali

| Descrizione | Valore |
|-------------|--------|
| Elemento strutturale | **{{ elementDescr }}** |
| Norma utilizzata per il materiale | **{{ keyCode }}** |

### Caratteristiche dei materiali

| Descrizione | Valore | u.d.m. |
|-------------|--------|--------|
| Classe del calcestruzzo | **{{ concreteClass }}** | ... |
| Resistenza cilindrica a compressione | $f_{ck}={{ cls_fck }}$ | $N/mm^2$ |
| Resistenza media a trazione | $f_{ctm}={{ cls_fctm }}$ | $N/mm^2$ |
| Classe di acciaio | **{{ steelClass }}** | ... |
| Resistenza caratteristica a snervamento | $f_{yk}={{ steel_fyk }}$ | $N/mm^2$ |

### Dati geometrici della sezione

| Descrizione | Valore | u.d.m. |
|-------------|--------|--------|
| Altezza dell'elemento | $H={{ hEl }}$ | $mm$ |
| Larghezza dell'elemento | $W={{ wEl }}$ | $mm$ |
| Larghezza media dell'elemento in zona tesa | $b_{t,med}={{ bt }}$ | $mm$ |
| Diametro barre longitudinali | $\phi_{lt} = {{ rebarD }}$ | $mm$ |
| Copriferro barre longitudinali | $c = {{ cover }}$ | $mm$ |
| Larghezza minima dell'elemento a taglio | $b_{t,min}={{ bMin }}$ | $mm$ |
| Diametro barre longitudinali compresse | $\phi_{lc} = {{ rebarDComp }}$ | $mm$ |
| Diametro staffe o spilli | $\phi_{st}={{ stirrupD }}$ | $mm$ |
| Numero di bracci trasversali assegnato | $n_{b,t}={{ nbLegDirX }}$ | ... |

### Armatura a flessione minima

| Descrizione | Valore | u.d.m. | Rif. |
|-------------|--------|--------|------|
| Altezza utile | $d=H-c-\frac{\phi_{lt}}{2}={{ heightUtil }}$ | $mm$ | |
| Area utile | $A_u=b_{t,med} \cdot d=1000 \cdot d = {{ areaUtil }}$ | $mm^2$ | |
| Area minima criterio (1) | $A_{min}^{(1)}=0.26 \cdot \frac {f_{ctm}} {f_{yk}}\cdot A_u = {{ minimumRebarAreaCrit1 }}$ | $mm^2$ | [4.1.45] |
| Area minima criterio (2) | $A_{min}^{(2)}=0.0013 \cdot A_u= {{ minimumRebarAreaCrit2 }}$ | $mm^2$ | 4.1.6.1.1 |
| Area minima | $A_{min}=max(A_{min}^{(1)},A_{min}^{(2)})={{ minimumRebarArea }}$ | $mm^2$ | |
| Area di acciaio disposta in zona corrente | $A_{disp}={{ rebarAreaDisposed }}$ | $mm^2$ | |
| Numero di barre disposte in zona corrente | $n_{disp}={{ rebarNumber }}$ | ... | |

### Armatura a taglio minima (spilli o staffe)

| Descrizione | Valore | u.d.m. | Rif. |
|-------------|--------|--------|------|
| Area minima per metro di elemento | $\frac{A_{sw,min}}{s} = 1.5 \cdot b_{t,min}={{ minimumRebarAreaForElementLenght }}$ | $mm^2/m$ | 4.1.6.1.1 |
| Numero di bracci totale con diametro assegnato | $n_{b}={{ minimumLegsForElementLenght }}$ | ... | |
| Passo massimo per disporre area minima (1) | $s_{max}^{(1)}=\frac{n_{b,t}}{n_{b}}\cdot 1000={{ maxStepCrit1 }}$ | $mm$ | |
| Passo massimo con altezza utile (2) | $s_{max}^{(2)}=0.8 \cdot d ={{ maxStepCrit3 }}$ | $mm$ | 4.1.6.1.1 |
| Passo massimo assoluto di tre staffe al metro (3) | $s_{max}^{(3)} = {{ maxStepCrit2 }}$ | $mm$ | 4.1.6.1.1 |
| Passo massimo con barre compresse (4) | $s_{max}^{(4)}=15 \cdot \phi_{lc} = {{ maxStepCrit4 }}$ | $mm$ | 4.1.6.1.1 |
| Passo massimo in generale | $s_{max}=min(s_{max}^{(1)},s_{max}^{(2)},s_{max}^{(3)})={{ stirrupStepMin }}$ | $mm$ | |
| Passo massimo con barre compresse | $s_{max}=min(s_{max}^{(1)},s_{max}^{(4)})={{ stirrupCompStepMin }}$ | $mm$ | |
