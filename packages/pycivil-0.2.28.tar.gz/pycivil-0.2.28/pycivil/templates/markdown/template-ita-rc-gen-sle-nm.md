<!-- SLE Verification Table for Generic RC Sections -->

### Verifiche SLE

| **id** | $N_{ed}$ | $M_{xed}$ | $M_{yed}$ | $\sigma_s$ | $\sigma_c$ | **FS** | **check** |
|--------|----------|-----------|-----------|------------|------------|--------|-----------|
|        | *[KN]*   | *[KNm]*   | *[KNm]*   | $\overline{\sigma}_s$ | $\overline{\sigma}_c$ | | |
|        |          |           |           | *[N/mm²]*  | *[N/mm²]*  |        |           |
{% for c in check_SLE_MN %}
| {{ c.id }} | {{ c.Ned }} | {{ c.Mxed }} | {{ c.Myed }} | {{ c.sigmas }} | {{ c.sigmac }} | {{ c.FS }} | {{ c.check }} |
|            |             |              |              | {{ c.sigmaxs }} | {{ c.sigmaxc }} |            |               |
{% endfor %}

{% for f in figures %}
### Tensioni agli SLE - Parte {{ f.figIndex }} di {{ nbFigs }}

{% for url in f.domainUrls %}
![Tensioni per carico con id = {{ url.idLoad }}]({{ url.domainUrl }}){width={{ figuresWidth }}}
{% endfor %}
{% endfor %}
