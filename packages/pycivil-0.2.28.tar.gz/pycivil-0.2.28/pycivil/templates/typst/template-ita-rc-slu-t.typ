#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto, auto, auto, auto, auto),
    align: (center, right, right, right, right, right, right, right, right, right, center),
    table.header(
      [*id*], [$bold(T_(e d))$ \ _\[KN\]_], [$bold(T_(r d))$ \ _\[KN\]_], [$bold(T_(r c d))$ \ _\[KN\]_], [$bold(T_(r s d))$ \ _\[KN\]_], [$bold(cot theta)$ \ _\[...\]_], [$bold(A_(s w))$ \ _\[mm²\]_], [$bold("step")$ \ _\[mm\]_], [$bold(sigma_(c p))$ \ _\[N/mm²\]_], [$bold(F S)$], [$bold("check")$],
    ),
    <%% for c in check_SLU_T %%>
    [<< c.id >>], [<< c.Ted >>], [<< c.Trd >>], [<< c.Trcd >>], [<< c.Trsd >>], [<< c.cotgtheta >>], [<< c.Asw >>], [<< c.step >>], [<< c.sigmacp >>], [<< c.FS >>], [<< c.check >>],
    <%% endfor %%>
  ),
  caption: [Verifiche SLU a Taglio],
)
