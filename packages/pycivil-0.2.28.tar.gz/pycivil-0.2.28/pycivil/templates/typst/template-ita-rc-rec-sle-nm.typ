#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto, auto),
    align: (center, right, right, right, right, right, right, center),
    table.header(
      table.cell(rowspan: 3)[*id*],
      table.cell(rowspan: 2)[$bold(N_(e d))$],
      table.cell(rowspan: 2)[$bold(M_(e d))$],
      [$bold(sigma_s)$], [$bold(sigma_c)$],
      table.cell(rowspan: 3)[$bold(x_i)$ \ _\[mm\]_],
      table.cell(rowspan: 3)[$bold(F S)$],
      table.cell(rowspan: 3)[$bold("check")$],
      [$bold(overline(sigma)_s)$], [$bold(overline(sigma)_c)$],
      [_\[KN\]_], [_\[KNm\]_], [_\[N/mm²\]_], [_\[N/mm²\]_],
    ),
    <%% for c in check_SLE_MN %%>
    table.cell(rowspan: 2)[<< c.id >>],
    table.cell(rowspan: 2)[<< c.Ned >>],
    table.cell(rowspan: 2)[<< c.Med >>],
    [<< c.sigmas >>], [<< c.sigmac >>],
    table.cell(rowspan: 2)[<< c.xi >>],
    table.cell(rowspan: 2)[<< c.FS >>],
    table.cell(rowspan: 2)[<< c.check >>],
    [<< c.sigmxs >>], [<< c.sigmxc >>],
    <%% endfor %%>
  ),
  caption: [Verifiche SLE],
)
