// Engineering Calculation Document
// Typst Template converted from LaTeX
// Original: http://www.LaTeXTemplates.com
// License: CC BY-NC-SA 3.0

#set page(paper: "a4", margin: (left: 1.3cm, right: 3.6cm, top: 4.8cm, bottom: 4.0cm))
#set text(font: "New Computer Modern", size: 11pt, lang: "it")
#set par(leading: 0.65em, first-line-indent: 0pt)
#set heading(numbering: "1.")

#show figure.where(kind: table): set block(breakable: true)

#set page(header: [
  #v(1.0cm)
  #set text(size: 9pt)
  #grid(
    columns: (1fr, auto),
    column-gutter: 8pt,
    align: (left, right + horizon),
    [#table(
      columns: (auto, 1.5fr, auto, 0.7fr),
      column-gutter: 2pt,
      row-gutter: 1pt,
      stroke: none,
      [*Project*], [<< project_brief >>], [*Page*], [#context{let cur = counter(page).get().first(); let tot = counter(page).final().first(); [#cur / #tot]}],
      [*Module*], [<< module_name >>], [*Date*], [<< report_date >>],
      [*Version*], [<< module_version >>], [*Time*], [<< report_time >>],
      [*Designer*], [<< report_designer >>], [*Token*], [<< report_token >>],
    )],
    <%% if has_logo %%>
    [#image("<< logo_path >>", height: 16mm)],
    <%% else %%>
    [],
    <%% endif %%>
  )
  #line(length: 100%)
])

<< place_holder >>
