# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from pathlib import Path

from pycivil.EXAStructural.loads import (
    ForcesOnSection,
)
from pycivil.EXAStructural.loads import Frequency_Enum as Fr
from pycivil.EXAStructural.loads import LimiteState_Enum as Ls
from pycivil.EXAUtils.report import (
    ReportTemplateEnum,
    TypstReporter,
    getTypstTemplatesPath,
)
from pycivil.EXAUtils.typstReportMakers import ForcesOnSectionListTypstFB


def test_report_typst_loads(tmp_path: Path):
    """Test forces on section list typst fragment generation."""
    typstTemplatePath = getTypstTemplatesPath()
    fragmentBuilder = ForcesOnSectionListTypstFB(typstTemplatePath)
    listOfForces = fragmentBuilder.forces()

    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 101,
            Fy=1e3 * 201,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f1",
            id=1,
            limitState=Ls.ULTIMATE,
            frequency=Fr.FREQUENCY_ND,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 102,
            Fy=1e3 * 202,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f2",
            id=2,
            limitState=Ls.ULTIMATE,
            frequency=Fr.FREQUENCY_ND,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 103,
            Fy=1e3 * 203,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f3",
            id=3,
            limitState=Ls.SERVICEABILITY,
            frequency=Fr.CHARACTERISTIC,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 104,
            Fy=1e3 * 204,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f4",
            id=4,
            limitState=Ls.SERVICEABILITY,
            frequency=Fr.FREQUENT,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 105,
            Fy=1e3 * 205,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f5",
            id=5,
            limitState=Ls.SERVICEABILITY,
            frequency=Fr.QUASI_PERMANENT,
        )
    )

    f1 = fragmentBuilder.buildFragment()

    print(f1.frags())

    reporter = TypstReporter(typstTemplatePath)
    reporter.linkFragments(template=ReportTemplateEnum.TYP_ENG_CAL, fragments=[f1])
    reporter.compileDocument(path=str(tmp_path), output_format="pdf")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.typ").exists()
    assert tmp_path.joinpath("report.pdf").exists()
    assert tmp_path.joinpath("report.pdf").stat().st_size > 0

    # Verify content has load data
    content = tmp_path.joinpath("report.typ").read_text(encoding="utf-8")
    assert "f1" in content or "101" in content
