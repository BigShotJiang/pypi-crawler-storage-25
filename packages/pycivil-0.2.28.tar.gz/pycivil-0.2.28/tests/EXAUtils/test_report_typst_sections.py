# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

import json
from pathlib import Path

from pycivil.EXAStructural.rcrecsolver.srvRcSecCheck import ModelInputRcSecCheck
from pycivil.EXAStructural.templateRCRect import SectionPlot
from pycivil.EXAUtils.report import (
    ReportTemplateEnum,
    TypstReporter,
    getTypstTemplatesPath,
)
from pycivil.EXAUtils.typstReportMakers import ConcreteSectionTypstFB


def _create_section_png(iData: ModelInputRcSecCheck, path: Path) -> None:
    """Create section plot PNG for Typst templates."""
    section = iData.buildRcsRectangular()
    if section is not None:
        plotter = SectionPlot(section)
        plotter.plot()
        plotter.save(path / "section.png")


def test_report_typst_section_01(tmp_path: Path):
    """Test RC section typst fragment generation with first test data."""
    with open(Path(__file__).parent / "test_report_latex_sections_01.json") as jsonFile:
        jsonObject = json.load(jsonFile)

    iData = ModelInputRcSecCheck(**jsonObject)

    section = iData.buildRcsRectangular()
    if section is not None:
        # Create section PNG for the template
        _create_section_png(iData, tmp_path)

        typstTemplatePath = getTypstTemplatesPath()
        f = ConcreteSectionTypstFB(typstTemplatePath, rcs=section).buildFragment()
        print(f.frags())
        reporter = TypstReporter(typstTemplatePath)
        reporter.linkFragments(template=ReportTemplateEnum.TYP_ENG_CAL, fragments=[f])
        reporter.compileDocument(path=str(tmp_path), output_format="typ")
        print(f"Temporary path for test is {tmp_path}")
        assert tmp_path.joinpath("report.typ").exists()

        # Verify content has section data
        content = tmp_path.joinpath("report.typ").read_text(encoding="utf-8")
        assert "400" in content  # width or height

        # Compile to PDF
        reporter.compileDocument(path=str(tmp_path), output_format="pdf")
        assert tmp_path.joinpath("report.pdf").exists()
        assert tmp_path.joinpath("report.pdf").stat().st_size > 0


def test_report_typst_section_02(tmp_path: Path):
    """Test RC section typst fragment generation with second test data."""
    with open(Path(__file__).parent / "test_report_latex_sections_02.json") as jsonFile:
        jsonObject = json.load(jsonFile)

    iData = ModelInputRcSecCheck(**jsonObject)

    section = iData.buildRcsRectangular()
    if section is not None:
        # Create section PNG for the template
        _create_section_png(iData, tmp_path)

        typstTemplatePath = getTypstTemplatesPath()
        f = ConcreteSectionTypstFB(typstTemplatePath, rcs=section).buildFragment()
        print(f.frags())
        reporter = TypstReporter(typstTemplatePath)
        reporter.linkFragments(template=ReportTemplateEnum.TYP_ENG_CAL, fragments=[f])
        reporter.compileDocument(path=str(tmp_path), output_format="pdf")
        print(f"Temporary path for test is {tmp_path}")
        assert tmp_path.joinpath("report.typ").exists()
        assert tmp_path.joinpath("report.pdf").exists()
        assert tmp_path.joinpath("report.pdf").stat().st_size > 0
