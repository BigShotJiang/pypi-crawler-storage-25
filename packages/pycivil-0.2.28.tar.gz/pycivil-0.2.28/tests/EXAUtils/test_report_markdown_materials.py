# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from pathlib import Path

from pycivil.EXAStructural.codes import Code
from pycivil.EXAStructural.materials import Concrete, ConcreteSteel
from pycivil.EXAUtils.markdownReportMakers import ConcreteMdFB, SteelConcreteMdFB
from pycivil.EXAUtils.report import (
    EnumFBSection,
    MarkdownReporter,
    ReportTemplateEnum,
    getMarkdownTemplatesPath,
)


def test_report_markdown_concrete_0001(tmp_path: Path):
    """Test concrete material markdown fragment generation."""
    code = Code("NTC2018")

    concrete = Concrete()
    concrete.setByCode(codeObj=code, catstr="C25/30")

    markdownTemplatePath = getMarkdownTemplatesPath()
    fragmentBuilder = ConcreteMdFB(markdownTemplatePath, concrete)

    fragmentBuilder.setFragmentOptions({"glossary": False})

    f = fragmentBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f], glossary=False
    )
    reporter.compileDocument(path=str(tmp_path), output_format="md")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()

    # Verify content has concrete data
    content = tmp_path.joinpath("report.md").read_text(encoding="utf-8")
    assert "C25/30" in content or "25.0" in content


def test_report_markdown_concrete_0002(tmp_path: Path):
    """Test concrete material with HTML output."""
    code = Code("NTC2018")

    concrete = Concrete()
    concrete.setByCode(codeObj=code, catstr="C35/45")

    markdownTemplatePath = getMarkdownTemplatesPath()
    fragmentBuilder = ConcreteMdFB(markdownTemplatePath, concrete)

    f = fragmentBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f])
    reporter.compileDocument(path=str(tmp_path), output_format="html")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()
    assert tmp_path.joinpath("report.html").exists()


def test_report_markdown_steel_0001(tmp_path: Path):
    """Test steel material markdown fragment generation."""
    code = Code("NTC2018")

    steel = ConcreteSteel()
    steel.setByCode(code, "B450A")

    markdownTemplatePath = getMarkdownTemplatesPath()

    fragmentBuilder = SteelConcreteMdFB(markdownTemplatePath, steel)

    fragmentBuilder.setFragmentOptions(
        {"section_title": "Acciaio B450A", "section_level": EnumFBSection.SEC_SECTION}
    )
    f1 = fragmentBuilder.buildFragment()

    steel.setByCode(code, "B450C")
    fragmentBuilder = SteelConcreteMdFB(markdownTemplatePath, steel)

    fragmentBuilder.setFragmentOptions(
        {"section_title": "Acciaio B450C", "section_level": EnumFBSection.SEC_SECTION}
    )

    # Here unsetted by code, the builder strip code used and kind of sensitivity
    steel.set_gammas(1.0)
    f2 = fragmentBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f1, f2])
    reporter.compileDocument(path=str(tmp_path), output_format="md")

    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()

    # Verify content has steel data
    content = tmp_path.joinpath("report.md").read_text(encoding="utf-8")
    assert "B450" in content or "450" in content


def test_report_markdown_combined_materials(tmp_path: Path):
    """Test combined concrete and steel materials in one report."""
    code = Code("NTC2018")

    # Concrete
    concrete = Concrete()
    concrete.setByCode(codeObj=code, catstr="C25/30")
    markdownTemplatePath = getMarkdownTemplatesPath()
    concreteFB = ConcreteMdFB(markdownTemplatePath, concrete)
    concreteFB.setFragmentOptions({"section_title": "Calcestruzzo C25/30"})
    f1 = concreteFB.buildFragment()

    # Steel
    steel = ConcreteSteel()
    steel.setByCode(code, "B450C")
    steelFB = SteelConcreteMdFB(markdownTemplatePath, steel)
    steelFB.setFragmentOptions({"section_title": "Acciaio B450C"})
    f2 = steelFB.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f1, f2])
    reporter.compileDocument(path=str(tmp_path), output_format="md")

    assert tmp_path.joinpath("report.md").exists()
    content = tmp_path.joinpath("report.md").read_text(encoding="utf-8")
    assert "C25/30" in content or "25.0" in content
    assert "B450" in content or "450" in content
