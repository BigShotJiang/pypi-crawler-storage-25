# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

"""Bundle round-trip tests for fe_persist_v1.

Each ``test_*_bundle`` mirrors the model-building setup of the corresponding
test in ``test_fe.py``, then asserts that ``save_bundle`` + ``load_bundle``
preserves all FEModel state plus the gmsh-side mesh/occ entity counts.
"""

import json
import zipfile
from pathlib import Path

import gmsh
import pytest

from pycivil.EXAGeometry.geometry import Point2d, Point3d, Vector3d
from pycivil.EXAStructuralModel.fe import Elem, FEModel
from pycivil.EXAStructuralModel.fe_persist_v1 import (
    BUNDLE_SUFFIX,
    SCHEMA_VERSION,
    _build_state,
    load_bundle,
    save_bundle,
)


def _reset_gmsh() -> None:
    """Tear down the active gmsh session between save and load."""
    try:
        gmsh.finalize()
    except Exception:
        pass


def _gmsh_snapshot() -> tuple[int, int]:
    """Return ``(num_mesh_nodes, num_occ_entities)`` for the active gmsh model."""
    try:
        n_nodes = len(gmsh.model.mesh.getNodes()[0])
    except Exception:
        n_nodes = 0
    try:
        n_occ = len(gmsh.model.occ.getEntities())
    except Exception:
        n_occ = 0
    return n_nodes, n_occ


def assert_bundle_round_trip(orig: FEModel, tmp_path: Path) -> FEModel:
    """Save, finalise gmsh, reload, and assert state + gmsh counts match."""
    state_orig = _build_state(orig).model_dump()
    snap_orig = _gmsh_snapshot()

    out = save_bundle(orig, tmp_path / "bundle")
    _reset_gmsh()

    loaded = load_bundle(out)

    state_loaded = _build_state(loaded).model_dump()
    assert state_loaded == state_orig

    snap_loaded = _gmsh_snapshot()
    assert snap_loaded == snap_orig

    _reset_gmsh()
    return loaded


# --- generic bundle assertions (independent of test_fe.py scenarios) ---


def test_save_bundle_appends_v1_suffix(tmp_path: Path) -> None:
    m = FEModel(descr="suffix", modelName="suffix")
    out = save_bundle(m, tmp_path / "myModel")
    assert out.name.endswith(BUNDLE_SUFFIX)
    assert out.exists()
    _reset_gmsh()


def test_load_bundle_rejects_unknown_schema(tmp_path: Path) -> None:
    bad_path = tmp_path / "bad_v1.zip"
    with zipfile.ZipFile(bad_path, "w") as zf:
        zf.writestr(
            "manifest.json",
            json.dumps(
                {
                    "schema_version": SCHEMA_VERSION + 99,
                    "gmsh_version": "x",
                    "created_at": "x",
                    "model_name": "x",
                    "has_geometry": False,
                    "has_mesh": False,
                }
            ),
        )
        zf.writestr("state.json", "{}")

    with pytest.raises(ValueError, match="schema version"):
        load_bundle(bad_path)


# --- one bundle test per scenario in test_fe.py ---


def test_fe_1d_elements_001_bundle(tmp_path: Path) -> None:
    am = FEModel(descr="bundle_1d_elements_001", modelName="bundle_1d_elements_001")
    n3 = am.addNode(x=0.0, y=0.0, z=5.0, tag=3, group=True, tagGroup=13)
    n5 = am.addNode(x=5.0, y=0.0, z=5.0, tag=5, group=True, tagGroup=15)
    n7 = am.addNode(x=10.0, y=0.0, z=5.0, tag=7, group=True, tagGroup=17)
    am.addFrame(tagStart=n5, tagEnd=n7, tag=20, group=True, tagGroup=21, nb=1)
    am.addFrame(tagStart=n3, tagEnd=n5, tag=10, group=True, tagGroup=11, nb=1)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_elements_quad_001_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_quad_001")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=0.3)
    n2 = am.addNode(x=5.0, y=0.0, z=0.0, meshSize=0.3)
    n3 = am.addNode(x=5.0, y=5.0, z=0.0, meshSize=0.3)
    n4 = am.addNode(x=0.0, y=5.0, z=0.0, meshSize=0.3)
    n11 = am.addNode(x=1.0, y=1.0, z=0.0, meshSize=0.3)
    n12 = am.addNode(x=4.0, y=1.0, z=0.0, meshSize=0.3)
    n13 = am.addNode(x=4.0, y=4.0, z=0.0, meshSize=0.3)
    n14 = am.addNode(x=1.0, y=4.0, z=0.0, meshSize=0.3)
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=7, transfiniteCurve=False)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=7, transfiniteCurve=False)
    f3 = am.addFrame(tagStart=n3, tagEnd=n4, nb=7, transfiniteCurve=False)
    f4 = am.addFrame(tagStart=n4, tagEnd=n1, nb=7, transfiniteCurve=False)
    pq1 = am.addPlate(f1, f2, f3, f4, transfiniteSurface=False)
    am.addNodesToPlate([n11, n12, n13, n14], pq1)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_elements_tria_001_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_tria_001")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=0.3)
    n2 = am.addNode(x=5.0, y=0.0, z=0.0, meshSize=0.3)
    n3 = am.addNode(x=5.0, y=5.0, z=0.0, meshSize=0.3)
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=7, transfiniteCurve=False)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=7, transfiniteCurve=False)
    f3 = am.addFrame(tagStart=n3, tagEnd=n1, nb=7, transfiniteCurve=False)
    am.addPlate(f1, f2, f3, transfiniteSurface=False)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_single_quad_element_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_single_quad")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0)
    n3 = am.addNode(x=1.0, y=1.0, z=0.0)
    n4 = am.addNode(x=0.0, y=1.0, z=0.0)
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=1, transfiniteCurve=True)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=1, transfiniteCurve=True)
    f3 = am.addFrame(tagStart=n3, tagEnd=n4, nb=1, transfiniteCurve=True)
    f4 = am.addFrame(tagStart=n4, tagEnd=n1, nb=1, transfiniteCurve=True)
    am.addPlate(f1, f2, f3, f4, transfiniteSurface=True, elType=Elem.ELEM_QUAD)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_single_tria_element_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_single_tria")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0)
    n3 = am.addNode(x=0.0, y=1.0, z=0.0)
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=1, transfiniteCurve=True)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=1, transfiniteCurve=True)
    f3 = am.addFrame(tagStart=n3, tagEnd=n1, nb=1, transfiniteCurve=True)
    am.addPlate(f1, f2, f3, transfiniteSurface=True, elType=Elem.ELEM_TRIA)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_nodes_quad_elements_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_nodes_quad")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=0.3)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0, meshSize=0.3)
    n3 = am.addNode(x=1.0, y=1.0, z=0.0, meshSize=0.3)
    n4 = am.addNode(x=0.0, y=1.0, z=0.0, meshSize=0.3)
    am.addPlate(nodes=[n1, n2, n3, n4], transfiniteSurface=False, elType=Elem.ELEM_QUAD)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_nodes_tria_elements_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_nodes_tria")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=0.3)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0, meshSize=0.3)
    n3 = am.addNode(x=0.0, y=1.0, z=0.0, meshSize=0.3)
    am.addPlate(nodes=[n1, n2, n3], transfiniteSurface=False, elType=Elem.ELEM_TRIA)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_nodes_single_quad_element_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_nodes_single_quad")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0)
    n3 = am.addNode(x=1.0, y=1.0, z=0.0)
    n4 = am.addNode(x=0.0, y=1.0, z=0.0)
    am.addPlate(nodes=[n1, n2, n3, n4], nb=1)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_nodes_single_tria_element_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_nodes_single_tria")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0)
    n3 = am.addNode(x=0.0, y=1.0, z=0.0)
    am.addPlate(nodes=[n1, n2, n3], nb=1, elType=Elem.ELEM_TRIA)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_1d_local_axis_001_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_local_axis_001")
    n_i = am.addNode(x=0.0, y=0.0, z=0.0)
    n_j = am.addNode(x=0.0, y=0.0, z=1.0)
    am.addFrame(n_i, n_j, nb=10)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_1d_local_axis_002_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_local_axis_002")
    n_i = am.addNode(x=0.0, y=0.0, z=0.0)
    n_j = am.addNode(x=0.0, y=1.0, z=1.0)
    am.addFrame(n_i, n_j, nb=10)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_1d_local_axis_003_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_local_axis_003")
    n_i = am.addNode(x=0.0, y=0.0, z=0.0)
    n_j = am.addNode(x=1.0, y=1.0, z=0.0)
    f = am.addFrame(n_i, n_j, nb=10)
    am.assignMultiFrameLocal2(axis=Vector3d(1.0, -1.0, 0.0), tagsMacro=[f])
    am.assignMultiFrameLocal2(axis=Vector3d(-1.0, 1.0, 0.0), tagsMacro=[f])
    # final state has the second axis assigned
    assert_bundle_round_trip(am, tmp_path)


def test_fe_1d_local_axis_004_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_local_axis_004")
    n_i = am.addNode(x=0.0, y=0.0, z=0.0)
    n_j = am.addNode(x=10.0, y=10.0, z=10.0)
    f = am.addFrame(n_i, n_j, nb=10)
    am.assignMultiFrameLocal2(axis=Vector3d(10.0, 0.0, 0.0), tagsMacro=[f])
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_elements_plate_tags_001_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_plate_tags_001")
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=5)
    n2 = am.addNode(x=5.0, y=0.0, z=0.0, meshSize=5)
    n3 = am.addNode(x=5.0, y=5.0, z=0.0, meshSize=5)
    n4 = am.addNode(x=0.0, y=5.0, z=0.0, meshSize=5)
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=2, transfiniteCurve=False)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=2, transfiniteCurve=False)
    f3 = am.addFrame(tagStart=n3, tagEnd=n4, nb=2, transfiniteCurve=False)
    f4 = am.addFrame(tagStart=n4, tagEnd=n1, nb=2, transfiniteCurve=False)
    am.addPlate(f1, f2, f3, f4, transfiniteSurface=True)
    assert_bundle_round_trip(am, tmp_path)


def _build_three_point_beam_load_model(name: str, swap_frame_order: bool) -> FEModel:
    am = FEModel(modelName=name)
    p1 = Point3d(x=0.0, y=0.0, z=0.0)
    p2 = Point3d(x=10.0, y=0.0, z=0.0)
    p3 = Point3d(x=20.0, y=0.0, z=0.0)
    n1 = am.addNode(point=p1)
    n2 = am.addNode(point=p2)
    n3 = am.addNode(point=p3)
    if swap_frame_order:
        f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=10)
        f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=10)
    else:
        f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=10)
        f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=10)
    am.addLoadCase("DL", "U", "user load case")
    am.addMacroFrameLoadLine(
        loadCase="DL",
        tagsMacro=[f1, f2],
        tp="force",
        direction="X",
        load_value_1=[0.1, 10.0],
        load_value_2=[0.9, 26.0],
        load_position_absolute=False,
    )
    return am


def test_fe_1d_elements_line_load_001_bundle(tmp_path: Path) -> None:
    am = _build_three_point_beam_load_model("bundle_line_load_001", swap_frame_order=True)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_1d_elements_line_load_002_bundle(tmp_path: Path) -> None:
    am = _build_three_point_beam_load_model("bundle_line_load_002", swap_frame_order=False)
    assert_bundle_round_trip(am, tmp_path)


def test_fe_1d_elements_line_load_003_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_line_load_003")
    p1 = Point2d(x=0.0, y=0.0)
    p2 = Point2d(x=10.0, y=0.0)
    p3 = Point2d(x=20.0, y=0.0)
    p1.rotate(45.0, Point2d(0.0, 0.0))
    p2.rotate(45.0, Point2d(0.0, 0.0))
    p3.rotate(45.0, Point2d(0.0, 0.0))
    n1 = am.addNode(point=Point3d().fromPoint2d(p1))
    n2 = am.addNode(point=Point3d().fromPoint2d(p2))
    n3 = am.addNode(point=Point3d().fromPoint2d(p3))
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=10)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=10)
    am.addLoadCase("DL", "U", "user load case")
    am.addMacroFrameLoadLine(
        loadCase="DL",
        tagsMacro=[f1, f2],
        tp="force",
        direction="X",
        load_value_1=[0.1, 10.0],
        load_value_2=[0.9, 26.0],
        load_position_absolute=False,
    )
    assert_bundle_round_trip(am, tmp_path)


def test_fe_2d_elements_quad_002_bundle(tmp_path: Path) -> None:
    am = FEModel(modelName="bundle_2d_quad_002")
    ne1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=1.0)
    ne2 = am.addNode(x=5.0, y=0.0, z=0.0, meshSize=1.0)
    ne3 = am.addNode(x=5.0, y=5.0, z=0.0, meshSize=1.0)
    ne4 = am.addNode(x=0.0, y=5.0, z=0.0, meshSize=1.0)
    ni1 = am.addNode(x=1.0, y=1.0, z=0.0, meshSize=1.0)
    ni2 = am.addNode(x=4.0, y=1.0, z=0.0, meshSize=1.0)
    ni3 = am.addNode(x=4.0, y=4.0, z=0.0, meshSize=1.0)
    ni4 = am.addNode(x=1.0, y=4.0, z=0.0, meshSize=1.0)
    am.addPlate(nodes=[ne1, ne2, ni2, ni1])
    am.addPlate(nodes=[ne2, ne3, ni3, ni2])
    am.addPlate(nodes=[ne3, ne4, ni4, ni3])
    am.addPlate(nodes=[ne4, ne1, ni1, ni4])
    assert_bundle_round_trip(am, tmp_path)