import math

import pytest
from pycivil.EXAGeometry.geometry import Point2d, Point3d, Vector3d
from pycivil.EXAStructuralModel.fe import FEModel, LoadType, Elem


# Test that show difference between model and mesh assigning relative tags
# The way to force mesh recognition elements with tags is assign a physical
# group during creation of 0d and 1d element
def test_fe_1d_elements_001():
    # It builds an analytical model
    #
    am = FEModel(descr=f"Model for {__name__}", modelName=__name__)

    # Only one model created currently by constructor ...
    #
    assert len(am.getModels()) == 1

    # ... named as passed in modelName ard during init
    #
    assert am.getModels()[0] == __name__

    # I build 3 nodes, forcing tag to specific values to 3, 5, 7
    #
    node_3 = am.addNode(x=0.0, y=0.0, z=5.0, tag=3, group=True, tagGroup=13)
    assert node_3 == 3
    node_3_pg = am.getNodesByPhysicalGroup(13)
    assert node_3_pg[0] == 3

    node_5 = am.addNode(x=5.0, y=0.0, z=5.0, tag=5, group=True, tagGroup=15)
    assert node_5 == 5
    node_5_pg = am.getNodesByPhysicalGroup(15)
    assert node_5_pg[0] == 5

    node_7 = am.addNode(x=10.0, y=0.0, z=5.0, tag=7, group=True, tagGroup=17)
    assert node_7 == 7
    node_7_pg = am.getNodesByPhysicalGroup(17)
    assert node_7_pg[0] == 7

    # I build 2 frames linked to nodes meshed in one element each one forcing
    # tag to 1 and 2.
    #
    frame_20 = am.addFrame(
        tagStart=node_5, tagEnd=node_7, tag=20, group=True, tagGroup=21, nb=1
    )
    assert frame_20 == 20

    frame_20_pg = am.getFramesByPhysicalGroup(21)
    assert frame_20_pg[0] == 20

    frame_10 = am.addFrame(
        tagStart=node_3, tagEnd=node_5, tag=10, group=True, tagGroup=11, nb=1
    )
    assert frame_10 == 10

    frame_10_pg = am.getFramesByPhysicalGroup(11)
    assert frame_10_pg[0] == 10

    #
    #            [frame 5]              [frame 4]
    # [node 1]---------------[node 2]---------------[node 3]
    #

    ft = am.framesTags()
    assert ft[0] == 5
    assert ft[1] == 4
    fnt = am.framesNodeTags()
    assert fnt[0][0] == 1
    assert fnt[0][1] == 2
    assert fnt[1][0] == 2
    assert fnt[1][1] == 3
    # am.show()


# Tests that interior points embedded into a 2D surface are included in the
# triangulation after mesh generation.
#
# A 5x5 square plate is built from 4 corner nodes (n1-n4) connected by 4
# boundary lines (f1-f4). The surface is meshed with unstructured Delaunay
# (transfiniteSurface=False) so that embedded interior points are respected.
# Boundary lines are also kept non-transfinite so they don't generate
# standalone 1D beam elements.
#
# Four interior points (n11-n14) are then embedded into the surface via
# gmsh embed, the mesh is regenerated, and the test asserts that each
# embedded point produced exactly one mesh node and that node appears in the
# full node list returned by FEModel.
def test_fe_2d_elements_quad_001():
    am = FEModel()

    # Corner nodes of the 5x5 square plate
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=0.3)
    n2 = am.addNode(x=5.0, y=0.0, z=0.0, meshSize=0.3)
    n3 = am.addNode(x=5.0, y=5.0, z=0.0, meshSize=0.3)
    n4 = am.addNode(x=0.0, y=5.0, z=0.0, meshSize=0.3)

    # Interior points to be embedded into the surface
    n11 = am.addNode(x=1.0, y=1.0, z=0.0, meshSize=0.3)
    n12 = am.addNode(x=4.0, y=1.0, z=0.0, meshSize=0.3)
    n13 = am.addNode(x=4.0, y=4.0, z=0.0, meshSize=0.3)
    n14 = am.addNode(x=1.0, y=4.0, z=0.0, meshSize=0.3)

    # Boundary lines: transfiniteCurve=False so they act as geometry boundaries
    # only and do not generate standalone 1D beam elements
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=7, transfiniteCurve=False)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=7, transfiniteCurve=False)
    f3 = am.addFrame(tagStart=n3, tagEnd=n4, nb=7, transfiniteCurve=False)
    f4 = am.addFrame(tagStart=n4, tagEnd=n1, nb=7, transfiniteCurve=False)

    # Unstructured surface mesh: transfiniteSurface=False allows embedded
    # interior points to be honoured by the Delaunay algorithm
    pq1 = am.addPlate(f1, f2, f3, f4, transfiniteSurface=False)

    # Embed the 4 interior points (dim=0) into the surface (dim=2) and
    # regenerate the mesh so they become vertices of the triangulation
    am.addNodesToPlate([n11, n12, n13, n14], pq1)

    modeler = am.getModeler()
    all_node_tags = am.nodesTags()
    for n in [n11, n12, n13, n14]:

        # Each embedded point must produce exactly one mesh node ...
        node_tags, _, _ = modeler.mesh.getNodes(0, n)
        assert len(node_tags) == 1

        # ... and that node must be present in the global node list
        assert node_tags[0] in all_node_tags

    # After addNodesToPlate the surface must consist exclusively of 4-node
    # quad elements (gmsh element type 3)
    elem_types, _, _ = modeler.mesh.getElements(dim=2, tag=pq1)
    assert list(elem_types) == [
        3
    ], f"Expected only 4-node quad elements (type 3), got element types: {list(elem_types)}"

    # am.show()


# This test same points of above, with triangular meshed surface
def test_fe_2d_elements_tria_001():
    am = FEModel()

    # Corner nodes of the 5x5 square plate
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=0.3)
    n2 = am.addNode(x=5.0, y=0.0, z=0.0, meshSize=0.3)
    n3 = am.addNode(x=5.0, y=5.0, z=0.0, meshSize=0.3)

    # Boundary lines: transfiniteCurve=False so they act as geometry boundaries
    # only and do not generate standalone 1D beam elements
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=7, transfiniteCurve=False)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=7, transfiniteCurve=False)
    f3 = am.addFrame(tagStart=n3, tagEnd=n1, nb=7, transfiniteCurve=False)

    # Unstructured surface mesh: transfiniteSurface=False allows embedded
    # interior points to be honoured by the Delaunay algorithm
    am.addPlate(f1, f2, f3, transfiniteSurface=False)

    # am.show()


# Verify that a 4-sided surface meshed with nb=2 on every boundary curve and
# transfiniteSurface=True produces exactly one 4-node quad element (gmsh type 3).
#
# The key to a single-element mesh is setting nb=1 on every boundary curve:
# addFrame translates nb into nb+1 nodes via setTransfiniteCurve, so nb=1
# places only the 2 endpoint nodes on each edge (1 segment).  The transfinite
# algorithm fills the interior with a single structured cell.  setRecombine
# (triggered by elType=ELEM_QUAD) converts that cell from two triangles into
# one quad.
def test_fe_2d_single_quad_element():
    am = FEModel()

    # Four corners of a 1x1 square
    n1 = am.addNode(x=0.0, y=0.0, z=0.0)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0)
    n3 = am.addNode(x=1.0, y=1.0, z=0.0)
    n4 = am.addNode(x=0.0, y=1.0, z=0.0)

    # nb=1 means 1 element per edge (addFrame calls setTransfiniteCurve with
    # nb+1 nodes, so nb=1 → 2 nodes = just the two endpoints = 1 segment).
    # transfiniteCurve=True registers the curve with the transfinite algorithm
    # so the surface mesher respects the prescribed node count.
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=1, transfiniteCurve=True)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=1, transfiniteCurve=True)
    f3 = am.addFrame(tagStart=n3, tagEnd=n4, nb=1, transfiniteCurve=True)
    f4 = am.addFrame(tagStart=n4, tagEnd=n1, nb=1, transfiniteCurve=True)

    # transfiniteSurface=True enables structured meshing.
    # elType=ELEM_QUAD triggers setRecombine so the two triangles that the
    # transfinite algorithm would normally produce are merged into one quad.
    pq = am.addPlate(f1, f2, f3, f4, transfiniteSurface=True, elType=Elem.ELEM_QUAD)

    modeler = am.getModeler()
    elem_types, elem_tags, _ = modeler.mesh.getElements(dim=2, tag=pq)

    # The surface must contain exactly one element type ...
    assert list(elem_types) == [
        3
    ], f"Expected only 4-node quad elements (gmsh type 3), got: {list(elem_types)}"
    # ... and that type must contain exactly one element
    assert (
        len(elem_tags[0]) == 1
    ), f"Expected exactly 1 quad element, got: {len(elem_tags[0])}"
    # am.show()


# Verify that a 3-sided surface meshed with nb=2 on every boundary curve and
# transfiniteSurface=True produces exactly one 3-node triangle element (gmsh type 2).
#
# Same principle as the quad test: nb=1 gives 1 segment per edge (addFrame
# maps nb → nb+1 nodes).  Without setRecombine (elType=ELEM_TRIA) the
# transfinite algorithm keeps the single triangular cell intact and does not
# merge it into a quad.
def test_fe_2d_single_tria_element():
    am = FEModel()

    # Three corners of a right triangle
    n1 = am.addNode(x=0.0, y=0.0, z=0.0)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0)
    n3 = am.addNode(x=0.0, y=1.0, z=0.0)

    # nb=1 — 1 element per edge (addFrame passes nb+1=2 nodes to gmsh, which
    # means just the two endpoints); transfiniteCurve=True required for the
    # transfinite surface algorithm to honour the prescribed element count
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=1, transfiniteCurve=True)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=1, transfiniteCurve=True)
    f3 = am.addFrame(tagStart=n3, tagEnd=n1, nb=1, transfiniteCurve=True)

    # elType=ELEM_TRIA skips setRecombine, so the result is a single triangle
    pt = am.addPlate(f1, f2, f3, transfiniteSurface=True, elType=Elem.ELEM_TRIA)

    modeler = am.getModeler()
    elem_types, elem_tags, _ = modeler.mesh.getElements(dim=2, tag=pt)

    # The surface must contain exactly one element type ...
    assert list(elem_types) == [
        2
    ], f"Expected only 3-node triangle elements (gmsh type 2), got: {list(elem_types)}"
    # ... and that type must contain exactly one element
    assert (
        len(elem_tags[0]) == 1
    ), f"Expected exactly 1 triangle element, got: {len(elem_tags[0])}"
    # am.show()


# Verify node mode: 4 nodes passed directly to addPlate produce a multi-element
# quad mesh.  No nb is set, so mesh density is driven by the node meshSize.
# The surface must contain only 4-node quad elements (gmsh type 3).
def test_fe_2d_nodes_quad_elements():
    am = FEModel()

    # Four corners of a 1x1 square with a coarse mesh size
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=0.3)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0, meshSize=0.3)
    n3 = am.addNode(x=1.0, y=1.0, z=0.0, meshSize=0.3)
    n4 = am.addNode(x=0.0, y=1.0, z=0.0, meshSize=0.3)

    # Boundary curves are created internally; no nb means no transfinite
    # settings on the curves, so the surface is meshed unstructured.
    # elType=ELEM_QUAD triggers setRecombine to produce quad elements.
    pq = am.addPlate(
        nodes=[n1, n2, n3, n4], transfiniteSurface=False, elType=Elem.ELEM_QUAD
    )

    modeler = am.getModeler()
    elem_types, _, _ = modeler.mesh.getElements(dim=2, tag=pq)

    assert list(elem_types) == [
        3
    ], f"Expected only 4-node quad elements (gmsh type 3), got: {list(elem_types)}"


# Verify node mode: 3 nodes passed directly to addPlate produce a multi-element
# triangle mesh.  No nb is set, so mesh density is driven by the node meshSize.
# The surface must contain only 3-node triangle elements (gmsh type 2).
def test_fe_2d_nodes_tria_elements():
    am = FEModel()

    # Three corners of a right triangle with a coarse mesh size
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=0.3)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0, meshSize=0.3)
    n3 = am.addNode(x=0.0, y=1.0, z=0.0, meshSize=0.3)

    # elType=ELEM_TRIA skips setRecombine so the unstructured Delaunay
    # triangulation is preserved as-is.
    pt = am.addPlate(
        nodes=[n1, n2, n3], transfiniteSurface=False, elType=Elem.ELEM_TRIA
    )

    modeler = am.getModeler()
    elem_types, _, _ = modeler.mesh.getElements(dim=2, tag=pt)

    assert list(elem_types) == [
        2
    ], f"Expected only 3-node triangle elements (gmsh type 2), got: {list(elem_types)}"


# Verify node mode with nb=1: 4 nodes + nb=1 forces a single 4-node quad.
# addPlate calls setTransfiniteCurve(line, nb+1=2) on each internally created
# boundary line, placing only the 2 endpoint nodes per edge (1 segment).
# Combined with transfiniteSurface=True and setRecombine (ELEM_QUAD) this
# yields exactly one quad element with no addFrame calls required.
def test_fe_2d_nodes_single_quad_element():
    am = FEModel()

    n1 = am.addNode(x=0.0, y=0.0, z=0.0)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0)
    n3 = am.addNode(x=1.0, y=1.0, z=0.0)
    n4 = am.addNode(x=0.0, y=1.0, z=0.0)

    pq = am.addPlate(nodes=[n1, n2, n3, n4], nb=1)

    modeler = am.getModeler()
    elem_types, elem_tags, _ = modeler.mesh.getElements(dim=2, tag=pq)

    assert list(elem_types) == [
        3
    ], f"Expected only 4-node quad elements (gmsh type 3), got: {list(elem_types)}"
    assert (
        len(elem_tags[0]) == 1
    ), f"Expected exactly 1 quad element, got: {len(elem_tags[0])}"


# Verify node mode with nb=1: 3 nodes + nb=1 forces a single 3-node triangle.
# Same principle as the quad case but elType=ELEM_TRIA skips setRecombine so
# the single transfinite cell remains a triangle.
def test_fe_2d_nodes_single_tria_element():
    am = FEModel()

    n1 = am.addNode(x=0.0, y=0.0, z=0.0)
    n2 = am.addNode(x=1.0, y=0.0, z=0.0)
    n3 = am.addNode(x=0.0, y=1.0, z=0.0)

    pt = am.addPlate(nodes=[n1, n2, n3], nb=1, elType=Elem.ELEM_TRIA)

    modeler = am.getModeler()
    elem_types, elem_tags, _ = modeler.mesh.getElements(dim=2, tag=pt)

    assert list(elem_types) == [
        2
    ], f"Expected only 3-node triangle elements (gmsh type 2), got: {list(elem_types)}"
    assert (
        len(elem_tags[0]) == 1
    ), f"Expected exactly 1 triangle element, got: {len(elem_tags[0])}"


# Local axis 3 as default directed as z axis
def test_fe_1d_local_axis_001():
    am = FEModel()

    n_i = am.addNode(x=0.0, y=0.0, z=0.0)
    n_j = am.addNode(x=0.0, y=0.0, z=1.0)

    frameMacroTag = am.addFrame(n_i, n_j, nb=10)

    frameTag = am.getFramesFromMacroTags([frameMacroTag])

    for el in frameTag:
        local_3 = am.getFrameLocal3(el)
        assert local_3 == Vector3d(0.0, 0.0, 1.0)

        local_2 = am.getFrameLocal2(el)
        assert local_2 == Vector3d(0.0, 1.0, 0.0)

        local_1 = am.getFrameLocal1(el)
        assert local_1 == Vector3d(1.0, 0.0, 0.0)


# Local axis 3 as default for frame oblique
def test_fe_1d_local_axis_002():
    am = FEModel()

    n_i = am.addNode(x=0.0, y=0.0, z=0.0)
    n_j = am.addNode(x=0.0, y=1.0, z=1.0)

    frameMacroTag = am.addFrame(n_i, n_j, nb=10)

    frameTags = am.getFramesFromMacroTags([frameMacroTag])

    connectivity = am.framesConnectivity()
    for el in frameTags:
        local_3 = am.getFrameLocal3(el)
        n1 = connectivity[el][0]
        n2 = connectivity[el][1]
        assert (
            local_3
            == Vector3d(
                Point3d(*am.nodeCoords(n1)), Point3d(*am.nodeCoords(n2))
            ).normalize()
        )

        local_2 = am.getFrameLocal2(el)
        assert local_2 == Vector3d(0.0, 0.0, 1.0).cross(local_3)

        local_1 = am.getFrameLocal1(el)
        assert local_1 == local_2.cross(local_3)


# Assigning Local axis 2 to macro frame
def test_fe_1d_local_axis_003():
    am = FEModel()

    n_i = am.addNode(x=0.0, y=0.0, z=0.0)
    n_j = am.addNode(x=1.0, y=1.0, z=0.0)

    frameMacroTag = am.addFrame(n_i, n_j, nb=10)
    frameTags = am.getFramesFromMacroTags([frameMacroTag])

    # same value as before assignMultiFrameLocal2 with Vector3d(1.0, -1.0, 0.0)
    am.assignMultiFrameLocal2(axis=Vector3d(1.0, -1.0, 0.0), tagsMacro=[frameMacroTag])

    for el in frameTags:
        local_2 = am.getFrameLocal2(el)
        assert local_2 == Vector3d(math.sqrt(2) / 2, -math.sqrt(2) / 2, 0.0)

    am.assignMultiFrameLocal2(axis=Vector3d(-1.0, 1.0, 0.0), tagsMacro=[frameMacroTag])

    for el in frameTags:
        local_2 = am.getFrameLocal2(el)
        assert local_2 == Vector3d(-math.sqrt(2) / 2, math.sqrt(2) / 2, 0.0)


# Tested with cad
def test_fe_1d_local_axis_004():
    am = FEModel()

    n_i = am.addNode(x=0.0, y=0.0, z=0.0)
    n_j = am.addNode(x=10.0, y=10.0, z=10.0)

    frame_macro_tag = am.addFrame(n_i, n_j, nb=10)
    frame_tags = am.getFramesFromMacroTags([frame_macro_tag])

    # same value as before assignMultiFrameLocal2 with Vector3d(1.0, -1.0, 0.0)
    am.assignMultiFrameLocal2(
        axis=Vector3d(10.0, 0.0, 0.0), tagsMacro=[frame_macro_tag]
    )

    for el in frame_tags:
        local_2 = am.getFrameLocal2(el)
        local_2_from_cad = Vector3d(6.6667, -3.3333, -3.3333).normalize()
        assert pytest.approx(local_2.vx, abs=1.0e-5) == local_2_from_cad.vx
        assert pytest.approx(local_2.vy, abs=1.0e-5) == local_2_from_cad.vy
        assert pytest.approx(local_2.vz, abs=1.0e-5) == local_2_from_cad.vz


def test_fe_2d_elements_plate_tags_001():
    am = FEModel()

    # Corner nodes of the 5x5 square plate
    n1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=5)
    n2 = am.addNode(x=5.0, y=0.0, z=0.0, meshSize=5)
    n3 = am.addNode(x=5.0, y=5.0, z=0.0, meshSize=5)
    n4 = am.addNode(x=0.0, y=5.0, z=0.0, meshSize=5)

    # Boundary lines: transfiniteCurve=False so they act as geometry boundaries
    # only and do not generate standalone 1D beam elements
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=2, transfiniteCurve=False)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=2, transfiniteCurve=False)
    f3 = am.addFrame(tagStart=n3, tagEnd=n4, nb=2, transfiniteCurve=False)
    f4 = am.addFrame(tagStart=n4, tagEnd=n1, nb=2, transfiniteCurve=False)

    # Unstructured surface mesh: transfiniteSurface=False allows embedded
    # interior points to be honoured by the Delaunay algorithm
    am.addPlate(f1, f2, f3, f4, transfiniteSurface=True)

    pt = am.platesTags()
    assert pt == [13, 14, 15, 16]
    pnt = am.platesNodeTags()
    assert pnt == [[1, 5, 9, 8], [8, 9, 7, 4], [5, 2, 6, 9], [9, 6, 3, 7]]

    # am.show()

# Three point beam with load on 45° loads starting from 2nd elemnt to 18th
# as image below
#
#    10 elements       10 elements
# <1>-------------<2>-------------<3>
#
def test_fe_1d_elements_line_load_001():
    am = FEModel()

    p1 = Point3d(x= 0.0, y=0.0, z=0.0)
    p2 = Point3d(x=10.0, y=0.0, z=0.0)
    p3 = Point3d(x=20.0, y=0.0, z=0.0)

    n1 = am.addNode(point=p1)
    n2 = am.addNode(point=p2)
    n3 = am.addNode(point=p3)

    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=10)
    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=10)

    # am.show()
    am.addLoadCase("DL", "U", "user load case")
    am.addMacroFrameLoadLine(
        loadCase="DL", tagsMacro=[f1, f2], tp="force",
        direction="X", load_value_1=[0.1, 10.0], load_value_2=[0.9, 26.0],
        load_position_absolute=False
    )
    # load
    # case | LoadType | tagFrame | tp
    # force | direction | value

    loads = am.getLoads()
    nb_GCX1_zero = 0
    nb_GCX2_zero = 0
    values_dict_left = []
    values_dict_right = []
    for f in loads["DL"][LoadType.FRAME_LOAD].values():
        if f['force']['GCX1'][1] == 0.0:
            nb_GCX1_zero += 1
        else:
            values_dict_left.append(f['force']['GCX1'][1])

        if f['force']['GCX2'][1] == 0.0:
            nb_GCX2_zero += 1
        else:
            values_dict_right.append(f['force']['GCX2'][1])

    assert nb_GCX1_zero == 4
    assert nb_GCX2_zero == 4

    assert pytest.approx(max(values_dict_left)) == 25
    assert pytest.approx(min(values_dict_left)) == 10
    assert pytest.approx(max(values_dict_right)) == 26
    assert pytest.approx(min(values_dict_right)) == 11

# As test_fe_1d_elements_line_load_001 but inverted
#
def test_fe_1d_elements_line_load_002():
    am = FEModel()

    p1 = Point3d(x= 0.0, y=0.0, z=0.0)
    p2 = Point3d(x=10.0, y=0.0, z=0.0)
    p3 = Point3d(x=20.0, y=0.0, z=0.0)

    n1 = am.addNode(point=p1)
    n2 = am.addNode(point=p2)
    n3 = am.addNode(point=p3)

    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=10)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=10)

    # am.show()
    am.addLoadCase("DL", "U", "user load case")
    am.addMacroFrameLoadLine(
        loadCase="DL", tagsMacro=[f1, f2], tp="force",
        direction="X", load_value_1=[0.1, 10.0], load_value_2=[0.9, 26.0],
        load_position_absolute=False
    )
    # load
    # case | LoadType | tagFrame | tp
    # force | direction | value

    loads = am.getLoads()
    nb_GCX1_zero = 0
    nb_GCX2_zero = 0
    values_dict_left = []
    values_dict_right = []
    for f in loads["DL"][LoadType.FRAME_LOAD].values():
        if f['force']['GCX1'][1] == 0.0:
            nb_GCX1_zero += 1
        else:
            values_dict_left.append(f['force']['GCX1'][1])

        if f['force']['GCX2'][1] == 0.0:
            nb_GCX2_zero += 1
        else:
            values_dict_right.append(f['force']['GCX2'][1])

    assert nb_GCX1_zero == 4
    assert nb_GCX2_zero == 4

    assert pytest.approx(max(values_dict_left)) == 25
    assert pytest.approx(min(values_dict_left)) == 10
    assert pytest.approx(max(values_dict_right)) == 26
    assert pytest.approx(min(values_dict_right)) == 11

# As test_fe_1d_elements_line_load_001 but rotated about 45 degree
#
def test_fe_1d_elements_line_load_003():
    am = FEModel()

    p1 = Point2d(x= 0.0, y=0.0)
    p2 = Point2d(x=10.0, y=0.0)
    p3 = Point2d(x=20.0, y=0.0)

    p1.rotate(45.0, Point2d(0.0, 0.0))
    p2.rotate(45.0, Point2d(0.0, 0.0))
    p3.rotate(45.0, Point2d(0.0, 0.0))

    n1 = am.addNode(point=Point3d().fromPoint2d(p1))
    n2 = am.addNode(point=Point3d().fromPoint2d(p2))
    n3 = am.addNode(point=Point3d().fromPoint2d(p3))

    f1 = am.addFrame(tagStart=n1, tagEnd=n2, nb=10)
    f2 = am.addFrame(tagStart=n2, tagEnd=n3, nb=10)

    # am.show()
    am.addLoadCase("DL", "U", "user load case")
    am.addMacroFrameLoadLine(
        loadCase="DL", tagsMacro=[f1, f2], tp="force",
        direction="X", load_value_1=[0.1, 10.0], load_value_2=[0.9, 26.0],
        load_position_absolute=False
    )
    # load
    # case | LoadType | tagFrame | tp
    # force | direction | value

    loads = am.getLoads()
    nb_GCX1_zero = 0
    nb_GCX2_zero = 0
    values_dict_left = []
    values_dict_right = []
    for f in loads["DL"][LoadType.FRAME_LOAD].values():
        if f['force']['GCX1'][1] == 0.0:
            nb_GCX1_zero += 1
        else:
            values_dict_left.append(f['force']['GCX1'][1])

        if f['force']['GCX2'][1] == 0.0:
            nb_GCX2_zero += 1
        else:
            values_dict_right.append(f['force']['GCX2'][1])

    assert nb_GCX1_zero == 4
    assert nb_GCX2_zero == 4

    assert pytest.approx(max(values_dict_left)) == 25
    assert pytest.approx(min(values_dict_left)) == 10
    assert pytest.approx(max(values_dict_right)) == 26
    assert pytest.approx(min(values_dict_right)) == 11


def test_fe_2d_elements_quad_002():
    am = FEModel()

    # Corner nodes of the 5x5 square plate
    ne1 = am.addNode(x=0.0, y=0.0, z=0.0, meshSize=1.0)
    ne2 = am.addNode(x=5.0, y=0.0, z=0.0, meshSize=1.0)
    ne3 = am.addNode(x=5.0, y=5.0, z=0.0, meshSize=1.0)
    ne4 = am.addNode(x=0.0, y=5.0, z=0.0, meshSize=1.0)

    # Inner points to be embedded into the surface
    ni1 = am.addNode(x=1.0, y=1.0, z=0.0, meshSize=1.0)
    ni2 = am.addNode(x=4.0, y=1.0, z=0.0, meshSize=1.0)
    ni3 = am.addNode(x=4.0, y=4.0, z=0.0, meshSize=1.0)
    ni4 = am.addNode(x=1.0, y=4.0, z=0.0, meshSize=1.0)

    am.addPlate(nodes=[ne1, ne2, ni2, ni1])
    am.addPlate(nodes=[ne2, ne3, ni3, ni2])
    am.addPlate(nodes=[ne3, ne4, ni4, ni3])
    am.addPlate(nodes=[ne4, ne1, ni1, ni4])

    conn = am.platesConnectivity()

    for n in [6, 14, 49, 27]:
        assert n in conn[80]

    for n in [46, 13, 14, 6]:
        assert n in conn[68]






