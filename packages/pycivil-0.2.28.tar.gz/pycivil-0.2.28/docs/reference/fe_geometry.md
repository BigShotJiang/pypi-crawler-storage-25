::: pycivil.EXAStructuralModel.fe_geometry
    options:
      filters:
        - "!^__"