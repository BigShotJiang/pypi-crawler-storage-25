::: pycivil.EXAStructuralModel.fe_mesh
    options:
      filters:
        - "!^__"