::: pycivil.EXAStructuralModel.fe_loads
    options:
      filters:
        - "!^__"