::: pycivil.EXAStructuralModel.fe_assign
    options:
      filters:
        - "!^__"