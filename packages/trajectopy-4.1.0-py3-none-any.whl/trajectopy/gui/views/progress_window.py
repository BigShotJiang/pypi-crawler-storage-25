﻿from PySide6 import QtCore, QtWidgets

from trajectopy.gui.utils import center_window


class ProgressWindow(QtWidgets.QMainWindow):
    """A modal-like progress window that shows during long operations."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent=parent)
        self._show_count = 0  # Track nested show requests
        self.setupUi()

    def setupUi(self):
        self.setObjectName("Form")
        self.resize(410, 70)
        center_window(self)
        self.setMinimumSize(QtCore.QSize(410, 70))
        self.setMaximumSize(QtCore.QSize(410, 70))
        self.verticalLayoutWidget = QtWidgets.QWidget(self)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(0, 0, 410, 70))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(10, 10, 10, 10)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem = QtWidgets.QSpacerItem(
            40,
            20,
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Minimum,
        )
        self.horizontalLayout.addItem(spacerItem)
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        spacerItem1 = QtWidgets.QSpacerItem(
            40,
            20,
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Minimum,
        )
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.progressBar = QtWidgets.QProgressBar(self.verticalLayoutWidget)
        self.progressBar.setMaximum(0)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setTextVisible(False)
        self.progressBar.setObjectName("progressBar")
        self.verticalLayout.addWidget(self.progressBar)

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("Form", "Please Wait"))
        self.label.setText(_translate("Form", "Please Wait ..."))

    @QtCore.Slot()
    def handle_show_request(self) -> None:
        self._show_count += 1
        if self._show_count == 1:
            self.show()

    @QtCore.Slot()
    def handle_close_request(self) -> None:
        self._show_count = max(0, self._show_count - 1)
        if self._show_count == 0:
            self.close()
