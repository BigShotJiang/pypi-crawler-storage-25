"""
Extends the pathlib.Path class to provide additional functionality.
"""

import datetime
import hashlib
import itertools
import os
import os.path
import pathlib
import re
import shutil
import zlib
from fnmatch import fnmatch
from os import PathLike, makedirs
from pathlib import PurePath
from typing import Any, Generator, Self


class CallableInt(int):
    """An int subclass that can be called. Use for backwards compatibility."""

    def __call__(self, *args: Any, **kwargs: Any) -> Self:
        return self


class CallableFloat(float):
    """A float subclass that can be called. Use for backwards compatibility."""

    def __call__(self, *args: Any, **kwargs: Any) -> Self:
        return self


def SetCallableDigit(digit: int | float) -> CallableInt | CallableFloat:
    """Convert int or float to CallableInt or CallableFloat."""
    if int(digit) == digit:
        return CallableInt(digit)
    else:
        return CallableFloat(digit)


def hash_file(filename: str | PathLike[str]) -> dict[str, str]:
    """Returns a dictionary containing the hash values of the given file."""

    # Initialize the hash values
    crc_value: int = 0
    hash_md5 = hashlib.md5()
    sha1_hash = hashlib.sha1()
    sha256_hash = hashlib.sha256()

    # Read the file and update the hash values
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            crc_value = zlib.crc32(chunk, crc_value)
            hash_md5.update(chunk)
            sha1_hash.update(chunk)
            sha256_hash.update(chunk)

    # Convert the hash values to hexadecimal strings
    hash_dict: dict[str, str] = {
        "crc32": "%X" % (crc_value & 0xFFFFFFFF),
        "md5": hash_md5.hexdigest(),
        "sha1": sha1_hash.hexdigest(),
        "sha256": sha256_hash.hexdigest(),
    }

    return hash_dict


class Path(pathlib.WindowsPath):
    """Extends the pathlib.WindowsPath class to provide additional functionality."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.cls = type(self)

        try:
            super().__init__(*args, **kwargs)
        except TypeError:
            super().__init__()
        self._stat_cached = False

    @property
    def parent(self) -> Self:
        """Return the parent path."""
        return self.cls(super().parent)

    @property
    def parents(self) -> list[Self]:
        """Return a list of parent paths."""
        return [self.cls(p) for p in super().parents]

    def _update_stat_info(self) -> None:
        """
        Update self.bytes, self.kilobytes, self.megabytes, self.gigabytes,
        self.hardlinks, self.accessed, self.modified, self.created

        self.bytes: int | float
        self.kilobytes: int | float
        self.megabytes: int | float
        self.gigabytes: int | float
        self.hardlinks: int
        self.accessed: datetime.datetime | float | None
        self.modified: datetime.datetime | float | None
        self.created: datetime.datetime | float | None
        """

        self._bytes: CallableInt | CallableFloat = SetCallableDigit(0)
        self._kilobytes: CallableInt | CallableFloat = SetCallableDigit(0)
        self._megabytes: CallableInt | CallableFloat = SetCallableDigit(0)
        self._gigabytes: CallableInt | CallableFloat = SetCallableDigit(0)
        self._hardlinks: int = 0
        self._accessed_float: float = 0.0
        self._modified_float: float = 0.0
        self._created_float: float = 0.0
        self._accessed: datetime.datetime | None = None
        self._modified: datetime.datetime | None = None
        self._created: datetime.datetime | None = None
        self.hash_dict: dict[str, str] = {}
        self.crc32: str | None = None
        self.md5: str | None = None
        self.sha1: str | None = None
        self.sha256: str | None = None

        if not self.exists():
            return

        _stat = os.stat(self)
        self._bytes = SetCallableDigit(_stat.st_size)
        self._kilobytes = SetCallableDigit(round(self._bytes / 1024, 2))
        self._megabytes = SetCallableDigit(round(self._kilobytes / 1024, 2))
        self._gigabytes = SetCallableDigit(round(self._megabytes / 1024, 2))
        self._hardlinks = _stat.st_nlink

        self._accessed_float = _stat.st_atime
        self._modified_float = _stat.st_mtime
        self._created_float = _stat.st_ctime
        self._accessed = datetime.datetime.fromtimestamp(_stat.st_atime)
        self._modified = datetime.datetime.fromtimestamp(_stat.st_mtime)
        self._created = datetime.datetime.fromtimestamp(_stat.st_ctime)

        self.hash_dict = hash_file(self) if self.is_file() else {}
        self.crc32 = self.hash_dict.get("crc32", None)
        self.md5 = self.hash_dict.get("md5", None)
        self.sha1 = self.hash_dict.get("sha1", None)
        self.sha256 = self.hash_dict.get("sha256", None)

    def _check_and_update_stat(self) -> None:
        """Update self if it is not already updated."""
        if not hasattr(self, "_stat_cached") or not self._stat_cached:
            self._update_stat_info()
            self._stat_cached = True

    def copy(self, target: str | PathLike[str] | PurePath) -> None:
        """Copy file whilst making any necessary directories in target destination."""
        assert self.is_file()
        dest = self.cls(target)
        makedirs(dest.parent, exist_ok=True)
        shutil.copy(str(self), str(dest))

    def copy2(self, target: str | PathLike[str] | PurePath) -> None:
        """
        Copy file whilst making any necessary directories in target destination, appending '_2'
        (or increasing integer) to end of file name to prevent colision.
        """

        assert self.is_file()
        dest = self.cls(target)
        makedirs(dest.parent, exist_ok=True)
        dest = self.move_helper(target=dest)
        shutil.copy(str(self), str(dest))

    def move(self, dst: str | PathLike[str] | PurePath) -> None:
        """Move file whilst making any necessary directories in target destination."""
        target = self.cls(dst)
        makedirs(target.parent, exist_ok=True)
        shutil.move(str(self), str(target))

    def move2(self, dst: str | PathLike[str] | PurePath) -> None:
        """
        Move file whilst making any necessary directories in target destination, appending '_2'
        (or increasing integer) to end of file name to prevent colision.
        """
        target = self.cls(dst)
        makedirs(target.parent, exist_ok=True)
        new_target = self.move_helper(target=target)
        shutil.move(str(self), str(new_target))

    def move_helper(self, target: str | PathLike[str] | PurePath) -> Self:
        """
        Get target destination for file, appending '_2'
        (or increasing integer) to end of file name to prevent colision.
        """

        mv_count = 2
        dest = self.cls(target)
        makedirs(dest.parent, exist_ok=True)
        while dest.exists():
            stem = dest.stem
            suffix = dest.suffix
            match = re.search(r"_(\d+)$", stem)
            if match:
                num = int(match.group(1))
                new_stem = stem[: match.start()] + f"_{num + 1}"
            else:
                new_stem = f"{stem}_{mv_count}"
            dest = dest.with_name(new_stem + suffix)
            mv_count += 1
        return dest

    def mkdirs(self) -> None:
        """Make directories, with no errors on a directory existing."""
        makedirs(self, exist_ok=True)

    @property
    def bytes(self) -> int:
        """Return size of file in bytes"""
        self._check_and_update_stat()
        return self._bytes

    @property
    def b(self) -> int:
        """Return size of file in bytes"""
        self._check_and_update_stat()
        return self._bytes

    @property
    def kilobytes(self) -> int | float:
        """Return size of file in kilobytes, rounded down."""
        self._check_and_update_stat()
        return self._kilobytes

    @property
    def kb(self) -> int | float:
        """Return size of file in kilobytes, rounded down."""
        self._check_and_update_stat()
        return self._kilobytes

    @property
    def megabytes(self) -> int | float:
        """Return size of file in megabytes, rounded down."""
        self._check_and_update_stat()
        return self._megabytes

    @property
    def mb(self) -> int | float:
        """Return size of file in megabytes, rounded down."""
        self._check_and_update_stat()
        return self._megabytes

    @property
    def gigabytes(self) -> int | float:
        """Return size of file in gigabytes, rounded down."""
        self._check_and_update_stat()
        return self._gigabytes

    @property
    def gb(self) -> int | float:
        """Return size of file in gigabytes, rounded down."""
        self._check_and_update_stat()
        return self._gigabytes

    @property
    def hardlinks(self) -> int:
        """Return the number of hard links to the file."""
        self._check_and_update_stat()
        return self._hardlinks

    def fnmatch_tuple(self, path: str | PathLike[str], wildcards: tuple) -> bool:
        """
        Return True if path matches one or more designations in wildcards.
        (See Python fnmatch doc for more info on how to format search terms).
        """

        return any(fnmatch(path, w) for w in wildcards)

    def scan(self, wildcards: str | tuple = "*") -> Generator[Self, None, None]:
        """
        Search through directory matching one or more designations.
        Uses os.scandir to search for a speed increase, whilst returning Path objects.
        (See Python fnmatch doc for more info on how to format search terms).
        """

        scan_path: Self = self.resolve()
        if scan_path == ".":
            scan_path = self.cls(os.getcwd())
        if isinstance(wildcards, str):
            return (
                self.cls(x.path)
                for x in os.scandir(scan_path)
                if fnmatch(x.path, wildcards)
            )
        if isinstance(wildcards, tuple):
            output: itertools.chain = itertools.chain()
            for w in wildcards:
                output = itertools.chain(
                    output, [x for x in os.scandir(scan_path) if fnmatch(x.path, w)]
                )
            return (self.cls(x.path) for x in output)

    def scanr(self, wildcards: str | tuple = "*") -> Generator[Self, None, None]:
        """
        Recursive search through directory matching one or more designations.
        Uses os.walk to search for a speed increase, whilst returning Path objects.
        (See Python fnmatch doc for more info on how to format search terms).
        """
        scan_path: Self = self.resolve()

        if scan_path == ".":
            scan_path = self.cls(os.getcwd())

        if isinstance(wildcards, str):
            wildcards = (wildcards,)

        for root, dirs, files in os.walk(scan_path):
            for item in files + dirs:
                joined = os.path.join(root, item)
                if self.fnmatch_tuple(joined, wildcards):
                    yield self.cls(joined)

    def write(
        self,
        data: "str | bytes",
        mode: str = "w",
        encoding: str | None = None,
    ) -> None:
        """Open file and write data to it."""
        with self.open(mode, encoding=encoding) as fwrite:
            fwrite.write(data)

    def readlines(self, encoding: str | None = None, strip: bool = False) -> list[str]:
        """Open file and return the readlines."""
        with self.open("r", encoding=encoding) as fread:
            if strip:
                return [x.strip() for x in fread.readlines()]
            else:
                return fread.readlines()

    def str_is_file(self) -> bool:
        """
        Attempt to tell if a string (to a file that does not exist)
        is a file or not. Not very reliable, but sometimes helpful.
        """

        ext = os.path.splitext(str(self))[1]
        if self.is_dir():
            return False
        if ext:
            return True
        return False

    def exists(self) -> bool:
        """Return bool of whether or not the file exists."""
        return os.path.exists(self)

    def splitext(self) -> tuple[str, str]:
        """Split filename from extension, returns a tuple."""
        return os.path.splitext(self)

    def getatime(self, as_float: bool = False) -> datetime.datetime | float | None:
        """Get accessed time for file as datetime."""
        self._check_and_update_stat()
        if as_float:
            return self._accessed_float
        else:
            return self._accessed

    def getmtime(self, as_float: bool = False) -> datetime.datetime | float | None:
        """Get modified time for file as datetime."""
        self._check_and_update_stat()
        if as_float:
            return self._modified_float
        else:
            return self._modified

    def getctime(self, as_float: bool = False) -> datetime.datetime | float | None:
        """Get created time for file as datetime."""
        self._check_and_update_stat()
        if as_float:
            return self._created_float
        else:
            return self._created

    def with_name(self, name):
        """Return a new path with the file name changed."""
        return self.cls(super().with_name(name))

    def with_stem(self, stem):
        """Return a new path with the stem changed."""
        return self.cls(super().with_stem(stem))

    def with_suffix(self, suffix):
        """Return a new path with the suffix changed."""
        return self.cls(super().with_suffix(suffix))

    def __str__(self):
        sep = os.path.sep
        if self.drive:
            return sep.join([self.drive] + list(self.parts)[1:])
        else:
            if not self._tail and self.root:
                return self.root
            elif self._tail:
                return sep.join(list(self.parts))
            else:
                return "."


class NewPath(Path):
    """
    NewPath is a subclass of PurePath.

    This class is a subclass of WindowsPath, and is used to create new instances of Path.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.cls = type(self)
        self._check_and_update_stat()


if __name__ == "__main__":
    pass
