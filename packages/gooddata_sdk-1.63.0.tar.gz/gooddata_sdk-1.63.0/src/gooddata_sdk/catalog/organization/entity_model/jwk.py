# (C) 2022 GoodData Corporation
from __future__ import annotations

from attrs import define
from gooddata_api_client.model.json_api_jwk_in import JsonApiJwkIn
from gooddata_api_client.model.json_api_jwk_in_attributes import JsonApiJwkInAttributes
from gooddata_api_client.model.json_api_jwk_in_attributes_content import JsonApiJwkInAttributesContent
from gooddata_api_client.model.json_api_jwk_in_document import JsonApiJwkInDocument

from gooddata_sdk.catalog.base import Base


@define(kw_only=True)
class CatalogJwkDocument(Base):
    data: CatalogJwk

    @staticmethod
    def client_class() -> type[JsonApiJwkInDocument]:
        return JsonApiJwkInDocument


@define(kw_only=True)
class CatalogJwk(Base):
    id: str
    attributes: CatalogJwkAttributes | None = None

    @staticmethod
    def client_class() -> type[JsonApiJwkIn]:
        return JsonApiJwkIn

    @classmethod
    def init(
        cls,
        jwk_id: str,
        rsa_spec: CatalogRsaSpecification | None = None,
    ) -> CatalogJwk:
        return cls(id=jwk_id, attributes=CatalogJwkAttributes(content=rsa_spec))


@define(kw_only=True)
class CatalogJwkAttributes(Base):
    content: CatalogRsaSpecification | None = None

    @staticmethod
    def client_class() -> type[JsonApiJwkInAttributes]:
        return JsonApiJwkInAttributes


@define(kw_only=True)
class CatalogRsaSpecification(Base):
    alg: str
    e: str
    kid: str
    kty: str
    n: str
    use: str
    x5c: list[str]
    x5t: str

    @staticmethod
    def client_class() -> type[JsonApiJwkInAttributesContent]:
        return JsonApiJwkInAttributesContent
