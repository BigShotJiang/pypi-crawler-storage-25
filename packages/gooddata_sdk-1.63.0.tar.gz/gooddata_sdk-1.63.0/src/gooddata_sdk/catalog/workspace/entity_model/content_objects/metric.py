# (C) 2022 GoodData Corporation
from __future__ import annotations

from typing import Any

from attrs import define
from gooddata_api_client.model.json_api_metric_out import JsonApiMetricOut

from gooddata_sdk.catalog.entity import AttrCatalogEntity
from gooddata_sdk.compute.model.metric import Metric, SimpleMetric
from gooddata_sdk.utils import safeget


@define(kw_only=True)
class CatalogMetric(AttrCatalogEntity):
    @staticmethod
    def client_class() -> Any:
        return JsonApiMetricOut

    @property
    def format(self) -> str | None:
        return safeget(self.json_api_attributes, ["content", "format"])

    @property
    def is_hidden(self) -> bool | None:
        return safeget(self.json_api_attributes, ["isHidden"])

    def as_computable(self) -> Metric:
        return SimpleMetric(local_id=self.id, item=self.obj_id)
