# (C) 2022 GoodData Corporation
from __future__ import annotations

from attrs import define
from gooddata_api_client.model.declarative_column import DeclarativeColumn

from gooddata_sdk.catalog.base import Base


@define(kw_only=True)
class CatalogDeclarativeColumn(Base):
    name: str
    data_type: str
    is_primary_key: bool | None = None
    referenced_table_id: str | None = None
    referenced_table_column: str | None = None
    is_nullable: bool | None = None
    null_value: str | None = None

    @staticmethod
    def client_class() -> type[DeclarativeColumn]:
        return DeclarativeColumn
