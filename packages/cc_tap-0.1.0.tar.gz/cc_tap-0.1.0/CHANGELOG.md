# Changelog

## [0.1.0] - Unreleased

### Added
- MCP server with session tools: list, read, send message, approve/deny tools
- Auto-authentication via macOS Keychain and plaintext credential fallback
- Protocol documentation (PROTOCOL.md)
- Reference Python client (scripts/ccr_client.py)
