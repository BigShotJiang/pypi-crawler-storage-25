"""cc-tap: MCP server bridging Claude Desktop to Claude Code sessions."""

try:
    from cc_tap._version import __version__
except ImportError:
    __version__ = "0.0.0-dev"
