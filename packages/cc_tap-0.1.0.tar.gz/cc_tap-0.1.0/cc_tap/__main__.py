"""Allow running as `python -m cc_tap`."""

from cc_tap.server import main

main()
