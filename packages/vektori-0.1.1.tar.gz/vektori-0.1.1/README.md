# Vektori Python SDK

> AI Memory that Actually Works — Graph-based memory for LLM applications.

## Installation

```bash
pip install vektori
```

## Quick Start

```python
from vektori import Vektori

# Cloud
memory = Vektori(api_key="vk_your_key")

# Self-hosted
memory = Vektori(url="http://localhost:8080")

# Store memories
memory.ingest(
    user_id="user_123",
    messages=[
        {"role": "user", "content": "I love pizza"},
        {"role": "assistant", "content": "Noted!"}
    ]
)

# Retrieve context
result = memory.retrieve(user_id="user_123", query="favorite food")
print(result.context)  # "User loves pizza"
```

## Documentation

Full documentation: [https://docs.vektori.cloud](https://docs.vektori.cloud)

## License

MIT
