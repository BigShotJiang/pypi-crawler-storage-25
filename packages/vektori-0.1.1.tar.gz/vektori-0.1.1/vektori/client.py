"""
Vektori Client - Main SDK entry point

Usage:
    # Cloud
    from vektori import Vektori
    memory = Vektori(api_key="vk_...")

    # Self-hosted
    memory = Vektori(url="http://localhost:8080")

    # Ingest
    memory.ingest(user_id="u1", messages=[{"role": "user", "content": "Hello"}])

    # Retrieve
    result = memory.retrieve(user_id="u1", query="What did the user say?")
    print(result.context)
"""

from typing import List, Optional, Union
import httpx

from vektori.models import (
    Message,
    IngestResponse,
    RetrieveResponse,
)


class VektoriError(Exception):
    """Base exception for Vektori SDK errors."""
    pass


class AuthenticationError(VektoriError):
    """Raised when API key is invalid or missing."""
    pass


class ValidationError(VektoriError):
    """Raised when request validation fails."""
    pass


class Vektori:
    """
    Vektori Memory Client.
    
    Connect to Vektori Cloud or a self-hosted instance to store and retrieve
    conversation memory for AI applications.
    
    Args:
        api_key: API key for Vektori Cloud (get one at vektori.cloud)
        url: URL of self-hosted Vektori server (e.g., "http://localhost:8080")
        timeout: Request timeout in seconds (default: 30)
    
    Example:
        >>> from vektori import Vektori
        >>> memory = Vektori(api_key="vk_...")
        >>> memory.ingest(user_id="u1", messages=[{"role": "user", "content": "I like pizza"}])
        >>> result = memory.retrieve(user_id="u1", query="What food does the user like?")
        >>> print(result.context)
        'User likes pizza'
    """
    
    DEFAULT_CLOUD_URL = "https://api.vektori.cloud"
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        url: Optional[str] = None,
        timeout: int = 30,
    ):
        if not api_key and not url:
            raise VektoriError(
                "Must provide either 'api_key' (for Cloud) or 'url' (for self-hosted)"
            )
        
        self.api_key = api_key
        self.base_url = url.rstrip("/") if url else self.DEFAULT_CLOUD_URL
        self.timeout = timeout
        
        # Build headers
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
        )
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self._client.close()
    
    def close(self):
        """Close the HTTP client."""
        self._client.close()
    
    def ingest(
        self,
        user_id: str,
        messages: List[Union[Message, dict]],
        session_id: Optional[str] = None,
    ) -> IngestResponse:
        """
        Ingest conversation messages into memory.
        
        Args:
            user_id: Unique identifier for the user
            messages: List of messages to ingest. Each message should have
                      'role' ("user" or "assistant") and 'content' (string).
            session_id: Optional session identifier. Auto-generated if not provided.
        
        Returns:
            IngestResponse with processing details
        
        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If request validation fails
            VektoriError: For other errors
        
        Example:
            >>> result = memory.ingest(
            ...     user_id="user_123",
            ...     messages=[
            ...         {"role": "user", "content": "I'm allergic to peanuts"},
            ...         {"role": "assistant", "content": "Noted!"}
            ...     ]
            ... )
            >>> print(f"Processed {result.processed.sentences} sentences")
        """
        # Convert Message objects to dicts
        msg_dicts = [
            m.model_dump() if isinstance(m, Message) else m
            for m in messages
        ]
        
        payload = {
            "user_id": user_id,
            "messages": msg_dicts,
        }
        if session_id:
            payload["session_id"] = session_id
        
        response = self._request("POST", "/v1/ingest", json=payload)
        return IngestResponse(**response)
    
    def retrieve(
        self,
        user_id: str,
        query: str,
        top_k: int = 10,
        include_raw: bool = False,
    ) -> RetrieveResponse:
        """
        Retrieve relevant context from memory.
        
        Args:
            user_id: Unique identifier for the user
            query: The query to search for relevant memories
            top_k: Maximum number of results to return (default: 10, max: 50)
            include_raw: Include raw facts/insights in response (default: False)
        
        Returns:
            RetrieveResponse with synthesized context and metadata
        
        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If request validation fails
            VektoriError: For other errors
        
        Example:
            >>> result = memory.retrieve(
            ...     user_id="user_123",
            ...     query="What are the user's dietary restrictions?"
            ... )
            >>> print(result.context)
            'User is allergic to peanuts'
        """
        payload = {
            "user_id": user_id,
            "query": query,
            "top_k": top_k,
            "include_raw": include_raw,
        }
        
        response = self._request("POST", "/v1/retrieve", json=payload)
        return RetrieveResponse(**response)
    
    def health(self) -> dict:
        """
        Check the health of the Vektori server.
        
        Returns:
            dict with status, version, and timestamp
        """
        return self._request("GET", "/v1/health")
    
    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make an HTTP request and handle errors."""
        try:
            response = self._client.request(method, path, **kwargs)
            
            if response.status_code == 401:
                raise AuthenticationError(
                    response.json().get("error", "Invalid API key")
                )
            
            if response.status_code == 400:
                data = response.json()
                raise ValidationError(
                    f"{data.get('error', 'Validation error')}: "
                    f"{data.get('details', '')}"
                )
            
            response.raise_for_status()
            return response.json()
            
        except httpx.HTTPStatusError as e:
            raise VektoriError(f"HTTP error: {e}")
        except httpx.RequestError as e:
            raise VektoriError(f"Request failed: {e}")


class AsyncVektori:
    """
    Async version of Vektori client.
    
    Usage:
        async with AsyncVektori(api_key="vk_...") as memory:
            await memory.ingest(user_id="u1", messages=[...])
            result = await memory.retrieve(user_id="u1", query="...")
    """
    
    DEFAULT_CLOUD_URL = "https://api.vektori.cloud"
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        url: Optional[str] = None,
        timeout: int = 30,
    ):
        if not api_key and not url:
            raise VektoriError(
                "Must provide either 'api_key' (for Cloud) or 'url' (for self-hosted)"
            )
        
        self.api_key = api_key
        self.base_url = url.rstrip("/") if url else self.DEFAULT_CLOUD_URL
        self.timeout = timeout
        
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
        )
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, *args):
        await self._client.aclose()
    
    async def close(self):
        """Close the HTTP client."""
        await self._client.aclose()
    
    async def ingest(
        self,
        user_id: str,
        messages: List[Union[Message, dict]],
        session_id: Optional[str] = None,
    ) -> IngestResponse:
        """
        Ingest conversation messages into memory.

        Args:
            user_id: Unique identifier for the user
            messages: List of messages to ingest. Each message should have
                      'role' ("user" or "assistant") and 'content' (string).
            session_id: Optional session identifier. Auto-generated if not provided.

        Returns:
            IngestResponse with processing details

        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If request validation fails
            VektoriError: For other errors

        Example:
            >>> result = await memory.ingest(
            ...     user_id="user_123",
            ...     messages=[
            ...         {"role": "user", "content": "I'm allergic to peanuts"},
            ...         {"role": "assistant", "content": "Noted!"}
            ...     ]
            ... )
            >>> print(f"Processed {result.processed.sentences} sentences")
        """
        msg_dicts = [
            m.model_dump() if isinstance(m, Message) else m
            for m in messages
        ]
        
        payload = {
            "user_id": user_id,
            "messages": msg_dicts,
        }
        if session_id:
            payload["session_id"] = session_id
        
        response = await self._request("POST", "/v1/ingest", json=payload)
        return IngestResponse(**response)
    
    async def retrieve(
        self,
        user_id: str,
        query: str,
        top_k: int = 10,
        include_raw: bool = False,
    ) -> RetrieveResponse:
        """
        Retrieve relevant context from memory.

        Args:
            user_id: Unique identifier for the user
            query: The query to search for relevant memories
            top_k: Maximum number of results to return (default: 10, max: 50)
            include_raw: Include raw facts/insights in response (default: False)

        Returns:
            RetrieveResponse with synthesized context and metadata

        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If request validation fails
            VektoriError: For other errors

        Example:
            >>> result = await memory.retrieve(
            ...     user_id="user_123",
            ...     query="What are the user's dietary restrictions?"
            ... )
            >>> print(result.context)
            'User is allergic to peanuts'
        """
        payload = {
            "user_id": user_id,
            "query": query,
            "top_k": top_k,
            "include_raw": include_raw,
        }
        
        response = await self._request("POST", "/v1/retrieve", json=payload)
        return RetrieveResponse(**response)
    
    async def health(self) -> dict:
        """Async version of health check."""
        return await self._request("GET", "/v1/health")
    
    async def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make an async HTTP request and handle errors."""
        try:
            response = await self._client.request(method, path, **kwargs)
            
            if response.status_code == 401:
                raise AuthenticationError(
                    response.json().get("error", "Invalid API key")
                )
            
            if response.status_code == 400:
                data = response.json()
                raise ValidationError(
                    f"{data.get('error', 'Validation error')}: "
                    f"{data.get('details', '')}"
                )
            
            response.raise_for_status()
            return response.json()
            
        except httpx.HTTPStatusError as e:
            raise VektoriError(f"HTTP error: {e}")
        except httpx.RequestError as e:
            raise VektoriError(f"Request failed: {e}")
