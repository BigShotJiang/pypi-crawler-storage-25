"""
Pydantic models for Vektori SDK
"""

from typing import Optional, List, Literal
from pydantic import BaseModel, Field


class Message(BaseModel):
    """A single message in a conversation."""
    role: Literal["user", "assistant"]
    content: str
    timestamp: Optional[str] = None  # ISO8601 format


class ProcessedCounts(BaseModel):
    """Counts of processed items from ingestion."""
    messages: int
    sentences: int
    facts: int
    insights: int
    summary: bool


class IngestResponse(BaseModel):
    """Response from the ingest endpoint."""
    success: bool
    session_id: str
    processed: ProcessedCounts
    latency_ms: int
    errors: Optional[List[str]] = None


class RawItem(BaseModel):
    """A single raw result item."""
    id: str
    score: float
    text: Optional[str] = None


class RawResults(BaseModel):
    """Raw retrieval results (when include_raw=True)."""
    facts: List[RawItem] = Field(default_factory=list)
    insights: List[RawItem] = Field(default_factory=list)
    sentences: List[RawItem] = Field(default_factory=list)


class SourceMetadata(BaseModel):
    """Metadata about source counts in retrieval."""
    sentences: int
    facts: int
    insights: int
    summaries: int


class RetrieveMetadata(BaseModel):
    """Metadata about the retrieval operation."""
    sources: SourceMetadata
    vector_latency_ms: Optional[int] = None
    ppr_latency_ms: Optional[int] = None
    synthesis_used: Optional[bool] = None


class RetrieveResponse(BaseModel):
    """Response from the retrieve endpoint."""
    context: str
    latency_ms: int
    metadata: RetrieveMetadata
    raw: Optional[RawResults] = None
