"""
Vektori - AI Memory that Actually Works

Graph-based memory for LLM applications with sentence-level retrieval and Personalized PageRank.
"""

from importlib.metadata import version, PackageNotFoundError

from vektori.client import Vektori, AsyncVektori, VektoriError, AuthenticationError, ValidationError
from vektori.models import (
    IngestResponse,
    RetrieveResponse,
    Message,
    RawResults,
    SourceMetadata,
)

try:
    __version__ = version("vektori")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = [
    "Vektori",
    "AsyncVektori",
    "VektoriError",
    "AuthenticationError",
    "ValidationError",
    "IngestResponse",
    "RetrieveResponse",
    "Message",
    "RawResults",
    "SourceMetadata",
]
