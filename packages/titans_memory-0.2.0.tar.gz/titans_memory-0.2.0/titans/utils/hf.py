import torch
from transformers import PreTrainedModel, PretrainedConfig
from titans import TitansMAC, TitansMAG, TitansMAL, TitansLMM
from titans.utils import TitansConfig

class TitansHFConfig(PretrainedConfig):
    model_type = "titans"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        for key, value in kwargs.items():
            setattr(self, key, value)

class TitansModelForCausalLM(PreTrainedModel):
    config_class = TitansHFConfig
    
    def __init__(self, config):
        super().__init__(config)
        # Map HF config to TitansConfig
        t_cfg = TitansConfig(
            vocab_size=config.vocab_size,
            d_model=config.d_model,
            n_layers=config.n_layers,
            n_heads=config.n_heads,
            mem_layers=config.mem_layers,
            # ... add other fields as needed
        )
        self.variant = getattr(config, "variant", "MAC")
        
        if self.variant == "MAC": self.model = TitansMAC(t_cfg)
        elif self.variant == "MAG": self.model = TitansMAG(t_cfg)
        elif self.variant == "MAL": self.model = TitansMAL(t_cfg)
        else: self.model = TitansLMM(t_cfg)

    def forward(self, input_ids, labels=None, **kwargs):
        return self.model(input_ids, labels=labels)

    def generate(self, *args, **kwargs):
        return self.model.generate(*args, **kwargs)
