from __future__ import annotations

import re


class ComplexityScorer:
    """
    Rule-based query complexity scorer. No inference. No external calls.
    Returns a score in [0.0, 1.0] — higher means more complex.

    Weights are tuned so that strong domain signals (math, code) dominate
    over weak proxies (token count, negation).
    """

    # Precompiled at class level — zero cost per call
    _MATH_RE = re.compile(
        r'[\$\^\_\{\}]|\\[a-zA-Z]+|\b(integral|derivative|matrix|eigenvalue|gradient|divergence)\b',
        re.IGNORECASE,
    )
    _CODE_RE = re.compile(
        r'```|\bdef \b|\bclass \b|\bimport \b|#include|function\s*\(|=>\s*\{',
    )
    _DEPTH_RE = re.compile(
        r'\b(why|explain|derive|prove|compare|contrast|analyze|critique|formalize)\b',
        re.IGNORECASE,
    )
    _NEGATION_RE = re.compile(
        r'\b(not|without|except|unless|neither|nor|never)\b',
        re.IGNORECASE,
    )

    # Weights sum to 1.0. Strong domain signals outweigh weak proxies.
    _WEIGHTS = {
        "math":     0.25,
        "code":     0.25,
        "depth":    0.20,
        "tokens":   0.15,
        "entities": 0.10,
        "negation": 0.05,
    }

    @classmethod
    def score(cls, query: str) -> float:
        tokens = query.split()
        n = len(tokens)

        math_score     = min(len(cls._MATH_RE.findall(query)) / 4, 1.0)
        code_score     = min(len(cls._CODE_RE.findall(query)) / 3, 1.0)
        depth_score    = min(len(cls._DEPTH_RE.findall(query)) / 3, 1.0)
        token_score    = min(n / 400, 1.0)
        negation_score = min(len(cls._NEGATION_RE.findall(query)) / 4, 1.0)

        # Crude entity count: capitalized non-first words longer than 2 chars.
        # Intentionally simple — avoids NLP dependency while capturing proper nouns.
        entity_hits = sum(
            1 for w in tokens[1:] if len(w) > 2 and w[0].isupper() and w.isalpha()
        )
        entity_score = min(entity_hits / 8, 1.0)

        w = cls._WEIGHTS
        return (
            w["math"]     * math_score
            + w["code"]     * code_score
            + w["depth"]    * depth_score
            + w["tokens"]   * token_score
            + w["entities"] * entity_score
            + w["negation"] * negation_score
        )
