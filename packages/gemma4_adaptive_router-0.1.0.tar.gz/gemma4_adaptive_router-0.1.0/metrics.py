from __future__ import annotations

from prometheus_client import Counter, Gauge, Histogram

router_decisions_total = Counter(
    "router_decisions_total",
    "Total routing decisions by tier",
    ["tier"],
)

router_complexity_score = Histogram(
    "router_complexity_score",
    "Distribution of query complexity scores",
    buckets=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
)

router_vram_free_gb = Gauge(
    "router_vram_free_gb",
    "GPU VRAM free at time of routing decision (GB)",
)

router_tier_high_ema_ms = Gauge(
    "router_tier_high_ema_ms",
    "Exponential moving average of tier_high request latency (ms)",
)


def record_decision(
    tier: str,
    complexity_score: float,
    vram_free_gb: float,
    ema_ms: float,
) -> None:
    """Update all router metrics in a single call. Keeps the router decoupled from metric objects."""
    router_decisions_total.labels(tier=tier).inc()
    router_complexity_score.observe(complexity_score)
    router_vram_free_gb.set(vram_free_gb)
    router_tier_high_ema_ms.set(ema_ms)
