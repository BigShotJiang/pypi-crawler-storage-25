from __future__ import annotations

from unittest.mock import PropertyMock, patch

import pytest

from adaptive_router.router import AdaptiveRouter, RouterState, RoutingConfig


@pytest.fixture
def config() -> RoutingConfig:
    return RoutingConfig(
        complexity_threshold=0.65,
        vram_headroom_gb=1.5,
        latency_sla_ms=2000.0,
    )


@pytest.fixture
def router(config: RoutingConfig) -> AdaptiveRouter:  # type: ignore[misc]
    with patch("adaptive_router.vram_monitor.pynvml"):
        r = AdaptiveRouter(config)
        yield r
        r.shutdown()


def _patch_vram(router: AdaptiveRouter, free_gb: float):  # type: ignore[no-untyped-def]
    """Patch VRAMState.free_gb without touching private attributes."""
    return patch.object(
        type(router._vram_state), "free_gb", new_callable=PropertyMock, return_value=free_gb
    )


def test_simple_query_routes_to_low_tier(router: AdaptiveRouter) -> None:
    assert router.route("what time is it") == "tier_low"


def test_complex_query_with_vram_routes_to_high(router: AdaptiveRouter) -> None:
    with _patch_vram(router, free_gb=6.0):
        # Query with explicit code blocks + LaTeX math + depth keywords — all three
        # dominant complexity dimensions fire, pushing score well above the 0.65 threshold.
        query = (
            "```python\ndef compute_eigenvalues(A):\n    return np.linalg.eig(A)\n```\n"
            "Prove that eigenvalue $\\lambda$ satisfies $\\det(A - \\lambda I) = 0$. "
            "Derive the characteristic polynomial and explain why convergence holds."
        )
        assert router.route(query) == "tier_high"


def test_complex_query_without_vram_falls_back(router: AdaptiveRouter) -> None:
    with _patch_vram(router, free_gb=0.8):
        query = "Implement a lock-free concurrent hash map in Rust with proofs of correctness"
        assert router.route(query) == "tier_low"


def test_sla_breach_routes_to_low_tier(router: AdaptiveRouter) -> None:
    with _patch_vram(router, free_gb=6.0):
        for _ in range(20):
            router.observe("tier_high", 3500.0)
        query = "Derive the Euler-Lagrange equations from the principle of least action"
        assert router.route(query) == "tier_low"


def test_observe_ema_converges(router: AdaptiveRouter) -> None:
    for _ in range(30):
        router.observe("tier_high", 1000.0)
    assert abs(router._latency_ema["tier_high"] - 1000.0) < 100.0


def test_custom_rule_overrides_defaults(config: RoutingConfig) -> None:
    """Custom rules list is used verbatim — default_rules() is not injected."""
    always_low: list = [lambda q, s: "tier_low"]
    with patch("adaptive_router.vram_monitor.pynvml"):
        r = AdaptiveRouter(config, rules=always_low)
        assert r.route("Prove the Riemann hypothesis step by step") == "tier_low"
        r.shutdown()


def test_vram_monitor_updates_state(router: AdaptiveRouter) -> None:
    # With pynvml mocked, the monitor thread runs but returns MagicMock values.
    # The important invariant is that the monitor thread is alive and the
    # VRAMState is accessible. Value correctness is covered in test_vram_monitor.py.
    assert router._monitor.is_alive()


def test_rule_chain_falls_through_to_tier_high(config: RoutingConfig) -> None:
    """When all rules abstain (return None), default is tier_high."""
    no_op_rules: list = [lambda q, s: None, lambda q, s: None]
    with patch("adaptive_router.vram_monitor.pynvml"):
        r = AdaptiveRouter(config, rules=no_op_rules)
        assert r.route("any query") == "tier_high"
        r.shutdown()


def test_router_state_immutable() -> None:
    state = RouterState(complexity_score=0.5, vram_free_gb=8.0, tier_high_ema_ms=500.0)
    with pytest.raises((AttributeError, TypeError)):
        state.complexity_score = 0.9  # type: ignore[misc]
