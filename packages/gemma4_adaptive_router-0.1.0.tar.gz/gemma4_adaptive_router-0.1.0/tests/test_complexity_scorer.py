from __future__ import annotations

import re

import pytest

from adaptive_router.complexity_scorer import ComplexityScorer


@pytest.mark.parametrize("query", [
    "",
    "hi",
    "what time is it",
    "x " * 400,  # long but trivial
])
def test_score_always_in_unit_interval(query: str) -> None:
    score = ComplexityScorer.score(query)
    assert 0.0 <= score <= 1.0


def test_simple_query_scores_below_threshold() -> None:
    score = ComplexityScorer.score("what time is it")
    assert score < 0.65, f"Expected < 0.65, got {score}"


def test_math_query_scores_high() -> None:
    # Uses explicit LaTeX syntax ($, \int, \infty, \sqrt, \pi) and depth keywords
    # so all three dominant dimensions (math, depth) fire clearly.
    query = (
        "Derive the integral $\\int_0^\\infty e^{-x^2} dx$ via Gaussian integration. "
        "Prove it equals $\\sqrt{\\pi}/2$ and explain the connection to the $\\Gamma$ function."
    )
    score = ComplexityScorer.score(query)
    assert score >= 0.40, f"Expected >= 0.40, got {score}"


def test_code_query_scores_high() -> None:
    query = "Implement a lock-free concurrent hash map:\n```python\ndef insert(self, key, value): ...\n```"
    score = ComplexityScorer.score(query)
    assert score >= 0.25, f"Expected >= 0.25, got {score}"


def test_depth_keyword_scores_higher_than_simple() -> None:
    simple_score = ComplexityScorer.score("what is a matrix")
    depth_score = ComplexityScorer.score("explain and derive the properties of an eigenvalue matrix")
    assert depth_score > simple_score


def test_score_is_deterministic() -> None:
    query = "Why does gradient descent converge for convex functions? Prove it formally."
    scores = [ComplexityScorer.score(query) for _ in range(10)]
    assert len(set(scores)) == 1, "score() must be deterministic"


def test_regex_patterns_are_precompiled() -> None:
    assert isinstance(ComplexityScorer._MATH_RE, type(re.compile("")))
    assert isinstance(ComplexityScorer._CODE_RE, type(re.compile("")))
    assert isinstance(ComplexityScorer._DEPTH_RE, type(re.compile("")))
    assert isinstance(ComplexityScorer._NEGATION_RE, type(re.compile("")))


def test_weights_sum_to_one() -> None:
    total = sum(ComplexityScorer._WEIGHTS.values())
    assert abs(total - 1.0) < 1e-9, f"Weights must sum to 1.0, got {total}"


def test_entity_count_contributes() -> None:
    no_entities = ComplexityScorer.score("explain matrix properties")
    with_entities = ComplexityScorer.score("explain Riemann Hypothesis Fermat Lagrange Euler matrix properties")
    assert with_entities >= no_entities
