from __future__ import annotations

import threading
import time
from unittest.mock import MagicMock, patch

from adaptive_router.vram_monitor import VRAMMonitor, VRAMState


def test_vram_state_defaults() -> None:
    state = VRAMState()
    assert state.free_gb == 16.0
    assert state.used_gb == 0.0
    assert state.gpu_util_pct == 0


def test_vram_state_update() -> None:
    state = VRAMState()
    state.update(free_gb=6.5, used_gb=9.5, util_pct=72)
    assert state.free_gb == 6.5
    assert state.used_gb == 9.5
    assert state.gpu_util_pct == 72


def test_vram_state_thread_safety() -> None:
    state = VRAMState()
    errors: list[Exception] = []

    def writer(n: int) -> None:
        try:
            for _ in range(100):
                state.update(free_gb=float(n), used_gb=float(16 - n), util_pct=n % 100)
        except Exception as exc:
            errors.append(exc)

    def reader() -> None:
        try:
            for _ in range(200):
                _ = state.free_gb
                _ = state.gpu_util_pct
        except Exception as exc:
            errors.append(exc)

    threads = [threading.Thread(target=writer, args=(i,)) for i in range(5)]
    threads += [threading.Thread(target=reader) for _ in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors, f"Thread-safety violations: {errors}"


def test_vram_monitor_updates_state() -> None:
    with patch("adaptive_router.vram_monitor.pynvml") as mock_nvml:
        mock_mem = MagicMock()
        mock_mem.free = 8_000_000_000
        mock_mem.used = 8_000_000_000
        mock_nvml.nvmlDeviceGetMemoryInfo.return_value = mock_mem

        mock_util = MagicMock()
        mock_util.gpu = 45
        mock_nvml.nvmlDeviceGetUtilizationRates.return_value = mock_util

        state = VRAMState()
        monitor = VRAMMonitor(state, poll_interval_ms=5, device_index=0)
        monitor.start()
        time.sleep(0.05)
        monitor.stop()

        assert abs(state.free_gb - 8.0) < 0.1
        assert state.gpu_util_pct == 45


def test_vram_monitor_stops_cleanly() -> None:
    with patch("adaptive_router.vram_monitor.pynvml"):
        state = VRAMState()
        monitor = VRAMMonitor(state, poll_interval_ms=10)
        monitor.start()
        assert monitor.is_alive()
        monitor.stop()
        assert not monitor.is_alive(), "monitor.stop() must join the thread"


def test_vram_monitor_is_daemon() -> None:
    assert VRAMMonitor.daemon is True, "VRAMMonitor must be a daemon thread"
