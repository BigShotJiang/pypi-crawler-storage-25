from __future__ import annotations

from dataclasses import fields
from pathlib import Path

import yaml

from adaptive_router.router import RoutingConfig

DEFAULT_CONFIG_PATH = Path.home() / ".config" / "gemma4-router" / "config.yaml"


def load_config(path: str | Path) -> RoutingConfig:
    """Load RoutingConfig from a YAML file. Unknown keys are silently ignored."""
    data = yaml.safe_load(Path(path).read_text())
    if not isinstance(data, dict):
        raise ValueError(f"Config file must be a YAML mapping, got: {type(data)}")
    known = {f.name for f in fields(RoutingConfig)}
    filtered = {k: v for k, v in data.items() if k in known}
    return RoutingConfig(**filtered)


def dump_default_config(path: str | Path | None = None) -> str:
    """Serialize default RoutingConfig to YAML. Optionally write to path."""
    config = RoutingConfig()
    doc = {f.name: getattr(config, f.name) for f in fields(config)}
    text = yaml.dump(doc, default_flow_style=False, sort_keys=False)
    if path is not None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text)
    return text
