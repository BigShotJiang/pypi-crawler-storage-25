from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Protocol, runtime_checkable

from adaptive_router.complexity_scorer import ComplexityScorer
from adaptive_router.vram_monitor import VRAMMonitor, VRAMState

_EMA_ALPHA = 0.2


@dataclass
class RoutingConfig:
    complexity_threshold: float = 0.65
    vram_headroom_gb: float = 1.5
    latency_sla_ms: float = 2000.0
    vram_poll_interval_ms: int = 15
    # Set to your expected p50 tier_high latency for a safer cold start.
    # At 0.0 (default), the EMA starts optimistic: all complex queries hit
    # tier_high until enough observations accumulate. See KNOWN LIMITATIONS.
    sla_warmup_seed_ms: float = 0.0


@dataclass(frozen=True)
class RouterState:
    complexity_score: float
    vram_free_gb: float
    tier_high_ema_ms: float


@runtime_checkable
class RoutingRule(Protocol):
    """
    A single routing predicate. Return the decided tier, or None to abstain
    and let the next rule in the chain decide.
    """

    def __call__(
        self, query: str, state: RouterState
    ) -> Literal["tier_high", "tier_low"] | None: ...


def complexity_rule(config: RoutingConfig) -> RoutingRule:
    def rule(
        query: str, state: RouterState
    ) -> Literal["tier_high", "tier_low"] | None:
        return "tier_low" if state.complexity_score < config.complexity_threshold else None

    return rule  # type: ignore[return-value]


def vram_rule(config: RoutingConfig) -> RoutingRule:
    def rule(
        query: str, state: RouterState
    ) -> Literal["tier_high", "tier_low"] | None:
        return "tier_low" if state.vram_free_gb < config.vram_headroom_gb else None

    return rule  # type: ignore[return-value]


def sla_rule(config: RoutingConfig) -> RoutingRule:
    def rule(
        query: str, state: RouterState
    ) -> Literal["tier_high", "tier_low"] | None:
        return "tier_low" if state.tier_high_ema_ms > config.latency_sla_ms else None

    return rule  # type: ignore[return-value]


def default_rules(config: RoutingConfig) -> list[RoutingRule]:
    return [complexity_rule(config), vram_rule(config), sla_rule(config)]


class AdaptiveRouter:
    """
    Routes LLM requests to local model tiers.

    Rules are evaluated in order; the first non-None decision wins.
    Inject a custom rules list to extend or override default behavior
    without subclassing or modifying this class.
    """

    def __init__(
        self,
        config: RoutingConfig,
        rules: list[RoutingRule] | None = None,
    ) -> None:
        self.config = config
        self._rules = rules if rules is not None else default_rules(config)
        self._vram_state = VRAMState()
        self._monitor = VRAMMonitor(self._vram_state, config.vram_poll_interval_ms)
        self._latency_ema: dict[str, float] = {
            "tier_high": config.sla_warmup_seed_ms,
            "tier_low": 0.0,
        }
        self._monitor.start()

    def route(self, query: str) -> Literal["tier_high", "tier_low"]:
        state = RouterState(
            complexity_score=ComplexityScorer.score(query),
            vram_free_gb=self._vram_state.free_gb,
            tier_high_ema_ms=self._latency_ema["tier_high"],
        )
        for rule in self._rules:
            decision = rule(query, state)
            if decision is not None:
                return decision
        return "tier_high"

    def observe(self, tier: Literal["tier_high", "tier_low"], latency_ms: float) -> None:
        """Report observed request latency so sla_rule can enforce the SLA."""
        prev = self._latency_ema[tier]
        self._latency_ema[tier] = _EMA_ALPHA * latency_ms + (1 - _EMA_ALPHA) * prev

    def shutdown(self) -> None:
        self._monitor.stop()
