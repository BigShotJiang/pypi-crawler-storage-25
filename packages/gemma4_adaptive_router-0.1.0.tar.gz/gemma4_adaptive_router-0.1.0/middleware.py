"""FastAPI ASGI proxy that sits in front of your LLM endpoints.

Run standalone:
    python -m adaptive_router.middleware \
        --tier-high-url http://llama-cpp:8080/v1 \
        --tier-low-url  http://vllm:8000/v1 \
        --port 9000
"""
from __future__ import annotations

import argparse
import time
from typing import Any

import httpx
import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.responses import StreamingResponse

from adaptive_router.metrics import record_decision
from adaptive_router.router import AdaptiveRouter, RoutingConfig


def _extract_query(body: dict[str, Any]) -> str:
    """Pull the last user message text from an OpenAI-style chat completions body."""
    messages = body.get("messages", [])
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            # Multimodal: extract text parts only
            if isinstance(content, list):
                return " ".join(
                    part.get("text", "") for part in content if part.get("type") == "text"
                )
    return ""


def create_app(
    config: RoutingConfig,
    tier_high_url: str,
    tier_low_url: str,
) -> FastAPI:
    app = FastAPI(title="gemma4-adaptive-router", version="0.1.0")
    router = AdaptiveRouter(config)
    client = httpx.AsyncClient(timeout=120.0)

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/metrics")
    async def metrics() -> Response:
        from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
        return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request) -> Response:
        body = await request.json()
        query = _extract_query(body)

        t0 = time.monotonic()
        tier = router.route(query)
        target_url = tier_high_url if tier == "tier_high" else tier_low_url

        record_decision(
            tier=tier,
            complexity_score=router._vram_state.free_gb,  # triggers a state read for metrics
            vram_free_gb=router._vram_state.free_gb,
            ema_ms=router._latency_ema["tier_high"],
        )

        headers = {k: v for k, v in request.headers.items() if k.lower() != "host"}
        upstream_resp = await client.post(
            f"{target_url}/chat/completions",
            json=body,
            headers=headers,
        )

        latency_ms = (time.monotonic() - t0) * 1000
        router.observe(tier, latency_ms)

        if upstream_resp.headers.get("content-type", "").startswith("text/event-stream"):
            return StreamingResponse(
                upstream_resp.aiter_bytes(),
                status_code=upstream_resp.status_code,
                headers=dict(upstream_resp.headers),
                media_type="text/event-stream",
            )

        return Response(
            content=upstream_resp.content,
            status_code=upstream_resp.status_code,
            headers=dict(upstream_resp.headers),
        )

    @app.on_event("shutdown")
    async def shutdown() -> None:
        router.shutdown()
        await client.aclose()

    return app


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Gemma 4 Adaptive Router proxy")
    p.add_argument("--tier-high-url", default="http://llama-cpp:8080/v1")
    p.add_argument("--tier-low-url", default="http://vllm:8000/v1")
    p.add_argument("--port", type=int, default=9000)
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--complexity-threshold", type=float, default=0.65)
    p.add_argument("--vram-headroom-gb", type=float, default=1.5)
    p.add_argument("--latency-sla-ms", type=float, default=2000.0)
    p.add_argument("--sla-warmup-seed-ms", type=float, default=0.0)
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    config = RoutingConfig(
        complexity_threshold=args.complexity_threshold,
        vram_headroom_gb=args.vram_headroom_gb,
        latency_sla_ms=args.latency_sla_ms,
        sla_warmup_seed_ms=args.sla_warmup_seed_ms,
    )
    app = create_app(config, args.tier_high_url, args.tier_low_url)
    uvicorn.run(app, host=args.host, port=args.port)
