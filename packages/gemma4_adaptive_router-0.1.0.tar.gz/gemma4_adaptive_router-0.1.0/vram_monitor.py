from __future__ import annotations

import threading
import time

import pynvml


class VRAMState:
    """Thread-safe VRAM snapshot. Properties acquire the lock internally."""

    __slots__ = ("_lock", "_free_gb", "_used_gb", "_gpu_util_pct")

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._free_gb: float = 16.0
        self._used_gb: float = 0.0
        self._gpu_util_pct: int = 0

    @property
    def free_gb(self) -> float:
        with self._lock:
            return self._free_gb

    @property
    def used_gb(self) -> float:
        with self._lock:
            return self._used_gb

    @property
    def gpu_util_pct(self) -> int:
        with self._lock:
            return self._gpu_util_pct

    def update(self, free_gb: float, used_gb: float, util_pct: int) -> None:
        with self._lock:
            self._free_gb = free_gb
            self._used_gb = used_gb
            self._gpu_util_pct = util_pct


class VRAMMonitor(threading.Thread):
    """
    Background thread polling GPU VRAM via pynvml — no subprocess overhead.
    Updates VRAMState atomically for the router to read.
    """

    daemon = True

    def __init__(
        self,
        state: VRAMState,
        poll_interval_ms: int = 15,
        device_index: int = 0,
    ) -> None:
        super().__init__()
        self.state = state
        self.interval = poll_interval_ms / 1000
        self.device_index = device_index
        self._stop_event = threading.Event()

    def run(self) -> None:
        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(self.device_index)
        try:
            while not self._stop_event.is_set():
                mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
                util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                self.state.update(
                    free_gb=mem.free / 1e9,
                    used_gb=mem.used / 1e9,
                    util_pct=util.gpu,
                )
                time.sleep(self.interval)
        finally:
            pynvml.nvmlShutdown()

    def stop(self) -> None:
        self._stop_event.set()
        self.join()
