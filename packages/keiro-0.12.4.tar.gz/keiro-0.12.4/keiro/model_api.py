"""Prompt-first hosted model facade for lightweight external use.

This mirrors the ergonomic parts of ``ember.api.models`` without pulling in
the full Ember runtime. The facade uses the hosted Keiro gateway underneath.
"""

from __future__ import annotations

import copy
import json
import logging
import time
from collections.abc import Callable, Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from keiro._internal.errors import ProviderAPIError
from keiro._internal.openai_responses import (
    merge_payload_instructions as _merge_payload_instructions,
)
from keiro._internal.stream_protocol import ClientStreamPayload
from keiro.client import Client, KeirError, KeirValidationError
from keiro.protocol import ParsedResponse, parse_response

LOG = logging.getLogger(__name__)


def _stringify_json(value: object) -> str:
    if isinstance(value, str):
        return value
    if value is None:
        return ""
    try:
        return json.dumps(value, ensure_ascii=False)
    except TypeError:
        return str(value)


def _content_to_text(content: object) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, bytes):
        return content.decode("utf-8", errors="ignore")
    if isinstance(content, Mapping):
        if content.get("text") is not None:
            return _stringify_json(content.get("text"))
        if content.get("content") is not None:
            return _content_to_text(content.get("content"))
        if content.get("output") is not None:
            return _stringify_json(content.get("output"))
        return _stringify_json(content)
    if isinstance(content, Sequence) and not isinstance(content, (str, bytes, bytearray)):
        return "".join(_content_to_text(part) for part in content)
    if content is None:
        return ""
    return str(content)


def _part_to_text(part: Mapping[str, Any]) -> str:
    if part.get("text") is not None:
        return _stringify_json(part.get("text"))
    if part.get("output") is not None:
        return _stringify_json(part.get("output"))
    if part.get("content") is not None:
        return _content_to_text(part.get("content"))
    return ""


def _extract_response_text(
    raw_response: Mapping[str, Any],
    parsed: ParsedResponse | None = None,
) -> str:
    if parsed is None:
        parsed = parse_response(raw_response)
    if parsed.text:
        return parsed.text

    choices = raw_response.get("choices")
    if isinstance(choices, Sequence) and not isinstance(choices, (str, bytes, bytearray)):
        for choice in choices:
            if not isinstance(choice, Mapping):
                continue
            message = choice.get("message")
            if isinstance(message, Mapping):
                text = _content_to_text(message.get("content"))
                if text:
                    return text
    return ""


def _usage_dict(parsed: ParsedResponse) -> dict[str, Any]:
    usage = parsed.usage
    return {
        "input_tokens": usage.input_tokens,
        "output_tokens": usage.output_tokens,
        "total_tokens": usage.total_tokens,
        "reasoning_tokens": usage.reasoning_tokens,
        "cost_usd": usage.cost_usd,
        "actual_cost_usd": usage.actual_cost_usd,
    }


def _normalized_context(context: Sequence[Mapping[str, Any]] | None) -> list[dict[str, Any]]:
    if context is None:
        return []
    if isinstance(context, (str, bytes, bytearray)):
        raise KeirValidationError(
            "'context' must be a list of message dicts, not a string.",
            code="invalid_context_type",
        )

    normalized: list[dict[str, Any]] = []
    for index, item in enumerate(context):
        if not isinstance(item, Mapping):
            raise KeirValidationError(
                f"context[{index}] must be a dict, got {type(item).__name__}.",
                code="invalid_context_entry",
            )
        normalized.append(copy.deepcopy(dict(item)))
    return normalized


def _build_prompt_messages(
    prompt: str,
    *,
    system: str | None,
    context: Sequence[Mapping[str, Any]] | None,
) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    if system is not None:
        messages.append({"role": "system", "content": str(system)})

    messages.extend(_normalized_context(context))
    if prompt:
        messages.append({"role": "user", "content": prompt})
    return messages


def _merge_keiro_instructions(
    request_payload: dict[str, Any],
    *,
    instructions: object | None,
    source: str,
    model: str,
) -> None:
    """Merge instructions into a Responses payload; map provider errors to Keir."""
    try:
        _merge_payload_instructions(
            request_payload,
            instructions,
            model=model,
            source=source,
        )
    except ProviderAPIError as exc:
        raise KeirValidationError(
            f"Cannot combine conflicting instructions with {source}.",
            code="conflicting_arguments",
        ) from exc


def _merge_responses_system_alias(
    request_payload: dict[str, Any],
    *,
    system: object | None,
    model: str,
) -> None:
    if system is None:
        return
    system_text = system if isinstance(system, str) else str(system)
    _merge_keiro_instructions(
        request_payload,
        instructions=system_text,
        source="'system'",
        model=model,
    )


def _has_chat_completions_tool_format(messages: Sequence[Mapping[str, Any]]) -> bool:
    return any(
        message.get("role") == "tool"
        or message.get("tool_calls") is not None
        or message.get("tool_call_id") is not None
        for message in messages
    )


def _is_sse_sentinel(text: str) -> bool:
    """Return True if *text* is the SSE ``[DONE]`` termination marker.

    This is a defense-in-depth check: the SSE parser in ``client.py``
    should filter ``[DONE]`` before it reaches higher layers, but if a
    variant encoding (extra whitespace, mixed case) slips through, this
    guard prevents the sentinel from being yielded as user-visible text.
    """
    return text.strip().upper() == "[DONE]"


def _extract_stream_text(
    event: Mapping[str, Any],
    *,
    include_reasoning: bool = False,
) -> str:
    """Extract plain text from a streaming event.

    Handles three formats:
    - Responses API text deltas (``response.output_text.delta``)
    - Custom ``delta`` events with a ``text`` field
    - Chat Completions deltas (``choices[].delta.content``)

    All other Responses API lifecycle events (``response.created``,
    ``response.completed``, etc.) are explicitly skipped.

    Args:
        event: A single streaming event dict.
        include_reasoning: When True, emit reasoning summary deltas as
            dim ANSI text (for admin mode). When False, suppress them.
    """
    event_type = ClientStreamPayload.from_mapping(event).effective_type

    # Responses API text delta — the only event carrying user-visible text.
    if event_type == "response.output_text.delta":
        text = _content_to_text(event.get("delta"))
        if _is_sse_sentinel(text):
            return ""
        return text

    # Reasoning summary deltas — show dimmed in admin mode, hide otherwise.
    if event_type == "response.reasoning_summary_text.delta":
        if include_reasoning:
            text = str(event.get("delta", ""))
            if text:
                return f"\033[2m{text}\033[0m"
        return ""

    # Custom "delta" event with a "text" field (gateway SSE format).
    # The gateway wraps Responses API events inside delta.text as JSON
    # strings — unwrap and only extract text from output_text.delta.
    if event_type == "delta":
        raw_text = event.get("text")
        if isinstance(raw_text, str) and _is_sse_sentinel(raw_text):
            return ""
        if isinstance(raw_text, str) and raw_text.startswith("{"):
            try:
                inner = json.loads(raw_text)
                if isinstance(inner, dict):
                    inner_type = inner.get("type", "")
                    if inner_type == "response.output_text.delta":
                        return str(inner.get("delta", ""))
                    if inner_type == "response.reasoning_summary_text.delta":
                        if include_reasoning:
                            text = str(inner.get("delta", ""))
                            if text:
                                return f"\033[2m{text}\033[0m"
                        return ""
                    # All other parsed JSON events carry no
                    # user-visible text.
                    return ""
            except (json.JSONDecodeError, TypeError):
                pass
        return _content_to_text(raw_text)

    # Defensive fallback: extract text from response.completed events
    # that embed the full response payload with output text.  This
    # handles gateways that return the text only in the completed event
    # (e.g., sync-to-stream conversion without proper delta injection).
    if event_type == "response.completed":
        resp_obj = event.get("response")
        if isinstance(resp_obj, Mapping):
            return _extract_response_text(resp_obj)
        return ""

    # Surface error events instead of silently dropping them.
    # Layer 1 (_iter_parsed_sse in client.py) should catch these first,
    # but this is a defensive fallback in case the event slips through.
    # The gateway may use either "response.error" or bare "error".
    if event_type in ("response.error", "error"):
        error_obj = event.get("error")
        msg = "Streaming error (no details provided by server)."
        error_type: str | None = None
        code: str | None = None
        if isinstance(error_obj, Mapping):
            raw_msg = error_obj.get("message")
            if isinstance(raw_msg, str) and raw_msg:
                msg = raw_msg
            error_type = error_obj.get("type")
            raw_code = error_obj.get("code")
            if raw_code is not None:
                code = str(raw_code)
        raise KeirError(
            msg,
            status_code=502,
            error_type=error_type,
            code=code,
        )

    # Skip all other Responses API lifecycle events. These carry metadata
    # (response objects, item status, usage) but no user-visible text.
    if isinstance(event_type, str) and event_type.startswith("response."):
        return ""

    # Chat Completions format: choices[].delta.content (always a string).
    choices = event.get("choices")
    if isinstance(choices, Sequence) and not isinstance(choices, (str, bytes, bytearray)):
        for choice in choices:
            if not isinstance(choice, Mapping):
                continue
            delta = choice.get("delta")
            if isinstance(delta, Mapping):
                content = delta.get("content")
                if isinstance(content, str) and content:
                    if _is_sse_sentinel(content):
                        return ""
                    return content
    return ""


_MAX_STREAM_BYTES: int = 512_000  # 512KB hard limit
_REPEAT_WINDOW: int = 20  # Track last N chunks for pattern detection
_REPEAT_THRESHOLD: int = 3  # Pattern must repeat this many times


def _is_degenerate_loop(recent: list[str]) -> bool:
    """Detect repeating patterns in a rolling window of chunks.

    For each candidate pattern length L (1..WINDOW), check whether the
    most recent ``L * THRESHOLD`` chunks consist of the same L-chunk
    sequence repeated THRESHOLD times.
    """
    n = len(recent)
    for length in range(1, n // _REPEAT_THRESHOLD + 1):
        span = length * _REPEAT_THRESHOLD
        if span > n:
            continue
        tail = recent[-span:]
        pattern = tail[:length]
        if all(tail[i] == pattern[i % length] for i in range(length, span)):
            return True
    return False


def _deduplicate_stream_text(
    events: Iterator[Mapping[str, Any]],
    *,
    include_reasoning: bool = False,
) -> Iterator[str]:
    """Yield text from streaming events, suppressing duplicates.

    When both ``response.output_text.delta`` events and a terminal
    ``response.completed`` event carry the same text, only the delta
    text is yielded. If no deltas arrived (sync-to-stream conversion),
    the completed event's text is used as a fallback.
    """
    yield from _iter_deduplicated_text(
        events,
        include_reasoning=include_reasoning,
    )


def _iter_deduplicated_text(
    events: Iterator[Mapping[str, Any]],
    on_event: Callable[[Mapping[str, Any]], None] | None = None,
    on_first_text: Callable[[], None] | None = None,
    *,
    include_reasoning: bool = False,
) -> Iterator[str]:
    """Core deduplication loop shared by plain streaming and AdminStream."""
    saw_delta = False
    total_bytes = 0
    recent_chunks: list[str] = []

    for event in events:
        if on_event is not None:
            on_event(event)
        event_type = ClientStreamPayload.from_mapping(event).effective_type
        text = _extract_stream_text(
            event,
            include_reasoning=include_reasoning,
        )
        if text:
            if event_type == "response.completed" and saw_delta:
                continue
            saw_delta = True
            if on_first_text is not None:
                on_first_text()
                on_first_text = None  # Fire once.

            total_bytes += len(text.encode("utf-8"))
            if total_bytes > _MAX_STREAM_BYTES:
                LOG.warning(
                    "Stream exceeded %d byte limit, terminating",
                    _MAX_STREAM_BYTES,
                )
                break

            recent_chunks.append(text)
            if len(recent_chunks) > _REPEAT_WINDOW:
                recent_chunks = recent_chunks[-_REPEAT_WINDOW:]
            if len(recent_chunks) >= _REPEAT_THRESHOLD and _is_degenerate_loop(recent_chunks):
                LOG.warning(
                    "Degenerate loop detected, terminating stream",
                )
                break

            yield text


@dataclass
class AdminMetrics:
    """Metrics captured during an admin-mode streaming response.

    Client-side fields (``ttfb_ms``, ``total_ms``) are always populated.
    Server-side fields require a valid ``KEIRO_ADMIN_TOKEN``.
    """

    request_id: str | None = None
    provider: str | None = None
    provider_model: str | None = None
    model: str | None = None

    candidates: list[str] = field(default_factory=list)
    candidates_attempted: int | None = None
    candidates_succeeded: int | None = None
    judge_model: str | None = None
    primary_source_model: str | None = None

    gnn_distribution: dict[str, float] = field(default_factory=dict)
    gnn_tier: str | None = None
    gnn_confidence: float | None = None
    gnn_logit_margin: float | None = None
    gnn_route_time_ms: float | None = None

    prompt_tokens: int = 0
    completion_tokens: int = 0
    reasoning_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float | None = None
    internal_cost_usd: float | None = None
    timings_ms: dict[str, float] = field(default_factory=dict)

    ttfb_ms: float | None = None
    total_ms: float | None = None

    admin_granted: bool | None = None


class AdminStream:
    """Streaming iterator that yields text while capturing admin metrics.

    Wraps the raw SSE event stream from ``Client.responses_stream()``.
    Uses ``_iter_deduplicated_text`` for text extraction so deduplication
    logic is shared with ``_deduplicate_stream_text``.
    """

    def __init__(
        self,
        raw_events: Iterator[Mapping[str, Any]],
        *,
        include_reasoning: bool = False,
        admin_status_fn: Callable[[], bool | None] | None = None,
        on_routing: Callable[["AdminMetrics"], None] | None = None,
    ) -> None:
        self._raw = raw_events
        self._start = time.monotonic()
        self._include_reasoning = include_reasoning
        self._admin_status_fn = admin_status_fn
        self._on_routing = on_routing
        self.metrics = AdminMetrics()

    def __iter__(self) -> Iterator[str]:
        def mark_ttfb() -> None:
            self.metrics.ttfb_ms = (time.monotonic() - self._start) * 1000
            # Resolve lazily: the streaming generator parses
            # response headers before yielding the first event.
            if self._admin_status_fn is not None:
                self.metrics.admin_granted = self._admin_status_fn()

        yield from _iter_deduplicated_text(
            self._raw,
            on_event=self._ingest,
            on_first_text=mark_ttfb,
            include_reasoning=self._include_reasoning,
        )
        self.metrics.total_ms = (time.monotonic() - self._start) * 1000

    def _ingest(self, event: Mapping[str, Any]) -> None:
        event_type = ClientStreamPayload.from_mapping(event).effective_type

        if event_type == "telemetry":
            self._ingest_telemetry(event)
            return

        if event_type == "header":
            self.metrics.request_id = _str_or_none(event.get("id"))
            self.metrics.model = _str_or_none(event.get("model"))
            self.metrics.provider = _str_or_none(event.get("provider"))
            self.metrics.provider_model = _str_or_none(
                event.get("provider_model"),
            )
            self._ingest_plan(event)
            self._ingest_provider_metadata(event)
            # Fire routing callback only if we already have routing
            # data (e.g. provider_metadata was non-empty in the header
            # event).  For GNN-routed models the distribution arrives
            # in a later response.routing event, so we defer.
            self._maybe_fire_routing_callback()

        if event_type == "response.routing":
            self._ingest_provider_metadata(event)
            self._maybe_fire_routing_callback()

        if event_type in ("done", "response.completed"):
            self._ingest_usage(event)
            self._ingest_provider_metadata(event)
            cost = event.get("cost_usd")
            if cost is not None:
                self.metrics.cost_usd = float(cost)
            resp = event.get("response")
            if isinstance(resp, Mapping):
                self._ingest_usage(resp)
                self._ingest_provider_metadata(resp)
                meta = resp.get("metadata")
                if isinstance(meta, Mapping):
                    self._ingest_debug_metadata(meta)

        if event_type not in ("delta", "response.output_text.delta"):
            meta = event.get("metadata")
            if isinstance(meta, Mapping):
                self._ingest_debug_metadata(meta)

    def _ingest_usage(self, source: Mapping[str, Any]) -> None:
        usage = source.get("usage")
        if not isinstance(usage, Mapping):
            return
        # Support both OpenAI (prompt_tokens/completion_tokens) and
        # Anthropic (input_tokens/output_tokens) naming conventions.
        pt = usage.get("prompt_tokens")
        if pt is None:
            pt = usage.get("input_tokens")
        ct = usage.get("completion_tokens")
        if ct is None:
            ct = usage.get("output_tokens")
        tt = usage.get("total_tokens")
        rt = usage.get("reasoning_tokens")
        if pt is not None:
            self.metrics.prompt_tokens = int(pt)
        if ct is not None:
            self.metrics.completion_tokens = int(ct)
        if tt is not None:
            self.metrics.total_tokens = int(tt)
        if rt is not None:
            self.metrics.reasoning_tokens = int(rt)

    def _ingest_plan(self, event: Mapping[str, Any]) -> None:
        """Extract ensemble plan details (candidate list, judge)."""
        plan = event.get("plan")
        if isinstance(plan, Mapping):
            cands = plan.get("candidates")
            if isinstance(cands, (list, tuple)) and cands:
                self.metrics.candidates = [str(c) for c in cands]
            judge = plan.get("judge")
            if isinstance(judge, str) and not self.metrics.judge_model:
                self.metrics.judge_model = judge
        outline = event.get("plan_outline")
        if isinstance(outline, Mapping) and not self.metrics.candidates:
            cands = outline.get("candidates")
            if isinstance(cands, (list, tuple)) and cands:
                self.metrics.candidates = [str(c) for c in cands]

    def _ingest_provider_metadata(self, event: Mapping[str, Any]) -> None:
        """Extract GNN routing signals from provider_metadata.

        Server emits these as ``_``-prefixed internal fields; we
        normalize to public field names on ``AdminMetrics``.
        """
        pm = event.get("provider_metadata")
        if not isinstance(pm, Mapping):
            return
        dist = pm.get("_distribution")
        if isinstance(dist, Mapping) and dist:
            self.metrics.gnn_distribution = {str(k): float(v) for k, v in dist.items()}
        selected = pm.get("_selected_model")
        if isinstance(selected, str) and not self.metrics.primary_source_model:
            self.metrics.primary_source_model = selected
        tier = pm.get("_tier")
        if isinstance(tier, str):
            self.metrics.gnn_tier = tier
        conf = pm.get("_confidence")
        if conf is not None:
            self.metrics.gnn_confidence = float(conf)
        margin = pm.get("_logit_margin")
        if margin is not None:
            self.metrics.gnn_logit_margin = float(margin)
        rt = pm.get("_route_time_ms")
        if rt is not None:
            self.metrics.gnn_route_time_ms = float(rt)

    def _maybe_fire_routing_callback(self) -> None:
        """Fire the routing callback if routing data is available.

        Data-driven: only fires when ``gnn_distribution`` or
        ``primary_source_model`` has been populated, ensuring the
        rendering layer has meaningful data to display.  Fires at
        most once.
        """
        if self._on_routing is None:
            return
        has_data = bool(self.metrics.gnn_distribution or self.metrics.primary_source_model)
        if not has_data:
            return
        try:
            self._on_routing(self.metrics)
        except Exception:
            pass  # Don't crash the stream on display errors.
        self._on_routing = None

    def _ingest_debug_metadata(self, metadata: Mapping[str, Any]) -> None:
        """Extract admin-only debug fields from response metadata."""
        for attr in ("judge_model", "primary_source_model"):
            value = metadata.get(attr)
            if value is not None:
                setattr(self.metrics, attr, str(value))
        for attr in ("candidates_attempted", "candidates_succeeded"):
            value = metadata.get(attr)
            if value is not None:
                setattr(self.metrics, attr, int(value))
        cands = metadata.get("candidates")
        if isinstance(cands, (list, tuple)) and cands and not self.metrics.candidates:
            self.metrics.candidates = [str(c) for c in cands]
        timings = metadata.get("timings_ms")
        if isinstance(timings, Mapping):
            self.metrics.timings_ms = {str(k): float(v) for k, v in timings.items()}

    def _ingest_telemetry(self, event: Mapping[str, Any]) -> None:
        """Parse a structured ``event: telemetry`` payload into metrics.

        The telemetry event is a versioned envelope emitted once at
        end-of-stream for admin users. It consolidates routing, usage,
        timings, and provider metadata into a single JSON object,
        replacing the need to scrape scattered header/done/metadata events.

        Existing sub-parsers remain for backward compat with older servers.
        """
        self.metrics.request_id = _str_or_none(event.get("request_id"))

        routing = event.get("routing")
        if isinstance(routing, Mapping):
            self.metrics.provider = _str_or_none(routing.get("provider"))
            self.metrics.provider_model = _str_or_none(
                routing.get("provider_model"),
            )
            self.metrics.model = _str_or_none(routing.get("canonical_model"))
            plan = routing.get("plan")
            if isinstance(plan, Mapping):
                cands = plan.get("candidates")
                if isinstance(cands, (list, tuple)) and cands:
                    self.metrics.candidates = [str(c) for c in cands]
                judge = plan.get("judge")
                if isinstance(judge, str):
                    self.metrics.judge_model = judge

        usage = event.get("usage")
        if isinstance(usage, Mapping):
            pt = usage.get("prompt_tokens")
            ct = usage.get("completion_tokens")
            tt = usage.get("total_tokens")
            rt = usage.get("reasoning_tokens")
            if pt is not None:
                self.metrics.prompt_tokens = int(pt)
            if ct is not None:
                self.metrics.completion_tokens = int(ct)
            if tt is not None:
                self.metrics.total_tokens = int(tt)
            if rt is not None:
                self.metrics.reasoning_tokens = int(rt)
            cost = usage.get("cost_usd")
            if cost is not None:
                self.metrics.cost_usd = float(cost)

        timings = event.get("timings_ms")
        if isinstance(timings, Mapping):
            self.metrics.timings_ms = {str(k): float(v) for k, v in timings.items()}

        pm = event.get("provider_metadata")
        if isinstance(pm, Mapping):
            dist = pm.get("distribution")
            if isinstance(dist, Mapping) and dist:
                self.metrics.gnn_distribution = {str(k): float(v) for k, v in dist.items()}
            tier = pm.get("tier")
            if isinstance(tier, str):
                self.metrics.gnn_tier = tier
            conf = pm.get("confidence")
            if conf is not None:
                self.metrics.gnn_confidence = float(conf)
            margin = pm.get("logit_margin")
            if margin is not None:
                self.metrics.gnn_logit_margin = float(margin)
            rt = pm.get("route_time_ms")
            if rt is not None:
                self.metrics.gnn_route_time_ms = float(rt)
            ic = pm.get("internal_cost_usd")
            if ic is not None:
                self.metrics.internal_cost_usd = float(ic)


def _str_or_none(value: object) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None


class Response:
    """Structured wrapper around hosted gateway responses."""

    def __init__(self, raw_response: Mapping[str, Any]):
        self._raw = dict(raw_response)
        self._parsed = parse_response(self._raw)

    @property
    def text(self) -> str:
        return self._parsed.text or _extract_response_text(self._raw, self._parsed)

    @property
    def usage(self) -> dict[str, Any]:
        return _usage_dict(self._parsed)

    @property
    def model_id(self) -> str | None:
        return self._parsed.model or None

    @property
    def metadata(self) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        if self._parsed.id:
            metadata["id"] = self._parsed.id
        if self._parsed.object:
            metadata["object"] = self._parsed.object
        created = self._raw.get("created")
        if created is not None:
            metadata["created"] = created
        if self.model_id is not None:
            metadata["model_id"] = self.model_id
        return metadata

    @property
    def output(self) -> list[dict[str, Any]]:
        raw_output = self._raw.get("output")
        if not isinstance(raw_output, list):
            return []
        return [dict(item) for item in raw_output if isinstance(item, Mapping)]

    @property
    def tool_calls(self) -> list[dict[str, Any]]:
        return [tool_call.to_chat_dict() for tool_call in self._parsed.tool_calls]

    @property
    def raw(self) -> dict[str, Any]:
        return dict(self._raw)

    def __str__(self) -> str:
        return self.text

    def __repr__(self) -> str:
        preview = self.text[:50]
        return f"Response(text={preview!r}, tokens={self.usage['total_tokens']})"


@dataclass(frozen=True)
class ModelInvocation:
    """Composite result exposing text alongside the structured response."""

    text: str
    response: Response

    @property
    def usage(self) -> dict[str, Any]:
        return self.response.usage

    @property
    def model_id(self) -> str | None:
        return self.response.model_id

    @property
    def metadata(self) -> dict[str, Any]:
        return self.response.metadata


class ModelResult(str):
    """String-like result that retains the structured response object."""

    __slots__ = ("_response",)
    _response: Response

    def __new__(cls, response: Response) -> "ModelResult":
        instance = super().__new__(cls, response.text)
        instance._response = response
        return instance

    @property
    def text(self) -> str:
        return str(self)

    @property
    def response(self) -> Response:
        return self._response

    @property
    def usage(self) -> dict[str, Any]:
        return self._response.usage

    @property
    def model_id(self) -> str | None:
        return self._response.model_id

    @property
    def metadata(self) -> dict[str, Any]:
        return self._response.metadata

    @property
    def output(self) -> list[dict[str, Any]]:
        return self._response.output

    @property
    def raw(self) -> dict[str, Any]:
        return self._response.raw

    def __repr__(self) -> str:
        return f"ModelResult(text={str(self)!r})"


class ModelBinding:
    """Reusable callable with a fixed model id and default parameters."""

    def __init__(self, model_id: str, api: ModelsAPI, **params: Any) -> None:
        self.model_id = model_id
        self._api = api
        self._params = dict(params)

    def __call__(self, prompt: str, **override_params: Any) -> str:
        return str(self._api(self.model_id, prompt, **{**self._params, **override_params}))

    def response(self, prompt: str, **override_params: Any) -> Response:
        return self._api.response(self.model_id, prompt, **{**self._params, **override_params})

    def with_metadata(self, prompt: str, **override_params: Any) -> ModelInvocation:
        return self._api.with_metadata(
            self.model_id,
            prompt,
            **{**self._params, **override_params},
        )

    def stream(self, prompt: str, **override_params: Any) -> Iterator[str]:
        return self._api.stream(self.model_id, prompt, **{**self._params, **override_params})

    def __repr__(self) -> str:
        return f"ModelBinding(model_id={self.model_id!r}, params={self._params!r})"


class ModelsAPI:
    """Hosted facade shaped like ``ember.api.models`` for quick testing.

    Caches a single :class:`Client` instance for HTTP connection reuse.
    Call :meth:`close` (or use as a context manager) to release the
    underlying connection pool explicitly.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        admin_token: str | None = None,
        timeout: float | None = None,
        retries: int = 3,
        pool_maxsize: int = 100,
        on_retry: Callable[[int, int, int, float], None] | None = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url
        self._admin_token = admin_token
        self._timeout = timeout
        self._retries = retries
        self._pool_maxsize = pool_maxsize
        self._on_retry = on_retry
        self._cached_client: Client | None = None

    def _client(self) -> Client:
        if self._cached_client is not None:
            return self._cached_client
        client_kwargs: dict[str, Any] = {
            "api_key": self._api_key,
            "base_url": self._base_url,
            "admin_token": self._admin_token,
            "retries": self._retries,
            "pool_maxsize": self._pool_maxsize,
        }
        if self._timeout is not None:
            client_kwargs["timeout"] = self._timeout
        if self._on_retry is not None:
            client_kwargs["on_retry"] = self._on_retry
        self._cached_client = Client(**client_kwargs)
        return self._cached_client

    def close(self) -> None:
        """Close the underlying HTTP client and release connections."""
        if self._cached_client is not None:
            self._cached_client.close()
            self._cached_client = None

    def __enter__(self) -> "ModelsAPI":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def _prepare_messages(
        self,
        prompt: str,
        params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Pop system/context from *params* and build chat messages."""
        system = params.pop("system", None)
        if system is not None and not isinstance(system, str):
            system = str(system)
        context = params.pop("context", None)
        if context is not None and (
            isinstance(context, (str, bytes, bytearray)) or not isinstance(context, Sequence)
        ):
            raise KeirValidationError(
                "'context' must be a list of message dicts when supplied.",
                code="invalid_context_type",
            )
        return _build_prompt_messages(prompt, system=system, context=context)

    def _chat_response(self, model: str, prompt: str, **params: Any) -> Response:
        stream_requested = bool(params.pop("stream", False))
        if stream_requested:
            raise KeirValidationError(
                "Pass stream=True to ModelsAPI.stream(), not to __call__().",
                code="use_stream_method",
            )

        if "messages" in params:
            raise KeirValidationError(
                "Pass raw messages via Client.chat() or "
                "ModelsAPI.responses(messages=...), not via __call__().",
                code="use_chat_for_messages",
            )

        messages = self._prepare_messages(prompt, params)
        return Response(self._client().chat(messages, model=model, **params))

    def _build_responses_payload(
        self,
        payload: Mapping[str, Any] | None,
        *,
        model: str,
        input: object | None,
        instructions: object | None,
        messages: Sequence[Mapping[str, Any]] | None,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        request_payload: dict[str, Any] = {}
        if payload is not None:
            request_payload.update(copy.deepcopy(dict(payload)))

        system = params.pop("system", None)

        if input is not None:
            request_payload["input"] = copy.deepcopy(input)

        if instructions is not None:
            request_payload["instructions"] = copy.deepcopy(instructions)

        _merge_responses_system_alias(request_payload, system=system, model=model)

        if messages is not None:
            for index, message in enumerate(messages):
                if not isinstance(message, Mapping):
                    raise KeirValidationError(
                        f"messages[{index}] must be a dict, got {type(message).__name__}.",
                        code="invalid_message_entry",
                    )

            if _has_chat_completions_tool_format(messages):
                from keiro._internal.openai_messages import (
                    as_responses_request_parts,
                )

                input_items, extracted_instructions = as_responses_request_parts(
                    list(messages),
                )
                _merge_keiro_instructions(
                    request_payload,
                    instructions=extracted_instructions,
                    source="system-role messages",
                    model=model,
                )
                request_payload["input"] = list(input_items)
            else:
                request_payload["messages"] = [copy.deepcopy(dict(m)) for m in messages]

        prompt = params.pop("prompt", None)
        if prompt is not None:
            if "input" in request_payload and request_payload["input"] is not None:
                raise KeirValidationError(
                    "Cannot supply both 'prompt' and 'input'. Use one or the other.",
                    code="conflicting_arguments",
                )
            request_payload["input"] = prompt

        context = params.pop("context", None)
        if context is not None and "messages" not in request_payload:
            if isinstance(context, (str, bytes, bytearray)) or not isinstance(context, Sequence):
                raise KeirValidationError(
                    "'context' must be a list of message dicts when supplied.",
                    code="invalid_context_type",
                )
            request_payload["messages"] = _normalized_context(context)

        max_tokens = params.pop("max_tokens", None)
        if max_tokens is not None and "max_output_tokens" not in request_payload:
            request_payload["max_output_tokens"] = max_tokens

        params.pop("stream", None)

        for key, value in list(params.items()):
            if value is None:
                continue
            request_payload[key] = copy.deepcopy(value)

        return {key: value for key, value in request_payload.items() if value is not None}

    def __call__(self, model: str, prompt: str, **params: Any) -> ModelResult:
        return ModelResult(self._chat_response(model, prompt, **params))

    def response(self, model: str, prompt: str, **params: Any) -> Response:
        return self._chat_response(model, prompt, **params)

    def with_metadata(self, model: str, prompt: str, **params: Any) -> ModelInvocation:
        response = self._chat_response(model, prompt, **params)
        return ModelInvocation(text=response.text, response=response)

    def instance(self, model: str, **params: Any) -> ModelBinding:
        return ModelBinding(model, self, **params)

    def stream(self, model: str, prompt: str, **params: Any) -> Iterator[str]:
        params.pop("stream", None)
        messages = self._prepare_messages(prompt, params)
        return _deduplicate_stream_text(
            self._client().chat_stream(messages, model=model, **params),
        )

    def responses(
        self,
        model: str,
        *,
        payload: Mapping[str, Any] | None = None,
        input: object | None = None,
        instructions: object | None = None,
        messages: Sequence[Mapping[str, Any]] | None = None,
        **params: Any,
    ) -> Response:
        stream_requested = bool(params.pop("stream", False))
        if stream_requested:
            raise KeirValidationError(
                "Pass stream=True to ModelsAPI.responses_stream(), not to responses().",
                code="use_stream_method",
            )
        timeout = params.pop("timeout", None)

        request_payload = self._build_responses_payload(
            payload,
            model=model,
            input=input,
            instructions=instructions,
            messages=messages,
            params=dict(params),
        )
        request_payload["model"] = model
        return Response(self._client().responses(request_payload, timeout=timeout))

    def responses_stream(
        self,
        model: str,
        *,
        payload: Mapping[str, Any] | None = None,
        input: object | None = None,
        instructions: object | None = None,
        messages: Sequence[Mapping[str, Any]] | None = None,
        **params: Any,
    ) -> Iterator[str]:
        params.pop("stream", None)
        timeout = params.pop("timeout", None)
        request_payload = self._build_responses_payload(
            payload,
            model=model,
            input=input,
            instructions=instructions,
            messages=messages,
            params=dict(params),
        )
        request_payload["model"] = model
        return _deduplicate_stream_text(
            self._client().responses_stream(request_payload, timeout=timeout),
        )

    def responses_stream_admin(
        self,
        model: str,
        *,
        payload: Mapping[str, Any] | None = None,
        input: object | None = None,
        instructions: object | None = None,
        messages: Sequence[Mapping[str, Any]] | None = None,
        on_routing: Callable[["AdminMetrics"], None] | None = None,
        **params: Any,
    ) -> AdminStream:
        """Stream a Responses API request with admin metrics capture.

        Returns an ``AdminStream`` that yields text chunks (like
        ``responses_stream``) but also populates ``stream.metrics``
        with server-side and client-side telemetry as events arrive.

        Args:
            on_routing: Optional callback invoked once when GNN
                routing data is available (before text deltas).
                Receives ``AdminMetrics`` with ``gnn_distribution``
                and ``primary_source_model`` populated.

        Requires ``admin_token`` on the ``ModelsAPI`` for server-side
        fields. Client-side timing (TTFB, total latency) is always
        captured regardless.
        """
        params.pop("stream", None)
        timeout = params.pop("timeout", None)
        request_payload = self._build_responses_payload(
            payload,
            model=model,
            input=input,
            instructions=instructions,
            messages=messages,
            params=dict(params),
        )
        request_payload["model"] = model
        client = self._client()
        raw_events = client.responses_stream(
            request_payload,
            timeout=timeout,
        )
        return AdminStream(
            raw_events,
            include_reasoning=True,
            admin_status_fn=lambda: client.admin_status,
            on_routing=on_routing,
        )

    def list(self, provider: str | None = None, *, status: str | None = None) -> list[str]:
        return sorted(self.discover(provider=provider, status=status))

    def discover(
        self,
        provider: str | None = None,
        *,
        status: str | None = None,
    ) -> dict[str, dict[str, Any]]:
        payload = self._client().get_models(provider=provider, status=status)

        data = payload.get("data")
        if not isinstance(data, list):
            raise ValueError("Gateway /v1/models response did not contain a 'data' list")

        discovered: dict[str, dict[str, Any]] = {}
        for entry in data:
            if not isinstance(entry, Mapping):
                continue
            model_id = entry.get("id")
            if not isinstance(model_id, str) or not model_id:
                continue
            discovered[model_id] = dict(entry)
        return discovered


__all__ = [
    "AdminMetrics",
    "AdminStream",
    "ModelBinding",
    "ModelInvocation",
    "ModelResult",
    "ModelsAPI",
    "Response",
]
