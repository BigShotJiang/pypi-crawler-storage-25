from math import ceil
from typing import Optional, Union

import numpy as np
import numpy.typing as npt
import polars as pl

from model_diagnostics._utils.array import (
    array_name,
    length_of_first_dimension,
    to_pl_series,
)


def _format_integer(x):
    """Nicely round and format large integers."""
    # https://stackoverflow.com/a/45846841
    x = float(f"{x:.3g}")
    magnitude = 0
    while abs(x) >= 1000 and magnitude < 4:
        magnitude += 1
        x /= 1000.0
    return "{}{}".format(
        f"{x:f}".rstrip("0").rstrip("."), ["", "k", "M", "G", "T"][magnitude]
    )


def bin_feature(
    feature: Optional[Union[npt.ArrayLike, pl.Series]],
    feature_name: Optional[Union[int, str]],
    n_obs: int,
    n_bins: int = 10,
    bin_method: str = "sturges",
) -> tuple[pl.Series, int, pl.DataFrame]:
    """Helper function to bin features of different dtypes.

    Best call this function inside a `with pl.StringCache()` context manager.

    Parameters
    ----------
    feature : array-like of shape (n_obs)
        Some feature column.
    feature_name : int, str or None
        Name of the feature.
    n_obs : int
        The expected length of the first dimention of feature.
    n_bins : int
        The number of bins, at least 2. For numerical features, `n_bins` only applies
        when `bin_method` is set to `"quantile"` or `"uniform"`.
        For string-like and categorical features, the most frequent values are taken.
        Ties are dealt with by taking the first value in natural sorting order.
        The remaining values are merged into `"other n"` with `n` indicating the unique
        count.

        I present, null values are always included in the output, accounting for one
        bin. NaN values are treated as null values.
    bin_method : str
        The method to use for finding bin edges (boundaries). Options are:

        - `"quantile"`
        - `"uniform"`
        - `"auto"`
        - `"fd"`
        - `"doane"`
        - `"scott"`
        - `"stone"`
        - `"rice"`
        - `"sturges"`
        - `"sqrt"`

    Returns
    -------
    feature : pl.Series or None
        The polars.Series version of the feature.
    n_bins : int
        Effective number of bins.
    f_binned : pl.DataFrame or None
        The binned/digitized version of the feature.
        For numerical features, columns are:

        - `bin`: The bin number.
          Bin `i` is assigned if `bin_edges[i] < feature <= bin_edges[i]`
        - `bin_edges`: edges/thresholds of the bins.

        For other features, columns are:

        - `bin`: The binned version of it, i.e. the many too small values are put
          together as `"other n"` where `n` is the number of unique values it contains.
    """
    is_categorical = False
    is_enum = False
    is_string = False
    f_binned = None

    valid_bin_methods = (
        "quantile",
        "uniform",
        "auto",
        "fd",
        "doane",
        "scott",
        "stone",
        "rice",
        "sturges",
        "sqrt",
    )
    if bin_method not in valid_bin_methods:
        msg = (
            f"Parameter bin_method must be one of {valid_bin_methods};"
            f" got {bin_method}."
        )
        raise ValueError(msg)
    if n_bins < 2:
        msg = f"Parameter n_bins must be at least 2, got {n_bins}."
        raise ValueError(msg)

    default = f"feature {feature_name}" if isinstance(feature_name, int) else "feature"
    feature_name = array_name(feature, default=default)
    # The following statement, i.e. possibly the creation of a pl.Categorical,
    # MUST be under the StringCache context manager!
    feature_out = to_pl_series(feature, name=feature_name)

    if length_of_first_dimension(feature_out) != n_obs:
        msg = (
            f"The feature array {feature_name} does not have length {n_obs} of its"
            " first dimension."
        )
        raise ValueError(msg)

    if feature_out.dtype == pl.Categorical:
        is_categorical = True
    elif feature_out.dtype == pl.Enum:
        is_enum = True
    elif feature_out.dtype in [pl.Utf8, pl.Object]:
        # We could convert strings to categoricals.
        is_string = True
    elif feature_out.dtype.is_float():
        # We treat NaN as Null values, numpy will see a Null as a NaN.
        feature_out = feature_out.fill_nan(None)
    else:
        # integers
        pass

    # If we have Null values, we should reserve one bin for it and reduce
    # the effective number of bins by 1.
    n_bins_ef = max(1, n_bins - feature_out.has_nulls())

    if is_categorical or is_enum or is_string:
        # For categorical and string features, knowing the frequency table in
        # advance makes life easier in order to make results consistent.
        # Consider (no null values)
        #     feature  count
        #         "a"      3
        #         "b"      2
        #         "c"      2
        #         "d"      1
        # with n_bins = 3. As we want the effective number of bins to be at most
        # n_bins, we want, in the above case, only "a" and "b" in the final result. All
        # the others a put into the second bin and called "other 2" because it comprises
        # 2 unique features values (c, d). Ties are dealt with by sorting.

        # value_counts(sort=True) sorts ties by first occurence, we want
        # alphanumerical sorting order.
        value_counts = (
            feature_out.drop_nulls()
            .value_counts()
            .sort(by=["count", feature_name], descending=[True, False])
        )

        if n_bins_ef >= value_counts.shape[0]:
            # This also covers the case of only null values.
            n_bins_ef = value_counts.shape[0]
            f_binned = pl.DataFrame({"bin": feature_out})
        else:
            # We keep the n_bins_ef - 1 most frequent values. Ties are resolved by
            # taking the first one of the sorted values (most often alpha-numerical).
            if feature_out.has_nulls():
                # To ease adding the null value, we take one value more.
                keep_values = value_counts[feature_name].head(n_bins_ef)
                if is_categorical or is_enum:
                    # FIXME: categorical: Workaround for https://github.com/pola-rs/polars/issues/21175
                    # FIXME: enum: Workaround for https://github.com/pola-rs/polars/pull/25245
                    # to be released in polars 1.35.3 or 1.36.
                    dtype = keep_values.dtype
                    keep_values = keep_values.cast(pl.String)
                    keep_values[-1] = None
                    keep_values = keep_values.cast(dtype)
                else:
                    keep_values[-1] = None
            else:
                keep_values = value_counts[feature_name].head(n_bins_ef - 1)
            # Number of feature values to put into one bin, called "other n",
            # n = n_remaining.
            n_remaining = value_counts.shape[0] - (n_bins_ef - 1)
            remaining_name = "other " + _format_integer(n_remaining)
            while remaining_name in keep_values.cast(pl.String):
                remaining_name = "_" + remaining_name
            return_dtype = feature_out.dtype
            if is_enum:
                return_dtype = pl.Enum(
                    pl.concat(
                        [feature_out.dtype.categories, pl.Series([remaining_name])]
                    )
                )
            f_binned = feature_out.replace_strict(
                old=keep_values,
                new=keep_values,
                default=remaining_name,
                return_dtype=return_dtype,
            )
            f_binned = pl.DataFrame({"bin": f_binned})
    else:
        # Binning a numerical feature
        # We will need min and max anyway.
        feature_min, feature_max = feature_out.min(), feature_out.max()
        if feature_min == -np.inf:
            finite_min = feature_out.filter(feature_out > -np.inf).min()
        else:
            finite_min = feature_min
        if feature_max == np.inf:
            finite_max = feature_out.filter(feature_out < np.inf).max()
        else:
            finite_max = feature_max
        f_range = finite_max - finite_min

        if bin_method == "quantile":
            # We use method="inverted_cdf" instead of the default "linear" because
            # "linear" produces as many unique values as before.
            q = np.nanquantile(
                feature_out,
                # Improved rounding errors by using integers and dividing at the
                # end as opposed to np.linspace with 1/n_bins step size.
                q=np.arange(1, n_bins_ef) / n_bins_ef,
                method="inverted_cdf",
            )
            bin_edges = np.unique(q)  # Some quantiles might be the same.
        elif bin_method == "uniform":
            bin_edges = finite_min + f_range * np.arange(1, n_bins_ef) / n_bins_ef
        else:
            # numpy histogram bin methods
            a = feature_out.filter(feature_out.is_finite() & feature_out.is_not_null())
            bin_edges = np.histogram_bin_edges(a, bins=bin_method)[1:-1]
            n_bins_ef = bin_edges.shape[0] + 1
        # We want: bins[i-1] < x <= bins[i]
        f_binned = np.digitize(feature_out, bins=bin_edges, right=True)
        # The full bin edges also include min and max of the feature.
        if bin_edges.size == 0:
            bin_edges = np.r_[feature_min, feature_max]
        else:
            bin_edges = np.r_[feature_min, bin_edges, feature_max]
        # This is quite a hack with numpy strides and views. We want to accomplish
        # bin_edges = [[value0, value1], [value1, value2], [value2, value3], ..]
        bin_edges = np.lib.stride_tricks.as_strided(
            bin_edges, (bin_edges.shape[0] - 1, 2), bin_edges.strides * 2
        )
        # Back to the binned feature.
        # Now, we insert Null values again at the original places.
        f_binned = (
            pl.LazyFrame(
                [
                    feature_out,
                    pl.Series("__f_binned", f_binned, dtype=feature_out.dtype),
                    pl.Series(
                        "__bin_edges",
                        bin_edges[f_binned],
                        dtype=pl.Array(pl.Float64, 2),
                    ),
                ]
            )
            .select(
                pl.when(pl.col(feature_name).is_null())
                .then(None)
                .otherwise(pl.col("__f_binned"))
                .alias("bin"),
                pl.when(pl.col(feature_name).is_null())
                .then(None)
                .otherwise(pl.col("__bin_edges"))
                .alias("bin_edges"),
            )
            .collect()
        )
    return feature_out, n_bins_ef + feature_out.has_nulls(), f_binned


def compute_grid(x: pl.Series, n: int) -> pl.Series:
    """Compute a grid with n equal distributed points.

    Best call this function inside a `with pl.StringCache()` context manager.
    """
    if x.dtype.is_numeric() or x.dtype.is_temporal():
        f_min, f_max = x.min(), x.max()
        if f_min == f_max:
            return pl.Series([f_min], dtype=x.dtype)
        elif x.dtype.is_float():
            # pl.linear_space was added in version 1.21.0, we have minimum 1.1.0.
            grid = pl.Series(np.linspace(f_min, f_max, n), dtype=x.dtype)
        elif x.dtype.is_integer():
            step = max(1, ceil((f_max - f_min + 1) / n))
            grid = pl.int_range(f_min, f_max + 1, step, dtype=x.dtype, eager=True)
        elif isinstance(x.dtype, (pl.Date, pl.Datetime, pl.Time)):
            d_range = {
                pl.Date: pl.date_range,
                pl.Datetime: pl.datetime_range,
                pl.Time: pl.time_range,
            }
            n_res = int((f_max - f_min) / f_min.resolution) // max(1, (n - 1))
            grid = d_range[x.dtype](f_min, f_max, n_res * f_min.resolution, eager=True)
            # TODO: pl.Duration
    else:
        # String, Categorical, Enum or complex types such as List, Union
        grid = x.value_counts(sort=True).head(n)[:, 0]

    return grid
