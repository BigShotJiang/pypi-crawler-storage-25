import copy
import operator
from typing import Callable

import numpy as np
import numpy.typing as npt
import polars as pl

from model_diagnostics._utils.array import (
    get_column_names,
    get_second_dimension,
    is_pandas_df,
    is_pyarrow_table,
    length_of_first_dimension,
    safe_assign_column,
    safe_index_rows,
    to_pl_series,
)
from model_diagnostics._utils.binning import compute_grid


def compute_partial_dependence(
    pred_fun: Callable,
    X: npt.ArrayLike,
    features: int | str,
    grid: npt.ArrayLike | int = 10,
    weights: npt.ArrayLike | None = None,
    n_max: int = 1000,
    rng: np.random.Generator | int | None = None,
):
    """Compute partial dependence.

    This is a fast brute force method to compute partial dependence values for the
    given grid.

    Parameters
    ----------
    pred_fun : callable
        Prediction function, such that `pred_fun(X)` gives predicted values.
    X : array-like of shape (n_obs, n_features)
        The dataframe or array of features to be passed to the model predict function.
    features : int or str
        Column index or column name of the feature in `X`.
    grid : pl.Series or int
        Values of the feature specified by `features`, for wich to compute partial
        dependence.
        If an integer is specified, a grid of `grid` points of the given feature is
        constructed automatically using binning.
    weights : array-like of shape (n_obs) or None
        Case weights. If given, the bias is calculated as weighted average of the
        identification function with these weights.
    n_max : int or None
        The number of rows to subsample from X. This speeds up computation, in
        particular for slow predict functions.
    rng : np.random.Generator, int or None
        The random number generator. The used one will be `np.random.default_rng(rng)`.

    Returns
    -------
    np.ndarray : shape (n_grid,)
        Partial dependence values for the grid.
    """
    n = length_of_first_dimension(X)
    try:
        feature_idx = operator.index(features)  # type: ignore
    except TypeError as err:
        if isinstance(features, str):
            feature_idx = get_column_names(X).index(features)
        else:
            msg = f"The argument 'features' must be an int or str; got {features}"
        raise ValueError(msg) from err

    try:
        n_grid = operator.index(grid)  # type: ignore
        feature_column = to_pl_series(get_second_dimension(X, feature_idx))
        grid = compute_grid(feature_column, n=n_grid)
    except TypeError:
        n_grid = length_of_first_dimension(grid)

    # Usually, the data is too large and we need subsampling.
    if n_max is not None and n > n_max:
        rng_ = np.random.default_rng(rng)
        row_indices = rng_.choice(n, size=n_max, replace=False)
        X = safe_index_rows(X, row_indices)
        if weights is not None:
            weights = safe_index_rows(weights, row_indices)
        n = n_max
    elif hasattr(X, "copy"):
        # pandas
        X = X.copy()
    elif is_pyarrow_table(X) or isinstance(X, pl.DataFrame):
        # Copy on Write
        pass
    else:
        X = copy.deepcopy(X)

    # X is stacked n_grid times, and grid column is replaced by replicated grid
    X_stacked = safe_index_rows(X, np.tile(np.arange(n), n_grid))
    grid_stacked = safe_index_rows(grid, np.repeat(np.arange(n_grid), n))

    if is_pandas_df(X):
        # pandas<2 does not allow "values" to have repeated indices
        X_stacked = X_stacked.reset_index(drop=True)
    X_stacked = safe_assign_column(
        X_stacked, values=grid_stacked, column_index=features
    )

    y_pred = pred_fun(X_stacked)
    if hasattr(y_pred, "to_numpy"):
        # pandas.Series, polars.Series, pyarrow.Array, pyarrow.ChunkedArray
        y_pred = y_pred.to_numpy()

    # Partial dependences are averages per grid block
    pd_values = np.average(
        y_pred.reshape(n_grid, y_pred.shape[0] // n_grid),
        axis=1,
        weights=weights,  # type: ignore
    )

    return pd_values
