r"""Real-workspace smoke script for the Databricks Phase A backend.

Exercises the public Phase A surface end-to-end against a live SQL
Warehouse via PAT auth. Exits 0 with a "skipped" banner when the required
env vars aren't set, so CI invocation is safe.

Usage:
    DATABRICKS_HOST=dbc-xxxx.cloud.databricks.com \\
    DATABRICKS_TOKEN=dapi... \\
    DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/<id> \\
    DATABRICKS_CATALOG=main \\          # optional, defaults to "main"
    DATABRICKS_SCHEMA=default \\        # optional, defaults to "default"
    just databricks-smoke

The script intentionally avoids any framework / pytest plumbing so it can
run from a stock ``uv run`` and serves as the manual-QA harness during
PR review and as a confidence check before TD-2734's wizard lands.
"""

from __future__ import annotations

import asyncio
import os
import sys
from typing import Optional

REQUIRED_ENV = (
    "DATABRICKS_HOST",
    "DATABRICKS_TOKEN",
    "DATABRICKS_HTTP_PATH",
)

# Cluster path used to verify the rejection path. Synthetic — never sent
# to the workspace.
CLUSTER_PATH_PROBE = "/sql/protocolv1/o/0/0123-456789-cluster"


def _section(title: str) -> None:
    print(f"\n=== {title} ===", flush=True)


def _missing_env() -> list[str]:
    return [name for name in REQUIRED_ENV if not os.environ.get(name)]


async def _run() -> int:
    # Late import so the missing-env path doesn't pay for the dependency
    # graph (and so the script remains importable in environments where
    # databricks-sql-connector itself is absent).
    from core.backends.config import DatabricksDataConfig, DatabricksPatAuth
    from core.backends.data_query.databricks_backend import (
        DatabricksClusterPathError,
        DatabricksDataQueryBackend,
    )

    host = os.environ["DATABRICKS_HOST"]
    token = os.environ["DATABRICKS_TOKEN"]
    http_path = os.environ["DATABRICKS_HTTP_PATH"]
    catalog = os.environ.get("DATABRICKS_CATALOG", "main")
    schema = os.environ.get("DATABRICKS_SCHEMA", "default")

    # Smoke script intentionally runs without allow-list pinning so
    # `list_databases` reflects what the PAT can actually see. Allow-list
    # filtering is covered exhaustively by unit tests (U2 + U7); this
    # script is a connectivity / contract smoke, not a security smoke.
    config = DatabricksDataConfig(
        host=host,
        http_path=http_path,
        catalog=catalog,
        schema_name=schema,
        auth=DatabricksPatAuth(token=token),
    )
    backend = DatabricksDataQueryBackend(config)

    # ------------------------------------------------------------------
    # 1. test_connection
    # ------------------------------------------------------------------
    _section("test_connection")
    probe = await backend.test_connection()
    print(
        f"ok={probe.ok} mode={probe.mode} "
        f"discovered_catalogs={probe.discovered_catalogs}"
    )
    for w in probe.warnings:
        print(f"  warning: {w}")
    if not probe.ok:
        print("✗ test_connection reported ok=False; aborting smoke.", file=sys.stderr)
        return 1

    # ------------------------------------------------------------------
    # 2. list_databases (UC catalogs)
    # ------------------------------------------------------------------
    _section("list_databases (catalogs)")
    cats = await backend.list_databases()
    print(f"catalogs={[r[0] for r in cats.rows]} (count={cats.row_count})")
    if cats.row_count == 0:
        print("✗ no catalogs visible.", file=sys.stderr)
        return 1

    # ------------------------------------------------------------------
    # 3. list_schemas
    # ------------------------------------------------------------------
    _section(f"list_schemas in {catalog}")
    schemas = await backend.list_schemas(catalog)
    print(
        f"schemas={[r[0] for r in schemas.rows][:10]} "
        f"(count={schemas.row_count})"
    )

    # ------------------------------------------------------------------
    # 4. list_tables
    # ------------------------------------------------------------------
    _section(f"list_tables in {catalog}.{schema}")
    tables = await backend.list_tables(catalog, schema)
    table_names = [r[0] for r in tables.rows]
    print(f"first_5={table_names[:5]} (total={tables.row_count})")

    first_table: Optional[str] = table_names[0] if table_names else None

    # ------------------------------------------------------------------
    # 5. get_table_schema on the first available table
    # ------------------------------------------------------------------
    if first_table is not None:
        _section(f"get_table_schema {catalog}.{schema}.{first_table}")
        ts = await backend.get_table_schema(catalog, schema, first_table)
        print(f"columns={[c.get('name') for c in ts.columns][:10]} "
              f"(count={len(ts.columns)})")

        # ------------------------------------------------------------------
        # 6. preview_table
        # ------------------------------------------------------------------
        _section(f"preview_table {catalog}.{schema}.{first_table} LIMIT 3")
        preview = await backend.preview_table(
            catalog, schema, first_table, limit=3
        )
        print(
            f"sample_row_count={preview.sample_row_count} "
            f"total_row_count={preview.total_row_count}"
        )
    else:
        print(f"  (skipping describe/preview — no tables in {catalog}.{schema})")

    # ------------------------------------------------------------------
    # 7. execute_query — trivial round-trip
    # ------------------------------------------------------------------
    _section("execute_query SELECT 1")
    qr = await backend.execute_query("SELECT 1 AS smoke_value")
    if qr.error_message:
        print(f"✗ execute_query failed: {qr.error_message}", file=sys.stderr)
        return 1
    print(f"columns={qr.columns} rows={qr.rows} elapsed_ms={qr.execution_time_ms:.1f}")

    # ------------------------------------------------------------------
    # 8. Cluster-path rejection (defense-in-depth)
    # ------------------------------------------------------------------
    _section("cluster_path_rejection")
    try:
        DatabricksDataConfig(
            host=host,
            http_path=CLUSTER_PATH_PROBE,
            catalog=catalog,
            schema_name=schema,
            auth=DatabricksPatAuth(token=token),
        )
    except ValueError as exc:
        print(f"✓ config validator rejected cluster path: {str(exc)[:100]}")
    else:
        print(
            "✗ config validator failed to reject cluster path",
            file=sys.stderr,
        )
        return 1

    # Runtime probe path also rejects (different code path; both must
    # produce the same outcome). Build a stand-in backend with a synthetic
    # config so we hit `_looks_like_cluster_path` without going through the
    # config validator (which would have rejected the path before we got
    # here).
    cluster_backend = DatabricksDataQueryBackend.__new__(DatabricksDataQueryBackend)
    cluster_backend.config = type("C", (), {"http_path": CLUSTER_PATH_PROBE})()
    try:
        await cluster_backend.test_connection()
    except DatabricksClusterPathError:
        print("✓ test_connection rejected cluster path with dedicated error")
    except Exception as exc:
        print(
            f"✗ test_connection raised {type(exc).__name__} for cluster path: {exc}",
            file=sys.stderr,
        )
        return 1
    else:
        print(
            "✗ test_connection did not reject cluster path",
            file=sys.stderr,
        )
        return 1

    # ------------------------------------------------------------------
    # 9. Privilege-degradation note (manual)
    # ------------------------------------------------------------------
    _section("privilege_degradation_note")
    print(
        "PAT-only smoke run cannot easily revoke grants; the\n"
        "system.access.table_lineage degradation banner is covered by\n"
        "U4 unit tests. To exercise the live degradation path, run\n"
        "this script with a PAT whose role lacks SELECT on\n"
        "system.access.table_lineage."
    )

    print("\n✓ Databricks Phase A smoke completed.")
    return 0


def main() -> int:
    """Entry point. Validates required env vars and runs the smoke flow.

    Returns 0 with a "skipped" banner when required env vars are unset
    (CI-safe), 0 on a successful smoke run, or 1 on any verification
    failure during the run.
    """
    missing = _missing_env()
    if missing:
        print(
            "Databricks smoke skipped — set the following env vars to run "
            "against a real workspace:",
            file=sys.stderr,
        )
        for name in missing:
            print(f"  - {name}", file=sys.stderr)
        print(
            "\nOptional: DATABRICKS_CATALOG (default: main), "
            "DATABRICKS_SCHEMA (default: default).",
            file=sys.stderr,
        )
        return 0

    return asyncio.run(_run())


if __name__ == "__main__":
    sys.exit(main())
