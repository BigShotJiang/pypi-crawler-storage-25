# Changelog

## [0.23.1](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.23.0...typedef-data-intelligence-v0.23.1) (2026-05-06)


### Miscellaneous Chores

* **api:** remove per-request logfire user_context debug log ([#672](https://github.com/typedef-ai/typedef/issues/672)) ([0d6c860](https://github.com/typedef-ai/typedef/commit/0d6c860843bd475c8243568cc33883df0f7eb128))

## [0.23.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.22.0...typedef-data-intelligence-v0.23.0) (2026-05-04)


### Features

* **ingest:** TD-2733 Databricks unified ingest — nodes + integration ([#644](https://github.com/typedef-ai/typedef/issues/644)) ([d782364](https://github.com/typedef-ai/typedef/commit/d78236492e20a0b15fea06a53668a2e1f8fee100))


### Bug Fixes

* **agent:** defer plan artifact persistence to end of turn (TD-3005) ([bf39add](https://github.com/typedef-ai/typedef/commit/bf39add431ed64534a1b26c9a5a4337b5317f8e6))
* **agent:** defer plan artifact persistence to end of turn (TD-3005) ([#652](https://github.com/typedef-ai/typedef/issues/652)) ([bf39add](https://github.com/typedef-ai/typedef/commit/bf39add431ed64534a1b26c9a5a4337b5317f8e6))

## [0.22.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.21.0...typedef-data-intelligence-v0.22.0) (2026-05-01)


### Features

* **databricks:** desktop setup wizard — panel + setup API + OAuth U2M (TD-2734) ([#607](https://github.com/typedef-ai/typedef/issues/607)) ([4086d33](https://github.com/typedef-ai/typedef/commit/4086d335783b61a354a8fb1d99f281edb6565bdd))
* **desktop:** direct-mode opt-out toggle + per-provider base URLs (TD-2955) ([#639](https://github.com/typedef-ai/typedef/issues/639)) ([880b21a](https://github.com/typedef-ai/typedef/commit/880b21abae53ba78118394ba0c5868c4c21f52d7))
* **desktop:** early preflight check on warehouse step (TD-2657) ([#635](https://github.com/typedef-ai/typedef/issues/635)) ([058c035](https://github.com/typedef-ai/typedef/commit/058c0352e4d3c3745a28cec0ce524f1339b4b8b8))
* **ingest:** route fenic semantic pipeline through controlplane proxy (TD-2887) ([#631](https://github.com/typedef-ai/typedef/issues/631)) ([ecc627b](https://github.com/typedef-ai/typedef/commit/ecc627b8e65f854e760013c6b0864bfc25dc71b8))


### Bug Fixes

* **desktop:** pin dbt target/log paths to project root ([#640](https://github.com/typedef-ai/typedef/issues/640)) ([b5715d4](https://github.com/typedef-ai/typedef/commit/b5715d423fd43bd5ad0a007e3c67a19415bff34e))
* **desktop:** regenerate dbt docs when base advances before sync ([#630](https://github.com/typedef-ai/typedef/issues/630)) ([288ea7b](https://github.com/typedef-ai/typedef/commit/288ea7b59463c7ed0e321a1972e5f2ba3b19f050))
* enable Snowflake secondary roles in wizard ([#634](https://github.com/typedef-ai/typedef/issues/634)) ([7411da5](https://github.com/typedef-ai/typedef/commit/7411da524cddf9e27016dd2fe9259348083dfbd1))

## [0.21.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.20.0...typedef-data-intelligence-v0.21.0) (2026-04-28)


### Features

* **controlplane:** LLM proxy service + multi-dimensional usage counter (GA Phase 2) ([#585](https://github.com/typedef-ai/typedef/issues/585)) ([91399dc](https://github.com/typedef-ai/typedef/commit/91399dc93a8f04b978bafdc15565994c5f5961af))
* **databricks:** Phase A backend (core reads + audit checklist) (TD-2730) ([#600](https://github.com/typedef-ai/typedef/issues/600)) ([4e8d120](https://github.com/typedef-ai/typedef/commit/4e8d120e5a146b080e2d57da0101d4ca5a7cc6f8))

## [0.20.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.19.0...typedef-data-intelligence-v0.20.0) (2026-04-28)


### Features

* **databricks:** platform wiring for config + types + factory + deps + OpenLineage + graph schema (TD-2729) ([#597](https://github.com/typedef-ai/typedef/issues/597)) ([01af087](https://github.com/typedef-ai/typedef/commit/01af08750af2dadbf24b890ed0fff6373125803a))


### Bug Fixes

* **desktop:** export DBT_PROJECT_DIR + parity for Snowflake env_vars (TD-2888) ([#603](https://github.com/typedef-ai/typedef/issues/603)) ([7300127](https://github.com/typedef-ai/typedef/commit/7300127633edb4cba9a40f868e1ba1025e8b37d8))

## [0.19.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.18.0...typedef-data-intelligence-v0.19.0) (2026-04-25)


### Features

* **desktop:** add Clerk auth gate with org auto-select and user tracking ([16a01e7](https://github.com/typedef-ai/typedef/commit/16a01e7826837bc1f5f4ec2e02f439c975c30876))
* **desktop:** add Clerk auth gate with org auto-select and user tracking ([#555](https://github.com/typedef-ai/typedef/issues/555)) ([16a01e7](https://github.com/typedef-ai/typedef/commit/16a01e7826837bc1f5f4ec2e02f439c975c30876))
* **ingest:** profile views with row-count-only lightweight mode ([#594](https://github.com/typedef-ai/typedef/issues/594)) ([306210c](https://github.com/typedef-ai/typedef/commit/306210cf7ba8ac82f4a16543c58f5d8971d78b30))
* **snowflake:** PAT authentication alongside private-key ([#590](https://github.com/typedef-ai/typedef/issues/590)) ([68c9ec4](https://github.com/typedef-ai/typedef/commit/68c9ec4026ad434b19c62428d35fdb9cf59f490b))


### Bug Fixes

* **desktop:** add personal Clerk org fallback ([16a01e7](https://github.com/typedef-ai/typedef/commit/16a01e7826837bc1f5f4ec2e02f439c975c30876))
* **desktop:** broker OAuth token persistence via signed Rust binary ([#583](https://github.com/typedef-ai/typedef/issues/583)) ([4fbb7ff](https://github.com/typedef-ai/typedef/commit/4fbb7ff5f0891075ad67df2a76bc194a868c414a))
* **desktop:** fix useOrganizationList destructuring for Clerk SDK types ([16a01e7](https://github.com/typedef-ai/typedef/commit/16a01e7826837bc1f5f4ec2e02f439c975c30876))
* prune unrelated sync menu cleanup ([16a01e7](https://github.com/typedef-ai/typedef/commit/16a01e7826837bc1f5f4ec2e02f439c975c30876))
* remove unused .retryButton CSS from AuthGate ([16a01e7](https://github.com/typedef-ai/typedef/commit/16a01e7826837bc1f5f4ec2e02f439c975c30876))
* simplify auth gate deps, dedupe CSS, downgrade per-request logging ([16a01e7](https://github.com/typedef-ai/typedef/commit/16a01e7826837bc1f5f4ec2e02f439c975c30876))
* update middleware docstring and restrict org auto-select to single-org users ([16a01e7](https://github.com/typedef-ai/typedef/commit/16a01e7826837bc1f5f4ec2e02f439c975c30876))

## [0.18.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.17.2...typedef-data-intelligence-v0.18.0) (2026-04-22)


### Features

* migrate reports and plans to blob_storage with new blob schema ([#556](https://github.com/typedef-ai/typedef/issues/556)) ([2c7b674](https://github.com/typedef-ai/typedef/commit/2c7b6748555968267b5dbe861a38748b92b91ab2))

## [0.17.2](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.17.1...typedef-data-intelligence-v0.17.2) (2026-04-21)


### Bug Fixes

* **dbt:** derive adapter from profiles.yml so worktrees pick the right venv ([#571](https://github.com/typedef-ai/typedef/issues/571)) ([e6478ed](https://github.com/typedef-ai/typedef/commit/e6478edf083e2fce5ea341d1c0be103ed9736a72))

## [0.17.1](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.17.0...typedef-data-intelligence-v0.17.1) (2026-04-20)


### Bug Fixes

* **desktop:** bundle uv for packaged dbt bootstrap ([#564](https://github.com/typedef-ai/typedef/issues/564)) ([69ee369](https://github.com/typedef-ai/typedef/commit/69ee3698fdce9f82b74e50bd876596eb4937003e))

## [0.17.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.16.1...typedef-data-intelligence-v0.17.0) (2026-04-20)


### Features

* **linear:** replace dual API keys with OAuth PKCE ([#543](https://github.com/typedef-ai/typedef/issues/543)) ([8de84ab](https://github.com/typedef-ai/typedef/commit/8de84ab4ce8994e2397a80ea4ffbdfb81ce38f4f))

## [0.16.1](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.16.0...typedef-data-intelligence-v0.16.1) (2026-04-16)


### Bug Fixes

* fix add project dbt build regression and tweak terminal sizes and clone messages ([#541](https://github.com/typedef-ai/typedef/issues/541)) ([5e49c09](https://github.com/typedef-ai/typedef/commit/5e49c096211c40bb60c6a6372443409e0228cc56))

## [0.16.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.15.0...typedef-data-intelligence-v0.16.0) (2026-04-15)


### Features

* Add ingest library version tracking and fix some bugs and behavior ([#528](https://github.com/typedef-ai/typedef/issues/528)) ([5d5dc7e](https://github.com/typedef-ai/typedef/commit/5d5dc7ee59cf5f0dca7714207f03d491dea033e1))
* **desktop:** telemetry disclosure consent modal and opt-out ([#540](https://github.com/typedef-ai/typedef/issues/540)) ([1063df9](https://github.com/typedef-ai/typedef/commit/1063df98d60a887974833928b05ce92ed63d1538))
* **mcp:** add read-only SurrealQL, schema overview, and describe_kind tools ([#530](https://github.com/typedef-ai/typedef/issues/530)) ([d2809fe](https://github.com/typedef-ai/typedef/commit/d2809feee5a4bc8539f7495d48ef11cf650dfec4))


### Bug Fixes

* autosave integrations on test success, SfAuthMode enum, secret placeholders (TD-2680) ([#525](https://github.com/typedef-ai/typedef/issues/525)) ([cffccc9](https://github.com/typedef-ai/typedef/commit/cffccc97beb49b4580cd0b5dd30b68ed0afd94f8))
* **desktop:** serialize sfauthtype manually as str ([#538](https://github.com/typedef-ai/typedef/issues/538)) ([2464a5b](https://github.com/typedef-ai/typedef/commit/2464a5b59b16a1d41cbd038480989402056e9bd1))
* sync state during medallion init and sync colors ([#533](https://github.com/typedef-ai/typedef/issues/533)) ([870a569](https://github.com/typedef-ai/typedef/commit/870a5691ea28d2da63f1531b2c1e6156dd533345))

## [0.15.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.14.0...typedef-data-intelligence-v0.15.0) (2026-04-15)


### Features

* **desktop-graph:** rewrite inspect_node with markdown output and inline findings (TD-2605) ([#508](https://github.com/typedef-ai/typedef/issues/508)) ([05767ad](https://github.com/typedef-ai/typedef/commit/05767ad3553ec7717c7c2abe7dcac04504a86561))
* **desktop:** add Fivetran integration to setup wizard ([#519](https://github.com/typedef-ai/typedef/issues/519)) ([f90afd0](https://github.com/typedef-ai/typedef/commit/f90afd076f3aad34d0a8d1a8565f357e2e27f0d2))
* **desktop:** add project configuration recovery flow ([#518](https://github.com/typedef-ai/typedef/issues/518)) ([c692f4d](https://github.com/typedef-ai/typedef/commit/c692f4d7f13cf7316404c0be2c40ee906935cfe2))


### Bug Fixes

* **desktop:** add project configuration recovery flow ([c692f4d](https://github.com/typedef-ai/typedef/commit/c692f4d7f13cf7316404c0be2c40ee906935cfe2))
* **desktop:** clarify catalog sync recovery next steps ([c692f4d](https://github.com/typedef-ai/typedef/commit/c692f4d7f13cf7316404c0be2c40ee906935cfe2))
* **desktop:** smooth project recovery sync UX ([c692f4d](https://github.com/typedef-ai/typedef/commit/c692f4d7f13cf7316404c0be2c40ee906935cfe2))
* **setup:** surface filtered dbt errors when docs generate fails (TD-2617) ([#509](https://github.com/typedef-ai/typedef/issues/509)) ([ac7ce2e](https://github.com/typedef-ai/typedef/commit/ac7ce2e082e4ff9bd4244ffe6f07835cfc44eed1))

## [0.14.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.13.0...typedef-data-intelligence-v0.14.0) (2026-04-14)


### Features

* backend endpoint for catalog health statuses ([#483](https://github.com/typedef-ai/typedef/issues/483)) ([ad97d8b](https://github.com/typedef-ai/typedef/commit/ad97d8baf364ee0d80f4f459bdafdebddd7ed573))


### Bug Fixes

* **desktop:** resume setup retry after worktree creation ([#487](https://github.com/typedef-ai/typedef/issues/487)) ([165652b](https://github.com/typedef-ai/typedef/commit/165652bbb774848987b89b346e94f32cf61197d9))
* **desktop:** surface full clone errors ([#502](https://github.com/typedef-ai/typedef/issues/502)) ([f87cfeb](https://github.com/typedef-ai/typedef/commit/f87cfeb273e9122b22142a79be269b0d8a858713))
* **setup:** validate Salesforce client ID and add cancel for OAuth flow (TD-2669) ([#497](https://github.com/typedef-ai/typedef/issues/497)) ([b461457](https://github.com/typedef-ai/typedef/commit/b4614572e1b18b33924fab315554983f7a5f8816))

## [0.13.0](https://github.com/typedef-ai/typedef/compare/typedef-data-intelligence-v0.12.2...typedef-data-intelligence-v0.13.0) (2026-04-13)


### Features

* add LookML card to Settings integrations page ([eecabf7](https://github.com/typedef-ai/typedef/commit/eecabf71306b0f849f06cf3bad23b3743d89862d))
* add LookML integration to desktop and TUI setup wizards ([eecabf7](https://github.com/typedef-ai/typedef/commit/eecabf71306b0f849f06cf3bad23b3743d89862d))
* add LookML integration to desktop and TUI setup wizards ([#413](https://github.com/typedef-ai/typedef/issues/413)) ([eecabf7](https://github.com/typedef-ai/typedef/commit/eecabf71306b0f849f06cf3bad23b3743d89862d))
* **agent,desktop:** iterative planning, ask_user tool, and plan infrastructure rebuild ([#416](https://github.com/typedef-ai/typedef/issues/416)) ([23e58c3](https://github.com/typedef-ai/typedef/commit/23e58c35cbc42f67a708f2e485ead8fd7850ecde))
* **agent:** add project orientation layer for desktop agents (TD-2388) ([#351](https://github.com/typedef-ai/typedef/issues/351)) ([5db9a2f](https://github.com/typedef-ai/typedef/commit/5db9a2f360da91d7c2ce64609450fd8f98fb78b6))
* **agent:** define mode and sub-agent capabilities (TD-2460) ([#406](https://github.com/typedef-ai/typedef/issues/406)) ([0295dc0](https://github.com/typedef-ai/typedef/commit/0295dc00c5aac72b6818b0b376db87ca610e498c))
* **agent:** profiler reads graph first, delete DataProfileBackend (TD-2525, TD-2500) ([#475](https://github.com/typedef-ai/typedef/issues/475)) ([6964c70](https://github.com/typedef-ai/typedef/commit/6964c70efe274352362ee41cbc42e3074c2ceb70))
* **agent:** reduce agent handoff token spend with todo-based delegation ([#317](https://github.com/typedef-ai/typedef/issues/317)) ([471f0d8](https://github.com/typedef-ai/typedef/commit/471f0d88297e568e75ef13813559740b242aa606))
* **core,desktop:** canonical entity ID scheme for consistent cross-layer linking (TD-2365) ([#352](https://github.com/typedef-ai/typedef/issues/352)) ([65ab7cc](https://github.com/typedef-ai/typedef/commit/65ab7cc62770c88a6bc57aa06a2146809de64a53))
* **desktop:** add guided quick start onboarding ([#403](https://github.com/typedef-ai/typedef/issues/403)) ([f8967b0](https://github.com/typedef-ai/typedef/commit/f8967b074e353ba22f1ff2106aaab08e43ea739f))
* **desktop:** add profiling toggle to sync wizard and settings (TD-2453) ([#457](https://github.com/typedef-ai/typedef/issues/457)) ([15a801a](https://github.com/typedef-ai/typedef/commit/15a801a3b95531162c1b68979750f69e60b3103e))
* **desktop:** add worktree removal flow ([#359](https://github.com/typedef-ai/typedef/issues/359)) ([b4a4fff](https://github.com/typedef-ai/typedef/commit/b4a4fffa92a6c777cd221e4780c7193b306d463a))
* **desktop:** auto-spawn backend sidecar with project switch restart (TD-2352) ([#330](https://github.com/typedef-ai/typedef/issues/330)) ([e79a54f](https://github.com/typedef-ai/typedef/commit/e79a54f6a7cc39ecc68379839541600204282fdb))
* **desktop:** chart rendering ([#377](https://github.com/typedef-ai/typedef/issues/377)) ([7717c37](https://github.com/typedef-ai/typedef/commit/7717c3782b745e69b5d5ecdd984abb74cefe798b))
* **desktop:** Claude Code delegation with live tool tracking and post-completion verification ([#355](https://github.com/typedef-ai/typedef/issues/355)) ([9909216](https://github.com/typedef-ai/typedef/commit/9909216336c3560a31e0d97134993e737bfaa2d7))
* **desktop:** Claude Code delegation with live tool tracking and post-completion verification ([#367](https://github.com/typedef-ai/typedef/issues/367)) ([569c9a9](https://github.com/typedef-ai/typedef/commit/569c9a9e72ec68f15f1be982ef6169c666b6a647))
* **desktop:** copy dbt_packages into new worktrees (TD-2559) ([#437](https://github.com/typedef-ai/typedef/issues/437)) ([73b7b9f](https://github.com/typedef-ai/typedef/commit/73b7b9fa7a9158f2a191ea0b8c768953b2b1e647))
* **desktop:** generalize worktree clone support for duckdb ([#402](https://github.com/typedef-ai/typedef/issues/402)) ([62db2f4](https://github.com/typedef-ai/typedef/commit/62db2f4e7322e665364e833dc40e5d8b2f7590a6))
* **desktop:** harden worktree and chat management ([#373](https://github.com/typedef-ai/typedef/issues/373)) ([cf6bd8b](https://github.com/typedef-ai/typedef/commit/cf6bd8b3fcb838e29bade315f010d60ab0945119))
* **desktop:** L1 Overview Redesign ([#395](https://github.com/typedef-ai/typedef/issues/395)) ([bc0304b](https://github.com/typedef-ai/typedef/commit/bc0304bbd577c59e3cbd232773d64e6913d01d0e))
* **desktop:** managed SurrealDB sidecar with RocksDB backend (TD-2382) ([#331](https://github.com/typedef-ai/typedef/issues/331)) ([b5e7425](https://github.com/typedef-ai/typedef/commit/b5e7425c697a262edb4da8335ab17ebb493aeda7))
* **desktop:** native desktop app prototype ([#323](https://github.com/typedef-ai/typedef/issues/323)) ([11e61b6](https://github.com/typedef-ai/typedef/commit/11e61b6b4934344b1f5523977d184834c74d151e))
* **desktop:** option to clone data on worktree creation ([19bfafc](https://github.com/typedef-ai/typedef/commit/19bfafcb9bd0cc16582882760d4f114aef16dedc))
* **desktop:** option to clone data on worktree creation ([#368](https://github.com/typedef-ai/typedef/issues/368)) ([19bfafc](https://github.com/typedef-ai/typedef/commit/19bfafcb9bd0cc16582882760d4f114aef16dedc))
* **desktop:** overhaul catalog search (TD-2386, TD-2379) ([#357](https://github.com/typedef-ai/typedef/issues/357)) ([2372b87](https://github.com/typedef-ai/typedef/commit/2372b87a386665b8b8bc98b1844cc36137737207))
* **desktop:** rework delegation as data-aware Claude Code integration (Phase A) ([#446](https://github.com/typedef-ai/typedef/issues/446)) ([6ce10e4](https://github.com/typedef-ai/typedef/commit/6ce10e4ade69d6fb726ce87a26240b69ff2f2f37))
* **desktop:** salesforce multi-auth with OAuth browser login (TD-2583) ([#451](https://github.com/typedef-ai/typedef/issues/451)) ([542033e](https://github.com/typedef-ai/typedef/commit/542033ea3b1d95d290ec1dbc2ac10c5f67220b5f))
* **desktop:** secure credential storage via OS keychain (TD-2414) ([#415](https://github.com/typedef-ai/typedef/issues/415)) ([c597086](https://github.com/typedef-ai/typedef/commit/c5970868eded9eac329ccb3223bd74fde4a7a3f9))
* **desktop:** setup wizard, sync pipeline, settings & multi-project ([#329](https://github.com/typedef-ai/typedef/issues/329)) ([7c8a629](https://github.com/typedef-ai/typedef/commit/7c8a62957ca1fe2b26f6be61c9bbd08838e93f24))
* **desktop:** ship preloaded trial key support for ff builds ([#454](https://github.com/typedef-ai/typedef/issues/454)) ([a9873b8](https://github.com/typedef-ai/typedef/commit/a9873b82dc537d0b4d34f9d574951183c3f9c135))
* hide base worktree from desktop chats ([#461](https://github.com/typedef-ai/typedef/issues/461)) ([7dbb155](https://github.com/typedef-ai/typedef/commit/7dbb15564a7a0918979e32c5cd7202fb05caf809))
* **ingest,agent:** semantic domain index for agent orientation (TD-2436) ([#399](https://github.com/typedef-ai/typedef/issues/399)) ([962a02c](https://github.com/typedef-ai/typedef/commit/962a02cfec109f8d95ca49292a72921460ad37d3))
* **ingest:** add MetricFlow semantic manifest ingestion to unified graph ([#401](https://github.com/typedef-ai/typedef/issues/401)) ([8f98e62](https://github.com/typedef-ai/typedef/commit/8f98e62796deafbd00da8d6ec418ba8e934423e3))
* **ingest:** add unified ingest pipeline and type inference engine ([#325](https://github.com/typedef-ai/typedef/issues/325)) ([f2468bd](https://github.com/typedef-ai/typedef/commit/f2468bd17c2a32a2cbb85cee494c0680321f21d2))
* **ingest:** port Fivetran integration to unified lineage system (TD-2423) ([#346](https://github.com/typedef-ai/typedef/issues/346)) ([0df51ea](https://github.com/typedef-ai/typedef/commit/0df51ea0412cecfa659813be3adf8c20c217eefb))
* **ingest:** port LookML/Looker integration to unified graph ([#398](https://github.com/typedef-ai/typedef/issues/398)) ([bdafa7b](https://github.com/typedef-ai/typedef/commit/bdafa7b842db20cea815abab2c79b4e822aa5e4b)), closes [#175](https://github.com/typedef-ai/typedef/issues/175)
* persist chat sessions to disk (TD-2562) ([#466](https://github.com/typedef-ai/typedef/issues/466)) ([3c3aa24](https://github.com/typedef-ai/typedef/commit/3c3aa242ba931e8d81f6719d4e10e57c637c4c7e))
* **service:** expose unified workflow via API/devtool CLI/docs ([#326](https://github.com/typedef-ai/typedef/issues/326)) ([befb626](https://github.com/typedef-ai/typedef/commit/befb626105ad6fde21c3ed2ff0134fac5e98cdfc))
* unified agent request for input bar and delegation tweaks ([#447](https://github.com/typedef-ai/typedef/issues/447)) ([5c4ea07](https://github.com/typedef-ai/typedef/commit/5c4ea0749a183e312f647fc736bd4e3a52b98760))
* unify TypeStore with graph metadata and merge agent toolsets (TD-2509, TD-2512) ([#417](https://github.com/typedef-ai/typedef/issues/417)) ([ec43be8](https://github.com/typedef-ai/typedef/commit/ec43be893a5f063d963a4eb5dfb8cffc5db16db3))


### Bug Fixes

* claude delegation loopback break ([#376](https://github.com/typedef-ai/typedef/issues/376)) ([db4775c](https://github.com/typedef-ai/typedef/commit/db4775c8e31478501c3325d43a9d2961401dd451))
* **desktop:** finish quickstart catalog readiness ([#443](https://github.com/typedef-ai/typedef/issues/443)) ([4fa87ad](https://github.com/typedef-ai/typedef/commit/4fa87adabb561f17968713df88ac63748bb67b22))
* **desktop:** fix search facets, L2 detail routing, and group disambiguation ([#422](https://github.com/typedef-ai/typedef/issues/422)) ([51d21c0](https://github.com/typedef-ai/typedef/commit/51d21c09ce2865be2c036cd456b169d0170c0225))
* **desktop:** handle self-profiled worktrees and create errors ([19bfafc](https://github.com/typedef-ai/typedef/commit/19bfafcb9bd0cc16582882760d4f114aef16dedc))
* **desktop:** keep LookML + add Fivetran to settings ([#419](https://github.com/typedef-ai/typedef/issues/419)) ([faac4ab](https://github.com/typedef-ai/typedef/commit/faac4ab52d065a02e0a49290122d670fcc05efb2))
* **desktop:** load UnifiedConfig in standalone mode so model tiers resolve (TD-2434) ([#356](https://github.com/typedef-ai/typedef/issues/356)) ([e56cdba](https://github.com/typedef-ai/typedef/commit/e56cdba032d0c23a4738e31466be6893ea5fa242))
* **desktop:** scope worktree directory per project ([#473](https://github.com/typedef-ai/typedef/issues/473)) ([f4d8017](https://github.com/typedef-ai/typedef/commit/f4d80172ab48065e6b20cbc443f98c4559742ba6))
* **desktop:** SSE endpoint handles shutdown ([#363](https://github.com/typedef-ai/typedef/issues/363)) ([05319c4](https://github.com/typedef-ai/typedef/commit/05319c4561b5280d136d1586c569ab48954f68a8))
* **desktop:** streamline worktree clone status interactions ([19bfafc](https://github.com/typedef-ai/typedef/commit/19bfafcb9bd0cc16582882760d4f114aef16dedc))
* local dev improvements for backend, Linear, and TUI ([#335](https://github.com/typedef-ai/typedef/issues/335)) ([2feb268](https://github.com/typedef-ai/typedef/commit/2feb268792d278febbfb45755702cdc3af20b589))
* more project switch bugs ([#440](https://github.com/typedef-ai/typedef/issues/440)) ([e64c33d](https://github.com/typedef-ai/typedef/commit/e64c33daa6e1785741dfc469db1aabcde457c98f))
* prevent DBT_PROFILES_DIR from leaking into dbt subprocesses ([#316](https://github.com/typedef-ai/typedef/issues/316)) ([1b6ecf7](https://github.com/typedef-ai/typedef/commit/1b6ecf752e7b1f8f232d161023e8914d5764f1b0))
* sync, surreal context, and catalog are always project-level ([#428](https://github.com/typedef-ai/typedef/issues/428)) ([001e8c2](https://github.com/typedef-ai/typedef/commit/001e8c22e8f37559860b74ee58904e765175f076))
* use core.paths for typedef home resolution (TD-2507, TD-2561) ([#450](https://github.com/typedef-ai/typedef/issues/450)) ([f2f4344](https://github.com/typedef-ai/typedef/commit/f2f4344f0e13283c0d52d860b5506de924f98efb))
* worktree sidebar load times by caching and other fixes ([#389](https://github.com/typedef-ai/typedef/issues/389)) ([827480d](https://github.com/typedef-ai/typedef/commit/827480daf6ede32a644170074b602ef80e0d297d))


### Performance Improvements

* **type-inference:** cache concept index to avoid redundant build ([30a71b1](https://github.com/typedef-ai/typedef/commit/30a71b10dd733043d1bc2efb0f3acee1fbf27c8a))
* **unified:** extract index creation from ensure_tables and use ([30a71b1](https://github.com/typedef-ai/typedef/commit/30a71b10dd733043d1bc2efb0f3acee1fbf27c8a))
* **unified:** extract index creation from ensure_tables and use CONCURRENTLY (TD-2362/TD-2363) ([#378](https://github.com/typedef-ai/typedef/issues/378)) ([30a71b1](https://github.com/typedef-ai/typedef/commit/30a71b10dd733043d1bc2efb0f3acee1fbf27c8a))

## [0.12.2](https://github.com/typedef-ai/data-intelligence/compare/typedef-data-intelligence-v0.12.1...typedef-data-intelligence-v0.12.2) (2026-03-09)


### Bug Fixes

* patch DuckDB add-project, env loading, and sync log noise ([#301](https://github.com/typedef-ai/data-intelligence/issues/301)) ([ba091fd](https://github.com/typedef-ai/data-intelligence/commit/ba091fd38dcb4ce6248214932c1e829244c46dd0))
* set default schema to main for duckdb and logs in wizard ([#299](https://github.com/typedef-ai/data-intelligence/issues/299)) ([6683da7](https://github.com/typedef-ai/data-intelligence/commit/6683da704fee2efbe4719e0b48183fe66078fce0))
* **tui:** harden backend lifecycle cleanup and stale reaping ([#297](https://github.com/typedef-ai/data-intelligence/issues/297)) ([7a9aa92](https://github.com/typedef-ai/data-intelligence/commit/7a9aa92bc7223af91fee5c8afe9fcbd14d14e358))
* **tui:** reposition slash command menu on initial chat screen ([#304](https://github.com/typedef-ai/data-intelligence/issues/304)) ([e9ec444](https://github.com/typedef-ai/data-intelligence/commit/e9ec4445693e42381e9144e095ef0cff3ab52c98))

## [0.12.1](https://github.com/typedef-ai/data-intelligence/compare/v0.12.0...v0.12.1) (2026-03-07)


### Bug Fixes

* **tui:** harden backend lifecycle cleanup and stale reaping ([#297](https://github.com/typedef-ai/data-intelligence/issues/297)) ([7a9aa92](https://github.com/typedef-ai/data-intelligence/commit/7a9aa92bc7223af91fee5c8afe9fcbd14d14e358))

## [0.12.0](https://github.com/typedef-ai/data-intelligence/compare/v0.11.0...v0.12.0) (2026-03-05)


### Features

* benchmarks support duckdb warehouse ([#279](https://github.com/typedef-ai/data-intelligence/issues/279)) ([63355cf](https://github.com/typedef-ai/data-intelligence/commit/63355cffdcecd19aa3ea3664bb6dab0a6b97f69b))


### Bug Fixes

* **packaging:** declare skills dependency and add wheel smoke imports ([#287](https://github.com/typedef-ai/data-intelligence/issues/287)) ([5f1e427](https://github.com/typedef-ai/data-intelligence/commit/5f1e427dca594ade39bb3d0c22dabcb4414f814c))

## [0.11.0](https://github.com/typedef-ai/data-intelligence/compare/v0.10.0...v0.11.0) (2026-03-03)


### Features

* **tui:** add `/status` command ([#282](https://github.com/typedef-ai/data-intelligence/issues/282)) ([f5c47ad](https://github.com/typedef-ai/data-intelligence/commit/f5c47ad93486b2f479eaa9abb77f6006c2fc0207))
* **tui:** add slash command autocomplete menu in chat input ([#277](https://github.com/typedef-ai/data-intelligence/issues/277)) ([1f2029c](https://github.com/typedef-ai/data-intelligence/commit/1f2029c42c67ae7b770c7a0403680d2b73392f1f))

## [0.10.0](https://github.com/typedef-ai/data-intelligence/compare/v0.9.0...v0.10.0) (2026-03-02)


### Features

* **agent:** 5-specialist architecture with progressive skill disclosure ([#251](https://github.com/typedef-ai/data-intelligence/issues/251)) ([a12a73e](https://github.com/typedef-ai/data-intelligence/commit/a12a73ecdec51cd00eabd3423274432363636b7a))
* **agent:** Graph-first agent prompts, grain validation, and benchmark tooling ([#266](https://github.com/typedef-ai/data-intelligence/issues/266)) ([fb17aef](https://github.com/typedef-ai/data-intelligence/commit/fb17aefff3312c8f61b1d53a68d073c610e96f28))
* **agent:** robustness improvements + replace custom todo toolset with pydantic-ai-todo ([#257](https://github.com/typedef-ai/data-intelligence/issues/257)) ([017eeba](https://github.com/typedef-ai/data-intelligence/commit/017eebac5452e1301e766ef989f9b9c6a0e08517))
* **benchmark:** agentic judge, rubric templates, results pipeline, and reporter dashboards ([#233](https://github.com/typedef-ai/data-intelligence/issues/233)) ([21de8f3](https://github.com/typedef-ai/data-intelligence/commit/21de8f377de736ce5a31f69fedd0fb1b4c822be4))
* bm workspaces for isolated task generation+validation ([#181](https://github.com/typedef-ai/data-intelligence/issues/181)) ([411e377](https://github.com/typedef-ai/data-intelligence/commit/411e3774ca3d6d388176707833fe468b8f7eec30))
* **data:** add DuckDB backend support with init wizard selector (TD-2187) ([#273](https://github.com/typedef-ai/data-intelligence/issues/273)) ([d741680](https://github.com/typedef-ai/data-intelligence/commit/d741680e6e516d75e64cee0c122a65fa01b8cc41))
* **tui:** minor performance improvements ([#268](https://github.com/typedef-ai/data-intelligence/issues/268)) ([1358244](https://github.com/typedef-ai/data-intelligence/commit/1358244090ffca736db9254a6c7e21e1b287f219))


### Bug Fixes

* **tui:** align wizard palette with app theme ([#275](https://github.com/typedef-ai/data-intelligence/issues/275)) ([fcc6b94](https://github.com/typedef-ai/data-intelligence/commit/fcc6b948cc3cf7d337e830d12f9700edfae6848b))
* **tui:** cleaner approach to clearing the chat box ([#259](https://github.com/typedef-ai/data-intelligence/issues/259)) ([160144d](https://github.com/typedef-ai/data-intelligence/commit/160144d67f0c9704bf7947dc653662645b3bc9d9))

## [0.9.0](https://github.com/typedef-ai/data-intelligence/compare/v0.8.0...v0.9.0) (2026-02-26)


### Features

* **tui:** improve chat focus + busy feedback ([#252](https://github.com/typedef-ai/data-intelligence/issues/252)) ([712a5f1](https://github.com/typedef-ai/data-intelligence/commit/712a5f1e2fd4139ad9c85ec831362b3aa832f105))

## [0.8.0](https://github.com/typedef-ai/data-intelligence/compare/v0.7.0...v0.8.0) (2026-02-25)


### Features

* **agent:** add ProjectOverview graph node and expose as tool (TD-2149) ([#247](https://github.com/typedef-ai/data-intelligence/issues/247)) ([bd4509d](https://github.com/typedef-ai/data-intelligence/commit/bd4509d7390be2b40a96e314c168eded1c3ae672))
* capture additional Salesforce field properties on SfField ([#248](https://github.com/typedef-ai/data-intelligence/issues/248)) ([8659b4b](https://github.com/typedef-ai/data-intelligence/commit/8659b4b2df39a7485b580011e17812fb6fb053b0))
* scope-level column lineage with structural edge tracking (TD-2087, TD-2088) ([#207](https://github.com/typedef-ai/data-intelligence/issues/207)) ([eb02897](https://github.com/typedef-ai/data-intelligence/commit/eb028973121076b9caf5b4b3b15c2f48adf4b4e8))
* **tui:** move artifacts to modal and add compact activity modal ([#250](https://github.com/typedef-ai/data-intelligence/issues/250)) ([e403fa3](https://github.com/typedef-ai/data-intelligence/commit/e403fa3eee083f944e16f30bde4e837b0148ec99))
* **tui:** unify help and shortcuts UX for keyboard-first guidance ([#240](https://github.com/typedef-ai/data-intelligence/issues/240)) ([5c00bf8](https://github.com/typedef-ai/data-intelligence/commit/5c00bf87ef2c81992c3d4c2d3478c7f27707d4fa))
* **tui:** unify shortcuts help and center command palette modal ([#243](https://github.com/typedef-ai/data-intelligence/issues/243)) ([a293811](https://github.com/typedef-ai/data-intelligence/commit/a29381122359c2b2c90816550fdbde940f0bfd8a))


### Bug Fixes

* lineage mcp works with claude code pipeline ([#163](https://github.com/typedef-ai/data-intelligence/issues/163)) ([f5cfdbf](https://github.com/typedef-ai/data-intelligence/commit/f5cfdbf0a64c86eac5a09f72d8631c8966eac899))
* **tui:** prevent collapsible title mount errors in chat tool blocks ([#246](https://github.com/typedef-ai/data-intelligence/issues/246)) ([792bbc4](https://github.com/typedef-ai/data-intelligence/commit/792bbc49778fe9dd2e12df02969289b3a6527298))
* **tui:** refine wizard nav layout and focus visibility ([#237](https://github.com/typedef-ai/data-intelligence/issues/237)) ([fbefbba](https://github.com/typedef-ai/data-intelligence/commit/fbefbba19fc8767e19b0f3ea39dc93e7f0915e04))


### Performance Improvements

* **agent:** Optimize SHOW TERSE semantic commands to avoid account-wide scan (TD-2169) ([#239](https://github.com/typedef-ai/data-intelligence/issues/239)) ([9f95847](https://github.com/typedef-ai/data-intelligence/commit/9f95847810dfedec0213db6ca11c9da10b3cfc18))

## [0.7.0](https://github.com/typedef-ai/data-intelligence/compare/v0.6.0...v0.7.0) (2026-02-20)


### Features

* add generic report schema with cross-platform IR and Salesforce integration ([#168](https://github.com/typedef-ai/data-intelligence/issues/168)) ([a80ec62](https://github.com/typedef-ai/data-intelligence/commit/a80ec62d34797873daaa0230a111fb90d22f2ac6))
* claude code SDK proc agent supported by bedrock ([#219](https://github.com/typedef-ai/data-intelligence/issues/219)) ([b1141fb](https://github.com/typedef-ai/data-intelligence/commit/b1141fba09247b93892f5c6d7a36c3af9bb2a51a))
* create PhysicalTable nodes for dbt sources ([#173](https://github.com/typedef-ai/data-intelligence/issues/173)) ([e2f2973](https://github.com/typedef-ai/data-intelligence/commit/e2f2973284d9c643717ee15198d99e842bce1dae))
* falkor copy and write exclusion ([#218](https://github.com/typedef-ai/data-intelligence/issues/218)) ([007c1ca](https://github.com/typedef-ai/data-intelligence/commit/007c1ca20f486ee4ea7e46b8cbca154d50b55b0f))
* lineage batch updates to falkordb during bulk_load and fingerprint optimization ([#190](https://github.com/typedef-ai/data-intelligence/issues/190)) ([fb04130](https://github.com/typedef-ai/data-intelligence/commit/fb041301c7201969d2c703b470f3164da256c495))
* **tui:** add progressive startup and dependency readiness checks ([#230](https://github.com/typedef-ai/data-intelligence/issues/230)) ([8eef3a5](https://github.com/typedef-ai/data-intelligence/commit/8eef3a573686192846077a8cac3dfd1e705addd2))
* **tui:** copy on highlight ([#226](https://github.com/typedef-ai/data-intelligence/issues/226)) ([e1e5002](https://github.com/typedef-ai/data-intelligence/commit/e1e50029c3b449804ed00aea690c1d96472efc06))
* **tui:** polish startup loading and adaptive status bar hints ([#231](https://github.com/typedef-ai/data-intelligence/issues/231)) ([5379b13](https://github.com/typedef-ai/data-intelligence/commit/5379b131dcb51000be349fc8f35d05c92cbc040e))
* **tui:** unify chat into one screen ([#225](https://github.com/typedef-ai/data-intelligence/issues/225)) ([32c0806](https://github.com/typedef-ai/data-intelligence/commit/32c0806983015cfd0f846fd2aa3f65d1c1744935))


### Bug Fixes

* auto-create DbtColumn nodes from SQL for undocumented models ([#188](https://github.com/typedef-ai/data-intelligence/issues/188)) ([2057129](https://github.com/typedef-ai/data-intelligence/commit/20571299c980a5e1014d88db47446b950698a735))
* linear mcp test should always use DEV team and should clean up issues ([#203](https://github.com/typedef-ai/data-intelligence/issues/203)) ([189a676](https://github.com/typedef-ai/data-intelligence/commit/189a676f0fb769129222fbef4d976846a452498e))
* resolve column lineage for CASE WHEN inside aggregations (TD-2084) ([#195](https://github.com/typedef-ai/data-intelligence/issues/195)) ([4204414](https://github.com/typedef-ai/data-intelligence/commit/4204414470cd6859d79c579bcb9513f655c1d082))
* **tui:** preserve wizard step state when navigating back ([#221](https://github.com/typedef-ai/data-intelligence/issues/221)) ([fd08314](https://github.com/typedef-ai/data-intelligence/commit/fd083143e3ae8134ce191ead04177c5052216582))

## [0.6.0](https://github.com/typedef-ai/data-intelligence/compare/v0.5.0...v0.6.0) (2026-02-12)

### Features

- add uv workspace dependency-groups for unified installs ([#161](https://github.com/typedef-ai/data-intelligence/issues/161)) ([c227af5](https://github.com/typedef-ai/data-intelligence/commit/c227af5324a4043cce57e68d772a2baefc9fdd79))
- **ci:** add tests github actions workflow ([#184](https://github.com/typedef-ai/data-intelligence/issues/184)) ([abd25df](https://github.com/typedef-ai/data-intelligence/commit/abd25dff27bbbd6b9a0bc962865f49cfdde0e59d))
- claude_code skills ([#171](https://github.com/typedef-ai/data-intelligence/issues/171)) ([dfd8513](https://github.com/typedef-ai/data-intelligence/commit/dfd85132507c3512e9450811b366eff36296faea))
- Deep Agent Prototype ([#91](https://github.com/typedef-ai/data-intelligence/issues/91)) ([1f2e229](https://github.com/typedef-ai/data-intelligence/commit/1f2e229272bd8ca2d42b2d2a9f6664b9e0d2f412))
- Enhanced Join Clustering to create Inferred Subject Areas ([#108](https://github.com/typedef-ai/data-intelligence/issues/108)) ([2fb6e68](https://github.com/typedef-ai/data-intelligence/commit/2fb6e68d954bd181d1b9e76b160f924d2abd7a71))
- Salesforce upstream source integration (metadata ingestion + OAuth authentication) ([#136](https://github.com/typedef-ai/data-intelligence/issues/136)) ([b66fd9f](https://github.com/typedef-ai/data-intelligence/commit/b66fd9fcc334a6b65ac2dc04ded0e2f7dc29712f))

### Bug Fixes

- pass sqlglot schema to cache fingerprint computation ([#166](https://github.com/typedef-ai/data-intelligence/issues/166)) ([40ed4ce](https://github.com/typedef-ai/data-intelligence/commit/40ed4cef351b256ee96e2b435054a224702db301))
- pass the proper environment variables when creating the eval workspace, pass --profiles-dir when it is required in the dbt tooling ([#152](https://github.com/typedef-ai/data-intelligence/issues/152)) ([cc67346](https://github.com/typedef-ai/data-intelligence/commit/cc67346ea11b6000bb0cbcacba172aad4655b1ca))
- reserve integration mark for external-service tests and skip by ([c7af0d8](https://github.com/typedef-ai/data-intelligence/commit/c7af0d8e477a5e6d2c31a5b76101723d27971d5a))
- reserve integration mark for external-service tests and skip by default ([#167](https://github.com/typedef-ai/data-intelligence/issues/167)) ([c7af0d8](https://github.com/typedef-ai/data-intelligence/commit/c7af0d8e477a5e6d2c31a5b76101723d27971d5a))
- update stale tests for current Linear MCP and Bedrock APIs ([c7af0d8](https://github.com/typedef-ai/data-intelligence/commit/c7af0d8e477a5e6d2c31a5b76101723d27971d5a))

### Performance Improvements

- benchmark persist base task db ([#162](https://github.com/typedef-ai/data-intelligence/issues/162)) ([2804dc2](https://github.com/typedef-ai/data-intelligence/commit/2804dc2c251d51cb47b22e3fcc845ebda1b8f461))

## [0.5.0](https://github.com/typedef-ai/data-intelligence/compare/v0.4.1...v0.5.0) (2026-01-31)

### Features

- Add dbt test and unit test support to lineage graph ([#132](https://github.com/typedef-ai/data-intelligence/issues/132)) ([6f5513b](https://github.com/typedef-ai/data-intelligence/commit/6f5513bc713bfcae07f0b40ec11210c6583bf5ae))
- create implicit DEPENDS_ON edges, fix PhysicalRelation fqns ([#143](https://github.com/typedef-ai/data-intelligence/issues/143)) ([e47ad23](https://github.com/typedef-ai/data-intelligence/commit/e47ad230e34f04618bb57a6d96b6a27ddafffb1a))
- new demo reset devtool for tui workspace ([#134](https://github.com/typedef-ai/data-intelligence/issues/134)) ([c7fd10d](https://github.com/typedef-ai/data-intelligence/commit/c7fd10dcecce541970708f15cf548c355e376a4a))
- Physically Agnostic Incremental Loading ([#121](https://github.com/typedef-ai/data-intelligence/issues/121)) ([39d16bb](https://github.com/typedef-ai/data-intelligence/commit/39d16bbf034796dc406c9b0035eae00deca36421))
- proper versioning in cli ([#146](https://github.com/typedef-ai/data-intelligence/issues/146)) ([5e7722b](https://github.com/typedef-ai/data-intelligence/commit/5e7722b5f85595d6446b21bc162cc2a409842c7c))

### Bug Fixes

- A few tweaks to benchmark and bedrock agents ([#141](https://github.com/typedef-ai/data-intelligence/issues/141)) ([6e38a03](https://github.com/typedef-ai/data-intelligence/commit/6e38a035b3e8614ab770fd576a5186fcb86f75ca))

## [0.4.1](https://github.com/typedef-ai/data-intelligence/compare/v0.4.0...v0.4.1) (2026-01-27)

### Bug Fixes

- support separate git configurations per project ([#133](https://github.com/typedef-ai/data-intelligence/issues/133)) ([44ac010](https://github.com/typedef-ai/data-intelligence/commit/44ac010c0a7df587f37b44155eae551d92791c26))

## [0.4.0](https://github.com/typedef-ai/data-intelligence/compare/v0.3.1...v0.4.0) (2026-01-27)

### Features

- add placeholder text for the agent screens ([0138828](https://github.com/typedef-ai/data-intelligence/commit/0138828873fb753811735d063b4f5e69fc90071c))
- add placeholder text for the agent screens ([#117](https://github.com/typedef-ai/data-intelligence/issues/117)) ([0138828](https://github.com/typedef-ai/data-intelligence/commit/0138828873fb753811735d063b4f5e69fc90071c))
- Benchmarks perform full and incremental graph builds ([#106](https://github.com/typedef-ai/data-intelligence/issues/106)) ([faa0c24](https://github.com/typedef-ai/data-intelligence/commit/faa0c24483c31bf2e90b463da64095e870337d2c))

### Bug Fixes

- handle new Linear API response format ([#127](https://github.com/typedef-ai/data-intelligence/issues/127)) ([37deb11](https://github.com/typedef-ai/data-intelligence/commit/37deb11059413434648d0d28e9060a0d9134c283))

## [0.3.1](https://github.com/typedef-ai/data-intelligence/compare/v0.3.0...v0.3.1) (2026-01-23)

### Bug Fixes

- local build regression from pypi README requirement ([#109](https://github.com/typedef-ai/data-intelligence/issues/109)) ([bb84348](https://github.com/typedef-ai/data-intelligence/commit/bb843486a3ae78bcdd499463474dcb839e3b1760))

## [0.3.0](https://github.com/typedef-ai/data-intelligence/compare/v0.2.0...v0.3.0) (2026-01-16)

### Features

- Deterministic-LLM Hybrid Analysis of dbt SQL ([#67](https://github.com/typedef-ai/data-intelligence/issues/67)) ([99e0dd6](https://github.com/typedef-ai/data-intelligence/commit/99e0dd6bf2398250385ccdb94405cb227c014e6b))

### Bug Fixes

- ensure that a uv venv exists in the project so we can run dbt cli. also moves profiles out of the project to limit project changes that need to be .gitignored ([#102](https://github.com/typedef-ai/data-intelligence/issues/102)) ([90da937](https://github.com/typedef-ai/data-intelligence/commit/90da937cc266a7394ef93219749fd96b76ccbdb9))
- regression in k8s builds caused by pypi doc req ([#104](https://github.com/typedef-ai/data-intelligence/issues/104)) ([d9b0719](https://github.com/typedef-ai/data-intelligence/commit/d9b0719b3072f4cb61a626cc63dd0ffe7ee723ae))

## [0.2.0](https://github.com/typedef-ai/data-intelligence/compare/v0.1.0...v0.2.0) (2026-01-13)

### Features

- Add Data Engineer tools/prompts to Pydantic CLI Agent, improved stability of logfire ([#32](https://github.com/typedef-ai/data-intelligence/issues/32)) ([08efbb1](https://github.com/typedef-ai/data-intelligence/commit/08efbb1fead1fd7727f641d42c85ec4086e8ca85))
- add rich progress tracking to ingest pipeline ([#47](https://github.com/typedef-ai/data-intelligence/issues/47)) ([91adc20](https://github.com/typedef-ai/data-intelligence/commit/91adc200a4d8f1e71756a31cf7024913545e973f))
- Add smart autoscroll control in TUI and enforce feature branch workflow for DE copilot ([#81](https://github.com/typedef-ai/data-intelligence/issues/81)) ([42e787d](https://github.com/typedef-ai/data-intelligence/commit/42e787db12d90585d9fc85559f4ebf464f76f385))
- Add support for bedrock models ([#58](https://github.com/typedef-ai/data-intelligence/issues/58)) ([7711bcc](https://github.com/typedef-ai/data-intelligence/commit/7711bcc37b33c13e940d275c171c07f63cdf6a62))
- add the daemon ticket based experience to the tui ([#70](https://github.com/typedef-ai/data-intelligence/issues/70)) ([fc87df8](https://github.com/typedef-ai/data-intelligence/commit/fc87df83100ad4f86189c6fc36d4dcb7f212169c))
- add TUI setup wizard with Textual (prototype) ([#49](https://github.com/typedef-ai/data-intelligence/issues/49)) ([6147e8c](https://github.com/typedef-ai/data-intelligence/commit/6147e8c5d5340144719d2e690f4b49a60065eb68))
- adding a webui for data analyst ([#2](https://github.com/typedef-ai/data-intelligence/issues/2)) ([9096a18](https://github.com/typedef-ai/data-intelligence/commit/9096a186c56087c101ec46c1a82ccebd90103593))
- dev docker compose ([#4](https://github.com/typedef-ai/data-intelligence/issues/4)) ([97e1d73](https://github.com/typedef-ai/data-intelligence/commit/97e1d73aa6de637eebe5f245e41ad71ad597ba97))
- falkordb full text search, snowflake db visibility filtering ([#46](https://github.com/typedef-ai/data-intelligence/issues/46)) ([5110928](https://github.com/typedef-ai/data-intelligence/commit/5110928ae576303fbe25456ae718e93d136213f5))
- full clustering implementation ([#10](https://github.com/typedef-ai/data-intelligence/issues/10)) ([71bebad](https://github.com/typedef-ai/data-intelligence/commit/71bebad07d0060dc0a07224472bffd0c0db4db88))
- Improve demo workflow with benchmark branch preservation and session management cleanup ([#64](https://github.com/typedef-ai/data-intelligence/issues/64)) ([df015f8](https://github.com/typedef-ai/data-intelligence/commit/df015f8613d532a14b7eada0b7c7c05c7719edf9))
- Mattermost clones working plus tasks for scenarios ([#43](https://github.com/typedef-ai/data-intelligence/issues/43)) ([fd77b49](https://github.com/typedef-ai/data-intelligence/commit/fd77b49b4ebd5f2905f9c227c0479a20f5c09d98))
- prototype benchmark for data-intelligence ([#26](https://github.com/typedef-ai/data-intelligence/issues/26)) ([de2871a](https://github.com/typedef-ai/data-intelligence/commit/de2871afdd78d586fbcd3da86d82d9bf1522d616))
- separate logical and physical concepts ([#20](https://github.com/typedef-ai/data-intelligence/issues/20)) ([3a9bd05](https://github.com/typedef-ai/data-intelligence/commit/3a9bd05cd6b07328d5098893574a1ab7477a17ef))

### Bug Fixes

- **backend/docker:** misc path/entrypoint fixes to get it running ([#22](https://github.com/typedef-ai/data-intelligence/issues/22)) ([aa47c3f](https://github.com/typedef-ai/data-intelligence/commit/aa47c3fba30895bde9f107d3f9bea4014fb2a8b1))
- daemon only grabs labeled tickets ([#18](https://github.com/typedef-ai/data-intelligence/issues/18)) ([748f6c3](https://github.com/typedef-ai/data-intelligence/commit/748f6c332cb5fac490f4c6645a2bdab7d4749e07))
- if the dbt project gets cloned with git, enable git in the config ([#73](https://github.com/typedef-ai/data-intelligence/issues/73)) ([6e99162](https://github.com/typedef-ai/data-intelligence/commit/6e9916232ab569c4385cbf54d6651c1312517c92))
- limit the daemon to only process tickets assigned to data-engineer-agent ([#74](https://github.com/typedef-ai/data-intelligence/issues/74)) ([ac94267](https://github.com/typedef-ai/data-intelligence/commit/ac94267c4965b040977cdf3933f39ace67cd06e1))
- minor fixes to get medallion + frontend to work ([#59](https://github.com/typedef-ai/data-intelligence/issues/59)) ([1444285](https://github.com/typedef-ai/data-intelligence/commit/1444285ba030a4a2f242a4494e102f106d81d868))
- readme ([#1](https://github.com/typedef-ai/data-intelligence/issues/1)) ([172767a](https://github.com/typedef-ai/data-intelligence/commit/172767a78d33c963e5a09685b34f5016bd7a9714))
