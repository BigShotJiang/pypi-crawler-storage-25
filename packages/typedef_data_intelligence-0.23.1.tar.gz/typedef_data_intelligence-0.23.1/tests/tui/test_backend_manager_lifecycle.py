"""Lifecycle tests for TUI backend process ownership and cleanup."""

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import pytest
from lineage.tui.backend import BackendManager


def _spawn_sleep_process(token: str) -> subprocess.Popen[str]:
    env = os.environ.copy()
    env["TYPEDEF_BACKEND_INSTANCE_TOKEN"] = token
    proc = subprocess.Popen(  # nosec B603 - controlled test process
        [sys.executable, "-c", "import time; time.sleep(120)"],
        text=True,
        env=env,
        start_new_session=True,
    )
    # Wait for execve to complete so /proc/{pid}/environ reflects the child's
    # passed env rather than the parent's pre-exec environ. Without this the
    # ownership validator can see no TYPEDEF_BACKEND_INSTANCE_TOKEN and bail
    # on slower runners.
    _wait_for_env_visible(proc.pid, "TYPEDEF_BACKEND_INSTANCE_TOKEN", token)
    return proc


def _wait_for_env_visible(
    pid: int, key: str, expected: str, timeout: float = 4.0
) -> None:
    target = f"{key}={expected}".encode()
    environ_path = Path(f"/proc/{pid}/environ")
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            raw = environ_path.read_bytes()
            if any(entry == target for entry in raw.split(b"\x00")):
                return
        except (FileNotFoundError, ProcessLookupError):
            pass
        except PermissionError:
            pytest.skip(
                f"cannot read {environ_path}; /proc may be mounted with hidepid"
            )
        time.sleep(0.01)
    raise RuntimeError(
        f"Timed out waiting for {key} to appear in /proc/{pid}/environ"
    )


def _is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def _wait_dead(pid: int, timeout: float = 4.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not _is_alive(pid):
            return True
        time.sleep(0.05)
    return False


def _force_cleanup_process(proc: subprocess.Popen[str]) -> None:
    if proc.poll() is not None:
        return
    try:
        pgid = os.getpgid(proc.pid)
        os.killpg(pgid, signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    try:
        proc.wait(timeout=2)
    except Exception:
        pass


@pytest.mark.skipif(
    not Path("/proc").exists(), reason="requires /proc process metadata"
)
def test_stop_is_idempotent_and_clears_marker(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Repeated stop calls should be safe and should remove marker."""
    monkeypatch.setenv("HOME", str(tmp_path))
    manager = BackendManager()

    proc = _spawn_sleep_process(manager.instance_token)
    manager.process = proc
    marker = manager._build_marker_for_pid(proc.pid)
    assert marker is not None
    manager._write_marker(marker)

    manager.STOP_TERM_TIMEOUT_SECONDS = 1
    manager.STOP_KILL_WAIT_SECONDS = 1

    manager.stop()
    assert _wait_dead(proc.pid)
    assert not manager.marker_file.exists()

    manager.stop()


@pytest.mark.skipif(
    not Path("/proc").exists(), reason="requires /proc process metadata"
)
def test_stale_reap_skips_when_token_validation_fails(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Stale reaping must not kill process when ownership token mismatches."""
    monkeypatch.setenv("HOME", str(tmp_path))
    owner = BackendManager()
    proc = _spawn_sleep_process("real-owner-token")

    try:
        marker = owner._build_marker_for_pid(proc.pid)
        assert marker is not None
        marker.instance_token = "different-token"
        owner._write_marker(marker)

        reaper = BackendManager()
        reaper.STOP_TERM_TIMEOUT_SECONDS = 1
        reaper.STOP_KILL_WAIT_SECONDS = 1
        reaper._reap_stale_backend_from_marker()

        assert _is_alive(proc.pid)
        assert reaper.marker_file.exists()
    finally:
        _force_cleanup_process(proc)


@pytest.mark.skipif(
    not Path("/proc").exists(), reason="requires /proc process metadata"
)
def test_stale_reap_kills_owned_process_and_clears_marker(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Validated ownership marker should allow stale-process reaping."""
    monkeypatch.setenv("HOME", str(tmp_path))
    owner = BackendManager()
    proc = _spawn_sleep_process("owned-token")

    try:
        marker = owner._build_marker_for_pid(proc.pid)
        assert marker is not None
        marker.instance_token = "owned-token"
        owner._write_marker(marker)

        reaper = BackendManager()
        reaper.STOP_TERM_TIMEOUT_SECONDS = 1
        reaper.STOP_KILL_WAIT_SECONDS = 1
        reaper._reap_stale_backend_from_marker()

        assert proc.wait(timeout=4) is not None
        assert not reaper.marker_file.exists()
    finally:
        _force_cleanup_process(proc)
