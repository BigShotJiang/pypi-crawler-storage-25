import importlib.util
import sys
import types
from pathlib import Path


def _load_helpers_module(monkeypatch):
    textual_app = types.ModuleType("textual.app")
    textual_app.App = object  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "textual.app", textual_app)

    textual_query = types.ModuleType("textual.css.query")
    textual_query.NoMatches = Exception  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "textual.css.query", textual_query)

    textual_widgets = types.ModuleType("textual.widgets")
    textual_widgets.Button = object  # type: ignore[attr-defined]
    textual_widgets.LoadingIndicator = object  # type: ignore[attr-defined]
    textual_widgets.Static = object  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "textual.widgets", textual_widgets)

    wizard_base = types.ModuleType("lineage.tui.wizards.base")
    wizard_base.WizardStep = object  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "lineage.tui.wizards.base", wizard_base)

    module_path = (
        Path(__file__).resolve().parents[1]
        / "src"
        / "lineage"
        / "tui"
        / "wizards"
        / "init"
        / "helpers.py"
    )
    spec = importlib.util.spec_from_file_location("test_helpers_module", module_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_ensure_dbt_venv_delegates_to_core_helper(monkeypatch, tmp_path):
    helpers = _load_helpers_module(monkeypatch)
    expected = tmp_path / "venvs" / "dbt-duckdb"
    calls: list[str] = []

    def fake_core_ensure(adapter: str) -> Path:
        calls.append(adapter)
        return expected

    monkeypatch.setattr(helpers, "core_ensure_dbt_venv", fake_core_ensure)

    assert helpers.ensure_dbt_venv("duckdb") == expected
    assert calls == ["duckdb"]
