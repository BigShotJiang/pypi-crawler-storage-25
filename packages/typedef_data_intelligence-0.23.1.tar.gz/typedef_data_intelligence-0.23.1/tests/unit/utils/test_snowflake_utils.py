"""Tests for Snowflake one-shot wizard helpers.

Covers secondary roles enablement, database listing, and schema listing
with mocked Snowflake connections.
"""

from __future__ import annotations

from unittest.mock import MagicMock, call, patch

from lineage.utils.snowflake import (
    _try_enable_secondary_roles,
    list_snowflake_databases,
    list_snowflake_schemas,
)
from snowflake.connector.errors import Error as SnowflakeError

# ── _try_enable_secondary_roles ──────────────────────────────────────


def test_try_enable_secondary_roles_success():
    cursor = MagicMock()
    assert _try_enable_secondary_roles(cursor) is True
    cursor.execute.assert_called_once_with("USE SECONDARY ROLES ALL")


def test_try_enable_secondary_roles_failure_returns_false():
    cursor = MagicMock()
    cursor.execute.side_effect = SnowflakeError("Secondary roles not supported")
    assert _try_enable_secondary_roles(cursor) is False


def test_try_enable_secondary_roles_does_not_raise():
    """Any SnowflakeError is swallowed — the function never raises."""
    cursor = MagicMock()
    cursor.execute.side_effect = SnowflakeError("transient session error")
    # Should not raise
    result = _try_enable_secondary_roles(cursor)
    assert result is False


# ── list_snowflake_databases ─────────────────────────────────────────


@patch("lineage.utils.snowflake._connect")
def test_list_databases_enables_secondary_roles_before_show(mock_connect):
    """Secondary roles are enabled before SHOW DATABASES."""
    cursor = MagicMock()
    cursor.fetchall.return_value = [(None, "DB_A"), (None, "DB_B")]
    conn = MagicMock()
    conn.cursor.return_value = cursor
    mock_connect.return_value = conn

    result = list_snowflake_databases(
        account="test_acct",
        user="test_user",
        role="test_role",
        warehouse="test_wh",
    )

    # Verify call order: secondary roles first, then SHOW DATABASES
    assert cursor.execute.call_args_list == [
        call("USE SECONDARY ROLES ALL"),
        call("SHOW DATABASES"),
    ]
    assert result == ["DB_A", "DB_B"]
    conn.close.assert_called_once()


@patch("lineage.utils.snowflake._connect")
def test_list_databases_works_when_secondary_roles_fail(mock_connect):
    """Database listing still works when secondary roles are unavailable."""
    cursor = MagicMock()
    cursor.execute.side_effect = [
        SnowflakeError("not supported"),  # USE SECONDARY ROLES ALL
        None,  # SHOW DATABASES succeeds
    ]
    cursor.fetchall.return_value = [(None, "DB_ONLY")]
    conn = MagicMock()
    conn.cursor.return_value = cursor
    mock_connect.return_value = conn

    result = list_snowflake_databases(
        account="test_acct",
        user="test_user",
        role=None,
        warehouse=None,
    )

    assert result == ["DB_ONLY"]


@patch("lineage.utils.snowflake._connect")
def test_list_databases_returns_sorted(mock_connect):
    cursor = MagicMock()
    cursor.fetchall.return_value = [(None, "ZEBRA"), (None, "ALPHA"), (None, "MIDDLE")]
    conn = MagicMock()
    conn.cursor.return_value = cursor
    mock_connect.return_value = conn

    result = list_snowflake_databases(
        account="a", user="u", role=None, warehouse=None
    )
    assert result == ["ALPHA", "MIDDLE", "ZEBRA"]


# ── list_snowflake_schemas ───────────────────────────────────────────


@patch("lineage.utils.snowflake._connect")
def test_list_schemas_connects_without_database(mock_connect):
    """Connection should NOT pass database= so secondary roles can be
    enabled before any database-scoped session setup."""
    cursor = MagicMock()
    cursor.fetchall.return_value = [(None, "PUBLIC"), (None, "RAW")]
    conn = MagicMock()
    conn.cursor.return_value = cursor
    mock_connect.return_value = conn

    list_snowflake_schemas(
        account="test_acct",
        user="test_user",
        role="test_role",
        warehouse="test_wh",
        database="MY_DB",
    )

    # Verify _connect was called without database kwarg
    connect_kwargs = mock_connect.call_args[1]
    assert "database" not in connect_kwargs


@patch("lineage.utils.snowflake._connect")
def test_list_schemas_enables_secondary_roles_before_show(mock_connect):
    cursor = MagicMock()
    cursor.fetchall.return_value = [(None, "PUBLIC")]
    conn = MagicMock()
    conn.cursor.return_value = cursor
    mock_connect.return_value = conn

    list_snowflake_schemas(
        account="a", user="u", role=None, warehouse=None, database="MY_DB"
    )

    assert cursor.execute.call_args_list == [
        call("USE SECONDARY ROLES ALL"),
        call('SHOW SCHEMAS IN DATABASE "MY_DB"'),
    ]


@patch("lineage.utils.snowflake._connect")
def test_list_schemas_returns_sorted(mock_connect):
    cursor = MagicMock()
    cursor.fetchall.return_value = [(None, "ZZZ"), (None, "AAA")]
    conn = MagicMock()
    conn.cursor.return_value = cursor
    mock_connect.return_value = conn

    result = list_snowflake_schemas(
        account="a", user="u", role=None, warehouse=None, database="DB"
    )
    assert result == ["AAA", "ZZZ"]
