"""Tests for the Databricks one-shot wizard helpers (TD-2734 U1).

These helpers power the desktop Setup Wizard's discovery dropdowns
(warehouse / catalog / schema) before a full ``DatabricksDataConfig``
exists. The Phase A backend (TD-2730) is used elsewhere for the rich
``test_connection`` probe; this module covers the simpler paths.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from lineage.utils.databricks import (
    _connect_databricks,
    _looks_like_cluster_path,
    _normalize_host,
    _quote_identifier,
    _resolve_auth,
    list_databricks_catalogs,
    list_databricks_schemas,
    list_databricks_warehouses,
)

# ── _quote_identifier ────────────────────────────────────────────────


def test_quote_identifier_wraps_in_backticks():
    assert _quote_identifier("main") == "`main`"


def test_quote_identifier_escapes_embedded_backtick():
    # Backticks inside the name are doubled, mirroring SQL standard quoting
    assert _quote_identifier("weird`name") == "`weird``name`"


def test_quote_identifier_rejects_nul_byte():
    with pytest.raises(ValueError, match="NUL byte"):
        _quote_identifier("bad\x00name")


# ── _looks_like_cluster_path ────────────────────────────────────────


def test_looks_like_cluster_path_detects_clusters_marker():
    assert _looks_like_cluster_path("/clusters/0123-abcdef")


def test_looks_like_cluster_path_detects_protocolv1_marker():
    assert _looks_like_cluster_path("/protocolv1/o/123/0123-abcdef")


def test_looks_like_cluster_path_accepts_warehouse_path():
    assert not _looks_like_cluster_path("/sql/1.0/warehouses/abc123")


def test_looks_like_cluster_path_handles_empty_string():
    assert not _looks_like_cluster_path("")


# ── _normalize_host ─────────────────────────────────────────────────


def test_normalize_host_strips_https_prefix():
    assert _normalize_host("https://acme.cloud.databricks.com") == "acme.cloud.databricks.com"


def test_normalize_host_strips_trailing_slash():
    assert _normalize_host("acme.cloud.databricks.com/") == "acme.cloud.databricks.com"


def test_normalize_host_strips_query_string():
    assert (
        _normalize_host("https://acme.cloud.databricks.com/?o=1234567890")
        == "acme.cloud.databricks.com"
    )


def test_normalize_host_handles_bare_hostname():
    assert _normalize_host("acme.cloud.databricks.com") == "acme.cloud.databricks.com"


def test_normalize_host_strips_http_prefix():
    # Be tolerant of dev-mode pastes; SDK upgrades to https either way
    assert _normalize_host("http://localhost:8080/") == "localhost:8080"


def test_normalize_host_rejects_empty_input():
    with pytest.raises(ValueError, match="host is required"):
        _normalize_host("")


def test_normalize_host_rejects_protocol_only():
    with pytest.raises(ValueError, match="empty string"):
        _normalize_host("https://")


# ── _resolve_auth ───────────────────────────────────────────────────


def test_resolve_auth_pat_only():
    assert _resolve_auth("pat-tok", None) == ("pat", "pat-tok")


def test_resolve_auth_oauth_only():
    assert _resolve_auth(None, "oauth-tok") == ("oauth_u2m", "oauth-tok")


def test_resolve_auth_rejects_both_tokens():
    with pytest.raises(ValueError, match="exactly one"):
        _resolve_auth("pat-tok", "oauth-tok")


def test_resolve_auth_rejects_no_token():
    with pytest.raises(ValueError, match="One of"):
        _resolve_auth(None, None)


def test_resolve_auth_rejects_empty_strings():
    # Empty strings are treated as "not provided" — this matches the
    # FastAPI request-model behavior where `field: str | None = None`
    # may surface as an empty string from a wizard form.
    with pytest.raises(ValueError, match="One of"):
        _resolve_auth("", "")


# ── _connect_databricks ─────────────────────────────────────────────


def test_connect_databricks_pat_path_calls_sql_connect():
    with patch("databricks.sql.connect") as mock_connect:
        mock_connect.return_value = "fake-conn"
        result = _connect_databricks(
            host="https://acme.cloud.databricks.com/",
            http_path="/sql/1.0/warehouses/abc123",
            pat_token="pat-tok",
        )
    assert result == "fake-conn"
    mock_connect.assert_called_once_with(
        server_hostname="acme.cloud.databricks.com",
        http_path="/sql/1.0/warehouses/abc123",
        access_token="pat-tok",
    )


def test_connect_databricks_oauth_path_passes_token_through():
    with patch("databricks.sql.connect") as mock_connect:
        mock_connect.return_value = "fake-conn"
        _connect_databricks(
            host="acme.cloud.databricks.com",
            http_path="/sql/1.0/warehouses/abc123",
            oauth_token="oauth-tok",
        )
    # access_token receives the oauth token unchanged — the SDK doesn't
    # distinguish PAT from OAuth on this surface
    mock_connect.assert_called_once_with(
        server_hostname="acme.cloud.databricks.com",
        http_path="/sql/1.0/warehouses/abc123",
        access_token="oauth-tok",
    )


def test_connect_databricks_rejects_cluster_path_before_connecting():
    with patch("databricks.sql.connect") as mock_connect:
        with pytest.raises(ValueError, match="SQL Warehouses only"):
            _connect_databricks(
                host="acme.cloud.databricks.com",
                http_path="/sql/protocolv1/o/123/0123-abc",
                pat_token="pat-tok",
            )
    mock_connect.assert_not_called()


def test_connect_databricks_rejects_clusters_path():
    with patch("databricks.sql.connect") as mock_connect:
        with pytest.raises(ValueError, match="SQL Warehouses only"):
            _connect_databricks(
                host="acme.cloud.databricks.com",
                http_path="/clusters/0123-abcdef",
                pat_token="pat-tok",
            )
    mock_connect.assert_not_called()


def test_connect_databricks_rejects_both_tokens():
    with pytest.raises(ValueError, match="exactly one"):
        _connect_databricks(
            host="acme.cloud.databricks.com",
            http_path="/sql/1.0/warehouses/abc123",
            pat_token="pat-tok",
            oauth_token="oauth-tok",
        )


def test_connect_databricks_rejects_no_token():
    with pytest.raises(ValueError, match="One of"):
        _connect_databricks(
            host="acme.cloud.databricks.com",
            http_path="/sql/1.0/warehouses/abc123",
        )


# ── list_databricks_warehouses ──────────────────────────────────────


def _make_warehouse(id: str, name: str, state: str) -> object:
    """Build a synthetic warehouse object matching the SDK's EndpointInfo shape."""
    wh = MagicMock()
    wh.id = id
    wh.name = name
    wh.state = state
    return wh


def test_list_databricks_warehouses_returns_id_name_state():
    fake_client = MagicMock()
    fake_client.warehouses.list.return_value = [
        _make_warehouse("abc123", "Prod Warehouse", "RUNNING"),
        _make_warehouse("def456", "Dev Warehouse", "STOPPED"),
    ]
    with patch(
        "databricks.sdk.WorkspaceClient", return_value=fake_client
    ) as mock_ctor:
        result = list_databricks_warehouses(
            host="acme.cloud.databricks.com",
            pat_token="pat-tok",
        )
    # Verify keyword-only call shape — positional args would TypeError,
    # but pin it explicitly so future regressions surface cleanly.
    mock_ctor.assert_called_once_with(
        host="https://acme.cloud.databricks.com",
        token="pat-tok",
    )
    assert result == [
        {"id": "abc123", "name": "Prod Warehouse", "state": "RUNNING"},
        {"id": "def456", "name": "Dev Warehouse", "state": "STOPPED"},
    ]


def test_list_databricks_warehouses_oauth_token_passed_through():
    fake_client = MagicMock()
    fake_client.warehouses.list.return_value = []
    with patch(
        "databricks.sdk.WorkspaceClient", return_value=fake_client
    ) as mock_ctor:
        list_databricks_warehouses(
            host="acme.cloud.databricks.com",
            oauth_token="oauth-tok",
        )
    mock_ctor.assert_called_once_with(
        host="https://acme.cloud.databricks.com",
        token="oauth-tok",
    )


def test_list_databricks_warehouses_empty_list_returns_empty_list():
    # Empty workspace must surface as [] (not None / not raise) so the
    # wizard renders the empty-state copy rather than an error banner.
    fake_client = MagicMock()
    fake_client.warehouses.list.return_value = []
    with patch("databricks.sdk.WorkspaceClient", return_value=fake_client):
        result = list_databricks_warehouses(
            host="acme.cloud.databricks.com",
            pat_token="pat-tok",
        )
    assert result == []


def test_list_databricks_warehouses_skips_warehouses_missing_id_or_name():
    # Defensive: SDK could surface partial entries on a stale catalog
    bad = MagicMock()
    bad.id = None
    bad.name = "no id"
    bad.state = "RUNNING"
    fake_client = MagicMock()
    fake_client.warehouses.list.return_value = [
        bad,
        _make_warehouse("good", "Good", "RUNNING"),
    ]
    with patch("databricks.sdk.WorkspaceClient", return_value=fake_client):
        result = list_databricks_warehouses(
            host="acme.cloud.databricks.com",
            pat_token="pat-tok",
        )
    assert result == [{"id": "good", "name": "Good", "state": "RUNNING"}]


def test_list_databricks_warehouses_renders_enum_state_as_value():
    """Databricks SDK exposes warehouse state as a `State` enum.

    Calling ``str()`` on the enum produces ``"State.RUNNING"`` which
    leaks into the wizard UI. Verify we surface the API value (e.g.
    ``"RUNNING"``) and gracefully fall back for plain strings / None.
    """
    from enum import Enum

    class _FakeState(Enum):
        RUNNING = "RUNNING"
        STOPPED = "STOPPED"

    enum_wh = MagicMock()
    enum_wh.id = "enum1"
    enum_wh.name = "Enum WH"
    enum_wh.state = _FakeState.RUNNING

    str_wh = MagicMock()
    str_wh.id = "str1"
    str_wh.name = "String WH"
    str_wh.state = "STARTING"

    none_wh = MagicMock()
    none_wh.id = "none1"
    none_wh.name = "None WH"
    none_wh.state = None

    fake_client = MagicMock()
    fake_client.warehouses.list.return_value = [enum_wh, str_wh, none_wh]
    with patch("databricks.sdk.WorkspaceClient", return_value=fake_client):
        result = list_databricks_warehouses(
            host="acme.cloud.databricks.com",
            pat_token="pat-tok",
        )
    assert result == [
        {"id": "enum1", "name": "Enum WH", "state": "RUNNING"},
        {"id": "str1", "name": "String WH", "state": "STARTING"},
        {"id": "none1", "name": "None WH", "state": "UNKNOWN"},
    ]


def test_list_databricks_warehouses_rejects_both_tokens():
    with pytest.raises(ValueError, match="exactly one"):
        list_databricks_warehouses(
            host="acme.cloud.databricks.com",
            pat_token="pat-tok",
            oauth_token="oauth-tok",
        )


def test_list_databricks_warehouses_rejects_no_token():
    with pytest.raises(ValueError, match="One of"):
        list_databricks_warehouses(host="acme.cloud.databricks.com")


# ── list_databricks_catalogs ────────────────────────────────────────


def _make_connection(rows: list[tuple]) -> tuple[MagicMock, MagicMock]:
    """Build a (connection, cursor) pair where cursor.fetchall returns *rows*."""
    cursor = MagicMock()
    cursor.fetchall.return_value = rows
    conn = MagicMock()
    conn.cursor.return_value = cursor
    return conn, cursor


def test_list_databricks_catalogs_returns_names_in_warehouse_order():
    conn, cursor = _make_connection([("main",), ("samples",), ("hive_metastore",)])
    with patch("databricks.sql.connect", return_value=conn):
        result = list_databricks_catalogs(
            host="acme.cloud.databricks.com",
            http_path="/sql/1.0/warehouses/abc123",
            pat_token="pat-tok",
        )
    assert result == ["main", "samples", "hive_metastore"]
    cursor.execute.assert_called_once_with("SHOW CATALOGS")
    conn.close.assert_called_once()


def test_list_databricks_catalogs_preserves_case():
    # Case-preservation matters — UC stores catalog names case-insensitively
    # but the warehouse reports whatever was used at create time. We
    # don't transform.
    conn, _ = _make_connection([("Main",), ("UPPER_CAT",), ("mixed_Case",)])
    with patch("databricks.sql.connect", return_value=conn):
        result = list_databricks_catalogs(
            host="acme.cloud.databricks.com",
            http_path="/sql/1.0/warehouses/abc123",
            pat_token="pat-tok",
        )
    assert result == ["Main", "UPPER_CAT", "mixed_Case"]


def test_list_databricks_catalogs_closes_connection_on_error():
    conn, cursor = _make_connection([])
    cursor.execute.side_effect = RuntimeError("show catalogs failed")
    with patch("databricks.sql.connect", return_value=conn):
        with pytest.raises(RuntimeError, match="show catalogs failed"):
            list_databricks_catalogs(
                host="acme.cloud.databricks.com",
                http_path="/sql/1.0/warehouses/abc123",
                pat_token="pat-tok",
            )
    conn.close.assert_called_once()


def test_list_databricks_catalogs_rejects_cluster_path_before_connecting():
    with patch("databricks.sql.connect") as mock_connect:
        with pytest.raises(ValueError, match="SQL Warehouses only"):
            list_databricks_catalogs(
                host="acme.cloud.databricks.com",
                http_path="/clusters/abc",
                pat_token="pat-tok",
            )
    mock_connect.assert_not_called()


# ── list_databricks_schemas ─────────────────────────────────────────


def test_list_databricks_schemas_quotes_catalog_in_query():
    conn, cursor = _make_connection([("default",), ("information_schema",)])
    with patch("databricks.sql.connect", return_value=conn):
        result = list_databricks_schemas(
            host="acme.cloud.databricks.com",
            http_path="/sql/1.0/warehouses/abc123",
            catalog="main",
            pat_token="pat-tok",
        )
    assert result == ["default", "information_schema"]
    cursor.execute.assert_called_once_with("SHOW SCHEMAS IN `main`")
    conn.close.assert_called_once()


def test_list_databricks_schemas_escapes_embedded_backtick():
    # Defensive — UC catalog names cannot legally contain backticks
    # but if one slipped through, the quoting prevents SQL injection.
    conn, cursor = _make_connection([])
    with patch("databricks.sql.connect", return_value=conn):
        list_databricks_schemas(
            host="acme.cloud.databricks.com",
            http_path="/sql/1.0/warehouses/abc123",
            catalog="weird`cat",
            pat_token="pat-tok",
        )
    cursor.execute.assert_called_once_with("SHOW SCHEMAS IN `weird``cat`")


def test_list_databricks_schemas_rejects_nul_byte_catalog():
    # NUL byte in catalog name raises before connecting (defense in depth)
    with patch("databricks.sql.connect") as mock_connect:
        with pytest.raises(ValueError, match="NUL byte"):
            list_databricks_schemas(
                host="acme.cloud.databricks.com",
                http_path="/sql/1.0/warehouses/abc123",
                catalog="bad\x00cat",
                pat_token="pat-tok",
            )
    mock_connect.assert_not_called()


def test_list_databricks_schemas_rejects_cluster_path_before_connecting():
    # NB: the NUL-byte check happens *after* the cluster-path check
    # in the call sequence (cluster check is inside _connect_databricks),
    # but with a clean catalog and a bad http_path the cluster-path
    # rejection path fires.
    with patch("databricks.sql.connect") as mock_connect:
        with pytest.raises(ValueError, match="SQL Warehouses only"):
            list_databricks_schemas(
                host="acme.cloud.databricks.com",
                http_path="/clusters/abc",
                catalog="main",
                pat_token="pat-tok",
            )
    mock_connect.assert_not_called()
