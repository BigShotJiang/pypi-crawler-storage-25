"""Tests for run_dbt_command env-var injection.

The desktop and TUI flows rely on run_dbt_command exporting DBT_PROJECT_DIR
into the subprocess env so dbt's `env_var()` Jinja helper can resolve
`{{ env_var('DBT_PROJECT_DIR') }}` references in dbt_project.yml. dbt-core
does not expose --project-dir back into Jinja, so this layer has to.
"""

from pathlib import Path
from unittest.mock import patch

from lineage.utils.dbt import run_dbt_command


def _completed(stdout: str = "", stderr: str = ""):
    class _Result:
        pass

    r = _Result()
    r.stdout = stdout
    r.stderr = stderr
    return r


@patch("lineage.utils.dbt.subprocess.run")
@patch("lineage.utils.dbt.resolve_dbt_cmd")
def test_dbt_project_dir_injected_when_caller_omits_it(
    mock_resolve, mock_run, tmp_path: Path
):
    mock_resolve.return_value = ["dbt", "deps"]
    mock_run.return_value = _completed()

    run_dbt_command(["deps"], tmp_path)

    env = mock_run.call_args.kwargs["env"]
    assert env["DBT_PROJECT_DIR"] == str(tmp_path)


@patch("lineage.utils.dbt.subprocess.run")
@patch("lineage.utils.dbt.resolve_dbt_cmd")
def test_extra_env_overrides_dbt_project_dir(mock_resolve, mock_run, tmp_path: Path):
    """Caller-supplied DBT_PROJECT_DIR wins over the injected default.

    Lets a user point dbt at a sibling project dir from the editor without
    the platform forcing the wrapping path.
    """
    mock_resolve.return_value = ["dbt", "deps"]
    mock_run.return_value = _completed()

    override = "/tmp/somewhere-else"
    run_dbt_command(["deps"], tmp_path, extra_env={"DBT_PROJECT_DIR": override})

    env = mock_run.call_args.kwargs["env"]
    assert env["DBT_PROJECT_DIR"] == override


@patch("lineage.utils.dbt.subprocess.run")
@patch("lineage.utils.dbt.resolve_dbt_cmd")
def test_profiles_dir_still_set_alongside_project_dir(
    mock_resolve, mock_run, tmp_path: Path
):
    mock_resolve.return_value = ["dbt", "deps"]
    mock_run.return_value = _completed()

    profiles = tmp_path / "profiles"
    run_dbt_command(["deps"], tmp_path, profiles_dir=profiles)

    env = mock_run.call_args.kwargs["env"]
    assert env["DBT_PROJECT_DIR"] == str(tmp_path)
    assert env["DBT_PROFILES_DIR"] == str(profiles)


@patch("lineage.utils.dbt.subprocess.run")
@patch("lineage.utils.dbt.resolve_dbt_cmd")
def test_target_and_log_path_pinned_to_project_dir(
    mock_resolve, mock_run, tmp_path: Path
):
    """typedef pins target/log paths so user dbt_project.yml templating can't
    redirect outputs away from where downstream code reads them.

    Covers two failure modes seen in the field:
      1. `target-path: "{{ env_var('DBT_PROJECT_DIR') }}/<sub>/target"` in
         monorepo projects rendering to a path typedef can't find.
      2. `log-path` Jinja not rendering during dbt's early logger init,
         leaving a literal `{{ env_var(...) }}` directory on disk.
    """
    mock_resolve.return_value = ["dbt", "deps"]
    mock_run.return_value = _completed()

    run_dbt_command(["deps"], tmp_path)

    env = mock_run.call_args.kwargs["env"]
    assert env["DBT_TARGET_PATH"] == str(tmp_path / "target")
    assert env["DBT_LOG_PATH"] == str(tmp_path / "logs")


@patch("lineage.utils.dbt.subprocess.run")
@patch("lineage.utils.dbt.resolve_dbt_cmd")
def test_relative_project_dir_resolved_to_absolute(
    mock_resolve, mock_run, tmp_path: Path, monkeypatch
):
    """run_dbt_command runs the subprocess with cwd=project_dir, and dbt
    resolves DBT_TARGET_PATH / DBT_LOG_PATH relative to its working directory.
    A relative project_dir would produce nested paths like
    `<cwd>/<project_dir>/target`. Pin to absolute up front to avoid that.
    """
    mock_resolve.return_value = ["dbt", "deps"]
    mock_run.return_value = _completed()

    # Establish a known absolute root, then call with a relative path.
    monkeypatch.chdir(tmp_path)
    proj = Path("myproj")
    proj.mkdir()

    run_dbt_command(["deps"], proj)

    abs_proj = (tmp_path / "myproj").resolve()
    env = mock_run.call_args.kwargs["env"]
    assert env["DBT_PROJECT_DIR"] == str(abs_proj)
    assert env["DBT_TARGET_PATH"] == str(abs_proj / "target")
    assert env["DBT_LOG_PATH"] == str(abs_proj / "logs")
    # cwd is the same resolved path so dbt's relative-path joins won't nest.
    assert mock_run.call_args.kwargs["cwd"] == abs_proj


@patch("lineage.utils.dbt.subprocess.run")
@patch("lineage.utils.dbt.resolve_dbt_cmd")
def test_target_and_log_paths_are_not_overridable(
    mock_resolve, mock_run, tmp_path: Path
):
    """typedef pins DBT_TARGET_PATH / DBT_LOG_PATH so downstream readers
    (run_dbt_docs_generate manifest validation, log hints, lineage loaders)
    stay in sync with where dbt writes. Allowing override would silently
    desync those readers — they look at hardcoded `<project_dir>/target/...`
    paths.
    """
    mock_resolve.return_value = ["dbt", "deps"]
    mock_run.return_value = _completed()

    run_dbt_command(
        ["deps"],
        tmp_path,
        extra_env={
            "DBT_TARGET_PATH": "/tmp/custom-target",
            "DBT_LOG_PATH": "/tmp/custom-logs",
        },
    )

    env = mock_run.call_args.kwargs["env"]
    assert env["DBT_TARGET_PATH"] == str(tmp_path / "target")
    assert env["DBT_LOG_PATH"] == str(tmp_path / "logs")
