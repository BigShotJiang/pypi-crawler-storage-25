from __future__ import annotations

from lineage.api.auth_context import resolve_user_context


def test_clerk_headers_take_precedence_when_org_present():
    user_id, org_id = resolve_user_context(
        {
            "X-Clerk-User-Id": "user_123",
            "X-Clerk-Org-Id": "org_456",
            "X-User-Id": "legacy_user",
            "X-Org-Id": "legacy_org",
        },
        default_user_id="test_user@example.com",
        default_org_id="test_org",
    )

    assert user_id == "user_123"
    assert org_id == "org_456"


def test_clerk_user_without_org_gets_personal_org_fallback():
    user_id, org_id = resolve_user_context(
        {"X-Clerk-User-Id": "user_123"},
        default_user_id="test_user@example.com",
        default_org_id="test_org",
    )

    assert user_id == "user_123"
    assert org_id == "personal_user_123"


def test_legacy_headers_still_apply_without_clerk_identity():
    user_id, org_id = resolve_user_context(
        {
            "X-User-Id": "legacy_user",
            "X-Org-Id": "legacy_org",
        },
        default_user_id="test_user@example.com",
        default_org_id="test_org",
    )

    assert user_id == "legacy_user"
    assert org_id == "legacy_org"
