from __future__ import annotations

import logging
from pathlib import Path
from types import SimpleNamespace

from fastapi import FastAPI
from fastapi.testclient import TestClient
from lineage.api import desktop_sync


class EscalatingProcess:
    def __init__(self):
        self.pid = 4242
        self.exitcode = 0
        self._alive = True
        self.close_called = False
        self.terminate_called = False
        self.kill_called = False

    def join(self, timeout=None):
        return None

    def is_alive(self):
        return self._alive

    def terminate(self):
        self.terminate_called = True

    def kill(self):
        self.kill_called = True
        self._alive = False

    def close(self):
        self.close_called = True


class CloseErrorProcess:
    def __init__(self):
        self.pid = 4242
        self.exitcode = 0
        self.close_called = False

    def join(self, timeout=None):
        return None

    def is_alive(self):
        return False

    def close(self):
        self.close_called = True
        raise ValueError(
            "Cannot close a process while it is still running. You should first call join() or terminate()."
        )


class CompletedQueue:
    def __init__(self):
        self.closed = False
        self.joined = False
        self._events = [
            {
                "stage": "complete",
                "current": 12,
                "total": 12,
                "status": "completed",
                "message": "Sync complete in 0.3s",
                "head_commit": "abc123",
            }
        ]

    def get(self, timeout=None):
        if self._events:
            return self._events.pop(0)
        raise RuntimeError("queue empty")

    def empty(self):
        return not self._events

    def get_nowait(self):
        if self._events:
            return self._events.pop(0)
        raise RuntimeError("queue empty")

    def close(self):
        self.closed = True

    def join_thread(self):
        self.joined = True


def test_sync_progress_emits_terminal_event_even_if_process_stays_alive(monkeypatch):
    app = FastAPI()
    app.include_router(desktop_sync.router)

    process = EscalatingProcess()
    queue = CompletedQueue()
    op = desktop_sync.SyncOperation(
        sync_id="sync-terminal",
        project_name="demo_project",
        process=process,
        queue=queue,
        status="running",
    )
    monkeypatch.setitem(desktop_sync._sync_ops, op.sync_id, op)
    monkeypatch.setattr(desktop_sync, "_persist_synced_commit", lambda *_: None)

    client = TestClient(app)

    response = client.get(f"/desktop/sync/{op.sync_id}/progress")

    assert response.status_code == 200
    assert "Sync complete in 0.3s" in response.text
    assert process.terminate_called is True
    assert process.kill_called is True
    assert process.close_called is True
    assert queue.closed is True
    assert queue.joined is True


def test_sync_progress_ignores_process_close_errors_during_cleanup(monkeypatch):
    app = FastAPI()
    app.include_router(desktop_sync.router)

    process = CloseErrorProcess()
    queue = CompletedQueue()
    op = desktop_sync.SyncOperation(
        sync_id="sync-close-error",
        project_name="demo_project",
        process=process,
        queue=queue,
        status="running",
    )
    monkeypatch.setitem(desktop_sync._sync_ops, op.sync_id, op)
    monkeypatch.setattr(desktop_sync, "_persist_synced_commit", lambda *_: None)

    client = TestClient(app)

    response = client.get(f"/desktop/sync/{op.sync_id}/progress")

    assert response.status_code == 200
    assert "Sync complete in 0.3s" in response.text
    assert process.close_called is True
    assert queue.closed is True
    assert queue.joined is True


# ── _maybe_regenerate_dbt_docs tests ─────────────────────────────────


class _RecordingQueue:
    """Minimal Queue stub that records put() calls for assertion."""

    def __init__(self) -> None:
        self.events: list[dict] = []

    def put(self, item: dict) -> None:
        self.events.append(item)


class _NotSetEvent:
    """Minimal Event stub: never set (no cancellation)."""

    def is_set(self) -> bool:
        return False


def _write_project_config(
    cfg_path: Path,
    project_name: str,
    dbt_path: Path,
    last_synced_commit: str | None = None,
    backend: str = "duckdb",
) -> None:
    """Write a minimal project config YAML to cfg_path."""
    import yaml

    project: dict = {
        "dbt_path": str(dbt_path),
        "data": {"backend": backend},
    }
    if last_synced_commit is not None:
        project["last_synced_commit"] = last_synced_commit
    cfg = {"projects": {project_name: project}}
    cfg_path.write_text(yaml.safe_dump(cfg), encoding="utf-8")


def _patch_config_path(monkeypatch, cfg_path: Path) -> None:
    """Make `from core.paths import config_path` resolve to cfg_path."""
    import core.paths as _core_paths

    monkeypatch.setattr(_core_paths, "config_path", lambda: cfg_path)


def _patch_run_git(monkeypatch, head_commit: str | None) -> None:
    """Patch _run_git in desktop_worktree to return the given HEAD."""
    from lineage.api import desktop_worktree

    def _stub(*_args, **_kwargs):
        return SimpleNamespace(
            returncode=0,
            stdout=(head_commit + "\n") if head_commit is not None else "",
            stderr="",
        )

    monkeypatch.setattr(desktop_worktree, "_run_git", _stub)


def test_maybe_regenerate_skips_when_manifest_valid_and_commits_match(
    monkeypatch, tmp_path
):
    cfg_path = tmp_path / "config.yaml"
    dbt_root = tmp_path / "dbt_project"
    dbt_root.mkdir()
    head = "deadbeef" * 5
    _write_project_config(
        cfg_path, "demo", dbt_root, last_synced_commit=head
    )
    _patch_config_path(monkeypatch, cfg_path)
    _patch_run_git(monkeypatch, head)

    from lineage.utils import dbt as dbt_utils

    monkeypatch.setattr(dbt_utils, "_validate_manifest", lambda _path: True)

    queue = _RecordingQueue()
    cancel = _NotSetEvent()
    log = logging.getLogger("test.skip")

    result = desktop_sync._maybe_regenerate_dbt_docs(
        "demo",
        dbt_root / "target" / "manifest.json",
        queue,  # type: ignore[arg-type]
        cancel,  # type: ignore[arg-type]
        log,
    )

    assert result is True
    assert queue.events == []


def test_maybe_regenerate_runs_when_manifest_invalid(monkeypatch, tmp_path):
    cfg_path = tmp_path / "config.yaml"
    dbt_root = tmp_path / "dbt_project"
    dbt_root.mkdir()
    head = "feedface" * 5
    _write_project_config(
        cfg_path, "demo", dbt_root, last_synced_commit=head
    )
    _patch_config_path(monkeypatch, cfg_path)
    _patch_run_git(monkeypatch, head)

    from lineage.tui.wizards.init import helpers as init_helpers
    from lineage.utils import dbt as dbt_utils

    monkeypatch.setattr(dbt_utils, "_validate_manifest", lambda _path: False)
    monkeypatch.setattr(
        init_helpers, "ensure_dbt_venv", lambda _adapter: tmp_path / "venv"
    )

    success_result = dbt_utils.DbtDocsResult(
        success=True,
        manifest_valid=True,
        catalog_exists=True,
        error_summary=None,
        raw_error=None,
        log_hint=None,
    )
    monkeypatch.setattr(
        dbt_utils, "run_dbt_docs_generate", lambda *a, **kw: success_result
    )

    queue = _RecordingQueue()
    cancel = _NotSetEvent()
    log = logging.getLogger("test.invalid_manifest")

    result = desktop_sync._maybe_regenerate_dbt_docs(
        "demo",
        dbt_root / "target" / "manifest.json",
        queue,  # type: ignore[arg-type]
        cancel,  # type: ignore[arg-type]
        log,
    )

    assert result is True
    stages = [e["stage"] for e in queue.events]
    assert stages == ["dbt_docs", "dbt_docs"]
    assert queue.events[0]["status"] == "running"
    assert "manifest.json missing or invalid" in queue.events[0]["message"]
    assert queue.events[-1]["message"] == "dbt docs regenerated"


def test_maybe_regenerate_runs_on_commit_drift(monkeypatch, tmp_path):
    cfg_path = tmp_path / "config.yaml"
    dbt_root = tmp_path / "dbt_project"
    dbt_root.mkdir()
    last_synced = "1111111111111111111111111111111111111111"
    head = "2222222222222222222222222222222222222222"
    _write_project_config(
        cfg_path, "demo", dbt_root, last_synced_commit=last_synced
    )
    _patch_config_path(monkeypatch, cfg_path)
    _patch_run_git(monkeypatch, head)

    from lineage.tui.wizards.init import helpers as init_helpers
    from lineage.utils import dbt as dbt_utils

    monkeypatch.setattr(dbt_utils, "_validate_manifest", lambda _path: True)
    monkeypatch.setattr(
        init_helpers, "ensure_dbt_venv", lambda _adapter: tmp_path / "venv"
    )

    success_result = dbt_utils.DbtDocsResult(
        success=True,
        manifest_valid=True,
        catalog_exists=True,
        error_summary=None,
        raw_error=None,
        log_hint=None,
    )
    monkeypatch.setattr(
        dbt_utils, "run_dbt_docs_generate", lambda *a, **kw: success_result
    )

    queue = _RecordingQueue()
    cancel = _NotSetEvent()
    log = logging.getLogger("test.commit_drift")

    result = desktop_sync._maybe_regenerate_dbt_docs(
        "demo",
        dbt_root / "target" / "manifest.json",
        queue,  # type: ignore[arg-type]
        cancel,  # type: ignore[arg-type]
        log,
    )

    assert result is True
    assert queue.events, "expected at least one progress event"
    first = queue.events[0]
    assert first["stage"] == "dbt_docs"
    assert first["status"] == "running"
    assert "base advanced" in first["message"]
    # short hashes (7 chars) appear in the reason
    assert last_synced[:7] in first["message"]
    assert head[:7] in first["message"]


def test_maybe_regenerate_returns_false_when_dbt_docs_fails(
    monkeypatch, tmp_path
):
    cfg_path = tmp_path / "config.yaml"
    dbt_root = tmp_path / "dbt_project"
    dbt_root.mkdir()
    _write_project_config(cfg_path, "demo", dbt_root)
    _patch_config_path(monkeypatch, cfg_path)
    _patch_run_git(monkeypatch, "abcdef0" * 5)

    from lineage.tui.wizards.init import helpers as init_helpers
    from lineage.utils import dbt as dbt_utils

    # Manifest invalid → triggers regen path
    monkeypatch.setattr(dbt_utils, "_validate_manifest", lambda _path: False)
    monkeypatch.setattr(
        init_helpers, "ensure_dbt_venv", lambda _adapter: tmp_path / "venv"
    )

    failure_result = dbt_utils.DbtDocsResult(
        success=False,
        manifest_valid=False,
        catalog_exists=False,
        error_summary="Compilation Error: missing column foo",
        raw_error="full traceback here",
        log_hint="/tmp/dbt.log",
    )
    monkeypatch.setattr(
        dbt_utils, "run_dbt_docs_generate", lambda *a, **kw: failure_result
    )

    queue = _RecordingQueue()
    cancel = _NotSetEvent()
    log = logging.getLogger("test.dbt_failure")

    result = desktop_sync._maybe_regenerate_dbt_docs(
        "demo",
        dbt_root / "target" / "manifest.json",
        queue,  # type: ignore[arg-type]
        cancel,  # type: ignore[arg-type]
        log,
    )

    assert result is False
    error_events = [e for e in queue.events if e["status"] == "error"]
    assert error_events, "expected an error progress event"
    err = error_events[-1]
    assert err["stage"] == "dbt_docs"
    assert "dbt docs generate failed" in err["message"]
    assert "Compilation Error: missing column foo" in err["message"]
    assert "/tmp/dbt.log" in err["message"]


def test_maybe_regenerate_skips_cleanly_when_config_missing(
    monkeypatch, tmp_path
):
    missing_cfg = tmp_path / "does_not_exist.yaml"
    _patch_config_path(monkeypatch, missing_cfg)

    queue = _RecordingQueue()
    cancel = _NotSetEvent()
    log = logging.getLogger("test.no_config")

    result = desktop_sync._maybe_regenerate_dbt_docs(
        "demo",
        tmp_path / "manifest.json",
        queue,  # type: ignore[arg-type]
        cancel,  # type: ignore[arg-type]
        log,
    )

    assert result is True
    assert queue.events == []
