from __future__ import annotations

import shutil
from pathlib import Path
from types import SimpleNamespace

import core.paths as core_paths
import pytest
import yaml
from core.backends.config import UnifiedConfig
from fastapi import HTTPException
from ingest.static_loaders.salesforce.factory import SfAuthMode
from lineage.api import desktop_context, desktop_projects, desktop_setup
from pydantic import ValidationError


def _write_config(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))


def _make_request(unified_config: UnifiedConfig) -> SimpleNamespace:
    return SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                unified_config=unified_config,
                desktop_reader_cache={"unified": object()},
            )
        ),
        headers={},
    )


def _reset_typedef_home(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def test_hot_swap_default_project_reloads_new_project_config(tmp_path, monkeypatch):
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    _reset_typedef_home(typedef_home)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()

    cfg_file = core_paths.config_path()
    _write_config(
        cfg_file,
        {
            "default_project": None,
            "projects": {},
            "lineage": {
                "backend": "surrealdb",
                "url": "ws://127.0.0.1:3567",
                "namespace": "lineage",
            },
        },
    )

    stale_config = UnifiedConfig.from_yaml(cfg_file)

    project_root = typedef_home / "projects" / "medallion_reference"
    project_root.mkdir(parents=True, exist_ok=True)

    _write_config(
        cfg_file,
        {
            "default_project": "medallion_reference",
            "projects": {
                "medallion_reference": {
                    "name": "medallion_reference",
                    "dbt_path": str(project_root),
                    "graph_name": "medallion_reference",
                    "profile_name": "medallion_reference",
                    "profiles_dir": str(
                        typedef_home / "profiles" / "medallion_reference"
                    ),
                    "dbt_target": "duckdb",
                    "data": {
                        "backend": "duckdb",
                        "db_path": str(project_root / "medallion-reference.duckdb"),
                    },
                }
            },
            "lineage": {
                "backend": "surrealdb",
                "url": "ws://127.0.0.1:3567",
                "namespace": "lineage",
            },
        },
    )

    request = _make_request(stale_config)

    desktop_projects._hot_swap_default_project(request, "medallion_reference")
    context = desktop_context.resolve_desktop_request_context(request)

    assert context.project_name == "medallion_reference"
    assert context.graph_name == "medallion_reference"
    assert context.config is not None
    assert context.config.projects is not None
    assert "medallion_reference" in context.config.projects
    assert context.config.projects["medallion_reference"].dbt_path == project_root
    assert request.app.state.desktop_reader_cache == {}


def test_hot_swap_default_project_falls_back_when_reload_fails(tmp_path, monkeypatch):
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    _reset_typedef_home(typedef_home)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()

    cfg_file = core_paths.config_path()
    _write_config(
        cfg_file,
        {
            "default_project": "old_project",
            "projects": {
                "old_project": {
                    "name": "old_project",
                    "dbt_path": str(typedef_home / "projects" / "old_project"),
                    "graph_name": "old_project",
                }
            },
            "lineage": {
                "backend": "surrealdb",
                "url": "ws://127.0.0.1:3567",
                "namespace": "lineage",
            },
        },
    )

    stale_config = UnifiedConfig.from_yaml(cfg_file)
    request = _make_request(stale_config)
    request.app.state.app_state = SimpleNamespace(config=stale_config)

    monkeypatch.setattr(
        "core.backends.config.UnifiedConfig.from_yaml",
        lambda path: (_ for _ in ()).throw(ValueError("bad config")),
    )

    desktop_projects._hot_swap_default_project(request, "medallion_reference")

    assert stale_config.default_project == "medallion_reference"
    assert request.app.state.unified_config is stale_config
    assert request.app.state.app_state.config is stale_config
    assert request.app.state.desktop_reader_cache == {}


def test_update_project_request_rejects_invalid_backend_type():
    with pytest.raises(ValidationError):
        desktop_projects.UpdateProjectRequest(backend_type="sqlite")


def test_project_detail_rejects_invalid_backend_type():
    with pytest.raises(ValidationError):
        desktop_projects.ProjectDetail(
            name="test_project",
            clone_path="/tmp/test_project",
            dbt_path="/tmp/test_project",
            backend_type="sqlite",
        )


def test_detect_subprojects_hides_raw_exception_details(
    typedef_home, monkeypatch, caplog
):
    home, _ = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)

    def boom(self, pattern):
        raise PermissionError(f"permission denied: {project_root / 'secret-path'}")

    monkeypatch.setattr(Path, "rglob", boom)

    with caplog.at_level("WARNING"):
        subprojects, selected, warning = desktop_projects._detect_subprojects(
            "test_project", str(project_root)
        )

    assert subprojects == []
    assert selected == "."
    assert (
        warning
        == "Could not inspect dbt subprojects. Check the project path and permissions."
    )
    assert str(project_root / "secret-path") not in warning
    assert any(
        record.message == "Could not inspect dbt subprojects for project test_project"
        and record.exc_info is not None
        for record in caplog.records
    )


# ── Fixtures ──────────────────────────────────────────────────────────


@pytest.fixture()
def typedef_home(tmp_path, monkeypatch):
    """Set up an isolated TYPEDEF_HOME and return a (home, config_path) tuple."""
    home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    _reset_typedef_home(home)
    monkeypatch.setenv("TYPEDEF_HOME", str(home))
    core_paths.typedef_home.cache_clear()
    cfg = core_paths.config_path()
    yield home, cfg
    core_paths.typedef_home.cache_clear()


def _base_config(project_name: str = "test_project", **project_overrides) -> dict:
    """Return a minimal config dict with one project."""
    proj = {
        "name": project_name,
        "dbt_path": "/tmp/dbt",
        "graph_name": project_name,
        "data": {"backend": "duckdb", "db_path": ":memory:"},
        **project_overrides,
    }
    return {
        "default_project": project_name,
        "projects": {project_name: proj},
        "lineage": {
            "backend": "surrealdb",
            "url": "ws://127.0.0.1:3567",
            "namespace": "lineage",
        },
    }


@pytest.mark.asyncio
async def test_get_project_returns_backend_detail_and_subprojects(typedef_home):
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    nested_root = project_root / "nested"
    nested_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    (nested_root / "dbt_project.yml").write_text("name: nested\n")

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(nested_root),
            profile_name="analytics_profile",
            dbt_target="prod",
            data={
                "backend": "snowflake",
                "account": "acme",
                "user": "alice",
                "private_key_path": "~/.ssh/snowflake.p8",
                "warehouse": "COMPUTE_WH",
                "role": "ANALYST",
                "database": "ANALYTICS",
                "schema_name": "CORE",
                "allowed_databases": ["ANALYTICS", "RAW"],
            },
            env={"DBT_THREADS": "8"},
            profiling={"enabled": False},
        ),
    )

    result = await desktop_projects.get_project("test_project")

    assert result.name == "test_project"
    assert result.backend_type == "snowflake"
    assert result.clone_path == str(project_root)
    assert result.dbt_path == str(nested_root)
    assert result.profile_name == "analytics_profile"
    assert result.dbt_target == "prod"
    assert result.snowflake_account == "acme"
    assert result.snowflake_user == "alice"
    assert result.snowflake_private_key_path == "~/.ssh/snowflake.p8"
    assert result.snowflake_database == "ANALYTICS"
    assert result.snowflake_schema == "CORE"
    assert result.allowed_databases == ["ANALYTICS", "RAW"]
    assert result.env_vars == "DBT_THREADS=8"
    assert result.profiling_enabled is False
    assert result.subprojects == [".", "nested"]
    assert result.selected_subproject == "nested"


@pytest.mark.asyncio
async def test_get_project_tolerates_non_list_allowed_databases(typedef_home):
    _, cfg = typedef_home
    _write_config(
        cfg,
        _base_config(
            data={
                "backend": "snowflake",
                "allowed_databases": "ANALYTICS",
            }
        ),
    )

    result = await desktop_projects.get_project("test_project")

    assert result.backend_type == "snowflake"
    assert result.allowed_databases == []


@pytest.mark.asyncio
async def test_get_project_rejects_unsupported_persisted_backend(typedef_home):
    _, cfg = typedef_home
    _write_config(cfg, _base_config(data={"backend": "sqlite"}))

    with pytest.raises(HTTPException) as exc_info:
        await desktop_projects.get_project("test_project")

    assert exc_info.value.status_code == 500
    assert exc_info.value.detail == "Project config contains unsupported backend value"


@pytest.mark.asyncio
async def test_get_project_does_not_leak_databricks_token_in_env_vars(typedef_home):
    """Regression for the credential-exposure bug surfaced by code review:
    project["env"] contains DATABRICKS_TOKEN in browser-dev mode; without
    filtering via _RESERVED_PROJECT_ENV_KEYS, _serialize_env_vars
    round-trips the literal token to the browser via
    ProjectDetail.env_vars. Same defense exists for SNOWFLAKE_PAT_TOKEN.
    """
    _, cfg = typedef_home
    _write_config(
        cfg,
        _base_config(
            data={
                "backend": "databricks",
                "host": "acme.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/abc",
                "catalog": "main",
                "auth": {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
            },
            env={
                "DATABRICKS_TOKEN": "dapi-secret-must-not-leak",
                "DATABRICKS_HOST": "acme.cloud.databricks.com",
                "DATABRICKS_HTTP_PATH": "/sql/1.0/warehouses/abc",
                # User-supplied env (non-reserved) should still surface
                "DBT_THREADS": "8",
            },
        ),
    )

    result = await desktop_projects.get_project("test_project")

    assert "dapi-secret-must-not-leak" not in result.env_vars
    assert "DATABRICKS_TOKEN" not in result.env_vars
    assert "DATABRICKS_HOST" not in result.env_vars
    assert "DATABRICKS_HTTP_PATH" not in result.env_vars
    # Non-reserved user env still flows through
    assert "DBT_THREADS=8" in result.env_vars


@pytest.mark.asyncio
async def test_get_project_returns_databricks_detail(typedef_home):
    """Regression for the 500 a real user hit on `GET /desktop/projects/<name>`
    after creating a Databricks project — _backend_type returned None for
    'databricks', and the snowflake-only auth_method gate rejected the
    nested databricks auth shape."""
    _, cfg = typedef_home
    _write_config(
        cfg,
        _base_config(
            data={
                "backend": "databricks",
                "host": "acme.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/abc123",
                "warehouse_id": "abc123",
                "catalog": "main",
                "schema_name": "default",
                "auth": {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
                "allowed_catalogs": ["main", "samples"],
            },
        ),
    )

    result = await desktop_projects.get_project("test_project")

    assert result.backend_type == "databricks"
    assert result.databricks_host == "acme.cloud.databricks.com"
    assert result.databricks_http_path == "/sql/1.0/warehouses/abc123"
    assert result.databricks_warehouse_id == "abc123"
    assert result.databricks_catalog == "main"
    assert result.databricks_schema == "default"
    assert result.databricks_auth_method == "pat"
    assert result.allowed_catalogs == ["main", "samples"]
    # Snowflake-shaped fields stay empty for databricks projects
    assert result.snowflake_account is None
    assert result.snowflake_database is None


@pytest.mark.asyncio
async def test_get_project_databricks_oauth_u2m_auth_method(typedef_home):
    _, cfg = typedef_home
    _write_config(
        cfg,
        _base_config(
            data={
                "backend": "databricks",
                "host": "acme.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/abc",
                "catalog": "main",
                "auth": {"auth_method": "oauth_u2m", "token": "${DATABRICKS_TOKEN}"},
            },
        ),
    )

    result = await desktop_projects.get_project("test_project")

    assert result.backend_type == "databricks"
    assert result.databricks_auth_method == "oauth_u2m"


@pytest.mark.asyncio
async def test_get_project_rejects_unsupported_databricks_auth_method(typedef_home):
    _, cfg = typedef_home
    _write_config(
        cfg,
        _base_config(
            data={
                "backend": "databricks",
                "host": "acme.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/abc",
                "catalog": "main",
                "auth": {"auth_method": "service_principal"},
            },
        ),
    )

    with pytest.raises(HTTPException) as exc_info:
        await desktop_projects.get_project("test_project")

    assert exc_info.value.status_code == 500
    assert "databricks auth_method" in exc_info.value.detail


@pytest.mark.asyncio
async def test_update_project_rewrites_profiles_and_selected_subproject(typedef_home):
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    nested_root = project_root / "nested"
    nested_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    (nested_root / "dbt_project.yml").write_text("name: nested\n")
    profiles_path = core_paths.profiles_dir() / "test_project"
    profiles_path.mkdir(parents=True, exist_ok=True)
    (profiles_path / "profiles.yml").write_text("old: true\n")

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(project_root),
            profile_name="old_profile",
            dbt_target="dev",
            profiles_dir=str(profiles_path),
            data={"backend": "duckdb", "db_path": "warehouse.duckdb"},
            env={"OLD_FLAG": "1"},
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            backend_type="snowflake",
            snowflake_account="acme",
            snowflake_user="alice",
            snowflake_private_key_path="~/.ssh/snowflake.p8",
            snowflake_warehouse="COMPUTE_WH",
            snowflake_role="ANALYST",
            snowflake_database="ANALYTICS",
            snowflake_schema="CORE",
            allowed_databases=["ANALYTICS", "RAW"],
            dbt_target="prod",
            profile_name="analytics_profile",
            sub_project="nested",
            env_vars="DBT_THREADS=8, FOO=bar",
            profiling_enabled=False,
        ),
    )

    raw = yaml.safe_load(cfg.read_text())
    project = raw["projects"]["test_project"]
    assert project["dbt_path"] == str(nested_root)
    assert project["profile_name"] == "analytics_profile"
    assert project["dbt_target"] == "prod"
    assert project["profiling"] == {"enabled": False}
    assert project["env"] == {
        "SNOWFLAKE_PRIVATE_KEY_PATH": "~/.ssh/snowflake.p8",
        "DBT_THREADS": "8",
        "FOO": "bar",
    }
    assert project["data"] == {
        "backend": "snowflake",
        "account": "acme",
        "user": "alice",
        "private_key_path": "~/.ssh/snowflake.p8",
        "warehouse": "COMPUTE_WH",
        "role": "ANALYST",
        "database": "ANALYTICS",
        "schema_name": "CORE",
        "allowed_databases": ["ANALYTICS", "RAW"],
    }

    profiles = yaml.safe_load((profiles_path / "profiles.yml").read_text())
    assert profiles == {
        "analytics_profile": {
            "target": "prod",
            "outputs": {
                "prod": {
                    "type": "snowflake",
                    "account": "acme",
                    "user": "alice",
                    "private_key_path": "~/.ssh/snowflake.p8",
                    "warehouse": "COMPUTE_WH",
                    "role": "ANALYST",
                    "database": "ANALYTICS",
                    "schema": "CORE",
                    "threads": 4,
                }
            },
        }
    }


@pytest.mark.asyncio
async def test_update_project_databricks_pat_save(typedef_home):
    """Settings → Configure Project save path on a Databricks PAT project.

    Regression for the user-facing 'editing Databricks settings is silently
    discarded' bug — previously UpdateProjectRequest had no databricks_*
    fields, so the wizard's PATCH body landed nowhere.
    """
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    profiles_path = core_paths.profiles_dir() / "test_project"
    profiles_path.mkdir(parents=True, exist_ok=True)

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(project_root),
            profile_name="myproj",
            dbt_target="prod",
            profiles_dir=str(profiles_path),
            data={
                "backend": "databricks",
                "host": "old.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/old123",
                "catalog": "old_catalog",
                "schema_name": "old_schema",
                "auth": {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
            },
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            backend_type="databricks",
            databricks_host="https://new.cloud.databricks.com/?o=1234",
            databricks_http_path="/sql/1.0/warehouses/new456",
            databricks_warehouse_id="new456",
            databricks_catalog="main",
            databricks_schema="default",
            databricks_auth_method="pat",
            allowed_catalogs=["main", "samples"],
        ),
    )

    raw = yaml.safe_load(cfg.read_text())
    data = raw["projects"]["test_project"]["data"]
    # Host is normalized — protocol and query stripped
    assert data["host"] == "new.cloud.databricks.com"
    assert data["http_path"] == "/sql/1.0/warehouses/new456"
    assert data["warehouse_id"] == "new456"
    assert data["catalog"] == "main"
    assert data["schema_name"] == "default"
    assert data["allowed_catalogs"] == ["main", "samples"]
    # auth dict is rebuilt as a coherent block, token reference preserved
    assert data["auth"] == {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"}


@pytest.mark.asyncio
async def test_update_project_databricks_auth_method_pat_to_oauth(typedef_home):
    """Switching auth_method rebuilds the nested auth block; the token
    reference template stays the same (the keychain bridge handles the
    swap, and OAuth tokens load from DatabricksU2MTokenStore at preflight)."""
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    profiles_path = core_paths.profiles_dir() / "test_project"
    profiles_path.mkdir(parents=True, exist_ok=True)

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(project_root),
            profile_name="myproj",
            profiles_dir=str(profiles_path),
            data={
                "backend": "databricks",
                "host": "acme.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/abc",
                "catalog": "main",
                "auth": {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
            },
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            databricks_auth_method="oauth_u2m",
        ),
    )

    raw = yaml.safe_load(cfg.read_text())
    data = raw["projects"]["test_project"]["data"]
    assert data["auth"]["auth_method"] == "oauth_u2m"
    assert data["auth"]["token"] == "${DATABRICKS_TOKEN}"


@pytest.mark.asyncio
async def test_update_project_strips_databricks_keys_when_switching_to_snowflake(
    typedef_home,
):
    """Stale-key cleanup: switching to snowflake removes Databricks-only
    keys from the data block so they don't haunt subsequent reads."""
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    profiles_path = core_paths.profiles_dir() / "test_project"
    profiles_path.mkdir(parents=True, exist_ok=True)

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(project_root),
            profile_name="myproj",
            profiles_dir=str(profiles_path),
            data={
                "backend": "databricks",
                "host": "acme.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/abc",
                "catalog": "main",
                "warehouse_id": "abc",
                "schema_name": "default",
                "auth": {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
                "allowed_catalogs": ["main"],
            },
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            backend_type="snowflake",
            snowflake_account="acme",
            snowflake_user="alice",
            snowflake_private_key_path="~/.ssh/key.p8",
            snowflake_database="ANALYTICS",
            snowflake_schema="CORE",
        ),
    )

    raw = yaml.safe_load(cfg.read_text())
    data = raw["projects"]["test_project"]["data"]
    # Snowflake keys present
    assert data["account"] == "acme"
    assert data["database"] == "ANALYTICS"
    # Databricks-only keys gone
    for stale_key in (
        "host",
        "http_path",
        "warehouse_id",
        "catalog",
        "auth",
        "allowed_catalogs",
    ):
        assert stale_key not in data, f"stale Databricks key {stale_key!r} not stripped"


@pytest.mark.asyncio
async def test_update_project_strips_snowflake_keys_when_switching_to_databricks(
    typedef_home,
):
    """The reverse direction: snowflake → databricks strips snowflake keys."""
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    profiles_path = core_paths.profiles_dir() / "test_project"
    profiles_path.mkdir(parents=True, exist_ok=True)

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(project_root),
            profile_name="myproj",
            profiles_dir=str(profiles_path),
            data={
                "backend": "snowflake",
                "account": "acme",
                "user": "alice",
                "private_key_path": "~/.ssh/key.p8",
                "warehouse": "COMPUTE_WH",
                "role": "ANALYST",
                "database": "ANALYTICS",
                "schema_name": "CORE",
                "auth_method": "private_key",
            },
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            backend_type="databricks",
            databricks_host="acme.cloud.databricks.com",
            databricks_http_path="/sql/1.0/warehouses/abc",
            databricks_catalog="main",
            databricks_schema="default",
            databricks_auth_method="pat",
        ),
    )

    raw = yaml.safe_load(cfg.read_text())
    data = raw["projects"]["test_project"]["data"]
    assert data["host"] == "acme.cloud.databricks.com"
    for stale_key in (
        "account",
        "user",
        "private_key_path",
        "warehouse",
        "role",
        "database",
        "auth_method",  # the FLAT one — Databricks uses nested data.auth
    ):
        assert stale_key not in data, f"stale Snowflake key {stale_key!r} not stripped"


@pytest.mark.asyncio
async def test_update_project_tolerates_non_mapping_data(typedef_home):
    _, cfg = typedef_home
    _write_config(cfg, _base_config(data=None))

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(duckdb_path="warehouse.duckdb"),
    )

    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["data"] == {"db_path": "warehouse.duckdb"}


@pytest.mark.asyncio
async def test_update_project_preserves_unsupported_persisted_backend(typedef_home):
    _, cfg = typedef_home
    _write_config(
        cfg,
        _base_config(
            data={"backend": "sqlite", "db_path": "warehouse.duckdb"},
            profiling={"enabled": False},
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(profiling_enabled=True),
    )

    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["data"]["backend"] == "sqlite"
    assert raw["projects"]["test_project"]["profiling"] == {"enabled": True}


@pytest.mark.asyncio
async def test_update_project_rejects_missing_subproject_path(typedef_home):
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    _write_config(cfg, _base_config(dbt_path=str(project_root)))

    with pytest.raises(HTTPException) as exc_info:
        await desktop_projects.update_project(
            "test_project",
            desktop_projects.UpdateProjectRequest(sub_project="missing"),
        )

    assert exc_info.value.status_code == 400
    assert str(exc_info.value.detail) == "Subproject path does not exist"


@pytest.mark.asyncio
async def test_update_project_rejects_subproject_without_dbt_project_yml(
    typedef_home,
):
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    missing_dbt_root = project_root / "missing_dbt"
    missing_dbt_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    _write_config(cfg, _base_config(dbt_path=str(project_root)))

    with pytest.raises(HTTPException) as exc_info:
        await desktop_projects.update_project(
            "test_project",
            desktop_projects.UpdateProjectRequest(sub_project="missing_dbt"),
        )

    assert exc_info.value.status_code == 400
    assert "dbt_project.yml" in str(exc_info.value.detail)


# ── Profiling: list_projects ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_list_projects_profiling_defaults_true_when_absent(typedef_home):
    """When config has no profiling section, list_projects returns enabled=True."""
    _, cfg = typedef_home
    _write_config(cfg, _base_config())

    result = await desktop_projects.list_projects()
    proj = result.projects[0]
    assert proj.integrations.profiling_enabled is True


@pytest.mark.asyncio
async def test_list_projects_profiling_returns_false_when_disabled(typedef_home):
    """When config has profiling.enabled=false, list_projects reflects that."""
    _, cfg = typedef_home
    config = _base_config(profiling={"enabled": False})
    _write_config(cfg, config)

    result = await desktop_projects.list_projects()
    proj = result.projects[0]
    assert proj.integrations.profiling_enabled is False


@pytest.mark.asyncio
async def test_list_projects_profiling_handles_non_dict(typedef_home):
    """When config has profiling set to a non-dict value, defaults to True."""
    _, cfg = typedef_home
    config = _base_config(profiling=None)
    _write_config(cfg, config)

    result = await desktop_projects.list_projects()
    proj = result.projects[0]
    assert proj.integrations.profiling_enabled is True


# ── Profiling: update_project ────────────────────────────────────────


@pytest.mark.asyncio
async def test_update_project_sets_profiling_enabled(typedef_home):
    """PATCH with profiling_enabled=false writes to config and is reflected by list."""
    _, cfg = typedef_home
    _write_config(cfg, _base_config())

    req = desktop_projects.UpdateProjectRequest(profiling_enabled=False)
    await desktop_projects.update_project("test_project", req)

    # Verify written to disk
    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["profiling"]["enabled"] is False

    # Verify round-trip via list_projects
    result = await desktop_projects.list_projects()
    assert result.projects[0].integrations.profiling_enabled is False


@pytest.mark.asyncio
async def test_update_project_profiling_none_leaves_unchanged(typedef_home):
    """PATCH without profiling_enabled does not alter existing profiling config."""
    _, cfg = typedef_home
    config = _base_config(profiling={"enabled": False})
    _write_config(cfg, config)

    req = desktop_projects.UpdateProjectRequest(snowflake_account="new_acct")
    await desktop_projects.update_project("test_project", req)

    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["profiling"]["enabled"] is False


@pytest.mark.asyncio
async def test_update_project_profiling_repairs_non_dict(typedef_home):
    """PATCH with profiling_enabled on a config with non-dict profiling value works."""
    _, cfg = typedef_home
    config = _base_config(profiling="broken")
    _write_config(cfg, config)

    req = desktop_projects.UpdateProjectRequest(profiling_enabled=True)
    await desktop_projects.update_project("test_project", req)

    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["profiling"] == {"enabled": True}


# ── Profiling: _build_project_config ─────────────────────────────────


def test_build_project_config_includes_profiling_enabled():
    """_build_project_config writes profiling.enabled from the request."""
    req = desktop_setup.CreateProjectRequest(
        name="proj",
        git_url="https://github.com/example/repo",
        backend="duckdb",
        profiling_enabled=True,
    )
    result = desktop_setup._build_project_config(
        req, "proj", "/tmp/dbt", profile_name="test"
    )
    assert result["profiling"] == {"enabled": True}


def test_build_project_config_profiling_disabled():
    """_build_project_config respects profiling_enabled=False."""
    req = desktop_setup.CreateProjectRequest(
        name="proj",
        git_url="https://github.com/example/repo",
        backend="duckdb",
        profiling_enabled=False,
    )
    result = desktop_setup._build_project_config(
        req, "proj", "/tmp/dbt", profile_name="test"
    )
    assert result["profiling"] == {"enabled": False}


# ── Salesforce auth_type YAML serialization ────────────────────────────


# ── env_vars: setup-path parser parity with project-settings ────────────


def test_build_project_config_writes_user_env_vars_for_snowflake():
    """env_vars must reach project['env'] for Snowflake (TD-2888 parity).

    Before TD-2888 the frontend only sent env_vars for DuckDB, so a Snowflake
    dbt_project.yml that referenced `{{ env_var('DBT_PROJECT_DIR') }}` would
    fail dbt deps with a parsing error. This test guards the backend half of
    the fix.
    """
    req = desktop_setup.CreateProjectRequest(
        name="proj",
        git_url="https://github.com/example/repo",
        backend="snowflake",
        env_vars="DBT_PROJECT_DIR=/Users/x/projects/proj, FOO=bar",
    )
    result = desktop_setup._build_project_config(
        req, "proj", "/tmp/dbt", profile_name="test"
    )
    assert result["env"]["DBT_PROJECT_DIR"] == "/Users/x/projects/proj"
    assert result["env"]["FOO"] == "bar"


def test_build_project_config_filters_reserved_env_keys():
    """Reserved keys in user-supplied env_vars must not clobber credentials.

    The setup path now delegates to desktop_projects._parse_env_vars, which
    already filters SNOWFLAKE_PRIVATE_KEY_PATH, SNOWFLAKE_PAT_TOKEN, and
    DUCKDB_PATH. Without this, a user could overwrite the auth field set
    from snowflake_private_key_path / snowflake_pat_token via the free-form
    editor.
    """
    req = desktop_setup.CreateProjectRequest(
        name="proj",
        git_url="https://github.com/example/repo",
        backend="snowflake",
        snowflake_auth_method="private_key",
        snowflake_private_key_path="/legit/key.p8",
        env_vars=(
            "SNOWFLAKE_PRIVATE_KEY_PATH=/attacker/key.p8, "
            "SNOWFLAKE_PAT_TOKEN=stolen, "
            "DUCKDB_PATH=/attacker.duckdb, "
            "DBT_PROJECT_DIR=/Users/x/projects/proj"
        ),
    )
    result = desktop_setup._build_project_config(
        req, "proj", "/tmp/dbt", profile_name="test"
    )
    assert result["env"]["SNOWFLAKE_PRIVATE_KEY_PATH"] == "/legit/key.p8"
    assert "SNOWFLAKE_PAT_TOKEN" not in result["env"]
    assert "DUCKDB_PATH" not in result["env"]
    assert result["env"]["DBT_PROJECT_DIR"] == "/Users/x/projects/proj"


def test_build_project_config_serializes_sf_auth_type_as_plain_string():
    """SfAuthMode must be written as a plain string, not a !!python/object tag."""
    req = desktop_setup.CreateProjectRequest(
        name="proj",
        git_url="https://github.com/example/repo",
        backend="duckdb",
        salesforce_enabled=True,
        salesforce_auth_type=SfAuthMode.OAUTH_PKCE,
        salesforce_client_id="test-client-id",
    )
    result = desktop_setup._build_project_config(
        req, "proj", "/tmp/dbt", profile_name="test"
    )
    raw_yaml = yaml.dump(result, default_flow_style=False)
    assert "!!python" not in raw_yaml
    assert result["salesforce"]["auth_type"] == "oauth_pkce"


@pytest.mark.asyncio
async def test_update_project_serializes_sf_auth_type_as_plain_string(typedef_home):
    """Updating salesforce_auth_type must write a plain string to config YAML."""
    _, cfg = typedef_home
    _write_config(cfg, _base_config())

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            salesforce_enabled=True,
            salesforce_auth_type=SfAuthMode.OAUTH_PKCE,
            salesforce_client_id="test-client-id",
        ),
    )

    raw_text = cfg.read_text()
    assert "!!python" not in raw_text
    raw = yaml.safe_load(raw_text)
    assert raw["projects"]["test_project"]["salesforce"]["auth_type"] == "oauth_pkce"


@pytest.mark.anyio
async def test_update_project_persists_cleared_browser_fallback_credentials(
    tmp_path, monkeypatch
):
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    _reset_typedef_home(typedef_home)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()

    cfg_file = core_paths.config_path()
    _write_config(
        cfg_file,
        {
            "default_project": "medallion_reference",
            "projects": {
                "medallion_reference": {
                    "name": "medallion_reference",
                    "dbt_path": str(typedef_home / "projects" / "medallion_reference"),
                    "graph_name": "medallion_reference",
                    "data": {"backend": "duckdb", "db_path": "example.duckdb"},
                }
            },
            "lineage": {
                "backend": "surrealdb",
                "url": "ws://127.0.0.1:3567",
                "namespace": "lineage",
            },
        },
    )
    core_paths.env_path().write_text(
        "ANTHROPIC_API_KEY=legacy-anthropic\n"
        "OPENAI_API_KEY=legacy-openai\n"
        "SF_PASSWORD=legacy-password\n"
        "SF_SECURITY_TOKEN=legacy-token\n"
        "SF_CLIENT_SECRET=legacy-secret\n"
    )

    await desktop_projects.update_project(
        "medallion_reference",
        desktop_projects.UpdateProjectRequest(
            anthropic_api_key="",
            openai_api_key="rotated-openai",
            sf_password="",
            sf_security_token="",
            sf_client_secret="",
        ),
    )

    env_values = {
        key: value
        for key, value in (
            line.split("=", 1)
            for line in core_paths.env_path().read_text().splitlines()
            if line and not line.startswith("#")
        )
    }

    assert "ANTHROPIC_API_KEY" not in env_values
    assert env_values["OPENAI_API_KEY"] == "rotated-openai"
    assert "SF_PASSWORD" not in env_values
    assert "SF_SECURITY_TOKEN" not in env_values
    assert "SF_CLIENT_SECRET" not in env_values


# ── TD-2955: PATCH plumbs custom base URLs into .env ─────────────────


def _read_env_file() -> dict[str, str]:
    return {
        key: value
        for key, value in (
            line.split("=", 1)
            for line in core_paths.env_path().read_text().splitlines()
            if line and not line.startswith("#")
        )
    }


@pytest.mark.asyncio
async def test_update_project_writes_provider_base_urls(typedef_home):
    """TD-2955: ANTHROPIC_BASE_URL / OPENAI_BASE_URL ride the same .env
    hot-reload pipeline as the API keys, so the Anthropic / OpenAI SDKs
    pick them up via their native env-var lookup with no agent-code change."""
    _, cfg = typedef_home
    _write_config(cfg, _base_config())

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            anthropic_api_key="sk-ant-test",
            anthropic_base_url="https://gateway.example.com/anthropic",
            openai_api_key="sk-test",
            openai_base_url="https://gateway.example.com/openai/v1",
        ),
    )

    env_values = _read_env_file()
    assert env_values["ANTHROPIC_API_KEY"] == "sk-ant-test"
    assert env_values["ANTHROPIC_BASE_URL"] == "https://gateway.example.com/anthropic"
    assert env_values["OPENAI_API_KEY"] == "sk-test"
    assert env_values["OPENAI_BASE_URL"] == "https://gateway.example.com/openai/v1"


@pytest.mark.parametrize(
    "bad_value",
    [
        "ftp://example.com",
        "file:///etc/passwd",
        "javascript:alert(1)",
        "https://ok.example.com\nMALICIOUS=evil",
        "https://ok.example.com\rMALICIOUS=evil",
        "not-a-url",
    ],
)
def test_update_project_request_rejects_unsafe_base_urls(bad_value):
    """TD-2955: parity with _validate_databricks_host. Reject CRLF (would
    corrupt .env) and non-http(s) schemes (would let a PATCH caller redirect
    SDK traffic to file:// or other local handlers)."""
    with pytest.raises(ValidationError):
        desktop_projects.UpdateProjectRequest(anthropic_base_url=bad_value)
    with pytest.raises(ValidationError):
        desktop_projects.UpdateProjectRequest(openai_base_url=bad_value)


def test_update_project_request_accepts_clear_and_valid_base_urls():
    """Clear signal ("") and a real http(s) URL must pass."""
    desktop_projects.UpdateProjectRequest(
        anthropic_base_url="",
        openai_base_url="https://llm.w10e.com/api",
    )
    desktop_projects.UpdateProjectRequest(
        anthropic_base_url="http://localhost:8080",
        openai_base_url=None,
    )


@pytest.mark.asyncio
async def test_update_project_clears_provider_base_urls_when_empty(typedef_home):
    """TD-2955: setting a base URL to "" must remove it from .env, mirroring
    the API key clear behavior — otherwise users couldn't go back to the
    SDK default after pointing it at a gateway."""
    _, cfg = typedef_home
    _write_config(cfg, _base_config())
    core_paths.env_path().write_text(
        "ANTHROPIC_BASE_URL=https://stale.example.com\n"
        "OPENAI_BASE_URL=https://stale.example.com\n"
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            anthropic_base_url="",
            openai_base_url="",
        ),
    )

    env_values = _read_env_file()
    assert "ANTHROPIC_BASE_URL" not in env_values
    assert "OPENAI_BASE_URL" not in env_values


# ── Cluster round-3: PATCH routes databricks_host through SSRF allowlist ─


@pytest.mark.asyncio
async def test_update_project_rejects_unallowlisted_databricks_host(typedef_home):
    """The PATCH handler must run incoming `databricks_host` through
    `_validate_databricks_host` (the SSRF allowlist) so an unallowlisted
    host can't slip onto disk and get used by preflight/sync later."""
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    profiles_path = core_paths.profiles_dir() / "test_project"
    profiles_path.mkdir(parents=True, exist_ok=True)

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(project_root),
            profile_name="myproj",
            dbt_target="prod",
            profiles_dir=str(profiles_path),
            data={
                "backend": "databricks",
                "host": "old.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/old123",
                "catalog": "old_catalog",
                "schema_name": "old_schema",
                "auth": {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
            },
        ),
    )

    with pytest.raises(HTTPException) as exc_info:
        await desktop_projects.update_project(
            "test_project",
            desktop_projects.UpdateProjectRequest(
                databricks_host="evil.example.com",
            ),
        )
    assert exc_info.value.status_code == 400
    assert "Unrecognized" in exc_info.value.detail

    # The on-disk config.yaml must still hold the original host — a
    # rejected PATCH must not partially mutate persisted state.
    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["data"]["host"] == "old.cloud.databricks.com"


@pytest.mark.asyncio
async def test_update_project_strips_fragment_from_databricks_host(typedef_home):
    """A PATCH carrying a fragment-bearing host (`https://...databricks.com/#/sql/...`)
    persists the bare hostname — same canonical form as the wizard /
    create-project path. Closes the round-3 cluster signal that
    desktop_projects.py's inline normalizer drifted from the canonical helper."""
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    profiles_path = core_paths.profiles_dir() / "test_project"
    profiles_path.mkdir(parents=True, exist_ok=True)

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(project_root),
            profile_name="myproj",
            dbt_target="prod",
            profiles_dir=str(profiles_path),
            data={
                "backend": "databricks",
                "host": "old.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/old123",
                "catalog": "old_catalog",
                "schema_name": "old_schema",
                "auth": {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
            },
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            databricks_host="https://acme.cloud.databricks.com/#/sql/warehouses/abc",
        ),
    )

    raw = yaml.safe_load(cfg.read_text())
    data = raw["projects"]["test_project"]["data"]
    # Bare hostname — scheme, path, query, AND fragment all stripped.
    assert data["host"] == "acme.cloud.databricks.com"
