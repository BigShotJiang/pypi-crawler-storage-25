"""Tests for the Databricks OAuth U2M flow endpoints (TD-2734 U3)."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from unittest.mock import MagicMock, patch

import core.paths as core_paths
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from lineage.api import desktop_setup
from lineage.utils import databricks_oauth


@pytest.fixture(autouse=True)
def _isolate_oauth_env(monkeypatch):
    """Same env hygiene as test_desktop_databricks_setup.

    Prevents the conftest's ``load_dotenv`` from reintroducing the real
    DATABRICKS_TOKEN, and stubs ``load_env_file`` so the API handlers
    can't pull it back either.
    """
    for k in (
        "DATABRICKS_HOST",
        "DATABRICKS_TOKEN",
        "DATABRICKS_HTTP_PATH",
        "DATABRICKS_WAREHOUSE_ID",
        "DATABRICKS_CATALOG",
        "DATABRICKS_CALLBACK_PORT",
    ):
        monkeypatch.delenv(k, raising=False)


@pytest.fixture
def client(tmp_path, monkeypatch) -> TestClient:
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    if typedef_home.exists():
        shutil.rmtree(typedef_home)
    typedef_home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()
    desktop_setup._databricks_oauth_flows.clear()
    desktop_setup._DatabricksCallbackHandler.auth_code = None
    desktop_setup._DatabricksCallbackHandler.error = None
    desktop_setup._DatabricksCallbackHandler.callback_state = None
    app = FastAPI()
    app.include_router(desktop_setup.router)
    return TestClient(app)


# ── _resolve_databricks_callback_port ────────────────────────────────


def test_resolve_callback_port_default():
    assert desktop_setup._resolve_databricks_callback_port() == 8445


def test_resolve_callback_port_env_override(monkeypatch):
    monkeypatch.setenv("DATABRICKS_CALLBACK_PORT", "9091")
    assert desktop_setup._resolve_databricks_callback_port() == 9091


def test_resolve_callback_port_invalid_falls_back(monkeypatch):
    monkeypatch.setenv("DATABRICKS_CALLBACK_PORT", "not-a-port")
    assert desktop_setup._resolve_databricks_callback_port() == 8445


def test_resolve_callback_port_out_of_range_falls_back(monkeypatch):
    monkeypatch.setenv("DATABRICKS_CALLBACK_PORT", "999999")
    assert desktop_setup._resolve_databricks_callback_port() == 8445


# ── databricks_oauth module ──────────────────────────────────────────


def test_oauth_public_client_id_constant():
    assert databricks_oauth.DATABRICKS_OAUTH_PUBLIC_CLIENT_ID == "databricks-cli"


def test_initiate_u2m_consent_uses_authorization_url_property():
    """Per codex peer review: the SDK property is `authorization_url`,
    not `auth_url`. Pin the lookup so a regression to the wrong name
    fails fast at the test boundary."""
    fake_consent = MagicMock()
    fake_consent.authorization_url = "https://acme.cloud.databricks.com/oidc/v1/authorize?..."
    fake_consent.as_dict.return_value = {"state": "abc", "verifier": "xyz"}

    fake_oauth_client = MagicMock()
    fake_oauth_client.initiate_consent.return_value = fake_consent

    with patch(
        "databricks.sdk.oauth.OAuthClient.from_host",
        return_value=fake_oauth_client,
    ) as mock_from_host:
        consent_dict, authorize_url = databricks_oauth.initiate_u2m_consent(
            host="acme.cloud.databricks.com",
            redirect_url="http://localhost:8445",
        )

    # Bare loopback URI — no `/callback` path. Databricks's `databricks-cli`
    # public client rejects any path suffix on the registered loopback URIs;
    # the path-suffix variant got the wizard a real
    # "redirect_uri ... not registered" error against a live workspace.
    mock_from_host.assert_called_once_with(
        host="https://acme.cloud.databricks.com",
        client_id="databricks-cli",
        redirect_url="http://localhost:8445",
    )
    assert consent_dict == {"state": "abc", "verifier": "xyz"}
    assert authorize_url.startswith("https://acme.cloud.databricks.com/oidc/")


def test_initiate_u2m_consent_passes_https_through():
    fake_consent = MagicMock()
    fake_consent.authorization_url = "..."
    fake_consent.as_dict.return_value = {}
    fake_oauth_client = MagicMock()
    fake_oauth_client.initiate_consent.return_value = fake_consent

    with patch(
        "databricks.sdk.oauth.OAuthClient.from_host",
        return_value=fake_oauth_client,
    ) as mock_from_host:
        databricks_oauth.initiate_u2m_consent(
            host="https://acme.cloud.databricks.com",
            redirect_url="http://localhost:8445/callback",
        )
    # https:// already prefixed, so passed unchanged
    assert mock_from_host.call_args.kwargs["host"] == "https://acme.cloud.databricks.com"


def test_complete_u2m_consent_round_trips_through_from_dict():
    """Per codex peer review: use Consent.as_dict()/from_dict(), not pickle.
    The dict must round-trip through Consent.from_dict cleanly."""
    consent_dict = {"state": "abc", "verifier": "xyz"}

    fake_token = MagicMock()
    fake_token.access_token = "u2m-access-tok"
    fake_token.refresh_token = "u2m-refresh-tok"
    # Token.expiry is a datetime in real SDK; use a fixture
    import datetime as _dt
    fake_token.expiry = _dt.datetime(2026, 12, 31, tzinfo=_dt.timezone.utc)

    fake_creds = MagicMock()
    fake_creds.token.return_value = fake_token

    fake_consent = MagicMock()
    fake_consent.exchange_callback_parameters.return_value = fake_creds

    with patch(
        "databricks.sdk.oauth.Consent.from_dict",
        return_value=fake_consent,
    ) as mock_from_dict:
        tokens = databricks_oauth.complete_u2m_consent(
            consent_dict, "auth-code", "state-abc"
        )

    mock_from_dict.assert_called_once_with(consent_dict)
    fake_consent.exchange_callback_parameters.assert_called_once_with(
        {"code": "auth-code", "state": "state-abc"}
    )
    assert tokens.access_token == "u2m-access-tok"
    assert tokens.refresh_token == "u2m-refresh-tok"
    assert tokens.expires_at > 0


def test_complete_u2m_consent_handles_missing_refresh_token():
    """Some IdPs don't issue refresh tokens; tokens still persist."""
    fake_token = MagicMock(spec=["access_token", "expiry"])
    fake_token.access_token = "u2m-access-tok"
    fake_token.expiry = None

    fake_creds = MagicMock()
    fake_creds.token.return_value = fake_token

    fake_consent = MagicMock()
    fake_consent.exchange_callback_parameters.return_value = fake_creds

    with patch(
        "databricks.sdk.oauth.Consent.from_dict",
        return_value=fake_consent,
    ):
        tokens = databricks_oauth.complete_u2m_consent({}, "code", "state")

    assert tokens.access_token == "u2m-access-tok"
    assert tokens.refresh_token is None
    assert tokens.expires_at == 0.0


# ── DatabricksU2MTokenStore (file backend) ───────────────────────────


def _force_file_backend_store(tmp_path: Path, host: str) -> databricks_oauth.DatabricksU2MTokenStore:
    """Construct a token store backed by a file (skip keychain bridge)."""
    fake_client = MagicMock()
    fake_client.is_available.return_value = False
    return databricks_oauth.DatabricksU2MTokenStore(
        host=host,
        store_path=tmp_path,
        keychain_client=fake_client,
    )


def test_token_store_save_load_round_trip(tmp_path):
    store = _force_file_backend_store(tmp_path, "acme.cloud.databricks.com")
    tokens = databricks_oauth.DatabricksU2MTokens(
        access_token="acc", refresh_token="ref", expires_at=12345.6
    )
    store.save(tokens)
    loaded = store.load()
    assert loaded == tokens


def test_token_store_load_missing_returns_none(tmp_path):
    store = _force_file_backend_store(tmp_path, "acme.cloud.databricks.com")
    assert store.load() is None


def test_token_store_clear_removes_file(tmp_path):
    store = _force_file_backend_store(tmp_path, "acme.cloud.databricks.com")
    store.save(databricks_oauth.DatabricksU2MTokens(access_token="x"))
    store.clear()
    assert store.load() is None


def test_token_store_corrupt_data_clears_and_returns_none(tmp_path):
    store = _force_file_backend_store(tmp_path, "acme.cloud.databricks.com")
    # Write garbage bypass the dataclass round-trip
    store._backend.save("not-json-at-all")
    assert store.load() is None
    # Corrupt store self-cleared
    assert store.load() is None


def test_token_store_per_host_isolation(tmp_path):
    """Two workspaces save tokens independently — no overwrite."""
    aws_store = _force_file_backend_store(tmp_path, "aws.cloud.databricks.com")
    azure_store = _force_file_backend_store(
        tmp_path, "tenant.azuredatabricks.net"
    )

    aws_store.save(databricks_oauth.DatabricksU2MTokens(access_token="aws-tok"))
    azure_store.save(
        databricks_oauth.DatabricksU2MTokens(access_token="azure-tok")
    )

    assert aws_store.load().access_token == "aws-tok"
    assert azure_store.load().access_token == "azure-tok"


def test_token_store_normalizes_host_for_filename(tmp_path):
    """https:// prefix and trailing path are stripped from the filename."""
    store = _force_file_backend_store(
        tmp_path, "https://acme.cloud.databricks.com/?o=12345"
    )
    store.save(databricks_oauth.DatabricksU2MTokens(access_token="x"))
    expected = tmp_path / "databricks_oauth_u2m_acme.cloud.databricks.com.json"
    assert expected.exists()


def test_token_store_rejects_empty_host(tmp_path):
    with pytest.raises(ValueError, match="Cannot derive token-store key"):
        databricks_oauth.DatabricksU2MTokenStore(host="https://")


# ── /databricks/start-oauth-u2m ──────────────────────────────────────


def _patch_initiate(monkeypatch, consent_dict, authorize_url):
    """Patch initiate_u2m_consent and capture call args for later assertions.

    The API does `from lineage.utils.databricks_oauth import initiate_u2m_consent`
    inside the handler, so the lookup hits the module attribute fresh.
    """
    captured: dict = {}

    def _fake(*, host, redirect_url, client_id=None):
        captured["host"] = host
        captured["redirect_url"] = redirect_url
        captured["client_id"] = client_id
        return (consent_dict, authorize_url)

    monkeypatch.setattr(databricks_oauth, "initiate_u2m_consent", _fake)
    return captured


def test_start_oauth_u2m_returns_authorize_url(client, monkeypatch):
    consent_dict = {"state": "abc", "verifier": "xyz"}
    authorize_url = "https://acme.cloud.databricks.com/oidc/v1/authorize?abc"

    captured = _patch_initiate(monkeypatch, consent_dict, authorize_url)

    fake_server = MagicMock()
    with patch.object(
        desktop_setup, "_start_databricks_callback_server",
        return_value=fake_server,
    ) as mock_start_server:
        response = client.post(
            "/desktop/setup/databricks/start-oauth-u2m",
            json={"host": "acme.cloud.databricks.com"},
        )

    assert response.status_code == 200
    data = response.json()
    assert data["authorize_url"] == authorize_url
    assert "flow_id" in data
    mock_start_server.assert_called_once_with(8445)
    # Flow registered for status polling
    assert data["flow_id"] in desktop_setup._databricks_oauth_flows
    # Bare loopback redirect_url — `/callback` path was rejected by
    # Databricks's `databricks-cli` public client in production. RFC 8252
    # §7.3 + the SDK's own external-browser flow (which uses
    # `http://localhost:8020`, no path) are the references.
    assert captured["redirect_url"] == "http://localhost:8445"
    assert "/callback" not in captured["redirect_url"]


def test_start_oauth_u2m_invalid_host_rejected(client, monkeypatch):
    response = client.post(
        "/desktop/setup/databricks/start-oauth-u2m",
        json={"host": "evil.example.com"},
    )
    assert response.status_code == 400
    assert "Unrecognized" in response.json()["detail"]


def test_start_oauth_u2m_port_collision_returns_409(client, monkeypatch):
    with patch.object(
        desktop_setup, "_start_databricks_callback_server",
        side_effect=OSError("Address already in use"),
    ):
        # Initiate would never run, but patch defensively
        _patch_initiate(monkeypatch, {}, "")
        response = client.post(
            "/desktop/setup/databricks/start-oauth-u2m",
            json={"host": "acme.cloud.databricks.com"},
        )
    assert response.status_code == 409
    assert "callback server" in response.json()["detail"]


def test_start_oauth_u2m_oidc_discovery_failure_returns_502(client, monkeypatch):
    """If from_host() can't reach the workspace's OIDC endpoint, return 502.

    The host allowlist passes, but DNS / network / 404 failures from the
    SDK's blocking discovery call should not surface as 500."""
    fake_server = MagicMock()

    def _raise(*, host, redirect_url, client_id=None):
        raise ConnectionError("DNS lookup failed")

    monkeypatch.setattr(databricks_oauth, "initiate_u2m_consent", _raise)
    with patch.object(
        desktop_setup, "_start_databricks_callback_server",
        return_value=fake_server,
    ):
        response = client.post(
            "/desktop/setup/databricks/start-oauth-u2m",
            json={"host": "acme.cloud.databricks.com"},
        )
    assert response.status_code == 502
    assert "OIDC" in response.json()["detail"]
    # Loopback server cleaned up on failure
    fake_server.server_close.assert_called_once()


def test_start_oauth_u2m_closes_prior_flow_server(client, monkeypatch):
    """Starting a new flow while one is pending closes the prior server."""
    consent_dict = {"state": "abc"}
    _patch_initiate(monkeypatch, consent_dict, "https://...")

    prior_server = MagicMock()
    desktop_setup._databricks_oauth_flows["stale-flow-id"] = {
        "server": prior_server,
        "consent_dict": {},
        "host": "acme.cloud.databricks.com",
    }

    new_server = MagicMock()
    with patch.object(
        desktop_setup, "_start_databricks_callback_server",
        return_value=new_server,
    ):
        response = client.post(
            "/desktop/setup/databricks/start-oauth-u2m",
            json={"host": "acme.cloud.databricks.com"},
        )

    assert response.status_code == 200
    prior_server.server_close.assert_called_once()
    assert "stale-flow-id" not in desktop_setup._databricks_oauth_flows


# ── /databricks/oauth-status SSE ─────────────────────────────────────


def _consume_sse(response) -> list[dict]:
    """Parse the streamed SSE response into a list of {event, data} dicts."""
    events = []
    for raw_block in response.text.split("\n\n"):
        block = raw_block.strip()
        if not block:
            continue
        event_type = "message"
        data_lines = []
        for line in block.split("\n"):
            if line.startswith("event:"):
                event_type = line[len("event:"):].strip()
            elif line.startswith("data:"):
                data_lines.append(line[len("data:"):].strip())
        if data_lines:
            events.append(
                {"event": event_type, "data": json.loads("\n".join(data_lines))}
            )
    return events


def test_oauth_status_unknown_flow_returns_404(client):
    response = client.get("/desktop/setup/databricks/oauth-status/missing")
    assert response.status_code == 404


def test_oauth_status_success_persists_token(client, tmp_path, monkeypatch):
    """Happy path: callback fires, exchange completes, token persists."""
    flow_id = "flow-123"
    desktop_setup._databricks_oauth_flows[flow_id] = {
        "server": MagicMock(),
        "consent_dict": {"state": "abc"},
        "host": "acme.cloud.databricks.com",
    }
    # Simulate the callback already firing
    desktop_setup._DatabricksCallbackHandler.auth_code = "code-xyz"
    desktop_setup._DatabricksCallbackHandler.callback_state = "abc"

    fake_tokens = databricks_oauth.DatabricksU2MTokens(
        access_token="captured-access-tok",
        refresh_token="captured-refresh-tok",
        expires_at=12345.0,
    )

    save_calls = []

    class _RecordingStore:
        def __init__(self, host):
            self._host = host

        def save(self, tokens):
            save_calls.append((self._host, tokens))

    def _fake_complete(consent_dict, code, state):
        return fake_tokens

    monkeypatch.setattr(databricks_oauth, "complete_u2m_consent", _fake_complete)
    monkeypatch.setattr(
        databricks_oauth, "DatabricksU2MTokenStore", _RecordingStore
    )

    response = client.get(f"/desktop/setup/databricks/oauth-status/{flow_id}")
    assert response.status_code == 200
    events = _consume_sse(response)

    success = next((e for e in events if e["event"] == "success"), None)
    assert success is not None
    assert success["data"]["host"] == "acme.cloud.databricks.com"
    assert success["data"]["access_token_captured"] is True
    # Access token must NOT be in the SSE payload (keychain bridge owns it)
    assert "access_token" not in success["data"]

    # Token persisted via the per-host store
    assert len(save_calls) == 1
    assert save_calls[0][0] == "acme.cloud.databricks.com"
    assert save_calls[0][1] == fake_tokens

    # Flow cleaned up
    assert flow_id not in desktop_setup._databricks_oauth_flows


def test_oauth_status_callback_error_emits_error_event(client):
    flow_id = "flow-err"
    desktop_setup._databricks_oauth_flows[flow_id] = {
        "server": MagicMock(),
        "consent_dict": {},
        "host": "acme.cloud.databricks.com",
    }
    desktop_setup._DatabricksCallbackHandler.error = "access_denied"

    response = client.get(f"/desktop/setup/databricks/oauth-status/{flow_id}")
    events = _consume_sse(response)

    err = next((e for e in events if e["event"] == "error"), None)
    assert err is not None
    assert "access_denied" in err["data"]["message"]
    assert flow_id not in desktop_setup._databricks_oauth_flows


def test_oauth_status_exchange_failure_emits_error_event(client, monkeypatch):
    flow_id = "flow-exch-fail"
    desktop_setup._databricks_oauth_flows[flow_id] = {
        "server": MagicMock(),
        "consent_dict": {"state": "abc"},
        "host": "acme.cloud.databricks.com",
    }
    desktop_setup._DatabricksCallbackHandler.auth_code = "code-xyz"
    desktop_setup._DatabricksCallbackHandler.callback_state = "abc"

    def _raise(consent_dict, code, state):
        raise RuntimeError("state mismatch")

    monkeypatch.setattr(databricks_oauth, "complete_u2m_consent", _raise)

    response = client.get(f"/desktop/setup/databricks/oauth-status/{flow_id}")
    events = _consume_sse(response)

    err = next((e for e in events if e["event"] == "error"), None)
    assert err is not None
    assert "Token exchange failed" in err["data"]["message"]
    assert flow_id not in desktop_setup._databricks_oauth_flows


# ── /databricks/disconnect ───────────────────────────────────────────


def test_disconnect_clears_token_store(client, monkeypatch):
    cleared_hosts = []

    class _RecordingStore:
        def __init__(self, host):
            self._host = host

        def clear(self):
            cleared_hosts.append(self._host)

    monkeypatch.setattr(
        databricks_oauth, "DatabricksU2MTokenStore", _RecordingStore
    )

    response = client.post(
        "/desktop/setup/databricks/disconnect",
        json={"host": "acme.cloud.databricks.com"},
    )
    assert response.status_code == 200
    assert cleared_hosts == ["acme.cloud.databricks.com"]


def test_disconnect_invalid_host_rejected(client):
    response = client.post(
        "/desktop/setup/databricks/disconnect",
        json={"host": "evil.example.com"},
    )
    assert response.status_code == 400
