"""Tests for the Databricks branches of the desktop setup API (TD-2734 U2)."""

from __future__ import annotations

import asyncio
import shutil
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import core.paths as core_paths
import pytest
from core.models.databricks import DatabricksConnectionProbe
from fastapi import FastAPI
from fastapi.testclient import TestClient
from lineage.api import desktop_setup


@pytest.fixture(autouse=True)
def _isolate_databricks_env(monkeypatch):
    """Clear DATABRICKS_* env that the conftest's load_dotenv may have populated.

    Tests that exercise env-defaults explicitly re-set the keys they need;
    this fixture ensures every other test sees a blank slate so the
    request-payload tokens are the source of truth.

    Patches ``load_env_file`` to a no-op so the .env reload in the
    setup-API handlers can't reintroduce the real ``DATABRICKS_TOKEN``
    that the conftest's ``load_dotenv`` may have placed in os.environ.
    """
    for k in (
        "DATABRICKS_HOST",
        "DATABRICKS_TOKEN",
        "DATABRICKS_HTTP_PATH",
        "DATABRICKS_WAREHOUSE_ID",
        "DATABRICKS_CATALOG",
    ):
        monkeypatch.delenv(k, raising=False)

    # The setup-API's _resolve_databricks_token / list-warehouses /
    # list-catalogs handlers call load_env_file() which re-reads the
    # repo .env via python-dotenv with override=False. With the env
    # vars cleared above, that reload would silently re-introduce the
    # real PAT and let the test hit production Databricks. Stub it.
    import lineage.utils.env

    def _noop():
        return None

    monkeypatch.setattr(lineage.utils.env, "load_env_file", _noop)
    # Some imports go through the api module's local reference
    import lineage.api.desktop_setup
    if hasattr(lineage.api.desktop_setup, "load_env_file"):
        monkeypatch.setattr(
            lineage.api.desktop_setup, "load_env_file", _noop, raising=False
        )


def _build_client(tmp_path, monkeypatch) -> TestClient:
    """Mirror of test_desktop_quickstart's _build_client for setup endpoints.

    TYPEDEF_HOME must live under ``Path.home()`` for ``core.paths`` security
    checks; pytest's tmp_path lives under /private/var/folders and is rejected.
    """
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    if typedef_home.exists():
        shutil.rmtree(typedef_home)
    typedef_home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()
    desktop_setup._clone_ops.clear()
    app = FastAPI()
    app.include_router(desktop_setup.router)
    return TestClient(app)


# ── env-defaults ─────────────────────────────────────────────────────


def test_env_defaults_surfaces_databricks_keys(tmp_path, monkeypatch):
    monkeypatch.setenv("DATABRICKS_HOST", "acme.cloud.databricks.com")
    monkeypatch.setenv("DATABRICKS_TOKEN", "pat-tok")
    monkeypatch.setenv("DATABRICKS_HTTP_PATH", "/sql/1.0/warehouses/abc123")
    monkeypatch.setenv("DATABRICKS_WAREHOUSE_ID", "abc123")
    monkeypatch.setenv("DATABRICKS_CATALOG", "main")

    client = _build_client(tmp_path, monkeypatch)
    response = client.get("/desktop/setup/env-defaults")

    assert response.status_code == 200
    data = response.json()
    assert data["DATABRICKS_HOST"] == "acme.cloud.databricks.com"
    assert data["DATABRICKS_TOKEN"] == "pat-tok"
    assert data["DATABRICKS_HTTP_PATH"] == "/sql/1.0/warehouses/abc123"
    assert data["DATABRICKS_WAREHOUSE_ID"] == "abc123"
    assert data["DATABRICKS_CATALOG"] == "main"


def test_env_defaults_omits_databricks_when_unset(tmp_path, monkeypatch):
    # Make sure DATABRICKS_* keys are not surfaced when not set
    for k in (
        "DATABRICKS_HOST",
        "DATABRICKS_TOKEN",
        "DATABRICKS_HTTP_PATH",
        "DATABRICKS_WAREHOUSE_ID",
        "DATABRICKS_CATALOG",
    ):
        monkeypatch.delenv(k, raising=False)

    client = _build_client(tmp_path, monkeypatch)
    response = client.get("/desktop/setup/env-defaults")

    assert response.status_code == 200
    data = response.json()
    assert "DATABRICKS_HOST" not in data
    assert "DATABRICKS_TOKEN" not in data


# ── _validate_databricks_host ────────────────────────────────────────


def test_validate_databricks_host_accepts_aws_workspace():
    assert (
        desktop_setup._validate_databricks_host(
            "https://dbc-abc12345-1234.cloud.databricks.com/"
        )
        == "dbc-abc12345-1234.cloud.databricks.com"
    )


def test_validate_databricks_host_accepts_gcp_workspace():
    assert (
        desktop_setup._validate_databricks_host(
            "https://acme.gcp.databricks.com/?o=1234"
        )
        == "acme.gcp.databricks.com"
    )


def test_validate_databricks_host_accepts_azure_workspace():
    assert (
        desktop_setup._validate_databricks_host(
            "adb-1234567890123456.7.azuredatabricks.net"
        )
        == "adb-1234567890123456.7.azuredatabricks.net"
    )


def test_validate_databricks_host_rejects_evil_host():
    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc:
        desktop_setup._validate_databricks_host("https://evil.example.com/")
    assert exc.value.status_code == 400
    assert "Unrecognized" in exc.value.detail


def test_validate_databricks_host_rejects_empty():
    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc:
        desktop_setup._validate_databricks_host("")
    assert exc.value.status_code == 400


def test_validate_databricks_host_allows_localhost_when_dev_mode_set(monkeypatch):
    # Loopback is opt-in via TYPEDEF_DEV_MODE=1 (recorded fixtures, tunnels).
    monkeypatch.setenv("TYPEDEF_DEV_MODE", "1")
    assert desktop_setup._validate_databricks_host("http://localhost:8080") == "localhost:8080"
    assert desktop_setup._validate_databricks_host("http://127.0.0.1:8080") == "127.0.0.1:8080"


def test_validate_databricks_host_rejects_localhost_without_dev_mode(monkeypatch):
    """SSRF allowlist must not silently permit loopback when this validator
    runs in a non-desktop deployment. Gated behind TYPEDEF_DEV_MODE=1."""
    from fastapi import HTTPException

    monkeypatch.delenv("TYPEDEF_DEV_MODE", raising=False)
    with pytest.raises(HTTPException) as exc:
        desktop_setup._validate_databricks_host("http://localhost:8080")
    assert exc.value.status_code == 400
    assert "TYPEDEF_DEV_MODE" in exc.value.detail

    with pytest.raises(HTTPException) as exc:
        desktop_setup._validate_databricks_host("http://127.0.0.1:8080")
    assert exc.value.status_code == 400
    assert "TYPEDEF_DEV_MODE" in exc.value.detail


def test_validate_databricks_host_rejects_localhost_when_dev_mode_not_one(monkeypatch):
    """Only the literal '1' opts in — '0', 'true', or empty must reject."""
    from fastapi import HTTPException

    for value in ("0", "true", "yes", ""):
        monkeypatch.setenv("TYPEDEF_DEV_MODE", value)
        with pytest.raises(HTTPException) as exc:
            desktop_setup._validate_databricks_host("http://localhost:8080")
        assert exc.value.status_code == 400, f"value={value!r} should reject"


def test_validate_databricks_host_accepts_explicit_port_on_known_suffix():
    """Regression for the copilot-found suffix-vs-port-bearing-host bug:
    the suffix check previously ran against the port-bearing normalized
    form, so a paste like 'dbc-...cloud.databricks.com:443' got rejected
    even though the host_only form matches the allowlist suffix."""
    assert (
        desktop_setup._validate_databricks_host(
            "https://dbc-abc12345-1234.cloud.databricks.com:443"
        )
        == "dbc-abc12345-1234.cloud.databricks.com:443"
    )


# ── /test-connection (Databricks branch) ─────────────────────────────


def _good_databricks_payload() -> dict:
    """A baseline Databricks test-connection payload that should succeed under mocks."""
    return {
        "backend_type": "databricks",
        "databricks_host": "acme.cloud.databricks.com",
        "databricks_http_path": "/sql/1.0/warehouses/abc123",
        "databricks_warehouse_id": "abc123",
        "databricks_catalog": "main",
        "databricks_auth_method": "pat",
        "databricks_pat_token": "pat-tok",
    }


def _patch_databricks_backend(probe: DatabricksConnectionProbe):
    """Patch DatabricksDataQueryBackend so test_connection returns *probe*.

    The backend is constructed inside an `async with` block; we mock both
    ``__aenter__`` and ``__aexit__`` plus the ``test_connection`` coroutine.
    """
    fake_backend = MagicMock()
    fake_backend.__aenter__ = AsyncMock(return_value=fake_backend)
    fake_backend.__aexit__ = AsyncMock(return_value=None)
    fake_backend.test_connection = AsyncMock(return_value=probe)
    return patch(
        "core.backends.data_query.databricks_backend.DatabricksDataQueryBackend",
        return_value=fake_backend,
    )


def test_databricks_test_connection_full_mode(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)
    probe = DatabricksConnectionProbe(
        ok=True, mode="full", warnings=[], discovered_catalogs=3
    )

    with _patch_databricks_backend(probe):
        response = client.post(
            "/desktop/setup/test-connection", json=_good_databricks_payload()
        )

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["message"] == "Connected successfully"


def test_databricks_test_connection_degraded_surfaces_warnings(tmp_path, monkeypatch):
    """R17: degraded mode surfaces warnings as success=True with banner copy."""
    client = _build_client(tmp_path, monkeypatch)
    probe = DatabricksConnectionProbe(
        ok=True,
        mode="degraded",
        warnings=[
            "system.access.table_lineage grant denied — falling back to "
            "sqlglot-only column lineage."
        ],
        discovered_catalogs=3,
    )

    with _patch_databricks_backend(probe):
        response = client.post(
            "/desktop/setup/test-connection", json=_good_databricks_payload()
        )

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True  # degraded != failure
    assert "degraded" in data["message"]
    assert "table_lineage" in data["message"]


def test_databricks_test_connection_not_ok_returns_failure(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)
    probe = DatabricksConnectionProbe(
        ok=False,
        mode="full",
        warnings=["information_schema.catalogs grant denied"],
        discovered_catalogs=0,
    )

    with _patch_databricks_backend(probe):
        response = client.post(
            "/desktop/setup/test-connection", json=_good_databricks_payload()
        )

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is False
    assert "information_schema" in data["message"]


def test_databricks_test_connection_cluster_path_inline_rejection(tmp_path, monkeypatch):
    """Cluster http_path returns 400 from the config validator, not a connector stack trace."""
    client = _build_client(tmp_path, monkeypatch)
    payload = _good_databricks_payload()
    payload["databricks_http_path"] = "/clusters/0123-abcdef"

    response = client.post("/desktop/setup/test-connection", json=payload)

    assert response.status_code == 400
    assert "cluster" in response.json()["detail"].lower() or "warehouse" in response.json()["detail"].lower()


def test_databricks_test_connection_invalid_host_rejected(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)
    payload = _good_databricks_payload()
    payload["databricks_host"] = "evil.example.com"

    response = client.post("/desktop/setup/test-connection", json=payload)

    assert response.status_code == 400
    assert "Unrecognized" in response.json()["detail"]


def test_databricks_test_connection_missing_token_rejected(tmp_path, monkeypatch):
    monkeypatch.delenv("DATABRICKS_TOKEN", raising=False)
    client = _build_client(tmp_path, monkeypatch)
    payload = _good_databricks_payload()
    payload["databricks_pat_token"] = None

    response = client.post("/desktop/setup/test-connection", json=payload)

    assert response.status_code == 400
    assert "PAT" in response.json()["detail"]


def test_databricks_test_connection_oauth_token_required_for_oauth_method(
    tmp_path, monkeypatch
):
    client = _build_client(tmp_path, monkeypatch)
    payload = _good_databricks_payload()
    payload["databricks_auth_method"] = "oauth_u2m"
    payload["databricks_pat_token"] = None
    payload["databricks_oauth_u2m_token"] = None

    # Stub the keychain-fallback so it returns no token (default case —
    # nothing stored for this host).
    monkeypatch.setattr(
        desktop_setup, "_load_databricks_oauth_token", lambda host: None
    )

    response = client.post("/desktop/setup/test-connection", json=payload)

    assert response.status_code == 400
    assert "OAuth U2M token" in response.json()["detail"]


def test_databricks_test_connection_oauth_token_loaded_from_keychain(
    tmp_path, monkeypatch
):
    """When the wizard's OAuth flow has stored a token in the per-host
    keychain blob, test-connection in OAuth mode picks it up automatically
    even though the request payload carries no databricks_oauth_u2m_token.

    Regression for the user-facing bug where the wizard reported
    'Authenticated' (because the SSE flow set
    databricksOAuthU2MTokenCaptured=true after persisting the token) but
    test_connection then 400'd with 'OAuth U2M token is required'.
    """
    client = _build_client(tmp_path, monkeypatch)

    # Track what token reaches the backend probe.
    captured = {}

    def _fake_loader(host: str):
        captured["host"] = host
        return "captured-oauth-tok"

    monkeypatch.setattr(
        desktop_setup, "_load_databricks_oauth_token", _fake_loader
    )

    probe = DatabricksConnectionProbe(
        ok=True, mode="full", warnings=[], discovered_catalogs=2
    )
    payload = _good_databricks_payload()
    payload["databricks_auth_method"] = "oauth_u2m"
    payload["databricks_pat_token"] = None
    payload["databricks_oauth_u2m_token"] = None

    with _patch_databricks_backend(probe):
        response = client.post("/desktop/setup/test-connection", json=payload)

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    # Loader was called with the request's host
    assert captured["host"] == "acme.cloud.databricks.com"


def test_databricks_test_connection_cold_start_timeout(tmp_path, monkeypatch):
    """When the probe doesn't return within 90s, surface 'starting' message."""
    client = _build_client(tmp_path, monkeypatch)

    # Build a backend whose test_connection blocks indefinitely; force the
    # timeout to fire by lowering it for the test.
    monkeypatch.setattr(
        desktop_setup, "_DATABRICKS_TEST_CONNECTION_TIMEOUT_S", 0.05
    )

    fake_backend = MagicMock()
    fake_backend.__aenter__ = AsyncMock(return_value=fake_backend)
    fake_backend.__aexit__ = AsyncMock(return_value=None)

    async def _hang_forever():
        await asyncio.sleep(10)
        return DatabricksConnectionProbe(ok=True, mode="full", discovered_catalogs=0)

    fake_backend.test_connection = _hang_forever

    with patch(
        "core.backends.data_query.databricks_backend.DatabricksDataQueryBackend",
        return_value=fake_backend,
    ):
        response = client.post(
            "/desktop/setup/test-connection", json=_good_databricks_payload()
        )

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is False
    assert "Warehouse is starting" in data["message"]


# ── /list-warehouses ─────────────────────────────────────────────────


def test_list_warehouses_returns_full_shape(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)

    fake_warehouses = [
        {"id": "abc123", "name": "Prod", "state": "RUNNING"},
        {"id": "def456", "name": "Dev", "state": "STOPPED"},
    ]
    with patch(
        "lineage.utils.databricks.list_databricks_warehouses",
        return_value=fake_warehouses,
    ) as mock_list:
        response = client.post(
            "/desktop/setup/list-warehouses",
            json={
                "host": "acme.cloud.databricks.com",
                "auth_method": "pat",
                "pat_token": "pat-tok",
            },
        )

    assert response.status_code == 200
    assert response.json() == {"warehouses": fake_warehouses}
    mock_list.assert_called_once_with(
        host="acme.cloud.databricks.com",
        pat_token="pat-tok",
        oauth_token=None,
    )


def test_list_warehouses_empty_workspace_returns_empty_list(tmp_path, monkeypatch):
    """R16: empty workspace returns {warehouses: []}, not 404."""
    client = _build_client(tmp_path, monkeypatch)

    with patch(
        "lineage.utils.databricks.list_databricks_warehouses",
        return_value=[],
    ):
        response = client.post(
            "/desktop/setup/list-warehouses",
            json={
                "host": "acme.cloud.databricks.com",
                "auth_method": "pat",
                "pat_token": "pat-tok",
            },
        )

    assert response.status_code == 200
    assert response.json() == {"warehouses": []}


def test_list_warehouses_oauth_path(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)

    with patch(
        "lineage.utils.databricks.list_databricks_warehouses",
        return_value=[],
    ) as mock_list:
        response = client.post(
            "/desktop/setup/list-warehouses",
            json={
                "host": "acme.cloud.databricks.com",
                "auth_method": "oauth_u2m",
                "oauth_u2m_token": "oauth-tok",
            },
        )

    assert response.status_code == 200
    mock_list.assert_called_once_with(
        host="acme.cloud.databricks.com",
        pat_token=None,
        oauth_token="oauth-tok",
    )


def test_list_warehouses_oauth_missing_token_rejected(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)
    response = client.post(
        "/desktop/setup/list-warehouses",
        json={
            "host": "acme.cloud.databricks.com",
            "auth_method": "oauth_u2m",
        },
    )
    assert response.status_code == 400
    assert "OAuth U2M token" in response.json()["detail"]


def test_list_warehouses_invalid_host_rejected(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)
    response = client.post(
        "/desktop/setup/list-warehouses",
        json={"host": "evil.example.com", "pat_token": "pat-tok"},
    )
    assert response.status_code == 400
    assert "Unrecognized" in response.json()["detail"]


# ── /list-catalogs ───────────────────────────────────────────────────


def test_list_catalogs_returns_names(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)

    with patch(
        "lineage.utils.databricks.list_databricks_catalogs",
        return_value=["main", "samples", "hive_metastore"],
    ):
        response = client.post(
            "/desktop/setup/list-catalogs",
            json={
                "host": "acme.cloud.databricks.com",
                "http_path": "/sql/1.0/warehouses/abc123",
                "pat_token": "pat-tok",
            },
        )

    assert response.status_code == 200
    assert response.json() == {"catalogs": ["main", "samples", "hive_metastore"]}


def test_list_catalogs_cluster_path_returns_400(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)

    with patch(
        "lineage.utils.databricks.list_databricks_catalogs",
        side_effect=ValueError(
            "Databricks backend supports SQL Warehouses only..."
        ),
    ):
        response = client.post(
            "/desktop/setup/list-catalogs",
            json={
                "host": "acme.cloud.databricks.com",
                "http_path": "/clusters/abc",
                "pat_token": "pat-tok",
            },
        )

    assert response.status_code == 400
    assert "SQL Warehouses only" in response.json()["detail"]


# ── /list-schemas (Databricks branch) ────────────────────────────────


def test_list_schemas_databricks_branch(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)

    with patch(
        "lineage.utils.databricks.list_databricks_schemas",
        return_value=["default", "information_schema"],
    ) as mock_list:
        response = client.post(
            "/desktop/setup/list-schemas",
            json={
                "backend_type": "databricks",
                "databricks_host": "acme.cloud.databricks.com",
                "databricks_http_path": "/sql/1.0/warehouses/abc123",
                "databricks_catalog": "main",
                "databricks_pat_token": "pat-tok",
            },
        )

    assert response.status_code == 200
    assert response.json() == {"schemas": ["default", "information_schema"]}
    mock_list.assert_called_once_with(
        host="acme.cloud.databricks.com",
        http_path="/sql/1.0/warehouses/abc123",
        catalog="main",
        pat_token="pat-tok",
        oauth_token=None,
    )


def test_list_schemas_databricks_missing_catalog_rejected(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)
    response = client.post(
        "/desktop/setup/list-schemas",
        json={
            "backend_type": "databricks",
            "databricks_host": "acme.cloud.databricks.com",
            "databricks_http_path": "/sql/1.0/warehouses/abc123",
            "databricks_pat_token": "pat-tok",
        },
    )
    assert response.status_code == 400
    assert "catalog" in response.json()["detail"].lower()


def test_list_schemas_snowflake_regression(tmp_path, monkeypatch):
    """Existing Snowflake list-schemas path still works after request-model extension."""
    client = _build_client(tmp_path, monkeypatch)

    with patch(
        "lineage.utils.snowflake.list_snowflake_schemas",
        return_value=["PUBLIC", "ANALYTICS"],
    ):
        response = client.post(
            "/desktop/setup/list-schemas",
            json={
                # backend_type defaults to "snowflake" — explicit here for clarity
                "backend_type": "snowflake",
                "account": "acme",
                "user": "user",
                "auth_method": "pat",
                "pat_token": "pat-tok",
                "database": "MY_DB",
            },
        )

    assert response.status_code == 200
    assert response.json() == {"schemas": ["PUBLIC", "ANALYTICS"]}


# ── Snowflake test-connection regression ─────────────────────────────


def test_snowflake_test_connection_still_works_after_databricks_extension(
    tmp_path, monkeypatch
):
    """Adding 'databricks' to the Literal must not break the Snowflake path."""
    client = _build_client(tmp_path, monkeypatch)

    with patch(
        "lineage.utils.snowflake.list_snowflake_databases",
        return_value=["DB1", "DB2"],
    ):
        response = client.post(
            "/desktop/setup/test-connection",
            json={
                "backend_type": "snowflake",
                "account": "acme",
                "user": "user",
                "auth_method": "pat",
                "pat_token": "pat-tok",
            },
        )

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["databases"] == ["DB1", "DB2"]


# ── U4: Config writer (profiles.yml + project config + CreateProjectRequest) ──


def _databricks_create_project_request(**overrides) -> "desktop_setup.CreateProjectRequest":
    """Helper that builds a baseline Databricks CreateProjectRequest."""
    base = dict(
        name="proj",
        git_url="https://example.com/proj.git",
        backend="databricks",
        databricks_host="acme.cloud.databricks.com",
        databricks_http_path="/sql/1.0/warehouses/abc123",
        databricks_warehouse_id="abc123",
        databricks_catalog="main",
        databricks_schema="default",
        databricks_auth_method="pat",
        databricks_pat_token="pat-tok",
        dbt_target="prod",
        profile_name="myproj",
    )
    base.update(overrides)
    return desktop_setup.CreateProjectRequest(**base)


def test_build_profiles_yml_databricks_pat_emits_env_var_template():
    req = _databricks_create_project_request()
    text = desktop_setup._build_profiles_yml(req, "myproj")

    import yaml

    parsed = yaml.safe_load(text)
    output = parsed["myproj"]["outputs"]["prod"]
    assert output["type"] == "databricks"
    assert output["host"] == "acme.cloud.databricks.com"
    assert output["http_path"] == "/sql/1.0/warehouses/abc123"
    assert output["catalog"] == "main"
    assert output["schema"] == "default"
    assert output["token"] == "{{ env_var('DATABRICKS_TOKEN') }}"
    assert output["threads"] == 4


def test_build_profiles_yml_databricks_strips_https_from_host():
    req = _databricks_create_project_request(
        databricks_host="https://acme.cloud.databricks.com/?o=12345"
    )
    text = desktop_setup._build_profiles_yml(req, "myproj")
    import yaml
    output = yaml.safe_load(text)["myproj"]["outputs"]["prod"]
    assert output["host"] == "acme.cloud.databricks.com"


def test_build_profiles_yml_databricks_oauth_uses_same_env_var():
    """OAuth U2M and PAT both reach dbt via DATABRICKS_TOKEN — keychain
    bridge populates the runtime env var either way."""
    req = _databricks_create_project_request(
        databricks_auth_method="oauth_u2m",
        databricks_pat_token=None,
        databricks_oauth_u2m_token="oauth-tok",
    )
    text = desktop_setup._build_profiles_yml(req, "myproj")
    import yaml
    output = yaml.safe_load(text)["myproj"]["outputs"]["prod"]
    assert output["token"] == "{{ env_var('DATABRICKS_TOKEN') }}"


def test_build_project_config_databricks_round_trips_through_pydantic():
    """The dict produced by _build_project_config['data'] must
    round-trip through DatabricksDataConfig.model_validate cleanly."""
    from core.backends.config import DatabricksDataConfig

    req = _databricks_create_project_request(
        allowed_catalogs=["main", "samples"]
    )
    project = desktop_setup._build_project_config(
        req, "proj", "/tmp/proj", "myproj"
    )
    data = project["data"]

    # Strip the env-var placeholder before validating — DatabricksDataConfig
    # accepts ${ENV_VAR} as an opaque token at the Pydantic boundary,
    # but the validator on http_path runs unconditionally so we keep that.
    config = DatabricksDataConfig(
        host=data["host"],
        http_path=data["http_path"],
        warehouse_id=data["warehouse_id"],
        catalog=data["catalog"],
        schema_name=data["schema_name"],
        auth={"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
        allowed_catalogs=data.get("allowed_catalogs"),
    )
    assert config.backend == "databricks"
    assert config.host == "acme.cloud.databricks.com"
    assert config.http_path == "/sql/1.0/warehouses/abc123"
    assert config.warehouse_id == "abc123"
    assert config.catalog == "main"
    assert config.allowed_catalogs == ["main", "samples"]


def test_build_project_config_databricks_oauth_emits_oauth_auth_method():
    req = _databricks_create_project_request(
        databricks_auth_method="oauth_u2m",
        databricks_pat_token=None,
        databricks_oauth_u2m_token="oauth-tok",
    )
    project = desktop_setup._build_project_config(
        req, "proj", "/tmp/proj", "myproj"
    )
    assert project["data"]["auth"]["auth_method"] == "oauth_u2m"
    assert project["data"]["auth"]["token"] == "${DATABRICKS_TOKEN}"


def test_build_project_config_databricks_omits_empty_allowed_catalogs():
    req = _databricks_create_project_request(allowed_catalogs=None)
    project = desktop_setup._build_project_config(
        req, "proj", "/tmp/proj", "myproj"
    )
    assert "allowed_catalogs" not in project["data"]


def test_build_project_config_databricks_pat_writes_per_project_env():
    """PAT path populates the per-project env so dbt env_var() resolves."""
    req = _databricks_create_project_request()
    project = desktop_setup._build_project_config(
        req, "proj", "/tmp/proj", "myproj"
    )
    assert project["env"]["DATABRICKS_TOKEN"] == "pat-tok"
    assert project["env"]["DATABRICKS_HOST"] == "acme.cloud.databricks.com"
    assert project["env"]["DATABRICKS_HTTP_PATH"] == "/sql/1.0/warehouses/abc123"


def test_build_project_config_databricks_oauth_does_not_write_token_to_env():
    """OAuth U2M tokens live in the per-host keychain blob, not the project env.
    The host + http_path still travel through env so dbt resolves them."""
    req = _databricks_create_project_request(
        databricks_auth_method="oauth_u2m",
        databricks_pat_token=None,
        databricks_oauth_u2m_token="oauth-tok",
    )
    project = desktop_setup._build_project_config(
        req, "proj", "/tmp/proj", "myproj"
    )
    assert "DATABRICKS_TOKEN" not in project.get("env", {})
    assert project["env"]["DATABRICKS_HOST"] == "acme.cloud.databricks.com"


def test_create_project_databricks_pat_mismatch_returns_400(tmp_path, monkeypatch):
    """databricks_pat_token + auth_method=oauth_u2m → 400."""
    client = _build_client(tmp_path, monkeypatch)

    # Need the project dir to exist so create_project doesn't 400 on the
    # earlier check; create a stub.
    import core.paths as _cp
    proj_dir = _cp.projects_dir() / "proj"
    proj_dir.mkdir(parents=True, exist_ok=True)
    (proj_dir / "dbt_project.yml").write_text("profile: myproj\n")

    response = client.post(
        "/desktop/setup/create-project",
        json={
            "name": "proj",
            "git_url": "https://example.com/proj.git",
            "backend": "databricks",
            "databricks_host": "acme.cloud.databricks.com",
            "databricks_http_path": "/sql/1.0/warehouses/abc123",
            "databricks_catalog": "main",
            "databricks_auth_method": "oauth_u2m",
            "databricks_pat_token": "pat-tok",  # mismatch with auth_method
            "profile_name": "myproj",
        },
    )
    assert response.status_code == 400
    assert "databricks_pat_token" in response.json()["detail"]


def test_preflight_request_accepts_databricks_backend():
    """The preflight Literal must accept 'databricks'.

    Regression test for the 422 a real user hit when starting preflight
    against a freshly-created Databricks project (the original Literal
    was ['snowflake', 'duckdb']). Validates the Pydantic schema
    directly — no SSE plumbing needed.
    """
    # Snowflake (existing)
    desktop_setup.PreflightRequest(project_name="p", backend="snowflake")
    # DuckDB (existing)
    desktop_setup.PreflightRequest(project_name="p", backend="duckdb")
    # Databricks (TD-2734)
    req = desktop_setup.PreflightRequest(project_name="p", backend="databricks")
    assert req.backend == "databricks"


def test_preflight_request_rejects_unknown_backend():
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        desktop_setup.PreflightRequest(project_name="p", backend="postgres")


def test_load_databricks_oauth_env_returns_token_for_oauth_project(monkeypatch):
    """Regression for Bug 3: OAuth U2M projects need their token loaded
    from the per-host keychain blob into env at preflight/sync time so
    dbt env_var('DATABRICKS_TOKEN') resolves. PAT projects are no-ops
    here — they get the token via .env or the keychain bridge directly.
    """
    from lineage.utils import databricks_oauth as _oauth

    fake_tokens = _oauth.DatabricksU2MTokens(
        access_token="loaded-from-keychain", expires_at=12345.0
    )

    class _FakeStore:
        def __init__(self, host):
            self._host = host

        def load(self):
            return fake_tokens

    monkeypatch.setattr(_oauth, "DatabricksU2MTokenStore", _FakeStore)

    project = {
        "data": {
            "backend": "databricks",
            "host": "acme.cloud.databricks.com",
            "auth": {"auth_method": "oauth_u2m", "token": "${DATABRICKS_TOKEN}"},
        }
    }
    env = desktop_setup._load_databricks_oauth_env_for_project(project)
    assert env == {"DATABRICKS_TOKEN": "loaded-from-keychain"}


def test_load_databricks_oauth_env_skips_pat_projects():
    """PAT projects don't need this path — the token is already in .env
    or the keychain bridge populated os.environ. Returning anything
    here would shadow the correct token."""
    project = {
        "data": {
            "backend": "databricks",
            "host": "acme.cloud.databricks.com",
            "auth": {"auth_method": "pat", "token": "${DATABRICKS_TOKEN}"},
        }
    }
    assert desktop_setup._load_databricks_oauth_env_for_project(project) == {}


def test_load_databricks_oauth_env_skips_non_databricks_projects():
    project = {
        "data": {"backend": "snowflake", "account": "acme", "user": "alice"},
    }
    assert desktop_setup._load_databricks_oauth_env_for_project(project) == {}


def test_load_databricks_oauth_env_returns_empty_when_token_missing(monkeypatch):
    """If the user is on an OAuth project but the keychain blob is gone
    (manually cleared, machine migrated, etc.), return empty so the
    downstream Databricks connector surfaces the auth error directly
    rather than hiding behind a stale env var."""
    from lineage.utils import databricks_oauth as _oauth

    class _EmptyStore:
        def __init__(self, host):
            pass

        def load(self):
            return None

    monkeypatch.setattr(_oauth, "DatabricksU2MTokenStore", _EmptyStore)

    project = {
        "data": {
            "backend": "databricks",
            "host": "acme.cloud.databricks.com",
            "auth": {"auth_method": "oauth_u2m"},
        }
    }
    assert desktop_setup._load_databricks_oauth_env_for_project(project) == {}


def test_create_project_databricks_oauth_token_mismatch_returns_400(
    tmp_path, monkeypatch
):
    """databricks_oauth_u2m_token + auth_method=pat → 400."""
    client = _build_client(tmp_path, monkeypatch)

    import core.paths as _cp
    proj_dir = _cp.projects_dir() / "proj"
    proj_dir.mkdir(parents=True, exist_ok=True)
    (proj_dir / "dbt_project.yml").write_text("profile: myproj\n")

    response = client.post(
        "/desktop/setup/create-project",
        json={
            "name": "proj",
            "git_url": "https://example.com/proj.git",
            "backend": "databricks",
            "databricks_host": "acme.cloud.databricks.com",
            "databricks_http_path": "/sql/1.0/warehouses/abc123",
            "databricks_catalog": "main",
            "databricks_auth_method": "pat",
            "databricks_oauth_u2m_token": "oauth-tok",  # mismatch
            "profile_name": "myproj",
        },
    )
    assert response.status_code == 400
    assert "databricks_oauth_u2m_token" in response.json()["detail"]


# ── Cluster round-3: centralized host normalization + SSRF allowlist ─


def test_validate_databricks_host_strips_fragment():
    """`_normalize_databricks_host` is the canonical normalizer; it strips
    URL fragments along with scheme/path/query so a paste like
    `https://...databricks.com/#/sql/...` yields the bare hostname.
    Regression for the round-3 cluster signal that pointed out inline
    normalizers were missing the `#` strip."""
    assert (
        desktop_setup._normalize_databricks_host(
            "https://acme.cloud.databricks.com/#/sql/warehouses/abc"
        )
        == "acme.cloud.databricks.com"
    )
    # Validator (which routes through the normalizer) returns the same
    # canonical form for a host that passes the SSRF allowlist.
    assert (
        desktop_setup._validate_databricks_host(
            "https://acme.cloud.databricks.com/#/sql/warehouses/abc"
        )
        == "acme.cloud.databricks.com"
    )


def test_build_profiles_yml_databricks_strips_fragment_from_host():
    """The dbt profiles.yml builder uses `_normalize_databricks_host`,
    so a fragment-bearing paste no longer leaks into output['host'].
    Closes round-3 cluster thread on _build_profiles_yml."""
    req = _databricks_create_project_request(
        databricks_host="https://acme.cloud.databricks.com/#/sql/warehouses/abc"
    )
    text = desktop_setup._build_profiles_yml(req, "myproj")
    import yaml
    output = yaml.safe_load(text)["myproj"]["outputs"]["prod"]
    assert output["host"] == "acme.cloud.databricks.com"


def test_build_project_config_databricks_strips_fragment_from_host():
    """The config.yaml builder uses `_normalize_databricks_host`,
    so a fragment-bearing paste no longer leaks into data['host'] —
    keeps token-store lookups and connector usage consistent.
    Closes round-3 cluster thread on _build_project_config."""
    req = _databricks_create_project_request(
        databricks_host="https://acme.cloud.databricks.com/#/sql/warehouses/abc"
    )
    project = desktop_setup._build_project_config(
        req, "proj", "/tmp/proj", "myproj"
    )
    assert project["data"]["host"] == "acme.cloud.databricks.com"
    # Per-project env entry also goes through the normalizer
    assert project["env"]["DATABRICKS_HOST"] == "acme.cloud.databricks.com"


def test_create_project_rejects_unallowlisted_databricks_host(tmp_path, monkeypatch):
    """create-project routes `databricks_host` through `_validate_databricks_host`
    so an unallowlisted host (SSRF risk) is rejected at the request boundary
    rather than being persisted to .env / profiles.yml / config.yaml."""
    client = _build_client(tmp_path, monkeypatch)

    import core.paths as _cp
    proj_dir = _cp.projects_dir() / "proj"
    proj_dir.mkdir(parents=True, exist_ok=True)
    (proj_dir / "dbt_project.yml").write_text("profile: myproj\n")

    response = client.post(
        "/desktop/setup/create-project",
        json={
            "name": "proj",
            "git_url": "https://example.com/proj.git",
            "backend": "databricks",
            "databricks_host": "evil.example.com",
            "databricks_http_path": "/sql/1.0/warehouses/abc123",
            "databricks_catalog": "main",
            "databricks_auth_method": "pat",
            "databricks_pat_token": "pat-tok",
            "profile_name": "myproj",
        },
    )

    assert response.status_code == 400
    assert "Unrecognized" in response.json()["detail"]
    # Defense in depth: nothing should have been persisted on rejection.
    ep = _cp.env_path()
    if ep.exists():
        assert "DATABRICKS_HOST" not in ep.read_text()


def test_create_project_normalizes_databricks_host_on_persistence(tmp_path, monkeypatch):
    """create-project persists the canonical (scheme/path/query/fragment-stripped)
    form to .env so preflight/sync see the same hostname the wizard uses."""
    client = _build_client(tmp_path, monkeypatch)

    import core.paths as _cp
    proj_dir = _cp.projects_dir() / "proj"
    proj_dir.mkdir(parents=True, exist_ok=True)
    (proj_dir / "dbt_project.yml").write_text("profile: myproj\n")

    response = client.post(
        "/desktop/setup/create-project",
        json={
            "name": "proj",
            "git_url": "https://example.com/proj.git",
            "backend": "databricks",
            "databricks_host": "https://acme.cloud.databricks.com/#/sql/warehouses/abc",
            "databricks_http_path": "/sql/1.0/warehouses/abc123",
            "databricks_catalog": "main",
            "databricks_auth_method": "pat",
            "databricks_pat_token": "pat-tok",
            "profile_name": "myproj",
        },
    )

    assert response.status_code == 200
    env_text = _cp.env_path().read_text()
    # Bare hostname — no scheme, path, query, or fragment
    assert "DATABRICKS_HOST=acme.cloud.databricks.com" in env_text
    # config.yaml host normalized identically
    import yaml
    cfg = yaml.safe_load(_cp.config_path().read_text())
    assert (
        cfg["projects"]["proj"]["data"]["host"] == "acme.cloud.databricks.com"
    )
