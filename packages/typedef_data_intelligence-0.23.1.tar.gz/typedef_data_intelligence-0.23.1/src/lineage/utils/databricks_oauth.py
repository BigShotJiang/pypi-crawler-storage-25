"""Databricks OAuth U2M browser flow helpers (TD-2734 U3).

Wraps ``databricks.sdk.oauth.OAuthClient`` so the desktop Setup Wizard can
drive a PKCE flow through its own loopback callback server (matching the
Linear flow's SSE shape) instead of the SDK's higher-level
``auth_type='external-browser'`` path.

Two public entry points:

- :func:`initiate_u2m_consent` — builds the OAuth client (HTTP discovery
  call wrapped in ``asyncio.to_thread`` by the caller), starts a
  ``Consent``, and serializes it to a JSON-safe dict for cross-request
  persistence.
- :func:`complete_u2m_consent` — rehydrates the ``Consent`` from its dict
  shape and exchanges the callback parameters for a session credentials
  bundle.

Persistence helpers (``DatabricksU2MTokens``, ``DatabricksU2MTokenStore``)
mirror the Linear token-store shape but key per-host so multi-workspace
setups don't collide.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

from core.backends.keychain_http import KeychainBlobStore, KeychainHTTPClient
from core.backends.utils import atomic_write_secret
from core.paths import typedef_home as _typedef_home

logger = logging.getLogger(__name__)


# Built-in public OAuth client ID the SDK itself uses for its browser flow.
# Hoisted as a named constant per codex peer review so a future
# "BYO Databricks OAuth app" feature has an obvious swap point.
DATABRICKS_OAUTH_PUBLIC_CLIENT_ID = "databricks-cli"


# ── Consent serialization ──────────────────────────────────────────


def initiate_u2m_consent(
    *, host: str, redirect_url: str, client_id: Optional[str] = None
) -> tuple[dict[str, Any], str]:
    """Start a U2M PKCE consent flow.

    Construction performs a synchronous HTTP GET to
    ``{host}/oidc/.well-known/oauth-authorization-server`` to discover
    the workspace's OIDC endpoints. **Callers running in async contexts
    must wrap this function in ``asyncio.to_thread`` to avoid blocking
    the event loop** — the FastAPI handlers in ``desktop_setup.py`` do
    exactly this.

    Returns:
        tuple: ``(consent_dict, authorize_url)``. The dict round-trips
        through :func:`Consent.from_dict` so the SSE generator can
        rehydrate it without holding the SDK object across requests.

    Raises:
        ImportError: if ``databricks-sdk`` is not installed.
    """
    from databricks.sdk.oauth import OAuthClient

    full_host = host if host.startswith(("http://", "https://")) else f"https://{host}"

    oauth_client = OAuthClient.from_host(
        host=full_host,
        client_id=client_id or DATABRICKS_OAUTH_PUBLIC_CLIENT_ID,
        redirect_url=redirect_url,
    )
    consent = oauth_client.initiate_consent()
    # `Consent.authorization_url` (NOT `auth_url`) — verified against
    # databricks-sdk 0.47.0 source.
    return consent.as_dict(), consent.authorization_url


def complete_u2m_consent(
    consent_dict: dict[str, Any], code: str, state: str
) -> "DatabricksU2MTokens":
    """Exchange callback parameters for a session-credentials bundle.

    Takes the dict produced by :func:`initiate_u2m_consent` (or
    persisted via ``Consent.as_dict()``) and a freshly captured
    ``code`` + ``state`` from the loopback callback.

    The exchange itself is a blocking HTTPS POST; callers in async
    contexts must wrap it in ``asyncio.to_thread``.

    Returns:
        :class:`DatabricksU2MTokens` carrying the access token, optional
        refresh token, and unix-timestamp expiry.

    Raises:
        ImportError: if ``databricks-sdk`` is not installed.
    """
    from databricks.sdk.oauth import Consent

    consent = Consent.from_dict(consent_dict)  # client_secret intentionally None
    creds = consent.exchange_callback_parameters({"code": code, "state": state})
    # SessionCredentials surfaces a Token object via .token — both Token and
    # the SessionCredentials shape have stayed stable across 0.x SDK releases.
    token = creds.token()
    return DatabricksU2MTokens(
        access_token=token.access_token,
        refresh_token=getattr(token, "refresh_token", None),
        # token.expiry is a datetime; coerce to unix timestamp for parity
        # with LinearStoredTokens.expires_at.
        expires_at=token.expiry.timestamp() if token.expiry else 0.0,
    )


# ── Token persistence ──────────────────────────────────────────────


@dataclass
class DatabricksU2MTokens:
    """Databricks U2M tokens persisted between sessions."""

    access_token: str = field(repr=False)
    refresh_token: Optional[str] = field(default=None, repr=False)
    expires_at: float = 0.0  # unix timestamp


def _normalize_host_for_key(host: str) -> str:
    """Normalize a workspace host for use as a keychain blob key suffix.

    Mirrors :func:`utils.databricks._normalize_host` but tolerant of
    inputs that have already been normalized. The result must be a
    valid blob-key fragment — keychain bridges treat ``:`` as a
    namespace separator, so we replace it.
    """
    cleaned = host.strip().lower()
    for prefix in ("https://", "http://"):
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):]
            break
    for sep in ("/", "?", "#"):
        idx = cleaned.find(sep)
        if idx != -1:
            cleaned = cleaned[:idx]
    return cleaned.replace(":", "_").strip()


def _bridge_key(host: str) -> str:
    """Per-host bridge key so multi-workspace setups don't collide."""
    return f"databricks_oauth_u2m:{_normalize_host_for_key(host)}"


class DatabricksU2MTokenStore:
    """Per-host secure storage for Databricks U2M OAuth tokens.

    Selects between the desktop keychain bridge and a local file store
    at construction; selection is sticky for the lifetime of the
    instance. Mirrors :class:`core.backends.tickets.linear_token_store.LinearTokenStore`.

    The per-host scoping means a user with both AWS and Azure
    workspaces stored at the same time keeps both tokens addressable
    without one overwriting the other.
    """

    def __init__(
        self,
        host: str,
        store_path: Optional[Path] = None,
        *,
        keychain_client: Optional[KeychainHTTPClient] = None,
    ) -> None:
        """Build a per-host token store.

        Args:
            host: Workspace hostname; will be normalized for the bridge key
                and the file path.
            store_path: Optional override for the file backend's directory.
                Defaults to ``$TYPEDEF_HOME``.
            keychain_client: Optional keychain HTTP client (test injection).
        """
        self._host = _normalize_host_for_key(host)
        if not self._host:
            raise ValueError(f"Cannot derive token-store key from host {host!r}")
        self._store_dir = store_path or _typedef_home()
        self._store_path = (
            self._store_dir / f"databricks_oauth_u2m_{self._host}.json"
        )
        bridge = KeychainBlobStore(_bridge_key(host), client=keychain_client)
        self._backend: Any = (
            bridge if bridge.is_available() else _FileBackend(self._store_path)
        )

    def save(self, tokens: DatabricksU2MTokens) -> None:
        """Persist tokens via the configured backend."""
        self._backend.save(json.dumps(asdict(tokens)))

    def load(self) -> Optional[DatabricksU2MTokens]:
        """Load persisted tokens, or ``None`` if not found."""
        raw = self._backend.load()
        if raw is None:
            return None
        try:
            return DatabricksU2MTokens(**json.loads(raw))
        except (json.JSONDecodeError, TypeError):
            logger.warning(
                "Corrupt Databricks U2M token data for host %s — clearing store",
                self._host,
            )
            self.clear()
            return None

    def clear(self) -> None:
        """Remove persisted tokens."""
        self._backend.clear()


class _FileBackend:
    """Persist tokens to ``$TYPEDEF_HOME/databricks_oauth_u2m_<host>.json``.

    Atomic writes via :func:`atomic_write_secret`. Mirrors Linear's
    file backend exactly.
    """

    def __init__(self, store_path: Path) -> None:
        self._store_path = store_path

    def save(self, data: str) -> None:
        atomic_write_secret(self._store_path, data)

    def load(self) -> Optional[str]:
        if not self._store_path.exists():
            return None
        try:
            return self._store_path.read_text(encoding="utf-8")
        except OSError:
            return None

    def clear(self) -> None:
        if self._store_path.exists():
            try:
                self._store_path.unlink()
            except OSError as exc:
                logger.debug(
                    "Failed to remove Databricks U2M token file: %s", exc
                )


__all__ = [
    "DATABRICKS_OAUTH_PUBLIC_CLIENT_ID",
    "DatabricksU2MTokens",
    "DatabricksU2MTokenStore",
    "complete_u2m_consent",
    "initiate_u2m_consent",
]
