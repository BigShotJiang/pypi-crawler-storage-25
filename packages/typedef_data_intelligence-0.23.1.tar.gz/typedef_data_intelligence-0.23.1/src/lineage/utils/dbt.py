"""dbt utility functions for project management."""

import json
import logging
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from core.utils.dbt import build_dbt_subprocess_env, dbt_venv_bin, resolve_dbt_cmd

logger = logging.getLogger(__name__)

# Regex to strip ANSI escape sequences from dbt output.
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")

_DEPRECATION_PATTERNS = (
    "Deprecation",
    "DeprecationWarning",
    "MissingPlusPrefixDeprecation",
    "PropertyMovedToConfigDeprecation",
    "PackageMaterializationOverrideDeprecation",
    "PackageInstallPathDeprecation",
    "PackageRedirectDeprecation",
    "SourceFreshnessProjectHooksNotRun",
)

_ERROR_INDICATORS = (
    "Compilation Error",
    "Runtime Error",
    "Database Error",
    "Parsing Error",
    "does not exist",
    "Encountered an error",
    "FAILED",
)


def run_dbt_command(
    command: list[str],
    project_dir: Path,
    profiles_dir: Optional[Path] = None,
    venv_dir: Optional[Path] = None,
    extra_env: Optional[dict[str, str]] = None,
) -> tuple[str, str]:
    """Run a dbt command in the specified project directory.

    Args:
        command: dbt command arguments (e.g., ["deps"], ["docs", "generate"])
        project_dir: dbt project directory
        profiles_dir: Optional profiles directory override
        venv_dir: Optional venv directory containing dbt installation
        extra_env: Optional additional environment variables to set

    Returns:
        Tuple of (stdout, stderr)

    Raises:
        subprocess.CalledProcessError: If command fails
    """
    # Resolve to absolute up front. The subprocess runs with cwd=project_dir
    # and dbt resolves DBT_TARGET_PATH / DBT_LOG_PATH relative to its working
    # directory, so a relative project_dir would produce a nested path
    # (`<cwd>/<project_dir>/target`) when dbt joins them. Same risk for any
    # user `env_var('DBT_PROJECT_DIR')` Jinja that builds further paths.
    project_dir = project_dir.resolve()

    # Build env vars. DBT_PROJECT_DIR is exported so dbt's `env_var()` Jinja
    # helper can resolve `{{ env_var('DBT_PROJECT_DIR') }}` references in
    # dbt_project.yml (dbt-core does not expose its own --project-dir as an env
    # var to Jinja). Caller-supplied extra_env wins on DBT_PROJECT_DIR so
    # users with a non-standard convention (e.g. monorepo bind-mount) can point
    # it elsewhere through the wizard's per-project env-vars field.
    env: dict[str, str] = {"DBT_PROJECT_DIR": str(project_dir)}
    if profiles_dir:
        env["DBT_PROFILES_DIR"] = str(profiles_dir)
    if extra_env:
        env.update(extra_env)

    # DBT_TARGET_PATH / DBT_LOG_PATH are pinned AFTER the extra_env merge —
    # not overridable. typedef's downstream code (manifest validation, log
    # hints, lineage loaders) reads from `<project_dir>/target/...` and
    # `<project_dir>/logs/...` at hardcoded locations; allowing override here
    # would silently desync those readers. Two failure modes that motivate
    # forcing these:
    #   1. User projects with `target-path: "{{ env_var('DBT_PROJECT_DIR') }}/.../target"`
    #      (a common monorepo / container-bind-mount convention) render to a
    #      different path than typedef expects when DBT_PROJECT_DIR points at
    #      the dbt project root rather than the parent.
    #   2. dbt initializes its logger before the full Jinja context exists,
    #      which causes `log-path: "{{ env_var(...) }}/..."` to land in a
    #      directory whose literal name is the un-rendered template string
    #      (https://docs.getdbt.com/reference/project-configs/log-path).
    #      DBT_LOG_PATH is the supported dynamic-config mechanism.
    # If a future use case genuinely needs custom artifact/log paths, plumb
    # the effective values into run_dbt_docs_generate / lineage loaders too,
    # then relax this pin.
    env["DBT_TARGET_PATH"] = str(project_dir / "target")
    env["DBT_LOG_PATH"] = str(project_dir / "logs")

    # Build base command — prefer explicit venv_dir if provided,
    # otherwise use the standard resolution chain (driven by the project's
    # profiles.yml, not ambient env vars).
    if venv_dir:
        venv_dbt = dbt_venv_bin(venv_dir)
        cmd = (
            [str(venv_dbt), *command]
            if venv_dbt
            else resolve_dbt_cmd(
                command, project_dir=project_dir, profiles_dir=profiles_dir
            )
        )
    else:
        cmd = resolve_dbt_cmd(
            command, project_dir=project_dir, profiles_dir=profiles_dir
        )

    logger.info(f"Running dbt command: {' '.join(cmd)} in {project_dir}")

    # If we have env vars, merge with system env
    run_env = build_dbt_subprocess_env(env or None)

    result = subprocess.run(
        cmd, cwd=project_dir, check=True, capture_output=True, text=True, env=run_env
    )

    return result.stdout, result.stderr


# ── dbt docs generate with error surfacing ───────────────────────────


def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences from text."""
    return _ANSI_RE.sub("", text)


def extract_dbt_errors(output: str) -> str:
    """Filter dbt output to surface actionable errors, stripping deprecation noise.

    This is a **presentation-only** helper — it should never drive control flow.
    Control flow uses exit codes and artifact validation instead.
    """
    cleaned = strip_ansi(output)
    lines = cleaned.splitlines()

    # First pass: collect lines that look like real errors.
    error_lines: list[str] = []
    in_error_block = False
    for line in lines:
        stripped = line.strip()
        if not stripped:
            in_error_block = False
            continue

        # Skip deprecation noise.
        if any(pat in stripped for pat in _DEPRECATION_PATTERNS):
            in_error_block = False
            continue

        # Start or continue an error block.
        if any(indicator in stripped for indicator in _ERROR_INDICATORS):
            in_error_block = True
            error_lines.append(stripped)
        elif in_error_block:
            # Continuation line (indented context after an error header).
            error_lines.append(stripped)

    if error_lines:
        return "\n".join(error_lines)

    # Fallback: if everything was filtered, return last non-blank lines.
    tail = [line.strip() for line in lines if line.strip()][-10:]
    return "\n".join(tail) if tail else cleaned[:500]


def _validate_manifest(path: Path) -> bool:
    """Check that a manifest.json file exists and is structurally valid."""
    if not path.exists():
        return False
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return isinstance(data, dict) and isinstance(data.get("nodes"), dict)
    except (json.JSONDecodeError, OSError):
        return False


@dataclass
class DbtDocsResult:
    """Result of running ``dbt docs generate``."""

    success: bool
    manifest_valid: bool
    catalog_exists: bool
    error_summary: (
        str | None
    )  # Filtered errors for display (deprecation noise stripped)
    raw_error: str | None  # Full unfiltered error output for logging
    log_hint: str | None  # Path to dbt.log for detailed debugging


def run_dbt_docs_generate(
    project_dir: Path,
    profiles_dir: Path | None = None,
    venv_dir: Path | None = None,
    extra_env: dict[str, str] | None = None,
    target_args: list[str] | None = None,
) -> DbtDocsResult:
    """Run ``dbt docs generate`` and return a structured result.

    On failure, filters dbt output to surface real errors (stripping ~250
    deprecation warnings that typically bury the actual compilation error).
    Points the user to ``dbt.log`` for full details.

    If the command exits non-zero but a valid manifest exists on disk (common
    with DuckDB's ``Pool.__del__`` traceback), treats it as success.

    Args:
        project_dir: Root directory of the dbt project.
        profiles_dir: Optional profiles directory override.
        venv_dir: Optional venv directory containing dbt installation.
        extra_env: Optional additional environment variables for dbt.
        target_args: Extra CLI args (e.g. ``["--target", "duckdb"]``).
    """
    if target_args is None:
        target_args = []

    manifest_path = project_dir / "target" / "manifest.json"
    catalog_path = project_dir / "target" / "catalog.json"
    dbt_log = project_dir / "logs" / "dbt.log"
    log_hint = str(dbt_log) if dbt_log.exists() else str(dbt_log.parent)

    try:
        run_dbt_command(
            ["docs", "generate", *target_args],
            project_dir,
            profiles_dir=profiles_dir,
            venv_dir=venv_dir,
            extra_env=extra_env,
        )
        if dbt_log.exists():
            log_hint = str(dbt_log)
        manifest_valid = _validate_manifest(manifest_path)
        return DbtDocsResult(
            success=manifest_valid,
            manifest_valid=manifest_valid,
            catalog_exists=catalog_path.exists(),
            error_summary=(
                f"dbt docs generate completed but manifest.json is missing or invalid at {manifest_path}"
                if not manifest_valid
                else None
            ),
            raw_error=None,
            log_hint=log_hint,
        )
    except subprocess.CalledProcessError as exc:
        raw_error = exc.stderr or exc.stdout or str(exc)
        logger.error(
            "dbt docs generate failed (exit %s):\n%s", exc.returncode, raw_error
        )
        if exc.stdout and exc.stdout != raw_error:
            logger.error("dbt stdout:\n%s", exc.stdout)

        if dbt_log.exists():
            log_hint = str(dbt_log)

        error_summary = extract_dbt_errors(raw_error)

        # DuckDB Pool.__del__ traceback causes non-zero exit but docs succeeded.
        if _validate_manifest(manifest_path):
            logger.info(
                "dbt docs generate returned non-zero but a valid manifest exists — continuing"
            )
            return DbtDocsResult(
                success=True,
                manifest_valid=True,
                catalog_exists=catalog_path.exists(),
                error_summary=error_summary,
                raw_error=raw_error,
                log_hint=log_hint,
            )

        return DbtDocsResult(
            success=False,
            manifest_valid=False,
            catalog_exists=catalog_path.exists(),
            error_summary=error_summary,
            raw_error=raw_error,
            log_hint=log_hint,
        )
