"""Snowflake utility functions for connection validation and metadata.

Supports two authentication methods:

- ``private_key`` — path to an RSA private key file (.p8). Default.
- ``pat`` — Snowflake Programmatic Access Token passed via the
  ``PROGRAMMATIC_ACCESS_TOKEN`` authenticator.
"""
import logging
from pathlib import Path
from typing import Literal, Optional

import snowflake.connector
from snowflake.connector.errors import Error

logger = logging.getLogger(__name__)

AuthMethod = Literal["private_key", "pat"]


def _quote_identifier(name: str) -> str:
    """Quote a Snowflake identifier (double-quote + escape embedded quotes).

    Mirrors ``SnowflakeNativeBackend._quote_snowflake_identifier``; we keep
    a small local copy rather than importing the backend class so this
    utility module stays lightweight.
    """
    if "\x00" in name:
        raise ValueError("Invalid Snowflake identifier: contains NUL byte")
    return '"' + str(name).replace('"', '""') + '"'


def _load_private_key_der(private_key_path: str) -> bytes:
    """Load an RSA private key file and return it in DER format.

    Expands ``~`` in the path so callers can pass user-relative paths
    (e.g. ``~/.ssh/snowflake_rsa_key.p8``) directly. Without this,
    ``open()`` would attempt to open a literal ``~`` directory and fail
    even when the file exists on disk.
    """
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization

    expanded = Path(private_key_path).expanduser()
    with open(expanded, "rb") as key:
        p_key = serialization.load_pem_private_key(
            key.read(),
            password=None,
            backend=default_backend(),
        )
    return p_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def _connect(
    *,
    account: str,
    user: str,
    role: Optional[str],
    warehouse: Optional[str],
    auth_method: AuthMethod,
    private_key_path: Optional[str],
    pat_token: Optional[str],
    database: Optional[str] = None,
    schema: Optional[str] = None,
) -> "snowflake.connector.SnowflakeConnection":
    """Connect to Snowflake using the selected auth method."""
    if auth_method == "pat":
        if not pat_token:
            raise ValueError("pat_token is required when auth_method='pat'")
        # The connector reads the PAT from `token=` when authenticator is
        # PROGRAMMATIC_ACCESS_TOKEN; `password=` is silently ignored on that
        # path and Snowflake responds with 250001 "token is invalid".
        auth_kwargs = {
            "authenticator": "PROGRAMMATIC_ACCESS_TOKEN",
            "token": pat_token,
        }
    else:
        if not private_key_path:
            raise ValueError(
                "private_key_path is required when auth_method='private_key'"
            )
        auth_kwargs = {"private_key": _load_private_key_der(private_key_path)}

    params: dict = {
        "account": account,
        "user": user,
        "role": role,
        "warehouse": warehouse,
        **auth_kwargs,
    }
    if database:
        params["database"] = database
    if schema:
        params["schema"] = schema

    return snowflake.connector.connect(**{k: v for k, v in params.items() if v is not None})


def _try_enable_secondary_roles(cursor: "snowflake.connector.cursor.SnowflakeCursor") -> bool:
    """Try to enable secondary roles on the session.

    Returns True if secondary roles were enabled, False if the statement
    failed with a Snowflake connector error (feature disabled, permission
    error, transient session issue, etc.).  Unexpected non-connector
    exceptions (e.g. programming errors) are not caught and will propagate.

    The actual connector exception is logged at DEBUG so callers can
    diagnose failures without misinterpreting False as strictly "not
    supported on this account".

    See TD-2970 for the follow-up to inject an ``on-run-start`` hook
    into dbt_project.yml when secondary roles are available.
    """
    try:
        cursor.execute("USE SECONDARY ROLES ALL")
        return True
    except Error as exc:
        # Log the actual error so transient/permission issues aren't silently
        # attributed to "secondary roles not available".
        logger.debug(
            "USE SECONDARY ROLES ALL failed (%s: %s) — continuing without",
            type(exc).__name__,
            exc,
        )
        return False


def list_snowflake_databases(
    account: str,
    user: str,
    role: Optional[str],
    warehouse: Optional[str],
    private_key_path: Optional[str] = None,
    *,
    auth_method: AuthMethod = "private_key",
    pat_token: Optional[str] = None,
) -> list[str]:
    """Connect to Snowflake and return list of accessible database names."""
    conn = _connect(
        account=account,
        user=user,
        role=role,
        warehouse=warehouse,
        auth_method=auth_method,
        private_key_path=private_key_path,
        pat_token=pat_token,
    )
    try:
        cursor = conn.cursor()

        # Enable secondary roles so SHOW DATABASES returns all databases
        # accessible via any role granted to the user, matching Snowsight
        # behavior.
        _try_enable_secondary_roles(cursor)

        cursor.execute("SHOW DATABASES")
        databases = [row[1] for row in cursor.fetchall()]
        return sorted(databases)
    finally:
        conn.close()


def list_snowflake_schemas(
    account: str,
    user: str,
    role: Optional[str],
    warehouse: Optional[str],
    database: str,
    private_key_path: Optional[str] = None,
    *,
    auth_method: AuthMethod = "private_key",
    pat_token: Optional[str] = None,
) -> list[str]:
    """Connect to Snowflake and return list of schemas in a database.

    Connects *without* a default database so the initial session setup
    cannot fail when the target database is only reachable via a secondary
    role.  Secondary roles are enabled first, then the schema query runs.
    """
    conn = _connect(
        account=account,
        user=user,
        role=role,
        warehouse=warehouse,
        auth_method=auth_method,
        private_key_path=private_key_path,
        pat_token=pat_token,
    )
    try:
        cursor = conn.cursor()
        _try_enable_secondary_roles(cursor)
        cursor.execute(f"SHOW SCHEMAS IN DATABASE {_quote_identifier(database)}")
        schemas = [row[1] for row in cursor.fetchall()]
        return sorted(schemas)
    finally:
        conn.close()


def validate_snowflake_read_access(
    account: str,
    user: str,
    role: Optional[str],
    warehouse: Optional[str],
    database: str,
    private_key_path: Optional[str] = None,
    schema: str = "PUBLIC",
    *,
    auth_method: AuthMethod = "private_key",
    pat_token: Optional[str] = None,
) -> tuple[bool, str, Optional[str]]:
    """Validate read access by listing tables and reading from one.

    Returns:
        tuple: (success, message, sample_table_name)
    """
    try:
        conn = _connect(
            account=account,
            user=user,
            role=role,
            warehouse=warehouse,
            auth_method=auth_method,
            private_key_path=private_key_path,
            pat_token=pat_token,
            database=database,
            schema=schema,
        )

        try:
            cursor = conn.cursor()

            qualified_schema = (
                f"{_quote_identifier(database)}.{_quote_identifier(schema)}"
            )
            cursor.execute(f"SHOW TABLES IN SCHEMA {qualified_schema}")
            tables = cursor.fetchall()

            if not tables:
                return True, f"Connected to {database}.{schema} (no tables found)", None

            first_table = tables[0][1]

            # 3. Try to read from it. All three identifiers pass through
            # _quote_identifier before composition, so the f-string below
            # cannot be used for SQL injection — bandit can't prove that
            # statically, hence the nosec with an explicit reason.
            qualified_table = (
                f"{_quote_identifier(database)}.{_quote_identifier(schema)}"
                f".{_quote_identifier(first_table)}"
            )
            cursor.execute(f"SELECT * FROM {qualified_table} LIMIT 1")  # nosec B608 - identifiers quoted via _quote_identifier
            cursor.fetchall()

            return True, f"Successfully read from {database}.{schema}.{first_table}", first_table

        except Error as e:
            return False, f"Snowflake error: {str(e)}", None
        except Exception as e:
            return False, f"Unexpected error: {str(e)}", None
        finally:
            conn.close()

    except Exception as e:
        return False, f"Connection failed: {str(e)}", None
