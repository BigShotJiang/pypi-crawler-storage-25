"""Databricks utility functions for connection validation and metadata.

One-shot helpers for the desktop Setup Wizard's Databricks panel. These
take raw connection parameters (host, http_path, PAT or OAuth token) and
return shaped metadata so the wizard can populate dropdowns before a full
``DatabricksDataConfig`` exists.

Mirrors ``utils/snowflake.py``: lightweight, no backend imports, no Pydantic
config dependency. The Phase A ``DatabricksDataQueryBackend`` (TD-2730) is
used elsewhere for the rich ``test_connection`` probe; this module covers
the simpler discovery paths.

Two auth methods supported (matching the Phase A backend):

- ``pat`` — Databricks Personal Access Token (string).
- ``oauth_u2m`` — User-to-machine OAuth access token (string), captured by
  the wizard's browser flow.

Exactly one of ``pat_token`` or ``oauth_token`` must be provided to every
call.
"""

from __future__ import annotations

from typing import Any, Literal, Optional

from core.backends.databricks_helpers import (
    _CLUSTER_PATH_MARKERS,
)
from core.backends.databricks_helpers import (
    looks_like_cluster_path as _looks_like_cluster_path,
)
from core.backends.databricks_helpers import (
    normalize_host as _normalize_host,
)
from core.backends.databricks_helpers import (
    quote_identifier as _quote_identifier,
)

AuthMode = Literal["pat", "oauth_u2m"]

# Databricks SDK constructs WorkspaceClient with keyword-only arguments;
# pinning the call shape in tests catches positional-arg regressions.
# Phase A backend reserves ``"databricks-cli"`` as the public OAuth client
# ID; if a future "BYO Databricks OAuth app" feature ships, that swap point
# lives in ``utils/databricks_oauth.py``, not here.

# ``_quote_identifier``, ``_looks_like_cluster_path``, ``_normalize_host``,
# and ``_CLUSTER_PATH_MARKERS`` are re-exported above from
# ``core.backends.databricks_helpers`` so the canonical implementation can
# also be reused by ``libs/python/ingest`` without a forbidden
# ``services/ → libs/`` import. The private names here are kept stable for
# the existing wizard test surface.

__all__ = [
    "AuthMode",
    "_CLUSTER_PATH_MARKERS",
    "_quote_identifier",
    "_looks_like_cluster_path",
    "_normalize_host",
    "_resolve_auth",
    "_connect_databricks",
    "list_databricks_warehouses",
    "list_databricks_catalogs",
    "list_databricks_schemas",
]


def _resolve_auth(
    pat_token: Optional[str], oauth_token: Optional[str]
) -> tuple[AuthMode, str]:
    """Validate that exactly one auth token is supplied.

    Returns:
        tuple: (auth_mode, token)

    Raises:
        ValueError: if both or neither token is supplied.
    """
    if pat_token and oauth_token:
        raise ValueError(
            "Pass exactly one of pat_token or oauth_token, not both."
        )
    if pat_token:
        return "pat", pat_token
    if oauth_token:
        return "oauth_u2m", oauth_token
    raise ValueError(
        "One of pat_token or oauth_token is required."
    )


def _connect_databricks(
    *,
    host: str,
    http_path: str,
    pat_token: Optional[str] = None,
    oauth_token: Optional[str] = None,
) -> Any:
    """Open a Databricks SQL connection using PAT or OAuth U2M.

    The SDK's ``access_token`` parameter accepts either flavour of
    bearer token interchangeably; the wizard distinguishes them only
    for storage routing (``DATABRICKS_TOKEN`` env vs. keychain blob).

    Raises:
        ValueError: if the http_path looks like a cluster path or if the
            auth tokens are not exactly-one.
    """
    if _looks_like_cluster_path(http_path):
        raise ValueError(
            "Databricks backend supports SQL Warehouses only. "
            "All-purpose cluster http_paths (containing '/clusters/' or "
            "'/protocolv1/') are not supported. Use a SQL Warehouse "
            "http_path of the form '/sql/1.0/warehouses/<warehouse_id>'."
        )

    _, token = _resolve_auth(pat_token, oauth_token)
    normalized = _normalize_host(host)

    import databricks.sql as databricks_sql

    return databricks_sql.connect(
        server_hostname=normalized,
        http_path=http_path,
        access_token=token,
    )


def list_databricks_warehouses(
    *,
    host: str,
    pat_token: Optional[str] = None,
    oauth_token: Optional[str] = None,
) -> list[dict[str, str]]:
    """List SQL Warehouses visible to the calling identity.

    Uses ``databricks-sdk`` ``WorkspaceClient`` (workspace-level API),
    not the SQL connector — warehouse listing is not a SQL query.

    Returns:
        list of dicts shaped ``{"id": str, "name": str, "state": str}``.
        The ``state`` field surfaces ``RUNNING`` / ``STARTING`` /
        ``STOPPED`` / ``DELETED`` so the wizard can show users a
        stopped warehouse rather than hiding it (the connector will
        wake it on first query).

    Raises:
        ValueError: on auth misconfiguration (see ``_resolve_auth``).
    """
    _, token = _resolve_auth(pat_token, oauth_token)
    normalized = _normalize_host(host)

    from databricks.sdk import WorkspaceClient

    # Keyword-only constructor; positional `host` raises TypeError.
    client = WorkspaceClient(host=f"https://{normalized}", token=token)

    warehouses = client.warehouses.list()
    out: list[dict[str, str]] = []
    for wh in warehouses:
        wh_id = getattr(wh, "id", None)
        wh_name = getattr(wh, "name", None)
        wh_state = getattr(wh, "state", None)
        if not wh_id or not wh_name:
            continue
        # state may be a plain string or an enum-like object. Prefer the
        # API value (e.g. "RUNNING") over the enum's repr (e.g.
        # "State.RUNNING") so the wizard surfaces a user-facing label.
        if wh_state is None:
            state_str = "UNKNOWN"
        elif isinstance(wh_state, str):
            state_str = wh_state
        else:
            state_value = getattr(wh_state, "value", None)
            state_name = getattr(wh_state, "name", None)
            if state_value is not None:
                state_str = str(state_value)
            elif state_name is not None:
                state_str = str(state_name)
            else:
                state_str = str(wh_state)
        out.append({"id": str(wh_id), "name": str(wh_name), "state": state_str})
    return out


def list_databricks_catalogs(
    *,
    host: str,
    http_path: str,
    pat_token: Optional[str] = None,
    oauth_token: Optional[str] = None,
) -> list[str]:
    """List Unity Catalog catalogs visible to the calling identity.

    Runs ``SHOW CATALOGS`` against the SQL Warehouse. Returns names
    exactly as the warehouse reports them — no case transformation.
    """
    conn = _connect_databricks(
        host=host,
        http_path=http_path,
        pat_token=pat_token,
        oauth_token=oauth_token,
    )
    try:
        cursor = conn.cursor()
        cursor.execute("SHOW CATALOGS")
        # databricks-sql-connector returns rows as tuples; first column is
        # the catalog name across all major SQL Warehouse versions.
        return [row[0] for row in cursor.fetchall()]
    finally:
        conn.close()


def list_databricks_schemas(
    *,
    host: str,
    http_path: str,
    catalog: str,
    pat_token: Optional[str] = None,
    oauth_token: Optional[str] = None,
) -> list[str]:
    """List UC schemas under a given catalog.

    Runs ``SHOW SCHEMAS IN <catalog>`` with the catalog name quoted via
    ``_quote_identifier`` (rejects NUL bytes; doubles embedded backticks).
    """
    quoted = _quote_identifier(catalog)
    conn = _connect_databricks(
        host=host,
        http_path=http_path,
        pat_token=pat_token,
        oauth_token=oauth_token,
    )
    try:
        cursor = conn.cursor()
        # nosec B608 - catalog quoted via _quote_identifier
        cursor.execute(f"SHOW SCHEMAS IN {quoted}")
        return [row[0] for row in cursor.fetchall()]
    finally:
        conn.close()
