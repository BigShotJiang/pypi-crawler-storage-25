"""Desktop project management routes.

CRUD for projects: list, update, delete (with two-phase safety).
"""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path
from typing import Any, Literal

from core.paths import config_path, env_path, profiles_dir, projects_dir
from fastapi import APIRouter, HTTPException, Request
from ingest.static_loaders.salesforce.factory import SfAuthMode
from pydantic import BaseModel, Field, ValidationError, field_validator

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/desktop/projects", tags=["desktop-projects"])

BackendType = Literal["snowflake", "duckdb", "databricks"]


# ── Models ────────────────────────────────────────────────────────────


class IntegrationSummary(BaseModel):
    """Current integration state for a project."""

    salesforce_enabled: bool = False
    salesforce_client_id: str | None = None
    salesforce_login_url: str | None = None
    salesforce_auth_type: SfAuthMode | None = None
    salesforce_instance_url: str | None = None
    salesforce_username: str | None = None
    cube_enabled: bool = False
    cube_project_dir: str | None = None
    lookml_enabled: bool = False
    lookml_project_dir: str | None = None
    fivetran_enabled: bool = False
    fivetran_connector_ids: list[str] | None = None
    linear_enabled: bool = False
    linear_team_id: str | None = None
    profiling_enabled: bool = True


class ProjectSummary(BaseModel):
    """Summary of a single configured project."""

    name: str
    backend: str | None = None
    dbt_path: str | None = None
    clone_path: str | None = None
    graph_name: str | None = None
    status: str = "ready"  # ready | initializing | deleting
    integrations: IntegrationSummary = IntegrationSummary()


class ProjectListResponse(BaseModel):
    """Response containing all configured projects."""

    projects: list[ProjectSummary]
    default_project: str | None = None


class UpdateProjectRequest(BaseModel):
    """Partial update — only provided fields are changed.

    In Tauri mode, secret fields go to the OS keychain and never reach this
    endpoint. In browser-only dev mode, secrets still arrive here and are
    written to .env as a fallback.
    """

    backend_type: BackendType | None = None
    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_auth_method: Literal["private_key", "pat"] | None = None
    snowflake_private_key_path: str | None = None
    # Only used in browser-dev fallback; Tauri writes PAT to OS keychain.
    snowflake_pat_token: str | None = None
    snowflake_warehouse: str | None = None
    snowflake_role: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = None
    allowed_databases: list[str] | None = None
    dbt_target: str | None = None
    profile_name: str | None = None
    duckdb_path: str | None = None
    env_vars: str | None = None
    sub_project: str | None = None
    # Databricks (TD-2734). databricks_oauth_u2m_token is intentionally
    # NOT exposed here — OAuth tokens flow through the per-host
    # DatabricksU2MTokenStore, never the PATCH endpoint, so adding it
    # would create a second persistence path that could drift.
    databricks_host: str | None = None
    databricks_http_path: str | None = None
    databricks_warehouse_id: str | None = None
    databricks_catalog: str | None = None
    databricks_schema: str | None = None
    databricks_auth_method: Literal["pat", "oauth_u2m"] | None = None
    # Browser-dev fallback only; Tauri writes via OS keychain.
    databricks_pat_token: str | None = None
    allowed_catalogs: list[str] | None = None
    # Secret fields — used by browser-only dev mode (.env fallback)
    anthropic_api_key: str | None = None
    openai_api_key: str | None = None
    # TD-2955: see keychain.rs SECRET_FIELDS. Empty string clears the env var.
    anthropic_base_url: str | None = Field(
        default=None,
        description=(
            "Custom base URL for the Anthropic SDK. Send '' to clear. "
            "Must be http(s); CRLF rejected to prevent .env injection."
        ),
    )
    openai_base_url: str | None = Field(
        default=None,
        description=(
            "Custom base URL for the OpenAI SDK. Send '' to clear. "
            "Must be http(s); CRLF rejected to prevent .env injection."
        ),
    )
    logfire_api_key: str | None = None
    # Integrations (explicit booleans so we can distinguish "not sent" from "disable")
    salesforce_enabled: bool | None = None
    salesforce_client_id: str | None = None
    salesforce_login_url: str | None = None
    salesforce_auth_type: SfAuthMode | None = None
    salesforce_instance_url: str | None = None
    salesforce_username: str | None = None
    # Salesforce secret fields — browser-only dev mode (.env fallback)
    sf_password: str | None = None
    sf_security_token: str | None = None
    sf_client_secret: str | None = None
    cube_enabled: bool | None = None
    cube_project_dir: str | None = None
    lookml_enabled: bool | None = None
    lookml_project_dir: str | None = None
    fivetran_enabled: bool | None = None
    fivetran_connector_ids: list[str] | None = None
    fivetran_api_key: str | None = None
    fivetran_api_secret: str | None = None
    linear_enabled: bool | None = None
    linear_team_id: str | None = None
    linear_analyst_api_key: str | None = None
    linear_data_engineer_api_key: str | None = None
    profiling_enabled: bool | None = None

    @field_validator("anthropic_base_url", "openai_base_url")
    @classmethod
    def _validate_provider_base_url(cls, v: str | None) -> str | None:
        # TD-2955: parity with _validate_databricks_host on this same model.
        # CRLF would corrupt .env (single line per entry); non-http(s) schemes
        # would let a PATCH caller redirect SDK traffic to file:// or other
        # local handlers. "" is the documented clear signal — let it through.
        if v is None or v == "":
            return v
        if "\n" in v or "\r" in v:
            raise ValueError("base URL must not contain CR/LF characters")
        if not (v.startswith("https://") or v.startswith("http://")):
            raise ValueError("base URL must use http:// or https:// scheme")
        return v


class ProjectDetail(BaseModel):
    """Detailed project-specific config for the Configure Project flow."""

    name: str
    clone_path: str
    dbt_path: str
    backend_type: BackendType
    dbt_target: str | None = None
    profile_name: str | None = None
    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_auth_method: Literal["private_key", "pat"] = "private_key"
    snowflake_private_key_path: str | None = None
    # Presence flag only — the token itself is never returned over the wire.
    snowflake_has_pat_token: bool = False
    snowflake_warehouse: str | None = None
    snowflake_role: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = None
    allowed_databases: list[str] = []
    duckdb_path: str | None = None
    # Databricks (TD-2734) — token never returned over the wire; presence flags only.
    databricks_host: str | None = None
    databricks_http_path: str | None = None
    databricks_warehouse_id: str | None = None
    databricks_catalog: str | None = None
    databricks_schema: str | None = None
    databricks_auth_method: Literal["pat", "oauth_u2m"] = "pat"
    databricks_has_pat_token: bool = False
    databricks_has_oauth_u2m_token: bool = False
    allowed_catalogs: list[str] = []
    env_vars: str = ""
    profiling_enabled: bool = True
    subprojects: list[str] = []
    selected_subproject: str = ""
    subproject_warning: str | None = None


# ── Helpers ───────────────────────────────────────────────────────────


def _read_config() -> dict:
    """Read config.yaml and return as dict. Returns empty dict if not found."""
    import yaml

    path = config_path()
    if not path.exists():
        return {}
    return yaml.safe_load(path.read_text()) or {}


def _write_config(data: dict) -> None:
    """Write config.yaml atomically."""
    import yaml

    path = config_path()
    tmp = path.with_suffix(".yaml.tmp")
    tmp.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
    os.replace(str(tmp), str(path))


_RESERVED_PROJECT_ENV_KEYS = {
    "SNOWFLAKE_PRIVATE_KEY_PATH",
    "SNOWFLAKE_PAT_TOKEN",
    "DUCKDB_PATH",
    # Databricks (TD-2734): DATABRICKS_TOKEN is the credential. HOST and
    # HTTP_PATH aren't secrets but they're persisted in project["env"] for
    # dbt env_var() resolution; surfacing them via the env_vars string
    # round-trips them to the browser as user-visible config, which we
    # don't want — they're already in ProjectDetail.databricks_host /
    # databricks_http_path.
    "DATABRICKS_TOKEN",
    "DATABRICKS_HOST",
    "DATABRICKS_HTTP_PATH",
}


def _custom_project_env(project: dict) -> dict[str, str]:
    raw_env = project.get("env")
    if not isinstance(raw_env, dict):
        return {}
    return {
        str(key): str(value)
        for key, value in raw_env.items()
        if key not in _RESERVED_PROJECT_ENV_KEYS and value is not None and str(value)
    }


def _serialize_env_vars(entries: dict[str, str]) -> str:
    if not entries:
        return ""
    return ", ".join(f"{key}={value}" for key, value in sorted(entries.items()))


def _parse_env_vars(raw: str | None) -> dict[str, str]:
    if not raw:
        return {}
    parsed: dict[str, str] = {}
    for pair in raw.split(","):
        pair = pair.strip()
        if not pair or "=" not in pair:
            continue
        key, value = pair.split("=", 1)
        key = key.strip()
        value = value.strip()
        if key and key not in _RESERVED_PROJECT_ENV_KEYS:
            parsed[key] = value
    return parsed


def _backend_type(value: object) -> BackendType | None:
    if value == "snowflake":
        return "snowflake"
    if value == "databricks":
        return "databricks"
    if value in {None, "", "duckdb"}:
        return "duckdb"
    return None


def _coerce_mapping(value: object) -> dict:
    return dict(value) if isinstance(value, dict) else {}


def _coerce_string_list(value: object) -> list[str]:
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return list(value)
    return []


def _build_project_env(project: dict) -> dict[str, str]:
    data = _coerce_mapping(project.get("data"))
    env_entries: dict[str, str] = {}

    if data.get("backend") == "snowflake":
        if data.get("auth_method") != "pat" and data.get("private_key_path"):
            env_entries["SNOWFLAKE_PRIVATE_KEY_PATH"] = str(data["private_key_path"])
    if data.get("backend") == "duckdb" and data.get("db_path"):
        env_entries["DUCKDB_PATH"] = str(data["db_path"])

    env_entries.update(_custom_project_env(project))
    return {key: value for key, value in env_entries.items() if value}


def _resolve_subproject_path(project_name: str, sub_project: str | None) -> Path:
    project_root = (projects_dir() / project_name).resolve()
    if not sub_project or sub_project in {".", "./"}:
        resolved = project_root
    else:
        sub = Path(sub_project)
        if sub.is_absolute() or ".." in sub.parts:
            raise HTTPException(status_code=400, detail="Invalid subproject path")

        resolved = (project_root / sub).resolve()
        if not resolved.is_relative_to(project_root):
            raise HTTPException(status_code=400, detail="Invalid subproject path")

    if not resolved.exists():
        raise HTTPException(status_code=400, detail="Subproject path does not exist")
    if not (resolved / "dbt_project.yml").exists():
        raise HTTPException(
            status_code=400,
            detail="Selected subproject must contain dbt_project.yml",
        )

    return resolved


def _detect_subprojects(
    project_name: str, dbt_path: str
) -> tuple[list[str], str, str | None]:
    project_root = (projects_dir() / project_name).resolve()
    selected = ""
    warning: str | None = None
    subprojects: list[str] = []

    try:
        dbt_root = Path(dbt_path).resolve()
        if dbt_root.is_relative_to(project_root):
            rel = dbt_root.relative_to(project_root)
            selected = str(rel) if str(rel) != "." else "."

        if project_root.exists():
            dbt_files = list(project_root.rglob("dbt_project.yml"))
            values = {
                str(file.parent.relative_to(project_root)) or "." for file in dbt_files
            }
            subprojects = sorted(values, key=lambda value: (value != ".", value))
    except Exception:
        logger.warning(
            "Could not inspect dbt subprojects for project %s",
            project_name,
            exc_info=True,
        )
        warning = (
            "Could not inspect dbt subprojects. Check the project path and permissions."
        )

    return subprojects, selected, warning


def _rewrite_profiles_yml(project_name: str, project: dict) -> None:
    from lineage.api.desktop_setup import CreateProjectRequest, _build_profiles_yml

    data = _coerce_mapping(project.get("data"))
    backend = _backend_type(data.get("backend"))
    if backend is None:
        logger.warning(
            "Skipping profiles.yml rewrite for project %s due to unsupported backend %r",
            project_name,
            data.get("backend"),
        )
        return

    # Snowflake's auth lives at data.auth_method (flat); Databricks nests
    # it at data.auth.auth_method. Read the right shape per backend so
    # neither's gate trips for the other.
    if backend == "databricks":
        auth_block = data.get("auth") or {}
        if not isinstance(auth_block, dict):
            auth_block = {}
        databricks_auth_method = auth_block.get("auth_method") or "pat"
        if databricks_auth_method not in ("pat", "oauth_u2m"):
            logger.warning(
                "Skipping profiles.yml rewrite for project %s due to "
                "unsupported databricks auth_method %r",
                project_name,
                databricks_auth_method,
            )
            return
        auth_method: Literal["private_key", "pat"] = (
            "private_key"  # snowflake default; ignored for databricks
        )
    else:
        databricks_auth_method = "pat"
        auth_method = data.get("auth_method", "private_key")
        if auth_method not in ("private_key", "pat"):
            logger.warning(
                "Skipping profiles.yml rewrite for project %s due to unsupported auth_method %r",
                project_name,
                auth_method,
            )
            return

    req = CreateProjectRequest(
        name=project_name,
        git_url="",
        backend=backend,
        snowflake_account=data.get("account"),
        snowflake_user=data.get("user"),
        snowflake_auth_method=auth_method,
        snowflake_private_key_path=data.get("private_key_path"),
        snowflake_warehouse=data.get("warehouse"),
        snowflake_role=data.get("role"),
        snowflake_database=data.get("database"),
        snowflake_schema=data.get("schema_name"),
        allowed_databases=data.get("allowed_databases"),
        dbt_target=project.get("dbt_target"),
        profile_name=project.get("profile_name"),
        duckdb_path=data.get("db_path"),
        # Databricks (TD-2734) — fields fan out only when backend=databricks;
        # for snowflake/duckdb these stay None and _build_profiles_yml's
        # backend branch won't see them.
        databricks_host=data.get("host") if backend == "databricks" else None,
        databricks_http_path=(
            data.get("http_path") if backend == "databricks" else None
        ),
        databricks_warehouse_id=(
            data.get("warehouse_id") if backend == "databricks" else None
        ),
        databricks_catalog=(data.get("catalog") if backend == "databricks" else None),
        databricks_schema=(
            data.get("schema_name") if backend == "databricks" else None
        ),
        databricks_auth_method=databricks_auth_method,
        allowed_catalogs=(
            data.get("allowed_catalogs") if backend == "databricks" else None
        ),
        env_vars=_serialize_env_vars(_custom_project_env(project)),
        profiling_enabled=bool(
            (project.get("profiling") or {}).get("enabled", True)
            if isinstance(project.get("profiling"), dict)
            else True
        ),
    )

    profile_name = str(project.get("profile_name") or project_name)
    path_value = project.get("profiles_dir")
    profiles_path = (
        Path(str(path_value)).expanduser()
        if path_value
        else profiles_dir() / project_name
    )
    profiles_path.mkdir(parents=True, exist_ok=True)
    (profiles_path / "profiles.yml").write_text(_build_profiles_yml(req, profile_name))


# ── Endpoints ─────────────────────────────────────────────────────────


@router.get("/", response_model=ProjectListResponse)
async def list_projects():
    """List all configured projects."""
    config = _read_config()
    projects_map = config.get("projects", {})
    default = config.get("default_project")

    summaries = []
    for name, proj in projects_map.items():
        data = proj.get("data", {}) if isinstance(proj, dict) else {}
        sf = proj.get("salesforce", {}) if isinstance(proj, dict) else {}
        cube = proj.get("cube", {}) if isinstance(proj, dict) else {}
        lookml = proj.get("lookml", {}) if isinstance(proj, dict) else {}
        ft = proj.get("fivetran", {}) if isinstance(proj, dict) else {}
        ticket = proj.get("ticket", {}) if isinstance(proj, dict) else {}
        _raw_prof = proj.get("profiling") if isinstance(proj, dict) else None
        profiling = _raw_prof if isinstance(_raw_prof, dict) else {}
        linear_enabled = (
            bool(ticket.get("enabled")) and ticket.get("backend") == "linear"
        )
        ft_ids = (
            ft.get("connector_ids")
            if isinstance(ft.get("connector_ids"), list)
            else None
        )
        summaries.append(
            ProjectSummary(
                name=name,
                backend=data.get("backend"),
                dbt_path=proj.get("dbt_path") if isinstance(proj, dict) else None,
                clone_path=str(projects_dir() / name),
                graph_name=proj.get("graph_name") if isinstance(proj, dict) else None,
                status=proj.get("status", "ready")
                if isinstance(proj, dict)
                else "ready",
                integrations=IntegrationSummary(
                    salesforce_enabled=bool(sf.get("enabled")),
                    salesforce_client_id=sf.get("client_id"),
                    salesforce_login_url=sf.get("login_url"),
                    salesforce_auth_type=sf.get("auth_type"),
                    salesforce_instance_url=sf.get("instance_url"),
                    salesforce_username=sf.get("username"),
                    cube_enabled=bool(cube.get("enabled")),
                    cube_project_dir=cube.get("project_dir"),
                    lookml_enabled=bool(lookml.get("enabled")),
                    lookml_project_dir=lookml.get("project_dir"),
                    fivetran_enabled=bool(ft.get("enabled")),
                    fivetran_connector_ids=ft_ids,
                    linear_enabled=linear_enabled,
                    linear_team_id=ticket.get("team_id") if linear_enabled else None,
                    profiling_enabled=bool(profiling.get("enabled", True)),
                ),
            )
        )

    return ProjectListResponse(projects=summaries, default_project=default)


@router.get("/{name}", response_model=ProjectDetail)
async def get_project(name: str):
    """Return detailed project-specific config for the Configure Project flow."""
    config = _read_config()
    projects_map = config.get("projects", {})
    if name not in projects_map:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")

    project = projects_map[name]
    data = _coerce_mapping(project.get("data"))
    profiling = (
        project.get("profiling") if isinstance(project.get("profiling"), dict) else {}
    )
    dbt_path = str(project.get("dbt_path") or projects_dir() / name)
    subprojects, selected_subproject, warning = _detect_subprojects(name, dbt_path)
    backend_type = _backend_type(data.get("backend"))
    if backend_type is None:
        logger.warning(
            "Project %s has unsupported backend %r in persisted config",
            name,
            data.get("backend"),
        )
        raise HTTPException(
            status_code=500,
            detail="Project config contains unsupported backend value",
        )

    # Snowflake's auth_method lives at data.auth_method (flat). Databricks
    # nests it under data.auth.auth_method (discriminated union). Read each
    # backend's shape independently so a Databricks project's nested-auth
    # shape doesn't fail the snowflake gate.
    if backend_type == "databricks":
        auth_block = data.get("auth") or {}
        if not isinstance(auth_block, dict):
            auth_block = {}
        databricks_auth_method = auth_block.get("auth_method") or "pat"
        if databricks_auth_method not in ("pat", "oauth_u2m"):
            logger.warning(
                "Project %s has unsupported databricks auth_method %r",
                name,
                databricks_auth_method,
            )
            raise HTTPException(
                status_code=500,
                detail="Project config contains unsupported databricks auth_method value",
            )
        # Snowflake auth_method irrelevant for databricks projects; default it.
        auth_method = "private_key"
    else:
        databricks_auth_method = "pat"
        auth_method = data.get("auth_method", "private_key")
        if auth_method not in ("private_key", "pat"):
            logger.warning(
                "Project %s has unsupported auth_method %r in persisted config",
                name,
                auth_method,
            )
            raise HTTPException(
                status_code=500,
                detail="Project config contains unsupported auth_method value",
            )

    # Pick up tokens persisted to ~/.typedef-desktop/.env in browser-dev
    # mode so the "(unchanged)" placeholder flips correctly after save.
    from lineage.utils.env import load_env_file

    load_env_file()
    has_pat_token = bool(os.environ.get("SNOWFLAKE_PAT_TOKEN"))
    has_databricks_pat_token = bool(os.environ.get("DATABRICKS_TOKEN"))
    has_databricks_oauth_u2m_token = False
    if backend_type == "databricks":
        # Per-host keychain blob — check if a stored OAuth U2M token
        # exists for this project's workspace host without returning the
        # token itself.
        try:
            from lineage.utils.databricks_oauth import DatabricksU2MTokenStore

            stored_host = data.get("host")
            if stored_host:
                store = DatabricksU2MTokenStore(str(stored_host))
                has_databricks_oauth_u2m_token = store.load() is not None
        except Exception:
            logger.debug(
                "Could not probe Databricks U2M token store for project %s",
                name,
                exc_info=True,
            )

    return ProjectDetail(
        name=name,
        clone_path=str(projects_dir() / name),
        dbt_path=dbt_path,
        backend_type=backend_type,
        dbt_target=project.get("dbt_target"),
        profile_name=project.get("profile_name"),
        snowflake_account=data.get("account"),
        snowflake_user=data.get("user"),
        snowflake_auth_method=auth_method,
        snowflake_private_key_path=data.get("private_key_path"),
        snowflake_has_pat_token=has_pat_token,
        snowflake_warehouse=data.get("warehouse"),
        snowflake_role=data.get("role"),
        snowflake_database=data.get("database"),
        snowflake_schema=data.get("schema_name"),
        allowed_databases=_coerce_string_list(data.get("allowed_databases")),
        duckdb_path=data.get("db_path"),
        # Databricks (TD-2734) — populated only for backend=databricks; the
        # config layer keeps these absent for snowflake/duckdb projects.
        databricks_host=data.get("host") if backend_type == "databricks" else None,
        databricks_http_path=(
            data.get("http_path") if backend_type == "databricks" else None
        ),
        databricks_warehouse_id=(
            data.get("warehouse_id") if backend_type == "databricks" else None
        ),
        databricks_catalog=(
            data.get("catalog") if backend_type == "databricks" else None
        ),
        databricks_schema=(
            data.get("schema_name") if backend_type == "databricks" else None
        ),
        databricks_auth_method=databricks_auth_method,
        databricks_has_pat_token=has_databricks_pat_token,
        databricks_has_oauth_u2m_token=has_databricks_oauth_u2m_token,
        allowed_catalogs=_coerce_string_list(data.get("allowed_catalogs")),
        env_vars=_serialize_env_vars(_custom_project_env(project)),
        profiling_enabled=bool(profiling.get("enabled", True)),
        subprojects=subprojects,
        selected_subproject=selected_subproject,
        subproject_warning=warning,
    )


@router.patch("/{name}")
async def update_project(name: str, req: UpdateProjectRequest):
    """Update project credentials/settings without destroying the graph."""
    config = _read_config()
    projects_map = config.get("projects", {})

    if name not in projects_map:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")

    # In Tauri mode, secrets go to OS keychain and never reach here.
    # In browser-only dev mode, secrets still arrive via this endpoint
    # and are written to .env as a fallback.
    fields = req.model_fields_set

    env_updates: dict[str, str] = {}
    if (
        "snowflake_private_key_path" in fields
        and req.snowflake_private_key_path is not None
    ):
        env_updates["SNOWFLAKE_PRIVATE_KEY_PATH"] = req.snowflake_private_key_path
    if "snowflake_pat_token" in fields and req.snowflake_pat_token is not None:
        # Effective auth method = explicit request value, else the persisted
        # project's current auth_method. This lets browser-mode "save just
        # the PAT" flows (which only send snowflake_pat_token) work without
        # re-stating snowflake_auth_method, while still refusing PAT writes
        # for projects currently configured for private-key auth.
        project_entry = projects_map.get(name, {})
        persisted_data = (
            project_entry.get("data") if isinstance(project_entry, dict) else None
        )
        persisted_auth = (
            persisted_data.get("auth_method")
            if isinstance(persisted_data, dict)
            else None
        )
        effective_auth = req.snowflake_auth_method or persisted_auth
        if effective_auth == "pat":
            env_updates["SNOWFLAKE_PAT_TOKEN"] = req.snowflake_pat_token
        # else: silently drop the stray PAT (don't write to disk for
        # private-key projects, matching the spirit of the prior gate).
    if "databricks_pat_token" in fields and req.databricks_pat_token is not None:
        # Same shape as the Snowflake PAT path: only persist when the
        # effective Databricks auth_method is 'pat' so a stray PAT on an
        # OAuth project doesn't quietly land on disk. The persisted auth
        # lives at data.auth.auth_method (nested), not data.auth_method.
        project_entry = projects_map.get(name, {})
        persisted_data = (
            project_entry.get("data") if isinstance(project_entry, dict) else None
        )
        persisted_auth_block: Any = (
            persisted_data.get("auth") if isinstance(persisted_data, dict) else None
        )
        persisted_databricks_auth: Any = None
        if isinstance(persisted_auth_block, dict):
            persisted_databricks_auth = persisted_auth_block.get("auth_method")
        effective_databricks_auth = (
            req.databricks_auth_method or persisted_databricks_auth
        )
        if effective_databricks_auth == "pat":
            env_updates["DATABRICKS_TOKEN"] = req.databricks_pat_token
    if "anthropic_api_key" in fields and req.anthropic_api_key is not None:
        env_updates["ANTHROPIC_API_KEY"] = req.anthropic_api_key
    if "anthropic_base_url" in fields and req.anthropic_base_url is not None:
        env_updates["ANTHROPIC_BASE_URL"] = req.anthropic_base_url
    if "openai_api_key" in fields and req.openai_api_key is not None:
        env_updates["OPENAI_API_KEY"] = req.openai_api_key
    if "openai_base_url" in fields and req.openai_base_url is not None:
        env_updates["OPENAI_BASE_URL"] = req.openai_base_url
    if "logfire_api_key" in fields and req.logfire_api_key is not None:
        env_updates["LOGFIRE_TOKEN"] = req.logfire_api_key
    if "fivetran_api_key" in fields and req.fivetran_api_key is not None:
        env_updates["FIVETRAN_API_KEY"] = req.fivetran_api_key
    if "fivetran_api_secret" in fields and req.fivetran_api_secret is not None:
        env_updates["FIVETRAN_API_SECRET"] = req.fivetran_api_secret
    if "linear_analyst_api_key" in fields and req.linear_analyst_api_key is not None:
        env_updates["LINEAR_ANALYST_API_KEY"] = req.linear_analyst_api_key
    if "sf_password" in fields and req.sf_password is not None:
        env_updates["SF_PASSWORD"] = req.sf_password
    if "sf_security_token" in fields and req.sf_security_token is not None:
        env_updates["SF_SECURITY_TOKEN"] = req.sf_security_token
    if "sf_client_secret" in fields and req.sf_client_secret is not None:
        env_updates["SF_CLIENT_SECRET"] = req.sf_client_secret
    if (
        "linear_data_engineer_api_key" in fields
        and req.linear_data_engineer_api_key is not None
    ):
        env_updates["LINEAR_DATA_ENGINEER_API_KEY"] = req.linear_data_engineer_api_key

    if env_updates:
        existing: dict[str, str] = {}
        ep = env_path()
        if ep.exists():
            for line in ep.read_text().splitlines():
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    existing[k.strip()] = v.strip()
        existing.update(env_updates)

        from lineage.api.desktop_setup import _write_env_file

        _write_env_file(ep, existing)

    # Update config fields
    proj = projects_map[name]
    data = _coerce_mapping(proj.get("data"))
    if "backend_type" in fields and req.backend_type is not None:
        data["backend"] = req.backend_type
    if "snowflake_account" in fields:
        if req.snowflake_account is None:
            data.pop("account", None)
        else:
            data["account"] = req.snowflake_account
    if "snowflake_user" in fields:
        if req.snowflake_user is None:
            data.pop("user", None)
        else:
            data["user"] = req.snowflake_user
    if "snowflake_auth_method" in fields and req.snowflake_auth_method is not None:
        data["auth_method"] = req.snowflake_auth_method
        if req.snowflake_auth_method == "pat":
            data.pop("private_key_path", None)
            data["pat_token"] = "${SNOWFLAKE_PAT_TOKEN}"  # nosec B105 - env var reference, not a literal secret
        else:
            data.pop("pat_token", None)
    if "snowflake_private_key_path" in fields:
        if req.snowflake_private_key_path is None:
            data.pop("private_key_path", None)
        else:
            data["private_key_path"] = req.snowflake_private_key_path
    if "snowflake_warehouse" in fields:
        if req.snowflake_warehouse is None:
            data.pop("warehouse", None)
        else:
            data["warehouse"] = req.snowflake_warehouse
    if "snowflake_role" in fields:
        if req.snowflake_role is None:
            data.pop("role", None)
        else:
            data["role"] = req.snowflake_role
    if "snowflake_database" in fields:
        if req.snowflake_database is None:
            data.pop("database", None)
        else:
            data["database"] = req.snowflake_database
    if "snowflake_schema" in fields:
        if req.snowflake_schema is None:
            data.pop("schema_name", None)
        else:
            data["schema_name"] = req.snowflake_schema
    if "allowed_databases" in fields:
        if req.allowed_databases:
            data["allowed_databases"] = req.allowed_databases
        else:
            data.pop("allowed_databases", None)
    if "duckdb_path" in fields:
        if req.duckdb_path is None:
            data.pop("db_path", None)
        else:
            data["db_path"] = req.duckdb_path

    # Databricks (TD-2734) — flat fields on data{}; auth lives at
    # data["auth"] as a nested {auth_method, token} dict. Build it as a
    # coherent block per peer-review feedback so a half-applied PATCH
    # can't leave a malformed discriminated-union on disk.
    if "databricks_host" in fields:
        if req.databricks_host is None:
            data.pop("host", None)
        else:
            # Route through the canonical SSRF allowlist + normalizer so
            # PATCH cannot persist an unallowlisted host that preflight /
            # sync will later use for outbound connections. Local import
            # avoids a hard module-level coupling between desktop_projects
            # and desktop_setup; the helper raises HTTPException(400) on
            # an unrecognized host and on empty input, and strips
            # scheme / path / query / fragment uniformly.
            from lineage.api.desktop_setup import _validate_databricks_host

            data["host"] = _validate_databricks_host(req.databricks_host)
    if "databricks_http_path" in fields:
        if req.databricks_http_path is None:
            data.pop("http_path", None)
        else:
            data["http_path"] = req.databricks_http_path
    if "databricks_warehouse_id" in fields:
        if req.databricks_warehouse_id is None:
            data.pop("warehouse_id", None)
        else:
            data["warehouse_id"] = req.databricks_warehouse_id
    if "databricks_catalog" in fields:
        if req.databricks_catalog is None:
            data.pop("catalog", None)
        else:
            data["catalog"] = req.databricks_catalog
    if "databricks_schema" in fields:
        if req.databricks_schema is None:
            data.pop("schema_name", None)
        else:
            data["schema_name"] = req.databricks_schema
    if "allowed_catalogs" in fields:
        if req.allowed_catalogs:
            data["allowed_catalogs"] = req.allowed_catalogs
        else:
            data.pop("allowed_catalogs", None)
    if "databricks_auth_method" in fields and req.databricks_auth_method is not None:
        # Build/replace the nested auth block as a single dict so the
        # discriminated union stays coherent. Token reference is the
        # same env-var template regardless of auth_method — the
        # keychain bridge populates DATABRICKS_TOKEN at runtime, and
        # OAuth tokens are loaded into the env at preflight/sync via
        # DatabricksU2MTokenStore (separate code path).
        existing_auth = data.get("auth") if isinstance(data.get("auth"), dict) else {}
        data["auth"] = {
            "auth_method": req.databricks_auth_method,
            "token": existing_auth.get("token") or "${DATABRICKS_TOKEN}",  # nosec B105 - env-var reference, not a literal secret
        }

    backend_type = data.get("backend")
    if backend_type == "duckdb":
        for key in [
            "account",
            "user",
            "private_key_path",
            "pat_token",
            "auth_method",
            "warehouse",
            "role",
            "database",
            "schema_name",
            "allowed_databases",
            # Databricks keys cleaned up too when switching to duckdb
            "host",
            "http_path",
            "warehouse_id",
            "catalog",
            "auth",
            "allowed_catalogs",
        ]:
            data.pop(key, None)
    elif backend_type == "snowflake":
        data.pop("db_path", None)
        # Strip Databricks keys when switching from databricks → snowflake
        for key in [
            "host",
            "http_path",
            "warehouse_id",
            "catalog",
            "auth",
            "allowed_catalogs",
        ]:
            data.pop(key, None)
    elif backend_type == "databricks":
        # Strip Snowflake/DuckDB keys when this is or just became a
        # Databricks project. The flat snowflake auth_method key would
        # otherwise collide with the get_project gate that checks it.
        for key in [
            "account",
            "user",
            "private_key_path",
            "pat_token",
            "auth_method",
            "warehouse",
            "role",
            "database",
            "allowed_databases",
            "db_path",
        ]:
            data.pop(key, None)
        # Note: schema_name is shared between snowflake and databricks
        # (both store the default schema there) — don't strip it.

    proj["data"] = data

    if "dbt_target" in fields:
        if req.dbt_target is None:
            proj.pop("dbt_target", None)
        else:
            proj["dbt_target"] = req.dbt_target

    if "profile_name" in fields:
        if req.profile_name is None:
            proj.pop("profile_name", None)
        else:
            proj["profile_name"] = req.profile_name

    if "sub_project" in fields:
        proj["dbt_path"] = str(_resolve_subproject_path(name, req.sub_project))

    if any(
        field in fields
        for field in {
            "env_vars",
            "duckdb_path",
            "snowflake_private_key_path",
            "snowflake_auth_method",
            "snowflake_pat_token",
            "backend_type",
        }
    ):
        custom_env = (
            _parse_env_vars(req.env_vars)
            if "env_vars" in fields
            else _custom_project_env(proj)
        )
        reserved_env = {}
        if data.get("backend") == "snowflake":
            if data.get("auth_method") == "pat":
                # Keep the existing PAT value if the project already had one;
                # this only hits the value caller provided in browser-dev mode.
                existing_env = (
                    proj.get("env") if isinstance(proj.get("env"), dict) else {}
                )
                pat_value = (
                    req.snowflake_pat_token
                    if req.snowflake_pat_token is not None
                    else str(existing_env.get("SNOWFLAKE_PAT_TOKEN", ""))
                )
                if pat_value:
                    reserved_env["SNOWFLAKE_PAT_TOKEN"] = pat_value
            elif data.get("private_key_path"):
                reserved_env["SNOWFLAKE_PRIVATE_KEY_PATH"] = str(
                    data["private_key_path"]
                )
        if data.get("backend") == "duckdb" and data.get("db_path"):
            reserved_env["DUCKDB_PATH"] = str(data["db_path"])
        env_map = {**reserved_env, **custom_env}
        if env_map:
            proj["env"] = env_map
        else:
            proj.pop("env", None)

    # Update integrations
    if req.salesforce_enabled is not None:
        if req.salesforce_enabled:
            sf = proj.get("salesforce", {})
            sf["enabled"] = True
            if req.salesforce_client_id is not None:
                sf["client_id"] = req.salesforce_client_id
            if req.salesforce_login_url is not None:
                sf["login_url"] = req.salesforce_login_url
            if req.salesforce_auth_type is not None:
                sf["auth_type"] = str(req.salesforce_auth_type)
            if req.salesforce_instance_url is not None:
                sf["instance_url"] = req.salesforce_instance_url
            if req.salesforce_username is not None:
                sf["username"] = req.salesforce_username
            proj["salesforce"] = sf
        else:
            proj.pop("salesforce", None)

    if req.cube_enabled is not None:
        if req.cube_enabled:
            cube = proj.get("cube", {})
            cube["enabled"] = True
            if req.cube_project_dir is not None:
                cube["project_dir"] = req.cube_project_dir
            proj["cube"] = cube
        else:
            proj.pop("cube", None)

    if req.lookml_enabled is not None:
        if req.lookml_enabled:
            lookml = proj.get("lookml", {})
            lookml["enabled"] = True
            if req.lookml_project_dir is not None:
                lookml["project_dir"] = req.lookml_project_dir
            proj["lookml"] = lookml
        else:
            proj.pop("lookml", None)

    if req.fivetran_enabled is not None:
        if req.fivetran_enabled:
            ft = proj.get("fivetran", {})
            ft["enabled"] = True
            if req.fivetran_connector_ids is not None:
                ft["connector_ids"] = req.fivetran_connector_ids
            proj["fivetran"] = ft
        else:
            proj.pop("fivetran", None)

    if req.linear_enabled is not None:
        if req.linear_enabled:
            ticket = proj.get("ticket", {})
            ticket["enabled"] = True
            ticket["backend"] = "linear"
            if req.linear_team_id is not None:
                ticket["team_id"] = req.linear_team_id
            proj["ticket"] = ticket
        else:
            proj.pop("ticket", None)

    if req.profiling_enabled is not None:
        _raw = proj.get("profiling")
        profiling = _raw if isinstance(_raw, dict) else {}
        profiling["enabled"] = req.profiling_enabled
        proj["profiling"] = profiling

    _rewrite_profiles_yml(name, proj)
    _write_config(config)
    return {"message": f"Project '{name}' updated"}


@router.delete("/{name}")
async def delete_project(name: str):
    """Delete a project with two-phase safety.

    Phase 1: Mark status as 'deleting' in config.
    Phase 2: Remove filesystem artifacts + SurrealDB database.
    Phase 3: Remove config entry.

    If the process crashes between phases, the next startup detects
    'deleting' entries and resumes cleanup.
    """
    import re

    config = _read_config()
    projects_map = config.get("projects", {})

    # Validate name to prevent path traversal
    if not re.fullmatch(r"[a-z0-9_]+", name):
        raise HTTPException(status_code=400, detail="Invalid project name")

    if name not in projects_map:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")

    # Phase 1: Mark as deleting
    projects_map[name]["status"] = "deleting"
    _write_config(config)
    logger.info("[desktop:projects] Marked project '%s' as deleting", name)

    # Phase 2: Remove filesystem artifacts
    errors: list[str] = []

    # Drop SurrealDB database (best-effort)
    graph_name = projects_map[name].get("graph_name", name)
    # Validate graph_name to prevent SurrealQL injection
    if not re.fullmatch(r"[a-z0-9_]+", graph_name):
        errors.append(f"Invalid graph name: {graph_name}")
        graph_name = None
    if graph_name:
        try:
            from core.backends.unified_graph.surreal.load import connect as _connect
            from core.paths import default_surreal_url

            db = _connect(
                url=os.environ.get("SURREAL_URL", default_surreal_url()),
                namespace=os.environ.get("SURREAL_NS", "lineage"),
                database="unified",  # connect to any db to issue REMOVE
                username=os.environ.get("SURREAL_USER", ""),
                password=os.environ.get("SURREAL_PASSWORD", ""),
            )
            db.query(f"REMOVE DATABASE IF EXISTS `{graph_name}`;")
            logger.info("[desktop:projects] Dropped SurrealDB database: %s", graph_name)
        except Exception as exc:
            errors.append(f"SurrealDB drop failed: {exc}")
            logger.warning(
                "[desktop:projects] Failed to drop database '%s': %s", graph_name, exc
            )

    # Remove project directory
    project_dir = projects_dir() / name
    if project_dir.exists():
        try:
            shutil.rmtree(project_dir)
        except Exception as exc:
            errors.append(f"Project dir removal failed: {exc}")

    # Remove profiles
    profile_dir = profiles_dir() / name
    if profile_dir.exists():
        try:
            shutil.rmtree(profile_dir)
        except Exception as exc:
            errors.append(f"Profiles removal failed: {exc}")

    # Phase 3: Remove config entry
    del projects_map[name]
    if config.get("default_project") == name:
        # Switch default to first remaining project, or None
        remaining = list(projects_map.keys())
        config["default_project"] = remaining[0] if remaining else None
    _write_config(config)

    logger.info("[desktop:projects] Deleted project '%s'", name)

    if errors:
        return {
            "message": f"Project '{name}' deleted with warnings",
            "warnings": errors,
        }
    return {"message": f"Project '{name}' deleted"}


@router.post("/switch/{name}")
async def switch_project(name: str, request: Request):
    """Switch the active project by updating the config default; returns restart_required so the frontend can restart the backend."""
    config = _read_config()
    projects_map = config.get("projects", {})

    if name not in projects_map:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")

    proj = projects_map[name]

    # Update default_project in config
    config["default_project"] = name
    _write_config(config)

    graph_name = proj.get("graph_name", name)

    # Hot-swap the in-memory config so subsequent requests (before any
    # backend restart) resolve to the new project's graph immediately.
    _hot_swap_default_project(request, name)

    return {
        "message": f"Switched to project '{name}'",
        "graph_name": graph_name,
        "restart_required": True,
    }


def _hot_swap_default_project(request: Request, name: str) -> None:
    """Reload runtime config after a project switch and clear the reader cache.

    Ensures the next request resolves the new project's graph/root even when
    the in-memory config was loaded before that project existed.
    """
    from core.backends.config import UnifiedConfig

    state = getattr(request.app.state, "app_state", None)
    try:
        refreshed = UnifiedConfig.from_yaml(config_path())
    except (FileNotFoundError, ValueError, ValidationError) as exc:
        logger.warning(
            "[desktop:projects] Failed to reload config during project switch; "
            "falling back to in-memory default_project update: %s",
            exc,
        )
        refreshed = None

    if refreshed is not None:
        if state is not None and getattr(state, "config", None) is not None:
            state.config = refreshed
        request.app.state.unified_config = refreshed
    else:
        if state is not None and getattr(state, "config", None) is not None:
            state.config.default_project = name
        ucfg = getattr(request.app.state, "unified_config", None)
        if ucfg is not None:
            ucfg.default_project = name

    # Clear the reader cache — stale readers point at the old project's DB.
    if hasattr(request.app.state, "desktop_reader_cache"):
        request.app.state.desktop_reader_cache = {}


def _get_unified_reader(request: Request):
    """Extract the unified reader from app state."""
    state = getattr(request.app.state, "app_state", None)
    if state is not None and getattr(state, "unified_reader", None) is not None:
        return state.unified_reader
    return getattr(request.app.state, "standalone_unified_reader", None)
