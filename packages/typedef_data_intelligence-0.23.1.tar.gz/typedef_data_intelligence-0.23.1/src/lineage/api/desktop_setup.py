"""Desktop project setup routes.

Wizard flow endpoints: validate project name, clone repository, discover
sub-projects, test data backend connection, and create project configuration.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import stat
import tempfile
import uuid
from pathlib import Path
from typing import Any, AsyncGenerator, Literal

from agent.api import shutdown_event
from core.backends.keychain_http import KeychainHTTPError
from core.paths import (
    config_path,
    default_surreal_url,
    ensure_home,
    env_path,
    profiles_dir,
    projects_dir,
    typedef_home,
)
from fastapi import APIRouter, HTTPException, Request
from ingest.static_loaders.salesforce.factory import SfAuthMode
from pydantic import BaseModel, Field
from starlette.responses import StreamingResponse

logger = logging.getLogger(__name__)


def _sse_event(event_type: str, data: dict) -> str:
    """Format a single SSE event as a string."""
    return f"event: {event_type}\ndata: {json.dumps(data)}\n\n"


def _keychain_save_failed_event(integration: str, exc: Exception) -> str:
    """SSE error for an OAuth token-persistence failure on the keychain bridge."""
    logger.error("%s token persistence failed: %s", integration, exc)
    return _sse_event(
        "error",
        {
            "message": (
                f"Couldn't save {integration} credentials. "
                "Try restarting the desktop app."
            )
        },
    )


router = APIRouter(prefix="/desktop/setup", tags=["desktop-setup"])

# Credential reload router — mounted at /desktop (not /desktop/setup)
# so it matches the path the Rust side calls.
credentials_router = APIRouter(prefix="/desktop", tags=["desktop-credentials"])


# Must stay in sync with SECRET_FIELDS in services/desktop/src-tauri/src/keychain.rs
# and ENV_TO_API_FIELD in services/desktop/src/lib/keychain.ts.
_ALLOWED_CREDENTIAL_KEYS = frozenset(
    {
        "ANTHROPIC_API_KEY",
        # TD-2955: see keychain.rs SECRET_FIELDS for why the *_BASE_URL
        # entries ride this pipeline.
        "ANTHROPIC_BASE_URL",
        "OPENAI_API_KEY",
        "OPENAI_BASE_URL",
        "LOGFIRE_TOKEN",
        "LINEAR_ANALYST_API_KEY",
        "LINEAR_DATA_ENGINEER_API_KEY",
        "FIVETRAN_API_KEY",
        "FIVETRAN_API_SECRET",
        "SF_PASSWORD",
        "SF_SECURITY_TOKEN",
        "SF_CLIENT_SECRET",
        "SNOWFLAKE_PAT_TOKEN",
        # Databricks PAT (TD-2734). OAuth U2M tokens go through
        # DatabricksU2MTokenStore (per-host blob), not this hot-reload
        # endpoint — adding DATABRICKS_OAUTH_U2M_TOKEN here would create
        # an unaudited second persistence path.
        "DATABRICKS_TOKEN",
    }
)


def _require_session_token(req: Request) -> None:
    """Validate the session token on desktop-only endpoints."""
    expected = os.environ.get("TYPEDEF_SESSION_TOKEN")
    if not expected:
        return  # No token configured (e.g. browser-only dev mode)
    auth = req.headers.get("authorization", "")
    if auth != f"Bearer {expected}":
        raise HTTPException(status_code=401, detail="Unauthorized")


@credentials_router.post("/reload-credentials")
async def reload_credentials(req: Request):
    """Hot-reload credentials into os.environ. Called by Tauri after keychain writes."""
    _require_session_token(req)
    body = await req.json()
    if not isinstance(body, dict):
        raise HTTPException(
            status_code=400, detail="Request body must be a JSON object"
        )
    count = 0
    for key, value in body.items():
        if key not in _ALLOWED_CREDENTIAL_KEYS:
            continue
        if value:
            if not isinstance(value, str):
                continue
            os.environ[key] = value
        else:
            os.environ.pop(key, None)
        count += 1
    return {"message": "Credentials reloaded", "count": count}


# ── Telemetry preference helpers ─────────────────────────────────────


def _read_telemetry_prefs() -> dict:
    """Read telemetry preferences from TYPEDEF_HOME/preferences.json."""
    path = typedef_home() / "preferences.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_telemetry_prefs(prefs: dict) -> None:
    """Write telemetry preferences to TYPEDEF_HOME/preferences.json atomically."""
    path = typedef_home() / "preferences.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(".json.tmp")
    tmp_path.write_text(json.dumps(prefs, indent=2))
    os.replace(str(tmp_path), str(path))


@credentials_router.get("/telemetry-status")
async def get_telemetry_status(req: Request):
    """Return current telemetry state: active (token present), opted_out, acknowledged."""
    _require_session_token(req)
    prefs = _read_telemetry_prefs()
    return {
        "active": bool(os.getenv("LOGFIRE_TOKEN")),
        "opted_out": prefs.get("telemetry_opted_out", False),
        "acknowledged": prefs.get("telemetry_acknowledged", False),
    }


@credentials_router.post("/telemetry-preference")
async def set_telemetry_preference(req: Request):
    """Update telemetry opt-out and/or acknowledgment preferences."""
    _require_session_token(req)
    body = await req.json()
    if not isinstance(body, dict):
        raise HTTPException(
            status_code=400, detail="Request body must be a JSON object"
        )
    prefs = _read_telemetry_prefs()
    if "opted_out" in body:
        prefs["telemetry_opted_out"] = bool(body["opted_out"])
    if "acknowledged" in body:
        prefs["telemetry_acknowledged"] = bool(body["acknowledged"])
    _write_telemetry_prefs(prefs)
    return {"ok": True}


# ── In-memory clone operation registry ────────────────────────────────
# Maps clone_id → {"status": ..., "dest": Path, "error": str | None}
_clone_ops: dict[str, dict[str, Any]] = {}

# ── In-memory Salesforce OAuth flow registry ─────────────────────────
# Maps flow_id → {"status": ..., "server": HTTPServer, ...}
_sf_oauth_flows: dict[str, dict[str, Any]] = {}

# ── In-memory Linear OAuth flow registry ─────────────────────────────
# Maps flow_id → {"status": ..., "server": HTTPServer, ...}
_linear_oauth_flows: dict[str, dict[str, Any]] = {}


# ── Request/response models ───────────────────────────────────────────


class ValidateProjectRequest(BaseModel):
    """Request to validate and sanitize a project name."""

    name: str = Field(..., min_length=1, max_length=64)


class ValidateProjectResponse(BaseModel):
    """Result of project name validation."""

    valid: bool
    sanitized_name: str
    reason: str | None = None


class CloneRequest(BaseModel):
    """Request to clone a git repository for a project."""

    git_url: str
    project_name: str


class CloneResponse(BaseModel):
    """Response containing the clone operation identifier."""

    clone_id: str


class SubprojectsResponse(BaseModel):
    """Discovered dbt sub-projects within a cloned repository."""

    paths: list[str]
    auto_selected: str | None = None


class TestConnectionRequest(BaseModel):
    """Credentials to test a data backend connection."""

    backend_type: Literal["snowflake", "duckdb", "databricks"]
    # Snowflake fields
    account: str | None = None
    user: str | None = None
    role: str | None = None
    warehouse: str | None = None
    auth_method: Literal["private_key", "pat"] = "private_key"
    private_key_path: str | None = None
    pat_token: str | None = None
    # DuckDB fields
    db_path: str | None = None
    # Databricks fields (TD-2734)
    databricks_host: str | None = None
    databricks_http_path: str | None = None
    databricks_warehouse_id: str | None = None
    databricks_catalog: str | None = None
    databricks_auth_method: Literal["pat", "oauth_u2m"] = "pat"
    databricks_pat_token: str | None = None
    databricks_oauth_u2m_token: str | None = None


class TestConnectionResponse(BaseModel):
    """Result of a backend connection test, with optional metadata."""

    success: bool
    message: str
    # Metadata auto-fill (cherry-pick: connection returns warehouse metadata)
    databases: list[str] | None = None
    warehouses: list[str] | None = None
    schemas: list[str] | None = None


class CreateProjectRequest(BaseModel):
    """Wizard payload for creating a new project configuration."""

    name: str
    git_url: str
    sub_project: str | None = None
    backend: Literal["snowflake", "duckdb", "databricks"]
    # Snowflake
    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_role: str | None = None
    snowflake_warehouse: str | None = None
    snowflake_auth_method: Literal["private_key", "pat"] = "private_key"
    snowflake_private_key_path: str | None = None
    # Only set in browser-only dev mode; Tauri persists PAT in the keychain
    # and delivers it via SNOWFLAKE_PAT_TOKEN env var.
    snowflake_pat_token: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = "PUBLIC"
    allowed_databases: list[str] | None = None
    dbt_target: str | None = "prod"
    profile_name: str | None = None
    # DuckDB
    duckdb_path: str | None = None
    # Databricks (TD-2734)
    databricks_host: str | None = None
    databricks_http_path: str | None = None
    databricks_warehouse_id: str | None = None
    databricks_catalog: str | None = None
    databricks_schema: str | None = "default"
    databricks_auth_method: Literal["pat", "oauth_u2m"] = "pat"
    # Browser-only dev mode fallback; Tauri persists PAT to keychain and
    # delivers it via DATABRICKS_TOKEN env var. OAuth U2M tokens are stored
    # via DatabricksU2MTokenStore — never written to .env.
    databricks_pat_token: str | None = None
    databricks_oauth_u2m_token: str | None = None
    allowed_catalogs: list[str] | None = None
    # Per-project env vars (comma-separated key=val for dbt env_var() references)
    env_vars: str | None = None
    # Integrations (optional)
    salesforce_enabled: bool = False
    salesforce_client_id: str | None = None
    salesforce_login_url: str | None = None
    salesforce_auth_type: SfAuthMode | None = None
    salesforce_instance_url: str | None = None
    salesforce_username: str | None = None
    cube_enabled: bool = False
    cube_project_dir: str | None = None
    lookml_enabled: bool = False
    lookml_project_dir: str | None = None
    fivetran_enabled: bool = False
    fivetran_connector_ids: list[str] | None = None
    linear_enabled: bool = False
    linear_team_id: str | None = None
    # Profiling
    profiling_enabled: bool = True
    # Secret fields — used by browser-only dev mode (.env fallback).
    # In Tauri mode, secrets go to OS keychain and never reach this endpoint.
    linear_analyst_api_key: str | None = None
    linear_data_engineer_api_key: str | None = None
    anthropic_api_key: str | None = None
    openai_api_key: str | None = None
    logfire_api_key: str | None = None


class CreateProjectResponse(BaseModel):
    """Response after successfully creating a project."""

    name: str
    config_path: str
    message: str


class PreflightCheckRequest(BaseModel):
    """Preflight check: run dbt deps + docs generate before createProject().

    Accepts the same warehouse credential fields as CreateProjectRequest
    so ``_build_profiles_yml`` can be reused directly.
    """

    project_name: str  # sanitized project name → projects_dir() / name
    sub_project: str | None = None
    backend: Literal["snowflake", "duckdb", "databricks"]
    # Snowflake
    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_role: str | None = None
    snowflake_warehouse: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = "PUBLIC"
    snowflake_auth_method: Literal["private_key", "pat"] = "private_key"
    snowflake_private_key_path: str | None = None
    snowflake_pat_token: str | None = None
    # DuckDB
    duckdb_path: str | None = None
    # Databricks
    databricks_host: str | None = None
    databricks_http_path: str | None = None
    databricks_catalog: str | None = None
    databricks_schema: str | None = "default"
    databricks_auth_method: Literal["pat", "oauth_u2m"] = "pat"
    databricks_pat_token: str | None = None
    # Shared
    dbt_target: str | None = "prod"
    profile_name: str | None = None
    env_vars: str | None = None


# ── Helpers ───────────────────────────────────────────────────────────


def _sanitize_project_name(name: str) -> str:
    """Sanitize a project name for filesystem and SurrealDB database use."""
    sanitized = re.sub(r"[^a-z0-9_]", "_", name.lower()).strip("_")
    # Collapse multiple underscores
    sanitized = re.sub(r"_+", "_", sanitized)
    return sanitized[:64]


# Databricks workspace host allowlist (TD-2734) — SSRF defense for the
# OAuth U2M flow's HTTPS round-trip and the SQL connector's TLS connection.
# Mirrors `_validate_salesforce_login_url`'s pattern.
_DATABRICKS_HOST_SUFFIXES = (
    ".cloud.databricks.com",   # AWS
    ".gcp.databricks.com",     # GCP
    ".azuredatabricks.net",    # Azure
    ".dev.databricks.com",     # internal dev hosts (rare but legit)
    ".staging.databricks.com",
)


def _normalize_databricks_host(host: str) -> str:
    """Strip protocol/path/query from a workspace host paste.

    Mirrors ``utils/databricks._normalize_host`` so the validator and the
    one-shot helpers agree on the canonical form. Returns the bare hostname
    (no scheme, no trailing slash) ready for allowlist comparison or for
    the SDK constructor.
    """
    if not host:
        raise HTTPException(status_code=400, detail="Databricks host is required")
    cleaned = host.strip()
    for prefix in ("https://", "http://"):
        if cleaned.lower().startswith(prefix):
            cleaned = cleaned[len(prefix):]
            break
    for sep in ("/", "?", "#"):
        idx = cleaned.find(sep)
        if idx != -1:
            cleaned = cleaned[:idx]
    cleaned = cleaned.strip().lower()
    if not cleaned:
        raise HTTPException(
            status_code=400,
            detail=f"Databricks host {host!r} normalized to empty string",
        )
    return cleaned


def _validate_databricks_host(host: str) -> str:
    """Validate a Databricks workspace host against the cloud-host allowlist.

    Returns the normalized hostname (no scheme, no path). Raises ``HTTPException``
    with status 400 on rejection. Defense in depth — the OAuth flow and the
    SQL connector also validate, but rejecting at the request boundary
    surfaces misuse with a clear error.
    """
    normalized = _normalize_databricks_host(host)
    # Strip port for allowlist comparison (e.g. "host:8080") — Databricks
    # production workspaces never use a non-default port, but local dev
    # modes (tunnels, recorded fixtures) sometimes do. Comparing the
    # port-stripped form against the suffix list means a paste of
    # "dbc-...cloud.databricks.com:443" still passes; the localhost
    # branch below handles the dev-mode case under an explicit opt-in.
    host_only = normalized.split(":", 1)[0]
    if host_only in {"localhost", "127.0.0.1"}:
        # Loopback is opt-in only. This validator is the request-boundary
        # SSRF defense; silently permitting localhost would let any
        # non-desktop deployment (e.g. shared/hosted backend) be coerced
        # into hitting loopback services. Gate behind TYPEDEF_DEV_MODE=1
        # (the codebase's existing dev-only relaxation flag — see
        # llm-proxy/auth_service.py and docker-compose.yml).
        if os.getenv("TYPEDEF_DEV_MODE") == "1":
            return normalized
        raise HTTPException(
            status_code=400,
            detail=(
                f"Loopback Databricks host {host_only!r} is not allowed "
                "unless TYPEDEF_DEV_MODE=1 (desktop/dev only)."
            ),
        )
    for suffix in _DATABRICKS_HOST_SUFFIXES:
        if host_only.endswith(suffix):
            return normalized
    raise HTTPException(
        status_code=400,
        detail=(
            f"Unrecognized Databricks workspace host: {host_only}. "
            f"Expected one of {', '.join(_DATABRICKS_HOST_SUFFIXES)}."
        ),
    )


def _write_env_file(path: Path, entries: dict[str, str]) -> None:
    """Write a .env file atomically with 0600 permissions."""
    content = "\n".join(f"{k}={v}" for k, v in entries.items() if v) + "\n"
    tmp_path = path.with_suffix(".env.tmp")
    # Write with restricted permissions from the start (no TOCTOU race)
    fd = os.open(
        str(tmp_path),
        os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
        stat.S_IRUSR | stat.S_IWUSR,
    )
    with os.fdopen(fd, "w") as f:
        f.write(content)
    os.rename(str(tmp_path), str(path))


def _write_config_atomic(path: Path, content: str) -> None:
    """Write a config file atomically via temp-file-then-rename."""
    tmp_path = path.with_suffix(".yaml.tmp")
    tmp_path.write_text(content)
    os.rename(str(tmp_path), str(path))


# ── Endpoints ─────────────────────────────────────────────────────────


@router.get("/env-defaults")
async def env_defaults():
    """Return Snowflake/Databricks/dbt env vars that are currently set.

    Used by the wizard's "Load from Environment" buttons.
    """
    env_keys = [
        "SNOWFLAKE_ACCOUNT",
        "SNOWFLAKE_USER",
        "SNOWFLAKE_ROLE",
        "SNOWFLAKE_WAREHOUSE",
        "SNOWFLAKE_PRIVATE_KEY_PATH",
        "SNOWFLAKE_PAT_TOKEN",
        # Databricks (TD-2734)
        "DATABRICKS_HOST",
        "DATABRICKS_TOKEN",
        "DATABRICKS_HTTP_PATH",
        "DATABRICKS_WAREHOUSE_ID",
        "DATABRICKS_CATALOG",
        "DBT_TARGET",
        "ANTHROPIC_API_KEY",
        "ANTHROPIC_BASE_URL",
        "OPENAI_API_KEY",
        "OPENAI_BASE_URL",
        "LOGFIRE_TOKEN",
        # Integration secrets — reported as present/absent for placeholder UI
        "SF_PASSWORD",
        "SF_SECURITY_TOKEN",
        "SF_CLIENT_SECRET",
        "FIVETRAN_API_KEY",
        "FIVETRAN_API_SECRET",
        "LINEAR_ANALYST_API_KEY",
        "LINEAR_DATA_ENGINEER_API_KEY",
    ]
    return {k: v for k in env_keys if (v := os.environ.get(k))}


@router.post("/validate-project", response_model=ValidateProjectResponse)
async def validate_project(req: ValidateProjectRequest):
    """Validate and sanitize a project name. Check for uniqueness."""
    sanitized = _sanitize_project_name(req.name)
    if not sanitized:
        return ValidateProjectResponse(
            valid=False,
            sanitized_name="",
            reason="Name must contain alphanumeric characters",
        )

    # Check if project directory already exists
    project_dir = projects_dir() / sanitized
    if project_dir.exists():
        return ValidateProjectResponse(
            valid=False,
            sanitized_name=sanitized,
            reason=f"Project '{sanitized}' already exists",
        )

    return ValidateProjectResponse(valid=True, sanitized_name=sanitized)


@router.post("/clone", response_model=CloneResponse)
async def start_clone(req: CloneRequest):
    """Start a git clone operation. Returns a clone_id for progress tracking."""
    from lineage.utils.git import is_valid_git_url

    if not is_valid_git_url(req.git_url):
        raise HTTPException(status_code=400, detail="Invalid git URL")

    sanitized = _sanitize_project_name(req.project_name)
    dest = projects_dir() / sanitized
    if dest.exists() and any(dest.iterdir()):
        raise HTTPException(
            status_code=409, detail=f"Project directory already exists: {sanitized}"
        )

    clone_id = str(uuid.uuid4())
    _clone_ops[clone_id] = {
        "status": "pending",
        "dest": dest,
        "url": req.git_url,
        "error": None,
    }

    # Spawn clone in background
    asyncio.create_task(_run_clone(clone_id, req.git_url, dest))

    return CloneResponse(clone_id=clone_id)


async def _run_clone(clone_id: str, url: str, dest: Path) -> None:
    """Background task that runs the clone and updates the operation registry."""
    from lineage.utils.git import clone_repo_with_progress

    _clone_ops[clone_id]["status"] = "running"
    try:
        async for progress in clone_repo_with_progress(url, dest):
            _clone_ops[clone_id]["last_progress"] = progress
            if progress.phase == "error":
                _clone_ops[clone_id]["status"] = "error"
                _clone_ops[clone_id]["error"] = progress.message
                return
        _clone_ops[clone_id]["status"] = "complete"
    except Exception as exc:
        _clone_ops[clone_id]["status"] = "error"
        _clone_ops[clone_id]["error"] = str(exc)


@router.get("/clone/{clone_id}/progress")
async def clone_progress(clone_id: str):
    """SSE stream for clone progress. Polls the in-memory operation registry."""
    if clone_id not in _clone_ops:
        raise HTTPException(
            status_code=404, detail=f"Clone operation '{clone_id}' not found"
        )

    async def generate():
        last_emitted = None
        while not shutdown_event.is_set():
            op = _clone_ops.get(clone_id)
            if not op:
                break

            status = op["status"]
            progress = op.get("last_progress")

            if progress and progress != last_emitted:
                yield _sse_event(
                    "progress",
                    {
                        "phase": progress.phase,
                        "percent": progress.percent,
                        "message": progress.message,
                    },
                )
                last_emitted = progress

            if status == "complete":
                yield _sse_event("done", {"phase": "done", "percent": 100})
                # Don't pop here — fetchSubprojects needs the entry.
                # Cleaned up by get_subprojects or on error.
                break
            elif status == "error":
                yield _sse_event(
                    "error",
                    {
                        "phase": "error",
                        "message": op.get("error", "Unknown error"),
                    },
                )
                _clone_ops.pop(clone_id, None)
                break

            await asyncio.sleep(0.5)

    return StreamingResponse(generate(), media_type="text/event-stream")


@router.get("/subprojects/{clone_id}", response_model=SubprojectsResponse)
async def get_subprojects(clone_id: str):
    """Scan a cloned repo for dbt_project.yml files. Auto-selects if exactly one."""
    op = _clone_ops.get(clone_id)
    if not op:
        raise HTTPException(
            status_code=404, detail=f"Clone operation '{clone_id}' not found"
        )
    if op["status"] != "complete":
        raise HTTPException(status_code=409, detail="Clone not yet complete")

    dest = op["dest"]
    # Find all dbt_project.yml files
    dbt_files = list(dest.rglob("dbt_project.yml"))
    paths = [str(f.parent.relative_to(dest)) for f in dbt_files]

    # Cherry-pick: auto-select if exactly one
    auto_selected = paths[0] if len(paths) == 1 else None

    # Clean up the in-memory clone registry now that subprojects have been read
    _clone_ops.pop(clone_id, None)

    return SubprojectsResponse(paths=paths, auto_selected=auto_selected)


@router.post("/test-connection", response_model=TestConnectionResponse)
async def test_connection(req: TestConnectionRequest):
    """Test data backend credentials. Returns metadata on success (cherry-pick)."""
    if req.backend_type == "duckdb":
        if not req.db_path:
            return TestConnectionResponse(
                success=True, message="In-memory DuckDB (no file path)"
            )
        db_path = Path(req.db_path).expanduser()
        if db_path.suffix not in (".db", ".duckdb", ""):
            return TestConnectionResponse(
                success=False, message="Invalid DuckDB file extension"
            )
        return TestConnectionResponse(success=True, message="DuckDB path is valid")

    if req.backend_type == "databricks":
        return await _test_databricks_connection(req)

    # Snowflake
    if not req.account or not req.user:
        return TestConnectionResponse(
            success=False, message="Account and user are required"
        )

    resolved_key_path: str | None = None
    pat_token: str | None = None
    if req.auth_method == "private_key":
        if not req.private_key_path:
            return TestConnectionResponse(
                success=False, message="Private key path is required"
            )
        key_path = Path(req.private_key_path).expanduser()
        if not key_path.exists():
            return TestConnectionResponse(
                success=False, message=f"Private key file not found: {key_path}"
            )
        resolved_key_path = str(key_path)
    else:
        # Load .env so browser-dev mode (where PAT lives only in
        # ~/.typedef-desktop/.env until the next backend restart) can resolve
        # the saved token when the UI leaves the PAT field blank.
        from lineage.utils.env import load_env_file

        load_env_file()
        pat_token = req.pat_token or os.environ.get("SNOWFLAKE_PAT_TOKEN")
        if not pat_token:
            return TestConnectionResponse(
                success=False,
                message="PAT token is required when auth_method='pat'",
            )

    try:
        from lineage.utils.snowflake import list_snowflake_databases

        databases = list_snowflake_databases(
            account=req.account,
            user=req.user,
            warehouse=req.warehouse,
            role=req.role,
            auth_method=req.auth_method,
            private_key_path=resolved_key_path,
            pat_token=pat_token,
        )

        return TestConnectionResponse(
            success=True,
            message="Connected successfully",
            databases=databases or None,
        )

    except ImportError:
        return TestConnectionResponse(
            success=False,
            message="snowflake-connector-python not installed",
        )
    except Exception as exc:
        return TestConnectionResponse(success=False, message=str(exc))


# ── Databricks endpoints (TD-2734) ────────────────────────────────────

# Cold-start ceiling for the rich Phase A probe. SQL Warehouses on demand
# can take 60–120s to wake; bound the wizard's wait at 90s so the user sees
# a "Warehouse is starting" message rather than an apparent hang.
_DATABRICKS_TEST_CONNECTION_TIMEOUT_S = 90.0


def _load_databricks_oauth_env_for_project(project: dict) -> dict[str, str]:
    """Resolve the DATABRICKS_TOKEN env value for a Databricks OAuth U2M project.

    Returns ``{}`` for non-Databricks projects, PAT projects (which already
    have the token in ``.env`` or ``os.environ`` via the keychain bridge),
    or projects whose stored OAuth token is missing.

    Token expiry is not handled here — the connector surfaces a 401 from
    the Databricks API which becomes a normal sync error. Refresh-token
    UX is a follow-up.

    Both ``start_preflight`` (dbt subprocess env) and ``_sync_worker``
    (parent-process os.environ for ``UnifiedPipelineConfig`` construction)
    call this so the same resolution runs in both code paths.
    """
    data = project.get("data") or {}
    if str(data.get("backend") or "").lower() != "databricks":
        return {}
    auth = data.get("auth") or {}
    if not isinstance(auth, dict) or auth.get("auth_method") != "oauth_u2m":
        return {}
    host = data.get("host")
    if not host:
        return {}
    try:
        from lineage.utils.databricks_oauth import DatabricksU2MTokenStore

        stored = DatabricksU2MTokenStore(str(host)).load()
        if stored and stored.access_token:
            return {"DATABRICKS_TOKEN": stored.access_token}
    except Exception:  # noqa: BLE001
        logger.debug(
            "Could not load Databricks U2M token for project (host=%s)",
            host,
            exc_info=True,
        )
    return {}


def _load_databricks_oauth_token(host: str | None) -> str | None:
    """Look up a stored OAuth U2M token for a given workspace host.

    The wizard's OAuth flow (U3) persists the token to a per-host keychain
    blob via :class:`DatabricksU2MTokenStore`. The wizard UI never holds
    the access-token string itself — it only knows the
    ``databricksOAuthU2MTokenCaptured`` flag. So the test-connection /
    list-* endpoints must consult the store directly when the request
    arrives with ``auth_method='oauth_u2m'`` but no token in the payload.

    Returns ``None`` if no token is stored, the host is missing, or the
    store layer raises (logged at DEBUG so transient keychain failures
    don't break the wizard).
    """
    if not host:
        return None
    try:
        from lineage.utils.databricks_oauth import DatabricksU2MTokenStore

        stored = DatabricksU2MTokenStore(host).load()
        return stored.access_token if stored else None
    except Exception:  # noqa: BLE001
        logger.debug(
            "Could not load Databricks U2M token for host %s",
            host,
            exc_info=True,
        )
        return None


def _resolve_databricks_token(req: TestConnectionRequest) -> tuple[str, str]:
    """Resolve the active auth method + token from a TestConnectionRequest.

    For PAT: falls back to ``DATABRICKS_TOKEN`` env when
    ``databricks_pat_token`` is blank — mirrors the Snowflake
    env-fallback path so browser-only dev mode can resolve a saved PAT.

    For OAuth U2M: falls back to the per-host keychain blob populated by
    the wizard's OAuth flow when ``databricks_oauth_u2m_token`` is blank
    — the wizard UI never carries the token in component state.

    Returns:
        tuple: (auth_method, token)

    Raises:
        HTTPException: 400 when no token is available.
    """
    if req.databricks_auth_method == "oauth_u2m":
        token = req.databricks_oauth_u2m_token or _load_databricks_oauth_token(
            req.databricks_host
        )
        if not token:
            raise HTTPException(
                status_code=400,
                detail=(
                    "OAuth U2M token is required when databricks_auth_method='oauth_u2m'. "
                    "Complete the browser flow first."
                ),
            )
        return "oauth_u2m", token

    # Default: PAT
    from lineage.utils.env import load_env_file

    load_env_file()
    token = req.databricks_pat_token or os.environ.get("DATABRICKS_TOKEN")
    if not token:
        raise HTTPException(
            status_code=400,
            detail="Databricks PAT is required (or set DATABRICKS_TOKEN in env).",
        )
    return "pat", token


def _build_databricks_data_config(
    req: TestConnectionRequest, normalized_host: str
) -> Any:
    """Build a DatabricksDataConfig from the wizard's test-connection request.

    Returns the config object ready to construct ``DatabricksDataQueryBackend``.
    Raises ``HTTPException`` on validation errors (cluster path, missing
    catalog, etc.).
    """
    from core.backends.config import (
        DatabricksDataConfig,
        DatabricksOAuthU2MAuth,
        DatabricksPatAuth,
    )
    from pydantic import ValidationError

    if not req.databricks_http_path:
        raise HTTPException(
            status_code=400, detail="Databricks http_path is required"
        )
    if not req.databricks_catalog:
        raise HTTPException(
            status_code=400, detail="Databricks catalog is required"
        )

    auth_method, token = _resolve_databricks_token(req)
    if auth_method == "oauth_u2m":
        auth: Any = DatabricksOAuthU2MAuth(token=token)
    else:
        auth = DatabricksPatAuth(token=token)

    try:
        return DatabricksDataConfig(
            host=normalized_host,
            http_path=req.databricks_http_path,
            warehouse_id=req.databricks_warehouse_id,
            catalog=req.databricks_catalog,
            auth=auth,
        )
    except ValidationError as exc:
        # Surface the most useful error from Pydantic (typically the
        # cluster-path validator firing) as a 400.
        first_err = exc.errors()[0] if exc.errors() else {"msg": str(exc)}
        raise HTTPException(status_code=400, detail=first_err.get("msg", str(exc))) from exc


async def _test_databricks_connection(
    req: TestConnectionRequest,
) -> TestConnectionResponse:
    """Run the Phase A backend's typed probe for the wizard.

    Surfaces ``DatabricksConnectionProbe.warnings`` into ``message`` so the
    privilege-degradation banner has copy to render. ``mode='degraded'``
    returns ``success=True`` (degraded != failure) — the wizard treats
    this as a non-blocking warning.
    """
    from core.backends.data_query.databricks_backend import (
        DatabricksClusterPathError,
        DatabricksDataQueryBackend,
    )

    if not req.databricks_host:
        raise HTTPException(
            status_code=400, detail="Databricks workspace host is required"
        )

    normalized_host = _validate_databricks_host(req.databricks_host)

    try:
        config = _build_databricks_data_config(req, normalized_host)
    except HTTPException:
        raise
    except Exception as exc:
        return TestConnectionResponse(success=False, message=str(exc))

    try:
        async with DatabricksDataQueryBackend(config) as backend:
            try:
                probe = await asyncio.wait_for(
                    backend.test_connection(),
                    timeout=_DATABRICKS_TEST_CONNECTION_TIMEOUT_S,
                )
            except asyncio.TimeoutError:
                return TestConnectionResponse(
                    success=False,
                    message=(
                        "Warehouse is starting — this may take up to 90 seconds. "
                        "Try Test Connection again in a moment."
                    ),
                )
    except DatabricksClusterPathError as exc:
        # Defense in depth — config validator should have caught this, but
        # the backend re-checks at probe time. Surface as 400.
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        # Connection failures (network, auth) — surface as success=False
        # rather than 500 so the wizard banner renders.
        return TestConnectionResponse(success=False, message=str(exc))

    if not probe.ok:
        return TestConnectionResponse(
            success=False,
            message="; ".join(probe.warnings) or "Connection probe failed",
        )

    # Degraded != failure; surface warnings inline so the wizard banner has copy.
    if probe.mode == "degraded" and probe.warnings:
        message = "Connected (degraded): " + "; ".join(probe.warnings)
    else:
        message = "Connected successfully"
    return TestConnectionResponse(success=True, message=message)


class ListDatabricksWarehousesRequest(BaseModel):
    """Auth + host for listing SQL Warehouses."""

    host: str
    auth_method: Literal["pat", "oauth_u2m"] = "pat"
    pat_token: str | None = None
    oauth_u2m_token: str | None = None


@router.post("/list-warehouses")
async def list_warehouses(req: ListDatabricksWarehousesRequest):
    """List Databricks SQL Warehouses for the wizard's warehouse dropdown."""
    from lineage.utils.databricks import list_databricks_warehouses

    normalized_host = _validate_databricks_host(req.host)

    if req.auth_method == "oauth_u2m":
        # Token may come from the request OR from the per-host keychain
        # blob the wizard's OAuth flow wrote — the wizard UI never holds
        # the token string in component state.
        oauth = req.oauth_u2m_token or _load_databricks_oauth_token(
            normalized_host
        )
        if not oauth:
            raise HTTPException(
                status_code=400,
                detail=(
                    "OAuth U2M token is required. Complete the browser "
                    "flow first."
                ),
            )
        pat = None
    else:
        from lineage.utils.env import load_env_file

        load_env_file()
        pat = req.pat_token or os.environ.get("DATABRICKS_TOKEN")
        if not pat:
            raise HTTPException(
                status_code=400,
                detail="Databricks PAT is required (or set DATABRICKS_TOKEN in env).",
            )
        oauth = None

    try:
        warehouses = await asyncio.to_thread(
            list_databricks_warehouses,
            host=normalized_host,
            pat_token=pat,
            oauth_token=oauth,
        )
        return {"warehouses": warehouses}
    except ImportError as exc:
        raise HTTPException(
            status_code=500, detail="databricks-sdk not installed"
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


class ListDatabricksCatalogsRequest(BaseModel):
    """Auth + host + http_path for listing UC catalogs."""

    host: str
    http_path: str
    auth_method: Literal["pat", "oauth_u2m"] = "pat"
    pat_token: str | None = None
    oauth_u2m_token: str | None = None


@router.post("/list-catalogs")
async def list_catalogs(req: ListDatabricksCatalogsRequest):
    """List Unity Catalog catalogs for the wizard's catalog dropdown."""
    from lineage.utils.databricks import list_databricks_catalogs

    normalized_host = _validate_databricks_host(req.host)

    if req.auth_method == "oauth_u2m":
        oauth = req.oauth_u2m_token or _load_databricks_oauth_token(
            normalized_host
        )
        if not oauth:
            raise HTTPException(
                status_code=400,
                detail=(
                    "OAuth U2M token is required. Complete the browser "
                    "flow first."
                ),
            )
        pat = None
    else:
        from lineage.utils.env import load_env_file

        load_env_file()
        pat = req.pat_token or os.environ.get("DATABRICKS_TOKEN")
        if not pat:
            raise HTTPException(
                status_code=400,
                detail="Databricks PAT is required (or set DATABRICKS_TOKEN in env).",
            )
        oauth = None

    try:
        catalogs = await asyncio.to_thread(
            list_databricks_catalogs,
            host=normalized_host,
            http_path=req.http_path,
            pat_token=pat,
            oauth_token=oauth,
        )
        return {"catalogs": catalogs}
    except ValueError as exc:
        # Cluster-path rejection from utils/databricks
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ImportError as exc:
        raise HTTPException(
            status_code=500, detail="databricks-sql-connector not installed"
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


# ── Databricks OAuth U2M PKCE flow (TD-2734 U3) ──────────────────────


class _DatabricksCallbackHandler:
    """Class-level state for the Databricks OAuth U2M loopback server.

    Mirrors :class:`_LinearCallbackHandler`. Cleared at the start of each
    new flow so a stale callback can't hijack a fresh authorization.
    """

    auth_code: str | None = None
    error: str | None = None
    callback_state: str | None = None


_DATABRICKS_CALLBACK_PORT = 8445


def _resolve_databricks_callback_port() -> int:
    """Honor ``DATABRICKS_CALLBACK_PORT`` env override; fall back to 8445."""
    override = os.getenv("DATABRICKS_CALLBACK_PORT")
    if not override:
        return _DATABRICKS_CALLBACK_PORT
    try:
        port = int(override)
        if not 1 <= port <= 65535:
            raise ValueError("port out of range")
        return port
    except ValueError:
        logger.warning(
            "Invalid DATABRICKS_CALLBACK_PORT=%r; falling back to default %s",
            override,
            _DATABRICKS_CALLBACK_PORT,
        )
        return _DATABRICKS_CALLBACK_PORT


def _start_databricks_callback_server(port: int) -> Any:
    """Start a minimal HTTP server to receive the Databricks OAuth callback.

    Mirrors :func:`_start_linear_callback_server` exactly — same handler
    shape, same threading model. The server handles a single request
    and stops.
    """
    import html as html_mod
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import parse_qs, urlparse

    _DatabricksCallbackHandler.auth_code = None
    _DatabricksCallbackHandler.error = None
    _DatabricksCallbackHandler.callback_state = None

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)

            if "error" in params:
                _DatabricksCallbackHandler.error = params["error"][0]
                desc = params.get("error_description", [""])[0]
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                err = html_mod.escape(_DatabricksCallbackHandler.error or "")
                self.wfile.write(
                    f"<html><body><h2>Authentication failed</h2>"
                    f"<p>Error: {err}</p>"
                    f"<p>{html_mod.escape(desc)}</p></body></html>".encode()
                )
                return

            code = params.get("code", [None])[0]
            state = params.get("state", [None])[0]
            if code:
                _DatabricksCallbackHandler.auth_code = code
                _DatabricksCallbackHandler.callback_state = state
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body><h2>Connected to Databricks</h2>"
                    b"<p>You can close this window and return to the app."
                    b"</p></body></html>"
                )
            else:
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body>Missing code parameter</body></html>"
                )

        def log_message(self, format: str, *args: object) -> None:
            logger.debug(format, *args)

    import threading

    server = HTTPServer(("localhost", port), Handler)
    server.timeout = 120.0

    ready = threading.Event()

    def _serve() -> None:
        ready.set()
        server.handle_request()

    thread = threading.Thread(target=_serve, daemon=True)
    thread.start()
    ready.wait(timeout=5.0)
    return server


# Active OAuth flows keyed by flow_id. Each entry holds the loopback
# server + the consent dict needed to exchange the callback parameters.
_databricks_oauth_flows: dict[str, dict[str, Any]] = {}


class StartDatabricksOAuthU2MRequest(BaseModel):
    """Payload to start a Databricks OAuth U2M flow."""

    host: str


class StartDatabricksOAuthU2MResponse(BaseModel):
    """Response containing the authorize URL and flow identifier."""

    flow_id: str
    authorize_url: str


@router.post(
    "/databricks/start-oauth-u2m",
    response_model=StartDatabricksOAuthU2MResponse,
)
async def start_databricks_oauth_u2m(req: StartDatabricksOAuthU2MRequest):
    """Start a Databricks OAuth U2M PKCE flow.

    Validates the host against the cloud-host allowlist, spawns the
    loopback callback server, runs the SDK's discovery + consent
    initiation in a worker thread (the SDK does a blocking HTTPS GET
    to the workspace's OIDC endpoint), and returns the authorize URL
    for the wizard to open in the user's default browser.
    """
    from lineage.utils.databricks_oauth import initiate_u2m_consent

    normalized_host = _validate_databricks_host(req.host)

    # Close any prior in-flight flow before starting a new one — matches
    # the Linear flow's behavior so a wedged callback server doesn't
    # block the new attempt.
    for fid, flow in list(_databricks_oauth_flows.items()):
        try:
            flow["server"].server_close()
        except Exception:  # noqa: BLE001
            logger.debug(
                "Failed to close stale Databricks OAuth callback server "
                "for flow %s",
                fid,
            )
        _databricks_oauth_flows.pop(fid, None)

    flow_id = str(uuid.uuid4())
    callback_port = _resolve_databricks_callback_port()
    # Bare loopback URI (no path) — Databricks's built-in `databricks-cli`
    # public OAuth client only registers `http://localhost:<port>` shapes,
    # not `.../callback`. RFC 8252 §7.3 allows any loopback port. The SDK's
    # own external-browser flow uses `http://localhost:8020` (see
    # databricks/sdk/credentials_provider.py:225). The callback handler
    # ignores the path anyway — it only reads `code` + `state` from the
    # query string.
    redirect_url = f"http://localhost:{callback_port}"

    try:
        server = _start_databricks_callback_server(callback_port)
    except OSError as exc:
        raise HTTPException(
            status_code=409,
            detail=(
                f"Could not start OAuth callback server on port "
                f"{callback_port}: {exc}"
            ),
        ) from exc

    try:
        # The SDK's `from_host()` does a blocking HTTPS GET to the
        # workspace's OIDC well-known endpoint — must run in a thread.
        consent_dict, authorize_url = await asyncio.to_thread(
            initiate_u2m_consent,
            host=normalized_host,
            redirect_url=redirect_url,
        )
    except ImportError as exc:
        server.server_close()
        raise HTTPException(
            status_code=500, detail="databricks-sdk not installed"
        ) from exc
    except Exception as exc:
        server.server_close()
        # Discovery failures (network, DNS, 404) — surface as 502 so the
        # wizard distinguishes "workspace unreachable" from "wrong
        # token". The host allowlist already filtered obviously bad
        # hosts above.
        raise HTTPException(
            status_code=502,
            detail=(
                f"Could not reach Databricks workspace OIDC endpoint at "
                f"{normalized_host}: {exc}"
            ),
        ) from exc

    _databricks_oauth_flows[flow_id] = {
        "server": server,
        "consent_dict": consent_dict,
        "host": normalized_host,
    }
    return StartDatabricksOAuthU2MResponse(
        flow_id=flow_id, authorize_url=authorize_url
    )


@router.get("/databricks/oauth-status/{flow_id}")
async def databricks_oauth_u2m_status(flow_id: str):
    """SSE stream that polls for the Databricks OAuth callback result.

    Emits ``waiting`` events while the user is in the browser, then a
    ``success`` event once the callback returns and the token exchange
    completes (token persisted to the per-host keychain blob). Times
    out at 120s.
    """
    if flow_id not in _databricks_oauth_flows:
        raise HTTPException(status_code=404, detail="OAuth flow not found")

    async def generate():
        import time

        from lineage.utils.databricks_oauth import (
            DatabricksU2MTokenStore,
            complete_u2m_consent,
        )

        flow = _databricks_oauth_flows[flow_id]
        deadline = time.monotonic() + 120.0
        try:
            while time.monotonic() < deadline and not shutdown_event.is_set():
                if _DatabricksCallbackHandler.auth_code is not None:
                    auth_code = _DatabricksCallbackHandler.auth_code
                    callback_state = _DatabricksCallbackHandler.callback_state

                    try:
                        # consent_dict already carries the expected state;
                        # SDK's exchange_callback_parameters validates it.
                        tokens = await asyncio.to_thread(
                            complete_u2m_consent,
                            flow["consent_dict"],
                            auth_code,
                            callback_state or "",
                        )
                    except Exception as exc:
                        logger.error(
                            "Databricks OAuth exchange failed: %s", exc
                        )
                        yield _sse_event(
                            "error",
                            {
                                "message": (
                                    "Token exchange failed. "
                                    "Check backend logs for details."
                                )
                            },
                        )
                        return

                    try:
                        store = DatabricksU2MTokenStore(flow["host"])
                        store.save(tokens)
                    except KeychainHTTPError as exc:
                        yield _keychain_save_failed_event("Databricks", exc)
                        return
                    except Exception as exc:
                        logger.error(
                            "Databricks token persistence failed: %s", exc
                        )
                        yield _sse_event(
                            "error",
                            {
                                "message": (
                                    "Couldn't save Databricks credentials. "
                                    "Try restarting the desktop app."
                                )
                            },
                        )
                        return

                    yield _sse_event(
                        "success",
                        {
                            "message": "Connected to Databricks",
                            "host": flow["host"],
                            "access_token_captured": True,  # nosec B105 - boolean flag, not a literal secret
                        },
                    )
                    return

                if _DatabricksCallbackHandler.error is not None:
                    yield _sse_event(
                        "error",
                        {
                            "message": (
                                f"OAuth error: {_DatabricksCallbackHandler.error}"
                            )
                        },
                    )
                    return

                yield _sse_event(
                    "waiting",
                    {"message": "Waiting for Databricks authorization..."},
                )
                await asyncio.sleep(1.0)

            yield _sse_event(
                "error", {"message": "OAuth flow timed out (120s)"}
            )
        finally:
            try:
                flow["server"].server_close()
            except Exception:  # noqa: BLE001
                logger.debug(
                    "Failed to close Databricks OAuth callback server "
                    "for flow %s",
                    flow_id,
                )
            _databricks_oauth_flows.pop(flow_id, None)

    return StreamingResponse(generate(), media_type="text/event-stream")


@router.post("/databricks/disconnect")
async def databricks_disconnect(req: StartDatabricksOAuthU2MRequest):
    """Clear stored Databricks U2M tokens for a given workspace host."""
    from lineage.utils.databricks_oauth import DatabricksU2MTokenStore

    normalized_host = _validate_databricks_host(req.host)
    store = DatabricksU2MTokenStore(normalized_host)
    store.clear()
    return {"message": f"Disconnected Databricks U2M for {normalized_host}"}


# ── Linear OAuth PKCE Endpoints ──────────────────────────────────────


class _LinearCallbackHandler:
    """Class-level state for the Linear OAuth callback server."""

    auth_code: str | None = None
    error: str | None = None
    callback_state: str | None = None


_LINEAR_CALLBACK_PORT = 8444


def _resolve_linear_callback_port() -> int:
    """Resolve the OAuth callback port, honoring LINEAR_CALLBACK_PORT env override.

    Users who register their own Linear OAuth app with a non-default redirect URI
    can set LINEAR_CALLBACK_PORT to match. Invalid values fall back to the default.
    """
    override = os.getenv("LINEAR_CALLBACK_PORT")
    if not override:
        return _LINEAR_CALLBACK_PORT
    try:
        port = int(override)
        if not 1 <= port <= 65535:
            raise ValueError("port out of range")
        return port
    except ValueError:
        logger.warning(
            "Invalid LINEAR_CALLBACK_PORT=%r; falling back to default port %s",
            override,
            _LINEAR_CALLBACK_PORT,
        )
        return _LINEAR_CALLBACK_PORT


def _start_linear_callback_server(port: int) -> Any:
    """Start a minimal HTTP server to receive the Linear OAuth callback."""
    import html as html_mod
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import parse_qs, urlparse

    _LinearCallbackHandler.auth_code = None
    _LinearCallbackHandler.error = None
    _LinearCallbackHandler.callback_state = None

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)

            if "error" in params:
                _LinearCallbackHandler.error = params["error"][0]
                desc = params.get("error_description", [""])[0]
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    f"<html><body><h2>Authentication failed</h2>"
                    f"<p>Error: {html_mod.escape(_LinearCallbackHandler.error)}</p>"
                    f"<p>{html_mod.escape(desc)}</p></body></html>".encode()
                )
                return

            code = params.get("code", [None])[0]
            state = params.get("state", [None])[0]
            if code:
                _LinearCallbackHandler.auth_code = code
                _LinearCallbackHandler.callback_state = state
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body><h2>Connected to Linear</h2>"
                    b"<p>You can close this window and return to the app.</p></body></html>"
                )
            else:
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"<html><body>Missing code parameter</body></html>")

        def log_message(self, format: str, *args: object) -> None:
            logger.debug(format, *args)

    import threading

    server = HTTPServer(("localhost", port), Handler)
    server.timeout = 120.0

    ready = threading.Event()

    def _serve() -> None:
        ready.set()
        server.handle_request()

    thread = threading.Thread(target=_serve, daemon=True)
    thread.start()
    ready.wait(timeout=5.0)
    return server


class StartLinearOAuthResponse(BaseModel):
    """Response from starting a Linear OAuth PKCE flow."""

    flow_id: str
    authorize_url: str


@router.post("/linear/start-oauth", response_model=StartLinearOAuthResponse)
async def start_linear_oauth():
    """Start a Linear OAuth PKCE flow.

    Generates PKCE code verifier/challenge, starts a local callback server
    on port 8444, and returns the authorize URL for the frontend to open
    in the user's browser.
    """
    import secrets

    from core.backends.tickets.linear_oauth import (
        generate_code_challenge,
        generate_code_verifier,
    )

    # Only allow one Linear OAuth flow at a time
    for fid, flow in list(_linear_oauth_flows.items()):
        try:
            flow["server"].server_close()
        except Exception:  # noqa: BLE001
            logger.debug(
                "Failed to close stale Linear OAuth callback server for flow %s", fid
            )
        _linear_oauth_flows.pop(fid, None)

    flow_id = str(uuid.uuid4())

    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)
    state = secrets.token_urlsafe(32)

    callback_port = _resolve_linear_callback_port()
    redirect_uri = f"http://localhost:{callback_port}/callback"

    # Start callback server before returning the URL
    try:
        server = _start_linear_callback_server(callback_port)
    except OSError as exc:
        raise HTTPException(
            status_code=409,
            detail=f"Could not start OAuth callback server on port {callback_port}: {exc}",
        ) from exc

    # Build authorize URL
    from urllib.parse import urlencode

    client_id = os.getenv("LINEAR_CLIENT_ID", "")
    if not client_id:
        server.server_close()
        raise HTTPException(
            status_code=400,
            detail="LINEAR_CLIENT_ID environment variable is required for OAuth flow",
        )

    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "read,issues:create,comments:create",
        "prompt": "consent",
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
    }
    # Linear expects literal commas in scope (read,write not read%2Cwrite)
    qs = urlencode(params).replace("%2C", ",")
    authorize_url = f"https://linear.app/oauth/authorize?{qs}"

    _linear_oauth_flows[flow_id] = {
        "status": "pending",
        "server": server,
        "code_verifier": code_verifier,
        "expected_state": state,
        "client_id": client_id,
        "redirect_uri": redirect_uri,
    }

    return StartLinearOAuthResponse(flow_id=flow_id, authorize_url=authorize_url)


@router.get("/linear/oauth-status/{flow_id}")
async def linear_oauth_status(flow_id: str):
    """SSE stream that polls for the Linear OAuth callback result.

    Emits ``waiting`` events while the user is in the browser, then a
    ``success`` (with team list) or ``error`` event once the callback is
    received or the flow times out.
    """
    if flow_id not in _linear_oauth_flows:
        raise HTTPException(status_code=404, detail="OAuth flow not found")

    async def generate():
        import time

        import httpx
        from core.backends.tickets.linear_token_store import (
            LinearStoredTokens,
            LinearTokenStore,
        )

        flow = _linear_oauth_flows[flow_id]
        deadline = time.monotonic() + 120.0  # 2 minute timeout

        try:
            while time.monotonic() < deadline and not shutdown_event.is_set():
                # Check if callback has been received
                if _LinearCallbackHandler.auth_code is not None:
                    auth_code = _LinearCallbackHandler.auth_code
                    callback_state = _LinearCallbackHandler.callback_state

                    # Validate state (CSRF protection)
                    if callback_state != flow["expected_state"]:
                        yield _sse_event(
                            "error",
                            {"message": "OAuth state mismatch — possible CSRF attack"},
                        )
                        return

                    # Exchange code for tokens
                    try:

                        def _exchange(code: str = auth_code) -> dict:
                            resp = httpx.post(
                                "https://api.linear.app/oauth/token",
                                data={
                                    "grant_type": "authorization_code",
                                    "client_id": flow["client_id"],
                                    "code": code,
                                    "redirect_uri": flow["redirect_uri"],
                                    "code_verifier": flow["code_verifier"],
                                },
                                headers={
                                    "Content-Type": "application/x-www-form-urlencoded",
                                },
                                timeout=30.0,
                            )
                            resp.raise_for_status()
                            return resp.json()

                        token_data = await asyncio.get_running_loop().run_in_executor(
                            None, _exchange
                        )

                        # Store tokens
                        expires_in = token_data.get("expires_in", 86400)
                        store = LinearTokenStore()
                        store.save(
                            LinearStoredTokens(
                                access_token=token_data["access_token"],
                                refresh_token=token_data.get("refresh_token"),
                                expires_at=time.time() + expires_in,
                                token_type=token_data.get("token_type", "Bearer"),
                                scope=token_data.get("scope", "read write"),
                            )
                        )

                        # Fetch teams for the post-auth team selection flow
                        teams_list: list[dict] = []
                        try:
                            from linear_api import LinearClient

                            def _fetch_teams(access_token: str) -> list[dict]:
                                client = LinearClient(api_key=f"Bearer {access_token}")
                                teams = client.teams.get_all()
                                return [
                                    {"id": tid, "name": t.name, "key": t.key}
                                    for tid, t in teams.items()
                                    if t.name
                                ]

                            teams_list = (
                                await asyncio.get_running_loop().run_in_executor(
                                    None, _fetch_teams, token_data["access_token"]
                                )
                            )
                        except Exception as exc:
                            logger.warning(
                                "Failed to fetch Linear teams after OAuth: %s", exc
                            )

                        yield _sse_event(
                            "success",
                            {
                                "message": "Connected to Linear",
                                "teams": teams_list,
                            },
                        )
                        return
                    except KeychainHTTPError as exc:
                        yield _keychain_save_failed_event("Linear", exc)
                        return
                    except Exception as exc:
                        logger.error("Linear token exchange failed: %s", exc)
                        yield _sse_event(
                            "error",
                            {
                                "message": "Token exchange failed. Check backend logs for details."
                            },
                        )
                        return

                if _LinearCallbackHandler.error is not None:
                    yield _sse_event(
                        "error",
                        {"message": f"OAuth error: {_LinearCallbackHandler.error}"},
                    )
                    return

                yield _sse_event(
                    "waiting", {"message": "Waiting for Linear authorization..."}
                )
                await asyncio.sleep(1.0)

            yield _sse_event("error", {"message": "OAuth flow timed out (120s)"})
        finally:
            try:
                flow["server"].server_close()
            except Exception:  # noqa: BLE001
                logger.debug(
                    "Failed to close Linear OAuth callback server for flow %s", flow_id
                )
            _linear_oauth_flows.pop(flow_id, None)

    return StreamingResponse(generate(), media_type="text/event-stream")


@router.post("/linear/disconnect")
async def linear_disconnect():
    """Disconnect from Linear: revoke token and clear stored credentials."""
    from core.backends.tickets.linear_token_store import LinearTokenStore

    store = LinearTokenStore()
    tokens = store.load()

    if tokens:
        # Attempt to revoke on Linear's side (async to avoid blocking event loop)
        try:
            import httpx

            async with httpx.AsyncClient() as client:
                await client.post(
                    "https://api.linear.app/oauth/revoke",
                    data={"token": tokens.access_token},
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                    timeout=10.0,
                )
        except Exception as exc:
            logger.warning("Failed to revoke Linear token: %s", exc)

    store.clear()
    return {"message": "Disconnected from Linear"}


@router.get("/linear/status")
async def linear_status():
    """Check if Linear OAuth tokens are stored and fetch available teams."""
    from core.backends.tickets.linear_token_store import LinearTokenStore

    store = LinearTokenStore()
    tokens = store.load()
    if not tokens:
        return {"connected": False, "teams": []}

    try:
        from linear_api import LinearClient

        def _fetch_teams(access_token: str) -> list[dict]:
            client = LinearClient(api_key=f"Bearer {access_token}")
            teams = client.teams.get_all()
            return [
                {"id": tid, "name": t.name, "key": t.key}
                for tid, t in teams.items()
                if t.name
            ]

        team_list = await asyncio.get_running_loop().run_in_executor(
            None, _fetch_teams, tokens.access_token
        )
        return {"connected": True, "teams": team_list}
    except Exception as exc:
        logger.warning("Stored Linear token is invalid: %s", exc)
        store.clear()
        return {"connected": False, "teams": []}


# ── Linear test/info endpoints ───────────────────────────────────────


class TestLinearRequest(BaseModel):
    """Payload for testing Linear API credentials."""

    api_key: str | None = None
    access_token: str | None = None
    team_id: str | None = None


class TestLinearResponse(BaseModel):
    """Result of a Linear API credential test."""

    success: bool
    message: str
    team_name: str | None = None


@router.post("/test-linear", response_model=TestLinearResponse)
async def test_linear(req: TestLinearRequest):
    """Test Linear credentials by fetching teams, optionally validating team_id.

    Accepts either an API key or an OAuth access token.
    """
    # Determine which credential to use
    auth_key: str | None = None
    if req.access_token:
        auth_key = f"Bearer {req.access_token}"
    elif req.api_key:
        auth_key = req.api_key
    else:
        return TestLinearResponse(
            success=False, message="API key or access token is required"
        )

    try:
        from linear_api import LinearClient

        client = LinearClient(api_key=auth_key)
        teams = client.teams.get_all()

        if not teams:
            return TestLinearResponse(
                success=False,
                message="Credentials valid but no teams found",
            )

        if req.team_id:
            team = teams.get(req.team_id)
            if not team:
                team_names = [f"{t.key} ({t.name})" for t in teams.values() if t.key]
                return TestLinearResponse(
                    success=False,
                    message=f"Team '{req.team_id}' not found. Available: {', '.join(team_names)}",
                )
            return TestLinearResponse(
                success=True,
                message=f"Connected to team {team.key} ({team.name})",
                team_name=team.name,
            )

        # No team_id specified — just confirm credentials work
        first = next(iter(teams.values()))
        return TestLinearResponse(
            success=True,
            message=f"Credentials valid. Found {len(teams)} team(s)",
            team_name=first.name,
        )

    except ImportError:
        return TestLinearResponse(
            success=False,
            message="linear-api package not installed",
        )
    except Exception as exc:
        return TestLinearResponse(success=False, message=str(exc))


class TestFivetranRequest(BaseModel):
    """Payload for testing Fivetran API credentials."""

    api_key: str
    api_secret: str


class TestFivetranResponse(BaseModel):
    """Result of a Fivetran API credential test."""

    success: bool
    message: str


@router.post("/test-fivetran", response_model=TestFivetranResponse)
async def test_fivetran(req: TestFivetranRequest):
    """Test Fivetran API credentials by listing groups."""
    if not req.api_key or not req.api_secret:
        return TestFivetranResponse(
            success=False, message="API key and secret are required"
        )

    try:
        from ingest.static_loaders.fivetran.client import FivetranClient
    except ImportError:
        return TestFivetranResponse(
            success=False, message="Fivetran client package not available"
        )

    try:
        with FivetranClient(api_key=req.api_key, api_secret=req.api_secret) as client:
            if client.test_connection():
                return TestFivetranResponse(
                    success=True, message="Connected to Fivetran API"
                )
            return TestFivetranResponse(success=False, message="Invalid credentials")
    except Exception:
        return TestFivetranResponse(
            success=False, message="Failed to connect to Fivetran API"
        )


# ── Salesforce auth endpoints ─────────────────────────────────────────

_ALLOWED_SF_HOSTS = {"login.salesforce.com", "test.salesforce.com"}


def _is_salesforce_host(host: str) -> bool:
    """Return True if *host* is a known Salesforce domain."""
    if host in _ALLOWED_SF_HOSTS:
        return True
    return host.endswith((".salesforce.com", ".force.com"))


def _validate_salesforce_login_url(url: str) -> None:
    """Reject login URLs that aren't known Salesforce endpoints (SSRF prevention)."""
    from urllib.parse import urlparse

    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise HTTPException(
            status_code=400, detail="Salesforce login URL must use HTTPS"
        )
    host = (parsed.hostname or "").lower()
    if _is_salesforce_host(host):
        return
    raise HTTPException(
        status_code=400,
        detail=f"Unrecognized Salesforce login host: {host}. "
        "Expected login.salesforce.com, test.salesforce.com, *.salesforce.com, or *.force.com",
    )


def _validate_salesforce_instance_url(url: str) -> None:
    """Reject instance URLs that aren't Salesforce domains (SSRF prevention)."""
    from urllib.parse import urlparse

    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise HTTPException(
            status_code=400, detail="Salesforce instance URL must use HTTPS"
        )
    host = (parsed.hostname or "").lower()
    if _is_salesforce_host(host):
        return
    raise HTTPException(
        status_code=400,
        detail=f"Unrecognized Salesforce instance host: {host}. "
        "Expected *.salesforce.com or *.force.com",
    )


class StartSalesforceOAuthRequest(BaseModel):
    """Payload to start a Salesforce OAuth PKCE flow."""

    client_id: str
    login_url: str = "https://login.salesforce.com"


class StartSalesforceOAuthResponse(BaseModel):
    """Response containing the authorize URL and flow identifier."""

    flow_id: str
    authorize_url: str


def _validate_salesforce_client_id(client_id: str) -> None:
    """Reject values that are clearly not a Salesforce Connected App Client ID."""
    trimmed = client_id.strip()
    if not trimmed:
        raise HTTPException(status_code=400, detail="Client ID is required.")
    if re.match(r"^https?://", trimmed, re.IGNORECASE):
        raise HTTPException(
            status_code=400,
            detail="This looks like a URL, not a Client ID. "
            "Paste the Consumer Key from your Salesforce Connected App.",
        )
    if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", trimmed):
        raise HTTPException(
            status_code=400,
            detail="This looks like an email address, not a Client ID.",
        )
    if re.search(r"\s", trimmed):
        raise HTTPException(
            status_code=400, detail="Client ID should not contain spaces."
        )


@router.post("/salesforce/start-oauth", response_model=StartSalesforceOAuthResponse)
async def start_salesforce_oauth(req: StartSalesforceOAuthRequest):
    """Start a Salesforce OAuth PKCE flow.

    Generates PKCE code verifier/challenge, starts a local callback server
    on port 8443, and returns the authorize URL for the frontend to open
    in the user's browser.
    """
    client_id = req.client_id.strip()
    _validate_salesforce_client_id(client_id)
    _validate_salesforce_login_url(req.login_url)

    import secrets
    from urllib.parse import quote, urlencode

    from ingest.static_loaders.salesforce.auth.oauth_pkce import (
        generate_code_challenge,
        generate_code_verifier,
    )
    from ingest.static_loaders.salesforce.auth.server import start_callback_server

    # Only allow one OAuth flow at a time — also clean up any old flows
    for fid, flow in list(_sf_oauth_flows.items()):
        try:
            flow["server"].server_close()
        except Exception:  # noqa: BLE001
            logger.debug("Failed to close stale OAuth callback server for flow %s", fid)
        _sf_oauth_flows.pop(fid, None)

    flow_id = str(uuid.uuid4())

    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)

    state = secrets.token_urlsafe(32)
    callback_port = 8443
    redirect_uri = f"http://localhost:{callback_port}/callback"

    # Start callback server before returning the URL
    try:
        server, _ready = start_callback_server(port=callback_port)
    except OSError as exc:
        raise HTTPException(
            status_code=409,
            detail=f"Could not start OAuth callback server on port {callback_port}: {exc}",
        ) from exc

    # Build authorize URL
    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "state": state,
        "scope": "refresh_token api",
    }
    authorize_url = f"{req.login_url}/services/oauth2/authorize?{urlencode(params, quote_via=quote)}"

    _sf_oauth_flows[flow_id] = {
        "status": "pending",
        "server": server,
        "code_verifier": code_verifier,
        "expected_state": state,
        "client_id": client_id,
        "login_url": req.login_url,
        "redirect_uri": redirect_uri,
        "callback_port": callback_port,
    }

    return StartSalesforceOAuthResponse(flow_id=flow_id, authorize_url=authorize_url)


@router.get("/salesforce/oauth-status/{flow_id}")
async def salesforce_oauth_status(flow_id: str):
    """SSE stream that polls for the OAuth callback result.

    Emits ``waiting`` events while the user is in the browser, then a
    ``success`` or ``error`` event once the callback is received or the
    flow times out.
    """
    if flow_id not in _sf_oauth_flows:
        raise HTTPException(status_code=404, detail="OAuth flow not found")

    async def generate():
        import time

        import httpx
        from ingest.static_loaders.salesforce.auth.server import _CallbackHandler
        from ingest.static_loaders.salesforce.auth.token_store import (
            StoredTokens,
            TokenStore,
        )

        flow = _sf_oauth_flows[flow_id]
        deadline = time.monotonic() + 120.0  # 2 minute timeout

        try:
            while time.monotonic() < deadline and not shutdown_event.is_set():
                # Check if callback has been received
                if _CallbackHandler.auth_code is not None:
                    auth_code = _CallbackHandler.auth_code
                    callback_state = _CallbackHandler.callback_state

                    # Validate state (CSRF protection)
                    if callback_state != flow["expected_state"]:
                        yield _sse_event(
                            "error",
                            {"message": "OAuth state mismatch — possible CSRF attack"},
                        )
                        return

                    # Exchange code for tokens (run in executor to avoid blocking the event loop)
                    try:

                        def _exchange(code: str = auth_code) -> dict:
                            resp = httpx.post(
                                f"{flow['login_url']}/services/oauth2/token",
                                data={
                                    "grant_type": "authorization_code",
                                    "client_id": flow["client_id"],
                                    "code": code,
                                    "redirect_uri": flow["redirect_uri"],
                                    "code_verifier": flow["code_verifier"],
                                },
                                timeout=30.0,
                            )
                            resp.raise_for_status()
                            return resp.json()

                        token_data = await asyncio.get_running_loop().run_in_executor(
                            None, _exchange
                        )

                        # Store tokens
                        store = TokenStore(org_key="default")
                        store.save(
                            StoredTokens(
                                access_token=token_data["access_token"],
                                instance_url=token_data["instance_url"],
                                refresh_token=token_data.get("refresh_token"),
                                token_type=token_data.get("token_type", "Bearer"),
                                issued_at=token_data.get("issued_at"),
                                org_key="default",
                            )
                        )

                        yield _sse_event(
                            "success",
                            {
                                "instance_url": token_data["instance_url"],
                                "message": f"Connected to {token_data['instance_url']}",
                            },
                        )
                        return
                    except KeychainHTTPError as exc:
                        yield _keychain_save_failed_event("Salesforce", exc)
                        return
                    except Exception as exc:
                        logger.error("Salesforce token exchange failed: %s", exc)
                        yield _sse_event(
                            "error",
                            {
                                "message": "Token exchange failed. Check backend logs for details."
                            },
                        )
                        return

                if _CallbackHandler.error is not None:
                    yield _sse_event(
                        "error", {"message": f"OAuth error: {_CallbackHandler.error}"}
                    )
                    return

                yield _sse_event("waiting", {"message": "Waiting for browser login..."})
                await asyncio.sleep(1.0)

            yield _sse_event("error", {"message": "OAuth flow timed out (120s)"})
        finally:
            try:
                flow["server"].server_close()
            except Exception:  # noqa: BLE001
                logger.debug(
                    "Failed to close OAuth callback server for flow %s", flow_id
                )
            _sf_oauth_flows.pop(flow_id, None)

    return StreamingResponse(generate(), media_type="text/event-stream")


class TestSalesforceRequest(BaseModel):
    """Payload for testing Salesforce credentials."""

    auth_type: SfAuthMode
    client_id: str | None = None
    client_secret: str | None = None
    login_url: str = "https://login.salesforce.com"
    instance_url: str | None = None
    username: str | None = None
    password: str | None = None
    security_token: str | None = None


class TestSalesforceResponse(BaseModel):
    """Result of a Salesforce credential test."""

    success: bool
    message: str
    instance_url: str | None = None


@router.post("/test-salesforce", response_model=TestSalesforceResponse)
async def test_salesforce(req: TestSalesforceRequest):
    """Test Salesforce credentials based on auth type."""
    _validate_salesforce_login_url(req.login_url)

    if req.auth_type is SfAuthMode.OAUTH_PKCE:
        # Check for cached tokens from a previous OAuth flow
        try:
            from ingest.static_loaders.salesforce.auth.token_store import TokenStore

            store = TokenStore(org_key="default")
            stored = store.load()
            if stored and stored.access_token:
                return TestSalesforceResponse(
                    success=True,
                    message=f"OAuth tokens available for {stored.instance_url}",
                    instance_url=stored.instance_url,
                )
            return TestSalesforceResponse(
                success=False,
                message="No OAuth tokens found. Use 'Connect with Salesforce' to authenticate.",
            )
        except Exception as exc:
            logger.error("Salesforce OAuth token check failed: %s", exc)
            return TestSalesforceResponse(
                success=False, message="Failed to check OAuth tokens"
            )

    elif req.auth_type is SfAuthMode.PASSWORD:
        if not all([req.instance_url, req.username, req.password, req.security_token]):
            return TestSalesforceResponse(
                success=False,
                message="Instance URL, username, password, and security token are required",
            )
        _validate_salesforce_instance_url(req.instance_url)  # type: ignore[arg-type]
        try:
            from simple_salesforce import Salesforce

            sf = await asyncio.get_running_loop().run_in_executor(
                None,
                lambda: Salesforce(
                    instance_url=req.instance_url,
                    username=req.username,
                    password=req.password,
                    security_token=req.security_token,
                ),
            )
            return TestSalesforceResponse(
                success=True,
                message=f"Connected to {sf.sf_instance}",
                instance_url=f"https://{sf.sf_instance}",
            )
        except ImportError:
            return TestSalesforceResponse(
                success=False,
                message="simple-salesforce package not installed",
            )
        except Exception as exc:
            logger.error("Salesforce password auth test failed: %s", exc)
            return TestSalesforceResponse(
                success=False, message="Authentication failed"
            )

    elif req.auth_type is SfAuthMode.CLIENT_CREDENTIALS:
        if not req.client_id or not req.client_secret:
            return TestSalesforceResponse(
                success=False,
                message="Client ID and Client Secret are required",
            )
        try:
            from ingest.static_loaders.salesforce.auth.client_creds import (
                ClientCredentialsAuth,
            )

            auth = ClientCredentialsAuth(
                client_id=req.client_id,
                client_secret=req.client_secret,
                login_url=req.login_url,
            )
            creds = await asyncio.get_running_loop().run_in_executor(
                None, auth.authenticate
            )
            return TestSalesforceResponse(
                success=True,
                message=f"Connected to {creds.instance_url}",
                instance_url=creds.instance_url,
            )
        except Exception as exc:
            logger.error("Salesforce client credentials test failed: %s", exc)
            return TestSalesforceResponse(
                success=False, message="Authentication failed"
            )

    return TestSalesforceResponse(
        success=False, message=f"Unknown auth type: {req.auth_type}"
    )


class ListSchemasRequest(BaseModel):
    """Connection details for listing schemas.

    Snowflake fields are required when ``backend_type='snowflake'`` (or omitted
    for backwards compatibility); Databricks fields are required when
    ``backend_type='databricks'``.
    """

    backend_type: Literal["snowflake", "databricks"] = "snowflake"
    # Snowflake fields
    account: str | None = None
    user: str | None = None
    role: str | None = None
    warehouse: str | None = None
    auth_method: Literal["private_key", "pat"] = "private_key"
    private_key_path: str | None = None
    pat_token: str | None = None
    database: str | None = None
    # Databricks fields (TD-2734)
    databricks_host: str | None = None
    databricks_http_path: str | None = None
    databricks_catalog: str | None = None
    databricks_auth_method: Literal["pat", "oauth_u2m"] = "pat"
    databricks_pat_token: str | None = None
    databricks_oauth_u2m_token: str | None = None


async def _list_schemas_databricks(req: ListSchemasRequest) -> dict[str, list[str]]:
    """Databricks branch of /list-schemas."""
    from lineage.utils.databricks import list_databricks_schemas

    if not req.databricks_host:
        raise HTTPException(
            status_code=400, detail="Databricks workspace host is required"
        )
    if not req.databricks_http_path:
        raise HTTPException(
            status_code=400, detail="Databricks http_path is required"
        )
    if not req.databricks_catalog:
        raise HTTPException(
            status_code=400, detail="Databricks catalog is required"
        )

    normalized_host = _validate_databricks_host(req.databricks_host)

    if req.databricks_auth_method == "oauth_u2m":
        oauth = req.databricks_oauth_u2m_token or _load_databricks_oauth_token(
            normalized_host
        )
        if not oauth:
            raise HTTPException(
                status_code=400,
                detail=(
                    "OAuth U2M token is required. Complete the browser "
                    "flow first."
                ),
            )
        pat = None
    else:
        from lineage.utils.env import load_env_file

        load_env_file()
        pat = req.databricks_pat_token or os.environ.get("DATABRICKS_TOKEN")
        if not pat:
            raise HTTPException(
                status_code=400,
                detail="Databricks PAT is required (or set DATABRICKS_TOKEN in env).",
            )
        oauth = None

    try:
        schemas = await asyncio.to_thread(
            list_databricks_schemas,
            host=normalized_host,
            http_path=req.databricks_http_path,
            catalog=req.databricks_catalog,
            pat_token=pat,
            oauth_token=oauth,
        )
        return {"schemas": schemas}
    except ValueError as exc:
        # Cluster-path or NUL-byte rejection
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ImportError as exc:
        raise HTTPException(
            status_code=500, detail="databricks-sql-connector not installed"
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/list-schemas")
async def list_schemas(req: ListSchemasRequest):
    """List schemas for a given Snowflake database or Databricks catalog."""
    if req.backend_type == "databricks":
        return await _list_schemas_databricks(req)

    if not req.account or not req.user or not req.database:
        raise HTTPException(
            status_code=400,
            detail="account, user, and database are required for Snowflake list-schemas",
        )
    resolved_key_path: str | None = None
    pat_token: str | None = None
    if req.auth_method == "private_key":
        if not req.private_key_path:
            raise HTTPException(status_code=400, detail="Private key path is required")
        key_path = Path(req.private_key_path).expanduser()
        if not key_path.exists():
            raise HTTPException(
                status_code=400, detail=f"Private key not found: {key_path}"
            )
        resolved_key_path = str(key_path)
    else:
        # Load .env so browser-dev mode can resolve a saved PAT when the UI
        # leaves the field blank (matches test_connection behavior).
        from lineage.utils.env import load_env_file

        load_env_file()
        pat_token = req.pat_token or os.environ.get("SNOWFLAKE_PAT_TOKEN")
        if not pat_token:
            raise HTTPException(
                status_code=400,
                detail="PAT token is required when auth_method='pat'",
            )

    try:
        from lineage.utils.snowflake import list_snowflake_schemas

        schemas = await asyncio.get_running_loop().run_in_executor(
            None,
            lambda: list_snowflake_schemas(
                account=req.account,
                user=req.user,
                database=req.database,
                warehouse=req.warehouse,
                role=req.role,
                auth_method=req.auth_method,
                private_key_path=resolved_key_path,
                pat_token=pat_token,
            ),
        )
        return {"schemas": schemas}
    except ImportError:
        raise HTTPException(
            status_code=500, detail="snowflake-connector-python not installed"
        ) from None
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from None


@router.post("/create-project", response_model=CreateProjectResponse)
async def create_project(req: CreateProjectRequest):
    """Create project configuration: config.yaml, profiles.yml, .env."""
    ensure_home()
    sanitized = _sanitize_project_name(req.name)

    # Build project config as Pydantic model (not Jinja2 template)
    project_dir = projects_dir() / sanitized
    if not project_dir.exists():
        raise HTTPException(
            status_code=400,
            detail=f"Project directory not found: {sanitized}. Clone first.",
        )

    dbt_path = str(project_dir)
    if req.sub_project:
        # Validate subproject path to prevent traversal
        sub = Path(req.sub_project)
        if sub.is_absolute() or ".." in sub.parts:
            raise HTTPException(status_code=400, detail="Invalid subproject path")
        resolved = (project_dir / sub).resolve()
        if not resolved.is_relative_to(project_dir.resolve()):
            raise HTTPException(status_code=400, detail="Invalid subproject path")
        dbt_path = str(resolved)

    # In Tauri mode, secrets go to OS keychain and never reach here.
    # In browser-only dev mode, secrets still arrive via this endpoint
    # and are written to .env as a fallback.
    env_entries: dict[str, str] = {}
    if req.snowflake_private_key_path:
        if req.snowflake_auth_method != "private_key":
            raise HTTPException(
                status_code=400,
                detail="snowflake_private_key_path is only allowed when snowflake_auth_method is 'private_key'",
            )
        env_entries["SNOWFLAKE_PRIVATE_KEY_PATH"] = req.snowflake_private_key_path
    if req.snowflake_pat_token:
        if req.snowflake_auth_method != "pat":
            raise HTTPException(
                status_code=400,
                detail="snowflake_pat_token is only allowed when snowflake_auth_method is 'pat'",
            )
        env_entries["SNOWFLAKE_PAT_TOKEN"] = req.snowflake_pat_token
    if req.snowflake_account:
        env_entries["SNOWFLAKE_ACCOUNT"] = req.snowflake_account
    if req.snowflake_user:
        env_entries["SNOWFLAKE_USER"] = req.snowflake_user
    if req.snowflake_role:
        env_entries["SNOWFLAKE_ROLE"] = req.snowflake_role
    if req.snowflake_warehouse:
        env_entries["SNOWFLAKE_WAREHOUSE"] = req.snowflake_warehouse
    # Databricks (TD-2734) — same browser-dev fallback envelope as Snowflake.
    # OAuth U2M tokens are stored separately by DatabricksU2MTokenStore and
    # never written to .env.
    if req.databricks_pat_token:
        if req.databricks_auth_method != "pat":
            raise HTTPException(
                status_code=400,
                detail=(
                    "databricks_pat_token is only allowed when "
                    "databricks_auth_method is 'pat'"
                ),
            )
        env_entries["DATABRICKS_TOKEN"] = req.databricks_pat_token
    if req.databricks_oauth_u2m_token and req.databricks_auth_method != "oauth_u2m":
        raise HTTPException(
            status_code=400,
            detail=(
                "databricks_oauth_u2m_token is only allowed when "
                "databricks_auth_method is 'oauth_u2m'"
            ),
        )
    if req.databricks_host:
        # SSRF allowlist + canonicalization at the request boundary —
        # raises HTTPException(400) on rejection. The same helper is
        # used by /test-connection, /list-schemas, /list-databases, etc.
        # so create-project can't be the back door that bypasses the
        # allowlist on persistence. Mutating req here keeps the
        # downstream profiles.yml / config.yaml builders observing the
        # same normalized hostname (no scheme, path, query, or fragment).
        req.databricks_host = _validate_databricks_host(req.databricks_host)
        env_entries["DATABRICKS_HOST"] = req.databricks_host
    if req.databricks_http_path:
        env_entries["DATABRICKS_HTTP_PATH"] = req.databricks_http_path
    if req.databricks_warehouse_id:
        env_entries["DATABRICKS_WAREHOUSE_ID"] = req.databricks_warehouse_id
    if req.databricks_catalog:
        env_entries["DATABRICKS_CATALOG"] = req.databricks_catalog
    if req.anthropic_api_key:
        env_entries["ANTHROPIC_API_KEY"] = req.anthropic_api_key
    if req.openai_api_key:
        env_entries["OPENAI_API_KEY"] = req.openai_api_key
    if req.logfire_api_key:
        env_entries["LOGFIRE_TOKEN"] = req.logfire_api_key
    if req.linear_analyst_api_key:
        env_entries["LINEAR_ANALYST_API_KEY"] = req.linear_analyst_api_key
    if req.linear_data_engineer_api_key:
        env_entries["LINEAR_DATA_ENGINEER_API_KEY"] = req.linear_data_engineer_api_key
    if req.linear_team_id:
        env_entries["LINEAR_TEAM_ID"] = req.linear_team_id

    if env_entries:
        ep = env_path()
        existing_env: dict[str, str] = {}
        if ep.exists():
            for line in ep.read_text().splitlines():
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    existing_env[k.strip()] = v.strip()
        existing_env.update(env_entries)
        _write_env_file(ep, existing_env)

    # Resolve profile name: prefer the caller-supplied value, then fall back
    # to reading dbt_project.yml.  When the caller already provides a profile
    # name (e.g. quickstart) we skip the file read so the project directory
    # doesn't need to contain dbt_project.yml yet.
    profile_name = req.profile_name
    if not profile_name:
        dbt_project_yml = Path(dbt_path) / "dbt_project.yml"
        if not dbt_project_yml.exists():
            raise HTTPException(
                status_code=400,
                detail=f"dbt_project.yml not found at {dbt_path}",
            )
        import yaml

        with open(dbt_project_yml) as f:
            dbt_cfg = yaml.safe_load(f) or {}
        profile_name = dbt_cfg.get("profile")
        if not profile_name:
            raise HTTPException(
                status_code=400,
                detail="No 'profile' key found in dbt_project.yml",
            )

    # Write profiles.yml
    profiles_path = profiles_dir() / sanitized
    profiles_path.mkdir(parents=True, exist_ok=True)
    profiles_yml = _build_profiles_yml(req, profile_name)
    (profiles_path / "profiles.yml").write_text(profiles_yml)

    # Merge new project into existing config.yaml (don't overwrite other projects)
    import yaml

    cfg_file = config_path()
    existing: dict = {}
    if cfg_file.exists():
        existing = yaml.safe_load(cfg_file.read_text()) or {}

    new_project = _build_project_config(req, sanitized, dbt_path, profile_name)
    projects = existing.get("projects") or {}
    projects[sanitized] = new_project
    existing["projects"] = projects
    existing["default_project"] = sanitized  # new project becomes default

    # Ensure lineage section exists (only required top-level field for UnifiedConfig;
    # models and memory have defaults / are optional)
    surreal_url = os.environ.get("SURREAL_URL", default_surreal_url())
    if "lineage" not in existing:
        existing["lineage"] = {
            "backend": "surrealdb",
            "url": surreal_url,
            "namespace": "lineage",
        }

    _write_config_atomic(
        cfg_file, yaml.dump(existing, default_flow_style=False, sort_keys=False)
    )

    return CreateProjectResponse(
        name=sanitized,
        config_path=str(config_path()),
        message=f"Project '{sanitized}' created successfully",
    )


# ── Shared preflight generator ────────────────────────────────────────


async def _run_preflight_sse(
    *,
    adapter: str,
    dbt_project_root: Path,
    profiles_dir: Path,
    extra_env: dict[str, str],
    event_prefix: str,
    dbt_target: str | None = None,
) -> AsyncGenerator[str, None]:
    """Shared SSE generator: ensure dbt venv, dbt deps, dbt docs generate.

    Both ``start_preflight`` (review step) and ``start_preflight_check``
    (warehouse step) delegate here so error handling and dbt orchestration
    stay in one place.

    Args:
        adapter: dbt adapter name (``snowflake``, ``databricks``, ``duckdb``).
        dbt_project_root: Path to the dbt project directory.
        profiles_dir: Directory containing ``profiles.yml``.
        extra_env: Env vars passed to every dbt subprocess.
        event_prefix: SSE event namespace (``preflight`` or ``preflight-check``).
        dbt_target: Explicit ``--target`` value. ``None`` omits the flag.
    """
    import subprocess as _sp  # nosec B404

    # ── ensure dbt venv ──
    yield _sse_event(
        f"{event_prefix}.status",
        {"phase": "venv", "message": f"Ensuring dbt-{adapter} virtual environment..."},
    )
    try:
        from lineage.tui.wizards.init.helpers import ensure_dbt_venv

        venv_dir = await asyncio.to_thread(ensure_dbt_venv, adapter)
        yield _sse_event(
            f"{event_prefix}.status", {"phase": "venv", "message": "dbt venv ready"}
        )
    except Exception as exc:
        yield _sse_event(
            f"{event_prefix}.error",
            {"phase": "venv", "message": f"Failed to create dbt venv: {exc}"},
        )
        return

    from lineage.utils.dbt import _validate_manifest, run_dbt_command

    # ── dbt deps ──
    yield _sse_event(
        f"{event_prefix}.status",
        {"phase": "deps", "message": "Running dbt deps..."},
    )
    try:
        await asyncio.to_thread(
            run_dbt_command,
            ["deps"],
            dbt_project_root,
            profiles_dir=profiles_dir,
            venv_dir=venv_dir,
            extra_env=extra_env or None,
        )
        yield _sse_event(
            f"{event_prefix}.status",
            {"phase": "deps", "message": "dbt deps completed"},
        )
    except _sp.CalledProcessError as exc:
        err_detail = exc.stderr or exc.stdout or str(exc)
        logger.error("[desktop:%s] dbt deps failed:\n%s", event_prefix, err_detail)
        display = err_detail if len(err_detail) <= 2000 else err_detail[:2000] + "..."
        yield _sse_event(
            f"{event_prefix}.error",
            {"phase": "deps", "message": f"dbt deps failed:\n{display}"},
        )
        return

    # ── manifest validation / docs generate ──
    manifest = dbt_project_root / "target" / "manifest.json"
    if _validate_manifest(manifest):
        yield _sse_event(
            f"{event_prefix}.status",
            {
                "phase": "docs",
                "message": "manifest.json already valid, skipping dbt docs generate",
            },
        )
    else:
        yield _sse_event(
            f"{event_prefix}.status",
            {"phase": "docs", "message": "Running dbt docs generate..."},
        )
        try:
            target_args = ["--target", dbt_target] if dbt_target else []

            # DuckDB: seed first so docs generate can resolve ref()s
            if adapter == "duckdb":
                yield _sse_event(
                    f"{event_prefix}.status",
                    {"phase": "seed", "message": "Running dbt seed..."},
                )
                try:
                    await asyncio.to_thread(
                        run_dbt_command,
                        ["seed", *target_args],
                        dbt_project_root,
                        profiles_dir=profiles_dir,
                        venv_dir=venv_dir,
                        extra_env=extra_env or None,
                    )
                except _sp.CalledProcessError as exc:
                    logger.warning(
                        "[desktop:%s] dbt seed failed (non-fatal):\n%s",
                        event_prefix,
                        (exc.stderr or exc.stdout or str(exc))[:500],
                    )

            from lineage.utils.dbt import run_dbt_docs_generate

            result = await asyncio.to_thread(
                run_dbt_docs_generate,
                dbt_project_root,
                profiles_dir=profiles_dir,
                venv_dir=venv_dir,
                extra_env=extra_env or None,
                target_args=target_args or None,
            )

            if result.success:
                yield _sse_event(
                    f"{event_prefix}.status",
                    {"phase": "docs", "message": "dbt docs generate completed"},
                )
            else:
                summary = result.error_summary or "Unknown error"
                parts = [summary[:500]]
                if result.log_hint:
                    parts.append(f"Full log: {result.log_hint}")
                yield _sse_event(
                    f"{event_prefix}.error",
                    {"phase": "docs", "message": "\n".join(parts)},
                )
                return
        except Exception as exc:
            yield _sse_event(
                f"{event_prefix}.error",
                {"phase": "docs", "message": f"dbt docs generate failed: {exc}"},
            )
            return

    artifacts_dir = str(dbt_project_root / "target")
    yield _sse_event(
        f"{event_prefix}.done",
        {"phase": "done", "message": "Preflight check passed", "artifacts_dir": artifacts_dir},
    )


# ── Preflight (dbt venv + docs generate) ─────────────────────────────


class PreflightRequest(BaseModel):
    """Request payload for the dbt preflight (venv + docs generate) step."""

    project_name: str
    backend: Literal["snowflake", "duckdb", "databricks"]


@router.post("/preflight/{project_name}/start")
async def start_preflight(project_name: str, req: PreflightRequest):
    """Run dbt venv setup + dbt docs generate. Returns SSE progress."""
    from core.paths import profiles_dir, projects_dir

    sanitized = _sanitize_project_name(project_name)
    project_dir = projects_dir() / sanitized
    if not project_dir.exists():
        raise HTTPException(
            status_code=404, detail=f"Project directory not found: {sanitized}"
        )

    # Determine dbt project root (may be a subproject)
    config_file = config_path()
    dbt_project_root = project_dir
    cfg: dict = {}
    proj_cfg: dict = {}
    if config_file.exists():
        import yaml

        with open(config_file) as f:
            cfg = yaml.safe_load(f) or {}
        proj_cfg = (cfg.get("projects") or {}).get(sanitized, {})
        dbt_path = proj_cfg.get("dbt_path")
        if dbt_path:
            dbt_project_root = Path(dbt_path)

    if req.backend == "snowflake":
        adapter = "snowflake"
    elif req.backend == "databricks":
        adapter = "databricks"
    else:
        adapter = "duckdb"
    prof_dir = profiles_dir() / sanitized

    # Build extra_env: .env file → project config env → OAuth keychain.
    extra_env: dict[str, str] = {}
    env_file = env_path()
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                extra_env[k.strip()] = v.strip()
    if proj_cfg.get("env"):
        for k, v in proj_cfg["env"].items():
            extra_env[k] = str(v)
    extra_env.update(_load_databricks_oauth_env_for_project(proj_cfg))

    # Determine dbt target from config
    dbt_target = (
        (cfg.get("projects") or {}).get(sanitized, {}).get("dbt_target")
        if config_file.exists()
        else None
    )

    async def generate():
        async for event in _run_preflight_sse(
            adapter=adapter,
            dbt_project_root=dbt_project_root,
            profiles_dir=prof_dir,
            extra_env=extra_env,
            event_prefix="preflight",
            dbt_target=dbt_target,
        ):
            yield event

    return StreamingResponse(generate(), media_type="text/event-stream")


# ── Preflight Check (early, before createProject) ────────────────────


@router.post("/preflight-check")
async def start_preflight_check(req: PreflightCheckRequest):
    """Run dbt deps + docs generate *before* createProject().

    Writes a temporary profiles.yml, runs the dbt commands against the
    clone directory, and streams SSE progress. On success the manifest
    lands in ``{clone_dir}/target/manifest.json`` so the later ReviewStep
    preflight can skip docs generate.
    """
    sanitized = _sanitize_project_name(req.project_name)
    project_dir = projects_dir() / sanitized
    if not project_dir.exists():
        raise HTTPException(
            status_code=404, detail=f"Project directory not found: {sanitized}"
        )

    # Resolve dbt project root (apply sub_project if set)
    dbt_project_root = project_dir
    if req.sub_project:
        sub = Path(req.sub_project)
        if sub.is_absolute() or ".." in sub.parts:
            raise HTTPException(status_code=400, detail="Invalid subproject path")
        resolved = (project_dir / sub).resolve()
        if not resolved.is_relative_to(project_dir.resolve()):
            raise HTTPException(status_code=400, detail="Invalid subproject path")
        if not resolved.is_dir():
            raise HTTPException(
                status_code=400,
                detail=f"Subproject path does not exist: {req.sub_project}",
            )
        dbt_project_root = resolved

    # Detect profile name from dbt_project.yml
    profile_name = req.profile_name
    if not profile_name:
        dbt_project_yml = dbt_project_root / "dbt_project.yml"
        if not dbt_project_yml.exists():
            raise HTTPException(
                status_code=400,
                detail=f"dbt_project.yml not found at {dbt_project_root}",
            )
        import yaml

        with open(dbt_project_yml) as f:
            dbt_cfg = yaml.safe_load(f) or {}
        profile_name = dbt_cfg.get("profile")
        if not profile_name:
            raise HTTPException(
                status_code=400,
                detail="No 'profile' key found in dbt_project.yml",
            )

    if req.backend == "snowflake":
        adapter = "snowflake"
    elif req.backend == "databricks":
        adapter = "databricks"
        # Validate/normalize host at the request boundary (matches create_project)
        if req.databricks_host:
            req.databricks_host = _validate_databricks_host(req.databricks_host)
    else:
        adapter = "duckdb"

    # Build extra_env: .env file → request env_vars → credential injection.
    extra_env: dict[str, str] = {}
    env_file = env_path()
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                extra_env[k.strip()] = v.strip()
    if req.env_vars:
        for entry in req.env_vars.split(","):
            entry = entry.strip()
            if "=" in entry:
                k, v = entry.split("=", 1)
                extra_env[k.strip()] = v.strip()
    if req.backend == "snowflake":
        if req.snowflake_auth_method == "pat" and req.snowflake_pat_token:
            extra_env["SNOWFLAKE_PAT_TOKEN"] = req.snowflake_pat_token
        elif (
            req.snowflake_auth_method == "pat"
            and "SNOWFLAKE_PAT_TOKEN" not in extra_env
        ):
            # Fall back to .env file (already loaded above)
            from lineage.utils.env import load_env_file

            load_env_file()
    if req.backend == "databricks":
        if req.databricks_auth_method == "pat" and req.databricks_pat_token:
            extra_env["DATABRICKS_TOKEN"] = req.databricks_pat_token
        elif req.databricks_auth_method == "pat" and "DATABRICKS_TOKEN" not in extra_env:
            # Fall back to .env file (already loaded above)
            from lineage.utils.env import load_env_file

            load_env_file()
        elif req.databricks_auth_method == "oauth_u2m":
            # OAuth U2M: always resolve from keychain, overriding any
            # DATABRICKS_TOKEN from .env since the user explicitly chose OAuth.
            oauth_token = _load_databricks_oauth_token(req.databricks_host)
            if oauth_token:
                extra_env["DATABRICKS_TOKEN"] = oauth_token

    async def generate():
        import shutil

        tmp_profiles_dir = Path(tempfile.mkdtemp(prefix="typedef-preflight-"))
        try:
            profiles_yml = _build_profiles_yml(req, profile_name)
            (tmp_profiles_dir / "profiles.yml").write_text(profiles_yml)
            async for event in _run_preflight_sse(
                adapter=adapter,
                dbt_project_root=dbt_project_root,
                profiles_dir=tmp_profiles_dir,
                extra_env=extra_env,
                event_prefix="preflight-check",
                dbt_target=req.dbt_target or "prod",
            ):
                yield event
        finally:
            shutil.rmtree(tmp_profiles_dir, ignore_errors=True)

    return StreamingResponse(generate(), media_type="text/event-stream")


def _build_profiles_yml(
    req: CreateProjectRequest | PreflightCheckRequest, profile_name: str
) -> str:
    """Build a dbt profiles.yml string from wizard inputs using yaml.dump.

    ``profile_name`` must match the ``profile:`` key in the project's
    ``dbt_project.yml`` so that dbt resolves it correctly.
    """
    import yaml

    target = req.dbt_target or "prod"
    if req.backend == "snowflake":
        output = {
            "type": "snowflake",
            "account": req.snowflake_account or "",
            "user": req.snowflake_user or "",
            "warehouse": req.snowflake_warehouse or "",
            "role": req.snowflake_role or "",
            "database": req.snowflake_database or "",
            "schema": req.snowflake_schema or "PUBLIC",
            "threads": 4,
        }
        if req.snowflake_auth_method == "pat":
            # dbt-snowflake (1.11.x) has no native PAT support: auth_args()
            # only forwards `token` to the connector when authenticator is
            # `oauth` or `jwt`, and Snowflake rejects PATs on the OAuth
            # bearer path with "Invalid OAuth access token".
            # Snowflake's PAT feature explicitly accepts a PAT in the
            # PASSWORD field, so use basic auth (no authenticator override).
            output["password"] = "{{ env_var('SNOWFLAKE_PAT_TOKEN') }}"  # nosec B105 - dbt Jinja env_var() template, not a literal secret
        else:
            output["private_key_path"] = req.snowflake_private_key_path or ""
    elif req.backend == "databricks":
        # dbt-databricks accepts a bare access token on `token`; the same
        # env var (DATABRICKS_TOKEN) carries either PAT or OAuth U2M
        # access token. The keychain bridge (or .env in browser-only dev)
        # populates the env at runtime.
        # Route every host through `_normalize_databricks_host` so scheme,
        # path, query, AND fragment are stripped consistently with every
        # other persistence/connection site. The SSRF allowlist runs at
        # the request boundary (create_project / update_project), so this
        # internal builder uses the normalizer alone.
        host = _normalize_databricks_host(req.databricks_host) if req.databricks_host else ""
        output = {
            "type": "databricks",
            "host": host,
            "http_path": req.databricks_http_path or "",
            "catalog": req.databricks_catalog or "",
            "schema": req.databricks_schema or "default",
            "token": "{{ env_var('DATABRICKS_TOKEN') }}",  # nosec B105 - dbt Jinja env_var() template, not a literal secret
            "threads": 4,
        }
    else:
        # DuckDB: use the same target name as Snowflake (default "prod") so dbt
        # schema generation rules that key on target name behave correctly.
        target = req.dbt_target or "prod"
        output = {
            "type": "duckdb",
            "path": req.duckdb_path or ":memory:",
            "threads": 4,
        }

    profile = {profile_name: {"target": target, "outputs": {target: output}}}
    return yaml.dump(profile, default_flow_style=False, sort_keys=False)


def _build_project_config(
    req: CreateProjectRequest,
    sanitized: str,
    dbt_path: str,
    profile_name: str | None = None,
) -> dict[str, Any]:
    """Build a single project config dict for merging into config.yaml."""
    data: dict[str, Any] = {"backend": req.backend}

    if req.backend == "snowflake":
        data.update(
            {
                "account": req.snowflake_account or "",
                "user": req.snowflake_user or "",
                "warehouse": req.snowflake_warehouse or "",
                "role": req.snowflake_role or "",
                "database": req.snowflake_database or "",
                "schema_name": req.snowflake_schema or "PUBLIC",
                "auth_method": req.snowflake_auth_method,
            }
        )
        if req.snowflake_auth_method == "pat":
            # PAT is held in the OS keychain / .env and injected into the
            # environment at runtime; config references the env var by name.
            data["pat_token"] = "${SNOWFLAKE_PAT_TOKEN}"  # nosec B105 - env var reference, not a literal secret
        else:
            data["private_key_path"] = req.snowflake_private_key_path or ""
        if req.allowed_databases:
            data["allowed_databases"] = list(req.allowed_databases)
    elif req.backend == "databricks":
        # Round-trips through DatabricksDataConfig.model_validate — kept
        # in sync with libs/python/core/src/core/backends/config.py.
        # Use the canonical normalizer so scheme/path/query/fragment all
        # get stripped (a paste like `https://...databricks.com/#/sql/...`
        # otherwise leaves a trailing fragment in `data["host"]`, which
        # breaks token-store lookups and connector usage downstream).
        host = _normalize_databricks_host(req.databricks_host) if req.databricks_host else ""
        data.update(
            {
                "host": host,
                "http_path": req.databricks_http_path or "",
                "catalog": req.databricks_catalog or "",
                "schema_name": req.databricks_schema or "default",
            }
        )
        if req.databricks_warehouse_id:
            data["warehouse_id"] = req.databricks_warehouse_id
        # Discriminated auth union — keys match DatabricksAuth in config.py.
        # The token field references the env var so the keychain bridge
        # (or .env fallback in browser-only dev) populates the runtime value.
        if req.databricks_auth_method == "oauth_u2m":
            data["auth"] = {
                "auth_method": "oauth_u2m",
                # OAuth U2M token comes from the per-host keychain blob;
                # Tauri reads it and exports DATABRICKS_TOKEN at boot.
                "token": "${DATABRICKS_TOKEN}",  # nosec B105 - env-var reference, not a literal secret
            }
        else:
            data["auth"] = {
                "auth_method": "pat",
                "token": "${DATABRICKS_TOKEN}",  # nosec B105 - env-var reference, not a literal secret
            }
        if req.allowed_catalogs:
            data["allowed_catalogs"] = list(req.allowed_catalogs)
    else:
        data["db_path"] = req.duckdb_path or ":memory:"

    # Use caller-resolved profile name (from dbt_project.yml or user-supplied)
    if not profile_name:
        raise ValueError("profile_name is required — must be read from dbt_project.yml")

    project: dict[str, Any] = {
        "name": sanitized,
        "dbt_path": dbt_path,
        "graph_name": sanitized,
        "profile_name": profile_name,
        "profiles_dir": str(profiles_dir() / sanitized),
        "dbt_target": req.dbt_target or "prod",
        "data": data,
    }

    # Per-project env vars so dbt can resolve env_var() references
    env_vars: dict[str, str] = {}
    if (
        req.backend == "snowflake"
        and req.snowflake_private_key_path
        and req.snowflake_auth_method == "private_key"
    ):
        env_vars["SNOWFLAKE_PRIVATE_KEY_PATH"] = req.snowflake_private_key_path
    if (
        req.backend == "snowflake"
        and req.snowflake_pat_token
        and req.snowflake_auth_method == "pat"
    ):
        env_vars["SNOWFLAKE_PAT_TOKEN"] = req.snowflake_pat_token
    if req.backend == "duckdb" and req.duckdb_path:
        env_vars["DUCKDB_PATH"] = req.duckdb_path
    if req.backend == "databricks":
        # PAT path: the wizard may have written DATABRICKS_TOKEN to .env
        # already; this per-project env mapping ensures dbt resolves
        # env_var('DATABRICKS_TOKEN') even when the runtime process
        # hasn't exported it. OAuth U2M tokens live in the per-host
        # keychain blob, not the project env.
        if (
            req.databricks_pat_token
            and req.databricks_auth_method == "pat"
        ):
            env_vars["DATABRICKS_TOKEN"] = req.databricks_pat_token
        if req.databricks_host:
            # Normalize via the canonical helper so the per-project env
            # value matches data["host"] / DATABRICKS_HOST in .env.
            env_vars["DATABRICKS_HOST"] = _normalize_databricks_host(
                req.databricks_host
            )
        if req.databricks_http_path:
            env_vars["DATABRICKS_HTTP_PATH"] = req.databricks_http_path
    # Parse user-supplied comma-separated key=val pairs (e.g. DBT_PROJECT_DIR
    # references in dbt_project.yml, or DuckDB env_var() refs). _parse_env_vars
    # filters reserved keys (SNOWFLAKE_PRIVATE_KEY_PATH, SNOWFLAKE_PAT_TOKEN,
    # DUCKDB_PATH, DATABRICKS_TOKEN, DATABRICKS_HOST, DATABRICKS_HTTP_PATH) so
    # user input cannot clobber credential fields set above. Local import
    # avoids a circular with desktop_projects.
    from lineage.api.desktop_projects import _parse_env_vars

    env_vars.update(_parse_env_vars(req.env_vars))
    if env_vars:
        project["env"] = env_vars

    if req.salesforce_enabled:
        sf: dict[str, Any] = {"enabled": True}
        if req.salesforce_client_id:
            sf["client_id"] = req.salesforce_client_id
        sf["login_url"] = req.salesforce_login_url or "https://login.salesforce.com"
        if req.salesforce_auth_type:
            sf["auth_type"] = str(req.salesforce_auth_type)
        if req.salesforce_instance_url:
            sf["instance_url"] = req.salesforce_instance_url
        if req.salesforce_username:
            sf["username"] = req.salesforce_username
        project["salesforce"] = sf
    if req.cube_enabled:
        cube: dict[str, Any] = {"enabled": True}
        if req.cube_project_dir:
            cube["project_dir"] = req.cube_project_dir
        project["cube"] = cube
    if req.lookml_enabled:
        lookml: dict[str, Any] = {"enabled": True}
        if req.lookml_project_dir:
            lookml["project_dir"] = req.lookml_project_dir
        project["lookml"] = lookml
    if req.fivetran_enabled:
        ft: dict[str, Any] = {"enabled": True}
        if req.fivetran_connector_ids:
            ft["connector_ids"] = req.fivetran_connector_ids
        project["fivetran"] = ft
    if req.linear_enabled:
        ticket: dict[str, Any] = {"enabled": True, "backend": "linear"}
        if req.linear_team_id:
            ticket["team_id"] = req.linear_team_id
        project["ticket"] = ticket

    project["profiling"] = {"enabled": req.profiling_enabled}

    return project
