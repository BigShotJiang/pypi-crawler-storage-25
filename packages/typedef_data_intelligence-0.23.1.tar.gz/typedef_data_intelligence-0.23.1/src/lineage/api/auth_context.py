"""Helpers for resolving desktop request identity context."""

from __future__ import annotations

from collections.abc import Mapping


def personal_org_id(user_id: str) -> str:
    """Return the deterministic personal-org fallback for a Clerk user."""
    return f"personal_{user_id}"


def resolve_user_context(
    headers: Mapping[str, str],
    *,
    default_user_id: str,
    default_org_id: str,
) -> tuple[str, str]:
    """Resolve request user/org context from Clerk or legacy headers."""
    clerk_user_id = headers.get("X-Clerk-User-Id")
    if clerk_user_id:
        return clerk_user_id, headers.get("X-Clerk-Org-Id") or personal_org_id(
            clerk_user_id
        )

    return (
        headers.get("X-User-Id") or default_user_id,
        headers.get("X-Org-Id") or default_org_id,
    )
