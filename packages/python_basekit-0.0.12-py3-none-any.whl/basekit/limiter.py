import asyncio
import time
from collections import deque
from collections.abc import Awaitable, Callable, Coroutine
from contextlib import nullcontext
from functools import wraps
from typing import Annotated, Any, Literal, Self, override

from pydantic import BaseModel, Field, PrivateAttr


class AsyncRateLimiter(BaseModel):
    limit: Annotated[int, Field(gt=0)]
    window: Annotated[float, Field(gt=0)] = 60.0

    _timestamps: deque[float] = PrivateAttr()
    _lock: asyncio.Lock = PrivateAttr()
    _waiters: deque[asyncio.Future[None]] = PrivateAttr()
    _wake_task: asyncio.Task[None] | None = PrivateAttr()

    @override
    def model_post_init(self, context) -> None:
        self._timestamps = deque()
        self._lock = asyncio.Lock()
        self._waiters = deque()
        self._wake_task = None

    def _evict(self, now: float, /) -> None:
        cutoff: float = now - self.window
        dq: deque[float] = self._timestamps

        while dq and dq[0] < cutoff:
            dq.popleft()

    def _drain_waiters_unlocked(self, now: float, /) -> None:
        self._evict(now)

        while self._waiters and len(self._timestamps) < self.limit:
            waiter: asyncio.Future[None] = self._waiters.popleft()
            if waiter.done():
                continue
            self._timestamps.append(now)
            waiter.set_result(None)

    def _reschedule_wake_unlocked(self, now: float, /) -> None:
        self._drain_waiters_unlocked(now)

        if not self._waiters:
            if self._wake_task is not None and not self._wake_task.done():
                self._wake_task.cancel()
            self._wake_task = None
            return

        if self._wake_task is not None and not self._wake_task.done():
            return

        wait: float = max(self._timestamps[0] + self.window - now, 0.0)
        self._wake_task = asyncio.create_task(coro=self._wake_after(wait))

    async def _wake_after(self, wait: float, /) -> None:
        try:
            await asyncio.sleep(delay=wait)
        except asyncio.CancelledError:
            return

        async with self._lock:
            if self._wake_task is not asyncio.current_task():
                return
            self._wake_task = None
            self._reschedule_wake_unlocked(time.monotonic())

    async def _acquire(self) -> None:
        async with self._lock:
            now: float = time.monotonic()
            self._evict(now)
            if not self._waiters and len(self._timestamps) < self.limit:
                self._timestamps.append(now)
                return

            waiter: asyncio.Future[None] = asyncio.get_running_loop().create_future()
            self._waiters.append(waiter)
            self._reschedule_wake_unlocked(now)

        try:
            await waiter
        except asyncio.CancelledError:
            async with self._lock:
                try:
                    self._waiters.remove(waiter)
                except ValueError:
                    pass
                self._reschedule_wake_unlocked(time.monotonic())
            raise

    async def __aenter__(self) -> Self:
        await self._acquire()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return

    def __call__[T, **P](
        self, func: Callable[P, Awaitable[T]], /
    ) -> Callable[P, Coroutine[Any, Any, T]]:
        @wraps(wrapped=func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            async with self:
                return await func(*args, **kwargs)

        return wrapper


class AsyncConcurrencyLimiter(BaseModel):
    limit: Annotated[int, Field(gt=0)]

    _semaphore: asyncio.Semaphore = PrivateAttr()

    @override
    def model_post_init(self, context) -> None:
        self._semaphore = asyncio.Semaphore(value=self.limit)

    async def __aenter__(self) -> Self:
        await self._semaphore.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self._semaphore.__aexit__(exc_type=exc_type, exc=exc, tb=tb)

    def __call__[T, **P](
        self, func: Callable[P, Awaitable[T]], /
    ) -> Callable[P, Coroutine[Any, Any, T]]:
        @wraps(wrapped=func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            async with self:
                return await func(*args, **kwargs)

        return wrapper


class AsyncLimiter(BaseModel):
    concurrency_limit: Annotated[int | None, Field(gt=0)]
    rate_limit: Annotated[int | None, Field(gt=0)]
    rate_window: Annotated[float, Field(gt=0)] = 60.0

    _concurrency_limiter: AsyncConcurrencyLimiter | nullcontext = PrivateAttr()
    _rate_limiter: AsyncRateLimiter | nullcontext = PrivateAttr()

    @override
    def model_post_init(self, context) -> None:
        self._concurrency_limiter = (
            AsyncConcurrencyLimiter(limit=self.concurrency_limit)
            if self.concurrency_limit is not None
            else nullcontext()
        )
        self._rate_limiter = (
            AsyncRateLimiter(limit=self.rate_limit, window=self.rate_window)
            if self.rate_limit is not None
            else nullcontext()
        )

    async def __aenter__(self) -> Self:
        await self._concurrency_limiter.__aenter__()
        await self._rate_limiter.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> Literal[False]:
        await self._concurrency_limiter.__aexit__(exc_type, exc, tb)
        await self._rate_limiter.__aexit__(exc_type, exc, tb)
        return False

    def __call__[T, **P](
        self, func: Callable[P, Awaitable[T]], /
    ) -> Callable[P, Coroutine[Any, Any, T]]:
        @wraps(wrapped=func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            async with self:
                return await func(*args, **kwargs)

        return wrapper
