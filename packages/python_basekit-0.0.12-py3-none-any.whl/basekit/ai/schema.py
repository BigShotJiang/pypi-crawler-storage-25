from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Any, ClassVar, Literal, override

from httpx import HTTPStatusError, RequestError
from pydantic import BaseModel, ConfigDict, PrivateAttr
from tenacity import (
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential_jitter,
)
from tenacity.stop import stop_base
from tenacity.wait import wait_base

from basekit.cache.schema import Cache
from basekit.http.clients.httpx import HttpxClient
from basekit.http.schema import DEFAULT_LIMIT
from basekit.limiter import AsyncLimiter

type ImageSize = Literal["1K", "2K", "4K"]
type ImageRatio = Literal[
    "9:16", "2:3", "3:4", "4:5", "1:1", "5:4", "4:3", "3:2", "16:9"
]


class NotSupportedError(ValueError):
    pass


class ValidationError(ValueError):
    pass


class Usage(BaseModel):
    input_tokens: int
    cache_creation_tokens: int
    cache_read_tokens: int
    output_tokens: int

    def format(self) -> str:
        return f"↓{self.input_tokens}(+{self.cache_creation_tokens},→{self.cache_read_tokens})/↑{self.output_tokens}"  # noqa: E501


class Tool[T: BaseModel](BaseModel):
    name: str
    description: str
    input_schema: type[T]


class Model(BaseModel):
    cache_key_fields: ClassVar[tuple[str, ...]] = ("name", "extra_params")

    name: str
    alias: str | None = None
    concurrency_limit: int | None = None
    rate_limit: int | None = None
    extra_params: dict | None = None

    @property
    def request_name(self) -> str:
        return self.alias or self.name


class AIClient(BaseModel):
    model_config: ClassVar[ConfigDict] = ConfigDict(arbitrary_types_allowed=True)
    cache_key_fields: ClassVar[tuple[str, ...]] = ("model",)

    model: Model
    retry_stop: stop_base = stop_after_attempt(max_attempt_number=3)
    retry_wait: wait_base = wait_exponential_jitter()
    cache: Cache | None = None

    _http_client: HttpxClient = PrivateAttr()
    _limiter: AsyncLimiter = PrivateAttr()

    @override
    def model_post_init(self, context: Any) -> None:
        self._http_client = HttpxClient(
            timeout=600.0, limit=self.model.concurrency_limit or DEFAULT_LIMIT
        )
        self._limiter = AsyncLimiter(
            concurrency_limit=self.model.concurrency_limit,
            rate_limit=self.model.rate_limit,
            rate_window=60.0,
        )

    @asynccontextmanager
    async def lifespan(self) -> AsyncIterator[None]:
        async with self._http_client.lifespan():
            yield

    def _should_retry(self, exc: BaseException, /) -> bool:
        if isinstance(exc, RequestError):
            return True
        if isinstance(exc, HTTPStatusError):
            status_code: int = exc.response.status_code
            return status_code == 429 or status_code >= 500
        if isinstance(exc, ValidationError):
            return True
        return False

    def _wrap[T, **P](
        self, func: Callable[P, Awaitable[T]], /
    ) -> Callable[P, Awaitable[T]]:
        wrapped_func: Callable[P, Awaitable[T]] = retry(
            retry=retry_if_exception(predicate=self._should_retry),
            stop=self.retry_stop,
            wait=self.retry_wait,
            reraise=True,
        )(func)
        return self.cache(wrapped_func) if self.cache else wrapped_func

    async def _create_message_once(
        self, system: str, prompt: str, extra: dict | None
    ) -> str:
        raise NotImplementedError

    async def create_message(
        self, system: str, prompt: str, extra: dict | None = None
    ) -> str:
        return await self._wrap(self._create_message_once)(
            system=system, prompt=prompt, extra=extra
        )

    async def _create_structured_message_once[T: BaseModel](
        self, system: str, prompt: str, schema: type[T], extra: dict | None
    ) -> T:
        raise NotImplementedError

    async def create_structured_message[T: BaseModel](
        self, system: str, prompt: str, schema: type[T], extra: dict | None = None
    ) -> T:
        return await self._wrap(self._create_structured_message_once)(
            system=system, prompt=prompt, schema=schema, extra=extra
        )

    async def _create_tool_use_once[T: BaseModel](
        self, system: str, prompt: str, tool: Tool[T], extra: dict | None
    ) -> T:
        raise NotImplementedError

    async def create_tool_use[T: BaseModel](
        self, system: str, prompt: str, tool: Tool[T], extra: dict | None = None
    ) -> T:
        return await self._wrap(self._create_tool_use_once)(
            system=system, prompt=prompt, tool=tool, extra=extra
        )

    async def _create_image_once(
        self, prompt: str, ratio: ImageRatio, size: ImageSize, extra: dict | None
    ) -> bytes:
        raise NotImplementedError

    async def create_image(
        self, prompt: str, ratio: ImageRatio, size: ImageSize, extra: dict | None = None
    ) -> bytes:
        return await self._wrap(self._create_image_once)(
            prompt=prompt, ratio=ratio, size=size, extra=extra
        )
