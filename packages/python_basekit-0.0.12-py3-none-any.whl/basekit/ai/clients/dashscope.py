from collections.abc import Callable
from typing import ClassVar, override

import logfire
from httpx import Response
from pydantic import BaseModel

from basekit.ai.schema import (
    AIClient,
    ImageRatio,
    ImageSize,
    NotSupportedError,
    ValidationError,
)
from basekit.utils.misc import recursive_merge


class ImageUsage(BaseModel):
    width: int
    height: int

    def format(self) -> str:
        return f"{self.width}x{self.height}"


class DashScopeClient(AIClient):
    cache_key_fields: ClassVar[tuple[str, ...]] = ()

    api_key: str
    base_url: str = "https://dashscope.aliyuncs.com/api/v1"

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _image_url(self) -> str:
        return f"{self.base_url}/services/aigc/multimodal-generation/generation"

    def _image_resolution(self, ratio: ImageRatio, size: ImageSize, /) -> str:
        base_resolution_map: dict[ImageRatio, tuple[int, int]] = {
            "9:16": (768, 1344),
            "2:3": (832, 1248),
            "3:4": (864, 1184),
            "4:5": (896, 1152),
            "1:1": (1024, 1024),
            "5:4": (1152, 896),
            "4:3": (1184, 864),
            "3:2": (1248, 832),
            "16:9": (1344, 768),
        }
        resolution_ratio_map: dict[ImageSize, int] = {"1K": 1, "2K": 2, "4K": 4}

        width: int = base_resolution_map[ratio][0] * resolution_ratio_map[size]
        height: int = base_resolution_map[ratio][1] * resolution_ratio_map[size]
        resolution: str = f"{width}*{height}"

        match self.model.name:
            case "qwen-image-2.0" | "qwen-image-2.0-pro":
                if size not in {"1K", "2K"}:
                    raise NotSupportedError(
                        f"模型 {self.model.name} 仅支持 1K 和 2K 分辨率"
                    )
                return resolution
            case _:
                raise NotSupportedError(f"模型 {self.model.name} 不合法")

    def _image_params(self, prompt: str, resolution: str, /) -> dict:
        return {
            "model": self.model.request_name,
            "input": {"messages": [{"role": "user", "content": [{"text": prompt}]}]},
            "parameters": {"size": resolution},
        }

    def _get_block(self, data: dict, filter_: Callable[[dict], bool], /) -> dict:
        choices: list = data["output"]["choices"]
        if len(choices) != 1:
            raise ValueError(f"LEN(CHOICES)：{len(choices)}")

        choice: dict = choices[0]
        if choice["finish_reason"] != "stop":
            raise ValueError(f"FINISH REASON：{choice['finish_reason']}")

        blocks: list[dict] = [c for c in choice["message"]["content"] if filter_(c)]
        if not blocks:
            raise ValueError(f"LEN(BLOCKS)：{len(blocks)}")

        return blocks[0]

    def _get_usage(self, data: dict, /) -> ImageUsage:
        usage: dict = data["usage"]
        return ImageUsage(width=usage["width"], height=usage["height"])

    @override
    async def _create_image_once(
        self, prompt: str, ratio: ImageRatio, size: ImageSize, extra: dict | None
    ) -> bytes:
        with logfire.span("dashscope client | create image") as span:
            resolution: str = self._image_resolution(ratio, size)

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="ratio", value=ratio)
            span.set_attribute(key="size", value=size)
            span.set_attribute(key="extra", value=extra)
            span.set_attribute(key="resolution", value=resolution)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._image_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._image_params(prompt, resolution),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, lambda c: "image" in c)
                image_url: str = block["image"]
                image: bytes = (await self._http_client.get(image_url)).content
                usage: ImageUsage = self._get_usage(data)

                span.set_attribute(key="image_url", value=image_url)
                span.set_attribute(key="filesize", value=len(image))
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} pixels"
                return image
            except Exception as exc:
                raise ValidationError("生成图像失败") from exc
