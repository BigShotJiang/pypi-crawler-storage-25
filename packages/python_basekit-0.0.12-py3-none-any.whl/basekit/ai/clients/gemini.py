import base64
from collections.abc import Callable
from typing import ClassVar, override

import logfire
from httpx import Response
from pydantic import BaseModel

from basekit.ai.schema import (
    AIClient,
    ImageRatio,
    ImageSize,
    NotSupportedError,
    Tool,
    Usage,
    ValidationError,
)
from basekit.ai.utils import transform_schema
from basekit.utils.misc import recursive_merge


class GeminiClient(AIClient):
    cache_key_fields: ClassVar[tuple[str, ...]] = ()

    api_key: str
    base_url: str = "https://generativelanguage.googleapis.com"

    def _headers(self) -> dict:
        return {"X-Goog-Api-Key": self.api_key, "Content-Type": "application/json"}

    def _message_url(self) -> str:
        return (
            f"{self.base_url}/v1beta/models/{self.model.request_name}:generateContent"
        )

    def _message_params(self, system: str, prompt: str, /) -> dict:
        return {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "responseModalities": ["TEXT"],
                "thinkingConfig": {"includeThoughts": True},
            },
        }

    def _structured_message_params(self, schema: dict, /) -> dict:
        return {
            "generationConfig": {
                "responseMimeType": "application/json",
                "responseSchema": schema,
            },
        }

    def _tool_use_params(self, tool: dict, /) -> dict:
        return {
            "tools": [{"functionDeclarations": [tool]}],
            "toolConfig": {"functionCallingConfig": {"mode": "ANY"}},
        }

    def _image_url(self) -> str:
        return (
            f"{self.base_url}/v1beta/models/{self.model.request_name}:generateContent"
        )

    def _image_config(self, ratio: ImageRatio, size: ImageSize, /) -> dict:
        match self.model.name:
            case "gemini-3.1-flash-image-preview":
                return {"aspectRatio": ratio, "imageSize": size}
            case "gemini-3-pro-image-preview":
                return {"aspectRatio": ratio, "imageSize": size}
            case "gemini-2.5-flash-image":
                if size != "1K":
                    raise NotSupportedError(f"模型 {self.model.name} 仅支持 1K 分辨率")
                return {"aspectRatio": ratio}
            case _:
                raise NotSupportedError(f"模型 {self.model.name} 不合法")

    def _image_params(self, prompt: str, config: dict, /) -> dict:
        return {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "responseModalities": ["IMAGE"],
                "thinkingConfig": {"includeThoughts": True},
                "imageConfig": config,
            },
        }

    def _get_block(self, data: dict, filter_: Callable[[dict], bool], /) -> dict:
        candidates: list = data["candidates"]
        if len(candidates) != 1:
            raise ValueError(f"LEN(CANDIDATES)：{len(candidates)}")

        candidate: dict = candidates[0]
        if candidate["finishReason"] != "STOP":
            raise ValueError(f"FINISH REASON：{candidate['finishReason']}")

        blocks: list[dict] = [
            p
            for p in candidate["content"]["parts"]
            if filter_(p) and "thought" not in p
        ]
        if len(blocks) != 1:
            raise ValueError(f"LEN(BLOCKS)：{len(blocks)}")

        return blocks[0]

    def _get_usage(self, data: dict, /) -> Usage:
        metadata: dict = data["usageMetadata"]
        return Usage(
            input_tokens=metadata["promptTokenCount"],
            cache_creation_tokens=0,
            cache_read_tokens=metadata.get("cachedContentTokenCount", 0),
            output_tokens=metadata.get("thoughtsTokenCount", 0)
            + metadata["candidatesTokenCount"],
        )

    @override
    async def _create_message_once(
        self, system: str, prompt: str, extra: dict | None
    ) -> str:
        with logfire.span("gemini client | create message") as span:
            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, lambda x: "text" in x)
                message: str = block["text"]
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=message)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return message
            except Exception as exc:
                raise ValidationError("生成消息失败") from exc

    @override
    async def _create_structured_message_once[T: BaseModel](
        self, system: str, prompt: str, schema: type[T], extra: dict | None
    ) -> T:
        schema_name: str = schema.__name__
        with logfire.span(
            f"gemini client | create structured message | {schema_name}"
        ) as span:
            schema_data: dict = transform_schema(
                schema.model_json_schema(), gemini=True
            )

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="schema", value=schema_data)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self._structured_message_params(schema_data),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, lambda x: "text" in x)
                result: T = schema.model_validate_json(json_data=block["text"])
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=result)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return result
            except Exception as exc:
                raise ValidationError("生成结构化消息失败") from exc

    @override
    async def _create_tool_use_once[T: BaseModel](
        self, system: str, prompt: str, tool: Tool[T], extra: dict | None
    ) -> T:
        tool_name: str = tool.name
        with logfire.span(f"gemini client | create tool use | {tool_name}") as span:
            tool_: dict = {
                "name": tool.name,
                "description": tool.description,
                "parameters": transform_schema(
                    tool.input_schema.model_json_schema(), gemini=True
                ),
            }

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="tool", value=tool_)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self._tool_use_params(tool_),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, lambda x: "functionCall" in x)
                result: T = tool.input_schema.model_validate(
                    obj=block["functionCall"]["args"]
                )
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=result)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return result
            except Exception as exc:
                raise ValidationError("生成工具调用失败") from exc

    @override
    async def _create_image_once(
        self, prompt: str, ratio: ImageRatio, size: ImageSize, extra: dict | None
    ) -> bytes:
        with logfire.span("gemini client | create image") as span:
            config: dict = self._image_config(ratio, size)

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="ratio", value=ratio)
            span.set_attribute(key="size", value=size)
            span.set_attribute(key="extra", value=extra)
            span.set_attribute(key="config", value=config)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._image_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._image_params(prompt, config),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, lambda x: "inlineData" in x)
                image: bytes = base64.b64decode(s=block["inlineData"]["data"])
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="filesize", value=len(image))
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return image
            except Exception as exc:
                raise ValidationError("生成图像失败") from exc
