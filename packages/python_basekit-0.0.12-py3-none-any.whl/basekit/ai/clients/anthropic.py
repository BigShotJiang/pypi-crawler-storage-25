from collections.abc import Callable
from typing import ClassVar, override

import logfire
from httpx import Response
from pydantic import BaseModel

from basekit.ai.schema import AIClient, Tool, Usage, ValidationError
from basekit.ai.utils import transform_schema
from basekit.utils.misc import recursive_merge


class AnthropicClient(AIClient):
    cache_key_fields: ClassVar[tuple[str, ...]] = ("max_tokens",)

    api_key: str
    base_url: str = "https://api.anthropic.com"
    max_tokens: int = 16000

    def _headers(self) -> dict:
        return {
            "X-Api-Key": self.api_key,
            "Anthropic-Version": "2023-06-01",
            "Content-Type": "application/json",
        }

    def _message_url(self) -> str:
        return f"{self.base_url}/v1/messages"

    def _message_params(self, system: str, prompt: str, /) -> dict:
        return {
            "model": self.model.request_name,
            "system": system,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": self.max_tokens,
        }

    def _structured_message_params(self, schema: dict, /) -> dict:
        return {"output_config": {"format": {"type": "json_schema", "schema": schema}}}

    def _tool_use_params(self, tool: dict, /) -> dict:
        return {"tools": [tool], "tool_choice": {"type": "any"}}

    def _get_block(
        self, data: dict, stop_reason: str, filter_: Callable[[dict], bool], /
    ) -> dict:
        if data["stop_reason"] != stop_reason:
            raise ValueError(f"STOP REASON：{data['stop_reason']}")

        blocks: list[dict] = [c for c in data["content"] if filter_(c)]
        if len(blocks) != 1:
            raise ValueError(f"LEN(BLOCKS)：{len(blocks)}")

        return blocks[0]

    def _get_usage(self, data: dict, /) -> Usage:
        usage: dict = data["usage"]
        cache_creation_tokens: int = usage.get("cache_creation_input_tokens", 0)
        cache_read_tokens: int = usage.get("cache_read_input_tokens", 0)
        return Usage(
            input_tokens=usage["input_tokens"]
            + cache_creation_tokens
            + cache_read_tokens,
            cache_creation_tokens=cache_creation_tokens,
            cache_read_tokens=cache_read_tokens,
            output_tokens=usage["output_tokens"],
        )

    @override
    async def _create_message_once(
        self, system: str, prompt: str, extra: dict | None
    ) -> str:
        with logfire.span("anthropic client | create message") as span:
            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(
                    data, "end_turn", lambda x: x["type"] == "text"
                )
                message: str = block["text"]
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=message)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return message
            except Exception as exc:
                raise ValidationError("生成消息失败") from exc

    @override
    async def _create_structured_message_once[T: BaseModel](
        self, system: str, prompt: str, schema: type[T], extra: dict | None
    ) -> T:
        schema_name: str = schema.__name__
        with logfire.span(
            f"anthropic client | create structured message | {schema_name}"
        ) as span:
            schema_data: dict = transform_schema(schema.model_json_schema())

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="schema", value=schema_data)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self._structured_message_params(schema_data),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(
                    data, "end_turn", lambda x: x["type"] == "text"
                )
                result: T = schema.model_validate_json(json_data=block["text"])
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=result)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return result
            except Exception as exc:
                raise ValidationError("生成结构化消息失败") from exc

    @override
    async def _create_tool_use_once[T: BaseModel](
        self, system: str, prompt: str, tool: Tool[T], extra: dict | None
    ) -> T:
        tool_name: str = tool.name
        with logfire.span(f"anthropic client | create tool use | {tool_name}") as span:
            tool_: dict = {
                "name": tool.name,
                "description": tool.description,
                "input_schema": transform_schema(tool.input_schema.model_json_schema()),
                "strict": True,
            }

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="tool", value=tool_)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self._tool_use_params(tool_),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(
                    data, "tool_use", lambda x: x["type"] == "tool_use"
                )
                result: T = tool.input_schema.model_validate(obj=block["input"])
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=result)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return result
            except Exception as exc:
                raise ValidationError("生成工具调用失败") from exc
