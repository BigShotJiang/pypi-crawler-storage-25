from collections.abc import Callable
from typing import ClassVar, override

import logfire
from httpx import Response
from pydantic import BaseModel

from basekit.ai.schema import AIClient, Tool, Usage, ValidationError
from basekit.ai.utils import transform_schema
from basekit.utils.misc import recursive_merge


class OpenAIClient(AIClient):
    cache_key_fields: ClassVar[tuple[str, ...]] = ()

    api_key: str
    base_url: str = "https://api.openai.com/v1"

    def _headers(self, /) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _message_url(self, /) -> str:
        return f"{self.base_url}/responses"

    def _message_params(self, system: str, prompt: str, /) -> dict:
        return {
            "model": self.model.request_name,
            "instructions": system,
            "input": [{"role": "user", "content": prompt}],
        }

    def _structured_message_params(self, name: str, schema: dict, /) -> dict:
        config: dict = {"name": name, "schema": schema, "strict": True}
        return {"text": {"format": {"type": "json_schema", **config}}}

    def _tool_use_params(self, tool: dict, /) -> dict:
        return {"tools": [tool], "tool_choice": "required"}

    def _check_status(self, data: dict, /) -> bool:
        return "status" not in data or data["status"] == "completed"

    def _get_block(self, data: dict, filter_: Callable[[dict], bool], /) -> dict:
        if not self._check_status(data):
            raise ValueError(f"STATUS：{data['status']}")

        blocks: list[dict] = [
            o for o in data["output"] if filter_(o) and self._check_status(o)
        ]
        if len(blocks) != 1:
            raise ValueError(f"LEN(BLOCKS)：{len(blocks)}")

        return blocks[0]

    def _get_text(self, block: dict, /) -> str:
        contents: list[dict] = [
            c for c in block["content"] if c["type"] == "output_text"
        ]
        if len(contents) != 1:
            raise ValueError(f"LEN(CONTENTS)：{len(contents)}")

        return contents[0]["text"]

    def _get_usage(self, data: dict, /) -> Usage:
        usage: dict = data["usage"]
        return Usage(
            input_tokens=usage["input_tokens"],
            cache_creation_tokens=0,
            cache_read_tokens=usage["input_tokens_details"]["cached_tokens"],
            output_tokens=usage["output_tokens"],
        )

    @override
    async def _create_message_once(
        self, system: str, prompt: str, extra: dict | None
    ) -> str:
        with logfire.span("openai client | create message") as span:
            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, lambda x: x["type"] == "message")
                message: str = self._get_text(block)
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=message)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return message
            except Exception as exc:
                raise ValidationError("生成消息失败") from exc

    @override
    async def _create_structured_message_once[T: BaseModel](
        self, system: str, prompt: str, schema: type[T], extra: dict | None
    ) -> T:
        schema_name: str = schema.__name__
        with logfire.span(
            f"openai client | create structured message | {schema_name}"
        ) as span:
            schema_data: dict = transform_schema(schema.model_json_schema())

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="schema", value=schema_data)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self._structured_message_params(schema_name, schema_data),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, lambda x: x["type"] == "message")
                message: str = self._get_text(block)
                result: T = schema.model_validate_json(json_data=message)
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=result)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return result
            except Exception as exc:
                raise ValidationError("生成结构化消息失败") from exc

    @override
    async def _create_tool_use_once[T: BaseModel](
        self, system: str, prompt: str, tool: Tool[T], extra: dict | None
    ) -> T:
        tool_name: str = tool.name
        with logfire.span(f"openai client | create tool use | {tool_name}") as span:
            tool_: dict = {
                "type": "function",
                "name": tool.name,
                "description": tool.description,
                "parameters": transform_schema(tool.input_schema.model_json_schema()),
                "strict": True,
            }

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="tool", value=tool_)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self._tool_use_params(tool_),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(
                    data, lambda x: x["type"] == "function_call"
                )
                result: T = tool.input_schema.model_validate_json(
                    json_data=block["arguments"]
                )
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=result)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return result
            except Exception as exc:
                raise ValidationError("生成工具调用失败") from exc


class OpenAILegacyClient(AIClient):
    cache_key_fields: ClassVar[tuple[str, ...]] = ()

    api_key: str
    base_url: str = "https://api.openai.com/v1"

    def _headers(self, /) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _message_url(self, /) -> str:
        return f"{self.base_url}/chat/completions"

    def _message_params(self, system: str, prompt: str, /) -> dict:
        return {
            "model": self.model.request_name,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
        }

    def _structured_message_params(self, name: str, schema: dict, /) -> dict:
        config: dict = {"name": name, "schema": schema, "strict": True}
        return {"response_format": {"type": "json_schema", "json_schema": config}}

    def _tool_use_params(self, tool: dict, /) -> dict:
        return {"tools": [tool], "tool_choice": "required"}

    def _get_block(self, data: dict, finish_reason: str, /) -> dict:
        choices: list[dict] = data["choices"]
        if len(choices) != 1:
            raise ValueError(f"LEN(BLOCKS)：{len(choices)}")

        choice: dict = choices[0]
        if choice["finish_reason"] != finish_reason:
            raise ValueError(f"FINISH REASON：{choice['finish_reason']}")

        return choice["message"]

    def _get_arguments(self, block: dict, /) -> str:
        arguments: list[str] = [t["function"]["arguments"] for t in block["tool_calls"]]
        if len(arguments) != 1:
            raise ValueError(f"LEN(ARGUMENTS)：{len(arguments)}")

        return arguments[0]

    def _get_usage(self, data: dict, /) -> Usage:
        usage: dict = data["usage"]
        return Usage(
            input_tokens=usage["prompt_tokens"],
            cache_creation_tokens=0,
            cache_read_tokens=usage["prompt_tokens_details"]["cached_tokens"],
            output_tokens=usage["completion_tokens"],
        )

    @override
    async def _create_message_once(
        self, system: str, prompt: str, extra: dict | None
    ) -> str:
        with logfire.span("openai client (legacy) | create message") as span:
            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, "stop")
                message: str = block["content"]
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=message)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return message
            except Exception as exc:
                raise ValidationError("生成消息失败") from exc

    @override
    async def _create_structured_message_once[T: BaseModel](
        self, system: str, prompt: str, schema: type[T], extra: dict | None
    ) -> T:
        schema_name: str = schema.__name__
        with logfire.span(
            f"openai client (legacy) | create structured message | {schema_name}"
        ) as span:
            schema_data: dict = transform_schema(schema.model_json_schema())

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="schema", value=schema_data)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self._structured_message_params(schema_name, schema_data),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, "stop")
                result: T = schema.model_validate_json(json_data=block["content"])
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=result)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return result
            except Exception as exc:
                raise ValidationError("生成结构化消息失败") from exc

    @override
    async def _create_tool_use_once[T: BaseModel](
        self, system: str, prompt: str, tool: Tool[T], extra: dict | None
    ) -> T:
        tool_name: str = tool.name
        with logfire.span(
            f"openai client (legacy) | create tool use | {tool_name}"
        ) as span:
            tool_: dict = {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": transform_schema(
                        tool.input_schema.model_json_schema()
                    ),
                    "strict": True,
                },
            }

            span.set_attribute(key="model", value=self.model)
            span.set_attribute(key="system", value=system)
            span.set_attribute(key="prompt", value=prompt)
            span.set_attribute(key="tool", value=tool_)
            span.set_attribute(key="extra", value=extra)

            async with self._limiter:
                response: Response = await self._http_client.post(
                    self._message_url(),
                    headers=self._headers(),
                    data=recursive_merge(
                        self._message_params(system, prompt),
                        self._tool_use_params(tool_),
                        self.model.extra_params,
                        extra,
                    ),
                )

            try:
                data: dict = response.json()
                block: dict = self._get_block(data, "tool_calls")
                arguments: str = self._get_arguments(block)
                result: T = tool.input_schema.model_validate_json(json_data=arguments)
                usage: Usage = self._get_usage(data)

                span.set_attribute(key="return", value=result)
                span.set_attribute(key="usage", value=usage)
                span.message = f"{span.message} -> {usage.format()} tokens"
                return result
            except Exception as exc:
                raise ValidationError("生成工具调用失败") from exc
