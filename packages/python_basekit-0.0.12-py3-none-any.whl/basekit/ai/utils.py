from typing import cast

from basekit.ai.schema import NotSupportedError
from basekit.utils.misc import Any


def transform_schema(schema: Any, /, *, gemini: bool = False) -> dict:
    if not isinstance(schema, dict):
        raise NotSupportedError(f"仅支持字典类型模式，SCHEMA：{type(schema)}")

    strict_schema: dict = {}

    if "$ref" in schema:
        strict_schema["$ref"] = schema["$ref"]
        return strict_schema

    if "$defs" in schema:
        strict_schema["$defs"] = {
            key: transform_schema(value, gemini=gemini)
            for key, value in schema["$defs"].items()
        }

    if "title" in schema:
        strict_schema["title"] = schema["title"]

    if "description" in schema:
        strict_schema["description"] = schema["description"]

    if "enum" in schema:
        strict_schema["enum"] = schema["enum"]

    if "const" in schema:
        strict_schema["const"] = schema["const"]

    if "default" in schema:
        strict_schema["default"] = schema["default"]

    if "anyOf" in schema:
        strict_schema["anyOf"] = [
            transform_schema(cast(dict, item), gemini=gemini)
            for item in schema["anyOf"]
        ]

    if "type" not in schema:
        return strict_schema

    strict_schema["type"] = schema["type"]

    match strict_schema["type"]:
        case "object":
            strict_schema["properties"] = {
                key: transform_schema(value, gemini=gemini)
                for key, value in schema["properties"].items()
            }
            strict_schema["required"] = list(strict_schema["properties"].keys())
            if not gemini:
                strict_schema["additionalProperties"] = False
        case "array":
            strict_schema["items"] = transform_schema(schema["items"], gemini=gemini)
        case "string" | "number" | "integer" | "boolean" | "null":
            pass

    return strict_schema
