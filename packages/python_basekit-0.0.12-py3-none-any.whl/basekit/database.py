from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import override

from pydantic import BaseModel, PrivateAttr
from sqlalchemy import MetaData
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, create_async_engine


class DatabaseClient(BaseModel):
    url: str

    _engine: AsyncEngine = PrivateAttr()

    @override
    def model_post_init(self, context) -> None:
        self._engine = create_async_engine(url=self.url)

    @asynccontextmanager
    async def lifespan(self) -> AsyncIterator[None]:
        try:
            yield
        finally:
            await self._engine.dispose()

    async def create_schema(self, metadata: MetaData, /) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(fn=metadata.create_all)

    @asynccontextmanager
    async def connection(self) -> AsyncIterator[AsyncConnection]:
        async with self._engine.connect() as connection:
            yield connection
