from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress
from http.cookiejar import CookieJar
from typing import Any, override

import logfire
from curl_cffi import AsyncSession, BrowserTypeLiteral, Response
from curl_cffi.requests.exceptions import HTTPError
from pydantic import PrivateAttr

from basekit.http.schema import HttpClient, HttpMethod
from basekit.http.utils import clone_cookiejar, truncate_data


class CurlCffiClient(HttpClient[Response]):
    impersonate: BrowserTypeLiteral = "chrome"

    _client: AsyncSession = PrivateAttr()

    @override
    def model_post_init(self, context: Any) -> None:
        self._client = AsyncSession(
            headers=self.headers,
            verify=self.verify,
            http_version="v2",
            timeout=self.timeout,
            allow_redirects=True,
            max_clients=self.limit,
            impersonate=self.impersonate,
        )

    @override
    @asynccontextmanager
    async def lifespan(self) -> AsyncIterator[None]:
        async with self._client:
            yield

    def save_cookies(self) -> CookieJar:
        return clone_cookiejar(self._client.cookies.jar)

    def load_cookies(self, cookies: CookieJar) -> None:
        self._client.cookies = clone_cookiejar(cookies)

    def _extract_content(self, response: Response, /) -> dict | str | bytes:
        content_type: str = response.headers.get(key="Content-Type", default="") or ""
        content_type = content_type.split(sep=";")[0].strip().lower()
        if content_type == "application/json":
            with suppress(Exception):
                return response.json()
        if content_type.startswith("text/"):
            with suppress(Exception):
                return response.text
        with suppress(Exception):
            return response.content
        return b""

    async def _request_once(
        self,
        method: HttpMethod,
        url: str,
        /,
        *,
        params: dict | None = None,
        data: dict | None = None,
        headers: dict[str, str] | None = None,
    ) -> Response:
        with logfire.span(f"curl cffi client | request | {method} | {url}") as span:
            span.set_attribute(key="request_params", value=truncate_data(params))
            span.set_attribute(key="request_data", value=truncate_data(data))
            span.set_attribute(key="request_headers", value=truncate_data(headers))

            response: Response = await self._client.request(
                method=method, url=url, params=params, json=data, headers=headers
            )

            status_code: int = response.status_code
            span.set_attribute(key="status_code", value=status_code)
            span.message = f"{span.message} -> {status_code}"

            response_headers: dict = dict(response.headers.items())
            span.set_attribute(
                key="response_headers", value=truncate_data(response_headers)
            )

            response_content: dict | str | bytes = self._extract_content(response)
            span.set_attribute(
                key="response_content", value=truncate_data(response_content)
            )

            response.raise_for_status()
            return response

    def _should_retry(self, exc: BaseException, /) -> bool:
        if not isinstance(exc, HTTPError):
            return True
        if exc.response is None:
            return True
        status_code: int = exc.response.status_code
        return status_code == 429 or status_code >= 500
