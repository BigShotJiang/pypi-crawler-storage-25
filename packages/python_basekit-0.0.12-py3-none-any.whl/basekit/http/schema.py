from contextlib import AbstractAsyncContextManager
from http.cookiejar import CookieJar
from typing import ClassVar, Literal

from pydantic import BaseModel, ConfigDict
from tenacity import (
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential_jitter,
)
from tenacity.stop import stop_base
from tenacity.wait import wait_base

DEFAULT_TIMEOUT = 5.0
DEFAULT_LIMIT = 100
DEFAULT_RETRY_STOP = stop_after_attempt(max_attempt_number=3)
DEFAULT_RETRY_WAIT = wait_exponential_jitter()

type HttpMethod = Literal["GET", "POST"]


class HttpClient[ResponseT](BaseModel):
    model_config: ClassVar[ConfigDict] = ConfigDict(arbitrary_types_allowed=True)

    headers: dict[str, str] | None = None
    verify: bool = True
    timeout: float = DEFAULT_TIMEOUT
    limit: int = DEFAULT_LIMIT
    retry_stop: stop_base = DEFAULT_RETRY_STOP
    retry_wait: wait_base = DEFAULT_RETRY_WAIT

    def lifespan(self) -> AbstractAsyncContextManager[None]:
        raise NotImplementedError

    def save_cookies(self) -> CookieJar:
        raise NotImplementedError

    def load_cookies(self, cookies: CookieJar) -> None:
        raise NotImplementedError

    async def _request_once(
        self,
        method: HttpMethod,
        url: str,
        /,
        *,
        params: dict | None = None,
        data: dict | None = None,
        headers: dict[str, str] | None = None,
    ) -> ResponseT:
        raise NotImplementedError

    def _should_retry(self, exc: BaseException, /) -> bool:
        raise NotImplementedError

    async def request(
        self,
        method: HttpMethod,
        url: str,
        /,
        *,
        params: dict | None = None,
        data: dict | None = None,
        headers: dict[str, str] | None = None,
        retry_on_failure: bool = False,
    ) -> ResponseT:
        if not retry_on_failure:
            return await self._request_once(
                method, url, params=params, data=data, headers=headers
            )
        return await retry(
            retry=retry_if_exception(predicate=self._should_retry),
            stop=self.retry_stop,
            wait=self.retry_wait,
            reraise=True,
        )(self._request_once)(method, url, params=params, data=data, headers=headers)

    async def get(
        self,
        url: str,
        /,
        *,
        params: dict | None = None,
        headers: dict[str, str] | None = None,
        retry_on_failure: bool = True,
    ) -> ResponseT:
        return await self.request(
            "GET",
            url,
            params=params,
            headers=headers,
            retry_on_failure=retry_on_failure,
        )

    async def post(
        self,
        url: str,
        /,
        *,
        data: dict | None = None,
        headers: dict[str, str] | None = None,
        retry_on_failure: bool = False,
    ) -> ResponseT:
        return await self.request(
            "POST",
            url,
            data=data,
            headers=headers,
            retry_on_failure=retry_on_failure,
        )
