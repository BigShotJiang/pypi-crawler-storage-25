from http.cookiejar import CookieJar
from typing import Any

SIZE_LIMIT = 1048576  # 1MB


def truncate_data(value: Any, /) -> Any:
    match value:
        case dict():
            return {k: truncate_data(v) for k, v in value.items()}
        case list():
            return [truncate_data(v) for v in value]
        case str():
            size: int = len(value)
            if size <= SIZE_LIMIT:
                return value
            return f"[TOO LARGE: {size} chars]{value[:SIZE_LIMIT]}..."
        case bytes():
            size: int = len(value)
            if size <= SIZE_LIMIT:
                return value
            return f"[TOO LARGE: {size} bytes]{value[:SIZE_LIMIT]}..."
        case _:
            return value


def clone_cookiejar(cookiejar: CookieJar, /) -> CookieJar:
    cloned_cookie_jar = CookieJar()
    for cookie in cookiejar:
        cloned_cookie_jar.set_cookie(cookie=cookie)
    return cloned_cookie_jar
