from mimetypes import guess_extension, guess_type

from filetype import Type
from filetype import guess as guess_filetype

DEFAULT_MIME = "application/octet-stream"
DEFAULT_SUFFIX = ".bin"


def guess_mime(
    *, data: bytes | None = None, mime: str | None = None, suffix: str | None = None
) -> str:
    if data:
        file_type: Type | None = guess_filetype(obj=data)
        if file_type:
            return file_type.mime
    if mime:
        return mime
    if suffix:
        suffix_mime: str | None = guess_type(url=f"test{suffix}")[0]
        if suffix_mime:
            return suffix_mime
    return DEFAULT_MIME


def guess_suffix(
    *, data: bytes | None = None, mime: str | None = None, suffix: str | None = None
) -> str:
    if data:
        file_type: Type | None = guess_filetype(obj=data)
        if file_type:
            return f".{file_type.extension}"
    if mime:
        mime_suffix: str | None = guess_extension(type=mime)
        if mime_suffix:
            return mime_suffix
    if suffix:
        return suffix
    return DEFAULT_SUFFIX
