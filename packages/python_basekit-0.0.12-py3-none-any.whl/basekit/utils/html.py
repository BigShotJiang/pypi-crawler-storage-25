from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup, Tag
from bs4.element import AttributeValueList

from basekit.utils.misc import require_non_null, require_truthy


def join_url(url: str, base: str, /) -> str:
    if urlparse(url=url).scheme:
        return url
    if url.startswith("//"):
        return f"{urlparse(url=base).scheme}:{url}"
    return urljoin(base=base, url=url)


def extract_attr(element: Tag, key: str, /) -> str | None:
    value: str | AttributeValueList | None = element.get(key=key)
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return " ".join(value)


def has_class(element: Tag, class_name: str, /) -> bool:
    classes: str | None = extract_attr(element, "class")
    if classes is None:
        return False
    return class_name in classes.split(sep=" ")


def select_one(element: BeautifulSoup, selector: str, /) -> Tag:
    result: Tag | None = element.select_one(selector=selector)
    return require_non_null(result)


def select_many(element: BeautifulSoup, selector: str, /) -> list[Tag]:
    results: list[Tag] = element.select(selector=selector)
    return require_truthy(results)


def combine_htmls(*htmls: str) -> str:
    contents: list[str] = []
    for html in htmls:
        soup = BeautifulSoup(markup=html, features="lxml")
        for element in require_non_null(soup.body).children:
            contents.append(str(object=element))
    html: str = "".join(contents)
    return BeautifulSoup(markup=html, features="lxml").decode()


def extract_mime(content_type: str, /) -> str:
    return content_type.split(sep=";", maxsplit=1)[0].strip().lower()
