import asyncio
from collections.abc import Awaitable

import logfire


async def run_batch[T](coros: list[Awaitable[T]], /, *, strict: bool) -> list[T]:
    if strict:
        return await asyncio.gather(*coros)

    results: list[T | BaseException] = await asyncio.gather(
        *coros, return_exceptions=True
    )
    instances: list[T] = [r for r in results if not isinstance(r, BaseException)]
    errors: list[BaseException] = [r for r in results if isinstance(r, BaseException)]
    if errors:
        exception: BaseExceptionGroup[BaseException] = BaseExceptionGroup(
            f"批量运行协程失败，{len(instances)}成功，{len(errors)}失败", errors
        )
        logfire.exception(str(object=exception), _exc_info=exception)
    return instances
