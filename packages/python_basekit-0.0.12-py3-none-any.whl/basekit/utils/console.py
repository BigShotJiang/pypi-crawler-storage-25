from pydantic import BaseModel
from rich.console import Console
from rich.table import Table, box


def print_table[T: BaseModel](
    console: Console, instances: list[T], /, *, title: str | None = None
) -> None:
    table = Table(title=title, box=box.SQUARE_DOUBLE_HEAD, show_lines=True)

    if not instances:
        table.add_column(header="无数据", justify="center", overflow="fold")
        table.add_row("无数据")
        console.print(table)
        return

    cls: type[T] = instances[0].__class__
    for field in cls.model_fields.values():
        table.add_column(header=field.description or "-", overflow="fold")
    for instance in instances:
        fields: list[str] = [
            str(object=getattr(instance, field) or "-")
            for field in cls.model_fields.keys()
        ]
        table.add_row(*fields)
    console.print(table)
