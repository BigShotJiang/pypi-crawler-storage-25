from flowmark import reformat_text
from flowmark.linewrapping.markdown_filling import ListSpacing
from markdown_it import MarkdownIt
from markdown_it.tree import SyntaxTreeNode
from markdownify import markdownify

PARSER: MarkdownIt = (
    MarkdownIt(config="commonmark")
    .enable(names=["linkify", "replacements", "smartquotes"])
    .enable(names=["table", "strikethrough"])
)


def format_markdown(markdown: str, /) -> str:
    return reformat_text(
        text=markdown, width=65535, semantic=False, list_spacing=ListSpacing.tight
    )


def convert_markdown(html: str, /) -> str:
    markdown: str = markdownify(
        html=html, heading_style="ATX", bullets="-", wrap_width=65535
    )
    return format_markdown(markdown)


def parse_markdown(markdown: str, /) -> list[tuple[str, str]]:
    lines: list[str] = markdown.splitlines(keepends=True)
    root = SyntaxTreeNode(tokens=PARSER.parse(src=markdown))
    blocks: list[tuple[str, str]] = []
    for node in root.children:
        if node.map is None:
            continue
        content: str = "".join(lines[node.map[0] : node.map[1]]).strip()
        if not content:
            continue
        blocks.append((content, node.type))
    return blocks
