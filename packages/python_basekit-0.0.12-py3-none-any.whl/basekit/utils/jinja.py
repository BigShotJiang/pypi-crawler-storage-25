from jinja2 import Environment, Template

MARKDOWN_ENV: Environment = Environment(
    autoescape=False, keep_trailing_newline=True, lstrip_blocks=True, trim_blocks=True
)
MARKDOWN_ENV.policies["json.dumps_kwargs"]["ensure_ascii"] = False


def build_template(template: str, /) -> Template:
    return MARKDOWN_ENV.from_string(source=template)


def render_template(template: str, /, **kwargs) -> str:
    return build_template(template).render(**kwargs)
