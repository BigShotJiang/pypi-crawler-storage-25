from collections.abc import Mapping
from typing import Any


def require_non_null[T](v: T | None, /) -> T:
    if v is None:
        raise ValueError(f"期望非空值: {v}")
    return v


def require_truthy[T](v: T | None, /) -> T:
    if not v:
        raise ValueError(f"期望真值: {v}")
    return v


def remove_space(s: str, /) -> str:
    return " ".join(s.split())


def recursive_merge(*args: Mapping | None) -> dict:
    result: dict = {}

    for mapping in args:
        if mapping is None:
            continue

        for key, value in mapping.items():
            current: Any | None = result.get(key)
            if isinstance(current, Mapping) and isinstance(value, Mapping):
                result[key] = recursive_merge(current, value)
            else:
                result[key] = value

    return result
