import pickle
import pickletools
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel


class CacheKeyError(Exception):
    pass


class CacheValueError(Exception):
    pass


def get_instance(func: Callable, /) -> Any:
    current: Callable | None = func
    while current is not None:
        instance: Any = getattr(current, "__self__", None)
        if instance is not None:
            return instance
        current = getattr(current, "__wrapped__", None)
    return None


def cache_key_fields(cls: type[BaseModel], /) -> list[str]:
    model_fields: set[str] = set()
    cache_key_fields: set[str] = set()
    for base in reversed(cls.__mro__):
        if not issubclass(base, BaseModel):
            continue
        current_model_fields: set[str] = set(base.model_fields.keys()) - model_fields
        current_cache_key_fields: set[str] = set(
            base.__dict__.get("cache_key_fields", current_model_fields)
        )
        model_fields.update(current_model_fields)
        cache_key_fields.update(current_cache_key_fields)
    return list(cache_key_fields)


def build_cache_key(value: Any, /) -> dict:
    if isinstance(value, type) and issubclass(value, BaseModel):
        return {
            "module": value.__module__,
            "class": value.__qualname__,
            "schema": value.model_json_schema(),
        }
    if isinstance(value, BaseModel):
        cls: type[BaseModel] = value.__class__
        instance: dict = {f: getattr(value, f) for f in cache_key_fields(cls)}
        return {
            "module": cls.__module__,
            "class": cls.__qualname__,
            "instance": build_cache_key(instance),
        }
    if isinstance(value, dict):
        if not all(isinstance(k, str) for k in value.keys()):
            raise ValueError(f"字典键必须是字符串：{value.keys()}")
        return {"dict": {k: build_cache_key(v) for k, v in value.items()}}
    if isinstance(value, list):
        return {"list": [build_cache_key(i) for i in value]}
    if isinstance(value, tuple):
        return {"tuple": [build_cache_key(i) for i in value]}
    if isinstance(value, bytes):
        return {"bytes": value}
    if isinstance(value, str):
        return {"str": value}
    if isinstance(value, bool):
        return {"bool": value}
    if isinstance(value, int):
        return {"int": value}
    if isinstance(value, float):
        return {"float": value}
    if value is None:
        return {"none": None}
    raise ValueError(f"类型不支持序列化：{value.__class__}")


def normalize_cache_key(value: Any, /) -> Any:
    if isinstance(value, dict):
        return {k: normalize_cache_key(value[k]) for k in sorted(value.keys())}
    if isinstance(value, list):
        return [normalize_cache_key(item) for item in value]
    if isinstance(value, tuple):
        return tuple(normalize_cache_key(item) for item in value)
    return value


def serialize_cache_key(value: Any, /) -> bytes:
    try:
        data: dict = normalize_cache_key(build_cache_key(value))
        return pickletools.optimize(
            p=pickle.dumps(obj=data, protocol=pickle.HIGHEST_PROTOCOL)
        )
    except Exception as exc:
        raise CacheKeyError("缓存键序列化失败") from exc


def serialize_cache_value(value: Any, /) -> bytes:
    try:
        return pickletools.optimize(
            p=pickle.dumps(obj=value, protocol=pickle.HIGHEST_PROTOCOL)
        )
    except Exception as exc:
        raise CacheValueError("缓存值序列化失败") from exc


def deserialize_cache_value(value: bytes, /) -> Any:
    try:
        return pickle.loads(value)
    except Exception as exc:
        raise CacheValueError("缓存值反序列化失败") from exc
