from collections.abc import Awaitable, Callable
from contextlib import AbstractAsyncContextManager, suppress
from functools import wraps

from pydantic import BaseModel

from basekit.cache.utils import (
    CacheValueError,
    deserialize_cache_value,
    get_instance,
    serialize_cache_key,
    serialize_cache_value,
)


class Cache(BaseModel):
    def lifespan(self) -> AbstractAsyncContextManager[None]:
        raise NotImplementedError

    async def set(self, key: bytes, value: bytes, /) -> None:
        raise NotImplementedError

    async def get(self, key: bytes, /) -> bytes | None:
        raise NotImplementedError

    async def delete(self, key: bytes, /) -> None:
        raise NotImplementedError

    def __call__[**P, T](
        self, func: Callable[P, Awaitable[T]], /
    ) -> Callable[P, Awaitable[T]]:
        @wraps(wrapped=func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            data: dict = {
                "module": func.__module__,
                "function": func.__qualname__,
                "instance": get_instance(func),
                "args": args,
                "kwargs": kwargs,
            }
            key: bytes = serialize_cache_key(data)

            cached_value: bytes | None = await self.get(key)
            if cached_value is not None:
                with suppress(CacheValueError):
                    return deserialize_cache_value(cached_value)
                await self.delete(key)

            value: T = await func(*args, **kwargs)
            await self.set(key, serialize_cache_value(value))
            return value

        return wrapper
