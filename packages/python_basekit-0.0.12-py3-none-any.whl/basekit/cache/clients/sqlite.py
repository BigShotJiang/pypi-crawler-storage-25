import hashlib
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import override

from pydantic import PrivateAttr
from sqlalchemy import (
    Column,
    CursorResult,
    Delete,
    LargeBinary,
    MetaData,
    Row,
    Select,
    String,
    Table,
    delete,
    select,
)
from sqlalchemy.dialects.sqlite import Insert, insert

from basekit.cache.schema import Cache
from basekit.database import DatabaseClient


class SQLiteCache(Cache):
    path: Path | None = None

    _client: DatabaseClient = PrivateAttr()
    _metadata: MetaData = PrivateAttr()
    _table: Table = PrivateAttr()

    @override
    def model_post_init(self, context) -> None:
        self.path = self.path.expanduser().resolve() if self.path else None
        path: str = self.path.as_posix() if self.path else ":memory:"
        url: str = f"sqlite+aiosqlite:///{path}"
        self._client = DatabaseClient(url=url)
        self._metadata = MetaData()
        self._table = Table(
            "cache",
            self._metadata,
            Column("sha256", String(length=64), nullable=False, primary_key=True),
            Column("key", LargeBinary(), nullable=False),
            Column("value", LargeBinary(), nullable=False),
        )

    @override
    @asynccontextmanager
    async def lifespan(self) -> AsyncIterator[None]:
        async with self._client.lifespan():
            await self._client.create_schema(self._metadata)
            yield

    def _sha256(self, key: bytes, /) -> str:
        return hashlib.sha256(string=key).hexdigest()

    @override
    async def set(self, key: bytes, value: bytes, /) -> None:
        async with self._client.connection() as connection:
            statement: Insert = (
                insert(table=self._table)
                .values(sha256=self._sha256(key), key=key, value=value)
                .on_conflict_do_update(
                    index_elements=[self._table.c.sha256],
                    set_={"key": key, "value": value},
                )
            )
            await connection.execute(statement=statement)
            await connection.commit()

    @override
    async def get(self, key: bytes, /) -> bytes | None:
        async with self._client.connection() as connection:
            statement: Select = select(self._table.c.value).where(
                self._table.c.sha256 == self._sha256(key)
            )
            result: CursorResult = await connection.execute(statement=statement)
        row: Row | None = result.one_or_none()
        return row.value if row else None

    @override
    async def delete(self, key: bytes, /) -> None:
        async with self._client.connection() as connection:
            statement: Delete = delete(table=self._table).where(
                self._table.c.sha256 == self._sha256(key)
            )
            await connection.execute(statement=statement)
            await connection.commit()
