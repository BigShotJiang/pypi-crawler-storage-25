import os
from setuptools import setup
from setuptools.command.install import install
import sys

# Renkler
G = '\033[92m'
B = '\033[94m'
R = '\033[0m'

BANNER = f"""
{G}  ███████╗ {B} ███████╗ {G} ██████╗  {B} ██████╗  {G}  ██╗
{G}  ██╔════╝ {B} ██╔════╝ {G} ██╔══██╗ {B} ██╔══██╗ {G} ███║
{G}  █████╗   {B} █████╗   {G} ██████╔╝ {B} ██║  ██║ {G} ╚██║
{G}  ██╔══╝   {B} ██╔══╝   {G} ██╔══██╗ {B} ██║  ██║ {G}  ██║
{G}  ██║      {B} ███████╗ {G} ██║  ██║ {B} ██████╔╝ {G}  ██║
{G}  ╚═╝      {B} ╚══════╝ {G} ╚═╝  ╚═╝ {B} ╚═════╝  {G}  ╚═╝

         {B}>>> {G}FERDI LEGEND PİP KURULUYOR... {B}<<<
"""

class PostInstallCommand(install):
    def run(self):
        # Ekranı temizle ve yazıyı en başa bas
        os.system('clear') 
        print(f"{G}Ferdi Legend pip kuruluyor...{R}")
        print(BANNER)
        sys.stdout.flush() # Yazıyı hemen ekrana gönder
        install.run(self)

setup(
    name="ferdixlegend",
    version="0.3.1",
    packages=["ferdixlegend"],
    cmdclass={
        'install': PostInstallCommand,
    },
)

