import sys
import os

# ANSI Renk Kodları (İsimleri BANNER içindekiyle aynı yapıyoruz)
G = '\033[92m'  # Yeşil
B = '\033[94m'  # Mavi
RESET = '\033[0m'

# 3D "FERD1" Banner'ı
BANNER = f"""
{G}  ███████╗ {B} ███████╗ {G} ██████╗  {B} ██████╗  {G}  ██╗
{G}  ██╔════╝ {B} ██╔════╝ {G} ██╔══██╗ {B} ██╔══██╗ {G} ███║
{G}  █████╗   {B} █████╗   {G} ██████╔╝ {B} ██║  ██║ {G} ╚██║
{G}  ██╔══╝   {B} ██╔══╝   {G} ██╔══██╗ {B} ██║  ██║ {G}  ██║
{G}  ██║      {B} ███████╗ {G} ██║  ██║ {B} ██████╔╝ {G}  ██║
{G}  ╚═╝      {B} ╚══════╝ {G} ╚═╝  ╚═╝ {B} ╚═════╝  {G}  ╚═╝

{B}>>> FerdiLegend Paketi Yüklendi! <<< 
{G}>>> Hazırlayan: {B}FerdiLegend{RESET}
"""

def show_banner():
    # Banner'ı yazdır
    print(BANNER)

# Paket ithal edildiğinde banner'ı göster
if __name__ != "__main__":
    show_banner()

