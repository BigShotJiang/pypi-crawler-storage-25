"""Contains the implementations for the likelihood-free methods

Implements the supported likelihood-free methods.

"""

from collections.abc import Callable

from pydantic import Field

from ..base import CalibrationMethodBase, CalibrationWorkflowBase
from ..data_model import CalibrationModel

TASK = "likelihood_free"
BASE_IMPLEMENTATIONS: dict[str, str] = dict(
	elfi=f"calisim.experimental.{TASK}.elfi_wrapper:ELFILikelihoodFree"
)


def get_implementations() -> dict[str, str]:
	"""Get the calibration implementations for likelihood-free.

	Returns:
		Dict[str, str]: The dictionary of
			calibration implementations for likelihood-free.
	"""
	implementations = dict(BASE_IMPLEMENTATIONS)
	implementations.update(CalibrationMethodBase.load_external_implementations(TASK))
	return implementations


class LikelihoodFreeMethodModel(CalibrationModel):
	"""The likelihood-free method data model.

	Args:
	    BaseModel (CalibrationModel): The calibration base model class.
	"""

	epsilon: float = Field(
		description="The dissimilarity threshold between observed and simulated data",
		default=0,
	)
	acq_noise_var: float = Field(
		description="Noise added to Lower Confidence Bound Selection Criterion",
		default=0,
	)
	sampler: str = Field(
		description="The sampling algorithm to perform inference", default="metropolis"
	)


class LikelihoodFreeMethod(CalibrationMethodBase):
	"""The likelihood-free method class."""

	def __init__(
		self,
		calibration_func: Callable,
		specification: LikelihoodFreeMethodModel,
		engine: str = "elfi",
		implementation: type[CalibrationWorkflowBase]
		| CalibrationWorkflowBase
		| None = None,
	) -> None:
		"""LikelihoodFreeMethod constructor.

		Args:
			calibration_func (Callable): The calibration function.
				For example, a simulation function or objective function.
		    specification (LikelihoodFreeMethodModel): The
				calibration specification.
		    engine (str, optional): The likelihood-free backend.
				Defaults to "elfi".
			implementation (type[CalibrationWorkflowBase] | CalibrationWorkflowBase
				| None): The calibration workflow implementation.
		"""
		super().__init__(
			calibration_func,
			specification,
			TASK,
			engine,
			get_implementations(),
			implementation,
		)
