"""Smoke tests for the `testtoolkit` CLI."""

import json
from pathlib import Path

import pytest

from src import cli


@pytest.fixture
def evaluation_workspace(tmp_path: Path) -> Path:
    profile_dir = tmp_path / "docker" / "test-results" / "evaluation" / "smoke"
    profile_dir.mkdir(parents=True)
    report = {
        "summary": {
            "evaluation_name": "cli-smoke",
            "model_name": "test-model",
            "overall_score": 0.9,
            "total_items": 1,
            "metrics_evaluated": ["recall"],
            "metrics_summary": {
                "recall": {"score": 0.9, "count": 1, "min": 0.9, "max": 0.9},
            },
        },
        "details": [
            {
                "item_number": 1,
                "question": "Q?",
                "ground_truth": "A",
                "model_answer": "A",
                "type": "text",
                "recall_score": 0.9,
            },
        ],
    }
    (profile_dir / "report.json").write_text(json.dumps(report), encoding="utf-8")
    return tmp_path


def test_list_command_prints_registered_types(capsys):
    rc = cli.main(["list"])
    assert rc == 0
    output = capsys.readouterr().out
    assert "evaluation" in output
    assert "bitbucket" in output


def test_publish_with_dummy_provider_runs_end_to_end(evaluation_workspace, monkeypatch, tmp_path):
    """Drive the CLI end-to-end with a captured in-memory provider."""
    captured = {}

    class _CaptureProvider:
        _version = "1.0.0"

        def __init__(self, config):
            self.config = config

        def validate_config(self):
            pass

        def create_test_run(self, run_name, **kwargs):
            captured["run_name"] = run_name
            return "captured-run"

        def upload_test_results(self, run_id, test_results, summary=None):
            captured["run_id"] = run_id
            captured["results_count"] = len(test_results)
            captured["summary"] = summary
            return True

        def get_test_run_info(self, run_id):
            return None

    monkeypatch.setitem(cli._PROVIDER_TYPES, "capture", _CaptureProvider)

    manifest_path = tmp_path / "publish.yaml"
    manifest_path.write_text(
        """
run_name: "cli-test-run"

collectors:
  - name: evaluation
    type: evaluation
    source: ./docker/test-results/evaluation/smoke

providers:
  - name: capture
    type: capture
    collector: evaluation
    config: {}
""".strip(),
        encoding="utf-8",
    )

    monkeypatch.chdir(evaluation_workspace)

    rc = cli.main(["publish", "--config", str(manifest_path)])
    assert rc == 0
    assert captured["run_name"] == "cli-test-run"
    assert captured["results_count"] == 1
    assert captured["summary"]["evaluation_name"] == "cli-smoke"
    assert captured["summary"]["overall_score"] == 0.9


def test_publish_rejects_manifest_without_collectors(tmp_path, monkeypatch):
    manifest_path = tmp_path / "publish.yaml"
    manifest_path.write_text("providers:\n  - name: x\n    type: testrail\n", encoding="utf-8")

    monkeypatch.chdir(tmp_path)
    rc = cli.main(["publish", "--config", str(manifest_path)])
    assert rc == 2


def test_disabled_provider_is_not_instantiated(evaluation_workspace, monkeypatch, tmp_path):
    """A provider with `enabled: false` must not call its constructor.

    This covers the "I don't have a Bitbucket token yet" case — the
    manifest keeps the bitbucket entry for documentation, and the CLI
    must skip it without the BitbucketProvider config validation
    kicking in.
    """

    instantiated = {"count": 0}

    class _ExplodingProvider:
        _version = "1.0.0"

        def __init__(self, config):
            instantiated["count"] += 1
            raise AssertionError("disabled provider must not be constructed")

        def validate_config(self):  # pragma: no cover
            pass

        def create_test_run(self, run_name, **kwargs):  # pragma: no cover
            return "x"

        def upload_test_results(self, run_id, test_results, summary=None):  # pragma: no cover
            return True

        def get_test_run_info(self, run_id):  # pragma: no cover
            return None

    class _RecordingProvider:
        _version = "1.0.0"
        calls = []

        def __init__(self, config):
            self.config = config

        def validate_config(self):
            pass

        def create_test_run(self, run_name, **kwargs):
            return "ok"

        def upload_test_results(self, run_id, test_results, summary=None):
            _RecordingProvider.calls.append((run_id, len(test_results)))
            return True

        def get_test_run_info(self, run_id):
            return None

    monkeypatch.setitem(cli._PROVIDER_TYPES, "exploding", _ExplodingProvider)
    monkeypatch.setitem(cli._PROVIDER_TYPES, "recording", _RecordingProvider)

    manifest_path = tmp_path / "publish.yaml"
    manifest_path.write_text(
        """
run_name: "cli-disabled-test"

collectors:
  - name: evaluation
    type: evaluation
    source: ./docker/test-results/evaluation/smoke

providers:
  - name: bitbucket-like
    type: exploding
    enabled: false
    config: {}
  - name: langfuse-like
    type: recording
    enabled: true
    config: {}
""".strip(),
        encoding="utf-8",
    )

    monkeypatch.chdir(evaluation_workspace)
    rc = cli.main(["publish", "--config", str(manifest_path)])

    assert rc == 0
    assert instantiated["count"] == 0, "disabled provider was instantiated"
    assert len(_RecordingProvider.calls) == 1
