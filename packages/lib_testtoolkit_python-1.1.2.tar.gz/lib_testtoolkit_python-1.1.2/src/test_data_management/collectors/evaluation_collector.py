"""
Collector for gathering results from model-evaluation JSON reports.

Targets the report format produced by the ``eic-model-evaluation`` library
(``ReportGenerator.to_json``), which is the format used by
``test-facade-evaluation-pytest-python`` and similar RAG evaluation projects.

Expected shape of the input ``report.json``::

    {
        "summary": {
            "evaluation_name": str,
            "model_name": str,
            "generated_at": str,       # ISO timestamp
            "overall_score": float,    # 0..1
            "total_items": int,
            "metrics_evaluated": ["recall", "precision", "ndcg", ...],
            "metrics_summary": {
                "recall":    {"score": 0..1, "count": int, "min": ..., "max": ...},
                "precision": {...},
                "ndcg":      {...}
            }
        },
        "details": [
            {
                "item_number": int,
                "question": str,
                "ground_truth": str,
                "model_answer": str,
                "type": str,
                "<metric>_score":     float,
                "<metric>_reasoning": str
            },
            ...
        ]
    }

Each item in ``details`` is emitted as one :class:`TestResult`:

* ``status`` is :attr:`ResultStatus.PASSED` by default — these items are
  *measurements*, not pass/fail tests. The hard PASS/FAIL decision is made
  separately by the test framework (e.g. pytest ``assert score >= threshold``)
  and shows up in its own JUnit report.
* If a per-item threshold map is supplied via collector config
  ``{"item_thresholds": {"recall": 0.8, ...}}`` the collector will flip the
  status to FAILED for items whose score is below the threshold. Off by default.

The collector also exposes aggregated metrics via
:meth:`collect_summary`, which downstream providers (Bitbucket Code
Insights, Langfuse) can attach to their reports.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from test_data_management.core.base_collector import BaseCollector
from test_data_management.core.base_provider import ResultStatus, TestResult


class EvaluationCollector(BaseCollector):
    """Collector for eic-model-evaluation report.json files."""

    _version = '1.0.0'

    # Item-level score keys follow "<metric>_score" / "<metric>_reasoning"
    # convention produced by ReportGenerator.
    _SCORE_SUFFIX = '_score'
    _REASONING_SUFFIX = '_reasoning'

    # Item fields that are not metrics and must never be treated as such.
    _NON_METRIC_FIELDS = frozenset({
        'item_number',
        'question',
        'ground_truth',
        'model_answer',
        'type',
    })

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__(config)
        self.logger = logging.getLogger(__name__)

    def validate_config(self) -> None:
        """
        Validate collector configuration.

        Supported optional config keys:

        * ``item_thresholds`` — ``Dict[str, float]`` mapping metric name to
          minimum acceptable per-item score. If provided, items whose score
          is below the threshold will be reported as FAILED.
        * ``test_id_prefix`` — ``str`` prefix used when building ``test_id``
          for items. Default: ``"eval"``.
        """
        item_thresholds = self.config.get('item_thresholds')
        if item_thresholds is not None and not isinstance(item_thresholds, dict):
            raise ValueError("'item_thresholds' must be a dict of metric -> float")

    def get_supported_formats(self) -> List[str]:
        return ['.json']

    # ---------------------------------------------------------------- results

    def collect_results(self, source_path: Path) -> List[TestResult]:
        """
        Collect per-item results from evaluation report(s).

        ``source_path`` may point to:

        * a single ``report.json`` file;
        * a directory — in that case every ``report.json`` found recursively
          will be parsed. The directory name is recorded in ``custom_fields``
          as ``profile`` (e.g. ``smoke``, ``full``).
        """
        results: List[TestResult] = []

        for report_path, profile_hint in self._iter_report_files(source_path):
            report = self._load_report(report_path)
            if report is None:
                continue
            results.extend(self._parse_details(report, report_path, profile_hint))

        return results

    def collect_summary(self, source_path: Path) -> Dict[str, Any]:
        """
        Aggregate evaluation summary across all report files under ``source_path``.

        If only one report file is found, its summary is returned as-is.
        If multiple reports are found (e.g. ``smoke/report.json`` and
        ``full/report.json`` in the same directory), the result is a merged
        structure with metrics prefixed by their profile name so nothing is
        silently overwritten.
        """
        collected: List[Dict[str, Any]] = []

        for report_path, profile_hint in self._iter_report_files(source_path):
            report = self._load_report(report_path)
            if report is None:
                continue
            normalized = self._normalize_summary(report, profile_hint)
            if normalized:
                collected.append(normalized)

        if not collected:
            return {}
        if len(collected) == 1:
            return collected[0]

        # Merge multiple summaries. Metric names are prefixed with the
        # profile to avoid collisions when both smoke and full are present.
        merged_metrics: List[Dict[str, Any]] = []
        for item in collected:
            profile = item.get('profile') or item.get('evaluation_name') or ''
            for metric in item.get('metrics') or []:
                prefixed = dict(metric)
                if profile:
                    prefixed['name'] = f"{profile}.{metric['name']}"
                merged_metrics.append(prefixed)

        return {
            'evaluation_name': 'combined',
            'reports': collected,
            'metrics': merged_metrics,
        }

    # ---------------------------------------------------------------- helpers

    def _iter_report_files(self, source_path: Path):
        """Yield ``(path, profile_hint)`` pairs for each report file to parse."""
        if source_path.is_file():
            if self.is_format_supported(source_path):
                yield source_path, source_path.parent.name
            else:
                self.logger.warning(f"File format {source_path} is not supported")
            return

        if source_path.is_dir():
            # Prefer explicit report.json matches so we don't pick up random JSON.
            for report_file in sorted(source_path.glob('**/report.json')):
                yield report_file, report_file.parent.name
            return

        raise ValueError(f"Unknown source type: {source_path}")

    def _load_report(self, report_path: Path) -> Optional[Dict[str, Any]]:
        try:
            with report_path.open('r', encoding='utf-8') as handle:
                payload = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            self.logger.error(f"Failed to read evaluation report {report_path}: {exc}")
            return None

        if not isinstance(payload, dict):
            self.logger.warning(f"Evaluation report {report_path} is not a JSON object — skipping")
            return None

        if 'summary' not in payload or 'details' not in payload:
            self.logger.warning(
                f"Evaluation report {report_path} does not match expected shape "
                "(missing 'summary' or 'details') — skipping"
            )
            return None

        return payload

    def _parse_details(
        self,
        report: Dict[str, Any],
        report_path: Path,
        profile_hint: str,
    ) -> List[TestResult]:
        summary = report.get('summary') or {}
        evaluation_name = summary.get('evaluation_name', '')
        model_name = summary.get('model_name', '')
        test_id_prefix = self.config.get('test_id_prefix', 'eval')
        item_thresholds: Dict[str, float] = self.config.get('item_thresholds') or {}

        results: List[TestResult] = []
        for raw_item in report.get('details') or []:
            if not isinstance(raw_item, dict):
                continue

            item_number = raw_item.get('item_number')
            question = (raw_item.get('question') or '').strip()
            test_name = question or f"Item {item_number}" if item_number is not None else 'item'
            test_id = self._build_test_id(test_id_prefix, profile_hint, item_number, question)

            metric_scores = self._extract_metric_scores(raw_item)

            status = self._decide_status(metric_scores, item_thresholds)
            error_message = self._build_error_message(metric_scores, item_thresholds) if status == ResultStatus.FAILED else None

            custom_fields: Dict[str, Any] = {
                'collector': 'evaluation',
                'profile': profile_hint,
                'evaluation_name': evaluation_name,
                'model_name': model_name,
                'source_file': str(report_path),
                'item_number': item_number,
                'question': question,
                'ground_truth': raw_item.get('ground_truth'),
                'model_answer': raw_item.get('model_answer'),
                'type': raw_item.get('type'),
                'metrics': metric_scores,
            }
            # Preserve raw reasoning strings for downstream visualisation.
            for key, value in raw_item.items():
                if key.endswith(self._REASONING_SUFFIX):
                    custom_fields[key] = value

            results.append(TestResult(
                test_id=test_id,
                test_name=self._clean_test_name(test_name),
                status=status,
                duration=None,
                error_message=error_message,
                stacktrace=None,
                attachments=None,
                custom_fields=custom_fields,
            ))

        self.logger.info(
            f"Parsed {len(results)} evaluation items from {report_path} "
            f"(profile='{profile_hint}', name='{evaluation_name}')"
        )
        return results

    def _normalize_summary(self, report: Dict[str, Any], profile_hint: str) -> Dict[str, Any]:
        summary = report.get('summary') or {}

        metrics_summary = summary.get('metrics_summary') or {}
        metrics: List[Dict[str, Any]] = []
        for metric_name, metric_data in metrics_summary.items():
            if not isinstance(metric_data, dict):
                continue
            score = metric_data.get('score')
            if not isinstance(score, (int, float)):
                continue
            metrics.append({
                'name': metric_name,
                'score': float(score),
                'count': metric_data.get('count'),
                'min': metric_data.get('min'),
                'max': metric_data.get('max'),
            })

        normalized: Dict[str, Any] = {
            'evaluation_name': summary.get('evaluation_name', ''),
            'model_name': summary.get('model_name', ''),
            'generated_at': summary.get('generated_at'),
            'overall_score': summary.get('overall_score'),
            'total_items': summary.get('total_items'),
            'metrics_evaluated': summary.get('metrics_evaluated') or [],
            'metrics': metrics,
            'profile': profile_hint,
        }
        return normalized

    def _extract_metric_scores(self, item: Dict[str, Any]) -> Dict[str, float]:
        metric_scores: Dict[str, float] = {}
        for key, value in item.items():
            if key in self._NON_METRIC_FIELDS:
                continue
            if not key.endswith(self._SCORE_SUFFIX):
                continue
            if not isinstance(value, (int, float)):
                continue
            metric_name = key[: -len(self._SCORE_SUFFIX)]
            if metric_name:
                metric_scores[metric_name] = float(value)
        return metric_scores

    def _decide_status(
        self,
        metric_scores: Dict[str, float],
        item_thresholds: Dict[str, float],
    ) -> ResultStatus:
        if not item_thresholds:
            return ResultStatus.PASSED
        for metric_name, threshold in item_thresholds.items():
            if metric_name not in metric_scores:
                continue
            try:
                if metric_scores[metric_name] < float(threshold):
                    return ResultStatus.FAILED
            except (TypeError, ValueError):
                continue
        return ResultStatus.PASSED

    @staticmethod
    def _build_error_message(
        metric_scores: Dict[str, float],
        item_thresholds: Dict[str, float],
    ) -> str:
        misses = []
        for metric_name, threshold in item_thresholds.items():
            score = metric_scores.get(metric_name)
            if score is None:
                continue
            try:
                if score < float(threshold):
                    misses.append(f"{metric_name}={score:.3f} < {float(threshold):.3f}")
            except (TypeError, ValueError):
                continue
        if not misses:
            return 'Item did not meet one or more item_thresholds'
        return 'Below per-item thresholds: ' + ', '.join(misses)

    @staticmethod
    def _build_test_id(
        prefix: str,
        profile: str,
        item_number: Optional[int],
        question: str,
    ) -> str:
        parts = [p for p in (prefix, profile) if p]
        if isinstance(item_number, int) and item_number > 0:
            parts.append(f"item-{item_number}")
        elif question:
            # Deterministic short tail for readability — not a hash.
            tail = '-'.join(question.split()[:4]).lower() or 'item'
            parts.append(tail)
        else:
            parts.append('item')
        return '::'.join(parts)
