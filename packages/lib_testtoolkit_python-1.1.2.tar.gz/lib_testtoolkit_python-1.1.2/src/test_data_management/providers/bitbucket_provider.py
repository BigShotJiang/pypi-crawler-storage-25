"""
Provider for Bitbucket test reporting.

Supports two delivery modes:
1) Bitbucket Code Insights report upload via REST API.
2) Local JUnit XML file generation for Pipelines Tests tab ingestion.
"""

import os
import re
import requests
from typing import Dict, List, Optional, Any
from xml.etree import ElementTree as ET

from test_data_management.core.base_provider import BaseProvider, TestResult, ResultStatus, TestRun


class BitbucketProvider(BaseProvider):
    """Provider for Bitbucket test reporting."""

    _version = '1.0.0'

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.session = requests.Session()

        auth_token = self.config.get('auth_token')
        if auth_token:
            self.session.headers.update({'Authorization': f'Bearer {auth_token}'})
        else:
            username = self.config.get('username')
            app_password = self.config.get('app_password') or self.config.get('password')
            if username and app_password:
                self.session.auth = (username, app_password)

        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': f'BitbucketProvider/{self._version}'
        })

    def validate_config(self) -> None:
        self.api_base_url = self.config.get('api_base_url', 'https://api.bitbucket.org/2.0').rstrip('/')
        self.workspace = self.config.get('workspace')
        self.repo_slug = self.config.get('repo_slug')
        self.commit = self.config.get('commit')
        self.junit_xml_output_path = self.config.get('junit_xml_output_path')
        self.use_pipeline_proxy = bool(self.config.get('use_pipeline_proxy', False))

        self.api_enabled = bool(self.workspace and self.repo_slug and self.commit)
        self.junit_enabled = bool(self.junit_xml_output_path)

        if not self.api_enabled and not self.junit_enabled:
            raise ValueError(
                "BitbucketProvider requires either API config "
                "(workspace, repo_slug, commit) or junit_xml_output_path"
            )

        if self.api_enabled and not self.use_pipeline_proxy:
            auth_token = self.config.get('auth_token')
            username = self.config.get('username')
            app_password = self.config.get('app_password') or self.config.get('password')
            if not auth_token and not (username and app_password):
                raise ValueError(
                    "Bitbucket API mode requires auth_token or username+app_password/password "
                    "(unless use_pipeline_proxy=true)"
                )

    def create_test_run(self, run_name: str, **kwargs) -> str:
        """
        For Bitbucket, run_id is used as report_id.
        """
        report_id = kwargs.get('report_id') or self._sanitize_report_id(run_name)
        return report_id

    def upload_test_results(
        self,
        run_id: str,
        test_results: List[TestResult],
        summary: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Upload test results to configured Bitbucket channels.

        If ``summary`` is provided (typically by a Collector that parses
        evaluation reports — e.g. recall / precision / ndcg), its metrics are
        attached as extra rows in the Code Insights report ``data`` array so
        they are visible in the commit / PR view without downloading
        artifacts.
        """
        results = []

        if self.junit_enabled:
            results.append(self._write_junit_xml(run_id, test_results))

        if self.api_enabled:
            results.append(self._upload_code_insights_report(run_id, test_results, summary))

        if not results:
            return False

        return all(results)

    def get_test_run_info(self, run_id: str) -> Optional[TestRun]:
        if not self.api_enabled:
            return None

        url = (
            f"{self.api_base_url}/repositories/{self.workspace}/{self.repo_slug}"
            f"/commit/{self.commit}/reports/{run_id}"
        )
        try:
            response = self._request('GET', url)
            response.raise_for_status()
            payload = response.json()

            test_count = None
            for item in payload.get('data', []):
                title = (item.get('title') or '').lower()
                if title in ('total tests', 'tests total') and isinstance(item.get('value'), (int, float)):
                    test_count = int(item['value'])
                    break

            return TestRun(
                run_id=run_id,
                name=payload.get('title', run_id),
                status=(payload.get('result', 'UNKNOWN') or 'UNKNOWN').lower(),
                created_on=None,
                description=payload.get('details', ''),
                test_count=test_count
            )
        except requests.exceptions.RequestException:
            return None

    def close_test_run(self, run_id: str) -> bool:
        # No close operation for Bitbucket reports.
        return True

    def _write_junit_xml(self, run_id: str, test_results: List[TestResult]) -> bool:
        """
        Write JUnit XML report suitable for Bitbucket Pipelines test scanner.
        """
        output_path = str(self.junit_xml_output_path).replace('{run_id}', run_id)
        directory = os.path.dirname(output_path)
        if directory:
            os.makedirs(directory, exist_ok=True)

        total = len(test_results)
        failures = sum(1 for result in test_results if result.status == ResultStatus.FAILED)
        skipped = sum(
            1 for result in test_results
            if result.status in (ResultStatus.SKIPPED, ResultStatus.NOT_RUN)
        )
        duration = sum((result.duration or 0.0) for result in test_results)

        testsuite = ET.Element(
            'testsuite',
            {
                'name': f'Bitbucket_{run_id}',
                'tests': str(total),
                'failures': str(failures),
                'skipped': str(skipped),
                'time': f'{duration:.3f}',
            }
        )

        for result in test_results:
            custom_fields = result.custom_fields or {}
            classname = str(custom_fields.get('classname', ''))
            testcase = ET.SubElement(
                testsuite,
                'testcase',
                {
                    'name': result.test_name or result.test_id or 'unknown',
                    'classname': classname,
                    'time': f'{(result.duration or 0.0):.3f}',
                }
            )

            if result.status == ResultStatus.FAILED:
                failure = ET.SubElement(
                    testcase,
                    'failure',
                    {'message': result.error_message or 'Test failed'}
                )
                failure.text = result.stacktrace or result.error_message or ''
            elif result.status in (ResultStatus.SKIPPED, ResultStatus.NOT_RUN):
                skipped_node = ET.SubElement(testcase, 'skipped')
                skipped_node.text = result.error_message or ''

        tree = ET.ElementTree(testsuite)
        tree.write(output_path, encoding='utf-8', xml_declaration=True)
        return True

    def _upload_code_insights_report(
        self,
        run_id: str,
        test_results: List[TestResult],
        summary: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Upload summary report and failed-test annotations to Bitbucket Code Insights.
        """
        failed = [result for result in test_results if result.status == ResultStatus.FAILED]
        passed = [result for result in test_results if result.status == ResultStatus.PASSED]
        skipped = [
            result for result in test_results
            if result.status in (ResultStatus.SKIPPED, ResultStatus.NOT_RUN)
        ]

        report_result = 'FAILED' if failed else 'PASSED'
        report_url = (
            f"{self.api_base_url}/repositories/{self.workspace}/{self.repo_slug}"
            f"/commit/{self.commit}/reports/{run_id}"
        )

        data_rows: List[Dict[str, Any]] = [
            {'title': 'Total tests', 'type': 'NUMBER', 'value': len(test_results)},
            {'title': 'Passed', 'type': 'NUMBER', 'value': len(passed)},
            {'title': 'Failed', 'type': 'NUMBER', 'value': len(failed)},
            {'title': 'Skipped', 'type': 'NUMBER', 'value': len(skipped)},
        ]
        data_rows.extend(self._build_summary_rows(summary))

        payload = {
            'title': self.config.get('report_title', f'Automated tests ({run_id})'),
            'details': self.config.get(
                'report_details',
                self._build_default_details(test_results, passed, failed, skipped, summary),
            ),
            'report_type': self.config.get('report_type', 'TEST'),
            'reporter': self.config.get('reporter', 'lib-testtoolkit-python'),
            'result': report_result,
            'data': data_rows,
        }

        link = self.config.get('report_link')
        if link:
            payload['link'] = link

        try:
            response = self._request('PUT', report_url, json=payload)
            response.raise_for_status()
        except requests.exceptions.RequestException:
            return False

        if not failed:
            return True

        max_annotations = int(self.config.get('max_annotations', 100))
        for idx, result in enumerate(failed[:max_annotations]):
            annotation_id = f"{run_id}-failed-{idx + 1}"
            annotation_url = (
                f"{self.api_base_url}/repositories/{self.workspace}/{self.repo_slug}"
                f"/commit/{self.commit}/reports/{run_id}/annotations/{annotation_id}"
            )

            custom_fields = result.custom_fields or {}
            summary = result.error_message or 'Test failed'
            annotation_payload = {
                'annotation_type': 'BUG',
                'summary': summary[:1000],
                'severity': self.config.get('annotation_severity', 'HIGH'),
                'title': result.test_name or result.test_id or f'failed-test-{idx + 1}'
            }

            path = custom_fields.get('path')
            line = custom_fields.get('line')
            if isinstance(path, str) and path:
                annotation_payload['path'] = path
            if isinstance(line, int) and line > 0:
                annotation_payload['line'] = line

            try:
                response = self._request('PUT', annotation_url, json=annotation_payload)
                response.raise_for_status()
            except requests.exceptions.RequestException:
                # Continue on annotation failures; summary report already uploaded.
                continue

        return True

    def _request(self, method: str, url: str, **kwargs):
        if self.use_pipeline_proxy:
            kwargs.setdefault('proxies', {
                'http': 'http://localhost:29418',
                'https': 'http://localhost:29418'
            })
        return self.session.request(method=method, url=url, **kwargs)

    def _sanitize_report_id(self, value: str) -> str:
        slug = re.sub(r'[^a-zA-Z0-9._-]+', '-', value.strip().lower()).strip('-')
        return slug or 'test-report'

    def _build_summary_rows(self, summary: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Convert a collector summary into Bitbucket Code Insights ``data`` rows.

        Recognised shape (see ``BaseCollector.collect_summary``):
            {
                "overall_score": 0..1,
                "total_items": int,
                "metrics": [{"name": "recall", "score": 0..1, ...}, ...]
            }

        Bitbucket supports types: BOOLEAN, DATE, DURATION, LINK, NUMBER,
        PERCENTAGE, TEXT. Score-like values (0..1) are emitted as PERCENTAGE.
        """
        rows: List[Dict[str, Any]] = []
        if not summary:
            return rows

        overall_score = summary.get('overall_score')
        if isinstance(overall_score, (int, float)):
            rows.append({
                'title': 'Overall Score',
                'type': 'PERCENTAGE',
                'value': round(float(overall_score) * 100, 2),
            })

        total_items = summary.get('total_items')
        if isinstance(total_items, int) and total_items > 0:
            rows.append({
                'title': 'Evaluated Items',
                'type': 'NUMBER',
                'value': total_items,
            })

        for metric in summary.get('metrics') or []:
            if not isinstance(metric, dict):
                continue
            name = metric.get('name')
            score = metric.get('score')
            if not name or not isinstance(score, (int, float)):
                continue
            # Bitbucket limits data[] to 10 rows per report.
            if len(rows) >= 10:
                break
            rows.append({
                'title': str(name).replace('_', ' ').title(),
                'type': 'PERCENTAGE',
                'value': round(float(score) * 100, 2),
            })

        return rows

    def _build_default_details(
        self,
        test_results: List[TestResult],
        passed: List[TestResult],
        failed: List[TestResult],
        skipped: List[TestResult],
        summary: Optional[Dict[str, Any]],
    ) -> str:
        """Build a one-line details string including run summary if available."""
        base = (
            f"Total: {len(test_results)}, Passed: {len(passed)}, "
            f"Failed: {len(failed)}, Skipped: {len(skipped)}"
        )
        if not summary:
            return base

        extras: List[str] = []
        overall_score = summary.get('overall_score')
        if isinstance(overall_score, (int, float)):
            extras.append(f"Overall {float(overall_score) * 100:.1f}%")
        for metric in summary.get('metrics') or []:
            if not isinstance(metric, dict):
                continue
            name = metric.get('name')
            score = metric.get('score')
            if not name or not isinstance(score, (int, float)):
                continue
            extras.append(f"{name}={float(score):.3f}")

        if not extras:
            return base
        return f"{base} | {', '.join(extras)}"
