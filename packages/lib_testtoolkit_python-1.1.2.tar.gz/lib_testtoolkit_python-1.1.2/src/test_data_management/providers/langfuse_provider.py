"""
Provider for publishing test runs and evaluation metrics to Langfuse.

Langfuse (https://langfuse.com) is an observability platform for LLM and
RAG applications. This provider is designed to surface evaluation-style
test results (recall / precision / ndcg / LLM-as-judge scores) with
per-item traceability — something a plain JUnit report can't do.

Why HTTP, not the langfuse SDK?
-------------------------------

The langfuse Python SDK went through incompatible rewrites between
v2 and v3, and this library targets ``>= Python 3.8`` without a
langfuse dependency. Instead we talk to the public **Ingestion API**
(``POST /api/public/ingestion``) over HTTPS. The payload format is stable
and documented, and ``requests`` is already a core dependency.

Model used
----------

Each run produces one **trace** with one child **span** per evaluation
item. Metric scores are attached as **scores** either to the trace
(overall metrics from the collector summary) or to the span (per-item
metrics from ``TestResult.custom_fields``).

            trace (run)
            │
            ├── score: overall_score
            ├── score: recall        ── aggregate
            ├── score: precision     ── aggregate
            ├── score: ndcg          ── aggregate
            │
            ├── span (item 1)
            │     ├── input:  question
            │     ├── output: model_answer
            │     ├── score:  recall
            │     ├── score:  precision
            │     └── score:  ndcg
            ├── span (item 2) ...

Provider configuration
----------------------

Required::

    host:       "https://cloud.langfuse.com"   # EU cloud is https://cloud.langfuse.com, US is https://us.cloud.langfuse.com
    public_key: "pk-lf-..."
    secret_key: "sk-lf-..."

Optional::

    tags:               ["ci", "smoke"]        # attached to every trace
    metadata:           {"branch": "main"}      # merged into trace metadata
    session_id:         "facade-eval-smoke"     # group related runs in UI
    user_id:            "ci-bot"
    request_timeout:    30                      # HTTP timeout per request
    batch_size:         100                     # events per POST request
    observation_kind:   "span"                  # "span" | "generation" | "event"
"""

from __future__ import annotations

import json
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

import requests

from test_data_management.core.base_provider import (
    BaseProvider,
    ResultStatus,
    TestResult,
    TestRun,
)


class LangfuseProvider(BaseProvider):
    """Publishes traces, observations and scores to Langfuse via Ingestion API."""

    _version = '1.0.0'

    _ALLOWED_OBSERVATION_KINDS = ('span', 'generation', 'event')

    # Status → Langfuse "level" mapping for observations.
    _LEVEL_BY_STATUS = {
        ResultStatus.PASSED: 'DEFAULT',
        ResultStatus.FAILED: 'ERROR',
        ResultStatus.SKIPPED: 'WARNING',
        ResultStatus.BLOCKED: 'WARNING',
        ResultStatus.NOT_RUN: 'WARNING',
    }

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger(__name__)
        self.session = requests.Session()
        self.session.auth = (self.config['public_key'], self.config['secret_key'])
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': f'LangfuseProvider/{self._version}',
        })

    # ------------------------------------------------------------- contract

    def validate_config(self) -> None:
        required = ('host', 'public_key', 'secret_key')
        missing = [key for key in required if not self.config.get(key)]
        if missing:
            raise ValueError(
                f"LangfuseProvider requires non-empty config keys: {missing}"
            )

        host = str(self.config['host']).rstrip('/')
        if not host.startswith(('http://', 'https://')):
            raise ValueError("LangfuseProvider 'host' must start with http:// or https://")
        self.config['host'] = host

        observation_kind = self.config.get('observation_kind', 'span')
        if observation_kind not in self._ALLOWED_OBSERVATION_KINDS:
            raise ValueError(
                f"LangfuseProvider 'observation_kind' must be one of "
                f"{self._ALLOWED_OBSERVATION_KINDS}, got '{observation_kind}'"
            )

    def create_test_run(self, run_name: str, **kwargs) -> str:
        """
        Return a deterministic run id used as Langfuse ``trace.id``.

        The trace itself is created lazily during :meth:`upload_test_results`
        so that run metadata can include per-run counts. Callers may pass
        ``trace_id`` in kwargs to use a pre-computed id.
        """
        trace_id = kwargs.get('trace_id') or self._sanitize_trace_id(run_name)
        return trace_id

    def upload_test_results(
        self,
        run_id: str,
        test_results: List[TestResult],
        summary: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Publish one trace per run, with per-item spans and metric scores.
        """
        timestamp = self._now_iso()
        run_name = self.config.get('run_name') or run_id

        events: List[Dict[str, Any]] = []

        # 1) Trace — covers the whole run.
        trace_body: Dict[str, Any] = {
            'id': run_id,
            'name': run_name,
            'timestamp': timestamp,
            'tags': list(self.config.get('tags') or []),
            'metadata': self._build_trace_metadata(test_results, summary),
            'release': self.config.get('release'),
            'version': self.config.get('version'),
        }
        if self.config.get('user_id'):
            trace_body['userId'] = str(self.config['user_id'])
        if self.config.get('session_id'):
            trace_body['sessionId'] = str(self.config['session_id'])
        trace_body['input'] = self._build_trace_input(test_results, summary)
        trace_body['output'] = self._build_trace_output(test_results, summary)
        events.append(self._make_event('trace-create', trace_body, timestamp))

        # 2) Run-level scores (overall, aggregated metric averages).
        events.extend(self._build_run_level_scores(run_id, summary, timestamp))

        # 3) Per-item observations + scores.
        observation_kind = self.config.get('observation_kind', 'span')
        for index, result in enumerate(test_results):
            observation_id = self._observation_id(run_id, index, result)
            observation_body = self._build_observation_body(
                run_id, observation_id, result, observation_kind, timestamp
            )
            events.append(
                self._make_event(f'{observation_kind}-create', observation_body, timestamp)
            )
            events.extend(
                self._build_item_scores(run_id, observation_id, result, timestamp)
            )

        return self._flush(events)

    def get_test_run_info(self, run_id: str) -> Optional[TestRun]:
        """
        Fetch trace information from Langfuse public API.

        Uses ``GET /api/public/traces/{traceId}``. Returns ``None`` if the
        trace has not yet been indexed or if the call fails — this
        provider is write-mostly and does not require read access for its
        primary use case.
        """
        url = f"{self.config['host']}/api/public/traces/{run_id}"
        try:
            response = self.session.get(
                url,
                timeout=int(self.config.get('request_timeout', 30)),
            )
            response.raise_for_status()
            payload = response.json()
        except requests.exceptions.RequestException as exc:
            self.logger.debug(f"Langfuse get_test_run_info failed for {run_id}: {exc}")
            return None
        except ValueError:
            return None

        observations = payload.get('observations') or []
        metrics = {
            score.get('name'): score.get('value')
            for score in (payload.get('scores') or [])
            if isinstance(score, dict) and score.get('name') is not None
        }
        return TestRun(
            run_id=str(payload.get('id', run_id)),
            name=payload.get('name', run_id),
            status='active',
            created_on=payload.get('createdAt'),
            description=None,
            test_count=len(observations) if observations else None,
            metrics=metrics or None,
        )

    # -------------------------------------------------------------- builders

    def _build_trace_input(
        self,
        test_results: List[TestResult],
        summary: Optional[Dict[str, Any]],
    ) -> str:
        """
        Trace-level ``input`` — one-line summary rendered at the top of
        the Langfuse trace view. Keeping this human-readable (not a raw
        dict) so the UI list renders it sensibly when truncated.
        """
        parts: List[str] = []
        if summary:
            ev_name = summary.get('evaluation_name')
            if ev_name:
                parts.append(f"Evaluation: {ev_name}")
            total = summary.get('total_items')
            if total:
                parts.append(f"Items: {total}")
            elif test_results:
                parts.append(f"Items: {len(test_results)}")
            model_name = summary.get('model_name')
            if model_name:
                parts.append(f"Model: {model_name}")
            profile = summary.get('profile')
            if profile:
                parts.append(f"Profile: {profile}")
        elif test_results:
            parts.append(f"Items: {len(test_results)}")

        return " | ".join(parts) if parts else "(no summary)"

    def _build_trace_output(
        self,
        test_results: List[TestResult],
        summary: Optional[Dict[str, Any]],
    ) -> str:
        """
        Trace-level ``output`` — Markdown with the aggregate metrics and
        per-status totals. Appears in the trace detail view next to the
        input, giving a run-at-a-glance summary without clicking into
        individual observations.
        """
        lines: List[str] = []

        if summary:
            overall = summary.get('overall_score')
            if isinstance(overall, (int, float)):
                lines.append(f"**Overall score:** {float(overall) * 100:.1f}%")

            metric_lines: List[str] = []
            for metric in summary.get('metrics') or []:
                if not isinstance(metric, dict):
                    continue
                name = metric.get('name')
                score = metric.get('score')
                if not name or not isinstance(score, (int, float)):
                    continue
                count = metric.get('count')
                suffix = f" (n={count})" if count else ""
                metric_lines.append(f"- **{name}**: {float(score):.3f}{suffix}")
            if metric_lines:
                if lines:
                    lines.append("")
                lines.append("**Metrics**")
                lines.extend(metric_lines)

        passed = sum(1 for r in test_results if r.status == ResultStatus.PASSED)
        failed = sum(1 for r in test_results if r.status == ResultStatus.FAILED)
        skipped = sum(
            1 for r in test_results
            if r.status in (ResultStatus.SKIPPED, ResultStatus.NOT_RUN)
        )
        if test_results:
            if lines:
                lines.append("")
            lines.append(
                f"**Status:** {passed} passed · {failed} failed · {skipped} skipped "
                f"(total {len(test_results)})"
            )

        return "\n".join(lines) if lines else "(no results)"

    def _build_trace_metadata(
        self,
        test_results: List[TestResult],
        summary: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        extra_metadata = self.config.get('metadata') or {}
        passed = sum(1 for r in test_results if r.status == ResultStatus.PASSED)
        failed = sum(1 for r in test_results if r.status == ResultStatus.FAILED)
        skipped = sum(
            1 for r in test_results
            if r.status in (ResultStatus.SKIPPED, ResultStatus.NOT_RUN)
        )
        metadata: Dict[str, Any] = {
            'source': 'lib-testtoolkit-python',
            'provider_version': self._version,
            'totals': {
                'total': len(test_results),
                'passed': passed,
                'failed': failed,
                'skipped': skipped,
            },
        }
        if summary:
            metadata['evaluation'] = {
                key: summary.get(key)
                for key in (
                    'evaluation_name',
                    'model_name',
                    'generated_at',
                    'overall_score',
                    'total_items',
                    'metrics_evaluated',
                    'profile',
                )
                if summary.get(key) is not None
            }
        if isinstance(extra_metadata, dict):
            metadata.update(extra_metadata)
        return metadata

    def _build_run_level_scores(
        self,
        run_id: str,
        summary: Optional[Dict[str, Any]],
        timestamp: str,
    ) -> List[Dict[str, Any]]:
        if not summary:
            return []

        events: List[Dict[str, Any]] = []

        overall = summary.get('overall_score')
        if isinstance(overall, (int, float)):
            events.append(self._make_event(
                'score-create',
                {
                    'id': f"{run_id}-score-overall",
                    'traceId': run_id,
                    'name': 'overall_score',
                    'value': float(overall),
                    'dataType': 'NUMERIC',
                    'comment': f"items={summary.get('total_items')}",
                },
                timestamp,
            ))

        for metric in summary.get('metrics') or []:
            if not isinstance(metric, dict):
                continue
            name = metric.get('name')
            score = metric.get('score')
            if not name or not isinstance(score, (int, float)):
                continue
            comment_parts = []
            for key in ('count', 'min', 'max'):
                if metric.get(key) is not None:
                    comment_parts.append(f"{key}={metric[key]}")
            events.append(self._make_event(
                'score-create',
                {
                    'id': f"{run_id}-score-{self._sanitize_id(str(name))}",
                    'traceId': run_id,
                    'name': str(name),
                    'value': float(score),
                    'dataType': 'NUMERIC',
                    'comment': ', '.join(comment_parts) or None,
                },
                timestamp,
            ))
        return events

    def _build_observation_body(
        self,
        run_id: str,
        observation_id: str,
        result: TestResult,
        kind: str,
        timestamp: str,
    ) -> Dict[str, Any]:
        custom = result.custom_fields or {}
        body: Dict[str, Any] = {
            'id': observation_id,
            'traceId': run_id,
            'name': self._short_observation_name(result, custom),
            'startTime': timestamp,
            'endTime': timestamp,
            'level': self._LEVEL_BY_STATUS.get(result.status, 'DEFAULT'),
            'input': self._safe_truncate(custom.get('question') or custom.get('input')),
            'output': self._safe_truncate(custom.get('model_answer') or custom.get('output')),
            'metadata': {
                'status': result.status.value if hasattr(result.status, 'value') else str(result.status),
                'test_id': result.test_id,
                'profile': custom.get('profile'),
                'item_number': custom.get('item_number'),
                'ground_truth': self._safe_truncate(custom.get('ground_truth')),
                'type': custom.get('type'),
                'question_full': self._safe_truncate(custom.get('question')),
            },
        }
        if result.status == ResultStatus.FAILED and result.error_message:
            body['statusMessage'] = self._safe_truncate(result.error_message, limit=2000)
        if kind == 'generation':
            body['model'] = custom.get('model_name')
        return body

    def _build_item_scores(
        self,
        run_id: str,
        observation_id: str,
        result: TestResult,
        timestamp: str,
    ) -> List[Dict[str, Any]]:
        events: List[Dict[str, Any]] = []
        custom = result.custom_fields or {}

        metrics = custom.get('metrics')
        if not isinstance(metrics, dict):
            return events

        for metric_name, score in metrics.items():
            if not isinstance(score, (int, float)):
                continue
            reasoning = custom.get(f"{metric_name}_reasoning")
            events.append(self._make_event(
                'score-create',
                {
                    'id': f"{observation_id}-{self._sanitize_id(str(metric_name))}",
                    'traceId': run_id,
                    'observationId': observation_id,
                    'name': str(metric_name),
                    'value': float(score),
                    'dataType': 'NUMERIC',
                    'comment': self._safe_truncate(reasoning) if reasoning else None,
                },
                timestamp,
            ))

        return events

    # --------------------------------------------------------------- HTTP IO

    def _flush(self, events: List[Dict[str, Any]]) -> bool:
        if not events:
            return True

        url = f"{self.config['host']}/api/public/ingestion"
        timeout = int(self.config.get('request_timeout', 30))
        batch_size = max(1, int(self.config.get('batch_size', 100)))

        all_ok = True
        for batch in self._chunked(events, batch_size):
            payload = {'batch': batch}
            try:
                response = self.session.post(url, json=payload, timeout=timeout)
                response.raise_for_status()
                body = self._safe_json(response)
                # Per Langfuse API, the endpoint may return per-event errors
                # even with a 200. Look for them so we don't report success
                # when the server quietly rejected half the batch.
                errors = []
                if isinstance(body, dict):
                    errors = body.get('errors') or []
                if errors:
                    all_ok = False
                    self.logger.error(
                        f"Langfuse ingestion reported {len(errors)} event error(s); "
                        f"first: {errors[0] if errors else ''}"
                    )
                else:
                    self.logger.info(
                        f"Sent {len(batch)} event(s) to Langfuse "
                        f"({self.config['host']})"
                    )
            except requests.exceptions.RequestException as exc:
                all_ok = False
                self.logger.error(f"Langfuse ingestion batch failed: {exc}")
        return all_ok

    # --------------------------------------------------------------- helpers

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z')

    @staticmethod
    def _chunked(items: List[Dict[str, Any]], size: int) -> Iterable[List[Dict[str, Any]]]:
        for start in range(0, len(items), size):
            yield items[start:start + size]

    @staticmethod
    def _make_event(event_type: str, body: Dict[str, Any], timestamp: str) -> Dict[str, Any]:
        # Strip None values so Langfuse doesn't reject payload over strict schema.
        cleaned_body = {k: v for k, v in body.items() if v is not None}
        # Metadata sub-object: also drop None leaves for cleanliness.
        metadata = cleaned_body.get('metadata')
        if isinstance(metadata, dict):
            cleaned_body['metadata'] = {k: v for k, v in metadata.items() if v is not None}
        return {
            'id': str(uuid.uuid4()),
            'type': event_type,
            'timestamp': timestamp,
            'body': cleaned_body,
        }

    @staticmethod
    def _short_observation_name(result: TestResult, custom: Dict[str, Any]) -> str:
        """
        Build a concise, stable observation name.

        Used only by the Langfuse UI for the span list in the Tracing view
        — long questions pushed list rows into multi-line wrap. The full
        question is still preserved in ``metadata.question_full`` and
        ``input``.
        """
        item_number = custom.get('item_number')
        question = custom.get('question') or ''
        question = question.strip()

        prefix = f"[{item_number}] " if isinstance(item_number, int) and item_number > 0 else ''

        if question:
            short = question if len(question) <= 80 else question[:77].rstrip() + '…'
            return f"{prefix}{short}"

        return prefix + (result.test_name or result.test_id or 'item')

    @staticmethod
    def _safe_truncate(value: Any, limit: int = 8000) -> Optional[str]:
        if value is None:
            return None
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)
        if len(text) <= limit:
            return text
        return text[: limit - 3] + '...'

    @staticmethod
    def _safe_json(response: requests.Response) -> Any:
        try:
            return response.json()
        except ValueError:
            return None

    @staticmethod
    def _sanitize_id(value: str) -> str:
        slug = re.sub(r'[^a-zA-Z0-9._-]+', '-', value.strip()).strip('-.')
        return slug or 'x'

    @staticmethod
    def _sanitize_trace_id(value: str) -> str:
        slug = re.sub(r'[^a-zA-Z0-9._-]+', '-', value.strip().lower()).strip('-.')
        if not slug:
            # Deterministic-ish fallback. Use a short time-based component so
            # concurrent runs without explicit ids still diverge.
            slug = f"run-{int(time.time())}"
        return slug[:100]

    @staticmethod
    def _observation_id(run_id: str, index: int, result: TestResult) -> str:
        suffix = LangfuseProvider._sanitize_id(result.test_id or result.test_name or f"item-{index + 1}")
        return f"{run_id}::obs::{index + 1:04d}::{suffix}"[:200]
