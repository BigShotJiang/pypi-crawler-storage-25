"""
Provider for TestRail API integration.
"""

import requests
import re
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import logging

from test_data_management.core.base_provider import BaseProvider, TestResult, ResultStatus, TestRun


class TestRailProvider(BaseProvider):
    """Provider for TestRail integration."""
    
    _version = '1.0.0'
    
    # Status mapping between internal and TestRail
    STATUS_MAPPING = {
        ResultStatus.PASSED: 1,    # Passed
        ResultStatus.FAILED: 5,    # Failed
        ResultStatus.SKIPPED: 3,   # Untested
        ResultStatus.BLOCKED: 2,   # Blocked
        ResultStatus.NOT_RUN: 3    # Untested
    }
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize TestRail provider.
        
        Args:
            config: Provider configuration
        """
        super().__init__(config)
        self.logger = logging.getLogger(__name__)
        
        # Initialize HTTP session
        self.session = requests.Session()
        self.session.auth = (
            self.config['username'], 
            self.config['password']
        )
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': f'TestRailProvider/{self._version}'
        })
        self._run_tests_cache: Dict[str, Dict[str, Dict[str, int]]] = {}
    
    def validate_config(self) -> None:
        """Validate provider configuration."""
        required_fields = ['url', 'username', 'password', 'project_id']
        
        for field in required_fields:
            if field not in self.config:
                raise ValueError(f"Missing required configuration field: {field}")
        
        # Check URL correctness
        if not self.config['url'].startswith(('http://', 'https://')):
            raise ValueError("URL must start with http:// or https://")
        
        # Add /index.php?/api/v2/ to URL if missing
        if not self.config['url'].endswith('/index.php?/api/v2/'):
            self.config['url'] = self.config['url'].rstrip('/') + '/index.php?/api/v2/'
    
    def create_test_run(self, run_name: str, **kwargs) -> str:
        """
        Create test run in TestRail.
        
        Args:
            run_name: Run name
            **kwargs: Additional parameters
            
        Returns:
            Created run ID
        """
        url = f"{self.config['url']}add_run/{self.config['project_id']}"
        
        # Prepare data for run creation
        run_data = {
            'name': run_name,
            'description': kwargs.get('description', ''),
            'milestone_id': kwargs.get('milestone_id'),
            'suite_id': kwargs.get('suite_id'),
            'assignedto_id': kwargs.get('assignedto_id'),
            'include_all': kwargs.get('include_all', True)
        }
        
        # Remove None values
        run_data = {k: v for k, v in run_data.items() if v is not None}
        
        self.logger.info(f"Creating test run in TestRail: {run_name}")
        
        try:
            response = self.session.post(url, json=run_data)
            response.raise_for_status()
            
            result = response.json()
            run_id = str(result['id'])
            
            self.logger.info(f"Created run with ID: {run_id}")
            return run_id
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error creating test run: {e}")
            raise
        except KeyError as e:
            self.logger.error(f"Unexpected response from TestRail API: {e}")
            raise
    
    def upload_test_results(
        self,
        run_id: str,
        test_results: List[TestResult],
        summary: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Upload test results to TestRail.

        Args:
            run_id: Run ID
            test_results: List of test results
            summary: Optional aggregated run-level summary. TestRail does not
                expose a structured metrics field for runs, so the summary is
                currently not persisted — it is accepted purely to satisfy
                the BaseProvider contract. Future iterations may push this
                into the run description.

        Returns:
            True if upload successful
        """
        # summary is accepted for BaseProvider contract compatibility; not used yet.
        del summary
        url = f"{self.config['url']}add_results_for_run/{run_id}"
        
        # Prepare results for TestRail
        results_data = []
        for test_result in test_results:
            result_data = self._convert_test_result(run_id, test_result)
            if result_data:
                results_data.append(result_data)
        
        if not results_data:
            self.logger.warning("No results to upload")
            return False
        
        # Split results into batches for large runs
        batch_size = self.config.get('batch_size', 100)
        batches = [results_data[i:i + batch_size] for i in range(0, len(results_data), batch_size)]
        
        self.logger.info(f"Uploading {len(results_data)} results in {len(batches)} batches")
        
        try:
            for i, batch in enumerate(batches):
                self.logger.info(f"Uploading batch {i + 1}/{len(batches)}")
                
                response = self.session.post(url, json={'results': batch})
                response.raise_for_status()
                
                self.logger.info(f"Batch {i + 1} uploaded successfully")
            
            return True
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error uploading results: {e}")
            return False
    
    def get_test_run_info(self, run_id: str) -> Optional[TestRun]:
        """
        Get test run information.
        
        Args:
            run_id: Run ID
            
        Returns:
            Run information or None if not found
        """
        url = f"{self.config['url']}get_run/{run_id}"
        
        try:
            response = self.session.get(url)
            response.raise_for_status()
            
            run_data = response.json()
            
            # Get test results
            results_url = f"{self.config['url']}get_results_for_run/{run_id}"
            results_response = self.session.get(results_url)
            results_response.raise_for_status()
            
            results_data = results_response.json()
            
            # Convert results only to derive consistent count with mapping rules
            converted_results = []
            for result in results_data:
                test_result = self._convert_from_testrail_result(result)
                if test_result:
                    converted_results.append(test_result)

            return TestRun(
                run_id=str(run_data['id']),
                name=run_data.get('name', ''),
                status='completed' if run_data.get('is_completed') else 'active',
                created_on=self._convert_timestamp(run_data.get('created_on')),
                description=run_data.get('description', ''),
                test_count=len(converted_results)
            )
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error getting test run information: {e}")
            return None
        except KeyError as e:
            self.logger.error(f"Unexpected response from TestRail API: {e}")
            return None
    
    def close_test_run(self, run_id: str) -> bool:
        """
        Close test run.
        
        Args:
            run_id: Run ID
            
        Returns:
            True if close successful
        """
        url = f"{self.config['url']}close_run/{run_id}"
        
        try:
            response = self.session.post(url)
            response.raise_for_status()
            
            self.logger.info(f"Run {run_id} closed successfully")
            return True
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error closing test run: {e}")
            return False
    
    def _convert_test_result(self, run_id: str, test_result: TestResult) -> Optional[Dict[str, Any]]:
        """
        Convert test result to TestRail format.

        Args:
            run_id: TestRail run ID
            test_result: Test result
            
        Returns:
            Dictionary with TestRail data or None
        """
        # Resolve test ID in TestRail run context
        test_id = self._resolve_test_id(run_id, test_result)
        if not test_id:
            self.logger.warning(f"Test ID not found for: {test_result.test_name}")
            return None
        
        # Status mapping
        status_id = self.STATUS_MAPPING.get(test_result.status, 3)  # Default to Untested
        
        # Build comment
        comment_parts = []
        if test_result.error_message:
            comment_parts.append(f"Error: {test_result.error_message}")
        if test_result.stacktrace:
            comment_parts.append(f"Stack trace:\n{test_result.stacktrace}")
        
        result_data = {
            'test_id': test_id,
            'status_id': status_id,
            'comment': '\n\n'.join(comment_parts) if comment_parts else None,
            'elapsed': self._convert_duration(test_result.duration)
        }
        
        # Add custom fields
        if test_result.custom_fields:
            for key, value in test_result.custom_fields.items():
                if key.startswith('custom_'):
                    result_data[key] = value
        
        return result_data

    def _resolve_test_id(self, run_id: str, test_result: TestResult) -> Optional[int]:
        """
        Resolve TestRail test ID for a result using explicit IDs, case IDs and run test index.
        """
        explicit_test_id = self._extract_explicit_test_id(test_result)
        if explicit_test_id:
            return explicit_test_id

        run_tests_index = self._get_run_tests_index(run_id)
        if not run_tests_index:
            return None

        explicit_case_id = self._extract_explicit_case_id(test_result)
        if explicit_case_id:
            mapped_test_id = run_tests_index['by_case_id'].get(str(explicit_case_id))
            if mapped_test_id:
                return mapped_test_id

        normalized_name = self._normalize_name(test_result.test_name)
        if normalized_name:
            mapped_test_id = run_tests_index['by_name'].get(normalized_name)
            if mapped_test_id:
                return mapped_test_id

        normalized_test_id = self._normalize_name(test_result.test_id)
        if normalized_test_id:
            mapped_test_id = run_tests_index['by_name'].get(normalized_test_id)
            if mapped_test_id:
                return mapped_test_id

        return None

    def _extract_explicit_test_id(self, test_result: TestResult) -> Optional[int]:
        """
        Extract explicit TestRail test ID from result fields.
        """
        # 1) Direct test ID in test_result.test_id
        direct_id, id_type = self._parse_prefixed_id(test_result.test_id)
        if direct_id and id_type == 'test':
            return direct_id
        if test_result.test_id and test_result.test_id.isdigit():
            return int(test_result.test_id)

        # 2) Explicit IDs in custom fields
        custom_fields = test_result.custom_fields or {}
        for key in ('testrail_test_id', 'test_id', 'custom_test_id'):
            value = custom_fields.get(key)
            parsed_id, parsed_type = self._parse_prefixed_id(value)
            if parsed_id and parsed_type == 'test':
                return parsed_id
            if isinstance(value, (int, float)) and int(value) > 0:
                return int(value)
            if isinstance(value, str) and value.isdigit():
                return int(value)

        return None

    def _extract_explicit_case_id(self, test_result: TestResult) -> Optional[int]:
        """
        Extract explicit TestRail case ID from result fields.
        """
        direct_id, id_type = self._parse_prefixed_id(test_result.test_id)
        if direct_id and id_type == 'case':
            return direct_id

        for source in (test_result.test_name, test_result.test_id):
            case_match = self._extract_case_id_from_text(source)
            if case_match:
                return case_match

        custom_fields = test_result.custom_fields or {}
        for key in ('testrail_case_id', 'case_id', 'custom_case_id'):
            value = custom_fields.get(key)
            parsed_id, parsed_type = self._parse_prefixed_id(value)
            if parsed_id and parsed_type == 'case':
                return parsed_id
            if isinstance(value, (int, float)) and int(value) > 0:
                return int(value)
            if isinstance(value, str) and value.isdigit():
                return int(value)

        return None

    def _parse_prefixed_id(self, raw_value: Any) -> Tuple[Optional[int], Optional[str]]:
        """
        Parse prefixed IDs like C123 or T456.
        """
        if raw_value is None:
            return None, None
        value = str(raw_value).strip()
        if not value:
            return None, None

        match = re.fullmatch(r'([cCtT])(\d+)', value)
        if not match:
            return None, None

        prefix = match.group(1).lower()
        parsed_id = int(match.group(2))
        return parsed_id, 'case' if prefix == 'c' else 'test'

    def _extract_case_id_from_text(self, text: Any) -> Optional[int]:
        if not text:
            return None
        match = re.search(r'\bC(\d+)\b', str(text), re.IGNORECASE)
        if match:
            return int(match.group(1))
        return None

    def _normalize_name(self, value: Any) -> str:
        if value is None:
            return ''
        return re.sub(r'\s+', ' ', str(value)).strip().lower()

    def _get_run_tests_index(self, run_id: str) -> Dict[str, Dict[str, int]]:
        """
        Build and cache run-level test index for resolving result -> test_id.
        """
        if run_id in self._run_tests_cache:
            return self._run_tests_cache[run_id]

        by_test_id: Dict[str, int] = {}
        by_case_id: Dict[str, int] = {}
        by_name: Dict[str, int] = {}

        limit = int(self.config.get('tests_fetch_limit', 250))
        offset = 0
        url = f"{self.config['url']}get_tests/{run_id}"

        try:
            while True:
                response = self.session.get(url, params={'limit': limit, 'offset': offset})
                response.raise_for_status()
                payload = response.json()

                if isinstance(payload, list):
                    tests_page = payload
                elif isinstance(payload, dict) and isinstance(payload.get('tests'), list):
                    tests_page = payload.get('tests', [])
                else:
                    tests_page = []

                if not tests_page:
                    break

                for item in tests_page:
                    test_id = item.get('id')
                    case_id = item.get('case_id')
                    title = item.get('title') or item.get('name') or ''

                    if isinstance(test_id, int) and test_id > 0:
                        by_test_id[str(test_id)] = test_id

                        if isinstance(case_id, int) and case_id > 0:
                            by_case_id.setdefault(str(case_id), test_id)
                            by_case_id.setdefault(f"c{case_id}", test_id)

                        normalized_title = self._normalize_name(title)
                        if normalized_title:
                            by_name.setdefault(normalized_title, test_id)

                page_size = len(tests_page)
                if page_size < limit:
                    break
                offset += page_size

            self._run_tests_cache[run_id] = {
                'by_test_id': by_test_id,
                'by_case_id': by_case_id,
                'by_name': by_name,
            }
            return self._run_tests_cache[run_id]

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Failed to load tests for run {run_id}: {e}")
            empty_index = {'by_test_id': {}, 'by_case_id': {}, 'by_name': {}}
            self._run_tests_cache[run_id] = empty_index
            return empty_index
    
    def _convert_from_testrail_result(self, result_data: Dict[str, Any]) -> Optional[TestResult]:
        """
        Convert result from TestRail format.
        
        Args:
            result_data: Result data from TestRail
            
        Returns:
            TestResult object or None
        """
        # Reverse status mapping
        status_mapping = {v: k for k, v in self.STATUS_MAPPING.items()}
        status = status_mapping.get(result_data.get('status_id'), ResultStatus.NOT_RUN)
        
        return TestResult(
            test_id=str(result_data.get('test_id', '')),
            test_name=result_data.get('test_name', ''),
            status=status,
            duration=self._parse_duration(result_data.get('elapsed')),
            error_message=result_data.get('comment'),
            custom_fields={
                'testrail_result_id': result_data.get('id'),
                'created_on': result_data.get('created_on'),
                'created_by': result_data.get('created_by')
            }
        )

    def _parse_duration(self, duration_value: Any) -> Optional[float]:
        """
        Parse TestRail elapsed duration to seconds.

        Supported values:
        - numeric seconds (int/float)
        - strings like "45s", "2m", "1m 30s", "1h 2m 3s"
        - plain numeric strings like "12.5"
        """
        if duration_value is None:
            return None

        if isinstance(duration_value, (int, float)):
            return float(duration_value)

        if not isinstance(duration_value, str):
            return None

        value = duration_value.strip().lower()
        if not value:
            return None

        # Plain numeric string means seconds
        try:
            return float(value)
        except ValueError:
            pass

        pattern = r'^(?:(\d+(?:\.\d+)?)h)?\s*(?:(\d+(?:\.\d+)?)m)?\s*(?:(\d+(?:\.\d+)?)s)?$'
        match = re.fullmatch(pattern, value)
        if not match:
            return None

        hours = float(match.group(1)) if match.group(1) else 0.0
        minutes = float(match.group(2)) if match.group(2) else 0.0
        seconds = float(match.group(3)) if match.group(3) else 0.0

        if hours == 0.0 and minutes == 0.0 and seconds == 0.0:
            return None

        return hours * 3600 + minutes * 60 + seconds
    
    def _convert_duration(self, duration: Optional[float]) -> Optional[str]:
        """
        Convert duration to TestRail format.
        
        Args:
            duration: Duration in seconds
            
        Returns:
            String with duration or None
        """
        if duration is None:
            return None
        
        # TestRail uses "1m 30s" format
        minutes = int(duration // 60)
        seconds = int(duration % 60)
        
        if minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"
    
    def _convert_timestamp(self, timestamp: Optional[int]) -> Optional[str]:
        """
        Convert timestamp to string.
        
        Args:
            timestamp: Unix timestamp
            
        Returns:
            String with date and time or None
        """
        if timestamp is None:
            return None
        
        try:
            dt = datetime.fromtimestamp(timestamp)
            return dt.isoformat()
        except (ValueError, OSError):
            return None 
