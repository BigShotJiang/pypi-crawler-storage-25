"""
Command-line entry point for lib-testtoolkit-python.

The CLI reads a single YAML manifest that declares which collectors to run,
which source files they should parse, and which providers to forward the
results to. This lets a CI pipeline publish test results with one line::

    testtoolkit publish --config ./publish.yaml

No knowledge of Collectors / Providers / TestDataManager wiring leaks into
the test project itself — that's the whole point.

Manifest shape
--------------

All ``{{VAR}}`` placeholders are resolved against the process environment
(Mustache via pystache, same as :class:`ConfigReader`). Empty values are
preserved so a provider that expects an optional field can tell 'absent'
from 'deliberately empty'.

Example::

    run_name: "eic-rag evaluation {{DATASET_PROFILE}} / build #{{BITBUCKET_BUILD_NUMBER}}"

    collectors:
      - name: junit
        type: junit
        source: ./docker/test-results/junit.xml

      - name: evaluation
        type: evaluation
        source: ./docker/test-results/evaluation/{{DATASET_PROFILE}}
        config:
          item_thresholds:
            recall:    0.5
            precision: 0.2
            ndcg:      0.5

    providers:
      - name: bitbucket
        type: bitbucket
        enabled: true
        collector: evaluation           # optional, defaults to first collector
        config:
          workspace:  "{{BITBUCKET_WORKSPACE}}"
          repo_slug:  "{{BITBUCKET_REPO_SLUG}}"
          commit:     "{{BITBUCKET_COMMIT}}"
          auth_token: "{{BITBUCKET_TOKEN}}"
          use_pipeline_proxy: false
          report_title: "Facade evaluation — {{DATASET_PROFILE}}"

      - name: langfuse
        type: langfuse
        enabled: true
        collector: evaluation
        config:
          host:        "{{LANGFUSE_HOST}}"
          public_key:  "{{LANGFUSE_PUBLIC_KEY}}"
          secret_key:  "{{LANGFUSE_SECRET_KEY}}"
          tags: ["{{DATASET_PROFILE}}", "ci"]
          session_id:  "facade-eval-{{DATASET_PROFILE}}"
          metadata:
            branch:     "{{BITBUCKET_BRANCH}}"
            commit:     "{{BITBUCKET_COMMIT}}"
            build:      "{{BITBUCKET_BUILD_NUMBER}}"
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pystache
import yaml

from test_data_management.collectors.allure_collector import AllureCollector
from test_data_management.collectors.cucumber_collector import CucumberCollector
from test_data_management.collectors.evaluation_collector import EvaluationCollector
from test_data_management.collectors.junit_collector import JUnitCollector
from test_data_management.collectors.nunit_collector import NUnitCollector
from test_data_management.core.base_collector import BaseCollector
from test_data_management.core.base_provider import BaseProvider
from test_data_management.core.test_data_manager import TestDataManager
from test_data_management.providers.bitbucket_provider import BitbucketProvider
from test_data_management.providers.testrail_provider import TestRailProvider


_LOGGER_NAME = 'testtoolkit.cli'

# Registries. Kept here (and not on BaseCollector / BaseProvider) because
# these are *CLI-level* defaults — library consumers always can instantiate
# any class directly.
_COLLECTOR_TYPES: Dict[str, type] = {
    'junit': JUnitCollector,
    'cucumber': CucumberCollector,
    'allure': AllureCollector,
    'nunit': NUnitCollector,
    'evaluation': EvaluationCollector,
}

_PROVIDER_TYPES: Dict[str, type] = {
    'bitbucket': BitbucketProvider,
    'testrail': TestRailProvider,
}


def _try_register_optional_providers() -> None:
    """
    Register providers with heavy / optional dependencies lazily so the
    CLI works even when they are not installed.
    """
    try:
        from test_data_management.providers.langfuse_provider import LangfuseProvider
        _PROVIDER_TYPES['langfuse'] = LangfuseProvider
    except Exception:  # pragma: no cover — optional
        pass


_try_register_optional_providers()


# ----------------------------------------------------------------- manifest


def _render_template(raw_text: str) -> str:
    """Render ``{{VAR}}`` placeholders from the process environment."""
    return pystache.render(raw_text, dict(os.environ))


def _load_manifest(manifest_path: Path) -> Dict[str, Any]:
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest file not found: {manifest_path}")

    with manifest_path.open('r', encoding='utf-8') as handle:
        rendered = _render_template(handle.read())

    try:
        parsed = yaml.safe_load(rendered)
    except yaml.YAMLError as exc:
        raise ValueError(f"Failed to parse manifest YAML '{manifest_path}': {exc}") from exc

    if not isinstance(parsed, dict):
        raise ValueError(f"Manifest '{manifest_path}' must be a YAML mapping at top level")

    return parsed


# -------------------------------------------------------- collector / provider


def _instantiate_collector(entry: Dict[str, Any]) -> Tuple[str, BaseCollector, Path]:
    name = entry.get('name')
    collector_type = entry.get('type') or name
    source = entry.get('source')

    if not name:
        raise ValueError(f"Collector entry is missing 'name': {entry}")
    if not collector_type:
        raise ValueError(f"Collector entry '{name}' is missing 'type'")
    if not source:
        raise ValueError(f"Collector entry '{name}' is missing 'source'")

    collector_cls = _COLLECTOR_TYPES.get(str(collector_type).lower())
    if collector_cls is None:
        raise ValueError(
            f"Unknown collector type '{collector_type}'. "
            f"Known: {sorted(_COLLECTOR_TYPES.keys())}"
        )

    config = entry.get('config') or {}
    if not isinstance(config, dict):
        raise ValueError(f"Collector '{name}' config must be a mapping")

    collector = collector_cls(config=config)
    return name, collector, Path(source)


def _instantiate_provider(entry: Dict[str, Any]) -> Tuple[str, BaseProvider, Optional[str]]:
    name = entry.get('name')
    provider_type = entry.get('type') or name
    collector_ref = entry.get('collector')

    if not name:
        raise ValueError(f"Provider entry is missing 'name': {entry}")
    if not provider_type:
        raise ValueError(f"Provider entry '{name}' is missing 'type'")

    provider_cls = _PROVIDER_TYPES.get(str(provider_type).lower())
    if provider_cls is None:
        raise ValueError(
            f"Unknown provider type '{provider_type}'. "
            f"Known: {sorted(_PROVIDER_TYPES.keys())}"
        )

    config = entry.get('config') or {}
    if not isinstance(config, dict):
        raise ValueError(f"Provider '{name}' config must be a mapping")

    provider = provider_cls(config=config)
    return name, provider, collector_ref


# ---------------------------------------------------------------- publish


def _cmd_publish(args: argparse.Namespace) -> int:
    logger = logging.getLogger(_LOGGER_NAME)

    manifest_path = Path(args.config).resolve()
    manifest = _load_manifest(manifest_path)

    run_name = manifest.get('run_name') or f"lib-testtoolkit run ({manifest_path.name})"

    manager = TestDataManager({'log_level': 'INFO'})

    collector_sources: Dict[str, Path] = {}
    for entry in manifest.get('collectors') or []:
        name, collector, source = _instantiate_collector(entry)
        manager.register_collector(name, collector)
        collector_sources[name] = source
        logger.info(f"Registered collector '{name}' ← {source}")

    if not collector_sources:
        logger.error("Manifest has no collectors — nothing to publish")
        return 2

    provider_specs: List[Tuple[str, BaseProvider, Optional[str], bool]] = []
    for entry in manifest.get('providers') or []:
        enabled = bool(entry.get('enabled', True))
        provider_name = entry.get('name') or '<unnamed>'

        if not enabled:
            # Skip instantiation entirely. A disabled provider should never
            # run its validate_config(), because the config may deliberately
            # lack required fields (e.g. a Bitbucket provider kept in the
            # manifest for documentation but without a token yet).
            logger.info(
                f"Provider '{provider_name}' has enabled=false — skipping instantiation"
            )
            continue

        name, provider, collector_ref = _instantiate_provider(entry)
        manager.register_provider(name, provider)
        provider_specs.append((name, provider, collector_ref, True))
        logger.info(
            f"Registered provider '{name}' "
            f"(collector='{collector_ref or 'first'}')"
        )

    if not provider_specs:
        logger.error("Manifest has no providers — nothing to publish")
        return 2

    # Pre-fetch results/summary per collector so we don't re-parse sources.
    collected_cache: Dict[str, Dict[str, Any]] = {}
    for collector_name, source in collector_sources.items():
        try:
            results = manager.collect_results(collector_name, source)
            summary = manager.collect_summary(collector_name, source)
            collected_cache[collector_name] = {
                'results': results,
                'summary': summary,
                'source': source,
            }
            logger.info(
                f"Collector '{collector_name}' produced {len(results)} result(s) "
                f"and {'non-empty' if summary else 'no'} summary"
            )
        except Exception as exc:  # pragma: no cover - collector-specific
            logger.exception(f"Collector '{collector_name}' failed: {exc}")
            if args.strict:
                return 3

    if not collected_cache:
        logger.error("No collectors produced any output — aborting publish")
        return 3

    first_collector_name = next(iter(collected_cache))

    overall_ok = True
    for provider_name, _, collector_ref, _enabled in provider_specs:
        # Disabled providers were filtered out at the registration step, so
        # every entry here is live. The tuple keeps the `enabled` slot for
        # future conditional logic (e.g. "warn but don't publish").
        target_collector = collector_ref or first_collector_name
        if target_collector not in collected_cache:
            logger.error(
                f"Provider '{provider_name}' refers to collector '{target_collector}' "
                f"which has no collected output. Available: {list(collected_cache.keys())}"
            )
            overall_ok = False
            if args.strict:
                return 4
            continue

        bundle = collected_cache[target_collector]
        results = bundle['results']
        summary = bundle['summary']

        try:
            run_id = manager.create_test_run(provider_name, run_name)
            success = manager.upload_results(
                provider_name, run_id, results, summary=summary,
            )
        except Exception as exc:  # pragma: no cover - provider-specific
            logger.exception(f"Provider '{provider_name}' failed: {exc}")
            overall_ok = False
            if args.strict:
                return 5
            continue

        if not success:
            logger.error(f"Provider '{provider_name}' reported upload failure")
            overall_ok = False
            if args.strict:
                return 6
        else:
            logger.info(
                f"Provider '{provider_name}' published run '{run_id}' "
                f"(results={len(results)}, summary={'yes' if summary else 'no'})"
            )

    return 0 if overall_ok else 1


# ------------------------------------------------------------------- info


def _cmd_list(args: argparse.Namespace) -> int:
    del args
    print("Collectors:")
    for key in sorted(_COLLECTOR_TYPES):
        print(f"  - {key}")
    print("Providers:")
    for key in sorted(_PROVIDER_TYPES):
        print(f"  - {key}")
    return 0


# ------------------------------------------------------------------- entry


def _configure_logging(verbosity: int) -> None:
    level = logging.DEBUG if verbosity > 0 else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog='testtoolkit',
        description='Collect test results and publish them to reporting providers.',
    )
    parser.add_argument(
        '-v', '--verbose', action='count', default=0,
        help='Increase logging verbosity (can be repeated).',
    )
    subparsers = parser.add_subparsers(dest='command', required=True)

    publish = subparsers.add_parser(
        'publish',
        help='Run collectors and publish results to configured providers.',
    )
    publish.add_argument(
        '-c', '--config', required=True,
        help='Path to the YAML manifest describing collectors and providers.',
    )
    publish.add_argument(
        '--strict', action='store_true',
        help='Abort on the first collector or provider failure.',
    )
    publish.set_defaults(func=_cmd_publish)

    list_cmd = subparsers.add_parser(
        'list',
        help='List registered collector and provider types.',
    )
    list_cmd.set_defaults(func=_cmd_list)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    _configure_logging(args.verbose)
    return int(args.func(args))


if __name__ == '__main__':  # pragma: no cover
    sys.exit(main())
