# cognis-executor

Standalone remote executor for Cognis.

This package provides the `cognis-executor` command used to connect a
remote executor process to a Cognis controller over WebSocket.
