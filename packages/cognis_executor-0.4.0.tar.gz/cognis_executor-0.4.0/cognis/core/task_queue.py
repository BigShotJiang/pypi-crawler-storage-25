"""Task queue — priority-based task picking, dependency resolution, and lifecycle.

Uses polling for MVP (event-based wakeups can be added via asyncio.Event
signaling or Postgres LISTEN/NOTIFY in Phase 2). Capacity enforcement
uses a unified model: max active steps globally and per-agent.
"""

from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from prometheus_client import Counter, Gauge, Histogram
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from cognis.core.agent_loop import PauseResolution
from cognis.core.events import Event, EventBus, EventType
from cognis.core.workflow_engine import WorkflowEngine
from cognis.core.workflow_management import (
    decode_skill_workflow_candidate_id,
    encode_skill_workflow_candidate_id,
    materialize_skill_workflow,
    skill_workflow_criteria,
)
from cognis.core.workflow_registry import WorkflowRegistry
from cognis.logging import get_logger
from cognis.models.task import TaskDelivery, TaskModel, TaskStatus
from cognis.models.workflow import CompletionDeliveryPolicy, WorkflowState
from cognis.runtime_context import scoped_runtime_context
from cognis.store.queries import (
    add_task_dependency,
    count_active_steps,
    create_task,
    fail_orphaned_running_step_runs,
    fail_running_step_runs_for_task,
    get_dependent_tasks,
    get_setting_value,
    get_task,
    get_task_dependencies,
    get_unmet_dependencies,
    list_stale_running_tasks,
    list_tasks_by_status,
    pick_ready_task,
    supersede_step_runs_for_revision,
    update_task_status,
    update_task_workflow_state,
    update_workflow,
)
from cognis.tools.skills import resolve_skills_for_agent

logger = get_logger(__name__)

# Prometheus metrics
QUEUE_DEPTH = Gauge(
    "cognis_task_queue_depth",
    "Tasks waiting in queue",
    labelnames=("queue",),
)
TASKS_TOTAL = Counter(
    "cognis_tasks_total",
    "Task lifecycle transitions",
    labelnames=("status",),
)
TASK_PICK_DURATION = Histogram(
    "cognis_task_pick_duration_seconds",
    "Time to pick next task",
)

# Default capacity limits
DEFAULT_MAX_ACTIVE_STEPS_GLOBAL = 10
DEFAULT_MAX_ACTIVE_STEPS_PER_AGENT = 5
DEFAULT_POLL_INTERVAL_SECONDS = 1.0
DEFAULT_STALE_AFTER_SECONDS = 300

_RERUN_CLONE_STATUSES = {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED}


@dataclass(slots=True)
class TaskRerunResult:
    """Resolved outcome of a task rerun request."""

    source_task_id: str
    task: TaskModel
    created_new: bool


def _recover_pause_options(value: Any) -> list[dict[str, Any]] | None:
    """Normalize recovered pause options into canonical list[dict] shape."""

    if not isinstance(value, list):
        return None
    normalized: list[dict[str, Any]] = []
    for option in value:
        if isinstance(option, dict):
            normalized.append(option)
        elif isinstance(option, str):
            normalized.append({"label": option, "action": option})
    return normalized or None


def _recover_pause_context(value: Any) -> dict[str, Any] | None:
    """Normalize recovered pause context into dict-or-None."""

    if isinstance(value, dict):
        return value
    if value is None or value == "":
        return None
    return {"note": str(value)}


class TaskQueue:
    """Priority-based task queue with dependency resolution."""

    def __init__(
        self,
        *,
        session_factory: async_sessionmaker[AsyncSession],
        workflow_engine: WorkflowEngine,
        workflow_registry: WorkflowRegistry,
        event_bus: EventBus,
        agent_registry: Any = None,
        llm_provider: Any = None,
        max_active_steps_global: int = DEFAULT_MAX_ACTIVE_STEPS_GLOBAL,
        max_active_steps_per_agent: int = DEFAULT_MAX_ACTIVE_STEPS_PER_AGENT,
        poll_interval_seconds: float = DEFAULT_POLL_INTERVAL_SECONDS,
    ) -> None:
        self._session_factory = session_factory
        self._workflow_engine = workflow_engine
        self._workflow_registry = workflow_registry
        self._event_bus = event_bus
        self._agent_registry = agent_registry
        self._llm_provider = llm_provider
        self._max_active_global = max_active_steps_global
        self._max_active_per_agent = max_active_steps_per_agent
        self._poll_interval = poll_interval_seconds
        self._accepting = True
        self._stop_event = asyncio.Event()
        self._drain_task: asyncio.Task[None] | None = None
        self._active_runs: dict[str, asyncio.Task[Any]] = {}
        self._run_controls: dict[str, asyncio.Event] = {}
        self._pick_lock = asyncio.Lock()
        self._wake_event = asyncio.Event()

    @classmethod
    async def from_session_factory(
        cls,
        *,
        session_factory: async_sessionmaker[AsyncSession],
        workflow_engine: WorkflowEngine,
        workflow_registry: WorkflowRegistry,
        event_bus: EventBus,
        agent_registry: Any = None,
        llm_provider: Any = None,
    ) -> TaskQueue:
        """Create a TaskQueue with DB-backed settings."""
        async with session_factory() as db_session:
            max_global = await get_setting_value(
                db_session,
                "workflow.max_active_steps_global",
                DEFAULT_MAX_ACTIVE_STEPS_GLOBAL,
            )
            max_per_agent = await get_setting_value(
                db_session,
                "workflow.max_active_steps_per_agent",
                DEFAULT_MAX_ACTIVE_STEPS_PER_AGENT,
            )
        return cls(
            session_factory=session_factory,
            workflow_engine=workflow_engine,
            workflow_registry=workflow_registry,
            event_bus=event_bus,
            agent_registry=agent_registry,
            llm_provider=llm_provider,
            max_active_steps_global=int(max_global)
            if isinstance(max_global, int)
            else DEFAULT_MAX_ACTIVE_STEPS_GLOBAL,
            max_active_steps_per_agent=int(max_per_agent)
            if isinstance(max_per_agent, int)
            else DEFAULT_MAX_ACTIVE_STEPS_PER_AGENT,
        )

    async def start(self) -> None:
        """Start the queue processing loop."""
        self._stop_event.clear()
        self._accepting = True
        self._drain_task = asyncio.create_task(self._drain_loop())
        logger.info("Task queue started")

    async def stop(self) -> None:
        """Graceful shutdown.

        1. Stop accepting new tasks
        2. Signal active workflow runs to finish current LLM call
        3. Wait up to 30s for active steps to finalize
        4. Mark remaining running tasks as 'queued' for recovery
        5. Cancel the drain loop
        """
        self._accepting = False
        self._stop_event.set()
        self._wake_event.set()

        if self._drain_task:
            self._drain_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, TimeoutError):
                await asyncio.wait_for(self._drain_task, timeout=5.0)

        # Cancel active runs with grace period
        if self._active_runs:
            logger.info(
                "Waiting for active workflow runs to finish",
                extra={"extra_data": {"count": len(self._active_runs)}},
            )
            active_task_ids = list(self._active_runs)
            for task_id, run_task in list(self._active_runs.items()):
                control = self._run_controls.get(task_id)
                if control is not None:
                    control.set()
                run_task.cancel()

            await asyncio.gather(
                *self._active_runs.values(),
                return_exceptions=True,
            )

            # Re-queue tasks that were running
            async with self._session_factory() as db_session:
                for task_id in active_task_ids:
                    await update_task_status(db_session, task_id, "queued")
                await db_session.commit()

        self._active_runs.clear()
        self._run_controls.clear()
        logger.info("Task queue stopped")

    async def submit(
        self,
        *,
        created_by: str,
        agent_id: str,
        title: str,
        description: str = "",
        expected_output: str | None = None,
        priority: int = 0,
        source_type: str = "api",
        source_ref: str | None = None,
        delivery: TaskDelivery | None = None,
        completion_delivery: CompletionDeliveryPolicy | None = None,
        interaction_mode_override: str | None = None,
        workflow_id: str | None = None,
        project_id: str | None = None,
        workspace_root: str | None = None,
        working_directory: str | None = None,
        scheduled_for: datetime | None = None,
        status: str = "queued",
    ) -> TaskModel:
        """Submit a task for execution.

        Creates the task in the DB and triggers dependency resolution.
        """
        if not self._accepting:
            raise RuntimeError("Task queue is not accepting new tasks")

        delivery = delivery or TaskDelivery()
        completion_delivery = completion_delivery or await self._resolve_completion_delivery_policy(
            workflow_id=workflow_id,
            owner_email=created_by,
            project_id=project_id,
        )

        async with self._session_factory() as db_session:
            row = await create_task(
                db_session,
                created_by=created_by,
                agent_id=agent_id,
                title=title,
                description=description,
                expected_output=expected_output,
                status=status,
                priority=priority,
                source_type=source_type,
                source_ref=source_ref,
                delivery_mode=delivery.mode,
                delivery_target=delivery.target,
                completion_mode_family=completion_delivery.completion_mode_family,
                allow_silent_completion=completion_delivery.allow_silent_completion,
                interaction_mode_override=interaction_mode_override,
                workflow_id=workflow_id,
                project_id=project_id,
                workspace_root=workspace_root,
                working_directory=working_directory,
                scheduled_for=scheduled_for,
            )
            await db_session.commit()

            task = _row_to_task_model(row)

        TASKS_TOTAL.labels(status=status).inc()
        await self._event_bus.publish(
            Event(
                type=EventType.TASK_CREATED,
                data={"task_id": task.task_id, "status": status},
            )
        )

        # If queued, try to transition to ready
        if status == "queued":
            await self._try_transition_to_ready(task.task_id)

        # Wake the drain loop
        self._wake_event.set()

        return task

    async def _resolve_completion_delivery_policy(
        self,
        *,
        workflow_id: str | None,
        owner_email: str,
        project_id: str | None,
    ) -> CompletionDeliveryPolicy:
        if workflow_id is None:
            return CompletionDeliveryPolicy()

        workflow = await self._workflow_registry.get(
            workflow_id,
            owner_email=owner_email,
            project_id=project_id,
        )
        if workflow is None:
            return CompletionDeliveryPolicy()

        defaults = getattr(workflow, "defaults", None)
        delivery_defaults = (
            defaults.get("delivery")
            if isinstance(defaults, dict)
            else getattr(defaults, "delivery", None)
        )
        if delivery_defaults is None:
            return CompletionDeliveryPolicy()

        return CompletionDeliveryPolicy.model_validate(
            delivery_defaults.model_dump(mode="json")
            if hasattr(delivery_defaults, "model_dump")
            else delivery_defaults
        )

    async def create_draft(
        self,
        *,
        created_by: str,
        agent_id: str,
        title: str,
        description: str = "",
        expected_output: str | None = None,
        priority: int = 0,
        delivery: TaskDelivery | None = None,
        completion_delivery: CompletionDeliveryPolicy | None = None,
        interaction_mode_override: str | None = None,
        workflow_id: str | None = None,
        project_id: str | None = None,
        workspace_root: str | None = None,
        working_directory: str | None = None,
        source_type: str = "api",
        source_ref: str | None = None,
    ) -> TaskModel:
        """Create a draft task visible in the kanban board."""
        return await self.submit(
            created_by=created_by,
            agent_id=agent_id,
            title=title,
            description=description,
            expected_output=expected_output,
            priority=priority,
            delivery=delivery,
            completion_delivery=completion_delivery,
            interaction_mode_override=interaction_mode_override,
            workflow_id=workflow_id,
            project_id=project_id,
            workspace_root=workspace_root,
            working_directory=working_directory,
            source_type=source_type,
            source_ref=source_ref,
            status="draft",
        )

    async def submit_existing(self, task_id: str) -> TaskModel:
        """Move an existing draft task into the queue."""
        async with self._session_factory() as db_session:
            task_row = await get_task(db_session, task_id)
            if task_row is None:
                raise ValueError("Task not found")
            if task_row.status != "draft":
                raise ValueError("Only draft tasks can be submitted")
            ok = await update_task_status(db_session, task_id, "queued")
            if not ok:
                raise ValueError("Task could not be submitted")
            await db_session.commit()
            task = _row_to_task_model(task_row)

        TASKS_TOTAL.labels(status="queued").inc()
        await self._try_transition_to_ready(task_id)
        self._wake_event.set()
        task.status = TaskStatus.QUEUED
        return task

    async def batch_submit(self, task_ids: list[str]) -> dict[str, Any]:
        """Submit multiple draft tasks in best-effort mode."""
        results: list[dict[str, Any]] = []
        succeeded = 0
        failed = 0
        for task_id in task_ids:
            try:
                task = await self.submit_existing(task_id)
                results.append({"task_id": task.task_id, "status": task.status})
                succeeded += 1
            except ValueError as exc:
                results.append({"task_id": task_id, "status": "error", "error": str(exc)})
                failed += 1
        return {"results": results, "succeeded": succeeded, "failed": failed}

    async def pause_task(self, task_id: str) -> TaskModel:
        """Pause a running task cooperatively."""
        async with self._session_factory() as db_session:
            task_row = await get_task(db_session, task_id)
            if task_row is None:
                raise ValueError("Task not found")
            if task_row.status != "running":
                raise ValueError("Only running tasks can be paused")
            ok = await update_task_status(db_session, task_id, "paused")
            if not ok:
                raise ValueError("Task could not be paused")
            await db_session.commit()
            task = _row_to_task_model(task_row)

        control = self._run_controls.get(task_id)
        if control is not None:
            control.set()
        return task.model_copy(update={"status": TaskStatus.PAUSED})

    async def resume_task(self, task_id: str) -> TaskModel:
        """Resume a paused task when capacity is available.

        Acquires ``_pick_lock`` to prevent races with the drain loop
        that could launch duplicate task runs.
        """
        if self._get_pending_interaction(task_id) is not None:
            raise ValueError("Task is waiting for gate or step input response")

        async with self._pick_lock:
            async with self._session_factory() as db_session:
                task_row = await get_task(db_session, task_id)
                if task_row is None:
                    raise ValueError("Task not found")
                if task_row.status != "paused":
                    raise ValueError("Only paused tasks can be resumed")
                task = _row_to_task_model(task_row)

            if not await self._has_capacity(agent_id=task.agent_id):
                raise ValueError("No execution capacity available to resume the task")

            async with self._session_factory() as db_session:
                ok = await update_task_status(db_session, task_id, "running")
                if not ok:
                    raise ValueError("Task could not be resumed")
                await db_session.commit()

            task.status = TaskStatus.RUNNING
            self._launch_task_run(task)
        return task

    async def retry_failed_task(self, task_id: str) -> TaskModel:
        """Reset a failed task's workflow state and re-launch it.

        Unlike ``resume_task`` (which only works for paused tasks), this
        method handles tasks in ``failed`` status by resetting the attempt
        counter for the current step and transitioning back to ``running``.
        """
        async with self._session_factory() as db_session:
            task_row = await get_task(db_session, task_id)
            if task_row is None:
                raise ValueError("Task not found")
            if task_row.status != "failed":
                raise ValueError("Only failed tasks can be retried via retry_failed_task")

            # Reset workflow state — clear attempt counters so the step
            # gets fresh attempts, and set status back to running.
            ws = (
                WorkflowState.model_validate(task_row.workflow_state)
                if task_row.workflow_state
                else WorkflowState()
            )
            ws.loop_iterations = {}  # Reset all attempt counters
            ws.status = "running"
            ws.current_step_status = None
            ws.pending_pause_type = None
            ws.pending_pause_payload = None

            task_row.workflow_state = ws.model_dump(mode="json")
            await update_task_status(db_session, task_id, "running")
            await db_session.commit()

            task = _row_to_task_model(task_row)

        task.workflow_state = ws
        self._launch_task_run(task)
        return task

    async def rerun_task(self, task_id: str) -> TaskRerunResult:
        """Re-run a task by resuming it or cloning it for a fresh run.

        Paused tasks resume in place. Terminal tasks create a fresh draft copy,
        preserve direct dependencies, then submit the new task.
        """

        async with self._session_factory() as db_session:
            task_row = await get_task(db_session, task_id)
            if task_row is None:
                raise ValueError("Task not found")
            task = _row_to_task_model(task_row)

        if task.status == TaskStatus.PAUSED:
            resumed = await self.resume_task(task_id)
            return TaskRerunResult(source_task_id=task_id, task=resumed, created_new=False)

        if task.status not in _RERUN_CLONE_STATUSES:
            raise ValueError(f"Cannot rerun task in '{task.status}' status.")

        cloned = await self._clone_task_for_rerun(task)
        return TaskRerunResult(source_task_id=task_id, task=cloned, created_new=True)

    async def request_revision(
        self,
        task_id: str,
        *,
        target_step: str | None,
        instruction: str,
    ) -> TaskModel:
        """Re-enter a workflow from a human-selected step in-place."""

        async with self._session_factory() as db_session:
            task_row = await get_task(db_session, task_id)
            if task_row is None:
                raise ValueError("Task not found")
            task = _row_to_task_model(task_row)
            if task.workflow_id is None:
                raise ValueError("Task has no workflow to revise")
            workflow = await self._workflow_registry.get(
                task.workflow_id,
                owner_email=task.created_by,
                project_id=task.project_id,
                include_disabled=True,
            )
            if workflow is None:
                raise ValueError("Workflow not found")

        pending_pause = self._get_pending_interaction(task_id)
        if pending_pause is not None:
            notification_service = self._workflow_engine._notification_service  # noqa: SLF001
            if notification_service is not None:
                await notification_service.resolve(
                    pending_pause.pause_id,
                    "revise",
                    {"note": instruction},
                    user_email=task.created_by,
                )
            else:
                self._workflow_engine._pause_waiter.resolve(  # noqa: SLF001
                    pending_pause.pause_id,
                    PauseResolution(decision="revise", data={"note": instruction}),
                )
        await self._cancel_active_run_for_revision(task_id)

        async with self._session_factory() as db_session:
            task_row = await get_task(db_session, task_id)
            if task_row is None:
                raise ValueError("Task not found")
            task = _row_to_task_model(task_row)
            state = task.workflow_state or WorkflowState()
            step_names = [step.name for step in workflow.steps]
            if not step_names:
                raise ValueError("Workflow has no steps")
            if target_step and target_step not in step_names:
                raise ValueError("Target step not found")
            target_index = (
                step_names.index(target_step) if target_step else max(0, state.current_step_index)
            )
            new_attempt_number = int(getattr(task_row, "attempt_number", 1) or 1) + 1
            state.current_step_index = target_index
            state.status = "running"
            state.current_step_status = None
            state.pending_pause_type = None
            state.pending_pause_payload = None
            state.last_operator_instruction = instruction
            state.last_revision_context = instruction
            for step_name in step_names[target_index:]:
                state.step_outputs.pop(step_name, None)
            await supersede_step_runs_for_revision(
                db_session,
                task_id,
                step_names[target_index:],
                before_attempt_number=new_attempt_number,
            )
            task_row.attempt_number = new_attempt_number
            task_row.status = "running"
            task_row.completed_at = None
            task_row.result_summary = None
            task_row.result_data = None
            task_row.workflow_state = state.model_dump(mode="json")
            task_row.updated_at = datetime.now(UTC)
            await db_session.commit()
            await db_session.refresh(task_row)
            task = _row_to_task_model(task_row)

        self._launch_task_run(task)
        return task

    async def _cancel_active_run_for_revision(self, task_id: str) -> None:
        """Stop an existing paused run so a revision starts from refreshed DB state."""

        run_task = self._active_runs.get(task_id)
        if run_task is None or run_task.done():
            return
        run_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await run_task

    async def _clone_task_for_rerun(self, source_task: TaskModel) -> TaskModel:
        """Clone a terminal task into a fresh submitted task."""

        draft = await self.create_draft(
            created_by=source_task.created_by,
            agent_id=source_task.agent_id,
            title=source_task.title,
            description=source_task.description,
            expected_output=source_task.expected_output,
            priority=source_task.priority,
            delivery=source_task.delivery,
            completion_delivery=source_task.completion_delivery,
            workflow_id=source_task.workflow_id,
            project_id=source_task.project_id,
            workspace_root=source_task.workspace_root,
            working_directory=source_task.working_directory,
            source_type=source_task.source_type,
            source_ref=source_task.source_ref,
        )

        async with self._session_factory() as db_session:
            dependencies = await get_task_dependencies(db_session, source_task.task_id)
            for dependency in dependencies:
                await add_task_dependency(
                    db_session,
                    draft.task_id,
                    dependency.depends_on,
                    required=bool(dependency.required),
                )
            await db_session.commit()

        return await self.submit_existing(draft.task_id)

    async def cancel_task(self, task_id: str) -> TaskModel:
        """Cancel a task in any mutable state."""
        pending_pause = self._get_pending_interaction(task_id)
        if pending_pause is not None:
            self._workflow_engine._pause_waiter.resolve(  # noqa: SLF001
                pending_pause.pause_id,
                self._build_cancel_resolution(pending_pause.pause_type),
            )

        async with self._session_factory() as db_session:
            task_row = await get_task(db_session, task_id)
            if task_row is None:
                raise ValueError("Task not found")
            if task_row.status in {"completed", "failed", "cancelled"}:
                return _row_to_task_model(task_row)
            ok = await update_task_status(
                db_session,
                task_id,
                "cancelled",
                completed_at=datetime.now(UTC),
            )
            if not ok:
                raise ValueError("Task could not be cancelled")
            if task_row.status == "paused":
                await fail_running_step_runs_for_task(
                    db_session,
                    task_id,
                    datetime.now(UTC),
                    final_status="cancelled",
                )
            await db_session.commit()
            task = _row_to_task_model(task_row)

        notification_service = getattr(self._workflow_engine, "_notification_service", None)
        if notification_service is not None:
            with contextlib.suppress(Exception):
                await notification_service.mark_task_notifications_terminal(
                    task_id,
                    reason="task_cancelled",
                )

        control = self._run_controls.get(task_id)
        if control is not None:
            control.set()
        run_task = self._active_runs.get(task_id)
        if run_task is not None:
            run_task.cancel()
        return task.model_copy(update={"status": TaskStatus.CANCELLED})

    async def resolve_dependencies(self, completed_task_id: str) -> list[str]:
        """Re-evaluate dependents when a task completes.

        Returns list of task IDs that were transitioned to 'ready'.
        """
        transitioned: list[str] = []

        async with self._session_factory() as db_session:
            dependent_ids = await get_dependent_tasks(db_session, completed_task_id)

            for dep_id in dependent_ids:
                unmet = await get_unmet_dependencies(db_session, dep_id)
                if not unmet:
                    # All dependencies met — transition to ready
                    ok = await update_task_status(db_session, dep_id, "ready")
                    if ok:
                        transitioned.append(dep_id)
                        TASKS_TOTAL.labels(status="ready").inc()
                else:
                    # Check for failed required dependencies
                    failed_required = [d for d in unmet if d.required]
                    if failed_required:
                        # Check if the depended-on task actually failed
                        for dep in failed_required:
                            dep_task = await get_task(db_session, dep.depends_on)
                            if dep_task and dep_task.status in ("failed", "cancelled"):
                                # Flag for user decision — pause the task
                                await update_task_status(db_session, dep_id, "paused")
                                break

            await db_session.commit()

        # Wake the drain loop for newly ready tasks
        if transitioned:
            self._wake_event.set()

        return transitioned

    async def recover_stale_tasks(
        self, stale_after_seconds: int = DEFAULT_STALE_AFTER_SECONDS
    ) -> list[str]:
        """Recover tasks stuck in running state after controller restart.

        Called on startup after SessionManager.recover_stale_sessions().
        """
        threshold = datetime.now(UTC) - timedelta(seconds=stale_after_seconds)
        recovered: list[str] = []

        async with self._session_factory() as db_session:
            stale_tasks = await list_stale_running_tasks(db_session, threshold)

            for task in stale_tasks:
                # Fail associated running step_runs
                await fail_running_step_runs_for_task(db_session, task.task_id, datetime.now(UTC))

                # Re-queue the task for retry
                ok = await update_task_status(db_session, task.task_id, "queued")
                if ok:
                    recovered.append(task.task_id)
                    logger.info(
                        "Recovered stale task",
                        extra={"extra_data": {"task_id": task.task_id}},
                    )

            await db_session.commit()

        return recovered

    async def recover_paused_tasks(self) -> list[str]:
        """Re-enter paused workflows so prompts and waits are recreated after restart.

        Each pause type has a distinct recovery contract:

        * ``gate`` — the workflow engine re-creates the gate notification
          when the task resumes.
        * ``step_input`` — if the user already responded before the
          restart, the payload carries ``response`` and the agent loop
          consumes it through ``_get_recovered_step_response``; relaunch
          without registering a new PauseWaiter (a fresh waiter would
          never be resolved and would pollute ``find_pending()`` output).
          If no response is persisted, register a waiter and keep the
          task paused until the user answers through the API.
        * ``credential_request`` / ``auth_challenge`` — resolutions for
          these pauses are stored on the ``NotificationRow`` (not on the
          task workflow state). If the notification is already
          ``resolved``, register the waiter and immediately replay the
          resolution so the relaunched agent loop can consume the
          response without blocking. Otherwise keep the task paused.

        Without relaunching, tasks whose awaiting coroutine died with
        the controller would stay paused forever.
        """

        from cognis.core.agent_loop import PauseResolution, PendingPause  # noqa: F401

        recovered: list[str] = []
        async with self._session_factory() as db_session:
            paused_rows = await list_tasks_by_status(db_session, ["paused"], limit=1000)

        for row in paused_rows:
            task = _row_to_task_model(row)
            if task.workflow_state is None:
                continue
            pause_type = task.workflow_state.pending_pause_type
            if pause_type is None:
                continue

            payload = task.workflow_state.pending_pause_payload or {}
            pause_id = str(payload.get("pause_id", f"recovered_{task.task_id}"))

            if pause_type == "gate":
                self._launch_task_run(task)
            elif pause_type == "step_input":
                await self._recover_step_input_pause(task=task, pause_id=pause_id, payload=payload)
            elif pause_type in {"credential_request", "auth_challenge"}:
                await self._recover_credential_or_auth_pause(
                    task=task,
                    pause_id=pause_id,
                    pause_type=str(pause_type),
                    payload=payload,
                )
            else:
                logger.warning(
                    "task_queue: unknown pause type during recovery",
                    extra={
                        "extra_data": {
                            "task_id": task.task_id,
                            "pause_type": pause_type,
                        }
                    },
                )
            recovered.append(task.task_id)

        return recovered

    async def _recover_step_input_pause(
        self,
        *,
        task: TaskModel,
        pause_id: str,
        payload: dict[str, Any],
    ) -> None:
        from cognis.core.agent_loop import PendingPause

        if payload.get("response") is not None:
            # The HTTP respond path persisted the user's answer before
            # the restart; the relaunched agent loop consumes it via
            # ``_get_recovered_step_response`` without a PauseWaiter.
            self._launch_task_run(task)
            return

        existing = self._workflow_engine._pause_waiter.get(pause_id)  # noqa: SLF001
        if existing is None:
            self._workflow_engine._pause_waiter.register(  # noqa: SLF001
                PendingPause(
                    pause_id=pause_id,
                    pause_type="step_input",
                    task_id=task.task_id,
                    step_name=payload.get("step_name"),
                    step_run_id=payload.get("step_run_id"),
                    session_id=payload.get("session_id"),
                    question=payload.get("question") or payload.get("message"),
                    options=_recover_pause_options(payload.get("options")),
                    context=_recover_pause_context(payload.get("context")),
                )
            )

    async def _recover_credential_or_auth_pause(
        self,
        *,
        task: TaskModel,
        pause_id: str,
        pause_type: str,
        payload: dict[str, Any],
    ) -> None:
        from cognis.core.agent_loop import PauseResolution, PendingPause

        resolved_decision: str | None = None
        resolved_data: dict[str, Any] | None = None

        notification_service = getattr(self._workflow_engine, "_notification_service", None)
        if notification_service is not None:
            try:
                notif_row = await notification_service.get(pause_id)
            except Exception:
                notif_row = None
            if notif_row is not None and getattr(notif_row, "status", None) == "resolved":
                resolution = getattr(notif_row, "resolution", None)
                if isinstance(resolution, dict):
                    resolved_decision = str(resolution.get("decision") or "continue")
                    resolved_data = {
                        key: value
                        for key, value in resolution.items()
                        if key not in {"decision", "state"}
                    }

        if resolved_decision is not None and resolved_data is not None:
            self._workflow_engine._pause_waiter.register(  # noqa: SLF001
                PendingPause(
                    pause_id=pause_id,
                    pause_type=pause_type,
                    task_id=task.task_id,
                    step_name=payload.get("step_name"),
                    step_run_id=payload.get("step_run_id"),
                    session_id=payload.get("session_id"),
                    question=payload.get("question") or payload.get("message"),
                    options=_recover_pause_options(payload.get("options")),
                    context=_recover_pause_context(payload.get("context")),
                )
            )
            self._workflow_engine._pause_waiter.resolve(  # noqa: SLF001
                pause_id,
                PauseResolution(decision=resolved_decision, data=resolved_data),
            )
            logger.info(
                "task_queue: replaying resolved credential/auth notification on recovery",
                extra={
                    "extra_data": {
                        "task_id": task.task_id,
                        "pause_type": pause_type,
                        "decision": resolved_decision,
                    }
                },
            )
            self._launch_task_run(task)
            return

        existing = self._workflow_engine._pause_waiter.get(pause_id)  # noqa: SLF001
        if existing is None:
            self._workflow_engine._pause_waiter.register(  # noqa: SLF001
                PendingPause(
                    pause_id=pause_id,
                    pause_type=pause_type,
                    task_id=task.task_id,
                    step_name=payload.get("step_name"),
                    step_run_id=payload.get("step_run_id"),
                    session_id=payload.get("session_id"),
                    question=payload.get("question") or payload.get("message"),
                    options=_recover_pause_options(payload.get("options")),
                    context=_recover_pause_context(payload.get("context")),
                )
            )

    async def recover_orphaned_running_step_runs(self) -> int:
        """Finalize running step runs whose parent tasks are already terminal."""

        async with self._session_factory() as db_session:
            recovered = await fail_orphaned_running_step_runs(
                db_session,
                datetime.now(UTC),
                final_status="failed",
            )
            await db_session.commit()
        if recovered:
            logger.info(
                "Recovered orphaned running step runs",
                extra={"extra_data": {"count": recovered}},
            )
        return recovered

    async def _drain_loop(self) -> None:
        """Main queue processing loop."""
        while not self._stop_event.is_set():
            try:
                # Wait for wake signal or poll interval
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(
                        self._wake_event.wait(),
                        timeout=self._poll_interval,
                    )
                self._wake_event.clear()

                if self._stop_event.is_set():
                    break

                # Clean up completed runs
                for task_id in list(self._active_runs):
                    if self._active_runs[task_id].done():
                        self._active_runs.pop(task_id)
                        self._run_controls.pop(task_id, None)

                # Check capacity
                if not await self._has_capacity():
                    continue

                # Try to pick and run a task
                await self._try_pick_and_run()

            except Exception:
                logger.exception("Task queue drain loop error")
                await asyncio.sleep(self._poll_interval)

    async def _try_pick_and_run(self) -> None:
        """Try to pick the next ready task and start executing it."""
        async with self._pick_lock, self._session_factory() as db_session:
            task_row = await pick_ready_task(db_session)
            if task_row is None:
                return
            await db_session.commit()

            task = _row_to_task_model(task_row)

        # Check per-agent capacity after picking
        if not await self._has_capacity(agent_id=task.agent_id):
            # Agent is saturated — put the task back to ready
            async with self._session_factory() as db_session:
                await update_task_status(db_session, task.task_id, "ready")
                await db_session.commit()
            return

        TASKS_TOTAL.labels(status="running").inc()

        await self._event_bus.publish(
            Event(
                type=EventType.TASK_STARTED,
                data={"task_id": task.task_id},
            )
        )

        # Start workflow execution in background
        self._launch_task_run(task)

    async def _select_workflow_for_task(self, task: TaskModel) -> str:
        """Auto-select a workflow using the LLM classifier.

        Falls back to ``system:general-task`` if the classifier is unavailable
        or no workflows match. Persists the selection to the DB so the user can
        see which workflow was chosen.
        """
        if self._llm_provider is None:
            return "system:general-task"

        from cognis.core.decision import select_workflow

        try:
            available = await self._workflow_registry.list_all(
                owner_email=task.created_by,
                project_id=task.project_id,
            )
            workflow_candidates = [
                {
                    "workflow_id": workflow.workflow_id,
                    "name": workflow.name,
                    "criteria": workflow.criteria,
                }
                for workflow in available
            ]
            if self._agent_registry is not None:
                agent = await self._agent_registry.get(task.agent_id, owner_email=task.created_by)
                if agent is not None:
                    async with self._session_factory() as session:
                        resolved_skills = await resolve_skills_for_agent(
                            session,
                            agent,
                            owner_email=task.created_by,
                        )
                    for skill in resolved_skills.skills:
                        if not skill.attached or not skill.steps:
                            continue
                        workflow_candidates.append(
                            {
                                "workflow_id": encode_skill_workflow_candidate_id(skill.skill_id),
                                "name": f"Skill: {skill.name}",
                                "criteria": skill_workflow_criteria(skill),
                            }
                        )
            if not workflow_candidates:
                return "system:general-task"

            selection = await select_workflow(
                llm=self._llm_provider,
                task_description=task.description or task.title,
                available_workflows=workflow_candidates,
                default_workflow_id="system:general-task",
            )
            workflow_id = selection.workflow_id
            selected_skill_id = decode_skill_workflow_candidate_id(workflow_id)
            if selected_skill_id is not None:
                created_workflow = await materialize_skill_workflow(
                    session_factory=self._session_factory,
                    owner_email=task.created_by,
                    skill_id=selected_skill_id,
                    lifecycle="ephemeral",
                    composition_source="agent_composed",
                    composition_intent=task.description or task.title,
                )
                workflow_id = created_workflow.workflow_id
            logger.info(
                "Auto-selected workflow for task",
                extra={
                    "extra_data": {
                        "task_id": task.task_id,
                        "workflow_id": workflow_id,
                        "confidence": selection.confidence,
                        "reason": selection.reason,
                    }
                },
            )
        except Exception:
            logger.warning(
                "Workflow auto-selection failed, falling back to system:general-task",
                extra={"extra_data": {"task_id": task.task_id}},
                exc_info=True,
            )
            workflow_id = "system:general-task"

        # Persist the selected workflow on the task for visibility
        task.workflow_id = workflow_id
        async with self._session_factory() as db_session:
            row = await get_task(db_session, task.task_id)
            if row is not None:
                row.workflow_id = workflow_id
                await db_session.commit()

        return workflow_id

    async def _run_task(self, task: TaskModel) -> None:
        """Execute a task's workflow.

        Runs inside ``scoped_runtime_context`` so that all downstream
        Intaris calls (event recording, evaluation, delivery) use the
        correct user identity instead of the default ``system@example.com``.
        """
        cancel_event = self._run_controls.setdefault(task.task_id, asyncio.Event())
        agent = await self._agent_registry.get(task.agent_id, owner_email=task.created_by)
        with scoped_runtime_context(
            user_email=task.created_by,
            agent_id=task.agent_id,
            agent_owner_email=(agent.owner_email if agent is not None else task.created_by),
            workspace_root=task.workspace_root,
            effective_working_directory=task.working_directory or task.workspace_root,
        ):
            try:
                # Resolve workflow — auto-select via LLM classifier if not set
                if task.workflow_id:
                    workflow_id = task.workflow_id
                else:
                    workflow_id = await self._select_workflow_for_task(task)
                workflow = await self._workflow_registry.get(
                    workflow_id, owner_email=task.created_by, project_id=task.project_id
                )
                if workflow is None:
                    logger.warning(
                        "Unknown workflow for task",
                        extra={"extra_data": {"task_id": task.task_id, "workflow_id": workflow_id}},
                    )
                    async with self._session_factory() as db_session:
                        await update_task_status(
                            db_session,
                            task.task_id,
                            "failed",
                            result_summary=f"Unknown workflow: {workflow_id}",
                            completed_at=datetime.now(UTC),
                        )
                        await db_session.commit()
                    return

                # Initialize workflow state
                task.workflow_state = task.workflow_state or WorkflowState()
                async with self._session_factory() as db_session:
                    await update_task_workflow_state(
                        db_session,
                        task.task_id,
                        task.workflow_state.model_dump(mode="json"),
                    )
                    await db_session.commit()

                # Execute
                result = await self._workflow_engine.execute_workflow(
                    task,
                    workflow,
                    cancel_event=cancel_event,
                )

                # Resolve dependencies — every terminal transition may
                # unblock or pause dependent tasks, not just completion.
                if result.status in {
                    TaskStatus.COMPLETED,
                    TaskStatus.FAILED,
                    TaskStatus.CANCELLED,
                }:
                    if str(getattr(workflow, "lifecycle", "persistent")) == "ephemeral":
                        async with self._session_factory() as db_session:
                            await update_workflow(
                                db_session,
                                workflow.workflow_id,
                                updates={"archived_at": datetime.now(UTC)},
                            )
                            await db_session.commit()
                    await self.resolve_dependencies(result.task_id)

            except asyncio.CancelledError:
                logger.info(
                    "Task execution cancelled",
                    extra={"extra_data": {"task_id": task.task_id}},
                )
                async with self._session_factory() as db_session:
                    task_row = await get_task(db_session, task.task_id)
                    current_status = str(task_row.status) if task_row is not None else "failed"
                    step_run_status = {
                        "cancelled": "cancelled",
                        "paused": "paused",
                        "queued": "failed",
                        "running": "failed",
                    }.get(current_status, "failed")
                    await fail_running_step_runs_for_task(
                        db_session,
                        task.task_id,
                        datetime.now(UTC),
                        final_status=step_run_status,
                    )
                    await db_session.commit()
            except Exception:
                logger.exception(
                    "Task execution failed",
                    extra={"extra_data": {"task_id": task.task_id}},
                )
                async with self._session_factory() as db_session:
                    await update_task_status(
                        db_session,
                        task.task_id,
                        "failed",
                        completed_at=datetime.now(UTC),
                    )
                    await db_session.commit()
            finally:
                self._active_runs.pop(task.task_id, None)
                self._run_controls.pop(task.task_id, None)
                # Update queue depth metric
                async with self._session_factory() as db_session:
                    queued = await list_tasks_by_status(db_session, ["queued", "ready"])
                QUEUE_DEPTH.labels(queue="default").set(len(queued))

    async def _has_capacity(self, agent_id: str | None = None) -> bool:
        """Check if there's capacity to run another step.

        Enforces both global and per-agent limits.
        """
        async with self._session_factory() as db_session:
            active_global = await count_active_steps(db_session)
            if active_global >= self._max_active_global:
                return False
            if agent_id is not None:
                active_for_agent = await count_active_steps(db_session, agent_id=agent_id)
                if active_for_agent >= self._max_active_per_agent:
                    return False
        return True

    async def _try_transition_to_ready(self, task_id: str) -> bool:
        """Try to transition a queued task to ready if all deps are met."""
        async with self._session_factory() as db_session:
            unmet = await get_unmet_dependencies(db_session, task_id)
            if not unmet:
                ok = await update_task_status(db_session, task_id, "ready")
                await db_session.commit()
                if ok:
                    TASKS_TOTAL.labels(status="ready").inc()
                    return True
            await db_session.commit()
        return False

    def _launch_task_run(self, task: TaskModel) -> None:
        """Start or restart a task execution coroutine."""
        if task.task_id in self._active_runs and not self._active_runs[task.task_id].done():
            return
        self._run_controls[task.task_id] = asyncio.Event()
        run_task = asyncio.create_task(self._run_task(task))
        self._active_runs[task.task_id] = run_task

    def _get_pending_interaction(self, task_id: str) -> Any:
        """Return a pending gate or step-input pause for a task."""
        pause_waiter = self._workflow_engine._pause_waiter  # noqa: SLF001
        return pause_waiter.find_pending(task_id=task_id)

    def _build_cancel_resolution(self, pause_type: str) -> PauseResolution:  # noqa: ARG002
        """Build a cancellation resolution for a pending pause.

        ``pause_type`` is accepted for future differentiation (e.g. gates
        vs step-input requests may warrant different resolution payloads).
        """
        return PauseResolution(decision="cancel", data={"response": ""})

    @property
    def active_run_count(self) -> int:
        """Return the number of actively executing tasks."""
        return len(self._active_runs)

    def has_active_run(self, task_id: str) -> bool:
        """Return True when the task currently has a running coroutine."""
        run_task = self._active_runs.get(task_id)
        return run_task is not None and not run_task.done()


def _row_to_task_model(row: Any) -> TaskModel:
    """Convert a DB Task row to a TaskModel."""
    return TaskModel(
        task_id=row.task_id,
        title=row.title,
        description=row.description or "",
        expected_output=getattr(row, "expected_output", None),
        status=TaskStatus(row.status),
        priority=row.priority,
        created_by=row.created_by,
        agent_id=row.agent_id,
        source_type=row.source_type,
        source_ref=row.source_ref,
        delivery=TaskDelivery(
            mode=row.delivery_mode,
            target=row.delivery_target,
        ),
        completion_delivery=CompletionDeliveryPolicy(
            completion_mode_family=getattr(row, "completion_mode_family", "default"),
            allow_silent_completion=bool(getattr(row, "allow_silent_completion", False)),
        ),
        interaction_mode_override=getattr(row, "interaction_mode_override", None),
        workflow_id=row.workflow_id,
        project_id=getattr(row, "project_id", None),
        attempt_number=getattr(row, "attempt_number", 1),
        workspace_root=getattr(row, "workspace_root", None),
        working_directory=getattr(row, "working_directory", None),
        workflow_state=(
            WorkflowState.model_validate(row.workflow_state) if row.workflow_state else None
        ),
        queue_name=row.queue_name,
        scheduled_for=row.scheduled_for,
        created_at=row.created_at,
        started_at=row.started_at,
        completed_at=row.completed_at,
        result_summary=row.result_summary,
        result_data=row.result_data,
        applied_completion_mode=getattr(row, "applied_completion_mode", None),
        applied_completion_reason=getattr(row, "applied_completion_reason", None),
    )
