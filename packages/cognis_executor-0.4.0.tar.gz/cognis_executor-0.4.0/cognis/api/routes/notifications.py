"""Unified notification endpoints for escalations, gates, and step questions."""

from __future__ import annotations

import re

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from cognis.api.common import require_current_user
from cognis.api.models import CredentialUpsertRequest
from cognis.core.notification_resolution import build_auth_challenge_resolution_data
from cognis.core.notifications import Notification, NotificationService

router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])


def _parse_credential_response(kind: str, response: str) -> dict[str, str]:
    text = response.strip()
    if not text:
        raise ValueError("Credential response is empty")
    normalized_kind = kind.strip().lower()
    if normalized_kind == "token":
        keyed = re.match(r"^token\s*:\s*(.+)$", text, re.IGNORECASE | re.DOTALL)
        return {"token": keyed.group(1).strip()} if keyed else {"token": text}
    if normalized_kind != "username_password":
        raise ValueError(f"Natural response parsing not implemented for credential kind: {kind}")

    keyed_values: dict[str, str] = {}
    for line in text.splitlines():
        match = re.match(r"^(username|email|password)\s*:\s*(.+)$", line.strip(), re.IGNORECASE)
        if match:
            field = "username" if match.group(1).lower() in {"username", "email"} else "password"
            keyed_values[field] = match.group(2).strip()
    if {"username", "password"}.issubset(keyed_values):
        return {"username": keyed_values["username"], "password": keyed_values["password"]}

    non_empty_lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(non_empty_lines) == 2:
        return {"username": non_empty_lines[0], "password": non_empty_lines[1]}

    if ":" in text:
        username, password = text.split(":", 1)
        if username.strip() and password.strip():
            return {"username": username.strip(), "password": password.strip()}

    raise ValueError(
        "Provide credentials as username:password, two lines, or username/password keyed lines"
    )


class NotificationResponse(BaseModel):
    """API response for a notification."""

    notification_id: str
    notification_type: str
    conversation_id: str
    task_id: str | None = None
    step_name: str | None = None
    step_run_id: str | None = None
    session_id: str | None = None
    payload: dict = {}
    status: str = "pending"
    resolution: dict | None = None
    created_at: str | None = None
    resolved_at: str | None = None


class ResolveRequest(BaseModel):
    """Request body for resolving any notification type."""

    decision: str
    note: str | None = None
    response: str | None = None
    feedback: str | None = None
    response_payload: dict[str, object] | None = None
    credential: CredentialUpsertRequest | None = None


def _to_response(n: Notification) -> NotificationResponse:
    return NotificationResponse(
        notification_id=n.notification_id,
        notification_type=n.notification_type,
        conversation_id=n.conversation_id,
        task_id=n.task_id,
        step_name=n.step_name,
        step_run_id=n.step_run_id,
        session_id=n.session_id,
        payload=n.payload,
        status=n.status,
        resolution=n.resolution,
        created_at=n.created_at.isoformat() if n.created_at else None,
        resolved_at=n.resolved_at.isoformat() if n.resolved_at else None,
    )


def _get_service(request: Request) -> NotificationService:
    svc: NotificationService | None = getattr(request.app.state, "notification_service", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Notification service not available")
    return svc


@router.get("", response_model=list[NotificationResponse])
async def list_notifications(
    request: Request,
    conversation_id: str | None = None,
    task_id: str | None = None,
    session_id: str | None = None,
) -> list[NotificationResponse]:
    """List pending notifications for the current user."""
    user = require_current_user(request)
    svc = _get_service(request)
    notifications = await svc.list_pending(
        user.email,
        conversation_id=conversation_id,
        task_id=task_id,
        session_id=session_id,
    )
    return [_to_response(n) for n in notifications]


@router.get("/{notification_id}", response_model=NotificationResponse)
async def get_notification(
    request: Request,
    notification_id: str,
) -> NotificationResponse:
    """Get a single notification by ID."""
    user = require_current_user(request)
    svc = _get_service(request)
    notification = await svc.get(notification_id)
    if notification is None or notification.user_email != user.email:
        raise HTTPException(status_code=404, detail="Notification not found")
    return _to_response(notification)


@router.post("/{notification_id}/resolve", response_model=dict)
async def resolve_notification(
    request: Request,
    notification_id: str,
    payload: ResolveRequest,
) -> dict[str, object]:
    """Resolve any notification type (escalation, gate, step question).

    For escalations: ``decision`` is ``approve`` or ``deny``, ``note`` is optional.
    For gates: ``decision`` is ``continue`` or ``cancel``, ``feedback`` is optional.
    For step questions: ``decision`` is ``continue``, ``response`` is the answer.
    """
    user = require_current_user(request)
    svc = _get_service(request)

    # Verify ownership before resolving
    notification = await svc.get(notification_id)
    if notification is None or notification.user_email != user.email:
        raise HTTPException(status_code=404, detail="Notification not found")

    if notification.notification_type == "step_question" and notification.task_id is None:
        pause = request.app.state.pause_waiter.get(notification_id)
        if pause is None or pause.pause_type != "step_question" or pause.task_id is not None:
            raise HTTPException(status_code=409, detail="Step question can no longer be resumed")

    if notification.notification_type == "credential_request":
        if payload.decision not in {"approve", "cancel", "deny"}:
            raise HTTPException(status_code=400, detail="Invalid credential request decision")
        if (
            payload.decision == "approve"
            and payload.credential is None
            and payload.response is None
        ):
            raise HTTPException(
                status_code=400,
                detail="Credential payload or response text required for approval",
            )
    if notification.notification_type == "auth_challenge" and payload.decision not in {
        "approve",
        "continue",
        "completed",
        "cancel",
        "deny",
    }:
        raise HTTPException(status_code=400, detail="Invalid auth challenge decision")

    # Build resolution data from the request
    data: dict[str, object] = {}
    if payload.note:
        data["note"] = payload.note
    if payload.response is not None:
        data["response"] = payload.response
    if payload.feedback:
        data["feedback"] = payload.feedback
    if payload.response_payload:
        data["response_payload"] = payload.response_payload

    if notification.notification_type == "credential_request" and payload.decision == "approve":
        requested = notification.payload if isinstance(notification.payload, dict) else {}
        credential_payload = payload.credential.payload if payload.credential is not None else None
        if credential_payload is None:
            try:
                credential_payload = _parse_credential_response(
                    str(requested.get("kind") or ""),
                    str(payload.response or ""),
                )
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        required_fields = requested.get("required_fields") if isinstance(requested, dict) else []
        if isinstance(required_fields, list):
            missing = [
                str(field)
                for field in required_fields
                if isinstance(field, str) and field not in credential_payload
            ]
            if missing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Credential approval is missing required fields: {', '.join(missing)}",
                )
        created = await request.app.state.providers.credentials.upsert_credential(
            credential_id=str(
                requested.get("credential_id")
                or (payload.credential.credential_id if payload.credential is not None else "")
            ),
            user_email=user.email,
            kind=str(
                requested.get("kind") or (payload.credential.kind if payload.credential else "")
            ),
            label=str(
                requested.get("label")
                or (payload.credential.label if payload.credential is not None else "")
            ),
            payload=credential_payload,
            metadata=(payload.credential.metadata if payload.credential is not None else {}),
            scope=str(requested.get("scope") or "user"),
            agent_id=(
                str(requested.get("agent_id")) if requested.get("agent_id") is not None else None
            ),
            description=(
                payload.credential.description if payload.credential is not None else None
            ),
            expires_at=(payload.credential.expires_at if payload.credential is not None else None),
        )
        data = {
            "credential_id": created.credential_id,
            "credential_label": created.label,
            "credential_kind": created.kind,
        }
    elif notification.notification_type == "auth_challenge":
        try:
            data = await build_auth_challenge_resolution_data(
                notification=notification,
                decision=payload.decision,
                user_email=user.email,
                credentials_provider=request.app.state.providers.credentials,
                response=payload.response,
                response_payload=payload.response_payload,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    ok = await svc.resolve(notification_id, payload.decision, data, user_email=user.email)
    if not ok:
        raise HTTPException(
            status_code=409,
            detail="Notification already resolved or not found",
        )
    return {"ok": True, "notification_id": notification_id, "decision": payload.decision}
