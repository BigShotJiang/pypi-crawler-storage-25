"""Concrete channel adapter implementations."""
