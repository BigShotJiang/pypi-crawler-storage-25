"""Model registration commands (BYOK)."""

from __future__ import annotations

from typing import Optional

import typer

from cloudagent_cli.client import CloudAgentClient, CloudAgentError
from cloudagent_cli.output import bail, print_detail, print_json, print_table

app = typer.Typer(no_args_is_help=True)

JSON_FLAG = typer.Option(False, "--json", "-j", help="Output raw JSON.")

MODEL_COLUMNS = ["id", "provider", "model_id", "display_name", "is_active", "created_at"]


def _client() -> CloudAgentClient:
    try:
        return CloudAgentClient()
    except CloudAgentError as e:
        bail(str(e))
        raise


@app.command("register")
def register_model(
    provider: str = typer.Option(..., "--provider", "-p", help="Provider name (e.g. anthropic, openai)."),
    model_id: str = typer.Option(..., "--model", "-m", help="Model identifier (e.g. claude-opus-4-6)."),
    api_key: str = typer.Option(..., "--api-key", "-k", help="Provider API key."),
    display_name: Optional[str] = typer.Option(None, "--display-name", "-n"),
    base_url: Optional[str] = typer.Option(None, "--base-url", "-u"),
    output_json: bool = JSON_FLAG,
) -> None:
    """Register a BYOK model."""
    client = _client()
    kwargs: dict = {
        "provider": provider,
        "model_id": model_id,
        "api_key": api_key,
    }
    if display_name:
        kwargs["display_name"] = display_name
    if base_url:
        kwargs["base_url"] = base_url
    try:
        data = client.register_model(**kwargs)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, MODEL_COLUMNS)


@app.command("list")
def list_models(
    output_json: bool = JSON_FLAG,
) -> None:
    """List registered models."""
    client = _client()
    try:
        data = client.list_models()
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), MODEL_COLUMNS)


@app.command("available")
def available_models(
    output_json: bool = JSON_FLAG,
) -> None:
    """Show all available models and their status."""
    client = _client()
    try:
        data = client.get_available_models()
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        cols = ["model_id", "provider", "display_name", "status", "source"]
        print_table(data.get("data", []), cols)
