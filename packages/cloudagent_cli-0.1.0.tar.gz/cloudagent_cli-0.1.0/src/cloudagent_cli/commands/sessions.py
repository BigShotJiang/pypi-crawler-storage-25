"""Session commands — create, list, get, send message, list events."""

from __future__ import annotations

import time
from typing import Optional

import typer

from cloudagent_cli.client import CloudAgentClient, CloudAgentError
from cloudagent_cli.output import bail, console, print_detail, print_json, print_table

app = typer.Typer(no_args_is_help=True)

JSON_FLAG = typer.Option(False, "--json", "-j", help="Output raw JSON.")

SESSION_COLUMNS = ["id", "agent_id", "status", "title", "created_at"]


def _client() -> CloudAgentClient:
    try:
        return CloudAgentClient()
    except CloudAgentError as e:
        bail(str(e))
        raise


@app.command("create")
def create_session(
    agent_id: str = typer.Option(..., "--agent", "-a", help="Agent ID."),
    environment_id: Optional[str] = typer.Option(None, "--environment", "-e", help="Environment ID."),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Session title."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Create a new session."""
    client = _client()
    kwargs: dict = {"agent_id": agent_id}
    if environment_id:
        kwargs["environment_id"] = environment_id
    if title:
        kwargs["title"] = title
    try:
        data = client.create_session(**kwargs)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, SESSION_COLUMNS)


@app.command("list")
def list_sessions(
    limit: int = typer.Option(20, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List sessions."""
    client = _client()
    try:
        data = client.list_sessions(limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), SESSION_COLUMNS)


@app.command("get")
def get_session(
    session_id: str = typer.Argument(..., help="Session ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Get session details."""
    client = _client()
    try:
        data = client.get_session(session_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data)


@app.command("send")
def send_message(
    session_id: str = typer.Argument(..., help="Session ID."),
    message: str = typer.Argument(..., help="Message text to send."),
    timeout: int = typer.Option(120, "--timeout", help="Seconds to wait for agent reply."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Send a message and wait for the agent response."""
    client = _client()

    # Build the user.message event
    event = {
        "type": "user.message",
        "content": [{"type": "text", "text": message}],
    }
    console.print("[dim]Sending message...[/dim]")
    try:
        client.send_events(session_id, [event])
    except CloudAgentError as e:
        bail(str(e))
        return

    console.print("[dim]Waiting for agent response...[/dim]")

    # Poll for agent.message
    deadline = time.time() + timeout
    seen_ids: set[str] = set()
    agent_reply: str | None = None

    while time.time() < deadline:
        try:
            events_data = client.list_events(session_id, limit=50)
        except CloudAgentError:
            time.sleep(2)
            continue

        for ev in events_data.get("data", []):
            ev_id = ev.get("id", "")
            if ev_id in seen_ids:
                continue
            seen_ids.add(ev_id)
            if ev.get("type") == "agent.message":
                # Extract text from content blocks
                parts = []
                for block in ev.get("content", []):
                    if isinstance(block, dict) and block.get("type") == "text":
                        parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        parts.append(block)
                agent_reply = "\n".join(parts)

        if agent_reply is not None:
            break
        time.sleep(2)

    if output_json:
        print_json({"reply": agent_reply})
    elif agent_reply is not None:
        console.print(f"\n[bold]Agent:[/bold] {agent_reply}")
    else:
        console.print("[yellow]Agent is still processing. Check back later with `cloudagent sessions events`.[/yellow]")


@app.command("events")
def list_events(
    session_id: str = typer.Argument(..., help="Session ID."),
    limit: int = typer.Option(50, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List events for a session."""
    client = _client()
    try:
        data = client.list_events(session_id, limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        cols = ["id", "type", "processed_at"]
        print_table(data.get("data", []), cols)
