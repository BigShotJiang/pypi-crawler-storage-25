"""Tests for `keel task add`."""

import json

from typer.testing import CliRunner

from keel.app import app
from keel.manifest import load_milestones_manifest

runner = CliRunner()


def _setup_milestone(proj):
    runner.invoke(app, ["milestone", "add", "m1", "--title", "Foundation"])


def test_add_creates_first_task(projects, make_project, monkeypatch) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    _setup_milestone(proj)
    result = runner.invoke(
        app,
        ["task", "add", "t1", "--milestone", "m1", "--title", "Set up"],
        catch_exceptions=False,
    )
    assert result.exit_code == 0, result.stderr
    m = load_milestones_manifest(proj / "milestones.toml")
    assert len(m.tasks) == 1
    assert m.tasks[0].id == "t1"
    assert m.tasks[0].milestone == "m1"
    assert m.tasks[0].status == "planned"
    assert m.tasks[0].depends_on == []


def test_add_with_dependencies(projects, make_project, monkeypatch) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    _setup_milestone(proj)
    runner.invoke(app, ["task", "add", "t1", "--milestone", "m1", "--title", "First"])
    result = runner.invoke(
        app,
        [
            "task",
            "add",
            "t2",
            "--milestone",
            "m1",
            "--title",
            "Second",
            "--depends-on",
            "t1",
        ],
        catch_exceptions=False,
    )
    assert result.exit_code == 0
    m = load_milestones_manifest(proj / "milestones.toml")
    t2 = next(t for t in m.tasks if t.id == "t2")
    assert t2.depends_on == ["t1"]


def test_add_with_multiple_dependencies(projects, make_project, monkeypatch) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    _setup_milestone(proj)
    runner.invoke(app, ["task", "add", "t1", "--milestone", "m1", "--title", "a"])
    runner.invoke(app, ["task", "add", "t2", "--milestone", "m1", "--title", "b"])
    result = runner.invoke(
        app,
        [
            "task",
            "add",
            "t3",
            "--milestone",
            "m1",
            "--title",
            "c",
            "--depends-on",
            "t1,t2",
        ],
    )
    assert result.exit_code == 0
    m = load_milestones_manifest(proj / "milestones.toml")
    t3 = next(t for t in m.tasks if t.id == "t3")
    assert sorted(t3.depends_on) == ["t1", "t2"]


def test_add_unknown_milestone_fails(projects, make_project, monkeypatch) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    result = runner.invoke(
        app,
        ["task", "add", "t1", "--milestone", "ghost", "--title", "x"],
    )
    assert result.exit_code == 1
    assert "milestone" in result.stderr.lower()


def test_add_unknown_dependency_fails(projects, make_project, monkeypatch) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    _setup_milestone(proj)
    result = runner.invoke(
        app,
        [
            "task",
            "add",
            "t1",
            "--milestone",
            "m1",
            "--title",
            "x",
            "--depends-on",
            "nonexistent",
        ],
    )
    assert result.exit_code == 1


def test_add_rejects_cycle_in_existing_manifest(projects, make_project, monkeypatch) -> None:
    """Adding a task fails if the loaded manifest already contains a cycle (DAG validation runs on save)."""
    import tomlkit

    proj = make_project("foo")
    monkeypatch.chdir(proj)
    runner.invoke(app, ["milestone", "add", "m1", "--title", "M1"])
    runner.invoke(app, ["task", "add", "t1", "--milestone", "m1", "--title", "a"])
    runner.invoke(
        app, ["task", "add", "t2", "--milestone", "m1", "--title", "b", "--depends-on", "t1"]
    )
    # Inject a cycle: t1 depends on t2
    mp = proj / "milestones.toml"
    doc = tomlkit.parse(mp.read_text())
    for t in doc["tasks"]:
        if t["id"] == "t1":
            t["depends_on"] = ["t2"]
    mp.write_text(tomlkit.dumps(doc))

    # Now adding any new task triggers validate_dag and exits 1
    result = runner.invoke(app, ["task", "add", "t3", "--milestone", "m1", "--title", "c"])
    assert result.exit_code == 1
    assert "cycle" in result.stderr.lower()


def test_add_duplicate_id_rejected(projects, make_project, monkeypatch) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    _setup_milestone(proj)
    runner.invoke(app, ["task", "add", "t1", "--milestone", "m1", "--title", "First"])
    result = runner.invoke(
        app,
        ["task", "add", "t1", "--milestone", "m1", "--title", "Second"],
    )
    assert result.exit_code == 1


def test_add_json(projects, make_project, monkeypatch) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    _setup_milestone(proj)
    result = runner.invoke(
        app,
        ["task", "add", "t1", "--milestone", "m1", "--title", "Set up", "--json"],
    )
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["id"] == "t1"
    assert data["milestone"] == "m1"
    assert data["status"] == "planned"


def test_add_dry_run_writes_nothing(projects, make_project, monkeypatch) -> None:
    """Dry-run validates but does not write to manifest."""
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    _setup_milestone(proj)

    # Capture pre-state
    mp = proj / "milestones.toml"
    pre_text = mp.read_text() if mp.exists() else None

    result = runner.invoke(
        app, ["task", "add", "t1", "--milestone", "m1", "--title", "Set up", "--dry-run"]
    )
    assert result.exit_code == 0
    # Confirm state unchanged
    post_text = mp.read_text() if mp.exists() else None
    assert pre_text == post_text


def test_task_add_without_milestone_creates_default(projects, make_project, monkeypatch) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    result = runner.invoke(app, ["task", "add", "t1", "--title", "Set up"], catch_exceptions=False)
    assert result.exit_code == 0
    from keel.api import load_milestones_manifest

    m = load_milestones_manifest(proj / "milestones.toml")
    assert any(ms.id == "default" for ms in m.milestones)
    t1 = next(t for t in m.tasks if t.id == "t1")
    assert t1.milestone == "default"


def test_task_add_default_milestone_singleton(projects, make_project, monkeypatch) -> None:
    """Multiple --milestone-less adds reuse the same default milestone."""
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    runner.invoke(app, ["task", "add", "t1", "--title", "First"])
    runner.invoke(app, ["task", "add", "t2", "--title", "Second"])
    from keel.api import load_milestones_manifest

    m = load_milestones_manifest(proj / "milestones.toml")
    defaults = [ms for ms in m.milestones if ms.id == "default"]
    assert len(defaults) == 1


def test_task_add_with_milestone_does_not_create_default(
    projects, make_project, monkeypatch
) -> None:
    proj = make_project("foo")
    monkeypatch.chdir(proj)
    runner.invoke(app, ["milestone", "add", "m1", "--title", "Foundation"])
    runner.invoke(app, ["task", "add", "t1", "--milestone", "m1", "--title", "Set up"])
    from keel.api import load_milestones_manifest

    m = load_milestones_manifest(proj / "milestones.toml")
    ids = {ms.id for ms in m.milestones}
    assert "default" not in ids
    assert "m1" in ids
