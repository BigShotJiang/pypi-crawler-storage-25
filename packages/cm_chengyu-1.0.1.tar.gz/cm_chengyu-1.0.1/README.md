# cm_chengyu 四字成语工具库

一个简单好用的 Python 四字成语工具库，收录 **29502** 个四字成语。

## 安装

```
pip install cm_chengyu
```

## 使用方法

### 判断是否是成语

```python
from cm_chengyu import is_chengyu

print(is_chengyu('守株待兔'))  # True
print(is_chengyu('你好世界'))  # False
```

### 随机抽取一个成语

```python
from cm_chengyu import random_chengyu

print(random_chengyu())  # 随机输出一个四字成语
```

### 其他功能

```python
from cm_chengyu import all_chengyu, count

print(count())          # 29502（成语总数）
cylist = all_chengyu()  # 获取所有成语的列表
```

## 数据来源

成语数据来自开源项目 [chinese-xinhua](https://github.com/pwxcoo/chinese-xinhua)，经筛选仅保留四字成语。
