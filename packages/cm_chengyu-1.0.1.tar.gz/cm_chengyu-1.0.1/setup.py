from setuptools import setup, find_packages

setup(
    name='cm_chengyu',
    version='1.0.1',
    author='Chen Mo',           # 作者名字
    author_email='chenmoemail@126.com',  # 作者邮箱
    description='计算概论C课程四字成语工具库：判断成语、随机抽取，收录 29502 个四字成语',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    url='',                       # ← 可选：填你的 GitHub 地址
    packages=find_packages(),
    package_data={
        'cm_chengyu': ['data/idioms.json'],
    },
    python_requires='>=3.6',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Natural Language :: Chinese (Simplified)',
    ],
)
