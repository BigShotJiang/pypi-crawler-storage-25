"""Pure utility functions."""
