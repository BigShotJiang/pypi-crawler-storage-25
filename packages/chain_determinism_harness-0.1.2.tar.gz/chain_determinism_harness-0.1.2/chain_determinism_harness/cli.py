"""CLI entry point for chain-determinism-harness.

Usage::

    python -m chain_determinism_harness eval --model X [--n-queries N] [--n-replays K]
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path

from .client import _scrub_secrets, make_client, run_query
from .metrics import chain_divergence_rate, format_summary, seq_full
from .queries import QUERIES
from .tools import SYSTEM_PROMPT, TOOL_SCHEMAS_OPENAI, stub_tool_response

# Output paths must end in one of these suffixes if the target already exists.
# Prevents accidental overwrite of `~/.bashrc`, `~/.zshrc`, repo `.env`, etc.
# when the harness is invoked from CI with attacker-influenced flags.
#  denylist-only
# was insufficient — `--out ~/.bashrc` resolves outside denied prefixes.
_ALLOWED_OUT_SUFFIXES = (".json", ".jsonl", ".ndjson", ".txt", ".log")


def _check_credentials(base_url: str | None) -> None:
    """Verify a usable API key is set.

    Note: ANTHROPIC_API_KEY is intentionally NOT considered — Anthropic keys
    are not OpenAI-compatible and forwarding them to an OpenAI-compatible
    endpoint would leak the credential. (This matches `client._resolve_api_key`.)

    If `base_url` is set (custom local / pinned-provider), allow the key check
    to pass even if no env keys are set; the caller may have configured the
    endpoint with no-auth or an embedded credential.
    """
    # Empty-string env vars are NOT a valid key — strip and require non-empty.
    has_openai = bool((os.environ.get("OPENAI_API_KEY") or "").strip())
    has_openrouter = bool((os.environ.get("OPENROUTER_API_KEY") or "").strip())
    if has_openai or has_openrouter:
        return
    if base_url:
        # Custom endpoint: caller's responsibility to ensure auth is correct
        # (e.g., local vLLM with no auth, or proxy injecting headers).
        print(
            "WARNING: --base-url is set but no OPENAI_API_KEY or OPENROUTER_API_KEY "
            "found. Continuing under the assumption the custom endpoint accepts "
            "the configuration.", file=sys.stderr,
        )
        return
    print("ERROR: no API key found. Set one of:", file=sys.stderr)
    print("    OPENAI_API_KEY=sk-...   (default)", file=sys.stderr)
    print("    OPENROUTER_API_KEY=sk-or-...   (for OpenRouter-routed models)", file=sys.stderr)
    print("(ANTHROPIC_API_KEY is not used by this harness — Anthropic keys are "
          "not OpenAI-compatible.)", file=sys.stderr)
    sys.exit(2)


def _validate_out_path(p: str | None, *, label: str) -> Path | None:
    """Validate an output path: resolve, refuse `..`-traversal, refuse writes
    to common system locations.

    The harness is meant to be runnable in CI / wrapped scripts; this guard
    is defense-in-depth, not a security boundary by itself.
    """
    if p is None:
        return None
    path = Path(p).expanduser()
    # Resolve to absolute; reject if `..` survives normalization (cross-fs)
    try:
        resolved = path.resolve()
    except (OSError, RuntimeError) as e:
        raise SystemExit(f"ERROR: invalid {label} path {p!r}: {e}") from None
    forbidden_prefixes = ("/etc", "/usr", "/sbin", "/bin", "/boot", "/sys", "/proc")
    s = str(resolved)
    for prefix in forbidden_prefixes:
        if s.startswith(prefix + "/") or s == prefix:
            raise SystemExit(
                f"ERROR: refusing to write {label} to system path {s!r}. "
                f"Use a path under your home directory or a tmpdir."
            )
    # Round-5 security review (cross-validated): block accidental overwrite
    # of dotfiles / config files. If the target already exists and its suffix
    # is not one we expect a harness output to use, refuse.
    if resolved.exists() and resolved.is_file():
        if resolved.suffix.lower() not in _ALLOWED_OUT_SUFFIXES:
            raise SystemExit(
                f"ERROR: refusing to overwrite existing non-output file "
                f"{label}={s!r} (suffix {resolved.suffix!r} not in "
                f"{_ALLOWED_OUT_SUFFIXES}). Pass an explicit .json/.jsonl path."
            )
    # Also block if the basename starts with `.` and the file does not yet exist
    # (e.g., `--out ~/.bashrc` when the file is somehow absent on first write).
    if resolved.name.startswith("."):
        raise SystemExit(
            f"ERROR: refusing to write {label} to dotfile path {s!r}. "
            f"Pass a path whose basename does not begin with '.'."
        )
    return resolved


async def _eval_async(args) -> dict:
    queries = QUERIES[: args.n_queries]
    print("==> chain-determinism-harness eval")
    print(f"    model:       {args.model}")
    print(f"    queries:     {len(queries)}  (out of {len(QUERIES)} embedded)")
    print(f"    replays:     {args.n_replays} per query")
    print(f"    total calls: {len(queries) * args.n_replays}")
    print(f"    temperature: {args.temperature}")
    print(f"    concurrency: {args.concurrency}")
    print(f"    base_url:    {args.base_url or '(default — OpenAI or OpenRouter via env)'}")
    print()

    client = make_client(base_url=args.base_url, timeout=args.timeout)

    t0 = time.time()
    all_runs: list[dict] = []
    n_err_total = 0
    for i, q in enumerate(queries, 1):
        print(f"  [{i}/{len(queries)}] {q['query_id'][:80]}", flush=True)
        runs = await run_query(
            client, args.model, q,
            n_replays=args.n_replays,
            temperature=args.temperature,
            system_prompt=SYSTEM_PROMPT,
            tools=TOOL_SCHEMAS_OPENAI,
            stub_tool_response=stub_tool_response,
            concurrency=args.concurrency,
        )
        all_runs.extend(runs)
        n_err = sum(1 for r in runs if r.get("error_category"))
        n_ok = len(runs) - n_err
        n_err_total += n_err
        # Use the canonical seq_full from metrics.py — same key the chain-divergence
        # rate is computed against — so the unique_sequences number matches what
        # downstream analysis sees. The earlier inline json.dumps + sort_keys was
        # NOT byte-for-byte identical to seq_full's canonical form (round-1 review
        # finding: hostile reviewer would notice the mismatch).
        ok_runs = [r for r in runs if not r.get("error_category")]
        unique_seqs = len({seq_full(r.get("tool_call_sequence") or []) for r in ok_runs})
        print(f"      ok={n_ok}/{len(runs)}  unique_sequences={unique_seqs}")

    elapsed = time.time() - t0
    print(f"\n  elapsed: {elapsed:.1f}s")

    stats = chain_divergence_rate(all_runs)
    print(format_summary(stats, args.model))

    out = {
        "model": args.model,
        "n_queries": len(queries),
        "n_replays": args.n_replays,
        "temperature": args.temperature,
        "elapsed_s": elapsed,
        "harness_version": "0.1.0",
        "base_url": args.base_url or None,
        # Wilson 95% CI is a 2-tuple of floats; convert to JSON-friendly form
        **stats,
    }
    if args.out:
        out_path = _validate_out_path(args.out, label="--out")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w") as f:
            json.dump(out, f, indent=2, default=str)
        print(f"  wrote: {out_path}")

    # Per-replay rows are independent of `--out`. Round-1 review finding:
    # earlier `--runs-out` was nested under `if args.out:`, so requesting only
    # per-replay output silently produced no file.
    if args.runs_out:
        runs_path = _validate_out_path(args.runs_out, label="--runs-out")
        runs_path.parent.mkdir(parents=True, exist_ok=True)
        with runs_path.open("w") as f:
            for r in all_runs:
                f.write(json.dumps(r, default=str) + "\n")
        print(f"  wrote per-replay: {runs_path}")

    out["_n_errors"] = n_err_total
    return out


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="chain-determinism-harness",
        description="Measure chain-determinism for any OpenAI-compatible LLM endpoint.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    e = sub.add_parser("eval", help="Run chain-divergence measurement")
    e.add_argument("--model", required=True,
                   help="Model identifier (e.g., gpt-4.1, qwen/qwen-2.5-72b-instruct)")
    e.add_argument("--n-queries", type=int, default=5,
                   help="Number of held-out queries to use (max 10 embedded; default 5)")
    e.add_argument("--n-replays", type=int, default=10,
                   help="Replays per query (default 10; minimum 2 to detect divergence)")
    e.add_argument("--temperature", type=float, default=0.0,
                   help="Sampling temperature in [0.0, 2.0] (default 0.0)")
    e.add_argument("--concurrency", type=int, default=5,
                   help="Max concurrent replay calls (default 5)")
    e.add_argument("--base-url", default=None,
                   help="API base URL. If unset, auto-detect from OPENAI_API_KEY / OPENROUTER_API_KEY.")
    e.add_argument("--timeout", type=float, default=60.0,
                   help="Per-request timeout in seconds (default 60)")
    e.add_argument("--out", default=None,
                   help="Write summary JSON to this path")
    e.add_argument("--runs-out", default=None,
                   help="Write per-replay JSONL to this path (independent of --out)")
    args = parser.parse_args(argv)

    if args.cmd == "eval":
        # Numeric validations (round-1 review: prior CLI accepted invalid numerics)
        if args.n_queries <= 0 or args.n_queries > len(QUERIES):
            print(f"ERROR: --n-queries must be in [1, {len(QUERIES)}], got {args.n_queries}",
                  file=sys.stderr)
            sys.exit(2)
        if args.n_replays < 2:
            print(f"ERROR: --n-replays must be >= 2 to detect divergence, got {args.n_replays}",
                  file=sys.stderr)
            sys.exit(2)
        if args.concurrency <= 0:
            print(f"ERROR: --concurrency must be > 0, got {args.concurrency}",
                  file=sys.stderr)
            sys.exit(2)
        if args.timeout <= 0:
            print(f"ERROR: --timeout must be > 0, got {args.timeout}",
                  file=sys.stderr)
            sys.exit(2)
        if not (0.0 <= args.temperature <= 2.0):
            print(f"ERROR: --temperature must be in [0.0, 2.0], got {args.temperature}",
                  file=sys.stderr)
            sys.exit(2)
        _check_credentials(args.base_url)
        # Round-5 security review (Scenario 1, cross-validated): unredacted
        # exception text could reach stderr / CI logs containing API keys
        # echoed by misbehaving providers in error bodies. Wrap the async
        # entry point so any escaping exception is scrubbed before emission.
        try:
            result = asyncio.run(_eval_async(args))
        except SystemExit:
            raise
        except KeyboardInterrupt:
            print("ERROR: interrupted", file=sys.stderr)
            sys.exit(130)
        except Exception as e:  # noqa: BLE001  (top-level last-resort sink)
            scrubbed = _scrub_secrets(f"{type(e).__name__}: {e!s}")
            print(f"ERROR: {scrubbed}", file=sys.stderr)
            sys.exit(4)
        # Round-1 review: previously the process always exited 0 even on
        # all-error runs. Surface "everything errored" via a non-zero exit
        # so CI / paper-pipeline scripts can detect failure.
        if result.get("n_total", 0) > 0 and result.get("_n_errors", 0) >= result["n_total"]:
            print("ERROR: all replays errored; exiting non-zero", file=sys.stderr)
            sys.exit(3)


if __name__ == "__main__":
    main()
