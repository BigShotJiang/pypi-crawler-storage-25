from autofmri.models.factory import get_model

__all__ = ["get_model"]
