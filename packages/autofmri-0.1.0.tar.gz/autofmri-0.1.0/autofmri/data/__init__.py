from autofmri.data.base import BaseFMRIDataLoader
from autofmri.data.haxby import HaxbyDataLoader
from autofmri.data.hcp import (
    EmotionDataLoader,
    GamblingDataLoader,
    HCPDataLoader,
    LanguageDataLoader,
)
from autofmri.data.vkmc import VKMCDataLoader
from autofmri.data.gtzan import GTZANDataLoader

__all__ = [
    "BaseFMRIDataLoader",
    "HaxbyDataLoader",
    "HCPDataLoader",
    "EmotionDataLoader",
    "GamblingDataLoader",
    "LanguageDataLoader",
    "VKMCDataLoader",
    "GTZANDataLoader",
]
