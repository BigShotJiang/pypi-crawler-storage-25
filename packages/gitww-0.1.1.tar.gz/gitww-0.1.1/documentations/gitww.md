# gitww

`gitww` is an interactive git history heatmap and rewrite assistant.

It helps you inspect commit activity in a repository and preview or rewrite commit metadata in a controlled way.

## Requirements

- Python 3.11+
- Git
- A repository you are willing to rewrite

## Basic setup

Install dependencies with `uv`:

```bash
uv sync --extra dev
```

Start the interactive shell:

```bash
uv run gitww
```

You can also run the module directly:

```bash
python -m gitww
```

## Interactive shell

`gitww` uses the current directory as the repository, clears the terminal, prints a figlet welcome banner, shows a week-based heatmap for the current repository covering the last 365 days, and starts a readline-backed REPL.

When the shell starts, it prompts for the branch to use and defaults to the branch currently checked out in that directory.

### Supported commands

- `/info`: Show GitHub identity and current repository heatmap.
- `/suggest`: Preview and redistribute all commits.
- `/suggest <count>`: Redistribute the last `<count>` commits.
- `/clear`: Clear the screen and redraw the dashboard.
- `/help`: Show the help panel.
- `/quit`: Exit the shell.

### `/suggest`

- Prompts for a custom date range, defaulting to the last 365 days.
- Prompts you to select a redistribution strategy.
- Automatically handles chronological order by ensuring redistribution starts after the boundary commit.
- Shows a preview heatmap including non-modified commits.
- Prompts whether to run the rewrite, defaulting to No.

## Standalone rewrite CLI

The `gitww.git_witchcraft_wizardry` module rewrites commit metadata from an explicit JSON config file path provided with `--config`.

Required keys for the rewrite CLI:

- `repo`: Path to the local git repository.
- `begin_commit`: The first commit to rewrite.
- `end_commit`: The last commit to rewrite.
- `dates`: ISO 8601 timestamps, one for each commit in the inclusive range.

The rewrite CLI automatically resolves the commit range and applies the supplied timestamps in order.

### Examples

Rewrite an inclusive commit range with different dates:

```json
{
  "repo": "/path/to/repo",
  "begin_commit": "HEAD~1",
  "end_commit": "HEAD",
  "dates": [
    "2025-08-15T10:30:00+00:00",
    "2025-08-16T11:45:00+00:00"
  ]
}
```

Rewrite only selected refs:

```json
{
  "repo": "/path/to/repo",
  "begin_commit": "HEAD~1",
  "end_commit": "HEAD",
  "dates": [
    "2025-08-15T10:30:00+00:00",
    "2025-08-16T11:45:00+00:00"
  ],
  "refs": ["main", "feature-branch"]
}
```

Rewrite a revision range:

```json
{
  "repo": "/path/to/repo",
  "begin_commit": "HEAD~2",
  "end_commit": "HEAD",
  "dates": [
    "2025-08-15T10:30:00+00:00",
    "2025-08-16T11:45:00+00:00",
    "2025-08-17T09:00:00+00:00"
  ],
  "refs": ["HEAD~10..HEAD"]
}
```

Preview the generated filter without executing:

```bash
uv run python -m gitww.git_witchcraft_wizardry --config /path/to/rewrite.json --dry-run
```

## Redistribution strategies

When using `/suggest`, you can choose a strategy that controls the daily and weekly rhythm of commits:

- **natural**: Workday rhythm with burst/lull cycles and occasional off-hours commits.
- **burst**: Bursts of activity followed by lulls.
- **workday**: High activity on Mon-Fri, minimal on weekends.
- **nightowl**: Late-night developer pattern.
- **sprint**: Agile-style 2-week sprints.
- **chaotic**: Maximum randomness.

## Demo repository

A helper script creates a demo repository with dummy history for testing the wizard:

```bash
python3 scripts/setup_test_repo.py
python3 scripts/setup_test_repo.py --path ~/my-demo-repo
```

After running the setup script, you can immediately start `gitww` to experiment with the tool.

## Notes

- Rewriting history changes commit IDs.
- If the repository is shared, you will need to force-push rewritten refs.
- `git filter-branch` prints a warning because it is older and easier to misuse than `git filter-repo`.
- The script always writes the same `name` and `email` to both author and committer fields.
- The initial commit is supported as `begin_commit` or `end_commit`.
- `begin_commit` must be an ancestor of `end_commit`.
- The script resolves commits in path order from `begin_commit` to `end_commit`, both inclusive.

## Publishing

To prepare a release:

```bash
uv build
uv publish
```

### PyPI

1. Create an account on PyPI and generate an API token.
2. Build the distribution with `uv build`.
3. Publish with:

```bash
uv publish --token pypi-...YOUR_TOKEN...
```

Users can then install with:

```bash
uv tool install gitww
```

### Private package registry

1. Point `uv publish` at your registry's upload endpoint.
2. Use the registry-specific token or credentials.
3. Document the install index URL for your consumers.

Example:

```bash
uv publish --publish-url https://your-registry.example.com/legacy/ --token YOUR_TOKEN
```

For installs, consumers typically use the registry's simple index URL with `uv`.
