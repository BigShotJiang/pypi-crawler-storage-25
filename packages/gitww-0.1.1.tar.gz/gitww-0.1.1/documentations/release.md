---
description: Release and publish `gitww` to PyPI
---

# Release guide

This document explains how to prepare, build, and publish `gitww` to PyPI.

## Prerequisites

Before you publish a release, make sure:

- You have access to the PyPI project for `gitww`.
- Your environment has `uv` installed.
- The working tree is clean.
- `pyproject.toml` has the version you want to release.

The package is built with `hatchling` and exposes the `gitww` console script from `gitww.__main__:main`.

## Release checklist

1. Update the version in `pyproject.toml`.
2. Review the changelog or commit history for the release notes you want to announce.
3. Run the test suite.
4. Build the distribution artifacts.
5. Publish to PyPI.
6. Verify that the published package installs correctly.

## Local verification

Run the tests before creating a release:

```bash
uv run pytest
```

If you want to inspect the built artifacts locally, create them with:

```bash
uv build
```

This should generate a source distribution and wheel under `dist/`.

## Publish to PyPI

Authenticate with a PyPI API token, then publish the built artifacts:

```bash
uv publish --token pypi-...YOUR_TOKEN...
```

You can also let `uv` build and publish in one step if you prefer:

```bash
uv publish
```

Use the combined build-and-publish flow only when you are confident the version and metadata are correct.

## Test PyPI dry run

If you want to validate the release process before publishing to the real PyPI index, use Test PyPI:

```bash
uv publish --publish-url https://test.pypi.org/legacy/ --token pypi-...YOUR_TEST_PYPI_TOKEN...
```

After that, test the install from Test PyPI in a clean environment.

Test PyPI does not mirror third-party dependencies from the main PyPI index, so installs can fail if your package depends on libraries that were not also uploaded to Test PyPI. For `gitww`, install from Test PyPI while also allowing dependency resolution from the real PyPI index:

```bash
uv tool install gitww \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/
```

If you want to test a fully isolated index, you must upload every runtime dependency to Test PyPI as well.

## After publishing

After the release is published:

- Confirm the package page shows the new version.
- Install it in a fresh environment to confirm the `gitww` command works.
- Create and push a git tag for the release if that matches your release process.

Example verification install:

```bash
uv tool install gitww
```

## Notes

- Keep the version in `pyproject.toml` aligned with the published release.
- Do not commit API tokens or store them in the repository.
- If publishing fails, inspect the `uv` output first; it usually points to metadata or authentication issues.
