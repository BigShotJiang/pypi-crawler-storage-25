# gitww

`gitww` is an interactive git heatmap tooling assistant.

## Quick start

1. Open a git repository you want to inspect or rewrite.
2. Install `gitww` with `uv`:

```bash
uv tool install gitww
```

If you want to work from a local checkout instead, install the project dependencies:

```bash
uv sync --extra dev
```

3. Start the CLI from that repository root:

```bash
uv run gitww
```

The shell uses the current directory as the repository and prompts for the branch to use, defaulting to the branch currently checked out in that directory.

## Documentation

Detailed usage, configuration examples, strategies, and publishing notes are in:

[`documentations/gitww.md`](documentations/gitww.md)

Release instructions for publishing `gitww` to PyPI are in:

[`documentations/release.md`](documentations/release.md)
