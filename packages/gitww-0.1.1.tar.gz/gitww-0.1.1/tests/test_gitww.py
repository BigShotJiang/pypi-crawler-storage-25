import subprocess
from datetime import date, datetime
from pathlib import Path

import pytest

import gitww.git_witchcraft_wizardry as brgm
import gitww.config_loader as config_loader
import gitww.git_utils as git_utils
import gitww.strategies as strategies
import gitww.shell as shell
from gitww.models import AppConfig, Suggestion
from gitww.strategies import _redistribute_commits, DeepWorkStrategy
from gitww.shell import resolve_command_name


def test_load_dates_rejects_out_of_order_values() -> None:
    with pytest.raises(SystemExit, match="ascending time order"):
        brgm.load_dates(
            {
                "dates": [
                    "2025-01-02T10:00:00+00:00",
                    "2025-01-01T10:00:00+00:00",
                ]
            }
        )


def test_build_filter_script_contains_expected_mappings() -> None:
    script = brgm.build_filter_script(
        name="New Identity",
        email="new@example.com",
        commits=["aaa111", "bbb222"],
        dates=[
            "2025-01-01T09:00:00+00:00",
            "2025-01-02T10:30:00+00:00",
        ],
    )

    assert "export GIT_AUTHOR_NAME='New Identity'" in script
    assert "export GIT_AUTHOR_EMAIL='new@example.com'" in script
    assert "export GIT_COMMITTER_NAME='New Identity'" in script
    assert "export GIT_COMMITTER_EMAIL='new@example.com'" in script
    assert "    'aaa111') new_date='2025-01-01T09:00:00+00:00' ;;" in script
    assert "    'bbb222') new_date='2025-01-02T10:30:00+00:00' ;;" in script


def test_resolve_commit_range_returns_inclusive_commits(monkeypatch) -> None:
    repo = Path("/tmp/example-repo")

    def fake_run_git(_repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
        if args == ("rev-parse", "--verify", "HEAD~1^{commit}"):
            return subprocess.CompletedProcess(args, 0, stdout="aaa111\n", stderr="")
        if args == ("rev-parse", "--verify", "HEAD^{commit}"):
            return subprocess.CompletedProcess(args, 0, stdout="ccc333\n", stderr="")
        if args == ("merge-base", "--is-ancestor", "aaa111", "ccc333"):
            return subprocess.CompletedProcess(args, 0, stdout="", stderr="")
        if args == ("rev-list", "--reverse", "--ancestry-path", "aaa111..ccc333"):
            return subprocess.CompletedProcess(
                args, 0, stdout="bbb222\nccc333\n", stderr=""
            )
        raise AssertionError(f"Unexpected git args: {args}")

    monkeypatch.setattr(brgm, "run_git", fake_run_git)

    commits = brgm.resolve_commit_range(repo, "HEAD~1", "HEAD")

    assert commits == ["aaa111", "bbb222", "ccc333"]


def test_load_app_config_uses_cwd_and_prompts_for_branch(tmp_path, monkeypatch) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    monkeypatch.chdir(repo_path)

    run_git_results = iter(
        [
            subprocess.CompletedProcess(("git",), 0, stdout="true\n", stderr=""),
            subprocess.CompletedProcess(("git",), 0, stdout="main\n", stderr=""),
            subprocess.CompletedProcess(
                ("git",), 0, stdout="refs/heads/main\n", stderr=""
            ),
        ]
    )

    monkeypatch.setattr(
        config_loader, "run_git", lambda *args, **kwargs: next(run_git_results)
    )
    monkeypatch.setattr("builtins.input", lambda: "")

    config = config_loader.load_app_config()

    assert config == AppConfig(
        repo=repo_path.resolve(),
        branch="main",
    )


def test_get_global_git_config_required_exits_when_missing(monkeypatch, capsys) -> None:
    class Result:
        returncode = 1
        stdout = ""
        stderr = ""

    monkeypatch.setattr(git_utils.subprocess, "run", lambda *args, **kwargs: Result())

    with pytest.raises(SystemExit, match="1"):
        git_utils.get_global_git_config("user.name", required=True)

    captured = capsys.readouterr()
    assert "Global git config 'user.name' is missing." in captured.out


def test_ask_identity_preference_keeps_original_when_global_identity_missing(
    monkeypatch,
) -> None:
    monkeypatch.setattr(shell, "get_global_git_config", lambda *args, **kwargs: None)
    monkeypatch.setattr("builtins.input", lambda _prompt: "")

    keep_identity, name, email = shell.ask_identity_preference()

    assert keep_identity is True
    assert name is None
    assert email is None


def test_ask_identity_preference_defaults_to_keep_original_when_global_identity_exists(
    monkeypatch,
) -> None:
    monkeypatch.setattr(
        shell,
        "get_global_git_config",
        lambda key: "Ada Lovelace" if key == "user.name" else "ada@example.com",
    )
    monkeypatch.setattr("builtins.input", lambda _prompt: "")

    keep_identity, name, email = shell.ask_identity_preference()

    assert keep_identity is True
    assert name is None
    assert email is None


def test_ask_identity_preference_returns_none_when_user_quits(monkeypatch) -> None:
    monkeypatch.setattr(shell, "get_global_git_config", lambda *args, **kwargs: None)
    monkeypatch.setattr("builtins.input", lambda _prompt: "q")

    assert shell.ask_identity_preference() is None


def test_ask_identity_preference_reraises_keyboard_interrupt(monkeypatch) -> None:
    monkeypatch.setattr(shell, "get_global_git_config", lambda *args, **kwargs: None)

    def raise_keyboard_interrupt(_prompt: str) -> str:
        raise KeyboardInterrupt

    monkeypatch.setattr("builtins.input", raise_keyboard_interrupt)

    with pytest.raises(KeyboardInterrupt):
        shell.ask_identity_preference()


def test_do_suggest_aborts_before_rewrite_when_identity_prompt_is_cancelled(
    monkeypatch,
) -> None:
    shell_app = shell.GitWWShell(
        AppConfig(repo=Path("/tmp/example-repo"), branch="main")
    )

    class FakeService:
        def get_status(self) -> str:
            return ""

        def build_all_commits_suggestion(self, *args, **kwargs) -> Suggestion:
            return Suggestion(
                start_day=date(2025, 1, 1),
                end_day=date(2025, 1, 2),
                total_commits=1,
                commits=["c1"],
                suggested_datetimes=["2025-01-01T00:00:00+00:00"],
            )

        def merged_suggestion_counts(self, *args, **kwargs) -> dict[str, int]:
            return {"2025-01-01": 1}

        def run_rewrite(self, *args, **kwargs) -> int:
            pytest.fail(
                "run_rewrite should not be called after cancelling identity preference"
            )

    shell_app.git_service = FakeService()
    shell_app.today = date(2025, 1, 2)
    shell_app.history_start = date(2025, 1, 1)

    monkeypatch.setattr(
        shell, "ask_date_range", lambda today: (date(2025, 1, 1), date(2025, 1, 2))
    )
    monkeypatch.setattr(shell, "ask_strategy", lambda allow_back=False: "fixed")
    monkeypatch.setattr(shell, "confirm", lambda prompt: True)
    monkeypatch.setattr(shell, "ask_identity_preference", lambda: None)
    monkeypatch.setattr(shell, "render_heatmap", lambda *args, **kwargs: "heatmap")
    monkeypatch.setattr(shell, "print_notice", lambda *args, **kwargs: None)

    shell_app.do_suggest("")


def test_redistribute_commits_uses_strategy_weights(monkeypatch) -> None:
    class FixedStrategy:
        def get_weights(self, total_days: int, start_day: date) -> list[float]:
            return [3.0, 1.0]

    commits = ["c1", "c2", "c3", "c4"]
    start_day = date(2025, 1, 1)
    end_day = date(2025, 1, 2)

    monkeypatch.setitem(strategies.STRATEGIES, "fixed", FixedStrategy)
    monkeypatch.setattr(strategies.random, "uniform", lambda *_args, **_kwargs: 0.0)

    scheduled = _redistribute_commits(commits, start_day, end_day, "fixed")

    assert len(scheduled) == 4
    assert scheduled == sorted(scheduled)

    scheduled_days = [datetime.fromisoformat(item).date() for item in scheduled]
    assert scheduled_days.count(start_day) == 3
    assert scheduled_days.count(end_day) == 1


def test_resolve_command_name_handles_aliases() -> None:
    assert resolve_command_name("/i") == "/info"
    assert resolve_command_name("/s") == "/suggest"
    assert resolve_command_name("/c") == "/clear"
    assert resolve_command_name("/h") == "/help"
    assert resolve_command_name("/q") == "/quit"

    assert resolve_command_name("/info") == "/info"
    assert resolve_command_name("/suggest") == "/suggest"

    assert resolve_command_name("/unknown") is None


def test_deep_work_strategy_generates_weights() -> None:
    strategy = DeepWorkStrategy()
    start_day = date(2025, 1, 1)
    weights = strategy.get_weights(total_days=10, start_day=start_day)

    assert len(weights) == 10
    assert any(w > 1.0 for w in weights)
    assert any(w < 0.2 for w in weights)
