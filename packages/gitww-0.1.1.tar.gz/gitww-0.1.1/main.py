#!/usr/bin/env python3
import sys

from gitww.__main__ import main


if __name__ == "__main__":
    sys.exit(main())
