#!/usr/bin/env python3
import os
import subprocess
import argparse
import shutil
from pathlib import Path
from datetime import datetime, timedelta


def run_cmd(cmd, cwd=None):
    """Run a shell command and capture output."""
    return subprocess.run(cmd, shell=True, check=True, cwd=cwd, capture_output=True)


def setup_demo_repo(repo_path: Path):
    """Create a demo git repository with a mix of old and recent commits."""
    if repo_path.exists():
        shutil.rmtree(repo_path)
    repo_path.mkdir(parents=True)

    run_cmd("git init", cwd=repo_path)
    run_cmd("git config user.name 'Wizard Tester'", cwd=repo_path)
    run_cmd("git config user.email 'wizard@example.com'", cwd=repo_path)

    # 1. Create 10 commits from ~2 years ago
    start_date_old = datetime.now() - timedelta(days=700)
    for i in range(10):
        commit_date = start_date_old + timedelta(days=i)
        date_str = commit_date.isoformat()
        file_path = repo_path / "history.txt"
        with open(file_path, "a") as f:
            f.write(f"Ancient wisdom: entry {i}\n")

        run_cmd("git add history.txt", cwd=repo_path)
        env = os.environ.copy()
        env["GIT_AUTHOR_DATE"] = date_str
        env["GIT_COMMITTER_DATE"] = date_str
        subprocess.run(
            f"git commit -m 'Ancient commit {i}'",
            shell=True,
            check=True,
            cwd=repo_path,
            env=env,
            capture_output=True,
        )

    # 2. Create 10 commits from the last 10 days
    start_date_recent = datetime.now() - timedelta(days=10)
    for i in range(10):
        commit_date = start_date_recent + timedelta(days=i)
        date_str = commit_date.isoformat()
        file_path = repo_path / "recent.txt"
        with open(file_path, "a") as f:
            f.write(f"Modern magic: spell {i}\n")

        run_cmd("git add recent.txt", cwd=repo_path)
        env = os.environ.copy()
        env["GIT_AUTHOR_DATE"] = date_str
        env["GIT_COMMITTER_DATE"] = date_str
        subprocess.run(
            f"git commit -m 'Recent commit {i}'",
            shell=True,
            check=True,
            cwd=repo_path,
            env=env,
            capture_output=True,
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Setup a demo repository for testing gitww."
    )
    parser.add_argument(
        "--path",
        type=str,
        default="/tmp/gitww_demo",
        help="Path where the demo repo will be created",
    )
    args = parser.parse_args()

    demo_path = Path(args.path).expanduser().resolve()
    setup_demo_repo(demo_path)

    print(f"✨ Demo repository created at: {demo_path}")
    print("\nNext steps:")
    print("1. Change into the demo repo directory.")
    print("2. Run the REPL: uv run gitww")
    print("3. Try commands like: /suggest or /suggest 5")
