import subprocess
import sys
from datetime import date, datetime, time, timezone, timedelta
from pathlib import Path
from collections import Counter


def run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        capture_output=True,
        check=True,
    )


def resolve_repo_path(raw_path: str) -> Path:
    repo = Path(raw_path).expanduser().resolve()
    try:
        run_git(repo, "rev-parse", "--is-inside-work-tree")
    except subprocess.CalledProcessError as exc:
        raise ValueError(f"Not a git repository: {repo}\n{exc.stderr.strip()}") from exc
    return repo


def git_log_date_counts(
    repo: Path, branch: str, start_day: date, end_day: date
) -> Counter[date]:
    since = datetime.combine(start_day, time.min, tzinfo=timezone.utc).isoformat()
    until = datetime.combine(end_day + timedelta(days=1), time.min, tzinfo=timezone.utc)
    result = run_git(
        repo,
        "log",
        branch,
        f"--since={since}",
        f"--until={until.isoformat()}",
        "--pretty=%cI",
    )

    counts: Counter[date] = Counter()
    for line in result.stdout.splitlines():
        text = line.strip()
        if not text:
            continue
        counts[datetime.fromisoformat(text).date()] += 1
    return counts


def get_global_git_config(key: str, required: bool = False) -> str | None:
    """Retrieve a global git configuration value."""
    try:
        # Using a dummy path for CWD since global config doesn't depend on the repo
        result = subprocess.run(
            ["git", "config", "--global", key],
            text=True,
            capture_output=True,
            check=False,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass

    if required:
        from .ui_utils import ERROR, RESET, BOLD

        print(f"\n{ERROR}{BOLD}✖  Global git config '{key}' is missing.{RESET}")
        print(
            f'   Please set it using: {BOLD}git config --global {key} "your value"{RESET}'
        )
        sys.exit(1)
    return None
