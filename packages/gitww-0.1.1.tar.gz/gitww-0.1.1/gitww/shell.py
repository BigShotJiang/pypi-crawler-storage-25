import cmd
import shlex
import json
import sys
import tempfile
import subprocess
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from collections import Counter

from .models import AppConfig, Suggestion
from .git_utils import git_log_date_counts, get_global_git_config
from .services import GitService
from .ui_utils import (
    RESET,
    DIM,
    MUTED,
    ACCENT,
    TITLE,
    box_lines,
    format_notice,
    print_notice,
    print_banner,
    print_repo_header,
    clear_screen,
    render_heatmap,
    confirm,
)
from .strategies import STRATEGIES

try:
    import readline
except ImportError:
    readline = None

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.application.current import get_app
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from prompt_toolkit.completion import WordCompleter
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.formatted_text import ANSI

    _PTK_AVAILABLE = True
except Exception:
    _PTK_AVAILABLE = False

_PROMPT_SESSION: "PromptSession[str] | None" = None
COMMANDS = ["/info", "/suggest", "/clear", "/help", "/quit"]
ALIASES = {
    "/i": "/info",
    "/s": "/suggest",
    "/c": "/clear",
    "/h": "/help",
    "/q": "/quit",
}
HISTORY_PATH = Path.home() / ".gitww_history"


def _build_toolbar() -> str:
    """Return a bottom-toolbar string showing commands that match the current input prefix."""
    if not _PTK_AVAILABLE:
        return ""
    try:
        text = get_app().current_buffer.text.strip()
    except Exception:
        return ""

    if not text:
        return ""

    if text == "/":
        matches = list(COMMANDS)
    elif text.startswith("/"):
        matches = [cmd for cmd in COMMANDS if cmd.startswith(text.split()[0])]
    else:
        return ""

    if not matches:
        return "  no command matches"

    lines = ["  commands:"]
    lines.extend(f"    {cmd}" for cmd in matches)
    return "\n".join(lines)


def _setup_prompt_session() -> None:
    global _PROMPT_SESSION
    if not _PTK_AVAILABLE or _PROMPT_SESSION is not None:
        return
    completer = WordCompleter(list(COMMANDS), ignore_case=True, sentence=True)
    _PROMPT_SESSION = PromptSession(
        history=FileHistory(str(HISTORY_PATH)),
        completer=completer,
        complete_while_typing=True,
        auto_suggest=AutoSuggestFromHistory(),
    )


def setup_readline() -> None:
    if readline is None:
        return

    # Keep "/" and "-" inside tokens so slash commands can complete.
    readline.set_completer_delims(" \t\n")
    try:
        readline.read_history_file(HISTORY_PATH)
    except (FileNotFoundError, OSError):
        pass


def save_readline_history() -> None:
    if readline is None:
        return
    try:
        readline.write_history_file(HISTORY_PATH)
    except OSError:
        pass


def ask_date_range(today: date) -> tuple[date, date]:
    while True:
        print(
            f"{MUTED}Date range{RESET} — enter days-before-today as "
            f"{ACCENT}start end{RESET}{MUTED}, e.g. {DIM}365 0{RESET}{MUTED} (default):{RESET} ",
            end="",
        )
        answer = input().strip()
        if not answer:
            return today - timedelta(days=364), today

        try:
            parts = answer.replace(",", " ").split()
            if len(parts) == 1:
                start_offset = int(parts[0])
                end_offset = 0
            elif len(parts) == 2:
                start_offset = int(parts[0])
                end_offset = int(parts[1])
            else:
                print_notice(
                    "Please enter one or two numbers (e.g., 365 or 365 0).", "warning"
                )
                continue

            if start_offset < end_offset:
                print_notice("Start offset must be >= end offset.", "warning")
                continue

            if start_offset <= 0:
                print_notice("Start offset must be positive.", "warning")
                continue

            start_day = today - timedelta(days=start_offset - 1)
            end_day = today - timedelta(days=end_offset)
            return start_day, end_day
        except ValueError:
            print_notice("Invalid input. Please enter numbers.", "warning")


def ask_identity_preference() -> tuple[bool, str | None, str | None] | None:
    """Ask user whether to keep original identity or use specified values.

    Returns:
        (keep_original, override_name, override_email)
    """
    target_name = get_global_git_config("user.name")
    target_email = get_global_git_config("user.email")

    has_global_identity = bool(target_name and target_email)

    print(f"\n{TITLE}Commit identity preference:{RESET}")
    if has_global_identity:
        print(
            f"  {ACCENT}1.{RESET} Set values to {ACCENT}{target_name} <{target_email}>{RESET}"
        )
    else:
        print(
            f"  {ACCENT}1.{RESET} Set values to your global git identity {DIM}(unavailable: configure user.name/user.email first){RESET}"
        )
    print(
        f"  {ACCENT}2.{RESET} Keep original author and committer names/emails {DIM}(default){RESET}"
    )
    print(f"  {ACCENT}3.{RESET} Quit without modifying metadata history")

    while True:
        try:
            default_choice = "2"
            prompt = (
                f"\n{MUTED}Choose option [1/2/3] (default: {default_choice}):{RESET} "
            )
            answer = input(prompt).strip()
            if not answer:
                return True, None, None
            if answer == "1" and has_global_identity:
                return False, target_name, target_email
            if answer == "2":
                return True, None, None
            if answer in {"3", "q", "quit"}:
                return None
            if answer == "1" and not has_global_identity:
                print_notice(
                    "Global git identity is not configured; choose option 2 to keep original identity.",
                    "warning",
                )
                continue
            print_notice("Please enter 1, 2, or 3.", "warning")
        except (ValueError, EOFError):
            print("")
            return True, None, None
        except KeyboardInterrupt:
            print("")
            raise


def ask_strategy(allow_back: bool = False) -> str | None:
    print(f"{TITLE}Choose a redistribution strategy:{RESET}")
    options = list(STRATEGIES.keys())
    for i, name in enumerate(options, 1):
        strategy = STRATEGIES[name]()
        print(f"  {ACCENT}{i}. {name}{RESET} - {DIM}{strategy.description}{RESET}")
    if allow_back:
        print(f"  {ACCENT}B.{RESET} Back to main REPL interface {DIM}(default){RESET}")
        print(f"  {ACCENT}Q.{RESET} Quit the REPL totally")

    while True:
        try:
            if allow_back:
                prompt = f"{MUTED}Select strategy [1-{len(options)}], B to go back, or Q to quit (default: B):{RESET} "
            else:
                prompt = (
                    f"{MUTED}Select strategy [1-{len(options)}] (default: 1):{RESET} "
                )
            answer = input(prompt).strip().lower()
            if not answer:
                return None if allow_back else options[0]
            if allow_back:
                if answer == "b":
                    return None
                if answer == "q":
                    return "QUIT"
            idx = int(answer) - 1
            if 0 <= idx < len(options):
                return options[idx]
            msg = f"Please enter a number between 1 and {len(options)}"
            if allow_back:
                msg += ", B, or Q"
            print_notice(f"{msg}.", "warning")
        except ValueError:
            msg = "Invalid input. Please enter a number"
            if allow_back:
                msg += ", B, or Q"
            print_notice(f"{msg}.", "warning")


def resolve_command_name(token: str) -> str | None:
    if token in ALIASES:
        return ALIASES[token]

    matches = [command for command in COMMANDS if command.startswith(token)]
    if len(matches) == 1:
        return matches[0]
    if not matches:
        return None

    print(f"Ambiguous command prefix: {token}")
    print("Matches:", ", ".join(matches))
    return ""


class GitWWShell(cmd.Cmd):
    def __init__(self, app_config: AppConfig) -> None:
        super().__init__(completekey="tab")
        self.app_config = app_config
        self.git_service = GitService(app_config.repo)
        self.today = datetime.now().date()
        self.history_start = self.today - timedelta(days=364)
        self.last_suggestion: Suggestion | None = None
        self.last_notice = format_notice(
            "Type /help to inspect commands, or /suggest to preview a 365-day redistribution."
        )
        self.pending_command: str | None = None

    @property
    def prompt(self) -> str:
        repo_name = self.app_config.repo.name or str(self.app_config.repo)
        return f"{ACCENT}{repo_name}{RESET} {DIM}gitww ›{RESET} "

    def render_dashboard(self) -> None:
        clear_screen()
        print_banner()
        print_repo_header(str(self.app_config.repo))
        try:
            counts = git_log_date_counts(
                self.app_config.repo,
                self.app_config.branch,
                self.history_start,
                self.today,
            )
            print(render_heatmap(counts, self.history_start, self.today))
        except subprocess.CalledProcessError as exc:
            message = exc.stderr.strip() or str(exc)
            print_notice(f"Failed to load git history: {message}", "error")
        print("")
        print(self.last_notice)
        if self.pending_command:
            print_notice(
                f"Pending: {self.pending_command}. Press Enter to confirm.", "info"
            )
        cmds = "  ".join(
            f"{ACCENT}{c}{RESET}"
            for c in ["/info", "/suggest", "/clear", "/help", "/quit"]
        )
        print(f"{DIM}Commands:{RESET}  {cmds}")

    def preloop(self) -> None:
        self.render_dashboard()

    def cmdloop(self, intro: object = None) -> None:  # type: ignore[override]
        """Run the REPL loop, using prompt_toolkit when available for the bottom toolbar."""
        self.preloop()
        if intro is not None:
            self.stdout.write(str(intro) + "\n")

        if _PROMPT_SESSION is not None:
            self._ptk_loop()
        else:
            # Fallback: use cmd.Cmd's standard loop
            self.use_rawinput = True
            stop = False
            while not stop:
                try:
                    # If we have a pending command, we can't easily "autofill" standard input()
                    # so we just show it in the notice and wait for the user to type it or press enter
                    line = input(self.prompt)
                except EOFError:
                    line = "EOF"
                except KeyboardInterrupt:
                    self.stdout.write("\n")
                    continue
                line = self.precmd(line)
                stop = self.onecmd(line)
                stop = self.postcmd(stop, line)
            self.postloop()

    def _ptk_loop(self) -> None:
        """Inner loop driven by prompt_toolkit PromptSession."""
        stop = False
        while not stop:
            try:
                # Use pending_command as default text if available
                default_text = self.pending_command or ""
                self.pending_command = None  # Clear it once used for autofill

                line = _PROMPT_SESSION.prompt(
                    ANSI(self.prompt),
                    bottom_toolbar=_build_toolbar,
                    default=default_text,
                )
            except EOFError:
                line = "EOF"
            except KeyboardInterrupt:
                self.stdout.write("\n")
                continue
            line = self.precmd(line)
            stop = self.onecmd(line)
            stop = self.postcmd(stop, line)

    def completenames(self, text: str, *ignored: object) -> list[str]:
        """Complete slash-prefixed command names.

        cmd.Cmd's default completenames only considers methods named do_*,
        which does not work for this shell because commands are parsed from
        slash-prefixed input and dispatched through default().
        """
        return [command for command in COMMANDS if command.startswith(text)]

    def completedefault(
        self, text: str, line: str, _begidx: int, _endidx: int
    ) -> list[str]:
        stripped = line.lstrip()
        if not stripped.startswith("/"):
            return []

        if " " not in stripped:
            return [
                command for command in COMMANDS if command.startswith(text or stripped)
            ]

        if stripped.startswith("/info"):
            return []

        if stripped.startswith("/suggest"):
            # No additional completions needed for simplified syntax
            return []

        return []

    def do_suggest(self, arg: str) -> None:
        parts = shlex.split(arg)
        commit_count = None
        if len(parts) == 1:
            try:
                commit_count = int(parts[0])
                if commit_count <= 0:
                    raise ValueError("Positive number required.")
            except ValueError:
                print_notice("Invalid commit count.", "error")
                return
        elif len(parts) > 1:
            print_notice("Usage: /suggest [count]", "warning")
            return

        # Check for uncommitted changes
        status = self.git_service.get_status()
        if status.strip():
            print_notice(
                "Uncommitted changes detected. Please commit or stash them before proceeding.",
                "error",
            )
            return

        start_day, end_day = ask_date_range(self.today)
        strategy_name = ask_strategy()

        while True:
            try:
                if commit_count is None:
                    suggestion = self.git_service.build_all_commits_suggestion(
                        self.app_config.branch,
                        self.today,
                        strategy_name=strategy_name,
                        start_day=start_day,
                        end_day=end_day,
                    )
                else:
                    suggestion = self.git_service.build_suggestion(
                        self.app_config.branch,
                        self.today,
                        strategy_name=strategy_name,
                        commit_count=commit_count,
                        start_day=start_day,
                        end_day=end_day,
                    )
            except (ValueError, subprocess.CalledProcessError) as exc:
                message = str(exc.stderr.strip() if hasattr(exc, "stderr") else exc)
                self.last_notice = format_notice(message, "error")
                print_notice(message, "error")
                return

            self.last_suggestion = suggestion
            counts = self.git_service.merged_suggestion_counts(
                self.app_config.branch,
                suggestion,
                self.history_start,
                self.today,
            )

            print("")
            title_prefix = (
                "all commits" if commit_count is None else f"{commit_count} commits"
            )
            window_str = (
                f"{suggestion.start_day.isoformat()} → {suggestion.end_day.isoformat()}"
            )
            print(
                f"{TITLE}Suggested heatmap{RESET}  {DIM}·{RESET}  {ACCENT}{title_prefix}{RESET}  {DIM}·{RESET}  {MUTED}{strategy_name}{RESET}  {DIM}·{RESET}  {window_str}"
            )
            if commit_count is None:
                print(
                    f"  {DIM}{self.app_config.repo}  ·  branch {self.app_config.branch}{RESET}"
                )
            print("")
            print(render_heatmap(counts, self.history_start, self.today))
            print("")
            print_notice(
                f"{ACCENT}{suggestion.total_commits}{RESET} commits will be redistributed using {ACCENT}{strategy_name}{RESET} strategy.",
                "info",
            )

            if confirm("Rewrite git history with this suggested distribution?"):
                identity_preference = ask_identity_preference()
                if identity_preference is None:
                    print_notice("Cancelled — history unchanged.", "info")
                    return

                keep_identity, name, email = identity_preference
                # Create a modified config if we have overrides
                # Note: AppConfig no longer has name/email fields, but we pass them to run_rewrite
                exit_code = self.git_service.run_rewrite(
                    self.app_config,
                    suggestion,
                    keep_identity=keep_identity,
                    override_name=name,
                    override_email=email,
                )
                if exit_code == 0:
                    self.last_notice = format_notice(
                        f"{suggestion.total_commits} commits rewritten with {ACCENT}{strategy_name}{RESET} strategy. "
                        f"Force-push if the repo is shared.",
                        "success",
                    )
                else:
                    self.last_notice = format_notice(
                        f"Rewrite failed (exit {exit_code}). History unchanged.",
                        "error",
                    )
                print(self.last_notice)
                break
            else:
                print("")
                new_strategy = ask_strategy(allow_back=True)
                if new_strategy == "QUIT":
                    return self.do_quit("")
                if new_strategy is None:
                    break
                strategy_name = new_strategy

    def do_quit(self, _arg: str) -> bool:
        print_notice("Exiting.", "info")
        return True

    def do_clear(self, _arg: str) -> None:
        self.render_dashboard()

    def do_help(self, _arg: str) -> None:
        help_lines = [
            f"{ACCENT}/info, /i{RESET}                  Show GitHub identity and current repository heatmap",
            f"{ACCENT}/suggest, /s{RESET}               Preview and redistribute ALL repo commits",
            f"{ACCENT}/suggest <count>{RESET}          Redistribute last <count> commits",
            f"{ACCENT}/clear, /c{RESET}                 Clear the screen",
            f"{ACCENT}/help, /h{RESET}                  Show this help panel",
            f"{ACCENT}/quit, /q{RESET}                  Exit the shell",
        ]
        print(box_lines(help_lines, title="Commands"))

    def do_info(self, _arg: str) -> None:
        name = get_global_git_config("user.name") or "Not set"
        email = get_global_git_config("user.email") or "Not set"
        print(f"{TITLE}Identity (Global):{RESET} {name} <{email}>")
        print(f"{TITLE}Repository:{RESET} {self.app_config.repo}")
        print(f"{TITLE}Branch:{RESET} {self.app_config.branch}")
        try:
            counts = git_log_date_counts(
                self.app_config.repo,
                self.app_config.branch,
                self.history_start,
                self.today,
            )
            print(render_heatmap(counts, self.history_start, self.today))
        except Exception as exc:
            print_notice(f"Error: {exc}", "error")

    def default(self, line: str) -> bool | None:
        stripped = line.strip()
        if not stripped:
            return None

        if not stripped.startswith("/"):
            print_notice("Unknown input. Commands must start with '/'.", "warning")
            return None

        command_token, _, remainder = stripped.partition(" ")
        resolved = resolve_command_name(command_token)

        if resolved is None:
            print_notice(f"Unknown command: {command_token}", "error")
            return None

        if resolved == "":  # Ambiguous
            return None

        # If the input was just a prefix, "autofill" it for the next prompt
        # EXCEPT for aliases which should execute immediately.
        if resolved != command_token and command_token not in ALIASES:
            self.pending_command = f"{resolved} {remainder}".strip()
            self.render_dashboard()
            return None

        # Exact match (or confirmed autofill), execute it
        if resolved == "/suggest":
            return self.do_suggest(remainder)
        if resolved == "/info":
            return self.do_info(remainder)
        if resolved == "/clear":
            return self.do_clear(remainder)
        if resolved == "/help":
            return self.do_help(remainder)
        if resolved == "/quit":
            return self.do_quit(remainder)

        return None
