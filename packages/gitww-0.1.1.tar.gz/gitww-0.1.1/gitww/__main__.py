#!/usr/bin/env python3
import sys

_RESET = "\033[0m"
_BOLD = "\033[1m"
_ERROR = "\033[38;5;203m"
_MUTED = "\033[38;5;246m"

from .config_loader import load_app_config
from .shell import (
    GitWWShell,
    _PTK_AVAILABLE,
    _setup_prompt_session,
    setup_readline,
    save_readline_history,
)


class GitWWApp:
    def run(self) -> int:
        if _PTK_AVAILABLE:
            _setup_prompt_session()
        else:
            setup_readline()

        try:
            app_config = load_app_config()
            shell = GitWWShell(app_config)
            shell.cmdloop()
            return 0
        except KeyboardInterrupt:
            print(f"\n{_MUTED}Interrupted. Exiting.{_RESET}")
            return 0
        except Exception as exc:
            print(f"\n{_ERROR}{_BOLD}✖  Unexpected error:{_RESET} {exc}")
            return 1
        finally:
            save_readline_history()


def main() -> int:
    return GitWWApp().run()


if __name__ == "__main__":
    sys.exit(main())
