import json
import subprocess
import sys
import tempfile
from collections import Counter
from datetime import date, datetime, time, timezone, timedelta
from pathlib import Path

from .models import AppConfig, Suggestion
from .git_utils import run_git
from .strategies import _redistribute_commits


class GitService:
    """Service layer for Git operations and history manipulation."""

    def __init__(self, repo_path: Path):
        self.repo = repo_path

    def build_suggestion(
        self,
        branch: str,
        today: date,
        strategy_name: str,
        commit_count: int | None = None,
        start_day: date | None = None,
        end_day: date | None = None,
    ) -> Suggestion:
        start_day = start_day or (today - timedelta(days=364))
        end_day = end_day or today
        window_start = start_day
        min_dt = None

        if commit_count is not None:
            result = run_git(self.repo, "rev-list", branch)
            all_commits = [
                line.strip() for line in result.stdout.splitlines() if line.strip()
            ]
            total_available = len(all_commits)

            if commit_count > total_available:
                raise ValueError(
                    f"Requested {commit_count} commits, but repository only has {total_available}."
                )

            commits = all_commits[:commit_count]
            commits.reverse()

            if total_available > commit_count:
                boundary_commit = all_commits[commit_count]
                date_result = run_git(
                    self.repo, "log", "-1", "--format=%cI", boundary_commit
                )
                min_dt = datetime.fromisoformat(date_result.stdout.strip())
                boundary_date = min_dt.date()
                start_day = max(window_start, boundary_date)
                if start_day > end_day:
                    start_day = end_day
            else:
                start_day = window_start
        else:
            result = run_git(
                self.repo,
                "rev-list",
                "--reverse",
                "--since",
                datetime.combine(start_day, time.min, tzinfo=timezone.utc).isoformat(),
                branch,
            )
            commits = [
                line.strip() for line in result.stdout.splitlines() if line.strip()
            ]

        total = len(commits)
        if total == 0:
            raise ValueError("No commits found.")

        suggested_datetimes = _redistribute_commits(
            commits,
            start_day,
            end_day,
            strategy_name=strategy_name,
            min_datetime=min_dt,
        )

        return Suggestion(
            start_day=start_day,
            end_day=end_day,
            total_commits=total,
            commits=commits,
            suggested_datetimes=suggested_datetimes,
        )

    def build_all_commits_suggestion(
        self,
        branch: str,
        today: date,
        strategy_name: str,
        start_day: date | None = None,
        end_day: date | None = None,
    ) -> Suggestion:
        start_day = start_day or (today - timedelta(days=364))
        end_day = end_day or today

        result = run_git(self.repo, "rev-list", branch, "--reverse")
        commits = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        total = len(commits)
        if total == 0:
            raise ValueError("No commits found in this repository.")

        suggested_datetimes = _redistribute_commits(
            commits, start_day, end_day, strategy_name=strategy_name
        )

        return Suggestion(
            start_day=start_day,
            end_day=end_day,
            total_commits=total,
            commits=commits,
            suggested_datetimes=suggested_datetimes,
        )

    def merged_suggestion_counts(
        self, branch: str, suggestion: Suggestion, start_day: date, end_day: date
    ) -> Counter[date]:
        since = datetime.combine(start_day, time.min, tzinfo=timezone.utc).isoformat()
        until = datetime.combine(
            end_day + timedelta(days=1), time.min, tzinfo=timezone.utc
        ).isoformat()
        result = run_git(
            self.repo,
            "log",
            branch,
            f"--since={since}",
            f"--until={until}",
            "--pretty=%H %cI",
        )

        counts: Counter[date] = Counter()
        replaced_hashes = set(suggestion.commits)

        for line in result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(None, 1)
            if len(parts) < 2:
                continue
            h, dt_str = parts
            if h not in replaced_hashes:
                counts[datetime.fromisoformat(dt_str).date()] += 1

        for stamp in suggestion.suggested_datetimes:
            counts[datetime.fromisoformat(stamp).date()] += 1

        return counts

    def run_rewrite(
        self,
        app_config: AppConfig,
        suggestion: Suggestion,
        keep_identity: bool = False,
        override_name: str | None = None,
        override_email: str | None = None,
    ) -> int:
        payload = {
            "repo": str(app_config.repo),
            "name": override_name or "",
            "email": override_email or "",
            "begin_commit": suggestion.commits[0],
            "end_commit": suggestion.commits[-1],
            "dates": suggestion.suggested_datetimes,
            "refs": [app_config.branch],
            "keep_identity": keep_identity,
        }

        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".json") as handle:
            json.dump(payload, handle, indent=2)
            handle.write("\n")
            temp_path = Path(handle.name)

        command = [
            sys.executable,
            "-m",
            "gitww.git_witchcraft_wizardry",
            "--config",
            str(temp_path),
        ]
        try:
            completed = subprocess.run(
                command, cwd=Path(__file__).resolve().parent.parent
            )
            return completed.returncode
        finally:
            temp_path.unlink(missing_ok=True)

    def get_status(self) -> str:
        """Return the porcelain status of the repository."""
        result = run_git(self.repo, "status", "--porcelain")
        return result.stdout
