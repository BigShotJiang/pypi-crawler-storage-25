import math
import random
import itertools
from datetime import date, datetime, time, timedelta, timezone


def _get_time_weight(hour: float) -> float:
    """Mixture of gaussians for human-like daily commit activity."""
    WORK_PEAK_HOUR = 10.5  # mid-morning peak
    WORK_SIGMA = 2.5  # hours
    LUNCH_DIP_CENTER = 13.0  # lunch dip
    LUNCH_DIP_SIGMA = 0.5
    NIGHT_PEAK_HOUR = 23.0  # late-night peak
    NIGHT_SIGMA = 1.5  # hours
    NIGHT_WEIGHT = 0.08  # ~8% as likely as work hours

    work = math.exp(-0.5 * ((hour - WORK_PEAK_HOUR) / WORK_SIGMA) ** 2)
    # Subtract a lunch dip
    lunch_dip = 0.35 * math.exp(
        -0.5 * ((hour - LUNCH_DIP_CENTER) / LUNCH_DIP_SIGMA) ** 2
    )

    # Night peak with wrap-around
    dh_night = hour - NIGHT_PEAK_HOUR
    if dh_night > 12:
        dh_night -= 24
    elif dh_night < -12:
        dh_night += 24
    night = NIGHT_WEIGHT * math.exp(-0.5 * (dh_night / NIGHT_SIGMA) ** 2)

    return max(work - lunch_dip + night, 0.01)


# Pre-calculate second-by-second weights for a full day
_SECOND_WEIGHTS = [_get_time_weight(s / 3600.0) for s in range(86400)]
_CUM_WEIGHTS = list(itertools.accumulate(_SECOND_WEIGHTS))


class RedistributionStrategy:
    """Base class for commit redistribution strategies."""

    name: str = "base"
    description: str = "Base strategy"

    def get_weights(self, total_days: int, start_day: date) -> list[float]:
        """Return a list of weights for each day in the range."""
        raise NotImplementedError


class BurstStrategy(RedistributionStrategy):
    """Bursts of activity followed by quiet periods."""

    name = "burst"
    description = "Bursts of activity (2-5 days) followed by lulls (1-3 days)"

    def get_weights(self, total_days: int, start_day: date) -> list[float]:
        weights = []
        is_burst = True
        remaining = total_days
        while remaining > 0:
            period_len = random.randint(2, 5) if is_burst else random.randint(1, 3)
            period_len = min(period_len, remaining)
            if is_burst:
                weight = random.uniform(0.5, 3.5)
            else:
                # Soft lull: occasional commits even in quiet periods
                weight = random.choice(
                    [
                        random.uniform(0.0, 0.1),  # most lull days: near-zero
                        random.uniform(0.2, 1.0),  # ~20% chance: a stray commit
                    ]
                )
            weights.extend([weight] * period_len)
            is_burst = not is_burst
            remaining -= period_len
        return weights


class WorkdayStrategy(RedistributionStrategy):
    """Focus activity on weekdays (Mon-Fri) with minimal weekend activity."""

    name = "workday"
    description = "High activity on Mon-Fri, minimal on weekends"

    def get_weights(self, total_days: int, start_day: date) -> list[float]:
        weights = []
        for i in range(total_days):
            current_day = start_day + timedelta(days=i)
            if current_day.weekday() < 5:  # Mon-Fri
                # ~15% chance of an unproductive weekday
                if random.random() < 0.15:
                    weights.append(random.uniform(0.0, 0.2))
                else:
                    weights.append(random.uniform(0.5, 3.5))
            else:  # Sat-Sun
                # ~25% chance of a weekend commit session
                if random.random() < 0.25:
                    weights.append(random.uniform(0.2, 1.5))
                else:
                    weights.append(random.uniform(0.0, 0.1))
        return weights


class NaturalStrategy(RedistributionStrategy):
    """Combines workday and burst patterns with realistic human variability."""

    name = "natural"
    description = (
        "Workday rhythm with burst/lull cycles and occasional off-hours commits"
    )

    def get_weights(self, total_days: int, start_day: date) -> list[float]:
        # Start with workday base
        base = WorkdayStrategy().get_weights(total_days, start_day)
        # Overlay burst/lull modulation
        burst = BurstStrategy().get_weights(total_days, start_day)
        weights = []
        for b, br in zip(base, burst):
            # Multiply: workday weight * burst weight, normalised around 1.0
            combined = b * br
            # Add per-day noise so no two days look identical
            combined *= random.uniform(0.3, 2.5)
            weights.append(combined)
        return weights


class NightOwlStrategy(RedistributionStrategy):
    """Activity concentrated in late evening and night hours."""

    name = "nightowl"
    description = (
        "Late-night developer: commits peak 20:00-02:00 with sparse daytime activity"
    )

    def get_weights(self, total_days: int, start_day: date) -> list[float]:
        weights = []
        for i in range(total_days):
            current_day = start_day + timedelta(days=i)
            # Base weight: everyone commits *something* sometimes
            base = random.uniform(0.2, 1.0)
            if current_day.weekday() < 5:
                # Weekdays: slightly more likely to have a late-night session
                if random.random() < 0.2:
                    base = random.uniform(0.0, 0.2)  # some weekdays: just sleep
                else:
                    base = random.uniform(0.5, 3.0)
            else:
                # Weekends: night owls often code more on weekends
                if random.random() < 0.35:
                    base = random.uniform(1.0, 4.0)  # weekend binge
                else:
                    base = random.uniform(0.1, 0.8)
            # Per-day noise
            weights.append(base * random.uniform(0.4, 2.0))
        return weights


class SprintStrategy(RedistributionStrategy):
    """Mimics agile sprint cycles with mid-sprint peaks and end-of-sprint crunches."""

    name = "sprint"
    description = (
        "Agile-style 2-week sprints: ramp-up, peak, and crunch before sprint end"
    )

    def get_weights(self, total_days: int, start_day: date) -> list[float]:
        SPRINT_LEN = random.choice([10, 14])  # 2 or ~2-week sprints
        weights = []
        remaining = total_days
        sprint_start = 0
        while remaining > 0:
            period = min(SPRINT_LEN, remaining)
            for d in range(period):
                progress = d / max(period - 1, 1)  # 0..1 within sprint
                # Ramp up early, dip mid-sprint, crunch at end
                if progress < 0.3:
                    base = 0.3 + 1.2 * (progress / 0.3)  # 0.3 -> 1.5
                elif progress < 0.7:
                    base = 0.8 + random.uniform(-0.4, 0.8)  # mid-sprint plateau
                else:
                    base = 1.0 + 1.5 * ((progress - 0.7) / 0.3)  # crunch: 1.0 -> 2.5
                # Weekend within sprint: reduced
                day_idx = sprint_start + d
                current_day = start_day + timedelta(days=day_idx)
                if current_day.weekday() >= 5:
                    base *= random.uniform(0.05, 0.4)
                # Random off-day or hyper-day
                roll = random.random()
                if roll < 0.15:
                    base *= random.uniform(0.0, 0.2)  # unproductive day
                elif roll > 0.85:
                    base *= random.uniform(1.5, 3.5)  # crunch overload
                weights.append(max(base * random.uniform(0.4, 2.2), 0.0))
            remaining -= period
            sprint_start += period
        return weights


class ChaoticStrategy(RedistributionStrategy):
    """Highly random distribution with no discernible pattern."""

    name = "chaotic"
    description = "Maximum randomness: no predictable daily or weekly pattern"

    def get_weights(self, total_days: int, start_day: date) -> list[float]:
        weights = []
        for i in range(total_days):
            # Heavy-tailed distribution: most days low, occasional spikes
            roll = random.random()
            if roll < 0.4:
                # Quiet day
                weights.append(random.uniform(0.0, 0.15))
            elif roll < 0.75:
                # Normal day
                weights.append(random.uniform(0.3, 0.9))
            elif roll < 0.92:
                # Active day
                weights.append(random.uniform(0.9, 1.4))
            else:
                # Spike / binge day
                weights.append(random.uniform(1.4, 2.0))
        return weights


class DeepWorkStrategy(RedistributionStrategy):
    """Long, intense bursts of productivity followed by significant lulls."""

    name = "deepwork"
    description = "Focused 'deep work' sessions: several hours of intense clustering"

    def get_weights(self, total_days: int, start_day: date) -> list[float]:
        weights = []
        is_burst = random.choice([True, False])
        remaining = total_days
        while remaining > 0:
            period_len = random.randint(3, 7) if is_burst else random.randint(2, 5)
            period_len = min(period_len, remaining)
            if is_burst:
                weight = random.uniform(1.5, 4.5)
            else:
                weight = random.uniform(0.0, 0.1)
            weights.extend([weight] * period_len)
            is_burst = not is_burst
            remaining -= period_len
        return weights


STRATEGIES: dict[str, type[RedistributionStrategy]] = {
    "natural": NaturalStrategy,
    "burst": BurstStrategy,
    "workday": WorkdayStrategy,
    "nightowl": NightOwlStrategy,
    "sprint": SprintStrategy,
    "chaotic": ChaoticStrategy,
    "deepwork": DeepWorkStrategy,
}


def _redistribute_commits(
    commits: list[str],
    start_day: date,
    end_day: date,
    strategy_name: str,
    min_datetime: datetime | None = None,
) -> list[str]:
    """Redistribute a list of commits across a date range using a strategy."""
    total = len(commits)
    total_days = (end_day - start_day).days + 1
    if total_days <= 0:
        start_day = end_day
        total_days = 1

    strategy_cls = STRATEGIES.get(
        strategy_name, NaturalStrategy
    )  # Fallback to Natural if not found
    strategy = strategy_cls()
    weights = strategy.get_weights(total_days, start_day)

    weight_sum = sum(weights)
    if weight_sum <= 0:
        # Fallback to natural if strategy produced all zeros
        strategy = NaturalStrategy()
        weights = strategy.get_weights(total_days, start_day)
        weight_sum = sum(weights)
        if weight_sum <= 0:  # Still zero? Just distribute evenly as ultimate fallback
            weights = [1.0] * total_days
            weight_sum = float(total_days)

    day_counts = [0] * total_days
    remaining_commits = total

    for i in range(total_days):
        count = int(total * weights[i] / weight_sum)
        day_counts[i] = count
        remaining_commits -= count

    if remaining_commits > 0:
        remainders = []
        for i in range(total_days):
            exact = total * weights[i] / weight_sum
            remainders.append((exact - day_counts[i], i))

        remainders.sort(key=lambda x: x[0], reverse=True)
        for i in range(remaining_commits):
            _, day_idx = remainders[i]
            day_counts[day_idx] += 1

    # Force all non-zero counts to be odd
    evens = {i for i, c in enumerate(day_counts) if c > 0 and c % 2 == 0}
    zeros = {i for i, c in enumerate(day_counts) if c == 0}
    odds = {i for i, c in enumerate(day_counts) if c % 2 != 0}

    loop_count = 0
    max_loops = total * 10
    while evens and loop_count < max_loops:
        loop_count += 1
        i = next(iter(evens))

        # 1. Pair with another even
        if len(evens) >= 2:
            it = iter(evens)
            next(it)  # skip i
            j = next(it)

            day_counts[i] -= 1
            day_counts[j] += 1

            evens.remove(i)
            odds.add(i)
            evens.remove(j)
            odds.add(j)
            continue

        # 2. Pair with a zero
        if zeros:
            j = max(zeros, key=lambda x: weights[x])
            day_counts[i] -= 1
            day_counts[j] += 1

            evens.remove(i)
            odds.add(i)
            zeros.remove(j)
            odds.add(j)
            continue

        # 3. Only 1 even, and no zeros. We MUST drive `i` to 0 or another state.
        if day_counts[i] >= 2 and odds:
            j = max(odds, key=lambda x: weights[x])
            day_counts[i] -= 2
            day_counts[j] += 2
            if day_counts[i] == 0:
                evens.remove(i)
                zeros.add(i)
            continue

        break

    def _human_time_seconds(
        count: int,
        available_sec: int,
        day_start_sec: int,
        strategy_name: str = "natural",
    ) -> list[int]:
        """Generate `count` second-offsets within the day that mimic human timing.

        Real developers:
        - Commit mostly during work hours (9-18) with a peak ~10-11 and ~14-16
        - Occasionally commit late at night (22-02)
        - Cluster commits into sessions with short gaps, then long gaps
        """
        is_deep_work = strategy_name == "deepwork"

        # --- Session-based sampling ---
        # Group commits into sessions
        sessions: list[list[int]] = []
        remaining = count
        if is_deep_work:
            # Deep work: 1 or 2 long sessions
            while remaining > 0:
                session_size = min(
                    random.randint(min(5, remaining), remaining), remaining
                )
                sessions.append(list(range(session_size)))
                remaining -= session_size
        else:
            # Natural: 1-3 small sessions
            while remaining > 0:
                session_size = min(random.randint(1, min(4, remaining)), remaining)
                sessions.append(list(range(session_size)))
                remaining -= session_size

        offsets: list[int] = []

        # Use pre-calculated cumulative weights for fast sampling
        base_weight = _CUM_WEIGHTS[day_start_sec - 1] if day_start_sec > 0 else 0.0
        total_day_weight = _CUM_WEIGHTS[day_start_sec + available_sec - 1] - base_weight

        if total_day_weight <= 0:
            # Fallback if range has no weight
            session_starts = [
                random.randint(0, available_sec - 1) for _ in range(len(sessions))
            ]
        else:
            session_starts = []
            for _ in range(len(sessions)):
                for _attempt in range(50):
                    r = base_weight + random.random() * total_day_weight
                    # Binary search in GLOBAL CDF
                    import bisect

                    idx = bisect.bisect_left(
                        _CUM_WEIGHTS,
                        r,
                        lo=day_start_sec,
                        hi=day_start_sec + available_sec,
                    )
                    candidate = idx - day_start_sec
                    # Ensure sessions aren't too close (at least 30 min apart)
                    if all(abs(candidate - s) > 1800 for s in session_starts):
                        break
                session_starts.append(candidate)

        session_starts.sort()

        for start, session in zip(session_starts, sessions):
            for i, _ in enumerate(session):
                # Within a session:
                if is_deep_work:
                    # Deep work: 15-30 min apart (focused flow)
                    gap = random.randint(900, 1800)
                else:
                    # Natural: 2-15 min apart (rapid fire)
                    gap = random.randint(120, 900)

                offset = start + (i * gap)
                offset = min(offset, available_sec - 1)
                offsets.append(offset)

        offsets.sort()
        return offsets

    suggested_datetimes: list[str] = []
    for day_offset, commit_count in enumerate(day_counts):
        if commit_count == 0:
            continue

        current_day = start_day + timedelta(days=day_offset)

        day_start_sec = 0
        if min_datetime and current_day == min_datetime.date():
            day_start_sec = (
                (min_datetime.hour * 3600)
                + (min_datetime.minute * 60)
                + min_datetime.second
                + 1
            )

        available_sec = 86400 - day_start_sec
        if available_sec <= 0:
            available_sec = 1
            day_start_sec = 86399

        second_offsets = _human_time_seconds(
            commit_count, available_sec, day_start_sec, strategy_name=strategy_name
        )
        for second_offset in second_offsets:
            timestamp = datetime.combine(
                current_day, time.min, tzinfo=timezone.utc
            ) + timedelta(seconds=day_start_sec + second_offset)
            suggested_datetimes.append(timestamp.isoformat())

    suggested_datetimes.sort()
    return suggested_datetimes
