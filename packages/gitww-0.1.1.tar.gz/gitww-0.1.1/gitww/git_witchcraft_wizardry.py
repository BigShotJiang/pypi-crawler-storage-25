"""Git metadata rewrite helpers and CLI entry point."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

# ANSI helpers (kept local so this module stays self-contained)
_RESET = "\033[0m"
_DIM = "\033[38;5;244m"
_ACCENT = "\033[38;5;81m"
_SUCCESS = "\033[38;5;42m"
_MUTED = "\033[38;5;246m"
_BOLD = "\033[1m"


def _kv(label: str, value: str) -> str:
    """Format a key-value line with an accented label."""
    return f"  {_MUTED}{label:<20}{_RESET}{value}"


@dataclass(frozen=True)
class GitMetadataRewriter:
    """Internal coordinator for rewriting commit metadata across a git range."""

    config_path: Path
    dry_run: bool = False

    @classmethod
    def from_args(cls, args: argparse.Namespace) -> "GitMetadataRewriter":
        return cls(
            config_path=Path(args.config).expanduser().resolve(), dry_run=args.dry_run
        )

    @staticmethod
    def build_parser() -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(
            description=(
                "Bulk rewrite git author/committer metadata and dates from a "
                "JSON config file with a single git filter-branch run."
            )
        )
        parser.add_argument(
            "--config",
            required=True,
            help="Path to a JSON config file.",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Print the generated filter and git command without executing.",
        )
        return parser

    def run(self) -> int:
        config = load_config(self.config_path)

        repo = Path(require_string(config, "repo")).expanduser().resolve()
        keep_identity = bool(config.get("keep_identity", False))

        name = config.get("name")
        email = config.get("email")

        if not keep_identity and (not name or not email):
            # We don't have access to gitww.git_utils here easily if we want to stay self-contained
            # but we can do a quick check
            if not name:
                res = subprocess.run(
                    ["git", "config", "--global", "user.name"],
                    capture_output=True,
                    text=True,
                )
                if res.returncode == 0:
                    name = res.stdout.strip()
            if not email:
                res = subprocess.run(
                    ["git", "config", "--global", "user.email"],
                    capture_output=True,
                    text=True,
                )
                if res.returncode == 0:
                    email = res.stdout.strip()

            if not name or not email:
                print(
                    f"\n{_RESET}\033[38;5;203m✖  Global git config 'user.name' or 'user.email' is missing.{_RESET}",
                    file=sys.stderr,
                )
                return 1

        begin_commit = require_string(config, "begin_commit")
        end_commit = require_string(config, "end_commit")
        dates = load_dates(config)
        refs = optional_string_list(config, "refs", default=["--all"])

        validate_repo(repo)
        resolved_commits = resolve_commit_range(repo, begin_commit, end_commit)
        if len(resolved_commits) != len(dates):
            raise SystemExit(
                "Config key 'dates' must contain exactly one entry for each commit in the inclusive begin_commit..end_commit range."
            )

        filter_script = build_filter_script(
            name=name,
            email=email,
            commits=resolved_commits,
            dates=dates,
            keep_identity=keep_identity,
        )

        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".sh") as handle:
            handle.write(filter_script)
            filter_path = Path(handle.name)

        os.chmod(filter_path, 0o700)
        git_command = [
            "git",
            "filter-branch",
            "-f",
            "--env-filter",
            f'. "{filter_path}"',
            "--",
            *refs,
        ]

        env = os.environ.copy()
        env["FILTER_BRANCH_SQUELCH_WARNING"] = "1"

        try:
            if self.dry_run:
                print(f"{_ACCENT}Generated env-filter script:{_RESET}")
                print(filter_script)
                print(f"{_ACCENT}Git command:{_RESET}")
                print(" ".join(git_command))
                return 0

            subprocess.run(git_command, cwd=repo, check=True, env=env)
        except subprocess.CalledProcessError as exc:
            print(
                f"\n{_RESET}\033[38;5;203m✗  git filter-branch failed (exit {exc.returncode}){_RESET}",
                file=sys.stderr,
            )
            return exc.returncode
        finally:
            filter_path.unlink(missing_ok=True)

        # Check if the begin commit is a root commit
        is_root = False
        try:
            root_result = subprocess.run(
                ["git", "rev-list", "--max-parents=0", resolved_commits[0]],
                cwd=repo,
                text=True,
                capture_output=True,
                check=True,
            )
            if root_result.stdout.strip() == resolved_commits[0]:
                is_root = True
        except subprocess.CalledProcessError:
            pass

        short_begin = "root" if is_root else resolved_commits[0][:12]
        short_end = resolved_commits[-1][:12]
        ref_list = " ".join(refs)
        n = len(resolved_commits)

        print()
        print(
            f"{_SUCCESS}{_BOLD}✔  Rewrite completed — {n} commit{'s' if n != 1 else ''} rewritten{_RESET}"
        )
        print(f"{_DIM}{'─' * 52}{_RESET}")
        print(_kv("Refs rewritten:", ref_list))
        print(_kv("Commit range:", f"{short_begin}  →  {short_end}"))
        print(_kv("Commits targeted:", str(n)))
        identity_str = (
            "Original (keep original author/committer)"
            if keep_identity
            else f"{name} <{email}>"
        )
        print(_kv("Identity:", identity_str))
        print(_kv("Date mode:", "per-commit (individual timestamps)"))
        print(f"{_DIM}{'─' * 52}{_RESET}")
        print(f"  {_MUTED}Force-push required if this repo is shared.{_RESET}")
        print()
        return 0


def parse_args() -> argparse.Namespace:
    return GitMetadataRewriter.build_parser().parse_args()


def load_config(config_path: Path) -> dict[str, object]:
    if not config_path.exists():
        raise SystemExit(f"Config file does not exist: {config_path}")
    if not config_path.is_file():
        raise SystemExit(f"Config path is not a file: {config_path}")

    try:
        content = config_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise SystemExit(f"Unable to read config file: {config_path}\n{exc}") from exc

    try:
        if config_path.suffix.lower() != ".json":
            raise SystemExit(
                f"Unsupported config format '{config_path.suffix}'. Use a .json file."
            )
        data = json.loads(content)
    except SystemExit:
        raise
    except Exception as exc:
        raise SystemExit(
            f"Failed to parse JSON config file: {config_path}\n{exc}"
        ) from exc

    if not isinstance(data, dict):
        raise SystemExit("Config file must contain a top-level JSON object.")

    return data


def require_string(config: dict[str, object], key: str) -> str:
    value = config.get(key)
    if not isinstance(value, str) or not value.strip():
        raise SystemExit(f"Config key '{key}' must be a non-empty string.")
    return value


def optional_string_list(
    config: dict[str, object], key: str, default: list[str]
) -> list[str]:
    value = config.get(key)
    if value is None:
        return default
    if not isinstance(value, list) or not all(
        isinstance(item, str) and item.strip() for item in value
    ):
        raise SystemExit(f"Config key '{key}' must be a list of non-empty strings.")
    return value


def load_dates(config: dict[str, object]) -> list[str]:
    value = config.get("dates")
    if value is None or not isinstance(value, list) or not value:
        raise SystemExit("Config key 'dates' must be a non-empty list.")

    dates: list[str] = []
    parsed_dates: list[datetime] = []
    for index, item in enumerate(value):
        if not isinstance(item, str) or not item.strip():
            raise SystemExit(f"Config key 'dates[{index}]' must be a non-empty string.")
        try:
            parsed = datetime.fromisoformat(item)
        except ValueError as exc:
            raise SystemExit(
                f"Config key 'dates[{index}]' must be a valid ISO 8601 datetime string."
            ) from exc
        dates.append(item)
        parsed_dates.append(parsed)

    for index in range(1, len(parsed_dates)):
        if parsed_dates[index] < parsed_dates[index - 1]:
            raise SystemExit("Config key 'dates' must be in ascending time order.")

    return dates


def run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        capture_output=True,
        check=True,
    )


def validate_repo(repo: Path) -> None:
    if not repo.exists():
        raise SystemExit(f"Repository path does not exist: {repo}")
    if not repo.is_dir():
        raise SystemExit(f"Repository path is not a directory: {repo}")
    try:
        run_git(repo, "rev-parse", "--is-inside-work-tree")
    except subprocess.CalledProcessError as exc:
        raise SystemExit(f"Not a git repository: {repo}\n{exc.stderr.strip()}") from exc


def resolve_commit(repo: Path, commit: str) -> str:
    try:
        result = run_git(repo, "rev-parse", "--verify", f"{commit}^{{commit}}")
    except subprocess.CalledProcessError as exc:
        raise SystemExit(
            f"Invalid commit selector '{commit}': {exc.stderr.strip()}"
        ) from exc
    return result.stdout.strip()


def resolve_commit_range(repo: Path, begin_commit: str, end_commit: str) -> list[str]:
    begin_sha = resolve_commit(repo, begin_commit)
    end_sha = resolve_commit(repo, end_commit)

    try:
        run_git(repo, "merge-base", "--is-ancestor", begin_sha, end_sha)
    except subprocess.CalledProcessError as exc:
        raise SystemExit(
            "The begin commit must be an ancestor of the end commit."
        ) from exc

    try:
        result = run_git(
            repo,
            "rev-list",
            "--reverse",
            "--ancestry-path",
            f"{begin_sha}..{end_sha}",
        )
    except subprocess.CalledProcessError as exc:
        raise SystemExit(
            f"Unable to resolve commit range {begin_commit}..{end_commit}: {exc.stderr.strip()}"
        ) from exc

    commits = [begin_sha]
    commits.extend(line.strip() for line in result.stdout.splitlines() if line.strip())
    if commits[0] != begin_sha or commits[-1] != end_sha:
        raise SystemExit(
            "Resolved commit range did not include both begin_commit and end_commit."
        )
    return commits


def build_filter_script(
    name: str,
    email: str,
    commits: list[str],
    dates: list[str],
    keep_identity: bool = False,
) -> str:
    case_lines = "\n".join(
        f"    {commit!r}) new_date={date!r} ;;"
        for commit, date in zip(commits, dates, strict=True)
    )

    identity_exports = ""
    if not keep_identity:
        identity_exports = f"""
export GIT_AUTHOR_NAME={name!r}
export GIT_AUTHOR_EMAIL={email!r}
export GIT_COMMITTER_NAME={name!r}
export GIT_COMMITTER_EMAIL={email!r}"""

    return f"""\
new_date=
case "$GIT_COMMIT" in
{case_lines}
    *) return 0 ;;
esac
{identity_exports}
export GIT_AUTHOR_DATE="$new_date"
export GIT_COMMITTER_DATE="$new_date"
"""


def main() -> int:
    args = parse_args()
    return GitMetadataRewriter.from_args(args).run()


if __name__ == "__main__":
    raise SystemExit(main())
