import subprocess
from pathlib import Path
from .models import AppConfig
from .git_utils import run_git
from .ui_utils import ACCENT, MUTED, RESET


def get_current_branch(repo: Path) -> str:
    result = run_git(repo, "rev-parse", "--abbrev-ref", "HEAD")
    return result.stdout.strip()


def ask_branch(default_branch: str) -> str:
    print(
        f"{MUTED}Branch{RESET} — press Enter to use "
        f"{ACCENT}{default_branch}{RESET}{MUTED}, or type another branch name:{RESET} ",
        end="",
    )
    answer = input().strip()
    return answer if answer else default_branch


def load_app_config() -> AppConfig:
    repo = Path.cwd().resolve()
    try:
        run_git(repo, "rev-parse", "--is-inside-work-tree")
    except subprocess.CalledProcessError as exc:
        raise SystemExit(f"Not a git repository: {repo}\n{exc.stderr.strip()}") from exc

    default_branch = get_current_branch(repo)
    branch = ask_branch(default_branch)

    try:
        run_git(repo, "rev-parse", "--verify", branch)
    except subprocess.CalledProcessError as exc:
        raise SystemExit(f"Invalid branch: {branch}\n{exc.stderr.strip()}") from exc

    return AppConfig(repo=repo, branch=branch)
