import re
import sys
import math
import pyfiglet
from datetime import date, timedelta
from collections import Counter

RESET = "\033[0m"
DIM = "\033[38;5;244m"
MUTED = "\033[38;5;246m"
ACCENT = "\033[38;5;81m"
TITLE = "\033[1;38;5;255m"
SUCCESS = "\033[38;5;42m"
WARNING = "\033[38;5;214m"
ERROR = "\033[38;5;203m"

COLOR_STYLES = [
    "\033[38;5;236m·\033[0m",
    "\033[38;5;22m■\033[0m",
    "\033[38;5;28m■\033[0m",
    "\033[38;5;34m■\033[0m",
    "\033[38;5;40m■\033[0m",
    "\033[38;5;46m■\033[0m",
]

ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def visible_len(text: str) -> int:
    return len(ANSI_RE.sub("", text))


def box_lines(lines: list[str], title: str | None = None) -> str:
    width = max((visible_len(line) for line in lines), default=0)
    title_text = f" {title} " if title else ""
    top_rule = f"┌{title_text}{'─' * max(width - visible_len(title_text) + 2, 2)}┐"
    bottom_rule = f"└{'─' * (width + 2)}┘"
    output = [f"{DIM}{top_rule}{RESET}"]
    for line in lines:
        padding = " " * (width - visible_len(line))
        output.append(f"{DIM}│{RESET} {line}{padding} {DIM}│{RESET}")
    output.append(f"{DIM}{bottom_rule}{RESET}")
    return "\n".join(output)


BOLD = "\033[1m"


def format_notice(message: str, tone: str = "info") -> str:
    color = {
        "info": ACCENT,
        "success": SUCCESS,
        "warning": WARNING,
        "error": ERROR,
    }.get(tone, ACCENT)
    marker = {
        "info": "›",
        "success": "✔",
        "warning": "⚠",
        "error": "✖",
    }.get(tone, "›")
    return f"{color}{BOLD}{marker}{RESET} {message}"


def print_notice(message: str, tone: str = "info") -> None:
    print(format_notice(message, tone))


def confirm(prompt: str) -> bool:
    """Prompt the user for y/n confirmation.

    Prints the styled prompt via sys.stdout.write (bypassing readline's
    prompt-length accounting) so ANSI escape codes don't corrupt the
    cursor position or cause garbled text.
    """
    colored_prompt = f"{prompt} {DIM}[{RESET}{ACCENT}y{RESET}{DIM}/{RESET}{MUTED}N{RESET}{DIM}]{RESET} "
    while True:
        sys.stdout.write(colored_prompt)
        sys.stdout.flush()
        answer = input("").strip().lower()
        if answer in {"y", "yes"}:
            print_notice("Confirmed — proceeding with rewrite.", "success")
            return True
        if answer in {"", "n", "no"}:
            print_notice("Cancelled — history unchanged.", "info")
            return False
        print_notice("Please answer y or n.", "warning")


def print_banner() -> None:
    banner = pyfiglet.figlet_format("gitww", font="slant")
    print(f"{ACCENT}{banner.rstrip()}{RESET}")
    print(f"{MUTED}Interactive git history shell{RESET}")
    print("")


def print_repo_header(repo_path: str) -> None:
    print("")
    print(f"{TITLE}Repository:{RESET} {repo_path}")
    print("")


def clear_screen() -> None:
    print("\033[2J\033[H", end="")


def render_heatmap(counts: Counter[date], start_day: date, end_day: date) -> str:
    first_sunday = start_day - timedelta(days=(start_day.weekday() + 1) % 7)
    last_saturday = end_day + timedelta(days=(5 - end_day.weekday()) % 7)
    grid_days: list[date] = []
    day = first_sunday
    while day <= last_saturday:
        grid_days.append(day)
        day += timedelta(days=1)

    visible_days = [day for day in grid_days if start_day <= day <= end_day]
    values = [counts.get(day, 0) for day in visible_days]
    total_commits = sum(values)
    max_count = max(values, default=0)
    commit_days = sorted([day for day in visible_days if counts.get(day, 0) > 0])
    first_commit = commit_days[0].isoformat() if commit_days else "none"
    recent_commit = commit_days[-1].isoformat() if commit_days else "none"
    active_days = len(commit_days)
    average = (total_commits / active_days) if active_days else 0.0

    def level_for(value: int) -> int:
        if value <= 0 or max_count <= 0:
            return 0
        ratio = value / max_count
        max_level = len(COLOR_STYLES) - 1
        level = math.ceil(ratio * max_level)
        if value < max_level:
            level = min(level, value)
        return min(max_level, max(1, level))

    weeks = len(grid_days) // 7
    rows = [[COLOR_STYLES[0] for _ in range(weeks)] for _ in range(7)]

    month_labels: list[str] = [" " for _ in range(weeks)]
    last_month = -1
    for week in range(weeks):
        week_start = first_sunday + timedelta(days=week * 7)
        first_visible = max(week_start, start_day)
        if first_visible.month != last_month and first_visible <= end_day:
            month_labels[week] = first_visible.strftime("%b")
            last_month = first_visible.month

    for week in range(weeks):
        week_start = first_sunday + timedelta(days=week * 7)
        for weekday in range(7):
            current = week_start + timedelta(days=weekday)
            if start_day <= current <= end_day:
                rows[weekday][week] = COLOR_STYLES[level_for(counts.get(current, 0))]

    header_chars = list(" " * (5 + weeks * 2 - 1))
    last_end_idx = -1
    for i in range(weeks):
        label = month_labels[i]
        if label != " ":
            start_idx = 5 + i * 2
            if start_idx < last_end_idx + 1:
                continue
            for j, char in enumerate(label):
                if start_idx + j < len(header_chars):
                    header_chars[start_idx + j] = char
            last_end_idx = start_idx + len(label)
    header_line = "".join(header_chars)

    day_labels = ["   ", "Mon", "   ", "Wed", "   ", "Fri", "   "]

    panel_lines = [header_line]
    for i in range(7):
        row_content = " ".join(rows[i])
        panel_lines.append(f"{day_labels[i]}  {row_content}")

    panel_width = max(visible_len(line) for line in panel_lines)
    top_border = f"{DIM}┌{'─' * (panel_width + 2)}┐{RESET}"
    bottom_border = f"{DIM}└{'─' * (panel_width + 2)}┘{RESET}"
    boxed_lines = [top_border]
    for line in panel_lines:
        padding = " " * (panel_width - visible_len(line))
        boxed_lines.append(f"{DIM}│{RESET} {line}{padding} {DIM}│{RESET}")
    boxed_lines.append(bottom_border)

    legend_parts = [f"{COLOR_STYLES[0]} none"]
    if max_count == 1:
        legend_parts.append(f"{COLOR_STYLES[level_for(1)]} high (1)")
    elif max_count > 1:
        legend_parts.append(f"{COLOR_STYLES[level_for(1)]} low (1)")
        if max_count >= 3:
            medium_val = (1 + max_count) // 2
            legend_parts.append(
                f"{COLOR_STYLES[level_for(medium_val)]} medium ({medium_val})"
            )
        legend_parts.append(f"{COLOR_STYLES[level_for(max_count)]} high ({max_count})")

    BOLD_S = "\033[1m"
    lines = [
        *boxed_lines,
        "",
        f"{MUTED}First commit:{RESET} {first_commit}  {MUTED}·{RESET}  {MUTED}Recent commit:{RESET} {recent_commit}",
        f"{BOLD_S}{total_commits}{RESET} commits across {BOLD_S}{active_days}{RESET} active days"
        f"{DIM},{RESET} avg {BOLD_S}{average:.1f}{RESET} commits/day",
        f"{MUTED}Legend:{RESET} " + "  ".join(legend_parts),
    ]
    return "\n".join(lines)
