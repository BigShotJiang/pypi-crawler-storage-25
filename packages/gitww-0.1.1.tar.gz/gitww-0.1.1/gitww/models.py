from dataclasses import dataclass
from datetime import date
from pathlib import Path


@dataclass(frozen=True)
class AppConfig:
    repo: Path
    branch: str


@dataclass(frozen=True)
class Suggestion:
    start_day: date
    end_day: date
    total_commits: int
    commits: list[str]
    suggested_datetimes: list[str]
