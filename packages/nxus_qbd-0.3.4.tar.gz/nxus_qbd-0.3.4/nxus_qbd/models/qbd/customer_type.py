from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import QbdDataExt, QbdRef

class CustomerType(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the customer type. (Max 31 characters)')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    full_name: Annotated[str | None, Field(alias='fullName', description='The fully-qualified unique name for this object, formed by combining the names of its parent objects with its own `name`, separated by colons. Not case-sensitive.')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Customer Type is inactive. Default is true.')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseCustomerType(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[CustomerType] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateCustomerTypeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the customer type. (Max 31 characters)', max_length=31)]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) If false, this Customer Type is inactive. Default is true.')] = None
    parent_id: Annotated[str | None, Field(alias='parentId', description='(Optional) The ListID or FullName of the parent customer type. Used for hierarchical customer types.\nFollows the Flattened-ID Pattern for ParentRef.', max_length=50)] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateCustomerTypeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
