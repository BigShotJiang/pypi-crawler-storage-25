from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BarCodeRequest, Lines, QbdDataExt, QbdRef

class ItemInventoryAssembly(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    sku: str | None = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    cogs_account: Annotated[QbdRef | None, Field(alias='cogsAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    asset_account: Annotated[QbdRef | None, Field(alias='assetAccount')] = None
    build_point: Annotated[float | None, Field(alias='buildPoint')] = None
    max: float | None = None
    quantity_on_hand: Annotated[float | None, Field(alias='quantityOnHand')] = None
    total_value: Annotated[float | None, Field(alias='totalValue')] = None
    average_cost: Annotated[float | None, Field(alias='averageCost')] = None
    quantity_on_order: Annotated[float | None, Field(alias='quantityOnOrder')] = None
    quantity_on_sales_order: Annotated[float | None, Field(alias='quantityOnSalesOrder')] = None
    lines: Lines | None = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseItemInventoryAssembly(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemInventoryAssembly] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateItemInventoryAssemblyLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    inventory_item_id: Annotated[str | None, Field(alias='inventoryItemId')] = None
    quantity: float | None = None


class CreateItemInventoryAssemblyRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    income_account_id: Annotated[str | None, Field(alias='incomeAccountId')] = None
    asset_account_id: Annotated[str, Field(alias='assetAccountId')]
    cogs_account_id: Annotated[str | None, Field(alias='cogsAccountId')] = None
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    sku: str | None = None
    unit_of_measure_set_id: Annotated[str | None, Field(alias='unitOfMeasureSetId')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code_id: Annotated[str | None, Field(alias='purchaseTaxCodeId')] = None
    preferred_vendor_id: Annotated[str | None, Field(alias='preferredVendorId')] = None
    build_notification_threshold: Annotated[float | None, Field(alias='buildNotificationThreshold')] = None
    maximum_quantity_on_hand: Annotated[float | None, Field(alias='maximumQuantityOnHand')] = None
    quantity_on_hand: Annotated[float | None, Field(alias='quantityOnHand')] = None
    total_value: Annotated[float | None, Field(alias='totalValue')] = None
    inventory_date: Annotated[date_aliased | None, Field(alias='inventoryDate')] = None
    lines: Lines | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateItemInventoryAssemblyLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_inventory_id: Annotated[str | None, Field(alias='itemInventoryId')] = None
    quantity: float | None = None


class UpdateItemInventoryAssemblyRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    sku: str | None = None
    unit_of_measure_set_id: Annotated[str | None, Field(alias='unitOfMeasureSetId')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account_id: Annotated[str | None, Field(alias='incomeAccountId')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code_id: Annotated[str | None, Field(alias='purchaseTaxCodeId')] = None
    cogs_account_id: Annotated[str | None, Field(alias='cogsAccountId')] = None
    preferred_vendor_id: Annotated[str | None, Field(alias='preferredVendorId')] = None
    asset_account_id: Annotated[str | None, Field(alias='assetAccountId')] = None
    build_notification_threshold: Annotated[float | None, Field(alias='buildNotificationThreshold')] = None
    maximum_quantity_on_hand: Annotated[float | None, Field(alias='maximumQuantityOnHand')] = None
    lines: Lines | None = None
