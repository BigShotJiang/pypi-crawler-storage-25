from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import QbdDataExt, QbdRef

class Class(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description="(Required) The name of the class (up to 31 characters).\nNote: If the class is going to be a sub-class, this property should only contain the\nchild's name, not the full hierarchical name of its ancestors.", examples=['Kitchen'])] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    full_name: Annotated[str | None, Field(alias='fullName', description='The FullName is the name prefixed by the names of each ancestor, for example Parent:Child:SubClass. FullName values are not case-sensitive.', examples=['Jones:Kitchen:Cabinets'])] = None
    parent: QbdRef | None = None
    sublevel: Annotated[int | None, Field(description='A number indicating the number of ancestors. For example, The customer job with Name = carpets and FullName = Jones:Building2:carpets would have a sublevel of 2.', examples=['2'])] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the class is active. Defaults to true.')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseClass(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Class] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateClassRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description="(Required) The name of the class (up to 31 characters).\nNote: If the class is going to be a sub-class, this property should only contain the\nchild's name, not the full hierarchical name of its ancestors.", max_length=31)]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the class is active. Defaults to true.', examples=['true'])] = None
    parent_id: Annotated[str | None, Field(alias='parentId', description='(Optional) The ListID or FullName of the parent class.\nA reference to the list object that is exactly one level above this one.\nUsed to create sub-classes.', examples=['10000001-1039043346'])] = None


class UpdateClassRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(description='(Optional) The new name for the class.', examples=['Kitchen'], max_length=31)] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Update the active status of the class.', examples=['true'])] = None
    parent_id: Annotated[str | None, Field(alias='parentId', description='(Optional) The ListID or FullName of the parent class (to move this class).\nTo remove the class from its current parent and move it to the top level,\nprovide an empty string.', examples=['10000001-1039043346'])] = None
