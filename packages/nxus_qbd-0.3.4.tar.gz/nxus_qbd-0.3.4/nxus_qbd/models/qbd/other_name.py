from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressBlock, CustomFields, QbdDataExt

class OtherName(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    company_name: Annotated[str | None, Field(alias='companyName')] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    address: Annotated[Address | None, Field(description='The primary address for the "Other Name".')] = None
    address_block: Annotated[AddressBlock | None, Field(alias='addressBlock', description='The address formatted as a 5-line block.')] = None
    phone: str | None = None
    alternate_phone: Annotated[str | None, Field(alias='alternatePhone')] = None
    fax: str | None = None
    email: str | None = None
    contact: str | None = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    notes: str | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseOtherName(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[OtherName] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateOtherNameRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str | None = None
    company_name: Annotated[str | None, Field(alias='companyName')] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    address: Address | None = None
    address_block: Annotated[AddressBlock | None, Field(alias='addressBlock')] = None
    phone: str | None = None
    alternat_phone: Annotated[str | None, Field(alias='alternatPhone')] = None
    fax: str | None = None
    email: str | None = None
    contact: str | None = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    notes: str | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateOtherNameRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str | None = None
    company_name: Annotated[str | None, Field(alias='companyName')] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    address: Address | None = None
    address_block: Annotated[AddressBlock | None, Field(alias='addressBlock')] = None
    phone: str | None = None
    alternate_phone: Annotated[str | None, Field(alias='alternatePhone')] = None
    fax: str | None = None
    email: str | None = None
    contact: str | None = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    notes: str | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None
    revision_number: Annotated[str, Field(alias='revisionNumber')]
