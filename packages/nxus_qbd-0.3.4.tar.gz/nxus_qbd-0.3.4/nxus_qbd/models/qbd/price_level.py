from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import PerItemPriceLevels, QbdDataExt, QbdRef, SetCredits

class PriceLevel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the new price level. Max length: 31 characters.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    price_level_type: Annotated[str | None, Field(alias='priceLevelType', description='The type of price level: "FixedPercentage" or "PerItem".')] = None
    fixed_percentage: Annotated[float | None, Field(alias='fixedPercentage', description='The fixed percentage adjustment (only for FixedPercentage type).')] = None
    per_item_price_levels: Annotated[PerItemPriceLevels | None, Field(alias='perItemPriceLevels', description='List of per-item price level rules (only for PerItem type).')] = None
    currency: Annotated[QbdRef | None, Field(description='The currency associated with this price level.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the price level is active. Defaults to true.')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponsePriceLevel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[PriceLevel] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class PriceLevelPerItem(SetCredits):
    pass


class CreatePriceLevelRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the new price level. Max length: 31 characters.')]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the price level is active. Defaults to true.')] = None
    price_level_fixed_percentage: Annotated[float | None, Field(alias='priceLevelFixedPercentage', description='(Optional) The fixed percentage to adjust prices by. Mutually exclusive with PriceLevelPerItem list.')] = None
    price_level_per_item: Annotated[PriceLevelPerItem | None, Field(alias='priceLevelPerItem', description='(Optional) The list of custom pricing rules for specific items. Mutually exclusive with PriceLevelFixedPercentage.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description="(Optional) The ListID of the currency associated with this price level. Only used with 'per item' price levels.")] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class PriceLevelPerItemRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: Annotated[str, Field(alias='itemId', description='(Required) The ListID of the item to apply the price level rule to. (ItemRef, Flattened-ID Pattern)')]
    custom_price: Annotated[float | None, Field(alias='customPrice', description='(Optional) The specific custom price for the item. Mutually exclusive with CustomPricePercent and the Adjust fields. (PRICETYPE)')] = None
    custom_price_percent: Annotated[float | None, Field(alias='customPricePercent', description='(Optional) The custom price expressed as a percentage of the base price. Mutually exclusive with CustomPrice and the Adjust fields. (PERCENTTYPE)')] = None
    adjust_percentage: Annotated[float | None, Field(alias='adjustPercentage', description='(Optional) The percentage to adjust the price by. Required if AdjustRelativeTo is provided. Mutually exclusive with CustomPrice and CustomPricePercent. (PERCENTTYPE)')] = None
    adjust_relative_to: Annotated[str | None, Field(alias='adjustRelativeTo', description='(Optional) The base price to adjust relative to. Valid values: StandardPrice, Cost, CurrentCustomPrice. Required if AdjustPercentage is provided. Mutually exclusive with CustomPrice and CustomPricePercent. (ENUMTYPE)')] = None


class UpdatePriceLevelRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(description='(Optional) The new name for the price level. Max length: 31 characters.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the price level is active.')] = None
    price_level_fixed_percentage: Annotated[float | None, Field(alias='priceLevelFixedPercentage', description='(Optional) The fixed percentage to adjust prices by. Mutually exclusive with PriceLevelPerItem list.')] = None
    price_level_per_item: Annotated[PriceLevelPerItem | None, Field(alias='priceLevelPerItem', description='(Optional) The list of custom pricing rules for specific items. Replaces all existing rules. Mutually exclusive with PriceLevelFixedPercentage.')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description="(Optional) The ListID of the currency associated with this price level. Only used with 'per item' price levels.")] = None
