from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressBlock, AddressRequest, CreateCreditCardTransactionInfoRequest, CreditCardTransactionInfo, CustomFields, ExpenseLine, ItemGroupLine, ItemLine, LineGroups, Lines, LinkedTransaction, QbdDataExt, QbdRef

class CreditMemo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for the transaction.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., Credit Memo #).')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    customer: QbdRef | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    receivables_account: Annotated[QbdRef | None, Field(alias='receivablesAccount')] = None
    template: QbdRef | None = None
    billing_address: Annotated[Address | None, Field(alias='billingAddress')] = None
    billing_address_block: Annotated[AddressBlock | None, Field(alias='billingAddressBlock')] = None
    shipping_address: Annotated[Address | None, Field(alias='shippingAddress')] = None
    shipping_address_block: Annotated[AddressBlock | None, Field(alias='shippingAddressBlock')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending', description='(Optional) Indicates if the credit memo is pending.')] = None
    po_number: Annotated[str | None, Field(alias='poNumber')] = None
    terms: QbdRef | None = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date.')] = None
    sales_representative: Annotated[QbdRef | None, Field(alias='salesRepresentative')] = None
    fob: Annotated[str | None, Field(description='(Optional) Free On Board (FOB) terms. (Max 13 characters)')] = None
    ship_date: Annotated[date_aliased | None, Field(alias='shipDate', description='(Optional) The date of shipment.')] = None
    ship_method: Annotated[QbdRef | None, Field(alias='shipMethod')] = None
    subtotal: float | None = None
    item_sales_tax: Annotated[QbdRef | None, Field(alias='itemSalesTax')] = None
    sales_tax_percentage: Annotated[float | None, Field(alias='salesTaxPercentage')] = None
    sales_tax_total: Annotated[float | None, Field(alias='salesTaxTotal')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount')] = None
    credit_remaining: Annotated[float | None, Field(alias='creditRemaining')] = None
    credit_remaining_in_home_currency: Annotated[float | None, Field(alias='creditRemainingInHomeCurrency')] = None
    customer_msg: Annotated[QbdRef | None, Field(alias='customerMsg')] = None
    is_to_be_printed: Annotated[bool | None, Field(alias='isToBePrinted', description='(Optional) Indicates if the transaction is to be printed.')] = None
    is_to_be_emailed: Annotated[bool | None, Field(alias='isToBeEmailed', description='(Optional) Indicates if the transaction is to be emailed.')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) Indicates if tax is included in the amounts.')] = None
    customer_sales_tax_code: Annotated[QbdRef | None, Field(alias='customerSalesTaxCode')] = None
    other: Annotated[str | None, Field(description='(Optional) Other custom field. (Max 29 characters)')] = None
    lines: Annotated[Lines | None, Field(description='(Optional) Standard item lines for the credit memo.')] = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[list[LinkedTransaction] | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[list[ExpenseLine] | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[list[ItemLine] | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[list[ItemGroupLine] | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseCreditMemo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[CreditMemo] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateCreditMemoLineGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_group_id: Annotated[str, Field(alias='itemGroupId', description='(Required) The ListID or FullName of the Item Group.')]
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the group.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class CreateCreditMemoLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item.')] = None
    description: Annotated[str | None, Field(description='(Optional) Description of the line item.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    rate: Annotated[float | None, Field(description='(Optional) Rate or price per unit.')] = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent', description='(Optional) Rate expressed as a percentage.')] = None
    price_level_id: Annotated[str | None, Field(alias='priceLevelId', description='(Optional) The ListID or FullName of the price level.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class for this line.')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line.')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item.')] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) Service date for the item.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code for this line.')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId', description="(Optional) The ListID or FullName of the account to override the item's default account.")] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None
    credit_card_transaction_info: Annotated[CreateCreditCardTransactionInfoRequest | None, Field(alias='creditCardTransactionInfo')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class CreateCreditMemoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    customer_id: Annotated[str, Field(alias='customerId', description='(Required) The ListID or FullName of the customer.')]
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='(Optional) The ListID or FullName of the template to use.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., Credit Memo #).')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending', description='(Optional) Indicates if the credit memo is pending.')] = None
    purchase_order_number: Annotated[str | None, Field(alias='purchaseOrderNumber', description='(Optional) The purchase order number.')] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='(Optional) The ListID or FullName of the terms.')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date.')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    ship_date: Annotated[date_aliased | None, Field(alias='shipDate', description='(Optional) The date of shipment.')] = None
    ship_method_id: Annotated[str | None, Field(alias='shipMethodId', description='(Optional) The ListID or FullName of the shipping method.')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the sales tax item.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    customer_message_id: Annotated[str | None, Field(alias='customerMessageId')] = None
    is_to_be_printed: Annotated[bool | None, Field(alias='isToBePrinted', description='(Optional) Indicates if the transaction is to be printed.')] = None
    is_queued_for_email: Annotated[bool | None, Field(alias='isQueuedForEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) Indicates if tax is included in the amounts.')] = None
    customer_sales_tax_code_id: Annotated[str | None, Field(alias='customerSalesTaxCodeId', description='(Optional) The ListID or FullName of the customer sales tax code.')] = None
    other_custom_field: Annotated[str | None, Field(alias='otherCustomField')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for the transaction.')] = None
    lines: Annotated[Lines | None, Field(description='(Optional) Standard item lines for the credit memo.')] = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class CreditMemoLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    id: str
    item: QbdRef | None = None
    description: Annotated[str | None, Field(description='(Optional) Description of the line item.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    override_unit_of_measure_set: Annotated[QbdRef | None, Field(alias='overrideUnitOfMeasureSet')] = None
    rate: Annotated[float | None, Field(description='(Optional) Rate or price per unit.')] = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent', description='(Optional) Rate expressed as a percentage.')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line.')] = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item.')] = None
    expiration_date: Annotated[str | None, Field(alias='expirationDate')] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) Service date for the item.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None
    credit_card_transaction: Annotated[CreditCardTransactionInfo | None, Field(alias='creditCardTransaction')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class CreditMemoLineGroup(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item_group: Annotated[QbdRef | None, Field(alias='itemGroup')] = None
    description: str | None = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the group.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    override_unit_of_measure_set: Annotated[QbdRef | None, Field(alias='overrideUnitOfMeasureSet')] = None
    should_print_items_in_group: Annotated[bool | None, Field(alias='shouldPrintItemsInGroup')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount')] = None
    lines: Annotated[Lines | None, Field(description='(Optional) List of modifications for the individual items within this group.')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class UpdateCreditMemoLineGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_group_id: Annotated[str | None, Field(alias='itemGroupId', description='(Optional) The ListID or FullName of the Item Group.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the group.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    override_uom_set_id: Annotated[str | None, Field(alias='overrideUomSetId', description='(Optional) The ListID or FullName of the override UOM set.')] = None
    lines: Annotated[Lines | None, Field(description='(Optional) List of modifications for the individual items within this group.')] = None


class UpdateCreditMemoLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item.')] = None
    description: Annotated[str | None, Field(description='(Optional) Description of the line item.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    override_uom_set_id: Annotated[str | None, Field(alias='overrideUomSetId', description='(Optional) The ListID or FullName of the UOM set to override.')] = None
    rate: Annotated[float | None, Field(description='(Optional) Rate or price per unit.')] = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent', description='(Optional) Rate expressed as a percentage.')] = None
    price_level_id: Annotated[str | None, Field(alias='priceLevelId', description='(Optional) The ListID or FullName of the price level.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class for this line.')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line.')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item.')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item.')] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) Service date for the item.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code for this line.')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId', description="(Optional) The ListID or FullName of the account to override the item's default account.")] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None


class UpdateCreditMemoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    receiveables_account_id: Annotated[str | None, Field(alias='receiveablesAccountId')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='(Optional) The ListID or FullName of the template.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number.')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending', description='(Optional) Indicates if the credit memo is pending.')] = None
    purchase_order_number: Annotated[str | None, Field(alias='purchaseOrderNumber', description='(Optional) The purchase order number.')] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='(Optional) The ListID or FullName of the terms.')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date.')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    shipping_origin: Annotated[str | None, Field(alias='shippingOrigin')] = None
    ship_date: Annotated[date_aliased | None, Field(alias='shipDate', description='(Optional) The date of shipment.')] = None
    ship_method_id: Annotated[str | None, Field(alias='shipMethodId', description='(Optional) The ListID or FullName of the shipping method.')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the sales tax item.')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the transaction.')] = None
    customer_message_id: Annotated[str | None, Field(alias='customerMessageId')] = None
    is_queued_to_print: Annotated[bool | None, Field(alias='isQueuedToPrint')] = None
    is_queued_to_email: Annotated[bool | None, Field(alias='isQueuedToEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) Indicates if tax is included in the amounts.')] = None
    customer_sales_tax_code_id: Annotated[str | None, Field(alias='customerSalesTaxCodeId', description='(Optional) The ListID or FullName of the customer sales tax code.')] = None
    other_custom_field: Annotated[str | None, Field(alias='otherCustomField')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for the transaction.')] = None
    lines: Annotated[Lines | None, Field(description='(Optional) List of modifications for standard item lines.')] = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
