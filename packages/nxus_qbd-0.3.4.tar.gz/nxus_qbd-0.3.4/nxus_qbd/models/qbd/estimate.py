from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressRequest, CustomFields, DataExt, ExpenseLine, ItemGroupLines, ItemLines, LineGroups, LineItemGroups, LineItems, Lines, LinkedTransactions, QbdDataExt, QbdRef

class Estimate(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate', description='(Optional) The date of the transaction. Cannot be cleared. (DATETYPE)')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for multi-currency transactions. (FLOATTYPE)')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The sequential reference number for the Estimate (e.g., Estimate Number). (STRTYPE)')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the entire transaction. (STRTYPE)')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    customer: QbdRef | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    template: QbdRef | None = None
    billing_address: Annotated[Address | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[Address | None, Field(alias='shippingAddress')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the Estimate is active. (BOOLTYPE)')] = None
    po_number: Annotated[str | None, Field(alias='poNumber', description="(Optional) Customer's Purchase Order number. (STRTYPE)")] = None
    terms: QbdRef | None = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date calculated from the terms. (DATETYPE)')] = None
    sales_representative: Annotated[QbdRef | None, Field(alias='salesRepresentative')] = None
    fob: Annotated[str | None, Field(description='(Optional) Freight on Board term. (STRTYPE)')] = None
    subtotal: float | None = None
    item_sales_tax: Annotated[QbdRef | None, Field(alias='itemSalesTax')] = None
    sales_tax_percentage: Annotated[float | None, Field(alias='salesTaxPercentage')] = None
    sales_tax_total: Annotated[float | None, Field(alias='salesTaxTotal')] = None
    total_amount_in_home_currency: Annotated[float | None, Field(alias='totalAmountInHomeCurrency')] = None
    customer_msg: Annotated[QbdRef | None, Field(alias='customerMsg')] = None
    is_to_be_emailed: Annotated[bool | None, Field(alias='isToBeEmailed', description='(Optional) Whether the Estimate should be flagged to be emailed. (BOOLTYPE)')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) Whether tax is included in the line item amounts. (BOOLTYPE)')] = None
    customer_sales_tax_code: Annotated[QbdRef | None, Field(alias='customerSalesTaxCode')] = None
    linked_transactions: Annotated[LinkedTransactions | None, Field(alias='linkedTransactions')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines')] = None
    other: Annotated[str | None, Field(description='(Optional) The Other field for the transaction. (STRTYPE)')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    expense_lines: Annotated[list[ExpenseLine] | None, Field(alias='expenseLines')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseEstimate(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Estimate] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateEstimateLineGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_group_id: Annotated[str, Field(alias='itemGroupId', description='(Required) The ListID or FullName of the item group. (ItemGroupRef, Flattened-ID Pattern)')]
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item group. (QUANTYPE)')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure for the quantity. (STRTYPE)')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the Inventory Site. (InventorySiteRef, Flattened-ID Pattern)')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the Inventory Site Location. (InventorySiteLocationRef, Flattened-ID Pattern)')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class CreateEstimateLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str | None = None
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item_id: Annotated[str | None, Field(alias='itemId')] = None
    description: str | None = None
    quantity: float | None = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    rate: float | None = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    amount: float | None = None
    option_for_price_rule_conflict: Annotated[str | None, Field(alias='optionForPriceRuleConflict')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    markup_rate: Annotated[float | None, Field(alias='markupRate')] = None
    markup_rate_percent: Annotated[float | None, Field(alias='markupRatePercent')] = None
    price_level_id: Annotated[str | None, Field(alias='priceLevelId')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId')] = None
    other1: str | None = None
    other2: str | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class CreateEstimateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    customer_id: Annotated[str, Field(alias='customerId', description='(Required) The ListID or FullName of the customer or job. (CustomerRef, Flattened-ID Pattern)')]
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with the entire transaction. (ClassRef, Flattened-ID Pattern)')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='(Optional) The ListID or FullName of the template to use for the Estimate. (TemplateRef, Flattened-ID Pattern)')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The sequential reference number for the Estimate (e.g., Estimate Number). (STRTYPE)')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the Estimate is active. (BOOLTYPE)')] = None
    purchase_order_number: Annotated[str | None, Field(alias='purchaseOrderNumber')] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='(Optional) The ListID or FullName of the payment terms for the Estimate. (TermsRef, Flattened-ID Pattern)')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date calculated from the terms. (DATETYPE)')] = None
    sales_rep_id: Annotated[str | None, Field(alias='salesRepId', description='(Optional) The ListID or FullName of the Sales Rep. (SalesRepRef, Flattened-ID Pattern)')] = None
    shippment_origin: Annotated[str | None, Field(alias='shippmentOrigin')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the sales tax item that applies to the entire Estimate. (ItemSalesTaxRef, Flattened-ID Pattern)')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the entire transaction. (STRTYPE)')] = None
    customer_message_id: Annotated[str | None, Field(alias='customerMessageId', description='(Optional) The ListID or FullName of the Customer Message to appear on the form. (CustomerMsgRef, Flattened-ID Pattern)')] = None
    is_queued_for_emailed: Annotated[bool | None, Field(alias='isQueuedForEmailed')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) Whether tax is included in the line item amounts. (BOOLTYPE)')] = None
    customer_sales_tax_code_id: Annotated[str | None, Field(alias='customerSalesTaxCodeId', description='(Optional) The ListID or FullName of the Customer Sales Tax Code. (CustomerSalesTaxCodeRef, Flattened-ID Pattern)')] = None
    other: Annotated[str | None, Field(description='(Optional) The Other field for the transaction. (STRTYPE)')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for multi-currency transactions. (FLOATTYPE)')] = None
    line_items: Annotated[LineItems | None, Field(alias='lineItems', description='(Optional) List of standard Estimate lines (EstimateLineAdd). Mutually exclusive with LineItemGroups.')] = None
    line_item_groups: Annotated[LineItemGroups | None, Field(alias='lineItemGroups', description='(Optional) List of item group lines (EstimateLineGroupAdd). Mutually exclusive with LineItems.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    data_ext: Annotated[DataExt | None, Field(alias='dataExt', description='(Optional) List of custom fields (DataExt) for the Estimate. (DataExtRequest)')] = None


class EstimateItemGroupLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item_group: Annotated[QbdRef | None, Field(alias='itemGroup')] = None
    description: str | None = None
    quantity: float | None = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    override_unit_of_measure_set: Annotated[QbdRef | None, Field(alias='overrideUnitOfMeasureSet')] = None
    is_print_items_in_group: Annotated[bool | None, Field(alias='isPrintItemsInGroup')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class EstimateItemLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item: QbdRef | None = None
    description: str | None = None
    quantity: float | None = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    override_unit_of_measure_set: Annotated[QbdRef | None, Field(alias='overrideUnitOfMeasureSet')] = None
    rate: float | None = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    amount: float | None = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    markup_rate: Annotated[float | None, Field(alias='markupRate')] = None
    markup_rate_percent: Annotated[float | None, Field(alias='markupRatePercent')] = None
    other: str | None = None
    other2: str | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class UpdateEstimateLineGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_group_id: Annotated[str | None, Field(alias='itemGroupId', description='(Optional) The ListID or FullName of the item group. (ItemGroupRef, Flattened-ID Pattern)')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item group. (QUANTYPE)')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure for the quantity. (STRTYPE)')] = None
    override_unit_of_m_set_id: Annotated[str | None, Field(alias='overrideUnitOfMSetId')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the Inventory Site. (InventorySiteRef, Flattened-ID Pattern)')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the Inventory Site Location. (InventorySiteLocationRef, Flattened-ID Pattern)')] = None
    lines: Lines | None = None


class UpdateEstimateLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    txn_line_id: Annotated[str, Field(alias='txnLineId', description='(Required) The TxnLineID of the specific line item being modified or deleted. (IDTYPE)')]
    id: str | None = None
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item_id: Annotated[str | None, Field(alias='itemId')] = None
    description: str | None = None
    quantity: float | None = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    rate: float | None = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    amount: float | None = None
    option_for_price_rule_conflict: Annotated[str | None, Field(alias='optionForPriceRuleConflict')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    markup_rate: Annotated[float | None, Field(alias='markupRate')] = None
    markup_rate_percent: Annotated[float | None, Field(alias='markupRatePercent')] = None
    price_level_id: Annotated[str | None, Field(alias='priceLevelId')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId')] = None
    other1: str | None = None
    other2: str | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class UpdateEstimateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job. Cannot be cleared. (CustomerRef, Flattened-ID Pattern)')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with the entire transaction. (ClassRef, Flattened-ID Pattern)')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='(Optional) The ListID or FullName of the template to use for the Estimate. Cannot be cleared. (TemplateRef, Flattened-ID Pattern)')] = None
    transaction_date: Annotated[FlexibleDatetime | None, Field(alias='transactionDate', description='(Optional) The date of the transaction. Cannot be cleared. (DATETYPE)')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The sequential reference number for the Estimate (e.g., Estimate Number). (STRTYPE)')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Whether the Estimate is active. Cannot be cleared. (BOOLTYPE)')] = None
    create_change_order: Annotated[bool | None, Field(alias='createChangeOrder', description='(Optional) Indicates whether a Change Order should be created. (BOOLTYPE)')] = None
    po_number: Annotated[str | None, Field(alias='poNumber', description="(Optional) Customer's Purchase Order number. (STRTYPE)")] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='(Optional) The ListID or FullName of the payment terms for the Estimate. (TermsRef, Flattened-ID Pattern)')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date calculated from the terms. Cannot be cleared. (DATETYPE)')] = None
    sales_rep_id: Annotated[str | None, Field(alias='salesRepId', description='(Optional) The ListID or FullName of the Sales Rep. (SalesRepRef, Flattened-ID Pattern)')] = None
    fob: Annotated[str | None, Field(description='(Optional) Freight on Board term. (STRTYPE)')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the sales tax item that applies to the entire Estimate. Cannot be cleared. (ItemSalesTaxRef, Flattened-ID Pattern)')] = None
    memo: Annotated[str | None, Field(description='(Optional) A memo for the entire transaction. (STRTYPE)')] = None
    customer_message_id: Annotated[str | None, Field(alias='customerMessageId', description='(Optional) The ListID or FullName of the Customer Message to appear on the form. (CustomerMsgRef, Flattened-ID Pattern)')] = None
    is_to_be_emailed: Annotated[bool | None, Field(alias='isToBeEmailed', description='(Optional) Whether the Estimate should be flagged to be emailed. (BOOLTYPE)')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) Whether tax is included in the line item amounts. (BOOLTYPE)')] = None
    customer_sales_tax_code_id: Annotated[str | None, Field(alias='customerSalesTaxCodeId', description='(Optional) The ListID or FullName of the Customer Sales Tax Code. (CustomerSalesTaxCodeRef, Flattened-ID Pattern)')] = None
    other_custom_field: Annotated[str | None, Field(alias='otherCustomField')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) The exchange rate for multi-currency transactions. (FLOATTYPE)')] = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
