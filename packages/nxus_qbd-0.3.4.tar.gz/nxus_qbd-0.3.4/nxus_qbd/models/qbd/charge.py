from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import ExpenseLine, ItemGroupLine, ItemLine, LinkedTransaction, QbdDataExt, QbdRef

class Charge(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number.')] = None
    memo: str | None = None
    txn_number: Annotated[int | None, Field(alias='txnNumber')] = None
    customer: QbdRef | None = None
    item: QbdRef | None = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    override_unit_of_measure_set: Annotated[QbdRef | None, Field(alias='overrideUnitOfMeasureSet')] = None
    override_item_account: Annotated[QbdRef | None, Field(alias='overrideItemAccount')] = None
    rate: Annotated[float | None, Field(description='(Optional) The rate or price per unit.')] = None
    balance_remaining: Annotated[float | None, Field(alias='balanceRemaining')] = None
    description: Annotated[str | None, Field(description='(Optional) Description of the charge.')] = None
    receivables_account: Annotated[QbdRef | None, Field(alias='receivablesAccount')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    billed_date: Annotated[date_aliased | None, Field(alias='billedDate', description='(Optional) The date the charge was billed.')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date for the charge.')] = None
    is_paid: Annotated[bool | None, Field(alias='isPaid')] = None
    amount: Annotated[float | None, Field(description='(Optional) The total amount of the charge.')] = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[list[LinkedTransaction] | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[list[ExpenseLine] | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[list[ItemLine] | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[list[ItemGroupLine] | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseCharge(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Charge] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateChargeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    customer_id: Annotated[str, Field(alias='customerId', description='(Required) The ListID or FullName of the customer.')]
    item_id: Annotated[str, Field(alias='itemId', description='(Required) The ListID or FullName of the item.')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number.')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    rate: Annotated[float | None, Field(description='(Optional) The rate or price per unit.')] = None
    option_for_price_rule_conflict: Annotated[str | None, Field(alias='optionForPriceRuleConflict', description='(Optional) Strategy for resolving price rule conflicts (Zero, BasePrice).')] = None
    amount: Annotated[float | None, Field(description='(Optional) The total amount of the charge.')] = None
    description: Annotated[str | None, Field(description='(Optional) Description of the charge.')] = None
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    billed_date: Annotated[date_aliased | None, Field(alias='billedDate', description='(Optional) The date the charge was billed.')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date for the charge.')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId', description='(Optional) The ListID or FullName of the override item account.')] = None


class UpdateChargeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The reference number (e.g., Invoice #).')] = None
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item.')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure.')] = None
    override_uom_set_id: Annotated[str | None, Field(alias='overrideUomSetId', description='(Optional) The ListID or FullName of the override unit of measure set.')] = None
    rate: Annotated[float | None, Field(description='(Optional) The rate or price per unit.')] = None
    option_for_price_rule_conflict: Annotated[str | None, Field(alias='optionForPriceRuleConflict', description='(Optional) Strategy for resolving price rule conflicts (Zero, BasePrice).')] = None
    amount: Annotated[float | None, Field(description='(Optional) The total amount of the charge.')] = None
    description: Annotated[str | None, Field(description='(Optional) Description of the charge.')] = None
    receivables_account_id: Annotated[str | None, Field(alias='receivablesAccountId')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    billed_date: Annotated[date_aliased | None, Field(alias='billedDate', description='(Optional) The date the charge was billed.')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The due date for the charge.')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId', description='(Optional) The ListID or FullName of the override item account.')] = None
