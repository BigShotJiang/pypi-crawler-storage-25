from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BarCodeRequest, DataExt, QbdDataExt, QbdRef

class ServiceItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    desc: str | None = None
    price: float | None = None
    price_percent: Annotated[float | None, Field(alias='pricePercent')] = None
    account: QbdRef | None = None
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    expense_account: Annotated[QbdRef | None, Field(alias='expenseAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseServiceItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ServiceItem] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateSalesAndPurchaseRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account_id: Annotated[str | None, Field(alias='incomeAccountId')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code_id: Annotated[str | None, Field(alias='purchaseTaxCodeId')] = None
    expense_account_id: Annotated[str | None, Field(alias='expenseAccountId')] = None
    pref_vendor_id: Annotated[str | None, Field(alias='prefVendorId')] = None


class CreateSalesOrPurchaseRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    description: str | None = None
    price: float | None = None
    price_percent: Annotated[float | None, Field(alias='pricePercent')] = None
    account_id: Annotated[str | None, Field(alias='accountId')] = None


class CreateServiceItemRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    unit_of_measure_set_id: Annotated[str | None, Field(alias='unitOfMeasureSetId')] = None
    force_uom_change: Annotated[bool | None, Field(alias='forceUOMChange')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    data_ext: Annotated[DataExt | None, Field(alias='dataExt')] = None
    sales_or_purchase: Annotated[CreateSalesOrPurchaseRequest | None, Field(alias='salesOrPurchase')] = None
    sales_and_purchase: Annotated[CreateSalesAndPurchaseRequest | None, Field(alias='salesAndPurchase')] = None


class UpdateSalesAndPurchaseRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account_id: Annotated[str | None, Field(alias='incomeAccountId')] = None
    apply_income_account_to_existing_transactions: Annotated[bool | None, Field(alias='applyIncomeAccountToExistingTransactions')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code_id: Annotated[str | None, Field(alias='purchaseTaxCodeId')] = None
    expense_account_id: Annotated[str | None, Field(alias='expenseAccountId')] = None
    apply_expense_account_to_existing_transactions: Annotated[bool | None, Field(alias='applyExpenseAccountToExistingTransactions')] = None
    pref_vendor_id: Annotated[str | None, Field(alias='prefVendorId')] = None


class UpdateSalesOrPurchaseRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    description: str | None = None
    price: float | None = None
    price_percent: Annotated[float | None, Field(alias='pricePercent')] = None
    account_id: Annotated[str | None, Field(alias='accountId')] = None
    apply_account_to_existing_transactions: Annotated[bool | None, Field(alias='applyAccountToExistingTransactions')] = None


class UpdateServiceItemRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    unit_of_measure_set_id: Annotated[str | None, Field(alias='unitOfMeasureSetId')] = None
    force_uom_change: Annotated[bool | None, Field(alias='forceUOMChange')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    apply_account_to_existing_transactions: Annotated[bool | None, Field(alias='applyAccountToExistingTransactions')] = None
    apply_income_account_to_existing_transactions: Annotated[bool | None, Field(alias='applyIncomeAccountToExistingTransactions')] = None
    apply_expense_account_to_existing_transactions: Annotated[bool | None, Field(alias='applyExpenseAccountToExistingTransactions')] = None
    sales_or_purchase_mod: Annotated[UpdateSalesOrPurchaseRequest | None, Field(alias='salesOrPurchaseMod')] = None
    sales_and_purchase_mod: Annotated[UpdateSalesAndPurchaseRequest | None, Field(alias='salesAndPurchaseMod')] = None
    include_ret_element: Annotated[list[str] | None, Field(alias='includeRetElement')] = None
