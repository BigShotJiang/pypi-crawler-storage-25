from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import QbdDataExt, QbdRef

class ItemPayment(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc')] = None
    deposit_to_account: Annotated[QbdRef | None, Field(alias='depositToAccount')] = None
    payment_method: Annotated[QbdRef | None, Field(alias='paymentMethod')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseItemPayment(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemPayment] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateItemPaymentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    description: str | None = None
    deposit_to_account_id: Annotated[str | None, Field(alias='depositToAccountId')] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateItemPaymentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    description: str | None = None
    deposit_to_account_id: Annotated[str | None, Field(alias='depositToAccountId')] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId')] = None
