from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import AdditionalContacts, AdditionalNotes, Address, AddressRequest, CustomContactFields, DefaultExpenseAccounts, QbdDataExt, QbdRef

class Vendor(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    company_name: Annotated[str | None, Field(alias='companyName', description='The company or business name of the vendor.')] = None
    salutation: Annotated[str | None, Field(description='Salutation/title for the vendor\'s contact person (e.g., "Mr.", "Dr.").')] = None
    first_name: Annotated[str | None, Field(alias='firstName', description="First name of the vendor's contact person.")] = None
    middle_name: Annotated[str | None, Field(alias='middleName', description="Middle name of the vendor's contact person.")] = None
    last_name: Annotated[str | None, Field(alias='lastName', description="Last name of the vendor's contact person.")] = None
    job_title: Annotated[str | None, Field(alias='jobTitle', description="Job title of the vendor's primary contact.")] = None
    phone: Annotated[str | None, Field(description='Primary phone number for the vendor.')] = None
    alternate_phone: Annotated[str | None, Field(alias='alternatePhone')] = None
    fax: Annotated[str | None, Field(description='Fax number for the vendor.')] = None
    email: Annotated[str | None, Field(description='Primary email address for the vendor.')] = None
    cc_email: Annotated[str | None, Field(alias='ccEmail')] = None
    contact: Annotated[str | None, Field(description="Name of the primary contact at the vendor's company.")] = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    name_on_check: Annotated[str | None, Field(alias='nameOnCheck', description='Name printed on checks issued to this vendor.')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber', description='Your account number with this vendor.')] = None
    note: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class', description='The class assigned to this vendor for departmental tracking.')] = None
    vendor_type: Annotated[QbdRef | None, Field(alias='vendorType', description='The vendor type category assigned to this vendor.')] = None
    terms: Annotated[QbdRef | None, Field(description='The default payment terms for this vendor (e.g., "Net 30").')] = None
    billing_rate: Annotated[QbdRef | None, Field(alias='billingRate', description='The billing rate used when tracking time for this vendor.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode', description='The sales tax code assigned to this vendor.')] = None
    sales_tax_return: Annotated[QbdRef | None, Field(alias='salesTaxReturn', description='The sales tax return account for this tax-agency vendor.')] = None
    purchase_tax_account: Annotated[QbdRef | None, Field(alias='purchaseTaxAccount')] = None
    sales_tax_account: Annotated[QbdRef | None, Field(alias='salesTaxAccount')] = None
    currency: Annotated[QbdRef | None, Field(description='The currency used for transactions with this vendor (multi-currency files only).')] = None
    default_expense_accounts: Annotated[list[QbdRef] | None, Field(alias='defaultExpenseAccounts')] = None
    billing_address: Annotated[Address | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[Address | None, Field(alias='shippingAddress')] = None
    custom_contact_fields: Annotated[list[CustomContactField] | None, Field(alias='customContactFields', description='Custom contact fields (name/value pairs) defined for this vendor.')] = None
    additional_contacts: Annotated[list[Contact] | None, Field(alias='additionalContacts', description='Additional contacts associated with this vendor.')] = None
    additional_notes: Annotated[list[AdditionalNote] | None, Field(alias='additionalNotes', description='Additional notes attached to this vendor record.')] = None
    balance: Annotated[float | None, Field(description='Current outstanding balance owed to this vendor.')] = None
    credit_limit: Annotated[float | None, Field(alias='creditLimit', description='Maximum credit limit extended by this vendor.')] = None
    tax_identification_number: Annotated[str | None, Field(alias='taxIdentificationNumber')] = None
    is_eligible_for1099: Annotated[bool | None, Field(alias='isEligibleFor1099')] = None
    is_tax_agency: Annotated[bool | None, Field(alias='isTaxAgency', description='Whether this vendor is a tax agency (e.g., IRS, state revenue department).')] = None
    sales_tax_country: Annotated[str | None, Field(alias='salesTaxCountry', description='The country to which this tax agency remits sales tax.')] = None
    is_sales_tax_agency: Annotated[bool | None, Field(alias='isSalesTaxAgency', description='Whether this vendor is configured as a sales tax agency.')] = None
    tax_registration_number: Annotated[str | None, Field(alias='taxRegistrationNumber', description="The vendor's tax registration number (used for international tax compliance).")] = None
    reporting_period: Annotated[str | None, Field(alias='reportingPeriod', description='The reporting period for sales tax remittance (e.g., "Monthly", "Quarterly").')] = None
    is_tracking_purchase_tax: Annotated[bool | None, Field(alias='isTrackingPurchaseTax')] = None
    is_tracking_sales_tax: Annotated[bool | None, Field(alias='isTrackingSalesTax')] = None
    is_compounding_tax: Annotated[bool | None, Field(alias='isCompoundingTax')] = None
    external_id: Annotated[UUID | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseVendor(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Vendor] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateVendorRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    company_name: Annotated[str | None, Field(alias='companyName')] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    job_title: Annotated[str | None, Field(alias='jobTitle')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    phone: str | None = None
    alternate_phone: Annotated[str | None, Field(alias='alternatePhone')] = None
    fax: str | None = None
    email: str | None = None
    cc_email: Annotated[str | None, Field(alias='ccEmail')] = None
    contact: str | None = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    custom_contact_fields: Annotated[list[CustomContactField] | None, Field(alias='customContactFields')] = None
    additional_contacts: Annotated[list[Contact] | None, Field(alias='additionalContacts')] = None
    name_on_check: Annotated[str | None, Field(alias='nameOnCheck')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    notes: str | None = None
    additional_notes: Annotated[list[AdditionalNote] | None, Field(alias='additionalNotes')] = None
    vendor_type_id: Annotated[str | None, Field(alias='vendorTypeId')] = None
    terms_id: Annotated[str | None, Field(alias='termsId')] = None
    credit_limit: Annotated[float | None, Field(alias='creditLimit')] = None
    tax_identification_number: Annotated[str | None, Field(alias='taxIdentificationNumber')] = None
    is_eligible_for1099: Annotated[bool | None, Field(alias='isEligibleFor1099')] = None
    opening_balance: Annotated[float | None, Field(alias='openingBalance')] = None
    opening_balance_date: Annotated[date_aliased | None, Field(alias='openingBalanceDate')] = None
    billing_rate_id: Annotated[str | None, Field(alias='billingRateId')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    sales_tax_country: Annotated[str | None, Field(alias='salesTaxCountry')] = None
    is_sales_tax_agency: Annotated[bool | None, Field(alias='isSalesTaxAgency')] = None
    sales_tax_return_id: Annotated[str | None, Field(alias='salesTaxReturnId')] = None
    tax_registration_number: Annotated[str | None, Field(alias='taxRegistrationNumber')] = None
    reporting_period: Annotated[str | None, Field(alias='reportingPeriod')] = None
    is_tracking_purchase_tax: Annotated[bool | None, Field(alias='isTrackingPurchaseTax')] = None
    purchase_tax_account_id: Annotated[str | None, Field(alias='purchaseTaxAccountId')] = None
    is_tax_tracked_on_sales: Annotated[bool | None, Field(alias='isTaxTrackedOnSales')] = None
    sales_tax_account_id: Annotated[str | None, Field(alias='salesTaxAccountId')] = None
    is_compounding_tax: Annotated[bool | None, Field(alias='isCompoundingTax')] = None
    default_expense_account_ids: Annotated[list[str] | None, Field(alias='defaultExpenseAccountIds')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateVendorRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    company_name: Annotated[str | None, Field(alias='companyName')] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    job_title: Annotated[str | None, Field(alias='jobTitle')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    phone: str | None = None
    alternate_phone: Annotated[str | None, Field(alias='alternatePhone')] = None
    fax: str | None = None
    email: str | None = None
    cc_email: Annotated[str | None, Field(alias='ccEmail')] = None
    contact: str | None = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    custom_contact_fields: Annotated[list[CustomContactField] | None, Field(alias='customContactFields')] = None
    additional_contacts: Annotated[list[Contact] | None, Field(alias='additionalContacts')] = None
    name_on_check: Annotated[str | None, Field(alias='nameOnCheck')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    note: str | None = None
    additional_notes: Annotated[list[AdditionalNote] | None, Field(alias='additionalNotes')] = None
    vendor_type_id: Annotated[str | None, Field(alias='vendorTypeId')] = None
    terms_id: Annotated[str | None, Field(alias='termsId')] = None
    credit_limit: Annotated[float | None, Field(alias='creditLimit')] = None
    tax_identification_number: Annotated[str | None, Field(alias='taxIdentificationNumber')] = None
    is_eligible_for1099: Annotated[bool | None, Field(alias='isEligibleFor1099')] = None
    billing_rate_id: Annotated[str | None, Field(alias='billingRateId')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    sales_tax_country: Annotated[str | None, Field(alias='salesTaxCountry')] = None
    is_sales_tax_agency: Annotated[bool | None, Field(alias='isSalesTaxAgency')] = None
    sales_tax_return_id: Annotated[str | None, Field(alias='salesTaxReturnId')] = None
    tax_registration_number: Annotated[str | None, Field(alias='taxRegistrationNumber')] = None
    reporting_period: Annotated[str | None, Field(alias='reportingPeriod')] = None
    is_tracking_purchase_tax: Annotated[bool | None, Field(alias='isTrackingPurchaseTax')] = None
    purchase_tax_account_id: Annotated[str | None, Field(alias='purchaseTaxAccountId')] = None
    is_tracking_sales_tax: Annotated[bool | None, Field(alias='isTrackingSalesTax')] = None
    sales_tax_account_id: Annotated[str | None, Field(alias='salesTaxAccountId')] = None
    is_compounding_tax: Annotated[bool | None, Field(alias='isCompoundingTax')] = None
    default_expense_account_ids: Annotated[list[str] | None, Field(alias='defaultExpenseAccountIds')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId')] = None
