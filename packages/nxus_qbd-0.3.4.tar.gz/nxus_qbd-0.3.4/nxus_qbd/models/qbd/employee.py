from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import AdditionalContacts, AdditionalNotes, QbdDataExt, QbdRef

class AdditionalContact(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str | None = None
    value: str | None = None
    relation: Annotated[str | None, Field(description='Relation for emergency contacts only. Values: Spouse, Partner, Mother, Father, Sister, Brother, Son, Daughter, Friend, Other')] = None


class EmergencyContact(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    primary_contact: Annotated[AdditionalContact | None, Field(alias='primaryContact', description="The employee's primary emergency contact.")] = None
    secondary_contact: Annotated[AdditionalContact | None, Field(alias='secondaryContact', description="The employee's secondary emergency contact.")] = None


class EmployeeAddress(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    line1: str | None = None
    line2: str | None = None
    line3: str | None = None
    line4: str | None = None
    line5: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: Annotated[str | None, Field(alias='postalCode')] = None
    country: str | None = None
    note: str | None = None


class SickHours(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    hours_available: Annotated[str | None, Field(alias='hoursAvailable', description='The total number of sick hours currently available for the employee to use, in ISO 8601 format for time intervals (PTnHnMnS). For example, 1 hour and 30 minutes is represented as PT1H30M. Defaults to 0.')] = None
    accrual_period: Annotated[str | None, Field(alias='accrualPeriod', description="How frequently the employee's sick hours are accrued.")] = None
    hours_accrued: Annotated[str | None, Field(alias='hoursAccrued')] = None
    maximum_hours: Annotated[str | None, Field(alias='maximumHours', description='The maximum number of sick hours the employee can accrue, in ISO 8601 format for time intervals (PTnHnMnS). For example, 1 hour and 30 minutes is represented as PT1H30M.')] = None
    is_resetting_hours_each_new_year: Annotated[bool | None, Field(alias='isResettingHoursEachNewYear')] = None
    hours_used: Annotated[str | None, Field(alias='hoursUsed', description='The number of sick hours the employee has used, in ISO 8601 format for time intervals (PTnHnMnS). For example, 1 hour and 30 minutes is represented as PT1H30M.')] = None
    year_begins_date: Annotated[date_aliased | None, Field(alias='yearBeginsDate')] = None
    accrual_start_date: Annotated[date_aliased | None, Field(alias='accrualStartDate', description="The date the employee's sick hours began to accrue, in ISO 8601 format (YYYY-MM-DD).")] = None


class VacationHours(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    hours_available: Annotated[str | None, Field(alias='hoursAvailable', description='The total number of vacation hours currently available for the employee to use, in ISO 8601 format for time intervals (PTnHnMnS). For example, 1 hour and 30 minutes is represented as PT1H30M. Defaults to 0.')] = None
    accrual_period: Annotated[str | None, Field(alias='accrualPeriod', description="How frequently the employee's vacation hours are accrued.")] = None
    hours_accrued: Annotated[str | None, Field(alias='hoursAccrued')] = None
    maximum_hours: Annotated[str | None, Field(alias='maximumHours', description='The maximum number of vacation hours the employee can accrue, in ISO 8601 format for time intervals (PTnHnMnS). For example, 1 hour and 30 minutes is represented as PT1H30M.')] = None
    is_resetting_hours_each_new_year: Annotated[bool | None, Field(alias='isResettingHoursEachNewYear')] = None
    hours_used: Annotated[str | None, Field(alias='hoursUsed', description='The number of vacation hours the employee has used, in ISO 8601 format for time intervals (PTnHnMnS). For example, 1 hour and 30 minutes is represented as PT1H30M.')] = None
    year_begins_date: Annotated[date_aliased | None, Field(alias='yearBeginsDate')] = None
    accrual_start_date: Annotated[date_aliased | None, Field(alias='accrualStartDate', description="The date the employee's vacation hours began to accrue, in ISO 8601 format (YYYY-MM-DD).")] = None


class EmployeePayrollInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    pay_period: Annotated[str | None, Field(alias='payPeriod')] = None
    pay_schedule: Annotated[QbdRef | None, Field(alias='paySchedule')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    clear_earnings: Annotated[bool | None, Field(alias='clearEarnings')] = None
    clear_non_earnings: Annotated[bool | None, Field(alias='clearNonEarnings')] = None
    use_time_data_to_create_paychecks: Annotated[str | None, Field(alias='useTimeDataToCreatePaychecks')] = None
    sick_hours: Annotated[SickHours | None, Field(alias='sickHours')] = None
    vacation_hours: Annotated[VacationHours | None, Field(alias='vacationHours')] = None


class Employee(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    job_title: Annotated[str | None, Field(alias='jobTitle')] = None
    supervisor: QbdRef | None = None
    department: str | None = None
    description: str | None = None
    target_bonus: Annotated[float | None, Field(alias='targetBonus')] = None
    employee_address: Annotated[EmployeeAddress | None, Field(alias='employeeAddress')] = None
    print_as: Annotated[str | None, Field(alias='printAs')] = None
    phone: str | None = None
    mobile: str | None = None
    pager: str | None = None
    pager_pin: Annotated[str | None, Field(alias='pagerPin')] = None
    alternate_phone: Annotated[str | None, Field(alias='alternatePhone')] = None
    fax: str | None = None
    ssn: str | None = None
    email: str | None = None
    emergency_contacts: Annotated[EmergencyContact | None, Field(alias='emergencyContacts', description='Emergency contacts for the employee (QBD only, v13.0+).')] = None
    additional_contacts: Annotated[AdditionalContacts | None, Field(alias='additionalContacts', description='Additional contact references (may repeat, v12.0+).')] = None
    additional_notes: Annotated[AdditionalNotes | None, Field(alias='additionalNotes', description='Additional notes (may repeat, v12.0+).')] = None
    employee_type: Annotated[str | None, Field(alias='employeeType')] = None
    part_or_full_time: Annotated[str | None, Field(alias='partOrFullTime')] = None
    exempt: str | None = None
    key_employee: Annotated[str | None, Field(alias='keyEmployee')] = None
    gender: str | None = None
    hired_date: Annotated[date_aliased | None, Field(alias='hiredDate')] = None
    original_hire_date: Annotated[date_aliased | None, Field(alias='originalHireDate')] = None
    adjusted_service_date: Annotated[date_aliased | None, Field(alias='adjustedServiceDate')] = None
    released_date: Annotated[date_aliased | None, Field(alias='releasedDate')] = None
    birth_date: Annotated[date_aliased | None, Field(alias='birthDate')] = None
    us_citizen: Annotated[str | None, Field(alias='usCitizen')] = None
    ethnicity: str | None = None
    disabled: str | None = None
    disability_desc: Annotated[str | None, Field(alias='disabilityDesc')] = None
    on_file: Annotated[str | None, Field(alias='onFile')] = None
    work_auth_expire_date: Annotated[date_aliased | None, Field(alias='workAuthExpireDate')] = None
    us_veteran: Annotated[str | None, Field(alias='usVeteran')] = None
    military_status: Annotated[str | None, Field(alias='militaryStatus')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    notes: str | None = None
    billing_rate: Annotated[QbdRef | None, Field(alias='billingRate')] = None
    employee_payroll_info: Annotated[EmployeePayrollInfo | None, Field(alias='employeePayrollInfo')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description="The employee's name (required). This is the display name in QuickBooks.")] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseEmployee(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Employee] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateAdditionalNoteRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    note: Annotated[str, Field(description='The note text (max 4095 characters).')]


class CreateEmployeeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    is_active: Annotated[bool | None, Field(alias='isActive', description="The employee's name (required). This is the display name in QuickBooks.")] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    job_title: Annotated[str | None, Field(alias='jobTitle')] = None
    supervisor_id: Annotated[str | None, Field(alias='supervisorId', description='ListID of the supervisor employee.')] = None
    department: str | None = None
    description: str | None = None
    employee_address: Annotated[EmployeeAddress | None, Field(alias='employeeAddress')] = None
    print_as: Annotated[str | None, Field(alias='printAs')] = None
    phone: str | None = None
    mobile: str | None = None
    pager: str | None = None
    pager_pin: Annotated[str | None, Field(alias='pagerPin')] = None
    alternate_phone: Annotated[str | None, Field(alias='alternatePhone')] = None
    fax: str | None = None
    email: str | None = None
    ssn: str | None = None
    additional_contacts: Annotated[AdditionalContacts | None, Field(alias='additionalContacts', description='Additional contact references (may repeat, v12.0+).')] = None
    emergency_contacts: Annotated[EmergencyContact | None, Field(alias='emergencyContacts', description='Emergency contacts for the employee (QBD only, v13.0+).')] = None
    additional_notes: Annotated[AdditionalNotes | None, Field(alias='additionalNotes', description='Additional notes (may repeat, v12.0+). For Add, only Note is needed.')] = None
    employee_type: Annotated[str | None, Field(alias='employeeType')] = None
    part_or_full_time: Annotated[str | None, Field(alias='partOrFullTime')] = None
    gender: str | None = None
    hired_date: Annotated[date_aliased | None, Field(alias='hiredDate')] = None
    released_date: Annotated[date_aliased | None, Field(alias='releasedDate')] = None
    birth_date: Annotated[date_aliased | None, Field(alias='birthDate')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    notes: str | None = None
    billing_rate_id: Annotated[str | None, Field(alias='billingRateId', description='ListID of the billing rate.')] = None
    target_bonus: Annotated[float | None, Field(alias='targetBonus')] = None
    exempt: str | None = None
    key_employee: Annotated[str | None, Field(alias='keyEmployee')] = None
    original_hire_date: Annotated[date_aliased | None, Field(alias='originalHireDate')] = None
    adjusted_service_date: Annotated[date_aliased | None, Field(alias='adjustedServiceDate')] = None
    us_citizen: Annotated[str | None, Field(alias='usCitizen')] = None
    ethnicity: str | None = None
    disabled: str | None = None
    disability_desc: Annotated[str | None, Field(alias='disabilityDesc')] = None
    on_file: Annotated[str | None, Field(alias='onFile')] = None
    work_auth_expire_date: Annotated[date_aliased | None, Field(alias='workAuthExpireDate')] = None
    us_veteran: Annotated[str | None, Field(alias='usVeteran')] = None
    military_status: Annotated[str | None, Field(alias='militaryStatus')] = None
    employee_payroll_info: Annotated[EmployeePayrollInfo | None, Field(alias='employeePayrollInfo')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    suffix: str | None = None


class UpdateAdditionalNoteRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    note_id: Annotated[int, Field(alias='noteId', description='The ID of the note to modify (required for updates).')]
    note: Annotated[str, Field(description='The note text (max 4095 characters).')]


class UpdateEmployeeRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    job_title: Annotated[str | None, Field(alias='jobTitle')] = None
    supervisor_id: Annotated[str | None, Field(alias='supervisorId', description='ListID of the supervisor employee.')] = None
    department: str | None = None
    description: str | None = None
    employee_address: Annotated[EmployeeAddress | None, Field(alias='employeeAddress')] = None
    print_as: Annotated[str | None, Field(alias='printAs')] = None
    phone: str | None = None
    mobile: str | None = None
    pager: str | None = None
    pager_pin: Annotated[str | None, Field(alias='pagerPin')] = None
    alt_phone: Annotated[str | None, Field(alias='altPhone')] = None
    fax: str | None = None
    email: str | None = None
    ssn: str | None = None
    additional_contacts: Annotated[AdditionalContacts | None, Field(alias='additionalContacts', description='Additional contact references (may repeat, v12.0+).')] = None
    emergency_contacts: Annotated[EmergencyContact | None, Field(alias='emergencyContacts', description='Emergency contacts for the employee (QBD only, v13.0+).')] = None
    employee_type: Annotated[str | None, Field(alias='employeeType')] = None
    part_or_full_time: Annotated[str | None, Field(alias='partOrFullTime')] = None
    gender: str | None = None
    hired_date: Annotated[date_aliased | None, Field(alias='hiredDate')] = None
    released_date: Annotated[date_aliased | None, Field(alias='releasedDate')] = None
    birth_date: Annotated[date_aliased | None, Field(alias='birthDate')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    notes: str | None = None
    additional_notes: Annotated[AdditionalNotes | None, Field(alias='additionalNotes', description='Additional notes modification (may repeat, v12.0+). Requires NoteId for existing notes.')] = None
    billing_rate_id: Annotated[str | None, Field(alias='billingRateId', description='ListID of the billing rate.')] = None
    suffix: str | None = None
    target_bonus: Annotated[float | None, Field(alias='targetBonus')] = None
    exempt: str | None = None
    key_employee: Annotated[str | None, Field(alias='keyEmployee')] = None
    original_hire_date: Annotated[date_aliased | None, Field(alias='originalHireDate')] = None
    adjusted_service_date: Annotated[date_aliased | None, Field(alias='adjustedServiceDate')] = None
    us_citizen: Annotated[str | None, Field(alias='usCitizen')] = None
    ethnicity: str | None = None
    disabled: str | None = None
    disability_desc: Annotated[str | None, Field(alias='disabilityDesc')] = None
    on_file: Annotated[str | None, Field(alias='onFile')] = None
    work_auth_expire_date: Annotated[date_aliased | None, Field(alias='workAuthExpireDate')] = None
    us_veteran: Annotated[str | None, Field(alias='usVeteran')] = None
    military_status: Annotated[str | None, Field(alias='militaryStatus')] = None
    employee_payroll_info: Annotated[EmployeePayrollInfo | None, Field(alias='employeePayrollInfo')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
