from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressBlock, AddressRequest, CreateCreditCardTransactionInfoRequest, CreditCardTransactionInfo, CustomFields, ExpenseLine, ItemGroupLine, ItemLine, LineGroups, Lines, LinkedTransaction, NullableCreditCardTransactionType, NullableTransactionMode, QbdDataExt, QbdRef, UpdateCreditCardTransactionResultInfoRequest

class SalesReceipt(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) Exchange rate if this is a foreign currency Sales Receipt.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The document number (e.g., receipt number). (Max 11 characters)')] = None
    memo: Annotated[str | None, Field(description='(Optional) General memo about the Sales Receipt. (Max 4095 characters)')] = None
    txn_number: Annotated[int | None, Field(alias='txnNumber')] = None
    customer: QbdRef | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    template: QbdRef | None = None
    billing_address: Annotated[Address | None, Field(alias='billingAddress')] = None
    billing_address_block: Annotated[AddressBlock | None, Field(alias='billingAddressBlock')] = None
    shipping_address: Annotated[Address | None, Field(alias='shippingAddress')] = None
    shipping_address_block: Annotated[AddressBlock | None, Field(alias='shippingAddressBlock')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending', description='(Optional) Indicates if the transaction is pending.')] = None
    check_number: Annotated[str | None, Field(alias='checkNumber', description='(Optional) Check number if payment method is check. (Max 25 characters)')] = None
    payment_method: Annotated[QbdRef | None, Field(alias='paymentMethod')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The date the payment is due (if applicable).')] = None
    sales_representative: Annotated[QbdRef | None, Field(alias='salesRepresentative')] = None
    ship_date: Annotated[date_aliased | None, Field(alias='shipDate')] = None
    ship_method: Annotated[QbdRef | None, Field(alias='shipMethod')] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    subtotal: float | None = None
    item_sales_tax: Annotated[QbdRef | None, Field(alias='itemSalesTax')] = None
    sales_tax_percentage: Annotated[float | None, Field(alias='salesTaxPercentage')] = None
    sales_tax_total: Annotated[float | None, Field(alias='salesTaxTotal')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount')] = None
    total_amount_in_home_currency: Annotated[float | None, Field(alias='totalAmountInHomeCurrency')] = None
    customer_message: Annotated[QbdRef | None, Field(alias='customerMessage')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_queued_for_email: Annotated[bool | None, Field(alias='isQueuedForEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, tax is included in the item amounts (tax-inclusive pricing).')] = None
    customer_sales_tax_code: Annotated[QbdRef | None, Field(alias='customerSalesTaxCode')] = None
    deposit_to_account: Annotated[QbdRef | None, Field(alias='depositToAccount')] = None
    credit_card_transaction: Annotated[CreditCardTransactionInfo | None, Field(alias='creditCardTransaction')] = None
    other_custom_field: Annotated[str | None, Field(alias='otherCustomField')] = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[list[LinkedTransaction] | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[list[ExpenseLine] | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[list[ItemLine] | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[list[ItemGroupLine] | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseSalesReceipt(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[SalesReceipt] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateSalesReceiptLineGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the group.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure override. (Max 31 characters)')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None


class CreateSalesReceiptLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item.')] = None
    description: Annotated[str | None, Field(description='(Optional) Description for the line item. (Max 4095 characters)')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure override. (Max 31 characters)')] = None
    override_uom_set_id: Annotated[str | None, Field(alias='overrideUOMSetId', description='(Optional) The ListID or FullName of the unit of measure set to override.')] = None
    rate: Annotated[float | None, Field(description='(Optional) The direct rate per unit. Use either Rate, RatePercent, or PriceLevelId.')] = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent', description='(Optional) The percentage rate based on item price. Use either Rate, RatePercent, or PriceLevelId.')] = None
    price_level_id: Annotated[str | None, Field(alias='priceLevelId', description='(Optional) The ListID or FullName of the price level to use. Use either Rate, RatePercent, or PriceLevelId.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line. Overrides calculation if Rate/RatePercent not set.')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item. Mutually exclusive with LotNumber. (Max 4095 characters)')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item. Mutually exclusive with SerialNumber. (Max 40 characters)')] = None
    expiration_date: Annotated[str | None, Field(alias='expirationDate')] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) The date the service was performed.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code.')] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None
    credit_card_transaction: Annotated[CreateCreditCardTransactionInfoRequest | None, Field(alias='creditCardTransaction')] = None


class CreateSalesReceiptRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    customer_id: Annotated[str, Field(alias='customerId', description='(Required by QB) The ListID or FullName of the customer or job this Sales Receipt is for.')]
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with the transaction header.')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='(Optional) The ListID or FullName of the Sales Receipt template to use.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The document number (e.g., receipt number). (Max 11 characters)')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    is_pending: Annotated[bool | None, Field(alias='isPending', description='(Optional) Indicates if the transaction is pending.')] = None
    check_number: Annotated[str | None, Field(alias='checkNumber', description='(Optional) Check number if payment method is check. (Max 25 characters)')] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId', description='(Optional) The ListID or FullName of the payment method (e.g., Check, Visa).')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The date the payment is due (if applicable).')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    ship_method_id: Annotated[str | None, Field(alias='shipMethodId', description='(Optional) The ListID or FullName of the ship method.')] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the sales tax item or group.')] = None
    memo: Annotated[str | None, Field(description='(Optional) General memo about the Sales Receipt. (Max 4095 characters)')] = None
    customer_message_id: Annotated[str | None, Field(alias='customerMessageId')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_queued_for_email: Annotated[bool | None, Field(alias='isQueuedForEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, tax is included in the item amounts (tax-inclusive pricing).')] = None
    customer_sales_tax_code_id: Annotated[str | None, Field(alias='customerSalesTaxCodeId', description='(Optional) The ListID or FullName of the Sales Tax Code for the customer.')] = None
    deposit_to_account_id: Annotated[str | None, Field(alias='depositToAccountId', description='(Optional) The ListID or FullName of the account to deposit the payment to.')] = None
    credit_card_transaction: Annotated[CreateCreditCardTransactionInfoRequest | None, Field(alias='creditCardTransaction')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) Exchange rate if this is a foreign currency Sales Receipt.')] = None
    other_customer_field: Annotated[str | None, Field(alias='otherCustomerField')] = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class SalesReceiptLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item: QbdRef | None = None
    description: Annotated[str | None, Field(description='(Optional) Description for the line item. (Max 4095 characters)')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure override. (Max 31 characters)')] = None
    override_uom_set: Annotated[QbdRef | None, Field(alias='overrideUOMSet')] = None
    rate: Annotated[float | None, Field(description='(Optional) The direct rate per unit. Use either Rate, RatePercent, or PriceLevelId.')] = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent', description='(Optional) The percentage rate based on item price. Use either Rate, RatePercent, or PriceLevelId.')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line. Overrides calculation if Rate/RatePercent not set.')] = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item. Mutually exclusive with LotNumber. (Max 4095 characters)')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item. Mutually exclusive with SerialNumber. (Max 40 characters)')] = None
    expiration_date: Annotated[str | None, Field(alias='expirationDate')] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) The date the service was performed.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None
    credit_card_transaction: Annotated[CreditCardTransactionInfo | None, Field(alias='creditCardTransaction')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class SalesReceiptLineGroup(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item_group: Annotated[QbdRef | None, Field(alias='itemGroup')] = None
    description: str | None = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the group.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure override. (Max 31 characters)')] = None
    override_unit_of_measure_set: Annotated[QbdRef | None, Field(alias='overrideUnitOfMeasureSet')] = None
    should_print_items_in_group: Annotated[bool | None, Field(alias='shouldPrintItemsInGroup')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount')] = None
    lines: Lines | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class UpdateCreditCardTransactionInputInfoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    credit_card_number: Annotated[str | None, Field(alias='creditCardNumber', description="(Optional) The customer's new credit card number. (Max 25 characters)", max_length=25)] = None
    expiration_month: Annotated[int | None, Field(alias='expirationMonth', description="(Optional) The credit card's new expiration month (1-12).", ge=1, le=12)] = None
    expiration_year: Annotated[int | None, Field(alias='expirationYear', description="(Optional) The credit card's new expiration year (e.g., 2025).", ge=2000, le=2100)] = None
    name_on_card: Annotated[str | None, Field(alias='nameOnCard', description='(Optional) The new name as it appears on the credit card. (Max 50 characters)', max_length=50)] = None
    credit_card_address: Annotated[str | None, Field(alias='creditCardAddress', description='(Optional) New street address for AVS validation. (Max 41 characters)', max_length=41)] = None
    credit_card_postal_code: Annotated[str | None, Field(alias='creditCardPostalCode', description='(Optional) New Postal/ZIP code for AVS validation. (Max 13 characters)', max_length=13)] = None
    commercial_card_code: Annotated[str | None, Field(alias='commercialCardCode', description='(Optional) New commercial card code. (Max 4 characters)', max_length=4)] = None
    transaction_mode: Annotated[NullableTransactionMode | None, Field(alias='transactionMode', description='(Optional) New transaction mode (0 for CardNotPresent [DEFAULT], 1 for CardPresent).')] = None
    credit_card_txn_type: Annotated[NullableCreditCardTransactionType | None, Field(alias='creditCardTxnType', description='(Optional) New type of credit card transaction.\nUsed for actions like changing an Authorization to a Capture (1).')] = None


class UpdateCreditCardTransactionInfoRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    credit_card_txn_input_info_mod: Annotated[UpdateCreditCardTransactionInputInfoRequest | None, Field(alias='creditCardTxnInputInfoMod')] = None
    credit_card_txn_result_info_mod: Annotated[UpdateCreditCardTransactionResultInfoRequest | None, Field(alias='creditCardTxnResultInfoMod')] = None


class UpdateSalesReceiptLineGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_group_id: Annotated[str | None, Field(alias='itemGroupId', description='(Optional) The ListID or FullName of the item group.')] = None
    quantity: Annotated[float | None, Field(description='(Optional) New quantity of the group.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure override. (Max 31 characters)')] = None
    lines: Lines | None = None


class UpdateSalesReceiptLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item.')] = None
    description: Annotated[str | None, Field(description='(Optional) New description for the line item. (Max 4095 characters)')] = None
    quantity: Annotated[float | None, Field(description='(Optional) New quantity of the item.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure', description='(Optional) Unit of measure override. (Max 31 characters)')] = None
    override_unit_of_measure_set_id: Annotated[str | None, Field(alias='overrideUnitOfMeasureSetId')] = None
    rate: Annotated[float | None, Field(description='(Optional) The direct rate per unit. Use either Rate, RatePercent, or PriceLevelId.')] = None
    rate_percent: Annotated[float | None, Field(alias='ratePercent', description='(Optional) The percentage rate based on item price. Use either Rate, RatePercent, or PriceLevelId.')] = None
    price_level_id: Annotated[str | None, Field(alias='priceLevelId', description='(Optional) The ListID or FullName of the price level to use. Use either Rate, RatePercent, or PriceLevelId.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class.')] = None
    amount: Annotated[float | None, Field(description='(Optional) New total amount for the line.')] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the inventory site.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the inventory site location.')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber', description='(Optional) Serial number for the item. Mutually exclusive with LotNumber. (Max 4095 characters)')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber', description='(Optional) Lot number for the item. Mutually exclusive with SerialNumber. (Max 40 characters)')] = None
    expiration_date: Annotated[str | None, Field(alias='expirationDate')] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) The new date the service was performed.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code.')] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None


class UpdateSalesReceiptRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job this Sales Receipt is for.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with the transaction header.')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='(Optional) The ListID or FullName of the Sales Receipt template to use.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The new document number (e.g., receipt number). (Max 11 characters)')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    check_number: Annotated[str | None, Field(alias='checkNumber', description='(Optional) New check number if payment method is check. (Max 25 characters)')] = None
    payment_method_id: Annotated[str | None, Field(alias='paymentMethodId', description='(Optional) The ListID or FullName of the payment method (e.g., Check, Visa).')] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The new date the payment is due (if applicable).')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    shipping_method_id: Annotated[str | None, Field(alias='shippingMethodId')] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId', description='(Optional) The ListID or FullName of the sales tax item or group.')] = None
    memo: Annotated[str | None, Field(description='(Optional) New general memo about the Sales Receipt. (Max 4095 characters)')] = None
    customer_message_id: Annotated[str | None, Field(alias='customerMessageId')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_queued_for_email: Annotated[bool | None, Field(alias='isQueuedForEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, tax is included in the item amounts (tax-inclusive pricing).')] = None
    customer_sales_tax_code_id: Annotated[str | None, Field(alias='customerSalesTaxCodeId', description='(Optional) The ListID or FullName of the Sales Tax Code for the customer.')] = None
    deposit_to_account_id: Annotated[str | None, Field(alias='depositToAccountId', description='(Optional) The ListID or FullName of the account to deposit the payment to.')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) New exchange rate if this is a foreign currency Sales Receipt.')] = None
    other_custom_field: Annotated[str | None, Field(alias='otherCustomField')] = None
    credit_card_transaction: Annotated[UpdateCreditCardTransactionInfoRequest | None, Field(alias='creditCardTransaction')] = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
