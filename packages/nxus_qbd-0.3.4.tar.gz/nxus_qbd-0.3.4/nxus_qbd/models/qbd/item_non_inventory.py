from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BarCodeRequest, QbdDataExt, QbdRef

class ItemNonInventory(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    manufacturer_part_number: Annotated[str | None, Field(alias='manufacturerPartNumber', description='Manufacturer part number for the item.')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    desc: str | None = None
    price: float | None = None
    price_percent: Annotated[float | None, Field(alias='pricePercent')] = None
    account: QbdRef | None = None
    sales_desc: Annotated[str | None, Field(alias='salesDesc')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    expense_account: Annotated[QbdRef | None, Field(alias='expenseAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseItemNonInventory(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemNonInventory] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class ItemNonInventorySalesAndPurchaseDetailsRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account_id: Annotated[str | None, Field(alias='incomeAccountId')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code_id: Annotated[str | None, Field(alias='purchaseTaxCodeId')] = None
    expense_account_id: Annotated[str | None, Field(alias='expenseAccountId')] = None
    preferred_vendor_id: Annotated[str | None, Field(alias='preferredVendorId')] = None


class ItemNonInventorySalesOrPurchaseDetailsRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    description: str | None = None
    price: float | None = None
    price_percentage: Annotated[float | None, Field(alias='pricePercentage')] = None
    posting_account_id: Annotated[str | None, Field(alias='postingAccountId')] = None


class CreateItemNonInventoryRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    barcode: BarCodeRequest | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    sku: str | None = None
    unit_of_measure_set_id: Annotated[str | None, Field(alias='unitOfMeasureSetId')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    sales_or_purchase_details: Annotated[ItemNonInventorySalesOrPurchaseDetailsRequest | None, Field(alias='salesOrPurchaseDetails')] = None
    sales_and_purchase_details: Annotated[ItemNonInventorySalesAndPurchaseDetailsRequest | None, Field(alias='salesAndPurchaseDetails')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateItemNonInventoryRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: str | None = None
    barcode: BarCodeRequest | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    sku: str | None = None
    unit_of_measure_set_id: Annotated[str | None, Field(alias='unitOfMeasureSetId')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    sales_or_purchase_details: Annotated[ItemNonInventorySalesOrPurchaseDetailsRequest | None, Field(alias='salesOrPurchaseDetails')] = None
    sales_and_purchase_details: Annotated[ItemNonInventorySalesAndPurchaseDetailsRequest | None, Field(alias='salesAndPurchaseDetails')] = None
