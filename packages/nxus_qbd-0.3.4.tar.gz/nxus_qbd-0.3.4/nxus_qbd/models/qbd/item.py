from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import FixedAssetSalesInfo, ItemSalesTax1, Lines, QbdDataExt, QbdRef

class ItemInventoryItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['InventoryItem'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    manufacturer_part_number: Annotated[str | None, Field(alias='manufacturerPartNumber')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_desc: Annotated[str | None, Field(alias='salesDesc')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    cogs_account: Annotated[QbdRef | None, Field(alias='cogsAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    asset_account: Annotated[QbdRef | None, Field(alias='assetAccount')] = None
    reorder_point: Annotated[float | None, Field(alias='reorderPoint')] = None
    max: float | None = None
    quantity_on_hand: Annotated[float | None, Field(alias='quantityOnHand')] = None
    average_cost: Annotated[float | None, Field(alias='averageCost')] = None
    quantity_on_order: Annotated[float | None, Field(alias='quantityOnOrder')] = None
    quantity_on_sales_order: Annotated[float | None, Field(alias='quantityOnSalesOrder')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemDiscount(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['Discount'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc')] = None
    discount_rate: Annotated[float | None, Field(alias='discountRate')] = None
    discount_rate_percent: Annotated[float | None, Field(alias='discountRatePercent')] = None
    account: QbdRef | None = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemFixedAsset(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['FixedAsset'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    acquired_as: Annotated[str | None, Field(alias='acquiredAs')] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc')] = None
    purchase_date: Annotated[date_aliased | None, Field(alias='purchaseDate')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    vendor_or_payee_name: Annotated[str | None, Field(alias='vendorOrPayeeName')] = None
    asset_account: Annotated[QbdRef | None, Field(alias='assetAccount')] = None
    sales_info: Annotated[FixedAssetSalesInfo | None, Field(alias='salesInfo')] = None
    asset_desc: Annotated[str | None, Field(alias='assetDesc')] = None
    location: str | None = None
    po_number: Annotated[str | None, Field(alias='poNumber')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber')] = None
    warranty_exp_date: Annotated[date_aliased | None, Field(alias='warrantyExpDate')] = None
    notes: str | None = None
    asset_number: Annotated[str | None, Field(alias='assetNumber')] = None
    cost_basis: Annotated[float | None, Field(alias='costBasis')] = None
    year_end_accumulated_depreciation: Annotated[float | None, Field(alias='yearEndAccumulatedDepreciation')] = None
    year_end_book_value: Annotated[float | None, Field(alias='yearEndBookValue')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemGroup(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['Group'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    should_print_items_in_group: Annotated[bool | None, Field(alias='shouldPrintItemsInGroup')] = None
    special_item_type: Annotated[str | None, Field(alias='specialItemType')] = None
    lines: Lines | None = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemInventoryAssembly(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['InventoryAssembly'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    sku: str | None = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_description: Annotated[str | None, Field(alias='purchaseDescription')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    cogs_account: Annotated[QbdRef | None, Field(alias='cogsAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    asset_account: Annotated[QbdRef | None, Field(alias='assetAccount')] = None
    build_point: Annotated[float | None, Field(alias='buildPoint')] = None
    max: float | None = None
    quantity_on_hand: Annotated[float | None, Field(alias='quantityOnHand')] = None
    total_value: Annotated[float | None, Field(alias='totalValue')] = None
    average_cost: Annotated[float | None, Field(alias='averageCost')] = None
    quantity_on_order: Annotated[float | None, Field(alias='quantityOnOrder')] = None
    quantity_on_sales_order: Annotated[float | None, Field(alias='quantityOnSalesOrder')] = None
    lines: Lines | None = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemNonInventory(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['NonInventory'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    manufacturer_part_number: Annotated[str | None, Field(alias='manufacturerPartNumber')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    desc: str | None = None
    price: float | None = None
    price_percent: Annotated[float | None, Field(alias='pricePercent')] = None
    account: QbdRef | None = None
    sales_desc: Annotated[str | None, Field(alias='salesDesc')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    expense_account: Annotated[QbdRef | None, Field(alias='expenseAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemOtherCharge(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['OtherCharge'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded')] = None
    special_item_type: Annotated[str | None, Field(alias='specialItemType')] = None
    item_other_charge_description: Annotated[str | None, Field(alias='itemOtherChargeDescription')] = None
    price: float | None = None
    price_percent: Annotated[float | None, Field(alias='pricePercent')] = None
    account: QbdRef | None = None
    sales_desc: Annotated[str | None, Field(alias='salesDesc')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    expense_account: Annotated[QbdRef | None, Field(alias='expenseAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemPayment(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['Payment'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc')] = None
    deposit_to_account: Annotated[QbdRef | None, Field(alias='depositToAccount')] = None
    payment_method: Annotated[QbdRef | None, Field(alias='paymentMethod')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemSalesTax(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['SalesTax'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc')] = None
    tax_rate: Annotated[float | None, Field(alias='taxRate')] = None
    tax_vendor: Annotated[QbdRef | None, Field(alias='taxVendor')] = None
    sales_tax_return_line: Annotated[QbdRef | None, Field(alias='salesTaxReturnLine')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemSalesTaxGroup(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['SalesTaxGroup'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc')] = None
    item_sales_tax: Annotated[ItemSalesTax1 | None, Field(alias='itemSalesTax')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemItemSubtotal(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['Subtotal'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc')] = None
    special_item_type: Annotated[str | None, Field(alias='specialItemType')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class ItemServiceItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_type: Annotated[Literal['Service'], Field(alias='itemType')]
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    desc: str | None = None
    price: float | None = None
    price_percent: Annotated[float | None, Field(alias='pricePercent')] = None
    account: QbdRef | None = None
    sales_description: Annotated[str | None, Field(alias='salesDescription')] = None
    sales_price: Annotated[float | None, Field(alias='salesPrice')] = None
    income_account: Annotated[QbdRef | None, Field(alias='incomeAccount')] = None
    purchase_desc: Annotated[str | None, Field(alias='purchaseDesc')] = None
    purchase_cost: Annotated[float | None, Field(alias='purchaseCost')] = None
    purchase_tax_code: Annotated[QbdRef | None, Field(alias='purchaseTaxCode')] = None
    expense_account: Annotated[QbdRef | None, Field(alias='expenseAccount')] = None
    preferred_vendor: Annotated[QbdRef | None, Field(alias='preferredVendor')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class Item(RootModel[ItemServiceItem | ItemItemNonInventory | ItemItemOtherCharge | ItemInventoryItem | ItemItemInventoryAssembly | ItemItemFixedAsset | ItemItemSubtotal | ItemItemDiscount | ItemItemPayment | ItemItemSalesTax | ItemItemSalesTaxGroup | ItemItemGroup]):
    root: Annotated[ItemServiceItem | ItemItemNonInventory | ItemItemOtherCharge | ItemInventoryItem | ItemItemInventoryAssembly | ItemItemFixedAsset | ItemItemSubtotal | ItemItemDiscount | ItemItemPayment | ItemItemSalesTax | ItemItemSalesTaxGroup | ItemItemGroup, Field(description='Any line item on a purchase order, invoice, or estimate must be set up as an Item.\nItems act as pointers for the financial statements.In other words, items handle the behind the scenes accounting for sales and purchases.\nItems make it easier to fill out sales forms.\nItems allow you to track quantities purchased and sold in addition to dollars purchased and sold.', discriminator='item_type')]


class BasePageResponseItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Item] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class ItemInventoryItemItemType(Enum):
    INVENTORY_ITEM = 'InventoryItem'


class ItemItemDiscountItemType(Enum):
    DISCOUNT = 'Discount'


class ItemItemFixedAssetItemType(Enum):
    FIXED_ASSET = 'FixedAsset'


class ItemItemGroupItemType(Enum):
    GROUP = 'Group'


class ItemItemInventoryAssemblyItemType(Enum):
    INVENTORY_ASSEMBLY = 'InventoryAssembly'


class ItemItemNonInventoryItemType(Enum):
    NON_INVENTORY = 'NonInventory'


class ItemItemOtherChargeItemType(Enum):
    OTHER_CHARGE = 'OtherCharge'


class ItemItemPaymentItemType(Enum):
    PAYMENT = 'Payment'


class ItemItemSalesTaxGroupItemType(Enum):
    SALES_TAX_GROUP = 'SalesTaxGroup'


class ItemItemSalesTaxItemType(Enum):
    SALES_TAX = 'SalesTax'


class ItemItemSubtotalItemType(Enum):
    SUBTOTAL = 'Subtotal'


class ItemServiceItemItemType(Enum):
    SERVICE = 'Service'
