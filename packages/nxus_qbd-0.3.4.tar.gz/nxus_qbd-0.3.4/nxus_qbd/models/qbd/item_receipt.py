from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import ExpenseLines, ItemGroupLines, ItemLines, LinkedTransaction, QbdDataExt, QbdRef

class ItemReceipt(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (Optional).')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the transaction (Optional).')] = None
    memo: Annotated[str | None, Field(description='Memo for the transaction (Optional).')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    payables_account: Annotated[QbdRef | None, Field(alias='payablesAccount')] = None
    liability_account: Annotated[QbdRef | None, Field(alias='liabilityAccount', description='The Liability account (e.g., for items received without a bill).')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Indicates if tax is included in line items (Optional).')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[list[LinkedTransaction] | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense line items for the item receipt.')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items for the item receipt.')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group line items for the item receipt.')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseItemReceipt(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemReceipt] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateItemReceiptRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    vendor_id: Annotated[str, Field(alias='vendorId', description='Filter by Vendor ID.')]
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId')] = None
    liability_account_id: Annotated[str | None, Field(alias='liabilityAccountId', description='Liability Account ListID (Optional - OR condition with APAccountId).\nAt least one of APAccountId or LiabilityAccountId must be provided.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the transaction (Optional).')] = None
    memo: Annotated[str | None, Field(description='Memo for the transaction (Optional).')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Indicates if tax is included in line items (Optional).')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='Sales Tax Code ListID (Optional).')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='Currency ListID (Optional - for multi-currency).')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (Optional).')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    link_to_transaction_ids: Annotated[list[str] | None, Field(alias='linkToTransactionIds')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense line items for the item receipt.')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items for the item receipt.')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group line items for the item receipt.')] = None


class UpdateItemReceiptRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    vendor_id: Annotated[str | None, Field(alias='vendorId', description='Filter by Vendor ID.', examples=['10000001-1039043346'])] = None
    payables_account_id: Annotated[str | None, Field(alias='payablesAccountId')] = None
    liability_account_id: Annotated[str | None, Field(alias='liabilityAccountId', description='Liability Account ListID (Optional for updates).')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='Reference number for the transaction (Optional).')] = None
    memo: Annotated[str | None, Field(description='Memo for the transaction (Optional).')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='Indicates if tax is included in line items (Optional).')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='Sales Tax Code ListID (Optional).')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId', description='Currency ListID (Optional).')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='Exchange rate for multi-currency transactions (Optional).')] = None
    expense_lines: Annotated[ExpenseLines | None, Field(alias='expenseLines', description='Expense line items (replaces existing lines).')] = None
    item_lines: Annotated[ItemLines | None, Field(alias='itemLines', description='Item line items (replaces existing lines).')] = None
    item_group_lines: Annotated[ItemGroupLines | None, Field(alias='itemGroupLines', description='Item group line items (replaces existing lines).')] = None
