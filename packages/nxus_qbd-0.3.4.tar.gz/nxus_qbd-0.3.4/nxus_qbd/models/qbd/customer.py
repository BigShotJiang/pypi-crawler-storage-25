from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import AdditionalContacts, AdditionalNotes, Address, AddressRequest, AlternateShippingAddresses, Contacts, CustomContactFields, QbdDataExt, QbdRef, ShipToAddresses, ShippingAddresses

class AdditionalNoteMod(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    note_id: Annotated[int | None, Field(alias='noteID')] = None
    note: str


class CreditCardInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    credit_card_number: Annotated[str | None, Field(alias='creditCardNumber')] = None
    expiration_month: Annotated[int | None, Field(alias='expirationMonth')] = None
    expiration_year: Annotated[int | None, Field(alias='expirationYear')] = None
    name_on_card: Annotated[str | None, Field(alias='nameOnCard')] = None
    credit_card_address: Annotated[str | None, Field(alias='creditCardAddress')] = None
    credit_card_postal_code: Annotated[str | None, Field(alias='creditCardPostalCode')] = None


class Customer(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    full_name: Annotated[str | None, Field(alias='fullName', description='The fully-qualified unique name for this object, formed by combining the names of its parent objects with its own `name`, separated by colons. Not case-sensitive.')] = None
    sublevel: Annotated[int | None, Field(description='The nesting depth of this customer (0 = top-level, 1 = sub-customer, etc.).')] = None
    company_name: Annotated[str | None, Field(alias='companyName', description='The company or business name of the customer.')] = None
    salutation: Annotated[str | None, Field(description='Salutation/title for the customer\'s contact person (e.g., "Mr.", "Dr.").')] = None
    first_name: Annotated[str | None, Field(alias='firstName', description="First name of the customer's contact person.")] = None
    middle_name: Annotated[str | None, Field(alias='middleName', description="Middle name of the customer's contact person.")] = None
    last_name: Annotated[str | None, Field(alias='lastName', description="Last name of the customer's contact person.")] = None
    job_title: Annotated[str | None, Field(alias='jobTitle', description="Job title of the customer's primary contact.")] = None
    billing_address: Annotated[Address | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[Address | None, Field(alias='shippingAddress')] = None
    alternate_shipping_addresses: Annotated[AlternateShippingAddresses | None, Field(alias='alternateShippingAddresses')] = None
    phone: Annotated[str | None, Field(description='Primary phone number for the customer.')] = None
    alternate_phone: Annotated[str | None, Field(alias='alternatePhone')] = None
    fax: Annotated[str | None, Field(description='Fax number for the customer.')] = None
    email: Annotated[str | None, Field(description='Primary email address for the customer.')] = None
    cc_email: Annotated[str | None, Field(alias='ccEmail', description='CC email address — copied on all emails sent to this customer.')] = None
    contact: Annotated[str | None, Field(description="Name of the primary contact at the customer's company.")] = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    custom_contact_fields: Annotated[CustomContactFields | None, Field(alias='customContactFields', description='Custom contact fields (name/value pairs) for the customer.\nMaps to AdditionalContactRef in QbXML (0-8 allowed at customer level).')] = None
    additional_contacts: Annotated[AdditionalContacts | None, Field(alias='additionalContacts', description='Additional contacts for the customer (full contact objects).\nMaps to Contacts in QbXML.')] = None
    class_: Annotated[QbdRef | None, Field(alias='class', description='The class assigned to this customer for departmental tracking.')] = None
    parent: Annotated[QbdRef | None, Field(description='The parent customer or job this record belongs to (for sub-customers/jobs).')] = None
    customer_type: Annotated[QbdRef | None, Field(alias='customerType', description='The customer type category assigned to this customer.')] = None
    terms: Annotated[QbdRef | None, Field(description='The default payment terms for this customer (e.g., "Net 30").')] = None
    sales_rep: Annotated[QbdRef | None, Field(alias='salesRep', description='The sales representative assigned to this customer.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode', description='The sales tax code that determines whether sales to this customer are taxable.')] = None
    item_sales_tax: Annotated[QbdRef | None, Field(alias='itemSalesTax', description='The default sales tax item applied to taxable sales for this customer.')] = None
    preferred_payment_method: Annotated[QbdRef | None, Field(alias='preferredPaymentMethod', description="The customer's preferred payment method.")] = None
    job_type: Annotated[QbdRef | None, Field(alias='jobType', description='The type of job (used when this record represents a job under a customer).')] = None
    price_level: Annotated[QbdRef | None, Field(alias='priceLevel', description='The custom price level applied to sales for this customer.')] = None
    currency: Annotated[QbdRef | None, Field(description='The currency used for transactions with this customer (multi-currency files only).')] = None
    balance: Annotated[float | None, Field(description='Current outstanding balance owed by this customer.')] = None
    total_balance: Annotated[float | None, Field(alias='totalBalance', description='Combined balance across this customer and all sub-customers/jobs.')] = None
    sales_tax_country: Annotated[str | None, Field(alias='salesTaxCountry', description='The country to which sales tax is remitted for this customer.')] = None
    resale_number: Annotated[str | None, Field(alias='resaleNumber', description="The customer's resale certificate number (used for tax-exempt sales).")] = None
    account_number: Annotated[str | None, Field(alias='accountNumber', description='Your account number for this customer (as assigned in QuickBooks).')] = None
    credit_limit: Annotated[float | None, Field(alias='creditLimit', description='Maximum credit limit extended to this customer.')] = None
    credit_card: Annotated[CreditCardInfo | None, Field(alias='creditCard')] = None
    job_status: Annotated[str | None, Field(alias='jobStatus', description='Current status of the job (e.g., "InProgress", "Awarded", "Closed"). Applies when this record is a job.')] = None
    job_start_date: Annotated[date_aliased | None, Field(alias='jobStartDate', description='Date the job started. Applies when this record is a job.')] = None
    job_projected_end_date: Annotated[date_aliased | None, Field(alias='jobProjectedEndDate', description='Projected completion date for the job.')] = None
    job_end_date: Annotated[date_aliased | None, Field(alias='jobEndDate', description='Actual end date of the job.')] = None
    job_description: Annotated[str | None, Field(alias='jobDescription', description='Description of the job or project.')] = None
    notes: Annotated[str | None, Field(description='Free-form notes about the customer.')] = None
    additional_notes: Annotated[AdditionalNotes | None, Field(alias='additionalNotes', description='Additional notes attached to this customer record.')] = None
    preferred_delivery_method: Annotated[str | None, Field(alias='preferredDeliveryMethod', description='The preferred method for delivering invoices and statements (e.g., "Email", "Mail", "None").')] = None
    tax_registration_number: Annotated[str | None, Field(alias='taxRegistrationNumber', description="The customer's tax registration number (used for international tax compliance).")] = None
    external_id: Annotated[UUID | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseCustomer(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Customer] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class NullableJobStatus(Enum):
    NONE = 'None'
    PENDING = 'Pending'
    AWARDED = 'Awarded'
    IN_PROGRESS = 'InProgress'
    CLOSED = 'Closed'
    NOT_AWARDED = 'NotAwarded'
    NONE_TYPE_NONE = None


class CreateCustomerRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    company_name: Annotated[str | None, Field(alias='companyName')] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName')] = None
    middle_name: Annotated[str | None, Field(alias='middleName')] = None
    last_name: Annotated[str | None, Field(alias='lastName')] = None
    job_title: Annotated[str | None, Field(alias='jobTitle')] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    shipping_addresses: Annotated[ShippingAddresses | None, Field(alias='shippingAddresses')] = None
    phone: str | None = None
    alt_phone: Annotated[str | None, Field(alias='altPhone')] = None
    fax: str | None = None
    email: str | None = None
    cc_email: Annotated[str | None, Field(alias='ccEmail')] = None
    contact: str | None = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    custom_contact_fields: Annotated[CustomContactFields | None, Field(alias='customContactFields')] = None
    contacts: Contacts | None = None
    customer_type_id: Annotated[str | None, Field(alias='customerTypeId')] = None
    terms_id: Annotated[str | None, Field(alias='termsId')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    open_balance: Annotated[float | None, Field(alias='openBalance')] = None
    open_balance_date: Annotated[date_aliased | None, Field(alias='openBalanceDate')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId')] = None
    item_sales_tax_id: Annotated[str | None, Field(alias='itemSalesTaxId')] = None
    sales_tax_country: Annotated[str | None, Field(alias='salesTaxCountry')] = None
    resale_number: Annotated[str | None, Field(alias='resaleNumber')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    credit_limit: Annotated[float | None, Field(alias='creditLimit')] = None
    preferred_payment_method_id: Annotated[str | None, Field(alias='preferredPaymentMethodId')] = None
    credit_card_info: Annotated[CreditCardInfo | None, Field(alias='creditCardInfo')] = None
    job_status: Annotated[NullableJobStatus | None, Field(alias='jobStatus', description='JobStatus may have one of the following values: Awarded, Closed, InProgress, None [DEFAULT], NotAwarded, Pending')] = None
    job_start_date: Annotated[date_aliased | None, Field(alias='jobStartDate')] = None
    job_projected_end_date: Annotated[date_aliased | None, Field(alias='jobProjectedEndDate')] = None
    job_end_date: Annotated[date_aliased | None, Field(alias='jobEndDate')] = None
    job_desc: Annotated[str | None, Field(alias='jobDesc')] = None
    job_type_id: Annotated[str | None, Field(alias='jobTypeId')] = None
    notes: str | None = None
    additional_notes: Annotated[list[str] | None, Field(alias='additionalNotes')] = None
    preferred_delivery_method: Annotated[str | None, Field(alias='preferredDeliveryMethod')] = None
    price_level_id: Annotated[str | None, Field(alias='priceLevelId')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    tax_registration_number: Annotated[str | None, Field(alias='taxRegistrationNumber')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId')] = None
    suffix: str | None = None
    print_as: Annotated[str | None, Field(alias='printAs')] = None
    pager: str | None = None
    mobile: str | None = None
    cc: str | None = None


class ShipToAddress(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    line1: str | None = None
    line2: str | None = None
    line3: str | None = None
    line4: str | None = None
    line5: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: Annotated[str | None, Field(alias='postalCode')] = None
    country: str | None = None
    note: str | None = None
    name: Annotated[str, Field(description='Name identifier for this shipping address (e.g., "Warehouse", "Store #1").\nRequired for ShipToAddress. Maps to line1 in Conductor API.')]
    is_default_shipping_address: Annotated[bool | None, Field(alias='isDefaultShippingAddress')] = None


class ShipToAddressRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='Name identifier for this shipping address (e.g., "Warehouse", "Store #1").\nRequired for ShipToAddress. Maps to line1 in Conductor API.', max_length=41)]
    default_ship_to: Annotated[bool | None, Field(alias='defaultShipTo', description='Whether this is the default shipping address for the customer.\nOptional - defaults to false.')] = None
    line1: str | None = None
    line2: str | None = None
    line3: str | None = None
    line4: str | None = None
    line5: str | None = None
    city: Annotated[str | None, Field(max_length=31)] = None
    state: Annotated[str | None, Field(max_length=21)] = None
    postal_code: Annotated[str | None, Field(alias='postalCode', max_length=13)] = None
    country: Annotated[str | None, Field(max_length=31)] = None
    note: Annotated[str | None, Field(max_length=4095)] = None


class UpdateCustomerRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(max_length=41)] = None
    company_name: Annotated[str | None, Field(alias='companyName', max_length=41)] = None
    suffix: str | None = None
    print_as: Annotated[str | None, Field(alias='printAs')] = None
    pager: str | None = None
    mobile: str | None = None
    cc: str | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    parent_id: Annotated[str | None, Field(alias='parentId')] = None
    class_id: Annotated[str | None, Field(alias='classId')] = None
    customer_type_id: Annotated[str | None, Field(alias='customerTypeId')] = None
    terms_id: Annotated[str | None, Field(alias='termsId')] = None
    sales_representative_id: Annotated[str | None, Field(alias='salesRepresentativeId')] = None
    sales_tax_item_id: Annotated[str | None, Field(alias='salesTaxItemId')] = None
    preferred_payment_method_id: Annotated[str | None, Field(alias='preferredPaymentMethodId')] = None
    price_level_id: Annotated[str | None, Field(alias='priceLevelId')] = None
    tax_registration_number: Annotated[str | None, Field(alias='taxRegistrationNumber')] = None
    job_type_id: Annotated[str | None, Field(alias='jobTypeId')] = None
    currency_id: Annotated[str | None, Field(alias='currencyId')] = None
    credit_card_info: Annotated[CreditCardInfo | None, Field(alias='creditCardInfo')] = None
    salutation: str | None = None
    first_name: Annotated[str | None, Field(alias='firstName', max_length=25)] = None
    middle_name: Annotated[str | None, Field(alias='middleName', max_length=5)] = None
    last_name: Annotated[str | None, Field(alias='lastName', max_length=25)] = None
    job_title: Annotated[str | None, Field(alias='jobTitle', max_length=41)] = None
    billing_address: Annotated[AddressRequest | None, Field(alias='billingAddress')] = None
    shipping_address: Annotated[AddressRequest | None, Field(alias='shippingAddress')] = None
    ship_to_addresses: Annotated[ShipToAddresses | None, Field(alias='shipToAddresses', description='Additional ship-to addresses (up to 50 allowed by QuickBooks).\nNote: Updating ship-to addresses replaces the entire list.')] = None
    phone: Annotated[str | None, Field(max_length=21)] = None
    alt_phone: Annotated[str | None, Field(alias='altPhone', max_length=21)] = None
    email: Annotated[str | None, Field(max_length=1023)] = None
    cc_email: Annotated[str | None, Field(alias='ccEmail', max_length=1023)] = None
    contact: Annotated[str | None, Field(max_length=41)] = None
    alternate_contact: Annotated[str | None, Field(alias='alternateContact')] = None
    custom_contact_fields: Annotated[CustomContactFields | None, Field(alias='customContactFields', description='Custom contact fields (name/value pairs) for the customer.\nMaps to AdditionalContactRef in QbXML (0-8 allowed at customer level).')] = None
    credit_limit: Annotated[float | None, Field(alias='creditLimit')] = None
    job_status: Annotated[NullableJobStatus | None, Field(alias='jobStatus')] = None
    job_start_date: Annotated[date_aliased | None, Field(alias='jobStartDate')] = None
    job_projected_end_date: Annotated[date_aliased | None, Field(alias='jobProjectedEndDate')] = None
    job_end_date: Annotated[date_aliased | None, Field(alias='jobEndDate')] = None
    job_desc: Annotated[str | None, Field(alias='jobDesc', max_length=99)] = None
    notes: Annotated[str | None, Field(max_length=4095)] = None
    additional_notes: Annotated[AdditionalNotes | None, Field(alias='additionalNotes')] = None
    preferred_delivery_method: Annotated[str | None, Field(alias='preferredDeliveryMethod', description='Can be None [Default], Email, or Fax. Use regex to validate.', pattern='^(None|Email|Fax)$')] = None
    resale_number: Annotated[str | None, Field(alias='resaleNumber')] = None
    account_number: Annotated[str | None, Field(alias='accountNumber')] = None
    fax: str | None = None
