from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import QbdDataExt, QbdRef

class PayrollItemNonWage(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the non-wage payroll item.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    non_wage_type: Annotated[str, Field(alias='nonWageType', description='(Required) The non-wage item type.\nPossible values: Addition, CompanyContribution, Deduction, DirectDeposit, Tax')]
    expense_account: Annotated[QbdRef | None, Field(alias='expenseAccount', description='The expense account associated with this payroll item.')] = None
    liability_account: Annotated[QbdRef | None, Field(alias='liabilityAccount', description='The liability account associated with this payroll item.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Indicates whether the payroll item is active.')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponsePayrollItemNonWage(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[PayrollItemNonWage] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None
