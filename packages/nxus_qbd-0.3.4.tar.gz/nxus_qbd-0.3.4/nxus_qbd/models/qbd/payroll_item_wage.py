from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import QbdDataExt, QbdRef

class PayrollItemWage(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name of the wage payroll item.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    wage_type: Annotated[str, Field(alias='wageType', description='(Required) The wage item type.\nPossible values: Bonus, Commission, HourlyOvertime, HourlyRegular, HourlySick, HourlyVacation, SalaryRegular, SalarySick, SalaryVacation.')]
    expense_account: Annotated[QbdRef, Field(alias='expenseAccount', description='The expense account associated with this wage item.')]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Indicates whether the payroll item is active.')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponsePayrollItemWage(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[PayrollItemWage] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreatePayrollItemWageRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name of the wage payroll item.', max_length=31)]
    wage_type: Annotated[str, Field(alias='wageType', description='(Required) The wage item type.\nPossible values: Bonus, Commission, HourlyOvertime, HourlyRegular, HourlySick, HourlyVacation, SalaryRegular, SalarySick, SalaryVacation.')]
    expense_account_id: Annotated[str, Field(alias='expenseAccountId', description='(Required) The ListID of the Expense Account associated with the payroll item. (Flattened-ID Pattern)')]
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Indicates whether the payroll item is active.')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
