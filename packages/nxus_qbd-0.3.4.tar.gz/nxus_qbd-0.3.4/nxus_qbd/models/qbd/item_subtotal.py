from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BarCodeRequest, QbdDataExt, QbdRef

class ItemSubtotal(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc', description='Description of the item.\nMax Length: 4095 characters.')] = None
    special_item_type: Annotated[str | None, Field(alias='specialItemType', description='Special Item Type.\nValues: FinanceCharge, ReimbursableExpenseGroup, ReimbursableExpenseSubtotal.')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseItemSubtotal(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemSubtotal] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateItemSubtotalRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_desc: Annotated[str | None, Field(alias='itemDesc', description='Description of the item.\nMax Length: 4095 characters.', max_length=4095)] = None
    special_item_type: Annotated[str | None, Field(alias='specialItemType', description='Special Item Type.\nValues: FinanceCharge, ReimbursableExpenseGroup, ReimbursableExpenseSubtotal.')] = None
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    bar_code_value: Annotated[str | None, Field(alias='barCodeValue', max_length=50)] = None
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateItemSubtotalRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc', description='Description of the item.\nMax Length: 4095 characters.', max_length=4095)] = None
    special_item_type: Annotated[str | None, Field(alias='specialItemType', description='Special Item Type.\nValues: FinanceCharge, ReimbursableExpenseGroup, ReimbursableExpenseSubtotal.')] = None
    name: str
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    bar_code_value: Annotated[str | None, Field(alias='barCodeValue', max_length=50)] = None
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
