from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BarCodeRequest, Lines, QbdDataExt, QbdRef

class ItemGroup(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    should_print_items_in_group: Annotated[bool | None, Field(alias='shouldPrintItemsInGroup')] = None
    special_item_type: Annotated[str | None, Field(alias='specialItemType')] = None
    lines: Lines | None = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: str | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseItemGroup(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemGroup] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateItemGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode')] = None
    description: str | None = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    unit_of_measure_set_id: Annotated[str | None, Field(alias='unitOfMeasureSetId')] = None
    should_print_items_in_group: Annotated[bool | None, Field(alias='shouldPrintItemsInGroup')] = None
    lines: Lines | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class ItemGroupLineDetailRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: Annotated[str, Field(alias='itemId')]
    quantity: float | None = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None


class UpdateItemGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: str | None = None
    bar_code: Annotated[BarCodeRequest | None, Field(alias='barCode')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    description: str | None = None
    unit_of_measure_set_id: Annotated[str | None, Field(alias='unitOfMeasureSetId')] = None
    force_unit_of_measure_change: Annotated[bool | None, Field(alias='forceUnitOfMeasureChange')] = None
    should_print_items_in_group: Annotated[bool | None, Field(alias='shouldPrintItemsInGroup')] = None
    clear_items_in_group: Annotated[bool | None, Field(alias='clearItemsInGroup')] = None
    lines: Lines | None = None
    revision_number: Annotated[str, Field(alias='revisionNumber')]
