from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import Address, AddressBlock, AddressRequest, CustomFields, ExpenseLine, ItemGroupLine, ItemLine, LineGroups, Lines, LinkedTransaction, QbdDataExt, QbdRef

class PurchaseOrder(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) Exchange rate if this is a foreign currency Purchase Order.')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The document number. (Max 11 characters)')] = None
    memo: Annotated[str | None, Field(description='(Optional) Memo about the transaction. (Max 4095 characters)')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    vendor: QbdRef | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    ship_to_entity: Annotated[QbdRef | None, Field(alias='shipToEntity')] = None
    template: QbdRef | None = None
    vendor_address: Annotated[Address | None, Field(alias='vendorAddress', description='(Optional) The primary address for the Vendor on this Purchase Order.')] = None
    vendor_address_block: Annotated[AddressBlock | None, Field(alias='vendorAddressBlock')] = None
    ship_address: Annotated[Address | None, Field(alias='shipAddress', description='(Optional) The shipping address for the Purchase Order.')] = None
    ship_address_block: Annotated[AddressBlock | None, Field(alias='shipAddressBlock')] = None
    terms: QbdRef | None = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The date the payment is due based on terms.')] = None
    expected_date: Annotated[date_aliased | None, Field(alias='expectedDate', description='(Optional) The date the vendor is expected to deliver the item.')] = None
    shipment_method: Annotated[QbdRef | None, Field(alias='shipmentMethod')] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount')] = None
    is_manually_closed: Annotated[bool | None, Field(alias='isManuallyClosed', description='(Optional) If true, the Purchase Order is considered manually closed (Cannot be cleared if modifying existing value).')] = None
    is_fully_received: Annotated[bool | None, Field(alias='isFullyReceived')] = None
    vendor_message: Annotated[str | None, Field(alias='vendorMessage')] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_queued_for_emailed: Annotated[bool | None, Field(alias='isQueuedForEmailed')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, the line item rates/amounts are inclusive of sales tax.')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
    amount: float | None = None
    entity: QbdRef | None = None
    account: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[list[LinkedTransaction] | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[list[ExpenseLine] | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[list[ItemLine] | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[list[ItemGroupLine] | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponsePurchaseOrder(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[PurchaseOrder] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreatePurchaseOrderLineGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the group to purchase.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the specific inventory site location where items will be received.', max_length=50)] = None


class CreatePurchaseOrderLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item being purchased.', max_length=50)] = None
    manufacturer_part_number: Annotated[str | None, Field(alias='manufacturerPartNumber', description="(Optional) The manufacturer's part number for the item. (Max 31 characters)", max_length=31)] = None
    description: Annotated[str | None, Field(description='(Optional) Description for the line item. (Max 4095 characters)', max_length=4095)] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item to purchase.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    override_uom_set_id: Annotated[str | None, Field(alias='overrideUOMSetId', description='(Optional) The ListID or FullName of the unit of measure set to override.', max_length=50)] = None
    rate: Annotated[float | None, Field(description='(Optional) Cost/Rate per item unit.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class for this line.', max_length=50)] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line.')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the specific inventory site location where items will be received.', max_length=50)] = None
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job this item is intended for (Job Costing).', max_length=50)] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) The date the service was performed (if this is a service item).')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code applicable to the item.', max_length=50)] = None
    other1: Annotated[str | None, Field(description='(Optional) User-defined field 1. (Max 29 characters)', max_length=29)] = None
    other2: Annotated[str | None, Field(description='(Optional) User-defined field 2. (Max 29 characters)', max_length=29)] = None


class CreatePurchaseOrderRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    vendor_id: Annotated[str | None, Field(alias='vendorId', description='Filter by Vendor ID.', examples=['10000001-1039043346'], max_length=50)] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with the transaction header.\nFollows the Flattened-ID Pattern for ClassRef.', max_length=50)] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the primary inventory site for this PO.\nFollows the Flattened-ID Pattern for InventorySiteRef.', max_length=50)] = None
    ship_to_entity_id: Annotated[str | None, Field(alias='shipToEntityId', description='(Optional) The ListID or FullName of the entity (Customer/Vendor) where items are shipped.\nFollows the Flattened-ID Pattern for ShipToEntityRef.')] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='(Optional) The ListID or FullName of the Purchase Order template to use.\nFollows the Flattened-ID Pattern for TemplateRef.', max_length=50)] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The document number. (Max 11 characters)', max_length=11)] = None
    vendor_address: Annotated[AddressRequest | None, Field(alias='vendorAddress', description='(Optional) The primary address for the Vendor on this Purchase Order.')] = None
    ship_address: Annotated[AddressRequest | None, Field(alias='shipAddress', description='(Optional) The shipping address for the Purchase Order.')] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='(Optional) The ListID or FullName of the payment terms.\nFollows the Flattened-ID Pattern for TermsRef.', max_length=50)] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The date the payment is due based on terms.')] = None
    expected_date: Annotated[date_aliased | None, Field(alias='expectedDate', description='(Optional) The date the vendor is expected to deliver the item.')] = None
    ship_method_id: Annotated[str | None, Field(alias='shipMethodId', description='(Optional) The ListID or FullName of the shipping method.\nFollows the Flattened-ID Pattern for ShipMethodRef.', max_length=50)] = None
    shipment_origin: Annotated[str | None, Field(alias='shipmentOrigin')] = None
    memo: Annotated[str | None, Field(description='(Optional) Memo about the transaction. (Max 4095 characters)', max_length=4095)] = None
    vendor_msg: Annotated[str | None, Field(alias='vendorMsg', description='(Optional) Message displayed to the vendor. (Max 99 characters)', max_length=99)] = None
    is_queued_for_print: Annotated[bool | None, Field(alias='isQueuedForPrint')] = None
    is_queued_for_email: Annotated[bool | None, Field(alias='isQueuedForEmail')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, the line item rates/amounts are inclusive of sales tax.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the Sales Tax Code (used for tax calculation defaults).\nFollows the Flattened-ID Pattern for SalesTaxCodeRef.', max_length=50)] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) Exchange rate if this is a foreign currency Purchase Order.')] = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class PurchaseOrderLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item: QbdRef | None = None
    manufacturer_part_number: Annotated[str | None, Field(alias='manufacturerPartNumber', description="(Optional) The manufacturer's part number for the item. (Max 31 characters)")] = None
    description: Annotated[str | None, Field(description='(Optional) Description for the line item. (Max 4095 characters)')] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item to purchase.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    override_unit_of_measure_set: Annotated[QbdRef | None, Field(alias='overrideUnitOfMeasureSet')] = None
    rate: Annotated[float | None, Field(description='(Optional) Cost/Rate per item unit.')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line.')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    customer: QbdRef | None = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) The date the service was performed (if this is a service item).')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    received_quantity: Annotated[float | None, Field(alias='receivedQuantity')] = None
    unbilled_quantity: Annotated[float | None, Field(alias='unbilledQuantity')] = None
    is_billed: Annotated[bool | None, Field(alias='isBilled')] = None
    is_manually_closed: Annotated[bool | None, Field(alias='isManuallyClosed', description='(Optional) If true, manually closes this line item.')] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class PurchaseOrderLineGroup(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    item_group: Annotated[QbdRef | None, Field(alias='itemGroup')] = None
    description: str | None = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the group to purchase.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    override_unit_of_measure_set: Annotated[QbdRef | None, Field(alias='overrideUnitOfMeasureSet')] = None
    is_print_items_in_group: Annotated[bool | None, Field(alias='isPrintItemsInGroup')] = None
    total_amount: Annotated[float | None, Field(alias='totalAmount')] = None
    lines: Lines | None = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class UpdatePurchaseOrderLineGroupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_group_id: Annotated[str | None, Field(alias='itemGroupId', description='(Optional) The ListID or FullName of the item group.', max_length=50)] = None
    quantity: Annotated[float | None, Field(description='(Optional) New quantity of the group.')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    lines: Lines | None = None


class UpdatePurchaseOrderLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_id: Annotated[str | None, Field(alias='itemId', description='(Optional) The ListID or FullName of the item being purchased. (Cannot be cleared if modifying existing value)', max_length=50)] = None
    manufacturer_part_number: Annotated[str | None, Field(alias='manufacturerPartNumber', description="(Optional) The manufacturer's part number for the item. (Max 31 characters)", max_length=31)] = None
    description: Annotated[str | None, Field(description='(Optional) Description for the line item. (Max 4095 characters)', max_length=4095)] = None
    quantity: Annotated[float | None, Field(description='(Optional) Quantity of the item to purchase. (Cannot be cleared if modifying existing value)')] = None
    unit_of_measure: Annotated[str | None, Field(alias='unitOfMeasure')] = None
    override_unit_of_measure_set_id: Annotated[str | None, Field(alias='overrideUnitOfMeasureSetId')] = None
    rate: Annotated[float | None, Field(description='(Optional) Cost/Rate per item unit. (Cannot be cleared if modifying existing value)')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class for this line.', max_length=50)] = None
    amount: Annotated[float | None, Field(description='(Optional) Total amount for the line. (Cannot be cleared if modifying existing value)')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId', description='(Optional) The ListID or FullName of the specific inventory site location where items will be received.', max_length=50)] = None
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job this item is intended for (Job Costing).', max_length=50)] = None
    service_date: Annotated[date_aliased | None, Field(alias='serviceDate', description='(Optional) The new date the service was performed.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the sales tax code applicable to the item.', max_length=50)] = None
    is_manually_closed: Annotated[bool | None, Field(alias='isManuallyClosed', description='(Optional) If true, manually closes this line item.')] = None
    override_item_account_id: Annotated[str | None, Field(alias='overrideItemAccountId', description='(Optional) The ListID or FullName of the expense account to override the default item account. (Cannot be cleared if modifying existing value)', max_length=50)] = None
    other_custom_field1: Annotated[str | None, Field(alias='otherCustomField1')] = None
    other_custom_field2: Annotated[str | None, Field(alias='otherCustomField2')] = None


class UpdatePurchaseOrderRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    vendor_id: Annotated[str | None, Field(alias='vendorId', description='Filter by Vendor ID.', examples=['10000001-1039043346'], max_length=50)] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with the transaction header.\nFollows the Flattened-ID Pattern for ClassRef.', max_length=50)] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the primary inventory site for this PO.\nFollows the Flattened-ID Pattern for InventorySiteRef.', max_length=50)] = None
    ship_to_entity_id: Annotated[str | None, Field(alias='shipToEntityId', description='(Optional) The ListID or FullName of the entity (Customer/Vendor) where items are shipped.\nFollows the Flattened-ID Pattern for ShipToEntityRef.', max_length=50)] = None
    template_id: Annotated[str | None, Field(alias='templateId', description='(Optional) The ListID or FullName of the Purchase Order template to use. (Cannot be cleared if modifying existing value)\nFollows the Flattened-ID Pattern for TemplateRef.')] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The document number. (Max 11 characters)', max_length=11)] = None
    vendor_address: Annotated[AddressRequest | None, Field(alias='vendorAddress', description='(Optional) The primary address for the Vendor on this Purchase Order.')] = None
    ship_address: Annotated[AddressRequest | None, Field(alias='shipAddress', description='(Optional) The shipping address for the Purchase Order.')] = None
    terms_id: Annotated[str | None, Field(alias='termsId', description='(Optional) The ListID or FullName of the payment terms.\nFollows the Flattened-ID Pattern for TermsRef.', max_length=50)] = None
    due_date: Annotated[date_aliased | None, Field(alias='dueDate', description='(Optional) The date the payment is due based on terms. (Cannot be cleared if modifying existing value)')] = None
    expected_date: Annotated[date_aliased | None, Field(alias='expectedDate', description='(Optional) The date the vendor is expected to deliver the item. (Cannot be cleared if modifying existing value)')] = None
    ship_method_id: Annotated[str | None, Field(alias='shipMethodId', description='(Optional) The ListID or FullName of the shipping method.\nFollows the Flattened-ID Pattern for ShipMethodRef.', max_length=50)] = None
    fob: Annotated[str | None, Field(description='(Optional) Free On Board point. (Max 13 characters)', max_length=13)] = None
    is_manually_closed: Annotated[bool | None, Field(alias='isManuallyClosed', description='(Optional) If true, the Purchase Order is considered manually closed (Cannot be cleared if modifying existing value).')] = None
    memo: Annotated[str | None, Field(description='(Optional) Memo about the transaction. (Max 4095 characters)', max_length=4095)] = None
    vendor_msg: Annotated[str | None, Field(alias='vendorMsg', description='(Optional) Message displayed to the vendor. (Max 99 characters)', max_length=99)] = None
    is_to_be_printed: Annotated[bool | None, Field(alias='isToBePrinted', description='(Optional) If true, the Purchase Order should be printed. (Cannot be cleared if modifying existing value)')] = None
    is_to_be_emailed: Annotated[bool | None, Field(alias='isToBeEmailed', description='(Optional) If true, the Purchase Order should be emailed.')] = None
    is_tax_included: Annotated[bool | None, Field(alias='isTaxIncluded', description='(Optional) If true, the line item rates/amounts are inclusive of sales tax.')] = None
    sales_tax_code_id: Annotated[str | None, Field(alias='salesTaxCodeId', description='(Optional) The ListID or FullName of the Sales Tax Code (used for tax calculation defaults).\nFollows the Flattened-ID Pattern for SalesTaxCodeRef.', max_length=50)] = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate', description='(Optional) New exchange rate if this is a foreign currency Purchase Order.')] = None
    other1: str | None = None
    other2: str | None = None
    lines: Lines | None = None
    line_groups: Annotated[LineGroups | None, Field(alias='lineGroups')] = None
