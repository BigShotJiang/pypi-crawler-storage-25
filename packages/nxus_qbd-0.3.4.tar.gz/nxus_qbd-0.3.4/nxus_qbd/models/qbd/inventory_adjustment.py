from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import CustomFields, ExpenseLine, InventoryAdjustmentLines, ItemGroupLine, ItemLine, Lines, LinkedTransaction, QbdDataExt, QbdRef

class InventoryAdjustment(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    currency: QbdRef | None = None
    exchange_rate: Annotated[float | None, Field(alias='exchangeRate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The document number. (Max 11 characters)')] = None
    memo: Annotated[str | None, Field(description='(Optional) General memo about the Inventory Adjustment. (Max 4095 characters)')] = None
    transaction_number: Annotated[int | None, Field(alias='transactionNumber')] = None
    account: QbdRef | None = None
    inventory_site: Annotated[QbdRef | None, Field(alias='inventorySite')] = None
    customer: QbdRef | None = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    lines: Lines | None = None
    amount: float | None = None
    entity: QbdRef | None = None
    amount_in_home_currency: Annotated[str | None, Field(alias='amountInHomeCurrency')] = None
    has_valid_line_items: Annotated[bool | None, Field(alias='hasValidLineItems')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    linked_transactions: Annotated[list[LinkedTransaction] | None, Field(alias='linkedTransactions')] = None
    expense_lines: Annotated[list[ExpenseLine] | None, Field(alias='expenseLines')] = None
    item_lines: Annotated[list[ItemLine] | None, Field(alias='itemLines')] = None
    item_group_lines: Annotated[list[ItemGroupLine] | None, Field(alias='itemGroupLines')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseInventoryAdjustment(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[InventoryAdjustment] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class LotNumberAdjustmentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    lot_number: Annotated[str | None, Field(alias='lotNumber')] = None
    count_adjustment: Annotated[int | None, Field(alias='countAdjustment')] = None
    expiration_date_for_serial_lot_number: Annotated[str | None, Field(alias='expirationDateForSerialLotNumber')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId')] = None


class QuantityAdjustmentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    new_quantity: Annotated[int | None, Field(alias='newQuantity')] = None
    quantity_difference: Annotated[int | None, Field(alias='quantityDifference')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber')] = None
    expiration_date_for_serial_lot_number: Annotated[str | None, Field(alias='expirationDateForSerialLotNumber')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId')] = None


class SerialNumberAdjustmentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    add_serial_number: Annotated[str | None, Field(alias='addSerialNumber')] = None
    remove_serial_number: Annotated[str | None, Field(alias='removeSerialNumber')] = None
    expiration_date_for_serial_lot_number: Annotated[str | None, Field(alias='expirationDateForSerialLotNumber')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId')] = None


class ValueAdjustmentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    new_quantity: Annotated[int | None, Field(alias='newQuantity')] = None
    quantity_difference: Annotated[int | None, Field(alias='quantityDifference')] = None
    new_value: Annotated[float | None, Field(alias='newValue')] = None
    value_difference: Annotated[float | None, Field(alias='valueDifference')] = None


class CreateInventoryAdjustmentLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: Annotated[str, Field(alias='itemId')]
    memo: str | None = None
    quantity_adjustment: Annotated[QuantityAdjustmentRequest | None, Field(alias='quantityAdjustment')] = None
    value_adjustment: Annotated[ValueAdjustmentRequest | None, Field(alias='valueAdjustment')] = None
    serial_number_adjustment: Annotated[SerialNumberAdjustmentRequest | None, Field(alias='serialNumberAdjustment')] = None
    lot_number_adjustment: Annotated[LotNumberAdjustmentRequest | None, Field(alias='lotNumberAdjustment')] = None


class CreateInventoryAdjustmentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    account_id: Annotated[str, Field(alias='accountId', description='(Required) The ListID or FullName of the Inventory Adjustment account (usually Inventory Adjustment or an expense account).\nFollows the Flattened-ID Pattern for AccountRef.', max_length=50)]
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The document number. (Max 11 characters)', max_length=11)] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the Inventory Site where the adjustment occurs.\nFollows the Flattened-ID Pattern for InventorySiteRef.', max_length=50)] = None
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job related to the adjustment (Job Costing).\nFollows the Flattened-ID Pattern for CustomerRef.', max_length=50)] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with the transaction header.\nFollows the Flattened-ID Pattern for ClassRef.', max_length=50)] = None
    memo: Annotated[str | None, Field(description='(Optional) General memo about the Inventory Adjustment. (Max 4095 characters)', max_length=4095)] = None
    inventory_adjustment_lines: Annotated[list[CreateInventoryAdjustmentLineRequest], Field(alias='inventoryAdjustmentLines')]
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class InventoryAdjustmentLine(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item: QbdRef | None = None
    serial_number: Annotated[str | None, Field(alias='serialNumber')] = None
    serial_number_added_or_removed: Annotated[str | None, Field(alias='serialNumberAddedOrRemoved')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber')] = None
    expiration_date: Annotated[str | None, Field(alias='expirationDate')] = None
    inventory_site_location: Annotated[QbdRef | None, Field(alias='inventorySiteLocation')] = None
    quantity_difference: Annotated[float | None, Field(alias='quantityDifference')] = None
    value_difference: Annotated[float | None, Field(alias='valueDifference')] = None
    custom_fields: Annotated[CustomFields | None, Field(alias='customFields')] = None


class UpdateInventoryAdjustmentLineRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    item_id: Annotated[str | None, Field(alias='itemId')] = None
    quantity_difference: Annotated[int | None, Field(alias='quantityDifference')] = None
    value_difference: Annotated[float | None, Field(alias='valueDifference')] = None
    serial_number: Annotated[str | None, Field(alias='serialNumber')] = None
    lot_number: Annotated[str | None, Field(alias='lotNumber')] = None
    count_adjustment: Annotated[int | None, Field(alias='countAdjustment')] = None
    expiration_date_for_serial_lot_number: Annotated[str | None, Field(alias='expirationDateForSerialLotNumber')] = None
    inventory_site_location_id: Annotated[str | None, Field(alias='inventorySiteLocationId')] = None


class UpdateInventoryAdjustmentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    account_id: Annotated[str | None, Field(alias='accountId', description='(Optional) The ListID or FullName of the Inventory Adjustment account.\nFollows the Flattened-ID Pattern for AccountRef.', max_length=50)] = None
    transaction_date: Annotated[date_aliased | None, Field(alias='transactionDate')] = None
    ref_number: Annotated[str | None, Field(alias='refNumber', description='(Optional) The new document number. (Max 11 characters)', max_length=11)] = None
    inventory_site_id: Annotated[str | None, Field(alias='inventorySiteId', description='(Optional) The ListID or FullName of the Inventory Site where the adjustment occurs.\nFollows the Flattened-ID Pattern for InventorySiteRef.', max_length=50)] = None
    customer_id: Annotated[str | None, Field(alias='customerId', description='(Optional) The ListID or FullName of the customer or job related to the adjustment.\nFollows the Flattened-ID Pattern for CustomerRef.', max_length=50)] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID or FullName of the class associated with the transaction header.\nFollows the Flattened-ID Pattern for ClassRef.', max_length=50)] = None
    memo: Annotated[str | None, Field(description='(Optional) New general memo about the Inventory Adjustment. (Max 4095 characters)', max_length=4095)] = None
    inventory_adjustment_lines: Annotated[InventoryAdjustmentLines | None, Field(alias='inventoryAdjustmentLines')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
