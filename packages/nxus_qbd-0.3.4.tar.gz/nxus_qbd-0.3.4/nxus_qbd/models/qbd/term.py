from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import QbdDataExt
from .date_driven_term import UpdateDateDrivenTermRequest

class Term(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: str | None = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    due_days: Annotated[int | None, Field(alias='dueDays')] = None
    discount_days: Annotated[int | None, Field(alias='discountDays')] = None
    due_day_of_month: Annotated[int | None, Field(alias='dueDayOfMonth')] = None
    grace_period_days: Annotated[int | None, Field(alias='gracePeriodDays')] = None
    discount_day_of_month: Annotated[int | None, Field(alias='discountDayOfMonth', description='Day of the month for discount eligibility (Date Driven Terms).')] = None
    discount_percentage: Annotated[float | None, Field(alias='discountPercentage')] = None
    is_active: Annotated[bool | None, Field(alias='isActive')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseTerm(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[Term] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateTermRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateTermRequest(UpdateDateDrivenTermRequest):
    pass
