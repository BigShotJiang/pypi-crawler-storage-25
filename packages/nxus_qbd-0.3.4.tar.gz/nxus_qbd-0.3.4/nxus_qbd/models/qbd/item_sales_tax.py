from __future__ import annotations
from datetime import date as date_aliased
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, RootModel

from .._datetime import FlexibleDatetime
from .._shared import BarCodeRequest, QbdDataExt, QbdRef

class ItemSalesTax(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    object_type: Annotated[str | None, Field(alias='objectType')] = None
    name: Annotated[str | None, Field(description='(Required) The name or identifier for the new sales tax item.')] = None
    created_at: Annotated[FlexibleDatetime, Field(alias='createdAt')]
    updated_at: Annotated[FlexibleDatetime, Field(alias='updatedAt')]
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    item_desc: Annotated[str | None, Field(alias='itemDesc', description='(Optional) A description for the sales tax item.')] = None
    tax_rate: Annotated[float | None, Field(alias='taxRate', description='(Optional) The tax rate as a percentage (e.g., 7.5 for 7.5%).')] = None
    tax_vendor: Annotated[QbdRef | None, Field(alias='taxVendor')] = None
    sales_tax_return_line: Annotated[QbdRef | None, Field(alias='salesTaxReturnLine')] = None
    full_name: Annotated[str | None, Field(alias='fullName')] = None
    barcode: Annotated[str | None, Field(description='(Optional) BarCode information.')] = None
    class_: Annotated[QbdRef | None, Field(alias='class')] = None
    parent: QbdRef | None = None
    sublevel: int | None = None
    unit_of_measure_set: Annotated[QbdRef | None, Field(alias='unitOfMeasureSet')] = None
    sales_tax_code: Annotated[QbdRef | None, Field(alias='salesTaxCode')] = None
    description: str | None = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Indicates whether the sales tax item is active.')] = None
    custom_fields: Annotated[list[QbdDataExt] | None, Field(alias='customFields')] = None


class BasePageResponseItemSalesTax(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    request_id: Annotated[str | None, Field(alias='requestId')] = None
    success: bool | None = None
    data: list[ItemSalesTax] | None = None
    next_cursor: Annotated[str | None, Field(alias='nextCursor')] = None
    page: int | None = None
    count: int | None = None
    limit: Annotated[int | None, Field(description='The maximum number of items to return in a single response.')] = None
    total_count: Annotated[int | None, Field(alias='totalCount')] = None
    page_count: Annotated[int | None, Field(alias='pageCount')] = None
    has_more: Annotated[bool | None, Field(alias='hasMore')] = None
    timestamp: FlexibleDatetime | None = None
    remaining_count: Annotated[int | None, Field(alias='remainingCount')] = None


class CreateItemSalesTaxRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description='(Required) The name or identifier for the new sales tax item.', max_length=31)]
    barcode: Annotated[BarCodeRequest | None, Field(description='(Optional) BarCode information.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Indicates whether the sales tax item is active.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID of the QuickBooks Class associated with this item. (Flattened-ID Pattern)')] = None
    description: str | None = None
    tax_rate: Annotated[float | None, Field(alias='taxRate', description='(Optional) The tax rate as a percentage (e.g., 7.5 for 7.5%).')] = None
    tax_vendor_id: Annotated[str | None, Field(alias='taxVendorId', description='(Optional) The ListID of the Vendor (Tax Agency) the sales tax is paid to. (Flattened-ID Pattern)')] = None
    sales_tax_return_line_id: Annotated[str | None, Field(alias='salesTaxReturnLineId', description='(Optional) The ListID of the Sales Tax Return Line to be associated with this tax item. (Flattened-ID Pattern)')] = None
    external_id: Annotated[str | None, Field(alias='externalId')] = None


class UpdateItemSalesTaxRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    revision_number: Annotated[str, Field(alias='revisionNumber')]
    name: Annotated[str | None, Field(description='(Optional) The name or identifier for the sales tax item.', max_length=31)] = None
    barcode: Annotated[BarCodeRequest | None, Field(description='(Optional) BarCode information.')] = None
    is_active: Annotated[bool | None, Field(alias='isActive', description='(Optional) Indicates whether the sales tax item is active.')] = None
    class_id: Annotated[str | None, Field(alias='classId', description='(Optional) The ListID of the QuickBooks Class associated with this item. (Flattened-ID Pattern)')] = None
    description: str | None = None
    tax_rate: Annotated[float | None, Field(alias='taxRate', description='(Optional) The tax rate as a percentage (e.g., 7.5 for 7.5%).')] = None
    tax_vendor_id: Annotated[str | None, Field(alias='taxVendorId', description='(Optional) The ListID of the Vendor (Tax Agency) the sales tax is paid to. (Flattened-ID Pattern)')] = None
    sales_tax_return_line_id: Annotated[str | None, Field(alias='salesTaxReturnLineId', description='(Optional) The ListID of the Sales Tax Return Line to be associated with this tax item. (Flattened-ID Pattern)')] = None
