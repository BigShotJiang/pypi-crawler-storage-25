//! AST → simulator [`Circuit`] 변환.
//!
//! - qreg/creg 선언을 모아 (reg_name → (offset, size)) 맵으로 통합.
//! - gate-decl 들을 user-defined gate 룩업 테이블에 저장.
//! - 게이트 호출은 (a) qelib1/stdgates 표 → (b) user-defined inline → (c) UnknownGate
//!   순으로 dispatch.
//! - `if (c==N) ...`, `reset`, `opaque`, 3.0 control flow 는 명시적 UnsupportedFeature.
//!
//! [`Circuit`]: qsim_simulator::Circuit

use std::collections::HashMap;

use qsim_simulator::Circuit;

use crate::ast::*;
use crate::error::{QasmError, QasmResult};
use crate::gates_lib::apply_named_gate;

const MAX_INLINE_DEPTH: usize = 16;

#[derive(Debug, Clone)]
struct RegInfo {
    offset: usize,
    size: usize,
}

pub fn lower_program(program: Program) -> QasmResult<Circuit> {
    // ----- 1단계: qreg/creg/gate-decl 수집 -----
    let mut qregs: HashMap<String, RegInfo> = HashMap::new();
    let mut cregs: HashMap<String, RegInfo> = HashMap::new();
    let mut gate_decls: HashMap<String, GateDecl> = HashMap::new();
    let mut total_qubits = 0usize;
    let mut total_cbits = 0usize;
    let mut allowed_includes_seen = false;

    for stmt in &program.stmts {
        match stmt {
            Stmt::Include { file, line, col } => {
                // qelib1.inc / stdgates.inc 만 인식. 다른 파일은 error.
                if file != "qelib1.inc" && file != "stdgates.inc" {
                    return Err(QasmError::UnsupportedFeature {
                        message: format!(
                            "include of {file:?} at line {line}:{col} not supported (only qelib1.inc / stdgates.inc)"
                        ),
                        planned_for: "v0.4+",
                    });
                }
                allowed_includes_seen = true;
            }
            Stmt::QregDecl { name, size } => {
                if qregs.contains_key(name) {
                    return Err(QasmError::Lower {
                        message: format!("duplicate qreg/qubit declaration {name:?}"),
                    });
                }
                qregs.insert(
                    name.clone(),
                    RegInfo {
                        offset: total_qubits,
                        size: *size,
                    },
                );
                total_qubits += size;
            }
            Stmt::CregDecl { name, size } => {
                if cregs.contains_key(name) {
                    return Err(QasmError::Lower {
                        message: format!("duplicate creg/bit declaration {name:?}"),
                    });
                }
                cregs.insert(
                    name.clone(),
                    RegInfo {
                        offset: total_cbits,
                        size: *size,
                    },
                );
                total_cbits += size;
            }
            Stmt::GateDecl(decl) => {
                if gate_decls.contains_key(&decl.name) {
                    return Err(QasmError::Lower {
                        message: format!("duplicate gate definition {:?}", decl.name),
                    });
                }
                gate_decls.insert(decl.name.clone(), decl.clone());
            }
            Stmt::OpaqueDecl { name, line, col } => {
                return Err(QasmError::UnsupportedFeature {
                    message: format!(
                        "opaque gate declaration {name:?} at line {line}:{col} not supported"
                    ),
                    planned_for: "v0.5",
                });
            }
            _ => {}
        }
    }
    let _ = allowed_includes_seen; // 현재는 검사만. v0.4 에서 strict mode option.

    let mut circuit = Circuit::new(total_qubits);

    // ----- 2단계: 본문 lowering -----
    for stmt in &program.stmts {
        match stmt {
            Stmt::Include { .. }
            | Stmt::QregDecl { .. }
            | Stmt::CregDecl { .. }
            | Stmt::GateDecl(_)
            | Stmt::OpaqueDecl { .. } => {} // 이미 처리.
            Stmt::Barrier { .. } => {} // no-op.
            Stmt::GateCall(call) => {
                lower_gate_call(&mut circuit, call, &qregs, &gate_decls, &Env::empty(), 0)?;
            }
            Stmt::Measure {
                qubit,
                cbit,
                line,
                col,
            } => {
                let q = resolve_qarg(qubit, &qregs).map_err(|e| with_loc(e, *line, *col))?;
                let c = resolve_carg(cbit, &cregs).map_err(|e| with_loc(e, *line, *col))?;
                if q.len() != c.len() {
                    return Err(QasmError::Lower {
                        message: format!(
                            "measure at line {line}:{col}: qubit/cbit broadcast size mismatch ({} vs {})",
                            q.len(),
                            c.len()
                        ),
                    });
                }
                for (qi, ci) in q.into_iter().zip(c) {
                    circuit.measure(qi, ci);
                }
            }
            Stmt::Reset { line, col, .. } => {
                return Err(QasmError::UnsupportedFeature {
                    message: format!(
                        "'reset' at line {line}:{col} requires mid-circuit measurement"
                    ),
                    planned_for: "v0.5",
                });
            }
            Stmt::If { line, col, .. } => {
                return Err(QasmError::UnsupportedFeature {
                    message: format!(
                        "classical control flow 'if (c == N) ...' at line {line}:{col} requires mid-circuit measurement"
                    ),
                    planned_for: "v0.5",
                });
            }
            Stmt::UnsupportedV3 { keyword, line, col } => {
                return Err(QasmError::UnsupportedFeature {
                    message: format!(
                        "OpenQASM 3.0 '{keyword}' (dynamic circuits) at line {line}:{col}"
                    ),
                    planned_for: "v0.5",
                });
            }
        }
    }

    Ok(circuit)
}

/// 게이트 호출 lowering. user-defined gate 일 경우 inline 확장한다.
#[allow(clippy::only_used_in_recursion)]
fn lower_gate_call(
    circuit: &mut Circuit,
    call: &GateCall,
    qregs: &HashMap<String, RegInfo>,
    gate_decls: &HashMap<String, GateDecl>,
    env: &Env,
    depth: usize,
) -> QasmResult<()> {
    if depth > MAX_INLINE_DEPTH {
        return Err(QasmError::RecursionLimit {
            name: call.name.clone(),
            limit: MAX_INLINE_DEPTH,
        });
    }

    // 파라미터 평가.
    let params: Vec<f64> = call
        .params
        .iter()
        .map(|e| eval_expr(e, env))
        .collect::<QasmResult<_>>()?;

    // qarg 해석.
    let qargs_resolved: Vec<Vec<usize>> = call
        .qargs
        .iter()
        .map(|q| resolve_qarg_in_env(q, qregs, env))
        .collect::<QasmResult<_>>()?;

    // broadcast 길이 결정.
    let broadcast = determine_broadcast(&qargs_resolved, &call.name, call.line, call.col)?;
    for k in 0..broadcast {
        let qubits: Vec<usize> = qargs_resolved
            .iter()
            .map(|qs| if qs.len() == 1 { qs[0] } else { qs[k] })
            .collect();

        // 1) qelib1/stdgates 표 시도
        if apply_named_gate(circuit, &call.name, &params, &qubits, call.line, call.col)? {
            continue;
        }
        // 2) user-defined gate inline
        if let Some(decl) = gate_decls.get(&call.name) {
            inline_user_gate(
                circuit,
                decl,
                &params,
                &qubits,
                qregs,
                gate_decls,
                depth + 1,
            )?;
            continue;
        }
        // 3) 모르는 게이트
        return Err(QasmError::UnknownGate {
            line: call.line,
            col: call.col,
            name: call.name.clone(),
        });
    }
    Ok(())
}

fn inline_user_gate(
    circuit: &mut Circuit,
    decl: &GateDecl,
    params: &[f64],
    qubits: &[usize],
    qregs: &HashMap<String, RegInfo>,
    gate_decls: &HashMap<String, GateDecl>,
    depth: usize,
) -> QasmResult<()> {
    if params.len() != decl.params.len() {
        return Err(QasmError::Lower {
            message: format!(
                "gate {:?} expected {} parameters, got {}",
                decl.name,
                decl.params.len(),
                params.len()
            ),
        });
    }
    if qubits.len() != decl.qubits.len() {
        return Err(QasmError::ArityMismatch {
            line: decl.line,
            col: decl.col,
            gate: decl.name.clone(),
            expected: decl.qubits.len(),
            got: qubits.len(),
        });
    }
    let mut env = Env::empty();
    for (name, value) in decl.params.iter().zip(params.iter()) {
        env.insert_param(name.clone(), *value);
    }
    for (name, qi) in decl.qubits.iter().zip(qubits.iter()) {
        env.insert_qubit(name.clone(), *qi);
    }
    for inner_call in &decl.body {
        lower_gate_call(circuit, inner_call, qregs, gate_decls, &env, depth)?;
    }
    Ok(())
}

#[derive(Debug, Default)]
struct Env {
    params: HashMap<String, f64>,
    qubits: HashMap<String, usize>,
}

impl Env {
    fn empty() -> Self {
        Self::default()
    }
    fn insert_param(&mut self, name: String, value: f64) {
        self.params.insert(name, value);
    }
    fn insert_qubit(&mut self, name: String, idx: usize) {
        self.qubits.insert(name, idx);
    }
}

/// `Stmt::Measure` 등 외부 호출용 — 단일 qarg → 큐비트 인덱스 리스트.
fn resolve_qarg(q: &QArg, qregs: &HashMap<String, RegInfo>) -> QasmResult<Vec<usize>> {
    resolve_qarg_in_env(q, qregs, &Env::empty())
}

/// gate-decl 본문 내 qubit name → 외부 qubit index 매핑 우선, 없으면 qreg lookup.
fn resolve_qarg_in_env(
    q: &QArg,
    qregs: &HashMap<String, RegInfo>,
    env: &Env,
) -> QasmResult<Vec<usize>> {
    match q {
        QArg::Indexed { reg, idx } => {
            if env.qubits.contains_key(reg) {
                return Err(QasmError::Lower {
                    message: format!("indexed qubit '{reg}[{idx}]' inside gate body not allowed"),
                });
            }
            let info = qregs.get(reg).ok_or_else(|| QasmError::Lower {
                message: format!("undefined qreg/qubit register {reg:?}"),
            })?;
            if *idx >= info.size {
                return Err(QasmError::QubitOutOfRange {
                    qubit: *idx,
                    n_qubits: info.size,
                });
            }
            Ok(vec![info.offset + idx])
        }
        QArg::Whole { reg } => {
            // gate-body 안의 매개변수 이름이면 단일 인덱스 반환.
            if let Some(qi) = env.qubits.get(reg) {
                return Ok(vec![*qi]);
            }
            let info = qregs.get(reg).ok_or_else(|| QasmError::Lower {
                message: format!("undefined qreg/qubit register {reg:?}"),
            })?;
            Ok((info.offset..info.offset + info.size).collect())
        }
    }
}

fn resolve_carg(c: &CArg, cregs: &HashMap<String, RegInfo>) -> QasmResult<Vec<usize>> {
    match c {
        CArg::Indexed { reg, idx } => {
            let info = cregs.get(reg).ok_or_else(|| QasmError::Lower {
                message: format!("undefined creg/bit register {reg:?}"),
            })?;
            if *idx >= info.size {
                return Err(QasmError::CbitOutOfRange {
                    cbit: *idx,
                    n_cbits: info.size,
                });
            }
            Ok(vec![info.offset + idx])
        }
        CArg::Whole { reg } => {
            let info = cregs.get(reg).ok_or_else(|| QasmError::Lower {
                message: format!("undefined creg/bit register {reg:?}"),
            })?;
            Ok((info.offset..info.offset + info.size).collect())
        }
    }
}

/// 여러 qarg 가 broadcast (일부는 single-qubit, 일부는 register-whole) 가능 여부 검사.
/// 모두 size-1 이거나, register-whole 들의 size 가 같아야.
fn determine_broadcast(
    qargs: &[Vec<usize>],
    gate: &str,
    line: usize,
    col: usize,
) -> QasmResult<usize> {
    let mut broadcast = 1usize;
    for qs in qargs {
        if qs.len() > 1 {
            if broadcast > 1 && broadcast != qs.len() {
                return Err(QasmError::Lower {
                    message: format!(
                        "gate '{gate}' at line {line}:{col}: broadcast size mismatch ({} vs {})",
                        broadcast,
                        qs.len()
                    ),
                });
            }
            broadcast = qs.len();
        }
    }
    Ok(broadcast)
}

fn with_loc(err: QasmError, line: usize, col: usize) -> QasmError {
    match err {
        QasmError::Lower { message } => QasmError::Lower {
            message: format!("at line {line}:{col}: {message}"),
        },
        e => e,
    }
}

/// 표현식 평가. user-defined gate 안에서는 [`Env`] 의 param 이름을 substitute.
fn eval_expr(e: &Expr, env: &Env) -> QasmResult<f64> {
    match e {
        Expr::Int(n) => Ok(*n as f64),
        Expr::Real(x) => Ok(*x),
        Expr::Pi => Ok(std::f64::consts::PI),
        Expr::Var(name) => env
            .params
            .get(name)
            .copied()
            .ok_or_else(|| QasmError::Lower {
                message: format!("undefined parameter {name:?} in expression"),
            }),
        Expr::Neg(inner) => Ok(-eval_expr(inner, env)?),
        Expr::Bin { op, lhs, rhs } => {
            let l = eval_expr(lhs, env)?;
            let r = eval_expr(rhs, env)?;
            Ok(match op {
                BinOp::Add => l + r,
                BinOp::Sub => l - r,
                BinOp::Mul => l * r,
                BinOp::Div => l / r,
                BinOp::Pow => l.powf(r),
            })
        }
        Expr::Call { fn_, arg } => {
            let v = eval_expr(arg, env)?;
            Ok(match fn_ {
                BuiltinFn::Sin => v.sin(),
                BuiltinFn::Cos => v.cos(),
                BuiltinFn::Tan => v.tan(),
                BuiltinFn::Exp => v.exp(),
                BuiltinFn::Ln => v.ln(),
                BuiltinFn::Sqrt => v.sqrt(),
            })
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::lexer::Lexer;
    use crate::parser::Parser;

    fn lower(src: &str) -> Circuit {
        let toks = Lexer::new(src).tokenize().unwrap();
        let prog = Parser::new(toks).parse_program().unwrap();
        lower_program(prog).unwrap()
    }

    #[test]
    fn test_bell_basic() {
        let c = lower("OPENQASM 2.0; include \"qelib1.inc\"; qreg q[2]; h q[0]; cx q[0], q[1];");
        assert_eq!(c.num_qubits(), 2);
        assert_eq!(c.instructions().len(), 2);
    }

    #[test]
    fn test_two_qregs_offsets() {
        let c = lower("OPENQASM 2.0; qreg a[2]; qreg b[3]; h a[0]; h b[2];");
        assert_eq!(c.num_qubits(), 5);
    }

    #[test]
    fn test_user_defined_gate_inline() {
        let c = lower("OPENQASM 2.0; qreg q[2]; gate bell a, b { h a; cx a, b; } bell q[0], q[1];");
        // bell 호출이 h + cx 두 인스트럭션으로 inline 되어야.
        assert_eq!(c.instructions().len(), 2);
    }

    #[test]
    fn test_parameter_substitution() {
        let c = lower("OPENQASM 2.0; qreg q[1]; gate myrx(a) q { rx(a/2) q; } myrx(pi) q[0];");
        assert_eq!(c.instructions().len(), 1);
    }

    #[test]
    fn test_v3_qubit_decl() {
        let c = lower("OPENQASM 3.0; include \"stdgates.inc\"; qubit[3] q; h q[0]; cx q[0], q[1]; cx q[0], q[2];");
        assert_eq!(c.num_qubits(), 3);
    }

    #[test]
    fn test_measure_emits_instruction() {
        let c = lower(
            "OPENQASM 2.0; qreg q[2]; creg c[2]; h q[0]; cx q[0], q[1]; measure q[0] -> c[0]; measure q[1] -> c[1];",
        );
        assert_eq!(c.num_cbits(), 2);
    }

    #[test]
    fn test_unsupported_if_errors() {
        let toks = Lexer::new("OPENQASM 2.0; qreg q[1]; creg c[1]; if (c == 1) x q[0];")
            .tokenize()
            .unwrap();
        let prog = Parser::new(toks).parse_program().unwrap();
        let r = lower_program(prog);
        assert!(matches!(r, Err(QasmError::UnsupportedFeature { .. })));
    }

    #[test]
    fn test_unknown_gate_errors() {
        let toks = Lexer::new("OPENQASM 2.0; qreg q[1]; foo q[0];")
            .tokenize()
            .unwrap();
        let prog = Parser::new(toks).parse_program().unwrap();
        let r = lower_program(prog);
        assert!(matches!(r, Err(QasmError::UnknownGate { .. })));
    }

    #[test]
    fn test_recursive_gate_hits_limit() {
        let toks = Lexer::new("OPENQASM 2.0; qreg q[1]; gate a x { a x; } a q[0];")
            .tokenize()
            .unwrap();
        let prog = Parser::new(toks).parse_program().unwrap();
        let r = lower_program(prog);
        assert!(matches!(r, Err(QasmError::RecursionLimit { .. })));
    }
}
