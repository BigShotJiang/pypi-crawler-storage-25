use num_complex::Complex;

use crate::complex::{complex, imag_unit, one, real, zero, Real};

/// 2×2 유니터리 행렬 (행 우선), 정밀도 `F`.
pub type Matrix2x2<F> = [[Complex<F>; 2]; 2];

/// 4×4 유니터리 행렬 (행 우선), 정밀도 `F`.
pub type Matrix4x4<F> = [[Complex<F>; 4]; 4];

/// 양자 게이트 정의.
///
/// 회전 각도는 항상 `f64` 로 저장한다. 행렬을 빌드할 때 trig (cos/sin) 도
/// `f64` 로 계산한 뒤 결과만 `F` 로 다운캐스트해야 깊은 회로의 phase 누적 오차를 방지할 수 있다.
#[derive(Debug, Clone)]
pub enum Gate {
    // 단일 큐비트 게이트
    H,
    X,
    Y,
    Z,
    S,
    Sdg,
    T,
    Tdg,
    Rx(f64),
    Ry(f64),
    Rz(f64),
    /// OpenQASM `U(θ,φ,λ)` 의 일반 1-큐비트 유니터리.
    /// Qiskit 의 `u3(θ,φ,λ)` / 3.0 의 `u(θ,φ,λ)` / `p(λ) = U(0,0,λ)` / `u1(λ) = U(0,0,λ)` 와 동일.
    /// 행렬: `[[cos(θ/2), -e^(iλ)sin(θ/2)], [e^(iφ)sin(θ/2), e^(i(φ+λ))cos(θ/2)]]`.
    /// 글로벌 phase 까지 정확히 Qiskit 정의 (statevector 1e-10 cross-check 용).
    U(f64, f64, f64),
    Id,
    // 2큐비트 게이트
    CNOT,
    CZ,
    SWAP,
    // 3큐비트 게이트
    Toffoli,
    Fredkin,
}

const FRAC_1_SQRT2: f64 = std::f64::consts::FRAC_1_SQRT_2;

impl Gate {
    /// 단일 큐비트 게이트의 2×2 유니터리 행렬을 정밀도 `F` 로 반환한다.
    ///
    /// trig 연산은 `f64` 에서 수행한 뒤 `F` 로 다운캐스트한다 (정밀도 보존).
    pub fn matrix_2x2<F: Real>(&self) -> Matrix2x2<F> {
        match self {
            Gate::H => {
                let s = real::<F>(FRAC_1_SQRT2);
                let neg_s = real::<F>(-FRAC_1_SQRT2);
                [[s, s], [s, neg_s]]
            }
            Gate::X => [[zero(), one()], [one(), zero()]],
            Gate::Y => {
                let neg_i: Complex<F> = -imag_unit::<F>();
                let i = imag_unit::<F>();
                [[zero(), neg_i], [i, zero()]]
            }
            Gate::Z => [[one(), zero()], [zero(), real::<F>(-1.0)]],
            Gate::S => [[one(), zero()], [zero(), imag_unit()]],
            Gate::Sdg => {
                let neg_i: Complex<F> = -imag_unit::<F>();
                [[one(), zero()], [zero(), neg_i]]
            }
            Gate::T => {
                // exp(iπ/4) = (1 + i)/√2
                let phase = complex::<F>(FRAC_1_SQRT2, FRAC_1_SQRT2);
                [[one(), zero()], [zero(), phase]]
            }
            Gate::Tdg => {
                // exp(-iπ/4) = (1 - i)/√2
                let phase = complex::<F>(FRAC_1_SQRT2, -FRAC_1_SQRT2);
                [[one(), zero()], [zero(), phase]]
            }
            Gate::U(theta, phi, lambda) => {
                // Qiskit u3 정의: [[cos(θ/2),       -e^(iλ)·sin(θ/2)],
                //                  [e^(iφ)·sin(θ/2), e^(i(φ+λ))·cos(θ/2)]]
                // -e^(iλ)·sin = -(cos λ + i sin λ)·s = (-s cos λ) + i(-s sin λ)
                let c = (theta / 2.0).cos();
                let s = (theta / 2.0).sin();
                let phi_plus_lambda = phi + lambda;
                let m00 = real::<F>(c);
                let m01 = complex::<F>(-s * lambda.cos(), -s * lambda.sin());
                let m10 = complex::<F>(s * phi.cos(), s * phi.sin());
                let m11 = complex::<F>(c * phi_plus_lambda.cos(), c * phi_plus_lambda.sin());
                [[m00, m01], [m10, m11]]
            }
            Gate::Rx(theta) => {
                let c = (theta / 2.0).cos();
                let s = (theta / 2.0).sin();
                let cos_term = real::<F>(c);
                let neg_i_sin = complex::<F>(0.0, -s);
                [[cos_term, neg_i_sin], [neg_i_sin, cos_term]]
            }
            Gate::Ry(theta) => {
                let c = (theta / 2.0).cos();
                let s = (theta / 2.0).sin();
                let cos_term = real::<F>(c);
                let sin_term = real::<F>(s);
                let neg_sin = real::<F>(-s);
                [[cos_term, neg_sin], [sin_term, cos_term]]
            }
            Gate::Rz(theta) => {
                let neg_phase = complex::<F>((-theta / 2.0).cos(), (-theta / 2.0).sin());
                let pos_phase = complex::<F>((theta / 2.0).cos(), (theta / 2.0).sin());
                [[neg_phase, zero()], [zero(), pos_phase]]
            }
            Gate::Id => [[one(), zero()], [zero(), one()]],
            _ => panic!("matrix_2x2는 단일 큐비트 게이트에만 사용 가능"),
        }
    }

    /// CNOT 게이트의 4×4 유니터리 행렬을 반환한다.
    pub fn cnot_matrix<F: Real>() -> Matrix4x4<F> {
        [
            [one(), zero(), zero(), zero()],
            [zero(), one(), zero(), zero()],
            [zero(), zero(), zero(), one()],
            [zero(), zero(), one(), zero()],
        ]
    }

    /// CZ 게이트의 4×4 유니터리 행렬을 반환한다.
    pub fn cz_matrix<F: Real>() -> Matrix4x4<F> {
        let neg_one: Complex<F> = real::<F>(-1.0);
        [
            [one(), zero(), zero(), zero()],
            [zero(), one(), zero(), zero()],
            [zero(), zero(), one(), zero()],
            [zero(), zero(), zero(), neg_one],
        ]
    }

    /// SWAP 게이트의 4×4 유니터리 행렬을 반환한다.
    pub fn swap_matrix<F: Real>() -> Matrix4x4<F> {
        [
            [one(), zero(), zero(), zero()],
            [zero(), zero(), one(), zero()],
            [zero(), one(), zero(), zero()],
            [zero(), zero(), zero(), one()],
        ]
    }

    /// Custom 유니터리 게이트(2×2)를 그대로 반환한다 (식별 함수).
    pub fn custom_2x2<F: Real>(matrix: Matrix2x2<F>) -> Matrix2x2<F> {
        matrix
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::complex::{approx_eq, ONE, ZERO};

    #[test]
    fn test_hadamard_is_unitary_f64() {
        let h: Matrix2x2<f64> = Gate::H.matrix_2x2();
        // H * H = I
        for i in 0..2 {
            for j in 0..2 {
                let sum: Complex<f64> = (0..2).map(|k| h[i][k] * h[k][j]).sum();
                let expected = if i == j { ONE } else { ZERO };
                assert!(approx_eq(sum, expected, 1e-10));
            }
        }
    }

    #[test]
    fn test_hadamard_is_unitary_f32() {
        let h: Matrix2x2<f32> = Gate::H.matrix_2x2();
        for i in 0..2 {
            for j in 0..2 {
                let sum: Complex<f32> = (0..2).map(|k| h[i][k] * h[k][j]).sum();
                let expected = if i == j {
                    Complex::new(1.0_f32, 0.0)
                } else {
                    Complex::new(0.0_f32, 0.0)
                };
                assert!(approx_eq(sum, expected, 1e-6_f32));
            }
        }
    }

    #[test]
    fn test_x_gate() {
        let x: Matrix2x2<f64> = Gate::X.matrix_2x2();
        assert_eq!(x[0][1], ONE);
        assert_eq!(x[1][0], ONE);
    }

    #[test]
    #[allow(clippy::needless_range_loop)]
    fn test_sdg_is_inverse_of_s() {
        let s: Matrix2x2<f64> = Gate::S.matrix_2x2();
        let sdg: Matrix2x2<f64> = Gate::Sdg.matrix_2x2();
        // S * Sdg = I
        for i in 0..2 {
            for j in 0..2 {
                let sum: Complex<f64> = (0..2).map(|k| s[i][k] * sdg[k][j]).sum();
                let expected = if i == j { ONE } else { ZERO };
                assert!(approx_eq(sum, expected, 1e-12));
            }
        }
    }

    #[test]
    #[allow(clippy::needless_range_loop)]
    fn test_tdg_is_inverse_of_t() {
        let t: Matrix2x2<f64> = Gate::T.matrix_2x2();
        let tdg: Matrix2x2<f64> = Gate::Tdg.matrix_2x2();
        for i in 0..2 {
            for j in 0..2 {
                let sum: Complex<f64> = (0..2).map(|k| t[i][k] * tdg[k][j]).sum();
                let expected = if i == j { ONE } else { ZERO };
                assert!(approx_eq(sum, expected, 1e-12));
            }
        }
    }

    #[test]
    #[allow(clippy::needless_range_loop)]
    fn test_u_gate_special_cases() {
        // U(0, 0, 0) = I
        let u: Matrix2x2<f64> = Gate::U(0.0, 0.0, 0.0).matrix_2x2();
        assert!(approx_eq(u[0][0], ONE, 1e-12));
        assert!(approx_eq(u[1][1], ONE, 1e-12));
        assert!(approx_eq(u[0][1], ZERO, 1e-12));
        assert!(approx_eq(u[1][0], ZERO, 1e-12));

        // U(0, 0, π/2) = S = diag(1, i)
        let u_s: Matrix2x2<f64> = Gate::U(0.0, 0.0, std::f64::consts::FRAC_PI_2).matrix_2x2();
        let s: Matrix2x2<f64> = Gate::S.matrix_2x2();
        for i in 0..2 {
            for j in 0..2 {
                assert!(approx_eq(u_s[i][j], s[i][j], 1e-12));
            }
        }

        // U(0, 0, π) = Z (up to identity in form)
        let u_z: Matrix2x2<f64> = Gate::U(0.0, 0.0, std::f64::consts::PI).matrix_2x2();
        let z: Matrix2x2<f64> = Gate::Z.matrix_2x2();
        for i in 0..2 {
            for j in 0..2 {
                assert!(approx_eq(u_z[i][j], z[i][j], 1e-12));
            }
        }

        // U(π, 0, π) = X (Qiskit u3(π, 0, π) == X exactly, no global phase)
        let u_x: Matrix2x2<f64> =
            Gate::U(std::f64::consts::PI, 0.0, std::f64::consts::PI).matrix_2x2();
        let x: Matrix2x2<f64> = Gate::X.matrix_2x2();
        for i in 0..2 {
            for j in 0..2 {
                assert!(
                    approx_eq(u_x[i][j], x[i][j], 1e-12),
                    "U(π,0,π)[{i}][{j}]={:?} ≠ X[{i}][{j}]={:?}",
                    u_x[i][j],
                    x[i][j]
                );
            }
        }
    }

    #[test]
    #[allow(clippy::needless_range_loop)]
    fn test_u_gate_matches_qiskit_u3_formula() {
        // 임의 θ, φ, λ 에서 Qiskit u3 행렬 정의와 정확히 일치하는지.
        let theta = 1.234_f64;
        let phi = -0.5_f64;
        let lambda = 2.7_f64;
        let u: Matrix2x2<f64> = Gate::U(theta, phi, lambda).matrix_2x2();
        let c = (theta / 2.0).cos();
        let s = (theta / 2.0).sin();
        let expected = [
            [
                Complex::new(c, 0.0),
                Complex::new(-s * lambda.cos(), -s * lambda.sin()),
            ],
            [
                Complex::new(s * phi.cos(), s * phi.sin()),
                Complex::new(c * (phi + lambda).cos(), c * (phi + lambda).sin()),
            ],
        ];
        for i in 0..2 {
            for j in 0..2 {
                assert!(approx_eq(u[i][j], expected[i][j], 1e-15));
            }
        }
    }

    #[test]
    fn test_rz_matches_f64_and_f32() {
        // Rz(π/8) 의 trig 결과가 f64 → f32 cast 시 ~1e-7 이내인지 확인
        let theta = std::f64::consts::PI / 8.0;
        let m64: Matrix2x2<f64> = Gate::Rz(theta).matrix_2x2();
        let m32: Matrix2x2<f32> = Gate::Rz(theta).matrix_2x2();
        for i in 0..2 {
            for j in 0..2 {
                let r_diff = (m64[i][j].re as f32 - m32[i][j].re).abs();
                let i_diff = (m64[i][j].im as f32 - m32[i][j].im).abs();
                assert!(r_diff < 1e-6 && i_diff < 1e-6, "Rz f32 cast 정밀도 손실");
            }
        }
    }
}
