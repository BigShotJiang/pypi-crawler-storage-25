use num_complex::Complex;
use numpy::{PyArray1, PyReadonlyArray2};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyDict;

use qsim_core::Gate;
use qsim_simulator::{
    Circuit, ExecutionEngine, Instruction, NoiseChannel, Precision, SimulationResult,
};

/// Python에서 사용 가능한 양자 회로 클래스.
#[pyclass(name = "Circuit")]
struct PyCircuit {
    inner: Circuit,
}

#[pymethods]
impl PyCircuit {
    #[new]
    fn new(n_qubits: usize) -> Self {
        Self {
            inner: Circuit::new(n_qubits),
        }
    }

    fn num_qubits(&self) -> usize {
        self.inner.num_qubits()
    }

    // 단일 큐비트 게이트
    fn h(&mut self, qubit: usize) {
        self.inner.h(qubit);
    }
    fn x(&mut self, qubit: usize) {
        self.inner.x(qubit);
    }
    fn y(&mut self, qubit: usize) {
        self.inner.y(qubit);
    }
    fn z(&mut self, qubit: usize) {
        self.inner.z(qubit);
    }
    fn s(&mut self, qubit: usize) {
        self.inner.s(qubit);
    }
    fn sdg(&mut self, qubit: usize) {
        self.inner.sdg(qubit);
    }
    fn t(&mut self, qubit: usize) {
        self.inner.t(qubit);
    }
    fn tdg(&mut self, qubit: usize) {
        self.inner.tdg(qubit);
    }
    fn rx(&mut self, theta: f64, qubit: usize) {
        self.inner.rx(theta, qubit);
    }
    fn ry(&mut self, theta: f64, qubit: usize) {
        self.inner.ry(theta, qubit);
    }
    fn rz(&mut self, theta: f64, qubit: usize) {
        self.inner.rz(theta, qubit);
    }
    fn id(&mut self, qubit: usize) {
        self.inner.id(qubit);
    }

    // 2큐비트 게이트
    fn cx(&mut self, control: usize, target: usize) {
        self.inner.cx(control, target);
    }
    fn cz(&mut self, qubit0: usize, qubit1: usize) {
        self.inner.cz(qubit0, qubit1);
    }
    fn swap(&mut self, qubit0: usize, qubit1: usize) {
        self.inner.swap(qubit0, qubit1);
    }

    // 3큐비트 게이트
    fn ccx(&mut self, ctrl1: usize, ctrl2: usize, target: usize) {
        self.inner.ccx(ctrl1, ctrl2, target);
    }
    fn cswap(&mut self, control: usize, target1: usize, target2: usize) {
        self.inner.cswap(control, target1, target2);
    }

    fn measure(&mut self, qubit: usize, cbit: usize) {
        self.inner.measure(qubit, cbit);
    }
    fn measure_all(&mut self) {
        self.inner.measure_all();
    }

    /// OpenQASM 2.0 또는 3.0 문자열을 파싱해 [`Circuit`] 으로 만든다.
    ///
    /// 헤더 (`OPENQASM 2.0;` 또는 `OPENQASM 3.0;`) 로 버전 자동 감지.
    /// 미지원 syntax (`if`, `reset`, `for`/`while`/`box`, `sx`/`gphase` 등) 는
    /// `ValueError` 로 변환되어 사용자에게 명확한 milestone 정보가 노출된다.
    #[staticmethod]
    fn from_qasm(qasm: &str) -> PyResult<Self> {
        let circuit =
            qsim_qasm::parse_qasm(qasm).map_err(|e| PyValueError::new_err(format!("{e}")))?;
        Ok(Self { inner: circuit })
    }

    /// 회로를 OpenQASM 문자열로 export 한다.
    ///
    /// `version`: `"2.0"` (default) 또는 `"3.0"`. 다른 값은 `ValueError`.
    #[pyo3(signature = (version = "2.0"))]
    fn to_qasm(&self, version: &str) -> PyResult<String> {
        let dialect = match version {
            "2.0" | "2" => qsim_qasm::QasmDialect::V2,
            "3.0" | "3" => qsim_qasm::QasmDialect::V3,
            other => {
                return Err(PyValueError::new_err(format!(
                    "to_qasm: version 은 '2.0' 또는 '3.0' 이어야 합니다 (입력: {other:?})"
                )));
            }
        };
        Ok(qsim_qasm::circuit_to_qasm(&self.inner, dialect))
    }

    /// 임의 2×2 unitary 행렬을 회로의 `qubit` 큐비트에 적용한다.
    ///
    /// Z-Y-Z 분해 (Nielsen-Chuang Thm 4.1) 로 native 게이트 시퀀스
    /// `Rz(δ); Ry(γ); Rz(β)` 를 추가하고 글로벌 phase α 는 회로의
    /// global_phase 에 누적된다.
    ///
    /// `validate=True` (default) 일 때 입력 행렬의 unitarity (`M·M† ≈ I`,
    /// 1e-10) 를 검증하고 위반 시 `ValueError`. `False` 면 검증 생략.
    #[pyo3(signature = (matrix, qubit, validate = true))]
    fn unitary(
        &mut self,
        matrix: PyReadonlyArray2<Complex<f64>>,
        qubit: usize,
        validate: bool,
    ) -> PyResult<()> {
        let arr = matrix.as_array();
        if arr.shape() != [2, 2] {
            return Err(PyValueError::new_err(format!(
                "unitary: matrix 는 2×2 여야 합니다 (입력 shape={:?})",
                arr.shape()
            )));
        }
        let m: qsim_transpiler::Matrix2 = [[arr[[0, 0]], arr[[0, 1]]], [arr[[1, 0]], arr[[1, 1]]]];
        if validate {
            qsim_transpiler::is_unitary_2x2(&m, 1e-10)
                .map_err(|e| PyValueError::new_err(format!("unitary: {e}")))?;
        }
        if qubit >= self.inner.num_qubits() {
            return Err(PyValueError::new_err(format!(
                "unitary: qubit 인덱스 {qubit} 가 범위를 벗어남 (n_qubits={})",
                self.inner.num_qubits()
            )));
        }
        qsim_transpiler::append_unitary(&mut self.inner, &m, qubit);
        Ok(())
    }

    /// 회로에 peephole 최적화 패스를 in-place 로 적용한다.
    ///
    /// Cut C 에서 실제 패스 (회전 합성, 항등식, trivial drop) 가 활성화되며,
    /// 현재는 no-op stub.  반환값은 수렴까지 사용된 패스 횟수.
    #[pyo3(signature = (max_iters = 16))]
    fn transpile(&mut self, max_iters: usize) -> usize {
        let stats = qsim_transpiler::peephole_optimize(&mut self.inner, max_iters);
        stats.passes
    }

    /// 회로의 누적된 글로벌 phase (라디안).
    #[getter]
    fn global_phase(&self) -> f64 {
        self.inner.global_phase()
    }

    /// 회로의 글로벌 phase 를 명시적으로 설정한다 (NoiseModel.apply_to 등에서
    /// 회로 재구성 후 phase 보존용).
    #[setter(global_phase)]
    fn set_global_phase(&mut self, lambda: f64) {
        self.inner.set_global_phase(lambda);
    }

    /// 단일 큐비트 노이즈 채널을 회로 명령 시퀀스에 추가한다 (v0.4 trajectory).
    fn add_noise(&mut self, channel: &PyNoiseChannel, qubit: usize) -> PyResult<()> {
        if qubit >= self.inner.num_qubits() {
            return Err(PyValueError::new_err(format!(
                "add_noise: qubit {qubit} 가 범위를 벗어남 (n_qubits={})",
                self.inner.num_qubits()
            )));
        }
        self.inner.add_noise(channel.inner, qubit);
        Ok(())
    }

    /// 회로의 명령 시퀀스를 Python 친화적 튜플 리스트로 반환한다.
    ///
    /// 반환 shape: `[(name, qubits, params), ...]` — Python `QuantumCircuit._ops`
    /// 와 동일 형태. `from_qasm()` 으로 만든 회로도 `_ops` 가 채워지므로
    /// `qc.draw()` / `to_qiskit()` 가 직접 매핑 path 를 사용할 수 있다.
    ///
    /// `name` → params 매핑:
    /// - 단일 큐비트 (no params): `"h"/"x"/"y"/"z"/"s"/"sdg"/"t"/"tdg"/"id"`
    /// - 회전: `"rx"/"ry"/"rz"` (params=[θ])
    /// - 일반 1-큐비트 유니터리: `"u"` (params=[θ, φ, λ])  — Qiskit u3 정의
    /// - 2/3 큐비트: `"cx"/"cz"/"swap"/"ccx"/"cswap"`
    /// - 측정: `"measure"` (qubits=[q], params=[cbit_as_f64]),
    ///   `"measure_all"` (qubits=[0..n], params=[])
    fn instructions(&self) -> Vec<(String, Vec<usize>, Vec<f64>)> {
        let mut out = Vec::with_capacity(self.inner.instructions().len());
        for inst in self.inner.instructions() {
            match inst {
                Instruction::ApplyGate { gate, targets } => {
                    let (name, params): (&str, Vec<f64>) = match gate {
                        Gate::H => ("h", vec![]),
                        Gate::X => ("x", vec![]),
                        Gate::Y => ("y", vec![]),
                        Gate::Z => ("z", vec![]),
                        Gate::S => ("s", vec![]),
                        Gate::Sdg => ("sdg", vec![]),
                        Gate::T => ("t", vec![]),
                        Gate::Tdg => ("tdg", vec![]),
                        Gate::Id => ("id", vec![]),
                        Gate::Rx(theta) => ("rx", vec![*theta]),
                        Gate::Ry(theta) => ("ry", vec![*theta]),
                        Gate::Rz(theta) => ("rz", vec![*theta]),
                        Gate::U(theta, phi, lam) => ("u", vec![*theta, *phi, *lam]),
                        Gate::CNOT => ("cx", vec![]),
                        Gate::CZ => ("cz", vec![]),
                        Gate::SWAP => ("swap", vec![]),
                        Gate::Toffoli => ("ccx", vec![]),
                        Gate::Fredkin => ("cswap", vec![]),
                    };
                    out.push((name.to_string(), targets.clone(), params));
                }
                Instruction::ApplyNoise { .. } => {
                    // Noise 명령은 Python `_ops` 형식으로 노출하지 않는다 (Cut C 에서
                    // 별도 NoiseModel 클래스가 채널을 관리). draw / to_qiskit 등 기존
                    // 어댑터가 noise 를 모르므로 skip 이 안전.
                }
                Instruction::Measure { qubit, cbit } => {
                    out.push(("measure".to_string(), vec![*qubit], vec![*cbit as f64]));
                }
                Instruction::MeasureAll => {
                    let qs: Vec<usize> = (0..self.inner.num_qubits()).collect();
                    out.push(("measure_all".to_string(), qs, vec![]));
                }
            }
        }
        out
    }
}

/// 단일 큐비트 노이즈 채널을 표현하는 Python 클래스 (v0.4).
///
/// 4 가지 표준 채널을 정적 컨스트럭터로 만든다. 모든 컨스트럭터는 파라미터
/// 범위 검증 (p ∈ [0, 1]) 후 `ValueError` 또는 인스턴스를 반환.
///
/// Python 측 [`panta_sim.NoiseModel`] 이 이 객체를 게이트 / 큐비트 필터와
/// 함께 묶어 회로에 적용한다.
#[pyclass(name = "NoiseChannel")]
#[derive(Clone)]
struct PyNoiseChannel {
    inner: NoiseChannel,
}

#[pymethods]
impl PyNoiseChannel {
    /// Bit-flip 채널: 확률 `p` 로 X 게이트 적용. p ∈ [0, 1].
    #[staticmethod]
    fn bit_flip(p: f64) -> PyResult<Self> {
        let inner = NoiseChannel::bit_flip(p).map_err(PyValueError::new_err)?;
        Ok(Self { inner })
    }

    /// Phase-flip 채널: 확률 `p` 로 Z 게이트 적용. p ∈ [0, 1].
    #[staticmethod]
    fn phase_flip(p: f64) -> PyResult<Self> {
        let inner = NoiseChannel::phase_flip(p).map_err(PyValueError::new_err)?;
        Ok(Self { inner })
    }

    /// Depolarizing 채널: 확률 `p` 로 {X, Y, Z} 균등 적용. p ∈ [0, 1].
    #[staticmethod]
    fn depolarizing(p: f64) -> PyResult<Self> {
        let inner = NoiseChannel::depolarizing(p).map_err(PyValueError::new_err)?;
        Ok(Self { inner })
    }

    /// Amplitude-damping 채널: T1 (에너지 손실) 모델. γ ∈ [0, 1].
    #[staticmethod]
    fn amplitude_damping(gamma: f64) -> PyResult<Self> {
        let inner = NoiseChannel::amplitude_damping(gamma).map_err(PyValueError::new_err)?;
        Ok(Self { inner })
    }

    fn __repr__(&self) -> String {
        match self.inner {
            NoiseChannel::BitFlip { p } => format!("NoiseChannel.bit_flip(p={p})"),
            NoiseChannel::PhaseFlip { p } => format!("NoiseChannel.phase_flip(p={p})"),
            NoiseChannel::Depolarizing { p } => format!("NoiseChannel.depolarizing(p={p})"),
            NoiseChannel::AmplitudeDamping { gamma } => {
                format!("NoiseChannel.amplitude_damping(gamma={gamma})")
            }
        }
    }
}

/// Python에서 사용 가능한 시뮬레이션 결과 클래스.
///
/// 내부 `SimulationResult` 가 정밀도별 enum 이므로 statevector / probabilities 는
/// 정밀도에 따라 numpy `complex64`/`float32` (f32) 또는 `complex128`/`float64` (f64) 를 반환한다.
#[pyclass(name = "SimulationResult")]
struct PySimulationResult {
    inner: SimulationResult,
}

#[pymethods]
impl PySimulationResult {
    /// 측정 결과 counts를 dict로 반환한다.
    fn counts(&self, py: Python<'_>) -> PyResult<Py<PyDict>> {
        let dict = PyDict::new(py);
        for (key, value) in self.inner.counts() {
            dict.set_item(key, value)?;
        }
        Ok(dict.into())
    }

    /// 시뮬레이션에 사용된 정밀도 ("f32" 또는 "f64").
    #[getter]
    fn precision(&self) -> &'static str {
        self.inner.precision().as_str()
    }

    /// 측정 전 상태 벡터를 numpy 배열로 반환한다.
    ///
    /// dtype 은 시뮬레이션 정밀도를 따른다:
    /// - f64 경로 → `numpy.complex128`
    /// - f32 경로 → `numpy.complex64`
    fn statevector<'py>(&self, py: Python<'py>) -> Bound<'py, PyAny> {
        match &self.inner {
            SimulationResult::F64 { statevector, .. } => {
                let amps: Vec<Complex<f64>> = statevector.amplitudes().to_vec();
                PyArray1::from_vec(py, amps).into_any()
            }
            SimulationResult::F32 { statevector, .. } => {
                let amps: Vec<Complex<f32>> = statevector.amplitudes().to_vec();
                PyArray1::from_vec(py, amps).into_any()
            }
        }
    }

    /// 확률 벡터를 numpy 배열로 반환한다.
    ///
    /// dtype 은 시뮬레이션 정밀도를 따른다 (`float64` / `float32`).
    fn probabilities<'py>(&self, py: Python<'py>) -> Bound<'py, PyAny> {
        match &self.inner {
            SimulationResult::F64 { statevector, .. } => {
                PyArray1::from_vec(py, statevector.probabilities()).into_any()
            }
            SimulationResult::F32 { statevector, .. } => {
                PyArray1::from_vec(py, statevector.probabilities()).into_any()
            }
        }
    }
}

/// 회로 실행 함수.
///
/// `precision` 으로 시뮬레이션 정밀도를 선택한다 ("f64" default, "f32" 옵션).
/// f32 는 메모리 ~50% 절감과 SIMD 친화성을 제공하지만 정확도는 ~1e-6 수준.
///
/// rayon 병렬 게이트 적용이 GIL 을 들고 있으면 Python 멀티스레드 환경에서
/// 다른 스레드가 막히므로, 시뮬레이션 동안 GIL 을 해제한다.
#[pyfunction]
#[pyo3(signature = (circuit, shots = 1024, seed = None, precision = "f64"))]
fn run(
    py: Python<'_>,
    circuit: &PyCircuit,
    shots: usize,
    seed: Option<u64>,
    precision: &str,
) -> PyResult<PySimulationResult> {
    let prec = match precision {
        "f64" => Precision::F64,
        "f32" => Precision::F32,
        other => {
            return Err(PyValueError::new_err(format!(
                "precision 은 'f32' 또는 'f64' 여야 합니다 (입력: {other:?})"
            )));
        }
    };
    let circuit_owned = circuit.inner.clone();
    let mut engine = match seed {
        Some(s) => ExecutionEngine::with_seed(s),
        None => ExecutionEngine::new(),
    };
    engine = engine.with_precision(prec);
    let result = py.allow_threads(move || engine.run(&circuit_owned, shots));
    Ok(PySimulationResult { inner: result })
}

#[pymodule]
fn qsim_python(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyCircuit>()?;
    m.add_class::<PySimulationResult>()?;
    m.add_class::<PyNoiseChannel>()?;
    m.add_function(wrap_pyfunction!(run, m)?)?;
    Ok(())
}
