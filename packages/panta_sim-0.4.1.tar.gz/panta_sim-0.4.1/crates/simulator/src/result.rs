use qsim_core::StateVector;
use std::collections::HashMap;

/// 시뮬레이션 정밀도 선택. 기본값은 `F64` (v0.2.0 호환).
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum Precision {
    /// 32비트 단일 정밀도 — amplitude 8 bytes, ~50% 메모리 절감, ~1e-6 정확도.
    F32,
    /// 64비트 배 정밀도 — amplitude 16 bytes, ~1e-15 정확도 (default).
    #[default]
    F64,
}

impl Precision {
    /// 사용자 친화 문자열 표현.
    pub fn as_str(&self) -> &'static str {
        match self {
            Precision::F32 => "f32",
            Precision::F64 => "f64",
        }
    }
}

/// 시뮬레이션 실행 결과. 정밀도별로 내부 state vector 의 타입이 다르므로 enum 으로 분기한다.
#[derive(Debug, Clone)]
pub enum SimulationResult {
    /// 32비트 정밀도 결과.
    F32 {
        counts: HashMap<String, usize>,
        statevector: StateVector<f32>,
    },
    /// 64비트 정밀도 결과 (default).
    F64 {
        counts: HashMap<String, usize>,
        statevector: StateVector<f64>,
    },
}

impl SimulationResult {
    /// f64 정밀도 결과 생성자. 기존 v0.2.0 API 호환.
    pub fn new(counts: HashMap<String, usize>, statevector: StateVector<f64>) -> Self {
        SimulationResult::F64 {
            counts,
            statevector,
        }
    }

    /// f32 정밀도 결과 생성자.
    pub fn new_f32(counts: HashMap<String, usize>, statevector: StateVector<f32>) -> Self {
        SimulationResult::F32 {
            counts,
            statevector,
        }
    }

    /// 정밀도 enum 반환.
    pub fn precision(&self) -> Precision {
        match self {
            SimulationResult::F32 { .. } => Precision::F32,
            SimulationResult::F64 { .. } => Precision::F64,
        }
    }

    /// 큐비트 수 반환.
    pub fn num_qubits(&self) -> usize {
        match self {
            SimulationResult::F32 { statevector, .. } => statevector.num_qubits(),
            SimulationResult::F64 { statevector, .. } => statevector.num_qubits(),
        }
    }

    /// 측정 결과 카운트를 반환한다 (정밀도 무관).
    pub fn counts(&self) -> &HashMap<String, usize> {
        match self {
            SimulationResult::F32 { counts, .. } => counts,
            SimulationResult::F64 { counts, .. } => counts,
        }
    }

    /// f64 statevector 참조. f32 결과면 `None`.
    pub fn statevector_f64(&self) -> Option<&StateVector<f64>> {
        match self {
            SimulationResult::F64 { statevector, .. } => Some(statevector),
            SimulationResult::F32 { .. } => None,
        }
    }

    /// f32 statevector 참조. f64 결과면 `None`.
    pub fn statevector_f32(&self) -> Option<&StateVector<f32>> {
        match self {
            SimulationResult::F32 { statevector, .. } => Some(statevector),
            SimulationResult::F64 { .. } => None,
        }
    }

    /// 기본 정밀도 (f64) 인 경우 `&StateVector<f64>` 를 반환. f32 결과에 호출 시 panic.
    /// v0.2.0 호환용 — 새 코드는 `statevector_f64()` / `statevector_f32()` 사용 권장.
    pub fn statevector(&self) -> &StateVector<f64> {
        match self {
            SimulationResult::F64 { statevector, .. } => statevector,
            SimulationResult::F32 { .. } => {
                panic!("statevector(): f32 결과입니다. statevector_f32() 를 사용하세요")
            }
        }
    }

    /// 각 basis state의 확률 벡터를 f64 로 반환한다 (정밀도 통일을 위해).
    /// f32 경로여도 f64 로 cast 후 반환 — 호출자가 분기할 필요 없음.
    pub fn probabilities(&self) -> Vec<f64> {
        match self {
            SimulationResult::F64 { statevector, .. } => statevector.probabilities(),
            SimulationResult::F32 { statevector, .. } => statevector
                .probabilities()
                .into_iter()
                .map(|p| p as f64)
                .collect(),
        }
    }
}
