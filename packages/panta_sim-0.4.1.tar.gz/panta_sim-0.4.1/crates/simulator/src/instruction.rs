use qsim_core::{Gate, NoiseChannel};

/// 회로에 추가되는 개별 명령.
#[derive(Debug, Clone)]
pub enum Instruction {
    /// 게이트 적용 명령.
    ApplyGate { gate: Gate, targets: Vec<usize> },
    /// 단일 큐비트 노이즈 채널 적용 (v0.4 stochastic trajectory).
    /// 실행 시 [`crate::engine::ExecutionEngine`] 의 RNG 로 Kraus 연산자 하나를
    /// 샘플링·적용·재정규화 한다.
    ApplyNoise {
        channel: NoiseChannel,
        target: usize,
    },
    /// 특정 큐비트 측정 명령.
    Measure { qubit: usize, cbit: usize },
    /// 모든 큐비트 측정.
    MeasureAll,
}
