use qsim_core::{Gate, NoiseChannel};

use crate::instruction::Instruction;

/// 양자 회로. 게이트와 측정 명령을 순서대로 저장한다.
///
/// `global_phase` 는 회로 전체에 곱해지는 e^(iλ) 인자를 라디안으로 추적한다
/// (Qiskit 의 `QuantumCircuit.global_phase` 와 동일 개념). 측정 결과 분포에는
/// 영향이 없지만 statevector 수준 비교/내보내기에서는 보존되어야 한다.
/// 누적은 [`Circuit::add_global_phase`] 로만 한다 — Decomposition 함수는 자기
/// 몫만 더하고 호출자가 책임진다.
#[derive(Debug, Clone)]
pub struct Circuit {
    n_qubits: usize,
    n_cbits: usize,
    instructions: Vec<Instruction>,
    global_phase: f64,
}

impl Circuit {
    /// n큐비트 빈 회로를 생성한다.
    pub fn new(n_qubits: usize) -> Self {
        Self {
            n_qubits,
            n_cbits: 0,
            instructions: Vec::new(),
            global_phase: 0.0,
        }
    }

    pub fn num_qubits(&self) -> usize {
        self.n_qubits
    }

    pub fn num_cbits(&self) -> usize {
        self.n_cbits
    }

    pub fn instructions(&self) -> &[Instruction] {
        &self.instructions
    }

    /// 명령 리스트에 대한 가변 참조 (트랜스파일러용).
    pub fn instructions_mut(&mut self) -> &mut Vec<Instruction> {
        &mut self.instructions
    }

    /// 누적된 글로벌 phase λ (라디안).
    pub fn global_phase(&self) -> f64 {
        self.global_phase
    }

    /// 글로벌 phase 에 λ 를 더한다.
    pub fn add_global_phase(&mut self, lambda: f64) {
        self.global_phase += lambda;
    }

    /// 글로벌 phase 를 λ 로 설정한다.
    pub fn set_global_phase(&mut self, lambda: f64) {
        self.global_phase = lambda;
    }

    fn validate_qubit(&self, q: usize) {
        assert!(
            q < self.n_qubits,
            "큐비트 인덱스 {q}가 범위를 벗어남 (n_qubits={})",
            self.n_qubits
        );
    }

    fn add_gate(&mut self, gate: Gate, targets: Vec<usize>) {
        for &t in &targets {
            self.validate_qubit(t);
        }
        self.instructions
            .push(Instruction::ApplyGate { gate, targets });
    }

    // 단일 큐비트 게이트
    pub fn h(&mut self, qubit: usize) {
        self.add_gate(Gate::H, vec![qubit]);
    }
    pub fn x(&mut self, qubit: usize) {
        self.add_gate(Gate::X, vec![qubit]);
    }
    pub fn y(&mut self, qubit: usize) {
        self.add_gate(Gate::Y, vec![qubit]);
    }
    pub fn z(&mut self, qubit: usize) {
        self.add_gate(Gate::Z, vec![qubit]);
    }
    pub fn s(&mut self, qubit: usize) {
        self.add_gate(Gate::S, vec![qubit]);
    }
    pub fn sdg(&mut self, qubit: usize) {
        self.add_gate(Gate::Sdg, vec![qubit]);
    }
    pub fn t(&mut self, qubit: usize) {
        self.add_gate(Gate::T, vec![qubit]);
    }
    pub fn tdg(&mut self, qubit: usize) {
        self.add_gate(Gate::Tdg, vec![qubit]);
    }
    /// OpenQASM `U(θ,φ,λ)` (= Qiskit `u3`) 일반 1-큐비트 유니터리.
    pub fn u(&mut self, theta: f64, phi: f64, lambda: f64, qubit: usize) {
        self.add_gate(Gate::U(theta, phi, lambda), vec![qubit]);
    }
    pub fn rx(&mut self, theta: f64, qubit: usize) {
        self.add_gate(Gate::Rx(theta), vec![qubit]);
    }
    pub fn ry(&mut self, theta: f64, qubit: usize) {
        self.add_gate(Gate::Ry(theta), vec![qubit]);
    }
    pub fn rz(&mut self, theta: f64, qubit: usize) {
        self.add_gate(Gate::Rz(theta), vec![qubit]);
    }
    pub fn id(&mut self, qubit: usize) {
        self.add_gate(Gate::Id, vec![qubit]);
    }

    // 2큐비트 게이트
    pub fn cx(&mut self, control: usize, target: usize) {
        self.add_gate(Gate::CNOT, vec![control, target]);
    }
    pub fn cz(&mut self, qubit0: usize, qubit1: usize) {
        self.add_gate(Gate::CZ, vec![qubit0, qubit1]);
    }
    pub fn swap(&mut self, qubit0: usize, qubit1: usize) {
        self.add_gate(Gate::SWAP, vec![qubit0, qubit1]);
    }

    // 3큐비트 게이트
    pub fn ccx(&mut self, ctrl1: usize, ctrl2: usize, target: usize) {
        self.add_gate(Gate::Toffoli, vec![ctrl1, ctrl2, target]);
    }
    pub fn cswap(&mut self, control: usize, target1: usize, target2: usize) {
        self.add_gate(Gate::Fredkin, vec![control, target1, target2]);
    }

    /// 특정 큐비트를 측정하여 클래식 비트에 저장한다.
    pub fn measure(&mut self, qubit: usize, cbit: usize) {
        self.validate_qubit(qubit);
        if cbit >= self.n_cbits {
            self.n_cbits = cbit + 1;
        }
        self.instructions.push(Instruction::Measure { qubit, cbit });
    }

    /// 모든 큐비트를 측정한다.
    pub fn measure_all(&mut self) {
        self.n_cbits = self.n_qubits;
        self.instructions.push(Instruction::MeasureAll);
    }

    /// 단일 큐비트 노이즈 채널을 회로 명령 시퀀스에 추가한다 (v0.4 trajectory).
    ///
    /// 실행 시점 (`ExecutionEngine::run`) 에 RNG 로 Kraus 연산자 하나가 샘플링되어
    /// 적용된다. 회로 자체는 deterministic — 동일 seed 로 같은 결과가 재현된다.
    pub fn add_noise(&mut self, channel: NoiseChannel, qubit: usize) {
        self.validate_qubit(qubit);
        self.instructions.push(Instruction::ApplyNoise {
            channel,
            target: qubit,
        });
    }
}
