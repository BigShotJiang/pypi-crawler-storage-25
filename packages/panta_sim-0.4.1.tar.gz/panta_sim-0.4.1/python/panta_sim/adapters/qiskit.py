"""Qiskit ↔ panta-sim 회로 변환 어댑터 (v0.3.5 Cut 1).

``from_qiskit`` 은 Qiskit ``QuantumCircuit`` 을 panta-sim ``QuantumCircuit`` 으로,
``to_qiskit`` 은 그 반대 방향 변환을 수행한다. statevector convention 은
양쪽 모두 little-endian (qubit 0 = LSB, ``little`` ordering) 이므로 매핑은
1:1 이며, statevector 비교 시 1e-10 (f64) 일치한다.

게이트 매핑:
    panta-sim 의 native Rust 게이트 (H, X, Y, Z, S, Sdg, T, Tdg, Id, Rx,
    Ry, Rz, CNOT, CZ, SWAP, Toffoli, Fredkin) 와 단일 큐비트 ``unitary`` 는
    직접 매핑. 그 외 Qiskit 게이트 (sx, sxdg, p, u, u1, u2, u3, ch, cy,
    cu, cu1, cu3, cp, crx, cry, crz, …) 는 ``qiskit.qasm2.dumps()`` 로
    OpenQASM 2.0 직렬화 후 panta-sim 의 ``from_qasm()`` 가 standard
    qelib1.inc decomposition 으로 import 한다.

미지원:
    - parameterized circuit (unbound ``Parameter``) — 먼저
      ``qc.assign_parameters({...})`` 로 bind 후 호출.
    - mid-circuit measurement 는 panta-sim 이 v0.4 에서 지원 — 현재는
      회로 끝의 measurement 만 정상 동작.
    - ``reset``, ``if_else`` 등 control flow — v0.5.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np

from ..circuit import QuantumCircuit as PantaCircuit

if TYPE_CHECKING:  # pragma: no cover
    from qiskit import QuantumCircuit as QiskitCircuit


_QISKIT_INSTALL_HINT = (
    "qiskit is required for this function — install with: "
    "pip install panta-sim[qiskit]"
)


def _lazy_import_qiskit() -> Any:
    """qiskit 패키지를 lazy import 한다 (미설치 시 친절한 ImportError)."""
    try:
        import qiskit  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover
        raise ImportError(_QISKIT_INSTALL_HINT) from exc
    return qiskit


# panta-sim 의 native fluent 메서드와 1:1 매핑되는 Qiskit gate 이름 표.
# 매핑 표 외 게이트 (sx/p/u/cu/ch/cu1/cu3/cy/cp/crx/cry/crz) 는 QASM2 우회.
_DIRECT_GATE_MAP: dict[str, str] = {
    "h": "h",
    "x": "x",
    "y": "y",
    "z": "z",
    "s": "s",
    "sdg": "sdg",
    "t": "t",
    "tdg": "tdg",
    "id": "id",
    "iden": "id",  # Qiskit alias
    "rx": "rx",
    "ry": "ry",
    "rz": "rz",
    "cx": "cx",
    "cnot": "cx",
    "cz": "cz",
    "swap": "swap",
    "ccx": "ccx",
    "toffoli": "ccx",
    "cswap": "cswap",
    "fredkin": "cswap",
}

# 매핑 표에 없지만 special-case 처리되는 op name.
_SPECIAL_OPS = {"measure", "barrier", "unitary"}


def from_qiskit(qiskit_circuit: "QiskitCircuit") -> PantaCircuit:
    """Qiskit ``QuantumCircuit`` 을 panta-sim ``QuantumCircuit`` 으로 변환한다.

    ``qiskit.QuantumCircuit.data`` 의 instruction list 를 순회하며 panta-sim 의
    fluent 메서드로 매핑한다. 매핑 표 외 게이트가 발견되면 회로 전체를
    ``qiskit.qasm2.dumps()`` → ``panta_sim.QuantumCircuit.from_qasm()`` 경로로
    fallback 한다 (v0.3.0 의 16종 qelib1 게이트 decomposition 재활용).

    Args:
        qiskit_circuit: Qiskit ``QuantumCircuit``. unbound ``Parameter`` 가 있으면
            ``ValueError`` (먼저 ``assign_parameters`` 로 bind 필요).

    Returns:
        panta-sim ``QuantumCircuit``. ``run()`` 결과의 statevector 가 Qiskit
        ``Statevector(qiskit_circuit)`` 와 1e-10 (f64) 일치한다.

    Raises:
        ImportError: ``qiskit`` 미설치.
        ValueError: 매개변수 bind 안 됐거나, 변환 불가 op (reset / if_else 등).

    Example:
        >>> from qiskit import QuantumCircuit as QC
        >>> from panta_sim import from_qiskit
        >>> qc = QC(2); qc.h(0); qc.cx(0, 1)
        >>> panta = from_qiskit(qc)
        >>> result = panta.run(shots=0)  # statevector mode
    """
    _lazy_import_qiskit()  # ImportError early

    if list(qiskit_circuit.parameters):
        raise ValueError(
            "qiskit circuit has unbound Parameters: "
            f"{list(qiskit_circuit.parameters)}. "
            "Call qc.assign_parameters({...}) before from_qiskit()."
        )

    n_qubits = qiskit_circuit.num_qubits

    # 1차: 모든 op 이 직접 매핑 가능한지 확인. 하나라도 매핑 표 외면
    # QASM2 fallback 으로 일괄 변환 (mixed walk 보다 단순 + 안정).
    needs_qasm_fallback = False
    for instr in qiskit_circuit.data:
        name = instr.operation.name
        if name in _DIRECT_GATE_MAP:
            continue
        if name in _SPECIAL_OPS:
            continue
        # control flow / reset 등 명시적 거부
        if name in ("reset", "if_else", "while_loop", "for_loop", "switch"):
            raise ValueError(
                f"qiskit op {name!r} is not supported by panta-sim "
                "(planned for v0.5)."
            )
        needs_qasm_fallback = True
        break

    if needs_qasm_fallback:
        return _from_qiskit_via_qasm(qiskit_circuit)

    # 직접 매핑 path
    panta = PantaCircuit(n_qubits)
    for instr in qiskit_circuit.data:
        op = instr.operation
        name = op.name
        qubit_idxs = [qiskit_circuit.find_bit(q).index for q in instr.qubits]

        if name == "barrier":
            continue  # no-op

        if name == "measure":
            cbit_idx = qiskit_circuit.find_bit(instr.clbits[0]).index
            panta.measure(qubit_idxs[0], cbit_idx)
            continue

        if name == "unitary":
            # UnitaryGate.params[0] 이 unitary 행렬 (numpy ndarray).
            matrix = op.params[0]
            if matrix.shape != (2, 2):
                # multi-qubit unitary → QASM 우회 (panta-sim 은 1qubit
                # unitary 만 native 지원, 다큐빗은 Rust 측에서 분해 안 함).
                return _from_qiskit_via_qasm(qiskit_circuit)
            panta.unitary(np.asarray(matrix, dtype=np.complex128), qubit_idxs[0])
            continue

        target = _DIRECT_GATE_MAP[name]
        params = list(op.params)
        method = getattr(panta, target)

        # parametric: rx/ry/rz 는 (theta, qubit) 시그니처
        if target in ("rx", "ry", "rz"):
            method(float(params[0]), qubit_idxs[0])
        else:
            method(*qubit_idxs)

    return panta


def _from_qiskit_via_qasm(qiskit_circuit: "QiskitCircuit") -> PantaCircuit:
    """OpenQASM 2.0 우회로로 변환. v0.3.0 의 from_qasm 인프라를 재활용한다."""
    _lazy_import_qiskit()
    import qiskit.qasm2 as qasm2  # submodule lazy import

    try:
        qasm_str = qasm2.dumps(qiskit_circuit)
    except Exception as exc:  # qasm2.dumps 실패 (예: QASM3-only feature)
        raise ValueError(
            f"failed to serialize qiskit circuit to OpenQASM 2.0: {exc}. "
            "Try qc.decompose() before from_qiskit() or use a circuit "
            "with only standard gates."
        ) from exc
    return PantaCircuit.from_qasm(qasm_str)


def to_qiskit(panta_circuit: PantaCircuit) -> "QiskitCircuit":
    """panta-sim ``QuantumCircuit`` 을 Qiskit ``QuantumCircuit`` 으로 변환한다.

    panta-sim 의 ``_ops`` (fluent 메서드 호출 기록) 를 순회하며 동명의 Qiskit
    메서드를 호출한다. v0.4 부터 ``from_qasm()`` 으로 만든 회로도 ``_ops`` 가
    Rust ``Circuit::instructions()`` 에서 복원되므로, QASM 우회 없이 직접
    매핑 path 가 사용된다.

    측정 / global phase 도 보존:
        - ``measure(qubit, cbit)`` → Qiskit ``measure(qubit, cbit)`` (cbit 인덱스
          1:1 보존).
        - ``measure_all()`` → Qiskit ``measure_all()``.
        - panta-sim 의 ``global_phase`` (radian) 가 Qiskit ``global_phase`` 로
          복사된다.

    Args:
        panta_circuit: panta-sim ``QuantumCircuit``.

    Returns:
        Qiskit ``QuantumCircuit``. ``Statevector()`` 와 panta-sim ``run().
        statevector()`` 가 1e-10 (f64) 일치한다.

    Raises:
        ImportError: ``qiskit`` 미설치.
    """
    qiskit = _lazy_import_qiskit()

    QiskitQC = qiskit.QuantumCircuit

    n = panta_circuit.num_qubits
    # cbit 개수 + unitary op 의 누적 phase 를 한 번에 산출.
    # unitary op 은 Qiskit 측에서 ``qc.unitary(m,...)`` 호출 시 phase 가
    # 자체 내장되므로, panta 의 ``global_phase`` 에서 그만큼 차감해야 double
    # counting 을 막을 수 있다. ``alpha = arg(det(m))/2`` 식은 panta-sim 의
    # ``crates/transpiler/src/decompose.rs`` 의 Z-Y-Z 분해와 동일.
    max_cbit = -1
    has_measure_all = False
    unitary_phase_sum = 0.0
    for name, _q, params in panta_circuit._ops:
        if name == "measure":
            max_cbit = max(max_cbit, int(params[0]) if params else 0)
        elif name == "measure_all":
            has_measure_all = True
        elif name == "unitary" and params:
            m = np.asarray(params[0], dtype=np.complex128)
            unitary_phase_sum += float(np.angle(np.linalg.det(m)) / 2.0)
    n_cbits = (max_cbit + 1) if max_cbit >= 0 else 0

    if has_measure_all and n_cbits == 0:
        # measure_all 은 cbit N 개를 자동 할당. 그 외 measure 가 없으므로
        # measure_all() Qiskit 메서드가 register 를 만든다 → 별도 cbit 인자 X.
        qc = QiskitQC(n)
    else:
        qc = QiskitQC(n, max(n_cbits, 0))

    for name, qubits, params in panta_circuit._ops:
        if name == "unitary":
            # params[0] 이 numpy 행렬.
            if not params:
                # 안전망: 옛 형식 (matrix 없음) — placeholder Identity.
                qc.id(qubits[0])
            else:
                qc.unitary(params[0], [qubits[0]])
            continue

        if name == "measure":
            cbit = int(params[0]) if params else qubits[0]
            qc.measure(qubits[0], cbit)
            continue

        if name == "measure_all":
            qc.measure_all()
            continue

        if name in ("rx", "ry", "rz"):
            getattr(qc, name)(float(params[0]), qubits[0])
            continue

        if name == "u":
            # OpenQASM U(θ,φ,λ) — Qiskit u3 와 동일 정의.
            qc.u(float(params[0]), float(params[1]), float(params[2]), qubits[0])
            continue

        # 그 외 gate name 들: 동명의 Qiskit 메서드 호출.
        method = getattr(qc, name)
        method(*qubits)

    # global phase 보존 (Qiskit Statevector 가 phase 포함 비교).
    # unitary op 의 phase 는 Qiskit 의 ``qc.unitary()`` 가 자체 내장하므로
    # ``unitary_phase_sum`` 만큼 빼서 double counting 방지.
    qc.global_phase = float(panta_circuit.global_phase - unitary_phase_sum)

    return qc
