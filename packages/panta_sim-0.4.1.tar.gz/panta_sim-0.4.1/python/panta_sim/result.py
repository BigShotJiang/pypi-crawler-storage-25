"""시뮬레이션 결과 클래스."""

from __future__ import annotations

from typing import Dict

import numpy as np
import numpy.typing as npt


class SimulationResult:
    """시뮬레이션 실행 결과를 래핑하는 클래스.

    Rust SimulationResult를 감싸서 Python에서 편리하게 사용할 수 있게 한다.

    정밀도(``f32`` / ``f64``)에 따라 ``statevector()`` / ``probabilities()`` 가
    반환하는 numpy dtype 이 달라진다 — Rust 가 native dtype 을 직접 노출하므로
    Python wrapper 가 추가 cast 를 하지 않는다 (메모리 절약).
    """

    def __init__(self, raw_result: object) -> None:
        self._raw = raw_result

    @property
    def precision(self) -> str:
        """시뮬레이션에 사용된 정밀도 (``"f32"`` 또는 ``"f64"``)."""
        return self._raw.precision

    def counts(self) -> Dict[str, int]:
        """측정 결과 카운트를 딕셔너리로 반환한다.

        Returns:
            비트 문자열을 키로, 측정 횟수를 값으로 하는 딕셔너리.
        """
        return dict(self._raw.counts())

    def statevector(self) -> npt.NDArray[np.complexfloating]:
        """측정 전 최종 상태 벡터를 numpy 배열로 반환한다.

        dtype 은 시뮬레이션 정밀도를 따른다:

        - f64 정밀도 → ``numpy.complex128``
        - f32 정밀도 → ``numpy.complex64``

        Returns:
            1D numpy 배열 (정밀도별 native dtype).
        """
        return self._raw.statevector()

    def probabilities(self) -> npt.NDArray[np.floating]:
        """각 basis state의 확률을 numpy 배열로 반환한다.

        dtype 은 시뮬레이션 정밀도를 따른다 (``float64`` / ``float32``).

        Returns:
            1D numpy 배열.
        """
        return self._raw.probabilities()

    def plot_histogram(self, **kwargs):  # type: ignore[no-untyped-def]
        """측정 카운트의 matplotlib 히스토그램 Figure 를 반환한다.

        ``panta_sim.plot_histogram(self.counts(), **kwargs)`` 의 alias.
        matplotlib 이 설치되어 있어야 한다 (``pip install panta-sim[viz]``).

        Args:
            **kwargs: ``figsize``, ``ax``, ``title``, ``color``, ``bar_labels``.

        Returns:
            ``matplotlib.figure.Figure``.
        """
        from .visualize import plot_histogram

        return plot_histogram(self.counts(), **kwargs)

    def histogram_text(self, width: int = 40, style: str = "unicode") -> str:
        """측정 카운트의 텍스트 막대 그래프를 반환한다 (matplotlib 불필요).

        Args:
            width: 막대의 최대 폭.
            style: ``"unicode"`` (default) 또는 ``"ascii"``.

        Returns:
            줄 바꿈된 문자열.
        """
        from .visualize import histogram_text

        return histogram_text(self.counts(), width=width, style=style)
