"""사용자용 QuantumCircuit 클래스."""

from __future__ import annotations

from typing import Any, Optional

from .qsim_python import Circuit as _RustCircuit
from .qsim_python import run as _rust_run
from .result import SimulationResult


def _ops_from_rust(
    rust_circuit: _RustCircuit,
) -> list[tuple[str, tuple[int, ...], tuple[Any, ...]]]:
    """Rust ``Circuit.instructions()`` → Python ``_ops`` 형식 변환.

    measure 의 cbit 은 f64 → int 로 cast (Python `_ops` 형 일치). 나머지 op 의
    params 는 그대로 float 유지.
    """
    ops: list[tuple[str, tuple[int, ...], tuple[Any, ...]]] = []
    for name, qubits, params in rust_circuit.instructions():
        q_tuple = tuple(qubits)
        if name == "measure":
            # cbit 만 들어 있음. f64 → int 복원.
            ops.append((name, q_tuple, (int(params[0]),)))
        else:
            ops.append((name, q_tuple, tuple(params)))
    return ops


class QuantumCircuit:
    """양자 회로를 구성하고 실행하는 메인 인터페이스.

    Args:
        n_qubits: 큐비트 수.

    Example:
        >>> qc = QuantumCircuit(2)
        >>> qc.h(0)
        >>> qc.cx(0, 1)
        >>> result = qc.run(shots=1024)
        >>> print(result.counts())
    """

    def __init__(self, n_qubits: int) -> None:
        self._circuit = _RustCircuit(n_qubits)
        # OpRecord = (name, qubits, params). params 슬롯은 ``rx/ry/rz`` 의 회전 각도
        # (float) 외에도 ``unitary`` op 의 행렬 (np.ndarray) / ``measure`` op 의
        # cbit (int) 등을 보존한다 — to_qiskit / to_cirq 어댑터 (v0.3.5) 에서 활용.
        self._ops: list[tuple[str, tuple[int, ...], tuple[Any, ...]]] = []
        self._from_qasm: bool = False

    @classmethod
    def from_qasm(cls, qasm: str) -> QuantumCircuit:
        """OpenQASM 2.0 또는 3.0 문자열로부터 회로를 구성한다.

        헤더 (``OPENQASM 2.0;`` 또는 ``OPENQASM 3.0;``) 가 버전을 결정한다. Qiskit /
        PennyLane 등이 emit 한 표준 회로를 그대로 import 할 수 있다.

        지원 게이트 (qelib1.inc / stdgates.inc): h/x/y/z/s/sdg/t/tdg/id, rx/ry/rz,
        u1/u2/u3/u/p, cx/CX/cy/cz/ch/swap, ccx/cswap, crx/cry/crz, cu1/cu3/cu/cp.

        지원 syntax: ``qreg q[N]`` / ``qubit[N] q``, ``creg c[N]`` / ``bit[N] c``,
        ``measure q[i] -> c[j]``, ``barrier`` (no-op), ``gate name(...) qubits {{ ... }}``
        user-defined gate (재귀 깊이 16 까지 inline).

        명시적 unsupported (명확한 ``ValueError`` + milestone 정보):
        ``if (c==N) ...`` / ``reset`` / ``opaque`` (v0.5),
        ``sx`` / ``sxdg`` / ``gphase`` (v0.3.1 transpiler 와 함께),
        3.0 의 ``for``/``while``/``box``/``def`` (v0.5).

        Args:
            qasm: OpenQASM 2.0 또는 3.0 소스 문자열.

        Returns:
            새 ``QuantumCircuit`` 객체.

        Raises:
            ValueError: 파싱 / lowering 실패 또는 unsupported feature.

        Example:
            >>> qc = QuantumCircuit.from_qasm('''
            ... OPENQASM 2.0;
            ... include "qelib1.inc";
            ... qreg q[2];
            ... h q[0];
            ... cx q[0], q[1];
            ... ''')
            >>> qc.num_qubits
            2
        """
        obj = cls.__new__(cls)
        obj._circuit = _RustCircuit.from_qasm(qasm)
        obj._ops = _ops_from_rust(obj._circuit)
        obj._from_qasm = True
        return obj

    def to_qasm(self, version: str = "2.0") -> str:
        """회로를 OpenQASM 문자열로 export 한다.

        Args:
            version: ``"2.0"`` (default) 또는 ``"3.0"``. 2.0 은 ``qreg``/``creg`` +
                ``include "qelib1.inc"``, 3.0 은 ``qubit[N]``/``bit[N]`` +
                ``include "stdgates.inc"`` 헤더를 emit. 게이트 매핑은 동일
                (``u3(θ,φ,λ)`` 형태).

        Returns:
            완성된 OpenQASM 문자열. ``qiskit.qasm2.loads()`` 또는
            ``qiskit.qasm3.loads()`` 가 직접 reparse 가능한 표준 형식.

        Raises:
            ValueError: ``version`` 이 ``"2.0"`` / ``"3.0"`` 가 아닐 때.

        Example:
            >>> qc = QuantumCircuit(2)
            >>> qc.h(0).cx(0, 1)
            >>> print(qc.to_qasm())
            OPENQASM 2.0;
            include "qelib1.inc";
            qreg q[2];
            h q[0];
            cx q[0],q[1];
        """
        return self._circuit.to_qasm(version)

    @property
    def num_qubits(self) -> int:
        """큐비트 수를 반환한다."""
        return self._circuit.num_qubits()

    # 단일 큐비트 게이트
    def h(self, qubit: int) -> QuantumCircuit:
        """Hadamard 게이트를 적용한다."""
        self._circuit.h(qubit)
        self._ops.append(("h", (qubit,), ()))
        return self

    def x(self, qubit: int) -> QuantumCircuit:
        """Pauli-X (NOT) 게이트를 적용한다."""
        self._circuit.x(qubit)
        self._ops.append(("x", (qubit,), ()))
        return self

    def y(self, qubit: int) -> QuantumCircuit:
        """Pauli-Y 게이트를 적용한다."""
        self._circuit.y(qubit)
        self._ops.append(("y", (qubit,), ()))
        return self

    def z(self, qubit: int) -> QuantumCircuit:
        """Pauli-Z 게이트를 적용한다."""
        self._circuit.z(qubit)
        self._ops.append(("z", (qubit,), ()))
        return self

    def s(self, qubit: int) -> QuantumCircuit:
        """S (Phase) 게이트를 적용한다."""
        self._circuit.s(qubit)
        self._ops.append(("s", (qubit,), ()))
        return self

    def sdg(self, qubit: int) -> QuantumCircuit:
        """S† (S-dagger) 게이트를 적용한다."""
        self._circuit.sdg(qubit)
        self._ops.append(("sdg", (qubit,), ()))
        return self

    def t(self, qubit: int) -> QuantumCircuit:
        """T 게이트를 적용한다."""
        self._circuit.t(qubit)
        self._ops.append(("t", (qubit,), ()))
        return self

    def tdg(self, qubit: int) -> QuantumCircuit:
        """T† (T-dagger) 게이트를 적용한다."""
        self._circuit.tdg(qubit)
        self._ops.append(("tdg", (qubit,), ()))
        return self

    def rx(self, theta: float, qubit: int) -> QuantumCircuit:
        """X축 회전 게이트를 적용한다."""
        self._circuit.rx(theta, qubit)
        self._ops.append(("rx", (qubit,), (float(theta),)))
        return self

    def ry(self, theta: float, qubit: int) -> QuantumCircuit:
        """Y축 회전 게이트를 적용한다."""
        self._circuit.ry(theta, qubit)
        self._ops.append(("ry", (qubit,), (float(theta),)))
        return self

    def rz(self, theta: float, qubit: int) -> QuantumCircuit:
        """Z축 회전 게이트를 적용한다."""
        self._circuit.rz(theta, qubit)
        self._ops.append(("rz", (qubit,), (float(theta),)))
        return self

    def id(self, qubit: int) -> QuantumCircuit:
        """Identity 게이트를 적용한다."""
        self._circuit.id(qubit)
        self._ops.append(("id", (qubit,), ()))
        return self

    # 2큐비트 게이트
    def cx(self, control: int, target: int) -> QuantumCircuit:
        """CNOT (Controlled-X) 게이트를 적용한다."""
        self._circuit.cx(control, target)
        self._ops.append(("cx", (control, target), ()))
        return self

    def cz(self, qubit0: int, qubit1: int) -> QuantumCircuit:
        """Controlled-Z 게이트를 적용한다."""
        self._circuit.cz(qubit0, qubit1)
        self._ops.append(("cz", (qubit0, qubit1), ()))
        return self

    def swap(self, qubit0: int, qubit1: int) -> QuantumCircuit:
        """SWAP 게이트를 적용한다."""
        self._circuit.swap(qubit0, qubit1)
        self._ops.append(("swap", (qubit0, qubit1), ()))
        return self

    # 3큐비트 게이트
    def ccx(self, ctrl1: int, ctrl2: int, target: int) -> QuantumCircuit:
        """Toffoli (CCX) 게이트를 적용한다."""
        self._circuit.ccx(ctrl1, ctrl2, target)
        self._ops.append(("ccx", (ctrl1, ctrl2, target), ()))
        return self

    def cswap(self, control: int, target1: int, target2: int) -> QuantumCircuit:
        """Fredkin (CSWAP) 게이트를 적용한다."""
        self._circuit.cswap(control, target1, target2)
        self._ops.append(("cswap", (control, target1, target2), ()))
        return self

    # 임의 unitary + transpile
    def unitary(
        self,
        matrix,
        qubit: int,
        validate: bool = True,
    ) -> QuantumCircuit:
        """임의 2×2 unitary 행렬을 ``qubit`` 번째 큐비트에 적용한다.

        내부적으로 Z-Y-Z 분해 (Nielsen-Chuang Thm 4.1) 로 native 게이트
        ``Rz(δ); Ry(γ); Rz(β)`` 를 추가하고 글로벌 phase α 는 회로 메타데이터에
        누적된다. Qiskit 의 ``Statevector`` 가 ``global_phase`` 를 포함하므로
        결과 비교 시 1e-10 수준에서 일치한다.

        Args:
            matrix: 2×2 unitary. ``numpy.ndarray`` 또는 list-of-list (자동 변환).
            qubit: 적용할 큐비트 인덱스.
            validate: ``True`` (default) 면 ``M·M† ≈ I`` (1e-10) 를 확인하고
                위반 시 ``ValueError``. ``False`` 면 검증 생략.

        Returns:
            ``self`` (fluent chaining 용).
        """
        import numpy as np

        arr = np.asarray(matrix, dtype=np.complex128)
        self._circuit.unitary(arr, qubit, validate)
        # to_qiskit / to_cirq 가 그대로 emit 할 수 있게 행렬을 params 슬롯에 보존.
        self._ops.append(("unitary", (qubit,), (arr,)))
        return self

    def transpile(self, max_iters: int = 16) -> QuantumCircuit:
        """회로에 peephole 최적화 패스를 in-place 로 적용한다.

        v0.3.1 Cut B 단계에서는 stub (no-op). Cut C 에서 회전 합성, H·X·H = Z
        같은 항등식, trivial drop 패스가 활성화된다.

        Args:
            max_iters: fixed-point iteration 상한 (기본 16).

        Returns:
            ``self`` (fluent chaining 용).
        """
        self._circuit.transpile(max_iters)
        return self

    @property
    def global_phase(self) -> float:
        """회로의 누적된 글로벌 phase (라디안)."""
        return self._circuit.global_phase

    def draw(self, style: str = "unicode") -> str:
        """회로의 텍스트 다이어그램을 반환한다.

        ``transpile()`` 호출 후에는 Rust 회로만 갱신되고 Python 측 ``_ops``
        는 그대로 남아 있으므로, ``draw()`` 는 항상 *transpile 전* 회로를
        표시한다. ``from_qasm()`` 으로 만든 회로도 v0.4 부터는 Rust
        ``Circuit::instructions()`` 에서 ``_ops`` 를 복원해 정상 다이어그램이
        출력된다.

        Args:
            style: ``"unicode"`` (default) — box-drawing 문자
                (``─ │ ┼ ┤ ├ ●``), 또는 ``"ascii"`` — 순수 ASCII
                (``- | + [ ] *``).

        Returns:
            줄 바꿈으로 join 된 다이어그램 문자열.

        Example:
            >>> qc = QuantumCircuit(2)
            >>> qc.h(0).cx(0, 1)
            >>> print(qc.draw())
            q0: ─┤H├──●──
            q1: ─────┤X├─
        """
        from .visualize import _draw_circuit_text

        return _draw_circuit_text(self._ops, self.num_qubits, style=style)

    def __repr__(self) -> str:
        return (
            f"QuantumCircuit({self.num_qubits} qubits, {len(self._ops)} ops)"
        )

    def __str__(self) -> str:
        return self.draw()

    # 측정
    def measure(self, qubit: int, cbit: int) -> QuantumCircuit:
        """특정 큐비트를 측정한다."""
        self._circuit.measure(qubit, cbit)
        # cbit 정보를 params 슬롯에 보존 (to_qiskit / to_cirq 에서 emit).
        self._ops.append(("measure", (qubit,), (int(cbit),)))
        return self

    def measure_all(self) -> QuantumCircuit:
        """모든 큐비트를 측정한다."""
        self._circuit.measure_all()
        self._ops.append(("measure_all", tuple(range(self.num_qubits)), ()))
        return self

    # 실행
    def run(
        self,
        shots: int = 1024,
        seed: Optional[int] = None,
        precision: str = "f64",
        noise_model: Optional[Any] = None,
    ) -> SimulationResult:
        """회로를 실행하고 결과를 반환한다.

        Args:
            shots: 측정 횟수.
            seed: 재현 가능한 결과를 위한 랜덤 시드.
            precision: 시뮬레이션 정밀도. ``"f64"`` (default) 또는 ``"f32"``.
                ``"f32"`` 는 메모리를 약 50% 절감하고 SIMD 친화적이지만,
                statevector 정확도가 ~1e-6 수준으로 떨어진다 (Qiskit 비교 시).
                동일 RAM 에서 큐비트 1개 더 시뮬레이션 가능.
            noise_model: ``panta_sim.NoiseModel`` 인스턴스 (v0.4 신규). 지정 시
                stochastic trajectory 모드로 실행 — 각 shot 마다 회로가
                fresh 상태에서 재실행되며 Kraus 연산자가 RNG 로 샘플링된다.
                ``shots=0`` 과 함께 쓰면 단일 trajectory 만 실행되어 mixed
                state 를 대표하지 못하므로 ``UserWarning`` 발생.

        Returns:
            SimulationResult 객체. ``result.precision`` 으로 사용된 정밀도 확인 가능.
            noise_model 사용 시 ``statevector()`` 는 마지막 trajectory 의 상태
            (디버깅 용) — 사용자는 ``counts()`` 로 통계량을 본다.
        """
        if noise_model is not None:
            if shots == 0:
                import warnings

                warnings.warn(
                    "noise model with shots=0 returns a single trajectory, "
                    "which is not representative of the mixed state",
                    UserWarning,
                    stacklevel=2,
                )
            runtime_circuit = noise_model.apply_to(self)
        else:
            runtime_circuit = self._circuit

        raw_result = _rust_run(runtime_circuit, shots, seed, precision)
        return SimulationResult(raw_result)
