"""Codebase RAG — semantic search over project files via Ollama embeddings.

Indexes the user's project files into a local vector store. The model
can call `search_codebase(query)` to retrieve the top-K relevant chunks.
Storage layout (separate from conversation memory):

  ~/.config/pw-agent/codebase/<project_hash>/
    chunks.json   list of {path, start_line, end_line, content, hash}
    vectors.npy   embedding matrix
    meta.json     project_dir, last_indexed, file_count, embed_model

Files are chunked by line groups (default 50 lines per chunk with 10
lines overlap) so retrieval brings back useful context windows. Big
files get split across many chunks; small files become single chunks.

Re-indexing skips chunks whose content hash hasn't changed.
"""

import hashlib
import json
import os
import time
from typing import Optional

import numpy as np
import requests


DEFAULT_INDEX_DIR = os.path.expanduser("~/.config/pw-agent/codebase")
EMBED_MODEL = "nomic-embed-text"

# Chunking config
CHUNK_LINES = 50
CHUNK_OVERLAP = 10

# Retrieval config
TOP_K = 8
MIN_SIMILARITY = 0.25

# Files to index by extension
INDEXABLE_EXTENSIONS = {
    ".py", ".pyi", ".pyx",
    ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs",
    ".go", ".rs", ".java", ".kt", ".swift", ".m", ".c", ".cc", ".cpp", ".h", ".hpp",
    ".rb", ".php", ".cs", ".scala", ".clj", ".ex", ".exs",
    ".html", ".css", ".scss", ".sass", ".vue", ".svelte",
    ".sh", ".bash", ".zsh", ".fish",
    ".sql", ".graphql", ".proto",
    ".md", ".mdx", ".rst", ".txt",
    ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf",
    ".dockerfile", ".tf", ".hcl",
}

# Directories to skip
IGNORED_DIRS = {
    "node_modules", ".git", ".venv", "venv", "env", "__pycache__",
    ".next", ".nuxt", "dist", "build", "out", "target", ".cache",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox",
    "coverage", "htmlcov", ".idea", ".vscode", ".DS_Store",
    "vendor", "bower_components", ".terraform", ".gradle",
    ".planning", ".worktrees", ".auto-claude",
}

# Cap on file size to index (200KB) — larger files are usually generated
MAX_FILE_BYTES = 200_000


class CodebaseIndex:
    """Vector index of project source files with chunked semantic search.

    Embeddings can come from two backends:
      - direct: hits a local Ollama at ollama_url (default localhost:11434)
      - cloud:  proxies through the PastaWater broker which routes to the
                user's active fleet brain. This lets cloud-mode pw-agents
                use /index without needing a local Ollama install.

    Pass an LLMClient via `client=` to enable the cloud path. The class
    auto-detects which path to use based on client.direct_mode.
    """

    def __init__(self, project_dir: str, ollama_url: str = "http://localhost:11434",
                 index_dir: str = "", client=None):
        self.project_dir = os.path.abspath(project_dir)
        self.ollama_url = ollama_url
        self.index_dir = index_dir or DEFAULT_INDEX_DIR
        self.client = client  # Optional LLMClient for cloud-mode embed proxy

        project_hash = hashlib.md5(self.project_dir.encode()).hexdigest()[:12]
        self.store_path = os.path.join(self.index_dir, project_hash)
        os.makedirs(self.store_path, exist_ok=True)

        self.chunks: list[dict] = []
        self.vectors: Optional[np.ndarray] = None
        self._embed_model: Optional[str] = None
        self._load()

    @property
    def size(self) -> int:
        return len(self.chunks)

    @property
    def is_indexed(self) -> bool:
        return self.size > 0 and self.vectors is not None

    def _chunks_path(self) -> str:
        return os.path.join(self.store_path, "chunks.json")

    def _vectors_path(self) -> str:
        return os.path.join(self.store_path, "vectors.npy")

    def _meta_path(self) -> str:
        return os.path.join(self.store_path, "meta.json")

    def _load(self):
        if os.path.exists(self._chunks_path()):
            try:
                with open(self._chunks_path(), "r") as f:
                    self.chunks = json.load(f)
            except Exception:
                self.chunks = []

        if os.path.exists(self._vectors_path()):
            try:
                self.vectors = np.load(self._vectors_path())
            except Exception:
                self.vectors = None

        if os.path.exists(self._meta_path()):
            try:
                with open(self._meta_path(), "r") as f:
                    meta = json.load(f)
                self._embed_model = meta.get("embed_model")
            except Exception:
                pass

    def _save(self):
        with open(self._chunks_path(), "w") as f:
            json.dump(self.chunks, f)
        if self.vectors is not None and len(self.vectors) > 0:
            np.save(self._vectors_path(), self.vectors)
        with open(self._meta_path(), "w") as f:
            json.dump({
                "project_dir": self.project_dir,
                "last_indexed": time.time(),
                "chunk_count": len(self.chunks),
                "embed_model": self._embed_model,
            }, f, indent=2)

    def _use_cloud_embed(self) -> bool:
        """True when we should route embeddings through the broker rather
        than hitting a local Ollama."""
        return bool(self.client) and not getattr(self.client, "direct_mode", False) and bool(getattr(self.client, "token", ""))

    def _embed_batch(self, texts: list[str]) -> Optional[np.ndarray]:
        """Embed a batch of texts. Returns (N, dim) or None on failure.

        Routes to broker /api/v1/agents/embed in cloud mode, falls back to
        local Ollama in direct mode.
        """
        if not texts:
            return None
        model = self._embed_model or EMBED_MODEL

        # Cloud mode: proxy through broker → fleet brain Ollama
        if self._use_cloud_embed():
            try:
                resp = self.client.session.post(
                    f"{self.client.api_url}/api/v1/agents/embed",
                    json={"model": model, "input": texts},
                    timeout=180,
                )
                if resp.status_code == 200:
                    data = resp.json() or {}
                    if data.get("success"):
                        embeddings = data.get("embeddings", [])
                        if embeddings:
                            self._embed_model = data.get("model", model)
                            return np.array(embeddings, dtype=np.float32)
                    # Surface broker errors so the caller can show them
                    err = data.get("error", "")
                    if err:
                        # Stash for caller diagnostics
                        self._last_embed_error = f"broker: {err}"
                        return None
                else:
                    self._last_embed_error = f"broker HTTP {resp.status_code}: {resp.text[:200]}"
                    return None
            except Exception as e:
                self._last_embed_error = f"broker request failed: {e}"
                return None

        # Direct/local mode: hit Ollama directly
        try:
            resp = requests.post(
                f"{self.ollama_url}/api/embed",
                json={"model": model, "input": texts},
                timeout=120,
            )
            if resp.status_code == 200:
                data = resp.json()
                embeddings = data.get("embeddings", [])
                if embeddings:
                    self._embed_model = model
                    return np.array(embeddings, dtype=np.float32)
        except Exception as e:
            self._last_embed_error = f"local Ollama failed: {e}"
            pass
        return None

    def index(self, force: bool = False, max_files: int = 5000) -> dict:
        """Walk the project, chunk files, embed new chunks. Skips unchanged content.

        Returns stats: {files_scanned, files_indexed, chunks_added, chunks_skipped, errors}
        """
        stats = {"files_scanned": 0, "files_indexed": 0, "chunks_added": 0,
                 "chunks_skipped": 0, "errors": 0}

        # Build set of existing chunk hashes for dedup
        existing_hashes = {c.get("hash"): i for i, c in enumerate(self.chunks)}

        # Walk filesystem
        new_chunks = []
        for chunk in self._walk_and_chunk(max_files=max_files):
            stats["files_scanned"] = chunk.get("_files_scanned", stats["files_scanned"])
            if chunk.get("_marker"):
                continue
            chunk_hash = chunk["hash"]
            if not force and chunk_hash in existing_hashes:
                stats["chunks_skipped"] += 1
                continue
            new_chunks.append(chunk)
            stats["chunks_added"] += 1

        if not new_chunks:
            return stats

        stats["files_indexed"] = len({c["path"] for c in new_chunks})

        # Embed in larger batches when going through the broker (one big
        # round-trip is way cheaper than many small ones across the WAN).
        # Local Ollama is fast either way, but bigger batches mean fewer
        # context switches.
        BATCH = 64
        all_vectors = []
        for i in range(0, len(new_chunks), BATCH):
            batch = new_chunks[i:i + BATCH]
            texts = [c["content"] for c in batch]
            vecs = self._embed_batch(texts)
            if vecs is None:
                stats["errors"] += len(batch)
                # Surface the most recent error for the caller
                if hasattr(self, "_last_embed_error"):
                    stats["last_error"] = self._last_embed_error
                continue
            all_vectors.append(vecs)

        if not all_vectors:
            return stats

        new_vec_matrix = np.vstack(all_vectors)

        # Append to existing
        if self.vectors is None or len(self.vectors) == 0:
            self.vectors = new_vec_matrix
            self.chunks = new_chunks
        else:
            # If embed dim changed (model swap), reset
            if self.vectors.shape[1] != new_vec_matrix.shape[1]:
                self.vectors = new_vec_matrix
                self.chunks = new_chunks
            else:
                self.vectors = np.vstack([self.vectors, new_vec_matrix])
                self.chunks = self.chunks + new_chunks

        self._save()
        return stats

    def _walk_and_chunk(self, max_files: int = 5000):
        """Generator yielding chunks dicts. Walks the project tree."""
        files_scanned = 0
        for root, dirs, files in os.walk(self.project_dir):
            # Prune ignored dirs in-place so os.walk doesn't recurse
            dirs[:] = [d for d in dirs if d not in IGNORED_DIRS and not d.startswith(".")]

            for fname in files:
                if files_scanned >= max_files:
                    return
                path = os.path.join(root, fname)
                ext = os.path.splitext(fname)[1].lower()
                if ext not in INDEXABLE_EXTENSIONS:
                    continue
                try:
                    if os.path.getsize(path) > MAX_FILE_BYTES:
                        continue
                    with open(path, "r", encoding="utf-8", errors="replace") as f:
                        content = f.read()
                except Exception:
                    continue

                rel_path = os.path.relpath(path, self.project_dir)
                files_scanned += 1
                yield {"_marker": True, "_files_scanned": files_scanned}

                lines = content.split("\n")
                if not lines:
                    continue

                # Chunk by line groups
                step = CHUNK_LINES - CHUNK_OVERLAP
                for start in range(0, len(lines), step):
                    end = min(len(lines), start + CHUNK_LINES)
                    chunk_lines = lines[start:end]
                    chunk_text = "\n".join(chunk_lines).strip()
                    if not chunk_text or len(chunk_text) < 30:
                        continue
                    # Prefix with file path so embeddings carry location info
                    embed_text = f"# {rel_path} (lines {start+1}-{end})\n{chunk_text}"
                    chunk_hash = hashlib.md5(embed_text.encode()).hexdigest()[:16]
                    yield {
                        "path": rel_path,
                        "start_line": start + 1,
                        "end_line": end,
                        "content": embed_text,
                        "hash": chunk_hash,
                    }
                    if end >= len(lines):
                        break

    def search(self, query: str, top_k: int = TOP_K) -> list[tuple[dict, float]]:
        """Semantic search over indexed chunks. Returns top-K (chunk, score)."""
        if not self.is_indexed:
            return []

        query_vec = self._embed_batch([query])
        if query_vec is None:
            return []

        # Cosine similarity
        q = query_vec / (np.linalg.norm(query_vec, axis=1, keepdims=True) + 1e-8)
        store = self.vectors / (np.linalg.norm(self.vectors, axis=1, keepdims=True) + 1e-8)
        sims = (store @ q.T).flatten()

        indices = np.argsort(sims)[::-1][:top_k]
        results = []
        for idx in indices:
            score = float(sims[idx])
            if score >= MIN_SIMILARITY:
                results.append((self.chunks[idx], score))
        return results

    def format_results(self, query: str, results: list[tuple[dict, float]] = None) -> str:
        """Format search results as readable text for the model."""
        if results is None:
            results = self.search(query)
        if not results:
            return f"No matches in indexed codebase for: {query}"
        lines = [f"Codebase search results for: {query}", ""]
        for chunk, score in results:
            path = chunk.get("path", "?")
            start = chunk.get("start_line", "?")
            end = chunk.get("end_line", "?")
            lines.append(f"━━━ {path}:{start}-{end}  (relevance {score:.2f})")
            content = chunk.get("content", "")
            # Strip the path-prefix line we added before embedding
            content_lines = content.split("\n", 1)
            if content_lines and content_lines[0].startswith("# ") and len(content_lines) > 1:
                content = content_lines[1]
            # Truncate very long chunks
            if len(content) > 1500:
                content = content[:1500] + "..."
            lines.append(content)
            lines.append("")
        return "\n".join(lines).rstrip()

    def clear(self):
        """Wipe the index."""
        self.chunks = []
        self.vectors = None
        for p in [self._chunks_path(), self._vectors_path(), self._meta_path()]:
            if os.path.exists(p):
                os.remove(p)
