# emkaymoin

> **Khaja Moinuddin Mohammed's data science portfolio — as a Python package.**

```bash
pip install emkaymoin
```

```python
import emkaymoin as emkay

emkay.whoami()
emkay.projects()
emkay.project("tacoma")
emkay.skills()
emkay.contact()
```

---

## What's inside

| Function | What it does |
|---|---|
| `emkay.whoami()` | Bio card |
| `emkay.projects()` | All projects as a pandas DataFrame |
| `emkay.projects(role='MLE')` | Filter by role |
| `emkay.projects(domain='audio')` | Filter by domain |
| `emkay.projects(stack='XGBoost')` | Filter by tech |
| `emkay.projects(sort='year', asc=True)` | Sort ascending |
| `emkay.project('tacoma')` | Full case study |
| `emkay.project('tacoma', mode='short')` | One-liner |
| `emkay.project('tacoma', mode='json')` | Raw dict |
| `emkay.search('CNN')` | Search all fields |
| `emkay.stack()` | All tech used |
| `emkay.domains()` | All domains |
| `emkay.summary()` | Portfolio stats |
| `emkay.timeline()` | ASCII timeline |
| `emkay.top(n=3)` | Most recent projects |
| `emkay.pitch()` | 30-second elevator pitch |
| `emkay.hire_me()` | Why hire me |
| `emkay.random()` | Random project |
| `emkay.skills()` | Skill bar chart |
| `emkay.education()` | Degrees |
| `emkay.contact()` | Contact details |
| `emkay.help()` | All commands |

---

## Projects

| Year | Title | Domain | Key Result |
|---|---|---|---|
| 2026 | Tacoma Pole Inspection Risk | Utilities · ML | 18% est. risk ↓ |
| 2026 | SafeANC — Emergency-Aware ANC | Audio AI · DL | <50ms latency target |
| 2026 | Legal Clause Classifier | NLP · DL | 87% F1 |
| 2025 | Bird Species Audio Classification | Audio · DL | 100% binary · 71.9% multiclass |
| 2025 | Youth Substance Use Risk | Health · ML | 81% accuracy |
| 2025 | Global Mortality Analysis | Health · Research | 75–80% variance explained |
| 2024 | Seattle Smart Parking | ML · Geospatial | R² = 0.86 |
| 2024 | SVM-Based Diabetes Risk | Health · ML | 84% acc · ROC-AUC 0.91 |

---

## Contact

- 📧 emkaymoin@gmail.com
- 🔗 linkedin.com/in/emkaymoin
- 🐙 github.com/kmohammedsu
- 🌐 emkaymoin.com

---

*M.S. Data Science · Seattle University · June 2026 · Available full-time*
