"""
emkaymoin — Khaja Moinuddin Mohammed's portfolio as a Python package.

Usage
-----
    import emkaymoin as emkay

    emkay.whoami()
    emkay.projects()
    emkay.project("tacoma")
    emkay.skills()
    emkay.education()
    emkay.contact()
    emkay.help()
"""

from ._data import PROFILE, PROJECTS, SKILLS, EDUCATION

try:
    import pandas as pd
    _PANDAS = True
except ImportError:
    _PANDAS = False


# ── helpers ───────────────────────────────────────────────

def _line(char="─", width=60):
    return char * width

def _header(text):
    print(_line())
    print(f"  {text}")
    print(_line())


# ── public API ────────────────────────────────────────────

def whoami():
    """Print a short bio card."""
    p = PROFILE
    _header(f"{p['name']}  ·  {p['callsign']}")
    print(f"  {p['tagline']}")
    print(f"  📍  {p['location']}  ·  {p['relocation']}")
    print(f"  🎓  {p['degree']}  ·  GPA {p['gpa']}")
    print(f"  💼  {p['current_role']}")
    print(f"  ✅  Available: {p['available']}")
    print(f"  🔍  Open to: {', '.join(p['open_to'])}")
    print(f"  💡  Interests: {', '.join(p['interests'])}")
    print(_line())


def projects(role=None, domain=None, stack=None, sort="year", asc=False):
    """
    Return all projects as a DataFrame, with optional filters and sorting.

    Parameters
    ----------
    role   : str  — filter by role tag: 'DS', 'MLE', 'DA'
    domain : str  — filter by domain keyword (case-insensitive)
    stack  : str  — filter by tech in stack list (case-insensitive)
    sort   : str  — sort key: 'year' | 'title' | 'metric' (default: 'year')
    asc    : bool — ascending sort (default: False)
    """
    data = PROJECTS
    if role:
        data = [p for p in data if role.upper() in p["roles"]]
    if domain:
        data = [p for p in data if domain.lower() in p["domain"].lower()]
    if stack:
        data = [p for p in data if any(stack.lower() in s.lower() for s in p["stack"])]

    data = sorted(data, key=lambda x: x.get(sort, x["year"]), reverse=not asc)

    if _PANDAS:
        cols = ["year", "title", "domain", "model", "metric", "roles"]
        return pd.DataFrame(data)[cols].reset_index(drop=True)
    else:
        for p in data:
            print(f"  [{p['year']}]  {p['title']}  ·  {p['metric']}")
        return data


def project(id: str, mode: str = "full"):
    """
    Print a case study card for one project.

    Parameters
    ----------
    id   : str — project id (tacoma | safeanc | legalbert | bird | youth | mortality | parking | diabetes)
    mode : str — 'full' | 'short' | 'json'
    """
    match = [p for p in PROJECTS if p["id"] == id.lower()]
    if not match:
        ids = [p["id"] for p in PROJECTS]
        print(f"  ⚠  No project with id '{id}'.")
        print(f"  Available ids: {', '.join(ids)}")
        return
    p = match[0]
    if mode == "json":
        return p
    if mode == "short":
        print(f"  [{p['year']}]  {p['title']}  ·  {p['domain']}  ·  {p['metric']}")
        return
    _header(f"{p['domain'].upper()}  ·  {p['year']}\n  {p['title']}")
    print(f"  KEY RESULT  →  {p['metric']}\n")
    print(f"  ▸ problem\n    {p['problem'] or '(coming soon)'}\n")
    print(f"  ▸ approach\n    {p['approach'] or '(coming soon)'}\n")
    print(f"  ▸ outcome\n    {p['outcome'] or '(coming soon)'}\n")
    print(f"  stack: {', '.join(p['stack'])}")
    print(_line())


def skills():
    """Print skill proficiency as a █ bar chart, rated 1–5."""
    _header("Skills  ·  self-rated 1–5")
    for skill, level in sorted(SKILLS.items(), key=lambda x: -x[1]):
        bar = "█" * level + "░" * (5 - level)
        print(f"  {skill:<22} {bar}  {level}/5")
    print(_line())


def education():
    """Print education history."""
    _header("Education")
    for e in EDUCATION:
        gpa = f"  ·  GPA {e['gpa']}" if e.get("gpa") else ""
        print(f"  {e['degree']}  ·  {e['school']}  ·  {e['year']}{gpa}")
    print(_line())


def contact():
    """Print contact details."""
    _header("Contact  ·  emkay")
    p = PROFILE
    print(f"  {'email':<12} {p['email']}")
    print(f"  {'phone':<12} {p['phone']}")
    print(f"  {'github':<12} {p['github']}")
    print(f"  {'linkedin':<12} {p['linkedin']}")
    print(_line())


def search(keyword: str):
    """Search across all project fields for a keyword."""
    keyword = keyword.lower()
    fields = ["title", "domain", "problem", "approach", "outcome"]
    results = []
    for p in PROJECTS:
        text = " ".join([str(p.get(f, "")) for f in fields] + p["stack"]).lower()
        if keyword in text:
            results.append(p)
    if not results:
        print(f"  ⚠  No projects matched '{keyword}'.")
        return
    _header(f"Search results for '{keyword}'")
    for p in results:
        print(f"  [{p['year']}]  {p['title']}  ·  {p['domain']}  ·  {p['metric']}")
    print(_line())


def stack():
    """Print every unique technology used across all projects, sorted A-Z."""
    all_tech = sorted(set(t for p in PROJECTS for t in p["stack"]))
    _header("Full Tech Stack")
    print("  " + ",  ".join(all_tech))
    print(_line())


def domains():
    """Print all unique domains across projects."""
    all_domains = sorted(set(p["domain"] for p in PROJECTS))
    _header("Domains")
    for d in all_domains:
        print(f"  {d}")
    print(_line())


def summary():
    """Print quick stats across the whole portfolio."""
    all_tech = set(t for p in PROJECTS for t in p["stack"])
    all_roles = set(r for p in PROJECTS for r in p["roles"])
    years = sorted(set(p["year"] for p in PROJECTS))
    _header("Portfolio Summary")
    print(f"  Projects    {len(PROJECTS)}")
    print(f"  Skills      {len(SKILLS)}")
    print(f"  Tech used   {len(all_tech)}")
    print(f"  Roles       {', '.join(sorted(all_roles))}")
    print(f"  Years       {years[0]} – {years[-1]}")
    print(_line())


def timeline():
    """Print an ASCII timeline of projects grouped by year."""
    from collections import defaultdict
    _header("Project Timeline")
    by_year = defaultdict(list)
    for p in PROJECTS:
        by_year[p["year"]].append(p)
    for year in sorted(by_year.keys(), reverse=True):
        print(f"\n  {year}")
        for p in by_year[year]:
            print(f"    ├─  {p['title']}  ·  {p['metric']}")
    print("\n" + _line())


def top(n: int = 3):
    """Print the n most recent projects as short cards."""
    recent = sorted(PROJECTS, key=lambda x: x["year"], reverse=True)[:n]
    _header(f"Top {n} Most Recent Projects")
    for p in recent:
        print(f"  [{p['year']}]  {p['title']}  ·  {p['domain']}  ·  {p['metric']}")
    print(_line())


def pitch():
    """Print a 30-second elevator pitch."""
    p = PROFILE
    roles = " · ".join(p["open_to"])
    _header("30-Second Pitch")
    print(f"""
  I'm {p['name']} — a data scientist based in {p['location']},
  finishing my master's in Data Science at Seattle University
  this June with a {p['gpa']} GPA.

  I currently work as {p['current_role']},
  where I built end-to-end ML systems that are actually being
  used — Tableau dashboards adopted by 5+ stakeholder groups,
  geospatial risk maps across 217 circuits, and classifiers
  tuned for real-world imbalanced data.

  My work spans utilities, healthcare, audio ML, and NLP.
  I'm looking for full-time roles as a {roles},
  available {p['available']}.
    """)
    print(_line())


def hire_me():
    """Print a why-hire-me blurb."""
    _header("Why Hire emkay")
    print("""
  ✦  I don't just build models — I ship things that get used.
     Tableau dashboards adopted by 5+ stakeholder groups at
     Tacoma Public Utilities. Real-time inference on edge hardware.

  ✦  I work across the full stack — ETL, modeling, evaluation,
     visualization, and stakeholder communication.

  ✦  I bring depth where it counts — SHAP explainability,
     geospatial pipelines, imbalanced-class handling, and
     domain-specific models like LegalBERT.

  ✦  I'm genuinely curious. This package is proof.
    """)
    print(_line())


def random():
    """Print a random project as a full case study."""
    import random as _random
    p = _random.choice(PROJECTS)
    project(p["id"])


def help():
    """List all available functions."""
    _header("emkaymoin  ·  available commands")
    cmds = {
        "emkay.whoami()":                        "Bio card",
        "emkay.projects()":                      "All projects as DataFrame",
        "emkay.projects(role='MLE')":            "Filter by role",
        "emkay.projects(domain='audio')":        "Filter by domain",
        "emkay.projects(stack='XGBoost')":       "Filter by tech",
        "emkay.projects(sort='year', asc=True)": "Sort ascending",
        "emkay.project('tacoma')":               "Full case study",
        "emkay.project('tacoma', mode='short')": "One-liner summary",
        "emkay.project('tacoma', mode='json')":  "Raw dict",
        "emkay.search('CNN')":                   "Search all fields",
        "emkay.stack()":                         "All tech used",
        "emkay.domains()":                       "All domains",
        "emkay.summary()":                       "Portfolio stats",
        "emkay.timeline()":                      "ASCII timeline",
        "emkay.top(n=3)":                        "Most recent n projects",
        "emkay.pitch()":                         "30-second elevator pitch",
        "emkay.hire_me()":                       "Why hire me",
        "emkay.random()":                        "Random project",
        "emkay.skills()":                        "Skill bar chart",
        "emkay.education()":                     "Degrees",
        "emkay.contact()":                       "Contact details",
        "emkay.help()":                          "This menu",
    }
    for cmd, desc in cmds.items():
        print(f"  {cmd:<45}  {desc}")
    print(_line())