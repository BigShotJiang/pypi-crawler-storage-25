from setuptools import setup, find_packages

setup(
    name="emkaymoin",
    version="0.2.0",
    description="Khaja Moinuddin Mohammed's data science portfolio as a Python package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Khaja Moinuddin Mohammed",
    author_email="emkaymoin@gmail.com",
    url="https://github.com/kmohammedsu/emkaymoin",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "pandas>=1.3",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
