import builtins
import contextlib
import functools
import os
import shutil
import subprocess
import sys
import tempfile
import textwrap
import time
import warnings
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import configargparse
import pytest

import compiletools.apptools
from compiletools.check_venv import cached_venv_mismatch_reason

# Re-exported so test files can use uth.example_path / uth.example_file
# without an extra import line.
from compiletools.examples_registry import (
    e2e_dir,
    example_file,  # noqa: F401
    example_path,  # noqa: F401
    features_dir,  # noqa: F401
)

# The abbreviation "uth" is often used for this "testhelper"


def _backend_tool_available(backend_name):
    """Check if the build tool for a backend is on PATH."""
    if backend_name == "shake":
        return True  # Self-executing, no external tool needed
    if backend_name == "bazel":
        return shutil.which("bazelisk") is not None or shutil.which("bazel") is not None
    if backend_name == "cmake":
        return shutil.which("cmake") is not None
    tool = {"make": "make", "ninja": "ninja", "slurm": "sbatch"}.get(backend_name)
    if tool is None:
        return False
    return shutil.which(tool) is not None


def requires_backend_tool(backend_name_or_param="backend_name"):
    """Skip test when the build tool for a backend is not on PATH.

    Usage with parametrize (reads 'backend_name' kwarg):
        @requires_backend_tool()
        @pytest.mark.parametrize("backend_name", available_backends())

    Usage with fixed name:
        @requires_backend_tool("ninja")
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            name = kwargs.get(backend_name_or_param, backend_name_or_param)
            if not _backend_tool_available(name):
                pytest.skip(f"{name} build tool not found on PATH")
            return func(*args, **kwargs)

        return wrapper

    if callable(backend_name_or_param):
        func = backend_name_or_param
        backend_name_or_param = "backend_name"
        return decorator(func)
    return decorator


def requires_functional_compiler(func):
    """Decorator to skip tests that require a functional C++ compiler.

    This decorator checks if a functional C++ compiler is available and
    automatically skips the test with an appropriate message if none is found.

    Usage:
        @requires_functional_compiler
        def test_something_that_needs_compiler(self):
            # Test code that requires a C++ compiler
            pass
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if compiletools.apptools.get_functional_cxx_compiler() is None:
            pytest.skip("No functional C++ compiler detected")
        return func(*args, **kwargs)

    return wrapper


def requires_lockdir_filesystem(func):
    """Decorator to skip tests that require lockdir-based locking (NFS/Lustre).

    This decorator checks if the test tmpdir filesystem uses lockdir strategy
    and automatically skips the test if it uses flock, fcntl, or cifs instead.

    Usage:
        @requires_lockdir_filesystem
        def test_something_that_needs_lockdir(self):
            # Test code that requires NFS/Lustre filesystem
            pass
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        import compiletools.filesystem_utils

        with tempfile.TemporaryDirectory() as tmpdir:
            fstype = compiletools.filesystem_utils.get_filesystem_type(tmpdir)
            strategy = compiletools.filesystem_utils.get_lock_strategy(fstype)
            if strategy != "lockdir":
                pytest.skip(f"Filesystem {fstype} uses {strategy} (not lockdir) - test requires NFS/Lustre")
        return func(*args, **kwargs)

    return wrapper


def requires_flock_filesystem(func):
    """Decorator to skip tests that require flock-based locking (local filesystems).

    This decorator checks if the test tmpdir filesystem uses flock strategy
    and automatically skips the test if it uses lockdir or cifs instead.

    Usage:
        @requires_flock_filesystem
        def test_something_that_needs_flock(self):
            # Test code that requires ext4/xfs/btrfs local filesystem
            pass
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        import compiletools.filesystem_utils

        with tempfile.TemporaryDirectory() as tmpdir:
            fstype = compiletools.filesystem_utils.get_filesystem_type(tmpdir)
            strategy = compiletools.filesystem_utils.get_lock_strategy(fstype)
            if strategy != "flock":
                pytest.skip(
                    f"Filesystem {fstype} uses {strategy} (not flock) - test requires local filesystem (ext4/xfs/btrfs)"
                )
        return func(*args, **kwargs)

    return wrapper


def skip_if_bazel_env_error(captured_stderr: str) -> None:
    """Skip the current test if *captured_stderr* indicates a Bazel environment
    problem (TLS certificate rejection, unsupported filesystem operation, JVM
    thread / heap exhaustion under high job counts, missing linker on a
    stripped toolchain) rather than a genuine code bug.
    """
    lower = captured_stderr.lower()
    env_markers = (
        "certificate",  # TLS trust store
        "operation not supported",  # filesystem op (NFS, etc.)
        "outofmemoryerror",  # JVM thread/heap exhaustion
        "unable to create native thread",  # same, more specific
        "cannot find 'ld'",  # linker unavailable in sandbox
        "could not find a c++ toolchain",  # rules_cc misconfigured
    )
    for marker in env_markers:
        if marker in lower:
            pytest.skip(f"bazel environment issue: {captured_stderr[:200]}")
            return


def with_group_writable_umask(cls_or_func):
    """Decorator to temporarily set group-writable umask for file-locking tests.

    This decorator temporarily sets umask to 0o002 (allow group read/write) for the
    duration of the test, then restores the original umask.

    Can be used on individual test methods or entire test classes.

    Usage:
        @with_group_writable_umask
        def test_something_that_needs_file_locking(self):
            pass

        @with_group_writable_umask
        class TestSharedObjects:
            pass
    """

    def with_umask(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            old_umask = os.umask(0o002)
            try:
                return func(*args, **kwargs)
            finally:
                os.umask(old_umask)

        return wrapper

    # If decorating a class
    if isinstance(cls_or_func, type):
        # Wrap all test methods
        for attr_name in dir(cls_or_func):
            if attr_name.startswith("test_"):
                attr = getattr(cls_or_func, attr_name)
                if callable(attr):
                    setattr(cls_or_func, attr_name, with_umask(attr))
        return cls_or_func
    else:
        # Decorating a function
        return with_umask(cls_or_func)


def requires_pkg_config(*packages):
    """Decorator to skip tests that require specific pkg-config packages.

    This decorator checks if the specified pkg-config packages are available
    and automatically skips the test with an appropriate message if any are missing.

    Args:
        *packages: One or more package names to check with pkg-config --exists

    Usage:
        @requires_pkg_config("zlib")
        def test_something_that_needs_zlib(self):
            # Test code that requires zlib
            pass

        @requires_pkg_config("zlib", "libcrypt")
        def test_something_that_needs_multiple_packages(self):
            # Test code that requires both zlib and libcrypt
            pass
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            missing_packages = []
            for package in packages:
                try:
                    result = subprocess.run(["pkg-config", "--exists", package], capture_output=True, check=False)
                    if result.returncode != 0:
                        missing_packages.append(package)
                except (subprocess.SubprocessError, FileNotFoundError):
                    # pkg-config not available or other error
                    missing_packages.append(package)

            if missing_packages:
                if len(missing_packages) == 1:
                    pytest.skip(f"pkg-config package '{missing_packages[0]}' not available")
                else:
                    pytest.skip(f"pkg-config packages {missing_packages} not available")

            return func(*args, **kwargs)

        return wrapper

    return decorator


def reset():
    delete_existing_parsers()
    compiletools.apptools.resetcallbacks()
    # Clear wrappedos caches to prevent test interactions
    import compiletools.wrappedos as wo

    wo.clear_cache()
    # Clear git utils caches
    import compiletools.git_utils as git_utils

    git_utils.clear_cache()
    # Clear configutils caches (default_config_directories, the per-path
    # parse cache, and the runtime out-of-order extends dedup set). Tests
    # that mutate conf files mid-process need this to see fresh content;
    # function-based tests would otherwise see stale state from the
    # previous test in the same xdist worker.
    import compiletools.configutils as configutils

    configutils.clear_cache()
    # Note: global_hash_registry, file_analyzer, preprocessing_cache,
    # and headerdeps include-list caches now live on BuildContext instances.
    # Creating a fresh BuildContext gives clean state, so no module-level
    # clearing is needed for those.


def delete_existing_parsers():
    """The singleton parsers supplied by configargparse
    don't play well with the test framework.
    This function will delete them so you are
    starting with a clean slate
    """
    configargparse._parsers = {}


def ctdir():
    return os.path.dirname(os.path.realpath(__file__))


def cakedir():
    return os.path.realpath(os.path.join(ctdir(), ".."))


def ctconfdir():
    return os.path.realpath(os.path.join(ctdir(), "ct.conf.d"))


# Root of the compiletools src tree containing this testhelper module.
# All test files in this repo live under ``src/compiletools/``, so they
# all share the same expected install root: this directory's parent.
_TESTSUITE_SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def skipif_e2e_unavailable(probe_predicate, feature_reason: str):
    """Build a ``pytest.mark.skipif`` that fires for either of two reasons:

    1. The venv's installed compiletools doesn't match this worktree
       (``check_venv.cached_venv_mismatch_reason()`` returned non-None).
       Affected e2e tests would silently exercise the wrong code, so
       skip with the actionable "re-install with `uv pip install -e .`"
       message instead of letting the test fail mysteriously.
    2. The compiler can't satisfy the feature being tested
       (``probe_predicate()`` returned False).

    When BOTH conditions trip, the venv message wins -- it's the more
    fundamental issue and the user has to fix it before the feature
    probe even becomes meaningful.

    Centralising the composition here lets every e2e test keep its
    single ``@requires_X`` decorator without sprouting a parallel
    ``@requires_fresh_venv`` everywhere.
    """
    venv_reason = cached_venv_mismatch_reason(_TESTSUITE_SRC)
    if venv_reason is not None:
        return pytest.mark.skipif(True, reason=venv_reason)
    return pytest.mark.skipif(not probe_predicate(), reason=feature_reason)


def create_temp_config(tempdir=None, filename=None, extralines=None):
    """Create a temporary config file with detected functional compilers.

    Uses get_functional_cxx_compiler() to detect working C++ compiler

    Args:
        tempdir: Directory to create temp file in
        filename: Specific filename to use (auto-generated if None)
        extralines: Additional config lines to append

    Returns:
        str: Path to created config file

    Note: User is responsible for removing the config file when finished
    """
    if extralines is None:
        extralines = []
    CXX = compiletools.apptools.get_functional_cxx_compiler()
    CC = compiletools.apptools.derive_c_compiler_from_cxx(CXX)

    if not filename:
        _tf_handle, filename = tempfile.mkstemp(suffix=".conf", text=True, dir=tempdir)

    with builtins.open(filename, "w") as ff:
        ff.write(f"CC={CC}\n")
        ff.write(f"CXX={CXX}\n")
        ff.write('CPPFLAGS="-std=c++20"\n')
        for line in extralines:
            ff.write(f"{line}\n")

    return filename


def create_temp_ct_conf(tempdir, defaultvariant="gcc.cxx26.debug", extralines=None):
    """User is responsible for removing the config file when
    they are finished.

    Default variant matches the bundled ct.conf default
    (``gcc.cxx26.debug``). Canonicalizes to itself under the builtin
    canonical-order; the bundled ``gcc.conf`` + ``cxx26.conf`` +
    ``debug.conf`` axis files satisfy the resolver in tests that don't
    supply their own.
    """
    if extralines is None:
        extralines = []
    with builtins.open(os.path.join(tempdir, "ct.conf"), "w") as ff:
        ff.write(f"variant = {defaultvariant}\n")
        ff.write("exemarkers = [main]\n")
        ff.write("testmarkers = unit_test.hpp\n")
        for line in extralines:
            ff.write(f"{line}\n")


def _rmtree_retry(func, path, exc_or_info):
    """Retry handler for shutil.rmtree on distributed filesystems (GPFS/NFS).

    On GPFS, rmtree can fail transiently when files are still being flushed
    (e.g., Slurm output files). Retry once after a short delay. If the retry
    also fails, warn instead of raising so test cleanup failures don't mask
    test results.

    Bridges the 3.10/3.11 ``onerror=(func, path, exc_info-tuple)`` and the
    3.12+ ``onexc=(func, path, exception)`` callback signatures.
    """
    if isinstance(exc_or_info, BaseException):
        exc_value = exc_or_info
        exc_type = type(exc_value)
    else:
        exc_type, exc_value, _ = exc_or_info
    if exc_type is FileNotFoundError:
        return  # already gone
    time.sleep(0.1)
    try:
        func(path)
    except OSError:
        warnings.warn(
            f"Failed to clean up temp path during test teardown: {path} ({exc_value})",
            stacklevel=2,
        )


# 3.12 renamed shutil.rmtree's callback kwarg from ``onerror`` (deprecated) to
# ``onexc``. Define the wrapper twice so each branch holds only the kwarg
# valid for its Python version.
if sys.version_info >= (3, 12):

    def _rmtree(path):
        shutil.rmtree(path, onexc=_rmtree_retry)
else:

    def _rmtree(path):
        # pyright is pinned to pythonVersion="3.10" where ``onerror`` is not
        # deprecated, so the deprecation hint that fires on newer interpreters
        # is suppressed for this codepath only.
        shutil.rmtree(path, onerror=_rmtree_retry)  # pyright: ignore[reportDeprecated]


class TempDirectoryContext:
    """Context manager for temporary directories with optional directory changing.

    Unifies all temp directory patterns into a single, flexible context manager.
    """

    def __init__(self, change_dir=True, prefix=None, suffix=None, dir=None):
        """
        Args:
            change_dir: If True, changes to the temp directory (default: True for backward compatibility)
            prefix: Prefix for temp directory name
            suffix: Suffix for temp directory name
            dir: Parent directory for temp directory
        """
        self.change_dir = change_dir
        self.prefix = prefix
        self.suffix = suffix
        self.dir = dir
        self._tmpdir = None
        self._origdir = None

    def __enter__(self):
        if self.change_dir:
            self._origdir = os.getcwd()

        self._tmpdir = tempfile.mkdtemp(prefix=self.prefix, suffix=self.suffix, dir=self.dir)

        if self.change_dir:
            os.chdir(self._tmpdir)

        return self._tmpdir

    def __exit__(self, exc_type, exc_value, traceback):
        if self.change_dir and self._origdir:
            os.chdir(self._origdir)
        if self._tmpdir:
            _rmtree(self._tmpdir)


# Backward compatibility aliases
class TempDirContext(TempDirectoryContext):
    """Backward compatibility: temp directory with directory change."""

    def __init__(self):
        super().__init__(change_dir=True)

    def __enter__(self):  # type: ignore[override]  # pyright: ignore[reportIncompatibleMethodOverride]
        # Deliberate divergence: the base class yields the tmpdir string, but
        # the legacy ``TempDirContext`` API returns ``self`` so callers can
        # access ``.tmpdir`` / ``.origdir`` after entering.
        super().__enter__()
        return self


class TempDirContextNoChange(TempDirectoryContext):
    """Backward compatibility: temp directory without directory change."""

    def __init__(self, prefix=None, suffix=None, dir=None):
        super().__init__(change_dir=False, prefix=prefix, suffix=suffix, dir=dir)


class TempDirContextWithChange(TempDirectoryContext):
    """Backward compatibility: temp directory with directory change."""

    def __init__(self, prefix=None, suffix=None, dir=None):
        super().__init__(change_dir=True, prefix=prefix, suffix=suffix, dir=dir)


@contextlib.contextmanager
def DirectoryContext(target_dir):
    """Context manager for changing to a specific directory temporarily."""
    origdir = os.getcwd()
    try:
        os.chdir(target_dir)
        yield target_dir
    finally:
        os.chdir(origdir)


@contextlib.contextmanager
def isolated_cas_dirs(parent):
    """Yield argv overriding the four ``--cas-*dir`` flags into ``parent/cas/``.

    Tests that run ct-cake / Cake from outside ``parent`` (i.e. without
    ``monkeypatch.chdir(parent)``) inherit the parent process's cwd, so
    ``find_git_root`` resolves to the compiletools repo and ``--cas-exedir``
    silently defaults to ``{git_root}/cas-exedir/<variant>`` — leaking link
    artefacts (and their ``.lock`` / ``.manifest`` sidecars) into the source
    tree. Overriding ``--cas-objdir`` alone is not enough; the four CAS
    directories are independent flags. This helper pins all four and removes
    the tree on exit.
    """
    parent = Path(parent)
    cas_root = parent / "cas"
    cas_root.mkdir(parents=True, exist_ok=True)
    argv = [
        "--cas-objdir",
        str(cas_root / "obj"),
        "--cas-pchdir",
        str(cas_root / "pch"),
        "--cas-pcmdir",
        str(cas_root / "pcm"),
        "--cas-exedir",
        str(cas_root / "exe"),
    ]
    try:
        yield argv
    finally:
        shutil.rmtree(cas_root, ignore_errors=True)


@contextlib.contextmanager
def EnvironmentContext(env_vars):
    """Context manager for temporarily setting environment variables.

    Args:
        env_vars: Dictionary of environment variables to set
    """
    original_values = {}

    # Save original values and set new ones
    for key, value in env_vars.items():
        if value:  # Only set non-empty values
            original_values[key] = os.getenv(key)
            os.environ[key] = value

    try:
        yield
    finally:
        # Restore original values
        for key in env_vars:
            if key in original_values:
                if original_values[key] is not None:
                    os.environ[key] = original_values[key]
                else:
                    os.environ.pop(key, None)  # Remove if it wasn't set before


@contextlib.contextmanager
def CompilerEnvContext(cxx):
    """Pin CXX, CPP, and LD to the same compiler in the environment.

    Subprocesses spawned inside the ``with`` block (e.g. ``ct-cake`` via
    ``subprocess.run``) inherit ``os.environ`` and pick up all three
    overrides without an explicit ``env=`` argument.

    LD must move with CXX: the bundled default variant
    (``gcc.cxx26.debug``) loads ``gcc.conf`` which pins ``LD = g++``;
    without an env LD override the linker stays g++ and any clang
    compile that auto-injects ``-stdlib=libc++`` (or merely propagates
    ``-std=c++20`` from CXXFLAGS into LDFLAGS via
    ``unsupplied_replacement``) leaks into a g++ link, producing either
    "unrecognized command line option" on an old g++ or undefined
    references to ``std::__1::*`` on a newer one. CC stays unchanged --
    the C++ samples are pure C++ and don't exercise the C compiler.
    """
    with EnvironmentContext({"CXX": cxx, "CPP": cxx, "LD": cxx}):
        yield


@contextlib.contextmanager
def ParserContext():
    """Context manager for temporarily resetting configargparse state."""
    saved_parsers = configargparse._parsers.copy()
    delete_existing_parsers()
    compiletools.apptools.resetcallbacks()

    try:
        yield
    finally:
        configargparse._parsers = saved_parsers
        compiletools.apptools.resetcallbacks()


@contextlib.contextmanager
def TempConfigContext(tempdir=None, filename=None, extralines=None):
    """Context manager for temporary config files with automatic cleanup.

    Args:
        tempdir: Directory to create temp config in (default: system temp)
        filename: Specific filename to use (default: auto-generated)
        extralines: Additional config lines to add
    """
    config_path = create_temp_config(tempdir=tempdir, filename=filename, extralines=extralines or [])
    try:
        yield config_path
    finally:
        if config_path and os.path.exists(config_path):
            os.unlink(config_path)


@contextlib.contextmanager
def CompileToolsTestContext(reload_modules=None, config_extralines=None):
    """A higher-level context manager for compiletools tests.

    This combines the most common testing patterns:
    - TempDirContextWithChange: Creates temp directory and changes to it
    - TempConfigContext: Creates temporary config file with cleanup
    - ParserContext: Provides isolated parser state
    - Module reloads: Reloads specified modules to pick up changes

    Args:
        reload_modules: List of modules to reload (e.g., [compiletools.headerdeps])
        config_extralines: Additional lines to add to temp config file

    Returns:
        tuple: (tempdir, config_path) for use in test
    """
    import importlib

    reload_modules = reload_modules or []

    with TempDirContextWithChange() as tempdir:
        with TempConfigContext(tempdir=tempdir, extralines=config_extralines) as config_path:
            with ParserContext():
                # Reload specified modules
                for module in reload_modules:
                    importlib.reload(module)

                yield (tempdir, config_path)


def run_headerdeps(kind, filename, cppflags=None, extra_args=None):
    """Helper function to run headerdeps analysis and return result set.

    Eliminates the repetitive pattern of:
    - Creating config
    - Creating parser
    - Running analysis
    - Converting to set

    Args:
        kind: HeaderDeps kind ("direct" or "cpp")
        filename: File to analyze
        cppflags: Optional CPPFLAGS string
        extra_args: Additional command line arguments

    Returns:
        set: Set of header dependencies found
    """
    with TempConfigContext() as temp_config_name:
        argv = [
            "--config=" + temp_config_name,
            f"--headerdeps={kind}",
            "--include",
            e2e_dir(),
        ]

        if cppflags:
            argv.extend(["--CPPFLAGS", f"-I{e2e_dir()} {cppflags}"])

        if extra_args:
            argv.extend(extra_args)

        with HeaderDepsTestContext(argv) as hdeps:
            return set(hdeps.process(filename, frozenset()))


@contextlib.contextmanager
def HeaderDepsTestContext(argv, config_extralines=None):
    """Context manager for headerdeps tests that handles the common boilerplate pattern.

    Encapsulates the repeated pattern of:
    - Create and configure parser
    - Parse arguments
    - Create headerdeps object

    Args:
        argv: Command line arguments for headerdeps
        config_extralines: Additional config file lines if needed

    Yields:
        headerdeps: Configured HeaderDeps object ready for testing
    """
    import configargparse

    import compiletools.apptools
    import compiletools.headerdeps
    from compiletools.build_context import BuildContext

    # Create and configure parser
    cap = configargparse.ArgumentParser(
        conflict_handler="resolve",
        args_for_setting_config_path=["-c", "--config"],
        ignore_unknown_config_file_keys=True,
    )
    compiletools.headerdeps.add_arguments(cap)

    # Create headerdeps object with fresh BuildContext
    ctx = BuildContext()
    args = compiletools.apptools.parseargs(cap, argv, context=ctx)
    headerdeps = compiletools.headerdeps.create(args, context=ctx)
    yield headerdeps


@contextlib.contextmanager
def CPPDepsTestContext(variant_configs=None, reload_modules=None):
    """A context manager for tests that call main() functions requiring configuration.

    Currently used by test_cppdeps. This combines:
    - TempDirContext: Creates temp directory and changes to it
    - Config file setup: Copies ct.conf and specified variant config files
    - Module reloads: Reloads specified modules to pick up changes
    - Parser cleanup: Resets configargparse state

    Args:
        variant_configs: List of config files to copy (e.g., ['gcc.debug.conf'])
        reload_modules: List of modules to reload (e.g., [compiletools.headerdeps])
    """
    import importlib

    variant_configs = variant_configs or ["blank.conf"]
    reload_modules = reload_modules or []

    # Use our refactored context managers in a nested fashion
    with TempDirContext() as temp_context:
        # Copy config files to test environment
        ct_conf_dir = os.path.join(os.getcwd(), "ct.conf.d")
        os.makedirs(ct_conf_dir, exist_ok=True)

        src_config_dir = ctconfdir()
        # Always copy ct.conf
        config_files = ["ct.conf"] + variant_configs
        for config_file in config_files:
            src_path = os.path.join(src_config_dir, config_file)
            dst_path = os.path.join(ct_conf_dir, config_file)
            if os.path.exists(src_path):
                shutil.copy2(src_path, dst_path)

        # Reload specified modules
        for module in reload_modules:
            importlib.reload(module)

        # Reset parser state
        reset()

        try:
            yield temp_context
        finally:
            reset()


def headerdeps_result(filename, kind="direct", cppflags=None, include=None, extra_args=None):
    """Return set of headers for given filename using specified headerdeps kind.
    Provides full isolation (TempConfig, Parser).
    Args:
        filename: Path to file to analyse (can be relative; will be realpathed by headerdeps)
        kind: 'direct' or 'cpp'
        cppflags: Raw CPPFLAGS string (pass full string, do NOT auto-prepend -I)
        include: Directory to use with --include (defaults to e2e_dir())
        extra_args: List of extra CLI args (e.g., ["--something", "value"])
    Returns: set of header paths
    """
    include = include or e2e_dir()
    if extra_args is None:
        extra_args = []
    # ``from ... import name`` so the local binding does not shadow
    # ``compiletools`` (which would lose ``apptools`` for the rest of the
    # function scope, breaking the call below).
    from compiletools import headerdeps as _headerdeps

    # Create config with custom CPPFLAGS if needed
    config_extralines = []
    if cppflags:
        config_extralines.append(f'CPPFLAGS="-std=c++20 {cppflags}"')

    from compiletools.build_context import BuildContext

    with TempConfigContext(extralines=config_extralines) as temp_config_name:
        # Clear all caches for test isolation
        _headerdeps.HeaderDepsBase.clear_cache()

        # Create fresh parser with complete isolation
        with ParserContext():
            cap = configargparse.ArgumentParser(
                description="HeaderDeps test parser",
                formatter_class=configargparse.ArgumentDefaultsHelpFormatter,
                args_for_setting_config_path=["-c", "--config"],
                ignore_unknown_config_file_keys=False,
            )
            _headerdeps.add_arguments(cap)
            argv = ["--config=" + temp_config_name, f"--headerdeps={kind}", "--include", include] + extra_args
            ctx = BuildContext()
            args = compiletools.apptools.parseargs(cap, argv, context=ctx)
            h = _headerdeps.create(args, context=ctx)
            return set(h.process(filename, frozenset()))


def compare_headerdeps_kinds(
    filename, cppflags=None, kinds=("direct", "cpp"), include=None, extra_args=None, scenario_name=None
):
    """Run multiple headerdeps kinds and assert their results match (if >1 kinds).
    Returns dict kind->set.
    scenario_name included in assertion message if provided.
    """
    results = {}
    for kind in kinds:
        results[kind] = headerdeps_result(
            filename, kind=kind, cppflags=cppflags, include=include, extra_args=extra_args
        )
    if len(kinds) > 1:
        baseline = results[kinds[0]]
        for kind in kinds[1:]:
            if results[kind] != baseline:
                raise AssertionError(
                    f"HeaderDeps results differ{(' for ' + scenario_name) if scenario_name else ''}: "
                    f"{kinds[0]}={sorted(os.path.basename(f) for f in baseline)} vs "
                    f"{kind}={sorted(os.path.basename(f) for f in results[kind])}"
                )
    return results


def touch(*paths):
    """Touch multiple files by appending a comment to ensure content hash changes.

    This ensures the file's content hash changes, not just its timestamp,
    which is important for build systems that use content-based change detection.
    Includes a small sleep to ensure timestamp differences are detectable.

    Args:
        *paths: Variable number of file paths to touch
    """
    import time

    for path in paths:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        # Append a comment with timestamp to ensure content changes
        with builtins.open(path, "a") as f:
            f.write(f"\n// touched at {time.time()}\n")

    # Note: global_hash_registry and file_analyzer caches now live on
    # BuildContext instances, so no module-level clearing needed here.

    import compiletools.wrappedos as wo

    wo.clear_cache()

    # Brief sleep to ensure timestamp differences are detectable
    time.sleep(0.01)


def write_sources(mapping, target_dir=None):
    """Central utility for temp source file creation.

    Args:
        mapping: Dictionary of {relative_path: content} for files to create
        target_dir: Directory to create files in (defaults to current directory)

    Returns:
        Dictionary of {relative_path: Path} for created files

    Usage:
        files = uth.write_sources({
            "main.cpp": '''
                #include <iostream>
                int main() { return 0; }
            ''',
            "extra.hpp": '''
                #pragma once
                void helper();
            '''
        })
        # files["main.cpp"] is a Path object to the created file

        # Or write to specific directory:
        files = uth.write_sources(mapping, target_dir="/tmp/test")
    """
    if target_dir is None:
        base_path = Path(os.getcwd())
    else:
        base_path = Path(target_dir)

    paths = {}
    for rel, text in mapping.items():
        p = base_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(textwrap.dedent(text).lstrip())
        paths[rel] = p
    return paths


# ---------------------------------------------------------------------------
# Slurm / shared-filesystem helpers
# ---------------------------------------------------------------------------


def _shared_filesystem_tmpdir_parent():
    """Return a directory on a shared filesystem suitable for Slurm temp dirs.

    Slurm submits compile jobs to remote nodes, so temp dirs must be on a
    shared filesystem (GPFS/NFS/Lustre) rather than node-local scratch.

    Uses the compiletools git root's parent directory (which is on GPFS
    when running from the standard worktree layout).
    """
    this_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        git_root = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            text=True,
            cwd=this_dir,
        ).strip()
        return os.path.dirname(git_root)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return os.path.dirname(this_dir)


@contextlib.contextmanager
def shared_filesystem_tmpdir(backend_name, fallback_path):
    """Provide a temp directory on a shared filesystem for distributed backends, or fallback_path for others.

    Backends like Slurm dispatch compile jobs to remote nodes that need
    access to the same files, so the temp directory must be on a shared
    filesystem (GPFS, NFS, Lustre, etc.) rather than node-local scratch.

    Yields a path string to use as the effective temp directory.
    """
    if backend_name == "slurm":
        with TempDirContextNoChange(dir=_shared_filesystem_tmpdir_parent()) as tmpdir:
            yield tmpdir
    else:
        yield str(fallback_path)


# ---------------------------------------------------------------------------
# Backend test helpers
# ---------------------------------------------------------------------------


def make_stub_backend_class():
    """Create a concrete BuildBackend subclass for unit testing."""
    from compiletools.build_backend import BuildBackend

    class StubBackend(BuildBackend):
        def generate(self, graph, output=None):
            self.last_graph = graph

        def execute(self, target="build"):
            pass

        def _execute_build(self, target: str) -> None:
            pass

        @staticmethod
        def name():
            return "stub_test"

        @staticmethod
        def build_filename():
            return "Stubfile"

    return StubBackend


def make_backend_args(tmpdir, **overrides):
    """Create a SimpleNamespace with standard backend args rooted in tmpdir.

    Mirrors ``apptools.parseargs`` by populating the raw flag strings
    (CPPFLAGS / CFLAGS / CXXFLAGS / LDFLAGS), their pre-tokenized
    siblings (``*_tokens``), and the structured ``args.flags`` view
    (``Flags`` from ``compiletools.flags``, populated at parseargs end
    by TOKEN-5). Production code that consumes ``args.flags.cxx`` etc.
    (build_backend compile commands, magicflags._parse) thus works
    without re-tokenizing in the test fixtures.
    """
    defaults = dict(
        filename=[],
        tests=[],
        static=[],
        dynamic=[],
        verbose=0,
        cas_objdir=os.path.join(tmpdir, "obj"),
        cas_exedir=os.path.join(tmpdir, "cas-exe"),
        bindir=os.path.join(tmpdir, "bin"),
        git_root="",
        CC="gcc",
        CXX="g++",
        CPPFLAGS="",
        CFLAGS="-O2",
        CXXFLAGS="-O2",
        LD="g++",
        LDFLAGS="",
        cas_pchdir=os.path.join(tmpdir, "pch"),
        file_locking=False,
        serialisetests=False,
        build_only_changed=None,
        diagnostics_dir=None,
        use_mtime=False,
        makefilename="Makefile",
        parallel=1,
        shuffle=False,
    )
    defaults.update(overrides)
    args = SimpleNamespace(**defaults)
    finalize_flag_state(args)
    return args


def finalize_flag_state(args) -> None:
    """Test-side wrapper for ``apptools._finalize_flag_state``.

    Use after ``cap.parse_args`` or after constructing a SimpleNamespace
    by hand, when the test then drives code that reads
    ``args.{*}_tokens`` or ``args.flags`` (Hunter, MagicFlags, build
    backends). Production code never needs this -- ``parseargs``
    already calls the underlying helper.
    """
    compiletools.apptools._finalize_flag_state(args)


def add_backend_arguments(cap):
    """Add the argparse surface needed to drive Hunter + backend.build_graph()
    from real ``argv``. Backend classes are imported lazily so this helper
    does not pull them into the testhelper import graph.
    """
    # ``from ... import name`` (not ``import compiletools.X``) so the local
    # binding is on ``hunter``/``namer``/``jobs`` directly, not on
    # ``compiletools`` — the latter would shadow the module-level
    # ``import compiletools.apptools`` for the rest of the function scope
    # and make pyright lose ``apptools``.
    from compiletools import hunter as _hunter
    from compiletools import jobs as _jobs
    from compiletools import namer as _namer
    from compiletools.makefile_backend import MakefileBackend
    from compiletools.trace_backend import SlurmBackend

    compiletools.apptools.add_target_arguments_ex(cap)
    compiletools.apptools.add_link_arguments(cap)
    _namer.Namer.add_arguments(cap)
    _hunter.add_arguments(cap)
    _jobs.add_arguments(cap)
    MakefileBackend.add_arguments(cap)
    SlurmBackend.add_arguments(cap)


def build_real_backend(backend_cls, tmp_path, sources, *, tests=None, extra_argv=None):
    """Construct a backend instance + BuildGraph from real ``argv``.

    Drives the full apptools -> headerdeps -> magicflags -> Hunter pipeline so
    callers get a backend wired to real dependency analysis (not mocks).
    *sources* and *tests* are path-likes; *tests* are passed via ``--tests``.
    Returns ``(backend, graph)``.
    """
    from compiletools import headerdeps as _headerdeps
    from compiletools import hunter as _hunter
    from compiletools import magicflags as _magicflags
    from compiletools.build_context import BuildContext

    objdir = os.path.join(str(tmp_path), "obj")
    bindir = os.path.join(str(tmp_path), "bin")
    argv = list(extra_argv or [])
    argv += ["--include", str(tmp_path), "--cas-objdir", objdir, "--bindir", bindir]
    if tests:
        # --tests is nargs="*": one flag carrying all values. A repeated
        # --tests=... flag would let only the last value survive.
        argv.append("--tests")
        argv += [str(t) for t in tests]
    argv += [str(s) for s in sources]

    with ParserContext():
        cap = compiletools.apptools.create_parser(f"{backend_cls.name()} real backend", argv=argv)
        add_backend_arguments(cap)
        ctx = BuildContext()
        args = compiletools.apptools.parseargs(cap, argv, context=ctx)
        headerdeps = _headerdeps.create(args, context=ctx)
        magicparser = _magicflags.create(args, headerdeps, context=ctx)
        hunter = _hunter.Hunter(args, headerdeps, magicparser, context=ctx)
        backend = backend_cls(args=args, hunter=hunter, context=ctx)
        graph = backend.build_graph()
    return backend, graph


def find_result_markers(tmp_path):
    """Return every ``.result`` test-success marker under *tmp_path*."""
    return [os.path.join(dp, fn) for dp, _, files in os.walk(str(tmp_path)) for fn in files if fn.endswith(".result")]


# A gtest-flavoured test fixture that writes its JUnit XML report when handed
# ``--gtest_output=xml:PATH`` and *then* exits non-zero. The write-then-fail
# ordering is what makes a backend's delete-output-on-failure behaviour
# observable.
_FAILING_GTEST_FIXTURE_SRC = (
    '#include "unit_test.hpp"\n'
    '#include "gtest/gtest.h"\n'
    "#include <cstdio>\n"
    "#include <cstring>\n"
    "int main(int argc, char** argv) {\n"
    '    static const char prefix[] = "--gtest_output=xml:";\n'
    "    const size_t plen = sizeof(prefix) - 1;\n"
    "    for (int i = 1; i < argc; ++i) {\n"
    "        if (std::strncmp(argv[i], prefix, plen) == 0) {\n"
    '            FILE* f = std::fopen(argv[i] + plen, "w");\n'
    "            if (f != nullptr) {\n"
    '                std::fputs("<testsuites>\\n", f);\n'
    '                std::fputs("  <testsuite name=\\"stub\\" tests=\\"1\\" failures=\\"1\\"/>\\n", f);\n'
    '                std::fputs("</testsuites>\\n", f);\n'
    "                std::fclose(f);\n"
    "            }\n"
    "        }\n"
    "    }\n"
    "    return 1;\n"
    "}\n"
)


def write_failing_gtest_fixture(tmp_path):
    """Write a deliberately-failing gtest test fixture into *tmp_path*.

    Framework detection trips on the ``gtest/gtest.h`` include-path token in
    the transitive header set (not on any symbol), so an empty stub header is
    sufficient. Also writes a ``unit_test.hpp`` stub so the file is recognised
    as a test target. Returns the test source ``Path``.
    """
    (tmp_path / "unit_test.hpp").write_text("#pragma once\n")
    (tmp_path / "gtest").mkdir(exist_ok=True)
    (tmp_path / "gtest" / "gtest.h").write_text("#pragma once\n")
    test_src = tmp_path / "test_fail_gtest.cpp"
    test_src.write_text(_FAILING_GTEST_FIXTURE_SRC)
    return test_src


def make_mock_hunter(sources=None, headers=None, magicflags_map=None, per_file_magicflags=None):
    """Create a MagicMock hunter with standard behavior.

    Args:
        sources: List of source files.
        headers: List of header files.
        magicflags_map: Single magicflags dict returned for all files.
        per_file_magicflags: Dict mapping source_path -> magicflags_dict.
            When provided, overrides magicflags_map.
    """
    hunter = MagicMock()
    hunter.huntsource = MagicMock()
    sources = sources or []
    hunter.getsources = MagicMock(return_value=sources)
    hunter.required_source_files = MagicMock(side_effect=lambda s: sources)
    headers = headers or []
    hunter.header_dependencies = MagicMock(return_value=headers)
    if per_file_magicflags is not None:
        hunter.magicflags = MagicMock(side_effect=lambda s: per_file_magicflags.get(s, {}))
    else:
        hunter.magicflags = MagicMock(return_value=magicflags_map or {})
    hunter.macro_state_hash = MagicMock(return_value="abcdef1234567890")
    # Real BuildContext so backend code that reaches into hunter.context
    # (e.g. for global_hash_registry lookups) gets a usable object rather
    # than an auto-attribute MagicMock that silently returns mocks for
    # every attribute and breaks JSON-serializing consumers.
    from compiletools.build_context import BuildContext

    hunter.context = BuildContext()
    # Real frozenset for cmdline_origin so build_backend's
    # _pch_scope_macro_hash can early-return without falling into a
    # MagicMock auto-attribute trap. Tests that need a non-empty
    # origin set should override this attribute explicitly.
    hunter.magicparser._initial_macro_state.cmdline_origin = frozenset()
    return hunter


def make_mock_namer(args):
    """Create a MagicMock namer deriving paths from args.cas_objdir/bindir.

    Mirrors the production sharded layout: ``object_pathname`` returns
    ``<objdir>/<bucket>/<basename>.o`` where ``bucket`` is a deterministic
    2-hex prefix of ``sha256(filename)``. The hash function differs from
    production (which keys on the per-source content hash via the global
    registry), but the on-disk shape is identical so build-graph tests
    exercise the same mkdir / order_only_deps wiring.
    """
    import hashlib

    objdir = args.cas_objdir
    bindir = args.bindir
    namer = MagicMock()

    def _bucket(filename):
        return hashlib.sha256(filename.encode()).hexdigest()[:2]

    def _object_pathname(filename, _macro_hash, _dep_hash):
        bucket = _bucket(filename)
        basename = filename.split("/")[-1].replace(".cpp", ".o")
        return f"{objdir}/{bucket}/{basename}"

    def _object_dir(sourcefilename=None, file_hash=None):
        if file_hash is not None:
            return f"{objdir}/{file_hash[:2]}"
        return objdir

    cas_exedir = getattr(args, "cas_exedir", f"{bindir}/exe")

    def _cas_exe_dir(link_key_hash=None):
        if link_key_hash is not None:
            return f"{cas_exedir}/{link_key_hash[:2]}"
        return cas_exedir

    def _cas_exe_pathname(filename, link_key_hash):
        basename = filename.split("/")[-1].replace(".cpp", "")
        return f"{cas_exedir}/{link_key_hash[:2]}/{basename}_{link_key_hash}.exe"

    def _staticlib_basename(filename):
        # Mirror namer.staticlibrary_name: lib<stem>.a
        return "lib" + filename.split("/")[-1].rsplit(".", 1)[0] + ".a"

    def _dynamiclib_basename(filename):
        return "lib" + filename.split("/")[-1].rsplit(".", 1)[0] + ".so"

    def _cas_staticlibrary_pathname(filename, lib_key_hash):
        return f"{cas_exedir}/{lib_key_hash[:2]}/{_staticlib_basename(filename)[:-2]}_{lib_key_hash}.a"

    def _cas_dynamiclibrary_pathname(filename, lib_key_hash):
        return f"{cas_exedir}/{lib_key_hash[:2]}/{_dynamiclib_basename(filename)[:-3]}_{lib_key_hash}.so"

    namer.object_pathname = MagicMock(side_effect=_object_pathname)
    namer.object_dir = MagicMock(side_effect=_object_dir)
    namer.executable_pathname = MagicMock(side_effect=lambda f: f"{bindir}/{f.split('/')[-1].replace('.cpp', '')}")
    namer.cas_exe_dir = MagicMock(side_effect=_cas_exe_dir)
    namer.cas_exe_pathname = MagicMock(side_effect=_cas_exe_pathname)
    # Production ``staticlibrary_pathname`` / ``dynamiclibrary_pathname`` take
    # an optional ``sourcefilename`` arg and derive the basename from it; the
    # mocks accept and ignore the arg so callers from build_backend.py work
    # without per-test wiring.
    namer.staticlibrary_pathname = MagicMock(side_effect=lambda f=None: f"{bindir}/libmylib.a")
    namer.dynamiclibrary_pathname = MagicMock(side_effect=lambda f=None: f"{bindir}/libmylib.so")
    namer.cas_staticlibrary_pathname = MagicMock(side_effect=_cas_staticlibrary_pathname)
    namer.cas_dynamiclibrary_pathname = MagicMock(side_effect=_cas_dynamiclibrary_pathname)
    namer.compute_dep_hash = MagicMock(return_value="dep_hash_12345")
    namer.executable_dir = MagicMock(return_value=bindir)
    return namer


def fake_subprocess_result(returncode=0, stdout="", stderr=""):
    """Real CompletedProcess instead of MagicMock."""
    return subprocess.CompletedProcess([], returncode, stdout, stderr)


@contextlib.contextmanager
def BackendTestContext(**arg_overrides):
    """Context manager yielding (backend, args, tmpdir) with a stub backend.

    Creates a temp directory, builds args and mock hunter/namer, and wires
    up a stub BuildBackend ready for build_graph() calls.

    Usage::

        with BackendTestContext(filename=["/src/main.cpp"]) as (backend, args, tmpdir):
            graph = backend.build_graph()
            ...
    """
    with TempDirContextNoChange() as tmpdir:
        args = make_backend_args(tmpdir, **arg_overrides)
        hunter = make_mock_hunter(
            sources=args.filename or [],
            headers=[],
        )
        StubClass = make_stub_backend_class()
        backend = StubClass(args=args, hunter=hunter)
        backend.namer = make_mock_namer(args)
        yield backend, args, tmpdir


@contextlib.contextmanager
def ShakeBackendTestContext(graph, **arg_overrides):
    """Context manager yielding (backend, tmpdir) with a ShakeBackend wired to a graph.

    Usage::

        with ShakeBackendTestContext(graph) as (backend, tmpdir):
            backend.execute("build")
    """
    from compiletools.trace_backend import ShakeBackend

    with TempDirContextNoChange() as tmpdir:
        args = make_backend_args(tmpdir, **arg_overrides)
        # Run the real __init__ (with a mock hunter) rather than hand-replicating
        # a subset of init state: every future __init__ attribute would otherwise
        # be a silent landmine for tests that drive _build_async/_execute_rule
        # directly. Only _graph is overridden afterwards, since the test supplies
        # its own pre-built graph instead of going through generate().
        backend = ShakeBackend(args=args, hunter=make_mock_hunter())
        backend._graph = graph
        yield backend, tmpdir


@contextlib.contextmanager
def CakeTestContext(backend_name="make", **arg_overrides):
    """Context manager yielding (cake, tmpdir) with mocked internals.

    Usage::

        with CakeTestContext("ninja", tests=["test.cpp"]) as (cake, tmpdir):
            cake.process()
    """
    from compiletools.build_backend import ensure_backends_registered
    from compiletools.cake import Cake

    ensure_backends_registered()

    with TempDirContextNoChange() as tmpdir:
        # Cake needs extra fields beyond the basic backend args
        cake_defaults = dict(
            backend=backend_name,
            auto=False,
            filelist=False,
            clean=False,
            realclean=False,
            output=None,
            compilation_database=False,
            makefilename="Makefile",
        )
        cake_defaults.update(arg_overrides)
        args = make_backend_args(tmpdir, **cake_defaults)
        cake = Cake(args)
        cake._createctobjs = MagicMock()
        cake._call_compilation_database = MagicMock()
        cake._copyexes = MagicMock()
        namer = MagicMock()
        namer.executable_dir.return_value = os.path.join(tmpdir, "exe")
        namer.topbindir.return_value = os.path.join(tmpdir, "topbin")
        cake.namer = namer
        # MagicMock is the unittest.mock stdlib idiom; unrelated to compiletools.magicflags.MagicFlags.
        cake.headerdeps = MagicMock()
        cake.magicparser = MagicMock()
        cake.hunter = MagicMock()
        yield cake, tmpdir
