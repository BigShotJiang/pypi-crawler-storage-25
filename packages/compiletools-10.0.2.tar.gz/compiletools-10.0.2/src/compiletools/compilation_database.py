import json
import os
from typing import Any, Optional

import stringzilla as sz

import compiletools.apptools
import compiletools.filesystem_utils
import compiletools.findtargets
import compiletools.headerdeps
import compiletools.hunter
import compiletools.magicflags
import compiletools.namer
import compiletools.utils
import compiletools.wrappedos
from compiletools.locking import FileLock


class CompilationDatabaseCreator:
    """Creates compile_commands.json files for clang tooling integration"""

    def __init__(self, args, namer=None, headerdeps=None, magicparser=None, hunter=None, *, context):
        self.args = args
        self.context = context

        # Use provided objects or create new ones
        self.namer = namer if namer is not None else compiletools.namer.Namer(args, context=context)
        self.headerdeps = (
            headerdeps if headerdeps is not None else compiletools.headerdeps.create(args, context=context)
        )
        self.magicparser = (
            magicparser
            if magicparser is not None
            else compiletools.magicflags.create(args, self.headerdeps, context=context)
        )
        self.hunter = (
            hunter
            if hunter is not None
            else compiletools.hunter.Hunter(args, self.headerdeps, self.magicparser, context=context)
        )

    @staticmethod
    def add_arguments(cap):
        """Add command-line arguments for standalone ct-compilation-database.

        Safe to call more than once on the same parser.
        """
        if compiletools.apptools._parser_has_option(cap, "--compilation-database-output"):
            return
        # Add standard target arguments that define what sources to process
        compiletools.apptools.add_target_arguments_ex(cap)

        cap.add_argument(
            "--compilation-database-output",
            dest="compilation_database_output",
            default=None,
            help="Output filename for compilation database (default: <gitroot>/compile_commands.json)",
        )

        cap.add_argument(
            "--relative-paths",
            dest="compilation_database_relative",
            action="store_true",
            help="Use relative paths instead of absolute paths",
        )

        compiletools.apptools.add_locking_arguments(cap)

    def _get_compiler_command(self, source_file: str) -> list[str]:
        """Generate compiler command arguments for a source file with StringZilla optimization"""

        # Determine compiler based on file extension
        if compiletools.utils.is_cpp_source(source_file):
            compiler = self.args.CXX
        else:
            compiler = self.args.CC

        # Build arguments list - properly split compiler command if it contains multiple tokens
        args = []
        if compiler:
            # Split compiler command (e.g., "ccache g++" -> ["ccache", "g++"])
            compiler_parts = compiletools.utils.split_command_cached(compiler)
            args.extend(compiler_parts)
        else:
            # If no compiler is set, we can't generate a valid command
            return []

        # Get magic flags for this specific file
        # Use Hunter's cached results (populated during huntsource)
        try:
            magic_flags = self.hunter.magicflags(source_file)
        except Exception as e:
            # Magic flags parsing may fail for various reasons
            if self.args.verbose >= 2:
                print(f"Warning: Could not parse magic flags for {source_file}: {e}")
            magic_flags = {}

        # Combine and deduplicate all flag sources
        if compiletools.utils.is_cpp_source(source_file):
            # C++ source: combine CPPFLAGS + CXXFLAGS from both args and magic flags
            combined_flags = compiletools.utils.combine_and_deduplicate_compiler_flags(
                getattr(self.args, "CPPFLAGS", None),
                magic_flags.get(sz.Str("CPPFLAGS"), []),
                getattr(self.args, "CXXFLAGS", None),
                magic_flags.get(sz.Str("CXXFLAGS"), []),
            )
        else:
            # C source: combine CPPFLAGS + CFLAGS from both args and magic flags
            combined_flags = compiletools.utils.combine_and_deduplicate_compiler_flags(
                getattr(self.args, "CPPFLAGS", None),
                magic_flags.get(sz.Str("CPPFLAGS"), []),
                getattr(self.args, "CFLAGS", None),
                magic_flags.get(sz.Str("CFLAGS"), []),
            )

        args.extend(combined_flags)

        # C++20 modules: TUs that participate in the module graph need
        # the compiler's modules-mode flag in the CDB so clangd /
        # clang-tidy / IDEs resolve `import M;` and `import <h>;` lookups.
        # Without this they report module imports as undefined. Per-
        # partition `.pcm` mappings and gcc's mapper file require the
        # full backend pre-pass and are intentionally omitted; consumers
        # that need them should run the build to populate the cache.
        args.extend(self._module_kind_flags(source_file))

        # Add compile-only flag
        args.extend(["-c"])

        # Add the source file
        if self.args.compilation_database_relative:
            args.append(os.path.relpath(source_file, os.getcwd()))
        else:
            args.append(compiletools.wrappedos.realpath(source_file))

        return args

    def _module_kind_flags(self, source_file: str) -> list[str]:
        """Per-TU C++20 modules flags for the detected compiler.

        Mirrors the user-visible slice of
        ``BuildBackend._compiler_module_flags_for``: just the umbrella
        flags that make a TU known to the compiler as a module
        participant. Per-partition ``-fmodule-file=`` mappings and
        gcc's ``-fmodule-mapper=`` require populating the build's
        module-interface registry, which is a side effect of the
        backend pre-pass — outside the CDB's scope. The umbrella
        flags alone are enough for clangd / clang-tidy to switch on
        modules-aware indexing.
        """
        try:
            result = self.hunter._file_analysis_result(source_file)
        except Exception:
            return []
        if result is None:
            return []
        if not (
            result.module_exports or result.module_implements or result.module_imports or result.module_header_imports
        ):
            return []
        kind = compiletools.apptools.compiler_kind(self.args.CXX)
        if kind == "gcc":
            return ["-fmodules-ts"]
        if kind == "clang":
            extras: list[str] = []
            if result.module_header_imports:
                extras.append("-fmodules")
            if "std" in result.module_imports:
                extras.append("-stdlib=libc++")
            return extras
        return []

    def _create_command_object(self, source_file: str) -> dict[str, Any] | None:
        """Create a single command object for the compilation database"""

        # Directory is always absolute (working directory)
        directory = compiletools.wrappedos.realpath(os.getcwd())

        # Get file path - relative or absolute based on option
        if self.args.compilation_database_relative:
            file_path = os.path.relpath(source_file, os.getcwd())
        else:
            file_path = compiletools.wrappedos.realpath(source_file)

        # Generate arguments
        arguments = self._get_compiler_command(source_file)

        # Skip files with empty arguments arrays - they provide no compile context
        if not arguments:
            return None

        return {"directory": directory, "file": file_path, "arguments": arguments}

    def create_compilation_database(self) -> list[dict[str, Any]]:
        """Create the compilation database as a list of command objects"""

        commands = []

        # Discover all source files using Hunter's project-level discovery
        try:
            # Hunt for all source files from command line arguments and dependencies
            self.hunter.huntsource()
            source_files = self.hunter.getsources()

            if self.args.verbose >= 6:
                print(f"CompilationDatabase: Processing {len(source_files)} source files")

        except Exception as e:
            if self.args.verbose:
                print(f"Warning: Error during source hunting: {e}")
            source_files = []

        # Process each source file
        for source_file in source_files:
            if os.path.exists(source_file):
                command_obj = self._create_command_object(source_file)
                if command_obj is not None:
                    commands.append(command_obj)
                elif self.args.verbose >= 2:
                    print(f"Warning: Skipping source file with empty arguments: {source_file}")
            elif self.args.verbose >= 2:
                print(f"Warning: Source file does not exist: {source_file}")

        return commands

    def write_compilation_database(self, output_file: Optional[str] = None):
        """Write the compilation database to file with incremental update support"""

        if output_file is None:
            output_file = self.namer.compilation_database_pathname()

        # Create new commands OUTSIDE lock - this is expensive (source hunting, parsing)
        # Only need lock for the actual read-merge-write operation
        new_commands = self.create_compilation_database()

        # Use same --file-locking flag as makefile.py
        # FileLock is no-op if args.file_locking is False
        # Lock held only for quick read-merge-write to minimize blocking
        with FileLock(output_file, self.args):
            self._write_database_impl(output_file, new_commands)

        # After a successful per-variant write, retarget the bare
        # compile_commands.json symlink that clangd / clang-tidy / IDEs open.
        # Skipped when the user pinned an explicit --compilation-database-output.
        symlink_path = self.namer.compilation_database_symlink_pathname()
        if symlink_path is not None and symlink_path != output_file:
            self._update_symlink(symlink_path, output_file)

    def _update_symlink(self, symlink_path: str, target_path: str):
        """Atomically point symlink_path at target_path using a relative target.

        Relative targets keep the link valid if the tree is moved or rsync'd.
        os.replace handles the symlink->symlink swap atomically; if a regular
        file (or directory) is sitting at symlink_path from a pre-upgrade
        install, we replace it — the file is regenerated on every build, so
        no user data is lost.
        """
        link_dir = compiletools.wrappedos.dirname(symlink_path)
        try:
            relative_target = os.path.relpath(target_path, link_dir)
        except ValueError:
            # Different drives on Windows — fall back to absolute target.
            relative_target = target_path

        # Skip the replace when the existing symlink already points at the
        # same target. os.symlink + os.replace creates a fresh inode and
        # advances mtime even on a target-identical update; clangd and other
        # IDE indexers re-stat the symlink on every build and treat any
        # mtime change as an invalidation. Compare the *literal* readlink
        # target — not os.path.realpath — because the target itself may be
        # a symlink chain whose resolution differs from its declared name.
        try:
            current_target = os.readlink(symlink_path)
            if current_target == relative_target:
                if self.args.verbose:
                    print(f"Symlink {symlink_path} already points to {relative_target}; skipping update")
                return
        except OSError:
            # Path doesn't exist, or isn't a symlink — fall through to the
            # normal replace path (preserves the regular-file replacement
            # behavior for stale pre-upgrade installs).
            pass

        # Build a unique tmp name in the same directory so os.replace is atomic.
        tmp_path = f"{symlink_path}.tmp.{os.getpid()}"
        try:
            try:
                os.unlink(tmp_path)
            except FileNotFoundError:
                pass
            os.symlink(relative_target, tmp_path)
            try:
                os.replace(tmp_path, symlink_path)
            except IsADirectoryError:
                # symlink_path is a real directory we shouldn't clobber.
                os.unlink(tmp_path)
                if self.args.verbose:
                    print(f"Warning: {symlink_path} is a directory; refusing to replace with symlink")
                return
            if self.args.verbose:
                print(f"Updated symlink {symlink_path} -> {relative_target}")
        except OSError as e:
            # Best-effort: filesystems without symlink support shouldn't break the build.
            if self.args.verbose:
                print(f"Warning: could not update symlink {symlink_path}: {e}")
            try:
                os.unlink(tmp_path)
            except FileNotFoundError:
                pass

    def _write_database_impl(self, output_file: str, new_commands: list[dict[str, Any]]):
        """Implementation of database write (extracted for locking)

        Args:
            output_file: Path to compile_commands.json
            new_commands: Pre-computed command objects (created outside lock)
        """
        # For incremental updates: read existing database and merge
        existing_commands = []
        if os.path.exists(output_file):
            try:
                # Use filesystem-safe reading (mmap on local, regular I/O on network filesystems)
                # No need for respect_locks since we're already inside FileLock context
                content_str = compiletools.filesystem_utils.safe_read_text_file(output_file, encoding="utf-8")
                if len(content_str) > 0:
                    existing_commands = json.loads(str(content_str))
                    if self.args.verbose:
                        print(f"Loaded existing compilation database: {len(existing_commands)} entries")
                else:
                    existing_commands = []
            except Exception as e:
                if self.args.verbose:
                    print(f"Warning: Could not read existing compilation database: {e}")
                existing_commands = []

        # Merge: keep existing entries for files we're not updating. CDB merges
        # are infrequent and I/O-bound on the JSON write below, so a plain str
        # path through os.path.realpath is the right tool — no StringZilla wrap
        # / unwrap roundtrip.
        new_files_normalized = {compiletools.wrappedos.realpath(cmd["file"]) for cmd in new_commands}

        merged_commands = []
        for existing_cmd in existing_commands:
            existing_file = existing_cmd["file"]
            # Resolve relative paths against their "directory" context, not cwd.
            if not os.path.isabs(existing_file):
                base_dir = existing_cmd.get("directory", os.getcwd())
                existing_file = os.path.join(base_dir, existing_file)
            if compiletools.wrappedos.realpath(existing_file) not in new_files_normalized:
                merged_commands.append(existing_cmd)

        # Add all new/updated entries
        merged_commands.extend(new_commands)

        # Write merged JSON file
        try:
            # Ensure the output directory exists
            output_dir = compiletools.wrappedos.dirname(output_file)
            if output_dir and not compiletools.wrappedos.isdir(output_dir):
                os.makedirs(output_dir, exist_ok=True)

            json_content = json.dumps(merged_commands, indent=2, ensure_ascii=False)

            # Skip the write entirely when the rendered JSON matches what is
            # already on disk. atomic_write_if_changed reads, compares, and
            # either skips or atomically replaces — preserves inode/mtime for
            # clangd consumers when unchanged. We are inside the FileLock the
            # caller acquired, so the read is race-free against peer writers.
            wrote = compiletools.filesystem_utils.atomic_write_if_changed(output_file, json_content)
            if not wrote and self.args.verbose:
                print(
                    f"Compilation database unchanged ({len(merged_commands)} entries); skipping write of {output_file}"
                )
            elif wrote and self.args.verbose:
                print(f"Written compilation database with {len(merged_commands)} entries to {output_file}")
                print(f"  Updated: {len(new_commands)} entries")
                print(f"  Preserved: {len(merged_commands) - len(new_commands)} entries")

        except Exception as e:
            print(f"Error writing compilation database: {e}")
            raise


def main(argv=None):
    """Main entry point for ct-compilation-database"""

    cap = compiletools.apptools.create_parser("Generate compile_commands.json for clang tooling", argv=argv)

    # Add compilation database specific arguments
    CompilationDatabaseCreator.add_arguments(cap)

    # Add standard compiletools arguments
    compiletools.hunter.add_arguments(cap)

    # Add findtargets arguments to support --auto mode
    compiletools.findtargets.add_arguments(cap)

    from compiletools.build_context import BuildContext

    context = BuildContext()

    # Parse arguments
    args = compiletools.apptools.parseargs(cap, argv, context=context)

    # Handle --auto mode: discover targets if no explicit targets provided
    if args.auto and not any([args.filename, args.static, args.dynamic, args.tests]):
        if args.verbose >= 2:
            print("Auto-detecting targets...")
        findtargets = compiletools.findtargets.FindTargets(args, context=context)
        findtargets.process(args)
        # Re-run substitutions after targets are discovered
        compiletools.apptools.substitutions(args, verbose=0)

    # Create and run the compilation database creator
    creator = CompilationDatabaseCreator(args, context=context)
    creator.write_compilation_database()

    return 0
