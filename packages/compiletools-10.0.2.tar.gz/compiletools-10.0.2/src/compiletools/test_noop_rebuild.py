"""Integration test: back-to-back build with no source changes must not
compile or link.

Verifies that the shake backend's content-addressable cache and trace
system correctly short-circuit both compile and link steps on a repeat
build.  This catches regressions like non-deterministic link command
ordering (which defeats the CA cache and forces a re-link every time).

The two builds run in separate subprocesses with different PYTHONHASHSEED
values so that any ordering that depends on set/dict hash randomization
will differ between runs — exactly the scenario that caused the original
bug.
"""

import json
import os
import subprocess
import sys
import textwrap

import compiletools.testhelper as uth

# Source files for a multi-file build.  Multiple translation units are
# needed so that set iteration order can vary between PYTHONHASHSEED
# values.  With a single .cpp file there is nothing to reorder.
_SOURCES = {
    "main.cpp": textwrap.dedent("""\
        #include "alpha.H"
        #include "bravo.H"
        #include "charlie.H"
        int main() { return alpha() + bravo() + charlie(); }
    """),
    "alpha.H": "#pragma once\nint alpha();\n",
    "alpha.cpp": '#include "alpha.H"\nint alpha() { return 0; }\n',
    "bravo.H": "#pragma once\nint bravo();\n",
    "bravo.cpp": '#include "bravo.H"\nint bravo() { return 0; }\n',
    "charlie.H": "#pragma once\nint charlie();\n",
    "charlie.cpp": '#include "charlie.H"\nint charlie() { return 0; }\n',
}

# Self-contained build script executed in a subprocess.
# Writes each source file, builds with the shake backend, counts
# subprocess.run calls made by trace_backend, writes JSON report.
_BUILD_SCRIPT = textwrap.dedent("""\
    import json
    import os
    import subprocess
    import sys
    from unittest import mock

    import compiletools.apptools
    import compiletools.headerdeps
    import compiletools.hunter
    import compiletools.magicflags
    import compiletools.testhelper as uth
    import compiletools.trace_backend  # ensure registered
    from compiletools.build_backend import get_backend_class
    from compiletools.build_context import BuildContext

    tmp_path = sys.argv[1]
    report_path = sys.argv[2]
    # sys.argv[3:] = capped_parallel_argv from the parent (no-op outside
    # pytest-xdist) followed by the four --cas-*dir argv pairs from the
    # parent's isolated_cas_dirs context manager. Passed through verbatim
    # so the subprocess shares the parent's cas roots (and the parent
    # cleans them up on exit).
    extra_argv = sys.argv[3:]

    source_path = os.path.realpath(os.path.join(tmp_path, "main.cpp"))
    bindir = os.path.join(tmp_path, "bin")
    argv = extra_argv + [
        "--include", tmp_path,
        "--bindir", bindir,
        source_path,
    ]

    uth.reset()
    cap = compiletools.apptools.create_parser("noop rebuild test", argv=argv)
    uth.add_backend_arguments(cap)

    ctx = BuildContext()
    args = compiletools.apptools.parseargs(cap, argv, context=ctx)
    headerdeps = compiletools.headerdeps.create(args, context=ctx)
    magicparser = compiletools.magicflags.create(args, headerdeps, context=ctx)
    hunter = compiletools.hunter.Hunter(args, headerdeps, magicparser, context=ctx)

    BackendClass = get_backend_class("shake")
    backend = BackendClass(args=args, hunter=hunter, context=ctx)
    graph = backend.build_graph()

    os.makedirs(bindir, exist_ok=True)
    backend.generate(graph)

    # Count all _run_with_signal_forwarding calls made during execute().
    # This is the new boundary that wraps both compile (atomic_compile) and
    # link (atomic_link) invocations.  On a no-op rebuild, the count should
    # be zero.
    import compiletools.locking
    call_count = 0
    orig_swf = compiletools.locking._run_with_signal_forwarding

    def counting_swf(cmd, *args, **kwargs):
        global call_count
        call_count += 1
        return orig_swf(cmd, *args, **kwargs)

    with mock.patch("compiletools.locking._run_with_signal_forwarding", side_effect=counting_swf):
        backend.execute("build")

    with open(report_path, "w") as f:
        json.dump({"subprocess_calls": call_count}, f)
""")


def _run_build(tmp_path, report_name, seed, cas_argv, capped_parallel_argv=()):
    """Run the build script in a subprocess with the given PYTHONHASHSEED.

    ``cas_argv`` is the four ``--cas-*dir`` argv pairs produced by
    ``uth.isolated_cas_dirs``; passed through to the subprocess so the
    subprocess's ct-cake call doesn't fall back to ``{git_root}/cas-*dir/``
    (which is the compiletools repo, since the subprocess inherits the
    parent's cwd).

    ``capped_parallel_argv`` is the conftest fixture's ``--parallel`` cap
    (no-op outside pytest-xdist) so the subprocess inherits the parent's
    parallelism cap.
    """
    import compiletools

    report_path = os.path.join(str(tmp_path), report_name)
    env = os.environ.copy()
    env["PYTHONHASHSEED"] = str(seed)
    # Pin the subprocess to *this* worktree's source — otherwise the
    # editable install's .pth file points at whichever worktree last
    # ran ``pip install -e .``, and the subprocess silently runs a
    # different version of the code than the parent pytest process.
    worktree_src = os.path.dirname(os.path.dirname(compiletools.__file__))
    env["PYTHONPATH"] = os.pathsep.join([worktree_src, env.get("PYTHONPATH", "")])
    cmd = [
        sys.executable,
        "-c",
        _BUILD_SCRIPT,
        str(tmp_path),
        report_path,
        *capped_parallel_argv,
        *cas_argv,
    ]
    result = subprocess.run(
        cmd,
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Build subprocess failed (seed={seed}, rc={result.returncode}):\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
    with open(report_path) as f:
        return json.load(f)


class TestNoopRebuild:
    """A back-to-back build with no source changes must not compile or link."""

    @uth.requires_functional_compiler
    def test_repeat_build_skips_compile_and_link(self, tmp_path, capped_parallel_argv):
        # Write multi-file source tree
        for name, content in _SOURCES.items():
            (tmp_path / name).write_text(content)

        with uth.isolated_cas_dirs(tmp_path) as cas_argv:
            # Build 1 (seed=42): real compilation — produces .o, executable, traces
            report1 = _run_build(
                tmp_path,
                "report1.json",
                seed=42,
                cas_argv=cas_argv,
                capped_parallel_argv=capped_parallel_argv,
            )
            assert report1["subprocess_calls"] >= 1, "First build should invoke the compiler"

            exe_path = os.path.join(str(tmp_path), "bin", "main")
            assert os.path.exists(exe_path), "First build did not produce executable"

            # Build 2 (seed=999): different hash seed, same source files on disk.
            # Nothing should compile or link.
            report2 = _run_build(
                tmp_path,
                "report2.json",
                seed=999,
                cas_argv=cas_argv,
                capped_parallel_argv=capped_parallel_argv,
            )
            assert report2["subprocess_calls"] == 0, (
                f"Expected zero compiler/linker calls on repeat build, got {report2['subprocess_calls']}"
            )
