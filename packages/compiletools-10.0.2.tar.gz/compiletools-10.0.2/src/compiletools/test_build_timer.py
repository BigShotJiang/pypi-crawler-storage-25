"""Tests for build_timer module."""

from __future__ import annotations

import threading
import time

import pytest

from compiletools.build_timer import BuildTimer, TimingEvent, _classify_output, _union_span

# ------------------------------------------------------------------ TimingEvent


class TestTimingEvent:
    def test_elapsed_with_end(self):
        ev = TimingEvent(name="x", category="compile", start_s=1.0, end_s=3.5)
        assert ev.elapsed_s == pytest.approx(2.5)

    def test_elapsed_without_end_uses_monotonic(self):
        ev = TimingEvent(name="x", category="compile", start_s=time.monotonic() - 1.0)
        assert ev.elapsed_s >= 1.0

    def test_to_dict_phase(self):
        ev = TimingEvent(name="build_graph", category="phase", start_s=0.0, end_s=1.5)
        d = ev.to_dict()
        assert d["name"] == "build_graph"
        assert d["elapsed_s"] == pytest.approx(1.5)
        assert "rule_type" not in d

    def test_to_dict_rule(self):
        ev = TimingEvent(
            name="foo.o",
            category="compile",
            start_s=0.0,
            end_s=2.0,
            target="obj/foo.o",
            source="src/foo.cpp",
        )
        d = ev.to_dict()
        assert d["rule_type"] == "compile"
        assert d["target"] == "obj/foo.o"
        assert d["source"] == "src/foo.cpp"
        assert d["start_s"] == pytest.approx(0.0)
        assert d["end_s"] == pytest.approx(2.0)

    def test_to_dict_with_children(self):
        child = TimingEvent(name="child", category="compile", start_s=0.0, end_s=1.0, target="a.o", source="a.cpp")
        parent = TimingEvent(name="build_execution", category="phase", start_s=0.0, end_s=2.0, children=[child])
        d = parent.to_dict()
        assert "rules" in d
        assert len(d["rules"]) == 1
        assert d["rules"][0]["name"] == "child"

    def test_roundtrip(self):
        ev = TimingEvent(
            name="foo.o",
            category="compile",
            start_s=1.0,
            end_s=3.0,
            target="obj/foo.o",
            source="src/foo.cpp",
            metadata={"weight": 5},
        )
        d = ev.to_dict()
        restored = TimingEvent.from_dict(d)
        assert restored.name == "foo.o"
        assert restored.category == "compile"
        assert restored.elapsed_s == pytest.approx(2.0)
        assert restored.target == "obj/foo.o"
        assert restored.source == "src/foo.cpp"


# ---------------------------------------------------------- BuildTimer disabled


class TestBuildTimerDisabled:
    def test_phase_is_noop(self):
        timer = BuildTimer(enabled=False)
        with timer.phase("test"):
            pass
        # Root should have no children
        assert len(timer._root.children) == 0

    def test_record_rule_is_noop(self):
        timer = BuildTimer(enabled=False)
        timer.record_rule("compile", "a.o", "a.cpp", 1.0)
        assert len(timer._root.children) == 0

    def test_to_dict_empty(self):
        timer = BuildTimer(enabled=False)
        d = timer.to_dict()
        assert d["version"] == 1
        assert d["phases"] == []

    def test_record_rules_from_ninja_log_noop(self, tmp_path):
        log = tmp_path / ".ninja_log"
        log.write_text("# ninja log v5\n0\t1000\t0\ta.o\thash\n")
        timer = BuildTimer(enabled=False)
        timer.record_rules_from_ninja_log(str(log))
        assert len(timer._root.children) == 0

    def test_record_rules_from_make_timing_noop(self, tmp_path):
        log = tmp_path / ".ct-make-timing.jsonl"
        log.write_text('{"target":"a.o","start_ns":0,"end_ns":1000000000}\n')
        timer = BuildTimer(enabled=False)
        timer.record_rules_from_make_timing(str(log))
        assert len(timer._root.children) == 0


# ----------------------------------------------------------- BuildTimer enabled


class TestBuildTimerEnabled:
    def test_phase_records_elapsed(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("test_phase"):
            time.sleep(0.01)
        assert len(timer._root.children) == 1
        phase = timer._root.children[0]
        assert phase.name == "test_phase"
        assert phase.category == "phase"
        assert phase.elapsed_s >= 0.01

    def test_nested_phases(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("outer"):
            with timer.phase("inner"):
                time.sleep(0.01)
        assert len(timer._root.children) == 1
        outer = timer._root.children[0]
        assert outer.name == "outer"
        assert len(outer.children) == 1
        inner = outer.children[0]
        assert inner.name == "inner"
        assert inner.elapsed_s >= 0.01

    def test_record_rule_adds_to_current_phase(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rule("compile", "a.o", "a.cpp", 1.5)
        phase = timer._root.children[0]
        assert len(phase.children) == 1
        rule = phase.children[0]
        assert rule.category == "compile"
        assert rule.target == "a.o"
        assert rule.source == "a.cpp"

    def test_record_rule_thread_safety(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            threads = []
            for i in range(20):
                t = threading.Thread(
                    target=timer.record_rule,
                    args=("compile", f"obj/{i}.o", f"src/{i}.cpp", 0.1 * i),
                )
                threads.append(t)
                t.start()
            for t in threads:
                t.join()
        phase = timer._root.children[0]
        assert len(phase.children) == 20

    def test_to_dict_structure(self):
        timer = BuildTimer(enabled=True, variant="gcc.debug", backend="ninja")
        with timer.phase("build_graph"):
            time.sleep(0.01)
        d = timer.to_dict()
        assert d["version"] == 1
        assert d["variant"] == "gcc.debug"
        assert d["backend"] == "ninja"
        assert d["total_elapsed_s"] > 0
        assert len(d["phases"]) == 1
        assert d["phases"][0]["name"] == "build_graph"

    def test_to_json_roundtrip(self, tmp_path):
        timer = BuildTimer(enabled=True, variant="gcc.debug", backend="make")
        with timer.phase("build_execution"):
            timer.record_rule("compile", "a.o", "a.cpp", 2.5, start_s=0.0, end_s=2.5)
            timer.record_rule("link", "app", "", 1.0, start_s=2.5, end_s=3.5)
        path = str(tmp_path / "timing.json")
        timer.to_json(path)

        loaded = BuildTimer.from_json(path)
        assert loaded.variant == "gcc.debug"
        assert loaded.backend == "make"
        assert len(loaded._root.children) == 1
        phase = loaded._root.children[0]
        assert phase.name == "build_execution"
        assert len(phase.children) == 2

    def test_from_dict_roundtrip(self):
        timer = BuildTimer(enabled=True, variant="clang.release", backend="ninja")
        with timer.phase("generate"):
            pass
        with timer.phase("build_execution"):
            timer.record_rule("compile", "x.o", "x.cpp", 3.0)

        d = timer.to_dict()
        restored = BuildTimer.from_dict(d)
        assert restored.variant == "clang.release"
        assert restored.backend == "ninja"
        d2 = restored.to_dict()
        assert len(d2["phases"]) == len(d["phases"])

    def test_finish_sets_end(self):
        timer = BuildTimer(enabled=True)
        assert timer._root.end_s is None
        timer.finish()
        assert timer._root.end_s is not None

    def test_finish_idempotent(self):
        timer = BuildTimer(enabled=True)
        timer.finish()
        end1 = timer._root.end_s
        timer.finish()
        assert timer._root.end_s == end1


# -------------------------------------------------------- ninja log parsing


class TestNinjaLogParsing:
    def _write_log(self, tmp_path, lines, header=True):
        log = tmp_path / ".ninja_log"
        content = ""
        if header:
            content = "# ninja log v5\n"
        content += "\n".join(lines) + "\n"
        log.write_text(content)
        return str(log)

    def test_parse_valid_log(self, tmp_path):
        log = self._write_log(
            tmp_path,
            [
                "0\t1500\t12345\tobj/foo.o\tabc123",
                "100\t2000\t12346\tobj/bar.o\tdef456",
            ],
        )
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_ninja_log(log)
        phase = timer._root.children[0]
        assert len(phase.children) == 2
        # Check first rule
        rules_by_target = {r.target: r for r in phase.children}
        foo = rules_by_target["obj/foo.o"]
        assert foo.elapsed_s == pytest.approx(1.5)
        assert foo.category == "compile"
        bar = rules_by_target["obj/bar.o"]
        assert bar.elapsed_s == pytest.approx(1.9)

    def test_parse_log_with_comments(self, tmp_path):
        log = self._write_log(
            tmp_path,
            [
                "# some comment",
                "0\t1000\t0\ta.o\thash",
            ],
        )
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_ninja_log(log)
        assert len(timer._root.children[0].children) == 1

    def test_parse_log_with_offset(self, tmp_path):
        log_path = tmp_path / ".ninja_log"
        old_content = "# ninja log v5\n0\t1000\t0\told.o\thash\n"
        new_content = "0\t2000\t0\tnew.o\thash\n"
        log_path.write_text(old_content + new_content)
        offset = len(old_content)

        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_ninja_log(str(log_path), offset=offset)
        phase = timer._root.children[0]
        assert len(phase.children) == 1
        assert phase.children[0].target == "new.o"

    def test_parse_empty_log(self, tmp_path):
        log = self._write_log(tmp_path, [])
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_ninja_log(log)
        assert len(timer._root.children[0].children) == 0

    def test_parse_duplicate_outputs_keeps_last(self, tmp_path):
        log = self._write_log(
            tmp_path,
            [
                "0\t1000\t0\tobj/foo.o\thash1",
                "1000\t3000\t0\tobj/foo.o\thash2",
            ],
        )
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_ninja_log(log)
        phase = timer._root.children[0]
        assert len(phase.children) == 1
        assert phase.children[0].elapsed_s == pytest.approx(2.0)

    def test_parse_nonexistent_log(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_ninja_log("/nonexistent/.ninja_log")
        assert len(timer._root.children[0].children) == 0

    def test_parse_with_graph_lookup(self, tmp_path):
        from compiletools.build_graph import BuildGraph, BuildRule

        graph = BuildGraph()
        graph.add_rule(
            BuildRule(
                output="obj/foo.o",
                inputs=["src/foo.cpp", "src/foo.h"],
                command=["g++", "-c", "src/foo.cpp", "-o", "obj/foo.o"],
                rule_type="compile",
            )
        )
        graph.add_rule(
            BuildRule(
                output="bin/app",
                inputs=["obj/foo.o"],
                command=["g++", "obj/foo.o", "-o", "bin/app"],
                rule_type="link",
            )
        )

        log = self._write_log(
            tmp_path,
            [
                "0\t5000\t0\tobj/foo.o\thash1",
                "5000\t6000\t0\tbin/app\thash2",
            ],
        )
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_ninja_log(log, graph=graph)
        phase = timer._root.children[0]
        rules = {r.target: r for r in phase.children}
        assert rules["obj/foo.o"].source == "src/foo.cpp"
        assert rules["obj/foo.o"].category == "compile"
        assert rules["bin/app"].category == "link"


# ------------------------------------------------------- make timing parsing


class TestMakeTimingParsing:
    def test_parse_valid_jsonl(self, tmp_path):
        log = tmp_path / ".ct-make-timing.jsonl"
        log.write_text(
            '{"target":"obj/foo.o","start_ns":1000000000,"end_ns":3500000000}\n'
            '{"target":"bin/app","start_ns":3500000000,"end_ns":4000000000}\n'
        )
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_make_timing(str(log))
        phase = timer._root.children[0]
        assert len(phase.children) == 2
        rules = {r.target: r for r in phase.children}
        assert rules["obj/foo.o"].elapsed_s == pytest.approx(2.5)
        assert rules["bin/app"].elapsed_s == pytest.approx(0.5)

    def test_parse_with_graph(self, tmp_path):
        from compiletools.build_graph import BuildGraph, BuildRule

        graph = BuildGraph()
        graph.add_rule(
            BuildRule(
                output="obj/foo.o",
                inputs=["src/foo.cpp"],
                command=["g++", "-c", "src/foo.cpp"],
                rule_type="compile",
            )
        )

        log = tmp_path / ".ct-make-timing.jsonl"
        log.write_text('{"target":"obj/foo.o","start_ns":0,"end_ns":2000000000}\n')
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_make_timing(str(log), graph=graph)
        rule = timer._root.children[0].children[0]
        assert rule.source == "src/foo.cpp"
        assert rule.category == "compile"

    def test_parse_invalid_json_skipped(self, tmp_path):
        log = tmp_path / ".ct-make-timing.jsonl"
        log.write_text('not json\n{"target":"a.o","start_ns":0,"end_ns":1000000000}\n')
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_make_timing(str(log))
        assert len(timer._root.children[0].children) == 1

    def test_parse_nonexistent_log(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rules_from_make_timing("/nonexistent/log.jsonl")
        assert len(timer._root.children[0].children) == 0

    def test_wall_to_monotonic_conversion(self, tmp_path):
        """Recipe wrappers write bash $EPOCHREALTIME (wall clock since
        1970, ~1.78e9 s in 2026), but in-Python record_rule callers use
        time.monotonic() (boot-relative, often ~10^6 s).  Without
        conversion the make-recorded rules end up ~1.78e9 s away from
        rules in the same trace, defeating any single-clock invariant.

        record_rules_from_make_timing must rebase wall-clock timestamps
        into the monotonic clock domain using the offset captured at
        BuildTimer init.  Record one rule via the make path and one
        via the in-Python path under the same phase, then assert their
        start_s values land within a few seconds of each other."""
        timer = BuildTimer(enabled=True)
        wall_ns = int(time.time() * 1_000_000_000)
        log = tmp_path / ".ct-make-timing.jsonl"
        log.write_text(f'{{"target":"obj/foo.o","start_ns":{wall_ns},"end_ns":{wall_ns + 100_000_000}}}\n')
        with timer.phase("build_execution"):
            timer.record_rules_from_make_timing(str(log))
            now = time.monotonic()
            timer.record_rule("compile", "obj/bar.o", "bar.cpp", 0.05, start_s=now, end_s=now + 0.05)

        phase = timer._root.children[0]
        make_rule = next(r for r in phase.children if r.target == "obj/foo.o")
        py_rule = next(r for r in phase.children if r.target == "obj/bar.o")
        # The make-recorded start_s must be on the monotonic clock,
        # not the wall clock — i.e. close to the in-Python rule's start_s.
        gap = abs(make_rule.start_s - py_rule.start_s)
        assert gap < 1.0, f"clocks not aligned: make={make_rule.start_s} python={py_rule.start_s} gap={gap}s"


# --------------------------------------------------------- chrome trace


class TestChromeTrace:
    def test_format(self):
        timer = BuildTimer(enabled=True, variant="gcc.debug", backend="ninja")
        with timer.phase("build_execution"):
            timer.record_rule("compile", "a.o", "a.cpp", 2.0, start_s=0.0, end_s=2.0)
        events = timer.to_chrome_trace()
        assert len(events) >= 2  # root + phase + rule
        # All events should have required Chrome trace fields
        for ev in events:
            assert "name" in ev
            assert "ph" in ev
            assert ev["ph"] == "X"
            assert "ts" in ev
            assert "dur" in ev
            assert "pid" in ev
            assert "tid" in ev

    def test_rule_has_args(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rule("compile", "obj/foo.o", "src/foo.cpp", 1.0)
        events = timer.to_chrome_trace()
        compile_events = [e for e in events if e["name"] == "foo.cpp"]
        assert len(compile_events) == 1
        assert compile_events[0]["args"]["target"] == "obj/foo.o"
        assert compile_events[0]["args"]["source"] == "src/foo.cpp"

    def test_normalizes_mixed_clock_domains(self):
        """All ingest paths now feed monotonic-aligned timestamps:
        in-Python recorders use ``time.monotonic()`` directly; the
        make recipe ingest converts bash ``$EPOCHREALTIME`` using the
        wall-to-monotonic offset captured at ``BuildTimer.__init__``;
        Slurm sacct timestamps are converted the same way.

        ``to_chrome_trace`` therefore just rebases against the root's
        ``start_s``.  Verify the round-trip preserves real start times
        for both phases and rules (no synthesised sequential stacking)
        — phases land at their actual offsets and within-phase rule
        parallelism comes through directly."""
        origin = 1_973_555.799  # realistic time.monotonic() value
        snapshot = {
            "version": 1,
            "total_elapsed_s": 0.28,
            "variant": "gcc.debug",
            "backend": "make",
            "start_s": origin,
            "phases": [
                {
                    "name": "build_execution",
                    "elapsed_s": 0.27,
                    "start_s": origin + 0.01,
                    "end_s": origin + 0.28,
                    "rules": [
                        {
                            "name": "a.cpp",
                            "rule_type": "compile",
                            "target": "a.o",
                            "source": "a.cpp",
                            "elapsed_s": 0.17,
                            "start_s": origin + 0.01,
                            "end_s": origin + 0.18,
                        },
                        {
                            "name": "b.cpp",
                            "rule_type": "compile",
                            "target": "b.o",
                            "source": "b.cpp",
                            "elapsed_s": 0.20,
                            "start_s": origin + 0.06,
                            "end_s": origin + 0.26,
                        },
                        # Tests run inside build_execution (no separate
                        # test_execution phase) with category="test".
                        {
                            "name": "test_x",
                            "rule_type": "test",
                            "target": "bin/test_x",
                            "source": "bin/test_x",
                            "elapsed_s": 0.01,
                            "start_s": origin + 0.27,
                            "end_s": origin + 0.28,
                        },
                    ],
                },
            ],
        }
        timer = BuildTimer.from_dict(snapshot)
        events = timer.to_chrome_trace()
        # All events fit inside the build's wall time (0.28 s).
        max_ts = max(e["ts"] + e["dur"] for e in events)
        assert max_ts < 1_000_000, f"ts not normalized: max_ts={max_ts}"
        # The root sits at ts=0 by construction.
        total = next(e for e in events if e["name"] == "total")
        assert total["ts"] == 0.0
        # The build_execution phase lands at its actual offset within the build.
        phases = {e["name"]: e for e in events if e["cat"] == "phase" and e["name"] != "total"}
        assert abs(phases["build_execution"]["ts"] - 10_000.0) < 1.0
        # Compile rules show their actual relative parallelism.
        compiles = sorted((e for e in events if e["cat"] == "compile"), key=lambda e: e["ts"])
        assert abs(compiles[0]["ts"] - 10_000.0) < 1.0
        assert abs(compiles[1]["ts"] - 60_000.0) < 1.0
        # The test rule runs late inside build_execution.
        test_event = next(e for e in events if e["cat"] == "test")
        assert abs(test_event["ts"] - 270_000.0) < 1.0

    def test_ninja_relative_events_share_timeline(self, tmp_path):
        """Regression: ninja log timestamps are ms relative to the
        ninja invocation; without folding onto the parent timer's
        monotonic clock they appear at ts ~ 0us, far below the phase's
        actual ts.  After the fix, build_start_mono is added on so
        the ninja rule overlaps the build_execution phase."""
        timer = BuildTimer(enabled=True, backend="ninja")
        with timer.phase("build_execution"):
            mono_at_ninja = time.monotonic()
            log = tmp_path / ".ninja_log"
            # ninja v5: <start_ms>\t<end_ms>\t<mtime_ms>\t<output>\t<hash>
            log.write_text("# ninja log v5\n0\t100\t0\tobj/foo.o\tdeadbeef\n")
            timer.record_rules_from_ninja_log(str(log), build_start_mono=mono_at_ninja)

        events = timer.to_chrome_trace()
        compile_ev = next(e for e in events if e["cat"] == "compile")
        phase_ev = next(e for e in events if e["cat"] == "phase" and e["name"] != "total")
        # The compile event starts within 1s of the phase start (they
        # should overlap, since the synthetic ninja log was "captured"
        # right at phase entry).
        assert abs(compile_ev["ts"] - phase_ev["ts"]) < 1_000_000, (
            f"ninja compile ts {compile_ev['ts']} not on same timeline as phase ts {phase_ev['ts']}"
        )


# ----------------------------------------------------------- summary table


class TestSummaryTable:
    def test_returns_rich_table(self):
        timer = BuildTimer(enabled=True, variant="gcc.debug", backend="make")
        with timer.phase("build_graph"):
            pass
        with timer.phase("build_execution"):
            timer.record_rule("compile", "a.o", "a.cpp", 2.0)
            timer.record_rule("link", "app", "", 1.0)
        table = timer.summary_table()
        assert table is not None
        assert table.title is not None
        assert "Build Timing Report" in str(table.title)

    def test_disabled_timer_summary(self):
        timer = BuildTimer(enabled=False)
        table = timer.summary_table()
        # Should still produce a table (just empty phases)
        assert table is not None


# ------------------------------------------------------------- classify


class TestClassifyOutput:
    def test_object_file(self):
        assert _classify_output("obj/foo.o") == "compile"
        assert _classify_output("foo.obj") == "compile"

    def test_static_library(self):
        assert _classify_output("lib/libfoo.a") == "static_library"

    def test_static_library_windows_lib(self):
        # Fix 10: .lib (Windows static lib) should bucket as static_library
        assert _classify_output("lib/foo.lib") == "static_library"

    def test_shared_library(self):
        assert _classify_output("lib/libfoo.so") == "shared_library"
        assert _classify_output("lib/libfoo.dylib") == "shared_library"
        assert _classify_output("lib/foo.dll") == "shared_library"

    def test_executable(self):
        assert _classify_output("bin/myapp") == "link"

    def test_windows_executable(self):
        # Fix 10: .exe should bucket as link, not "other"
        assert _classify_output("bin/myapp.exe") == "link"
        assert _classify_output("bin/myapp.EXE") == "link"

    def test_unknown_suffix_other(self):
        # Fix 10: previously buckets fell through to "link", masking
        # genuine artefacts (PCH, generated headers).  Now: "other".
        assert _classify_output("pch/foo.h.gch") == "other"
        assert _classify_output("gen/api.h") == "other"


# ------------------------------------------------- chrome trace tid uniqueness


class TestChromeTraceTidUniqueness:
    """Fix 3: sibling phases used to reuse tids 1..N — siblings of unrelated
    phases collided on the same Perfetto lane.  Now: monotonic across walk."""

    def test_no_two_rules_share_tid(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("phase_a"):
            timer.record_rule("compile", "a1.o", "a1.cpp", 1.0, start_s=0.0, end_s=1.0)
            timer.record_rule("compile", "a2.o", "a2.cpp", 1.0, start_s=0.0, end_s=1.0)
        with timer.phase("phase_b"):
            timer.record_rule("compile", "b1.o", "b1.cpp", 1.0, start_s=0.0, end_s=1.0)
            timer.record_rule("compile", "b2.o", "b2.cpp", 1.0, start_s=0.0, end_s=1.0)
        events = timer.to_chrome_trace()
        rule_tids = [e["tid"] for e in events if e.get("cat") == "compile"]
        assert len(rule_tids) == 4
        assert len(set(rule_tids)) == 4, f"tids collided: {rule_tids}"


# ----------------------------------------- summary table CPU-time semantics


class TestSummaryTableCPUTimeColumn:
    """Fix 2: rule sub-rows aggregate per-rule wall-clock spans, which can
    exceed the parent phase's wall-clock when rules ran in parallel.  The
    column header must reflect that (was previously misleading)."""

    def test_column_header_is_cpu_time(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("build_execution"):
            timer.record_rule("compile", "a.o", "a.cpp", 1.0, start_s=0.0, end_s=1.0)
        table = timer.summary_table()
        assert table is not None
        # rich Column.header is RenderableType (str | ConsoleRenderable | RichCast); stringify
        # before substring matching so the test is robust across rich versions.
        headers = [str(c.header) for c in table.columns]
        # Wall and CPU are presented as separate columns; sub-rows fill
        # CPU with the per-rule duration sum (which can exceed Wall).
        assert any("Wall" in h for h in headers), f"Expected a Wall column, got: {headers}"
        assert any("CPU" in h for h in headers), f"Expected a CPU column distinct from Wall, got: {headers}"

    def test_summed_children_may_exceed_phase_wall_clock(self):
        # Build a phase whose two child rules ran in parallel for 2s each
        # but the phase wall-clock is only 2s.  Sum (4s) > phase wall (2s).
        timer = BuildTimer(enabled=True)
        # Manually craft the tree so phase end_s reflects parallel exec
        from compiletools.build_timer import TimingEvent

        phase = TimingEvent(name="build_execution", category="phase", start_s=0.0, end_s=2.0)
        phase.children.append(
            TimingEvent(name="a", category="compile", start_s=0.0, end_s=2.0, target="a.o", source="a.cpp")
        )
        phase.children.append(
            TimingEvent(name="b", category="compile", start_s=0.0, end_s=2.0, target="b.o", source="b.cpp")
        )
        timer._root.children.append(phase)
        timer._root.end_s = 2.0
        # Sum of children exceeds phase wall — that is expected, not a bug
        sum_children = sum(c.elapsed_s for c in phase.children)
        assert sum_children > phase.elapsed_s
        # summary_table must still render without error
        assert timer.summary_table() is not None


# ----------------------------------------------------------- _union_span


class TestUnionSpan:
    @staticmethod
    def _ev(start: float, end: float) -> TimingEvent:
        return TimingEvent(name="r", category="compile", start_s=start, end_s=end)

    def test_disjoint_intervals_sum(self):
        events = [self._ev(0.0, 1.0), self._ev(2.0, 3.5)]
        assert _union_span(events) == pytest.approx(2.5)

    def test_overlapping_intervals_merged(self):
        events = [self._ev(0.0, 2.0), self._ev(1.0, 3.0)]
        assert _union_span(events) == pytest.approx(3.0)

    def test_fully_contained_interval(self):
        events = [self._ev(0.0, 5.0), self._ev(1.0, 2.0)]
        assert _union_span(events) == pytest.approx(5.0)

    def test_in_flight_event_skipped(self):
        finished = self._ev(0.0, 1.0)
        in_flight = TimingEvent(name="r", category="compile", start_s=2.0, end_s=None)
        assert _union_span([finished, in_flight]) == pytest.approx(1.0)

    def test_empty(self):
        assert _union_span([]) == 0.0


# ----------------------------------------- aggregate_by_category


class TestAggregateByCategory:
    """The category aggregation is the single source of truth shared by
    the static summary table and the Textual TUI tree.  Both interfaces
    must show the same Wall / CPU / parallelism numbers; if this helper
    drifts, the two views silently disagree."""

    def _build_timer_with_overlap(self) -> BuildTimer:
        # Two compiles: 0..2s and 1..3s -> Wall=3, CPU=4, parallelism=4/3
        # One link: 3..4s -> Wall=1, CPU=1, parallelism=1.0
        timer = BuildTimer(enabled=True)
        phase = TimingEvent(name="build_execution", category="phase", start_s=0.0, end_s=4.0)
        phase.children.append(
            TimingEvent(name="a", category="compile", start_s=0.0, end_s=2.0, target="a.o", source="a.cpp")
        )
        phase.children.append(
            TimingEvent(name="b", category="compile", start_s=1.0, end_s=3.0, target="b.o", source="b.cpp")
        )
        phase.children.append(TimingEvent(name="app", category="link", start_s=3.0, end_s=4.0, target="app"))
        timer._root.children.append(phase)
        timer._root.end_s = 4.0
        return timer

    def test_wall_is_union_not_sum(self):
        timer = self._build_timer_with_overlap()
        phase = timer.phases[0]
        rows = timer.aggregate_by_category(phase)
        compile_row = next(r for r in rows if r[0] == "compile")
        _cat, wall, cpu, parallelism, _ = compile_row
        assert wall == pytest.approx(3.0)  # union [0,3]
        assert cpu == pytest.approx(4.0)  # 2 + 2
        assert parallelism == pytest.approx(4.0 / 3.0)

    def test_sorted_by_cpu_descending(self):
        timer = self._build_timer_with_overlap()
        rows = timer.aggregate_by_category(timer.phases[0])
        cpus = [r[2] for r in rows]
        assert cpus == sorted(cpus, reverse=True)

    def test_non_aggregating_phase_returns_empty(self):
        timer = BuildTimer(enabled=True)
        phase = TimingEvent(name="build_graph", category="phase", start_s=0.0, end_s=1.0)
        phase.children.append(TimingEvent(name="x", category="compile", start_s=0.0, end_s=1.0, target="x.o"))
        timer._root.children.append(phase)
        assert timer.aggregate_by_category(phase) == []

    def test_empty_phase_returns_empty(self):
        timer = BuildTimer(enabled=True)
        phase = TimingEvent(name="build_execution", category="phase", start_s=0.0, end_s=0.0)
        timer._root.children.append(phase)
        assert timer.aggregate_by_category(phase) == []

    def test_summary_table_uses_aggregation(self):
        # Numbers in the rendered cells must equal what aggregate_by_category
        # returns -- they're the same source of truth, formatted differently.
        timer = self._build_timer_with_overlap()
        rows = timer.aggregate_by_category(timer.phases[0])
        compile_row = next(r for r in rows if r[0] == "compile")
        _, wall, cpu, parallelism, _ = compile_row

        table = timer.summary_table()
        assert table is not None
        # Materialize cell text per column.  Rich doesn't expose row data
        # directly; iterate columns and zip their cells.
        cols = [list(c.cells) for c in table.columns]
        cells = list(zip(*cols))
        compile_cells = next(row for row in cells if "Compile" in row[0])
        assert compile_cells[1] == f"{wall:.2f}"
        assert compile_cells[2] == f"{cpu:.2f}"
        assert compile_cells[3] == f"{parallelism:.1f}×"


# ----------------------------------------- ANSI in non-TTY stderr


class TestPrintSummaryNoAnsiOnPipe:
    """Fix 5: ANSI codes leaking into CI logs is ugly.  When stderr is not
    a TTY, Console must be created with ``force_terminal=False``."""

    def test_no_ansi_when_stderr_not_tty(self, capsys):
        timer = BuildTimer(enabled=True, variant="gcc.debug", backend="make")
        with timer.phase("build_execution"):
            timer.record_rule("compile", "a.o", "a.cpp", 1.0, start_s=0.0, end_s=1.0)
        timer.print_summary()
        captured = capsys.readouterr()
        # ANSI escape sequences start with ESC ([\x1b)
        assert "\x1b[" not in captured.err, f"ANSI escapes leaked into non-TTY stderr: {captured.err!r}"


class TestPrintSummarySkipsEmpty:
    """Fix 7: failure-path callers (cake.py finally) used to print '0.0s'
    tables that obscure the real exception.  Skip when nothing recorded."""

    def test_skips_when_no_phases(self, capsys):
        timer = BuildTimer(enabled=True)
        timer.print_summary()
        captured = capsys.readouterr()
        assert captured.err == "" and captured.out == ""

    def test_skips_when_phases_empty(self, capsys):
        # phases recorded but no rules — still nothing to report
        timer = BuildTimer(enabled=True)
        with timer.phase("build_graph"):
            pass
        timer.print_summary()
        captured = capsys.readouterr()
        # build_graph phase with zero children — print_summary skips
        assert captured.err == "" and captured.out == ""


# ----------------------------------------- loaded timer is read-only


class TestLoadedTimerReadOnly:
    """Fix 9: ``from_dict`` used to leave the loaded timer mutable; callers
    could append phases/rules to a historical snapshot and silently corrupt
    saved JSON if they re-saved."""

    def test_phase_on_loaded_raises(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("p"):
            timer.record_rule("compile", "a.o", "a.cpp", 1.0)
        loaded = BuildTimer.from_dict(timer.to_dict())
        with pytest.raises(RuntimeError, match="read-only"):
            with loaded.phase("late"):
                pass

    def test_record_rule_on_loaded_raises(self):
        timer = BuildTimer(enabled=True)
        with timer.phase("p"):
            timer.record_rule("compile", "a.o", "a.cpp", 1.0)
        loaded = BuildTimer.from_dict(timer.to_dict())
        with pytest.raises(RuntimeError, match="read-only"):
            loaded.record_rule("compile", "x.o", "x.cpp", 1.0)
