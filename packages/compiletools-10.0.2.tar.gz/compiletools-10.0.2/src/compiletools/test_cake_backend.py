from unittest.mock import MagicMock, patch

import pytest

import compiletools.apptools
from compiletools.build_backend import available_backends, ensure_backends_registered, get_backend_class
from compiletools.testhelper import CakeTestContext

ensure_backends_registered()


class TestBackendCLIArg:
    def test_make_is_default(self):
        cls = get_backend_class("make")
        assert cls.name() == "make"

    def test_available_includes_all_backends(self):
        backends = available_backends()
        assert "make" in backends
        assert "ninja" in backends
        assert "shake" in backends
        assert "bazel" in backends
        assert "cmake" in backends


class TestCakeBackendDispatch:
    """Verify that cake.process() dispatches to the correct backend."""

    @pytest.mark.parametrize("backend_name", ["make", "ninja", "bazel", "cmake", "shake"])
    def test_backend_dispatch_instantiates_correct_backend(self, backend_name):
        """--backend=X should instantiate the correct backend class."""
        with CakeTestContext(backend_name) as (cake, _tmpdir):
            expected_class = get_backend_class(backend_name)

            with (
                patch.object(expected_class, "build_graph") as mock_build_graph,
                patch.object(expected_class, "generate") as mock_generate,
                patch.object(expected_class, "execute") as mock_execute,
            ):
                mock_build_graph.return_value = MagicMock()
                cake.process()

                mock_build_graph.assert_called_once()
                mock_generate.assert_called_once()
                mock_execute.assert_called()

    def test_backend_dispatch_generates_compilation_database(self):
        """Backend dispatch should still generate compilation database."""
        with CakeTestContext("ninja", compilation_database=True) as (cake, _tmpdir):
            expected_class = get_backend_class("ninja")

            with (
                patch.object(expected_class, "build_graph", return_value=MagicMock()),
                patch.object(expected_class, "generate"),
                patch.object(expected_class, "execute"),
            ):
                cake.process()
                # _call_compilation_database is monkey-patched to MagicMock by CakeTestContext;
                # the mock's assert_* helpers aren't visible to the type checker.
                cake._call_compilation_database.assert_called_once()  # type: ignore[attr-defined]

    def test_clean_calls_backend_clean_method(self):
        """--clean should call backend.clean() instead of execute('realclean')."""
        with CakeTestContext("ninja", clean=True) as (cake, tmpdir):
            cake.args.output = tmpdir + "/out"
            expected_class = get_backend_class("ninja")

            mock_graph = MagicMock()
            mock_graph.outputs = {"build", "all"}
            with (
                patch.object(expected_class, "build_graph", return_value=mock_graph),
                patch.object(expected_class, "generate"),
                patch.object(expected_class, "clean") as mock_clean,
            ):
                cake.process()
                mock_clean.assert_called_once()

    def test_realclean_calls_backend_realclean_method(self):
        """--realclean should call backend.realclean(graph) instead of clean()."""
        with CakeTestContext("ninja", realclean=True) as (cake, tmpdir):
            cake.args.output = tmpdir + "/out"
            expected_class = get_backend_class("ninja")

            mock_graph = MagicMock()
            mock_graph.outputs = {"build", "all"}
            with (
                patch.object(expected_class, "build_graph", return_value=mock_graph),
                patch.object(expected_class, "generate"),
                patch.object(expected_class, "realclean") as mock_realclean,
                patch.object(expected_class, "clean") as mock_clean,
            ):
                cake.process()
                mock_realclean.assert_called_once_with(mock_graph)
                mock_clean.assert_not_called()

    def test_backend_dispatch_does_not_issue_separate_runtests(self):
        """Every backend runs its test rules during execute('build'), so
        cake.py issues only execute('build') — never a separate
        execute('runtests') phase."""
        with CakeTestContext("cmake", tests=["test_main.cpp"]) as (cake, _tmpdir):
            expected_class = get_backend_class("cmake")

            mock_graph = MagicMock()
            mock_graph.outputs = {"build", "all", "runtests"}
            with (
                patch.object(expected_class, "build_graph", return_value=mock_graph),
                patch.object(expected_class, "generate"),
                patch.object(expected_class, "execute") as mock_execute,
            ):
                cake.process()
                calls = [c[0][0] for c in mock_execute.call_args_list]
                assert "build" in calls
                assert "runtests" not in calls

    def test_static_flag_allowed_for_make_backend(self):
        """--static should not raise for --backend=make."""
        with CakeTestContext("make", static=["lib.cpp"]) as (cake, _tmpdir):
            cake.hunter = MagicMock()
            cake.hunter.required_source_files = MagicMock(return_value=[])
            expected_class = get_backend_class("make")

            with (
                patch.object(compiletools.apptools, "substitutions"),
                patch.object(compiletools.apptools, "verboseprintconfig"),
                patch.object(expected_class, "build_graph", return_value=MagicMock()),
                patch.object(expected_class, "generate"),
                patch.object(expected_class, "execute"),
            ):
                cake.process()

    def test_backend_dispatch_skips_runtests_when_no_tests(self):
        """When args.tests is empty, execute('runtests') should NOT be called."""
        with CakeTestContext("ninja") as (cake, _tmpdir):
            expected_class = get_backend_class("ninja")

            mock_graph = MagicMock()
            mock_graph.outputs = {"build", "all"}
            with (
                patch.object(expected_class, "build_graph", return_value=mock_graph),
                patch.object(expected_class, "generate"),
                patch.object(expected_class, "execute") as mock_execute,
            ):
                cake.process()
                calls = [c[0][0] for c in mock_execute.call_args_list]
                assert "build" in calls
                assert "runtests" not in calls
