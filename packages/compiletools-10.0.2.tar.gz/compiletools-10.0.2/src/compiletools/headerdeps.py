import os
from pathlib import Path

# At deep verbose levels pprint is used
from pprint import pprint

import stringzilla as sz

import compiletools.apptools
import compiletools.file_analyzer
import compiletools.git_utils
import compiletools.preprocessor
import compiletools.tree as tree
import compiletools.utils
import compiletools.wrappedos
from compiletools.file_analyzer import analyze_file, set_analyzer_args
from compiletools.global_hash_registry import get_file_hash
from compiletools.preprocessing_cache import (
    MacroCacheKey,
    MacroDict,
    MacroState,
    get_or_compute_preprocessing,
    is_permanently_invariant,
)
from compiletools.utils import instance_cache, split_command_cached


def clear_caches(context):
    """Clear all caches on the BuildContext. Used by test framework between tests."""
    context.include_list_cache.clear()
    context.invariant_include_cache.clear()


def clear_include_list_cache(context):
    """Clear the include list cache.

    Used during two-pass header discovery to ensure Pass 2 gets fresh results.
    """
    context.include_list_cache.clear()


def create(args, context):
    """HeaderDeps Factory"""
    classname = args.headerdeps.title() + "HeaderDeps"
    if args.verbose >= 4:
        print("Creating " + classname + " to process header dependencies.")
    depsclass = globals()[classname]
    return depsclass(args, context=context)


def add_arguments(cap):
    """Add the command line arguments that the HeaderDeps classes require"""
    if compiletools.apptools._parser_has_option(cap, "--headerdeps"):
        return
    compiletools.apptools.add_common_arguments(cap)
    alldepscls = [st[:-10].lower() for st in dict(globals()) if st.endswith("HeaderDeps")]
    cap.add_argument(
        "--headerdeps",
        choices=alldepscls,
        default="direct",
        help="Methodology for determining header dependencies",
    )
    if not compiletools.apptools._parser_has_option(cap, "--max-file-read-size"):
        cap.add_argument(
            "--max-file-read-size",
            type=int,
            default=0,
            help="Maximum bytes to read from files (0 = entire file)",
        )

    # Add FileAnalyzer arguments for file reading strategy control
    compiletools.file_analyzer.FileAnalyzer.add_arguments(cap)


class HeaderDepsBase:
    """Implement the common functionality of the different header
    searching classes.  This really should be an abstract base class.
    """

    def __init__(self, args, context):
        self.args = args
        self.context = context
        # Set analyzer args for FileAnalyzer caching
        set_analyzer_args(args, context)

    def _process_impl(self, realpath: str, macro_cache_key: MacroCacheKey) -> list[str]:
        """Derived classes implement this function"""
        raise NotImplementedError

    def process(self, filename: str, macro_cache_key: MacroCacheKey) -> list[str]:
        """Return an ordered list of header dependencies for the given file.

        Args:
            filename: File to analyze for dependencies
            macro_cache_key: Frozenset of (macro_name, macro_value) tuples for cache key.
                            Pass frozenset() for no variable macros (core only).

        Notes:
                - The list preserves discovery order (depth-first and preprocessor-respecting
                    for DirectHeaderDeps; cpp -MM derived for CppHeaderDeps) while removing
                    duplicates.
                - The input file itself is excluded from the returned list.
                - System include paths are excluded by default unless configured otherwise.
        """
        realpath = compiletools.wrappedos.realpath(filename)
        return self._process_impl(realpath, macro_cache_key)

    @staticmethod
    def _extract_prefixed_paths(flag_value, prefix):
        """Extract paths following ``prefix`` (e.g. ``-I`` or ``-isystem``).

        Handles three forms:
          * ``-I /path``         (separate tokens)
          * ``-I/path``          (attached)
          * ``["-I", "/path"]``  (list from configargparse multi-value)

        Uses shell parsing so quoted paths with spaces are preserved.
        """
        if not flag_value:
            return []

        if isinstance(flag_value, list):
            flag_value = " ".join(flag_value)

        try:
            tokens = split_command_cached(flag_value)
        except ValueError:
            tokens = flag_value.split()

        prefix_len = len(prefix)
        paths = []
        i = 0
        while i < len(tokens):
            token = tokens[i]
            if token == prefix:
                if i + 1 < len(tokens):
                    paths.append(tokens[i + 1])
                    i += 2
                else:
                    i += 1
            elif token.startswith(prefix):
                path = token[prefix_len:]
                if path:
                    paths.append(path)
                i += 1
            else:
                i += 1
        return paths

    @staticmethod
    def _extract_isystem_paths_from_flags(flag_value):
        """Extract -isystem paths from command-line flags."""
        return HeaderDepsBase._extract_prefixed_paths(flag_value, "-isystem")

    @staticmethod
    def _extract_include_paths_from_flags(flag_value):
        """Extract -I include paths from command-line flags."""
        return HeaderDepsBase._extract_prefixed_paths(flag_value, "-I")

    @staticmethod
    def clear_cache():
        # print("HeaderDepsBase::clear_cache")
        compiletools.apptools.clear_cache()
        # Note: clear_include_list_cache() requires a BuildContext;
        # include list caches live on BuildContext instances and are
        # cleaned up when the context is discarded.
        DirectHeaderDeps.clear_cache()
        CppHeaderDeps.clear_cache()


class DirectHeaderDeps(HeaderDepsBase):
    """Create a tree structure that shows the header include tree"""

    def __init__(self, args, context):
        HeaderDepsBase.__init__(self, args, context=context)

        # Keep track of ancestor paths so that we can do header cycle detection
        self.ancestor_paths = []

        # Cache core macros and gitroot anchor (computed once, reused
        # for all files). Both are seeded here so their lifecycles are
        # visibly co-managed -- _initialize_includes_and_macros only
        # populates them when _core_macros is None.
        self._core_macros = None
        self._anchor_root: str = ""
        self._includes: list = []

        # Initialize includes and macros
        self._initialize_includes_and_macros({})

    def _initialize_includes_and_macros(self, variable_macros: MacroDict):
        """Initialize include paths and macro definitions from compile flags.

        Caches core macros and includes on first call for reuse across all files.

        Args:
            variable_macros: Dict of variable macros (from file #defines).
                            Pass {} for no variable macros (core only).
        """
        # Cache core macros and includes - they never change for this instance
        if self._core_macros is None:
            # Grab the include paths from the CPPFLAGS, excluding system paths.
            # Use proper shell parsing instead of regex to handle quoted paths with spaces
            self._includes = self._extract_include_paths_from_flags(self.args.CPPFLAGS)

            if self.args.verbose >= 3:
                print("Includes=" + str(self._includes))

            # Extract macro definitions from command line flags and compiler
            # Both are static for the lifetime of this instance (core macros).
            # (compiletools.apptools is already module-level imported above; no
            # local re-import — the local re-import shadows the module-level
            # ``compiletools`` binding for the type checker, breaking access to
            # sibling submodules like ``compiletools.git_utils`` below.)
            raw_macros = compiletools.apptools.extract_command_line_macros(
                self.args,
                flag_sources=["CPPFLAGS", "CFLAGS", "CXXFLAGS"],
                include_compiler_macros=True,
                verbose=self.args.verbose,
            )
            # Convert all keys and values to StringZilla.Str and place in core
            self._core_macros = {sz.Str(k): sz.Str(v) for k, v in raw_macros.items()}

            # Cache gitroot once for the lifetime of this instance. Used as
            # the anchor for canonicalizing -I paths in the cache-key hash
            # so identical TUs share entries across workspace moves.
            self._anchor_root = compiletools.git_utils.find_git_root()

        # Set includes and reset macro state (reuse cached core, use provided variable dict).
        # Deliberate non-propagation of cmdline_origin / *_tokens / compiler_identity:
        # this MacroState only feeds the headerdeps preprocessor walker via
        # get_cache_key() / get_relevant_key() / get_hash(include_core=False)
        # -- none of which consult those fields. Object-naming hashes flow
        # through magicflags' _final_macro_states, not this one, so there's
        # nothing to scope here.  ``compiler_identity=""`` is passed
        # explicitly so the constructor call enumerates every build-context
        # field deliberately.
        self.includes = self._includes
        self.defined_macros = MacroState(
            self._core_macros,
            variable_macros,
            compiler_path=getattr(self.args, "CXX", ""),
            cppflags=getattr(self.args, "CPPFLAGS", ""),
            compiler_identity="",
            anchor_root=self._anchor_root,
        )

    @instance_cache
    def _search_project_includes(self, include: sz.Str):
        """Internal use.  Find the given include file in the project include paths"""
        for inc_dir in self.includes:
            trialpath_sz = compiletools.wrappedos.join_sz(sz.Str(inc_dir), include)
            if compiletools.wrappedos.isfile_sz(trialpath_sz):
                return str(compiletools.wrappedos.realpath_sz(trialpath_sz))

        return None

    @instance_cache
    def _find_include(self, include: sz.Str, cwd: str):
        """Internal use.  Find the given include file.
        Start at the current working directory then try the project includes
        """
        # Check if the file is referable from the current working directory
        # if that guess doesn't exist then try all the include paths
        trialpath_sz = compiletools.wrappedos.join_sz(sz.Str(cwd), include)
        if compiletools.wrappedos.isfile_sz(trialpath_sz):
            return str(compiletools.wrappedos.realpath_sz(trialpath_sz))

        return self._search_project_includes(include)

    @instance_cache
    def _process_impl(self, realpath, macro_cache_key):
        """Process file with macro state in cache key.

        Args:
            realpath: File to process
            macro_cache_key: Frozenset cache key of initial macro state (part of cache key)

        Note: Assumes caller has already initialized macro state via process()
        """
        if self.args.verbose >= 9:
            print(f"DirectHeaderDeps::_process_impl: {realpath} (macro_key={macro_cache_key})")

        results_order = []
        results_set = set()
        self._process_impl_recursive(realpath, results_order, results_set)
        if realpath in results_order:
            results_order.remove(realpath)
        return results_order

    def process(self, filename: str, macro_cache_key: MacroCacheKey) -> list[str]:
        """Override to compute and pass initial macro cache key.

        Args:
            filename: File to analyze for dependencies
            macro_cache_key: Frozenset of (macro_name, macro_value) tuples for cache key.
                            Pass frozenset() for no variable macros (core only).
        """
        realpath = compiletools.wrappedos.realpath(filename)

        # Convert cache key frozenset to MacroDict for MacroState initialization
        # Ensure all keys/values are sz.Str for consistency (MacroState uses stringzilla exclusively)
        variable_macros: MacroDict = {sz.Str(k): sz.Str(v) for k, v in macro_cache_key}

        # Initialize with variable macros to ensure consistent initial_macro_key for LRU cache
        self._initialize_includes_and_macros(variable_macros)
        initial_macro_key = self.defined_macros.get_cache_key()

        return self._process_impl(realpath, initial_macro_key)

    def _create_include_list(self, realpath):
        """Internal use. Create the list of includes for the given file

        Caches filtered include lists to avoid redundant processing when the same
        file is encountered with the same macro state across different traversals.

        Uses two-level caching:
        - Invariant cache: For files without conditionals, keyed by content_hash only
        - Variant cache: For files with conditionals, keyed by (content_hash, macro_key)

        This dramatically improves cache hit rate since most files are invariant.
        """
        ctx = self.context
        content_hash = get_file_hash(realpath, ctx)
        analysis_result = analyze_file(content_hash, ctx)
        inv_inc_cache = ctx.invariant_include_cache
        var_inc_cache = ctx.include_list_cache

        # Check if file is permanently invariant (no conditionals at all)
        # This is a fast check based on file content, not macro state
        if is_permanently_invariant(analysis_result):
            # Invariant file - use content_hash only as cache key
            if content_hash in inv_inc_cache:
                cached_includes, cached_file_defines, cached_file_undefs = inv_inc_cache[content_hash]
                if cached_file_defines:
                    self.defined_macros = self.defined_macros.with_updates(cached_file_defines)
                if cached_file_undefs:
                    self.defined_macros = self.defined_macros.without_keys(cached_file_undefs)
                return cached_includes

            # Cache miss for invariant file - compute and store
            result = get_or_compute_preprocessing(analysis_result, self.defined_macros, self.args.verbose, context=ctx)

            include_list = [
                sz.Str(inc["filename"]) for inc in result.active_includes if not inc.get("is_commented", False)
            ]

            self.defined_macros = result.updated_macros
            inv_inc_cache[content_hash] = (include_list, result.file_defines, result.file_undefs)
            return include_list

        # Variant file - use file-specific macro key (only macros that affect this file)
        macro_key = self.defined_macros.get_relevant_key(analysis_result.conditional_macros)
        cache_key = (content_hash, macro_key)

        if cache_key in var_inc_cache:
            cached_includes, cached_file_defines, cached_file_undefs = var_inc_cache[cache_key]
            if cached_file_defines:
                self.defined_macros = self.defined_macros.with_updates(cached_file_defines)
            if cached_file_undefs:
                self.defined_macros = self.defined_macros.without_keys(cached_file_undefs)
            return cached_includes

        # Cache miss for variant file - compute and store
        if self.args.verbose >= 9 and analysis_result.include_positions:
            print(
                f"DirectHeaderDeps::analyze - FileAnalyzer pre-found "
                f"{len(analysis_result.include_positions)} includes in {realpath}"
            )

        result = get_or_compute_preprocessing(analysis_result, self.defined_macros, self.args.verbose, context=ctx)

        include_list = [sz.Str(inc["filename"]) for inc in result.active_includes if not inc.get("is_commented", False)]

        self.defined_macros = result.updated_macros
        var_inc_cache[cache_key] = (include_list, result.file_defines, result.file_undefs)

        return include_list

    def _generate_tree_impl(self, realpath, node=None):
        """Return a tree that describes the header includes
        The node is passed recursively, however the original caller
        does not need to pass it in.
        """

        if self.args.verbose >= 4:
            print("DirectHeaderDeps::_generate_tree_impl: ", realpath)

        if node is None:
            node = tree.tree()

        # Stop cycles
        if realpath in self.ancestor_paths:
            if self.args.verbose >= 7:
                print(
                    "DirectHeaderDeps::_generate_tree_impl is breaking the cycle on ",
                    realpath,
                )
            return node
        self.ancestor_paths.append(realpath)

        # This next line is how you create the node in the tree
        node[realpath]

        if self.args.verbose >= 6:
            print("DirectHeaderDeps inserted: " + realpath)
            pprint(tree.dicts(node))

        cwd = os.path.dirname(realpath)
        for include in self._create_include_list(realpath):
            trialpath = self._find_include(include, cwd)
            if trialpath:
                self._generate_tree_impl(trialpath, node[realpath])
                if self.args.verbose >= 5:
                    print("DirectHeaderDeps building tree: ")
                    pprint(tree.dicts(node))

        self.ancestor_paths.pop()
        return node

    def generatetree(self, filename, macro_cache_key=None):
        """Returns the tree of include files"""
        self.ancestor_paths = []
        if macro_cache_key:
            variable_macros = {sz.Str(k): sz.Str(v) for k, v in macro_cache_key}
            self._initialize_includes_and_macros(variable_macros)
        realpath = compiletools.wrappedos.realpath(filename)
        return self._generate_tree_impl(realpath)

    def _process_impl_recursive(self, realpath, results_order, results_set):
        if realpath in results_set:
            return
        results_set.add(realpath)

        # Process includes first (depth-first traversal to match preprocessor)
        cwd = compiletools.wrappedos.dirname(realpath)
        for include in self._create_include_list(realpath):
            trialpath = self._find_include(include, cwd)
            if trialpath and trialpath not in results_set:
                if self.args.verbose >= 9:
                    print(
                        "DirectHeaderDeps::_process_impl_recursive about to follow ",
                        trialpath,
                    )
                self._process_impl_recursive(trialpath, results_order, results_set)

        # Add current file after processing includes (depth-first order)
        results_order.append(realpath)

    def clear_instance_cache(self):
        """Clear this instance's per-instance caches."""
        for method in (self._search_project_includes, self._find_include, self._process_impl):
            # See Hunter.clear_instance_cache — cache_attr is on the @instance_cache
            # wrapper; route through ``__func__`` for the type checker.
            self.__dict__.pop(method.__func__.cache_attr, None)  # type: ignore[attr-defined]
        if self.args.verbose >= 5:
            print("DirectHeaderDeps::clear_instance_cache completed")

    @staticmethod
    def clear_cache():
        pass  # Instance caches are per-instance; nothing class-level to clear


class CppHeaderDeps(HeaderDepsBase):
    """Using the C Pre Processor, create the list of headers that the given file depends upon."""

    def __init__(self, args, context):
        HeaderDepsBase.__init__(self, args, context=context)
        self.preprocessor = compiletools.preprocessor.PreProcessor(args)

    def process(self, filename: str, macro_cache_key: MacroCacheKey) -> list[str]:
        """Process using cpp -MM (raises error if macro_cache_key non-empty).

        Args:
            filename: File to analyze for dependencies
            macro_cache_key: Must be empty frozenset(). CppHeaderDeps does not support
                            file-level macro contexts (compiler determines macros).

        Raises:
            NotImplementedError: If macro_cache_key is non-empty
        """
        if macro_cache_key:
            raise NotImplementedError(
                "CppHeaderDeps does not support file-level macro contexts. "
                "Use --headerdeps=direct (default) for macro-aware dependency analysis."
            )
        realpath = compiletools.wrappedos.realpath(filename)
        return self._process_impl(realpath, macro_cache_key)

    def _process_impl(self, realpath: str, macro_cache_key: MacroCacheKey) -> list[str]:
        """Use the -MM option to the compiler to generate the list of dependencies
        If you supply a header file rather than a source file then
        a dummy, blank, source file will be transparently provided
        and the supplied header file will be included into the dummy source file.
        """
        # Exclude system paths. Use proper shell parsing instead of regex to
        # handle quoted paths with spaces.
        isystem_paths = self._extract_isystem_paths_from_flags(self.args.CPPFLAGS)
        system_paths = tuple(item for pth in isystem_paths for item in (pth, compiletools.wrappedos.realpath(pth)))
        realpath_obj = Path(realpath)
        if any(realpath_obj.is_relative_to(syspath) for syspath in system_paths):
            return []

        output = self.preprocessor.process(realpath, extraargs="-MM")

        # output will be something like
        # test_direct_include.o: tests/test_direct_include.cpp
        # tests/get_numbers.hpp tests/get_double.hpp tests/get_int.hpp
        # We need to throw away the object file and only keep the dependency
        # list
        deplist = output.split(":")[1]

        # Strip non-space whitespace, remove any backslashes, and remove any empty strings
        # Also remove the initially given realpath and /dev/null from the list
        # Use a set to inherently remove any redundancies
        # Use realpath to get rid of  // and ../../ etc in paths (similar to normpath) and
        # to get the full path even to files in the current working directory
        return compiletools.utils.ordered_unique(
            [
                compiletools.wrappedos.realpath(x)
                for x in deplist.split()
                if x.strip("\\\t\n\r")
                and x not in [realpath, "/dev/null"]
                and not any(Path(x).is_relative_to(syspath) for syspath in system_paths)
            ]
        )

    @staticmethod
    def clear_cache():
        pass
