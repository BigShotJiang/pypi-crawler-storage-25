"""Cache trimming utility for the object CAS, PCH CAS, PCM CAS, and the
linker-artefact CAS (cas-exedir).

Scans cas-objdir, cas-pchdir, cas-pcmdir, and cas-exedir for stale entries
and removes them, keeping entries that match the current git state and
preserving a configurable number of recent non-current entries per source
file or per module/header/linker-artefact bucket.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import shutil
import sys
import time

# Object filename format: {basename}_{file_hash_12}_{dep_hash_14}_{macro_state_hash_16}.o
# Anchored from the END (the three hash fields have fixed widths) so the
# basename can contain anything — including embedded substrings that look
# like our hash fields. Per-trailing-component matching avoids the regex
# backtracking quirks of a greedy ``(.+)`` first group.
_OBJ_FILENAME_RE = re.compile(
    r"^(?P<basename>.+)_(?P<file>[0-9a-f]{12})_(?P<dep>[0-9a-f]{14})_(?P<macro>[0-9a-f]{16})\.o$"
)

# Object bucket directories are exactly 2 lowercase hex chars (the leading
# 2 chars of the per-source ``file_hash``). Top-level entries that don't
# match — ``TraceStore/`` dirs, anything else — are invisible to the
# scanner.  Diagnostics artifacts (timing JSON and ``slurm-ct-*.out`` logs)
# default to ``<bindir>/diagnostics/<invocation>/`` and are not in objdir;
# if a user overrides ``--diagnostics-dir`` to point back at ``--cas-objdir``
# they remain invisible here too, by design.
_OBJ_BUCKET_RE = re.compile(r"^[0-9a-f]{2}$")

# PCH command hash directories are exactly 16 lowercase hex chars.
_PCH_COMMAND_HASH_RE = re.compile(r"^[0-9a-f]{16}$")

# PCM command_hash directories use the same shape as PCH: 16 hex chars
# of sha256 truncation, single hash per cache entry. The PCM cache key
# folds source content + transitive header content + compiler + flags
# into one ``command_hash``; safety against accidental collision is
# provided by the compiler's BMI verification at consume time
# (see _pcm_command_hash docstring), so the additional entropy of an
# object-cache-style 3-axis path layout isn't needed here.
_PCM_COMMAND_HASH_RE = re.compile(r"^[0-9a-f]{16}$")

# Suffixes recognised inside cas-exedir buckets. Keep in lockstep with
# ``namer.cas_*_pathname`` and ``build_backend._build_publish_rule``.
# Anything not on this list (e.g. ``.lock`` sidecars, ``.lock.excl``)
# is silently skipped, which is what we want — peer-build lock files
# must never be enumerated as trim or report candidates.
_CAS_EXE_SUFFIXES: tuple[str, ...] = (".exe", ".a", ".so")


def _load_exe_manifest(cas_path: str) -> dict | None:
    """Read a cas-exedir entry's sidecar manifest at ``<cas_path>.manifest``.

    Returns ``None`` for legacy entries (no manifest), unreadable, or
    corrupt files. Callers must treat ``None`` as "fall back to
    basename bucketing" so reporting/trimming keep working during the
    manifest-rollout window.
    """
    try:
        with open(cas_path + ".manifest") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _load_cmd_hash_manifest(cmd_hash_dir: str) -> dict | None:
    """Read a cmd_hash dir's sidecar manifest (PCH or PCM).

    Returns ``None`` for legacy (manifest-less) entries or unreadable /
    corrupt files. Callers must treat ``None`` as "fall back to global
    ranking" so the trim path keeps working during the manifest-rollout
    window.
    """
    path = os.path.join(cmd_hash_dir, "manifest.json")
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


# Back-compat aliases for the (now-deduplicated) PCH/PCM manifest loaders.
# Re-exported by cache_report.py.
_load_pch_manifest = _load_cmd_hash_manifest
_load_pcm_manifest = _load_cmd_hash_manifest


def parse_object_filename(filename):
    """Parse a content-addressable object filename into its components.

    Args:
        filename: Object filename (not path), e.g.
            ``my_module_aabbccddeeff_11223344556677_0011223344556677.o``

    Returns:
        Tuple of (basename, file_hash_12, dep_hash_14, macro_state_hash_16)
        or None if the filename does not match the expected format.
    """
    m = _OBJ_FILENAME_RE.match(filename)
    if m:
        return m.group(1), m.group(2), m.group(3), m.group(4)
    return None


def build_current_hash_set(context):
    """Build the set of 12-char file hash prefixes for all git-tracked files.

    The 12-char (48-bit) prefix is deliberately loose: the failure mode
    of a collision is over-retention (treating a non-current entry as
    current and keeping it), never under-deletion. With ~80k tracked
    files the birthday probability of a collision is non-trivial but
    benign.

    Args:
        context: BuildContext with loaded file hashes.

    Returns:
        set of 12-character hex strings.
    """
    from compiletools.global_hash_registry import get_tracked_files

    tracked = get_tracked_files(context)
    return {sha[:12] for sha in tracked.values()}


class CacheTrimmer:
    """Trims stale entries from cas-objdir and cas-pchdir caches."""

    def __init__(self, args):
        self.dry_run = getattr(args, "dry_run", False)
        self.verbose = getattr(args, "verbose", 1)
        self.keep_count = getattr(args, "keep_count", 1)
        max_age_days = getattr(args, "max_age", None)
        self.max_age_seconds = max_age_days * 86400 if max_age_days is not None else None

    # ------------------------------------------------------------------
    # Object directory trimming
    # ------------------------------------------------------------------

    def trim_objdir(self, objdir, current_hashes):
        """Trim stale object files from an object CAS.

        Note on ``max_age``: "aged" means "old since written" (mtime), NOT
        "old since last accessed" (atime). A heavily-used cache entry from
        months ago will still be evicted because we cannot rely on atime
        (most production filesystems mount with ``noatime``).

        Args:
            objdir: Path to the object CAS.
            current_hashes: Set of 12-char hex strings representing current
                file hashes (from build_current_hash_set).

        Returns:
            dict with statistics: total_scanned, basenames_found,
            current_kept, noncurrent_kept, removed, failed, bytes_freed.
        """
        stats = {
            "total_scanned": 0,
            "basenames_found": 0,
            "current_kept": 0,
            "noncurrent_kept": 0,
            "removed": 0,
            "failed": 0,
            "bytes_freed": 0,
        }

        if not os.path.isdir(objdir):
            if self.verbose >= 1:
                print(f"Object directory does not exist: {objdir}")
            return stats

        try:
            groups = self._scan_object_files(objdir, stats)
        except OSError as exc:
            print(f"Error scanning {objdir}: {exc}", file=sys.stderr)
            return stats

        now = time.time()
        for _basename, files in groups.items():
            self._process_basename_group(files, current_hashes, now, stats)

        return stats

    def _scan_object_files(self, objdir, stats):
        """Scan ``objdir`` for parseable ``.o`` entries, grouped by basename.

        Walks two levels: ``<objdir>/<bucket>/*.o`` where ``<bucket>`` is
        a 2-hex shard derived from the per-source ``file_hash[:2]``.
        Top-level entries that aren't 2-hex bucket dirs (Slurm ``.out``
        logs, ``TraceStore/`` dirs, stray pre-sharding ``.o`` leftovers)
        are skipped — they are outside the sharded cache's world.

        Within each bucket, ``.lockdir`` entries are skipped (they sit
        next to their ``.o`` and are managed by the lock subsystem, not
        the trimmer).

        Mutates ``stats`` in place: increments ``total_scanned`` per
        successfully-parsed entry and sets ``basenames_found`` to the final
        number of distinct basenames discovered.

        Returns a dict mapping basename to a list of
        ``(path, file_hash, mtime, size)`` tuples. May raise ``OSError`` if
        the initial ``os.scandir`` call fails. Per-bucket ``OSError`` (e.g.
        a bucket dir vanishes mid-scan) is swallowed and that bucket's
        contribution is just skipped — best-effort scan.
        """
        groups = {}  # basename -> list of (path, file_hash, mtime, size)
        with os.scandir(objdir) as entries:
            bucket_paths = []
            for entry in entries:
                if not _OBJ_BUCKET_RE.match(entry.name):
                    continue
                if not entry.is_dir(follow_symlinks=False):
                    continue
                bucket_paths.append(entry.path)

        for bucket_path in bucket_paths:
            try:
                with os.scandir(bucket_path) as bucket_entries:
                    for entry in bucket_entries:
                        if entry.name.endswith(".lockdir"):
                            continue
                        if not entry.name.endswith(".o"):
                            continue
                        parsed = parse_object_filename(entry.name)
                        if parsed is None:
                            continue
                        stats["total_scanned"] += 1
                        basename, file_hash, _dep_hash, _macro_hash = parsed
                        try:
                            st = entry.stat()
                        except OSError:
                            continue
                        groups.setdefault(basename, []).append((entry.path, file_hash, st.st_mtime, st.st_size))
            except OSError:
                continue  # bucket vanished or unreadable; skip and move on

        stats["basenames_found"] = len(groups)
        return groups

    def _process_basename_group(self, files, current_hashes, now, stats):
        """Apply the keep/remove policy to one basename's object files.

        Mutates ``stats`` in place additively (``current_kept``,
        ``noncurrent_kept``, ``removed``, ``failed``, ``bytes_freed``) and
        performs the per-file ``print`` / ``_safe_locked_unlink`` side effects
        in the order ``files`` was accumulated.
        """
        current = [(p, fh, mt, sz) for p, fh, mt, sz in files if fh in current_hashes]
        noncurrent = [(p, fh, mt, sz) for p, fh, mt, sz in files if fh not in current_hashes]

        stats["current_kept"] += len(current)

        # Sort non-current by mtime descending (newest first)
        noncurrent.sort(key=lambda x: x[2], reverse=True)

        to_keep = noncurrent[: self.keep_count]
        candidates = noncurrent[self.keep_count :]

        # Safety: always keep at least 1 file per basename total.
        # Only fires when keep_count=0 AND no current entry exists; if
        # the basename has zero non-current entries it stays absent (no
        # file to retain — nothing is silently lost, there is nothing
        # to keep).
        if not current and not to_keep and candidates:
            to_keep.append(candidates.pop(0))

        # Apply max_age filter: only remove candidates older than max_age
        if self.max_age_seconds is not None:
            cutoff = now - self.max_age_seconds
            to_remove = [f for f in candidates if f[2] < cutoff]
        else:
            to_remove = candidates

        stats["noncurrent_kept"] += len(to_keep) + (len(candidates) - len(to_remove))

        for path, _fh, _mt, size in to_remove:
            if self.verbose >= 1:
                action = "Would remove" if self.dry_run else "Removing"
                print(f"  {action}: {path} ({_format_size(size)})")
            if not self.dry_run:
                if _safe_locked_unlink(path):
                    stats["removed"] += 1
                    stats["bytes_freed"] += size
                else:
                    stats["failed"] += 1
                    if self.verbose >= 1:
                        print(f"  Failed to remove {path}", file=sys.stderr)
            else:
                stats["removed"] += 1
                stats["bytes_freed"] += size

    # ------------------------------------------------------------------
    # PCH directory trimming
    # ------------------------------------------------------------------

    def trim_pchdir(self, pchdir):
        """Trim stale precompiled header directories from the PCH CAS.

        Each ``<pchdir>/<cmd_hash>/`` directory is one unique compile
        configuration (compiler + flags + header realpath). The trim
        policy treats each cmd_hash dir as an independent unit:

        * Sort all cmd_hash dirs by mtime, newest first.
        * Keep the newest ``keep_count`` overall.
        * If ``max_age_seconds`` is set, also keep anything younger
          than that even beyond ``keep_count``.

        Bucketing-by-header-basename was tried in v8.0.2 but caused
        cache thrash: two unrelated projects both using ``stdafx.h``
        evicted each other at the default ``keep_count=1``.
        Per-realpath bucketing is now used instead — each
        ``<pchdir>/<cmd_hash>/`` writes a sidecar ``manifest.json``
        recording the immediate header's realpath, and ``keep_count``
        is enforced per realpath bucket so cross-variant builds of the
        same header coexist. Legacy entries without a manifest fall
        back to the previous global ranking.

        Note on ``max_age``: "aged" means "old since written" (the
        cmd_hash dir's mtime), NOT "old since last accessed". A
        heavily-used PCH cmd_hash dir from months ago is still evicted
        if it falls outside ``keep_count`` and ``max_age``. atime is
        unreliable on noatime-mounted filesystems.

        Note on cache-key composition: the cmd_hash captures the
        immediate header's realpath. Transitive-header content hashes
        are stored in the sidecar manifest and consulted during trim —
        entries whose transitive content has changed are pre-evicted so
        the user does not pay the slow ``cc1`` PCH-stamp rejection at
        consume time.

        Args:
            pchdir: Path to the PCH CAS.

        Returns:
            dict with statistics: total_dirs_scanned, headers_found,
            dirs_kept, dirs_removed, failed, bytes_freed.
        """
        stats = {
            "total_dirs_scanned": 0,
            "headers_found": 0,
            "dirs_kept": 0,
            "dirs_removed": 0,
            "failed": 0,
            "bytes_freed": 0,
        }

        if not os.path.isdir(pchdir):
            if self.verbose >= 1:
                print(f"PCH directory does not exist: {pchdir}")
            return stats

        # Phase 1: scan command_hash directories
        # dir_info: {command_hash: (path, mtime, total_size, [header_basenames])}
        dir_info = {}
        unique_headers: set[str] = set()

        try:
            entries = list(os.scandir(pchdir))
        except OSError as exc:
            print(f"Error scanning {pchdir}: {exc}", file=sys.stderr)
            return stats

        for entry in entries:
            if not entry.is_dir():
                continue
            if not _PCH_COMMAND_HASH_RE.match(entry.name):
                continue
            stats["total_dirs_scanned"] += 1

            headers = []
            total_size = 0
            try:
                for gch_entry in os.scandir(entry.path):
                    if gch_entry.name.endswith(".gch") and gch_entry.is_file():
                        header_base = gch_entry.name[:-4]  # strip .gch
                        headers.append(header_base)
                        try:
                            total_size += gch_entry.stat().st_size
                        except OSError:
                            pass
            except OSError:
                continue

            if not headers:
                continue

            try:
                dir_mtime = entry.stat().st_mtime
            except OSError:
                continue

            dir_info[entry.name] = (entry.path, dir_mtime, total_size, headers)
            unique_headers.update(headers)

        stats["headers_found"] = len(unique_headers)
        now = time.time()

        # Phase 2: bucket cmd_hash dirs by header_realpath (from sidecar
        # manifest) and apply ``keep_count`` per bucket. Legacy entries
        # without a manifest fall into the ``__legacy__`` bucket and use
        # the previous global-ranking semantics so the rollout is
        # backwards-compatible.
        buckets: dict[str, list[str]] = {}
        for cmd_hash, (path, _mtime, _size, _headers) in dir_info.items():
            manifest = _load_pch_manifest(path)
            realpath = manifest.get("header_realpath") if manifest else None
            key = realpath or "__legacy__"
            buckets.setdefault(key, []).append(cmd_hash)

        needed_dirs: set[str] = set()
        for _bucket_key, hashes in buckets.items():
            sorted_hashes = sorted(hashes, key=lambda ch: dir_info[ch][1], reverse=True)
            needed_dirs.update(sorted_hashes[: self.keep_count])

        if self.max_age_seconds is not None:
            cutoff = now - self.max_age_seconds
            for cmd_hash, (_path, mtime, _size, _headers) in dir_info.items():
                if mtime >= cutoff:
                    needed_dirs.add(cmd_hash)

        # Phase 2b: pre-evict entries whose transitive headers have
        # changed since the .gch was built. Best-effort — manifest
        # absence or unreadable headers leave the entry alone.
        # Hashes use the same git-blob-SHA1 algorithm as
        # ``global_hash_registry._compute_external_file_hash`` so
        # comparisons are meaningful without taking on a BuildContext
        # dependency in the trim CLI.
        for cmd_hash in list(needed_dirs):
            path = dir_info[cmd_hash][0]
            manifest = _load_pch_manifest(path)
            if not manifest:
                continue
            for h_realpath, expected_hash in manifest.get("transitive_hashes", {}).items():
                try:
                    with open(h_realpath, "rb") as fh:
                        content = fh.read()
                except OSError:
                    continue  # best-effort: missing or unreadable
                current = hashlib.sha1(f"blob {len(content)}\0".encode() + content).hexdigest()
                if current != expected_hash:
                    if self.verbose >= 1:
                        print(f"  Pre-evicting {path} (transitive {h_realpath} changed)")
                    needed_dirs.discard(cmd_hash)
                    break

        # Phase 3: remove directories not needed
        for cmd_hash, (path, _mtime, total_size, _headers) in dir_info.items():
            if cmd_hash in needed_dirs:
                stats["dirs_kept"] += 1
                continue

            if self.verbose >= 1:
                action = "Would remove" if self.dry_run else "Removing"
                print(f"  {action}: {path} ({_format_size(total_size)})")

            if not self.dry_run:
                # Lock each .gch file before removing the cmd_hash
                # dir. If a build is currently generating one of the .gch
                # files, we block until it releases — never deleting a
                # file a peer is mid-write to. Best-effort: filesystems
                # that don't support our lock strategies fall through to
                # plain rmtree (the lock acquisition is wrapped to ignore
                # errors so we don't fail trims on unlocked filesystems).
                if _safe_locked_rmtree(path):
                    stats["dirs_removed"] += 1
                    stats["bytes_freed"] += total_size
                else:
                    stats["failed"] += 1
                    if self.verbose >= 1:
                        print(f"  Failed to remove {path}", file=sys.stderr)
            else:
                stats["dirs_removed"] += 1
                stats["bytes_freed"] += total_size

        return stats

    # ------------------------------------------------------------------
    # PCM directory trimming
    # ------------------------------------------------------------------

    def trim_pcmdir(self, pcmdir):
        """Trim stale precompiled C++20 module artefacts from the PCM CAS.

        Layout: ``<pcmdir>/<command_hash>/<name>.{pcm,gcm}`` plus a
        sidecar ``manifest.json`` per command_hash directory. Mirrors
        ``trim_pchdir``: each command_hash dir is one unique compile
        configuration; the manifest carries ``bucket_key`` (source
        realpath for named modules, verbatim token for header units),
        ``stage``, and ``transitive_hashes``.

        The single-hash + manifest design here is **deliberately
        simpler** than the object cache's 3-hash path -- see
        ``_pcm_command_hash`` for why PCM doesn't need the object
        cache's per-axis path isolation. The compiler verifies BMIs
        at consume time, so the worst case of a hypothetical 64-bit
        collision is a slow re-precompile, never a miscompile.

        Trim policy:

        - **bucketing** (mirrors pchdir): per-bucket ``keep_count``
          using ``bucket_key`` from the manifest. Cross-variant builds
          of the same source coexist at ``keep_count=1``.
        - **transitive-staleness pre-eviction** (mirrors pchdir): if
          a recorded transitive header's content hash no longer
          matches its on-disk content, the entry is pre-evicted.
        - **max_age**: keeps anything younger than the cutoff
          regardless of bucket position.

        Args:
            pcmdir: Path to the PCM CAS.

        Returns:
            dict with statistics: total_dirs_scanned, buckets_found,
            dirs_kept, dirs_removed, failed, bytes_freed.
        """
        stats = {
            "total_dirs_scanned": 0,
            "buckets_found": 0,
            "dirs_kept": 0,
            "dirs_removed": 0,
            "failed": 0,
            "bytes_freed": 0,
        }

        if not os.path.isdir(pcmdir):
            if self.verbose >= 1:
                print(f"PCM directory does not exist: {pcmdir}")
            return stats

        # Phase 1: scan command_hash directories.
        # dir_info: {cmd_hash: (path, mtime, total_size, [leaf_filenames])}
        dir_info: dict[str, tuple] = {}

        try:
            entries = list(os.scandir(pcmdir))
        except OSError as exc:
            print(f"Error scanning {pcmdir}: {exc}", file=sys.stderr)
            return stats

        for entry in entries:
            if not entry.is_dir() or not _PCM_COMMAND_HASH_RE.match(entry.name):
                continue
            stats["total_dirs_scanned"] += 1
            leaves = []
            total_size = 0
            try:
                for leaf in os.scandir(entry.path):
                    if leaf.name.endswith((".pcm", ".gcm")) and leaf.is_file():
                        leaves.append(leaf.name)
                        try:
                            total_size += leaf.stat().st_size
                        except OSError:
                            pass
            except OSError:
                continue
            if not leaves:
                continue
            try:
                dir_mtime = entry.stat().st_mtime
            except OSError:
                continue
            dir_info[entry.name] = (entry.path, dir_mtime, total_size, leaves)

        # Phase 2: bucket by manifest's bucket_key. Header-unit entries
        # use the token (``<vector>``); named-module entries use the
        # source realpath. Legacy / manifest-less entries fall into
        # ``__legacy__`` for global ranking so older builds keep working.
        buckets: dict[str, list[str]] = {}
        for cmd_hash, (path, _mtime, _size, _leaves) in dir_info.items():
            manifest = _load_pcm_manifest(path)
            bucket_key = (manifest.get("bucket_key") if manifest else None) or "__legacy__"
            buckets.setdefault(bucket_key, []).append(cmd_hash)
        stats["buckets_found"] = sum(1 for k in buckets if k != "__legacy__")

        needed_dirs: set[str] = set()
        for _bucket_key, hashes in buckets.items():
            sorted_hashes = sorted(hashes, key=lambda ch: dir_info[ch][1], reverse=True)
            needed_dirs.update(sorted_hashes[: self.keep_count])

        now = time.time()
        if self.max_age_seconds is not None:
            cutoff = now - self.max_age_seconds
            for cmd_hash, (_path, mtime, _size, _leaves) in dir_info.items():
                if mtime >= cutoff:
                    needed_dirs.add(cmd_hash)

        # Phase 2b: pre-evict entries whose transitive headers have
        # changed. Same git-blob SHA1 algorithm as
        # ``global_hash_registry._compute_external_file_hash``.
        for cmd_hash in list(needed_dirs):
            path = dir_info[cmd_hash][0]
            manifest = _load_pcm_manifest(path)
            if not manifest:
                continue
            for h_realpath, expected_hash in manifest.get("transitive_hashes", {}).items():
                try:
                    with open(h_realpath, "rb") as fh:
                        content = fh.read()
                except OSError:
                    continue
                current = hashlib.sha1(f"blob {len(content)}\0".encode() + content).hexdigest()
                if current != expected_hash:
                    if self.verbose >= 1:
                        print(f"  Pre-evicting {path} (transitive {h_realpath} changed)")
                    needed_dirs.discard(cmd_hash)
                    break

        # Phase 3: remove dirs not in the keep set.
        for cmd_hash, (path, _mtime, total_size, _leaves) in dir_info.items():
            if cmd_hash in needed_dirs:
                stats["dirs_kept"] += 1
                continue

            if self.verbose >= 1:
                action = "Would remove" if self.dry_run else "Removing"
                print(f"  {action}: {path} ({_format_size(total_size)})")

            if not self.dry_run:
                if _safe_locked_rmtree(path):
                    stats["dirs_removed"] += 1
                    stats["bytes_freed"] += total_size
                else:
                    stats["failed"] += 1
                    if self.verbose >= 1:
                        print(f"  Failed to remove {path}", file=sys.stderr)
            else:
                stats["dirs_removed"] += 1
                stats["bytes_freed"] += total_size

        return stats

    # ------------------------------------------------------------------
    # Executable cache (cas-exedir) trimming
    # ------------------------------------------------------------------

    def trim_exedir(self, exedir):
        """Trim stale entries from the content-addressable linker-artefact
        cache (executables, static libraries, shared libraries — all
        share the cas-exedir root).

        Layout: ``<exedir>/<key[:2]>/<basename>_<key>.<ext>`` with
        ``<ext>`` ∈ ``{.exe, .a, .so}``. Flatter than the PCH/PCM
        caches (no per-entry sidecar manifest; the key itself is the
        cache identity).

        Trim policy:

        * **Bucket** by ``(basename, suffix)`` (the part of the
          filename before ``_<key>``, plus its suffix). One
          executable's distinct link configurations live in the same
          bucket — and ``libfoo.a`` and ``libfoo.so`` bucket
          separately because the suffix differs. The newest
          ``keep_count`` per bucket survive bucket-rank eviction.
        * **max_age**: anything younger than the cutoff is kept
          regardless of bucket position (mirrors objdir / pchdir /
          pcmdir).
        * **Hard-link safety**: skip files with ``st_nlink > 1``.
          The ``symlink`` rule publishes ``bin/<variant>/<name>`` as a
          hard link to the cas entry; a second reference means a
          user-facing artefact is still pointing at this inode and
          deleting it would force a relink on the next build for no
          actual savings (the inode would survive anyway via the
          remaining link). Symlinked-fallback bin paths show
          ``st_nlink == 1`` on the cas entry and are NOT protected — the
          user can rebuild if a symlink dangles.
        * **Lock-aware delete**: ``_safe_locked_unlink`` acquires
          ``<path>.lock`` via the same ``FileLock`` strategy used by
          the link/ar wrapper, so a trim that lands mid-link blocks
          until the link releases the lock instead of clobbering a
          partially-renamed artefact.

        Sidecar lock files (``*.lock`` / ``*.lock.excl``) are filtered
        at the suffix-match step — they don't end in any of the
        ``_CAS_EXE_SUFFIXES`` so they never become candidates.

        Args:
            exedir: Path to the linker-artefact CAS.

        Returns:
            dict with statistics: total_scanned, basenames_found,
            kept, removed, failed, bytes_freed.
        """
        stats = {
            "total_scanned": 0,
            "basenames_found": 0,
            "kept": 0,
            "removed": 0,
            "failed": 0,
            "bytes_freed": 0,
        }

        if not os.path.isdir(exedir):
            if self.verbose >= 1:
                print(f"Executable directory does not exist: {exedir}")
            return stats

        # entry_info: {full_path: (bucket_key, mtime, size, st_nlink)}
        # bucket_key prefers ``(source_realpath, suffix)`` from the
        # sidecar manifest written at link time (C4 — disambiguates
        # distinct executables that happen to share a basename like
        # ``main``). Falls back to ``(basename, suffix)`` for legacy
        # entries that pre-date the sidecar contract (existing caches
        # don't suddenly behave differently after upgrading).
        entry_info: dict[str, tuple] = {}
        for bucket_entry in os.scandir(exedir):
            if not bucket_entry.is_dir():
                continue
            try:
                inner = list(os.scandir(bucket_entry.path))
            except OSError:
                continue
            for leaf in inner:
                if not leaf.is_file():
                    continue
                matched_suffix = next(
                    (s for s in _CAS_EXE_SUFFIXES if leaf.name.endswith(s)),
                    None,
                )
                if matched_suffix is None:
                    continue
                # ``<basename>_<key><suffix>``: split on the LAST underscore
                # so basenames containing underscores stay intact.
                stem = leaf.name[: -len(matched_suffix)]
                sep = stem.rfind("_")
                if sep <= 0:
                    continue
                basename = stem[:sep]
                try:
                    st = leaf.stat()
                except OSError:
                    continue
                # Prefer source_realpath from sidecar; fall back to basename.
                bucket_id: str = basename
                manifest = _load_exe_manifest(leaf.path)
                if manifest is not None:
                    src = manifest.get("source_realpath")
                    if isinstance(src, str) and src:
                        bucket_id = src
                entry_info[leaf.path] = ((bucket_id, matched_suffix), st.st_mtime, st.st_size, st.st_nlink)
                stats["total_scanned"] += 1

        if not entry_info:
            return stats

        # Bucket by executable basename, then sort each bucket newest-first
        # and keep the top keep_count.
        buckets: dict[str, list[str]] = {}
        for path, (basename, _mtime, _size, _nlink) in entry_info.items():
            buckets.setdefault(basename, []).append(path)
        stats["basenames_found"] = len(buckets)

        keep_paths: set[str] = set()
        for paths in buckets.values():
            paths.sort(key=lambda p: entry_info[p][1], reverse=True)
            keep_paths.update(paths[: self.keep_count])

        # max-age: keep anything younger than the cutoff regardless of rank.
        now = time.time()
        if self.max_age_seconds is not None:
            cutoff = now - self.max_age_seconds
            for path, (_basename, mtime, _size, _nlink) in entry_info.items():
                if mtime >= cutoff:
                    keep_paths.add(path)

        # Hard-link safety: anything with another reference is in use.
        for path, (_basename, _mtime, _size, nlink) in entry_info.items():
            if nlink > 1:
                keep_paths.add(path)

        for path, (_basename, _mtime, size, _nlink) in entry_info.items():
            if path in keep_paths:
                stats["kept"] += 1
                continue
            if self.dry_run:
                if self.verbose >= 1:
                    print(f"  Would remove: {path}")
                stats["removed"] += 1
                stats["bytes_freed"] += size
                continue
            # I4: re-stat under the lock and skip if a peer publish
            # elevated nlink between the initial scan and this unlink.
            if _safe_locked_unlink(path, skip_if_nlink_above=1):
                stats["removed"] += 1
                stats["bytes_freed"] += size
                # Sidecar files are best-effort cleanup — don't count
                # towards bytes_freed (small, ignore failure). The
                # ``.result`` sidecar is the per-CAS-entry test-success
                # marker touched by the in-build test rules in CAS-only mode.
                for sidecar_suffix in (".manifest", ".result"):
                    try:
                        os.remove(path + sidecar_suffix)
                    except OSError:
                        pass
            else:
                stats["failed"] += 1

        return stats

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def print_summary(self, objdir_stats=None, pchdir_stats=None, pcmdir_stats=None, exedir_stats=None):
        """Print a formatted summary of trimming results."""
        total_freed = 0
        print()
        print("=" * 60)
        print("Cache trim complete")

        if objdir_stats is not None:
            total_freed += objdir_stats["bytes_freed"]
            print("  Object files:")
            print(f"    Total scanned:   {objdir_stats['total_scanned']}")
            print(f"    Basenames found: {objdir_stats['basenames_found']}")
            print(f"    Current (kept):  {objdir_stats['current_kept']}")
            print(f"    Non-current kept:{objdir_stats['noncurrent_kept']}")
            removed_str = f"    Removed:         {objdir_stats['removed']}"
            if objdir_stats["bytes_freed"]:
                removed_str += f" ({_format_size(objdir_stats['bytes_freed'])} freed)"
            print(removed_str)
            if objdir_stats["failed"]:
                print(f"    Failed:          {objdir_stats['failed']}")

        if pchdir_stats is not None:
            total_freed += pchdir_stats["bytes_freed"]
            print("  PCH directories:")
            print(f"    Total scanned:   {pchdir_stats['total_dirs_scanned']}")
            print(f"    Headers found:   {pchdir_stats['headers_found']}")
            print(f"    Kept:            {pchdir_stats['dirs_kept']}")
            removed_str = f"    Removed:         {pchdir_stats['dirs_removed']}"
            if pchdir_stats["bytes_freed"]:
                removed_str += f" ({_format_size(pchdir_stats['bytes_freed'])} freed)"
            print(removed_str)
            if pchdir_stats["failed"]:
                print(f"    Failed:          {pchdir_stats['failed']}")

        if pcmdir_stats is not None:
            total_freed += pcmdir_stats["bytes_freed"]
            print("  PCM directories:")
            print(f"    Total scanned:   {pcmdir_stats['total_dirs_scanned']}")
            print(f"    Buckets found:   {pcmdir_stats['buckets_found']}")
            print(f"    Kept:            {pcmdir_stats['dirs_kept']}")
            removed_str = f"    Removed:         {pcmdir_stats['dirs_removed']}"
            if pcmdir_stats["bytes_freed"]:
                removed_str += f" ({_format_size(pcmdir_stats['bytes_freed'])} freed)"
            print(removed_str)
            if pcmdir_stats["failed"]:
                print(f"    Failed:          {pcmdir_stats['failed']}")

        if exedir_stats is not None:
            total_freed += exedir_stats["bytes_freed"]
            print("  Executable cache:")
            print(f"    Total scanned:   {exedir_stats['total_scanned']}")
            print(f"    Basenames found: {exedir_stats['basenames_found']}")
            print(f"    Kept:            {exedir_stats['kept']}")
            removed_str = f"    Removed:         {exedir_stats['removed']}"
            if exedir_stats["bytes_freed"]:
                removed_str += f" ({_format_size(exedir_stats['bytes_freed'])} freed)"
            print(removed_str)
            if exedir_stats["failed"]:
                print(f"    Failed:          {exedir_stats['failed']}")

        # The summary line aggregates whatever was actually scanned.
        scanned = sum(s is not None for s in (objdir_stats, pchdir_stats, pcmdir_stats, exedir_stats))
        if scanned >= 2:
            print(f"  Total space freed: {_format_size(total_freed)}")
        print("=" * 60)


def _safe_locked_unlink(path, *, skip_if_nlink_above=None):
    """Unlink path after acquiring the build lock for it.

    Used by ct-trim-cache to avoid deleting an .o file that a concurrent
    build is currently writing. Returns True on success, False on failure.

    If the lock subsystem cannot acquire a lock (filesystem unsupported,
    permissions, etc.), this function REFUSES to delete the file —
    deleting unlocked would defeat the entire purpose of the wrapper
    and could clobber an in-flight write from a peer build. The caller
    sees False and reports the file as failed; a future trim run can
    retry once the underlying lock issue is resolved.

    ``skip_if_nlink_above`` (I4): if not None, re-stat the path under
    the lock and skip the unlink if ``st_nlink`` exceeds the threshold.
    Closes a TOCTOU window where a peer publish-as-hardlink lands
    between the trim's initial scan (nlink read=1) and this per-entry
    unlink (nlink would now be 2, but the in-memory snapshot is stale).
    Without this re-check, we'd evict an entry that just gained a
    published reference and force a relink on the next build. Returns
    False (entry still considered live) when the threshold trips.
    """
    from types import SimpleNamespace

    from compiletools.locking import FileLock

    lock_args = SimpleNamespace(
        file_locking=True,
        verbose=0,
        lock_cross_host_timeout=300,
        lock_warn_interval=30,
        lock_creation_grace_period=2,
        sleep_interval_lockdir=None,
        sleep_interval_cifs=0.1,
        sleep_interval_flock_fallback=0.1,
    )
    try:
        with FileLock(path, lock_args):
            if skip_if_nlink_above is not None:
                try:
                    st = os.stat(path)
                except FileNotFoundError:
                    return True  # peer already removed
                except OSError:
                    return False
                if st.st_nlink > skip_if_nlink_above:
                    # I4: peer publish elevated nlink mid-trim. Treat as
                    # still-in-use; do not unlink.
                    return False
            try:
                os.remove(path)
                return True
            except FileNotFoundError:
                return True  # peer already removed
            except OSError:
                return False
    except OSError as exc:
        # Lock acquisition failed — refuse to delete unlocked. Deleting
        # without a lock could clobber a peer build that is mid-write.
        print(
            f"  Refusing to remove {path}: lock unavailable ({exc})",
            file=sys.stderr,
        )
        return False


def _safe_locked_rmtree(dir_path):
    """Remove dir_path after acquiring a build lock on each contained file.

    Used by ct-trim-cache to avoid deleting files that a concurrent build
    is currently writing. Returns True on success, False on failure.

    Lock-unavailable safety: if any file's lock cannot be acquired, this
    function REFUSES to remove the directory and returns False. Deleting
    unlocked would defeat the wrapper's purpose and risk clobbering a
    peer build's in-flight write.

    TOCTOU safety: after locks are acquired, the directory is re-scanned.
    If any new file appeared between the initial scan and lock window
    (a peer build creating a fresh .gch), we abort the removal so the
    new file is not deleted unlocked. Caller sees False and the dir is
    naturally retried on the next trim pass.
    """
    from types import SimpleNamespace

    lock_args = SimpleNamespace(
        file_locking=True,
        verbose=0,
        lock_cross_host_timeout=300,
        lock_warn_interval=30,
        lock_creation_grace_period=2,
        sleep_interval_lockdir=None,
        sleep_interval_cifs=0.1,
        sleep_interval_flock_fallback=0.1,
    )

    # Lock-metadata sidecars (FlockLock/FcntlLock/CIFSLock create
    # ``<target>.lock`` and ``.lock.excl`` files alongside build artifacts).
    # They aren't build outputs, so we neither lock them (locking a .lock
    # file would create .lock.lock) nor count them as peer activity in the
    # TOCTOU re-scan — the .lock files we acquire below would otherwise
    # show up there as "new files" and abort the removal.
    def _is_build_artifact(name):
        return not (name.endswith(".lock") or name.endswith(".lock.excl"))

    files_to_lock = []
    try:
        for entry in os.scandir(dir_path):
            if entry.is_file() and _is_build_artifact(entry.name):
                files_to_lock.append(entry.path)
    except OSError:
        # Dir vanished — nothing to do
        return True

    from compiletools.locking import FileLock

    def _release_quiet(fl):
        # Match the original best-effort release semantics: a stray OSError
        # on lock release during cleanup must not fail the trim (the rmtree
        # may already have succeeded).
        with contextlib.suppress(OSError):
            fl.__exit__(None, None, None)

    with contextlib.ExitStack() as stack:
        for path in files_to_lock:
            try:
                fl = FileLock(path, lock_args)
                fl.__enter__()
            except OSError as exc:
                # Lock acquisition failed — refuse to delete unlocked.
                # Deleting without a lock could clobber a peer build
                # that is mid-write to one of these files.
                print(
                    f"  Refusing to remove {dir_path}: lock unavailable for {path} ({exc})",
                    file=sys.stderr,
                )
                return False
            stack.callback(_release_quiet, fl)

        # Re-scan inside the lock window to catch files that appeared
        # between the initial scan and lock acquisition. A peer build
        # creating a fresh .gch in this dir is unlocked from our side,
        # so removing it would be unsafe — abort instead.
        try:
            current_files = {
                entry.path for entry in os.scandir(dir_path) if entry.is_file() and _is_build_artifact(entry.name)
            }
        except OSError:
            # Dir vanished between scan and re-scan; nothing more to do
            return True

        locked_set = set(files_to_lock)
        new_files = current_files - locked_set
        if new_files:
            print(
                f"  Refusing to remove {dir_path}: {len(new_files)} new file(s) "
                f"appeared after scan (peer build active)",
                file=sys.stderr,
            )
            return False

        try:
            shutil.rmtree(dir_path)
            return True
        except OSError:
            return False


def _format_size(size_bytes):
    """Format a byte count as a human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"
