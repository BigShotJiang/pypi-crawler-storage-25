"""File analysis module for efficient pattern detection in source files.

This module provides SIMD-optimized file analysis with StringZilla when available,
falling back to traditional regex-based analysis for compatibility.
"""

import bisect
import builtins
import mmap
import resource
import sys
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from compiletools.build_context import BuildContext

import stringzilla
from stringzilla import Str

import compiletools.filesystem_utils
import compiletools.wrappedos
from compiletools.stringzilla_utils import (
    ends_with_backslash_sz,
    is_alpha_or_underscore_sz,
    join_lines_strip_backslash_sz,
    strip_sz,
)


class MarkerType(Enum):
    """Type of marker found in source file."""

    NONE = 0
    EXE = 1
    TEST = 2
    LIBRARY = 3


def is_position_commented_simd_optimized(str_text: "stringzilla.Str", pos: int, line_byte_offsets: list[int]) -> bool:
    """Optimized comment detection using pre-computed line boundaries."""
    # Binary search for line start using precomputed line starts
    line_start_idx = bisect.bisect_right(line_byte_offsets, pos) - 1
    line_start = line_byte_offsets[line_start_idx] if line_start_idx >= 0 else 0

    # Check for single-line comment on current line using StringZilla
    line_prefix_slice = str_text[line_start:pos]
    if line_prefix_slice.find("//") != -1:
        return True

    # Delegate block-comment check to the dedicated helper to avoid duplication.
    return is_inside_block_comment_simd(str_text, pos)


def is_inside_block_comment_simd(str_text: "stringzilla.Str", pos: int) -> bool:
    """Check if position is inside a multi-line block comment using StringZilla."""
    last_block_start = str_text.rfind("/*", 0, pos)
    if last_block_start != -1:
        last_block_end = str_text.rfind("*/", last_block_start, pos)
        if last_block_end == -1:
            return True

    return False


def find_include_positions_simd_bulk(str_text, line_byte_offsets: list[int]) -> list[int]:
    """Optimized include position finder using pre-computed line byte offsets.

    Vectorization: Minimizes Python-level loops by finding all positions in one pass.
    """
    positions = []

    # Single-pass search: find and validate in one loop
    pos = str_text.find("#include", 0)
    while pos != -1:
        if not is_position_commented_simd_optimized(str_text, pos, line_byte_offsets):
            positions.append(pos)
        pos = str_text.find("#include", pos + 8)  # Continue from next position

    return positions


def find_magic_positions_simd_bulk(str_text, line_byte_offsets: list[int]) -> list[int]:
    """Optimized magic position finder using pre-computed line byte offsets.

    Vectorization: Single-pass search avoiding intermediate list allocation.
    """
    positions = []

    # Single-pass search with inline validation
    pos = str_text.find("//#", 0)
    while pos != -1:
        # Binary search for line start
        line_start_idx = bisect.bisect_right(line_byte_offsets, pos) - 1
        line_start = line_byte_offsets[line_start_idx] if line_start_idx >= 0 else 0

        # Check if only whitespace before //# using StringZilla slice
        if pos > line_start:
            line_prefix_slice = str_text[line_start:pos]
            # Use StringZilla's character set operations for efficient whitespace checking
            if line_prefix_slice.find_first_not_of(" \t\r\n") != -1:
                pos = str_text.find("//#", pos + 3)
                continue

        # Check if we're inside a block comment
        if is_inside_block_comment_simd(str_text, pos):
            pos = str_text.find("//#", pos + 3)
            continue

        # Look for KEY=value pattern after //# using StringZilla
        after_hash = pos + 3
        # Find the end of this line using line_byte_offsets
        current_line_idx = bisect.bisect_right(line_byte_offsets, pos) - 1
        if current_line_idx + 1 < len(line_byte_offsets):
            line_end = line_byte_offsets[current_line_idx + 1] - 1  # End before next line starts
        else:
            line_end = len(str_text)  # Last line

        # Use StringZilla slice to find = efficiently
        line_content_slice = str_text[after_hash:line_end]
        equals_pos = line_content_slice.find("=")
        if equals_pos != -1:
            # Extract key part using StringZilla slice
            key_slice = line_content_slice[:equals_pos]

            # Use StringZilla's character set operations for efficient whitespace trimming
            start_pos = key_slice.find_first_not_of(" \t")
            if start_pos != -1:
                end_pos = key_slice.find_last_not_of(" \t")
                trimmed_key = key_slice[start_pos : end_pos + 1]
            else:
                trimmed_key = key_slice[0:0]  # Empty slice

            if len(trimmed_key) > 0:
                # Validate key format using StringZilla character set operations
                if (
                    trimmed_key.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")
                    == -1
                ):
                    if is_alpha_or_underscore_sz(trimmed_key, 0):
                        positions.append(pos)

        # Continue search from next position
        pos = str_text.find("//#", pos + 3)

    return positions


def find_directive_positions_simd_bulk(str_text, line_byte_offsets: list[int]) -> dict[str, list[int]]:
    """Optimized directive position finder using pre-computed newline positions.

    Vectorization: Single-pass search without intermediate list allocation.
    """
    directive_positions = {}

    # Pre-define common directives for faster lookup
    target_directives = {
        "include",
        "ifdef",
        "ifndef",
        "define",
        "undef",
        "endif",
        "else",
        "elif",
        "pragma",
        "error",
        "warning",
        "line",
        "if",
    }

    # Single-pass search: find and process each # character
    hash_pos = str_text.find("#", 0)
    while hash_pos != -1:
        # Binary search for line start using precomputed line starts
        line_start_idx = bisect.bisect_right(line_byte_offsets, hash_pos) - 1
        line_start = line_byte_offsets[line_start_idx] if line_start_idx >= 0 else 0

        # Check if only whitespace before # using StringZilla slice
        if hash_pos > line_start:
            line_prefix_slice = str_text[line_start:hash_pos]
            # Use StringZilla's character set operations for efficient whitespace checking
            if line_prefix_slice.find_first_not_of(" \t\r\n") != -1:
                hash_pos = str_text.find("#", hash_pos + 1)
                continue

        # Extract directive name efficiently
        directive_start = hash_pos + 1
        # Skip whitespace after # using StringZilla
        directive_start = str_text.find_first_not_of(" \t", directive_start)
        if directive_start == -1:
            hash_pos = str_text.find("#", hash_pos + 1)
            continue

        # Find end of directive name using character set
        directive_end = str_text.find_first_not_of(
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_", directive_start
        )
        if directive_end == -1:  # Directive takes up rest of string
            directive_end = len(str_text)

        if directive_end > directive_start:
            # Use StringZilla slice for directive name
            directive_slice = str_text[directive_start:directive_end]

            # Check if directive matches any target directive using StringZilla direct comparison
            for target_directive in target_directives:
                # Use StringZilla's efficient string comparison
                if directive_slice == target_directive:
                    if target_directive not in directive_positions:
                        directive_positions[target_directive] = []
                    directive_positions[target_directive].append(hash_pos)
                    break

        # Continue search from next position
        hash_pos = str_text.find("#", hash_pos + 1)

    return directive_positions


def parse_directive_struct(
    dtype: str, pos: int, line_num: int, directive_lines: list["stringzilla.Str"]
) -> "PreprocessorDirective":
    """Parse a directive into structured form using StringZilla operations."""
    full_text_str = join_lines_strip_backslash_sz(directive_lines)

    directive = PreprocessorDirective(
        line_num=line_num, byte_pos=pos, directive_type=dtype, continuation_lines=len(directive_lines) - 1
    )

    # Find start of content after directive
    content_start_pos = full_text_str.find(dtype)
    if content_start_pos == -1:
        return directive
    content_start_pos += len(dtype)

    # Skip whitespace after directive
    content_start_pos = full_text_str.find_first_not_of(" \t", content_start_pos)
    if content_start_pos == -1:
        return directive

    content_slice = full_text_str[content_start_pos:]

    if dtype in ("ifdef", "ifndef", "undef"):
        directive.macro_name = strip_sz(content_slice)

    elif dtype in ("if", "elif"):
        directive.condition = strip_sz(content_slice)

    elif dtype == "define":
        parts = content_slice.split(maxsplit=1)
        if len(parts) > 0:
            name_part = parts[0]
            # Handle function-like macros: extract name before '('
            paren_pos = name_part.find("(")
            if paren_pos != -1:
                directive.macro_name = name_part[:paren_pos]
            else:
                directive.macro_name = name_part

            if len(parts) > 1:
                directive.macro_value = strip_sz(parts[1])
            else:
                directive.macro_value = None

    elif dtype == "include":
        directive.condition = strip_sz(content_slice)

    elif dtype == "pragma":
        # Extract pragma name (e.g., "once" from "#pragma once")
        directive.macro_name = strip_sz(content_slice)

    return directive


def _warn_low_ulimit(total_files: int, soft_limit: int, context: "BuildContext"):
    """Warn once about low file descriptor limit."""
    if context.warned_low_ulimit:
        return
    args = context.analyzer_args

    if args and getattr(args, "suppress_fd_warnings", False):
        return

    print(f"Warning: File descriptor limit too low for mmap mode (ulimit -n = {soft_limit})", file=sys.stderr)
    print(f"  Total files: {total_files}, available FDs (90% of limit): {int(soft_limit * 0.9)}", file=sys.stderr)
    print("  Using traditional file I/O instead of mmap to avoid 'Too many open files' errors", file=sys.stderr)
    print("  This is ~0.1-0.2ms slower per file but prevents EMFILE errors", file=sys.stderr)
    print(f"  To use faster mmap mode: ulimit -n {total_files * 2}", file=sys.stderr)
    print("  To suppress this warning: add '--suppress-fd-warnings' flag or config", file=sys.stderr)
    context.warned_low_ulimit = True


def _determine_file_reading_strategy(context: "BuildContext") -> str:
    """Determine which file reading strategy to use for this session.

    Returns:
        'mmap' - Use Str(File(filepath)) directly (best performance)
        'no_mmap' - Use traditional open()/read() (for low ulimit or problematic filesystems)
    """
    if context.file_reading_strategy is not None:
        return context.file_reading_strategy
    args = context.analyzer_args

    # Check for manual overrides first
    if args and not getattr(args, "use_mmap", True):
        strategy = "no_mmap"
        context.file_reading_strategy = strategy
        return strategy

    if args and getattr(args, "force_mmap", False):
        strategy = "mmap"
        context.file_reading_strategy = strategy
        return strategy

    # Get total file count from global hash registry
    try:
        from compiletools.global_hash_registry import get_registry_stats, load_hashes

        load_hashes(context=context)
        stats = get_registry_stats(context=context)
        total_files = stats.get("total_files", 0)
    except (ImportError, AttributeError):
        total_files = 0

    # Query actual OS limit
    try:
        soft_limit, _ = resource.getrlimit(resource.RLIMIT_NOFILE)
    except (OSError, AttributeError):
        soft_limit = 1024  # Reasonable fallback

    # If ulimit is dangerously low (< 100), always use no_mmap mode
    if soft_limit < 100:
        if total_files > 0:
            _warn_low_ulimit(total_files, soft_limit, context)
        strategy = "no_mmap"
        context.file_reading_strategy = strategy
        return strategy

    # Compare file count to available fd limit
    safe_fd_limit = int(soft_limit * 0.9)

    if total_files > 0 and total_files > safe_fd_limit:
        _warn_low_ulimit(total_files, soft_limit, context)
        strategy = "no_mmap"
    else:
        strategy = "mmap"

    context.file_reading_strategy = strategy

    return strategy


def _read_file_with_strategy(filepath: str, strategy: str):
    """Read file using specified strategy.

    Args:
        filepath: Path to file to read
        strategy: 'mmap' or 'no_mmap' (based on ulimit/file count)

    Returns:
        stringzilla.Str object with file contents
    """
    # Strategy is about ulimit/resource constraints
    # Filesystem safety is handled by safe_read_text_file
    force_no_mmap = strategy == "no_mmap"

    return compiletools.filesystem_utils.safe_read_text_file(filepath, encoding="utf-8", force_no_mmap=force_no_mmap)


def set_analyzer_args(args, context: "BuildContext"):
    """Set args for file analysis. Must be called once at build start.

    Args:
        args: Args object containing max_read_size, verbose, exemarkers, testmarkers, librarymarkers
        context: BuildContext where state is stored
    """
    context.analyzer_args = args
    context.file_reading_strategy = None
    _determine_file_reading_strategy(context)


def _load_file_text(filepath: str, file_size: int, max_read_size: int, strategy: str):
    """Load file text into a stringzilla.Str, honoring strategy and truncation.

    Returns:
        tuple: (str_text, bytes_analyzed, was_truncated)
    """
    # Handle empty files - StringZilla cannot memory-map zero-byte files
    if file_size == 0:
        return Str(""), 0, False

    read_entire_file = (max_read_size == 0) or (file_size <= max_read_size)

    if read_entire_file:
        # Read entire file using appropriate strategy
        str_text = _read_file_with_strategy(filepath, strategy)
        return str_text, len(str_text), False

    # Read limited amount using mmap for better performance
    text, bytes_analyzed, was_truncated = read_file_mmap(filepath, max_read_size)
    try:
        str_text = Str(text)
    except UnicodeDecodeError:
        # This shouldn't happen since read_file_mmap decodes with errors='ignore'
        # But if it does, provide useful debugging info
        print(f"ERROR: Failed to create Str from text in {filepath}", file=sys.stderr)
        print(f"  text type: {type(text)}, len: {len(text)}", file=sys.stderr)
        print(f"  First 100 chars: {text[:100]!r}", file=sys.stderr)
        raise
    return str_text, bytes_analyzed, was_truncated


def _compute_line_byte_offsets(str_text) -> list[int]:
    """Build the list of byte offsets where each line begins."""
    line_byte_offsets = [0]  # First line starts at position 0
    pos = str_text.find("\n", 0)
    while pos != -1:
        line_byte_offsets.append(pos + 1)  # Next line starts after newline
        pos = str_text.find("\n", pos + 1)  # Continue from next position
    return line_byte_offsets


def _extract_directives(
    directive_positions: dict[str, list[int]],
    lines: list["stringzilla.Str"],
    line_byte_offsets: list[int],
) -> tuple[list["PreprocessorDirective"], dict[int, "PreprocessorDirective"]]:
    """Extract structured directive records from raw directive positions.

    Honors line continuations (lines ending with backslash). Each line is processed
    only once even if it appears under multiple directive types.
    """
    directives: list[PreprocessorDirective] = []
    directive_by_line: dict[int, PreprocessorDirective] = {}
    processed_lines: set[int] = set()

    for dtype, positions in directive_positions.items():
        for pos in positions:
            # Use binary search on pre-computed line offsets for O(log n) performance
            line_num = bisect.bisect_right(line_byte_offsets, pos) - 1
            if line_num in processed_lines:
                continue

            # Extract directive with continuations using StringZilla
            directive_lines = []
            current_line = line_num
            while current_line < len(lines):
                line = lines[current_line]
                directive_lines.append(line)  # Already StringZilla.Str from splitlines()
                processed_lines.add(current_line)
                if not ends_with_backslash_sz(line):
                    break
                current_line += 1

            # Parse directive
            directive = parse_directive_struct(dtype, pos, line_num, directive_lines)
            directives.append(directive)
            directive_by_line[line_num] = directive

    return directives, directive_by_line


def _extract_includes(
    include_positions: list[int],
    lines: list["stringzilla.Str"],
    line_byte_offsets: list[int],
    str_text: "stringzilla.Str",
) -> list[dict]:
    """Build include records for each #include position."""
    includes: list[dict] = []
    if not include_positions:
        return includes

    for pos in include_positions:
        line_num = bisect.bisect_right(line_byte_offsets, pos) - 1
        line = lines[line_num] if line_num < len(lines) else Str("")  # Already Str from splitlines()

        is_commented = is_position_commented_simd_optimized(str_text, pos, line_byte_offsets)

        # Extract filename and type using StringZilla, replacing regex
        include_keyword_pos = line.find("#include")
        if include_keyword_pos == -1:
            continue

        search_start = include_keyword_pos + 8  # len('#include')

        quote_pos = line.find('"', search_start)
        lt_pos = line.find("<", search_start)

        start_delim_pos = -1
        is_system = False
        end_delim = ""

        if quote_pos != -1 and (lt_pos == -1 or quote_pos < lt_pos):
            start_delim_pos = quote_pos
            end_delim = '"'
            is_system = False
        elif lt_pos != -1:
            start_delim_pos = lt_pos
            end_delim = ">"
            is_system = True

        if start_delim_pos != -1:
            end_delim_pos = line.find(end_delim, start_delim_pos + 1)
            if end_delim_pos != -1:
                filename_slice = line[start_delim_pos + 1 : end_delim_pos]
                includes.append(
                    {
                        "line_num": line_num,
                        "byte_pos": pos,
                        "full_line": line,
                        "filename": filename_slice,
                        "is_system": is_system,
                        "is_commented": is_commented,
                    }
                )

    return includes


def _extract_magic_flags(
    magic_positions: list[int],
    lines: list["stringzilla.Str"],
    line_byte_offsets: list[int],
) -> list[dict]:
    """Build magic-flag records for each //#KEY=value position."""
    magic_flags: list[dict] = []
    if not magic_positions:
        return magic_flags

    for pos in magic_positions:
        line_num = bisect.bisect_right(line_byte_offsets, pos) - 1
        # Use Str("") for the OOB fallback — a bare "" literal makes pyright track
        # ``line`` as ``Str | Literal[""]``, which then propagates LiteralString
        # through slice/split and breaks attribute resolution on the stringzilla
        # surface (find_first_not_of et al.) below.
        line = lines[line_num] if line_num < len(lines) else Str("")

        # Parse magic flag using StringZilla operations - ensure line is Str
        if not isinstance(line, Str):
            line = Str(line)
        hash_pos = line.find("//#")
        if hash_pos == -1:
            continue

        after_hash = line[hash_pos + 3 :]  # Skip //#

        # Use StringZilla split for KEY=value parsing
        equals_parts = after_hash.split("=", maxsplit=1)
        if len(equals_parts) != 2:
            continue

        key_part = equals_parts[0]
        value_part = equals_parts[1]

        # Trim whitespace using StringZilla character set operations
        key_start = key_part.find_first_not_of(" \t")
        if key_start == -1:
            continue
        key_end = key_part.find_last_not_of(" \t")
        key_trimmed = key_part[key_start : key_end + 1]

        # Validate key format using StringZilla character set operations
        if len(key_trimmed) == 0 or not is_alpha_or_underscore_sz(key_trimmed, 0):
            continue

        # Use StringZilla to check if all chars are valid (alphanumeric, _, -)
        invalid_pos = key_trimmed.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")
        if invalid_pos != -1:
            continue

        # Trim value whitespace
        value_start = value_part.find_first_not_of(" \t")
        if value_start != -1:
            value_end = value_part.find_last_not_of(" \t\r\n")
            value_trimmed = value_part[value_start : value_end + 1]
        else:
            value_trimmed = value_part[0:0]  # Empty Str

        magic_flags.append(
            {
                "line_num": line_num,
                "byte_pos": pos,
                "full_line": line,
                "key": key_trimmed,
                "value": value_trimmed,
            }
        )

    return magic_flags


# C++20 module declarations. Recognized at the start of a logical line
# (after stripping leading whitespace, ignoring lines inside block
# comments). Phase 1 of compiletools' modules support handles only the
# three forms below; partition-internal imports (`import :part;`),
# header units (`import "h";`, `import <h>;`), and the global module
# fragment opener (`module;`) are recognized syntactically and skipped.
def _classify_module_line(rest: "stringzilla.Str"):
    """Classify a single source line as a C++20 module declaration.

    `rest` is the line content (already a stringzilla.Str) AFTER leading
    whitespace has been stripped by the caller, AND verified not to be
    inside a block comment.

    Returns ``(kind, name)`` where ``kind`` is one of
    ``"export_module"``, ``"module"``, ``"import"`` -- or ``(None, None)``
    if the line is not a module declaration we want to record.

    Returns ``("header_import", "<vector>")`` or ``("header_import",
    "\"foo.h\"")`` for header units -- the token form (with brackets or
    quotes) is preserved so build_backend can re-emit it on the
    precompile invocation and on the importer's
    ``-fmodule-file=NAME=PATH`` flag.

    Phase 1 deliberately returned ``(None, None)`` for the global module
    fragment opener (``module;``), partition imports (``import :p;``),
    and header units. Phase 3 added partitions; Phase 5 adds header
    units.
    """
    s = str(rest)
    n = len(s)
    if n == 0:
        return None, None

    def is_ident_start(c: str) -> bool:
        return c.isalpha() or c == "_"

    def is_ident_cont(c: str) -> bool:
        return c.isalnum() or c == "_"

    def read_ident(j: int):
        if j >= n or not is_ident_start(s[j]):
            return None, j
        k = j + 1
        while k < n and is_ident_cont(s[k]):
            k += 1
        return s[j:k], k

    def read_dotted_ident(j: int):
        first, j = read_ident(j)
        if first is None:
            return None, j
        parts = [first]
        while j < n and s[j] == ".":
            nxt, jj = read_ident(j + 1)
            if nxt is None:
                return None, j
            parts.append(nxt)
            j = jj
        return ".".join(parts), j

    def read_module_spec(j: int, allow_partition_only: bool):
        """Read a module-name spec: ``M[.dotted][:P[.dotted]]`` or ``:P``.

        ``:P`` is only legal when ``allow_partition_only`` is True (the
        ``import :P;`` form inside a module). The leading ``:`` is
        preserved in the returned string so the consumer can tell the
        partition-only form apart from a fully-qualified ``M:P``.
        """
        # Partition-only form: leading `:`, not the `::` scope operator.
        if j < n and s[j] == ":":
            if not allow_partition_only:
                return None, j
            if j + 1 >= n or s[j + 1] == ":":
                return None, j
            part, jj = read_dotted_ident(j + 1)
            if part is None:
                return None, j
            return ":" + part, jj
        # Otherwise: M[.dotted][:P[.dotted]]
        name, j = read_dotted_ident(j)
        if name is None:
            return None, j
        if j < n and s[j] == ":" and (j + 1 >= n or s[j + 1] != ":"):
            part, jj = read_dotted_ident(j + 1)
            if part is not None:
                return name + ":" + part, jj
        return name, j

    def skip_ws(j: int) -> int:
        while j < n and s[j] in " \t":
            j += 1
        return j

    word1, i = read_ident(0)
    if word1 is None:
        return None, None

    if word1 == "export":
        i = skip_ws(i)
        word2, i = read_ident(i)
        # Allow `export import :P;` / `export import M;` -- common in
        # primary interface units that re-export a partition or another
        # module. We only need to classify the underlying token kind, so
        # treat `export import` as `import` (the export wrapper doesn't
        # change which other TUs the importer needs).
        if word2 == "import":
            i = skip_ws(i)
            if i >= n:
                return None, None
            if s[i] in ("<", '"'):
                return None, None
            name, i = read_module_spec(i, allow_partition_only=True)
            if name is None:
                return None, None
            i = skip_ws(i)
            if i >= n or s[i] != ";":
                return None, None
            return "import", name
        if word2 != "module":
            return None, None
        i = skip_ws(i)
        name, i = read_module_spec(i, allow_partition_only=False)
        if name is None:
            return None, None
        i = skip_ws(i)
        if i >= n or s[i] != ";":
            return None, None
        return "export_module", name

    if word1 == "module":
        i = skip_ws(i)
        # `module;` is the global module fragment opener -- not a name
        # declaration, ignore. `module NAME;` is an implementation unit.
        if i < n and s[i] == ";":
            return None, None
        name, i = read_module_spec(i, allow_partition_only=False)
        if name is None:
            return None, None
        i = skip_ws(i)
        if i >= n or s[i] != ";":
            return None, None
        return "module", name

    if word1 == "import":
        i = skip_ws(i)
        if i >= n:
            return None, None
        # Header unit: `import <h>;` or `import "h";`. Capture the
        # token verbatim (including brackets/quotes) so the build
        # backend can re-emit it as the header-name argument to the
        # precompile and as the lookup key in clang's
        # `-fmodule-file=<h>=<path>` flag.
        if s[i] == "<":
            close = s.find(">", i + 1)
            if close == -1:
                return None, None
            tok = s[i : close + 1]
            j = skip_ws(close + 1)
            if j >= n or s[j] != ";":
                return None, None
            return "header_import", tok
        if s[i] == '"':
            close = s.find('"', i + 1)
            if close == -1:
                return None, None
            tok = s[i : close + 1]
            j = skip_ws(close + 1)
            if j >= n or s[j] != ";":
                return None, None
            return "header_import", tok
        name, i = read_module_spec(i, allow_partition_only=True)
        if name is None:
            return None, None
        i = skip_ws(i)
        if i >= n or s[i] != ";":
            return None, None
        return "import", name

    return None, None


def _extract_module_declarations(
    str_text: "stringzilla.Str",
    line_byte_offsets: list[int],
) -> dict[str, list[str]]:
    """Find every C++20 module declaration in a source.

    Walks lines, ignores lines whose first non-whitespace position is
    inside a block comment, and delegates per-line classification to
    ``_classify_module_line``.

    Returns a dict with four keys -- ``"export_module"``, ``"module"``,
    ``"import"``, ``"header_import"`` -- mapping to lists of names in
    source order. ``header_import`` entries preserve the token form
    (with ``<...>`` or ``"..."``) so the build backend can re-emit them.
    """
    result: dict[str, list[str]] = {
        "export_module": [],
        "module": [],
        "import": [],
        "header_import": [],
    }
    n = len(str_text)
    if n == 0 or not line_byte_offsets:
        return result

    line_count = len(line_byte_offsets)
    for i in range(line_count):
        start = line_byte_offsets[i]
        end = line_byte_offsets[i + 1] if i + 1 < line_count else n
        line = str_text[start:end]
        first_nws = line.find_first_not_of(" \t")
        if first_nws == -1:
            continue
        kw_pos = start + first_nws
        if is_inside_block_comment_simd(str_text, kw_pos):
            continue
        rest = line[first_nws:]
        kind, name = _classify_module_line(rest)
        if kind is not None and name is not None:
            result[kind].append(name)
    return result


def _extract_defines(
    define_positions: list[int],
    lines: list["stringzilla.Str"],
    line_byte_offsets: list[int],
    include_guard: Optional["stringzilla.Str"],
) -> list[dict]:
    """Build define records, excluding the include guard if set."""
    defines: list[dict] = []
    for pos in define_positions:
        line_num = bisect.bisect_right(line_byte_offsets, pos) - 1

        # Get all lines including continuations using StringZilla
        define_lines = []
        current_line = line_num
        while current_line < len(lines):
            line = lines[current_line]
            define_lines.append(line)  # Already StringZilla.Str from splitlines()
            if not ends_with_backslash_sz(line):
                break
            current_line += 1

        # Parse define using StringZilla, replacing regex
        if not define_lines:
            continue

        first_line = define_lines[0]
        define_kw_pos = first_line.find("#define")
        if define_kw_pos == -1:
            continue

        # Find start of macro name
        name_start_pos = first_line.find_first_not_of(" \t", define_kw_pos + 7)
        if name_start_pos == -1:
            continue

        # Join lines for parsing complex defines using StringZilla
        full_define_str = join_lines_strip_backslash_sz(define_lines)

        # Find macro name part in the joined string
        name_part_start = full_define_str.find_first_not_of(" \t", full_define_str.find("#define") + 7)

        # Find end of name (space or parenthesis)
        paren_pos = full_define_str.find("(", name_part_start)
        space_pos = full_define_str.find_first_of(" \t", name_part_start)

        name_end_pos = -1
        if paren_pos != -1 and (space_pos == -1 or paren_pos < space_pos):
            name_end_pos = paren_pos
        else:
            name_end_pos = space_pos

        if name_end_pos == -1:  # Macro without value
            name = full_define_str[name_part_start:]
            value = None
            is_function_like = False
            params = []
        else:
            name = full_define_str[name_part_start:name_end_pos]

            # Check for function-like macro
            is_function_like = paren_pos == name_end_pos
            if is_function_like:
                params_end_pos = full_define_str.find(")", paren_pos + 1)
                if params_end_pos != -1:
                    params_str = full_define_str[paren_pos + 1 : params_end_pos]
                    params = [strip_sz(p) for p in params_str.split(",")] if params_str else []
                    value_start_pos = full_define_str.find_first_not_of(" \t", params_end_pos + 1)
                else:  # Malformed
                    params = []
                    value_start_pos = -1
            else:
                params = []
                value_start_pos = full_define_str.find_first_not_of(" \t", name_end_pos)

            if value_start_pos != -1:
                value = strip_sz(full_define_str[value_start_pos:])
            else:
                value = None

        # Skip include guard - it's tracked separately and doesn't affect compilation
        if include_guard and name == include_guard:
            continue

        defines.append(
            {
                "line_num": line_num,
                "byte_pos": pos,
                "lines": define_lines,
                "name": name,
                "value": value if value else None,
                "is_function_like": is_function_like,
                "params": params,
            }
        )

    return defines


def _detect_marker_type(
    str_text,
    exe_markers: list,
    test_markers: list,
    library_markers: list,
) -> MarkerType:
    """Detect EXE/TEST/LIBRARY marker type by scanning the source text.

    Priority is intentional: EXE > TEST > LIBRARY. The first matching list
    short-circuits the rest, mirroring the cumulative-flag check in the
    pre-decompose orchestrator.
    """
    if exe_markers:
        for marker in exe_markers:
            if str_text.count(marker) > 0:
                return MarkerType.EXE

    if test_markers:
        for marker in test_markers:
            if str_text.count(marker) > 0:
                return MarkerType.TEST

    if library_markers:
        for marker in library_markers:
            if str_text.count(marker) > 0:
                return MarkerType.LIBRARY

    return MarkerType.NONE


def analyze_file(content_hash: str, context: "BuildContext") -> "FileAnalysisResult":
    """File analysis with per-context caching - content hash based.

    Args:
        content_hash: Git blob hash of file content
        context: BuildContext where cache and args are stored

    Raises:
        FileNotFoundError: If file with given hash not found
        RuntimeError: If analyzer args not set via set_analyzer_args()
    """
    cached = context.analyze_file_cache.get(content_hash)
    if cached is not None:
        return cached

    if context.analyzer_args is None:
        raise RuntimeError("analyze_file: analyzer args not set on context. Call set_analyzer_args() first.")

    args = context.analyzer_args

    # Reverse lookup to get filepath (already realpath from registry)
    from compiletools.global_hash_registry import get_filepath_by_hash

    filepath = get_filepath_by_hash(content_hash, context)

    # Extract parameters from args
    max_read_size = getattr(args, "max_read_size", 0)
    exe_markers = getattr(args, "exemarkers", [])
    test_markers = getattr(args, "testmarkers", [])
    library_markers = getattr(args, "librarymarkers", [])

    file_size = compiletools.wrappedos.getsize(filepath)

    # Determine file reading strategy and read file content
    strategy = _determine_file_reading_strategy(context)
    str_text, bytes_analyzed, was_truncated = _load_file_text(filepath, file_size, max_read_size, strategy)

    # Use StringZilla's splitlines for optimal line processing
    lines = str_text.splitlines()

    # Build line_byte_offsets efficiently in a single pass
    line_byte_offsets = _compute_line_byte_offsets(str_text)

    # Find all pattern positions using optimized StringZilla bulk operations
    include_positions = find_include_positions_simd_bulk(str_text, line_byte_offsets)
    magic_positions = find_magic_positions_simd_bulk(str_text, line_byte_offsets)
    directive_positions = find_directive_positions_simd_bulk(str_text, line_byte_offsets)

    # Extract structured directive information
    directives, directive_by_line = _extract_directives(directive_positions, lines, line_byte_offsets)

    # Extract includes with full information using bulk processing
    includes = _extract_includes(include_positions, lines, line_byte_offsets, str_text)

    # Extract magic flags with full information using StringZilla operations
    magic_flags = _extract_magic_flags(magic_positions, lines, line_byte_offsets)

    # Sort directives by line number for correct guard detection
    # The directives list is built by iterating directive_positions.items()
    # which processes by directive TYPE, not line number order
    directives_sorted = sorted(directives, key=lambda d: d.line_num)

    # Detect include guard first so we can exclude it from defines
    include_guard = detect_include_guard(directives_sorted)

    # Extract defines with full information (excluding include guard)
    defines = _extract_defines(directive_positions.get("define", []), lines, line_byte_offsets, include_guard)

    # Extract unique headers
    system_headers = {inc["filename"] for inc in includes if inc["is_system"]}
    quoted_headers = {inc["filename"] for inc in includes if not inc["is_system"]}

    # Extract macros referenced in conditionals (for cache optimization)
    conditional_macros = _extract_conditional_macros(directives)

    # Extract static undef targets (macro names from all #undef directives)
    undef_targets = frozenset(d.macro_name for d in directives if d.directive_type == "undef" and d.macro_name)

    # Detect marker type - check for exe, test, or library markers
    marker_type = _detect_marker_type(str_text, exe_markers, test_markers, library_markers)

    # C++20 module declarations (Phase 1: name-only modules; partitions
    # and header units are skipped at the classifier).
    module_decls = _extract_module_declarations(str_text, line_byte_offsets)

    result = FileAnalysisResult(
        line_count=len(lines),
        line_byte_offsets=line_byte_offsets,
        include_positions=include_positions,
        magic_positions=magic_positions,
        directive_positions=directive_positions,
        directives=directives,
        directive_by_line=directive_by_line,
        bytes_analyzed=bytes_analyzed,
        was_truncated=was_truncated,
        includes=includes,
        magic_flags=magic_flags,
        defines=defines,
        system_headers=system_headers,
        quoted_headers=quoted_headers,
        content_hash=content_hash,
        include_guard=include_guard,
        conditional_macros=conditional_macros,
        undef_targets=undef_targets,
        marker_type=marker_type,
        module_exports=tuple(module_decls["export_module"]),
        module_implements=tuple(module_decls["module"]),
        module_imports=tuple(module_decls["import"]),
        module_header_imports=tuple(module_decls["header_import"]),
    )

    context.analyze_file_cache[content_hash] = result
    return result


def cache_clear(context: "BuildContext"):
    """Clear the file analysis cache and reset analyzer args."""
    context.analyzer_args = None
    context.file_reading_strategy = None
    context.warned_low_ulimit = False
    context.analyze_file_cache.clear()


def get_cache_stats(context: "BuildContext"):
    """Get cache statistics from context cache."""
    cache_size = len(context.analyze_file_cache)
    return {
        "cache_size": cache_size,
    }


def print_cache_stats(context: "BuildContext"):
    """Print cache statistics."""
    stats = get_cache_stats(context)

    print("\n=== FileAnalyzer Cache Statistics ===")
    print(f"Cache size:     {stats['cache_size']:,}")


def read_file_mmap(filepath, max_size=0):
    """Use memory-mapped I/O for large files with fallback to traditional reading.

    Args:
        filepath: Path to file to read
        max_size: Maximum bytes to read (0 = entire file)

    Returns:
        tuple: (text_content, bytes_analyzed, was_truncated)
    """
    try:
        file_size = compiletools.wrappedos.getsize(filepath)

        # Handle empty files (mmap fails on zero-byte files)
        if file_size == 0:
            return "", 0, False

        with builtins.open(filepath, "rb") as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            if max_size > 0 and max_size < file_size:
                data = mm[:max_size]
                bytes_analyzed = max_size
                was_truncated = True
            else:
                data = mm[:]
                bytes_analyzed = len(data)
                was_truncated = False

            text = data.decode("utf-8", errors="ignore")
            return text, bytes_analyzed, was_truncated

    except (OSError, ValueError):
        # Fallback to traditional reading on any mmap failure
        return read_file_traditional(filepath, max_size)


def read_file_traditional(filepath, max_size=0):
    """Traditional file reading fallback.

    Args:
        filepath: Path to file to read
        max_size: Maximum bytes to read (0 = entire file)

    Returns:
        tuple: (text_content, bytes_analyzed, was_truncated)
    """
    try:
        file_size = compiletools.wrappedos.getsize(filepath)

        with builtins.open(filepath, encoding="utf-8", errors="ignore") as f:
            if max_size > 0 and max_size < file_size:
                text = f.read(max_size)
                bytes_analyzed = len(text.encode("utf-8"))
                was_truncated = True
            else:
                text = f.read()
                bytes_analyzed = len(text.encode("utf-8"))
                was_truncated = False

        return text, bytes_analyzed, was_truncated

    except (OSError, ValueError):
        # Return empty content on any error
        return "", 0, False


@dataclass
class PreprocessorDirective:
    """A preprocessor directive with all its content."""

    line_num: int  # Starting line number (0-based)
    byte_pos: int  # Byte position in original file
    directive_type: str  # 'if', 'ifdef', 'ifndef', 'elif', 'else', 'endif', 'define', 'undef', 'include'
    continuation_lines: int  # Number of continuation lines (for multi-line directives)
    condition: Optional["stringzilla.Str"] = None  # The condition expression (for if/ifdef/ifndef/elif)
    macro_name: Optional["stringzilla.Str"] = None  # Macro name (for define/undef/ifdef/ifndef)
    macro_value: Optional["stringzilla.Str"] = None  # Macro value (for define)


def _extract_conditional_macros(directives: list[PreprocessorDirective]) -> frozenset["stringzilla.Str"]:
    """Extract all macro names referenced in conditional directives.

    Returns frozenset of sz.Str macro names from ifdef/ifndef/if/elif conditions.
    Used for cache optimization - files are effectively invariant when none
    of these macros are defined.
    """

    macros = set()

    for directive in directives:
        if directive.directive_type in ("ifdef", "ifndef"):
            if directive.macro_name:
                macros.add(directive.macro_name)
        elif directive.directive_type in ("if", "elif", "include"):
            if directive.condition:
                # Extract identifiers from condition using stringzilla
                cond = directive.condition
                keywords = {"and", "or", "not", "true", "false", "defined"}

                i = 0
                while i < len(cond):
                    # Skip non-identifier chars
                    if not is_alpha_or_underscore_sz(cond, i):
                        i += 1
                        continue

                    # Found start of identifier - vectorized
                    start = i
                    identifier_end = cond.find_first_not_of(
                        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_", start
                    )
                    i = identifier_end if identifier_end != -1 else len(cond)

                    # Extract identifier
                    identifier = cond[start:i]
                    name = str(identifier)

                    if name not in keywords:
                        macros.add(identifier)

    return frozenset(macros)


def detect_include_guard(directives: list[PreprocessorDirective]) -> Optional["stringzilla.Str"]:
    """Detect include guard macro from preprocessor directives.

    Supports both traditional include guards (#ifndef/#define) and #pragma once.
    Returns the guard macro name as StringZilla.Str or sz.Str("pragma_once") for #pragma once.

    Include guard detection is STRICT to avoid false positives:
    - #pragma once must be among the first 3 directives
    - #ifndef/#define pattern must start at the FIRST directive
    - The matching #endif must be the LAST (or near-last) directive
    - This avoids misidentifying feature flag patterns like:
        #ifndef ENABLE_FEATURE
        #define ENABLE_FEATURE
        #endif
        // ... rest of file
    """
    import stringzilla as sz

    if not directives:
        return None

    # Check for #pragma once first (must be early in file)
    # Note: pragma directives have macro_name set (e.g., "once")
    for directive in directives[:3]:  # Only first 3 directives
        if directive.directive_type == "pragma":
            # Check macro_name for "once" (how parse_directive_struct stores it)
            if directive.macro_name and str(directive.macro_name) == "once":
                return sz.Str("pragma_once")
            # Also check condition in case it's stored there
            if directive.condition and "once" in str(directive.condition):
                return sz.Str("pragma_once")

    # Check for traditional include guard pattern: #ifndef GUARD followed by #define GUARD
    # STRICT: Must start at the FIRST directive to be a true include guard
    # AND the matching #endif must be the LAST directive (wraps entire file)
    if len(directives) < 3:  # Need at least #ifndef, #define, #endif
        return None

    first_directive = directives[0]
    last_directive = directives[-1]

    # The last directive must be #endif for this to be an include guard
    if last_directive.directive_type != "endif":
        return None

    if first_directive.directive_type == "ifndef" and first_directive.macro_name:
        guard_candidate = first_directive.macro_name

        # Look ahead up to 5 positions for the matching #define
        # This handles cases where comments or other directives appear between
        # the #ifndef and the matching #define
        for j in range(1, min(6, len(directives))):
            if (
                directives[j].directive_type == "define"
                and directives[j].macro_name
                and directives[j].macro_name == guard_candidate
            ):
                # guard_candidate is already sz.Str from PreprocessorDirective.macro_name
                return guard_candidate

    return None


@dataclass
class FileAnalysisResult:
    """Complete structured result without text field.

    Provides all information needed by consumers without requiring text reconstruction.
    """

    # Line-level data (for SimplePreprocessor) - required fields first
    line_count: int  # Number of lines in the file
    line_byte_offsets: list[int]  # Byte offset where each line starts

    # Position arrays (for fast lookups) - required fields
    include_positions: list[int]  # Byte positions of #include directives
    magic_positions: list[int]  # Byte positions of //#KEY= patterns
    directive_positions: dict[str, list[int]]  # Byte positions by directive type

    # Preprocessor directives (structured for SimplePreprocessor) - required fields
    directives: list[PreprocessorDirective]  # All directives with full context
    directive_by_line: dict[int, PreprocessorDirective]  # Line number -> directive mapping

    # Metadata - required fields
    bytes_analyzed: int  # Bytes analyzed from file
    was_truncated: bool  # Whether file was truncated

    # Optional fields with defaults come last
    includes: list[dict] = field(default_factory=list)
    # Each include dict contains:
    # {
    #   'line_num': int,                # Line number (0-based)
    #   'byte_pos': int,                # Byte position
    #   'full_line': str,               # Complete include line (str for compatibility)
    #   'filename': stringzilla.Str,    # Extracted filename
    #   'is_system': bool,              # True for <>, False for ""
    #   'is_commented': bool,           # True if in comment
    # }

    magic_flags: list[dict] = field(default_factory=list)
    # Each magic flag dict contains:
    # {
    #   'line_num': int,           # Line number (0-based)
    #   'byte_pos': int,                 # Byte position
    #   'full_line': stringzilla.Str,   # Complete line with //#KEY=value
    #   'key': stringzilla.Str,          # The KEY part
    #   'value': stringzilla.Str,        # The value part
    # }

    defines: list[dict] = field(default_factory=list)
    # Each define dict contains:
    # {
    #   'line_num': int,                        # Starting line number
    #   'byte_pos': int,                        # Byte position
    #   'lines': List[stringzilla.Str],         # All lines including continuations
    #   'name': stringzilla.Str,                # Macro name
    #   'value': Optional[stringzilla.Str],     # Macro value (if any)
    #   'is_function_like': bool,               # True for function-like macros
    #   'params': List[stringzilla.Str],        # Parameters for function-like macros
    # }

    system_headers: set[str] = field(default_factory=set)  # Unique system headers found
    quoted_headers: set[str] = field(default_factory=set)  # Unique quoted headers found
    content_hash: str = ""  # SHA1 of original content
    include_guard: Optional["stringzilla.Str"] = (
        None  # Include guard macro name (traditional) or sz.Str("pragma_once") for #pragma once
    )
    conditional_macros: frozenset["stringzilla.Str"] = field(
        default_factory=frozenset
    )  # Macros referenced in conditionals (for cache optimization)
    undef_targets: frozenset["stringzilla.Str"] = field(
        default_factory=frozenset
    )  # Macro names from all #undef directives (static, input-independent)
    marker_type: MarkerType = MarkerType.NONE  # Type of marker found in file (exe, test, library, or none)

    # C++20 module declarations. See _extract_module_declarations for the
    # forms recognized in Phase 1; partition imports, header units, and
    # the global module fragment opener are deliberately not surfaced.
    module_exports: tuple[str, ...] = ()  # `export module NAME;`
    module_implements: tuple[str, ...] = ()  # `module NAME;` (impl unit)
    module_imports: tuple[str, ...] = ()  # `import NAME;`
    module_header_imports: tuple[str, ...] = ()  # `import <h>;` / `import "h";`

    # Helper method for SimplePreprocessor compatibility
    def get_directive_line_numbers(self) -> dict[str, set[int]]:
        """Get line numbers for each directive type (for SimplePreprocessor)."""
        result = {}
        for dtype, positions in self.directive_positions.items():
            line_nums = set()
            for pos in positions:
                # Binary search in line_byte_offsets to find line number
                line_num = bisect.bisect_right(self.line_byte_offsets, pos) - 1
                line_nums.add(line_num)
            result[dtype] = line_nums
        return result


class FileAnalyzer:
    """Namespace for file-analyzer command-line arguments.

    The module-level ``analyze_file()`` is the canonical entry point for file
    analysis; this class only exists to host ``add_arguments`` for backward
    compatibility with existing call sites in ``findtargets`` and ``headerdeps``.
    """

    @staticmethod
    def add_arguments(cap):
        """Add file analyzer specific arguments.

        Safe to call more than once on the same parser.

        Args:
            cap: ConfigArgParse parser instance
        """
        import compiletools.apptools
        import compiletools.utils

        if compiletools.apptools._parser_has_option(cap, "--use-mmap"):
            return

        # Manual overrides for testing/debugging
        compiletools.utils.add_flag_argument(
            parser=cap,
            name="use-mmap",
            dest="use_mmap",
            default=True,
            help="Use mmap for file reading. Disable with --no-use-mmap for GPFS, SMB/CIFS, etc.",
        )

        compiletools.utils.add_flag_argument(
            parser=cap,
            name="force-mmap",
            dest="force_mmap",
            default=False,
            help="Force mmap mode even on low ulimit systems (for testing/debugging)",
        )

        # Warning suppression
        compiletools.utils.add_flag_argument(
            parser=cap,
            name="suppress-fd-warnings",
            dest="suppress_fd_warnings",
            default=False,
            help="Suppress file descriptor limit warnings",
        )

        compiletools.utils.add_flag_argument(
            parser=cap,
            name="suppress-filesystem-warnings",
            dest="suppress_filesystem_warnings",
            default=False,
            help="Suppress filesystem compatibility warnings",
        )
