"""Verifying-traces build backends: Shake (local threads) and Slurm (HPC cluster).

Both backends implement the Shake rebuild strategy from "Build Systems à la Carte"
(Mokhov, Mitchell, Jones 2018), specifically:
- Suspending scheduler: build dependencies on-demand recursively
- Verifying traces: content-hash-based change detection for minimal rebuilds
- Early cutoff: if rebuilt output is byte-identical, skip rebuilding dependents

Content-addressable short-circuit: compile rules produce output filenames that
encode source hash, dependency hash, and macro state hash.  If such an output
already exists on disk it is correct by construction, so verifying traces
degenerates to a single os.path.exists() call — skipping all hashing, trace
lookup, and input comparison for no-op rebuilds.

ShakeBackend drives compilation directly from Python using asyncio coroutines
with a semaphore to limit subprocess concurrency.

SlurmBackend replaces the async compile phase with batch Slurm job
submission, distributing compile rules across an HPC cluster:

1. Identify compile rules that need rebuilding (trace verify).
2. Submit all of them to Slurm as job arrays (``sbatch --array``).
3. Poll ``sacct`` until every task reaches a terminal state.
4. Record traces for successfully compiled outputs.
5. Run link/library rules locally (they are few, fast, and serial-dependent).
6. Save traces.

Assumes a shared network filesystem (GPFS, Lustre, NFS, etc.) visible to
both the submission node and all compute nodes — source files, object
directories, and the working directory must be accessible at the same
paths on every node.  The implementation accounts for metadata-visibility
lag common on network filesystems (fsync before close, polling for output
files after job completion).

The dependency graph is static (pre-computed by Hunter), not dynamic as in the
original Shake (which uses monadic tasks for dynamic dependency discovery).
This is sufficient because compiletools resolves all dependencies at a higher
level before the backend executes.

No external build tool required for either backend — both drive compilation
directly from Python.
"""

from __future__ import annotations

import argparse
import asyncio
import collections
import contextlib
import datetime
import glob
import hashlib
import json
import logging
import os
import shlex
import signal
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from typing import ClassVar

import compiletools.apptools
import compiletools.diagnostics
import compiletools.filesystem_utils
import compiletools.git_utils
import compiletools.wrappedos
from compiletools.build_backend import (
    _ORDER_ONLY_DEP_FORBIDDEN_EXTS,
    BuildBackend,
    _compiler_identity,
    register_backend,
)
from compiletools.build_graph import BuildGraph, BuildRule, RuleType
from compiletools.global_hash_registry import get_file_hash
from compiletools.locking import execute_compile_rule, execute_link_rule

logger = logging.getLogger(__name__)

TRACE_VERSION = 1

# LD_LIBRARY_PATH is included because non-system-installed compilers (Spack, Lmod,
# environment modules, custom installs) almost always need it to find their shared
# libs on the compute node. Other HPC vars (MODULEPATH, LMOD_*, SPACK_ROOT, etc.)
# are deliberately excluded — sites using those toolchains can extend this via
# --slurm-export.
_DEFAULT_SLURM_EXPORT = "PATH,HOME,USER,LANG,LC_ALL,CC,CXX,CPATH,LD_LIBRARY_PATH"


@dataclass
class TraceEntry:
    """Record of a successful build action for verifying traces."""

    output_hash: str
    input_hashes: dict[str, str]
    command_hash: str


class TraceStore:
    """Persistent store for build traces, backed by JSON on disk."""

    def __init__(self, path: str):
        self._path = path
        self._traces: dict[str, TraceEntry] = {}
        self._load()

    def _load(self) -> None:
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path) as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            logger.warning("trace store %s is corrupt (%s); discarding", self._path, e)
            self._traces = {}
            return
        if not isinstance(data, dict) or data.get("version") != TRACE_VERSION:
            return
        for output, entry_dict in data.get("traces", {}).items():
            try:
                self._traces[output] = TraceEntry(**entry_dict)
            except (KeyError, TypeError) as e:
                logger.warning("dropping corrupt trace entry for %s: %s", output, e)

    def get(self, output: str) -> TraceEntry | None:
        return self._traces.get(output)

    def put(self, output: str, entry: TraceEntry) -> None:
        self._traces[output] = entry

    def save(self) -> None:
        data = {
            "version": TRACE_VERSION,
            "traces": {output: asdict(entry) for output, entry in self._traces.items()},
        }
        with compiletools.filesystem_utils.atomic_output_file(self._path, mode="w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, sort_keys=True)


def _canonicalize_cmd_for_hash(cmd: list[str], anchor_root: str) -> list[str]:
    """Anchor-relative every path token in *cmd* for stable cross-workspace hashing.

    Two passes are needed because path-bearing flags appear in two forms:
    attached (``-I/abs/path``) and bare-positional (``-c /abs/path/foo.cpp``,
    ``/abs/path/foo.o``). ``canonicalize_for_cache_key`` handles the
    flag-attached forms (recognises ``-I``/``-isystem``/``-iquote``/``-include``
    /``-include-pch``/``-F``/``-B``/``-idirafter``); the second pass then
    rewrites any remaining bare absolute-path tokens that live under
    *anchor_root*. Tokens outside *anchor_root* and non-path tokens pass
    through unchanged in both passes.
    """
    if not anchor_root:
        return list(cmd)
    flag_canonicalized = compiletools.apptools.canonicalize_for_cache_key(list(cmd), anchor_root)
    return compiletools.apptools.canonicalize_paths_for_cache_key(flag_canonicalized, anchor_root)


def hash_command(cmd: list[str], compiler_identity: str | None = None) -> str:
    """Compute a stable hash of a shell command list.

    *compiler_identity* folds in the resolved binary's realpath + size + mtime
    for the tool that runs the command, so an in-place compiler upgrade
    invalidates traces even when the argv is byte-identical.

    Callers wanting cross-workspace stability must pre-canonicalize *cmd*
    via ``_canonicalize_cmd_for_hash`` so absolute paths embedded in the
    argv (-c <src>, -o <out>, -I/abs/path, ...) become anchor-relative.
    """
    payload = [compiler_identity, cmd] if compiler_identity is not None else cmd
    return hashlib.sha256(json.dumps(payload, sort_keys=False).encode()).hexdigest()


def _is_build_artifact(rule) -> bool:
    """Rules whose output names encode all inputs — existence implies correctness."""
    return rule.rule_type in (RuleType.COMPILE, RuleType.LINK, RuleType.STATIC_LIBRARY, RuleType.SHARED_LIBRARY)


def _parse_slurm_elapsed(elapsed_str: str) -> float:
    """Parse sacct Elapsed field (HH:MM:SS or D-HH:MM:SS) to seconds."""
    days = 0
    if "-" in elapsed_str:
        day_part, elapsed_str = elapsed_str.split("-", 1)
        days = int(day_part)
    parts = elapsed_str.split(":")
    if len(parts) == 3:
        return days * 86400 + int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    if len(parts) == 2:
        return days * 86400 + int(parts[0]) * 60 + float(parts[1])
    return float(elapsed_str)


def _make_trace_entry(rule: BuildRule, context, output_hash: str | None = None) -> TraceEntry:
    """Build a TraceEntry for a successfully executed rule.

    Pass *output_hash* when already computed (avoids a redundant disk read).
    """
    assert rule.command is not None, "only call _make_trace_entry after a rule executes"
    if output_hash is None and not os.path.isfile(rule.output):
        raise RuntimeError(
            f"_make_trace_entry: rule {rule.output!r} executed successfully but its "
            f"output file is missing. The rule's command may have side-effect-only "
            f"semantics (e.g., a test rule whose success_marker was never touched) "
            f"and should not be in the trace-execution path."
        )
    # Anchor the input keys to gitroot so a trace written under workspace A
    # verifies under workspace B (cross-CI-runner CAS reuse). Mirrors the
    # 9.1.0 path-canonical CAS-key fix for per-TU object / PCH / PCM caches;
    # without it, _verify's set-equality check on input_hashes keys rejects
    # every cross-workspace hit even when the cached output is byte-identical.
    anchor_root = compiletools.git_utils.find_git_root()
    input_hashes = {}
    for p in rule.inputs:
        if os.path.isfile(p):
            key = compiletools.apptools.canonicalize_path_for_cache_key(compiletools.wrappedos.realpath(p), anchor_root)
            input_hashes[key] = get_file_hash(p, context)
        else:
            logger.debug("_make_trace_entry: skipping non-file input %s for %s", p, rule.output)
    identity = _compiler_identity(rule.command[0], anchor_root=anchor_root) if rule.command else None
    canonical_cmd = _canonicalize_cmd_for_hash(rule.command, anchor_root)
    return TraceEntry(
        output_hash=output_hash if output_hash is not None else get_file_hash(rule.output, context),
        input_hashes=input_hashes,
        command_hash=hash_command(canonical_cmd, compiler_identity=identity),
    )


@register_backend
class ShakeBackend(BuildBackend):
    """Self-executing backend using Shake-style verifying traces."""

    def __init__(self, args, hunter, *, context=None):
        super().__init__(args, hunter, context=context)
        self._graph: BuildGraph | None = None
        # Test rules run in-process during the build phase. A failing test
        # appends here instead of raising from inside the rule executor --
        # raising mid-flight would abort sibling rules that asyncio.gather
        # already has in flight. The aggregated list is raised as a single
        # RuntimeError once the top-level traversal in execute() returns.
        self._test_failures: list[str] = []

    @staticmethod
    def name() -> str:
        return "shake"

    @staticmethod
    def tool_command() -> str | None:
        # Self-executing — runs each rule directly via subprocess.
        return None

    @staticmethod
    def build_filename() -> str:
        return ".ct-traces.json"

    def generate(self, graph: BuildGraph, output=None) -> None:
        self._graph = graph
        if output is not None:
            self._write_summary(graph, output)

    def _write_summary(self, graph: BuildGraph, f) -> None:
        f.write("# Shake build graph summary\n\n")
        for rule in graph.rules:
            if rule.rule_type == RuleType.PHONY:
                f.write(f"phony {rule.output}: {' '.join(rule.inputs)}\n")
            elif rule.command:
                f.write(f"{rule.rule_type} {rule.output}:\n")
                f.write(f"  inputs: {' '.join(rule.inputs)}\n")
                f.write(f"  command: {' '.join(rule.command)}\n")
        f.write("\n")

    def _ca_target(self, rule: BuildRule) -> str:
        """Content-addressable output path for a link/library rule.

        Hashes sorted inputs + command (with output path stripped to avoid
        circularity).  The CA filename lives alongside the human-readable
        output so directory creation is already handled.
        """
        assert rule.command is not None, "_ca_target only applies to link/library rules"
        cmd_filtered = [a for a in rule.command if a != rule.output]
        key = json.dumps({"inputs": sorted(rule.inputs), "cmd": cmd_filtered}, sort_keys=True)
        h = hashlib.sha256(key.encode()).hexdigest()[:20]
        base = os.path.basename(rule.output)
        name, ext = os.path.splitext(base)
        return os.path.join(os.path.dirname(rule.output), f"{name}_{h}{ext}")

    def _execute_build(self, target: str) -> None:
        # Not used: ShakeBackend overrides execute() with its own build engine.
        del target
        raise NotImplementedError  # pragma: no cover

    def execute(self, target: str = "build") -> None:
        """Run the Shake build engine.

        ``execute("build")`` is retargeted to the ``all`` phony, whose
        transitive deps include ``runtests`` -> every test rule fires the
        moment its exe's link future resolves. ``execute("runtests")`` walks
        the ``runtests`` phony directly so a standalone test run uses the
        same native, in-process ``RuleType.TEST`` rules as the in-build path.
        """
        if self._graph is None:
            raise RuntimeError("generate() must be called before execute()")

        if target == "runtests":
            walk_target = "runtests" if self._graph.get_rule("runtests") is not None else target
        elif target == "build":
            walk_target = "all" if self._graph.get_rule("all") is not None else target
        else:
            walk_target = target

        # Each execute() call is a fresh top-level traversal; clear any
        # aggregated failures from a prior call on the same backend instance.
        self._test_failures = []

        trace_path = os.path.join(self.args.cas_objdir, self.build_filename())
        traces = TraceStore(trace_path)

        parallel = getattr(self.args, "parallel", 1)
        max_workers = parallel if parallel and parallel > 0 else 1
        sem = asyncio.Semaphore(max_workers)
        memo: dict[str, asyncio.Task[bool]] = {}

        try:
            asyncio.run(self._build_async(walk_target, self._graph, traces, memo, sem))
        finally:
            traces.save()

        # A failed test only appended to _test_failures (so sibling rules
        # already in flight could finish); surface the aggregate now so a
        # failing test makes ct-cake exit non-zero.
        if self._test_failures:
            raise RuntimeError("test execution failed:\n  " + "\n  ".join(self._test_failures))

    async def _build_async(
        self,
        target: str,
        graph: BuildGraph,
        traces: TraceStore,
        memo: dict[str, asyncio.Task[bool]],
        sem: asyncio.Semaphore,
    ) -> bool:
        """Async suspending scheduler with verifying traces and early cutoff.

        Uses asyncio.gather for fan-out (no deadlock risk) and a semaphore
        to limit subprocess concurrency.  Memoization via the memo dict
        ensures each target is built at most once (diamond deps await the
        same task).

        Returns True if the target's output changed (dependents should rebuild).
        """
        if target not in memo:
            memo[target] = asyncio.ensure_future(self._do_build(target, graph, traces, memo, sem))
        return await memo[target]

    async def _do_build(
        self,
        target: str,
        graph: BuildGraph,
        traces: TraceStore,
        memo: dict[str, asyncio.Task[bool]],
        sem: asyncio.Semaphore,
    ) -> bool:
        """Build a single target, recursing into dependencies via gather."""
        rule = graph.get_rule(target)
        if rule is None:
            return False  # Leaf node (source/header file)

        if rule.rule_type == RuleType.PHONY:
            results = await asyncio.gather(*(self._build_async(inp, graph, traces, memo, sem) for inp in rule.inputs))
            return any(results)

        if rule.rule_type == RuleType.TEST:
            # Build the test's prerequisites first, then run the test
            # in-process. A test rule's order_only_deps carry the exe path
            # (produced by a LINK/SYMLINK rule -- recurse into it) plus, when
            # --test-xml-dir is set, an XML-bucket directory (an MKDIR rule --
            # just mkdir it; do not walk it, an MKDIR rule has no on-disk file
            # output and would trip _make_trace_entry). ``inputs`` is populated
            # in mtime mode (the exe path again) and empty in CAS-only mode.
            await asyncio.gather(*(self._build_async(inp, graph, traces, memo, sem) for inp in rule.inputs))
            for dep in rule.order_only_deps:
                dep_rule = graph.get_rule(dep)
                if dep_rule is not None and dep_rule.rule_type != RuleType.MKDIR:
                    await self._build_async(dep, graph, traces, memo, sem)
                else:
                    os.makedirs(dep, exist_ok=True)
            # Rerun-skip predicate (CAS-only mode): a test rule's ``output`` is
            # the JUnit XML path (framework tests) or the ``.result`` marker
            # (no-framework tests). When it already exists on disk the test's
            # exe bytes were tested before -- skip the re-run, mirroring the
            # make/ninja ``<output>: | <exe>`` order-only-prereq rule and the
            # ``_all_outputs_current`` RuleType.TEST branch. In ``--use-mtime``
            # mode the exe path is a real input, so always re-run (the user
            # opted into "touch to force rebuild" semantics).
            if not getattr(self.args, "use_mtime", False) and os.path.exists(rule.output):
                return False
            assert rule.command is not None, "test rules always carry a command"
            loop = asyncio.get_running_loop()
            async with sem:
                await loop.run_in_executor(None, self._execute_rule, rule, target, list(rule.command))
            # Test rules never enter the trace store: _execute_rule records the
            # outcome (success marker touched, or failure appended to
            # _test_failures) and we deliberately do NOT call _make_trace_entry
            # here -- a test rule's "output" is a framework XML file or the
            # .result marker, not a content-addressed build artefact, and a
            # failed test must not assert its output exists.
            return False

        # Ensure order-only deps (bucket directories) exist. Reject
        # artefact-shaped paths up front: ``order_only_deps`` is reserved
        # for *bucket directories* (see
        # ``_ORDER_ONLY_DEP_FORBIDDEN_EXTS``), and a silent mkdir on an
        # artefact path would clobber the file the producer rule is
        # supposed to write -- the original defect class behind the
        # C++20-modules trace_backend xfail. Mirrors the check in
        # ``BuildBackend._prebuild_aux_artefacts`` so producers can't
        # smuggle a file path past one backend by hitting the other
        # first. Module/PCH/BMI deps belong in ``inputs``, where
        # ``_build_async`` recurses into the producer.
        for dep in rule.order_only_deps:
            if dep.endswith(_ORDER_ONLY_DEP_FORBIDDEN_EXTS):
                raise AssertionError(
                    f"order_only_dep {dep!r} on rule {rule.output!r} has an "
                    f"artefact suffix; order_only_deps must be bucket "
                    f"directories. Route artefact dependencies through "
                    f"`inputs` (see build_backend._wire_module_inputs)."
                )
            os.makedirs(dep, exist_ok=True)

        # CONTENT-ADDRESSABLE SHORT-CIRCUIT
        if _is_build_artifact(rule):
            if rule.rule_type in (RuleType.COMPILE, RuleType.LINK):
                # Both compile and link rule outputs are content-addressable
                # by construction: object names encode file_h+dep_h+macro_h;
                # cas-exe paths encode the link key (linker identity + sorted
                # canonical objects + ldflags). Existence is sufficient.
                # The publish-as-symlink rule (separate, downstream) exposes
                # link outputs at user-facing bin/<name>.
                if os.path.exists(target):
                    return False
            else:
                # static_library / shared_library still use the legacy
                # in-place CA layout (output adjacent CA file then copy).
                # When/if those move into a cas-libdir, this branch can
                # collapse into the existence-only fast path above.
                ca = self._ca_target(rule)
                if os.path.exists(ca):
                    compiletools.filesystem_utils.atomic_copy(ca, target)
                    return False

        # SUSPEND: build all inputs concurrently via gather.
        results = await asyncio.gather(*(self._build_async(inp, graph, traces, memo, sem) for inp in rule.inputs))
        any_input_rebuilt = any(results)

        # VERIFY TRACE (non-CA rules only)
        if not _is_build_artifact(rule) and not any_input_rebuilt:
            trace = traces.get(target)
            if trace is not None and self._verify(rule, trace):
                return False  # up to date

        # EXECUTE (semaphore limits subprocess concurrency)
        old_hash = None
        if not _is_build_artifact(rule):
            old_hash = get_file_hash(target, self.context) if os.path.exists(target) else None

        assert rule.command is not None, "only rules with commands reach EXECUTE"
        cmd = rule.command
        verbose = getattr(self.args, "verbose", 0)
        if verbose >= 1:
            print(" ".join(cmd), file=sys.stderr)

        flat_cmd = list(cmd)

        loop = asyncio.get_running_loop()
        async with sem:
            await loop.run_in_executor(None, self._execute_rule, rule, target, flat_cmd)

        # CA outputs don't need trace recording or early cutoff
        if _is_build_artifact(rule):
            return True  # New output -> dependents must rebuild

        new_hash = get_file_hash(target, self.context)
        traces.put(target, _make_trace_entry(rule, self.context, output_hash=new_hash))

        # EARLY CUTOFF
        return old_hash != new_hash

    def _execute_rule(self, rule: BuildRule, target: str, flat_cmd: list[str]) -> None:
        """Run the subprocess for a single build rule (called from a thread).

        ``skip_if_exists=True`` on the three CA branches closes the TOCTOU
        window between the pre-lock fast-path in ``_do_build`` and the
        helper's own lock acquire. The ``else`` branch keeps the default
        False — verify-trace already decided the output is stale.
        """
        start = time.monotonic()
        if rule.rule_type == RuleType.TEST:
            # Pure-argv test invocation -- NOT routed through
            # execute_compile_rule / execute_link_rule (those are for
            # lock-guarded build artefacts; a test is neither). flat_cmd
            # already carries TESTPREFIX + exe + framework XML argv, baked in
            # at graph-build time by _test_command_for. On success touch the
            # .result marker (always success_marker, even for framework tests);
            # on failure append to _test_failures and continue so sibling
            # rules already in flight can finish -- execute() raises the
            # aggregate once the traversal returns.
            result = subprocess.run(flat_cmd)
            if result.returncode == 0:
                self._touch_result_marker(rule.success_marker or "")
            else:
                self._test_failures.append(f"{target} (exit {result.returncode}): {' '.join(flat_cmd)}")
        elif rule.rule_type == RuleType.COMPILE:
            execute_compile_rule(target, flat_cmd, self.args, skip_if_exists=True, cwd=rule.cwd)
        elif rule.rule_type == RuleType.LINK:
            # Link output IS the cas-exe path; the downstream publish-as-symlink
            # rule materialises bin/<name>. No per-rule CA-then-copy here —
            # that's only for static_library / shared_library.
            execute_link_rule(target, flat_cmd, self.args, skip_if_exists=True)
        elif _is_build_artifact(rule):
            ca = self._ca_target(rule)
            ca_cmd = [ca if a == target else a for a in flat_cmd]
            execute_link_rule(ca, ca_cmd, self.args, skip_if_exists=True)
            compiletools.filesystem_utils.atomic_copy(ca, target)
        else:
            execute_link_rule(target, flat_cmd, self.args)

        # Record per-rule timing
        elapsed = time.monotonic() - start
        timer = self._timer
        if timer:
            source = rule.inputs[0] if rule.inputs else ""
            timer.record_rule(
                rule_type=rule.rule_type,
                target=target,
                source=source,
                elapsed_s=elapsed,
                start_s=start,
                end_s=start + elapsed,
            )

    def _verify(self, rule, trace: TraceEntry) -> bool:
        """Check if a trace is still valid (output exists, inputs unchanged, same command)."""
        assert rule.command is not None, "_verify only applies to rules with commands"
        try:
            if get_file_hash(rule.output, self.context) != trace.output_hash:
                return False
        except (FileNotFoundError, OSError):
            return False

        # Symmetric with _make_trace_entry: anchor on the current workspace's
        # gitroot so cross-workspace traces still verify (the trace's keys
        # and command_hash were canonicalized at write time).
        anchor_root = compiletools.git_utils.find_git_root()
        identity = _compiler_identity(rule.command[0], anchor_root=anchor_root) if rule.command else None
        canonical_cmd = _canonicalize_cmd_for_hash(rule.command, anchor_root)
        if hash_command(canonical_cmd, compiler_identity=identity) != trace.command_hash:
            return False
        # Map each canonical key to a real on-disk path for the current
        # workspace so we can read the file hash. Since _make_trace_entry
        # canonicalizes (realpath -> <GITROOT>/relpath), the reverse here is
        # taking each rule input, realpath'ing it, then canonicalizing —
        # producing the same canonical key.
        canonical_to_real = {
            compiletools.apptools.canonicalize_path_for_cache_key(compiletools.wrappedos.realpath(p), anchor_root): p
            for p in rule.inputs
        }
        if set(canonical_to_real.keys()) != set(trace.input_hashes.keys()):
            return False

        for canonical_key, stored_hash in trace.input_hashes.items():
            try:
                current_hash = get_file_hash(canonical_to_real[canonical_key], self.context)
            except (FileNotFoundError, OSError):
                return False
            if current_hash != stored_hash:
                return False

        return True


_DEFAULT_MEM_TIERS_STR = "1:1G,2:2G,4:4G,8:8G,16:16G"


def _parse_mem_str(mem_str: str) -> int:
    """Parse a Slurm memory string (e.g. '4G', '512M') to megabytes."""
    s = mem_str.strip().upper()
    if not s:
        raise ValueError("empty memory value")
    if s.endswith("G"):
        return int(s[:-1]) * 1024
    if s.endswith("M"):
        return int(s[:-1])
    return int(s)


def _slurm_mem_arg(value: str) -> str:
    try:
        if _parse_mem_str(value) <= 0:
            raise ValueError("memory must be positive")
    except ValueError as e:
        raise argparse.ArgumentTypeError(
            f"invalid Slurm memory '{value}': {e} (expected '<int>G', '<int>M', or '<int>')"
        ) from e
    return value


def _slurm_max_wait_arg(value: str) -> float:
    """Validate the --slurm-max-wait wall-clock cap (positive float seconds)."""
    s = (value or "").strip()
    if not s:
        raise argparse.ArgumentTypeError("invalid --slurm-max-wait: empty")
    try:
        seconds = float(s)
    except ValueError as e:
        raise argparse.ArgumentTypeError(f"invalid --slurm-max-wait '{value}': not a number") from e
    if seconds <= 0:
        raise argparse.ArgumentTypeError(f"invalid --slurm-max-wait '{value}': must be positive")
    return seconds


def _slurm_time_arg(value: str) -> str:
    """Validate Slurm wall-clock time format (HH:MM:SS or D-HH:MM:SS)."""
    s = value.strip()
    if not s:
        raise argparse.ArgumentTypeError("invalid Slurm time: empty")
    rest = s
    if "-" in rest:
        day_str, rest = rest.split("-", 1)
        try:
            if int(day_str) < 0:
                raise ValueError("days must be non-negative")
        except ValueError as e:
            raise argparse.ArgumentTypeError(f"invalid Slurm time '{value}': bad days field") from e
    parts = rest.split(":")
    if len(parts) not in (2, 3):
        raise argparse.ArgumentTypeError(f"invalid Slurm time '{value}': expected HH:MM:SS or D-HH:MM:SS")
    try:
        for p in parts:
            if int(p) < 0:
                raise ValueError("time fields must be non-negative")
    except ValueError as e:
        raise argparse.ArgumentTypeError(f"invalid Slurm time '{value}': {e}") from e
    return value


def _slurm_mem_tiers_arg(value: str) -> list[tuple[int, str]]:
    """Parse '<threshold>:<mem>,<threshold>:<mem>,...' into a sorted tier list."""
    if not value or not value.strip():
        raise argparse.ArgumentTypeError("invalid --slurm-mem-tiers: empty")
    tiers: list[tuple[int, str]] = []
    for entry in value.split(","):
        entry = entry.strip()
        if not entry:
            continue
        if ":" not in entry:
            raise argparse.ArgumentTypeError(f"invalid --slurm-mem-tiers entry '{entry}': expected '<threshold>:<mem>'")
        thr_str, mem_str = entry.split(":", 1)
        try:
            threshold = int(thr_str.strip())
        except ValueError as e:
            raise argparse.ArgumentTypeError(f"invalid --slurm-mem-tiers threshold '{thr_str}': {e}") from e
        mem = mem_str.strip()
        try:
            _parse_mem_str(mem)
        except ValueError as e:
            raise argparse.ArgumentTypeError(f"invalid --slurm-mem-tiers memory '{mem}': {e}") from e
        tiers.append((threshold, mem))
    if not tiers:
        raise argparse.ArgumentTypeError("invalid --slurm-mem-tiers: no entries")
    tiers.sort(key=lambda t: t[0])
    return tiers


@register_backend
class SlurmBackend(ShakeBackend):
    """Self-executing backend that distributes compile rules via Slurm."""

    @staticmethod
    def name() -> str:
        return "slurm"

    @staticmethod
    def tool_command() -> str:
        # Slurm jobs are submitted via sbatch.
        return "sbatch"

    @staticmethod
    def build_filename() -> str:
        return ".ct-slurm-traces.json"

    @staticmethod
    def add_arguments(cap) -> None:
        if compiletools.apptools._parser_has_option(cap, "--slurm-partition"):
            return
        cap.add_argument(
            "--slurm-partition",
            default=None,
            help="Slurm partition (queue) for compile jobs. Omit to use the site default partition.",
        )
        cap.add_argument(
            "--slurm-time",
            default="00:30:00",
            type=_slurm_time_arg,
            help="Wall-clock time limit per compile job (HH:MM:SS or D-HH:MM:SS). Default: 00:30:00",
        )
        cap.add_argument(
            "--slurm-mem",
            default="16G",
            type=_slurm_mem_arg,
            help="Memory ceiling per compile job (e.g. 16G, 8G, 512M). Default: 16G",
        )
        cap.add_argument(
            "--slurm-cpus",
            default=1,
            type=int,
            help="CPUs allocated per compile job. Default: 1",
        )
        cap.add_argument(
            "--slurm-account",
            default=None,
            help="Slurm account/project to charge for compile jobs.",
        )
        cap.add_argument(
            "--slurm-max-array",
            default=1000,
            type=int,
            help="Maximum job-array size per sbatch call. Larger projects are split into "
            "multiple arrays. Default: 1000",
        )
        cap.add_argument(
            "--slurm-poll-interval",
            default=2.0,
            type=float,
            help="Seconds between sacct polls when waiting for compile jobs. Default: 2.0",
        )
        cap.add_argument(
            "--slurm-job-name",
            default="ct-compile",
            help="Name applied to submitted Slurm jobs (visible in squeue/sacct). "
            "Default: ct-compile. Useful for distinguishing concurrent ct-cake invocations.",
        )
        cap.add_argument(
            "--slurm-mem-tiers",
            default=_DEFAULT_MEM_TIERS_STR,
            type=_slurm_mem_tiers_arg,
            help="Memory tier mapping as 'threshold:mem,threshold:mem,...' where threshold is "
            "the maximum work-weight for that tier (quoted-include count for compile rules, "
            "input-object count for link/library rules). Rules whose weight exceeds the largest "
            "threshold use --slurm-mem. Default: " + _DEFAULT_MEM_TIERS_STR,
        )
        cap.add_argument(
            "--slurm-sacct-failure-threshold",
            default=10,
            type=int,
            help="Consecutive sacct failures tolerated before _wait_for_arrays raises. Default: 10",
        )
        cap.add_argument(
            "--slurm-output-wait-timeout",
            default=30.0,
            type=float,
            help="Seconds to wait for compiled outputs to become visible on the submitter "
            "after sacct reports COMPLETED (network filesystem metadata lag). Default: 30.0",
        )
        cap.add_argument(
            "--slurm-export",
            default=_DEFAULT_SLURM_EXPORT,
            help="Value passed to sbatch --export=. Default propagates a curated allowlist "
            f"({_DEFAULT_SLURM_EXPORT}) instead of the submitter's full environment. "
            "Use 'ALL' to restore legacy behavior, 'NONE' for a fully isolated environment, "
            "or extend the default for Lmod/Spack sites (e.g. "
            "'PATH,HOME,USER,LANG,LC_ALL,CC,CXX,CPATH,LD_LIBRARY_PATH,MODULEPATH,LMOD_CMD'). "
            "See README.ct-backends for guidance.",
        )
        cap.add_argument(
            "--slurm-rule-retry-cap",
            default=3,
            type=int,
            help="Maximum OOM retries per rule before that rule is abandoned. Default: 3",
        )
        cap.add_argument(
            "--slurm-max-wait",
            default=7200.0,
            type=_slurm_max_wait_arg,
            help="Total wall-clock seconds to wait for all submitted Slurm arrays "
            "to reach a terminal state.  Raised as RuntimeError if exceeded. "
            "Tune upward on busy clusters where queue waits exceed the default. "
            "Default: 7200.0 (2 hours)",
        )

    # ------------------------------------------------------------------
    # Core execute() — overrides ShakeBackend's async engine

    def execute(self, target: str = "build") -> None:
        if self._graph is None:
            raise RuntimeError("generate() must be called before execute()")

        graph = self._graph
        trace_path = os.path.join(self.args.cas_objdir, self.build_filename())
        traces = TraceStore(trace_path)

        # Each execute() call is a fresh traversal; clear any test failures
        # aggregated by a prior call on the same backend instance.
        self._test_failures = []

        if target == "runtests":
            # Standalone test run: exes were produced by a prior
            # execute("build"). Run the graph's RuleType.TEST rules through
            # the same local-rule path the in-build phase uses, after
            # materialising any xml-bucket dirs they order-only depend on.
            for rule in graph.rules_by_type("mkdir"):
                os.makedirs(rule.output, exist_ok=True)
            test_rules = list(graph.rules_by_type("test"))
            if test_rules:
                asyncio.run(self._run_local_async(test_rules, traces))
            if self._test_failures:
                raise RuntimeError("test execution failed:\n  " + "\n  ".join(self._test_failures))
            return

        # Resolve (and create) the per-invocation diagnostics directory once,
        # so the three downstream sites (sbatch --output=, _invocation_log_paths,
        # _read_slurm_logs_for_failures) read a stored path instead of
        # re-invoking the resolver (which would mkdir each time).  The
        # cleanup path (_invocation_log_paths via _cleanup_slurm_logs in the
        # finally block) checks for this attribute and short-circuits when
        # execute() raised before this assignment, so we don't mint an empty
        # diagnostics dir for an invocation that produced no logs.
        self._diag_dir = compiletools.diagnostics.resolve_diagnostics_dir(self.args)

        self._created_aux_files: list[str] = []
        self._tracked_jobs: dict[str, str] = {}  # job_id -> "pending"|"terminal"

        # Index from job_id -> chunk_id, so log lookups don't have to glob.
        self._chunk_id_for_job: dict[str, int] = {}

        def _on_signal(signum, _frame):  # pragma: no cover - exercised via thread test
            self._scancel_pending()
            # Restore default handler and re-raise so normal interrupt semantics apply.
            # graceful_shutdown's restoration won't run until the with block exits, but
            # os.kill below re-delivers immediately and sys.exit unwinds through it.
            signal.signal(signum, signal.SIG_DFL)
            os.kill(os.getpid(), signum)

        with (
            compiletools.apptools.graceful_shutdown(_on_signal, signal.SIGINT, signal.SIGTERM),
            contextlib.ExitStack() as stack,
        ):
            # Callbacks fire in LIFO order, so declared order here matches
            # the original nested-finally order: scancel → cleanup → save.
            stack.callback(traces.save)
            stack.callback(self._cleanup_invocation_files)
            stack.callback(self._scancel_pending)
            self._execute_impl(graph, traces)

    def _execute_impl(self, graph: BuildGraph, traces: TraceStore) -> None:
        # Ensure output directories exist (order-only deps on compile rules)
        for rule in graph.rules_by_type("mkdir"):
            if rule.command:
                subprocess.check_call(rule.command)
            else:
                os.makedirs(rule.output, exist_ok=True)

        # Phase 0: locally build PCH (.gch) and HEADER_UNIT (.pcm/.gcm)
        # producers before submitting compile jobs to slurm. Slurm
        # parallelises compile rules into a flat job array with no DAG
        # ordering, so an importer compile job submitted alongside its
        # header-unit precompile would race the .gcm and crash with
        # "imports must be built before being imported". The shake
        # backend has no equivalent gap because its async engine
        # recurses into rule.inputs and naturally builds dependencies
        # first; cmake/bazel solve the same problem the same way (call
        # _prebuild_aux_artefacts before handing off to the native
        # tool). Doing it here makes slurm symmetric with cmake/bazel
        # for any artefact that lives outside the per-TU compile chain.
        self._prebuild_aux_artefacts()

        # Phase 1: identify compile rules that need rebuilding.
        to_submit = [
            rule
            for rule in graph.rules_by_type("compile")
            if not os.path.exists(rule.output)
            or not (
                (trace := traces.get(rule.output))  # type: ignore[attr-defined]
                and self._verify(rule, trace)  # type: ignore[attr-defined]
            )
        ]

        max_array = self.args.slurm_max_array
        index_map: dict[str, list[BuildRule]] = {}

        tiers: dict[str, list[BuildRule]] = collections.defaultdict(list)
        for rule in to_submit:
            mem = self._estimate_memory(rule)
            tiers[mem].append(rule)

        # chunk_id is a per-invocation *uniqueness token* used to namespace
        # commands/outputs/log files, NOT a task-index offset.  Incrementing
        # by len(chunk) (rather than +1) leaves a gap large enough that no two
        # chunks ever share a filename even if a future change reused chunk_id
        # as a task base.  Cheap defence against accidental collisions.
        chunk_id = 0
        for mem, tier_rules in tiers.items():
            for chunk_start in range(0, len(tier_rules), max_array):
                chunk = tier_rules[chunk_start : chunk_start + max_array]
                array_job_id = self._sbatch_array(chunk, chunk_id=chunk_id, mem=mem)
                index_map[array_job_id] = chunk
                self._tracked_jobs[array_job_id] = "pending"
                self._chunk_id_for_job[array_job_id] = chunk_id
                chunk_id += len(chunk)

        all_failures: list[SlurmBackend._TaskFailure] = []
        retry_cap = getattr(self.args, "slurm_rule_retry_cap", 3)
        per_rule_retries: dict[str, int] = collections.defaultdict(int)

        try:
            if index_map:
                failures = self._wait_for_arrays(index_map)
                mem_cap_mb = self._parse_mem(self.args.slurm_mem)

                oom_rules = [f.rule for f in failures if f.state == self._OOM_STATE]
                non_oom = [f for f in failures if f.state != self._OOM_STATE]
                all_failures.extend(non_oom)

                rule_mem: dict[str, str] = {r.output: self._estimate_memory(r) for r in oom_rules}
                while oom_rules:
                    capped: list[BuildRule] = []
                    retryable: list[tuple[BuildRule, str]] = []
                    abandoned: list[BuildRule] = []
                    for r in oom_rules:
                        if per_rule_retries[r.output] >= retry_cap:
                            abandoned.append(r)
                            continue
                        doubled = self._double_mem(rule_mem[r.output])
                        if self._parse_mem(doubled) > mem_cap_mb:
                            capped.append(r)
                        else:
                            rule_mem[r.output] = doubled
                            retryable.append((r, doubled))
                    all_failures.extend(
                        SlurmBackend._TaskFailure(rule=r, state=self._OOM_STATE, job_id="retry") for r in capped
                    )
                    all_failures.extend(
                        SlurmBackend._TaskFailure(rule=r, state=self._OOM_STATE, job_id=f"retry-cap-{retry_cap}")
                        for r in abandoned
                    )
                    if not retryable:
                        break

                    retry_tiers: dict[str, list[BuildRule]] = collections.defaultdict(list)
                    for r, mem in retryable:
                        retry_tiers[mem].append(r)

                    logger.info(
                        "Retrying %d OOM compile job(s) across %d memory tier(s) (cap: %s)",
                        len(retryable),
                        len(retry_tiers),
                        self.args.slurm_mem,
                    )
                    retry_map: dict[str, list[BuildRule]] = {}
                    # See chunk_id comment above: increment by len(chunk) is a
                    # uniqueness token, not a task-index offset.
                    for mem, tier_rules in retry_tiers.items():
                        for retry_start in range(0, len(tier_rules), max_array):
                            chunk = tier_rules[retry_start : retry_start + max_array]
                            array_job_id = self._sbatch_array(chunk, chunk_id=chunk_id, mem=mem)
                            retry_map[array_job_id] = chunk
                            self._tracked_jobs[array_job_id] = "pending"
                            self._chunk_id_for_job[array_job_id] = chunk_id
                            chunk_id += len(chunk)

                    for r, _ in retryable:
                        per_rule_retries[r.output] += 1

                    # Merge retry submissions into the timing-collection map so
                    # tasks that succeeded only on retry have their elapsed time
                    # recorded.  Each iteration's retry_map carries fresh job
                    # IDs, so dict.update is collision-free.
                    index_map.update(retry_map)

                    retry_failures = self._wait_for_arrays(retry_map)
                    oom_rules = [f.rule for f in retry_failures if f.state == self._OOM_STATE]
                    non_oom = [f for f in retry_failures if f.state != self._OOM_STATE]
                    all_failures.extend(non_oom)
        finally:
            # Always collect timing for any array we actually waited on, even
            # if a later step raises.  index_map includes initial submissions
            # and every retry round merged in above.
            with contextlib.suppress(Exception):
                self._collect_timing(index_map)

        # Phase 4: record traces for successfully built compile rules.
        # Done BEFORE the failure raise so successes (including ones that
        # only succeeded after OOM retry) survive a mixed-failure invocation
        # and are not re-submitted on the next ct-cake call.
        for rule in to_submit:
            if os.path.exists(rule.output):
                traces.put(rule.output, _make_trace_entry(rule, self.context))

        if all_failures:
            lines = [f"Job {f.job_id} ({f.rule.output}): {f.state}" for f in all_failures]
            diag = self._read_slurm_logs_for_failures(all_failures)
            msg = "Slurm compile jobs failed:\n" + "\n".join(lines)
            if diag:
                msg += "\n\n" + diag
            raise RuntimeError(msg)

        has_link_rules = any(r.rule_type not in ("phony", "mkdir", "compile", "clean") for r in graph.rules)
        if to_submit and has_link_rules:
            # I5: scale the output-wait timeout with the number of outputs we
            # are waiting on.  Lustre/GPFS metadata propagation is roughly
            # proportional to the working set; a fixed 30s cap is too tight
            # for 1000+ outputs.  Heuristic: max(configured, 0.05 * outputs)
            # capped at 300s.
            configured = getattr(self.args, "slurm_output_wait_timeout", 30.0)
            scaled = min(max(configured, 0.05 * len(to_submit)), 300.0)
            timeout = scaled
            try:
                self._wait_for_output_files(to_submit, timeout=timeout)
            except RuntimeError as e:
                # Save traces for completed compiles before re-raising so the
                # next invocation doesn't re-submit them.  Slurm logs are
                # preserved so the user can diagnose the missing output.
                self._save_traces_for_completed(to_submit, traces)
                log_paths = self._invocation_log_paths()
                if log_paths:
                    raise RuntimeError(
                        f"{e}\n\nSlurm logs preserved for diagnosis ({len(log_paths)} file(s)):\n"
                        + "\n".join(f"  {p}" for p in log_paths[:10])
                        + ("" if len(log_paths) <= 10 else f"\n  ... and {len(log_paths) - 10} more")
                    ) from e
                raise

        self._cleanup_slurm_logs()

        # Phase 5: run link/library/test/other non-compile rules locally, in
        # parallel where dependency order permits.  Mirrors the Shake backend's
        # asyncio approach so independent links don't serialize on the
        # submitter (I5).  RuleType.TEST rules participate too — _run_local
        # handles them as pure-argv invocations (no atomic_link) and a test
        # rule's order_only_deps make it wait for its exe's link/symlink rule.
        local_rules = [r for r in graph.rules if r.rule_type not in ("phony", "mkdir", "compile", "clean")]
        if local_rules:
            asyncio.run(self._run_local_async(local_rules, traces))

        self._record_link_signatures(graph)

        # A failed test buffered itself in _test_failures instead of raising
        # mid-sweep so sibling locals could finish; surface the aggregate now
        # so a failing test makes ct-cake exit non-zero.
        if self._test_failures:
            raise RuntimeError("test execution failed:\n  " + "\n  ".join(self._test_failures))

    async def _run_local_async(self, local_rules: list[BuildRule], traces: TraceStore) -> None:
        """Run *local_rules* concurrently, respecting input-output dependencies.

        Each rule becomes a coroutine that awaits its input rules' tasks
        before executing.  Independent rules run in parallel; dependents
        wait only for their own inputs.  Concurrency is capped by --parallel.
        """
        timer = self._timer
        parallel = getattr(self.args, "parallel", 1)
        max_workers = parallel if parallel and parallel > 0 else 1
        sem = asyncio.Semaphore(max_workers)

        # Compile inputs were already produced by the Slurm phase and
        # confirmed visible by _wait_for_output_files; the only edges we
        # need to respect here are output->input within local_rules.
        loop = asyncio.get_running_loop()
        tasks: dict[str, asyncio.Task[None]] = {}

        async def run(rule: BuildRule) -> None:
            # Wait for dependencies that are themselves local rules. Both
            # inputs and order_only_deps matter: a RuleType.TEST rule carries
            # its exe in order_only_deps (CAS-only mode) or inputs (mtime
            # mode), so the test must not fire before the link/symlink rule
            # that produces it.
            dep_names = list(rule.inputs) + list(rule.order_only_deps)
            deps = [tasks[d] for d in dep_names if d in tasks]
            if deps:
                await asyncio.gather(*deps)
            async with sem:
                start = time.monotonic()
                await loop.run_in_executor(None, self._run_local, rule, traces)
                end = time.monotonic()
            if timer:
                source = rule.inputs[0] if rule.inputs else ""
                timer.record_rule(
                    rule_type=rule.rule_type,
                    target=rule.output,
                    source=source,
                    elapsed_s=end - start,
                    start_s=start,
                    end_s=end,
                )

        # Schedule all rules first so each can find its dependencies in
        # *tasks* before any start awaiting.
        for rule in local_rules:
            tasks[rule.output] = asyncio.ensure_future(run(rule))

        await asyncio.gather(*tasks.values())

    # ------------------------------------------------------------------
    # Memory estimation

    # Default tier thresholds: (max_quoted_includes, slurm_mem_string).
    #
    # Derived from profiling C++20 builds on an HPC cluster (gcc-12, -O3, with a large C++
    # framework).  Quoted #include count correlates strongly with peak RSS
    # (r=0.85) because each quoted include transitively pulls in framework
    # headers and triggers template instantiation.  Unity-build patterns
    # contribute naturally to this count.  Override via --slurm-mem-tiers.
    _MEMORY_TIERS: ClassVar[list[tuple[int, str]]] = [
        (1, "1G"),
        (2, "2G"),
        (4, "4G"),
        (8, "8G"),
        (16, "16G"),
    ]

    def _estimate_memory(self, rule: BuildRule) -> str:
        """Estimate Slurm memory from the rule's work weight.

        The same --slurm-mem-tiers table sizes both compile and link work;
        only the *weight* differs by rule type:

        * Compile rules use ``rule.include_weight`` (=
          ``len(FileAnalyzer.quoted_headers)`` for the source file, set in
          ``BuildBackend._create_compile_rule()`` at zero cost — analyze_file
          results are cached from the header-dep walk).
        * Link / static_library / shared_library rules have no source file
          (``include_weight`` is 0), so they would always match the smallest
          tier and OOM on real binaries.  Use ``len(rule.inputs)`` instead.
          This is a loose proxy: a static archive counts as 1 input even
          though the linker scans every object inside it for symbol
          resolution, so executables that pull in a large ``.a`` will be
          under-sized here.  The OOM-retry-and-double loop in
          ``_compile_concurrent`` catches under-estimates by re-submitting
          at 2x memory, capped at ``--slurm-mem``.

        For real link rules (hundreds of objects, template-heavy framework)
        ``len(inputs)`` typically exceeds the largest default tier (16) and
        the rule falls off to ``--slurm-mem`` (16G default — the empirical
        peak the proposal calibrated against).  The 1G-16G ladder only
        meaningfully sizes 1-to-16-object link rules; production link work
        is sized by ``--slurm-mem`` plus the OOM-retry loop, not by the
        intermediate tiers.

        Rules whose weight exceeds the largest threshold use ``--slurm-mem``
        (the per-job ceiling).
        """
        if rule.rule_type in (RuleType.LINK, RuleType.STATIC_LIBRARY, RuleType.SHARED_LIBRARY):
            weight = len(rule.inputs)
        else:
            weight = rule.include_weight
        tiers = getattr(self.args, "slurm_mem_tiers", None) or self._MEMORY_TIERS
        for threshold, mem in tiers:
            if weight <= threshold:
                return mem
        return self.args.slurm_mem

    # ------------------------------------------------------------------
    # Slurm helpers

    def _sbatch_array(self, rules: list[BuildRule], chunk_id: int = 0, mem: str | None = None) -> str:
        """Submit *rules* as a single Slurm job array; return the array job ID.

        Each array task (index 0 … N-1) reads its compile command from a
        commands file written to the objdir and executes it.

        *chunk_id* is used to give each chunk a unique commands/outputs filename so
        multiple chunks submitted before the first chunk's tasks start reading do not
        overwrite each other's files.

        *mem* overrides ``--slurm-mem`` for this array (used for per-tier sizing).
        """
        n = len(rules)
        assert n > 0, "_sbatch_array called with empty rules list (would produce --array=0--1)"
        real_objdir = compiletools.wrappedos.realpath(self.args.cas_objdir)

        # Per-invocation prefix prevents collisions with peer ct-cake processes
        # sharing the same objdir on a network filesystem.  Sourced from the
        # shared diagnostics module so all per-invocation artifacts (timing.json,
        # slurm logs, cmds/outs files) share one id.
        prefix = compiletools.diagnostics.invocation_id()
        cmds_file = os.path.join(real_objdir, f".ct-slurm-cmds-{prefix}-{chunk_id}.txt")
        outs_file = os.path.join(real_objdir, f".ct-slurm-outs-{prefix}-{chunk_id}.txt")
        with open(cmds_file, "w") as fc, open(outs_file, "w") as fo:
            for rule in rules:
                assert rule.command is not None, "compile rules always have a command"
                flat = list(rule.command)
                # Strip the trailing "-o <path>" pair: the wrap script reattaches
                # ``-o "$TMP"`` so the compile writes to a per-task temp file and
                # is atomically renamed to OUT, matching the local atomic_compile
                # guarantee (see locking.py:atomic_compile docstring).
                try:
                    o_idx = flat.index("-o")
                except ValueError as e:
                    raise AssertionError(f"compile rule missing -o flag: {flat}") from e
                cmd_without_output = flat[:o_idx] + flat[o_idx + 2 :]
                fc.write(shlex.join(cmd_without_output) + "\n")
                fo.write(rule.output + "\n")
            fc.flush()
            fo.flush()
            os.fsync(fc.fileno())
            os.fsync(fo.fileno())

        # Track for end-of-build cleanup.
        if hasattr(self, "_created_aux_files"):
            self._created_aux_files.append(cmds_file)
            self._created_aux_files.append(outs_file)

        # eval "$CMD -o \"$TMP\"" runs the compile against a per-task temp file,
        # then ``mv -f`` renames it onto OUT.  Peer readers (linker, second
        # ct-cake) see either the previous good .o (old inode) or the new one
        # (new inode), never a torn file — same guarantee atomic_compile
        # provides on the local path.
        # The cmds-file line was produced by shlex.join (with -o stripped), so
        # each token is single-quoted and metacharacters like $, backticks,
        # parentheses are literal — eval parses the quoting once and produces
        # argv without re-expansion.
        wrap = (
            f'CMD=$(sed -n "$((SLURM_ARRAY_TASK_ID + 1))p" {shlex.quote(cmds_file)}); '
            f'OUT=$(sed -n "$((SLURM_ARRAY_TASK_ID + 1))p" {shlex.quote(outs_file)}); '
            f'[ -n "$CMD" ] || {{ echo "ct-compile: empty command (index $SLURM_ARRAY_TASK_ID)" >&2; exit 1; }}; '
            f'TMP="${{OUT}}.${{SLURM_JOB_ID}}.${{SLURM_ARRAY_TASK_ID}}.tmp"; '
            f'eval "$CMD -o \\"$TMP\\"" || {{ rm -f "$TMP"; exit 1; }}; '
            f'mv -f "$TMP" "$OUT" || {{ rm -f "$TMP"; exit 1; }}'
        )

        effective_mem = mem if mem is not None else self.args.slurm_mem
        slurm_log = os.path.join(self._diag_dir, f"slurm-ct-{chunk_id}-%a.out")
        export_value = getattr(self.args, "slurm_export", _DEFAULT_SLURM_EXPORT)
        cmd = [
            "sbatch",
            "--parsable",
            f"--export={export_value}",
            f"--chdir={os.getcwd()}",
            f"--array=0-{n - 1}",
            f"--job-name={getattr(self.args, 'slurm_job_name', 'ct-compile')}",
            f"--time={self.args.slurm_time}",
            f"--mem={effective_mem}",
            f"--cpus-per-task={self.args.slurm_cpus}",
            f"--output={slurm_log}",
            f"--error={slurm_log}",
        ]
        if self.args.slurm_partition:
            cmd += ["--partition", self.args.slurm_partition]
        if self.args.slurm_account:
            cmd += ["--account", self.args.slurm_account]
        cmd += ["--wrap", wrap]
        try:
            return subprocess.check_output(cmd, text=True, stderr=subprocess.PIPE).strip()
        except subprocess.CalledProcessError as e:
            stderr_text = (e.stderr or "").strip()
            raise RuntimeError(f"sbatch failed (exit {e.returncode}): {stderr_text or '<no stderr>'}") from e
        except FileNotFoundError as e:
            raise RuntimeError(f"sbatch not found on PATH: {e}") from e

    def _collect_timing(self, index_map: dict[str, list[BuildRule]]) -> None:
        """Collect per-job timing from Slurm accounting via sacct.

        Also collects Start/End wall-clock so the Chrome trace renders the
        rules across the timeline rather than stacking them at t=0.
        """
        timer = self._timer
        if not timer or not index_map:
            return

        # sacct formats Start/End as ISO 8601 ("2026-04-21T11:22:33"); convert
        # to wall-clock seconds, then shift into the BuildTimer's monotonic
        # clock domain so the rule events share an origin with the in-Python
        # record_rule callers (test runner, etc.).  Wall clocks across the
        # cluster are NTP-synced, so the conversion is meaningful for the
        # local viewer even though sacct timestamps come from the controller.
        offset = timer._wall_to_monotonic_offset

        def _parse_iso(ts: str) -> float | None:
            ts = ts.strip()
            if not ts or ts in ("Unknown", "None"):
                return None
            try:
                return datetime.datetime.fromisoformat(ts).timestamp() + offset
            except ValueError:
                return None

        for array_job_id, rules in index_map.items():
            try:
                out = subprocess.check_output(
                    [
                        "sacct",
                        "-j",
                        array_job_id,
                        "--format=JobID,Elapsed,State,Start,End",
                        "--noheader",
                        "--parsable2",
                    ],
                    text=True,
                )
            except (subprocess.CalledProcessError, FileNotFoundError) as e:
                logger.debug("sacct unavailable for job %s: %s", array_job_id, e)
                continue
            for line in out.splitlines():
                parts = line.strip().split("|")
                if len(parts) < 3:
                    continue
                jid = parts[0]
                if "." in jid:
                    continue  # skip sub-steps
                elapsed_str = parts[1]
                state = parts[2].split()[0]
                if state != "COMPLETED":
                    continue
                start_s = _parse_iso(parts[3]) if len(parts) > 3 else None
                end_s = _parse_iso(parts[4]) if len(parts) > 4 else None
                # Parse task index from job ID (format: "array_job_id_index")
                jid_parts = jid.rsplit("_", 1)
                if len(jid_parts) != 2:
                    continue
                try:
                    task_idx = int(jid_parts[1])
                except ValueError:
                    continue
                if task_idx >= len(rules):
                    continue
                rule = rules[task_idx]
                elapsed_s = _parse_slurm_elapsed(elapsed_str)
                source = rule.inputs[0] if rule.inputs else ""
                kwargs = {
                    "rule_type": rule.rule_type,
                    "target": rule.output,
                    "source": source,
                    "elapsed_s": elapsed_s,
                }
                if start_s is not None and end_s is not None:
                    kwargs["start_s"] = start_s
                    kwargs["end_s"] = end_s
                timer.record_rule(**kwargs)

    def _invocation_log_paths(self) -> list[str]:
        """Slurm log paths produced by THIS invocation.

        The diagnostics directory is per-invocation by construction (its leaf
        is ``compiletools.diagnostics.invocation_id()``), so every
        ``slurm-ct-*.out`` it contains belongs to this ct-cake invocation —
        no per-prefix glob filter is required.

        Returns ``[]`` (without creating a diagnostics dir) if execute() never
        ran or raised before caching ``self._diag_dir`` — the cleanup path in
        execute()'s finally block must not mint an empty diagnostics directory
        for an invocation that produced no logs.
        """
        diag_dir = getattr(self, "_diag_dir", None)
        if diag_dir is None:
            return []
        return sorted(glob.glob(os.path.join(diag_dir, "slurm-ct-*.out")))

    def _cleanup_slurm_logs(self) -> None:
        """Remove THIS invocation's slurm log files when verbosity is low."""
        verbose = getattr(self.args, "verbose", 0)
        if verbose >= 2:
            return
        for f in self._invocation_log_paths():
            with contextlib.suppress(OSError):
                os.remove(f)

    def _cleanup_invocation_files(self) -> None:
        """Remove cmds/outs files this invocation created. Best effort.

        Also sweeps stale per-task temp files (``${OUT}.${SLURM_JOB_ID}.${SLURM_ARRAY_TASK_ID}.tmp``)
        left by NODE_FAIL or hard-killed wrap scripts.  The wrap script
        ``rm -f``s on normal-failure paths, but NODE_FAIL skips the trap
        entirely.  Sweep only files keyed off jobs *this invocation* tracked
        so we don't disturb peer ct-cake processes' in-flight compiles.
        """
        for f in getattr(self, "_created_aux_files", []):
            with contextlib.suppress(OSError):
                os.remove(f)
        self._created_aux_files = []

        # Sweep stale temp files keyed off our tracked job IDs.  Filename
        # pattern is ``${OUT}.${jobid}.${task_idx}.tmp``; we only know the
        # objdir and our jobids, so glob across the objdir for that suffix
        # pattern.  Bounded by len(_tracked_jobs) — typically O(few).
        tracked = getattr(self, "_tracked_jobs", {})
        if not tracked:
            return
        objdir = getattr(self.args, "cas_objdir", None)
        if not objdir:
            return
        for jid in tracked:
            # ${OUT}.${jid}.*.tmp — OUT lives under objdir but may be in a
            # subdir; glob recursively to catch nested namer layouts.
            for stale in glob.glob(os.path.join(objdir, "**", f"*.{jid}.*.tmp"), recursive=True):
                with contextlib.suppress(OSError):
                    os.remove(stale)

    def _scancel_pending(self) -> None:
        """Cancel any tracked Slurm jobs not yet known to be terminal. Never raises."""
        pending = [jid for jid, status in getattr(self, "_tracked_jobs", {}).items() if status != "terminal"]
        if not pending:
            return
        try:
            result = subprocess.run(
                ["scancel", *pending],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode != 0:
                logger.warning(
                    "scancel returned %s for jobs %s: %s",
                    result.returncode,
                    pending,
                    (result.stderr or "").strip(),
                )
            else:
                logger.info("scancel cancelled pending Slurm jobs: %s", pending)
        except FileNotFoundError:
            logger.warning("scancel not found on PATH; %d Slurm job(s) may still be pending: %s", len(pending), pending)
        except Exception as e:  # pragma: no cover - defensive
            logger.warning("scancel failed for jobs %s: %s", pending, e)
        finally:
            for jid in pending:
                self._tracked_jobs[jid] = "terminal"

    def _save_traces_for_completed(self, rules: list[BuildRule], traces: TraceStore) -> None:
        """Record trace entries for rules whose output exists on disk, then save."""
        for rule in rules:
            if os.path.exists(rule.output):
                traces.put(rule.output, _make_trace_entry(rule, self.context))
        traces.save()

    def _read_slurm_logs_for_failures(self, failures: list[SlurmBackend._TaskFailure]) -> str:
        """Read slurm log content for failed tasks and return formatted diagnostics.

        Log files for a chunk are named ``slurm-ct-<chunk_id>-<array_index>.out``
        inside the per-invocation diagnostics directory.  Looks up the exact
        chunk_id for the failure's array job to avoid matching retry chunks
        that share the same array_index.
        """
        diagnostics: list[str] = []
        diag_dir = getattr(self, "_diag_dir", None)
        if diag_dir is None:
            return ""
        for f in failures:
            parts = f.job_id.rsplit("_", 1)
            if len(parts) != 2:
                continue
            array_job_id, task_idx = parts
            chunk_id = getattr(self, "_chunk_id_for_job", {}).get(array_job_id)
            if chunk_id is None:
                # No chunk index available (e.g. synthetic 'retry'/'retry-cap' job_ids).
                continue
            log_path = os.path.join(diag_dir, f"slurm-ct-{chunk_id}-{task_idx}.out")
            try:
                with open(log_path) as fh:
                    content = fh.read().strip()
                if content:
                    diagnostics.append(f"--- {f.rule.output} (job {f.job_id}) ---\n{content}")
            except OSError:
                pass
        return "\n".join(diagnostics)

    def _query_array_task_states_status(self, array_job_id: str) -> tuple[dict[str, str], bool]:
        """Return ``({task_id: state}, exec_failed)`` for *array_job_id*.

        *exec_failed* is True if the sacct *invocation itself* failed
        (CalledProcessError / FileNotFoundError) — a real fault that should
        count toward the failure threshold.  False when sacct ran cleanly,
        regardless of whether it returned any rows.  An empty dict with
        exec_failed=False means "sacct OK, no rows yet" (benign — common for
        freshly-submitted arrays).
        """
        try:
            out = subprocess.check_output(
                [
                    "sacct",
                    "-j",
                    array_job_id,
                    "--format=JobID,State",
                    "--noheader",
                    "--parsable2",
                ],
                text=True,
                stderr=subprocess.PIPE,
            )
        except subprocess.CalledProcessError as e:
            stderr_text = (e.stderr or "").strip()
            logger.warning(
                "sacct failed for job %s (exit %s): %s",
                array_job_id,
                e.returncode,
                stderr_text or "<no stderr>",
            )
            return {}, True
        except FileNotFoundError as e:
            logger.warning("sacct not found on PATH: %s", e)
            return {}, True

        result: dict[str, str] = {}
        for line in out.splitlines():
            parts = line.strip().split("|")
            if len(parts) < 2:
                continue
            jid = parts[0]
            if "." in jid:
                continue
            result[jid] = parts[1].split()[0]
        return result, False

    def _query_array_task_states(self, array_job_id: str) -> dict[str, str]:
        """Back-compat shim: return only the states dict.

        Used by _collect_timing and existing tests that mock it.  The wait
        loop calls _query_array_task_states_status directly so it can
        distinguish "sacct exec failed" from "sacct OK but empty".
        """
        states, _exec_failed = self._query_array_task_states_status(array_job_id)
        return states

    _TERMINAL_STATES = frozenset({"COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "OUT_OF_MEMORY", "NODE_FAIL"})
    _SUCCESS_STATE = "COMPLETED"
    _OOM_STATE = "OUT_OF_MEMORY"

    @staticmethod
    def _parse_mem(mem_str: str) -> int:
        """Parse a Slurm memory string (e.g. '4G', '512M') to megabytes."""
        return _parse_mem_str(mem_str)

    @staticmethod
    def _format_mem(mb: int) -> str:
        """Format megabytes as a Slurm memory string (e.g. '4G', '512M')."""
        if mb >= 1024 and mb % 1024 == 0:
            return f"{mb // 1024}G"
        return f"{mb}M"

    @staticmethod
    def _double_mem(mem_str: str) -> str:
        """Double a Slurm memory string (e.g. '4G' -> '8G')."""
        return SlurmBackend._format_mem(SlurmBackend._parse_mem(mem_str) * 2)

    @dataclass
    class _TaskFailure:
        """Structured info about a failed Slurm task."""

        rule: BuildRule
        state: str
        job_id: str

    def _wait_for_arrays(self, index_map: dict[str, list[BuildRule]]) -> list[SlurmBackend._TaskFailure]:
        """Poll sacct until every task in every array reaches a terminal state.

        *index_map* maps array_job_id → ordered list of rules (index == task index).
        Returns a list of _TaskFailure for failed tasks (empty if all succeeded).
        Raises RuntimeError if sacct polling times out, or if sacct fails
        consecutively more than --slurm-sacct-failure-threshold times.
        """
        poll_interval = self.args.slurm_poll_interval
        max_wait_s = getattr(self.args, "slurm_max_wait", 7200.0)
        # Wall-clock cap derived from poll_interval is just a poll-count safety
        # net; the actual cap is enforced via time.monotonic() below so backoff
        # sleeps don't bypass it.
        max_polls = max(1, int(max_wait_s / max(poll_interval, 0.1)))
        polls = 0
        failure_threshold = getattr(self.args, "slurm_sacct_failure_threshold", 10)
        consecutive_failures = 0
        # Cap exponential backoff at 30s so a slurmdbd outage doesn't make the
        # build wait minutes between polls.
        BACKOFF_CAP_S = 30.0

        pending: set[str] = set(index_map)
        failures: list[SlurmBackend._TaskFailure] = []

        while pending:
            if polls >= max_polls:
                raise RuntimeError(
                    f"Timed out after {polls} sacct polls "
                    f"(--slurm-max-wait={max_wait_s}s) waiting for Slurm arrays: " + ", ".join(sorted(pending))
                )
            polls += 1

            still_pending: set[str] = set()
            any_exec_failure = False
            all_exec_failed = True
            for array_job_id in pending:
                rules = index_map[array_job_id]
                states, exec_failed = self._query_array_task_states_status(array_job_id)
                if exec_failed:
                    any_exec_failure = True
                else:
                    all_exec_failed = False

                terminal_tasks = {jid: st for jid, st in states.items() if st in self._TERMINAL_STATES and "_" in jid}
                if len(terminal_tasks) < len(rules):
                    still_pending.add(array_job_id)
                    continue

                # All tasks terminal — mark the parent job terminal so scancel skips it.
                if hasattr(self, "_tracked_jobs"):
                    self._tracked_jobs[array_job_id] = "terminal"

                for jid, st in terminal_tasks.items():
                    if st != self._SUCCESS_STATE:
                        try:
                            idx = int(jid[len(array_job_id) + 1 :])
                            rule = rules[idx]
                            if os.path.exists(rule.output):
                                os.remove(rule.output)
                        except (ValueError, IndexError, OSError):
                            # M1: do not misattribute by falling back to rules[0];
                            # log and skip the malformed entry.
                            logger.warning(
                                "could not parse failed task index from sacct jid %r "
                                "(array_job_id=%s); skipping failure record",
                                jid,
                                array_job_id,
                            )
                            continue
                        failures.append(SlurmBackend._TaskFailure(rule=rule, state=st, job_id=jid))

            # Only count *exec* failures toward the threshold.  An empty
            # response from sacct that ran cleanly is benign (just-submitted
            # array, slurmctld lag) and must not abort the build.
            if pending and all_exec_failed and any_exec_failure:
                consecutive_failures += 1
                if consecutive_failures >= failure_threshold:
                    raise RuntimeError(
                        f"sacct returned no usable data for {consecutive_failures} consecutive polls "
                        f"(threshold={failure_threshold}); pending arrays: " + ", ".join(sorted(pending))
                    )
            else:
                consecutive_failures = 0

            pending = still_pending
            if pending:
                # Back off on consecutive sacct exec failures so a slurmdbd
                # outage doesn't hammer the controller.  Doubles each failure,
                # capped at BACKOFF_CAP_S; reverts to base interval on success.
                if consecutive_failures > 0:
                    sleep_s = min(poll_interval * (2**consecutive_failures), BACKOFF_CAP_S)
                else:
                    sleep_s = poll_interval
                time.sleep(sleep_s)

        return failures

    def _wait_for_output_files(self, rules: list[BuildRule], timeout: float = 30.0) -> None:
        """Wait for compiled output files to become visible on this node.

        On network filesystems, sacct may report a job as COMPLETED before
        the output file metadata has propagated to the submission node.
        This polls briefly so that subsequent link steps don't fail with
        missing .o files.
        """
        missing = [r for r in rules if not os.path.exists(r.output)]
        if not missing:
            return

        start = time.monotonic()
        deadline = start + timeout
        warn_threshold = start + (timeout / 2.0)
        warned = False
        interval = 0.1
        while missing and time.monotonic() < deadline:
            # M4: don't sleep past the deadline.
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(interval, remaining))
            interval = min(interval * 2, 2.0)
            missing = [r for r in missing if not os.path.exists(r.output)]
            if not warned and missing and time.monotonic() >= warn_threshold:
                logger.warning(
                    "ct-slurm: still waiting on %d output file(s) after %.0fs of %.0fs timeout "
                    "(network filesystem metadata lag); raise --slurm-output-wait-timeout if this recurs",
                    len(missing),
                    time.monotonic() - start,
                    timeout,
                )
                warned = True

        if missing:
            names = ", ".join(os.path.basename(r.output) for r in missing[:5])
            msg = (
                f"Slurm reported jobs COMPLETED but {len(missing)} output file(s) "
                f"are still missing after {timeout:.0f}s "
                f"(network filesystem metadata lag, or sacct false-positive): {names}"
            )
            print(f"ct-slurm: {msg}", file=sys.stderr)
            raise RuntimeError(msg)

    # ------------------------------------------------------------------
    # Local execution for link/library rules

    def _run_local(self, rule: BuildRule, traces: TraceStore) -> None:
        """Run a link/library/copy rule locally, with CA short-circuit.

        Non-build-artifact rules (e.g. copy) consult the trace store first so
        the rule is not re-executed on every build when its inputs are unchanged.
        """
        if rule.command is None:
            return

        flat_cmd = list(rule.command)

        if rule.rule_type == RuleType.TEST:
            # Pure-argv test invocation -- NOT a build artefact, so no
            # atomic-output / trace-store semantics. flat_cmd already carries
            # TESTPREFIX + exe + framework XML argv, baked in at graph-build
            # time by _test_command_for. Skip the re-run when the rule's
            # output (the JUnit XML path for framework tests, else the
            # .result marker) already exists: the exe bytes were tested
            # before -- mirrors ShakeBackend and the make/ninja
            # order-only-prereq rule. On success touch the .result marker; on
            # failure append to _test_failures and let sibling locals finish
            # (execute() raises the aggregate once the sweep returns).
            if not getattr(self.args, "use_mtime", False) and os.path.exists(rule.output):
                return
            result = subprocess.run(flat_cmd)
            if result.returncode == 0:
                self._touch_result_marker(rule.success_marker or "")
            else:
                self._test_failures.append(f"{rule.output} (exit {result.returncode}): {' '.join(flat_cmd)}")
            return

        if rule.rule_type in (RuleType.LINK, RuleType.STATIC_LIBRARY, RuleType.SHARED_LIBRARY):
            ca = self._ca_target(rule)
            if os.path.exists(ca):
                compiletools.filesystem_utils.atomic_copy(ca, rule.output)
                return
            out_dir = os.path.dirname(rule.output)
            if out_dir:
                os.makedirs(out_dir, exist_ok=True)
            ca_cmd = [ca if a == rule.output else a for a in flat_cmd]
            ca_dir = os.path.dirname(ca)
            if ca_dir:
                os.makedirs(ca_dir, exist_ok=True)
            execute_link_rule(ca, ca_cmd, self.args)
            compiletools.filesystem_utils.atomic_copy(ca, rule.output)
        else:
            # Non-build-artifact (copy etc.): verify trace before re-executing.
            trace = traces.get(rule.output)
            if trace is not None and self._verify(rule, trace):
                return
            execute_link_rule(rule.output, flat_cmd, self.args)

        traces.put(rule.output, _make_trace_entry(rule, self.context))

    def _execute_build(self, target: str) -> None:
        # SlurmBackend is self-executing via execute(); this path is never used.
        del target
        raise NotImplementedError  # pragma: no cover
