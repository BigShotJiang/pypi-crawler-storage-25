"""Unit tests for the Slurm build backend (no compiler or Slurm required)."""

from __future__ import annotations

import argparse
import contextlib
import os
import subprocess
import threading
import time
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

import compiletools.diagnostics
import compiletools.trace_backend  # ensure registered
from compiletools.build_backend import available_backends, get_backend_class, is_backend_available
from compiletools.build_context import BuildContext
from compiletools.build_graph import BuildGraph, BuildRule
from compiletools.testhelper import TempDirContextNoChange, make_backend_args
from compiletools.trace_backend import (
    _DEFAULT_SLURM_EXPORT,
    SlurmBackend,
    TraceStore,
    _make_trace_entry,
    _slurm_max_wait_arg,
    _slurm_mem_arg,
    _slurm_mem_tiers_arg,
    _slurm_time_arg,
)


class _ScancelMock:
    """Holds both the patcher and the active mock so tests can stop/start."""

    def __init__(self):
        self._patcher = patch.object(SlurmBackend, "_scancel_pending", autospec=True)
        self.mock = self._patcher.start()

    @property
    def called(self):
        return self.mock.called

    def stop(self):
        self._patcher.stop()

    def start(self):
        self.mock = self._patcher.start()


@pytest.fixture(autouse=True)
def _reset_diagnostics_cache():
    """Clear cached invocation_id around every test so filenames don't leak across tests."""
    compiletools.diagnostics._reset_for_tests()
    yield
    compiletools.diagnostics._reset_for_tests()


@pytest.fixture(autouse=True)
def _mock_scancel():
    """Stub out _scancel_pending so execute()'s finally block doesn't shell out.

    Tests that exercise scancel directly should call .stop()/.start() on the
    yielded helper.
    """
    helper = _ScancelMock()
    try:
        yield helper
    finally:
        with contextlib.suppress(RuntimeError):
            helper.stop()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@contextlib.contextmanager
def SlurmBackendTestContext(graph, **arg_overrides):
    """Context manager yielding (backend, _tmpdir) with a SlurmBackend wired to *graph*."""
    slurm_defaults = dict(
        slurm_partition=None,
        slurm_time="00:30:00",
        slurm_mem="2G",
        slurm_cpus=1,
        slurm_account=None,
        slurm_max_array=1000,
        slurm_poll_interval=0.0,  # no sleep in tests
    )
    # Pop test-only options before make_backend_args sees them.
    # When set_diag_dir is True (default), the helper pre-creates and assigns
    # backend._diag_dir so tests that bypass execute() (and call _sbatch_array
    # / _read_slurm_logs_for_failures directly) get the same cached path that
    # execute() would set.  Tests covering the cleanup-path short-circuit when
    # execute() never ran can pass set_diag_dir=False to leave it unset.
    set_diag_dir = arg_overrides.pop("set_diag_dir", True)
    slurm_defaults.update(arg_overrides)
    with TempDirContextNoChange() as tmpdir:
        args = make_backend_args(tmpdir, **slurm_defaults)
        os.makedirs(args.cas_objdir, exist_ok=True)
        backend = SlurmBackend.__new__(SlurmBackend)
        backend.args = args
        backend._graph = graph
        backend.namer = MagicMock()
        backend.context = BuildContext()
        # __init__ is bypassed here; the in-build test-execution path appends
        # failing tests to this list (ShakeBackend.__init__ would set it).
        backend._test_failures = []
        if set_diag_dir:
            backend._diag_dir = compiletools.diagnostics.resolve_diagnostics_dir(args)
        yield backend, tmpdir


def make_compile_rule(output="obj/foo.o", src="src/foo.cpp"):
    return BuildRule(
        output=output,
        inputs=[src],
        command=["g++", "-c", src, "-o", output],
        rule_type="compile",
    )


def make_link_rule(output="bin/foo", inputs=("obj/foo.o",)):
    return BuildRule(
        output=output,
        inputs=list(inputs),
        command=["g++", "-o", output] + list(inputs),
        rule_type="link",
    )


def make_phony_rule(name="build", inputs=()):
    return BuildRule(output=name, inputs=list(inputs), command=None, rule_type="phony")


def _sacct_output(*rows):
    """Build a mock sacct --parsable2 output string."""
    return "\n".join(f"{jid}|{state}" for jid, state in rows) + "\n"


def _sbatch_calls(mock_check_output):
    """Return only the sbatch calls from a check_output mock.

    The broad subprocess.check_output patch also catches unrelated calls
    (e.g. git rev-parse from find_git_root).  Filter to sbatch only.
    """
    return [c for c in mock_check_output.call_args_list if c[0][0][0] == "sbatch"]


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


class TestRegistration:
    def test_registered_as_slurm(self):
        assert get_backend_class("slurm") is SlurmBackend

    def test_name(self):
        assert SlurmBackend.name() == "slurm"

    def test_build_filename(self):
        assert SlurmBackend.build_filename() == ".ct-slurm-traces.json"

    def test_in_available_backends(self):
        assert "slurm" in available_backends()

    def test_separate_trace_file_from_shake(self):
        assert SlurmBackend.build_filename() != ".ct-traces.json"


# ---------------------------------------------------------------------------
# Availability check
# ---------------------------------------------------------------------------


class TestAvailability:
    def test_available_when_sbatch_on_path(self):
        with patch("shutil.which", side_effect=lambda t: "/usr/bin/sbatch" if t == "sbatch" else None):
            assert is_backend_available("slurm") is True

    def test_unavailable_when_sbatch_missing(self):
        with patch("shutil.which", return_value=None):
            assert is_backend_available("slurm") is False


# ---------------------------------------------------------------------------
# Slurm job array submission
# ---------------------------------------------------------------------------


class TestSbatchSubmission:
    def test_compile_rule_submitted_to_slurm(self, tmp_path):
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="12345\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        # One sbatch call (the array submission)
        assert len(_sbatch_calls(mock_sbatch)) == 1
        cmd = mock_sbatch.call_args[0][0]
        assert cmd[0] == "sbatch"
        assert "--parsable" in cmd
        assert "--array=0-0" in cmd

    def test_sbatch_wrap_reads_from_cmds_file(self, tmp_path):
        """The --wrap script reads the compile command from the commands file."""
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="42\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

            cmd = mock_sbatch.call_args[0][0]
            wrap_idx = cmd.index("--wrap")
            wrap_value = cmd[wrap_idx + 1]
            assert "sed" in wrap_value
            assert "SLURM_ARRAY_TASK_ID" in wrap_value
            # Wrap must reference the per-invocation cmds file.
            import re

            m = re.search(r"\.ct-slurm-cmds-[\w\-.]+-0\.txt", wrap_value)
            assert m, f"wrap missing cmds file pattern: {wrap_value}"

    def test_partition_added_when_specified(self, tmp_path):
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph, slurm_partition="gpu") as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="7\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        cmd = mock_sbatch.call_args[0][0]
        assert "--partition" in cmd
        assert "gpu" in cmd

    def test_partition_omitted_when_none(self, tmp_path):
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="7\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        cmd = mock_sbatch.call_args[0][0]
        assert "--partition" not in cmd

    def test_account_added_when_specified(self, tmp_path):
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph, slurm_account="myproject") as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="9\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        cmd = mock_sbatch.call_args[0][0]
        assert "--account" in cmd
        assert "myproject" in cmd

    def test_multiple_compile_rules_in_one_array(self, tmp_path):
        """Multiple compile rules are submitted as a single job array, not N individual jobs."""
        graph = BuildGraph()
        r1 = make_compile_rule(output=str(tmp_path / "a.o"), src="a.cpp")
        r2 = make_compile_rule(output=str(tmp_path / "b.o"), src="b.cpp")
        graph.add_rule(r1)
        graph.add_rule(r2)
        graph.add_rule(make_phony_rule("build", [r1.output, r2.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="55\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        # Both rules in one sbatch call with --array=0-1
        assert len(_sbatch_calls(mock_sbatch)) == 1
        cmd = mock_sbatch.call_args[0][0]
        assert "--array=0-1" in cmd

    def test_large_project_uses_multiple_arrays_with_unique_filenames(self, tmp_path):
        """Projects larger than slurm-max-array get split into multiple job arrays.

        Each chunk must write to uniquely-named command/output files so that
        concurrent chunks do not overwrite each other's task lists.
        """
        graph = BuildGraph()
        rules = []
        for i in range(5):
            r = make_compile_rule(output=str(tmp_path / f"rule{i}.o"), src=f"src{i}.cpp")
            graph.add_rule(r)
            rules.append(r)
        graph.add_rule(make_phony_rule("build", [r.output for r in rules]))

        sbatch_ids = iter(["10\n", "20\n", "30\n"])

        with SlurmBackendTestContext(graph, slurm_max_array=2) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", side_effect=sbatch_ids) as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

            # 5 rules / max_array=2 → ceil(5/2) = 3 sbatch calls
            assert mock_sbatch.call_count == 3

            # Each sbatch call's wrap script must reference a distinct cmds file
            # (per-invocation prefix + per-chunk suffix prevents collisions).
            wrap_files = []
            for c in _sbatch_calls(mock_sbatch):
                cmd = c[0][0]
                wrap_idx = cmd.index("--wrap")
                wrap = cmd[wrap_idx + 1]
                # Extract the cmds-file path from the wrap script
                import re

                m = re.search(r"\.ct-slurm-cmds-[\w\-.]+\.txt", wrap)
                assert m
                wrap_files.append(m.group(0))
            assert len(set(wrap_files)) == 3, f"Expected 3 unique cmds filenames, got: {wrap_files}"


# ---------------------------------------------------------------------------
# Content-addressable short-circuit
# ---------------------------------------------------------------------------


class TestCAShortCircuit:
    def test_existing_output_with_valid_trace_skips_sbatch(self, tmp_path):
        """Compile rules whose output exists AND has a valid trace are skipped."""
        src = str(tmp_path / "foo.cpp")
        out = str(tmp_path / "foo.o")
        (tmp_path / "foo.cpp").write_text("int x;")
        (tmp_path / "foo.o").write_text("compiled")

        rule = make_compile_rule(output=out, src=src)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            backend.args.cas_objdir = str(tmp_path)
            ctx = backend.context

            # Write a valid trace so the file is trusted
            trace_path = str(tmp_path / ".ct-slurm-traces.json")
            store = TraceStore(trace_path)
            store.put(out, _make_trace_entry(rule, ctx))
            store.save()

            with patch("subprocess.check_output") as mock_sbatch:
                backend.execute("build")

            assert len(_sbatch_calls(mock_sbatch)) == 0

    def test_existing_output_without_trace_is_resubmitted(self, tmp_path):
        """Compile rules whose output exists but has no trace are resubmitted.

        A file with no trace was produced by a crashed build (Phase 4 trace-recording
        never ran) and cannot be trusted even if it appears valid on disk.
        """
        out = str(tmp_path / "foo.o")
        graph = BuildGraph()
        rule = make_compile_rule(output=out)
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        # File exists on disk but no trace was recorded for it
        open(out, "w").close()

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="42\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        # Must resubmit despite the file existing — no trace means untrusted
        assert len(_sbatch_calls(mock_sbatch)) == 1


# ---------------------------------------------------------------------------
# Trace-based short-circuit
# ---------------------------------------------------------------------------


class TestTraceVerification:
    def test_valid_trace_skips_sbatch(self, tmp_path):
        """Compile rules with a valid trace are skipped without submitting."""
        src = str(tmp_path / "foo.cpp")
        out = str(tmp_path / "foo.o")
        with open(src, "w") as f:
            f.write("int main(){}")
        with open(out, "w") as f:
            f.write("compiled")

        rule = make_compile_rule(output=out, src=src)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            # Point objdir to tmp_path so the trace file is found
            backend.args.cas_objdir = str(tmp_path)
            ctx = backend.context

            trace_path = str(tmp_path / ".ct-slurm-traces.json")
            store = TraceStore(trace_path)
            store.put(out, _make_trace_entry(rule, ctx))
            store.save()

            with patch("subprocess.check_output") as mock_sbatch:
                backend.execute("build")

            assert len(_sbatch_calls(mock_sbatch)) == 0


# ---------------------------------------------------------------------------
# Failed job handling
# ---------------------------------------------------------------------------


class TestJobFailures:
    def test_failed_job_raises_runtime_error(self, tmp_path):
        out = str(tmp_path / "foo.o")
        rule = make_compile_rule(output=out)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with patch(
                "subprocess.check_output",
                side_effect=[
                    "99\n",  # sbatch returns array job ID
                    _sacct_output(("99_0", "FAILED")),  # sacct for array task
                ],
            ):
                with pytest.raises(RuntimeError, match="Slurm compile jobs failed"):
                    backend.execute("build")

    def test_cancelled_job_raises_runtime_error(self, tmp_path):
        out = str(tmp_path / "foo.o")
        rule = make_compile_rule(output=out)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with patch(
                "subprocess.check_output",
                side_effect=[
                    "88\n",
                    _sacct_output(("88_0", "CANCELLED")),
                ],
            ):
                with pytest.raises(RuntimeError, match="Slurm compile jobs failed"):
                    backend.execute("build")

    def test_failed_job_deletes_corrupt_output_file(self, tmp_path):
        """_wait_for_arrays removes the output file when a task fails (monitoring layer)."""
        out = str(tmp_path / "foo.o")
        open(out, "w").close()  # simulate corrupt artifact from prior crash

        rule = make_compile_rule(output=out)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with patch(
                "subprocess.check_output",
                side_effect=[
                    "99\n",
                    _sacct_output(("99_0", "FAILED")),
                ],
            ):
                with pytest.raises(RuntimeError, match="Slurm compile jobs failed"):
                    backend.execute("build")

        # Monitoring layer must delete the corrupt file on failure
        assert not os.path.exists(out)

    def test_wait_for_arrays_times_out_when_sacct_stops_reporting(self, tmp_path):
        """_wait_for_arrays raises RuntimeError if tasks never reach a terminal state.

        Exercises the poll cap added to prevent infinite hangs when sacct loses
        track of jobs (e.g. accounting history purge or cluster issue).
        """
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))

        b = SlurmBackend.__new__(SlurmBackend)
        # poll_interval=1800 → max_polls = max(1, int(1800/1800)) = 1: times out after 1 poll
        b.args = SimpleNamespace(slurm_poll_interval=1800.0)
        index_map = {"77": [rule]}

        with (
            patch("subprocess.check_output", return_value=_sacct_output(("77_0", "RUNNING"))),
            patch("time.sleep"),  # don't actually sleep
        ):
            with pytest.raises(RuntimeError, match="Timed out"):
                b._wait_for_arrays(index_map)

    def test_wait_for_output_files_raises_when_outputs_missing(self, tmp_path):
        """If sacct says COMPLETED but the output never appears (e.g. NFS
        metadata lag past the timeout, or sacct false-positive), raise
        RuntimeError so the linker doesn't fail later with a confusing
        'no such file' diagnostic far from the cause."""
        rule = make_compile_rule(output=str(tmp_path / "ghost.o"))
        # File is intentionally NOT created

        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(slurm_poll_interval=0.0)

        # Force the polling loop to terminate immediately
        with (
            patch("time.monotonic", side_effect=[0.0, 100.0, 100.0, 100.0]),
            patch("time.sleep"),
        ):
            with pytest.raises(RuntimeError, match=r"output file.*still missing"):
                b._wait_for_output_files([rule], timeout=30.0)

    def test_wait_for_output_files_returns_when_files_appear(self, tmp_path):
        """Outputs that exist immediately must not raise or sleep."""
        out = str(tmp_path / "real.o")
        open(out, "w").close()
        rule = make_compile_rule(output=out)

        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(slurm_poll_interval=0.0)
        # Should return without sleeping or raising
        b._wait_for_output_files([rule], timeout=30.0)

    def test_missing_outputs_preserves_slurm_logs_and_mentions_them(self, tmp_path):
        """When _wait_for_output_files raises, slurm-ct-*.out logs survive on disk
        AND their paths are quoted in the RuntimeError so the user can investigate."""
        # Two compile rules; only the link rule presence triggers the wait.
        ghost_out = str(tmp_path / "ghost.o")
        real_out = str(tmp_path / "real.o")
        ghost_rule = make_compile_rule(output=ghost_out, src="ghost.cpp")
        real_rule = make_compile_rule(output=real_out, src="real.cpp")
        link_rule = make_link_rule(output=str(tmp_path / "app"), inputs=(ghost_out, real_out))

        graph = BuildGraph()
        graph.add_rule(ghost_rule)
        graph.add_rule(real_rule)
        graph.add_rule(link_rule)
        graph.add_rule(make_phony_rule("build", [link_rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            # Pre-create only real_out; ghost_out stays missing
            open(real_out, "w").close()

            log_dir = compiletools.diagnostics.resolve_diagnostics_dir(backend.args)
            log_paths_created: list[str] = []

            def fake_sbatch(*_args, **_kwargs):
                # Create a slurm log named for this invocation's chunk.  The
                # diagnostics directory is per-invocation by construction, so
                # the filename no longer needs the prefix.
                log_path = os.path.join(log_dir, "slurm-ct-0-0.out")
                with open(log_path, "w") as f:
                    f.write("OOM-kill: task ran out of memory\n")
                log_paths_created.append(log_path)
                return "42\n"

            with (
                patch("subprocess.check_output", side_effect=fake_sbatch),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
                patch("time.monotonic", side_effect=[0.0, 100.0, 100.0, 100.0, 100.0]),
                patch("time.sleep"),
            ):
                with pytest.raises(RuntimeError) as excinfo:
                    backend.execute("build")

            assert log_paths_created
            log_path = log_paths_created[0]
            log_basename = os.path.basename(log_path)
            assert log_basename in str(excinfo.value)
            assert "Slurm logs preserved" in str(excinfo.value)
            assert os.path.exists(log_path), "slurm log was deleted before raise"

    def test_missing_outputs_saves_traces_for_completed_compiles(self, tmp_path):
        """When _wait_for_output_files raises, traces for compiles that DID complete
        must be persisted, so the next ct-cake invocation does not re-submit them."""
        ghost_out = str(tmp_path / "ghost.o")
        real_src = str(tmp_path / "real.cpp")
        real_out = str(tmp_path / "real.o")
        # real_src must exist so _make_trace_entry can hash it as an input
        with open(real_src, "w") as f:
            f.write("int x;\n")
        ghost_rule = make_compile_rule(output=ghost_out, src="ghost.cpp")
        real_rule = make_compile_rule(output=real_out, src=real_src)
        link_rule = make_link_rule(output=str(tmp_path / "app"), inputs=(ghost_out, real_out))

        graph = BuildGraph()
        graph.add_rule(ghost_rule)
        graph.add_rule(real_rule)
        graph.add_rule(link_rule)
        graph.add_rule(make_phony_rule("build", [link_rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            # Only the real output exists post-"submission"
            with open(real_out, "w") as f:
                f.write("compiled\n")

            with (
                patch("subprocess.check_output", return_value="55\n"),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
                patch("time.monotonic", side_effect=[0.0, 100.0, 100.0, 100.0, 100.0]),
                patch("time.sleep"),
            ):
                with pytest.raises(RuntimeError):
                    backend.execute("build")

            # Trace store on disk must contain real_out but not ghost_out
            trace_path = os.path.join(backend.args.cas_objdir, ".ct-slurm-traces.json")
            assert os.path.exists(trace_path), "traces.save() was never called on raise path"
            persisted = TraceStore(trace_path)
            assert persisted.get(real_out) is not None, "completed compile not recorded"
            assert persisted.get(ghost_out) is None, "missing output incorrectly recorded"


# ---------------------------------------------------------------------------
# _query_array_task_states parsing
# ---------------------------------------------------------------------------


class TestQueryStates:
    def _make_backend(self, tmp_path):
        args = SimpleNamespace(
            cas_objdir=str(tmp_path),
            slurm_partition=None,
            slurm_time="00:30:00",
            slurm_mem="2G",
            slurm_cpus=1,
            slurm_account=None,
            slurm_max_array=1000,
            slurm_poll_interval=0.0,
        )
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = args
        return b

    def test_parses_completed(self, tmp_path):
        b = self._make_backend(tmp_path)
        sacct_out = _sacct_output(("123_0", "COMPLETED"), ("123_1", "RUNNING"))
        with patch("subprocess.check_output", return_value=sacct_out):
            states = b._query_array_task_states("123")
        assert states["123_0"] == "COMPLETED"
        assert states["123_1"] == "RUNNING"

    def test_skips_batch_substeps(self, tmp_path):
        b = self._make_backend(tmp_path)
        sacct_out = "123|RUNNING\n123_0|COMPLETED\n123_0.batch|COMPLETED\n123_0.extern|COMPLETED\n"
        with patch("subprocess.check_output", return_value=sacct_out):
            states = b._query_array_task_states("123")
        # Only top-level entries (no dots); includes the overall job and array tasks
        assert all("." not in k for k in states)
        assert states["123_0"] == "COMPLETED"

    def test_strips_state_reason(self, tmp_path):
        b = self._make_backend(tmp_path)
        sacct_out = "77_0|CANCELLED by 1001\n"
        with patch("subprocess.check_output", return_value=sacct_out):
            states = b._query_array_task_states("77")
        assert states["77_0"] == "CANCELLED"

    def test_handles_empty_output(self, tmp_path):
        b = self._make_backend(tmp_path)
        with patch("subprocess.check_output", return_value=""):
            states = b._query_array_task_states("999")
        assert states == {}


# ---------------------------------------------------------------------------
# Local link execution
# ---------------------------------------------------------------------------


class TestParallelLocalLink:
    """I5 regression: independent link/library rules must run concurrently
    on the submitter (mirrors Shake backend), not strictly serial."""

    def test_independent_link_rules_run_in_parallel(self, tmp_path):
        """Two independent link rules execute concurrently via asyncio.gather."""
        src_a = str(tmp_path / "a.cpp")
        src_b = str(tmp_path / "b.cpp")
        obj_a = str(tmp_path / "a.o")
        obj_b = str(tmp_path / "b.o")
        exe_a = str(tmp_path / "app_a")
        exe_b = str(tmp_path / "app_b")
        for p in (src_a, src_b):
            with open(p, "w") as f:
                f.write("int x;\n")
        for p in (obj_a, obj_b):
            with open(p, "w") as f:
                f.write("compiled")

        ra = make_compile_rule(output=obj_a, src=src_a)
        rb = make_compile_rule(output=obj_b, src=src_b)
        link_a = make_link_rule(output=exe_a, inputs=[obj_a])
        link_b = make_link_rule(output=exe_b, inputs=[obj_b])

        graph = BuildGraph()
        graph.add_rule(ra)
        graph.add_rule(rb)
        graph.add_rule(link_a)
        graph.add_rule(link_b)
        graph.add_rule(make_phony_rule("build", [exe_a, exe_b]))

        with SlurmBackendTestContext(graph, parallel=4) as (backend, _tmpdir):
            # Pre-populate compile traces so they're skipped.
            store = TraceStore(os.path.join(backend.args.cas_objdir, ".ct-slurm-traces.json"))
            store.put(obj_a, _make_trace_entry(ra, backend.context))
            store.put(obj_b, _make_trace_entry(rb, backend.context))
            store.save()

            # Both links must hit the barrier concurrently to pass.
            barrier = threading.Barrier(2, timeout=5)

            def fake_link(target, cmd, args, **_kw):
                barrier.wait()
                with open(target, "wb") as f:
                    f.write(b"\x7fELF link")
                return 0

            with patch("compiletools.trace_backend.execute_link_rule", side_effect=fake_link) as mock_link:
                backend.execute("build")
                assert mock_link.call_count == 2

    def test_dependent_link_runs_after_input_link(self, tmp_path):
        """A link rule whose input is another link's output must wait for it."""
        # lib_a -> link_b (link_b depends on lib_a's output)
        lib_a = str(tmp_path / "liba.so")
        out_b = str(tmp_path / "appb")
        # Inputs from "compile phase"; pre-existing on disk.  No compile
        # rule for x.o means the Slurm submit phase is skipped (to_submit empty).
        obj = str(tmp_path / "x.o")
        with open(obj, "w") as f:
            f.write("compiled")

        rule_lib = BuildRule(
            output=lib_a,
            inputs=[obj],
            command=["g++", "-shared", "-o", lib_a, obj],
            rule_type="shared_library",
        )
        rule_link = BuildRule(
            output=out_b,
            inputs=[obj, lib_a],
            command=["g++", "-o", out_b, obj, lib_a],
            rule_type="link",
        )

        graph = BuildGraph()
        graph.add_rule(rule_lib)
        graph.add_rule(rule_link)
        graph.add_rule(make_phony_rule("build", [out_b]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            order: list[str] = []

            def fake_link(target, cmd, args, **_kw):
                order.append(target)
                with open(target, "wb") as f:
                    f.write(b"\x7fELF")
                return 0

            with patch("compiletools.trace_backend.execute_link_rule", side_effect=fake_link):
                backend.execute("build")

            # Library must complete before the dependent link.  Order list
            # contains the CA path for each link rule; the lib's path must
            # appear before the executable's.
            lib_idx = next(i for i, t in enumerate(order) if "liba" in t)
            link_idx = next(i for i, t in enumerate(order) if "appb" in t)
            assert lib_idx < link_idx, f"link ran before its dependency: {order}"


class TestLocalLink:
    def test_link_rule_runs_locally_not_via_sbatch(self, tmp_path):
        src = str(tmp_path / "foo.cpp")
        obj = str(tmp_path / "foo.o")
        exe = str(tmp_path / "foo")
        (tmp_path / "foo.cpp").write_text("int main(){}")
        (tmp_path / "foo.o").write_text("compiled")  # pretend compile happened

        compile_rule = make_compile_rule(output=obj, src=src)
        link_rule = make_link_rule(output=exe, inputs=[obj])
        graph = BuildGraph()
        graph.add_rule(compile_rule)
        graph.add_rule(link_rule)
        graph.add_rule(make_phony_rule("build", [exe]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            # Record a valid trace for the compile output so it is trusted and skipped.

            ctx = backend.context
            store = TraceStore(os.path.join(backend.args.cas_objdir, ".ct-slurm-traces.json"))
            store.put(obj, _make_trace_entry(compile_rule, ctx))
            store.save()

            # Link rules now go through atomic_link → _run_with_signal_forwarding;
            # sbatch/sacct (none expected here, since the trace skips compile)
            # would go through subprocess.run.
            with patch("compiletools.locking._run_with_signal_forwarding") as mock_swf:

                def fake_swf(cmd):
                    try:
                        idx = cmd.index("-o")
                        open(cmd[idx + 1], "w").close()
                    except (ValueError, IndexError):
                        pass
                    return subprocess.CompletedProcess(cmd, 0, None, None)

                mock_swf.side_effect = fake_swf
                backend.execute("build")

        # link ran locally via _run_with_signal_forwarding
        mock_swf.assert_called()

    def test_link_rule_routes_through_atomic_link(self, tmp_path):
        """Regression for review issue C2: SlurmBackend._run_local used to wrap
        link rules in `with FileLock(...)` + raw subprocess.run, leaving an
        orphaned linker writing to the now-unlocked target on signal."""
        src = str(tmp_path / "foo.cpp")
        obj = str(tmp_path / "foo.o")
        exe = str(tmp_path / "foo")
        (tmp_path / "foo.cpp").write_text("int main(){}")
        (tmp_path / "foo.o").write_text("compiled")

        compile_rule = make_compile_rule(output=obj, src=src)
        link_rule = make_link_rule(output=exe, inputs=[obj])
        graph = BuildGraph()
        graph.add_rule(compile_rule)
        graph.add_rule(link_rule)
        graph.add_rule(make_phony_rule("build", [exe]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            ctx = backend.context
            store = TraceStore(os.path.join(backend.args.cas_objdir, ".ct-slurm-traces.json"))
            store.put(obj, _make_trace_entry(compile_rule, ctx))
            store.save()

            with patch("compiletools.trace_backend.execute_link_rule") as mock_link:
                mock_link.side_effect = lambda target, cmd, args, **_kw: open(target, "wb").close() or 0
                backend.execute("build")
                # Link routed through execute_link_rule (which wraps atomic_link)
                assert mock_link.call_count == 1

    def test_runtests_runs_test_rules_locally(self):
        """``execute("runtests")`` runs the graph's RuleType.TEST rules through
        the local-rule path (``_run_local``) — the same path the in-build
        sweep uses — not the legacy Python-side ``_run_tests`` sweep."""
        result_path = "/tmp/ct-slurm-runtests/test_foo.result"
        test_rule = BuildRule(
            output=result_path,
            inputs=[],
            command=["/bin/true"],
            rule_type="test",
            order_only_deps=["/tmp/ct-slurm-runtests/test_foo"],
            success_marker=result_path,
        )
        graph = BuildGraph()
        graph.add_rule(test_rule)
        graph.add_rule(make_phony_rule("runtests", [result_path]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with patch.object(backend, "_run_local") as mock_run_local:
                backend.execute("runtests")

        mock_run_local.assert_called_once()
        assert mock_run_local.call_args[0][0] is test_rule

    def test_generate_before_execute_required(self):
        args = SimpleNamespace(
            cas_objdir="/tmp",
            slurm_partition=None,
            slurm_time="00:30:00",
            slurm_mem="2G",
            slurm_cpus=1,
            slurm_account=None,
            slurm_max_array=1000,
            slurm_poll_interval=0.0,
        )
        backend = SlurmBackend.__new__(SlurmBackend)
        backend.args = args
        backend._graph = None

        with pytest.raises(RuntimeError, match="generate\\(\\) must be called"):
            backend.execute("build")


# ---------------------------------------------------------------------------
# Memory estimation and tiered submission
# ---------------------------------------------------------------------------


def _make_rule_with_weight(output, src, include_weight):
    """Create a compile rule with a given include_weight."""
    return BuildRule(
        output=output,
        inputs=[src],
        command=["g++", "-c", src, "-o", output],
        rule_type="compile",
        include_weight=include_weight,
    )


class TestMemoryEstimation:
    """Test _estimate_memory tier boundaries.

    Default tiers (per --slurm-mem-tiers default):
      <=1 -> 1G, <=2 -> 2G, <=4 -> 4G, <=8 -> 8G, <=16 -> 16G,
      else -> --slurm-mem
    """

    def _make_backend(self, slurm_mem="32G", tiers=None):
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(slurm_mem=slurm_mem, slurm_mem_tiers=tiers)
        return b

    def test_zero_weight_gets_1G(self):
        rule = make_compile_rule()
        assert self._make_backend()._estimate_memory(rule) == "1G"

    def test_weight_1_gets_1G(self):
        rule = _make_rule_with_weight("a.o", "a.C", include_weight=1)
        assert self._make_backend()._estimate_memory(rule) == "1G"

    def test_weight_2_gets_2G(self):
        rule = _make_rule_with_weight("a.o", "a.C", include_weight=2)
        assert self._make_backend()._estimate_memory(rule) == "2G"

    def test_weight_4_gets_4G(self):
        rule = _make_rule_with_weight("a.o", "a.C", include_weight=4)
        assert self._make_backend()._estimate_memory(rule) == "4G"

    def test_weight_8_gets_8G(self):
        rule = _make_rule_with_weight("a.o", "a.C", include_weight=8)
        assert self._make_backend()._estimate_memory(rule) == "8G"

    def test_weight_16_gets_16G(self):
        rule = _make_rule_with_weight("a.o", "a.C", include_weight=16)
        assert self._make_backend()._estimate_memory(rule) == "16G"

    def test_weight_above_top_tier_gets_slurm_mem(self):
        rule = _make_rule_with_weight("a.o", "a.C", include_weight=100)
        assert self._make_backend(slurm_mem="64G")._estimate_memory(rule) == "64G"

    def test_custom_tiers_override_defaults(self):
        """--slurm-mem-tiers overrides the class default tier mapping."""
        rule = _make_rule_with_weight("a.o", "a.C", include_weight=1)
        custom = [(1, "500M"), (4, "1G")]
        assert self._make_backend(tiers=custom)._estimate_memory(rule) == "500M"

    @pytest.mark.parametrize("rule_type", ["link", "static_library", "shared_library"])
    @pytest.mark.parametrize(
        "n_inputs,expected",
        [(1, "1G"), (2, "2G"), (4, "4G"), (8, "8G"), (16, "16G")],
    )
    def test_link_rule_sized_by_input_count(self, rule_type, n_inputs, expected):
        """Link/library rules must size on len(inputs), not include_weight=0.

        Regression: link rules carry include_weight=0 (no source file walked),
        which previously matched the smallest tier and OOM-killed real binaries.
        """
        rule = BuildRule(
            output="bin/app",
            inputs=[f"obj{i}.o" for i in range(n_inputs)],
            command=["g++", "-o", "bin/app"] + [f"obj{i}.o" for i in range(n_inputs)],
            rule_type=rule_type,
            include_weight=0,
        )
        assert self._make_backend()._estimate_memory(rule) == expected

    def test_link_rule_above_top_tier_gets_slurm_mem(self):
        """A link rule with more inputs than the largest tier falls off to --slurm-mem."""
        rule = BuildRule(
            output="bin/app",
            inputs=[f"obj{i}.o" for i in range(200)],
            command=["g++", "-o", "bin/app"],
            rule_type="link",
            include_weight=0,
        )
        assert self._make_backend(slurm_mem="64G")._estimate_memory(rule) == "64G"

    def test_link_rule_ignores_include_weight(self):
        """include_weight on a link rule is ignored — sizing is by input count."""
        rule = BuildRule(
            output="bin/app",
            inputs=["a.o", "b.o"],
            command=["g++", "-o", "bin/app", "a.o", "b.o"],
            rule_type="link",
            include_weight=999,
        )
        assert self._make_backend()._estimate_memory(rule) == "2G"


class TestTieredSubmission:
    """Test that rules with different include_weight produce separate sbatch calls."""

    def test_mixed_tiers_produce_separate_sbatch_calls(self, tmp_path):
        """Rules with different memory needs get separate sbatch calls."""
        graph = BuildGraph()
        # Small file: weight=0 -> 1G
        r_small = _make_rule_with_weight(str(tmp_path / "small.o"), "small.C", include_weight=0)
        # Large file: weight=20 -> exceeds top tier (16) -> slurm_mem
        r_large = _make_rule_with_weight(str(tmp_path / "large.o"), "large.C", include_weight=20)
        graph.add_rule(r_small)
        graph.add_rule(r_large)
        graph.add_rule(make_phony_rule("build", [r_small.output, r_large.output]))

        sbatch_ids = iter(["100\n", "200\n"])

        with SlurmBackendTestContext(graph, slurm_mem="32G") as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", side_effect=sbatch_ids) as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        assert mock_sbatch.call_count == 2
        mems = []
        for c in mock_sbatch.call_args_list:
            cmd = c[0][0]
            for arg in cmd:
                if arg.startswith("--mem="):
                    mems.append(arg)
        assert "--mem=1G" in mems
        assert "--mem=32G" in mems

    def test_same_tier_uses_single_sbatch_call(self, tmp_path):
        """Rules in the same memory tier are batched into one array."""
        graph = BuildGraph()
        # Both weight <= 1 -> same tier (1G)
        r1 = _make_rule_with_weight(str(tmp_path / "a.o"), "a.C", include_weight=0)
        r2 = _make_rule_with_weight(str(tmp_path / "b.o"), "b.C", include_weight=1)
        graph.add_rule(r1)
        graph.add_rule(r2)
        graph.add_rule(make_phony_rule("build", [r1.output, r2.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="55\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        # Both in same tier (1G) -> one sbatch call
        assert len(_sbatch_calls(mock_sbatch)) == 1
        cmd = mock_sbatch.call_args[0][0]
        assert "--array=0-1" in cmd
        assert "--mem=1G" in cmd

    def test_sbatch_array_mem_parameter_overrides_default(self, tmp_path):
        """The mem parameter to _sbatch_array overrides self.args.slurm_mem."""
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph, slurm_mem="16G") as (backend, _tmpdir):
            with patch("subprocess.check_output", return_value="42\n") as mock_sbatch:
                backend._sbatch_array([rule], chunk_id=0, mem="1G")

        cmd = mock_sbatch.call_args[0][0]
        assert "--mem=1G" in cmd
        assert "--mem=16G" not in cmd

    def test_sbatch_array_without_mem_uses_default(self, tmp_path):
        """Without mem parameter, _sbatch_array uses self.args.slurm_mem."""
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph, slurm_mem="16G") as (backend, _tmpdir):
            with patch("subprocess.check_output", return_value="42\n") as mock_sbatch:
                backend._sbatch_array([rule], chunk_id=0)

        cmd = mock_sbatch.call_args[0][0]
        assert "--mem=16G" in cmd


# ---------------------------------------------------------------------------
# Memory parsing helpers
# ---------------------------------------------------------------------------


class TestMemoryHelpers:
    def test_parse_mem_gigabytes(self):
        assert SlurmBackend._parse_mem("4G") == 4096

    def test_parse_mem_megabytes(self):
        assert SlurmBackend._parse_mem("512M") == 512

    def test_format_mem_gigabytes(self):
        assert SlurmBackend._format_mem(4096) == "4G"

    def test_format_mem_megabytes(self):
        assert SlurmBackend._format_mem(1500) == "1500M"

    def test_double_mem(self):
        assert SlurmBackend._double_mem("4G") == "8G"
        assert SlurmBackend._double_mem("512M") == "1G"


# ---------------------------------------------------------------------------
# OOM retry
# ---------------------------------------------------------------------------


class TestOOMRetry:
    """Test that OUT_OF_MEMORY failures are retried with doubled memory."""

    def test_oom_jobs_retried_with_doubled_memory(self, tmp_path):
        """OOM jobs are resubmitted with 2x memory."""
        out = str(tmp_path / "foo.o")
        rule = _make_rule_with_weight(out, "foo.C", include_weight=1)  # -> 1G tier
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        # OOM at 1G -> retry at 2G -> COMPLETED
        with SlurmBackendTestContext(graph, slurm_mem="8G") as (backend, _tmpdir):
            with patch(
                "subprocess.check_output",
                side_effect=[
                    "88\n",  # initial sbatch
                    _sacct_output(("88_0", "OUT_OF_MEMORY")),  # sacct poll
                    "99\n",  # retry sbatch
                    _sacct_output(("99_0", "COMPLETED")),  # sacct poll
                ],
            ) as mock_sbatch:
                backend.execute("build")

        sbatch_calls = _sbatch_calls(mock_sbatch)
        assert len(sbatch_calls) == 2
        retry_cmd = sbatch_calls[1][0][0]
        assert "--mem=2G" in retry_cmd

    def test_oom_retry_doubles_until_cap(self, tmp_path):
        """OOM retries double memory each time, stopping at --slurm-mem cap."""
        out = str(tmp_path / "foo.o")
        rule = _make_rule_with_weight(out, "foo.C", include_weight=1)  # -> 1G tier
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        # OOM at 1G -> retry 2G -> OOM at 2G -> retry 4G -> COMPLETED
        with SlurmBackendTestContext(graph, slurm_mem="4G") as (backend, _tmpdir):
            with patch(
                "subprocess.check_output",
                side_effect=[
                    "10\n",
                    _sacct_output(("10_0", "OUT_OF_MEMORY")),
                    "20\n",
                    _sacct_output(("20_0", "OUT_OF_MEMORY")),
                    "30\n",
                    _sacct_output(("30_0", "COMPLETED")),
                ],
            ) as mock_sbatch:
                backend.execute("build")

        sbatch_calls = _sbatch_calls(mock_sbatch)
        assert len(sbatch_calls) == 3
        mems = []
        for c in sbatch_calls:
            cmd = c[0][0]
            for arg in cmd:
                if arg.startswith("--mem="):
                    mems.append(arg)
        assert mems == ["--mem=1G", "--mem=2G", "--mem=4G"]

    def test_oom_at_cap_raises(self, tmp_path):
        """OOM at the memory cap raises RuntimeError."""
        out = str(tmp_path / "foo.o")
        rule = _make_rule_with_weight(out, "foo.C", include_weight=1)  # -> 1G tier
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        # OOM at 1G -> retry 2G -> OOM at 2G -> cap is 2G, fail
        with SlurmBackendTestContext(graph, slurm_mem="2G") as (backend, _tmpdir):
            with patch(
                "subprocess.check_output",
                side_effect=[
                    "10\n",
                    _sacct_output(("10_0", "OUT_OF_MEMORY")),
                    "20\n",
                    _sacct_output(("20_0", "OUT_OF_MEMORY")),
                ],
            ):
                with pytest.raises(RuntimeError, match="Slurm compile jobs failed"):
                    backend.execute("build")

    def test_non_oom_failure_not_retried(self, tmp_path):
        """Non-OOM failures (FAILED, CANCELLED) are not retried."""
        out = str(tmp_path / "foo.o")
        rule = make_compile_rule(output=out)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph, slurm_mem="16G") as (backend, _tmpdir):
            with patch(
                "subprocess.check_output",
                side_effect=[
                    "88\n",
                    _sacct_output(("88_0", "FAILED")),
                ],
            ) as mock_sbatch:
                with pytest.raises(RuntimeError, match="Slurm compile jobs failed"):
                    backend.execute("build")

        # Only one sbatch call — no retry for FAILED
        assert len(_sbatch_calls(mock_sbatch)) == 1

    def test_mixed_failure_retry_persists_successful_traces(self, tmp_path):
        """C2 regression: when one rule fails and another succeeds on retry,
        the successful retry's trace must be persisted BEFORE raise — otherwise
        the next invocation re-submits a known-good output.
        """
        # Two rules: rule_ok succeeds initially; rule_bad FAILS (non-OOM).
        ok_src = str(tmp_path / "ok.cpp")
        ok_out = str(tmp_path / "ok.o")
        bad_out = str(tmp_path / "bad.o")
        with open(ok_src, "w") as f:
            f.write("int x;\n")
        # ok_out exists post-"compile" so trace can hash it.
        with open(ok_out, "w") as f:
            f.write("compiled-ok\n")

        rule_ok = make_compile_rule(output=ok_out, src=ok_src)
        rule_bad = make_compile_rule(output=bad_out, src="bad.cpp")
        graph = BuildGraph()
        graph.add_rule(rule_ok)
        graph.add_rule(rule_bad)
        graph.add_rule(make_phony_rule("build", [ok_out, bad_out]))

        from compiletools.trace_backend import SlurmBackend as _SB

        # First wait: rule_ok COMPLETED, rule_bad FAILED.
        wait_results = iter(
            [
                [_SB._TaskFailure(rule=rule_bad, state="FAILED", job_id="100_0")],
            ]
        )

        with SlurmBackendTestContext(graph, slurm_mem="8G") as (backend, _tmpdir):
            with (
                patch.object(backend, "_wait_for_arrays", side_effect=lambda im: next(wait_results)),
                patch("subprocess.check_output", return_value="100\n"),
            ):
                with pytest.raises(RuntimeError, match="Slurm compile jobs failed"):
                    backend.execute("build")

            # Trace store on disk MUST contain ok_out (it succeeded), so the
            # next invocation does not re-submit it.
            trace_path = os.path.join(backend.args.cas_objdir, ".ct-slurm-traces.json")
            assert os.path.exists(trace_path)
            persisted = TraceStore(trace_path)
            assert persisted.get(ok_out) is not None, (
                "successful compile's trace was dropped because raise happened before the put loop"
            )

    def test_per_rule_retry_cap_aborts_after_threshold(self, tmp_path):
        """A rule that OOMs more than --slurm-rule-retry-cap times is abandoned."""
        out = str(tmp_path / "foo.o")
        rule = _make_rule_with_weight(out, "foo.C", include_weight=1)  # 1G
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        # Cap=1: initial OOM, retry once, then second OOM -> abandon (no third sbatch)
        with SlurmBackendTestContext(
            graph,
            slurm_mem="64G",
            slurm_rule_retry_cap=1,
        ) as (backend, _tmpdir):
            with patch(
                "subprocess.check_output",
                side_effect=[
                    "1\n",
                    _sacct_output(("1_0", "OUT_OF_MEMORY")),
                    "2\n",
                    _sacct_output(("2_0", "OUT_OF_MEMORY")),
                ],
            ) as mock_sbatch:
                with pytest.raises(RuntimeError, match="Slurm compile jobs failed"):
                    backend.execute("build")

        # Exactly 2 sbatch calls (initial + 1 retry) — third would exceed cap.
        assert len(_sbatch_calls(mock_sbatch)) == 2


# ---------------------------------------------------------------------------
# Argparse type validation (Fix I1)
# ---------------------------------------------------------------------------


class TestArgValidation:
    def test_slurm_mem_valid_passes(self):
        assert _slurm_mem_arg("4G") == "4G"
        assert _slurm_mem_arg("512M") == "512M"
        assert _slurm_mem_arg("2048") == "2048"

    def test_slurm_mem_invalid_raises(self):
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_mem_arg("4XB")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_mem_arg("")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_mem_arg("0G")

    def test_slurm_time_valid_passes(self):
        assert _slurm_time_arg("00:30:00") == "00:30:00"
        assert _slurm_time_arg("12:34") == "12:34"
        assert _slurm_time_arg("2-04:00:00") == "2-04:00:00"

    def test_slurm_time_invalid_raises(self):
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_time_arg("notatime")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_time_arg("")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_time_arg("1:2:3:4")

    def test_slurm_mem_tiers_valid_parses(self):
        out = _slurm_mem_tiers_arg("1:1G,4:4G,16:16G")
        assert out == [(1, "1G"), (4, "4G"), (16, "16G")]

    def test_slurm_mem_tiers_invalid_raises(self):
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_mem_tiers_arg("garbage")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_mem_tiers_arg("1:badmem")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_mem_tiers_arg("")

    def test_slurm_mem_tiers_sorts_by_threshold(self):
        out = _slurm_mem_tiers_arg("16:16G,1:1G,4:4G")
        assert out == [(1, "1G"), (4, "4G"), (16, "16G")]

    def test_slurm_max_wait_valid_passes(self):
        assert _slurm_max_wait_arg("60") == 60.0
        assert _slurm_max_wait_arg("0.5") == 0.5
        assert _slurm_max_wait_arg("7200") == 7200.0

    def test_slurm_max_wait_invalid_raises(self):
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_max_wait_arg("")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_max_wait_arg("0")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_max_wait_arg("-1")
        with pytest.raises(argparse.ArgumentTypeError):
            _slurm_max_wait_arg("abc")


class TestSlurmMaxWait:
    """Verify --slurm-max-wait drives the wall-clock cap in _wait_for_arrays."""

    def test_wait_for_arrays_respects_configured_cap(self, tmp_path):
        """A short cap with a never-terminating sacct mock raises Timed out."""
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(
            slurm_poll_interval=0.0,
            slurm_sacct_failure_threshold=10,
            slurm_max_wait=0.05,
        )
        index_map = {"77": [rule]}

        with (
            patch.object(b, "_query_array_task_states_status", return_value=({"77_0": "RUNNING"}, False)),
            patch("time.sleep"),
        ):
            with pytest.raises(RuntimeError, match="Timed out"):
                b._wait_for_arrays(index_map)

    def test_wait_for_arrays_default_cap_is_two_hours(self, tmp_path):
        """When --slurm-max-wait is not in args, default of 7200s applies."""
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        b = SlurmBackend.__new__(SlurmBackend)
        # Intentionally omit slurm_max_wait so getattr() default fires.
        b.args = SimpleNamespace(slurm_poll_interval=2.0, slurm_sacct_failure_threshold=10)
        index_map = {"77": [rule]}

        # Make COMPLETED on first poll so we don't actually loop.
        with (
            patch.object(b, "_query_array_task_states_status", return_value=({"77_0": "COMPLETED"}, False)),
            patch("time.sleep"),
        ):
            failures = b._wait_for_arrays(index_map)
        assert failures == []


# ---------------------------------------------------------------------------
# Per-invocation file naming + cleanup (Fix I2 + I3)
# ---------------------------------------------------------------------------


class TestInvocationFiles:
    def test_two_invocations_produce_distinct_filenames(self, tmp_path):
        graph1 = BuildGraph()
        r1 = make_compile_rule(output=str(tmp_path / "a.o"), src="a.cpp")
        graph1.add_rule(r1)
        graph1.add_rule(make_phony_rule("build", [r1.output]))

        graph2 = BuildGraph()
        r2 = make_compile_rule(output=str(tmp_path / "b.o"), src="b.cpp")
        graph2.add_rule(r2)
        graph2.add_rule(make_phony_rule("build", [r2.output]))

        prefixes: list[str] = []
        for graph in (graph1, graph2):
            # Reset cached invocation_id so each loop iteration is treated as a
            # fresh ct-cake invocation.  The autouse fixture only brackets the
            # whole test, not per-loop.
            compiletools.diagnostics._reset_for_tests()
            # Sleep > 1s so the seconds-resolution timestamp portion of
            # invocation_id() advances even on hosts where the pid is reused.
            time.sleep(1.1)
            with SlurmBackendTestContext(graph) as (backend, _tmp):
                with (
                    patch("subprocess.check_output", return_value="1\n"),
                    patch.object(backend, "_wait_for_arrays", return_value=[]),
                ):
                    backend.execute("build")
                prefixes.append(compiletools.diagnostics.invocation_id())
        assert prefixes[0] != prefixes[1]

    def test_invocation_files_cleaned_up_in_finally(self, tmp_path):
        """cmds/outs files for THIS invocation are removed when execute() returns."""
        graph = BuildGraph()
        r = make_compile_rule(output=str(tmp_path / "a.o"), src="a.cpp")
        graph.add_rule(r)
        graph.add_rule(make_phony_rule("build", [r.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmp):
            with (
                patch("subprocess.check_output", return_value="1\n"),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

            objdir = backend.args.cas_objdir
            leftover = [f for f in os.listdir(objdir) if f.startswith(".ct-slurm-cmds-")]
            assert leftover == []
            leftover_outs = [f for f in os.listdir(objdir) if f.startswith(".ct-slurm-outs-")]
            assert leftover_outs == []

    def test_cleanup_sweeps_stale_temp_files_for_tracked_jobs(self, tmp_path):
        """I6: NODE_FAIL/hard-kill leaves ${OUT}.${jobid}.${task}.tmp behind.
        _cleanup_invocation_files must sweep them for jobs THIS invocation tracked.
        """
        graph = BuildGraph()
        r = make_compile_rule(output=str(tmp_path / "a.o"), src="a.cpp")
        graph.add_rule(r)
        graph.add_rule(make_phony_rule("build", [r.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmp):
            objdir = backend.args.cas_objdir
            # Pre-create stale temps as if NODE_FAIL killed the wrap script.
            stale_a = os.path.join(objdir, "foo.o.42.0.tmp")
            stale_b = os.path.join(objdir, "bar.o.42.5.tmp")
            foreign = os.path.join(objdir, "other.o.999.0.tmp")
            for p in (stale_a, stale_b, foreign):
                with open(p, "w") as f:
                    f.write("partial")

            with (
                patch("subprocess.check_output", return_value="42\n"),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

            # Sweeper removed temps keyed off our jobid (42), not foreign 999.
            assert not os.path.exists(stale_a), "stale temp for tracked job 42 not swept"
            assert not os.path.exists(stale_b), "stale temp for tracked job 42 not swept"
            assert os.path.exists(foreign), "foreign job's temp must NOT be swept"

    def test_cleanup_only_touches_own_invocation_files(self, tmp_path):
        """A foreign-prefix cmds file is NOT removed by this invocation's cleanup."""
        graph = BuildGraph()
        r = make_compile_rule(output=str(tmp_path / "a.o"), src="a.cpp")
        graph.add_rule(r)
        graph.add_rule(make_phony_rule("build", [r.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmp):
            objdir = backend.args.cas_objdir
            foreign = os.path.join(objdir, ".ct-slurm-cmds-other-1234-99.txt")
            with open(foreign, "w") as f:
                f.write("foreign\n")

            with (
                patch("subprocess.check_output", return_value="1\n"),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

            assert os.path.exists(foreign), "foreign cmds file must survive own cleanup"


# ---------------------------------------------------------------------------
# scancel-on-failure (Fix C3)
# ---------------------------------------------------------------------------


class TestScancelOnFailure:
    def test_scancel_called_when_wait_raises(self, tmp_path, _mock_scancel):
        """If _wait_for_arrays raises, scancel runs in the finally block."""
        out = str(tmp_path / "foo.o")
        rule = make_compile_rule(output=out)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="55\n"),
                patch.object(backend, "_wait_for_arrays", side_effect=RuntimeError("boom")),
            ):
                with pytest.raises(RuntimeError, match="boom"):
                    backend.execute("build")

        # _scancel_pending was invoked at least once during finally.
        assert _mock_scancel.called

    def test_scancel_skips_terminal_jobs(self, tmp_path, _mock_scancel):
        """Jobs marked terminal by _wait_for_arrays are not cancelled again."""
        out = str(tmp_path / "foo.o")
        rule = make_compile_rule(output=out)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            backend._tracked_jobs = {"77": "terminal", "88": "pending"}
            # Stop the autouse mock so the real _scancel_pending runs
            _mock_scancel.stop()
            try:
                with patch("subprocess.run") as mock_run:
                    mock_run.return_value = subprocess.CompletedProcess(["scancel"], 0, "", "")
                    backend._scancel_pending()

                assert mock_run.call_count == 1
                args = mock_run.call_args[0][0]
                assert args[0] == "scancel"
                assert "88" in args
                assert "77" not in args
            finally:
                _mock_scancel.start()


# ---------------------------------------------------------------------------
# sacct transient failure handling (Fix C1)
# ---------------------------------------------------------------------------


class TestSacctTransientFailures:
    def test_query_states_returns_empty_on_called_process_error(self, tmp_path):
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(cas_objdir=str(tmp_path))
        with patch(
            "subprocess.check_output",
            side_effect=subprocess.CalledProcessError(1, ["sacct"], stderr="slurmdbd down"),
        ):
            assert b._query_array_task_states("123") == {}

    def test_query_states_returns_empty_on_sacct_missing(self, tmp_path):
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(cas_objdir=str(tmp_path))
        with patch("subprocess.check_output", side_effect=FileNotFoundError("sacct")):
            assert b._query_array_task_states("123") == {}

    def test_wait_for_arrays_recovers_after_one_sacct_failure(self, tmp_path):
        """Single sacct exec failure does not crash — polling continues."""
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(slurm_poll_interval=0.0, slurm_sacct_failure_threshold=10)
        index_map = {"77": [rule]}

        with (
            patch.object(
                b,
                "_query_array_task_states_status",
                side_effect=[({}, True), ({"77_0": "COMPLETED"}, False)],
            ),
            patch("time.sleep"),
        ):
            failures = b._wait_for_arrays(index_map)
        assert failures == []

    def test_wait_for_arrays_raises_after_threshold_failures(self, tmp_path):
        """Persistent sacct EXEC failure raises after threshold consecutive failures.

        Counts only sacct *execution* failures (CalledProcessError / FileNotFoundError),
        not benign "executed OK but returned no rows" cases — a freshly-submitted
        array can legitimately have no rows yet.
        """
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(slurm_poll_interval=0.0, slurm_sacct_failure_threshold=3)
        index_map = {"77": [rule]}

        with (
            patch.object(b, "_query_array_task_states_status", return_value=({}, True)),
            patch("time.sleep"),
        ):
            with pytest.raises(RuntimeError, match="sacct returned no usable data"):
                b._wait_for_arrays(index_map)

    def test_wait_for_arrays_does_not_count_benign_empty_responses(self, tmp_path):
        """C1 regression: 'sacct OK but empty' must NOT trip the failure threshold.

        Newly-submitted job arrays have no sacct rows yet — that's benign and
        must not count as a failure or the build aborts during slurmdbd outages.
        """
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(
            slurm_poll_interval=0.0,
            slurm_sacct_failure_threshold=2,
            slurm_max_wait=7200.0,
        )
        index_map = {"77": [rule]}

        # 5 benign empties (sacct OK, no rows), then COMPLETED — must not raise.
        responses = [
            ({}, False),
            ({}, False),
            ({}, False),
            ({}, False),
            ({}, False),
            ({"77_0": "COMPLETED"}, False),
        ]
        with (
            patch.object(b, "_query_array_task_states_status", side_effect=responses),
            patch("time.sleep"),
        ):
            failures = b._wait_for_arrays(index_map)
        assert failures == []

    def test_wait_for_arrays_backs_off_on_consecutive_failures(self, tmp_path):
        """Consecutive sacct exec failures back off the sleep interval (capped)."""
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace(
            slurm_poll_interval=2.0,
            slurm_sacct_failure_threshold=100,
            slurm_max_wait=7200.0,
        )
        index_map = {"77": [rule]}

        sleeps: list[float] = []

        # 6 exec failures, then success — verify sleep grows then caps.
        responses = [
            ({}, True),
            ({}, True),
            ({}, True),
            ({}, True),
            ({}, True),
            ({}, True),
            ({"77_0": "COMPLETED"}, False),
        ]
        with (
            patch.object(b, "_query_array_task_states_status", side_effect=responses),
            patch("time.sleep", side_effect=sleeps.append),
        ):
            b._wait_for_arrays(index_map)

        # Sleeps must be monotonically non-decreasing on consecutive failures
        # and capped at 30s.
        assert sleeps, "expected at least one sleep call during backoff"
        assert all(s <= 30.0 for s in sleeps), f"sleep exceeded 30s cap: {sleeps}"
        assert max(sleeps) > 2.0, f"backoff never grew beyond base interval: {sleeps}"


# ---------------------------------------------------------------------------
# eval safety in wrap script (Fix C2)
# ---------------------------------------------------------------------------


class TestWrapScriptEval:
    def test_wrap_uses_eval_not_bash_c(self, tmp_path):
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="42\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

        cmd = mock_sbatch.call_args[0][0]
        wrap = cmd[cmd.index("--wrap") + 1]
        # Post-Fix-1: eval reattaches -o "$TMP" so the compile writes to a
        # temp file before atomic rename onto OUT.
        assert 'eval "$CMD' in wrap
        assert 'bash -c "$CMD"' not in wrap

    def test_command_substitution_in_arg_is_quoted_literally(self, tmp_path):
        """A compile arg containing $(...) is single-quoted by shlex.join,
        so eval treats it as a literal string instead of running a subshell."""
        import shlex as _shlex

        rule = BuildRule(
            output=str(tmp_path / "foo.o"),
            inputs=["src/foo.cpp"],
            command=["g++", "-DFOO=$(rogue)", "-c", "src/foo.cpp", "-o", str(tmp_path / "foo.o")],
            rule_type="compile",
        )
        assert rule.command is not None
        line = _shlex.join(rule.command)
        # The metacharacter-bearing token must be single-quoted in the cmds file
        # so that `eval "$CMD"` treats `$(rogue)` as a literal string.
        assert "'-DFOO=$(rogue)'" in line


def test_quoted_define_with_space_survives_flatten(tmp_path, monkeypatch):
    """A token like -DGREETING=Hello World (literal space, no quotes — what
    magicflags emits after its single shlex split) must reach the cmds file as
    a single shell-quoted argv element so the compiler receives one -D, not two
    args.

    Note: post-Fix-1 the trailing ``-o <path>`` pair is stripped from the line
    (the compute-node wrap script reattaches ``-o "$TMP"`` for atomic temp+rename).
    """
    import shlex as _shlex

    graph = BuildGraph()
    rule = BuildRule(
        output=str(tmp_path / "foo.o"),
        inputs=["src/foo.cpp"],
        command=[
            "g++",
            "-O2",
            "-DGREETING=Hello World",
            "-c",
            "src/foo.cpp",
            "-o",
            str(tmp_path / "foo.o"),
        ],
        rule_type="compile",
    )
    graph.add_rule(rule)
    graph.add_rule(make_phony_rule("build", [rule.output]))

    monkeypatch.setattr(compiletools.diagnostics, "invocation_id", lambda: "test")
    with SlurmBackendTestContext(graph) as (backend, _tmpdir):
        backend._created_aux_files = []
        with patch("subprocess.check_output", return_value="42\n"):
            backend._sbatch_array([rule], chunk_id=0)
        cmds_file = os.path.join(
            os.path.realpath(backend.args.cas_objdir),
            ".ct-slurm-cmds-test-0.txt",
        )
        with open(cmds_file) as f:
            line = f.read().strip()

    tokens = _shlex.split(line)
    assert "-DGREETING=Hello World" in tokens, f"GREETING split across argv elements: tokens={tokens!r} line={line!r}"
    # Post-Fix-1: -o is stripped; the wrap script reattaches it pointing at $TMP.
    assert "-o" not in tokens, f"compile cmds-file line must not include -o: tokens={tokens!r}"


# ---------------------------------------------------------------------------
# Atomic compute-node compile (Fix: temp+rename in wrap script)
# ---------------------------------------------------------------------------


class TestAtomicComputeNodeCompile:
    """The compute-node wrap script must use temp+rename so peer readers
    never observe a half-written .o.  The compile command's trailing
    ``-o <path>`` pair is stripped from the cmds file; the wrap script
    reattaches ``-o "$TMP"`` and renames to ``$OUT`` on success.
    """

    def test_cmds_file_omits_o_flag(self, tmp_path, monkeypatch):
        """The cmds file line must NOT contain '-o <path>'."""
        import shlex as _shlex

        rule = make_compile_rule(output=str(tmp_path / "foo.o"), src="src/foo.cpp")
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        monkeypatch.setattr(compiletools.diagnostics, "invocation_id", lambda: "atomic")
        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            backend._created_aux_files = []
            with patch("subprocess.check_output", return_value="1\n"):
                backend._sbatch_array([rule], chunk_id=0)
            cmds_file = os.path.join(
                os.path.realpath(backend.args.cas_objdir),
                ".ct-slurm-cmds-atomic-0.txt",
            )
            with open(cmds_file) as f:
                line = f.read().strip()

        tokens = _shlex.split(line)
        assert "-o" not in tokens, f"-o must be stripped from compile line; got tokens={tokens!r}"
        assert str(tmp_path / "foo.o") not in tokens, f"output path must not appear; got tokens={tokens!r}"

    def test_wrap_script_uses_temp_then_rename(self, tmp_path):
        """The wrap script must compile to a temp file and ``mv -f`` to OUT."""
        rule = make_compile_rule(output=str(tmp_path / "foo.o"), src="src/foo.cpp")
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="1\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")

            cmd = mock_sbatch.call_args[0][0]
            wrap = cmd[cmd.index("--wrap") + 1]

        # Must define a per-task temp path that includes job_id and array_task_id
        # so concurrent retries cannot collide.
        assert "SLURM_JOB_ID" in wrap, f"wrap missing SLURM_JOB_ID in temp path: {wrap}"
        assert "SLURM_ARRAY_TASK_ID" in wrap
        assert ".tmp" in wrap, f"wrap missing temp suffix: {wrap}"
        # Compiler invoked via eval with -o pointing at the temp file.
        # The wrap-script literal contains \" so eval sees -o "$TMP" after one
        # round of unquoting.
        assert r"-o \"$TMP\"" in wrap, f"wrap missing eval with -o $TMP: {wrap}"
        # Atomic rename on success.
        assert 'mv -f "$TMP" "$OUT"' in wrap, f"wrap missing atomic mv: {wrap}"
        # Cleanup on failure.
        assert 'rm -f "$TMP"' in wrap, f"wrap missing temp cleanup on failure: {wrap}"

    def test_assertion_raised_when_compile_rule_missing_o_flag(self, tmp_path):
        """Defensive: a malformed compile rule (no -o) must raise AssertionError."""
        rule = BuildRule(
            output=str(tmp_path / "bad.o"),
            inputs=["bad.cpp"],
            command=["g++", "-c", "bad.cpp"],  # no -o pair
            rule_type="compile",
        )
        with SlurmBackendTestContext(BuildGraph()) as (backend, _tmpdir):
            backend._created_aux_files = []
            with patch("subprocess.check_output", return_value="1\n"):
                with pytest.raises(AssertionError, match="-o"):
                    backend._sbatch_array([rule], chunk_id=0)


# ---------------------------------------------------------------------------
# --slurm-export plumbing (Fix I10)
# ---------------------------------------------------------------------------


class TestSlurmExport:
    def _run_with_export(self, tmp_path, export_value):
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph, slurm_export=export_value) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="42\n") as mock_sbatch,
                patch.object(backend, "_wait_for_arrays", return_value=[]),
            ):
                backend.execute("build")
        return mock_sbatch.call_args[0][0]

    def test_default_export_is_curated_allowlist(self, tmp_path):
        cmd = self._run_with_export(tmp_path, _DEFAULT_SLURM_EXPORT)
        assert f"--export={_DEFAULT_SLURM_EXPORT}" in cmd
        assert "--export=ALL" not in cmd
        assert "LD_LIBRARY_PATH" in _DEFAULT_SLURM_EXPORT

    def test_argparse_default_matches_runtime_fallback_constant(self):
        import configargparse

        parser = configargparse.ArgumentParser()
        SlurmBackend.add_arguments(parser)
        args = parser.parse_args([])
        assert args.slurm_export == _DEFAULT_SLURM_EXPORT

    def test_export_all_when_user_overrides(self, tmp_path):
        cmd = self._run_with_export(tmp_path, "ALL")
        assert "--export=ALL" in cmd

    def test_export_none_when_user_overrides(self, tmp_path):
        cmd = self._run_with_export(tmp_path, "NONE")
        assert "--export=NONE" in cmd


# ---------------------------------------------------------------------------
# stderr capture on sbatch failure (Fix I8)
# ---------------------------------------------------------------------------


class TestSbatchStderr:
    def test_sbatch_failure_includes_stderr_in_message(self, tmp_path):
        graph = BuildGraph()
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            err = subprocess.CalledProcessError(1, ["sbatch"], stderr="invalid partition: bogus")
            with patch("subprocess.check_output", side_effect=err):
                with pytest.raises(RuntimeError, match="invalid partition: bogus"):
                    backend.execute("build")


# ---------------------------------------------------------------------------
# Output-wait timeout configurable (Fix I7)
# ---------------------------------------------------------------------------


class TestOutputWaitTimeout:
    def test_timeout_taken_from_args(self, tmp_path):
        ghost_out = str(tmp_path / "ghost.o")
        ghost_rule = make_compile_rule(output=ghost_out, src="ghost.cpp")
        link_rule = make_link_rule(output=str(tmp_path / "app"), inputs=(ghost_out,))

        graph = BuildGraph()
        graph.add_rule(ghost_rule)
        graph.add_rule(link_rule)
        graph.add_rule(make_phony_rule("build", [link_rule.output]))

        with SlurmBackendTestContext(graph, slurm_output_wait_timeout=7.0) as (backend, _tmpdir):
            captured = {}

            real_wait = backend._wait_for_output_files

            def spy(rules, timeout=30.0):
                captured["timeout"] = timeout
                return real_wait(rules, timeout=timeout)

            with (
                patch("subprocess.check_output", return_value="1\n"),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
                patch.object(backend, "_wait_for_output_files", side_effect=spy),
                patch("time.monotonic", side_effect=[0.0, 100.0, 100.0, 100.0]),
                patch("time.sleep"),
            ):
                with pytest.raises(RuntimeError):
                    backend.execute("build")

            assert captured["timeout"] == 7.0


# ---------------------------------------------------------------------------
# Wrong log-file matching after retry (Fix I6)
# ---------------------------------------------------------------------------


class TestLogLookupExactChunk:
    def test_log_lookup_uses_chunk_id_not_glob(self, tmp_path):
        """Two chunks with same task_idx must produce different log lookups."""
        out_a = str(tmp_path / "a.o")
        out_b = str(tmp_path / "b.o")
        rule_a = make_compile_rule(output=out_a, src="a.cpp")
        rule_b = make_compile_rule(output=out_b, src="b.cpp")
        graph = BuildGraph()
        graph.add_rule(rule_a)
        graph.add_rule(rule_b)
        graph.add_rule(make_phony_rule("build", [out_a, out_b]))

        with SlurmBackendTestContext(graph, slurm_max_array=1) as (backend, _tmpdir):
            backend._chunk_id_for_job = {"100": 0, "200": 1}
            log_dir = compiletools.diagnostics.resolve_diagnostics_dir(backend.args)

            # Two logs, both with task_idx=0 but different chunk_ids.  The
            # diagnostics directory is per-invocation, so filenames no longer
            # carry a prefix.
            log_chunk0 = os.path.join(log_dir, "slurm-ct-0-0.out")
            log_chunk1 = os.path.join(log_dir, "slurm-ct-1-0.out")
            with open(log_chunk0, "w") as f:
                f.write("CONTENT-CHUNK-0\n")
            with open(log_chunk1, "w") as f:
                f.write("CONTENT-CHUNK-1\n")

            failure_for_chunk1 = SlurmBackend._TaskFailure(rule=rule_b, state="FAILED", job_id="200_0")
            diag = backend._read_slurm_logs_for_failures([failure_for_chunk1])
            assert "CONTENT-CHUNK-1" in diag
            assert "CONTENT-CHUNK-0" not in diag


# ---------------------------------------------------------------------------
# Timing collected on failure path (Fix I4)
# ---------------------------------------------------------------------------


class TestTimingIncludesRetries:
    """Tasks that succeed only after an OOM retry must still appear in
    the timing report.  Pre-fix _collect_timing was passed only the
    initial index_map and silently dropped retry-round timings."""

    def test_oom_retry_timing_recorded(self, tmp_path):
        """A rule that OOMs then succeeds on retry has its retry-job elapsed
        time recorded by the timer."""
        out = str(tmp_path / "foo.o")
        rule = _make_rule_with_weight(out, "foo.C", include_weight=1)  # 1G tier
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        # Sequence of subprocess.check_output calls during execute:
        #   sbatch (initial 1G)         -> "100\n"
        #   sbatch (retry 2G)           -> "200\n"
        #   sacct for jobid 100         -> COMPLETED row (initial chunk timing)
        #   sacct for jobid 200         -> COMPLETED row (retry chunk timing)
        sacct_initial = "100_0|00:00:05|COMPLETED\n"
        sacct_retry = "200_0|00:00:09|COMPLETED\n"

        # _wait_for_arrays calls are intercepted; simulate OOM then success.
        from compiletools.trace_backend import SlurmBackend as _SB

        wait_results = iter(
            [
                [_SB._TaskFailure(rule=rule, state=_SB._OOM_STATE, job_id="100_0")],
                [],  # retry succeeded
            ]
        )

        with SlurmBackendTestContext(graph, slurm_mem="8G") as (backend, _tmpdir):
            mock_timer = MagicMock()
            mock_timer._wall_to_monotonic_offset = 0.0
            with (
                patch.object(type(backend), "_timer", new_callable=lambda: property(lambda self: mock_timer)),
                patch.object(backend, "_wait_for_arrays", side_effect=lambda im: next(wait_results)),
                patch(
                    "subprocess.check_output",
                    side_effect=[
                        "100\n",  # initial sbatch
                        "200\n",  # retry sbatch
                        sacct_initial,  # _collect_timing for job 100
                        sacct_retry,  # _collect_timing for job 200 (would be lost pre-fix)
                    ],
                ),
            ):
                backend.execute("build")

        # Both initial-chunk and retry-chunk timings must reach the timer.
        elapsed_seconds = sorted(call.kwargs["elapsed_s"] for call in mock_timer.record_rule.call_args_list)
        assert 5.0 in elapsed_seconds, f"initial chunk elapsed missing: {elapsed_seconds}"
        assert 9.0 in elapsed_seconds, (
            f"retry-chunk elapsed missing — _collect_timing was given only the initial index_map: {elapsed_seconds}"
        )


class TestTimingPopulatesStartEnd:
    """#11 regression: _collect_timing must include Start/End in sacct format
    so Chrome trace renders rules across the timeline, not at t=0."""

    def test_collect_timing_includes_start_end(self, tmp_path):
        rule = make_compile_rule(output=str(tmp_path / "foo.o"))
        b = SlurmBackend.__new__(SlurmBackend)
        b.args = SimpleNamespace()
        mock_timer = MagicMock()
        # _collect_timing reads timer._wall_to_monotonic_offset to shift
        # sacct's wall-clock timestamps into the monotonic clock domain;
        # MagicMock's auto-attr would otherwise poison the arithmetic.
        mock_timer._wall_to_monotonic_offset = 0.0
        # sacct row with ISO 8601 Start/End.
        sacct_row = "100_0|00:00:05|COMPLETED|2026-04-21T10:00:00|2026-04-21T10:00:05\n"

        with (
            patch.object(type(b), "_timer", new_callable=lambda: property(lambda self: mock_timer)),
            patch("subprocess.check_output", return_value=sacct_row),
        ):
            b._collect_timing({"100": [rule]})

        assert mock_timer.record_rule.called
        kwargs = mock_timer.record_rule.call_args.kwargs
        assert "start_s" in kwargs, "start_s missing → Chrome trace stacks at t=0"
        assert "end_s" in kwargs, "end_s missing → Chrome trace stacks at t=0"
        assert kwargs["end_s"] - kwargs["start_s"] == pytest.approx(5.0, abs=1.0)

    def test_local_link_records_start_end(self, tmp_path):
        """Local link rules also pass start_s/end_s through to record_rule."""
        obj = str(tmp_path / "foo.o")
        exe = str(tmp_path / "foo")
        with open(obj, "w") as f:
            f.write("compiled")

        compile_rule = make_compile_rule(output=obj, src=obj)
        link_rule = make_link_rule(output=exe, inputs=[obj])
        graph = BuildGraph()
        graph.add_rule(compile_rule)
        graph.add_rule(link_rule)
        graph.add_rule(make_phony_rule("build", [exe]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            store = TraceStore(os.path.join(backend.args.cas_objdir, ".ct-slurm-traces.json"))
            store.put(obj, _make_trace_entry(compile_rule, backend.context))
            store.save()

            mock_timer = MagicMock()
            with (
                patch.object(type(backend), "_timer", new_callable=lambda: property(lambda self: mock_timer)),
                patch("compiletools.trace_backend.execute_link_rule") as mock_link,
            ):
                mock_link.side_effect = lambda target, cmd, args, **_kw: open(target, "wb").close() or 0
                backend.execute("build")

            link_calls = [c for c in mock_timer.record_rule.call_args_list if c.kwargs.get("rule_type") == "link"]
            assert link_calls, "link rule timing not recorded"
            kwargs = link_calls[0].kwargs
            assert "start_s" in kwargs and "end_s" in kwargs


class TestTimingOnFailure:
    def test_timing_collected_when_output_wait_raises(self, tmp_path):
        """_collect_timing runs even if a later step raises."""
        ghost_out = str(tmp_path / "ghost.o")
        ghost_rule = make_compile_rule(output=ghost_out, src="ghost.cpp")
        link_rule = make_link_rule(output=str(tmp_path / "app"), inputs=(ghost_out,))

        graph = BuildGraph()
        graph.add_rule(ghost_rule)
        graph.add_rule(link_rule)
        graph.add_rule(make_phony_rule("build", [link_rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="1\n"),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
                patch.object(backend, "_collect_timing") as mock_timing,
                patch("time.monotonic", side_effect=[0.0, 100.0, 100.0, 100.0, 100.0]),
                patch("time.sleep"),
            ):
                with pytest.raises(RuntimeError):
                    backend.execute("build")

            assert mock_timing.called


# ---------------------------------------------------------------------------
# CA shortcut for non-build-artifact rules (Fix I9)
# ---------------------------------------------------------------------------


class TestCopyRuleCAShortcut:
    def test_copy_rule_skipped_when_trace_valid(self, tmp_path):
        src = str(tmp_path / "foo.bin")
        dst = str(tmp_path / "out.bin")
        with open(src, "w") as f:
            f.write("data")
        with open(dst, "w") as f:
            f.write("data")

        rule = BuildRule(
            output=dst,
            inputs=[src],
            command=["cp", src, dst],
            rule_type="copy",
        )

        with SlurmBackendTestContext(BuildGraph()) as (backend, _tmpdir):
            store = TraceStore(os.path.join(backend.args.cas_objdir, ".ct-slurm-traces.json"))
            store.put(dst, _make_trace_entry(rule, backend.context))

            with patch("compiletools.trace_backend.execute_link_rule") as mock_link:
                backend._run_local(rule, store)
            assert not mock_link.called, "valid trace should skip re-execution"


# ---------------------------------------------------------------------------
# traces.save() always runs (Fix C-inherited)
# ---------------------------------------------------------------------------


class TestTracesAlwaysSaved:
    def test_traces_saved_on_unexpected_exception(self, tmp_path):
        """An unexpected exception must not strand the trace store."""
        out = str(tmp_path / "foo.o")
        rule = make_compile_rule(output=out)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with (
                patch("subprocess.check_output", return_value="1\n"),
                patch.object(backend, "_wait_for_arrays", side_effect=RuntimeError("kaboom")),
            ):
                with pytest.raises(RuntimeError, match="kaboom"):
                    backend.execute("build")

            # Trace file must exist on disk after the raise
            trace_path = os.path.join(backend.args.cas_objdir, ".ct-slurm-traces.json")
            assert os.path.exists(trace_path), "traces.save() never ran on raise path"


# ---------------------------------------------------------------------------
# Test rules: run locally as part of the Phase 5 sweep
# ---------------------------------------------------------------------------


class TestTestRulesExecutedLocally:
    """RuleType.TEST rules participate in the Phase 5 local-rule sweep:
    _run_local handles them as pure-argv invocations (no atomic_link) and
    touches their .result marker on success. This pins the filter that
    includes them.
    """

    def test_execute_impl_runs_test_rules_locally(self, tmp_path):
        bin_dir = tmp_path / "bin"
        bin_dir.mkdir()
        result_path = str(bin_dir / "test_foo.result")
        test_rule = BuildRule(
            output=result_path,
            inputs=[str(bin_dir / "test_foo")],
            command=[str(bin_dir / "test_foo")],
            rule_type="test",
            success_marker=result_path,
        )
        graph = BuildGraph()
        graph.add_rule(test_rule)
        graph.add_rule(make_phony_rule("runtests", [result_path]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            backend._created_aux_files = []
            backend._tracked_jobs = {}
            backend._chunk_id_for_job = {}
            with patch.object(backend, "_run_local") as mock_run_local:
                traces = TraceStore(os.path.join(backend.args.cas_objdir, "traces.json"))
                backend._execute_impl(graph, traces)

            mock_run_local.assert_called_once()
            assert mock_run_local.call_args[0][0] is test_rule

    @staticmethod
    def _test_rule(tmp_path, command):
        result_path = str(tmp_path / "test_foo.result")
        return result_path, BuildRule(
            output=result_path,
            inputs=[],
            command=command,
            rule_type="test",
            order_only_deps=[str(tmp_path / "test_foo")],
            success_marker=result_path,
        )

    def test_run_local_touches_result_marker_on_success(self, tmp_path):
        result_path, test_rule = self._test_rule(tmp_path, ["/bin/true"])
        graph = BuildGraph()
        graph.add_rule(test_rule)
        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            traces = TraceStore(os.path.join(backend.args.cas_objdir, "traces.json"))
            backend._run_local(test_rule, traces)
            assert os.path.exists(result_path)
            assert backend._test_failures == []

    def test_run_local_buffers_failure_without_touching_marker(self, tmp_path):
        result_path, test_rule = self._test_rule(tmp_path, ["/bin/false"])
        graph = BuildGraph()
        graph.add_rule(test_rule)
        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            traces = TraceStore(os.path.join(backend.args.cas_objdir, "traces.json"))
            backend._run_local(test_rule, traces)
            assert not os.path.exists(result_path)
            assert len(backend._test_failures) == 1

    def test_execute_runtests_runs_and_marks_tests(self, tmp_path):
        """execute("runtests") end-to-end: test rules run via the local sweep
        and their .result markers are touched on success."""
        result_path, test_rule = self._test_rule(tmp_path, ["/bin/true"])
        graph = BuildGraph()
        graph.add_rule(test_rule)
        graph.add_rule(make_phony_rule("runtests", [result_path]))
        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            backend.execute("runtests")
        assert os.path.exists(result_path)

    def test_execute_runtests_raises_on_failure(self, tmp_path):
        result_path, test_rule = self._test_rule(tmp_path, ["/bin/false"])
        graph = BuildGraph()
        graph.add_rule(test_rule)
        graph.add_rule(make_phony_rule("runtests", [result_path]))
        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            with pytest.raises(RuntimeError, match="test execution failed"):
                backend.execute("runtests")
        assert not os.path.exists(result_path)


class TestScancelOnSignal:
    def test_signal_handler_calls_scancel(self, tmp_path, _mock_scancel):
        """SIGINT during execute() triggers scancel via the installed handler."""
        out = str(tmp_path / "foo.o")
        rule = make_compile_rule(output=out)
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [out]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            # Simulate slow polling so we can deliver a signal mid-execute
            block = threading.Event()

            def slow_wait(index_map):
                block.set()
                time.sleep(2.0)
                return []

            with (
                patch("subprocess.check_output", return_value="1\n"),
                patch.object(backend, "_wait_for_arrays", side_effect=slow_wait),
            ):
                exc_holder: list[BaseException] = []

                def runner():
                    try:
                        backend.execute("build")
                    except BaseException as e:
                        exc_holder.append(e)

                t = threading.Thread(target=runner)
                t.start()
                block.wait(2.0)
                # Can't actually deliver SIGINT to a non-main thread reliably;
                # just verify the handler was installed by inspecting state.
                assert "_tracked_jobs" in backend.__dict__
                assert "1" in backend._tracked_jobs
                # Let the slow_wait return so the thread can exit cleanly
                t.join(timeout=5.0)
                # And confirm scancel ran in the finally block
                assert _mock_scancel.called


# ---------------------------------------------------------------------------
# Build-log-dir resolver
# ---------------------------------------------------------------------------


class TestSlurmLogsRouteThroughDiagnostics:
    """Slurm log paths must route through compiletools.diagnostics, not objdir."""

    def test_no_call_site_uses_objdir_for_slurm_log_filenames(self):
        """Regression guard: line-based check for slurm-ct-*.out filenames
        joined with objdir on the same line.  Cheap and catches the naive
        mistake.  Note: this is intentionally line-based and can be evaded
        by multi-line ``os.path.join`` calls.  The diagnostics-dir invariant
        is also enforced by the integration tests in
        :class:`TestSbatchUsesDiagnosticsDir`, which exercise the actual
        sbatch argv path.
        """
        import compiletools.trace_backend as tb

        with open(tb.__file__, encoding="utf-8") as fh:
            source = fh.read()
        offending = []
        for lineno, line in enumerate(source.splitlines(), start=1):
            if "slurm-ct-" not in line or ".out" not in line:
                continue
            if "self.args.cas_objdir" in line or "real_objdir" in line:
                offending.append((lineno, line.strip()))
        assert not offending, (
            "slurm log filenames must be joined with "
            "compiletools.diagnostics.resolve_diagnostics_dir(self.args), not objdir.  "
            f"Offending lines: {offending}"
        )

    def test_cleanup_path_does_not_create_diagnostics_dir_when_execute_never_ran(self, tmp_path):
        """If execute() raised before caching self._diag_dir (or was never
        called at all), the cleanup path must short-circuit and NOT mint an
        empty diagnostics directory for an invocation that produced no logs.
        """
        rule = make_compile_rule(output=str(tmp_path / "foo.o"), src="foo.cpp")
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph, set_diag_dir=False) as (backend, _tmpdir):
            iid = compiletools.diagnostics.invocation_id()
            diag_dir = os.path.join(backend.args.bindir, "diagnostics", iid)
            assert not os.path.exists(diag_dir), "precondition: diag dir absent"

            # execute() was never called, so backend._diag_dir is unset.
            assert not hasattr(backend, "_diag_dir")

            # Cleanup-path entry point must return [] without creating anything.
            assert backend._invocation_log_paths() == []
            assert not os.path.exists(diag_dir), (
                "cleanup path must not create diagnostics dir for invocation that never reached execute()"
            )


# ---------------------------------------------------------------------------
# Sbatch routing through diagnostics
# ---------------------------------------------------------------------------


class TestSbatchUsesDiagnosticsDir:
    """sbatch --output/--error paths must come from
    compiletools.diagnostics.resolve_diagnostics_dir(), not objdir.
    """

    def test_sbatch_output_path_under_bindir_diagnostics_by_default(self, tmp_path):
        rule = make_compile_rule(output=str(tmp_path / "foo.o"), src="foo.cpp")
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        with SlurmBackendTestContext(graph) as (backend, _tmpdir):
            captured = {}

            def fake_sbatch(cmd, *args, **kwargs):
                for tok in cmd:
                    if tok.startswith("--output="):
                        captured["output"] = tok.split("=", 1)[1]
                    elif tok.startswith("--error="):
                        captured["error"] = tok.split("=", 1)[1]
                return "42\n"

            with (
                patch("subprocess.check_output", side_effect=fake_sbatch),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
                patch.object(backend, "_wait_for_output_files"),
            ):
                open(rule.output, "w").close()
                with contextlib.suppress(Exception):
                    backend.execute("build")

            iid = compiletools.diagnostics.invocation_id()
            expected_dir = os.path.join(backend.args.bindir, "diagnostics", iid)
            assert "output" in captured, "sbatch was never called"
            assert captured["output"].startswith(expected_dir + os.sep), (
                f"slurm --output should live under {expected_dir}, got {captured['output']}"
            )
            assert captured["error"] == captured["output"]

    def test_sbatch_output_path_uses_explicit_diagnostics_dir(self, tmp_path):
        rule = make_compile_rule(output=str(tmp_path / "foo.o"), src="foo.cpp")
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        override = str(tmp_path / "scratch-diag")
        with SlurmBackendTestContext(graph, diagnostics_dir=override) as (backend, _tmpdir):
            captured = {}

            def fake_sbatch(cmd, *args, **kwargs):
                for tok in cmd:
                    if tok.startswith("--output="):
                        captured["output"] = tok.split("=", 1)[1]
                return "42\n"

            with (
                patch("subprocess.check_output", side_effect=fake_sbatch),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
                patch.object(backend, "_wait_for_output_files"),
            ):
                open(rule.output, "w").close()
                with contextlib.suppress(Exception):
                    backend.execute("build")

            iid = compiletools.diagnostics.invocation_id()
            expected_dir = os.path.join(override, iid)
            assert "output" in captured, "sbatch was never called"
            assert captured["output"].startswith(expected_dir + os.sep), (
                f"slurm --output should live under {expected_dir}, got {captured.get('output')}"
            )
            assert os.path.isdir(expected_dir), "diagnostics dir must be created if missing"

    def test_diagnostics_dir_created_when_missing(self, tmp_path):
        """The default <bindir>/diagnostics/<iid>/ must be created on first sbatch."""
        rule = make_compile_rule(output=str(tmp_path / "foo.o"), src="foo.cpp")
        graph = BuildGraph()
        graph.add_rule(rule)
        graph.add_rule(make_phony_rule("build", [rule.output]))

        # set_diag_dir=False: skip the helper's pre-creation so we can
        # observe execute() minting the leaf on its own.
        with SlurmBackendTestContext(graph, set_diag_dir=False) as (backend, _tmpdir):
            iid = compiletools.diagnostics.invocation_id()
            diag_dir = os.path.join(backend.args.bindir, "diagnostics", iid)
            # invocation_id() is pure-string and creates no directories;
            # the leaf will be minted by the in-execute()
            # resolve_diagnostics_dir call.
            assert not os.path.exists(diag_dir), "precondition: diag dir absent before sbatch"

            sbatch_calls = []

            def fake_sbatch(*_args, **_kwargs):
                sbatch_calls.append(1)
                return "42\n"

            with (
                patch("subprocess.check_output", side_effect=fake_sbatch),
                patch.object(backend, "_wait_for_arrays", return_value=[]),
                patch.object(backend, "_wait_for_output_files"),
            ):
                open(rule.output, "w").close()
                with contextlib.suppress(Exception):
                    backend.execute("build")

            assert sbatch_calls, "sbatch was never called"
            assert os.path.isdir(diag_dir), "diagnostics dir must exist after sbatch"
