//
// Created by Giuliano Iorio on 15/10/24.
//

//
// Created by Giuliano Iorio on 15/10/24.
//

#include <wdhurleyhe.h>
#include <star.h>

WDHurleyHE::WDHurleyHE(_UNUSED Star* s, _UNUSED utilities::MassContainer* preWDmass) : WDFormation(s,preWDmass) {

    double preWDMCO{0.}, preWDMHE{0.};
    if (preWDmass != nullptr){
        preWDMCO = preWDmass->MCO;
        preWDMHE = preWDmass->MHE;
    } else{
        preWDMCO = s->getp(MCO::ID);
        preWDMHE = s->getp(MHE::ID);
    }

    set_WD_mass(preWDMHE); //WD mass taken as the mass of the HE core
    //GI: 26/04/2023
    //TODO: Is this the best implementation we can have? It is true that a stripped low mass star never ignite Helium?
    //Following Hurley, a HeWD is formed when a low-mass star (a star with MZAMS<MHEf, mass helium flash) loses the envelope when it is
    //has not yet started the core Helium burning (see setting kw = 10 in hrdiag.f).
    //So here we just assume that a HeWD is formed if the stars arrive at this point with a MCO=0. ATM, it is not really possible
    //to arrive here through normal SSE with MCO=0, but this method can be triggered externally by some event in binary.
    //This is what we actually implemented in the method used to transform the star in a pureHe (Star::jump_to_pureHE_tracks), if it has not a CO core yet and Mzams< approx 2,
    //the turn_into_remnant method is called and we enter in the first condition forming a HeWD.
    if (preWDMCO<=utilities::TINY){
        set_WD_type(Lookup::Remnants::HeWD);
    }
    else {
        if (preWDMHE < 1.6) //TODO 1.6 limit is taken from Hurley (M_{c,BAGB}), Section 6 of https://academic.oup.com/mnras/article/315/3/543/972062
            set_WD_type(Lookup::Remnants::COWD);
        else
            set_WD_type(Lookup::Remnants::ONeWD);
    }

}

