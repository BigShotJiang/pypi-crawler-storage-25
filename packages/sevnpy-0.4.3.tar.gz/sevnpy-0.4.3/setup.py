from setuptools import setup, Extension
import sys
import glob
import os
import numpy

# Ensure all relative paths in this file are relative to setup.py's directory,
# regardless of which directory the build tool invokes us from.
_HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(_HERE)

""""""""""""""""""""""""""""""""""""
"          SETUP UTILS             "
""""""""""""""""""""""""""""""""""""
def include_all_sources(root_path):
    # CWD == _HERE, so glob returns paths relative to setup.py
    return glob.glob(f"{root_path}/**/*.cpp", recursive=True)

def include_all_dirs(root_path):
    # Absolute paths are required for compiler -I flags
    abs_root = os.path.join(_HERE, root_path)
    dirs = [abs_root]
    for dirpath, dirnames, _ in os.walk(abs_root):
        for dn in dirnames:
            dirs.append(os.path.join(dirpath, dn))
    return dirs

""""""""""""""""""""""""""""""""""""
"          SETUP UTILS  END        "
""""""""""""""""""""""""""""""""""""

# Check Python version
if sys.version_info < (3, 7):
    sys.exit('Sorry, Python < 3.7 is not supported by SEVNpy')

# Locate SEVN C++ sources:
#   - _sevnsrc/ is present when building from the PyPI sdist or after `make prepare_dist`
#   - ../src is used when building in-place from the SEVN repository
if os.path.isdir("_sevnsrc/src"):
    sevn_src_root = "_sevnsrc/src"
    sevn_inc_root = "_sevnsrc/include"
elif os.path.isdir("../src"):
    sevn_src_root = "../src"
    sevn_inc_root = "../include"
else:
    sys.exit(
        "Cannot find SEVN C++ sources. Either run `make prepare_dist` first "
        "or build from within the SEVN repository."
    )

# To get the version
exec(open('sevnpy/version.py').read())
# To get the long description from README.md
with open("README.md", "r") as fh:
    long_description = fh.read()

all_sources = include_all_sources(sevn_src_root) + include_all_sources("sevnpy/sevn/src")

all_includes = (
    include_all_dirs(sevn_src_root)
    + include_all_dirs(sevn_inc_root)
    + include_all_dirs("sevnpy/sevn/src")
    + [numpy.get_include()]
)

module = Extension(
    "sevnpy.sevn.sevnwrap",
    sources=all_sources,
    include_dirs=all_includes,
    extra_compile_args=["-O3", "-std=c++11"],
    language="c++",
)

setup(
    name="SEVNpy",
    version=__version__,
    author="Giuliano Iorio",
    author_email="giuliano.iorio.astro@gmail.com",
    description="A Python companion module for SEVN",
    license="MIT",
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
    packages=["sevnpy", "sevnpy.sevn", "sevnpy.utility", "sevnpy.io", "sevnpy.auxiliary_data"],
    package_data={
        "sevnpy.auxiliary_data": ["*"],
    },
    ext_modules=[module],
    install_requires=[
        "numpy",
        "pandas",
        "scipy",
        "typing_extensions",
    ],
)
