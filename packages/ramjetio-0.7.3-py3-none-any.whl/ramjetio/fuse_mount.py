"""
FUSE Cache Mount for RAMJET

Presents the distributed cache as a mountable local directory.
Any framework (YOLO, HuggingFace, PyTorch) reads files normally —
cache.get/set happens transparently under the hood.

Usage:
    from ramjetio.fuse_mount import RamjetMount

    mount = RamjetMount(s3_client, cache, manifest)
    mount.mount('/tmp/ramjet_fuse')
    # ... training reads from /tmp/ramjet_fuse ...
    mount.unmount()

Requires: pip install ramjetio[fuse]
Docker: --device /dev/fuse --cap-add SYS_ADMIN
"""

import os
import stat
import errno
import time
import logging
import threading
import subprocess
from typing import Dict, List, Optional, Any, Tuple
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

# Optional FUSE dependency
try:
    import fuse
    fuse.fuse_python_api = (0, 2)
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False


def fuse_available() -> Tuple[bool, Optional[str]]:
    """
    Check if FUSE is usable in the current environment.
    
    Returns:
        (available, message): True if FUSE can be used, else False with reason.
    """
    if not FUSE_AVAILABLE:
        return False, (
            "FUSE mount requires fusepy. Install with:\n"
            "  pip install ramjetio[fuse]\n"
            "Falling back to export_local()."
        )
    
    if os.name == 'nt':
        return False, "FUSE is not supported on Windows. Falling back to export_local()."
    
    if not os.path.exists('/dev/fuse'):
        return False, (
            "FUSE device not found (/dev/fuse). If running in Docker, add:\n"
            "  docker run --device /dev/fuse --cap-add SYS_ADMIN ...\n"
            "For Kubernetes pods:\n"
            "  securityContext:\n"
            "    capabilities:\n"
            "      add: ['SYS_ADMIN']\n"
            "Falling back to export_local()."
        )
    
    return True, None


class FileBuffer:
    """In-memory buffer for a single file's content."""
    __slots__ = ('data', 'size', 'atime')
    
    def __init__(self, data: bytes):
        self.data = data
        self.size = len(data)
        self.atime = time.monotonic()


class LRUFileCache:
    """
    Thread-safe LRU cache for file contents.
    Evicts least-recently-used entries when max_size_bytes is exceeded.
    """
    
    def __init__(self, max_size_bytes: int = 2 * 1024 * 1024 * 1024):  # 2GB default
        self._cache: OrderedDict[str, FileBuffer] = OrderedDict()
        self._lock = threading.Lock()
        self._current_size = 0
        self._max_size = max_size_bytes
    
    def get(self, path: str) -> Optional[bytes]:
        with self._lock:
            buf = self._cache.get(path)
            if buf is None:
                return None
            # Move to end (most recently used)
            self._cache.move_to_end(path)
            buf.atime = time.monotonic()
            return buf.data
    
    def put(self, path: str, data: bytes) -> None:
        with self._lock:
            # Remove if already exists
            if path in self._cache:
                old = self._cache.pop(path)
                self._current_size -= old.size
            
            buf = FileBuffer(data)
            
            # Evict LRU entries until we have space
            while self._current_size + buf.size > self._max_size and self._cache:
                _, evicted = self._cache.popitem(last=False)
                self._current_size -= evicted.size
            
            self._cache[path] = buf
            self._current_size += buf.size
    
    @property
    def size(self) -> int:
        return self._current_size


class RamjetFuseFS(fuse.Operations if FUSE_AVAILABLE else object):
    """
    FUSE filesystem backed by distributed cache + S3 fallback.
    
    File reads go through:
      1. LRU in-memory buffer (fastest)
      2. Distributed cache — cache.get() (fast, local or remote node)
      3. S3/HTTP fallback — s3_client.get_bytes() (slow, origin)
      → On miss: cache.set() in background for other nodes
    
    Metadata (stat, readdir) served from in-memory manifest — zero network calls.
    """
    
    def __init__(self, data_client, cache, manifest: Dict[str, int], 
                 buffer_max_bytes: int = 2 * 1024 * 1024 * 1024):
        """
        Args:
            data_client: S3Client or HTTPClient with .get_bytes(path) method
            cache: DistributedCache instance (or None for no caching)
            manifest: Dict of {relative_path: file_size_bytes}
            buffer_max_bytes: Max size for in-memory LRU buffer (default 2GB)
        """
        self._client = data_client
        self._cache = cache
        self._manifest = manifest  # {path: size}
        self._buffer = LRUFileCache(max_size_bytes=buffer_max_bytes)
        self._bg_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="fuse_cache")
        
        # Build directory tree from manifest
        self._dirs: Dict[str, set] = {'/': set()}
        for path in manifest:
            parts = path.strip('/').split('/')
            current = '/'
            for i, part in enumerate(parts[:-1]):
                next_dir = f"{current}{part}/" if current == '/' else f"{current}/{part}/"
                next_dir_clean = '/' + '/'.join(parts[:i+1])
                if next_dir_clean not in self._dirs:
                    self._dirs[next_dir_clean] = set()
                # Add to parent
                parent = '/' + '/'.join(parts[:i]) if i > 0 else '/'
                self._dirs.setdefault(parent, set()).add(part)
                current = next_dir_clean
            # Add file to parent dir
            parent = '/' + '/'.join(parts[:-1]) if len(parts) > 1 else '/'
            self._dirs.setdefault(parent, set()).add(parts[-1])
        
        self._mount_time = time.time()
        self._uid = os.getuid()
        self._gid = os.getgid()
    
    # ------------------------------------------------------------------
    # Metadata operations (from in-memory manifest, zero network)
    # ------------------------------------------------------------------
    
    def getattr(self, path, fh=None):
        """Return file/directory attributes from manifest."""
        if path in self._dirs:
            # Directory
            return {
                'st_mode': stat.S_IFDIR | 0o555,
                'st_nlink': 2 + len(self._dirs[path]),
                'st_uid': self._uid,
                'st_gid': self._gid,
                'st_size': 0,
                'st_atime': self._mount_time,
                'st_mtime': self._mount_time,
                'st_ctime': self._mount_time,
            }
        
        # Strip leading /
        rel_path = path.lstrip('/')
        if rel_path in self._manifest:
            return {
                'st_mode': stat.S_IFREG | 0o444,
                'st_nlink': 1,
                'st_uid': self._uid,
                'st_gid': self._gid,
                'st_size': self._manifest[rel_path],
                'st_atime': self._mount_time,
                'st_mtime': self._mount_time,
                'st_ctime': self._mount_time,
            }
        
        raise fuse.FuseOSError(errno.ENOENT)
    
    def readdir(self, path, fh):
        """List directory contents from manifest."""
        entries = ['.', '..']
        
        if path in self._dirs:
            entries.extend(self._dirs[path])
        
        return entries
    
    def open(self, path, flags):
        """Open is stateless — just validate the file exists."""
        rel_path = path.lstrip('/')
        if rel_path not in self._manifest:
            raise fuse.FuseOSError(errno.ENOENT)
        
        # Read-only check
        accmode = os.O_RDONLY | os.O_WRONLY | os.O_RDWR
        if (flags & accmode) != os.O_RDONLY:
            raise fuse.FuseOSError(errno.EACCES)
        
        return 0
    
    # ------------------------------------------------------------------
    # Read operation (cache-backed with S3 fallback)
    # ------------------------------------------------------------------
    
    def read(self, path, size, offset, fh):
        """
        Read file data. Three-tier: LRU buffer → distributed cache → S3.
        Loads entire file on first access for efficiency.
        """
        rel_path = path.lstrip('/')
        
        if rel_path not in self._manifest:
            raise fuse.FuseOSError(errno.ENOENT)
        
        # Tier 1: In-memory LRU buffer
        data = self._buffer.get(rel_path)
        if data is not None:
            return data[offset:offset + size]
        
        # Tier 2: Distributed cache
        if self._cache:
            cache_key = f"fuse:{rel_path}"
            try:
                cached = self._cache.get(cache_key)
                if cached is not None:
                    # cached could be bytes or pickled bytes
                    if isinstance(cached, bytes):
                        data = cached
                    else:
                        data = bytes(cached)
                    self._buffer.put(rel_path, data)
                    return data[offset:offset + size]
            except Exception as e:
                logger.debug(f"Cache get failed for {rel_path}: {e}")
        
        # Tier 3: S3/HTTP origin fetch
        try:
            data = self._client.get_bytes(rel_path)
        except Exception as e:
            logger.error(f"Failed to fetch {rel_path} from origin: {e}")
            raise fuse.FuseOSError(errno.EIO)
        
        # Store in buffer
        self._buffer.put(rel_path, data)
        
        # Background cache.set for other nodes
        if self._cache and data:
            self._bg_pool.submit(self._safe_cache_set, f"fuse:{rel_path}", data)
        
        return data[offset:offset + size]
    
    def _safe_cache_set(self, key: str, value: bytes) -> None:
        """Fire-and-forget cache set."""
        try:
            self._cache.set(key, value)
        except Exception:
            pass
    
    # ------------------------------------------------------------------
    # Unsupported write operations (read-only filesystem)
    # ------------------------------------------------------------------
    
    def write(self, path, data, offset, fh):
        raise fuse.FuseOSError(errno.EROFS)
    
    def create(self, path, mode, fi=None):
        raise fuse.FuseOSError(errno.EROFS)
    
    def mkdir(self, path, mode):
        raise fuse.FuseOSError(errno.EROFS)
    
    def unlink(self, path):
        raise fuse.FuseOSError(errno.EROFS)
    
    def rmdir(self, path):
        raise fuse.FuseOSError(errno.EROFS)
    
    def rename(self, old, new):
        raise fuse.FuseOSError(errno.EROFS)
    
    def truncate(self, path, length, fh=None):
        raise fuse.FuseOSError(errno.EROFS)
    
    def chmod(self, path, mode):
        raise fuse.FuseOSError(errno.EROFS)
    
    def chown(self, path, uid, gid):
        raise fuse.FuseOSError(errno.EROFS)
    
    def statfs(self, path):
        """Return filesystem stats."""
        total_size = sum(self._manifest.values())
        block_size = 4096
        total_blocks = max(total_size // block_size, 1)
        return {
            'f_bsize': block_size,
            'f_frsize': block_size,
            'f_blocks': total_blocks,
            'f_bfree': 0,
            'f_bavail': 0,
            'f_files': len(self._manifest),
            'f_ffree': 0,
            'f_favail': 0,
            'f_namemax': 255,
        }
    
    def destroy(self, path):
        """Cleanup on unmount."""
        self._bg_pool.shutdown(wait=False)


class RamjetMount:
    """
    High-level API for mounting distributed cache as a local directory.
    
    Multi-process safe: when torchrun --nproc_per_node > 1, only the first
    process mounts FUSE. Other processes detect the existing mount and reuse it.
    
    Usage:
        mount = RamjetMount(s3_client, cache)
        mount.mount('/tmp/ramjet_fuse', manifest={'images/001.jpg': 45000, ...})
        # ... training reads from /tmp/ramjet_fuse/images/001.jpg ...
        mount.unmount()
    """
    
    def __init__(self, data_client, cache=None, buffer_max_bytes: int = 2 * 1024 * 1024 * 1024):
        """
        Args:
            data_client: S3Client or HTTPClient with .get_bytes(path)
            cache: DistributedCache instance (or None)
            buffer_max_bytes: LRU buffer size limit (default 2GB)
        """
        self._client = data_client
        self._cache = cache
        self._buffer_max = buffer_max_bytes
        self._mount_point: Optional[str] = None
        self._fuse_thread: Optional[threading.Thread] = None
        self._fuse_server = None
        self._mounted = threading.Event()
        self._is_owner = False  # True if this process created the mount
    
    @property
    def is_mounted(self) -> bool:
        return self._mount_point is not None and self._fuse_thread is not None and self._fuse_thread.is_alive()
    
    def mount(self, path: str, manifest: Dict[str, int], foreground: bool = False) -> str:
        """
        Mount the distributed cache at the given path.
        
        Multi-process safe: if another process already mounted at this path,
        reuses the existing mount instead of creating a new one.
        
        Args:
            path: Local mount point (will be created if needed)
            manifest: Dict of {relative_path: file_size_bytes}
            foreground: Run FUSE in foreground (blocking). Default: background thread.
            
        Returns:
            The mount path.
        """
        available, msg = fuse_available()
        if not available:
            raise RuntimeError(msg)
        
        # Multi-process guard: if already mounted (e.g., another local_rank), reuse it
        lockfile = f"{path}.ramjet.lock"
        if os.path.ismount(path):
            # Verify it's alive by checking if we can list directory
            try:
                os.listdir(path)
                logger.info(f"Reusing existing FUSE mount at {path} (another process owns it)")
                self._mount_point = path
                self._is_owner = False
                return path
            except OSError:
                # Stale mount — clean it up
                logger.info(f"Cleaning stale mount at {path}")
                _fusermount_unmount(path)
                time.sleep(0.5)
        
        os.makedirs(path, exist_ok=True)
        
        # Write lockfile with PID
        try:
            with open(lockfile, 'w') as f:
                f.write(str(os.getpid()))
        except OSError:
            pass
        
        fs = RamjetFuseFS(
            data_client=self._client,
            cache=self._cache,
            manifest=manifest,
            buffer_max_bytes=self._buffer_max,
        )
        self._fs = fs  # Keep reference for direct buffer access (prefetch)
        
        self._mount_point = path
        self._is_owner = True
        
        fuse_kwargs = {
            'foreground': True,  # Always foreground in our thread
            'nothreads': False,  # Allow multiple threads (DataLoader workers)
            'allow_other': False,
            'ro': True,
            'max_background': 1024,  # Allow many concurrent reads (default 12 is too low for remote FS)
            'congestion_threshold': 512,
        }
        
        if foreground:
            # Blocking mode
            fuse.FUSE(fs, path, **fuse_kwargs)
        else:
            # Background thread mode
            self._fuse_thread = threading.Thread(
                target=self._run_fuse,
                args=(fs, path, fuse_kwargs),
                daemon=True,
                name='ramjet-fuse',
            )
            self._fuse_thread.start()
            
            # Wait for mount to become available
            for _ in range(50):  # 5 seconds max
                time.sleep(0.1)
                if os.path.ismount(path):
                    break
            
            if not os.path.ismount(path):
                raise RuntimeError(f"FUSE mount at {path} did not become available")
            
            logger.info(f"FUSE mounted at {path} ({len(manifest)} files)")
        
        return path
    
    def _run_fuse(self, fs, path, kwargs):
        """Run FUSE server in thread."""
        try:
            fuse.FUSE(fs, path, **kwargs)
        except Exception as e:
            logger.error(f"FUSE thread error: {e}")
    
    def unmount(self) -> None:
        """Unmount the FUSE filesystem. Only the owning process unmounts."""
        if self._mount_point:
            if self._is_owner:
                _fusermount_unmount(self._mount_point)
                # Clean up lockfile
                lockfile = f"{self._mount_point}.ramjet.lock"
                try:
                    os.unlink(lockfile)
                except OSError:
                    pass
                logger.info("FUSE unmounted")
            else:
                logger.info("Skipping unmount (not mount owner)")
            self._mount_point = None
    
    def prefetch(self, paths: List[str], wait: bool = False) -> None:
        """
        Pre-warm the FUSE buffer and distributed cache for a list of file paths.
        Fetches directly from S3 and stores in both layers, bypassing FUSE kernel.
        
        Args:
            paths: List of relative file paths to prefetch.
            wait: If True, block until all prefetches complete.
        """
        pool = ThreadPoolExecutor(max_workers=16, thread_name_prefix="fuse_prefetch")
        
        def _prefetch_one(p: str):
            try:
                # Check if already in FUSE buffer
                if self._fs and self._fs._buffer.get(p) is not None:
                    return
                # Fetch from S3 origin
                data = self._client.get_bytes(p)
                if data:
                    # Store in FUSE LRU buffer (zero-cost reads on next access)
                    if self._fs:
                        self._fs._buffer.put(p, data)
                    # Also store in distributed cache for other nodes
                    if self._cache:
                        try:
                            self._cache.set(f"fuse:{p}", data)
                        except Exception:
                            pass
            except Exception:
                pass
        
        for p in paths:
            pool.submit(_prefetch_one, p)
        
        pool.shutdown(wait=wait)


def _fusermount_unmount(path: str) -> None:
    """Unmount a FUSE filesystem using fusermount."""
    try:
        if os.uname().sysname == 'Darwin':
            subprocess.run(['umount', path], capture_output=True, timeout=5)
        else:
            subprocess.run(['fusermount', '-u', path], capture_output=True, timeout=5)
    except Exception as e:
        logger.warning(f"Failed to unmount {path}: {e}")


def build_manifest_from_s3(s3_client, prefixes: List[str] = None, 
                            suffixes: List[str] = None) -> Dict[str, int]:
    """
    Build a file manifest from S3 bucket listing.
    Returns {relative_path: size_in_bytes}.
    
    Args:
        s3_client: S3Client instance
        prefixes: List of S3 prefixes to scan (e.g., ['images/', 'labels/'])
        suffixes: File extensions to include (e.g., ['.jpg', '.txt'])
    """
    manifest = {}
    search_prefixes = prefixes or ['']
    
    for prefix in search_prefixes:
        full_prefix = f"{s3_client.prefix}{prefix}" if s3_client.prefix else prefix
        paginator = s3_client.client.get_paginator('list_objects_v2')
        
        for page in paginator.paginate(Bucket=s3_client.bucket, Prefix=full_prefix):
            if 'Contents' not in page:
                continue
            for obj in page['Contents']:
                key = obj['Key']
                size = obj['Size']
                
                # Strip bucket prefix to get relative path
                if s3_client.prefix and key.startswith(s3_client.prefix):
                    rel_key = key[len(s3_client.prefix):]
                else:
                    rel_key = key
                
                if suffixes:
                    if not any(rel_key.lower().endswith(s) for s in suffixes):
                        continue
                
                manifest[rel_key] = size
    
    return manifest
