class Course:

    def __init__(self, name, duration, link):
        self.name = name
        self.duration = duration
        self.link = link

    def __repr__(self):
        return f"{self.name}, [{self.duration} horas], {self.link}"

# Lista
courses = [
    Course("Linux", 15, "https://hack4u.io/curso/introduccion-a-linux"),
    Course("Personalización", 3, "https://hack4u.io/curso/personalizacion-de-entorno-en-linux"),
    Course("Hacking", 53, "https://hack4u.io/curso/introduccion-al-hacking")
]

def list_courses():
    for course in courses:
       print(course)

def search_course_by_name(name):
    for course in courses:
        if course.name == name:
            return course

    return None
