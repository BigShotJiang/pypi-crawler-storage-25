# alfa10 Academy Courses Library

Una biblioteca Python para consultar cursos de la academia alfa10.

## Cursos disponibles:

- Linux [15 horas]
- Personalización [3 horas]
- Hacking [53 horas]

## Instalación 

Instala el paquete usando `pip3`:

```python3
pip3 install alfa10 
```

## Uso básico

## Listar todos los cursos

```python 
from alfa10 import list_courses():

for course in list_courses():
    print(course)
```

### Obtener un curso por nombre

```python
from alfa10 import search_course_by_name

course = search_course_by_name("Linux")
print(course)
```

### Calcular duración total de los cursos

```python3
from alfa10.utils import total_durationi

print(f"Duración total: {total_duration()} horas")
