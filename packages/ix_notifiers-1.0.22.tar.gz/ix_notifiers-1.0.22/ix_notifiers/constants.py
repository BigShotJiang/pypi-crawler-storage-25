#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.0.22'
BUILD = '2424939893'
NAME = 'ix-notifiers'
