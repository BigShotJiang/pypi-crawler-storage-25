"""AD Agent — LLM-driven Active Directory security assessment."""

import logging
from typing import Any

from agents.base import BaseAgent
from engine.llm.client import LLMClient

logger = logging.getLogger("pentest-ai.ad")


class ADAgent(BaseAgent):
    agent_type = "ad"

    def __init__(self, registry: Any, db: Any, llm: LLMClient | None = None, scope: Any = None):
        super().__init__(registry, db, llm, scope=scope)

    async def run_assessment(self, target: str, domain: str, engagement_id: str = "") -> dict[str, Any]:
        logger.info(f"Starting AD assessment against {target} (domain: {domain})")

        if self.llm:
            prompt = (
                f"Run an Active Directory security assessment against {target} in domain {domain}.\n\n"
                f"Methodology:\n"
                f"1. Domain enumeration: users, groups, GPOs, trusts, SPNs\n"
                f"2. SMB enumeration: shares, null sessions, signing\n"
                f"3. Kerberoasting: find SPNs, request tickets\n"
                f"4. AS-REP roasting: find users without preauth\n"
                f"5. ACL analysis: look for write permissions leading to escalation\n"
                f"6. Password spraying (if approved): common/seasonal passwords\n\n"
                f"Start with enumeration. Only attempt active attacks after understanding the environment."
            )
            return await self.run_tool_loop(prompt, engagement_id)

        return await self._run_deterministic_ad(target, domain, engagement_id)

    async def _run_deterministic_ad(self, target: str, domain: str, engagement_id: str) -> dict[str, Any]:
        findings_count = 0
        phases = [
            (["enum4linux", "ldapsearch", "rpcclient"], "enumeration"),
            (["smbclient", "nbtscan"], "smb_enum"),
            (["netexec"], "kerberoasting"),
            (["kerbrute"], "asrep_roast"),
        ]
        for tool_names, _phase in phases:
            for tool_name in tool_names:
                tool = self.registry.get_tool(tool_name)
                if tool and tool.is_installed():
                    result = await tool.execute(target)
                    count = len(result.get("findings", []))
                    findings_count += count
                    for f in result.get("findings", []):
                        f["engagement_id"] = engagement_id
                        await self.db.add_finding(f)
        return {"target": target, "domain": domain, "findings_count": findings_count, "status": "complete"}
