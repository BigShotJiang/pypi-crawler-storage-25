"""Recon Agent — LLM-driven network reconnaissance and OSINT orchestration.

When an LLM is configured, the agent reasons about which tools to run,
interprets results, and adapts its approach based on findings.
Falls back to deterministic tool loops when no LLM is available.
"""

import asyncio
import logging
from typing import Any

from agents.base import BaseAgent
from engine.llm.client import LLMClient

logger = logging.getLogger("pentest-ai.recon")


class ReconAgent(BaseAgent):
    agent_type = "recon"

    def __init__(self, registry: Any, db: Any, llm: LLMClient | None = None, scope: Any = None):
        super().__init__(registry, db, llm, scope=scope)

    async def run_recon(self, target: str, depth: str = "standard", engagement_id: str = "") -> dict[str, Any]:
        logger.info(f"Starting recon against {target} (depth: {depth})")

        if self.llm:
            prompt = (
                f"Run {depth} reconnaissance against {target}.\n\n"
                f"Available depth levels:\n"
                f"- passive: subdomain enum, OSINT only (no direct contact with target)\n"
                f"- standard: passive + port scanning + web tech detection\n"
                f"- deep: standard + vulnerability scanning + content discovery\n\n"
                f"Start by running built-in scanners (always available), then use external tools if installed.\n"
                f"Analyze each result before deciding what to run next."
            )
            return await self.run_tool_loop(prompt, engagement_id)

        return await self._run_deterministic_recon(target, depth, engagement_id)

    async def _run_deterministic_recon(self, target: str, depth: str, engagement_id: str) -> dict[str, Any]:
        tasks: list[Any] = []

        if depth in ("passive", "standard", "deep"):
            tasks.extend([self._run_subdomain_enum(target, engagement_id), self._run_osint(target)])

        if depth in ("standard", "deep"):
            tasks.extend([self._run_port_scan(target, engagement_id), self._run_web_tech_detect(target)])

        if depth == "deep":
            tasks.extend([self._run_vuln_scan(target, engagement_id), self._run_content_discovery(target, engagement_id)])

        results = await asyncio.gather(*tasks, return_exceptions=True)
        total_findings = sum(r.get("findings_count", 0) for r in results if isinstance(r, dict))

        return {
            "target": target,
            "depth": depth,
            "findings_count": total_findings,
            "status": "complete",
            "phases_completed": len([r for r in results if isinstance(r, dict)]),
        }

    async def _run_tool_phase(self, tool_names: list[str], target: str, engagement_id: str, phase: str) -> dict[str, Any]:
        findings_count = 0
        for tool_name in tool_names:
            tool = self.registry.get_tool(tool_name)
            if tool and tool.is_installed():
                result = await tool.execute(target)
                count = len(result.get("findings", []))
                findings_count += count
                logger.info(f"  {tool_name}: {count} findings")
                for f in result.get("findings", []):
                    f["engagement_id"] = engagement_id
                    await self.db.add_finding(f)
        return {"tool": phase, "findings_count": findings_count}

    async def _run_subdomain_enum(self, target: str, eid: str) -> dict[str, Any]:
        return await self._run_tool_phase(["amass", "subfinder", "assetfinder", "knockpy"], target, eid, "subdomain_enum")

    async def _run_osint(self, target: str) -> dict[str, Any]:
        return await self._run_tool_phase(["theharvester", "sherlock"], target, "", "osint")

    async def _run_port_scan(self, target: str, eid: str) -> dict[str, Any]:
        return await self._run_tool_phase(["nmap", "rustscan", "naabu"], target, eid, "port_scan")

    async def _run_web_tech_detect(self, target: str) -> dict[str, Any]:
        return await self._run_tool_phase(["whatweb", "httpx", "httprobe"], target, "", "web_tech")

    async def _run_vuln_scan(self, target: str, eid: str) -> dict[str, Any]:
        return await self._run_tool_phase(["nuclei", "nikto"], target, eid, "vuln_scan")

    async def _run_content_discovery(self, target: str, eid: str) -> dict[str, Any]:
        return await self._run_tool_phase(["gobuster", "feroxbuster", "dirsearch"], target, eid, "content_discovery")
