"""Web Agent — LLM-driven web application and API security testing.

Follows OWASP Testing Guide v4 methodology when LLM is available.
Falls back to deterministic tool loops otherwise.
"""

import asyncio
import logging
from typing import Any

from agents.base import BaseAgent
from engine.llm.client import LLMClient

logger = logging.getLogger("pentest-ai.web")


class WebAgent(BaseAgent):
    agent_type = "web"

    def __init__(self, registry: Any, db: Any, llm: LLMClient | None = None, scope: Any = None):
        super().__init__(registry, db, llm, scope=scope)

    async def run_assessment(
        self,
        target: str,
        auth_credentials: dict[str, str] | None = None,
        focus_areas: list[str] | None = None,
        engagement_id: str = "",
    ) -> dict[str, Any]:
        logger.info(f"Starting web assessment against {target}")

        if self.llm:
            areas = focus_areas or ["all"]
            if auth_credentials:
                cred_info = f"\nAuthentication credentials provided: {list(auth_credentials.keys())}"
            else:
                cred_info = "\nNo authentication credentials provided (testing unauthenticated)."
            prompt = (
                f"Run a web application security assessment against {target}.\n"
                f"Focus areas: {', '.join(areas)}\n"
                f"{cred_info}\n\n"
                f"Follow the OWASP Testing Guide methodology:\n"
                f"1. Content discovery and tech fingerprinting\n"
                f"2. Vulnerability scanning (nuclei, nikto)\n"
                f"3. Injection testing (SQLi, XSS, SSRF, command injection)\n"
                f"4. Authentication and session testing\n"
                f"5. API endpoint discovery and testing\n"
                f"6. Business logic testing (IDOR, race conditions)\n\n"
                f"Start with built-in scanners, then use external tools. Analyze results between phases."
            )
            return await self.run_tool_loop(prompt, engagement_id)

        return await self._run_deterministic(target, focus_areas, engagement_id)

    async def _run_deterministic(self, target: str, focus_areas: list[str] | None, engagement_id: str) -> dict[str, Any]:  # type: ignore[override]
        areas = focus_areas or ["all"]
        tasks: list[Any] = [
            self._run_tool_phase(["gobuster", "ffuf", "feroxbuster", "dirsearch", "katana"], target, engagement_id, "content_discovery"),
            self._run_tool_phase(["whatweb", "wafw00f", "httpx"], target, engagement_id, "tech_fingerprint"),
            self._run_tool_phase(["nuclei", "nikto", "skipfish"], target, engagement_id, "vuln_scan"),
        ]

        if "sqli" in areas or "all" in areas:
            tasks.append(self._run_tool_phase(["sqlmap"], target, engagement_id, "sqli"))
        if "xss" in areas or "all" in areas:
            tasks.append(self._run_tool_phase(["dalfox", "xsstrike"], target, engagement_id, "xss"))
        if "api" in areas or "all" in areas:
            tasks.append(self._run_tool_phase(["kiterunner", "arjun", "paramspider"], target, engagement_id, "api"))

        results = await asyncio.gather(*tasks, return_exceptions=True)
        total_findings = sum(r.get("findings_count", 0) for r in results if isinstance(r, dict))

        return {"target": target, "focus_areas": areas, "findings_count": total_findings, "status": "complete"}

    async def _run_tool_phase(self, tool_names: list[str], target: str, engagement_id: str, phase: str) -> dict[str, Any]:
        findings_count = 0
        for tool_name in tool_names:
            tool = self.registry.get_tool(tool_name)
            if tool and tool.is_installed():
                result = await tool.execute(target)
                count = len(result.get("findings", []))
                findings_count += count
                for f in result.get("findings", []):
                    f["engagement_id"] = engagement_id
                    await self.db.add_finding(f)
        return {"phase": phase, "findings_count": findings_count}
