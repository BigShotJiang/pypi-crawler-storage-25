"""
Tool Registry — Manages 150+ security tool wrappers with intelligent output parsing.

Each tool is defined with metadata, command templates, and output parsers
that convert raw tool output into structured findings.
"""

import asyncio
import re
import shutil
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, ClassVar

BLOCKED_ARG_KEYS = frozenset({
    "script", "script-args", "output", "oN", "oX", "oG", "oA",
    "exec", "eval", "command", "cmd", "shell", "system",
    "upload", "download", "write", "config",
})


@dataclass
class SecurityTool:
    name: str
    category: str
    description: str
    command: str
    required_deps: list[str] = field(default_factory=list)
    build_args: Callable | None = None
    parse_output: Callable | None = None
    allowed_args: set[str] | None = None

    # Class-level cache + intensity injection. Set via configure_cache().
    _cache: ClassVar[Any] = None
    _cache_intensity: ClassVar[str] = "normal"
    _cache_disabled: ClassVar[bool] = False

    def is_installed(self) -> bool:
        return shutil.which(self.command) is not None

    def _build_command(self, target: str, args: dict[str, Any] | None = None) -> list[str]:
        if self.build_args:
            return self.build_args(target, args)
        cmd_parts = [self.command]
        if args:
            for key, value in args.items():
                if key in BLOCKED_ARG_KEYS:
                    continue
                if self.allowed_args and key not in self.allowed_args:
                    continue
                if not re.match(r"^[a-zA-Z0-9_-]+$", key):
                    continue
                if isinstance(value, bool) and value:
                    cmd_parts.append(f"--{key}")
                elif isinstance(value, (str, int)):
                    str_val = str(value)
                    if any(c in str_val for c in (";", "|", "&", "`", "$", "\n")):
                        continue
                    cmd_parts.extend([f"--{key}", str_val])
        cmd_parts.append(target)
        return cmd_parts

    async def execute(self, target: str, args: dict[str, Any] | None = None) -> dict[str, Any]:
        cache = type(self)._cache
        intensity = type(self)._cache_intensity
        cache_disabled = type(self)._cache_disabled
        cache_key = None

        if cache is not None and not cache_disabled:
            from engine.cache import make_key
            cache_key = make_key(self.name, target, intensity, args)
            cached = await cache.get(cache_key)
            if cached is not None:
                cached["cache_hit"] = True
                return cached

        start = time.time()
        cmd_parts = self._build_command(target, args)

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd_parts,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()
            duration = time.time() - start

            result = {
                "tool": self.name,
                "target": target,
                "exit_code": proc.returncode,
                "stdout": stdout.decode() if stdout else "",
                "stderr": stderr.decode() if stderr else "",
                "duration": round(duration, 2),
                "findings": [],
                "cache_hit": False,
            }

            if self.parse_output:
                result["findings"] = self.parse_output(result)

            if cache is not None and not cache_disabled and cache_key and proc.returncode == 0:
                from engine.cache import ttl_for
                ttl = ttl_for(self.category)
                if ttl > 0:
                    await cache.put(
                        cache_key,
                        result,
                        tool=self.name,
                        target=target,
                        intensity=intensity,
                        ttl=ttl,
                    )

            return result
        except FileNotFoundError:
            return {"error": f"Tool '{self.command}' not found", "tool": self.name, "findings": []}
        except Exception as e:
            return {"error": str(e), "tool": self.name, "findings": []}


def configure_cache(cache: Any | None, intensity: str = "normal", disabled: bool = False) -> None:
    """Wire a ToolResultCache (or None) into all SecurityTool instances."""
    SecurityTool._cache = cache
    SecurityTool._cache_intensity = intensity
    SecurityTool._cache_disabled = disabled


# ─── Output Parsers ──────────────────────────────────────────────────────


def parse_nmap(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    for line in stdout.splitlines():
        port_match = re.match(r"(\d+)/tcp\s+(open|filtered|closed)\s+(\S+)(?:\s+(.*))?", line.strip())
        if port_match:
            port, state, service, version = port_match.groups()
            if state == "open":
                severity = "info"
                if service in ("ssh", "ftp", "telnet", "rsh", "rlogin") or service in (
                    "smb",
                    "microsoft-ds",
                    "netbios-ssn",
                ):
                    severity = "medium"
                elif service in ("mysql", "postgres", "mssql", "oracle", "redis", "mongodb"):
                    severity = "high"
                elif service in ("http", "https", "http-alt"):
                    severity = "low"
                findings.append(
                    {
                        "title": f"Open port {port}/tcp — {service}",
                        "description": f"Port {port}/tcp is open running {service}"
                        + (f" ({version})" if version else ""),
                        "severity": severity,
                        "category": "network",
                        "tool_source": "nmap",
                        "target": target,
                        "evidence": line.strip(),
                        "raw_output": line.strip(),
                    }
                )
    vuln_match = re.findall(r"VULNERABLE:.*?\n.*?\n(?:.*?\n)*?\s*State: VULNERABLE", stdout, re.MULTILINE)
    for v in vuln_match:
        findings.append(
            {
                "title": f"Nmap NSE vulnerability: {v.splitlines()[0].replace('VULNERABLE: ', '')}",
                "description": v.strip(),
                "severity": "high",
                "category": "vulnerability",
                "tool_source": "nmap",
                "target": target,
                "evidence": v.strip(),
            }
        )
    return findings


def parse_nuclei(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    severity_map = {"critical": "critical", "high": "high", "medium": "medium", "low": "low", "info": "info"}
    for line in stdout.splitlines():
        if "[" in line and "]" in line and any(s in line for s in ["critical", "high", "medium", "low", "info"]):
            sev_match = re.search(r"\[(critical|high|medium|low|info)\]", line)
            if sev_match:
                severity = sev_match.group(1)
                findings.append(
                    {
                        "title": f"Nuclei: {line.strip()}",
                        "description": line.strip(),
                        "severity": severity_map.get(severity, "info"),
                        "category": "vulnerability",
                        "tool_source": "nuclei",
                        "target": target,
                        "evidence": line.strip(),
                    }
                )
    return findings


def parse_sqlmap(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    if "is vulnerable" in stdout.lower() or "injection found" in stdout.lower():
        inj_type = "SQL injection"
        if "union" in stdout.lower():
            inj_type = "UNION-based SQL injection"
        elif "boolean" in stdout.lower():
            inj_type = "Boolean-based blind SQL injection"
        elif "time" in stdout.lower():
            inj_type = "Time-based blind SQL injection"
        elif "error" in stdout.lower():
            inj_type = "Error-based SQL injection"
        findings.append(
            {
                "title": f"SQL injection detected — {inj_type}",
                "description": f"sqlmap confirmed {inj_type} on {target}",
                "severity": "critical",
                "category": "injection",
                "tool_source": "sqlmap",
                "target": target,
                "evidence": stdout[:2000],
            }
        )
    return findings


def parse_gobuster(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    for line in stdout.splitlines():
        if "Status: " in line or "(Status: " in line:
            status_match = re.search(r"Status:\s*(\d+)", line)
            if status_match:
                status_code = int(status_match.group(1))
                path = line.split()[0] if line.split() else "/"
                severity = "info"
                if status_code == 200:
                    severity = "low"
                elif status_code in (301, 302):
                    severity = "info"
                elif status_code == 403:
                    severity = "medium"
                elif status_code == 500:
                    severity = "high"
                findings.append(
                    {
                        "title": f"Discovered path: {path} (HTTP {status_code})",
                        "description": f"Gobuster found {path} returning HTTP {status_code}",
                        "severity": severity,
                        "category": "discovery",
                        "tool_source": "gobuster",
                        "target": target,
                        "evidence": line.strip(),
                    }
                )
    return findings


def parse_nikto(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    for line in stdout.splitlines():
        if line.strip().startswith("+ ") and not line.startswith("+ "):
            continue
        if "+ " in line:
            content = line.split("+ ", 1)[-1].strip() if "+ " in line else ""
            if content and any(
                kw in content.lower()
                for kw in ["vuln", "exploit", "backdoor", "injection", "xss", "sqli", "overflow", "disclosure"]
            ):
                findings.append(
                    {
                        "title": f"Nikto: {content[:120]}",
                        "description": content,
                        "severity": "high",
                        "category": "vulnerability",
                        "tool_source": "nikto",
                        "target": target,
                        "evidence": line.strip(),
                    }
                )
            elif content:
                findings.append(
                    {
                        "title": f"Nikto: {content[:100]}",
                        "description": content,
                        "severity": "info",
                        "category": "discovery",
                        "tool_source": "nikto",
                        "target": target,
                        "evidence": line.strip(),
                    }
                )
    return findings


def parse_wafw00f(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    waf_match = re.search(r"Detected WAF:\s*(\S+)", stdout)
    if waf_match:
        waf_name = waf_match.group(1)
        findings.append(
            {
                "title": f"WAF detected: {waf_name}",
                "description": f"A Web Application Firewall ({waf_name}) was detected on {target}",
                "severity": "info",
                "category": "discovery",
                "tool_source": "wafw00f",
                "target": target,
                "evidence": stdout.strip(),
            }
        )
    return findings


def parse_subfinder(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    for line in stdout.splitlines():
        subdomain = line.strip()
        if subdomain and "." in subdomain and subdomain != target:
            findings.append(
                {
                    "title": f"Subdomain discovered: {subdomain}",
                    "description": f"Passive enumeration found subdomain {subdomain}",
                    "severity": "info",
                    "category": "recon",
                    "tool_source": "subfinder",
                    "target": subdomain,
                    "evidence": subdomain,
                }
            )
    return findings


def parse_amass(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    result.get("target", "")
    for line in stdout.splitlines():
        parts = line.strip().split()
        if len(parts) >= 2:
            subdomain = parts[0]
            source = parts[-1] if len(parts) > 1 else "unknown"
            if "." in subdomain:
                findings.append(
                    {
                        "title": f"Subdomain discovered: {subdomain}",
                        "description": f"Amass found {subdomain} via {source}",
                        "severity": "info",
                        "category": "recon",
                        "tool_source": "amass",
                        "target": subdomain,
                        "evidence": line.strip(),
                    }
                )
    return findings


def parse_whatweb(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    tech_match = re.findall(r"\[(\d+[A-Z]*)\]\s+(\S+)\s+\[(.*?)\]", stdout)
    for _code, url, techs in tech_match:
        for tech in techs.split(","):
            tech = tech.strip()
            if tech:
                findings.append(
                    {
                        "title": f"Technology detected: {tech}",
                        "description": f"WhatWeb identified {tech} on {url}",
                        "severity": "info",
                        "category": "discovery",
                        "tool_source": "whatweb",
                        "target": target,
                        "evidence": tech,
                    }
                )
    return findings


def parse_hydra(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    if "host:" in stdout and "login:" in stdout and "password:" in stdout:
        for line in stdout.splitlines():
            if "login:" in line and "password:" in line:
                login_match = re.search(r"login:\s*(\S+)", line)
                pass_match = re.search(r"password:\s*(\S+)", line)
                if login_match and pass_match:
                    findings.append(
                        {
                            "title": f"Valid credentials found: {login_match.group(1)}:{pass_match.group(1)}",
                            "description": f"Hydra found valid credentials for {target}",
                            "severity": "critical",
                            "category": "authentication",
                            "tool_source": "hydra",
                            "target": target,
                            "evidence": line.strip(),
                        }
                    )
    return findings


def parse_trufflehog(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    for line in stdout.splitlines():
        if "Detector Type:" in line or "Secret:" in line or "decoder_type" in line:
            findings.append(
                {
                    "title": "Secret/credential exposed in repository",
                    "description": f"TruffleHog found a secret in {target}",
                    "severity": "critical",
                    "category": "secret",
                    "tool_source": "trufflehog",
                    "target": target,
                    "evidence": line.strip()[:500],
                }
            )
    return findings


def parse_gitleaks(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    for line in stdout.splitlines():
        if "rule:" in line.lower() or "secret:" in line.lower() or "author:" in line.lower():
            findings.append(
                {
                    "title": "Git secret detected",
                    "description": f"Gitleaks found a secret in {target}",
                    "severity": "critical",
                    "category": "secret",
                    "tool_source": "gitleaks",
                    "target": target,
                    "evidence": line.strip()[:500],
                }
            )
    return findings


def parse_checksec(result: dict) -> list[dict]:
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    if "No RELRO" in stdout:
        findings.append(
            {
                "title": "No RELRO protection",
                "description": "Binary compiled without RELRO",
                "severity": "medium",
                "category": "binary",
                "tool_source": "checksec",
                "target": target,
                "evidence": stdout[:500],
            }
        )
    if "No canary found" in stdout:
        findings.append(
            {
                "title": "No stack canary",
                "description": "Binary compiled without stack canaries",
                "severity": "medium",
                "category": "binary",
                "tool_source": "checksec",
                "target": target,
                "evidence": stdout[:500],
            }
        )
    if "NX disabled" in stdout:
        findings.append(
            {
                "title": "NX bit disabled",
                "description": "Binary compiled without NX (DEP)",
                "severity": "high",
                "category": "binary",
                "tool_source": "checksec",
                "target": target,
                "evidence": stdout[:500],
            }
        )
    if "PIE disabled" in stdout:
        findings.append(
            {
                "title": "No PIE",
                "description": "Binary compiled without Position Independent Executable",
                "severity": "medium",
                "category": "binary",
                "tool_source": "checksec",
                "target": target,
                "evidence": stdout[:500],
            }
        )
    return findings


def parse_default(result: dict) -> list[dict]:
    """Generic parser for tools without specialized parsers."""
    findings = []
    stdout = result.get("stdout", "")
    target = result.get("target", "")
    tool = result.get("tool", "unknown")
    if stdout.strip() and len(stdout.strip()) > 10:
        findings.append(
            {
                "title": f"{tool} output for {target}",
                "description": stdout.strip()[:500],
                "severity": "info",
                "category": "recon",
                "tool_source": tool,
                "target": target,
                "evidence": stdout.strip()[:1000],
            }
        )
    return findings


# ─── Tool Definitions ────────────────────────────────────────────────────

NETWORK_TOOLS = [
    SecurityTool(
        "nmap",
        "network",
        "Advanced port scanner with NSE scripts",
        "nmap",
        ["nmap"],
        build_args=lambda t, a: ["nmap", "-sV", "-sC", "-O", "--script", "vuln", t],
        parse_output=parse_nmap,
    ),
    SecurityTool(
        "masscan",
        "network",
        "High-speed Internet-scale port scanner",
        "masscan",
        ["masscan"],
        build_args=lambda t, a: ["masscan", "-p1-65535", "--rate", "10000", t],
        parse_output=parse_default,
    ),
    SecurityTool(
        "rustscan",
        "network",
        "Ultra-fast port scanner",
        "rustscan",
        ["rustscan"],
        build_args=lambda t, a: ["rustscan", "-a", t, "--", "-sV", "-sC"],
        parse_output=parse_default,
    ),
    SecurityTool("autorecon", "network", "Comprehensive automated reconnaissance", "autorecon", ["autorecon"]),
    SecurityTool(
        "amass",
        "network",
        "Subdomain enumeration and OSINT",
        "amass",
        ["amass"],
        build_args=lambda t, a: ["amass", "enum", "-d", t],
        parse_output=parse_amass,
    ),
    SecurityTool(
        "subfinder",
        "network",
        "Fast passive subdomain discovery",
        "subfinder",
        ["subfinder"],
        build_args=lambda t, a: ["subfinder", "-d", t],
        parse_output=parse_subfinder,
    ),
    SecurityTool("fierce", "network", "DNS reconnaissance and zone transfer", "fierce", ["fierce"]),
    SecurityTool("dnsenum", "network", "DNS information gathering", "dnsenum", ["dnsenum"]),
    SecurityTool(
        "theharvester",
        "network",
        "Email and subdomain harvesting",
        "theHarvester",
        ["theHarvester"],
        build_args=lambda t, a: ["theHarvester", "-d", t, "-b", "all"],
    ),
    SecurityTool("responder", "network", "LLMNR/NBT-NS/MDNS poisoner", "Responder", ["Responder"]),
    SecurityTool("netexec", "network", "Network service exploitation framework", "netexec", ["netexec"]),
    SecurityTool("enum4linux", "network", "SMB enumeration", "enum4linux", ["enum4linux"]),
    SecurityTool("enum4linux-ng", "network", "Advanced SMB enumeration", "enum4linux-ng", ["enum4linux-ng"]),
    SecurityTool("smbmap", "network", "SMB share enumeration", "smbmap", ["smbmap"]),
    SecurityTool("arp-scan", "network", "Network discovery using ARP", "arp-scan", ["arp-scan"]),
    SecurityTool("nbtscan", "network", "NetBIOS name scanning", "nbtscan", ["nbtscan"]),
    SecurityTool("rpcclient", "network", "RPC enumeration", "rpcclient", ["rpcclient"]),
    SecurityTool(
        "whatweb", "network", "Web technology identification", "whatweb", ["whatweb"], parse_output=parse_whatweb
    ),
    SecurityTool("httprobe", "network", "HTTP probing", "httprobe", ["httprobe"]),
    SecurityTool("naabu", "network", "Fast port scanner by ProjectDiscovery", "naabu", ["naabu"]),
    SecurityTool("dnsx", "network", "DNS query toolkit", "dnsx", ["dnsx"]),
    SecurityTool("httpx", "network", "HTTP probing toolkit", "httpx", ["httpx"]),
    SecurityTool("katana", "network", "Next-gen crawling and spidering", "katana", ["katana"]),
    SecurityTool("gau", "network", "Get All URLs from archives", "gau", ["gau"]),
    SecurityTool("waybackurls", "network", "Historical URL discovery", "waybackurls", ["waybackurls"]),
    SecurityTool("dnsrecon", "network", "DNS reconnaissance", "dnsrecon", ["dnsrecon"]),
    SecurityTool("knockpy", "network", "Subdomain enumeration", "knockpy", ["knockpy"]),
    SecurityTool("assetfinder", "network", "Domain asset finder", "assetfinder", ["assetfinder"]),
    SecurityTool(
        "nmap-vulners",
        "network",
        "Nmap vulners NSE script",
        "nmap",
        ["nmap"],
        build_args=lambda t, a: ["nmap", "--script", "vulners", "-sV", t],
    ),
    SecurityTool(
        "nmap-enum",
        "network",
        "Nmap enumeration scripts",
        "nmap",
        ["nmap"],
        build_args=lambda t, a: ["nmap", "--script", "enum", "-sV", t],
    ),
]

WEB_TOOLS = [
    SecurityTool(
        "gobuster",
        "web",
        "Directory/file/DNS enumeration",
        "gobuster",
        ["gobuster"],
        build_args=lambda t, a: ["gobuster", "dir", "-u", t, "-w", "/usr/share/wordlists/dirb/common.txt"],
        parse_output=parse_gobuster,
    ),
    SecurityTool(
        "dirsearch",
        "web",
        "Advanced directory discovery",
        "dirsearch",
        ["dirsearch"],
        build_args=lambda t, a: ["dirsearch", "-u", t],
    ),
    SecurityTool("feroxbuster", "web", "Recursive content discovery", "feroxbuster", ["feroxbuster"]),
    SecurityTool(
        "ffuf",
        "web",
        "Fast web fuzzer",
        "ffuf",
        ["ffuf"],
        build_args=lambda t, a: ["ffuf", "-u", f"{t}/FUZZ", "-w", "/usr/share/wordlists/dirb/common.txt"],
    ),
    SecurityTool("dirb", "web", "Web content scanner", "dirb", ["dirb"]),
    SecurityTool(
        "nuclei",
        "web",
        "Vulnerability scanner with templates",
        "nuclei",
        ["nuclei"],
        build_args=lambda t, a: ["nuclei", "-u", t],
        parse_output=parse_nuclei,
    ),
    SecurityTool(
        "nikto",
        "web",
        "Web server vulnerability scanner",
        "nikto",
        ["nikto"],
        build_args=lambda t, a: ["nikto", "-h", t],
        parse_output=parse_nikto,
    ),
    SecurityTool(
        "sqlmap",
        "web",
        "SQL injection testing",
        "sqlmap",
        ["sqlmap"],
        build_args=lambda t, a: ["sqlmap", "-u", t, "--batch", "--level=3", "--risk=2"],
        parse_output=parse_sqlmap,
    ),
    SecurityTool(
        "wpscan",
        "web",
        "WordPress security scanner",
        "wpscan",
        ["wpscan"],
        build_args=lambda t, a: ["wpscan", "--url", t, "--enumerate", "vp,vt,tt,cb,dbe"],
    ),
    SecurityTool("arjun", "web", "HTTP parameter discovery", "arjun", ["arjun"]),
    SecurityTool("paramspider", "web", "Parameter mining from archives", "paramspider", ["paramspider"]),
    SecurityTool("dalfox", "web", "XSS vulnerability scanning", "dalfox", ["dalfox"]),
    SecurityTool("wafw00f", "web", "WAF fingerprinting", "wafw00f", ["wafw00f"], parse_output=parse_wafw00f),
    SecurityTool(
        "testssl",
        "web",
        "SSL/TLS configuration testing",
        "testssl.sh",
        ["testssl.sh"],
        build_args=lambda t, a: ["testssl.sh", t],
    ),
    SecurityTool("sslscan", "web", "SSL/TLS cipher enumeration", "sslscan", ["sslscan"]),
    SecurityTool("sslyze", "web", "SSL/TLS configuration analyzer", "sslyze", ["sslyze"]),
    SecurityTool("jwt_tool", "web", "JWT testing", "jwt_tool", ["jwt_tool"]),
    SecurityTool("commix", "web", "Command injection exploitation", "commix", ["commix"]),
    SecurityTool("nosqlmap", "web", "NoSQL injection testing", "nosqlmap", ["nosqlmap"]),
    SecurityTool("tplmap", "web", "Template injection exploitation", "tplmap", ["tplmap"]),
    SecurityTool("wfuzz", "web", "Web application fuzzer", "wfuzz", ["wfuzz"]),
    SecurityTool("xsstrike", "web", "Advanced XSS detection", "xsstrike", ["xsstrike"]),
    SecurityTool("x8", "web", "Hidden parameter discovery", "x8", ["x8"]),
    SecurityTool("jaeles", "web", "Advanced vulnerability scanning", "jaeles", ["jaeles"]),
    SecurityTool("hakrawler", "web", "Fast web endpoint discovery", "hakrawler", ["hakrawler"]),
    SecurityTool("uro", "web", "URL filtering and deduplication", "uro", ["uro"]),
    SecurityTool("qsreplace", "web", "Query string replacement", "qsreplace", ["qsreplace"]),
    SecurityTool("anew", "web", "Append new lines efficiently", "anew", ["anew"]),
    SecurityTool("subjack", "web", "Subdomain takeover checker", "subjack", ["subjack"]),
    SecurityTool("kiterunner", "web", "API endpoint discovery", "kr", ["kr"]),
    SecurityTool("dirhunt", "web", "Web crawler without brute force", "dirhunt", ["dirhunt"]),
    SecurityTool("joomscan", "web", "Joomla vulnerability scanner", "joomscan", ["joomscan"]),
    SecurityTool("droopescan", "web", "CMS scanner", "droopescan", ["droopescan"]),
    SecurityTool("cmsmap", "web", "Multi-CMS scanner", "cmsmap", ["cmsmap"]),
    SecurityTool("skipfish", "web", "Web application security scanner", "skipfish", ["skipfish"]),
    SecurityTool("graphql-voyager", "web", "GraphQL schema exploration", "graphql-voyager", ["graphql-voyager"]),
    SecurityTool("zaproxy", "web", "OWASP ZAP scanning", "zaproxy", ["zaproxy"]),
    SecurityTool("burp", "web", "Burp Suite integration", "burpsuite", ["burpsuite"]),
    SecurityTool("postman", "web", "API testing", "postman", ["postman"]),
    SecurityTool(
        "nmap-http",
        "web",
        "HTTP NSE script scanning",
        "nmap",
        ["nmap"],
        build_args=lambda t, a: ["nmap", "-p", "80,443,8080,8443", "--script", "http-enum,http-vuln-*", t],
    ),
    SecurityTool(
        "eyewitness-web",
        "web",
        "Web screenshot and analysis",
        "EyeWitness",
        ["EyeWitness"],
        build_args=lambda t, a: ["EyeWitness", "--web", "-d", t, "--no-prompt"],
    ),
]

PASSWORD_TOOLS = [
    SecurityTool(
        "hydra",
        "password",
        "Network login cracker",
        "hydra",
        ["hydra"],
        build_args=lambda t, a: ["hydra", "-L", "users.txt", "-P", "passwords.txt", t, "ssh"],
        parse_output=parse_hydra,
    ),
    SecurityTool("john", "password", "Password hash cracking", "john", ["john"]),
    SecurityTool("hashcat", "password", "GPU-accelerated password recovery", "hashcat", ["hashcat"]),
    SecurityTool("medusa", "password", "Parallel login brute-forcer", "medusa", ["medusa"]),
    SecurityTool("patator", "password", "Multi-purpose brute-forcer", "patator", ["patator"]),
    SecurityTool("crackmapexec", "password", "Network pentesting swiss army knife", "crackmapexec", ["crackmapexec"]),
    SecurityTool("evil-winrm", "password", "Windows Remote Management shell", "evil-winrm", ["evil-winrm"]),
    SecurityTool("hash-identifier", "password", "Hash type identification", "hash-identifier", ["hash-identifier"]),
    SecurityTool("hashid", "password", "Advanced hash identifier", "hashid", ["hashid"]),
    SecurityTool("cewl", "password", "Custom wordlist generator", "cewl", ["cewl"]),
    SecurityTool("crunch", "password", "Wordlist generator", "crunch", ["crunch"]),
    SecurityTool("cupp", "password", "Common User Password Profiler", "cupp", ["cupp"]),
    SecurityTool("kerbrute", "password", "Kerberos brute-forcing", "kerbrute", ["kerbrute"]),
    SecurityTool("rsmangler", "password", "Rule-based wordlist mangler", "rsmangler", ["rsmangler"]),
]

BINARY_TOOLS = [
    SecurityTool("gdb", "binary", "GNU Debugger", "gdb", ["gdb"]),
    SecurityTool("radare2", "binary", "Reverse engineering framework", "r2", ["r2"]),
    SecurityTool("ghidra", "binary", "NSA reverse engineering suite", "analyzeHeadless", ["analyzeHeadless"]),
    SecurityTool("binwalk", "binary", "Firmware analysis", "binwalk", ["binwalk"]),
    SecurityTool(
        "checksec", "binary", "Binary security property checker", "checksec", ["checksec"], parse_output=parse_checksec
    ),
    SecurityTool("strings", "binary", "Extract printable strings", "strings", ["strings"]),
    SecurityTool("objdump", "binary", "Object file information", "objdump", ["objdump"]),
    SecurityTool("volatility3", "binary", "Memory forensics", "vol", ["vol"]),
    SecurityTool("foremost", "binary", "File carving", "foremost", ["foremost"]),
    SecurityTool("steghide", "binary", "Steganography detection", "steghide", ["steghide"]),
    SecurityTool("exiftool", "binary", "Metadata reader/writer", "exiftool", ["exiftool"]),
    SecurityTool("ropgadget", "binary", "ROP/JOP gadget finder", "ROPgadget", ["ROPgadget"]),
    SecurityTool("ropper", "binary", "ROP gadget finder", "ropper", ["ropper"]),
    SecurityTool("one-gadget", "binary", "One-shot RCE gadget finder", "one_gadget", ["one_gadget"]),
    SecurityTool("pwntools", "binary", "CTF framework", "python3", ["python3"]),
    SecurityTool("angr", "binary", "Binary analysis platform", "python3", ["python3"]),
    SecurityTool("libc-database", "binary", "Libc identification", "python3", ["python3"]),
    SecurityTool("pwninit", "binary", "Binary exploitation setup", "pwninit", ["pwninit"]),
    SecurityTool("msfvenom", "binary", "Payload generator", "msfvenom", ["msfvenom"]),
    SecurityTool("upx", "binary", "Executable packer/unpacker", "upx", ["upx"]),
    SecurityTool("xxd", "binary", "Hex dump utility", "xxd", ["xxd"]),
    SecurityTool("hexdump", "binary", "Hex viewer", "hexdump", ["hexdump"]),
    SecurityTool("readelf", "binary", "ELF file analyzer", "readelf", ["readelf"]),
    SecurityTool("ltrace", "binary", "Library call tracer", "ltrace", ["ltrace"]),
    SecurityTool("strace", "binary", "System call tracer", "strace", ["strace"]),
    SecurityTool("file", "binary", "File type identification", "file", ["file"]),
    SecurityTool("nm", "binary", "List symbols from object files", "nm", ["nm"]),
]

CLOUD_TOOLS = [
    SecurityTool("prowler", "cloud", "AWS/Azure/GCP security assessment", "prowler", ["prowler"]),
    SecurityTool("scout-suite", "cloud", "Multi-cloud security auditing", "scout", ["scout"]),
    SecurityTool("trivy", "cloud", "Container vulnerability scanner", "trivy", ["trivy"]),
    SecurityTool("kube-hunter", "cloud", "Kubernetes pentesting", "kube-hunter", ["kube-hunter"]),
    SecurityTool("kube-bench", "cloud", "CIS Kubernetes benchmark", "kube-bench", ["kube-bench"]),
    SecurityTool(
        "docker-bench-security",
        "cloud",
        "Docker security assessment",
        "docker-bench-security",
        ["docker-bench-security"],
    ),
    SecurityTool("checkov", "cloud", "IaC security scanning", "checkov", ["checkov"]),
    SecurityTool("terrascan", "cloud", "Infrastructure security scanner", "terrascan", ["terrascan"]),
    SecurityTool("cloudsploit", "cloud", "Cloud security scanning", "cloudsploit", ["cloudsploit"]),
    SecurityTool("pacu", "cloud", "AWS exploitation framework", "pacu", ["pacu"]),
    SecurityTool("cloudmapper", "cloud", "AWS network visualization", "cloudmapper", ["cloudmapper"]),
    SecurityTool("aws-cli", "cloud", "AWS command line", "aws", ["aws"]),
    SecurityTool("azure-cli", "cloud", "Azure command line", "az", ["az"]),
    SecurityTool("gcloud", "cloud", "GCP command line", "gcloud", ["gcloud"]),
    SecurityTool("kubectl", "cloud", "Kubernetes CLI", "kubectl", ["kubectl"]),
    SecurityTool("helm", "cloud", "Kubernetes package manager", "helm", ["helm"]),
    SecurityTool("falco", "cloud", "Runtime security monitoring", "falco", ["falco"]),
    SecurityTool("clair", "cloud", "Container vulnerability analysis", "clair", ["clair"]),
    SecurityTool("istioctl", "cloud", "Istio service mesh", "istioctl", ["istioctl"]),
    SecurityTool("opa", "cloud", "Policy engine", "opa", ["opa"]),
    SecurityTool("steampipe", "cloud", "Cloud resource querying", "steampipe", ["steampipe"]),
    SecurityTool("cloudsplaining", "cloud", "AWS IAM policy analysis", "cloudsplaining", ["cloudsplaining"]),
]

OSINT_TOOLS = [
    SecurityTool("sherlock", "osint", "Username investigation", "sherlock", ["sherlock"]),
    SecurityTool("social-analyzer", "osint", "Social media analysis", "social-analyzer", ["social-analyzer"]),
    SecurityTool("recon-ng", "osint", "Web reconnaissance framework", "recon-ng", ["recon-ng"]),
    SecurityTool("spiderfoot", "osint", "OSINT automation", "spiderfoot", ["spiderfoot"]),
    SecurityTool("maltego", "osint", "Link analysis", "maltego", ["maltego"]),
    SecurityTool("shodan", "osint", "Internet device search", "shodan", ["shodan"]),
    SecurityTool("censys", "osint", "Internet asset discovery", "censys", ["censys"]),
    SecurityTool("haveibeenpwned", "osint", "Breach data analysis", "haveibeenpwned", ["haveibeenpwned"]),
    SecurityTool(
        "trufflehog", "osint", "Git secret scanning", "trufflehog", ["trufflehog"], parse_output=parse_trufflehog
    ),
    SecurityTool("gitrob", "osint", "GitHub reconnaissance", "gitrob", ["gitrob"]),
    SecurityTool("gitleaks", "osint", "Git secret detection", "gitleaks", ["gitleaks"], parse_output=parse_gitleaks),
    SecurityTool("aquatone", "osint", "Visual website inspection", "aquatone", ["aquatone"]),
    SecurityTool("eyeWitness", "osint", "Screenshot and credential capture", "EyeWitness", ["EyeWitness"]),
    SecurityTool("theHarvester", "osint", "Email/subdomain harvesting", "theHarvester", ["theHarvester"]),
    SecurityTool("google-dorks", "osint", "Google dorking", "google", ["google"]),
    SecurityTool("wayback-machine", "osint", "Historical web content", "waybackurls", ["waybackurls"]),
    SecurityTool("github-search", "osint", "GitHub code search", "gh", ["gh"]),
    SecurityTool("dnsrecon", "osint", "DNS reconnaissance", "dnsrecon", ["dnsrecon"]),
    SecurityTool("knockpy", "osint", "Subdomain enumeration", "knockpy", ["knockpy"]),
    SecurityTool("assetfinder", "osint", "Domain asset finder", "assetfinder", ["assetfinder"]),
    SecurityTool("urlcrazy", "osint", "Typosquatting detection", "urlcrazy", ["urlcrazy"]),
    SecurityTool("datasploit", "osint", "OSINT framework", "datasploit", ["datasploit"]),
    SecurityTool(
        "theHarvester-email",
        "osint",
        "Email harvesting",
        "theHarvester",
        ["theHarvester"],
        build_args=lambda t, a: ["theHarvester", "-d", t, "-b", "all", "-e"],
    ),
    SecurityTool("metagoofil", "osint", "Metadata extraction from documents", "metagoofil", ["metagoofil"]),
]

MOBILE_TOOLS = [
    SecurityTool("jadx", "mobile", "Android APK decompiler", "jadx", ["jadx"]),
    SecurityTool(
        "apktool", "mobile", "Android APK reverse engineering", "apktool", ["apktool"],
        build_args=lambda t, a: ["apktool", "d", t, "-o", f"{t}.decoded"],
    ),
    SecurityTool("drozer", "mobile", "Android security testing framework", "drozer", ["drozer"]),
    SecurityTool("frida", "mobile", "Dynamic instrumentation toolkit", "frida", ["frida-tools"]),
    SecurityTool("objection", "mobile", "Runtime mobile exploration", "objection", ["objection"]),
    SecurityTool("class-dump", "mobile", "iOS Objective-C header dump", "class-dump", ["class-dump"]),
    SecurityTool("otool", "mobile", "iOS Mach-O binary analysis", "otool", []),
    SecurityTool("binwalk", "mobile", "Firmware and binary analysis", "binwalk", ["binwalk"]),
    SecurityTool("mob-sf", "mobile", "Mobile Security Framework", "mobsf", ["mobsf"]),
    SecurityTool("qark", "mobile", "Android static analysis", "qark", ["qark"]),
]

WIRELESS_TOOLS = [
    SecurityTool(
        "airodump-ng", "wireless", "WiFi network scanner", "airodump-ng", ["aircrack-ng"],
        build_args=lambda t, a: ["airodump-ng", t],
    ),
    SecurityTool(
        "aireplay-ng", "wireless", "WiFi deauthentication and injection", "aireplay-ng", ["aircrack-ng"],
    ),
    SecurityTool("kismet", "wireless", "Wireless network detector and sniffer", "kismet", ["kismet"]),
    SecurityTool("wash", "wireless", "WPS-enabled AP scanner", "wash", ["reaver"]),
    SecurityTool("hashcat", "wireless", "Advanced password recovery", "hashcat", ["hashcat"]),
    SecurityTool("john", "wireless", "John the Ripper password cracker", "john", ["john"]),
    SecurityTool("bluelog", "wireless", "Bluetooth device scanner", "bluelog", ["bluelog"]),
    SecurityTool("btscanner", "wireless", "Bluetooth device discovery", "btscanner", ["btscanner"]),
]

SOCIAL_TOOLS = [
    SecurityTool("gophish", "social", "Phishing campaign framework", "gophish", ["gophish"]),
    SecurityTool("setoolkit", "social", "Social Engineering Toolkit", "setoolkit", ["setoolkit"]),
    SecurityTool("evilginx2", "social", "MitM attack framework for credentials", "evilginx2", ["evilginx2"]),
    SecurityTool("spoofcheck", "social", "Email spoofing verification", "spoofcheck", ["spoofcheck"]),
    SecurityTool(
        "dmarc-report", "social", "DMARC/SPF/DKIM analysis", "checkdmarc", ["checkdmarc"],
        build_args=lambda t, a: ["checkdmarc", t],
    ),
]

AD_TOOLS = [
    SecurityTool("enum4linux", "ad", "SMB/NetBIOS enumeration", "enum4linux", ["enum4linux"]),
    SecurityTool("ldapsearch", "ad", "LDAP directory queries", "ldapsearch", []),
    SecurityTool("rpcclient", "ad", "Windows RPC enumeration", "rpcclient", []),
    SecurityTool("smbclient", "ad", "SMB share enumeration", "smbclient", []),
    SecurityTool("nbtscan", "ad", "NetBIOS name scanner", "nbtscan", ["nbtscan"]),
    SecurityTool("netexec", "ad", "Network execution and Kerberos attacks", "netexec", ["netexec"]),
    SecurityTool("kerbrute", "ad", "Kerberos brute force and enumeration", "kerbrute", ["kerbrute"]),
    SecurityTool("bloodhound-python", "ad", "BloodHound data collector", "bloodhound-python", ["bloodhound"]),
    SecurityTool(
        "impacket-secretsdump", "ad", "Credential dumping", "secretsdump.py", ["impacket"],
        build_args=lambda t, a: ["secretsdump.py", t],
    ),
    SecurityTool(
        "impacket-getTGT", "ad", "Kerberos TGT request", "getTGT.py", ["impacket"],
        build_args=lambda t, a: ["getTGT.py", t],
    ),
]


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, SecurityTool] = {}
        self._register_all_tools()

    def _register(self, tool: SecurityTool):
        self._tools[tool.name] = tool

    def get_tool(self, name: str) -> SecurityTool | None:
        return self._tools.get(name)

    def list_tools(self, category: str | None = None) -> list[SecurityTool]:
        tools = list(self._tools.values())
        if category:
            tools = [t for t in tools if t.category == category]
        return tools

    def _register_all_tools(self):
        for tool in NETWORK_TOOLS:
            self._register(tool)
        for tool in WEB_TOOLS:
            self._register(tool)
        for tool in PASSWORD_TOOLS:
            self._register(tool)
        for tool in BINARY_TOOLS:
            self._register(tool)
        for tool in CLOUD_TOOLS:
            self._register(tool)
        for tool in OSINT_TOOLS:
            self._register(tool)
        for tool in MOBILE_TOOLS:
            self._register(tool)
        for tool in WIRELESS_TOOLS:
            self._register(tool)
        for tool in SOCIAL_TOOLS:
            self._register(tool)
        for tool in AD_TOOLS:
            self._register(tool)
