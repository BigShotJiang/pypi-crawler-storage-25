"""Factory for creating LLM clients from config."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.llm.client import LLMClient


def create_llm_client(provider: str = "", model: str = "", api_key: str = "", base_url: str = "") -> LLMClient:
    provider = provider or os.getenv("PENTEST_AI_LLM_PROVIDER", "openai")
    api_key = api_key or os.getenv("PENTEST_AI_API_KEY", "") or os.getenv("OPENAI_API_KEY", "") or os.getenv("ANTHROPIC_API_KEY", "")

    if provider == "anthropic":
        from engine.llm.providers.anthropic import AnthropicProvider

        return AnthropicProvider(
            api_key=api_key or os.getenv("ANTHROPIC_API_KEY", ""),
            model=model or "claude-sonnet-4-20250514",
        )

    if provider == "ollama":
        from engine.llm.providers.ollama import OllamaProvider

        return OllamaProvider(
            model=model or "llama3.1",
            base_url=base_url or os.getenv("OLLAMA_BASE_URL", ""),
        )

    from engine.llm.providers.openai import OpenAIProvider

    return OpenAIProvider(
        api_key=api_key or os.getenv("OPENAI_API_KEY", ""),
        model=model or "gpt-4o",
        base_url=base_url or os.getenv("OPENAI_BASE_URL", ""),
    )
