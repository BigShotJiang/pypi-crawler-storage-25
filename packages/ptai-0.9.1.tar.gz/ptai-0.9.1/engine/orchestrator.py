"""
Agent Orchestrator — Coordinates multiple specialist agents across an engagement.

Manages the lifecycle: recon -> analysis -> exploitation -> chaining -> reporting.
Each agent runs in sequence or parallel depending on scope and findings.
Supports checkpoint/resume for interrupted engagements.
"""

import asyncio
import logging
from collections.abc import Callable
from typing import Any

from engine.auth_handler import AuthCredentials
from engine.findings_db import FindingsDB
from engine.llm.client import LLMClient
from engine.rate_limiter import RateLimiter, ScanProfile
from engine.scope import ScopeEnforcer

logger = logging.getLogger("pentest-ai.orchestrator")

ProgressCallback = Callable[[str, str, float], None]


def _noop_progress(phase: str, message: str, percent: float) -> None:
    pass


PHASE_ORDER = [
    "recon",
    "web",
    "ad",
    "cloud",
    "mobile",
    "chaining",
    "validation",
    "detection",
    "report",
]


class AgentOrchestrator:
    def __init__(
        self,
        db: FindingsDB,
        llm: LLMClient | None = None,
        scope: ScopeEnforcer | None = None,
    ):
        self.db = db
        self.llm = llm
        self.scope = scope
        self._running = False
        self._current_phase: str | None = None
        self._recon_context: dict[str, Any] = {}
        self._rate_limiter: RateLimiter | None = None
        self._auth: AuthCredentials = AuthCredentials()
        self._phase_errors: dict[str, str] = {}

    async def set_intensity(self, engagement_id: str, intensity: str) -> None:
        """Change scan intensity, persisting to DB and updating live rate limiter if running."""
        if intensity not in ("stealth", "normal", "aggressive"):
            raise ValueError(f"intensity must be stealth|normal|aggressive, got: {intensity}")
        await self.db.update_engagement_intensity(engagement_id, intensity)
        if self._running:
            profile = ScanProfile.from_intensity(intensity)
            self._rate_limiter = RateLimiter(profile)
            logger.info(f"Engagement {engagement_id} intensity changed live to {intensity}")

    def set_auth(self, creds: AuthCredentials) -> None:
        self._auth = creds

    async def start_engagement(
        self,
        engagement: dict[str, Any],
        on_progress: ProgressCallback | None = None,
    ) -> None:
        self._running = True
        self._phase_errors = {}
        engagement_id = engagement["id"]
        scope = engagement.get("scope", "full")
        intensity = engagement.get("intensity", "normal")
        progress = on_progress or _noop_progress

        profile = ScanProfile.from_intensity(intensity)
        self._rate_limiter = RateLimiter(profile)

        logger.info(f"Starting engagement {engagement_id} against {engagement['target']} (intensity={intensity})")

        try:
            phases = self._build_phase_list(scope, engagement)
            total = len(phases)

            for idx, (phase_name, runner) in enumerate(phases):
                pct = idx / total
                self._current_phase = phase_name
                await self.db.update_engagement_phase(engagement_id, phase_name)
                progress(phase_name, f"Running {phase_name} phase", pct)

                if profile.delay_between_phases > 0 and idx > 0:
                    await asyncio.sleep(profile.delay_between_phases)

                try:
                    await runner(engagement)
                except Exception as phase_err:
                    logger.error(f"Phase {phase_name} failed: {phase_err}")
                    self._phase_errors[phase_name] = str(phase_err)
                    progress(phase_name, f"{phase_name} failed, continuing", pct)
                    continue

                await self.db.update_engagement_phase(engagement_id, phase_name, completed=True)
                progress(phase_name, f"{phase_name} complete", (idx + 1) / total)

            await self.db.update_engagement_status(engagement_id, "completed")
            progress("done", "Engagement complete", 1.0)

        except Exception as e:
            logger.error(f"Engagement {engagement_id} failed during {self._current_phase}: {e}")
            await self.db.update_engagement_status(engagement_id, "failed")
            raise
        finally:
            self._running = False
            self._current_phase = None
            if self.llm and hasattr(self.llm, "close"):
                await self.llm.close()

    async def resume_engagement(
        self,
        engagement: dict[str, Any],
        on_progress: ProgressCallback | None = None,
    ) -> None:
        self._running = True
        self._phase_errors = {}
        engagement_id = engagement["id"]
        scope = engagement.get("scope", "full")
        intensity = engagement.get("intensity", "normal")
        progress = on_progress or _noop_progress

        profile = ScanProfile.from_intensity(intensity)
        self._rate_limiter = RateLimiter(profile)

        checkpoint = await self.db.get_checkpoint(engagement_id)
        completed = set(checkpoint["completed_phases"]) if checkpoint else set()

        logger.info(f"Resuming engagement {engagement_id}, completed phases: {completed}")
        await self.db.update_engagement_status(engagement_id, "running")

        try:
            phases = self._build_phase_list(scope, engagement)
            remaining = [(name, runner) for name, runner in phases if name not in completed]
            total = len(phases)
            done_count = len(completed)

            for idx, (phase_name, runner) in enumerate(remaining):
                pct = (done_count + idx) / total
                self._current_phase = phase_name
                await self.db.update_engagement_phase(engagement_id, phase_name)
                progress(phase_name, f"Running {phase_name} phase", pct)

                if profile.delay_between_phases > 0 and idx > 0:
                    await asyncio.sleep(profile.delay_between_phases)

                try:
                    await runner(engagement)
                except Exception as phase_err:
                    logger.error(f"Phase {phase_name} failed on resume: {phase_err}")
                    self._phase_errors[phase_name] = str(phase_err)
                    continue

                await self.db.update_engagement_phase(engagement_id, phase_name, completed=True)
                progress(phase_name, f"{phase_name} complete", (done_count + idx + 1) / total)

            await self.db.update_engagement_status(engagement_id, "completed")
            progress("done", "Engagement complete", 1.0)

        except Exception as e:
            logger.error(f"Engagement {engagement_id} failed during {self._current_phase}: {e}")
            await self.db.update_engagement_status(engagement_id, "failed")
            raise
        finally:
            self._running = False
            self._current_phase = None
            if self.llm and hasattr(self.llm, "close"):
                await self.llm.close()

    @property
    def phase_errors(self) -> dict[str, str]:
        return dict(self._phase_errors)

    def _build_phase_list(
        self,
        scope: str,
        engagement: dict[str, Any],
    ) -> list[tuple[str, Any]]:
        phases: list[tuple[str, Any]] = [("recon", self._run_recon)]

        if scope in ("web", "full"):
            phases.append(("web", self._run_web_assessment))
        if scope in ("ad", "full"):
            phases.append(("ad", self._run_ad_assessment))
        if scope in ("cloud", "full"):
            phases.append(("cloud", self._run_cloud_assessment))
        if scope in ("mobile", "full") and engagement.get("mobile_target"):
            phases.append(("mobile", self._run_mobile_assessment))

        phases.extend([
            ("chaining", self._run_exploit_chaining),
            ("validation", self._run_poc_validation),
            ("detection", self._run_detection_generation),
            ("report", self._generate_report),
        ])
        return phases

    def _get_registry(self):
        from tools.registry import ToolRegistry
        return ToolRegistry()

    async def _run_recon(self, engagement: dict[str, Any]) -> None:
        from agents.recon.recon_agent import ReconAgent

        registry = self._get_registry()
        agent = ReconAgent(registry, self.db, llm=self.llm, scope=self.scope)
        agent.set_rate_limiter(self._rate_limiter)
        agent.set_auth(self._auth)
        result = await agent.run_recon(engagement["target"], engagement_id=engagement["id"])

        self._recon_context = {
            "findings_count": result.get("findings_count", 0),
            "summary": result.get("summary", ""),
            "target": engagement["target"],
        }
        findings = await self.db.get_findings(engagement_id=engagement["id"])
        open_ports = []
        services = []
        for f in findings:
            title = f.get("title", "").lower()
            if "open port" in title or "port" in f.get("category", "").lower():
                open_ports.append(f.get("title", ""))
            if "service" in title or "technology" in title:
                services.append(f.get("title", ""))
        self._recon_context["open_ports"] = open_ports
        self._recon_context["services"] = services

        logger.info(f"Recon complete: {result.get('findings_count', 0)} findings")

    def _configure_agent(self, agent: Any) -> None:
        if hasattr(agent, "set_rate_limiter") and self._rate_limiter:
            agent.set_rate_limiter(self._rate_limiter)
        if hasattr(agent, "set_auth") and self._auth.is_set:
            agent.set_auth(self._auth)

    async def _run_web_assessment(self, engagement: dict[str, Any]) -> None:
        from agents.web.web_agent import WebAgent

        registry = self._get_registry()
        agent = WebAgent(registry, self.db, llm=self.llm, scope=self.scope)
        if self._recon_context:
            agent.set_context(self._recon_context)
        self._configure_agent(agent)
        result = await agent.run_assessment(engagement["target"], engagement_id=engagement["id"])
        logger.info(f"Web assessment complete: {result.get('findings_count', 0)} findings")

    async def _run_ad_assessment(self, engagement: dict[str, Any]) -> None:
        from agents.ad.ad_agent import ADAgent

        registry = self._get_registry()
        agent = ADAgent(registry, self.db, llm=self.llm, scope=self.scope)
        if self._recon_context:
            agent.set_context(self._recon_context)
        self._configure_agent(agent)
        result = await agent.run_assessment(
            engagement["target"], engagement.get("domain", engagement["target"]), engagement_id=engagement["id"]
        )
        logger.info(f"AD assessment complete: {result.get('findings_count', 0)} findings")

    async def _run_cloud_assessment(self, engagement: dict[str, Any]) -> None:
        from agents.cloud.cloud_agent import CloudAgent

        registry = self._get_registry()
        agent = CloudAgent(registry, self.db, llm=self.llm, scope=self.scope)
        if self._recon_context:
            agent.set_context(self._recon_context)
        self._configure_agent(agent)
        result = await agent.run_assessment(
            engagement.get("cloud_provider", "aws"), engagement["target"], engagement_id=engagement["id"]
        )
        logger.info(f"Cloud assessment complete: {result.get('findings_count', 0)} findings")

    async def _run_mobile_assessment(self, engagement: dict[str, Any]) -> None:
        from agents.mobile.mobile_agent import MobileAgent

        registry = self._get_registry()
        agent = MobileAgent(registry, self.db, llm=self.llm, scope=self.scope)
        self._configure_agent(agent)
        result = await agent.run_assessment(
            engagement["mobile_target"],
            platform=engagement.get("mobile_platform", "android"),
            engagement_id=engagement["id"],
        )
        logger.info(f"Mobile assessment complete: {result.get('findings_count', 0)} findings")

    async def _run_exploit_chaining(self, engagement: dict[str, Any]) -> None:
        from agents.exploit_chain.chain_agent import ExploitChainAgent

        agent = ExploitChainAgent(self.db, llm=self.llm, scope=self.scope)
        chains = await agent.discover_chains(engagement["id"])
        logger.info(f"Exploit chaining complete: {len(chains)} chains discovered")

    async def _run_poc_validation(self, engagement: dict[str, Any]) -> None:
        from agents.poc_validator.poc_agent import PoCAgent

        agent = PoCAgent(self.db, llm=self.llm, scope=self.scope)
        await agent.validate_all(engagement["id"])
        logger.info("PoC validation complete")

    async def _run_detection_generation(self, engagement: dict[str, Any]) -> None:
        from agents.detection.detection_agent import DetectionAgent

        agent = DetectionAgent(self.db, llm=self.llm, scope=self.scope)
        rules = await agent.generate_rules(engagement["id"])
        logger.info(f"Detection rules generated: {len(rules)} rules")

    async def _generate_report(self, engagement: dict[str, Any]) -> None:
        from agents.report.report_agent import ReportAgent

        agent = ReportAgent(self.db, llm=self.llm, scope=self.scope)
        report = await agent.generate_report(engagement["id"])
        logger.info(f"Report generated: {report.get('output_path', 'unknown')}")

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def current_phase(self) -> str | None:
        return self._current_phase
