"""Optional dashboard linking for pentest-ai CLI.

pentest-ai is fully open source. All features run locally without auth.
This module is only used to link the CLI to an Enterprise dashboard account
(app.pentestai.xyz) for users who want cloud sync of findings.
"""

import logging
from pathlib import Path

import httpx

logger = logging.getLogger("pentest-ai.auth")

PENTEST_AI_DIR = Path.home() / ".pentest-ai"
CREDENTIALS_FILE = PENTEST_AI_DIR / "credentials"
VALIDATION_URL = "https://app.pentestai.xyz/api/cli/validate"


def _ensure_dir() -> None:
    PENTEST_AI_DIR.mkdir(mode=0o700, exist_ok=True)


def store_api_key(api_key: str) -> None:
    _ensure_dir()
    CREDENTIALS_FILE.write_text(api_key.strip())
    CREDENTIALS_FILE.chmod(0o600)


def load_api_key() -> str | None:
    if CREDENTIALS_FILE.exists():
        key = CREDENTIALS_FILE.read_text().strip()
        return key if key else None
    return None


def remove_credentials() -> None:
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def validate_key_remote(api_key: str) -> dict | None:
    """Validate API key against the Enterprise dashboard. Returns org info or None."""
    try:
        resp = httpx.post(VALIDATION_URL, json={"api_key": api_key}, timeout=10.0)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("valid"):
                return data
        return None
    except (httpx.HTTPError, httpx.TimeoutException, Exception) as e:
        logger.debug(f"Remote validation failed: {e}")
        return None
