"""CLI for pentest-ai"""
