#==============================================================================
# C O P Y R I G H T
#------------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
#==============================================================================

from pdfminer.pdfdocument import PDFNoOutlines


class RawMakerError(Exception):
    """Parent class for user errors or input errors.

    Exceptions of this type are handled by the command line tool
    and result in clear error messages, as opposed to backtraces.
    """


class TextExtractionNotAllowed(RawMakerError):
    pass


class InvalidPDF(RawMakerError):
    pass


class PDFParserImplementationError(RawMakerError):
    pass


class MissingOutlines(RawMakerError, PDFNoOutlines):
    pass
