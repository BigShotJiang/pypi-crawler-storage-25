# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================
import iamraw
import pytest
import serializeraw
import utilo

import rawmaker.features.text
import tests.examples.single


@pytest.mark.parametrize('strip', (
    True,
    False,
))
def test_layout_extraction_mine_mini_numbers(strip):
    example = tests.examples.single.HEADLINE_MOVINGFOOTER_FOOTNOTES_PDF

    text, _ = rawmaker.features.text.work(
        document=example,
        boxes_flow=1.0,
        char_margin=10.0,
        line_margin=1.0,
        nostrip=not strip,
    )

    text = serializeraw.load_document(text)
    firstpage = text[0]
    containers = utilo.select_type(firstpage, iamraw.TextContainer)
    lines = utilo.flat([item.lines for item in containers])
    footnotes = lines[-8:-1]
    first_rises = [item[0].rise for item in footnotes]
    # skip second line of first foot note
    first_rises = [first_rises[0]] + first_rises[2:]
    # ensure to parse rised number of footnotes
    assert all(item > 5.0 for item in first_rises), first_rises
