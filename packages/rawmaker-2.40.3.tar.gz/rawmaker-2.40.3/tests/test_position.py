# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import hoverpower
import utilotest
from iamraw import BoundingBox
from iamraw import Document
from pytest import fixture
from pytest import raises

from rawmaker.features import extract_content
from rawmaker.miner.position import DocumentItemHasher
from rawmaker.miner.position import ItemNotFound
from rawmaker.miner.position import hash_positions
from rawmaker.reader import read

BBox = BoundingBox.from_str  # pylint:disable=invalid-name


@fixture
def sample_hasher() -> DocumentItemHasher:
    hasher = DocumentItemHasher()
    item, position = 'ThisIsJustATest', BBox('10.0 20.0 30.0 40.0')
    hasher.hashitem(item, position)
    return hasher


def test_itemhasher():
    hasher = DocumentItemHasher()
    item, position = 'ThisIsJustATest', BBox('10.0 20.0 30.0 40.0')
    hasher.hashitem(item, position)

    hashed = hasher.position(item)

    assert hashed == position


def test_key_does_not_exists():
    hasher = DocumentItemHasher()

    with raises(ItemNotFound):
        hasher.position('ItemDoesNotExits')


@fixture
def document() -> Document:
    extracted = None
    with read(hoverpower.DOCU013_PDF) as pdf:
        extracted = extract_content(pdf)
    assert extracted
    return extracted


@utilotest.longrun
def test_hash_document(document: Document):  # pylint:disable=W0621
    hashed = hash_positions(document)
    assert len(hashed) == len(document)
    # sum all the data count of the page hasher
    items = sum((len(item.content) for item in hashed))
    # There are a lot of items in this document
    assert items > 30
