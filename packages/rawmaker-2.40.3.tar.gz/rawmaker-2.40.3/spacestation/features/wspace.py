# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2021-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import configos
import iamraw
import serializeraw
import utilo

import rawmaker.features
import rawmaker.miner.char
import rawmaker.reader

# two chars differ less than this to be merged to the same line
CHAR_SAME_LINE_DIFF_MAX = configos.HV_FLOAT_PLUS(default=10.0)


def work(source: str, pages: tuple = None) -> tuple[str, str]:
    wordspaces, words = extract(source, pages=pages)
    dumped_space = serializeraw.dump_wspaces(wordspaces)
    dumped_words = serializeraw.dump_wwords(words)
    return dumped_space, dumped_words


def extract(document: str, pages: tuple = None):
    with rawmaker.reader.read(document) as pdf:
        document = rawmaker.features.extract_content(
            pdf,
            converter=rawmaker.miner.char.CharPDFConvert,
            config=rawmaker.parameter.ParsingConfiguration(strip=True),
            pages=pages,
        )
    result = []
    words = []
    for page in document:
        if utilo.should_skip(page.page, pages):
            continue
        extracted = extract_page(page)
        if not extracted:
            continue
        wspace, chargroups = extracted
        result.append(iamraw.PageContent(page=page.page, content=wspace))
        words.append(iamraw.PageContent(page=page.page, content=chargroups))
    return result, words


def extract_page(chars: list, maxdiff: callable = None) -> list:
    if not maxdiff:
        maxdiff = diffme
    # remove empty chars
    chars = [char for char in chars if char._text.strip()]  # pylint:disable=W0212
    if not chars:
        return []
    result = []
    chargroups = [[chars[0]]]
    chars = sameline(chars)
    last = chars[0].bbox
    for char in chars[1:]:
        bbox = char.bbox
        chargroups[-1].append(char)
        xdiff_max, ydiff_max = maxdiff(char.fontsize)
        # x0, y0, x1, y1
        xdiff = last[2] - bbox[0]
        ydiff = last[3] - bbox[3]
        # rectangle between
        if abs(ydiff) > ydiff_max:
            # new line
            last = char
            chargroups.append([chargroups[-1].pop()])
            continue
        if abs(xdiff) > xdiff_max:
            # new word
            # x0, y0, x1, y1
            bounding = iamraw.BoundingBox(
                min(last[2], bbox[0]),
                min(last[1], bbox[1]),
                max(last[2], bbox[0]),
                max(last[3], bbox[3]),
            )
            result.append(bounding)
            last = char
            chargroups.append([chargroups[-1].pop()])
            continue
        last = char.bbox
    return result, chargroups


MAXDIFF = configos.HolyTable(items=[
    (7.0, 1.4),
    (10.0, 1.4),
    (15.0, 3.0),
    (20.0, 4.0),
    (25.0, 5.0),
])


def diffme(fontsize: float) -> tuple:
    # assert 4.0 <= fontsize <= 100, str(fontsize)
    # xdiff, ydiff
    xdiff = MAXDIFF(fontsize)
    return (xdiff, 10.0)


def sameline(
    chars,
    diff_max=CHAR_SAME_LINE_DIFF_MAX,
):
    # sort by x0
    chars = sorted(chars, key=lambda x: x.bbox[0])
    # sort by y0
    chars = sorted(chars, key=lambda x: x.bbox[3])
    # run cluster
    clusterd = utilo.same_line_cluster(
        chars,
        min_elements=1,
        max_diff=diff_max.
        value,  # TODO: FIX ACCESS LATER, SEE RUNTIME PROBLEM IN NEAR
        matcher=lambda x: x.bbox[3],
    )
    # sort top down
    # TODO: REMOVE AFTR HAVING STABLE LINE CLUSTER
    clusterd = sorted(clusterd, key=lambda x: x.center.bbox[3])
    result = [sorted(line, key=lambda x: x.bbox[0]) for line in clusterd]
    result = utilo.flat(result)
    return result
