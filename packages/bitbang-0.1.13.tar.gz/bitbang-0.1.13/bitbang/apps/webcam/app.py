try:
    from .webcam_adapter import WebcamBitBang
except ImportError:
    from webcam_adapter import WebcamBitBang
from flask import Flask, render_template


app = Flask(__name__, template_folder=".")

@app.route('/')
def index():
    return render_template('index.html')


def main():
    adapter = WebcamBitBang(app)
    adapter.run()


if __name__ == '__main__':
    main()
