import json
import os
from pathlib import Path
from typing import Any

import plotly.graph_objects as go
from reporterly import Report

from modelzone.training.artifacts import Artifact
from modelzone.training.tracking.trackers.base import Tracker

TAGS_FILENAME = "results/tags.jsonl"
LOG_FILENAME = "results/logs.log"
FILES_DIR = "results/files"
FIGURES_DIR = "results/figures"
METRICS_DIR = "results/metrics"
ARTIFACTS_DIR = "artifacts"


class LocalTracker(Tracker):
    def __init__(self, output_dir: str):
        self.output_dir = Path(output_dir)
        self.multi_figures: dict[str, list[tuple[dict, go.Figure]]] = {}
        self.multi_metrics: dict[str, list[tuple[dict, float | int | str]]] = {}

    def __enter__(self):
        self.output_dir.mkdir(parents=True, exist_ok=True)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Log deferered multi-figure items
        for name in self.multi_figures.keys():
            self._finalize_multi_figures(name)
        # Log deferered multi-metric items
        for name in self.multi_metrics.keys():
            self._finalize_multi_metrics(name)

        if exc_type is not None:
            self.output_dir.rename(target=str(self.output_dir) + "__FAILED")

    def log_tag(self, key: str, value: str) -> None:
        """Log a tag.

        Args:
            key (str): Tag name (e.g. "model").
            value (str): Tag value (e.g. "viking").
        """
        entry = {"name": key, "value": value}

        filepath = self.output_dir / TAGS_FILENAME

        filepath.parent.mkdir(parents=True, exist_ok=True)

        with open(filepath, "a") as f:
            f.write(json.dumps(entry) + "\n")

        print(f"   TAG   {key} = {value}")

    def log_file(self, name: str, data: bytes | str) -> str:
        """Save an arbitrary file into the run directory.

        Args:
            name (str): File name (e.g. "predictions.csv")
            data (bytes | str): Data as bytes or string.
        """
        files_dir = os.path.join(self.output_dir, FILES_DIR)

        os.makedirs(files_dir, exist_ok=True)
        filepath = os.path.join(files_dir, name)

        mode = "wb" if isinstance(data, bytes) else "w"

        with open(filepath, mode) as f:
            f.write(data)

        print(f"  DATA   {name} (saved to {filepath})")
        return filepath

    def log_message(self, message: str) -> None:
        """Print a message to stdout **and** append to the run log.

        Args:
            message (str): The message to log.
        """
        log_filepath = os.path.join(self.output_dir, LOG_FILENAME)

        os.makedirs(os.path.dirname(log_filepath), exist_ok=True)

        with open(log_filepath, "a") as f:
            f.write(message + "\n")

        print(f"   LOG   '{message}'")

    def log_artifact(self, name: str, artifact: Artifact) -> None:
        """Save an arbitrary object into the run directory as a pickled file.

        Args:
            name (str): Artifact name (e.g. "model").
            artifact (Artifact): The artifact to save.
        """
        artifacts_dir = self.output_dir / ARTIFACTS_DIR

        artifacts_dir.mkdir(parents=True, exist_ok=True)

        artifact.save(name, artifacts_dir)

        print(f"  ARTIFACT   {name} (saved to {artifacts_dir})")

    def _log_single_metric(
        self,
        name: str,
        value: float | int | str,
    ) -> None:
        """Log a single metric as an HTML file containing a Plotly indicator figure."""
        filepath = self.output_dir / METRICS_DIR / f"{name}.html"

        filepath.parent.mkdir(parents=True, exist_ok=True)

        fig = go.Figure(
            go.Indicator(
                mode="number",
                value=value,
            )
        )

        fig.update_layout(
            title=name,
        )

        fig.write_html(filepath)

        print(f"   METRIC   {name} = {value}")

    def _add_multi_metric_item(
        self,
        name: str,
        value: float | int | str,
        dimensions: dict[str, Any],
    ) -> None:
        """Add a multi-metric item to be logged when the run ends.
        NOTE: The reason for deferring multi-metric logging is that we need to have all
        the metric values in order to create a single table figure.
        """
        if name not in self.multi_metrics:
            self.multi_metrics[name] = []

        self.multi_metrics[name].append((dimensions, value))

        print(f"   METRIC   {name} (deferred saving)")

    def _finalize_multi_metrics(self, name: str) -> None:
        """Log a multi-metric as an HTML file containing a Plotly table figure."""
        metrics = self.multi_metrics[name]

        first_dimensions_keys = metrics[0][0].keys()
        header = list(first_dimensions_keys) + [name]

        cells = []
        for dimensions, value in metrics:
            if dimensions.keys() != first_dimensions_keys:
                raise ValueError(
                    f"All dimensions for metric '{name}' must have the same keys"
                )

            cell = [str(dimensions[key]) for key in first_dimensions_keys] + [
                str(value)
            ]
            cells.append(cell)

        fig = go.Figure(
            data=go.Table(
                header=dict(values=header),
                cells=dict(values=list(zip(*cells))),
            )
        )

        filepath = self.output_dir / METRICS_DIR / f"{name}.html"

        filepath.parent.mkdir(parents=True, exist_ok=True)

        fig.write_html(filepath)

    def log_metric(
        self,
        name: str,
        value: float | int | str,
        dimensions: dict[str, Any] | None = None,
    ) -> None:
        if dimensions is not None:
            self._add_multi_metric_item(name, value, dimensions)
        else:
            self._log_single_metric(name, value)

    def _log_single_figure(
        self,
        name: str,
        figure: go.Figure,
    ) -> None:
        """Log a single figure as an HTML file containing the Plotly figure."""
        filepath = self.output_dir / FIGURES_DIR / f"{name}.html"

        filepath.parent.mkdir(parents=True, exist_ok=True)

        figure.write_html(filepath)

        print(f"  FIGURE   {name} (saved to {filepath})")

    def _add_multi_figure_item(
        self,
        name: str,
        figure: "go.Figure",
        dimensions: dict[str, Any],
    ) -> None:
        """Add a multi-figure item to be logged when the run ends.
        NOTE: The reason for deferring multi-figure logging is that we need to have all
        the figure items in order to create a single figure with dropdown selection."""
        if name not in self.multi_figures:
            self.multi_figures[name] = []

        self.multi_figures[name].append((dimensions, figure))

        print(f"  FIGURE   {name} (deferred saving)")

    def _finalize_multi_figures(self, name: str) -> None:
        """Log multiple figures as a single HTML file containing a dropdown to select
        between the figures."""
        figures = self.multi_figures[name]

        first_dimensions_keys = figures[0][0].keys()
        report = Report()
        for dimensions, figure in figures:
            if dimensions.keys() != first_dimensions_keys:
                raise ValueError(
                    f"All dimensions for figure '{name}' must have the same keys"
                )

            report.add(
                selection=dimensions,
                figure=figure,
            )

        filepath = self.output_dir / FIGURES_DIR / f"{name}.html"

        filepath.parent.mkdir(parents=True, exist_ok=True)

        report.write_html(filepath)

    def log_figure(
        self, name: str, figure: "go.Figure", dimensions: dict[str, Any] | None = None
    ) -> None:
        if dimensions is not None:
            self._add_multi_figure_item(name, figure, dimensions)
        else:
            self._log_single_figure(name, figure)
