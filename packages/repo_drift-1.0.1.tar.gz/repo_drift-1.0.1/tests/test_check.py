"""Tests for the ``check`` command logic in core/check.py.

Covers:
- _strip_prefix() edge cases
- _resolve_repo_id() auto-detection and validation
- _match_check_against_files() matching logic
- evaluate_changed_files() full integration:
  - no affected files → pass
  - affected files with/without policy → fail
  - policy-based verdict (warn vs fail severities)
  - multi-check configs
  - single-repo auto-detection
  - multi-repo explicit selection
  - local path configs (absolute snapshot_path)
  - remote path configs (relative repos/ prefix)
"""

from __future__ import annotations

import pytest

from repo_drift.core.check import (
    AffectedCheck,
    _match_check_against_files,
    _resolve_repo_id,
    _severity_order,
    _strip_prefix,
    evaluate_changed_files,
)
from repo_drift.core.types import CheckConfig, PolicyRule, ProjectConfig, RepoConfig

# ── Helpers ──────────────────────────────────────────────────────────────


def _project(
    repos: list[RepoConfig],
    checks: list[CheckConfig],
    fail_on: list[PolicyRule] | None = None,
) -> ProjectConfig:
    return ProjectConfig(
        version=1,
        repos=repos,
        checks=checks,
        fail_on=fail_on or [],
    )


def _repo(
    id: str = "acme-sdk",
    url: str = "https://github.com/org/acme-sdk.git",
    snapshot_path: str = "repos/acme-sdk",
) -> RepoConfig:
    return RepoConfig(id=id, url=url, ref_policy="main", snapshot_path=snapshot_path)


def _check(
    id: str = "hash-api-spec",
    check_type: str = "file_pair_hash",
    severity: str = "high",
    left: str = "repos/acme-sdk/specs/api.json",
    right: str = "repos/web/generated/api.json",
) -> CheckConfig:
    return CheckConfig(
        id=id,
        type=check_type,
        severity=severity,
        params={"left": left, "right": right},
    )


# ── _strip_prefix ───────────────────────────────────────────────────────


class TestStripPrefix:
    def test_relative_prefix(self) -> None:
        assert _strip_prefix("repos/acme-sdk/specs/api.json", "repos/acme-sdk") == "specs/api.json"

    def test_absolute_prefix(self) -> None:
        assert (
            _strip_prefix("/Users/x/acme-sdk/sdk/foo.json", "/Users/x/acme-sdk") == "sdk/foo.json"
        )

    def test_no_match_returns_none(self) -> None:
        assert _strip_prefix("repos/web/generated/api.json", "repos/acme-sdk") is None

    def test_exact_match(self) -> None:
        # Edge case: path *is* the prefix (file at root)
        assert _strip_prefix("repos/acme-sdk", "repos/acme-sdk") == "."

    def test_backslash_normalization(self) -> None:
        assert (
            _strip_prefix("repos\\acme-sdk\\specs\\api.json", "repos/acme-sdk") == "specs/api.json"
        )

    def test_trailing_slash_prefix(self) -> None:
        assert _strip_prefix("repos/acme-sdk/specs/api.json", "repos/acme-sdk/") == "specs/api.json"


# ── _resolve_repo_id ────────────────────────────────────────────────────


class TestResolveRepoId:
    def test_explicit_valid(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk"), _repo("web", snapshot_path="repos/web")],
            checks=[_check()],
        )
        assert _resolve_repo_id(config, "acme-sdk") == "acme-sdk"

    def test_explicit_invalid_raises(self) -> None:
        config = _project(repos=[_repo("acme-sdk")], checks=[_check()])
        with pytest.raises(ValueError, match="not found"):
            _resolve_repo_id(config, "nonexistent")

    def test_auto_detect_single_repo(self) -> None:
        config = _project(repos=[_repo("acme-sdk")], checks=[_check()])
        assert _resolve_repo_id(config, None) == "acme-sdk"

    def test_auto_detect_multiple_repos_raises(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk"), _repo("web", snapshot_path="repos/web")],
            checks=[_check()],
        )
        with pytest.raises(ValueError, match="Multiple repos"):
            _resolve_repo_id(config, None)


# ── _severity_order ──────────────────────────────────────────────────────


class TestSeverityOrder:
    def test_known_severities(self) -> None:
        assert _severity_order("low") < _severity_order("medium")
        assert _severity_order("medium") < _severity_order("high")
        assert _severity_order("high") < _severity_order("critical")

    def test_unknown_severity(self) -> None:
        assert _severity_order("unknown") == -1


# ── _match_check_against_files ───────────────────────────────────────────


class TestMatchCheckAgainstFiles:
    def test_left_match(self) -> None:
        repo = _repo("acme-sdk")
        check = _check(left="repos/acme-sdk/specs/api.json", right="repos/web/gen/api.json")
        affected: list[AffectedCheck] = []
        _match_check_against_files(check, repo, ["specs/api.json"], affected)
        assert len(affected) == 1
        assert affected[0].matched_param == "left"
        assert affected[0].matched_file == "specs/api.json"
        assert affected[0].counterpart == "repos/web/gen/api.json"

    def test_right_match(self) -> None:
        web = _repo("web", snapshot_path="repos/web")
        check = _check(left="repos/acme-sdk/specs/api.json", right="repos/web/gen/api.json")
        affected: list[AffectedCheck] = []
        _match_check_against_files(check, web, ["gen/api.json"], affected)
        assert len(affected) == 1
        assert affected[0].matched_param == "right"
        assert affected[0].counterpart == "repos/acme-sdk/specs/api.json"

    def test_no_match(self) -> None:
        repo = _repo("acme-sdk")
        check = _check(left="repos/acme-sdk/specs/api.json", right="repos/web/gen/api.json")
        affected: list[AffectedCheck] = []
        _match_check_against_files(check, repo, ["unrelated/file.py"], affected)
        assert len(affected) == 0

    def test_both_sides_match(self) -> None:
        """If a repo owns both left and right, both can match."""
        repo = _repo("mono", snapshot_path="repos/mono")
        check = _check(
            left="repos/mono/specs/api.json",
            right="repos/mono/gen/api.json",
        )
        affected: list[AffectedCheck] = []
        _match_check_against_files(check, repo, ["specs/api.json", "gen/api.json"], affected)
        assert len(affected) == 2

    def test_empty_params_skipped(self) -> None:
        check = CheckConfig(id="noop", type="file_pair_hash", severity="low", params={})
        affected: list[AffectedCheck] = []
        _match_check_against_files(check, _repo(), ["anything.txt"], affected)
        assert len(affected) == 0

    def test_local_absolute_path(self) -> None:
        repo = _repo("acme-sdk", snapshot_path="/Users/dev/acme-sdk")
        check = _check(
            left="/Users/dev/acme-sdk/sdk/task.json",
            right="/Users/dev/web/contracts/task.json",
        )
        affected: list[AffectedCheck] = []
        _match_check_against_files(check, repo, ["sdk/task.json"], affected)
        assert len(affected) == 1
        assert affected[0].matched_param == "left"
        assert affected[0].matched_file == "sdk/task.json"


# ── evaluate_changed_files ───────────────────────────────────────────────


class TestEvaluateChangedFiles:
    def test_no_affected_files_pass(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[_check(left="repos/acme-sdk/specs/api.json", right="repos/web/gen/api.json")],
        )
        verdict = evaluate_changed_files(config, None, ["README.md"])
        assert verdict.verdict == "pass"
        assert verdict.affected == []
        assert "No contract files" in verdict.summary

    def test_affected_file_no_policy_fails(self) -> None:
        """Without explicit policy, any affected check triggers fail."""
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[_check(left="repos/acme-sdk/specs/api.json", right="repos/web/gen/api.json")],
        )
        verdict = evaluate_changed_files(config, None, ["specs/api.json"])
        assert verdict.verdict == "fail"
        assert len(verdict.affected) == 1

    def test_affected_file_with_matching_policy_fails(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    severity="high",
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                )
            ],
            fail_on=[PolicyRule(severity="high", status="fail")],
        )
        verdict = evaluate_changed_files(config, None, ["specs/api.json"])
        assert verdict.verdict == "fail"

    def test_affected_file_with_warn_policy_passes(self) -> None:
        """Affected check with severity 'high' but policy only fails on 'critical'."""
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    severity="high",
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                )
            ],
            fail_on=[PolicyRule(severity="critical", status="fail")],
        )
        verdict = evaluate_changed_files(config, None, ["specs/api.json"])
        # Policy says only fail on critical — high is not critical, so pass.
        assert verdict.verdict == "pass"
        assert len(verdict.affected) == 1

    def test_multi_check_multiple_hits(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    id="check-1",
                    severity="high",
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                ),
                _check(
                    id="check-2",
                    severity="medium",
                    left="repos/acme-sdk/specs/events.json",
                    right="repos/web/gen/events.json",
                ),
            ],
        )
        verdict = evaluate_changed_files(config, None, ["specs/api.json", "specs/events.json"])
        assert verdict.verdict == "fail"
        assert len(verdict.affected) == 2
        check_ids = {a.check_id for a in verdict.affected}
        assert check_ids == {"check-1", "check-2"}

    def test_multi_repo_explicit_selection(self) -> None:
        config = _project(
            repos=[
                _repo("acme-sdk"),
                _repo("web", url="https://github.com/org/web.git", snapshot_path="repos/web"),
            ],
            checks=[
                _check(
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                )
            ],
        )
        # Select web repo — changing gen/api.json should match the "right" side.
        verdict = evaluate_changed_files(config, "web", ["gen/api.json"])
        assert verdict.verdict == "fail"
        assert len(verdict.affected) == 1
        assert verdict.affected[0].matched_param == "right"

    def test_multi_repo_no_selection_raises(self) -> None:
        config = _project(
            repos=[
                _repo("acme-sdk"),
                _repo("web", snapshot_path="repos/web"),
            ],
            checks=[_check()],
        )
        with pytest.raises(ValueError, match="Multiple repos"):
            evaluate_changed_files(config, None, ["any.file"])

    def test_empty_changed_files_pass(self) -> None:
        config = _project(repos=[_repo("acme-sdk")], checks=[_check()])
        verdict = evaluate_changed_files(config, None, [])
        assert verdict.verdict == "pass"
        assert verdict.affected == []

    def test_summary_contains_severity(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    severity="critical",
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                )
            ],
        )
        verdict = evaluate_changed_files(config, None, ["specs/api.json"])
        assert "critical" in verdict.summary.lower()

    def test_to_dict_serialization(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[_check(left="repos/acme-sdk/specs/api.json", right="repos/web/gen/api.json")],
        )
        verdict = evaluate_changed_files(config, None, ["specs/api.json"])
        d = verdict.to_dict()
        assert d["repo"] == "acme-sdk"
        assert d["verdict"] == "fail"
        assert isinstance(d["affected"], list)
        assert d["affected"][0]["check_id"] == "hash-api-spec"
        assert d["affected"][0]["matched_param"] == "left"

    def test_local_path_config(self) -> None:
        """Configs with absolute snapshot paths (local repos) work correctly."""
        config = _project(
            repos=[_repo("acme-sdk", snapshot_path="/Users/dev/acme-sdk")],
            checks=[
                _check(
                    left="/Users/dev/acme-sdk/sdk/task.json",
                    right="/Users/dev/web/contracts/task.json",
                )
            ],
        )
        verdict = evaluate_changed_files(config, None, ["sdk/task.json"])
        assert verdict.verdict == "fail"
        assert len(verdict.affected) == 1
        assert verdict.affected[0].matched_file == "sdk/task.json"

    def test_schema_compat_check_type(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    id="schema-task",
                    check_type="json_schema_compat",
                    severity="high",
                    left="repos/acme-sdk/specs/task.json",
                    right="repos/web/gen/task.json",
                )
            ],
        )
        verdict = evaluate_changed_files(config, None, ["specs/task.json"])
        assert verdict.affected[0].check_type == "json_schema_compat"

    def test_policy_warn_status_does_not_fail(self) -> None:
        """Policy with status='warn' should not cause failure."""
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    severity="high",
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                )
            ],
            fail_on=[PolicyRule(severity="high", status="warn")],
        )
        verdict = evaluate_changed_files(config, None, ["specs/api.json"])
        # warn status should NOT trigger fail (only status="fail" does).
        assert verdict.verdict == "pass"

    def test_multiple_files_one_match(self) -> None:
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                )
            ],
        )
        verdict = evaluate_changed_files(
            config,
            None,
            ["README.md", "src/main.py", "specs/api.json", "tests/test_foo.py"],
        )
        assert verdict.verdict == "fail"
        assert len(verdict.affected) == 1
        assert verdict.affected[0].matched_file == "specs/api.json"

    def test_mixed_severity_policy(self) -> None:
        """Policy fails on critical but not high — only critical triggers fail."""
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    id="check-high",
                    severity="high",
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                ),
                _check(
                    id="check-critical",
                    severity="critical",
                    left="repos/acme-sdk/specs/events.json",
                    right="repos/web/gen/events.json",
                ),
            ],
            fail_on=[PolicyRule(severity="critical", status="fail")],
        )
        # Only change a high-severity file — should pass.
        v1 = evaluate_changed_files(config, None, ["specs/api.json"])
        assert v1.verdict == "pass"

        # Change a critical-severity file — should fail.
        v2 = evaluate_changed_files(config, None, ["specs/events.json"])
        assert v2.verdict == "fail"

    def test_changed_file_path_normalization(self) -> None:
        """Leading/trailing slashes and backslashes are normalized."""
        config = _project(
            repos=[_repo("acme-sdk")],
            checks=[
                _check(
                    left="repos/acme-sdk/specs/api.json",
                    right="repos/web/gen/api.json",
                )
            ],
        )
        # Extra leading slash in changed file.
        verdict = evaluate_changed_files(config, None, ["/specs/api.json"])
        assert verdict.verdict == "fail"
        assert len(verdict.affected) == 1

    def test_verdict_repo_field(self) -> None:
        config = _project(repos=[_repo("acme-sdk")], checks=[_check()])
        verdict = evaluate_changed_files(config, None, ["README.md"])
        assert verdict.repo == "acme-sdk"
        assert verdict.changed_files == ["README.md"]
