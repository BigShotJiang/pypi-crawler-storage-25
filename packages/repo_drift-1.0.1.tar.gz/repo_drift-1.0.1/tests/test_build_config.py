"""Tests for _build_config() path generation in init/workflow.py.

Verifies that check paths use the repo's snapshot_path prefix:
- Remote repos: "repos/<id>/<path>"
- Local repos: "<absolute_snapshot_path>/<path>"
"""

from __future__ import annotations

from repo_drift.core.types import RepoConfig
from repo_drift.discover.catalog import ContractEntry, ContractPair, RepoCatalog
from repo_drift.init.types import ArchitectureMap, ContractExpectation
from repo_drift.init.workflow import _build_config


def _make_architecture(domains: list[str] | None = None) -> ArchitectureMap:
    """Create a minimal ArchitectureMap for testing."""
    expectations = []
    for d in domains or []:
        expectations.append(
            ContractExpectation(
                domain=d,
                contract_type="json-schema",
                owner_repo="repo-a",
                consumer_repos=["repo-b"],
                risk="high",
                rationale="test",
            )
        )
    return ArchitectureMap(contract_expectations=expectations)


def test_remote_repos_use_repos_prefix() -> None:
    """Remote repos should have paths like repos/<id>/<file>."""
    repos = [
        RepoConfig(
            id="repo-a",
            url="https://github.com/org/repo-a.git",
            ref_policy="main",
            snapshot_path="repos/repo-a",
        ),
        RepoConfig(
            id="repo-b",
            url="https://github.com/org/repo-b.git",
            ref_policy="main",
            snapshot_path="repos/repo-b",
        ),
    ]
    catalogs = [
        RepoCatalog(
            repo_id="repo-a",
            repo_url=repos[0].url,
            branch="main",
            snapshot_path="repos/repo-a",
            contracts=[
                ContractEntry(
                    path="specs/api.json",
                    role="source",
                    file_type="json-schema",
                    domain="api",
                    confidence=0.9,
                ),
            ],
        ),
        RepoCatalog(
            repo_id="repo-b",
            repo_url=repos[1].url,
            branch="main",
            snapshot_path="repos/repo-b",
            contracts=[],
        ),
    ]
    pairs = [
        ContractPair(
            domain="api",
            source_repo="repo-a",
            source_path="specs/api.json",
            consumer_repo="repo-b",
            consumer_path="generated/api.json",
        ),
    ]
    architecture = _make_architecture(["api"])

    config = _build_config(repos, catalogs, pairs, architecture)

    checks = config["checks"]
    assert len(checks) >= 1
    hash_check = checks[0]
    assert hash_check["params"]["left"] == "repos/repo-a/specs/api.json"
    assert hash_check["params"]["right"] == "repos/repo-b/generated/api.json"


def test_local_repos_use_absolute_path() -> None:
    """Local repos should have paths like /absolute/path/<file>."""
    repos = [
        RepoConfig(
            id="acme-sdk",
            url="/Users/dev/acme-sdk",
            ref_policy="main",
            snapshot_path="/Users/dev/acme-sdk",
        ),
        RepoConfig(
            id="web", url="/Users/dev/web", ref_policy="main", snapshot_path="/Users/dev/web"
        ),
    ]
    catalogs = [
        RepoCatalog(
            repo_id="acme-sdk",
            repo_url=repos[0].url,
            branch="main",
            snapshot_path="/Users/dev/acme-sdk",
            contracts=[
                ContractEntry(
                    path="sdk/task.json",
                    role="source",
                    file_type="json-schema",
                    domain="task-spec",
                    confidence=0.9,
                ),
            ],
        ),
        RepoCatalog(
            repo_id="web",
            repo_url=repos[1].url,
            branch="main",
            snapshot_path="/Users/dev/web",
            contracts=[],
        ),
    ]
    pairs = [
        ContractPair(
            domain="task-spec",
            source_repo="acme-sdk",
            source_path="sdk/task.json",
            consumer_repo="web",
            consumer_path="contracts/task.json",
        ),
    ]
    architecture = _make_architecture(["task-spec"])

    config = _build_config(repos, catalogs, pairs, architecture)

    checks = config["checks"]
    assert len(checks) >= 1
    hash_check = checks[0]
    assert hash_check["params"]["left"] == "/Users/dev/acme-sdk/sdk/task.json"
    assert hash_check["params"]["right"] == "/Users/dev/web/contracts/task.json"


def test_mixed_local_and_remote_repos() -> None:
    """Mixed local+remote repos should use correct prefix for each."""
    repos = [
        RepoConfig(
            id="local-svc", url="/home/dev/svc", ref_policy="main", snapshot_path="/home/dev/svc"
        ),
        RepoConfig(
            id="remote-svc",
            url="https://github.com/org/remote-svc.git",
            ref_policy="main",
            snapshot_path="repos/remote-svc",
        ),
    ]
    catalogs = [
        RepoCatalog(
            repo_id="local-svc",
            repo_url=repos[0].url,
            branch="main",
            snapshot_path="/home/dev/svc",
            contracts=[
                ContractEntry(
                    path="api/spec.yaml",
                    role="source",
                    file_type="openapi",
                    domain="svc-api",
                    confidence=0.9,
                ),
            ],
        ),
        RepoCatalog(
            repo_id="remote-svc",
            repo_url=repos[1].url,
            branch="main",
            snapshot_path="repos/remote-svc",
            contracts=[],
        ),
    ]
    pairs = [
        ContractPair(
            domain="svc-api",
            source_repo="local-svc",
            source_path="api/spec.yaml",
            consumer_repo="remote-svc",
            consumer_path="specs/spec.yaml",
        ),
    ]
    architecture = _make_architecture(["svc-api"])

    config = _build_config(repos, catalogs, pairs, architecture)

    checks = config["checks"]
    hash_check = checks[0]
    assert hash_check["params"]["left"] == "/home/dev/svc/api/spec.yaml"
    assert hash_check["params"]["right"] == "repos/remote-svc/specs/spec.yaml"


def test_schema_compat_check_uses_snapshot_path() -> None:
    """json_schema_compat checks should also use snapshot_path prefix."""
    repos = [
        RepoConfig(
            id="acme-sdk",
            url="/Users/dev/acme-sdk",
            ref_policy="main",
            snapshot_path="/Users/dev/acme-sdk",
        ),
        RepoConfig(
            id="web", url="/Users/dev/web", ref_policy="main", snapshot_path="/Users/dev/web"
        ),
    ]
    catalogs = [
        RepoCatalog(
            repo_id="acme-sdk",
            repo_url=repos[0].url,
            branch="main",
            snapshot_path="/Users/dev/acme-sdk",
            contracts=[
                ContractEntry(
                    path="specs/task.json",
                    role="source",
                    file_type="json-schema",
                    domain="task-spec",
                    confidence=0.9,
                ),
            ],
        ),
        RepoCatalog(
            repo_id="web",
            repo_url=repos[1].url,
            branch="main",
            snapshot_path="/Users/dev/web",
            contracts=[],
        ),
    ]
    pairs = [
        ContractPair(
            domain="task-spec",
            source_repo="acme-sdk",
            source_path="specs/task.json",
            consumer_repo="web",
            consumer_path="gen/task.json",
        ),
    ]
    architecture = _make_architecture(["task-spec"])

    config = _build_config(repos, catalogs, pairs, architecture)

    checks = config["checks"]
    # Should have 2 checks: file_pair_hash + json_schema_compat
    assert len(checks) == 2
    schema_check = checks[1]
    assert schema_check["type"] == "json_schema_compat"
    assert schema_check["params"]["left"] == "/Users/dev/acme-sdk/specs/task.json"
    assert schema_check["params"]["right"] == "/Users/dev/web/gen/task.json"


def test_empty_pairs_produces_no_checks() -> None:
    """No pairs should produce no checks."""
    repos = [
        RepoConfig(
            id="repo-a",
            url="https://github.com/org/repo-a.git",
            ref_policy="main",
            snapshot_path="repos/repo-a",
        ),
    ]
    catalogs = [
        RepoCatalog(
            repo_id="repo-a", repo_url=repos[0].url, branch="main", snapshot_path="repos/repo-a"
        ),
    ]
    architecture = _make_architecture()

    config = _build_config(repos, catalogs, [], architecture)

    assert config["checks"] == []
