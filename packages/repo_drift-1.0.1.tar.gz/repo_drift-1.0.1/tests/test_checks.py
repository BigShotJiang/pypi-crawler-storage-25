"""Tests for check functions using shared fixtures from testdata/."""

from pathlib import Path

from repo_drift.checks.file_pair_hash import run_file_pair_hash_check
from repo_drift.checks.json_schema_compat import run_json_schema_compat_check
from repo_drift.checks.json_semantic_equal import run_json_semantic_equal_check
from repo_drift.checks.openapi_compat import run_openapi_compat_check
from repo_drift.checks.yaml_semantic_equal import run_yaml_semantic_equal_check
from repo_drift.core.types import CheckConfig

# Resolve testdata relative to repo root (python/ is one level down).
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_TESTDATA = _REPO_ROOT / "testdata"


def _check(check_type: str, left: str, right: str, severity: str = "high") -> CheckConfig:
    return CheckConfig(
        id="test-check",
        type=check_type,
        severity=severity,
        params={"left": left, "right": right},
    )


class TestFilePairHash:
    def test_identical_files_pass(self) -> None:
        c = _check(
            "file_pair_hash",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec.json",
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.status == "pass"
        assert "byte-identical" in result.summary

    def test_different_files_fail(self) -> None:
        c = _check(
            "file_pair_hash",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec-drifted.json",
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "differ" in result.summary

    def test_missing_file_fails(self) -> None:
        c = _check(
            "file_pair_hash",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/nonexistent.json",
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "missing" in result.summary.lower()

    def test_bad_params_error(self) -> None:
        c = CheckConfig(
            id="test-check",
            type="file_pair_hash",
            severity="high",
            params={"left": 123},  # not a string
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.status == "error"

    def test_severity_preserved(self) -> None:
        c = _check(
            "file_pair_hash",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec.json",
            severity="critical",
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.severity == "critical"


class TestJSONSchemaCompat:
    def test_identical_schemas_pass(self) -> None:
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "pass"
        assert "passed" in result.summary.lower()

    def test_removed_required_fields_fail(self) -> None:
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec-missing-fields.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "incompatible" in result.summary.lower()

    def test_added_required_fields_fail(self) -> None:
        """When the right side adds new required fields, that's a breaking change."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-b/generated/task-spec-missing-fields.json",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        # Adding new required fields is breaking (name is not in left properties)
        assert result.status == "fail"

    def test_additive_changes_pass(self) -> None:
        """When right adds only optional properties/enum values, it's safe."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec-nested.json",
            "testdata/fixtures/repo-b/generated/task-spec-nested-safe-additive.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "pass"

    def test_missing_file_fails(self) -> None:
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/nonexistent.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"

    def test_removed_required_and_properties_fail(self) -> None:
        """The missing-fields fixture removes 'name' from both required AND properties."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec-missing-fields.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"

    # --- Deep schema comparison tests ---

    def test_nested_type_change_fail(self) -> None:
        """Changing a property's type is a breaking change."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec-nested.json",
            "testdata/fixtures/repo-b/generated/task-spec-nested-type-changed.json",
            severity="high",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert any(e.kind == "type_changed" for e in result.evidence)

    def test_enum_restriction_fail(self) -> None:
        """Removing enum values is a breaking change."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec-nested.json",
            "testdata/fixtures/repo-b/generated/task-spec-nested-enum-restricted.json",
            severity="high",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert any(e.kind == "enum_restricted" for e in result.evidence)

    def test_additional_properties_restricted_fail(self) -> None:
        """Changing additionalProperties to false is a breaking change."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec-nested.json",
            "testdata/fixtures/repo-b/generated/task-spec-nested-additional-props-closed.json",
            severity="high",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert any(e.kind == "additional_properties_restricted" for e in result.evidence)

    def test_nested_required_added_fail(self) -> None:
        """Adding new required fields in a nested schema is breaking."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec-nested.json",
            "testdata/fixtures/repo-b/generated/task-spec-nested-required-added.json",
            severity="high",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert any(e.kind == "required_added" for e in result.evidence)


class TestOpenAPICompat:
    def test_identical_specs_pass(self) -> None:
        c = _check(
            "openapi_compat",
            "testdata/fixtures/repo-a/openapi/tasks-v1.json",
            "testdata/fixtures/repo-a/openapi/tasks-v1.json",
        )
        result = run_openapi_compat_check(c, _REPO_ROOT)
        assert result.status == "pass"
        assert "backward-compatible" in result.summary.lower()

    def test_additive_changes_pass(self) -> None:
        c = _check(
            "openapi_compat",
            "testdata/fixtures/repo-a/openapi/tasks-v1.json",
            "testdata/fixtures/repo-b/openapi/tasks-v1-safe-additive.json",
        )
        result = run_openapi_compat_check(c, _REPO_ROOT)
        assert result.status == "pass"

    def test_breaking_changes_fail(self) -> None:
        c = _check(
            "openapi_compat",
            "testdata/fixtures/repo-a/openapi/tasks-v1.json",
            "testdata/fixtures/repo-b/openapi/tasks-v2-breaking.json",
        )
        result = run_openapi_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "breaking" in result.summary.lower()
        kinds = {e.kind for e in result.evidence}
        assert "endpoint_removed" in kinds or "parameter_required" in kinds

    def test_missing_file_fails(self) -> None:
        c = _check(
            "openapi_compat",
            "testdata/fixtures/repo-a/openapi/tasks-v1.json",
            "testdata/fixtures/repo-b/openapi/nonexistent.json",
        )
        result = run_openapi_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"

    def test_bad_params_error(self) -> None:
        c = CheckConfig(
            id="test-check",
            type="openapi_compat",
            severity="high",
            params={"left": 123},
        )
        result = run_openapi_compat_check(c, _REPO_ROOT)
        assert result.status == "error"

    def test_non_openapi_file_error(self) -> None:
        """A valid JSON file that isn't an OpenAPI spec should error."""
        c = _check(
            "openapi_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec.json",
        )
        result = run_openapi_compat_check(c, _REPO_ROOT)
        assert result.status == "error"

    def test_metadata_has_breaking_changes(self) -> None:
        c = _check(
            "openapi_compat",
            "testdata/fixtures/repo-a/openapi/tasks-v1.json",
            "testdata/fixtures/repo-b/openapi/tasks-v2-breaking.json",
        )
        result = run_openapi_compat_check(c, _REPO_ROOT)
        assert "breaking_changes" in result.metadata
        assert len(result.metadata["breaking_changes"]) > 0


class TestJSONSemanticEqual:
    def test_identical_files_pass(self) -> None:
        c = _check(
            "json_semantic_equal",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec.json",
        )
        result = run_json_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "pass"
        assert "identical" in result.summary.lower()

    def test_reordered_keys_pass(self) -> None:
        """Same data, different key order should pass."""
        c = _check(
            "json_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.json",
            "testdata/fixtures/repo-b/generated/config-a-reordered.json",
        )
        result = run_json_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "pass"

    def test_different_values_fail(self) -> None:
        c = _check(
            "json_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.json",
            "testdata/fixtures/repo-b/generated/config-a-different-value.json",
        )
        result = run_json_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "differ" in result.summary.lower()

    def test_missing_file_fails(self) -> None:
        c = _check(
            "json_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.json",
            "testdata/fixtures/repo-b/generated/nonexistent.json",
        )
        result = run_json_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "fail"

    def test_bad_params_error(self) -> None:
        c = CheckConfig(
            id="test-check",
            type="json_semantic_equal",
            severity="high",
            params={"left": 123},
        )
        result = run_json_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "error"

    def test_severity_preserved(self) -> None:
        c = _check(
            "json_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.json",
            "testdata/fixtures/repo-b/generated/config-a-reordered.json",
            severity="critical",
        )
        result = run_json_semantic_equal_check(c, _REPO_ROOT)
        assert result.severity == "critical"


class TestYAMLSemanticEqual:
    def test_identical_files_pass(self) -> None:
        c = _check(
            "yaml_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.yaml",
            "testdata/fixtures/repo-a/specs/config-a.yaml",
        )
        result = run_yaml_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "pass"
        assert "identical" in result.summary.lower()

    def test_reordered_keys_pass(self) -> None:
        """Same data, different key order/quoting should pass."""
        c = _check(
            "yaml_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.yaml",
            "testdata/fixtures/repo-b/generated/config-a-reordered.yaml",
        )
        result = run_yaml_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "pass"

    def test_different_values_fail(self) -> None:
        c = _check(
            "yaml_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.yaml",
            "testdata/fixtures/repo-b/generated/config-a-different-value.yaml",
        )
        result = run_yaml_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "differ" in result.summary.lower()

    def test_missing_file_fails(self) -> None:
        c = _check(
            "yaml_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.yaml",
            "testdata/fixtures/repo-b/generated/nonexistent.yaml",
        )
        result = run_yaml_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "fail"

    def test_bad_params_error(self) -> None:
        c = CheckConfig(
            id="test-check",
            type="yaml_semantic_equal",
            severity="high",
            params={"left": 123},
        )
        result = run_yaml_semantic_equal_check(c, _REPO_ROOT)
        assert result.status == "error"

    def test_severity_preserved(self) -> None:
        c = _check(
            "yaml_semantic_equal",
            "testdata/fixtures/repo-a/specs/config-a.yaml",
            "testdata/fixtures/repo-b/generated/config-a-reordered.yaml",
            severity="critical",
        )
        result = run_yaml_semantic_equal_check(c, _REPO_ROOT)
        assert result.severity == "critical"
