"""Tests for the ``generate-aw`` template generator in core/aw_template.py.

Covers:
- _url_to_slug() conversion
- generate_aw_template() with:
  - Remote repos (checkout frontmatter generated)
  - Local repos (no checkout entries)
  - Mixed local + remote repos
  - No checks configured
  - Multiple checks with different severities
  - Custom architecture/config paths
  - Single repo config
  - Empty repos (edge case)
"""

from __future__ import annotations

from repo_drift.core.aw_template import _url_to_slug, generate_aw_template
from repo_drift.core.types import CheckConfig, ProjectConfig, RepoConfig

# ── Helpers ──────────────────────────────────────────────────────────────


def _project(
    repos: list[RepoConfig],
    checks: list[CheckConfig] | None = None,
) -> ProjectConfig:
    return ProjectConfig(
        version=1,
        repos=repos,
        checks=checks or [],
        fail_on=[],
    )


def _repo(
    id: str = "acme-sdk",
    url: str = "https://github.com/org/acme-sdk.git",
    snapshot_path: str = "repos/acme-sdk",
) -> RepoConfig:
    return RepoConfig(
        id=id,
        url=url,
        ref_policy="main",
        snapshot_path=snapshot_path,
    )


def _check(
    id: str = "pod-spec-sync",
    check_type: str = "file_pair_hash",
    severity: str = "high",
    left: str = "repos/acme-sdk/api.json",
    right: str = "repos/web/api.json",
) -> CheckConfig:
    return CheckConfig(
        id=id,
        type=check_type,
        severity=severity,
        params={"left": left, "right": right},
    )


# ── _url_to_slug tests ──────────────────────────────────────────────────


class TestUrlToSlug:
    def test_https_with_git_suffix(self) -> None:
        assert _url_to_slug("https://github.com/org/repo.git") == "org/repo"

    def test_https_without_git_suffix(self) -> None:
        assert _url_to_slug("https://github.com/org/repo") == "org/repo"

    def test_https_with_trailing_slash(self) -> None:
        assert _url_to_slug("https://github.com/org/repo.git/") == "org/repo"

    def test_ssh_url(self) -> None:
        assert _url_to_slug("git@github.com:org/repo.git") == "org/repo"

    def test_non_github_url(self) -> None:
        result = _url_to_slug("https://gitlab.com/org/repo.git")
        assert result == "https://gitlab.com/org/repo"

    def test_already_slug(self) -> None:
        # Not a full URL — no github.com in it, so returned as-is minus .git
        assert _url_to_slug("org/repo.git") == "org/repo"


# ── generate_aw_template tests ──────────────────────────────────────────


class TestGenerateAWTemplate:
    def test_basic_remote_repos(self) -> None:
        """Remote repos should generate checkout frontmatter."""
        cfg = _project(
            repos=[
                _repo(id="api", url="https://github.com/org/api.git", snapshot_path="repos/api"),
                _repo(id="web", url="https://github.com/org/web.git", snapshot_path="repos/web"),
            ],
            checks=[_check()],
        )
        template = generate_aw_template(cfg)

        assert "checkout:" in template
        assert "  - repo: org/api" in template
        assert "    path: repos/api" in template
        assert "  - repo: org/web" in template
        assert "    path: repos/web" in template
        assert "2 repo(s)" in template
        assert "api, web" in template

    def test_local_repos_no_checkout(self) -> None:
        """Local repos should produce no checkout entries."""
        cfg = _project(
            repos=[
                _repo(id="local", url="/Users/me/project", snapshot_path="/Users/me/project"),
            ],
            checks=[_check()],
        )
        template = generate_aw_template(cfg)

        assert "# No remote repos to check out" in template
        assert "1 repo(s)" in template

    def test_mixed_local_and_remote(self) -> None:
        """Mixed config: only remote repos get checkout entries."""
        cfg = _project(
            repos=[
                _repo(
                    id="remote",
                    url="https://github.com/org/remote.git",
                    snapshot_path="repos/remote",
                ),
                _repo(id="local", url="/home/user/local", snapshot_path="/home/user/local"),
            ],
            checks=[_check()],
        )
        template = generate_aw_template(cfg)

        assert "  - repo: org/remote" in template
        assert "2 repo(s)" in template
        assert "remote, local" in template
        # Should NOT have a checkout line for local
        assert "/home/user/local" not in template.split("checkout:")[1].split("---")[0]

    def test_no_checks(self) -> None:
        """Config with no checks should show 'No checks configured'."""
        cfg = _project(
            repos=[_repo()],
            checks=[],
        )
        template = generate_aw_template(cfg)

        assert "- No checks configured" in template

    def test_multiple_checks_listed(self) -> None:
        """All checks should appear in the Monitored Contracts section."""
        cfg = _project(
            repos=[_repo()],
            checks=[
                _check(id="check-1", severity="high", left="a/left.json", right="b/right.json"),
                _check(
                    id="check-2",
                    severity="medium",
                    check_type="json_schema_compat",
                    left="c/schema.json",
                    right="d/schema.json",
                ),
            ],
        )
        template = generate_aw_template(cfg)

        assert "**check-1** (file_pair_hash, severity: high)" in template
        assert "`a/left.json` <-> `b/right.json`" in template
        assert "**check-2** (json_schema_compat, severity: medium)" in template
        assert "`c/schema.json` <-> `d/schema.json`" in template

    def test_custom_architecture_path(self) -> None:
        """Custom architecture path should be in the template."""
        cfg = _project(repos=[_repo()], checks=[_check()])
        template = generate_aw_template(cfg, architecture_path="docs/ARCH.md")

        assert "cat docs/ARCH.md" in template

    def test_custom_config_path(self) -> None:
        """Custom config path should be in the template."""
        cfg = _project(repos=[_repo()], checks=[_check()])
        template = generate_aw_template(cfg, config_path="config/drift.json")

        assert "cat config/drift.json" in template

    def test_default_paths(self) -> None:
        """Default paths should be ARCHITECTURE.md and .repo-drift.json."""
        cfg = _project(repos=[_repo()], checks=[_check()])
        template = generate_aw_template(cfg)

        assert "cat ARCHITECTURE.md" in template
        assert "cat .repo-drift.json" in template

    def test_frontmatter_structure(self) -> None:
        """Template should have valid gh-aw frontmatter."""
        cfg = _project(repos=[_repo()], checks=[_check()])
        template = generate_aw_template(cfg)

        assert template.startswith("---\n")
        # Should have closing frontmatter
        parts = template.split("---")
        assert len(parts) >= 3  # before, frontmatter, content

        # Check key frontmatter fields
        assert "description: Cross-repo contract drift review" in template
        assert "tools:" in template
        assert "  - github" in template
        assert "safe-outputs:" in template
        assert "  - add-comment" in template

    def test_task_instructions_present(self) -> None:
        """Template should include review instructions."""
        cfg = _project(repos=[_repo()], checks=[_check()])
        template = generate_aw_template(cfg)

        assert "## Your Task" in template
        assert "Read the PR diff" in template
        assert "Post a review comment" in template
        assert "## Output Format" in template
        assert "Cross-Repo Drift Review" in template

    def test_ssh_repo_url(self) -> None:
        """SSH URLs should be recognized as remote and checked out."""
        cfg = _project(
            repos=[
                _repo(
                    id="ssh-repo",
                    url="git@github.com:org/ssh-repo.git",
                    snapshot_path="repos/ssh-repo",
                ),
            ],
            checks=[_check()],
        )
        template = generate_aw_template(cfg)

        assert "  - repo: org/ssh-repo" in template
        assert "    path: repos/ssh-repo" in template

    def test_check_missing_params(self) -> None:
        """Checks without left/right params should show '?'."""
        cfg = _project(
            repos=[_repo()],
            checks=[
                CheckConfig(
                    id="weird-check",
                    type="file_pair_hash",
                    severity="low",
                    params={},
                ),
            ],
        )
        template = generate_aw_template(cfg)

        assert "**weird-check** (file_pair_hash, severity: low): `?` <-> `?`" in template
