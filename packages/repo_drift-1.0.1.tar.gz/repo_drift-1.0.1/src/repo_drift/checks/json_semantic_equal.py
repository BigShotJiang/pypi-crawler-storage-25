"""Semantic JSON equality check.

Compares two JSON files by parsing and normalizing them (sorted keys, consistent
formatting). Two files that contain the same data but differ in key order or
whitespace will pass. Any actual value difference will fail.

This is a zero-dependency stdlib-only check.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from repo_drift.core.types import CheckConfig, CheckResult, Evidence


def _normalize_json(path: Path) -> tuple[str, Any] | None:
    """Parse and re-serialize JSON with sorted keys.

    Returns (canonical_str, parsed_value) or None on failure.
    """
    try:
        raw = path.read_text()
        parsed = json.loads(raw)
        canonical = json.dumps(parsed, sort_keys=True, separators=(",", ":"))
        return canonical, parsed
    except Exception:
        return None


def run_json_semantic_equal_check(check: CheckConfig, root: Path) -> CheckResult:
    """Run semantic JSON equality check."""
    left_rel = check.params.get("left")
    right_rel = check.params.get("right")

    if not isinstance(left_rel, str) or not isinstance(right_rel, str):
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Invalid check params: expected string `left` and `right`",
            evidence=[
                Evidence(kind="config", message="Missing or invalid params.left/params.right")
            ],
        )

    left = (root / left_rel).resolve()
    right = (root / right_rel).resolve()

    if not left.exists() or not right.exists():
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="fail",
            severity=check.severity,
            summary="Semantic equality check failed due to missing file(s)",
            evidence=[
                Evidence(
                    kind="missing",
                    message="Left file missing" if not left.exists() else "Left file present",
                    path=str(left) if not left.exists() else None,
                ),
                Evidence(
                    kind="missing",
                    message="Right file missing" if not right.exists() else "Right file present",
                    path=str(right) if not right.exists() else None,
                ),
            ],
        )

    left_result = _normalize_json(left)
    right_result = _normalize_json(right)

    if left_result is None or right_result is None:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Failed to parse JSON",
            evidence=[
                Evidence(
                    kind="parse",
                    message="Unable to parse left file",
                    path=str(left) if left_result is None else None,
                ),
                Evidence(
                    kind="parse",
                    message="Unable to parse right file",
                    path=str(right) if right_result is None else None,
                ),
            ],
        )

    left_canonical, _ = left_result
    right_canonical, _ = right_result

    if left_canonical == right_canonical:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="pass",
            severity=check.severity,
            summary="No drift: JSON documents are semantically identical",
            evidence=[
                Evidence(
                    kind="semantic_equal",
                    message="Documents are identical after normalization",
                    left=str(left),
                    right=str(right),
                )
            ],
        )
    else:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="fail",
            severity=check.severity,
            summary="Drift detected: JSON documents differ semantically",
            evidence=[
                Evidence(
                    kind="semantic_diff",
                    message="Documents differ after normalization",
                    left=str(left),
                    right=str(right),
                )
            ],
        )
