"""OpenAPI backward-compatibility check.

Parses two OpenAPI 3.x specs (JSON) and detects breaking changes:
  - Endpoints removed
  - Response fields removed
  - Required request fields added
  - Parameters made required
  - Response status codes removed
  - Type/enum changes in parameters or schemas (delegates to json_schema_compat helpers)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from repo_drift.checks.json_schema_compat import _compare_schemas
from repo_drift.core.types import CheckConfig, CheckResult, Evidence


def _load_json(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text())
    except Exception:
        return None
    if isinstance(payload, dict):
        return payload
    return None


def _is_openapi(doc: dict[str, Any]) -> bool:
    return isinstance(doc.get("openapi"), str) or isinstance(doc.get("swagger"), str)


def _compare_openapi(
    left: dict[str, Any],
    right: dict[str, Any],
) -> list[Evidence]:
    """Compare two OpenAPI specs and return breaking-change evidence."""
    issues: list[Evidence] = []

    left_paths = left.get("paths", {})
    right_paths = right.get("paths", {})

    if not isinstance(left_paths, dict) or not isinstance(right_paths, dict):
        return issues

    # --- Endpoints removed ---
    for path_key in sorted(left_paths.keys()):
        if path_key not in right_paths:
            issues.append(
                Evidence(
                    kind="endpoint_removed",
                    message=f"Endpoint removed: {path_key}",
                )
            )
            continue

        left_path_item = left_paths[path_key]
        right_path_item = right_paths[path_key]
        if not isinstance(left_path_item, dict) or not isinstance(right_path_item, dict):
            continue

        # --- Methods removed ---
        http_methods = {"get", "post", "put", "patch", "delete", "options", "head", "trace"}
        for method in sorted(http_methods):
            left_op = left_path_item.get(method)
            right_op = right_path_item.get(method)

            if left_op is not None and right_op is None:
                issues.append(
                    Evidence(
                        kind="endpoint_removed",
                        message=f"Method removed: {method.upper()} {path_key}",
                    )
                )
                continue

            if not isinstance(left_op, dict) or not isinstance(right_op, dict):
                continue

            op_path = f"{method.upper()} {path_key}"

            # --- Parameters ---
            issues.extend(_compare_parameters(left_op, right_op, op_path))

            # --- Request body ---
            issues.extend(_compare_request_body(left_op, right_op, op_path))

            # --- Responses ---
            issues.extend(_compare_responses(left_op, right_op, op_path))

    return issues


def _compare_parameters(
    left_op: dict[str, Any],
    right_op: dict[str, Any],
    op_path: str,
) -> list[Evidence]:
    """Compare operation parameters for breaking changes."""
    issues: list[Evidence] = []

    left_params = left_op.get("parameters", [])
    right_params = right_op.get("parameters", [])
    if not isinstance(left_params, list) or not isinstance(right_params, list):
        return issues

    # Index by (name, in) tuple
    left_by_key: dict[tuple[str, str], dict[str, Any]] = {}
    for p in left_params:
        if isinstance(p, dict):
            key = (p.get("name", ""), p.get("in", ""))
            left_by_key[key] = p

    right_by_key: dict[tuple[str, str], dict[str, Any]] = {}
    for p in right_params:
        if isinstance(p, dict):
            key = (p.get("name", ""), p.get("in", ""))
            right_by_key[key] = p

    # Parameters made required
    for key, right_param in sorted(right_by_key.items()):
        left_param = left_by_key.get(key)
        right_required = right_param.get("required", False)

        if left_param is not None:
            left_required = left_param.get("required", False)
            if not left_required and right_required:
                issues.append(
                    Evidence(
                        kind="parameter_required",
                        message=f"{op_path}: parameter '{key[0]}' ({key[1]}) made required",
                    )
                )
        elif right_required and key not in left_by_key:
            # New required parameter added
            issues.append(
                Evidence(
                    kind="parameter_required",
                    message=f"{op_path}: new required parameter '{key[0]}' ({key[1]}) added",
                )
            )

    return issues


def _compare_request_body(
    left_op: dict[str, Any],
    right_op: dict[str, Any],
    op_path: str,
) -> list[Evidence]:
    """Compare request bodies for breaking changes."""
    issues: list[Evidence] = []

    left_body = left_op.get("requestBody", {})
    right_body = right_op.get("requestBody", {})
    if not isinstance(left_body, dict) or not isinstance(right_body, dict):
        return issues

    # Get schemas from application/json content type
    left_schema = _extract_content_schema(left_body)
    right_schema = _extract_content_schema(right_body)

    if left_schema and right_schema:
        schema_issues = _compare_schemas(left_schema, right_schema, f"{op_path} requestBody")
        # For request bodies, added required fields are breaking
        issues.extend(schema_issues)

    return issues


def _compare_responses(
    left_op: dict[str, Any],
    right_op: dict[str, Any],
    op_path: str,
) -> list[Evidence]:
    """Compare responses for breaking changes."""
    issues: list[Evidence] = []

    left_responses = left_op.get("responses", {})
    right_responses = right_op.get("responses", {})
    if not isinstance(left_responses, dict) or not isinstance(right_responses, dict):
        return issues

    # Status codes removed
    for code in sorted(left_responses.keys()):
        if code not in right_responses:
            issues.append(
                Evidence(
                    kind="response_removed",
                    message=f"{op_path}: response status '{code}' removed",
                )
            )
            continue

        # Compare response schemas
        left_resp = left_responses[code]
        right_resp = right_responses[code]
        if not isinstance(left_resp, dict) or not isinstance(right_resp, dict):
            continue

        left_schema = _extract_content_schema(left_resp)
        right_schema = _extract_content_schema(right_resp)

        if left_schema and right_schema:
            schema_issues = _compare_schemas(
                left_schema, right_schema, f"{op_path} response[{code}]"
            )
            issues.extend(schema_issues)

    return issues


def _extract_content_schema(container: dict[str, Any]) -> dict[str, Any] | None:
    """Extract schema from content.application/json.schema."""
    content = container.get("content", {})
    if not isinstance(content, dict):
        return None
    json_content = content.get("application/json", {})
    if not isinstance(json_content, dict):
        return None
    schema = json_content.get("schema")
    if isinstance(schema, dict):
        return schema
    return None


def run_openapi_compat_check(check: CheckConfig, root: Path) -> CheckResult:
    """Run OpenAPI backward-compatibility check."""
    left_rel = check.params.get("left")
    right_rel = check.params.get("right")

    if not isinstance(left_rel, str) or not isinstance(right_rel, str):
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Invalid check params: expected string `left` and `right`",
            evidence=[
                Evidence(kind="config", message="Missing or invalid params.left/params.right")
            ],
        )

    left = (root / left_rel).resolve()
    right = (root / right_rel).resolve()

    if not left.exists() or not right.exists():
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="fail",
            severity=check.severity,
            summary="OpenAPI compatibility check failed due to missing file(s)",
            evidence=[
                Evidence(
                    kind="missing",
                    message="Left spec missing" if not left.exists() else "Left spec present",
                    path=str(left) if not left.exists() else None,
                ),
                Evidence(
                    kind="missing",
                    message="Right spec missing" if not right.exists() else "Right spec present",
                    path=str(right) if not right.exists() else None,
                ),
            ],
        )

    left_doc = _load_json(left)
    right_doc = _load_json(right)

    if left_doc is None or right_doc is None:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Failed to parse OpenAPI spec JSON",
            evidence=[
                Evidence(
                    kind="parse",
                    message="Unable to parse left spec",
                    path=str(left) if left_doc is None else None,
                ),
                Evidence(
                    kind="parse",
                    message="Unable to parse right spec",
                    path=str(right) if right_doc is None else None,
                ),
            ],
        )

    if not _is_openapi(left_doc) or not _is_openapi(right_doc):
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="File does not appear to be an OpenAPI spec",
            evidence=[Evidence(kind="parse", message="Missing 'openapi' or 'swagger' field")],
        )

    issues = _compare_openapi(left_doc, right_doc)

    breaking_kinds = {
        "endpoint_removed",
        "parameter_required",
        "response_removed",
        "type_changed",
        "enum_restricted",
        "additional_properties_restricted",
        "required_removed",
        "required_added",
    }
    warn_kinds = {"properties_removed"}

    has_breaking = any(e.kind in breaking_kinds for e in issues)
    has_warn = any(e.kind in warn_kinds for e in issues)

    if has_breaking:
        status = "fail"
        summary = "Breaking API change detected"
    elif has_warn:
        status = "warn"
        summary = "Potential API drift detected"
    else:
        status = "pass"
        summary = "OpenAPI specs are backward-compatible"

    if not issues:
        issues = [
            Evidence(
                kind="compat",
                message="No breaking API changes detected",
                left=str(left),
                right=str(right),
            )
        ]

    return CheckResult(
        check_id=check.id,
        check_type=check.type,
        status=status,
        severity=check.severity,
        summary=summary,
        evidence=issues,
        metadata={
            "breaking_changes": [e.message for e in issues if e.kind in breaking_kinds],
        },
    )
