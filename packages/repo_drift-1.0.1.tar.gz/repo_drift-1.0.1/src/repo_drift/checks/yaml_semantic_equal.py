"""Semantic YAML equality check.

Compares two YAML files by parsing and normalizing them via JSON canonical form.
Two files that contain the same data but differ in key order, quoting style, or
whitespace will pass. Any actual value difference will fail.

Uses PyYAML if available, falls back to a basic YAML subset parser for simple
key-value YAML files. For full YAML support (anchors, aliases, complex types),
install PyYAML: ``pip install pyyaml``.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from repo_drift.core.types import CheckConfig, CheckResult, Evidence


def _parse_yaml(text: str) -> Any:
    """Parse YAML text, using PyYAML if available, otherwise a basic fallback."""
    try:
        import yaml  # pyrefly: ignore[missing-import]

        return yaml.safe_load(text)
    except ImportError:
        pass

    # Basic fallback: handle simple key-value YAML and lists
    return _basic_yaml_parse(text)


def _basic_yaml_parse(text: str) -> Any:
    """Minimal YAML parser for simple mappings and sequences.

    Supports:
      - Top-level and nested mappings (key: value)
      - Sequences (- item)
      - Quoted and unquoted strings
      - Integers, floats, booleans, null
    """
    lines = text.split("\n")
    result, _ = _parse_block(lines, 0, 0)
    return result


def _parse_block(lines: list[str], start: int, base_indent: int) -> tuple[Any, int]:
    """Parse a block at the given indentation level."""
    if start >= len(lines):
        return None, start

    # Determine if this is a mapping or a sequence
    for i in range(start, len(lines)):
        line = lines[i]
        stripped = line.lstrip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("- "):
            return _parse_sequence(lines, start, base_indent)
        else:
            return _parse_mapping(lines, start, base_indent)

    return None, len(lines)


def _parse_mapping(lines: list[str], start: int, base_indent: int) -> tuple[dict[str, Any], int]:
    """Parse a YAML mapping."""
    result: dict[str, Any] = {}
    i = start
    while i < len(lines):
        line = lines[i]
        stripped = line.lstrip()

        if not stripped or stripped.startswith("#"):
            i += 1
            continue

        current_indent = len(line) - len(stripped)
        if current_indent < base_indent:
            break

        if ":" not in stripped:
            i += 1
            continue

        colon_pos = stripped.index(":")
        key = stripped[:colon_pos].strip().strip("\"'")
        rest = stripped[colon_pos + 1 :].strip()

        if rest:
            result[key] = _parse_scalar(rest)
            i += 1
        else:
            # Value on next line(s), determine child indent
            child_indent = base_indent + 2
            for j in range(i + 1, len(lines)):
                child_line = lines[j]
                child_stripped = child_line.lstrip()
                if child_stripped and not child_stripped.startswith("#"):
                    child_indent = len(child_line) - len(child_stripped)
                    break

            child_val, i = _parse_block(lines, i + 1, child_indent)
            result[key] = child_val

    return result, i


def _parse_sequence(lines: list[str], start: int, base_indent: int) -> tuple[list[Any], int]:
    """Parse a YAML sequence."""
    result: list[Any] = []
    i = start
    while i < len(lines):
        line = lines[i]
        stripped = line.lstrip()

        if not stripped or stripped.startswith("#"):
            i += 1
            continue

        current_indent = len(line) - len(stripped)
        if current_indent < base_indent:
            break

        if stripped.startswith("- "):
            val = stripped[2:].strip()
            result.append(_parse_scalar(val))
            i += 1
        else:
            i += 1

    return result, i


def _parse_scalar(text: str) -> Any:
    """Parse a YAML scalar value."""
    text = text.strip()

    # Remove comments
    if " #" in text:
        text = text[: text.index(" #")].strip()

    # Quoted strings
    if (text.startswith('"') and text.endswith('"')) or (
        text.startswith("'") and text.endswith("'")
    ):
        return text[1:-1]

    # Null
    if text in ("null", "~", ""):
        return None

    # Booleans
    if text.lower() in ("true", "yes", "on"):
        return True
    if text.lower() in ("false", "no", "off"):
        return False

    # Numbers
    try:
        return int(text)
    except ValueError:
        pass
    try:
        return float(text)
    except ValueError:
        pass

    return text


def _normalize_yaml(path: Path) -> tuple[str, Any] | None:
    """Parse YAML and produce canonical JSON string for comparison."""
    try:
        raw = path.read_text()
        parsed = _parse_yaml(raw)
        canonical = json.dumps(parsed, sort_keys=True, separators=(",", ":"))
        return canonical, parsed
    except Exception:
        return None


def run_yaml_semantic_equal_check(check: CheckConfig, root: Path) -> CheckResult:
    """Run semantic YAML equality check."""
    left_rel = check.params.get("left")
    right_rel = check.params.get("right")

    if not isinstance(left_rel, str) or not isinstance(right_rel, str):
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Invalid check params: expected string `left` and `right`",
            evidence=[
                Evidence(kind="config", message="Missing or invalid params.left/params.right")
            ],
        )

    left = (root / left_rel).resolve()
    right = (root / right_rel).resolve()

    if not left.exists() or not right.exists():
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="fail",
            severity=check.severity,
            summary="Semantic equality check failed due to missing file(s)",
            evidence=[
                Evidence(
                    kind="missing",
                    message="Left file missing" if not left.exists() else "Left file present",
                    path=str(left) if not left.exists() else None,
                ),
                Evidence(
                    kind="missing",
                    message="Right file missing" if not right.exists() else "Right file present",
                    path=str(right) if not right.exists() else None,
                ),
            ],
        )

    left_result = _normalize_yaml(left)
    right_result = _normalize_yaml(right)

    if left_result is None or right_result is None:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Failed to parse YAML",
            evidence=[
                Evidence(
                    kind="parse",
                    message="Unable to parse left file",
                    path=str(left) if left_result is None else None,
                ),
                Evidence(
                    kind="parse",
                    message="Unable to parse right file",
                    path=str(right) if right_result is None else None,
                ),
            ],
        )

    left_canonical, _ = left_result
    right_canonical, _ = right_result

    if left_canonical == right_canonical:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="pass",
            severity=check.severity,
            summary="No drift: YAML documents are semantically identical",
            evidence=[
                Evidence(
                    kind="semantic_equal",
                    message="Documents are identical after normalization",
                    left=str(left),
                    right=str(right),
                )
            ],
        )
    else:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="fail",
            severity=check.severity,
            summary="Drift detected: YAML documents differ semantically",
            evidence=[
                Evidence(
                    kind="semantic_diff",
                    message="Documents differ after normalization",
                    left=str(left),
                    right=str(right),
                )
            ],
        )
