from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from repo_drift.core.types import CheckConfig, CheckResult, Evidence


def _load_json(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text())
    except Exception:
        return None
    if isinstance(payload, dict):
        return payload
    return None


def _normalize_type(t: Any) -> set[str]:
    """Normalize a JSON Schema 'type' value to a set of type strings."""
    if isinstance(t, str):
        return {t}
    if isinstance(t, list):
        return {s for s in t if isinstance(s, str)}
    return set()


def _get_enum(schema: dict[str, Any]) -> set[str] | None:
    """Extract enum values as a set, or None if no enum."""
    raw = schema.get("enum")
    if not isinstance(raw, list):
        return None
    return {json.dumps(v, sort_keys=True) for v in raw}


def _compare_schemas(
    left: dict[str, Any],
    right: dict[str, Any],
    path: str,
) -> list[Evidence]:
    """Recursively compare two JSON schemas and return breaking-change evidence.

    'left' is the source-of-truth (old/producer), 'right' is the consumer (new).
    We detect changes in 'right' that would break consumers of 'left'.
    """
    issues: list[Evidence] = []

    # --- Type change ---
    left_types = _normalize_type(left.get("type"))
    right_types = _normalize_type(right.get("type"))
    if (
        left_types
        and right_types
        and left_types != right_types
        and not right_types.issuperset(left_types)
    ):
        issues.append(
            Evidence(
                kind="type_changed",
                message=(
                    f"{path}: type changed from {sorted(left_types)} to {sorted(right_types)}"
                ),
            )
        )

    # --- Enum restriction ---
    left_enum = _get_enum(left)
    right_enum = _get_enum(right)
    if left_enum is not None and right_enum is not None:
        removed_values = left_enum - right_enum
        if removed_values:
            issues.append(
                Evidence(
                    kind="enum_restricted",
                    message=f"{path}: enum values removed: {sorted(removed_values)}",
                )
            )
    elif left_enum is None and right_enum is not None:
        # Adding an enum where there was none is a restriction
        issues.append(
            Evidence(
                kind="enum_restricted",
                message=f"{path}: enum constraint added where none existed",
            )
        )

    # --- additionalProperties: true -> false is breaking ---
    left_additional = left.get("additionalProperties")
    right_additional = right.get("additionalProperties")
    if left_additional is not False and right_additional is False:
        issues.append(
            Evidence(
                kind="additional_properties_restricted",
                message=f"{path}: additionalProperties changed to false",
            )
        )

    # --- Required fields added (breaking for producers of data matching 'left') ---
    left_req_raw = left.get("required", [])
    right_req_raw = right.get("required", [])
    left_required: set[str] = (
        {str(x) for x in left_req_raw} if isinstance(left_req_raw, list) else set()
    )
    right_required: set[str] = (
        {str(x) for x in right_req_raw} if isinstance(right_req_raw, list) else set()
    )

    removed_required = sorted(left_required - right_required)
    if removed_required:
        issues.append(
            Evidence(
                kind="required_removed",
                message=f"{path}: required fields removed: {', '.join(removed_required)}",
            )
        )

    added_required = sorted(right_required - left_required)
    if added_required:
        # New required fields that don't exist in left properties = breaking
        left_props = left.get("properties", {}) if isinstance(left.get("properties"), dict) else {}
        truly_new: list[str] = [f for f in added_required if f not in left_props]
        if truly_new:
            issues.append(
                Evidence(
                    kind="required_added",
                    message=f"{path}: new required fields added: {', '.join(truly_new)}",
                )
            )

    # --- Properties removed (warn-level) ---
    left_props = left.get("properties", {}) if isinstance(left.get("properties"), dict) else {}
    right_props = right.get("properties", {}) if isinstance(right.get("properties"), dict) else {}
    removed_props = sorted(set(left_props.keys()) - set(right_props.keys()))
    if removed_props:
        issues.append(
            Evidence(
                kind="properties_removed",
                message=f"{path}: properties removed: {', '.join(removed_props)}",
            )
        )

    # --- Recurse into shared properties ---
    for prop_name in sorted(set(left_props.keys()) & set(right_props.keys())):
        left_sub = left_props[prop_name]
        right_sub = right_props[prop_name]
        if isinstance(left_sub, dict) and isinstance(right_sub, dict):
            issues.extend(_compare_schemas(left_sub, right_sub, f"{path}.properties.{prop_name}"))

    # --- Recurse into items (for arrays) ---
    left_items = left.get("items")
    right_items = right.get("items")
    if isinstance(left_items, dict) and isinstance(right_items, dict):
        issues.extend(_compare_schemas(left_items, right_items, f"{path}.items"))

    return issues


def run_json_schema_compat_check(check: CheckConfig, root: Path) -> CheckResult:
    left_rel = check.params.get("left")
    right_rel = check.params.get("right")

    if not isinstance(left_rel, str) or not isinstance(right_rel, str):
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Invalid check params: expected string `left` and `right`",
            evidence=[
                Evidence(kind="config", message="Missing or invalid params.left/params.right")
            ],
        )

    left = (root / left_rel).resolve()
    right = (root / right_rel).resolve()

    if not left.exists() or not right.exists():
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="fail",
            severity=check.severity,
            summary="Schema compatibility check failed due to missing file(s)",
            evidence=[
                Evidence(
                    kind="missing",
                    message="Left schema missing",
                    path=str(left) if not left.exists() else None,
                ),
                Evidence(
                    kind="missing",
                    message="Right schema missing",
                    path=str(right) if not right.exists() else None,
                ),
            ],
        )

    left_schema = _load_json(left)
    right_schema = _load_json(right)
    if left_schema is None or right_schema is None:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Failed to parse schema JSON",
            evidence=[
                Evidence(
                    kind="parse",
                    message="Unable to parse left schema",
                    path=str(left) if left_schema is None else None,
                ),
                Evidence(
                    kind="parse",
                    message="Unable to parse right schema",
                    path=str(right) if right_schema is None else None,
                ),
            ],
        )

    # Deep recursive comparison
    issues = _compare_schemas(left_schema, right_schema, "$")

    # Classify: any breaking kinds → fail; properties_removed only → warn; else → pass
    breaking_kinds = {
        "type_changed",
        "enum_restricted",
        "additional_properties_restricted",
        "required_removed",
        "required_added",
    }
    warn_kinds = {"properties_removed"}

    has_breaking = any(e.kind in breaking_kinds for e in issues)
    has_warn = any(e.kind in warn_kinds for e in issues)

    if has_breaking:
        status = "fail"
        summary = "Incompatible schema change detected"
    elif has_warn:
        status = "warn"
        summary = "Potential drift: properties removed from schema"
    else:
        status = "pass"
        summary = "Schema compatibility check passed"

    if not issues:
        issues = [
            Evidence(
                kind="compat",
                message="No breaking changes detected",
                left=str(left),
                right=str(right),
            )
        ]

    # Build metadata for backward compat with existing consumers
    removed_required = [e.message for e in issues if e.kind == "required_removed"]
    removed_props = [e.message for e in issues if e.kind == "properties_removed"]

    return CheckResult(
        check_id=check.id,
        check_type=check.type,
        status=status,
        severity=check.severity,
        summary=summary,
        evidence=issues,
        metadata={
            "removed_required": removed_required,
            "removed_props": removed_props,
            "breaking_changes": [e.message for e in issues if e.kind in breaking_kinds],
        },
    )
