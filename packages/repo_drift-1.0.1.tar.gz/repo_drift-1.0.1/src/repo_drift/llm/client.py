"""Abstract LLM client interface."""

from __future__ import annotations

import json
import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

_logger = logging.getLogger(__name__)

# Valid thinking/reasoning effort levels.
VALID_EFFORTS = ("low", "medium", "high")

# Budget tokens for Claude extended thinking at each effort level.
CLAUDE_THINKING_BUDGETS: dict[str, int] = {
    "low": 1024,
    "medium": 4096,
    "high": 10240,
}

# Pattern for OpenAI reasoning/o-series models (o1, o3, o4-mini, etc.).
_O_SERIES_RE = re.compile(r"^o\d")

# Pattern for Claude models.
_CLAUDE_RE = re.compile(r"claude", re.IGNORECASE)


def is_o_series_model(model: str) -> bool:
    """Return True if model is an OpenAI o-series reasoning model."""
    return bool(_O_SERIES_RE.match(model))


def is_claude_model(model: str) -> bool:
    """Return True if model is an Anthropic Claude model."""
    return bool(_CLAUDE_RE.search(model))


def parse_model_spec(spec: str) -> tuple[str, str | None]:
    """Parse a ``model^effort`` string into ``(model_name, effort_or_none)``.

    Examples:
        >>> parse_model_spec("gpt-4o")
        ('gpt-4o', None)
        >>> parse_model_spec("claude-sonnet-4^high")
        ('claude-sonnet-4', 'high')

    Raises:
        ValueError: If the effort level is not one of low/medium/high.
    """
    if "^" in spec:
        model, effort = spec.rsplit("^", 1)
        effort = effort.lower().strip()
        if effort not in VALID_EFFORTS:
            raise ValueError(
                f"Invalid thinking effort '{effort}' in '{spec}'. "
                f"Must be one of: {', '.join(VALID_EFFORTS)}"
            )
        return model.strip(), effort
    return spec.strip(), None


@dataclass(slots=True)
class LLMResponse:
    """Structured response from an LLM call."""

    content: str
    model: str
    usage: dict[str, int] = field(default_factory=dict)

    def json(self) -> dict[str, Any]:
        """Parse response content as JSON.

        Extracts JSON from markdown code fences if present, and tolerates
        trailing text after the JSON object (e.g. LLM explanations).
        """
        text = self.content.strip()

        # Strip markdown code fences (```json ... ``` or ``` ... ```)
        if text.startswith("```"):
            first_newline = text.index("\n")
            text = text[first_newline + 1 :]
            if text.endswith("```"):
                text = text[: -len("```")]
            text = text.strip()

        # Try strict parse first.
        try:
            return json.loads(text)  # type: ignore[no-any-return]
        except json.JSONDecodeError:
            pass

        # Fallback: decode only the first JSON object (ignores trailing text).
        try:
            decoder = json.JSONDecoder()
            # Find the first '{' to handle any leading non-JSON text.
            start = text.index("{")
            result, _ = decoder.raw_decode(text, start)
            if isinstance(result, dict):
                return result
        except (json.JSONDecodeError, ValueError):
            pass

        raise ValueError(f"Could not extract JSON object from LLM response: {text[:200]!r}")


class LLMClient(ABC):
    """Abstract base for LLM API clients."""

    def __init__(self, model: str, thinking_effort: str | None = None):
        self.model = model
        self.thinking_effort = thinking_effort
        self._total_prompt_tokens = 0
        self._total_completion_tokens = 0

    @abstractmethod
    def complete(self, system: str, user: str) -> LLMResponse:
        """Send a chat completion request.

        Args:
            system: System prompt.
            user: User message.

        Returns:
            LLMResponse with the assistant's reply.
        """

    @abstractmethod
    def list_models(self) -> list[dict[str, str]]:
        """List available models from the provider.

        Returns:
            List of model info dicts, each containing at least an "id" key.
        """

    def _track_usage(self, usage: dict[str, int]) -> None:
        prompt = usage.get("prompt_tokens", 0)
        completion = usage.get("completion_tokens", 0)
        self._total_prompt_tokens += prompt
        self._total_completion_tokens += completion
        _logger.debug(
            "LLM usage: prompt=%d completion=%d (total: prompt=%d completion=%d)",
            prompt,
            completion,
            self._total_prompt_tokens,
            self._total_completion_tokens,
        )

    @property
    def total_tokens(self) -> dict[str, int]:
        return {
            "prompt_tokens": self._total_prompt_tokens,
            "completion_tokens": self._total_completion_tokens,
            "total": self._total_prompt_tokens + self._total_completion_tokens,
        }


def validate_clients(
    clients: list[LLMClient],
    interactive: bool = False,
) -> list[LLMClient]:
    """Pre-flight validation: test each client with a trivial prompt.

    Returns the list of clients that succeeded. If a model fails and
    ``interactive`` is True (tty), prompts the user to continue without it.
    Otherwise, logs a warning and drops the failed model.

    Raises:
        SystemExit: If all models fail, or if the user declines to continue.
    """
    import sys

    valid: list[LLMClient] = []
    failed: list[tuple[LLMClient, str]] = []

    for client in clients:
        try:
            _logger.info("Validating model %s ...", client.model)
            client.complete(
                system='Respond with a json object: {"ok":true}',
                user="Validate.",
            )
            valid.append(client)
            _logger.info("Model %s: OK", client.model)
        except Exception as exc:
            reason = str(exc)
            _logger.warning("Model %s: FAILED (%s)", client.model, reason)
            failed.append((client, reason))

    if not failed:
        return valid

    # Report failures.
    for client, reason in failed:
        print(f"WARNING: Model '{client.model}' is not available: {reason}")

    if not valid:
        raise SystemExit(
            "All models failed validation. Cannot continue.\n"
            "Check model names with: repo-drift models"
        )

    if interactive and sys.stdin.isatty():
        remaining = ", ".join(c.model for c in valid)
        try:
            answer = (
                input(f"Continue with {len(valid)} remaining model(s) ({remaining})? [Y/n] ")
                .strip()
                .lower()
            )
        except (EOFError, KeyboardInterrupt):
            raise SystemExit("\nAborted.") from None
        if answer in ("n", "no"):
            raise SystemExit("Aborted by user.")

    return valid
