"""Init workflow — 5-phase pipeline for architecture mapping and config generation.

Phase 1: Snapshot  — clone/fetch all repos (reuses existing snapshot logic)
Phase 2: Analyze   — deep scan of each repo (file-based + LLM-enhanced)
Phase 3: Map       — LLM builds cross-repo architecture map
Phase 4: Discover  — existing contract file discovery (scan + classify)
Phase 5: Generate  — produce ARCHITECTURE.md + .repo-drift.json

Supports multi-model consensus at every LLM-powered phase.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from repo_drift.core.snapshot import SnapshotResult, ensure_snapshot
from repo_drift.core.types import RepoConfig
from repo_drift.discover.catalog import ContractPair, RepoCatalog
from repo_drift.discover.consensus import merge_catalogs, merge_configs, merge_pairs
from repo_drift.discover.prompts import format_discover_prompt, format_generate_prompt
from repo_drift.discover.scan import (
    build_file_tree,
    read_candidate_preview,
    scan_repo_for_candidates,
)
from repo_drift.discover.workflow import (
    _build_repo_configs,
    _catalogs_to_json,
)
from repo_drift.llm.client import LLMClient

from .analyze import analyze_repo
from .markdown import render_architecture_md
from .overrides import load_overrides, merge_config_with_overrides
from .prompts import format_analyze_prompt, format_map_prompt
from .types import (
    ArchitectureMap,
    ContractExpectation,
    InitResult,
    RepoAnalysis,
    RepoRelationship,
    RepoSummary,
)

_logger = logging.getLogger(__name__)

_MIN_CONFIDENCE = 0.3
_MAX_CANDIDATES_PER_CALL = 40


def run_init(
    *,
    clients: Sequence[LLMClient],
    repo_urls: list[str],
    workspace: Path,
    ref_policy: str = "develop_or_main",
    skip_snapshot: bool = False,
    overrides_path: Path | None = None,
    orchestrator: LLMClient | None = None,
) -> InitResult:
    """Run the full init pipeline.

    Args:
        clients: One or more LLM clients. Multiple = multi-model consensus.
        repo_urls: Git repo URLs or org/repo shorthand.
        workspace: Root directory for cloning repos.
        ref_policy: Branch resolution policy.
        skip_snapshot: Skip cloning, assume repos already present.
        overrides_path: Path to .repo-drift-overrides.json (optional).
        orchestrator: Optional orchestrator client for final synthesis.

    Returns:
        InitResult with analyses, architecture map, config, and markdown.
    """
    if not clients:
        msg = "at least one LLM client is required"
        raise ValueError(msg)
    if not repo_urls:
        msg = "at least one repo URL is required"
        raise ValueError(msg)

    repos = _build_repo_configs(repo_urls, ref_policy)

    model_names = ", ".join(c.model for c in clients)

    # ── Phase 1: Snapshot ────────────────────────────────────────
    _logger.info("Phase 1/5: Snapshot (%d repos)", len(repos))
    if skip_snapshot:
        snapshots = {
            r.id: SnapshotResult(
                repo_id=r.id,
                branch="main",
                commit="local",
                path=str(
                    Path(r.snapshot_path).resolve()
                    if Path(r.snapshot_path).is_absolute()
                    else (workspace / r.snapshot_path)
                ),
            )
            for r in repos
        }
    else:
        snapshots = _phase_snapshot(repos, workspace)

    # ── Phase 2: Analyze ─────────────────────────────────────────
    _logger.info("Phase 2/5: Analyze (deep repo scan, models: %s)", model_names)
    analyses = _phase_analyze(clients, repos, snapshots, workspace)

    # ── Phase 3: Map ─────────────────────────────────────────────
    _logger.info("Phase 3/5: Map (architecture mapping, models: %s)", model_names)
    architecture = _phase_map(clients, analyses)

    # ── Phase 4: Discover ────────────────────────────────────────
    _logger.info("Phase 4/5: Discover (contract file scanning, models: %s)", model_names)
    catalogs, pairs = _phase_discover_and_generate(clients, repos, snapshots, workspace)

    # ── Phase 5: Generate ────────────────────────────────────────
    _logger.info("Phase 5/5: Generate (config + markdown)")
    config = _build_config(repos, catalogs, pairs, architecture)
    _logger.info("  Built config with %d checks", len(config.get("checks", [])))

    # Apply overrides if provided
    if overrides_path:
        overrides = load_overrides(overrides_path)
        if overrides:
            _logger.info("applying overrides from %s", overrides_path)
            config = merge_config_with_overrides(config, overrides)

    # ── Orchestrator synthesis (optional) ────────────────────────
    if orchestrator is not None:
        from repo_drift.orchestrator import synthesize_init

        _logger.info("Running orchestrator synthesis ...")
        config = synthesize_init(
            orchestrator=orchestrator,
            architecture_dict=architecture.to_dict(),
            config=config,
        )

    # Build result and render markdown
    all_clients_for_usage: list[LLMClient] = list(clients)
    if orchestrator is not None:
        all_clients_for_usage.append(orchestrator)
    result = InitResult(
        analyses=analyses,
        architecture=architecture,
        config=config,
        markdown="",  # filled below
        token_usage=_aggregate_token_usage(all_clients_for_usage),
    )
    result.markdown = render_architecture_md(result)

    return result


def _phase_snapshot(
    repos: list[RepoConfig],
    workspace: Path,
) -> dict[str, SnapshotResult]:
    """Phase 1: Clone/fetch all repos."""
    snapshots: dict[str, SnapshotResult] = {}
    for i, repo in enumerate(repos, 1):
        _logger.info("  [%d/%d] Snapshotting %s ...", i, len(repos), repo.id)
        snap = ensure_snapshot(repo, workspace)
        _logger.info(
            "  [%d/%d] %s -> branch=%s commit=%s", i, len(repos), repo.id, snap.branch, snap.commit
        )
        snapshots[repo.id] = snap
    return snapshots


def _phase_analyze(
    clients: Sequence[LLMClient],
    repos: list[RepoConfig],
    snapshots: dict[str, SnapshotResult],
    workspace: Path,
) -> list[RepoAnalysis]:
    """Phase 2: Deep analysis of each repo (file scan + LLM enhancement)."""
    use_consensus = len(clients) > 1
    analyses: list[RepoAnalysis] = []

    for i, repo in enumerate(repos, 1):
        snap = snapshots[repo.id]
        repo_dir = Path(snap.path).resolve()

        _logger.info("  [%d/%d] Analyzing %s (file scan) ...", i, len(repos), repo.id)
        # File-based analysis (no LLM)
        analysis = analyze_repo(
            repo_id=repo.id,
            repo_url=repo.url,
            branch=snap.branch,
            snapshot_path=repo.snapshot_path,
            repo_dir=repo_dir,
        )

        # LLM-enhanced analysis
        if use_consensus:
            _logger.info(
                "  [%d/%d] Enhancing %s with %d models (consensus) ...",
                i,
                len(repos),
                repo.id,
                len(clients),
            )
            _enhance_analysis_consensus(clients, analysis)
        else:
            _logger.info(
                "  [%d/%d] Enhancing %s with %s ...",
                i,
                len(repos),
                repo.id,
                clients[0].model,
            )
            _enhance_analysis_single(clients[0], analysis)

        analyses.append(analysis)

    return analyses


def _enhance_analysis_single(
    client: LLMClient,
    analysis: RepoAnalysis,
) -> None:
    """Enhance a repo analysis with a single LLM model."""
    analysis_dict = analysis.to_dict()
    analysis_dict["manifest_contents"] = analysis.manifest_contents
    analysis_dict["entry_point_snippets"] = analysis.entry_point_snippets

    system, user = format_analyze_prompt(analysis_dict)

    try:
        response = client.complete(system, user)
        data = response.json()
        _apply_llm_analysis(analysis, data)
    except (RuntimeError, ValueError, KeyError):
        _logger.warning(
            "LLM analysis failed for %s, using file-based analysis only",
            analysis.repo_id,
            exc_info=True,
        )


def _enhance_analysis_consensus(
    clients: Sequence[LLMClient],
    analysis: RepoAnalysis,
) -> None:
    """Enhance a repo analysis with multi-model consensus."""
    analysis_dict = analysis.to_dict()
    analysis_dict["manifest_contents"] = analysis.manifest_contents
    analysis_dict["entry_point_snippets"] = analysis.entry_point_snippets

    system, user = format_analyze_prompt(analysis_dict)
    results: dict[str, dict[str, Any]] = {}

    for client in clients:
        try:
            _logger.info("    model %s: calling LLM for %s ...", client.model, analysis.repo_id)
            response = client.complete(system, user)
            data = response.json()
            results[response.model] = data
            _logger.info("    model %s: done", client.model)
        except (RuntimeError, ValueError, KeyError):
            _logger.warning(
                "LLM analysis failed for %s with model %s",
                analysis.repo_id,
                client.model,
                exc_info=True,
            )

    if not results:
        return

    if len(results) == 1:
        _apply_llm_analysis(analysis, next(iter(results.values())))
        return

    # Merge: majority vote on service_type, union on tech_stack/contracts
    _logger.info("    merging %d model results for %s", len(results), analysis.repo_id)
    merged = _merge_analyses(results)
    _apply_llm_analysis(analysis, merged)


def _merge_analyses(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Merge multiple LLM analysis results via majority vote and union."""
    # Majority vote on service_type
    type_counts: dict[str, int] = {}
    for data in results.values():
        st = data.get("service_type", "unknown")
        type_counts[st] = type_counts.get(st, 0) + 1
    service_type = max(type_counts, key=lambda k: type_counts[k])

    # Union tech_stack
    tech: set[str] = set()
    for data in results.values():
        tech.update(data.get("tech_stack", []))

    # Union owns/consumes contracts
    owns: set[str] = set()
    consumes: set[str] = set()
    for data in results.values():
        owns.update(data.get("owns_contracts", []))
        consumes.update(data.get("consumes_contracts", []))

    # Use the richest endpoint list
    best_endpoints: list[dict[str, str]] = []
    for data in results.values():
        eps = data.get("endpoints", [])
        if len(eps) > len(best_endpoints):
            best_endpoints = eps

    # Use the richest infra list
    best_infra: list[dict[str, str]] = []
    for data in results.values():
        infra = data.get("infra_dependencies", [])
        if len(infra) > len(best_infra):
            best_infra = infra

    # Take summary from first model (they should be similar)
    summary = ""
    for data in results.values():
        summary = data.get("summary", "")
        if summary:
            break

    # Union risk areas
    risk_descs: set[str] = set()
    risk_areas: list[dict[str, str]] = []
    for data in results.values():
        for risk in data.get("risk_areas", []):
            desc = risk.get("description", "")
            if desc and desc not in risk_descs:
                risk_descs.add(desc)
                risk_areas.append(risk)

    return {
        "summary": summary,
        "service_type": service_type,
        "tech_stack": sorted(tech),
        "owns_contracts": sorted(owns),
        "consumes_contracts": sorted(consumes),
        "endpoints": best_endpoints,
        "infra_dependencies": best_infra,
        "risk_areas": risk_areas,
    }


def _apply_llm_analysis(analysis: RepoAnalysis, data: dict[str, Any]) -> None:
    """Apply LLM analysis results back to the RepoAnalysis object."""
    if data.get("summary"):
        analysis.readme_summary = data["summary"]
    if data.get("service_type"):
        analysis.service_type = data["service_type"]
    if "tech_stack" in data:
        analysis.frameworks = data["tech_stack"]
    if "owns_contracts" in data:
        for domain in data["owns_contracts"]:
            if not any(c.domain == domain for c in analysis.contracts):
                from .types import DetectedContract

                analysis.contracts.append(
                    DetectedContract(path="", file_type="", domain=domain, role="source")
                )
    if "consumes_contracts" in data:
        for domain in data["consumes_contracts"]:
            if not any(c.domain == domain for c in analysis.contracts):
                from .types import DetectedContract

                analysis.contracts.append(
                    DetectedContract(path="", file_type="", domain=domain, role="consumer")
                )
    if "endpoints" in data:
        from .types import DetectedEndpoint

        for ep in data["endpoints"]:
            analysis.endpoints.append(
                DetectedEndpoint(
                    method=ep.get("method", ""),
                    path=ep.get("path", ""),
                    description=ep.get("description", ""),
                )
            )


def _phase_map(
    clients: Sequence[LLMClient],
    analyses: list[RepoAnalysis],
) -> ArchitectureMap:
    """Phase 3: Build cross-repo architecture map via LLM."""
    # Prepare analyses for the prompt (include LLM-enhanced data)
    analyses_dicts = [a.to_dict() for a in analyses]

    if len(clients) > 1:
        return _phase_map_consensus(clients, analyses_dicts)
    return _phase_map_single(clients[0], analyses_dicts)


def _phase_map_single(
    client: LLMClient,
    analyses: list[dict[str, Any]],
) -> ArchitectureMap:
    """Map architecture with a single model."""
    _logger.info("  Mapping with %s ...", client.model)
    system, user = format_map_prompt(analyses, len(analyses))

    try:
        response = client.complete(system, user)
        data = response.json()
        return _parse_architecture_map(data)
    except (RuntimeError, ValueError, KeyError):
        _logger.warning("LLM mapping failed, returning empty architecture", exc_info=True)
        return ArchitectureMap()


def _phase_map_consensus(
    clients: Sequence[LLMClient],
    analyses: list[dict[str, Any]],
) -> ArchitectureMap:
    """Map architecture with multi-model consensus."""
    system, user = format_map_prompt(analyses, len(analyses))
    results: dict[str, dict[str, Any]] = {}

    for client in clients:
        try:
            _logger.info("  model %s: mapping architecture ...", client.model)
            response = client.complete(system, user)
            data = response.json()
            results[response.model] = data
            _logger.info("  model %s: done", client.model)
        except (RuntimeError, ValueError, KeyError):
            _logger.warning(
                "LLM mapping failed with model %s",
                client.model,
                exc_info=True,
            )

    if not results:
        return ArchitectureMap()

    if len(results) == 1:
        return _parse_architecture_map(next(iter(results.values())))

    _logger.info("  Merging %d model results ...", len(results))
    return _merge_architecture_maps(results)


def _coerce_notes(raw: list[Any]) -> list[str]:
    """Coerce a list of notes to strings.

    Some models return notes as dicts instead of plain strings.
    Convert them so they are always ``list[str]``.
    """
    out: list[str] = []
    for note in raw:
        if isinstance(note, dict):
            out.append(json.dumps(note, sort_keys=True))
        else:
            out.append(str(note))
    return out


def _parse_architecture_map(data: dict[str, Any]) -> ArchitectureMap:
    """Parse LLM response into ArchitectureMap."""
    arch = ArchitectureMap()

    for repo in data.get("repos", []):
        arch.repos.append(
            RepoSummary(
                repo_id=repo.get("repo_id") or "",
                summary=repo.get("summary") or "",
                tech_stack=repo.get("tech_stack") or [],
                service_type=repo.get("service_type") or "",
                owns_contracts=repo.get("owns_contracts") or [],
                consumes_contracts=repo.get("consumes_contracts") or [],
            )
        )

    for rel in data.get("relationships", []):
        arch.relationships.append(
            RepoRelationship(
                from_repo=rel.get("from_repo") or "",
                to_repo=rel.get("to_repo") or "",
                rel_type=rel.get("type") or "unknown",
                contracts=rel.get("contracts") or [],
                description=rel.get("description") or "",
            )
        )

    for ce in data.get("contract_expectations", []):
        arch.contract_expectations.append(
            ContractExpectation(
                domain=ce.get("domain") or "",
                contract_type=ce.get("type") or "",
                owner_repo=ce.get("owner") or "",
                consumer_repos=ce.get("consumers") or [],
                risk=ce.get("risk") or "medium",
                rationale=ce.get("rationale") or "",
            )
        )

    arch.notes = _coerce_notes(data.get("notes", []))

    return arch


def _merge_architecture_maps(
    results: dict[str, dict[str, Any]],
) -> ArchitectureMap:
    """Merge architecture maps from multiple models."""
    merged = ArchitectureMap()

    # Merge repos: union by repo_id, majority vote on fields
    repo_data: dict[str, list[tuple[str, dict[str, Any]]]] = {}
    for model, data in results.items():
        for repo in data.get("repos", []):
            rid = repo.get("repo_id", "")
            if rid:
                repo_data.setdefault(rid, []).append((model, repo))

    for rid, entries in repo_data.items():
        # Take fields from majority or first
        best = entries[0][1]
        agreed = [m for m, _ in entries]
        tech: set[str] = set()
        owns: set[str] = set()
        consumes: set[str] = set()
        for _, repo in entries:
            tech.update(repo.get("tech_stack") or [])
            owns.update(repo.get("owns_contracts") or [])
            consumes.update(repo.get("consumes_contracts") or [])
        merged.repos.append(
            RepoSummary(
                repo_id=rid,
                summary=best.get("summary") or "",
                tech_stack=sorted(tech),
                service_type=best.get("service_type") or "",
                owns_contracts=sorted(owns),
                consumes_contracts=sorted(consumes),
                agreement_count=len(entries),
                agreed_models=agreed,
            )
        )

    # Merge relationships: union by (from, to, type), track agreement
    rel_key_map: dict[tuple[str, str, str], list[tuple[str, dict[str, Any]]]] = {}
    for model, data in results.items():
        for rel in data.get("relationships", []):
            key = (
                rel.get("from_repo") or "",
                rel.get("to_repo") or "",
                rel.get("type") or "",
            )
            rel_key_map.setdefault(key, []).append((model, rel))

    for key, entries in rel_key_map.items():
        best = entries[0][1]
        agreed = [m for m, _ in entries]
        contracts: set[str] = set()
        for _, rel in entries:
            contracts.update(rel.get("contracts") or [])
        merged.relationships.append(
            RepoRelationship(
                from_repo=key[0],
                to_repo=key[1],
                rel_type=key[2],
                contracts=sorted(contracts),
                description=best.get("description") or "",
                agreement_count=len(entries),
                agreed_models=agreed,
            )
        )

    # Merge contract expectations: union by domain, track agreement
    ce_map: dict[str, list[tuple[str, dict[str, Any]]]] = {}
    for model, data in results.items():
        for ce in data.get("contract_expectations", []):
            domain = ce.get("domain", "")
            if domain:
                ce_map.setdefault(domain, []).append((model, ce))

    for domain, entries in ce_map.items():
        best = entries[0][1]
        agreed = [m for m, _ in entries]
        consumers: set[str] = set()
        for _, ce in entries:
            consumers.update(ce.get("consumers") or [])
        # Use highest risk from any model
        risk_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        highest_risk = "low"
        for _, ce in entries:
            r = ce.get("risk", "medium")
            if risk_order.get(r, 99) < risk_order.get(highest_risk, 99):
                highest_risk = r
        merged.contract_expectations.append(
            ContractExpectation(
                domain=domain,
                contract_type=best.get("type") or "",
                owner_repo=best.get("owner") or "",
                consumer_repos=sorted(consumers),
                risk=highest_risk or "medium",
                rationale=best.get("rationale") or "",
                agreement_count=len(entries),
                agreed_models=agreed,
            )
        )

    # Union notes
    seen_notes: set[str] = set()
    for data in results.values():
        for note in _coerce_notes(data.get("notes", [])):
            if note not in seen_notes:
                seen_notes.add(note)
                merged.notes.append(note)

    return merged


def _phase_discover_and_generate(
    clients: Sequence[LLMClient],
    repos: list[RepoConfig],
    snapshots: dict[str, SnapshotResult],
    workspace: Path,
) -> tuple[list[RepoCatalog], list[ContractPair]]:
    """Phase 4: Run the existing discover pipeline (scan + classify + generate)."""
    use_consensus = len(clients) > 1

    # Phase 4a: Discover contracts per repo
    if use_consensus:
        catalogs = _discover_consensus(clients, repos, snapshots, workspace)
    else:
        catalogs = _discover_single(clients[0], repos, snapshots, workspace)

    # Phase 4b: Generate config from catalogs
    _logger.info("  Generating config from %d catalogs ...", len(catalogs))
    if use_consensus:
        _, pairs, _ = _generate_consensus(clients, catalogs, repos)
    else:
        _, pairs, _ = _generate_single(clients[0], catalogs, repos)

    return catalogs, pairs


def _discover_single(
    client: LLMClient,
    repos: list[RepoConfig],
    snapshots: dict[str, SnapshotResult],
    workspace: Path,
) -> list[RepoCatalog]:
    """Discover contracts with a single model."""
    catalogs: list[RepoCatalog] = []
    for i, repo in enumerate(repos, 1):
        snap = snapshots[repo.id]
        repo_dir = Path(snap.path).resolve()
        _logger.info(
            "  [%d/%d] Discovering contracts in %s with %s ...",
            i,
            len(repos),
            repo.id,
            client.model,
        )
        catalog = _discover_repo(client, repo, snap, repo_dir)
        _logger.info(
            "  [%d/%d] %s: found %d contracts", i, len(repos), repo.id, len(catalog.contracts)
        )
        catalogs.append(catalog)
    return catalogs


def _discover_consensus(
    clients: Sequence[LLMClient],
    repos: list[RepoConfig],
    snapshots: dict[str, SnapshotResult],
    workspace: Path,
) -> list[RepoCatalog]:
    """Discover contracts with multi-model consensus."""
    catalogs: list[RepoCatalog] = []
    for i, repo in enumerate(repos, 1):
        snap = snapshots[repo.id]
        repo_dir = Path(snap.path).resolve()

        per_model: dict[str, RepoCatalog] = {}
        for client in clients:
            _logger.info(
                "  [%d/%d] Discovering contracts in %s with %s ...",
                i,
                len(repos),
                repo.id,
                client.model,
            )
            cat = _discover_repo(client, repo, snap, repo_dir)
            _logger.info(
                "  [%d/%d] %s (%s): found %d contracts",
                i,
                len(repos),
                repo.id,
                client.model,
                len(cat.contracts),
            )
            per_model[client.model] = cat

        _logger.info(
            "  [%d/%d] Merging %d model results for %s ...", i, len(repos), len(per_model), repo.id
        )
        merged = merge_catalogs(per_model)
        catalogs.append(merged)
    return catalogs


def _discover_repo(
    client: LLMClient,
    repo: RepoConfig,
    snap: SnapshotResult,
    repo_dir: Path,
) -> RepoCatalog:
    """Discover contracts in a single repo with a single model."""
    from repo_drift.discover.catalog import ContractEntry

    catalog = RepoCatalog(
        repo_id=repo.id,
        repo_url=repo.url,
        branch=snap.branch,
        snapshot_path=str(repo_dir),
    )

    candidates = scan_repo_for_candidates(repo_dir)
    if not candidates:
        return catalog

    tree = build_file_tree(repo_dir, candidates)
    truncated = candidates[:_MAX_CANDIDATES_PER_CALL]
    content_parts: list[str] = []
    for cand in truncated:
        rel = str(cand.relative_to(repo_dir))
        preview = read_candidate_preview(cand)
        if preview:
            content_parts.append(f"### {rel}\n```\n{preview}\n```")
    file_contents = "\n\n".join(content_parts)

    system, user = format_discover_prompt(repo.id, repo.url, snap.branch, tree, file_contents)

    try:
        response = client.complete(system, user)
        data = response.json()
        for entry_data in data.get("contracts", []):
            confidence = entry_data.get("confidence", 0.0)
            if confidence < _MIN_CONFIDENCE:
                continue
            catalog.contracts.append(
                ContractEntry(
                    path=entry_data.get("path", ""),
                    role=entry_data.get("role", "unknown"),
                    file_type=entry_data.get("file_type", "other"),
                    domain=entry_data.get("domain", ""),
                    confidence=confidence,
                    reasoning=entry_data.get("reasoning", ""),
                )
            )
    except (RuntimeError, ValueError, KeyError):
        _logger.warning("discover failed for %s, skipping", repo.id, exc_info=True)

    return catalog


def _generate_single(
    client: LLMClient,
    catalogs: list[RepoCatalog],
    repos: list[RepoConfig],
) -> tuple[dict[str, Any], list[ContractPair], list[str]]:
    """Generate config from catalogs with a single model."""
    _logger.info("  Generating config with %s ...", client.model)
    catalogs_json = _catalogs_to_json(catalogs)
    system, user = format_generate_prompt(catalogs_json, len(repos))

    try:
        response = client.complete(system, user)
        data = response.json()
        config = data.get("config", {})
        notes = _coerce_notes(data.get("notes", []))
        pairs = [
            ContractPair(
                domain=p.get("domain", ""),
                source_repo=p.get("source_repo", ""),
                source_path=p.get("source_path", ""),
                consumer_repo=p.get("consumer_repo", ""),
                consumer_path=p.get("consumer_path", ""),
            )
            for p in data.get("pairs", [])
        ]
        return config, pairs, notes
    except (RuntimeError, ValueError, KeyError):
        _logger.warning("generate failed, returning empty config", exc_info=True)
        return {}, [], []


def _generate_consensus(
    clients: Sequence[LLMClient],
    catalogs: list[RepoCatalog],
    repos: list[RepoConfig],
) -> tuple[dict[str, Any], list[ContractPair], list[str]]:
    """Generate config with multi-model consensus."""
    catalogs_json = _catalogs_to_json(catalogs)
    system, user = format_generate_prompt(catalogs_json, len(repos))

    configs_per_model: dict[str, dict[str, Any]] = {}
    pairs_per_model: dict[str, list[ContractPair]] = {}
    all_notes: list[str] = []

    for client in clients:
        try:
            _logger.info("  model %s: generating config ...", client.model)
            response = client.complete(system, user)
            data = response.json()
            _logger.info("  model %s: done", client.model)
            configs_per_model[response.model] = data.get("config", {})
            pairs_per_model[response.model] = [
                ContractPair(
                    domain=p.get("domain", ""),
                    source_repo=p.get("source_repo", ""),
                    source_path=p.get("source_path", ""),
                    consumer_repo=p.get("consumer_repo", ""),
                    consumer_path=p.get("consumer_path", ""),
                )
                for p in data.get("pairs", [])
            ]
            for note in _coerce_notes(data.get("notes", [])):
                if note not in all_notes:
                    all_notes.append(note)
        except (RuntimeError, ValueError, KeyError):
            _logger.warning("generate failed with model %s", client.model, exc_info=True)

    if not configs_per_model:
        return {}, [], all_notes

    config = merge_configs(configs_per_model)
    pairs = merge_pairs(pairs_per_model) if pairs_per_model else []

    return config, pairs, all_notes


def _build_config(
    repos: list[RepoConfig],
    catalogs: list[RepoCatalog],
    pairs: list[ContractPair],
    architecture: ArchitectureMap,
) -> dict[str, Any]:
    """Build the final config JSON from all gathered data."""
    config: dict[str, Any] = {"version": 1}

    # Repos
    config["repos"] = [
        {
            "id": r.id,
            "url": r.url,
            "ref_policy": r.ref_policy,
            "snapshot_path": r.snapshot_path,
        }
        for r in repos
    ]

    # Build repo_id -> snapshot_path lookup for correct path prefixing.
    # Local repos have absolute snapshot_path; remote repos use "repos/<id>".
    snap_lookup: dict[str, str] = {r.id: r.snapshot_path for r in repos}

    def _check_path(repo_id: str, file_path: str) -> str:
        """Build a check path using the repo's snapshot_path prefix."""
        snap = snap_lookup.get(repo_id, f"repos/{repo_id}")
        if snap.startswith("/"):
            # Absolute path (local repo) — join directly.
            return f"{snap}/{file_path}"
        return f"{snap}/{file_path}"

    # Checks from pairs
    checks: list[dict[str, Any]] = []
    for pair in pairs:
        # file_pair_hash check for every pair
        checks.append(
            {
                "id": f"{pair.domain}-hash-sync",
                "type": "file_pair_hash",
                "severity": _severity_for_domain(pair.domain, architecture),
                "params": {
                    "left": _check_path(pair.source_repo, pair.source_path),
                    "right": _check_path(pair.consumer_repo, pair.consumer_path),
                },
            }
        )

        # json_schema_compat for schema types
        source_catalog = next((c for c in catalogs if c.repo_id == pair.source_repo), None)
        if source_catalog:
            entry = next(
                (e for e in source_catalog.contracts if e.path == pair.source_path),
                None,
            )
            if entry and entry.file_type in ("json-schema", "openapi"):
                checks.append(
                    {
                        "id": f"{pair.domain}-schema-compat",
                        "type": "json_schema_compat",
                        "severity": "medium",
                        "params": {
                            "left": _check_path(pair.source_repo, pair.source_path),
                            "right": _check_path(pair.consumer_repo, pair.consumer_path),
                        },
                    }
                )

    config["checks"] = checks

    # Policy: fail on high/critical failures by default
    config["policy"] = {
        "fail_on": [
            {"severity": "critical", "status": "fail"},
            {"severity": "high", "status": "fail"},
        ]
    }

    return config


def _severity_for_domain(domain: str, architecture: ArchitectureMap) -> str:
    """Determine severity for a contract based on architecture risk assessment."""
    for ce in architecture.contract_expectations:
        if ce.domain == domain:
            return ce.risk
    return "high"  # default


def _aggregate_token_usage(clients: Sequence[LLMClient]) -> dict[str, int]:
    """Sum token usage across all clients."""
    totals: dict[str, int] = {}
    for client in clients:
        for key, val in client.total_tokens.items():
            totals[key] = totals.get(key, 0) + val
    return totals
