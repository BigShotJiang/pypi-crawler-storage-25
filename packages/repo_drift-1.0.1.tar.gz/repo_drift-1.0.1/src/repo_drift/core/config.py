from __future__ import annotations

import json
from pathlib import Path

from .types import CheckConfig, PolicyRule, ProjectConfig, RepoConfig

_ALLOWED_REPO_POLICIES = {"develop_or_main", "develop", "main", "custom"}
_ALLOWED_CHECK_TYPES = {
    "file_pair_hash",
    "json_schema_compat",
    "json_semantic_equal",
    "openapi_compat",
    "yaml_semantic_equal",
}
_ALLOWED_SEVERITIES = {"low", "medium", "high", "critical"}
_ALLOWED_STATUSES = {"fail", "warn"}


class ConfigError(ValueError):
    pass


def _expect_type(value: object, expected: type, message: str) -> None:
    if not isinstance(value, expected):
        raise ConfigError(message)


def load_project_config(path: Path) -> ProjectConfig:
    try:
        payload = json.loads(path.read_text())
    except FileNotFoundError as exc:
        raise ConfigError(f"Config not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ConfigError(f"Invalid JSON in config {path}: {exc}") from exc

    _expect_type(payload, dict, "Config root must be an object")

    version = payload.get("version")
    repos = payload.get("repos")
    checks = payload.get("checks")

    if not isinstance(version, int) or version < 1:
        raise ConfigError("`version` must be an integer >= 1")
    if not isinstance(repos, list) or not repos:
        raise ConfigError("`repos` must be a non-empty array")
    if not isinstance(checks, list) or not checks:
        raise ConfigError("`checks` must be a non-empty array")

    parsed_repos: list[RepoConfig] = []
    for idx, repo in enumerate(repos):
        _expect_type(repo, dict, f"repos[{idx}] must be an object")
        repo_id = repo.get("id")
        url = repo.get("url")
        ref_policy = repo.get("ref_policy")
        snapshot_path = repo.get("snapshot_path")
        custom_ref = repo.get("custom_ref")

        if not isinstance(repo_id, str) or not repo_id.strip():
            raise ConfigError(f"repos[{idx}].id must be a non-empty string")
        if not isinstance(url, str) or not url.strip():
            raise ConfigError(f"repos[{idx}].url must be a non-empty string")
        if ref_policy not in _ALLOWED_REPO_POLICIES:
            raise ConfigError(f"repos[{idx}].ref_policy must be one of {_ALLOWED_REPO_POLICIES}")
        if not isinstance(snapshot_path, str) or not snapshot_path.strip():
            raise ConfigError(f"repos[{idx}].snapshot_path must be a non-empty string")
        if ref_policy == "custom" and (not isinstance(custom_ref, str) or not custom_ref.strip()):
            raise ConfigError(f"repos[{idx}] with custom ref_policy requires custom_ref")

        parsed_repos.append(
            RepoConfig(
                id=repo_id.strip(),
                url=url.strip(),
                ref_policy=ref_policy,
                snapshot_path=snapshot_path.strip(),
                custom_ref=custom_ref.strip() if isinstance(custom_ref, str) else None,
            )
        )

    parsed_checks: list[CheckConfig] = []
    for idx, check in enumerate(checks):
        _expect_type(check, dict, f"checks[{idx}] must be an object")
        check_id = check.get("id")
        check_type = check.get("type")
        severity = check.get("severity")
        params = check.get("params")

        if not isinstance(check_id, str) or not check_id.strip():
            raise ConfigError(f"checks[{idx}].id must be a non-empty string")
        if check_type not in _ALLOWED_CHECK_TYPES:
            raise ConfigError(f"checks[{idx}].type must be one of {_ALLOWED_CHECK_TYPES}")
        if severity not in _ALLOWED_SEVERITIES:
            raise ConfigError(f"checks[{idx}].severity must be one of {_ALLOWED_SEVERITIES}")
        if not isinstance(params, dict):
            raise ConfigError(f"checks[{idx}].params must be an object")

        parsed_checks.append(
            CheckConfig(
                id=check_id.strip(),
                type=check_type,
                severity=severity,
                params=params,
            )
        )

    fail_on: list[PolicyRule] = []
    policy = payload.get("policy", {})
    if policy is not None:
        _expect_type(policy, dict, "policy must be an object")
        rules = policy.get("fail_on", [])
        if rules is not None:
            _expect_type(rules, list, "policy.fail_on must be an array")
            for idx, rule in enumerate(rules):
                _expect_type(rule, dict, f"policy.fail_on[{idx}] must be an object")
                severity = rule.get("severity")
                status = rule.get("status")
                if severity not in _ALLOWED_SEVERITIES:
                    raise ConfigError(
                        f"policy.fail_on[{idx}].severity must be one of {_ALLOWED_SEVERITIES}"
                    )
                if status not in _ALLOWED_STATUSES:
                    raise ConfigError(
                        f"policy.fail_on[{idx}].status must be one of {_ALLOWED_STATUSES}"
                    )
                fail_on.append(PolicyRule(severity=severity, status=status))

    return ProjectConfig(
        version=version,
        repos=parsed_repos,
        checks=parsed_checks,
        fail_on=fail_on,
    )
