from __future__ import annotations

from pathlib import Path

from repo_drift.checks import (
    run_file_pair_hash_check,
    run_json_schema_compat_check,
    run_json_semantic_equal_check,
    run_openapi_compat_check,
    run_yaml_semantic_equal_check,
)
from repo_drift.core.types import CheckConfig, CheckResult

_DISPATCH = {
    "file_pair_hash": run_file_pair_hash_check,
    "json_schema_compat": run_json_schema_compat_check,
    "json_semantic_equal": run_json_semantic_equal_check,
    "openapi_compat": run_openapi_compat_check,
    "yaml_semantic_equal": run_yaml_semantic_equal_check,
}


def run_check(check: CheckConfig, root: Path) -> CheckResult:
    handler = _DISPATCH.get(check.type)
    if handler is not None:
        return handler(check, root)

    return CheckResult(
        check_id=check.id,
        check_type=check.type,
        status="error",
        severity=check.severity,
        summary=f"Unsupported check type: {check.type}",
        evidence=[],
    )


def run_checks(checks: list[CheckConfig], root: Path) -> list[CheckResult]:
    return [run_check(check, root) for check in checks]
