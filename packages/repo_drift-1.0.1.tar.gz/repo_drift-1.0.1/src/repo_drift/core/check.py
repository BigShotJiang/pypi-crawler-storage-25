"""PR impact assessment — ``check`` command logic.

Given a list of changed files (from a PR diff) and a repo-drift config,
determine which contracts are affected and whether the policy is violated.

This module is generic and config-driven — it works with any
``.repo-drift.json`` regardless of how it was generated.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any

from .types import CheckConfig, ProjectConfig, RepoConfig


@dataclass(slots=True)
class AffectedCheck:
    """A check from the config that is affected by a changed file."""

    check_id: str
    check_type: str
    severity: str
    matched_file: str
    matched_param: str  # "left" or "right"
    counterpart: str  # the other side of the contract pair

    def to_dict(self) -> dict[str, str]:
        return {
            "check_id": self.check_id,
            "check_type": self.check_type,
            "severity": self.severity,
            "matched_file": self.matched_file,
            "matched_param": self.matched_param,
            "counterpart": self.counterpart,
        }


@dataclass(slots=True)
class CheckVerdict:
    """Result of evaluating changed files against repo-drift config."""

    repo: str
    changed_files: list[str]
    affected: list[AffectedCheck]
    verdict: str  # "pass" or "fail"
    summary: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "repo": self.repo,
            "changed_files": self.changed_files,
            "affected": [a.to_dict() for a in self.affected],
            "verdict": self.verdict,
            "summary": self.summary,
        }


def _strip_prefix(path: str, prefix: str) -> str | None:
    """Strip a snapshot_path prefix from a check param path.

    Returns the relative portion after the prefix, or ``None`` if
    *path* doesn't start with *prefix*.

    Examples::

        _strip_prefix("/Users/x/acme-sdk/sdk/foo.json", "/Users/x/acme-sdk")
        #  -> "sdk/foo.json"
        _strip_prefix("repos/acme-sdk/sdk/foo.json", "repos/acme-sdk")
        #  -> "sdk/foo.json"
    """
    norm_path = PurePosixPath(path.replace("\\", "/"))
    norm_prefix = PurePosixPath(prefix.replace("\\", "/"))

    try:
        return str(norm_path.relative_to(norm_prefix))
    except ValueError:
        return None


def _find_repo_config(config: ProjectConfig, repo_id: str) -> RepoConfig | None:
    """Find the RepoConfig for a given repo ID."""
    for repo in config.repos:
        if repo.id == repo_id:
            return repo
    return None


def _resolve_repo_id(config: ProjectConfig, repo_id: str | None) -> str:
    """Resolve the repo ID to use.

    If *repo_id* is explicitly given, validate it exists in the config.
    If ``None``, auto-detect: use the only repo if there's exactly one,
    otherwise raise.
    """
    if repo_id is not None:
        if _find_repo_config(config, repo_id) is None:
            available = [r.id for r in config.repos]
            raise ValueError(
                f"Repo '{repo_id}' not found in config. Available: {', '.join(available)}"
            )
        return repo_id

    if len(config.repos) == 1:
        return config.repos[0].id

    available = [r.id for r in config.repos]
    raise ValueError(
        f"Multiple repos in config — specify --repo. Available: {', '.join(available)}"
    )


def evaluate_changed_files(
    config: ProjectConfig,
    repo_id: str | None,
    changed_files: list[str],
) -> CheckVerdict:
    """Evaluate a list of changed files against the repo-drift config.

    Parameters
    ----------
    config:
        The loaded project config (from ``.repo-drift.json``).
    repo_id:
        The ID of the repo where the PR is opened. If ``None``,
        auto-detected when the config has exactly one repo.
    changed_files:
        List of file paths relative to the repo root
        (e.g. from ``git diff --name-only``).

    Returns
    -------
    CheckVerdict with the list of affected checks and a pass/fail verdict.
    """
    resolved_id = _resolve_repo_id(config, repo_id)
    repo_cfg = _find_repo_config(config, resolved_id)

    affected: list[AffectedCheck] = []

    for check in config.checks:
        left_path = check.params.get("left", "")
        right_path = check.params.get("right", "")

        if not isinstance(left_path, str) or not isinstance(right_path, str):
            continue

        _match_check_against_files(
            check=check,
            repo_cfg=repo_cfg,
            changed_files=changed_files,
            affected=affected,
        )

    # Determine verdict based on policy rules.
    verdict = "pass"
    if affected:
        if config.fail_on:
            for item in affected:
                for rule in config.fail_on:
                    if item.severity == rule.severity and rule.status == "fail":
                        verdict = "fail"
                        break
                if verdict == "fail":
                    break
        else:
            # No explicit policy — any affected contract means fail.
            verdict = "fail"

    # Build summary.
    if not affected:
        summary = "No contract files affected by this change."
    else:
        unique_checks = {a.check_id for a in affected}
        severities = sorted({a.severity for a in affected}, key=_severity_order)
        top_sev = severities[-1] if severities else "unknown"
        summary = (
            f"{len(affected)} contract file(s) affected across "
            f"{len(unique_checks)} check(s). "
            f"Highest severity: {top_sev}."
        )

    return CheckVerdict(
        repo=resolved_id,
        changed_files=changed_files,
        affected=affected,
        verdict=verdict,
        summary=summary,
    )


def _severity_order(severity: str) -> int:
    """Return a numeric order for severity levels."""
    return {"low": 0, "medium": 1, "high": 2, "critical": 3}.get(severity, -1)


def _match_check_against_files(
    check: CheckConfig,
    repo_cfg: RepoConfig | None,
    changed_files: list[str],
    affected: list[AffectedCheck],
) -> None:
    """Check if any changed file matches the left or right path of a check.

    A file matches if, after stripping the repo's snapshot_path prefix
    from the check param, the relative path equals the changed file path.
    """
    left_path: str = check.params.get("left", "")
    right_path: str = check.params.get("right", "")

    if not left_path or not right_path:
        return

    for param_name, param_path, other_path in [
        ("left", left_path, right_path),
        ("right", right_path, left_path),
    ]:
        relative = None
        if repo_cfg:
            relative = _strip_prefix(param_path, repo_cfg.snapshot_path)

        if relative is None:
            continue

        # Normalize for comparison.
        relative_norm = relative.replace("\\", "/").strip("/")

        for changed in changed_files:
            changed_norm = changed.replace("\\", "/").strip("/")
            if changed_norm == relative_norm:
                affected.append(
                    AffectedCheck(
                        check_id=check.id,
                        check_type=check.type,
                        severity=check.severity,
                        matched_file=changed,
                        matched_param=param_name,
                        counterpart=other_path,
                    )
                )
