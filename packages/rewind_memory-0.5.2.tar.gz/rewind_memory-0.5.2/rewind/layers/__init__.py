"""Rewind memory layers — bio-inspired hierarchical retrieval.

Each layer mirrors a different aspect of biological memory:
- L0: Reflexive keyword matching (brainstem-level pattern detection)
- L1: System/core files (working memory — always loaded, always available)
- L2: Orchestrator (prefrontal cortex — coordinates and fuses all layers)
- L3: Knowledge graph (semantic/associative memory — entities and relationships)
- L4: Vector search (episodic memory — dense similarity over experience chunks)
"""

from rewind.layers.l0_fts import L0FullTextSearch
from rewind.layers.l1_system import L1SystemFiles
from rewind.layers.l2_orchestrator import L2Orchestrator
from rewind.layers.l3_graph_sqlite import L3GraphSQLite
from rewind.layers.l4_vector import L4Vector

__all__ = [
    "L0FullTextSearch",
    "L1SystemFiles",
    "L2Orchestrator",
    "L3GraphSQLite",
    "L4Vector",
]
