"""L1 System Files — core working-memory retrieval.

Bio-inspired analogy: **Working memory** (prefrontal buffer).
Always-loaded, always-available files that form the agent's immediate context.
Like the handful of items you hold in working memory at any moment — small in
number but instantly accessible and highest priority.
"""

import logging
import os
import time
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


def extract_relevant_snippet(
    content: str, keywords: List[str], max_chars: int = 400
) -> str:
    """Extract the most relevant snippet from *content* around *keywords*.

    Slides a window across the text, scores each position by keyword density,
    and returns the highest-scoring window trimmed to sentence boundaries.
    """
    content_lower = content.lower()
    best_pos = 0
    best_score = 0

    # Find position with highest keyword density
    for i in range(0, len(content), 100):
        window = content_lower[i : i + max_chars]
        score = sum(window.count(keyword) for keyword in keywords)
        if score > best_score:
            best_score = score
            best_pos = i

    # Extract snippet around best position
    start = max(0, best_pos - 50)
    end = min(len(content), best_pos + max_chars + 50)
    snippet = content[start:end].strip()

    # Clean up to sentence boundaries if possible
    if ". " in snippet:
        sentences = snippet.split(". ")
        # Keep middle sentences (most likely to be complete)
        if len(sentences) > 2:
            snippet = ". ".join(sentences[1:-1]) + "."

    return snippet


class L1SystemFiles:
    """Highest-priority retrieval from core memory files.

    Searches MEMORY.md, plans.md, SESSION-STATE.md, SOUL.md, USER.md,
    and today's/yesterday's daily notes using simple keyword matching.
    Results always score 1.0 — these are the agent's ground truth.
    """

    def __init__(
        self,
        workspace_path: str,
        core_files: Optional[List[str]] = None,
    ) -> None:
        """Initialise with workspace root and optional file list.

        Args:
            workspace_path: Absolute path to the workspace directory.
            core_files: Override list of relative file paths. Defaults to the
                standard set including today's and yesterday's daily notes.
        """
        self.workspace_path = workspace_path
        self._custom_core_files = core_files

    @property
    def core_files(self) -> List[str]:
        """Resolve the list of core files (includes dynamic daily-note paths)."""
        if self._custom_core_files is not None:
            return self._custom_core_files
        return [
            "MEMORY.md",
            "plans.md",
            "SESSION-STATE.md",
            "SOUL.md",
            "USER.md",
            f"memory/daily/{time.strftime('%Y-%m-%d')}.md",
            f"memory/daily/{time.strftime('%Y-%m-%d', time.localtime(time.time() - 86400))}.md",
        ]

    def search(
        self,
        query: str,
        limit: int = 6,
        namespace: Optional[str] = None,
    ) -> List[Dict]:
        """Search core memory files for keyword matches.

        Args:
            query: Natural-language query string.
            limit: Maximum results to return.
            namespace: If set, restrict to files whose path starts with this prefix.

        Returns:
            List of result dicts with keys: path, text, score, source, layer,
            keyword_hits, file_type.
        """
        files = self.core_files
        if namespace:
            files = [f for f in files if f.startswith(namespace)]

        results: List[Dict] = []
        query_lower = query.lower()
        keywords = [w for w in query_lower.split() if len(w) > 2]

        for file_path in files:
            try:
                full_path = os.path.join(self.workspace_path, file_path)
                if not os.path.exists(full_path):
                    continue

                with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                content_lower = content.lower()
                keyword_hits = sum(content_lower.count(kw) for kw in keywords)

                if keyword_hits > 0:
                    snippet = extract_relevant_snippet(content, keywords, 400)
                    results.append({
                        "path": file_path,
                        "text": snippet,
                        "score": 1.0,  # Highest priority — core memory
                        "source": "core_memory",
                        "layer": "L1",
                        "keyword_hits": keyword_hits,
                        "file_type": "core",
                    })
            except Exception as e:
                log.warning(f"Failed to read core file {file_path}: {e}")
                continue

        results.sort(key=lambda x: x["keyword_hits"], reverse=True)
        return results[:limit]
