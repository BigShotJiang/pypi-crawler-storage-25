"""Rewind — 7-layer bio-inspired memory architecture for AI agents."""

__version__ = "0.1.0"

from rewind.client import RewindClient

__all__ = ["RewindClient", "__version__"]
