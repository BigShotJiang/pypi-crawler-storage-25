"""Rewind integrations — drop-in memory for AI platforms."""
