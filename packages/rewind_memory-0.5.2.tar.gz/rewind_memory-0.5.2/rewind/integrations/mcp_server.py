#!/usr/bin/env python3
"""
Rewind MCP Server — Expose memory as MCP tools for Claude Code, Cursor, etc.

Uses RewindClient directly (in-process) — no separate API server needed.

Usage:
    # Claude Code — add to ~/.claude/settings.json:
    {
      "mcpServers": {
        "rewind": {
          "command": "rewind-mcp",
          "env": {
            "REWIND_WORKSPACE": "~/my-project"
          }
        }
      }
    }

This exposes 5 MCP tools:
    - memory_search: Search across all memory layers
    - memory_store: Store a new memory
    - memory_stats: Get memory system statistics
    - memory_health: Health check
    - graph_traverse: Multi-hop knowledge graph traversal
"""

import json
import os
import sys
import logging
from typing import Any, Dict, Optional

log = logging.getLogger(__name__)

# MCP protocol constants
JSONRPC_VERSION = "2.0"
MCP_PROTOCOL_VERSION = "2025-06-18"

# ── Client singleton ─────────────────────────────────────────────────────────

_client = None


def _get_client():
    """Lazy-init RewindClient."""
    global _client
    if _client is None:
        from rewind.client import RewindClient
        from rewind.config import default_config

        workspace = os.environ.get("REWIND_WORKSPACE", os.getcwd())
        db_path = os.environ.get("REWIND_DB", os.path.join(workspace, "rewind.db"))
        tier = os.environ.get("REWIND_TIER", "free")

        cfg = default_config(tier)
        cfg.workspace_path = os.path.expanduser(workspace)
        cfg.vector_db_path = os.path.expanduser(db_path)

        _client = RewindClient(cfg)
    return _client


# ── Tool Definitions ─────────────────────────────────────────────────────────

TOOLS = [
    {
        "name": "memory_search",
        "description": (
            "Search persistent memory across all layers (keyword, semantic, graph). "
            "Returns ranked results with source attribution. Use before answering "
            "questions about prior work, decisions, people, or context."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural language search query"},
                "limit": {"type": "integer", "description": "Max results (default: 10)", "default": 10},
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_store",
        "description": "Store text into memory. Auto-indexes into FTS, graph, and vector layers.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Text to store"},
                "path": {"type": "string", "description": "Optional virtual path/label"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "memory_stats",
        "description": "Get memory system statistics and health status.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "memory_health",
        "description": "Health check — returns layer status and tier info.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "graph_traverse",
        "description": (
            "Traverse the knowledge graph from a starting entity. "
            "Discovers related entities via co-occurrence edges."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "entity": {"type": "string", "description": "Starting entity name"},
                "hops": {"type": "integer", "description": "Hops (1-3, default: 2)", "default": 2},
            },
            "required": ["entity"],
        },
    },
]


# ── Tool Handlers ────────────────────────────────────────────────────────────

def handle_memory_search(args: Dict) -> str:
    client = _get_client()
    query = args.get("query", "")
    limit = args.get("limit", 10)

    results = client.search(query, limit=limit)

    if not results:
        return "No memories found."

    lines = []
    for i, r in enumerate(results, 1):
        score = f"{r.score:.2f}" if hasattr(r, 'score') else "?"
        layer = getattr(r, 'layer', '?')
        text = getattr(r, 'text', str(r))[:300].strip()
        path = getattr(r, 'path', '')
        source = f" ({path})" if path else ""
        lines.append(f"#{i} [{layer}] score={score}{source}\n  {text}")

    return "\n\n".join(lines)


def handle_memory_store(args: Dict) -> str:
    client = _get_client()
    content = args.get("content", "")
    args.get("path", "mcp-stored")

    if not content:
        return "Error: content is required"

    # Write to a temp file and ingest
    import tempfile
    with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False, prefix="rewind_") as f:
        f.write(content)
        tmp_path = f.name

    try:
        client.ingest(tmp_path)
        return f"Stored {len(content)} chars into memory."
    except Exception as e:
        return f"Error storing memory: {e}"
    finally:
        os.unlink(tmp_path)


def handle_memory_stats(args: Dict) -> str:
    client = _get_client()
    health = client.health()
    return json.dumps(health, indent=2, default=str)


def handle_memory_health(args: Dict) -> str:
    client = _get_client()
    health = client.health()

    lines = [
        f"Tier: {health.get('tier', '?')}",
        f"Healthy: {health.get('healthy', False)}",
    ]
    for name, status in health.get("layers", {}).items():
        s = status.get("status", "unknown")
        icon = "✅" if s == "ok" else "❌"
        lines.append(f"  {icon} {name}: {s}")

    return "\n".join(lines)


def handle_graph_traverse(args: Dict) -> str:
    client = _get_client()
    entity = args.get("entity", "")
    min(args.get("hops", 2), 3)

    if not entity:
        return "Error: entity is required"

    # Use L3 graph directly
    if "l3" not in client._layers:
        return "Graph layer not available"

    try:
        results = client._layers["l3"].search(entity, limit=20, entities=[entity])
        if isinstance(results, dict):
            results = results.get("results", [])

        if not results:
            return f"No graph connections found for '{entity}'"

        lines = []
        for r in results[:15]:
            if isinstance(r, dict):
                text = r.get("text", str(r))
            else:
                text = str(r)
            lines.append(f"  → {text}")

        return f"Graph connections for '{entity}':\n" + "\n".join(lines)
    except Exception as e:
        return f"Graph traversal error: {e}"


TOOL_HANDLERS = {
    "memory_search": handle_memory_search,
    "memory_store": handle_memory_store,
    "memory_stats": handle_memory_stats,
    "memory_health": handle_memory_health,
    "graph_traverse": handle_graph_traverse,
}


# ── MCP Protocol ─────────────────────────────────────────────────────────────

def _make_response(id: Any, result: Any) -> Dict:
    return {"jsonrpc": JSONRPC_VERSION, "id": id, "result": result}


def _make_error(id: Any, code: int, message: str) -> Dict:
    return {"jsonrpc": JSONRPC_VERSION, "id": id, "error": {"code": code, "message": message}}


def handle_request(request: Dict) -> Optional[Dict]:
    method = request.get("method", "")
    params = request.get("params", {})
    req_id = request.get("id")

    if method == "initialize":
        return _make_response(req_id, {
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "rewind", "version": "0.2.1"},
        })

    elif method == "notifications/initialized":
        return None  # no response for notifications

    elif method == "tools/list":
        return _make_response(req_id, {"tools": TOOLS})

    elif method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})

        handler = TOOL_HANDLERS.get(tool_name)
        if not handler:
            return _make_error(req_id, -32601, f"Unknown tool: {tool_name}")

        try:
            result_text = handler(tool_args)
            return _make_response(req_id, {
                "content": [{"type": "text", "text": result_text}],
                "isError": False,
            })
        except Exception as e:
            return _make_response(req_id, {
                "content": [{"type": "text", "text": f"Error: {e}"}],
                "isError": True,
            })

    elif method == "ping":
        return _make_response(req_id, {})

    else:
        return _make_error(req_id, -32601, f"Method not found: {method}")


def run_stdio():
    """Run MCP server over STDIO (JSON-RPC, line-delimited)."""
    logging.basicConfig(level=logging.WARNING, stream=sys.stderr)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            request = json.loads(line)
        except json.JSONDecodeError:
            continue

        response = handle_request(request)
        if response is not None:
            sys.stdout.write(json.dumps(response) + "\n")
            sys.stdout.flush()


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Rewind MCP Server")
    parser.add_argument("--workspace", default=os.environ.get("REWIND_WORKSPACE", os.getcwd()),
                        help="Workspace path (default: cwd)")
    parser.add_argument("--db", default=None, help="Database path")
    args = parser.parse_args()

    if args.workspace:
        os.environ["REWIND_WORKSPACE"] = args.workspace
    if args.db:
        os.environ["REWIND_DB"] = args.db

    run_stdio()


# Alias for discoverability
create_mcp_server = main

if __name__ == "__main__":
    main()
