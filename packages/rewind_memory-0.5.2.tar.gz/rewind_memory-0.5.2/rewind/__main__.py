"""Rewind CLI — memory stack for AI agents.

Usage:
    rewind ingest <path> [--tier free|pro|enterprise] [--db ./data/vector.db]
    rewind search <query> [--tier free|pro|enterprise] [--limit 10]
    rewind health [--tier free|pro|enterprise]
    rewind stats
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import sqlite3
import sys
from pathlib import Path



def cmd_remember(args: argparse.Namespace) -> None:
    """Store a freeform text note directly into memory."""
    import tempfile
    import os
    from rewind.config import default_config
    from rewind.ingest import IngestPipeline

    text = args.text
    if not text.strip():
        print("Error: text cannot be empty", file=sys.stderr)
        sys.exit(1)

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt", delete=False, prefix="rewind_note_"
    ) as fh:
        fh.write(text)
        tmp_path = fh.name

    try:
        pipeline = IngestPipeline(cfg)
        pipeline.ingest_file(tmp_path, source="note")
        pipeline.close()
    finally:
        os.unlink(tmp_path)

    preview = text[:50]
    suffix = "..." if len(text) > 50 else ""
    print(f'Stored: "{preview}{suffix}"')


def cmd_ingest(args: argparse.Namespace) -> None:
    """Ingest files into the memory stack."""
    from rewind.config import default_config
    from rewind.ingest import IngestPipeline
    from pathlib import Path

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    pipeline = IngestPipeline(cfg)

    path = Path(args.path)
    if path.is_dir():
        stats = pipeline.ingest_directory(str(path))
    elif path.is_file():
        stats = pipeline.ingest_file(str(path))
    else:
        print(f"Error: {args.path} not found", file=sys.stderr)
        sys.exit(1)

    pipeline.close()

    # Print summary
    print(f"Files:    {stats.get('files', 1)}")
    print(f"Chunks:   {stats.get('chunks', 0)}")
    print(f"Vectors:  {stats.get('vectors', 0)}")
    print(f"Entities: {stats.get('entities', 0)}")
    if "elapsed_seconds" in stats:
        print(f"Time:     {stats['elapsed_seconds']}s")
    if stats.get("errors"):
        print(f"Errors:   {stats['errors']}")


def cmd_search(args: argparse.Namespace) -> None:
    """Search the memory stack."""
    from rewind.client import RewindClient
    from rewind.config import default_config

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    client = RewindClient(cfg)
    results = client.search(args.query, limit=args.limit)
    client.close()

    if not results:
        print("No results found.")
        return

    if args.json:
        print(json.dumps([{
            "score": r.score, "layer": r.layer,
            "path": r.path, "text": r.text[:200],
        } for r in results], indent=2))
    else:
        for i, r in enumerate(results, 1):
            print(f"\n{'─' * 60}")
            print(f"  #{i}  score={r.score:.3f}  layer={r.layer}")
            if r.path:
                print(f"  path: {r.path}")
            print(f"  {r.text[:200]}")


def cmd_health(args: argparse.Namespace) -> None:
    """Health check."""
    from rewind.client import RewindClient
    from rewind.config import default_config

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    client = RewindClient(cfg)
    health = client.health()
    client.close()

    print(f"Tier:         {health['tier']}")
    print(f"Orchestrator: {'✅' if health['orchestrator'] else '❌'}")
    print(f"Pro plugin:   {'✅' if health.get('pro_installed') else '❌ (Free tier)'}")
    print(f"Healthy:      {'✅' if health['healthy'] else '❌'}")
    print()
    for name, status in health.get("layers", {}).items():
        s = status.get("status", "unknown")
        icon = "✅" if s == "ok" else "❌" if s == "error" else "⚠️"
        extra = ""
        if "nodes" in status:
            extra = f" ({status['nodes']} nodes, {status.get('edges', 0)} edges)"
        elif "total_chunks" in status:
            extra = f" ({status['total_chunks']} chunks)"
        elif "backend" in status:
            extra = f" ({status['backend']})"
        print(f"  {icon} {name}: {s}{extra}")


def cmd_doctor(args: argparse.Namespace) -> None:
    """Auto-diagnose and fix common issues with the memory stack."""
    import hashlib
    import sqlite3
    from pathlib import Path

    fixes = []
    warnings = []
    ok = []

    # ── Resolve paths ─────────────────────────────────────────────────────
    db_path = Path(
        args.db
        or os.environ.get("REWIND_MEMORY_DB", "")
        or str(Path.home() / ".rewind" / "memory" / "main.sqlite")
    )
    workspace = Path(
        getattr(args, "workspace", None)
        or os.environ.get("REWIND_WORKSPACE", "")
        or ""
    )
    if not workspace or not workspace.exists():
        for candidate in [Path.home() / "rewind", Path.home() / ".openclaw" / "workspace"]:
            if candidate.exists():
                workspace = candidate
                break

    print("Rewind Doctor")
    print("=" * 50)
    print(f"  L0 DB:     {db_path}")
    print(f"  Workspace: {workspace}")
    print()

    # ── 1. L0 FTS5 index ─────────────────────────────────────────────────
    print("Checking L0 FTS5 index...")
    db_path.parent.mkdir(parents=True, exist_ok=True)
    needs_build = False

    if not db_path.exists():
        needs_build = True
        print("  ⚠️  Database missing — will create")
    else:
        try:
            conn = sqlite3.connect(str(db_path), timeout=2)
            count = conn.execute(
                "SELECT COUNT(*) FROM chunks_fts"
            ).fetchone()[0]
            conn.close()
            if count == 0:
                needs_build = True
                print("  ⚠️  FTS5 table empty — will rebuild")
            else:
                ok.append(f"L0 FTS5: {count} chunks indexed")
                print(f"  ✅ {count} chunks indexed")
        except Exception:
            needs_build = True
            print("  ⚠️  FTS5 table missing or corrupt — will rebuild")

    if needs_build:
        if not workspace or not workspace.exists():
            warnings.append("L0: no workspace found to index")
            print("  ❌ No workspace directory found — cannot build index")
        else:
            print(f"  Building index from {workspace}...")
            conn = sqlite3.connect(str(db_path))
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS chunks (
                    id INTEGER PRIMARY KEY,
                    path TEXT,
                    text TEXT,
                    hash TEXT UNIQUE
                )
            """)
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
                USING fts5(path, text, content=chunks, content_rowid=id)
            """)

            chunk_count = 0
            for md_file in workspace.rglob("*.md"):
                try:
                    text = md_file.read_text(errors="replace")
                    rel = str(md_file.relative_to(workspace))
                    paragraphs = [
                        c.strip() for c in text.split("\n\n")
                        if c.strip() and len(c.strip()) > 20
                    ]
                    for chunk in paragraphs:
                        h = hashlib.md5(
                            (rel + chunk[:200]).encode()
                        ).hexdigest()
                        try:
                            conn.execute(
                                "INSERT INTO chunks (path, text, hash) VALUES (?, ?, ?)",
                                (rel, chunk, h),
                            )
                            rid = conn.execute(
                                "SELECT last_insert_rowid()"
                            ).fetchone()[0]
                            conn.execute(
                                "INSERT INTO chunks_fts (rowid, path, text) VALUES (?, ?, ?)",
                                (rid, rel, chunk),
                            )
                            chunk_count += 1
                        except sqlite3.IntegrityError:
                            pass
                except Exception:
                    pass

            conn.commit()
            conn.close()
            fixes.append(f"L0 FTS5: indexed {chunk_count} chunks")
            print(f"  ✅ Built L0 index: {chunk_count} chunks")

    # ── 2. OpenClaw config validation fix ─────────────────────────────────
    print()
    print("Checking OpenClaw config...")
    oc_config = Path.home() / ".openclaw" / "openclaw.json"

    if not oc_config.exists():
        ok.append("OpenClaw config: not present (skip)")
        print("  ℹ️  No OpenClaw config found — skipping")
    else:
        try:
            raw = oc_config.read_text()
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                try:
                    import json5  # type: ignore
                    data = json5.loads(raw)
                except (ImportError, Exception):
                    warnings.append("OpenClaw config: not valid JSON (json5 not installed)")
                    print("  ⚠️  Config is not valid JSON and json5 is not installed — skipping")
                    data = None

            if data is not None:
                # Strip keys that OpenClaw's validator rejects
                strip_rules = {
                    ("channels", "bluebubbles"): ["enrichGroupParticipantsFromContacts"],
                }
                dirty = False
                for path_keys, bad_keys in strip_rules.items():
                    obj = data
                    for p in path_keys:
                        obj = obj.get(p, {}) if isinstance(obj, dict) else {}
                    for k in bad_keys:
                        if isinstance(obj, dict) and k in obj:
                            del obj[k]
                            dirty = True
                            fixes.append(f"OpenClaw config: stripped {'.'.join(path_keys)}.{k}")
                            print(f"  🔧 Stripped invalid key: {'.'.join(path_keys)}.{k}")

                if dirty:
                    oc_config.write_text(json.dumps(data, indent=2))
                    print("  ✅ Config fixed and saved")
                else:
                    ok.append("OpenClaw config: clean")
                    print("  ✅ Config is clean — no invalid keys found")
        except Exception as e:
            warnings.append(f"OpenClaw config: error — {e}")
            print(f"  ❌ Error checking config: {e}")

    # ── 3. Health check ───────────────────────────────────────────────────
    print()
    print("Running health check...")
    try:
        from rewind.client import RewindClient
        from rewind.config import default_config

        cfg = default_config(args.tier)
        if args.db:
            cfg.vector_db_path = args.db

        client = RewindClient(cfg)
        health = client.health()
        client.close()

        for name, status in health.get("layers", {}).items():
            s = status.get("status", "unknown")
            icon = "✅" if s == "ok" else "❌" if s == "error" else "⚠️"
            extra = ""
            if "nodes" in status:
                extra = f" ({status['nodes']} nodes)"
            elif "total_chunks" in status:
                extra = f" ({status['total_chunks']} chunks)"
            print(f"  {icon} {name}: {s}{extra}")
            if s == "ok":
                ok.append(f"{name}: {s}{extra}")
            else:
                warnings.append(f"{name}: {s}")
    except Exception as e:
        warnings.append(f"Health check failed: {e}")
        print(f"  ⚠️  Health check failed: {e}")

    # ── 4. Summary ────────────────────────────────────────────────────────
    print()
    print("=" * 50)
    print("Summary")
    print("=" * 50)
    if fixes:
        print(f"  🔧 Fixed:    {len(fixes)}")
        for f in fixes:
            print(f"     • {f}")
    if warnings:
        print(f"  ⚠️  Warnings: {len(warnings)}")
        for w in warnings:
            print(f"     • {w}")
    if ok:
        print(f"  ✅ OK:       {len(ok)}")

    if not fixes and not warnings:
        print("  ✅ Everything looks healthy!")


def cmd_ingest_chats(args: argparse.Namespace) -> None:
    """One-time backfill: scan all OpenClaw session JSONL files and index into L0."""
    import hashlib
    import json
    import os
    import sqlite3
    from pathlib import Path

    rewind_dir = Path.home() / ".rewind"
    rewind_dir.mkdir(parents=True, exist_ok=True)

    db_path = Path(
        args.db
        or os.environ.get("REWIND_MEMORY_DB", "")
        or str(rewind_dir / "memory" / "main.sqlite")
    )
    db_path.parent.mkdir(parents=True, exist_ok=True)

    # ── Session directory detection ────────────────────────────────────────
    if args.session_dir:
        jsonl_files = sorted(Path(args.session_dir).glob("*.jsonl"))
    else:
        agents_root = Path.home() / ".openclaw" / "agents"
        jsonl_files = sorted(agents_root.glob("*/sessions/*.jsonl")) if agents_root.exists() else []

    jsonl_files = [f for f in jsonl_files if ".lock" not in f.name and ".deleted" not in f.name]

    if not jsonl_files:
        print("No OpenClaw session JSONL files found.")
        return

    # ── DB setup ───────────────────────────────────────────────────────────
    conn = sqlite3.connect(str(db_path), timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS chunks (
            id INTEGER PRIMARY KEY,
            path TEXT,
            text TEXT,
            hash TEXT UNIQUE
        )
    """)
    conn.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
        USING fts5(path, text, content=chunks, content_rowid=id)
    """)
    conn.commit()

    def index_text(path_label: str, text: str) -> bool:
        text = text.strip()
        if not text or len(text) < 10:
            return False
        h = hashlib.md5((path_label + text[:200]).encode()).hexdigest()
        try:
            conn.execute(
                "INSERT INTO chunks (path, text, hash) VALUES (?, ?, ?)",
                (path_label, text, h),
            )
            rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            conn.execute(
                "INSERT INTO chunks_fts (rowid, path, text) VALUES (?, ?, ?)",
                (rid, path_label, text),
            )
            return True
        except sqlite3.IntegrityError:
            return False

    total_chunks = 0
    total_messages = 0
    files_processed = 0
    total_files = len(jsonl_files)

    for idx, filepath in enumerate(jsonl_files, 1):
        messages = []
        try:
            with open(filepath, "r", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    role = obj.get("role", "")
                    if role not in ("user", "assistant"):
                        continue
                    content = obj.get("content", "")
                    if isinstance(content, list):
                        parts = []
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                parts.append(block.get("text", ""))
                            elif isinstance(block, str):
                                parts.append(block)
                        content = " ".join(parts)
                    if not isinstance(content, str):
                        content = str(content)
                    messages.append((role, content))
        except Exception as e:
            print(f"  Warning: could not read {filepath.name}: {e}")
            continue

        print(f"Processing file {idx}/{total_files}: {filepath.name} ({len(messages)} messages)")

        agent_name = filepath.parent.parent.name if filepath.parent.name == "sessions" else filepath.parent.name
        file_chunks = 0
        for role, content in messages:
            path_label = f"session:{agent_name}/{filepath.stem}:{role}"
            chunk_size = 500
            for i in range(0, max(1, len(content)), chunk_size):
                chunk = content[i:i + chunk_size].strip()
                if index_text(path_label, chunk):
                    file_chunks += 1

        total_chunks += file_chunks
        total_messages += len(messages)
        files_processed += 1

    conn.commit()
    conn.close()

    print(f"\nIndexed {total_chunks} chunks from {files_processed} files ({total_messages} messages)")


def cmd_watch(args: argparse.Namespace) -> None:
    """Watch OpenClaw session files and index conversations in real-time into L0 FTS5."""
    import hashlib
    import json
    import os
    import signal
    import sqlite3
    import sys
    import time
    from pathlib import Path

    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
    except ImportError:
        print("Error: watchdog library not installed. Run: pip install 'watchdog>=3.0'", file=sys.stderr)
        sys.exit(1)

    # ── Paths ──────────────────────────────────────────────────────────────
    rewind_dir = Path.home() / ".rewind"
    rewind_dir.mkdir(parents=True, exist_ok=True)

    db_path = Path(
        args.db
        or os.environ.get("REWIND_MEMORY_DB", "")
        or str(rewind_dir / "memory" / "main.sqlite")
    )
    db_path.parent.mkdir(parents=True, exist_ok=True)

    state_file = rewind_dir / "watch-state.json"
    pid_file = rewind_dir / "watch.pid"

    # ── Session directory detection ────────────────────────────────────────
    if args.session_dir:
        session_dirs = [Path(args.session_dir)]
    else:
        agents_root = Path.home() / ".openclaw" / "agents"
        session_dirs = sorted(agents_root.glob("*/sessions")) if agents_root.exists() else []

    if not session_dirs:
        print("No OpenClaw session directories found.", file=sys.stderr)
        sys.exit(1)

    # ── Daemon mode ────────────────────────────────────────────────────────
    if args.daemon:
        pid = os.fork()
        if pid > 0:
            print(f"Watch daemon started (PID {pid})")
            pid_file.write_text(str(pid))
            sys.exit(0)
        os.setsid()

    # ── DB setup ───────────────────────────────────────────────────────────
    def get_conn():
        conn = sqlite3.connect(str(db_path), timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY,
                path TEXT,
                text TEXT,
                hash TEXT UNIQUE
            )
        """)
        conn.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
            USING fts5(path, text, content=chunks, content_rowid=id)
        """)
        conn.commit()
        return conn

    # ── State persistence (file offsets) ──────────────────────────────────
    def load_state():
        if state_file.exists():
            try:
                return json.loads(state_file.read_text())
            except Exception:
                pass
        return {}

    def save_state(state):
        state_file.write_text(json.dumps(state, indent=2))

    # ── Index a chunk of text ──────────────────────────────────────────────
    def index_text(conn, path_label: str, text: str) -> bool:
        text = text.strip()
        if not text or len(text) < 10:
            return False
        h = hashlib.md5((path_label + text[:200]).encode()).hexdigest()
        try:
            conn.execute(
                "INSERT INTO chunks (path, text, hash) VALUES (?, ?, ?)",
                (path_label, text, h),
            )
            rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            conn.execute(
                "INSERT INTO chunks_fts (rowid, path, text) VALUES (?, ?, ?)",
                (rid, path_label, text),
            )
            return True
        except sqlite3.IntegrityError:
            return False

    # ── Process new lines from a JSONL session file ────────────────────────
    def process_file(filepath: Path, state: dict, conn) -> int:
        key = str(filepath)
        offset = state.get(key, 0)
        indexed = 0
        try:
            with open(filepath, "r", errors="replace") as f:
                f.seek(offset)
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    role = obj.get("role", "")
                    if role not in ("user", "assistant"):
                        continue
                    content = obj.get("content", "")
                    if isinstance(content, list):
                        # handle content blocks
                        parts = []
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                parts.append(block.get("text", ""))
                            elif isinstance(block, str):
                                parts.append(block)
                        content = " ".join(parts)
                    if not isinstance(content, str):
                        content = str(content)

                    path_label = f"session:{filepath.parent.parent.name}/{filepath.stem}:{role}"
                    # Chunk by ~500 chars with overlap
                    chunk_size = 500
                    for i in range(0, max(1, len(content)), chunk_size):
                        chunk = content[i:i + chunk_size].strip()
                        if index_text(conn, path_label, chunk):
                            indexed += 1

                new_offset = f.tell()
            state[key] = new_offset
        except Exception as e:
            print(f"[watch] Error processing {filepath}: {e}", file=sys.stderr)
        return indexed

    # ── Scan all existing files on startup ────────────────────────────────
    state = load_state()
    conn = get_conn()

    total_startup = 0
    for sdir in session_dirs:
        for jsonl in sdir.glob("*.jsonl"):
            if ".lock" in jsonl.suffixes or ".deleted" in jsonl.name:
                continue
            n = process_file(jsonl, state, conn)
            if n:
                print(f"[watch] Indexed {n} chunks from {jsonl.name}")
                total_startup += n

    conn.commit()
    save_state(state)
    if total_startup:
        print(f"[watch] Startup: indexed {total_startup} new chunks total")

    print(f"[watch] Watching {len(session_dirs)} session dir(s)...")
    for d in session_dirs:
        print(f"  → {d}")

    # ── Watchdog handler ──────────────────────────────────────────────────
    class SessionHandler(FileSystemEventHandler):
        def on_modified(self, event):
            if event.is_directory:
                return
            p = Path(event.src_path)
            if p.suffix != ".jsonl" or ".lock" in p.name or ".deleted" in p.name:
                return
            n = process_file(p, state, conn)
            conn.commit()
            save_state(state)
            if n:
                print(f"[watch] +{n} chunks ← {p.name}")

        def on_created(self, event):
            self.on_modified(event)

    observer = Observer()
    handler = SessionHandler()
    for sdir in session_dirs:
        if sdir.exists():
            observer.schedule(handler, str(sdir), recursive=False)

    observer.start()

    # ── Graceful shutdown ─────────────────────────────────────────────────
    def shutdown(signum, frame):
        print("\n[watch] Shutting down...")
        observer.stop()
        observer.join()
        conn.close()
        save_state(state)
        if pid_file.exists():
            try:
                pid_file.unlink()
            except Exception:
                pass
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        shutdown(None, None)


def cmd_proxy(args) -> None:
    """Start memory proxy."""
    from rewind.proxy import main as proxy_main
    import sys
    # Rebuild argv for proxy's own parser
    sys.argv = ["rewind-proxy",
                "--port", str(args.port),
                "--host", args.host,
                "--upstream", args.upstream]
    if args.upstream_key:
        sys.argv += ["--upstream-key", args.upstream_key]
    if args.proxy_db:
        sys.argv += ["--db", args.proxy_db]
    if args.no_auto_store:
        sys.argv.append("--no-auto-store")
    proxy_main()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="rewind",
        description="Rewind — bio-inspired memory stack for AI agents",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable debug logging",
    )

    sub = parser.add_subparsers(dest="command")

    # ingest
    p_ingest = sub.add_parser("ingest", help="Ingest files into memory")
    p_ingest.add_argument("path", help="File or directory to ingest")
    p_ingest.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_ingest.add_argument("--db", default=None, help="Path to vector DB")

    # search
    p_search = sub.add_parser("search", help="Search memory")
    p_search.add_argument("query", help="Search query")
    p_search.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_search.add_argument("--db", default=None, help="Path to vector DB")
    p_search.add_argument("--limit", type=int, default=10)
    p_search.add_argument("--json", action="store_true", help="Output JSON")

    # health
    p_health = sub.add_parser("health", help="Health check")
    p_health.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_health.add_argument("--db", default=None, help="Path to vector DB")

    p_proxy = sub.add_parser("proxy", help="Memory proxy — auto-inject memory into LLM calls")
    p_proxy.add_argument("--port", type=int, default=8080, help="Port (default: 8080)")
    p_proxy.add_argument("--host", default="127.0.0.1", help="Host (default: 127.0.0.1)")
    p_proxy.add_argument("--upstream", default="https://api.openai.com/v1",
                         help="Upstream LLM API URL")
    p_proxy.add_argument("--upstream-key", default="", help="Upstream API key")
    p_proxy.add_argument("--db", default=None, dest="proxy_db", help="Rewind database path")
    p_proxy.add_argument("--no-auto-store", action="store_true", help="Disable auto fact extraction")

    # serve (alias for proxy)
    p_serve = sub.add_parser("serve", help="Start memory API server (alias for proxy)")
    p_serve.add_argument("--port", type=int, default=8080, help="Port (default: 8080)")
    p_serve.add_argument("--host", default="127.0.0.1", help="Host (default: 127.0.0.1)")
    p_serve.add_argument("--upstream", default="https://api.openai.com/v1",
                         help="Upstream LLM API URL")
    p_serve.add_argument("--upstream-key", default="", help="Upstream API key")
    p_serve.add_argument("--db", default=None, dest="proxy_db", help="Rewind database path")
    p_serve.add_argument("--no-auto-store", action="store_true", help="Disable auto fact extraction")


    # remember
    p_remember = sub.add_parser("remember", help="Store a text note into memory")
    p_remember.add_argument("text", help="Text to store")
    p_remember.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_remember.add_argument("--db", default=None, help="Path to vector DB")

    # ingest-chats
    p_ic = sub.add_parser("ingest-chats", help="Backfill historical OpenClaw conversations into memory")
    p_ic.add_argument("--session-dir", help="Override session directory")
    p_ic.add_argument("--db", default=None, help="Path to L0 SQLite DB")

    # watch
    p_watch = sub.add_parser("watch", help="Watch OpenClaw sessions and index conversations in real-time")
    p_watch.add_argument("--session-dir", help="Override session directory")
    p_watch.add_argument("--daemon", action="store_true", help="Run as background daemon")
    p_watch.add_argument("--db", default=None, help="Path to L0 SQLite DB")

    # doctor
    p_doctor = sub.add_parser("doctor", help="Auto-diagnose and fix common issues")
    p_doctor.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_doctor.add_argument("--db", default=None, help="Path to L0 SQLite DB")
    p_doctor.add_argument("--workspace", default=None, help="Path to workspace directory")

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(name)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    if args.command == "remember":
        cmd_remember(args)
    elif args.command == "ingest":
        cmd_ingest(args)
    elif args.command == "search":
        cmd_search(args)
    elif args.command == "health":
        cmd_health(args)
    elif args.command in ("proxy", "serve"):
        cmd_proxy(args)
    elif args.command == "doctor":
        cmd_doctor(args)
    elif args.command == "ingest-chats":
        cmd_ingest_chats(args)
    elif args.command == "watch":
        cmd_watch(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
