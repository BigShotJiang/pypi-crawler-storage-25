"""Rewind Memory Proxy — OpenAI-compatible proxy that auto-injects memory context.

Point any tool at this proxy instead of the real API. Memory is automatically
searched and injected into every prompt, and new facts are extracted from responses.

Usage:
    rewind proxy --port 8080 --upstream https://api.openai.com/v1

Then set your tool's API base URL to http://localhost:8080/v1

Works with: Claude Code, Cursor, Aider, Continue, OpenClaw, any OpenAI-compatible client.
"""

import json
import logging
import os
import re
import time
from typing import Dict, List

import httpx

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Memory injection
# ---------------------------------------------------------------------------

MEMORY_HEADER = "\n\n<memory_context>\nRelevant memories (auto-retrieved by Rewind):\n"
MEMORY_FOOTER = "\n</memory_context>\n"

MAX_MEMORY_CHARS = 4000  # cap injected memory to avoid blowing context

# Rough token-to-char ratios for context budget estimation
# Most models: ~4 chars per token. We leave headroom for the response.
MODEL_CONTEXT_LIMITS = {
    "gpt-4": 8192,
    "gpt-4-turbo": 128000,
    "gpt-4o": 128000,
    "gpt-4o-mini": 128000,
    "gpt-3.5-turbo": 16385,
    "claude-3-5-sonnet": 200000,
    "claude-3-opus": 200000,
    "claude-sonnet-4-5": 200000,
    "claude-opus-4-6": 200000,
}
DEFAULT_CONTEXT_LIMIT = 32000  # conservative default
CHARS_PER_TOKEN = 4
RESPONSE_HEADROOM_TOKENS = 4096  # reserve for response


def _extract_query_from_messages(messages: List[Dict]) -> str:
    """Extract a search query from the last user message(s)."""
    user_messages = [m for m in messages if m.get("role") == "user"]
    if not user_messages:
        return ""

    last = user_messages[-1]
    content = last.get("content", "")
    if isinstance(content, list):
        # Vision/multimodal — extract text parts
        text_parts = [p.get("text", "") for p in content if p.get("type") == "text"]
        content = " ".join(text_parts)

    # Take last 500 chars as search query
    return content[-500:].strip()


def _format_memory_results(results: List[Dict]) -> str:
    """Format memory search results for injection."""
    if not results:
        return ""

    lines = []
    for i, r in enumerate(results[:8], 1):
        r.get("score", 0)
        layer = r.get("layer", "?")
        text = r.get("text", "").strip()[:400]
        path = r.get("path", "")
        source = f" ({path})" if path else ""
        lines.append(f"  [{layer}] {text}{source}")

    body = "\n".join(lines)
    if len(body) > MAX_MEMORY_CHARS:
        body = body[:MAX_MEMORY_CHARS] + "\n  ... (truncated)"

    return MEMORY_HEADER + body + MEMORY_FOOTER


def _estimate_message_chars(messages: List[Dict]) -> int:
    """Estimate total characters in messages."""
    total = 0
    for m in messages:
        content = m.get("content", "")
        if isinstance(content, list):
            for p in content:
                total += len(p.get("text", ""))
        else:
            total += len(str(content))
    return total


def _budget_memory_chars(messages: List[Dict], model: str = "") -> int:
    """Calculate how many chars of memory we can safely inject.

    Estimates current prompt size, checks model context limit,
    and returns the available budget for memory injection.
    """
    # Get model context limit
    context_tokens = DEFAULT_CONTEXT_LIMIT
    for prefix, limit in MODEL_CONTEXT_LIMITS.items():
        if prefix in model.lower():
            context_tokens = limit
            break

    available_tokens = context_tokens - RESPONSE_HEADROOM_TOKENS
    available_chars = available_tokens * CHARS_PER_TOKEN

    current_chars = _estimate_message_chars(messages)
    budget = available_chars - current_chars

    # Clamp between 0 and MAX_MEMORY_CHARS
    return max(0, min(budget, MAX_MEMORY_CHARS))


def _inject_memory(messages: List[Dict], memory_context: str) -> List[Dict]:
    """Inject memory context into the system message."""
    if not memory_context:
        return messages

    messages = [m.copy() for m in messages]  # don't mutate original

    # Find system message
    for m in messages:
        if m.get("role") == "system":
            m["content"] = m.get("content", "") + memory_context
            return messages

    # No system message — prepend one
    messages.insert(0, {"role": "system", "content": memory_context.strip()})
    return messages


# ---------------------------------------------------------------------------
# Fact extraction (lightweight, no LLM needed)
# ---------------------------------------------------------------------------

def _extract_facts(response_text: str) -> List[str]:
    """Extract potential facts/decisions from assistant response.

    Simple heuristic extraction — looks for decision language, commitments,
    and factual statements. Not perfect, but catches the obvious ones.
    """
    facts = []

    # Decision patterns
    decision_patterns = [
        r"(?:decided|decision|agreed|confirmed|approved|chose|selected|picked)[\s:]+(.{20,150})",
        r"(?:we(?:'ll| will)|I(?:'ll| will)|going to)\s+(.{20,100})",
        r"(?:the plan is|next step(?:s)?|action item)[\s:]+(.{20,150})",
    ]

    for pattern in decision_patterns:
        matches = re.findall(pattern, response_text, re.IGNORECASE)
        for m in matches:
            clean = m.strip().rstrip(".,;:")
            if len(clean) > 20:
                facts.append(clean)

    return facts[:5]  # cap at 5 per response


# ---------------------------------------------------------------------------
# Proxy server
# ---------------------------------------------------------------------------

def create_app(
    upstream_url: str = "https://api.openai.com/v1",
    upstream_key: str = "",
    db_path: str = "~/.rewind/data/rewind.db",
    workspace_path: str = "~/.rewind",
    auto_store: bool = True,
):
    """Create the proxy ASGI app."""

    # Lazy import to keep startup fast
    from rewind.client import RewindClient
    from rewind.config import default_config

    cfg = default_config("free")
    cfg.vector_db_path = os.path.expanduser(db_path)
    cfg.workspace_path = os.path.expanduser(workspace_path)
    client = RewindClient(cfg)

    # -- ASGI app ----------------------------------------------------------

    async def app(scope, receive, send):
        if scope["type"] != "http":
            return

        path = scope["path"]
        scope["method"]

        # Health endpoint
        if path == "/health":
            health = client.health()
            body = json.dumps({"status": "ok", "proxy": True, "upstream": upstream_url, **health}).encode()
            await _send_json(send, 200, body)
            return

        # Only proxy /v1/chat/completions (and variants)
        if not path.endswith("/chat/completions"):
            # Pass through everything else to upstream
            await _proxy_passthrough(scope, receive, send, upstream_url, upstream_key)
            return

        # -- Chat completions with memory injection --
        body = await _read_body(receive)
        try:
            request_data = json.loads(body)
        except json.JSONDecodeError:
            await _send_json(send, 400, json.dumps({"error": "Invalid JSON"}).encode())
            return

        messages = request_data.get("messages", [])
        stream = request_data.get("stream", False)

        # 1. Extract query from messages
        query = _extract_query_from_messages(messages)

        # 2. Calculate memory budget based on model context limit
        model = request_data.get("model", "")
        memory_budget = _budget_memory_chars(messages, model)

        # 3. Search memory (skip if no budget)
        memory_context = ""
        if query and memory_budget > 200:
            try:
                t0 = time.time()
                results = client.search(query, limit=8)
                search_ms = (time.time() - t0) * 1000

                if results:
                    raw_results = [
                        {"score": r.score, "layer": r.layer, "text": r.text, "path": r.path}
                        for r in results
                    ]
                    memory_context = _format_memory_results(raw_results)
                    # Trim to budget
                    if len(memory_context) > memory_budget:
                        memory_context = memory_context[:memory_budget] + MEMORY_FOOTER
                        log.info(f"Memory: trimmed to {memory_budget} chars (context budget)")
                    log.info(f"Memory: {len(results)} results in {search_ms:.0f}ms, injecting {len(memory_context)} chars (budget: {memory_budget})")
                else:
                    log.info(f"Memory: no results for '{query[:50]}...' ({search_ms:.0f}ms)")
            except Exception as exc:
                log.warning(f"Memory search failed: {exc}")
        elif query and memory_budget <= 200:
            log.warning(f"Memory: skipped — context too full ({_estimate_message_chars(messages)} chars, budget only {memory_budget})")

        # 4. Inject memory into messages
        if memory_context:
            request_data["messages"] = _inject_memory(messages, memory_context)

        # 5. Forward to upstream
        upstream_endpoint = upstream_url.rstrip("/") + "/chat/completions"
        headers = {"Content-Type": "application/json"}
        if upstream_key:
            headers["Authorization"] = f"Bearer {upstream_key}"

        # Pass through client's auth header if no upstream key configured
        if not upstream_key:
            for header_name, header_value in scope.get("headers", []):
                if header_name == b"authorization":
                    headers["Authorization"] = header_value.decode()
                    break

        if stream:
            # Streaming response — pass through directly
            await _proxy_stream(send, upstream_endpoint, headers, request_data)
        else:
            # Non-streaming — forward, optionally extract facts
            async with httpx.AsyncClient(timeout=120) as http:
                resp = await http.post(upstream_endpoint, json=request_data, headers=headers)

            response_data = resp.json()

            # 6. Extract and store facts from response
            if auto_store and resp.status_code == 200:
                try:
                    choices = response_data.get("choices", [])
                    if choices:
                        assistant_text = choices[0].get("message", {}).get("content", "")
                        facts = _extract_facts(assistant_text)
                        for fact in facts:
                            log.info(f"Auto-stored fact: {fact[:80]}")
                            # Store via L0 ingest (text chunk)
                except Exception as exc:
                    log.warning(f"Fact extraction failed: {exc}")

            await _send_json(send, resp.status_code, json.dumps(response_data).encode())

    return app


# ---------------------------------------------------------------------------
# ASGI helpers
# ---------------------------------------------------------------------------

async def _read_body(receive) -> bytes:
    body = b""
    while True:
        message = await receive()
        body += message.get("body", b"")
        if not message.get("more_body", False):
            break
    return body


async def _send_json(send, status: int, body: bytes):
    await send({
        "type": "http.response.start",
        "status": status,
        "headers": [
            [b"content-type", b"application/json"],
            [b"x-rewind-proxy", b"true"],
        ],
    })
    await send({"type": "http.response.body", "body": body})


async def _proxy_stream(send, url: str, headers: dict, data: dict):
    """Stream the upstream response back to the client."""
    await send({
        "type": "http.response.start",
        "status": 200,
        "headers": [
            [b"content-type", b"text/event-stream"],
            [b"x-rewind-proxy", b"true"],
        ],
    })

    async with httpx.AsyncClient(timeout=120) as http:
        async with http.stream("POST", url, json=data, headers=headers) as resp:
            async for chunk in resp.aiter_bytes():
                await send({"type": "http.response.body", "body": chunk, "more_body": True})

    await send({"type": "http.response.body", "body": b""})


async def _proxy_passthrough(scope, receive, send, upstream_url: str, upstream_key: str):
    """Pass through non-chat requests to upstream."""
    body = await _read_body(receive)
    path = scope["path"]
    method = scope["method"]

    url = upstream_url.rstrip("/") + path
    headers = {"Content-Type": "application/json"}
    if upstream_key:
        headers["Authorization"] = f"Bearer {upstream_key}"
    else:
        for header_name, header_value in scope.get("headers", []):
            if header_name == b"authorization":
                headers["Authorization"] = header_value.decode()
                break

    async with httpx.AsyncClient(timeout=60) as http:
        if method == "GET":
            resp = await http.get(url, headers=headers)
        elif method == "POST":
            resp = await http.post(url, content=body, headers=headers)
        else:
            resp = await http.request(method, url, content=body, headers=headers)

    await _send_json(send, resp.status_code, resp.content)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="Rewind Memory Proxy — auto-inject memory into every LLM call"
    )
    parser.add_argument("--port", type=int, default=8080, help="Port to listen on (default: 8080)")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    parser.add_argument("--upstream", default=os.environ.get("REWIND_UPSTREAM_URL", "https://api.openai.com/v1"),
                        help="Upstream LLM API URL")
    parser.add_argument("--upstream-key", default=os.environ.get("REWIND_UPSTREAM_KEY", ""),
                        help="Upstream API key (or pass through client's key)")
    parser.add_argument("--db", default="~/.rewind/data/rewind.db", help="Rewind database path")
    parser.add_argument("--workspace", default="~/.rewind", help="Rewind workspace path")
    parser.add_argument("--no-auto-store", action="store_true", help="Disable automatic fact extraction")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

    app = create_app(
        upstream_url=args.upstream,
        upstream_key=args.upstream_key,
        db_path=args.db,
        workspace_path=args.workspace,
        auto_store=not args.no_auto_store,
    )

    try:
        import uvicorn
        print("🧠 Rewind Memory Proxy")
        print(f"   Listening: http://{args.host}:{args.port}")
        print(f"   Upstream:  {args.upstream}")
        print(f"   Auto-store: {'on' if not args.no_auto_store else 'off'}")
        print()
        print(f"   Set your tool's API base URL to: http://{args.host}:{args.port}/v1")
        print()
        uvicorn.run(app, host=args.host, port=args.port, log_level="info")
    except ImportError:
        print("Error: uvicorn is required for proxy mode.")
        print("Install it: pip install uvicorn")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
