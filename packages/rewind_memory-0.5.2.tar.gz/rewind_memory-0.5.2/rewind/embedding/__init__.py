"""Embedding providers."""

from .base import EmbeddingProvider
from .ollama import OllamaProvider

__all__ = [
    "EmbeddingProvider",
    "OllamaProvider",
]
