"""Abstract embedding provider."""

from abc import ABC, abstractmethod
from typing import List, Optional


class EmbeddingProvider(ABC):
    """Base class for all embedding providers."""

    @abstractmethod
    def embed(self, text: str) -> Optional[List[float]]:
        """Embed a single text string.

        Returns:
            Embedding vector, or *None* on failure.
        """
        ...

    @abstractmethod
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Embed a batch of texts.

        Returns:
            List of embedding vectors (same length as *texts*).
        """
        ...

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Dimensionality of the embedding vectors."""
        ...
