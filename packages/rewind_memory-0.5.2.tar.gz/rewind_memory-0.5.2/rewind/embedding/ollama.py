"""Ollama embedding provider (768-dim, free tier)."""

import logging
import sys
from typing import List, Optional

import httpx

from .base import EmbeddingProvider

log = logging.getLogger(__name__)

_OLLAMA_INSTALL_HELP = """
╔══════════════════════════════════════════════════════════════╗
║  Ollama not found — required for vector search (L4)         ║
║                                                             ║
║  Install:  curl -fsSL https://ollama.com/install.sh | sh    ║
║  Then:     ollama pull nomic-embed-text                     ║
║                                                             ║
║  Docs: https://ollama.com                                   ║
║  L0 (keyword) and L3 (graph) still work without Ollama.     ║
╚══════════════════════════════════════════════════════════════╝
"""

_MODEL_MISSING_HELP = """
╔══════════════════════════════════════════════════════════════╗
║  Embedding model '{model}' not found in Ollama              ║
║                                                             ║
║  Pull it:  ollama pull {model}                              ║
║  (~274MB download)                                          ║
╚══════════════════════════════════════════════════════════════╝
"""


class OllamaProvider(EmbeddingProvider):
    """Embedding provider using Ollama's local ``nomic-embed-text`` model."""

    _DIMENSION = 768
    _checked = False
    _available = False

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "nomic-embed-text",
        target_dim: int = 768,
        timeout: float = 15.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.target_dim = target_dim
        self.timeout = timeout
        self._check_ollama()

    def _check_ollama(self):
        """Check if Ollama is running and model is available."""
        if OllamaProvider._checked:
            return
        OllamaProvider._checked = True

        try:
            resp = httpx.get(f"{self.base_url}/api/tags", timeout=3.0)
            resp.raise_for_status()
            models = [m.get("name", "").split(":")[0] for m in resp.json().get("models", [])]
            OllamaProvider._available = True

            if self.model not in models and f"{self.model}" not in [m.split(":")[0] for m in models]:
                log.warning(_MODEL_MISSING_HELP.format(model=self.model))
                print(_MODEL_MISSING_HELP.format(model=self.model), file=sys.stderr)

        except httpx.ConnectError:
            log.warning("Ollama not running at %s", self.base_url)
            print(_OLLAMA_INSTALL_HELP, file=sys.stderr)
        except Exception as e:
            log.warning("Ollama check failed: %s", e)

    @property
    def dimension(self) -> int:
        return self.target_dim

    def _pad(self, vec: List[float]) -> List[float]:
        """Zero-pad to target dimension if needed."""
        if len(vec) >= self.target_dim:
            return vec[: self.target_dim]
        return vec + [0.0] * (self.target_dim - len(vec))

    def embed(self, text: str) -> Optional[List[float]]:
        try:
            resp = httpx.post(
                f"{self.base_url}/api/embeddings",
                json={"model": self.model, "prompt": text[:2048]},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            vec = resp.json().get("embedding")
            return self._pad(vec) if vec else None
        except Exception:
            return None

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        results: List[List[float]] = []
        for text in texts:
            vec = self.embed(text)
            results.append(vec if vec else [])
        return results
