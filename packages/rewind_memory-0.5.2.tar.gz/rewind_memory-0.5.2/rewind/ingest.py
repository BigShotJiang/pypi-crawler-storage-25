"""Ingest pipeline — chunk files into the memory stack.

Reads files from a workspace directory, chunks them, and writes to:
- L0: FTS5 index (chunks_fts) for BM25 keyword search
- L4: sqlite-vec (chunks_vec) for semantic vector search
- L3: SQLite graph (entity extraction from chunks)

Usage::

    from rewind.ingest import IngestPipeline
    from rewind.config import default_config

    pipeline = IngestPipeline(default_config("free"))
    stats = pipeline.ingest_directory("./workspace")
    print(stats)  # {"files": 42, "chunks": 186, "vectors": 186, "entities": 23}
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
import struct
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from rewind.config import RewindConfig, default_config

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

# File extensions we can ingest
TEXT_EXTENSIONS = {
    ".md", ".txt", ".py", ".js", ".ts", ".json", ".yaml", ".yml",
    ".toml", ".cfg", ".ini", ".sh", ".bash", ".zsh", ".html", ".css",
    ".xml", ".csv", ".rst", ".org", ".tex", ".r", ".sql", ".go",
    ".rs", ".java", ".kt", ".swift", ".c", ".cpp", ".h", ".hpp",
}

# Directories to skip
SKIP_DIRS = {
    "__pycache__", ".git", "node_modules", ".venv", "venv",
    ".mypy_cache", ".pytest_cache", ".tox", "dist", "build",
    ".eggs", "*.egg-info",
}

# Default chunk config
DEFAULT_MAX_CHARS = 1200
DEFAULT_OVERLAP = 100


def chunk_text(
    text: str,
    source_path: str = "",
    max_chars: int = DEFAULT_MAX_CHARS,
    overlap: int = DEFAULT_OVERLAP,
) -> List[Dict[str, Any]]:
    """Split text into overlapping chunks with section awareness.

    For markdown files, splits on ## / ### headings first.
    For other files, splits on double newlines or at max_chars boundaries.

    Returns list of dicts: {"text": str, "heading": str, "index": int}
    """
    if not text.strip():
        return []

    is_markdown = source_path.endswith(".md")

    if is_markdown:
        return _chunk_markdown(text, max_chars, overlap)
    else:
        return _chunk_plain(text, max_chars, overlap)


def _chunk_markdown(
    text: str, max_chars: int, overlap: int
) -> List[Dict[str, Any]]:
    """Chunk markdown by heading boundaries."""
    chunks: List[Dict[str, Any]] = []
    sections = re.split(r"(^#{1,3}\s+.+$)", text, flags=re.MULTILINE)

    current_heading = ""
    current_text = ""
    idx = 0

    for part in sections:
        if re.match(r"^#{1,3}\s+", part):
            if current_text.strip():
                for sub in _split_long(current_text.strip(), max_chars, overlap):
                    chunks.append({
                        "text": sub,
                        "heading": current_heading,
                        "index": idx,
                    })
                    idx += 1
            current_heading = part.strip().lstrip("#").strip()
            current_text = ""
        else:
            current_text += part

    if current_text.strip():
        for sub in _split_long(current_text.strip(), max_chars, overlap):
            chunks.append({
                "text": sub,
                "heading": current_heading,
                "index": idx,
            })
            idx += 1

    # Fallback
    if not chunks and text.strip():
        chunks.append({"text": text.strip()[:max_chars], "heading": "", "index": 0})

    return chunks


def _chunk_plain(
    text: str, max_chars: int, overlap: int
) -> List[Dict[str, Any]]:
    """Chunk plain text by paragraph boundaries."""
    paragraphs = re.split(r"\n\n+", text)
    chunks: List[Dict[str, Any]] = []
    current = ""
    idx = 0

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(current) + len(para) + 2 > max_chars and current:
            chunks.append({"text": current, "heading": "", "index": idx})
            idx += 1
            # Keep overlap from end of current chunk
            current = current[-overlap:] + "\n\n" + para if overlap else para
        else:
            current = current + "\n\n" + para if current else para

    if current.strip():
        chunks.append({"text": current.strip(), "heading": "", "index": idx})

    if not chunks and text.strip():
        for sub in _split_long(text.strip(), max_chars, overlap):
            chunks.append({"text": sub, "heading": "", "index": len(chunks)})

    return chunks


def _split_long(text: str, max_chars: int, overlap: int) -> List[str]:
    """Split text exceeding max_chars into overlapping windows."""
    if len(text) <= max_chars:
        return [text]

    parts: List[str] = []
    start = 0
    while start < len(text):
        end = start + max_chars
        # Try to break at a sentence or newline boundary
        if end < len(text):
            for sep in ["\n\n", "\n", ". ", "! ", "? "]:
                bp = text.rfind(sep, start + max_chars // 2, end)
                if bp > start:
                    end = bp + len(sep)
                    break
        parts.append(text[start:end].strip())
        start = end - overlap if overlap else end

    return [p for p in parts if p]


# ---------------------------------------------------------------------------
# Simple entity extraction (no LLM needed)
# ---------------------------------------------------------------------------

# Common stop words for entity filtering
_ENTITY_STOP = frozenset({
    "the", "and", "for", "with", "that", "this", "from", "what",
    "how", "does", "have", "has", "are", "was", "were", "been",
    "not", "but", "can", "will", "all", "any", "each", "which",
    "when", "where", "who", "why", "its", "also", "than", "then",
    "into", "only", "other", "some", "such", "new", "use", "used",
    "using", "may", "must", "should", "would", "could", "very",
    "true", "false", "none", "null", "todo", "note", "see",
})


def extract_entities(text: str) -> List[Dict[str, str]]:
    """Extract named entities from text using simple heuristics.

    Returns list of {"name": str, "label": str} dicts.
    No LLM required — uses capitalisation, patterns, and context clues.
    """
    entities: List[Dict[str, str]] = []
    seen: Set[str] = set()

    # Title-case words (proper nouns)
    words = text.split()
    for i, word in enumerate(words):
        clean = re.sub(r"[^\w\s-]", "", word).strip()
        if not clean or len(clean) < 3:
            continue
        if clean.lower() in _ENTITY_STOP:
            continue

        if clean[0].isupper() and not clean.isupper():
            # Check for multi-word entities
            name = clean
            if i + 1 < len(words):
                next_word = re.sub(r"[^\w\s-]", "", words[i + 1]).strip()
                if next_word and next_word[0:1].isupper() and len(next_word) > 2:
                    name = f"{clean} {next_word}"

            if name.lower() not in seen and name.lower() not in _ENTITY_STOP:
                seen.add(name.lower())
                entities.append({"name": name, "label": "Entity"})

    # Email addresses → Person
    for email in re.findall(r"[\w.+-]+@[\w.-]+\.\w+", text):
        local = email.split("@")[0].replace(".", " ").replace("_", " ").title()
        if local.lower() not in seen:
            seen.add(local.lower())
            entities.append({"name": local, "label": "Person"})

    # URLs → System/Project
    for url in re.findall(r"https?://[\w.-]+(?:/[\w./-]*)?", text):
        domain = url.split("//")[1].split("/")[0]
        if domain not in seen and "localhost" not in domain:
            seen.add(domain)
            entities.append({"name": domain, "label": "System"})

    return entities[:50]  # Cap to prevent explosion


# ---------------------------------------------------------------------------
# Ingest Pipeline
# ---------------------------------------------------------------------------

class IngestPipeline:
    """Chunks files and writes to L0 (FTS5), L4 (sqlite-vec), and L3 (graph).

    Usage::

        pipeline = IngestPipeline(config)
        stats = pipeline.ingest_directory("./workspace")
        # or single file:
        stats = pipeline.ingest_file("./workspace/MEMORY.md")
    """

    def __init__(
        self,
        config: Optional[RewindConfig] = None,
        embedding_fn: Optional[Callable[[str], List[float]]] = None,
    ) -> None:
        self.config = config or default_config()
        self._embedding_fn = embedding_fn
        self._db_conn: Optional[sqlite3.Connection] = None
        self._graph = None
        self._embed_dim: Optional[int] = None

    def _get_conn(self) -> sqlite3.Connection:
        """Get or create the SQLite connection for L0+L4."""
        if self._db_conn is not None:
            return self._db_conn

        db_path = os.path.expanduser(self.config.vector_db_path)
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)

        self._db_conn = sqlite3.connect(db_path, timeout=10)
        self._db_conn.execute("PRAGMA journal_mode=WAL")
        self._db_conn.execute("PRAGMA synchronous=NORMAL")
        self._ensure_schema(self._db_conn)
        return self._db_conn

    def _ensure_schema(self, conn: sqlite3.Connection) -> None:
        """Create chunks, chunks_fts, and chunks_vec tables if needed."""
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path TEXT NOT NULL,
                text TEXT NOT NULL,
                heading TEXT DEFAULT '',
                source TEXT DEFAULT 'file',
                chunk_index INTEGER DEFAULT 0,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(path);
        """)

        # FTS5 virtual table for L0
        try:
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
                USING fts5(path, text, content=chunks, content_rowid=id)
            """)
        except Exception as e:
            log.warning("FTS5 table creation failed (may already exist): %s", e)

        conn.commit()

    def _ensure_vec_table(self, conn: sqlite3.Connection, dim: int) -> bool:
        """Create the vec0 virtual table for L4 if sqlite-vec is available."""
        try:
            from rewind.utils import load_vec0
            if not load_vec0(conn):
                log.debug("sqlite-vec not available — L4 vectors will be skipped")
                return False

            conn.execute(f"""
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_vec
                USING vec0(embedding float[{dim}])
            """)
            conn.commit()
            return True
        except Exception as e:
            log.warning("vec0 table creation failed: %s", e)
            return False

    def _get_embedding_fn(self) -> Optional[Callable[[str], List[float]]]:
        """Get embedding function from config."""
        if self._embedding_fn:
            return self._embedding_fn

        cfg = self.config.embedding
        if cfg.provider == "ollama":
            try:
                import httpx

                def embed(text: str) -> List[float]:
                    resp = httpx.post(
                        f"{cfg.url}/api/embed",
                        json={"model": cfg.model, "input": text},
                        timeout=30,
                    )
                    resp.raise_for_status()
                    data = resp.json()
                    return data["embeddings"][0] if "embeddings" in data else data["embedding"]

                return embed
            except ImportError:
                log.warning("httpx not installed — embeddings unavailable")
                return None

        elif cfg.provider in ("nv_embed", "openai"):
            try:
                import httpx

                def embed(text: str) -> List[float]:
                    resp = httpx.post(
                        f"{cfg.url}/v1/embeddings",
                        json={"model": cfg.model, "input": text},
                        timeout=30,
                    )
                    resp.raise_for_status()
                    return resp.json()["data"][0]["embedding"]

                return embed
            except ImportError:
                log.warning("httpx not installed — embeddings unavailable")
                return None

        return None

    def _get_graph(self):
        """Get or create the L3 graph backend."""
        if self._graph is not None:
            return self._graph

        if not self.config.layers.l3_graph:
            return None

        try:
            from rewind.layers.l3_graph_sqlite import L3GraphSQLite
            db_path = os.path.expanduser(self.config.vector_db_path)
            graph_db = str(Path(db_path).parent / "graph.db")
            self._graph = L3GraphSQLite(graph_db)
            return self._graph
        except Exception as exc:
            log.warning("L3 graph init failed: %s", exc)
            return None

    # -- Public API -------------------------------------------------------

    def ingest_file(
        self,
        file_path: str,
        source: str = "file",
    ) -> Dict[str, int]:
        """Ingest a single file into the memory stack.

        Args:
            file_path: Path to the file to ingest.
            source: Source label (e.g. "file", "chat", "email").

        Returns:
            Stats dict: {"chunks": N, "vectors": N, "entities": N}
        """
        path = Path(file_path)
        if not path.exists():
            return {"chunks": 0, "vectors": 0, "entities": 0, "error": "file not found"}

        ext = path.suffix.lower()
        if ext not in TEXT_EXTENSIONS:
            return {"chunks": 0, "vectors": 0, "entities": 0, "error": f"unsupported extension: {ext}"}

        try:
            text = path.read_text(errors="ignore")
        except Exception as exc:
            return {"chunks": 0, "vectors": 0, "entities": 0, "error": str(exc)}

        if not text.strip():
            return {"chunks": 0, "vectors": 0, "entities": 0}

        # Chunk
        chunks = chunk_text(text, str(path))
        if not chunks:
            return {"chunks": 0, "vectors": 0, "entities": 0}

        conn = self._get_conn()
        str_path = str(path.resolve())

        # Delete existing chunks for this path (re-ingest)
        conn.execute("DELETE FROM chunks WHERE path = ?", (str_path,))

        # Insert chunks into L0 (chunks + FTS5)
        chunk_ids: List[int] = []
        for chunk in chunks:
            cursor = conn.execute(
                "INSERT INTO chunks (path, text, heading, source, chunk_index) VALUES (?, ?, ?, ?, ?)",
                (str_path, chunk["text"], chunk.get("heading", ""), source, chunk["index"]),
            )
            chunk_ids.append(cursor.lastrowid)

        # Sync FTS5
        try:
            conn.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')")
        except Exception as e:
            log.debug("FTS5 rebuild: %s", e)

        conn.commit()

        # L4: Generate embeddings and insert vectors
        vectors_written = 0
        embed_fn = self._get_embedding_fn()
        if embed_fn:
            try:
                # Get dimension from first embedding
                test_emb = embed_fn(chunks[0]["text"][:500])
                if not test_emb:
                    log.debug("Embedding service unavailable — skipping L4 vectors")
                    embed_fn = None  # disable for remaining chunks
                    raise ValueError("no embeddings")
                dim = len(test_emb)

                if self._embed_dim is None:
                    self._embed_dim = dim
                    self._ensure_vec_table(conn, dim)

                for chunk_id, chunk in zip(chunk_ids, chunks):
                    try:
                        emb = embed_fn(chunk["text"][:500])
                        blob = struct.pack(f"{len(emb)}f", *emb)
                        conn.execute(
                            "INSERT INTO chunks_vec (rowid, embedding) VALUES (?, ?)",
                            (chunk_id, blob),
                        )
                        vectors_written += 1
                    except Exception as exc:
                        log.debug("Embedding failed for chunk %d: %s", chunk_id, exc)

                conn.commit()
            except ValueError:
                pass  # no embeddings available — expected on free tier without Ollama
            except Exception as exc:
                log.debug("L4 vector ingest skipped: %s", exc)

        # L3: Extract entities and add to graph
        entities_added = 0
        graph = self._get_graph()
        if graph:
            all_entities: List[str] = []
            for chunk in chunks:
                for ent in extract_entities(chunk["text"]):
                    node_name = ent["name"]
                    graph.add_node(node_name, ent["label"])
                    all_entities.append(node_name)
                    entities_added += 1

            # Add edges between co-occurring entities within same file
            unique = list(dict.fromkeys(all_entities))  # dedup preserving order
            for i, e1 in enumerate(unique[:20]):
                for e2 in unique[i + 1:20]:
                    graph.add_edge(e1, e2, "CO_OCCURS")

        return {
            "chunks": len(chunks),
            "vectors": vectors_written,
            "entities": entities_added,
        }

    def ingest_directory(
        self,
        directory: str,
        source: str = "file",
        recursive: bool = True,
    ) -> Dict[str, Any]:
        """Ingest all supported files from a directory.

        Args:
            directory: Path to the directory to scan.
            source: Source label for all files.
            recursive: Whether to recurse into subdirectories.

        Returns:
            Stats dict with totals and per-file breakdown.
        """
        root = Path(directory).resolve()
        if not root.is_dir():
            return {"error": f"Not a directory: {directory}", "files": 0}

        start = time.time()
        totals = {"files": 0, "chunks": 0, "vectors": 0, "entities": 0, "errors": 0}
        file_stats: List[Dict] = []

        pattern = root.rglob("*") if recursive else root.glob("*")

        for path in sorted(pattern):
            if not path.is_file():
                continue

            # Skip hidden and excluded directories
            parts = path.relative_to(root).parts
            if any(p.startswith(".") or p in SKIP_DIRS for p in parts[:-1]):
                continue

            ext = path.suffix.lower()
            if ext not in TEXT_EXTENSIONS:
                continue

            stats = self.ingest_file(str(path), source)
            totals["files"] += 1
            totals["chunks"] += stats.get("chunks", 0)
            totals["vectors"] += stats.get("vectors", 0)
            totals["entities"] += stats.get("entities", 0)
            if "error" in stats:
                totals["errors"] += 1

            if stats.get("chunks", 0) > 0:
                file_stats.append({"path": str(path), **stats})

            # Progress logging every 50 files
            if totals["files"] % 50 == 0:
                log.info(
                    "Ingest progress: %d files, %d chunks, %d vectors",
                    totals["files"], totals["chunks"], totals["vectors"],
                )

        elapsed = time.time() - start
        totals["elapsed_seconds"] = round(elapsed, 2)
        totals["files_detail"] = file_stats

        log.info(
            "Ingest complete: %d files → %d chunks, %d vectors, %d entities in %.1fs",
            totals["files"], totals["chunks"], totals["vectors"],
            totals["entities"], elapsed,
        )

        return totals


    def close(self) -> None:
        """Close all connections."""
        if self._db_conn:
            self._db_conn.close()
            self._db_conn = None
        if self._graph:
            self._graph.close()
            self._graph = None
