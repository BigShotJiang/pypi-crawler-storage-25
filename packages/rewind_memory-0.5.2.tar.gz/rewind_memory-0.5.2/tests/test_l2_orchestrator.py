"""Test L2 orchestrator — fusion, dedup, scoring, entity extraction."""
from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class MockResult:
    path: str = ""
    text: str = ""
    score: float = 0.0
    layer: str = ""
    source: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


def fuse_results(layer_results: dict[str, list[MockResult]], limit: int = 16) -> list[MockResult]:
    """Simplified L2 fusion: merge, dedup by path, re-score, sort."""
    seen = {}
    for layer_name, results in layer_results.items():
        for r in results:
            key = r.path or r.text[:80]
            if key in seen:
                # Boost score for multi-layer hits
                seen[key].score = max(seen[key].score, r.score) * 1.2
                seen[key].metadata["multi_layer"] = True
            else:
                seen[key] = MockResult(
                    path=r.path, text=r.text, score=r.score,
                    layer=layer_name, source=r.source, metadata=dict(r.metadata),
                )
    fused = sorted(seen.values(), key=lambda r: r.score, reverse=True)
    return fused[:limit]


def extract_entities(text: str) -> list[str]:
    """Naive entity extraction: capitalised multi-word sequences."""
    words = text.split()
    entities = []
    current = []
    for i, w in enumerate(words):
        if w[0].isupper() and len(w) > 1 and i > 0:
            current.append(w)
        else:
            if len(current) >= 2:
                entities.append(" ".join(current))
            current = []
    if len(current) >= 2:
        entities.append(" ".join(current))
    return entities


def adaptive_score(query: str, result: MockResult) -> float:
    """Boost conversational queries (questions) towards graph layer."""
    base = result.score
    is_question = query.strip().endswith("?") or query.lower().startswith(("who", "what", "where", "when", "why", "how"))
    if is_question and result.layer in ("L3_graph", "L3"):
        base *= 1.5
    return base


class TestFusion:
    def test_dedup_by_path(self):
        layers = {
            "L0": [MockResult(path="/a.md", text="hello", score=0.8, layer="L0")],
            "L1": [MockResult(path="/a.md", text="hello", score=0.6, layer="L1")],
        }
        fused = fuse_results(layers)
        assert len(fused) == 1
        assert fused[0].metadata.get("multi_layer") is True

    def test_multi_layer_boost(self):
        layers = {
            "L0": [MockResult(path="/a.md", text="hello", score=0.5)],
            "L1": [MockResult(path="/a.md", text="hello", score=0.7)],
        }
        fused = fuse_results(layers)
        assert fused[0].score > 0.7  # boosted

    def test_limit_respected(self):
        layers = {
            "L0": [MockResult(path=f"/{i}.md", score=0.5) for i in range(20)],
        }
        fused = fuse_results(layers, limit=5)
        assert len(fused) == 5

    def test_scoring_order(self):
        layers = {
            "L0": [
                MockResult(path="/low.md", score=0.1),
                MockResult(path="/high.md", score=0.9),
            ],
        }
        fused = fuse_results(layers)
        assert fused[0].path == "/high.md"


class TestEntityExtraction:
    def test_extract_multi_word(self):
        entities = extract_entities("The Hebbian Learning principle applies here")
        assert "Hebbian Learning" in entities

    def test_no_single_words(self):
        entities = extract_entities("Hello world this is a test")
        # No consecutive capitalised words of length >= 2
        assert len(entities) == 0

    def test_empty_input(self):
        assert extract_entities("") == []


class TestAdaptiveScoring:
    def test_question_boosts_graph(self):
        r = MockResult(path="/x.md", score=1.0, layer="L3_graph")
        boosted = adaptive_score("Who invented Hebbian learning?", r)
        assert boosted == 1.5

    def test_non_question_no_boost(self):
        r = MockResult(path="/x.md", score=1.0, layer="L3_graph")
        score = adaptive_score("Hebbian learning overview", r)
        assert score == 1.0

    def test_question_no_boost_other_layer(self):
        r = MockResult(path="/x.md", score=1.0, layer="L0")
        score = adaptive_score("Who invented it?", r)
        assert score == 1.0
