class User:
    def __init__(self, client, data):
        self.client = client
        self.discord_id = data["discord_id"]
        self.luduvo_id = data["luduvo_id"]
        self.created_at = data["created_at"]

    def __str__(self):
        return f"User(discord_id={self.discord_id}, luduvo_id={self.luduvo_id})"

    def __repr__(self):
        return self.__str__()


class VerifyingUser:
    def __init__(self, client, data):
        self.client = client
        self.discord_id = data["discord_id"]
        self.luduvo_id = data["luduvo_id"]
        self.code = data["code"]
