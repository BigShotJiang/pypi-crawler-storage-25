class VerificationLog:
    def __init__(self, data: dict):
        self.discord_id = data.get("discord_id")
        self.luduvo_id = data.get("luduvo_id")
        self.success = data.get("success")


class CommandLog:
    def __init__(self, data: dict):
        self.command = data.get("command")
        self.user_id = data.get("user_id")
        self.guild_id = data.get("guild_id")
        self.channel_id = data.get("channel_id")
        self.success = data.get("success")


class ErrorLog:
    def __init__(self, data: dict):
        self.error_message = data.get("error_message")
        self.stack_trace = data.get("stack_trace")
