class Guild:
    def __init__(self, client, data):
        self.client = client
        self.guild_id = data["guild_id"]
        self.owner_id = data["owner_id"]
        self.created_at = data["created_at"]

    def __str__(self):
        return f"Guild(id={self.guild_id}, owner_id={self.owner_id})"

    def __repr__(self):
        return self.__str__()
