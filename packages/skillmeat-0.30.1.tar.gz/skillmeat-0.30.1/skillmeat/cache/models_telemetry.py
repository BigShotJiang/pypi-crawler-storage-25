"""SQLAlchemy ORM models for telemetry tables (PostgreSQL).

This module defines enterprise-tier ORM models that store execution telemetry
and aggregated agentic metrics. These models share the EnterpriseBase
DeclarativeBase from models_enterprise.py so that they participate in the
same PostgreSQL metadata graph and never contaminate the SQLite schema.

Tables defined here:
    - ExecutionOutcome          (execution_outcomes)         — TEL-1.1
    - ProjectAgenticMetrics     (project_agentic_metrics)    — TEL-1.2

Design invariants:
    - All tables are PostgreSQL-only (UUID PKs, JSONB, TIMESTAMPTZ).
    - ExecutionOutcome rows are append-only; status transitions are final once
      the row is written. Do not UPDATE status outside of the ingestion path.
    - ProjectAgenticMetrics uses a unique constraint on
      (project_id, workflow_id, period_start, period_end) to support
      INSERT ... ON CONFLICT DO UPDATE (upsert) idempotency.
    - EnterpriseBase is the single shared base. Do NOT use the local-mode
      Base from models.py for these models.

Exports:
    ExecutionOutcome: Per-execution result record for telemetry analytics.
    ProjectAgenticMetrics: Aggregated agentic effectiveness metrics per project.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import DateTime, Float, Index, Integer, String, UniqueConstraint, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from skillmeat.cache.models_enterprise import EnterpriseBase

# =============================================================================
# ExecutionOutcome model  (TEL-1.1)
# =============================================================================


class ExecutionOutcome(EnterpriseBase):
    """Per-execution telemetry record for workflow and bundle runs.

    Each row captures the result, timing, cost, and arbitrary metrics for a
    single execution identified by a unique ``execution_id`` supplied by the
    calling agent or orchestrator.

    Status vocabulary:
        "success"  — execution completed without errors.
        "failure"  — execution completed but produced an error result.
        "partial"  — execution completed but some steps were skipped or errored.
        "timeout"  — execution was terminated due to a timeout.
        "error"    — execution could not start or encountered an infrastructure error.

    Attributes:
        id:               UUID primary key, server-generated via gen_random_uuid().
        execution_id:     Caller-supplied unique token for idempotent writes.
        project_id:       Identifier of the project that triggered this execution.
        workflow_id:      Optional workflow identifier; NULL for ad-hoc runs.
        bundle_id:        Optional bundle identifier; NULL for non-bundle executions.
        status:           Final execution status from the status vocabulary above.
        metrics:          Arbitrary JSONB payload for execution-specific metrics.
        started_at:       Timezone-aware wall-clock start time of the execution.
        completed_at:     Timezone-aware wall-clock end time of the execution.
        duration_seconds: Wall-clock execution duration in seconds.
        cost_usd:         Estimated monetary cost of the execution in USD.
        client_version:   Version string of the agent/CLI client that ran the execution.
        created_at:       Timezone-aware row creation timestamp (server default: now()).
        updated_at:       Timezone-aware last-modified timestamp (app-managed).

    Constraints:
        uq_execution_outcomes_execution_id:
            UNIQUE (execution_id) — enforces idempotency for ingestion.

    Indexes:
        uq_execution_outcomes_execution_id:    UNIQUE (execution_id)
        idx_execution_outcomes_project_id:     (project_id)
        idx_execution_outcomes_project_workflow: (project_id, workflow_id)
    """

    __tablename__ = "execution_outcomes"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique row identifier",
    )
    execution_id: Mapped[str] = mapped_column(
        String(256),
        nullable=False,
        comment="Caller-supplied unique execution token; enforces ingestion idempotency",
    )

    # -------------------------------------------------------------------------
    # Scope
    # -------------------------------------------------------------------------

    project_id: Mapped[str] = mapped_column(
        String(256),
        nullable=False,
        comment="Project identifier that owns this execution record",
    )
    workflow_id: Mapped[Optional[str]] = mapped_column(
        String(256),
        nullable=True,
        comment="Workflow identifier; NULL for ad-hoc or non-workflow executions",
    )
    bundle_id: Mapped[Optional[str]] = mapped_column(
        String(256),
        nullable=True,
        comment="Bundle identifier; NULL when the execution is not bundle-driven",
    )

    # -------------------------------------------------------------------------
    # Result
    # -------------------------------------------------------------------------

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        comment="Final execution status: success | failure | partial | timeout | error",
    )
    metrics: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
        comment="Arbitrary execution-specific metrics payload (token counts, step results, etc.)",
    )

    # -------------------------------------------------------------------------
    # Timing
    # -------------------------------------------------------------------------

    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware wall-clock start time of the execution",
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware wall-clock end time of the execution",
    )
    duration_seconds: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment="Wall-clock execution duration in seconds; derived from started_at/completed_at",
    )

    # -------------------------------------------------------------------------
    # Cost and client metadata
    # -------------------------------------------------------------------------

    cost_usd: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment="Estimated monetary cost of the execution in USD",
    )
    client_version: Mapped[Optional[str]] = mapped_column(
        String(50),
        nullable=True,
        comment="Version string of the agent or CLI client that submitted this record",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware row creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Unique: one row per execution_id; supports idempotent ingestion
        UniqueConstraint(
            "execution_id",
            name="uq_execution_outcomes_execution_id",
        ),
        # B-tree: primary project filter (covers most listing queries)
        Index(
            "idx_execution_outcomes_project_id",
            "project_id",
        ),
        # B-tree: workflow-scoped execution history within a project
        Index(
            "idx_execution_outcomes_project_workflow",
            "project_id",
            "workflow_id",
        ),
    )

    def __repr__(self) -> str:
        return (
            f"ExecutionOutcome("
            f"id={self.id!r}, "
            f"execution_id={self.execution_id!r}, "
            f"project_id={self.project_id!r}, "
            f"status={self.status!r})"
        )


# =============================================================================
# ProjectAgenticMetrics model  (TEL-1.2)
# =============================================================================


class ProjectAgenticMetrics(EnterpriseBase):
    """Aggregated agentic effectiveness metrics per project and time period.

    Each row is a pre-computed rollup summarising execution outcomes for a
    specific (project_id, workflow_id, period_start, period_end) slice.
    The unique constraint on that tuple enables idempotent upserts from the
    telemetry aggregation job.

    Attributes:
        id:                   UUID primary key, server-generated via gen_random_uuid().
        project_id:           Project whose executions are summarised.
        workflow_id:          Workflow scope for the rollup; NULL = project-wide aggregate.
        bundle_id:            Optional bundle scope; NULL = not bundle-scoped.
        execution_count:      Total number of executions in the period.
        success_rate:         Fraction of executions with status "success" (0.0–1.0).
        avg_duration_seconds: Mean wall-clock duration across executions in the period.
        avg_cost_usd:         Mean monetary cost across executions in the period.
        effectiveness_score:  Computed composite score (domain-defined, 0.0–1.0 range).
        rollup_computed_at:   Timezone-aware timestamp of the most recent rollup computation.
        period_start:         Inclusive start of the aggregation time window.
        period_end:           Exclusive end of the aggregation time window.
        created_at:           Timezone-aware row creation timestamp (server default: now()).
        updated_at:           Timezone-aware last-modified timestamp (app-managed).

    Constraints:
        uq_project_agentic_metrics_period:
            UNIQUE (project_id, workflow_id, period_start, period_end) — supports
            INSERT ... ON CONFLICT DO UPDATE (upsert) for idempotent rollup writes.

    Indexes:
        idx_project_agentic_metrics_project_workflow: (project_id, workflow_id)
        uq_project_agentic_metrics_period:            UNIQUE (project_id, workflow_id, period_start, period_end)
    """

    __tablename__ = "project_agentic_metrics"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique row identifier",
    )

    # -------------------------------------------------------------------------
    # Scope
    # -------------------------------------------------------------------------

    project_id: Mapped[str] = mapped_column(
        String(256),
        nullable=False,
        comment="Project identifier whose executions are aggregated",
    )
    workflow_id: Mapped[Optional[str]] = mapped_column(
        String(256),
        nullable=True,
        comment="Workflow scope for this rollup; NULL = project-wide aggregate",
    )
    bundle_id: Mapped[Optional[str]] = mapped_column(
        String(256),
        nullable=True,
        comment="Bundle scope for this rollup; NULL = not bundle-scoped",
    )

    # -------------------------------------------------------------------------
    # Aggregated metrics
    # -------------------------------------------------------------------------

    execution_count: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default=text("0"),
        comment="Total executions recorded in the period",
    )
    success_rate: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment="Fraction of executions with status 'success'; range 0.0–1.0",
    )
    avg_duration_seconds: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment="Mean wall-clock duration in seconds across executions in the period",
    )
    avg_cost_usd: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment="Mean monetary cost in USD across executions in the period",
    )
    effectiveness_score: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment="Composite effectiveness score (domain-defined); range 0.0–1.0",
    )

    # -------------------------------------------------------------------------
    # Rollup bookkeeping
    # -------------------------------------------------------------------------

    rollup_computed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timestamp of the most recent rollup computation for this row",
    )

    # -------------------------------------------------------------------------
    # Time window
    # -------------------------------------------------------------------------

    period_start: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        comment="Inclusive start of the aggregation time window",
    )
    period_end: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        comment="Exclusive end of the aggregation time window",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware row creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Unique: one rollup row per (project, workflow, period) slice;
        # enables INSERT ... ON CONFLICT DO UPDATE upsert idempotency
        UniqueConstraint(
            "project_id",
            "workflow_id",
            "period_start",
            "period_end",
            name="uq_project_agentic_metrics_period",
        ),
        # B-tree: workflow-scoped metric history within a project
        Index(
            "idx_project_agentic_metrics_project_workflow",
            "project_id",
            "workflow_id",
        ),
    )

    def __repr__(self) -> str:
        return (
            f"ProjectAgenticMetrics("
            f"id={self.id!r}, "
            f"project_id={self.project_id!r}, "
            f"workflow_id={self.workflow_id!r}, "
            f"period_start={self.period_start!r}, "
            f"period_end={self.period_end!r})"
        )
