"""FQAN (Fully Qualified Artifact Name) utilities for DVCS Phase 3.

An FQAN uniquely identifies an artifact across the 4-tier collection
inheritance hierarchy.  The canonical format is::

    scope://namespace/name@version

Examples::

    marketplace://anthropics/canvas@v2.1.0
    enterprise://acme-corp/coding-standards@latest
    team://platform-eng/deploy-helpers@abc1234
    dev://personal/my-script@0.0.1
    project://local/scratch-agent@v0.1

The ``local`` scope is a parser-level alias that normalises to ``project``.

Public API
----------
- :func:`compute_fqan` — assemble an FQAN string from its components.
- :func:`parse_fqan` — decompose an FQAN string into a :class:`ParsedFQAN`.
- :class:`ParsedFQAN` — immutable NamedTuple for parsed FQAN components.

Both functions validate input strictly and raise :exc:`ValueError` on
malformed input.  No external dependencies are required.
"""

from __future__ import annotations

import re
from typing import NamedTuple

__all__ = [
    "ParsedFQAN",
    "compute_fqan",
    "parse_fqan",
]

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Valid collection tier identifiers (mirrors ``CollectionTier`` enum values).
#: ``local`` is NOT a valid FQAN scope — it normalises to ``project`` during
#: parsing.
_VALID_SCOPES = frozenset({"marketplace", "enterprise", "team", "dev", "project"})

#: ``local`` normalises to ``project`` at parse time.
_SCOPE_ALIASES: dict[str, str] = {"local": "project"}

#: Compiled regex for FQAN validation.
#: Captures: (scope, namespace, name, version)
_FQAN_RE = re.compile(
    r"""
    ^
    (?P<scope>[a-z][a-z0-9_-]*)   # scope: starts with lowercase letter
    ://
    (?P<namespace>[^/]+)           # namespace: any chars except '/'
    /
    (?P<name>[^@]+)                # name: any chars except '@'
    @
    (?P<version>.+)                # version: remainder of string
    $
    """,
    re.VERBOSE,
)


# ---------------------------------------------------------------------------
# ParsedFQAN
# ---------------------------------------------------------------------------


class ParsedFQAN(NamedTuple):
    """Immutable components of a parsed FQAN string.

    Attributes:
        scope: Normalised collection tier (one of the five ``CollectionTier``
               values).  ``local`` is normalised to ``project``.
        namespace: Namespace slug within the tier (e.g. ``"platform-eng"``).
        name: Artifact name (e.g. ``"canvas"``).
        version: Version specifier (e.g. ``"v2.1.0"``, ``"latest"``,
                 a SHA prefix).

    Example:
        >>> p = parse_fqan("team://platform-eng/canvas@v1.2")
        >>> p.scope
        'team'
        >>> p.namespace
        'platform-eng'
        >>> p.name
        'canvas'
        >>> p.version
        'v1.2'
    """

    scope: str
    namespace: str
    name: str
    version: str


# ---------------------------------------------------------------------------
# compute_fqan
# ---------------------------------------------------------------------------


def compute_fqan(tier: str, namespace: str, name: str, version: str) -> str:
    """Compute a canonical FQAN string from its components.

    The result has the format::

        scope://namespace/name@version

    Args:
        tier: Collection tier (``'marketplace'``, ``'enterprise'``,
              ``'team'``, ``'dev'``, or ``'project'``).  The alias
              ``'local'`` is accepted and normalised to ``'project'``.
        namespace: Namespace slug within the tier.  Must be non-empty and
                   must not contain ``'/'``.
        name: Artifact name.  Must be non-empty and must not contain
              ``'@'``.
        version: Version specifier.  Must be non-empty.

    Returns:
        The FQAN string, e.g. ``'team://platform-eng/canvas@v1.2'``.

    Raises:
        ValueError: If *tier* is not a recognised scope, or any component
                    fails validation.

    Example:
        >>> compute_fqan("team", "platform-eng", "canvas", "v1.2")
        'team://platform-eng/canvas@v1.2'
        >>> compute_fqan("local", "personal", "my-tool", "latest")
        'project://personal/my-tool@latest'
    """
    # Normalise aliases (local → project)
    normalised_tier = _SCOPE_ALIASES.get(tier, tier)

    if normalised_tier not in _VALID_SCOPES:
        raise ValueError(
            f"Invalid collection tier {tier!r}. "
            f"Must be one of: {sorted(_VALID_SCOPES)} (or the alias 'local')."
        )
    if not namespace:
        raise ValueError("namespace must be non-empty.")
    if "/" in namespace:
        raise ValueError(f"namespace must not contain '/'; got {namespace!r}.")
    if not name:
        raise ValueError("name must be non-empty.")
    if "@" in name:
        raise ValueError(f"name must not contain '@'; got {name!r}.")
    if not version:
        raise ValueError("version must be non-empty.")

    return f"{normalised_tier}://{namespace}/{name}@{version}"


# ---------------------------------------------------------------------------
# parse_fqan
# ---------------------------------------------------------------------------


def parse_fqan(fqan: str) -> ParsedFQAN:
    """Parse an FQAN string into its components.

    The ``local`` scope alias is normalised to ``project`` during parsing.

    Args:
        fqan: The FQAN string to parse, e.g.
              ``'team://platform-eng/canvas@v1.2'``.

    Returns:
        A :class:`ParsedFQAN` NamedTuple with ``scope``, ``namespace``,
        ``name``, and ``version`` fields.

    Raises:
        ValueError: If *fqan* does not match the expected format, the scope
                    is not a recognised tier, or any component is empty.

    Example:
        >>> p = parse_fqan("marketplace://anthropics/canvas@v2.1.0")
        >>> p.scope, p.namespace, p.name, p.version
        ('marketplace', 'anthropics', 'canvas', 'v2.1.0')

        >>> parse_fqan("local://personal/my-tool@latest").scope
        'project'

        >>> parse_fqan("bad-fqan")  # raises
        Traceback (most recent call last):
            ...
        ValueError: ...
    """
    if not fqan or not isinstance(fqan, str):
        raise ValueError(f"fqan must be a non-empty string; got {fqan!r}.")

    match = _FQAN_RE.match(fqan)
    if match is None:
        raise ValueError(
            f"Malformed FQAN {fqan!r}. "
            "Expected format: scope://namespace/name@version"
        )

    raw_scope = match.group("scope")
    namespace = match.group("namespace")
    name = match.group("name")
    version = match.group("version")

    # Normalise aliases (local → project)
    scope = _SCOPE_ALIASES.get(raw_scope, raw_scope)

    if scope not in _VALID_SCOPES:
        raise ValueError(
            f"Unknown FQAN scope {raw_scope!r} in {fqan!r}. "
            f"Valid scopes: {sorted(_VALID_SCOPES)} (or 'local' as alias for 'project')."
        )

    # Secondary validation: none of the components should be empty after
    # regex capture (the regex enforces non-empty via [^/]+ etc., but we
    # double-check for clarity).
    if not namespace:
        raise ValueError(f"FQAN namespace is empty in {fqan!r}.")
    if not name:
        raise ValueError(f"FQAN name is empty in {fqan!r}.")
    if not version:
        raise ValueError(f"FQAN version is empty in {fqan!r}.")

    return ParsedFQAN(scope=scope, namespace=namespace, name=name, version=version)
