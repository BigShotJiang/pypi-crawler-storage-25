"""SQLAlchemy ORM models for SkillMeat cache database.

This module defines SQLAlchemy ORM models that map to the cache database schema
defined in schema.py. These models provide type-safe data access for the
CacheRepository and enable relationship-based queries.

Models:
    - Project: Project metadata and status
    - Artifact: Artifact metadata per project
    - ArtifactMetadata: Extended artifact metadata (YAML frontmatter)
    - Collection: User-defined artifact collections
    - Group: Custom grouping of artifacts within collections
    - GroupArtifact: Association between groups and artifacts with ordering
    - ProjectTemplate: Reusable project templates with artifact deployment patterns
    - TemplateEntity: Association between templates and artifacts with deployment metadata
    - MarketplaceEntry: Cached marketplace artifact listings
    - MarketplaceSource: GitHub repository sources for marketplace artifacts
    - MarketplaceCatalogEntry: Detected artifacts from marketplace sources
    - UserRating: User ratings and feedback for artifacts
    - CommunityScore: Aggregated scoring from external sources
    - MatchHistory: Artifact matching query history for analytics
    - CacheMetadata: Cache system metadata
    - CompositeArtifact: Deployable multi-artifact bundle (composite-artifact-infrastructure-v1)
    - CompositeMembership: Child-artifact membership within a CompositeArtifact
    - BundleEntity: Publishable, versioned artifact bundle for distribution (ADR-008)
    - BundleMembership: Artifact membership record within a BundleEntity (ADR-008)
    - DeploymentSet: Named, ordered set of artifacts/groups for batch deployment (deployment-sets-v1)
    - DeploymentSetMember: Polymorphic member entry within a DeploymentSet
    - CustomColor: User-defined hex colors for the site-wide color palette registry
    - DuplicatePair: Persisted record of a similar/duplicate artifact pair with optional ignored flag
    - SimilarityCache: Cached pairwise composite similarity scores with breakdown JSON (SSO-2.2)
    - AttestationRecord: Owner-scoped attestation metadata for an artifact (skillbom-attestation)
    - ArtifactHistoryEvent: Immutable audit log entries for artifact lifecycle events (skillbom-attestation)
    - BomSnapshot: Point-in-time Bill-of-Materials snapshots (skillbom-attestation)
    - AttestationPolicy: Enterprise policy for enforcing attestation requirements (skillbom-attestation)
    - BomMetadata: BOM version and format metadata (skillbom-attestation)
    - ScopeValidator: Utility model for RBAC scope pattern validation (skillbom-attestation)
    - DriftCheckResult: Drift detection results for a DeploymentSet (backstage-plugin-v2)
    - ScaffoldTemplate: Backstage scaffold template configuration linked to a BundleEntity (template-management)
    - VersionSet: Logical grouping of related ArtifactVersions with configurable depth limit (artifact-vcs-v2)
    - ArtifactCollectionVersion: Per-artifact pointer to current collection-side version (artifact-vcs-v2)
    - ProjectVersionDeployment: Append-only log of content-addressed deployment events (artifact-vcs-v2)
    - BundleCommit: Atomic snapshot of a composite artifact's member state at a point in time (DVCS-2.1)
    - BundleCommitMember: Per-member payload row within a BundleCommit snapshot (DVCS-2.1)
    - ArtifactDependency: DAG edge table for cross-tier dependency traversal (DVCS-2.1)
    - SyncDebounceEntry: DB-backed debounce state for sync-driven version capture (dvcs-unified-sync)
    - SyncCaptureConfig: Per-scope configuration overrides for the sync-capture subsystem (SYNC-5.2)

Usage:
    >>> from skillmeat.cache.models import get_session, Project, Artifact
    >>> session = get_session()
    >>> try:
    ...     projects = session.query(Project).filter_by(status='active').all()
    ...     for project in projects:
    ...         print(f"Project: {project.name}")
    ...         for artifact in project.artifacts:
    ...             print(f"  - {artifact.name} ({artifact.type})")
    ... finally:
    ...     session.close()

Note:
    These models require SQLAlchemy 2.0+. For Python 3.9 compatibility,
    use `from __future__ import annotations` for forward references.
"""

from __future__ import annotations

import enum
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from skillmeat.core.clone_target import CloneTarget

from skillmeat.cache.auth_types import OwnerType, Visibility
from skillmeat.cache.column_types import EncryptedString

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    LargeBinary,
    String,
    Text,
    TypeDecorator,
    UniqueConstraint,
    create_engine,
    event,
    text,
)
from sqlalchemy.engine import Engine
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    mapped_column,
    relationship,
    sessionmaker,
)


class TSVectorType(TypeDecorator):
    """Dialect-adaptive TSVECTOR type.

    On PostgreSQL: uses native TSVECTOR for full-text search.
    On SQLite: uses Text (column never populated, but prevents compilation errors).

    This allows the same model definition to work with both dialects without
    conditional column definitions or model modifications.
    """

    impl = Text  # Default/fallback implementation
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            from sqlalchemy.dialects.postgresql import TSVECTOR

            return dialect.type_descriptor(TSVECTOR())
        else:
            # SQLite and other dialects: use Text as a no-op placeholder
            return dialect.type_descriptor(Text())


# =============================================================================
# Constants
# =============================================================================

# Default collection for artifacts not explicitly assigned to a collection
DEFAULT_COLLECTION_ID = "default"
DEFAULT_COLLECTION_NAME = "Default Collection"


# =============================================================================
# Base Class
# =============================================================================


class Base(DeclarativeBase):
    """Base class for all ORM models.

    Provides common functionality for all cache database models.
    """

    pass


# =============================================================================
# ORM Models
# =============================================================================


class Project(Base):
    """Project metadata and cache status.

    Represents a Claude Code project (.claude directory) tracked in the cache.
    Each project can have multiple artifacts deployed to it.

    Attributes:
        id: Unique project identifier (primary key)
        name: Human-readable project name
        path: Absolute filesystem path (unique)
        description: Optional project description
        created_at: Timestamp when project was first cached
        updated_at: Timestamp when project was last updated
        last_fetched: Timestamp when artifacts were last fetched
        status: Project status ('active', 'stale', or 'error')
        error_message: Error message if status is 'error'
        artifacts: List of artifacts deployed to this project

    Indexes:
        - idx_projects_status: Fast filtering by status
        - idx_projects_last_fetched: TTL-based refresh queries
        - idx_projects_path (UNIQUE): One cache entry per project path
    """

    __tablename__ = "projects"

    # Primary key
    id: Mapped[str] = mapped_column(String, primary_key=True)

    # Core fields
    name: Mapped[str] = mapped_column(String, nullable=False)
    path: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )
    last_fetched: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Status tracking
    status: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default="active",
        server_default="active",
    )
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Ownership and visibility
    owner_id: Mapped[Optional[str]] = mapped_column(String, nullable=True, default=None)
    owner_type: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default=OwnerType.user.value
    )
    visibility: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default=Visibility.private.value
    )

    # Relationships
    artifacts: Mapped[List["Artifact"]] = relationship(
        "Artifact",
        back_populates="project",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    deployment_profiles: Mapped[List["DeploymentProfile"]] = relationship(
        "DeploymentProfile",
        back_populates="project",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "status IN ('active', 'stale', 'error')",
            name="check_project_status",
        ),
    )

    def __repr__(self) -> str:
        """Return string representation of Project."""
        return (
            f"<Project(id={self.id!r}, name={self.name!r}, "
            f"path={self.path!r}, status={self.status!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert Project to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the project
        """
        return {
            "id": self.id,
            "name": self.name,
            "path": self.path,
            "description": self.description,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "last_fetched": (
                self.last_fetched.isoformat() if self.last_fetched else None
            ),
            "status": self.status,
            "error_message": self.error_message,
            "artifacts": [artifact.to_dict() for artifact in self.artifacts],
            "deployment_profiles": [
                profile.to_dict() for profile in self.deployment_profiles
            ],
        }


class Artifact(Base):
    """Artifact metadata for a project.

    Represents a deployed artifact (skill, command, agent, etc.) within a project.
    Tracks version information and modification status.

    Attributes:
        id: Unique artifact identifier (primary key, type:name composite key)
        uuid: Stable UUID for cross-context identity (32-char hex, globally unique)
        project_id: Foreign key to projects.id
        name: Artifact name
        type: Artifact type (skill, command, agent, mcp_server, hook)
        source: Optional source identifier (e.g., "github:user/repo/path")
        deployed_version: Version string deployed to project
        upstream_version: Latest version available in collection
        is_outdated: True if deployed_version != upstream_version
        local_modified: True if artifact has local modifications
        created_at: Timestamp when artifact was first cached
        updated_at: Timestamp when artifact was last updated
        project: Related Project object
        metadata: Related ArtifactMetadata object

    Indexes:
        - idx_artifacts_project_id: Join performance
        - idx_artifacts_type: Filter by artifact type
        - idx_artifacts_is_outdated: Find artifacts needing updates
        - idx_artifacts_updated_at: Sort by recency
        - idx_artifacts_project_type: Composite for project+type queries
        - idx_artifacts_outdated_type: Composite for outdated+type queries
    """

    __tablename__ = "artifacts"

    # Primary key
    id: Mapped[str] = mapped_column(String, primary_key=True)

    # Stable cross-context identity (ADR-007)
    uuid: Mapped[str] = mapped_column(
        String,
        unique=True,
        nullable=False,
        default=lambda: uuid.uuid4().hex,
        index=True,
    )

    # Foreign key
    project_id: Mapped[str] = mapped_column(
        String, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False
    )

    # Core fields
    name: Mapped[str] = mapped_column(String, nullable=False)
    type: Mapped[str] = mapped_column(String, nullable=False)
    source: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Version tracking
    deployed_version: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    upstream_version: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Status flags
    is_outdated: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="0"
    )
    local_modified: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="0"
    )

    # Context entity fields
    path_pattern: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    auto_load: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="0"
    )
    category: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    content_hash: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    content: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    context_module_id: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        index=True,
        comment=(
            "Optional FK to context_modules.id. When set, this context entity "
            "belongs to the specified context module and can be filtered by "
            "GET /api/v1/context-entities?module_id=<id>."
        ),
    )
    core_content: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment=(
            "Platform-agnostic content before assembly. "
            "When modular_content_architecture is enabled, this stores the raw "
            "author-supplied content and `content` holds the assembled/cached output "
            "for the default target platform."
        ),
    )
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    target_platforms: Mapped[Optional[List[str]]] = mapped_column(JSON, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Ownership and visibility
    owner_id: Mapped[Optional[str]] = mapped_column(String, nullable=True, default=None)
    owner_type: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default=OwnerType.user.value
    )
    visibility: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default=Visibility.private.value
    )
    enforce_override: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="false"
    )

    # Latest deployment pointer (artifact-vcs-v2) — nullable for backward compat.
    # Set to the most recent ProjectVersionDeployment.id for this artifact.
    # NOTE: No SQLAlchemy-level FK constraint here — the circular reference
    # (Artifact -> ProjectVersionDeployment -> Artifact) causes issues with
    # SQLite test fixtures that selectively create tables.  The FK is enforced
    # at the DB level by migration 20260327_0002_artifact_vcs_v2 only.
    latest_deployment_id: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="FK to project_version_deployments.id (enforced by migration, not ORM)",
    )

    # DVCS Phase 3 — TierCollection / FQAN fields (DVCS-3.1)
    # -------------------------------------------------------------------------
    # collection_tier: which tier of the 4-tier inheritance hierarchy this
    # artifact belongs to.  CHECK constraint mirrors CollectionTier enum values.
    collection_tier: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment=(
            "DVCS collection tier: 'marketplace'|'enterprise'|'team'|'dev'|'project'. "
            "Mirrors skillmeat.core.enums.CollectionTier."
        ),
    )
    # namespace: slug that identifies the namespace within the tier
    # (e.g. 'platform-eng' for team tier, 'personal' for dev tier).
    namespace: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Namespace slug within the collection_tier (e.g. 'platform-eng').",
    )
    # fqan: application-computed canonical DVCS address.
    # Format: scope://namespace/name@version  (e.g. team://platform-eng/canvas@v1.2)
    # This column is populated by FQANResolverService; it is never set directly
    # by the ORM.  The lightweight CHECK constraint validates the format but
    # does NOT re-validate every character — full validation lives in fqan_utils.py.
    fqan: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment=(
            "Canonical FQAN: scope://namespace/name@version. "
            "Application-computed; see skillmeat/cache/fqan_utils.py."
        ),
    )

    # Relationships
    project: Mapped["Project"] = relationship("Project", back_populates="artifacts")
    artifact_metadata: Mapped[Optional["ArtifactMetadata"]] = relationship(
        "ArtifactMetadata",
        back_populates="artifact",
        cascade="all, delete-orphan",
        uselist=False,
        lazy="selectin",
    )
    collections: Mapped[List["Collection"]] = relationship(
        "Collection",
        secondary="collection_artifacts",
        primaryjoin="Artifact.uuid == foreign(CollectionArtifact.artifact_uuid)",
        secondaryjoin="foreign(CollectionArtifact.collection_id) == Collection.id",
        viewonly=True,
        lazy="select",
    )
    tags: Mapped[List["Tag"]] = relationship(
        "Tag",
        secondary="artifact_tags",
        primaryjoin="Artifact.uuid == foreign(ArtifactTag.artifact_uuid)",
        secondaryjoin="foreign(ArtifactTag.tag_id) == Tag.id",
        lazy="selectin",
        back_populates="artifacts",
    )
    versions: Mapped[List["ArtifactVersion"]] = relationship(
        "ArtifactVersion",
        back_populates="artifact",
        cascade="all, delete-orphan",
        lazy="selectin",
        order_by="ArtifactVersion.created_at.desc()",
    )
    # Composite membership — artifacts may appear as children in one or more
    # CompositeArtifact bundles.  The explicit foreign_keys= argument is
    # required because CompositeMembership references artifacts.uuid (not
    # artifacts.id), which would otherwise trigger AmbiguousForeignKeysError.
    composite_memberships: Mapped[List["CompositeMembership"]] = relationship(
        "CompositeMembership",
        foreign_keys="[CompositeMembership.child_artifact_uuid]",
        back_populates="child_artifact",
        lazy="selectin",
    )
    # Group membership — artifacts may appear in one or more Groups.
    # The explicit foreign_keys= argument is required because GroupArtifact
    # references artifacts.uuid (not artifacts.id).
    group_memberships: Mapped[List["GroupArtifact"]] = relationship(
        "GroupArtifact",
        foreign_keys="[GroupArtifact.artifact_uuid]",
        lazy="select",
    )
    # Category membership — artifacts may belong to zero or more structured
    # ContextEntityCategory buckets via the entity_category_associations join table.
    categories: Mapped[List["ContextEntityCategory"]] = relationship(
        "ContextEntityCategory",
        secondary="entity_category_associations",
        primaryjoin="Artifact.uuid == foreign(ArtifactCategoryAssociation.artifact_uuid)",
        secondaryjoin="foreign(ArtifactCategoryAssociation.category_id) == ContextEntityCategory.id",
        back_populates="artifacts",
        lazy="selectin",
    )
    # Cryptographic signatures for this artifact (DVCS-4.1)
    signatures: Mapped[List["ArtifactSignature"]] = relationship(
        "ArtifactSignature",
        back_populates="artifact",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "type IN ('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', "
            "'workflow', 'composite', 'project_config', 'spec_file', 'rule_file', "
            "'context_file', 'progress_template', 'context_module', 'template', "
            "'group', 'deployment_set', 'context_pack', 'bundle')",
            name="check_artifact_type",
        ),
        # DVCS-3.1 — collection_tier domain guard
        CheckConstraint(
            "collection_tier IN ('marketplace', 'enterprise', 'team', 'dev', 'project') "
            "OR collection_tier IS NULL",
            name="check_artifacts_collection_tier",
        ),
        # DVCS-3.1 — FQAN lightweight format guard (scope://namespace/name@version)
        CheckConstraint(
            "fqan LIKE '%://%/%@%' OR fqan IS NULL",
            name="check_artifacts_fqan_format",
        ),
        # DVCS-3.1 — FQAN lookup index (partial: only rows with a non-null FQAN)
        Index(
            "idx_artifacts_fqan",
            "fqan",
            sqlite_where=Column("fqan") != None,  # noqa: E711
        ),
        # DVCS-3.1 — Upper-tier uniqueness (enterprise / team / dev)
        # Ensures no two artifacts at these tiers share the same logical identity.
        Index(
            "idx_artifacts_upper_tier_fqan_unique",
            "collection_tier",
            "namespace",
            "name",
            "type",
            unique=True,
            sqlite_where=Column("collection_tier").in_(["enterprise", "team", "dev"]),
        ),
        # DVCS-3.1 — Project-tier uniqueness (scoped per project)
        Index(
            "idx_artifacts_project_tier_fqan_unique",
            "project_id",
            "namespace",
            "name",
            "type",
            unique=True,
            sqlite_where=Column("collection_tier") == "project",
        ),
    )

    def __repr__(self) -> str:
        """Return string representation of Artifact."""
        return (
            f"<Artifact(id={self.id!r}, name={self.name!r}, "
            f"type={self.type!r}, project_id={self.project_id!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert Artifact to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the artifact
        """
        result = {
            "id": self.id,
            "uuid": self.uuid,
            "project_id": self.project_id,
            "name": self.name,
            "type": self.type,
            "source": self.source,
            "deployed_version": self.deployed_version,
            "upstream_version": self.upstream_version,
            "is_outdated": self.is_outdated,
            "local_modified": self.local_modified,
            "path_pattern": self.path_pattern,
            "auto_load": self.auto_load,
            "category": self.category,
            "content_hash": self.content_hash,
            "content": self.content,
            "core_content": self.core_content,
            "description": self.description,
            "target_platforms": self.target_platforms,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

        # Include metadata if loaded
        if self.artifact_metadata:
            result["metadata"] = self.artifact_metadata.to_dict()

        # Include categories if loaded (avoids N+1 when lazy="selectin" fires)
        result["categories"] = [c.name for c in self.categories]

        return result


class DeploymentProfile(Base):
    """Deployment profile configuration for a project."""

    __tablename__ = "deployment_profiles"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    project_id: Mapped[str] = mapped_column(
        String, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False
    )
    profile_id: Mapped[str] = mapped_column(String, nullable=False)
    platform: Mapped[str] = mapped_column(String, nullable=False)
    root_dir: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    artifact_path_map: Mapped[Optional[Dict[str, str]]] = mapped_column(
        JSON, nullable=True
    )
    config_filenames: Mapped[Optional[List[str]]] = mapped_column(JSON, nullable=True)
    context_prefixes: Mapped[Optional[List[str]]] = mapped_column(JSON, nullable=True)
    supported_types: Mapped[Optional[List[str]]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    project: Mapped["Project"] = relationship(
        "Project", back_populates="deployment_profiles"
    )

    __table_args__ = (
        UniqueConstraint(
            "project_id",
            "profile_id",
            name="uq_deployment_profiles_project_profile_id",
        ),
        Index(
            "idx_deployment_profiles_project_profile",
            "project_id",
            "profile_id",
            unique=True,
        ),
        CheckConstraint(
            "platform IN ('claude_code', 'codex', 'gemini', 'cursor', 'remote_git', 'other')",
            name="ck_deployment_profiles_platform",
        ),
    )

    def to_dict(self) -> Dict[str, Any]:
        """Convert deployment profile to dictionary."""
        return {
            "id": self.id,
            "project_id": self.project_id,
            "profile_id": self.profile_id,
            "platform": self.platform,
            "root_dir": self.root_dir,
            "description": self.description,
            "artifact_path_map": self.artifact_path_map,
            "config_filenames": self.config_filenames or [],
            "context_prefixes": self.context_prefixes or [],
            "supported_types": self.supported_types or [],
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ArtifactMetadata(Base):
    """Extended artifact metadata from YAML frontmatter.

    Stores additional metadata extracted from artifact files (SKILL.md, etc.).
    This is a one-to-one relationship with Artifact.

    Attributes:
        artifact_id: Foreign key to artifacts.id (primary key)
        metadata_json: Full YAML frontmatter as JSON (for exact preservation)
        description: Extracted description for quick access
        tags: Comma-separated tags for searchability
        aliases: Comma-separated aliases for alias resolution
        artifact: Related Artifact object

    Indexes:
        - idx_metadata_tags: Tag-based search performance
    """

    __tablename__ = "artifact_metadata"

    # Primary key and foreign key
    artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.id", ondelete="CASCADE"),
        primary_key=True,
    )

    # Metadata fields
    metadata_json: Mapped[Optional[str]] = mapped_column(
        "metadata", Text, nullable=True
    )
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    tags: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    aliases: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    artifact: Mapped["Artifact"] = relationship(
        "Artifact", back_populates="artifact_metadata"
    )

    def __repr__(self) -> str:
        """Return string representation of ArtifactMetadata."""
        return f"<ArtifactMetadata(artifact_id={self.artifact_id!r})>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert ArtifactMetadata to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the metadata
        """
        # Parse JSON metadata if present
        metadata_dict = None
        if self.metadata_json:
            try:
                metadata_dict = json.loads(self.metadata_json)
            except json.JSONDecodeError:
                metadata_dict = None

        return {
            "artifact_id": self.artifact_id,
            "metadata": metadata_dict,
            "description": self.description,
            "tags": self.tags.split(",") if self.tags else [],
            "aliases": self.aliases.split(",") if self.aliases else [],
        }

    def get_metadata_dict(self) -> Optional[Dict[str, Any]]:
        """Parse and return metadata as dictionary.

        Returns:
            Parsed metadata dictionary or None if invalid/missing
        """
        if not self.metadata_json:
            return None

        try:
            return json.loads(self.metadata_json)
        except json.JSONDecodeError:
            return None

    def set_metadata_dict(self, metadata_dict: Dict[str, Any]) -> None:
        """Set metadata from dictionary.

        Args:
            metadata_dict: Dictionary to serialize as JSON
        """
        self.metadata_json = json.dumps(metadata_dict)

    def get_tags_list(self) -> List[str]:
        """Get tags as a list.

        Returns:
            List of tag strings
        """
        if not self.tags:
            return []
        return [tag.strip() for tag in self.tags.split(",") if tag.strip()]

    def set_tags_list(self, tags: List[str]) -> None:
        """Set tags from a list.

        Args:
            tags: List of tag strings
        """
        self.tags = ",".join(tags) if tags else None

    def get_aliases_list(self) -> List[str]:
        """Get aliases as a list.

        Returns:
            List of alias strings
        """
        if not self.aliases:
            return []
        return [alias.strip() for alias in self.aliases.split(",") if alias.strip()]

    def set_aliases_list(self, aliases: List[str]) -> None:
        """Set aliases from a list.

        Args:
            aliases: List of alias strings
        """
        self.aliases = ",".join(aliases) if aliases else None


class ArtifactVersion(Base):
    """Version history entry for an artifact.

    Tracks version lineage with parent-child relationships and change origin
    attribution. Each version stores content hash for content-based deduplication.

    Attributes:
        id: Unique version identifier (UUID hex)
        artifact_id: Foreign key to artifacts.id
        content_hash: SHA-256 hash of artifact content (UNIQUE)
        parent_hash: Content hash of parent version (NULL for root)
        change_origin: Origin of this version ('deployment', 'sync', 'local_modification')
        version_lineage: JSON array of ancestor content hashes
        created_at: Timestamp when version was created
        metadata_json: Additional JSON metadata
        artifact: Related Artifact object

    Indexes:
        - idx_artifact_versions_artifact_id: Fast lookup by artifact
        - idx_artifact_versions_content_hash (UNIQUE): Content-based deduplication
        - idx_artifact_versions_parent_hash: Fast lookup by parent
        - idx_artifact_versions_artifact_created: Composite for artifact+time queries
        - idx_artifact_versions_change_origin: Filter by origin type
    """

    __tablename__ = "artifact_versions"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Foreign key
    artifact_id: Mapped[str] = mapped_column(
        String, ForeignKey("artifacts.id", ondelete="CASCADE"), nullable=False
    )

    # Version tracking
    # NOTE: content_hash is unique per artifact (not globally unique).
    # The global UniqueConstraint was replaced by a composite unique on
    # (artifact_id, content_hash) in migration 20260327_0002_artifact_vcs_v2.
    content_hash: Mapped[str] = mapped_column(String, nullable=False)
    parent_hash: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    change_origin: Mapped[str] = mapped_column(String, nullable=False)
    version_lineage: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True
    )  # JSON array

    # VCS v2 fields (artifact-vcs-v2)
    version_label: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    bom_snapshot_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("bom_snapshots.id", ondelete="SET NULL"), nullable=True
    )
    message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # VersionSet membership (artifact-vcs-v2) — nullable for backward compatibility.
    # NOTE: No SQLAlchemy-level FK constraint — the FK is enforced at the DB level
    # by migration 20260327_0002_artifact_vcs_v2.  This avoids breaking test fixtures
    # that selectively create tables without version_sets (SQLite PRAGMA foreign_keys=ON
    # rejects INSERTs even with NULL FK values when the referenced table doesn't exist).
    version_set_id: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="FK to version_sets.id (enforced by migration, not ORM)",
    )

    # Ghost version flag (artifact-vcs-v2) — True when this version represents an
    # upstream GitHub change that has not yet been pulled into the collection.
    # Ghost rows are inserted by GhostVersionDetector with change_origin='github_update'.
    is_ghost: Mapped[Optional[bool]] = mapped_column(
        Boolean, nullable=True, default=False, server_default="0"
    )

    # Inline content storage for version diff support (local edition).
    # Stores the diffable text representation of the artifact at this version.
    # For single-file artifacts: raw file text.
    # For directory artifacts: concatenated file representation.
    content_payload: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # CAS blob architecture fields (dvcs-cas-architecture, ADR-013).
    # content_tree stores a JSON mapping of relative path -> SHA-256 blob hash.
    # Stored as TEXT for SQLite compatibility; treat as JSON in application code.
    content_tree: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment=(
            "JSON map of {relative_path: sha256_hex} for content-addressed "
            "blob references. NULL until CAS backfill migration runs (DVCS-1.4)."
        ),
    )
    # upstream_hash stores the SHA-256 of the upstream GitHub blob at capture time
    # for fast divergence detection without re-fetching upstream content.
    upstream_hash: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="SHA-256 hex of upstream content at capture time (64 chars).",
    )
    # upstream_tier: integer tier of the upstream source (0=direct, 1=fork, etc.)
    upstream_tier: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        comment="Upstream source tier (0 = direct/canonical, >0 = fork depth).",
    )
    # is_complete_capture: True when all referenced blobs are stored in artifact_blobs.
    # False/NULL until DVCS-1.4 backfill migration promotes historic versions.
    is_complete_capture: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        default=False,
        server_default="0",
        comment=(
            "True when all content_tree blob hashes are present in artifact_blobs. "
            "Set by DVCS-1.4 backfill migration."
        ),
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Metadata
    metadata_json: Mapped[Optional[str]] = mapped_column(
        "metadata", Text, nullable=True
    )

    # Relationships
    artifact: Mapped["Artifact"] = relationship("Artifact", back_populates="versions")
    bom_snapshot: Mapped[Optional["BomSnapshot"]] = relationship(
        "BomSnapshot", foreign_keys=[bom_snapshot_id], lazy="select"
    )

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "change_origin IN ('initial_seed', 'deployment', 'sync', 'local_modification', "
            "'restore', 'promotion', 'push', 'github_update', 'import', "
            "'policy_enforcement', 'composite_update', 'rename', 'patch', 'auto_capture')",
            name="check_artifact_versions_change_origin",
        ),
        Index("idx_artifact_versions_artifact_id", "artifact_id"),
        # Per-artifact unique: same content hash may appear in different artifacts
        Index(
            "idx_artifact_versions_artifact_hash",
            "artifact_id",
            "content_hash",
            unique=True,
        ),
        Index("idx_artifact_versions_parent_hash", "parent_hash"),
        Index("idx_artifact_versions_artifact_created", "artifact_id", "created_at"),
        Index("idx_artifact_versions_change_origin", "change_origin"),
        Index("idx_artifact_versions_version_set_id", "version_set_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of ArtifactVersion."""
        return (
            f"<ArtifactVersion(id={self.id!r}, artifact_id={self.artifact_id!r}, "
            f"content_hash={self.content_hash[:8]}..., change_origin={self.change_origin!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert ArtifactVersion to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the version
        """
        # Parse lineage and metadata JSON if present
        lineage_list = self.get_lineage_list()
        metadata_dict = self.get_metadata_dict()

        return {
            "id": self.id,
            "artifact_id": self.artifact_id,
            "content_hash": self.content_hash,
            "parent_hash": self.parent_hash,
            "change_origin": self.change_origin,
            "version_lineage": lineage_list,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "metadata": metadata_dict,
        }

    def get_lineage_list(self) -> List[str]:
        """Parse version_lineage JSON to list.

        Returns:
            List of ancestor content hashes or empty list if None/invalid
        """
        if not self.version_lineage:
            return []

        try:
            lineage = json.loads(self.version_lineage)
            if isinstance(lineage, list):
                return lineage
            return []
        except json.JSONDecodeError:
            return []

    def set_lineage_list(self, hashes: List[str]) -> None:
        """Serialize list of hashes to version_lineage JSON.

        Args:
            hashes: List of ancestor content hashes
        """
        if not hashes:
            self.version_lineage = None
        else:
            self.version_lineage = json.dumps(hashes)

    def get_metadata_dict(self) -> Optional[Dict[str, Any]]:
        """Parse and return metadata as dictionary.

        Returns:
            Parsed metadata dictionary or None if invalid/missing
        """
        if not self.metadata_json:
            return None

        try:
            return json.loads(self.metadata_json)
        except json.JSONDecodeError:
            return None

    def set_metadata_dict(self, metadata_dict: Dict[str, Any]) -> None:
        """Set metadata from dictionary.

        Args:
            metadata_dict: Dictionary to serialize as JSON
        """
        self.metadata_json = json.dumps(metadata_dict)


class ArtifactBlob(Base):
    """Content-addressed blob storage for artifact file content (ADR-013).

    Each row stores a unique chunk of artifact file content keyed by its
    SHA-256 hash.  The table is the backing store for the CAS (Content-
    Addressed Storage) layer introduced by the DVCS CAS architecture spike.

    A blob is referenced from ``ArtifactVersion.content_tree`` (a JSON map of
    relative path -> blob hash).  One blob may be referenced by many versions,
    enabling deduplication across the collection.

    Attributes:
        hash: SHA-256 hex digest of ``content`` (primary key, 64 chars).
        content: Raw text content of the blob (UTF-8 by default).
        encoding: Character encoding of ``content``. Default ``'utf8'``.
        size_bytes: Byte length of ``content``. Must be >= 0.
        created_at: UTC timestamp when the blob was first stored.
        compression: Compression algorithm applied to ``content``
            before storage. Default ``'none'``.
        gc_eligible_at: When set, the GC sweep may delete this blob if no
            ``ArtifactVersion.content_tree`` references its hash. NULL means
            the blob is permanently retained.

    Indexes:
        - idx_artifact_blobs_created_at: Range scans / time-ordered GC sweeps.
        - idx_artifact_blobs_gc_eligible: Fast GC candidate lookup (nullable).

    Notes:
        The ``hash`` column is the sole primary key — no surrogate integer.
        Write semantics are INSERT OR IGNORE (upsert-by-hash): callers must
        never mutate content for an existing hash.
    """

    __tablename__ = "artifact_blobs"

    # Content-addressed primary key
    hash: Mapped[str] = mapped_column(
        String(64),
        primary_key=True,
        comment="SHA-256 hex digest of content (64 chars). Immutable once written.",
    )

    # Blob content
    content: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Raw text content of the blob (encoding given by the encoding column).",
    )
    encoding: Mapped[str] = mapped_column(
        String(8),
        nullable=False,
        default="utf8",
        server_default="utf8",
        comment="Character encoding of content. Default: utf8.",
    )
    size_bytes: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        comment="Byte length of content. Stored redundantly to avoid re-computing.",
    )

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="UTC timestamp when the blob was first written to the store.",
    )

    # Compression metadata
    compression: Mapped[str] = mapped_column(
        String(8),
        nullable=False,
        default="none",
        server_default="none",
        comment=(
            "Compression algorithm applied before storage. "
            "'none' = raw text. Future values: 'zstd', 'gzip'."
        ),
    )

    # GC eligibility
    gc_eligible_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        comment=(
            "When set, this blob is a GC candidate after this timestamp "
            "if no ArtifactVersion.content_tree references its hash. "
            "NULL = permanently retained."
        ),
    )

    # Constraints & indexes
    __table_args__ = (
        Index("idx_artifact_blobs_created_at", "created_at"),
        Index("idx_artifact_blobs_gc_eligible", "gc_eligible_at"),
    )

    def __repr__(self) -> str:
        """Return string representation of ArtifactBlob."""
        return (
            f"<ArtifactBlob(hash={self.hash[:8]}..., "
            f"size_bytes={self.size_bytes}, compression={self.compression!r})>"
        )


class Collection(Base):
    """User-defined collection of artifacts.

    Collections allow users to organize artifacts into logical groups
    for easier management and deployment. Each collection can contain
    multiple artifacts and support nested organization through groups.

    Attributes:
        id: Unique collection identifier (primary key, UUID hex)
        name: Collection name (1-255 characters)
        description: Optional detailed description
        created_by: User identifier for future multi-user support
        collection_type: Optional collection type (e.g., "context", "artifacts")
        context_category: Optional category for context collections (e.g., "rules", "specs")
        created_at: Timestamp when collection was created
        updated_at: Timestamp when collection was last modified
        groups: List of artifact groups within this collection
        artifacts: List of artifacts in this collection (via association)

    Indexes:
        - idx_collections_name: Fast lookup by name
        - idx_collections_created_by: Filter by creator
        - idx_collections_created_at: Sort by creation date
        - idx_collections_type: Filter by collection type
    """

    __tablename__ = "collections"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Core fields
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_by: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Collection type fields for filtering and categorization
    collection_type: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    context_category: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Ownership and visibility
    owner_id: Mapped[Optional[str]] = mapped_column(String, nullable=True, default=None)
    owner_type: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default=OwnerType.user.value
    )
    visibility: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default=Visibility.private.value
    )
    enforce_override: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="false"
    )

    # Relationships
    groups: Mapped[List["Group"]] = relationship(
        "Group",
        back_populates="collection",
        cascade="all, delete-orphan",
        lazy="select",
    )
    collection_artifacts: Mapped[List["CollectionArtifact"]] = relationship(
        "CollectionArtifact",
        cascade="all, delete-orphan",
        lazy="select",
    )
    templates: Mapped[List["ProjectTemplate"]] = relationship(
        "ProjectTemplate",
        back_populates="collection",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "length(name) > 0 AND length(name) <= 255",
            name="check_collection_name_length",
        ),
        Index("idx_collections_name", "name"),
        Index("idx_collections_created_by", "created_by"),
        Index("idx_collections_created_at", "created_at"),
        Index("idx_collections_type", "collection_type"),
    )

    def __repr__(self) -> str:
        """Return string representation of Collection."""
        return (
            f"<Collection(id={self.id!r}, name={self.name!r}, "
            f"created_by={self.created_by!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert Collection to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the collection
        """
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "created_by": self.created_by,
            "collection_type": self.collection_type,
            "context_category": self.context_category,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class Group(Base):
    """Custom grouping of artifacts within a collection.

    Groups provide a way to organize artifacts within a collection into
    logical categories. Each group belongs to exactly one collection and
    can contain multiple artifacts with custom ordering.

    Attributes:
        id: Unique group identifier (primary key, UUID hex)
        collection_id: Foreign key to collections.id (NOT NULL)
        name: Group name (1-255 characters, unique per collection)
        description: Optional detailed description
        tags_json: JSON-serialized list of group-local tags
        color: Visual accent token for group cards
        icon: Icon token for group cards
        position: Display order within collection (0-based, default 0)
        created_at: Timestamp when group was created
        updated_at: Timestamp when group was last modified
        collection: Parent collection object
        artifacts: List of artifacts in this group (via association)

    Indexes:
        - idx_groups_collection_id: Fast lookup by collection
        - idx_groups_collection_position: Ordered queries within collection
        - Unique constraint on (collection_id, name)
    """

    __tablename__ = "groups"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Foreign key
    collection_id: Mapped[str] = mapped_column(
        String, ForeignKey("collections.id", ondelete="CASCADE"), nullable=False
    )

    # Core fields
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    tags_json: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        default="[]",
        server_default="[]",
        comment="JSON-serialized list of group-local tags",
    )
    color: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        default="slate",
        server_default="slate",
        comment="Visual accent token for group card rendering",
    )
    icon: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        default="layers",
        server_default="layers",
        comment="Icon token for group card rendering",
    )
    position: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Ownership and visibility
    owner_id: Mapped[Optional[str]] = mapped_column(String, nullable=True, default=None)
    owner_type: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default=OwnerType.user.value
    )
    visibility: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default=Visibility.private.value
    )

    # Relationships
    collection: Mapped["Collection"] = relationship(
        "Collection", back_populates="groups"
    )
    group_artifacts: Mapped[List["GroupArtifact"]] = relationship(
        "GroupArtifact",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    # Constraints
    __table_args__ = (
        UniqueConstraint("collection_id", "name", name="uq_group_collection_name"),
        CheckConstraint(
            "length(name) > 0 AND length(name) <= 255",
            name="check_group_name_length",
        ),
        CheckConstraint("position >= 0", name="check_group_position"),
        Index("idx_groups_collection_id", "collection_id"),
        Index("idx_groups_collection_position", "collection_id", "position"),
    )

    def __repr__(self) -> str:
        """Return string representation of Group."""
        return (
            f"<Group(id={self.id!r}, name={self.name!r}, "
            f"collection_id={self.collection_id!r}, position={self.position})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert Group to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the group
        """
        return {
            "id": self.id,
            "collection_id": self.collection_id,
            "name": self.name,
            "description": self.description,
            "tags": self.get_tags_list(),
            "color": self.color,
            "icon": self.icon,
            "position": self.position,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "artifact_count": 0,  # Will be populated when artifacts relationship exists
        }

    def get_tags_list(self) -> List[str]:
        """Parse and return group-local tags as a list."""
        if not self.tags_json:
            return []
        try:
            parsed = json.loads(self.tags_json)
        except json.JSONDecodeError:
            return []
        return parsed if isinstance(parsed, list) else []

    def set_tags_list(self, tags: List[str]) -> None:
        """Persist group-local tags from a list as JSON text."""
        self.tags_json = json.dumps(tags or [])


class GroupArtifact(Base):
    """Association between Group and Artifact with position for ordering.

    Represents the many-to-many relationship between groups and artifacts,
    allowing artifacts to be organized within groups with custom ordering.

    Attributes:
        group_id: Foreign key to groups.id (part of composite primary key)
        artifact_uuid: FK to artifacts.uuid (part of composite PK, CASCADE DELETE)
        position: Display order within group (0-based, default 0)
        added_at: Timestamp when artifact was added to group

    Indexes:
        - idx_group_artifacts_group_id: Fast lookup by group
        - idx_group_artifacts_artifact_uuid: Fast lookup by artifact UUID
        - idx_group_artifacts_group_position: Ordered queries within group
        - idx_group_artifacts_added_at: Sort by membership date

    Note:
        artifact_uuid references artifacts.uuid (the stable ADR-007 identity
        column) rather than artifacts.id (the mutable type:name string).  This
        allows cascade deletes when an artifact is removed from the cache and
        keeps the join table referentially sound.
    """

    __tablename__ = "group_artifacts"

    # Composite primary key
    group_id: Mapped[str] = mapped_column(
        String, ForeignKey("groups.id", ondelete="CASCADE"), primary_key=True
    )
    artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        primary_key=True,
        comment="FK to artifacts.uuid (ADR-007 stable identity) — CASCADE DELETE",
    )

    # Ordering and metadata
    position: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    added_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Constraints
    __table_args__ = (
        CheckConstraint("position >= 0", name="check_group_artifact_position"),
        Index("idx_group_artifacts_group_id", "group_id"),
        Index("idx_group_artifacts_artifact_uuid", "artifact_uuid"),
        Index("idx_group_artifacts_group_position", "group_id", "position"),
        Index("idx_group_artifacts_added_at", "added_at"),
    )

    # Relationship to Artifact (lazy to avoid N+1 in list queries)
    artifact: Mapped[Optional["Artifact"]] = relationship(
        "Artifact",
        primaryjoin="GroupArtifact.artifact_uuid == foreign(Artifact.uuid)",
        foreign_keys="[GroupArtifact.artifact_uuid]",
        lazy="select",
        viewonly=True,
    )

    @property
    def artifact_id(self) -> Optional[str]:
        """Return the artifact's type:name identifier (e.g. 'skill:canvas').

        This is a compatibility shim — the DB FK column is artifact_uuid but
        many service-layer callers expect the old type:name string.  The value
        is resolved via the artifact relationship (one extra query per access
        unless the relationship is already loaded).
        """
        if self.artifact is not None:
            return self.artifact.id
        return None

    def __repr__(self) -> str:
        """Return string representation of GroupArtifact."""
        return (
            f"<GroupArtifact(group_id={self.group_id!r}, "
            f"artifact_uuid={self.artifact_uuid!r}, position={self.position})>"
        )


class CollectionArtifact(Base):
    """Association between Collection and Artifact (many-to-many).

    Links artifacts to collections with tracking of when they were added.
    This is a rich association table (has cached metadata columns in addition
    to the join keys) with a composite primary key.

    Attributes:
        collection_id: Foreign key to collections.id (part of composite PK)
        artifact_uuid: FK to artifacts.uuid with CASCADE delete (part of composite PK)
        added_at: Timestamp when artifact was added to collection

    Indexes:
        - idx_collection_artifacts_collection_id: Fast lookup by collection
        - idx_collection_artifacts_artifact_uuid: Fast lookup by artifact UUID
        - idx_collection_artifacts_added_at: Sort by addition date

    Note:
        artifact_uuid references artifacts.uuid (the stable ADR-007 identity
        column) rather than artifacts.id (the mutable type:name string).  This
        allows cascade deletes when an artifact is removed from the cache and
        keeps the join table referentially sound.
    """

    __tablename__ = "collection_artifacts"

    # Composite primary key
    collection_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("collections.id", ondelete="CASCADE"),
        primary_key=True,
    )
    artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        primary_key=True,
        comment="FK to artifacts.uuid (ADR-007 stable identity) — CASCADE DELETE",
    )

    # Timestamp
    added_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Cached metadata for DB-backed /collection page
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    author: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    license: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    tags_json: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True
    )  # JSON array string
    tools_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    deployments_json: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True
    )  # JSON array of deployment paths
    version: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Fingerprint fields for similarity scoring (SSO-2.1)
    artifact_content_hash: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="SHA-256 hash of artifact file contents — distinct from context-entity content_hash",
    )
    artifact_structure_hash: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="Hash of artifact directory structure (filenames + tree shape)",
    )
    artifact_file_count: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
        comment="Number of files in the artifact",
    )
    artifact_total_size: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
        comment="Total byte size of all artifact files",
    )
    source: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    origin: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    origin_source: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    resolved_sha: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    resolved_version: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    synced_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Indexes
    __table_args__ = (
        Index("idx_collection_artifacts_collection_id", "collection_id"),
        Index("idx_collection_artifacts_artifact_uuid", "artifact_uuid"),
        Index("idx_collection_artifacts_added_at", "added_at"),
    )

    # Relationship to Artifact (lazy to avoid N+1 in list queries)
    artifact: Mapped[Optional["Artifact"]] = relationship(
        "Artifact",
        primaryjoin="CollectionArtifact.artifact_uuid == foreign(Artifact.uuid)",
        foreign_keys="[CollectionArtifact.artifact_uuid]",
        lazy="select",
        viewonly=True,
    )

    @property
    def artifact_id(self) -> Optional[str]:
        """Return the artifact's type:name identifier (e.g. 'skill:canvas').

        This is a compatibility shim — the DB FK column is artifact_uuid but
        many service-layer callers expect the old type:name string.  The value
        is resolved via the artifact relationship (one extra query per access
        unless the relationship is already loaded).
        """
        if self.artifact is not None:
            return self.artifact.id
        return None

    @property
    def tools(self) -> list[str]:
        """Parse tools_json into a list of tool names."""
        if self.tools_json:
            return json.loads(self.tools_json)
        return []

    def __repr__(self) -> str:
        """Return string representation of CollectionArtifact."""
        return (
            f"<CollectionArtifact("
            f"collection_id={self.collection_id!r}, "
            f"artifact_uuid={self.artifact_uuid!r}, "
            f"added_at={self.added_at!r})>"
        )


class Tag(Base):
    """Tag for categorizing and organizing artifacts.

    Tags provide a flexible categorization system for artifacts, enabling
    filtering, searching, and organization. Each tag has a unique name and
    optional color for visual distinction.

    Attributes:
        id: Unique tag identifier (primary key, UUID hex)
        name: Tag name (unique, non-empty, max 100 characters)
        slug: URL-friendly identifier (unique, kebab-case)
        color: Optional hex color code (e.g., "#FF5733")
        created_at: Timestamp when tag was created
        updated_at: Timestamp when tag was last modified
        artifacts: List of artifacts with this tag (via association)

    Indexes:
        - idx_tags_name (UNIQUE): Fast lookup by name
        - idx_tags_slug (UNIQUE): Fast lookup by slug
    """

    __tablename__ = "tags"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Core fields
    name: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)
    slug: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)
    color: Mapped[Optional[str]] = mapped_column(String(7), nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    artifacts: Mapped[List["Artifact"]] = relationship(
        "Artifact",
        secondary="artifact_tags",
        primaryjoin="Tag.id == ArtifactTag.tag_id",
        secondaryjoin="foreign(ArtifactTag.artifact_uuid) == Artifact.uuid",
        lazy="selectin",
        back_populates="tags",
        viewonly=True,
    )
    deployment_sets: Mapped[List["DeploymentSet"]] = relationship(
        "DeploymentSet",
        secondary="deployment_set_tags",
        primaryjoin="Tag.id == DeploymentSetTag.tag_id",
        secondaryjoin="foreign(DeploymentSetTag.deployment_set_id) == DeploymentSet.id",
        lazy="selectin",
        viewonly=True,
    )

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "length(name) > 0 AND length(name) <= 100",
            name="check_tag_name_length",
        ),
        CheckConstraint(
            "length(slug) > 0 AND length(slug) <= 100",
            name="check_tag_slug_length",
        ),
        CheckConstraint(
            "color IS NULL OR (length(color) = 7 AND color LIKE '#%')",
            name="check_tag_color_format",
        ),
        Index("idx_tags_name", "name", unique=True),
        Index("idx_tags_slug", "slug", unique=True),
    )

    def __repr__(self) -> str:
        """Return string representation of Tag."""
        return f"<Tag(id={self.id!r}, name={self.name!r}, slug={self.slug!r})>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert Tag to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the tag
        """
        return {
            "id": self.id,
            "name": self.name,
            "slug": self.slug,
            "color": self.color,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ArtifactTag(Base):
    """Association between Artifact and Tag (many-to-many).

    Links artifacts to tags for categorization and filtering. Each artifact
    can have multiple tags, and each tag can be applied to multiple artifacts.

    Attributes:
        artifact_uuid: FK to artifacts.uuid (part of composite PK; CASCADE
            delete so removing an artifact purges its tag associations)
        tag_id: Foreign key to tags.id (part of composite PK)
        created_at: Timestamp when tag was added to artifact

    Indexes:
        - idx_artifact_tags_artifact_uuid: Fast lookup by artifact UUID
        - idx_artifact_tags_tag_id: Fast lookup by tag
        - idx_artifact_tags_created_at: Sort by tag application date
    """

    __tablename__ = "artifact_tags"

    # Composite primary key
    # artifact_uuid references artifacts.uuid (ADR-007 stable identity) with
    # CASCADE delete so that removing an artifact purges all its tag rows.
    artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        primary_key=True,
    )
    tag_id: Mapped[str] = mapped_column(
        String, ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True
    )

    # Timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Indexes
    __table_args__ = (
        Index("idx_artifact_tags_artifact_uuid", "artifact_uuid"),
        Index("idx_artifact_tags_tag_id", "tag_id"),
        Index("idx_artifact_tags_created_at", "created_at"),
    )

    def __repr__(self) -> str:
        """Return string representation of ArtifactTag."""
        return (
            f"<ArtifactTag(artifact_uuid={self.artifact_uuid!r}, "
            f"tag_id={self.tag_id!r}, created_at={self.created_at!r})>"
        )


class DeploymentSetTag(Base):
    """Association between DeploymentSet and Tag (many-to-many).

    Links deployment sets to tags for categorization and filtering. Each
    deployment set can have multiple tags, and each tag can be applied to
    multiple deployment sets.

    Attributes:
        deployment_set_id: FK to deployment_sets.id (part of composite PK;
            CASCADE delete so removing a set purges its tag associations)
        tag_id: Foreign key to tags.id (part of composite PK)
        created_at: Timestamp when tag was added to deployment set

    Indexes:
        - idx_deployment_set_tags_set_id: Fast lookup by deployment set
        - idx_deployment_set_tags_tag_id: Fast lookup by tag
    """

    __tablename__ = "deployment_set_tags"

    # Composite primary key
    deployment_set_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("deployment_sets.id", ondelete="CASCADE"),
        primary_key=True,
    )
    tag_id: Mapped[str] = mapped_column(
        String, ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True
    )

    # Timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Indexes
    __table_args__ = (
        Index("idx_deployment_set_tags_set_id", "deployment_set_id"),
        Index("idx_deployment_set_tags_tag_id", "tag_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of DeploymentSetTag."""
        return (
            f"<DeploymentSetTag(deployment_set_id={self.deployment_set_id!r}, "
            f"tag_id={self.tag_id!r}, created_at={self.created_at!r})>"
        )


class MarketplaceEntry(Base):
    """Cached marketplace artifact listing.

    Stores cached information about artifacts available in the marketplace.
    TTL-based refresh strategy to keep marketplace data fresh.

    Attributes:
        id: Unique marketplace entry identifier (primary key)
        name: Artifact name
        type: Artifact type (skill, command, agent, mcp_server, hook)
        url: URL to artifact source
        description: Optional artifact description
        cached_at: Timestamp when entry was cached
        data: Additional data as JSON

    Indexes:
        - idx_marketplace_type: Filter by artifact type
        - idx_marketplace_name: Fast lookup by name
    """

    __tablename__ = "marketplace"

    # Primary key
    id: Mapped[str] = mapped_column(String, primary_key=True)

    # Core fields
    name: Mapped[str] = mapped_column(String, nullable=False)
    type: Mapped[str] = mapped_column(String, nullable=False)
    url: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Cache metadata
    cached_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Additional data (JSON)
    data: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "type IN ('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', "
            "'project_config', 'spec_file', 'rule_file', 'context_file', 'progress_template')",
            name="check_marketplace_type",
        ),
    )

    def __repr__(self) -> str:
        """Return string representation of MarketplaceEntry."""
        return (
            f"<MarketplaceEntry(id={self.id!r}, name={self.name!r}, "
            f"type={self.type!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert MarketplaceEntry to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the marketplace entry
        """
        # Parse JSON data if present
        data_dict = None
        if self.data:
            try:
                data_dict = json.loads(self.data)
            except json.JSONDecodeError:
                data_dict = None

        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "url": self.url,
            "description": self.description,
            "cached_at": self.cached_at.isoformat() if self.cached_at else None,
            "data": data_dict,
        }

    def get_data_dict(self) -> Optional[Dict[str, Any]]:
        """Parse and return data as dictionary.

        Returns:
            Parsed data dictionary or None if invalid/missing
        """
        if not self.data:
            return None

        try:
            return json.loads(self.data)
        except json.JSONDecodeError:
            return None

    def set_data_dict(self, data_dict: Dict[str, Any]) -> None:
        """Set data from dictionary.

        Args:
            data_dict: Dictionary to serialize as JSON
        """
        self.data = json.dumps(data_dict)


class MarketplaceSource(Base):
    """GitHub repository source for marketplace artifacts.

    Represents a GitHub repository that can be scanned for Claude Code artifacts.
    Supports authentication, trust levels, and visibility controls.

    Attributes:
        id: Unique marketplace source identifier (primary key)
        repo_url: Full GitHub repository URL
        owner: Repository owner/organization name
        repo_name: Repository name
        ref: Branch, tag, or SHA to scan (default: "main")
        root_hint: Optional subdirectory path within repository
        description: User-provided description for this source (max 500 chars)
        notes: Internal notes/documentation for this source (max 2000 chars)
        repo_description: Description fetched from GitHub API (max 2000 chars)
        repo_readme: README content from GitHub (up to 50KB)
        tags: JSON-serialized list of tags for categorization
        manual_map: JSON string for manual override catalog
        access_token_id: Optional encrypted PAT reference
        trust_level: Trust level ("untrusted", "basic", "verified", "official")
        visibility: Visibility level ("private", "internal", "public")
        enable_frontmatter_detection: Parse markdown frontmatter for artifact type hints
        indexing_enabled: Tri-state control for search indexing (None=use global mode, True=enable, False=disable)
        path_tag_config: JSON config for path-based tag extraction rules
        single_artifact_mode: Treat entire repo (or root_hint dir) as single artifact
        single_artifact_type: Artifact type when single_artifact_mode is True
        clone_target_json: JSON-serialized CloneTarget for rapid re-indexing
        deep_indexing_enabled: Clone entire artifact directories for enhanced search
        webhook_secret: Secret for GitHub webhook verification (future use)
        last_webhook_event_at: Timestamp of last webhook event received
        last_sync_at: Timestamp of last successful scan
        last_error: Last error message if scan failed
        scan_status: Current scan status ("pending", "scanning", "success", "error")
        artifact_count: Cached count of discovered artifacts
        counts_by_type: JSON-serialized dict mapping artifact type to count
        created_at: Timestamp when source was added
        updated_at: Timestamp when source was last updated
        entries: List of catalog entries discovered from this source

    Indexes:
        - idx_marketplace_sources_repo_url (UNIQUE): One entry per repo URL
        - idx_marketplace_sources_last_sync: TTL-based refresh queries
        - idx_marketplace_sources_scan_status: Filter by scan status
    """

    __tablename__ = "marketplace_sources"

    # Primary key
    id: Mapped[str] = mapped_column(String, primary_key=True)

    # Core fields
    repo_url: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    owner: Mapped[str] = mapped_column(String, nullable=False)
    repo_name: Mapped[str] = mapped_column(String, nullable=False)
    ref: Mapped[str] = mapped_column(
        String, nullable=False, default="main", server_default="main"
    )
    root_hint: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # User-provided metadata
    description: Mapped[Optional[str]] = mapped_column(
        String(500),
        nullable=True,
        comment="User-provided description for this source",
    )
    notes: Mapped[Optional[str]] = mapped_column(
        String(2000),
        nullable=True,
        comment="Internal notes/documentation for this source",
    )

    # GitHub-fetched metadata
    repo_description: Mapped[Optional[str]] = mapped_column(
        String(2000),
        nullable=True,
        comment="Description fetched from GitHub API",
    )
    repo_readme: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="README content from GitHub (up to 50KB)",
    )
    tags: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-serialized list of tags for categorization",
    )
    auto_tags: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON: {extracted: [{value, normalized, status, source}]} for GitHub topics",
    )

    # Extended configuration
    manual_map: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    access_token_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Security and visibility
    trust_level: Mapped[str] = mapped_column(
        String, nullable=False, default="basic", server_default="basic"
    )
    visibility: Mapped[str] = mapped_column(
        String, nullable=False, default="public", server_default="public"
    )

    # Detection settings
    enable_frontmatter_detection: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
        comment="Parse markdown frontmatter for artifact type hints",
    )
    indexing_enabled: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        comment="Enable frontmatter indexing for search",
    )
    # indexing_enabled: Per-source override for search indexing.
    # - None: Use global mode default
    # - True: Enable indexing regardless of mode
    # - False: Disable indexing regardless of mode
    path_tag_config: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON config for path-based tag extraction rules",
    )

    # Clone-based artifact indexing fields (Phase 1)
    clone_target_json: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-serialized CloneTarget for rapid re-indexing",
    )
    deep_indexing_enabled: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="0",
        comment="Clone entire artifact directories for enhanced search",
    )
    webhook_secret: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="Secret for GitHub webhook verification (future use)",
    )
    last_webhook_event_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        comment="Timestamp of last webhook event received",
    )

    # Single artifact mode settings
    single_artifact_mode: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
        comment="Treat entire repository (or root_hint dir) as single artifact",
    )
    single_artifact_type: Mapped[Optional[str]] = mapped_column(
        String(20),
        nullable=True,
        comment="Artifact type when single_artifact_mode is True (skill, command, agent, mcp_server, hook)",
    )

    # Sync status
    last_sync_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    scan_status: Mapped[str] = mapped_column(
        String, nullable=False, default="pending", server_default="pending"
    )
    artifact_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    counts_by_type: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-serialized dict mapping artifact type to count (e.g., {'skill': 5, 'command': 3})",
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    entries: Mapped[List["MarketplaceCatalogEntry"]] = relationship(
        "MarketplaceCatalogEntry",
        back_populates="source",
        cascade="all, delete-orphan",
        lazy="raise",  # Prevent accidental eager loading - explicitly load when needed
    )

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "trust_level IN ('untrusted', 'basic', 'verified', 'official')",
            name="check_trust_level",
        ),
        CheckConstraint(
            "visibility IN ('private', 'internal', 'public')",
            name="check_visibility",
        ),
        CheckConstraint(
            "scan_status IN ('pending', 'scanning', 'success', 'error')",
            name="check_scan_status",
        ),
    )

    def __repr__(self) -> str:
        """Return string representation of MarketplaceSource."""
        return (
            f"<MarketplaceSource(id={self.id!r}, repo_url={self.repo_url!r}, "
            f"scan_status={self.scan_status!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert MarketplaceSource to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the marketplace source
        """
        # Parse manual_map JSON if present
        manual_map_dict = None
        if self.manual_map:
            try:
                manual_map_dict = json.loads(self.manual_map)
            except json.JSONDecodeError:
                manual_map_dict = None

        # Parse tags JSON if present
        tags_list = self.get_tags_list()

        return {
            "id": self.id,
            "repo_url": self.repo_url,
            "owner": self.owner,
            "repo_name": self.repo_name,
            "ref": self.ref,
            "root_hint": self.root_hint,
            "description": self.description,
            "notes": self.notes,
            "repo_description": self.repo_description,
            "repo_readme": self.repo_readme,
            "tags": tags_list,
            "auto_tags": self.get_auto_tags_dict(),
            "manual_map": manual_map_dict,
            "access_token_id": self.access_token_id,
            "trust_level": self.trust_level,
            "visibility": self.visibility,
            "enable_frontmatter_detection": self.enable_frontmatter_detection,
            "indexing_enabled": self.indexing_enabled,
            "single_artifact_mode": self.single_artifact_mode,
            "single_artifact_type": self.single_artifact_type,
            # Clone-based artifact indexing fields
            "clone_target": self.clone_target.to_dict() if self.clone_target else None,
            "deep_indexing_enabled": self.deep_indexing_enabled,
            "webhook_secret": self.webhook_secret,
            "last_webhook_event_at": (
                self.last_webhook_event_at.isoformat()
                if self.last_webhook_event_at
                else None
            ),
            "last_sync_at": (
                self.last_sync_at.isoformat() if self.last_sync_at else None
            ),
            "last_error": self.last_error,
            "scan_status": self.scan_status,
            "artifact_count": self.artifact_count,
            "counts_by_type": self.get_counts_by_type_dict(),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def get_manual_map_dict(self) -> Optional[Dict[str, Any]]:
        """Parse and return manual_map as dictionary.

        Returns:
            Parsed manual_map dictionary or None if invalid/missing
        """
        if not self.manual_map:
            return None

        try:
            return json.loads(self.manual_map)
        except json.JSONDecodeError:
            return None

    def set_manual_map_dict(self, manual_map_dict: Dict[str, Any]) -> None:
        """Set manual_map from dictionary.

        Args:
            manual_map_dict: Dictionary to serialize as JSON
        """
        self.manual_map = json.dumps(manual_map_dict)

    def get_counts_by_type_dict(self) -> Dict[str, int]:
        """Parse counts_by_type JSON to dict.

        Returns:
            Dictionary mapping artifact type to count, or empty dict if null/invalid
        """
        if not self.counts_by_type:
            return {}
        try:
            return json.loads(self.counts_by_type)
        except json.JSONDecodeError:
            return {}

    def set_counts_by_type_dict(self, counts_dict: Dict[str, int]) -> None:
        """Serialize counts dict to JSON and store.

        Args:
            counts_dict: Dictionary mapping artifact type (skill, command, agent,
                        hook, mcp-server) to count
        """
        self.counts_by_type = json.dumps(counts_dict)

    def get_tags_list(self) -> Optional[List[str]]:
        """Parse and return tags as list.

        Returns:
            Parsed tags list or None if invalid/missing
        """
        if not self.tags:
            return None

        try:
            return json.loads(self.tags)
        except json.JSONDecodeError:
            return None

    def set_tags_list(self, tags_list: List[str]) -> None:
        """Set tags from list.

        Args:
            tags_list: List of tag strings to serialize as JSON
        """
        self.tags = json.dumps(tags_list)

    def get_auto_tags_dict(self) -> Optional[Dict[str, Any]]:
        """Parse and return auto_tags as dictionary.

        Returns:
            Parsed auto_tags dict with 'extracted' list, or None if invalid/missing.
            Structure: {"extracted": [{"value": str, "normalized": str,
                        "status": str, "source": str}]}
        """
        if not self.auto_tags:
            return None

        try:
            return json.loads(self.auto_tags)
        except json.JSONDecodeError:
            return None

    def set_auto_tags_dict(self, auto_tags_dict: Dict[str, Any]) -> None:
        """Set auto_tags from dictionary.

        Args:
            auto_tags_dict: Dictionary with 'extracted' key containing list of
                           auto-tag segments
        """
        self.auto_tags = json.dumps(auto_tags_dict)

    @property
    def clone_target(self) -> Optional["CloneTarget"]:
        """Get deserialized CloneTarget from JSON.

        Returns:
            CloneTarget instance if clone_target_json is set, None otherwise.

        Raises:
            json.JSONDecodeError: If clone_target_json contains invalid JSON.
            KeyError: If required CloneTarget fields are missing.
            ValueError: If CloneTarget strategy is invalid.
        """
        if not self.clone_target_json:
            return None
        from skillmeat.core.clone_target import CloneTarget

        return CloneTarget.from_json(self.clone_target_json)

    @clone_target.setter
    def clone_target(self, value: Optional["CloneTarget"]) -> None:
        """Set CloneTarget, serializing to JSON.

        Args:
            value: CloneTarget instance to serialize, or None to clear.
        """
        if value is None:
            self.clone_target_json = None
        else:
            self.clone_target_json = value.to_json()


class MarketplaceCatalogEntry(Base):
    """Detected artifact from marketplace source repository.

    Represents an artifact discovered during GitHub repository scanning.
    Tracks detection metadata, import status, and relationship to source.
    Supports user-driven exclusion for entries that are not actually artifacts
    (e.g., documentation files, configuration templates mistakenly detected).

    Attributes:
        id: Unique catalog entry identifier (primary key)
        source_id: Foreign key to marketplace_sources.id
        artifact_type: Type of artifact ("skill", "command", "agent", "mcp_server", "hook")
        name: Artifact name from detection
        path: Path within repository
        upstream_url: Full URL to artifact in repository
        detected_version: Extracted version if available
        detected_sha: Git commit SHA at detection time
        detected_at: Timestamp when artifact was detected
        confidence_score: Heuristic confidence 0-100
        raw_score: Raw confidence score before normalization (optional)
        score_breakdown: JSON breakdown of scoring components (optional)
        status: Import status ("new", "updated", "removed", "imported")
        import_date: When artifact was imported to collection
        import_id: Reference to imported artifact ID
        excluded_at: Timestamp when entry was marked as "not an artifact" (None if not excluded)
        excluded_reason: User-provided reason for exclusion (optional, max 500 chars)
        title: Artifact title from frontmatter for search display (max 200 chars)
        description: Artifact description from frontmatter for search
        search_tags: JSON array of tags from frontmatter for search filtering
        search_text: Concatenated searchable text (title + description + tags)
        deep_search_text: Full-text content from deep indexing of artifact files
        deep_indexed_at: Timestamp of last deep indexing operation
        deep_index_files: JSON array of files included in deep index
        metadata_json: Additional detection metadata as JSON
        created_at: Timestamp when entry was created
        updated_at: Timestamp when entry was last updated
        source: Related MarketplaceSource object

    Indexes:
        - idx_catalog_entries_source_id: Query by source
        - idx_catalog_entries_status: Filter by status
        - idx_catalog_entries_type: Filter by artifact type
        - idx_catalog_entries_upstream_url: Deduplication on URL
        - idx_catalog_entries_source_status: Composite for filtered queries
    """

    __tablename__ = "marketplace_catalog_entries"

    # Primary key
    id: Mapped[str] = mapped_column(String, primary_key=True)

    # Foreign key
    source_id: Mapped[str] = mapped_column(
        String, ForeignKey("marketplace_sources.id", ondelete="CASCADE"), nullable=False
    )

    # Core fields
    artifact_type: Mapped[str] = mapped_column(String, nullable=False)
    name: Mapped[str] = mapped_column(String, nullable=False)
    path: Mapped[str] = mapped_column(String, nullable=False)
    upstream_url: Mapped[str] = mapped_column(String, nullable=False)

    # Version tracking
    detected_version: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    detected_sha: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    detected_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Detection quality
    confidence_score: Mapped[int] = mapped_column(Integer, nullable=False)
    raw_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    score_breakdown: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Import tracking
    status: Mapped[str] = mapped_column(
        String, nullable=False, default="new", server_default="new"
    )
    import_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    import_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Exclusion tracking (for entries that are not actually artifacts)
    excluded_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        default=None,
        doc="Timestamp when entry was marked as 'not an artifact'",
    )
    excluded_reason: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        default=None,
        doc="User-provided reason for exclusion (optional, max 500 chars)",
    )
    path_segments: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON array of extracted path segments with approval status",
    )

    # Cross-source search fields (populated from frontmatter indexing)
    title: Mapped[Optional[str]] = mapped_column(
        String(200),
        nullable=True,
        comment="Artifact title from frontmatter for search display",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Artifact description from frontmatter for search",
    )
    search_tags: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON array of tags from frontmatter for search filtering",
    )
    search_text: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Concatenated searchable text (title + description + tags)",
    )

    # Deep indexing fields (Phase 1 clone-based artifact indexing)
    deep_search_text: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Full-text content from deep indexing",
    )
    deep_indexed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        comment="Timestamp of last deep indexing",
    )
    deep_index_files: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON array of files included in deep index",
    )

    # PostgreSQL full-text search vector (managed by DB trigger on PostgreSQL)
    # Uses dialect-adaptive TSVectorType: native TSVECTOR on PostgreSQL, Text on SQLite.
    # On SQLite the column exists in the model but is never populated or queried.
    # This column is intentionally omitted from __init__, to_dict(), and all insert/update
    # logic — it is populated exclusively by a PostgreSQL trigger on INSERT/UPDATE.
    search_vector: Mapped[Optional[Any]] = mapped_column(
        TSVectorType(),
        nullable=True,
        index=False,
        deferred=True,
        comment="Managed by PostgreSQL trigger — do not set manually",
    )

    # Additional metadata
    metadata_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    source: Mapped["MarketplaceSource"] = relationship(
        "MarketplaceSource", back_populates="entries"
    )

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "artifact_type IN ('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', "
            "'composite', 'project_config', 'spec_file', 'rule_file', 'context_file', "
            "'progress_template', 'context_module', 'template', 'group', "
            "'deployment_set', 'context_pack', 'bundle')",
            name="check_catalog_artifact_type",
        ),
        CheckConstraint(
            "status IN ('new', 'updated', 'removed', 'imported', 'excluded')",
            name="check_catalog_status",
        ),
        CheckConstraint(
            "confidence_score >= 0 AND confidence_score <= 100",
            name="check_confidence_score",
        ),
    )

    def __repr__(self) -> str:
        """Return string representation of MarketplaceCatalogEntry."""
        return (
            f"<MarketplaceCatalogEntry(id={self.id!r}, name={self.name!r}, "
            f"type={self.artifact_type!r}, status={self.status!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert MarketplaceCatalogEntry to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the catalog entry
        """
        # Parse metadata_json if present
        metadata_dict = None
        if self.metadata_json:
            try:
                metadata_dict = json.loads(self.metadata_json)
            except json.JSONDecodeError:
                metadata_dict = None

        # Parse search_tags JSON if present
        search_tags_list = None
        if self.search_tags:
            try:
                search_tags_list = json.loads(self.search_tags)
            except json.JSONDecodeError:
                search_tags_list = None

        return {
            "id": self.id,
            "source_id": self.source_id,
            "artifact_type": self.artifact_type,
            "name": self.name,
            "path": self.path,
            "upstream_url": self.upstream_url,
            "detected_version": self.detected_version,
            "detected_sha": self.detected_sha,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
            "confidence_score": self.confidence_score,
            "raw_score": self.raw_score,
            "score_breakdown": self.score_breakdown,
            "status": self.status,
            "import_date": self.import_date.isoformat() if self.import_date else None,
            "import_id": self.import_id,
            "excluded_at": self.excluded_at.isoformat() if self.excluded_at else None,
            "excluded_reason": self.excluded_reason,
            "title": self.title,
            "description": self.description,
            "search_tags": search_tags_list,
            "search_text": self.search_text,
            # Deep indexing fields
            "deep_search_text": self.deep_search_text,
            "deep_indexed_at": (
                self.deep_indexed_at.isoformat() if self.deep_indexed_at else None
            ),
            "deep_index_files": self.get_deep_index_files_list(),
            "metadata": metadata_dict,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def get_metadata_dict(self) -> Optional[Dict[str, Any]]:
        """Parse and return metadata as dictionary.

        Returns:
            Parsed metadata dictionary or None if invalid/missing
        """
        if not self.metadata_json:
            return None

        try:
            return json.loads(self.metadata_json)
        except json.JSONDecodeError:
            return None

    def set_metadata_dict(self, metadata_dict: Dict[str, Any]) -> None:
        """Set metadata from dictionary.

        Args:
            metadata_dict: Dictionary to serialize as JSON
        """
        self.metadata_json = json.dumps(metadata_dict)

    def get_search_tags_list(self) -> List[str]:
        """Parse and return search_tags as a list.

        Returns:
            List of tag strings or empty list if invalid/missing
        """
        if not self.search_tags:
            return []

        try:
            tags = json.loads(self.search_tags)
            if isinstance(tags, list):
                return tags
            return []
        except json.JSONDecodeError:
            return []

    def set_search_tags_list(self, tags: List[str]) -> None:
        """Set search_tags from a list.

        Args:
            tags: List of tag strings to serialize as JSON
        """
        if not tags:
            self.search_tags = None
        else:
            self.search_tags = json.dumps(tags)

    def get_deep_index_files_list(self) -> List[str]:
        """Parse and return deep_index_files as a list.

        Returns:
            List of file path strings or empty list if invalid/missing
        """
        if not self.deep_index_files:
            return []

        try:
            files = json.loads(self.deep_index_files)
            if isinstance(files, list):
                return files
            return []
        except json.JSONDecodeError:
            return []

    def set_deep_index_files_list(self, files: List[str]) -> None:
        """Set deep_index_files from a list.

        Args:
            files: List of file path strings to serialize as JSON
        """
        if not files:
            self.deep_index_files = None
        else:
            self.deep_index_files = json.dumps(files)


class ProjectTemplate(Base):
    """Project template for defining reusable artifact deployment patterns.

    Templates provide a way to define standardized project setups with
    predefined artifacts and configurations. Each template belongs to a
    collection and can specify a default project config.

    Attributes:
        id: Unique template identifier (primary key, UUID hex)
        name: Template name (1-255 characters, unique)
        description: Optional detailed description
        collection_id: Foreign key to collections.id
        default_project_config_id: Optional foreign key to artifacts.id for project config
        created_at: Timestamp when template was created
        updated_at: Timestamp when template was last modified
        collection: Parent collection object
        default_config: Optional default project config artifact
        entities: List of template entities (artifacts with deploy order)

    Indexes:
        - idx_templates_name (UNIQUE): Fast lookup by name
        - idx_templates_collection_id: Filter by collection
        - idx_templates_created_at: Sort by creation date
    """

    __tablename__ = "project_templates"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Core fields
    name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Foreign keys
    collection_id: Mapped[str] = mapped_column(
        String, ForeignKey("collections.id", ondelete="CASCADE"), nullable=False
    )
    default_project_config_id: Mapped[Optional[str]] = mapped_column(
        String, ForeignKey("artifacts.id", ondelete="SET NULL"), nullable=True
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    collection: Mapped["Collection"] = relationship(
        "Collection", back_populates="templates"
    )
    default_config: Mapped[Optional["Artifact"]] = relationship(
        "Artifact", foreign_keys=[default_project_config_id]
    )
    entities: Mapped[List["TemplateEntity"]] = relationship(
        "TemplateEntity",
        back_populates="template",
        cascade="all, delete-orphan",
        lazy="selectin",
        order_by="TemplateEntity.deploy_order",
    )

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "length(name) > 0 AND length(name) <= 255",
            name="check_template_name_length",
        ),
        Index("idx_templates_name", "name", unique=True),
        Index("idx_templates_collection_id", "collection_id"),
        Index("idx_templates_created_at", "created_at"),
    )

    def __repr__(self) -> str:
        """Return string representation of ProjectTemplate."""
        return (
            f"<ProjectTemplate(id={self.id!r}, name={self.name!r}, "
            f"collection_id={self.collection_id!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert ProjectTemplate to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the template
        """
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "collection_id": self.collection_id,
            "default_project_config_id": self.default_project_config_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "entity_count": len(self.entities) if self.entities else 0,
        }


class TemplateEntity(Base):
    """Association between ProjectTemplate and Artifact with deployment metadata.

    Represents the many-to-many relationship between templates and artifacts,
    defining which artifacts should be deployed as part of a template with
    specific ordering and requirement flags.

    Attributes:
        template_id: Foreign key to project_templates.id (part of composite PK)
        artifact_id: Foreign key to artifacts.id (part of composite PK)
        deploy_order: Deployment order within template (0-based)
        required: Whether artifact is required for template deployment
        template: Related ProjectTemplate object
        artifact: Related Artifact object

    Indexes:
        - idx_template_entities_template_id: Fast lookup by template
        - idx_template_entities_artifact_id: Fast lookup by artifact
        - idx_template_entities_deploy_order: Ordered queries within template
    """

    __tablename__ = "template_entities"

    # Composite primary key
    template_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("project_templates.id", ondelete="CASCADE"),
        primary_key=True,
    )
    artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.id", ondelete="CASCADE"),
        primary_key=True,
    )

    # Deployment metadata
    deploy_order: Mapped[int] = mapped_column(Integer, nullable=False)
    required: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default="1"
    )

    # Relationships
    template: Mapped["ProjectTemplate"] = relationship(
        "ProjectTemplate", back_populates="entities"
    )
    artifact: Mapped["Artifact"] = relationship("Artifact")

    # Constraints
    __table_args__ = (
        CheckConstraint("deploy_order >= 0", name="check_deploy_order"),
        Index("idx_template_entities_template_id", "template_id"),
        Index("idx_template_entities_artifact_id", "artifact_id"),
        Index("idx_template_entities_deploy_order", "template_id", "deploy_order"),
    )

    def __repr__(self) -> str:
        """Return string representation of TemplateEntity."""
        return (
            f"<TemplateEntity(template_id={self.template_id!r}, "
            f"artifact_id={self.artifact_id!r}, deploy_order={self.deploy_order}, "
            f"required={self.required})>"
        )


class UserRating(Base):
    """User ratings for artifacts.

    Stores individual user ratings and feedback for artifacts. Supports
    optional community sharing for aggregated scoring.

    Attributes:
        id: Unique rating identifier (primary key)
        artifact_id: Artifact identifier (indexed, not FK - external artifacts allowed)
        rating: Integer rating from 1-5 stars
        feedback: Optional text feedback from user
        share_with_community: Whether to include in community aggregation
        rated_at: Timestamp when rating was submitted
        artifacts: Related artifacts (if in local cache)

    Indexes:
        - idx_user_ratings_artifact_id: Fast lookup by artifact
        - idx_user_ratings_artifact_id_rated_at: Composite for artifact+time queries

    Constraints:
        - check_valid_rating: Ensures rating is between 1-5
    """

    __tablename__ = "user_ratings"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    # Core fields
    artifact_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    rating: Mapped[int] = mapped_column(Integer, nullable=False)
    feedback: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    share_with_community: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="0"
    )

    # Timestamp
    rated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Constraints
    __table_args__ = (
        CheckConstraint("rating >= 1 AND rating <= 5", name="check_valid_rating"),
        Index("idx_user_ratings_artifact_id", "artifact_id"),
        Index("idx_user_ratings_artifact_id_rated_at", "artifact_id", "rated_at"),
    )

    def __repr__(self) -> str:
        """Return string representation of UserRating."""
        return (
            f"<UserRating(id={self.id}, artifact_id={self.artifact_id!r}, "
            f"rating={self.rating})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert UserRating to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the rating
        """
        return {
            "id": self.id,
            "artifact_id": self.artifact_id,
            "rating": self.rating,
            "feedback": self.feedback,
            "share_with_community": self.share_with_community,
            "rated_at": self.rated_at.isoformat() if self.rated_at else None,
        }


class CommunityScore(Base):
    """Community scores from external sources.

    Aggregates scoring data from multiple sources including GitHub stars,
    registry popularity, and exported user ratings. Each artifact can have
    multiple scores from different sources.

    Attributes:
        id: Unique score identifier (primary key)
        artifact_id: Artifact identifier (indexed, not FK - external artifacts allowed)
        source: Source identifier ("github_stars", "registry", "user_export")
        score: Normalized score from 0-100
        last_updated: Timestamp when score was last refreshed
        imported_from: Optional source URL or identifier

    Indexes:
        - idx_community_scores_artifact_id: Fast lookup by artifact
        - uq_community_score: Unique constraint on (artifact_id, source)

    Constraints:
        - uq_community_score: One score per artifact per source
    """

    __tablename__ = "community_scores"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    # Core fields
    artifact_id: Mapped[str] = mapped_column(String, nullable=False)
    source: Mapped[str] = mapped_column(String, nullable=False)
    score: Mapped[float] = mapped_column(Float, nullable=False)
    last_updated: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    imported_from: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Constraints
    __table_args__ = (
        UniqueConstraint("artifact_id", "source", name="uq_community_score"),
        Index("idx_community_scores_artifact_id", "artifact_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of CommunityScore."""
        return (
            f"<CommunityScore(id={self.id}, artifact_id={self.artifact_id!r}, "
            f"source={self.source!r}, score={self.score})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert CommunityScore to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the score
        """
        return {
            "id": self.id,
            "artifact_id": self.artifact_id,
            "source": self.source,
            "score": self.score,
            "last_updated": (
                self.last_updated.isoformat() if self.last_updated else None
            ),
            "imported_from": self.imported_from,
        }


class MatchHistory(Base):
    """History of match queries for analytics.

    Tracks artifact matching queries and user behavior to improve future
    matching algorithms. Records confidence scores and whether users
    deployed the matched artifacts.

    Attributes:
        id: Unique history entry identifier (primary key)
        query: Search query text
        artifact_id: Matched artifact identifier (indexed, not FK)
        confidence: Match confidence score (0.0-1.0)
        user_confirmed: Whether user deployed the matched artifact (NULL=unknown)
        matched_at: Timestamp when match was recorded

    Indexes:
        - idx_match_history_artifact_query: Composite for artifact+query analytics

    Note:
        artifact_id has no FK constraint to allow tracking matches for
        external/marketplace artifacts not yet in local cache.
    """

    __tablename__ = "match_history"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    # Core fields
    query: Mapped[str] = mapped_column(String, nullable=False)
    artifact_id: Mapped[str] = mapped_column(String, nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    user_confirmed: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)

    # Timestamp
    matched_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Constraints
    __table_args__ = (
        Index("idx_match_history_artifact_query", "artifact_id", "query"),
    )

    def __repr__(self) -> str:
        """Return string representation of MatchHistory."""
        return (
            f"<MatchHistory(id={self.id}, query={self.query!r}, "
            f"artifact_id={self.artifact_id!r}, confidence={self.confidence})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert MatchHistory to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the match history entry
        """
        return {
            "id": self.id,
            "query": self.query,
            "artifact_id": self.artifact_id,
            "confidence": self.confidence,
            "user_confirmed": self.user_confirmed,
            "matched_at": self.matched_at.isoformat() if self.matched_at else None,
        }


class GitHubRepoCache(Base):
    """Cached GitHub repository statistics.

    Stores GitHub repository stats to minimize API calls and respect rate limits.
    Cache entries expire after a configurable TTL (default: 24 hours).

    Attributes:
        cache_key: Repository identifier in format "owner/repo" (primary key)
        data: JSON-serialized GitHubRepoStats data
        fetched_at: Timestamp when data was fetched from GitHub

    Indexes:
        - idx_github_repo_cache_fetched_at: For TTL-based expiry queries
    """

    __tablename__ = "github_repo_cache"

    # Primary key
    cache_key: Mapped[str] = mapped_column(String, primary_key=True)

    # Core fields
    data: Mapped[str] = mapped_column(Text, nullable=False)

    # Timestamp
    fetched_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Constraints
    __table_args__ = (Index("idx_github_repo_cache_fetched_at", "fetched_at"),)

    def __repr__(self) -> str:
        """Return string representation of GitHubRepoCache."""
        return f"<GitHubRepoCache(cache_key={self.cache_key!r}, fetched_at={self.fetched_at})>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert GitHubRepoCache to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the cache entry
        """
        return {
            "cache_key": self.cache_key,
            "data": json.loads(self.data) if self.data else None,
            "fetched_at": self.fetched_at.isoformat() if self.fetched_at else None,
        }


class CacheMetadata(Base):
    """Cache system metadata.

    Stores key-value pairs for cache system metadata such as schema version,
    last vacuum timestamp, and cached counts.

    Common Keys:
        - schema_version: Database schema version
        - last_vacuum: Last VACUUM operation timestamp
        - last_analyze: Last ANALYZE operation timestamp
        - total_projects: Cached count for performance
        - total_artifacts: Cached count for performance

    Attributes:
        key: Metadata key (primary key)
        value: Metadata value (stored as string)
        updated_at: Timestamp when metadata was last updated
    """

    __tablename__ = "cache_metadata"

    # Primary key
    key: Mapped[str] = mapped_column(String, primary_key=True)

    # Core fields
    value: Mapped[str] = mapped_column(String, nullable=False)

    # Timestamp
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:
        """Return string representation of CacheMetadata."""
        return f"<CacheMetadata(key={self.key!r}, value={self.value!r})>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert CacheMetadata to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the metadata
        """
        return {
            "key": self.key,
            "value": self.value,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


# =============================================================================
# Memory & Context Intelligence System Models
# =============================================================================


class MemoryItem(Base):
    """Project-scoped memory item for the Memory & Context Intelligence System.

    Stores learned knowledge about a project including decisions, constraints,
    gotchas, style rules, and learnings. Each item has a confidence score,
    status lifecycle, provenance tracking, and TTL policies.

    Attributes:
        id: Unique identifier (UUID hex string)
        project_id: Foreign key to projects.id
        type: Memory type (decision, constraint, gotcha, style_rule, learning)
        content: The actual memory content text
        confidence: Confidence score between 0.0 and 1.0
        status: Lifecycle status (candidate, active, stable, deprecated)
        share_scope: Cross-project visibility scope (private, project, global_candidate)
        provenance_json: JSON object tracking origin/source of the memory
        anchors_json: JSON array of structured anchor objects
        git_branch: Promoted git branch provenance field
        git_commit: Promoted git commit provenance field
        session_id: Promoted session identifier provenance field
        agent_type: Promoted agent type provenance field
        model: Promoted model provenance field
        source_type: Promoted source type provenance field
        ttl_policy_json: JSON object with max_age_days, max_idle_days
        content_hash: SHA hash of content for deduplication (unique)
        access_count: Number of times this memory has been accessed
        created_at: ISO datetime when memory was created
        updated_at: ISO datetime when memory was last modified
        deprecated_at: ISO datetime when memory was deprecated (nullable)
        context_modules: List of context modules containing this memory

    Indexes:
        - idx_memory_items_project_status: Filter by project and status
        - idx_memory_items_project_type: Filter by project and type
        - idx_memory_items_created_at: Chronological ordering
        - content_hash UNIQUE: Deduplication
    """

    __tablename__ = "memory_items"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Foreign key
    project_id: Mapped[str] = mapped_column(
        String, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False
    )

    # Core fields
    type: Mapped[str] = mapped_column(String, nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False, default=0.75)
    status: Mapped[str] = mapped_column(
        String, nullable=False, default="candidate", server_default="candidate"
    )
    share_scope: Mapped[str] = mapped_column(
        String, nullable=False, default="project", server_default="project"
    )

    # JSON fields (stored as Text, following codebase convention)
    provenance_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    anchors_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    git_branch: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    git_commit: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    session_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    agent_type: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    model: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    source_type: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, default="manual", server_default="manual"
    )
    ttl_policy_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Deduplication and access tracking
    content_hash: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    access_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )

    # Timestamps (stored as ISO strings, following codebase convention for new tables)
    created_at: Mapped[str] = mapped_column(String, nullable=False)
    updated_at: Mapped[str] = mapped_column(String, nullable=False)
    deprecated_at: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Relationships
    context_modules: Mapped[List["ContextModule"]] = relationship(
        "ContextModule",
        secondary="module_memory_items",
        back_populates="memory_items",
        lazy="select",
    )

    # Constraints and indexes
    __table_args__ = (
        CheckConstraint(
            "confidence >= 0.0 AND confidence <= 1.0",
            name="ck_memory_items_confidence",
        ),
        CheckConstraint(
            "type IN ('decision', 'constraint', 'gotcha', 'style_rule', 'learning')",
            name="ck_memory_items_type",
        ),
        CheckConstraint(
            "status IN ('candidate', 'active', 'stable', 'deprecated')",
            name="ck_memory_items_status",
        ),
        CheckConstraint(
            "share_scope IN ('private', 'project', 'global_candidate')",
            name="ck_memory_items_share_scope",
        ),
        Index("idx_memory_items_project_status", "project_id", "status"),
        Index("idx_memory_items_project_type", "project_id", "type"),
        Index("idx_memory_items_share_scope", "share_scope"),
        Index("idx_memory_items_created_at", "created_at"),
        Index("idx_memory_items_git_branch", "git_branch"),
        Index("idx_memory_items_git_commit", "git_commit"),
        Index("idx_memory_items_session_id", "session_id"),
        Index("idx_memory_items_agent_type", "agent_type"),
        Index("idx_memory_items_model", "model"),
        Index("idx_memory_items_source_type", "source_type"),
    )

    @property
    def provenance(self) -> Optional[Dict[str, Any]]:
        """Parse provenance_json into a dictionary."""
        if self.provenance_json:
            return json.loads(self.provenance_json)
        return None

    @property
    def anchors(self) -> List[Any]:
        """Parse anchors_json into a list of structured anchor objects.

        Legacy records may still contain plain string paths until migrated.
        """
        if self.anchors_json:
            return json.loads(self.anchors_json)
        return []

    @property
    def ttl_policy(self) -> Optional[Dict[str, Any]]:
        """Parse ttl_policy_json into a dictionary."""
        if self.ttl_policy_json:
            return json.loads(self.ttl_policy_json)
        return None

    def __repr__(self) -> str:
        """Return string representation of MemoryItem."""
        return (
            f"<MemoryItem(id={self.id!r}, project_id={self.project_id!r}, "
            f"type={self.type!r}, status={self.status!r}, "
            f"share_scope={self.share_scope!r}, confidence={self.confidence})>"
        )


class ContextModule(Base):
    """Named grouping of memory items with selector criteria.

    Context modules define how memory items are assembled into contextual
    knowledge for different workflows. Each module has selector criteria
    (memory types, confidence thresholds, file patterns, workflow stages)
    and a priority for ordering when multiple modules apply.

    Attributes:
        id: Unique identifier (UUID hex string)
        project_id: Foreign key to projects.id
        name: Human-readable module name
        description: Optional description of the module's purpose
        selectors_json: JSON object with memory_types, min_confidence,
            file_patterns, workflow_stages
        priority: Module priority for ordering (default 5)
        content_hash: Hash of assembled content for cache invalidation
        created_at: ISO datetime when module was created
        updated_at: ISO datetime when module was last modified
        memory_items: List of memory items in this module

    Indexes:
        - idx_context_modules_project: Filter by project
    """

    __tablename__ = "context_modules"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Foreign key
    project_id: Mapped[str] = mapped_column(
        String, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False
    )

    # Core fields
    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # JSON fields
    selectors_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Priority
    priority: Mapped[int] = mapped_column(
        Integer, nullable=False, default=5, server_default="5"
    )

    # Cache hash
    content_hash: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Timestamps
    created_at: Mapped[str] = mapped_column(String, nullable=False)
    updated_at: Mapped[str] = mapped_column(String, nullable=False)

    # Relationships
    memory_items: Mapped[List["MemoryItem"]] = relationship(
        "MemoryItem",
        secondary="module_memory_items",
        back_populates="context_modules",
        lazy="select",
    )

    # Constraints and indexes
    __table_args__ = (Index("idx_context_modules_project", "project_id"),)

    @property
    def selectors(self) -> Optional[Dict[str, Any]]:
        """Parse selectors_json into a dictionary."""
        if self.selectors_json:
            return json.loads(self.selectors_json)
        return None

    def __repr__(self) -> str:
        """Return string representation of ContextModule."""
        return (
            f"<ContextModule(id={self.id!r}, project_id={self.project_id!r}, "
            f"name={self.name!r}, priority={self.priority})>"
        )


class ModuleMemoryItem(Base):
    """Association between ContextModule and MemoryItem with ordering.

    Represents the many-to-many relationship between context modules and
    memory items, allowing memory items to be organized within modules
    with explicit ordering.

    Attributes:
        module_id: Foreign key to context_modules.id (part of composite PK)
        memory_id: Foreign key to memory_items.id (part of composite PK)
        ordering: Display/priority order within module (0-based, default 0)

    Indexes:
        - Primary key covers (module_id, memory_id)
        - idx_module_memory_items_memory: Reverse lookup by memory item
    """

    __tablename__ = "module_memory_items"

    # Composite primary key
    module_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("context_modules.id", ondelete="CASCADE"),
        primary_key=True,
    )
    memory_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("memory_items.id", ondelete="CASCADE"),
        primary_key=True,
    )

    # Ordering
    ordering: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )

    # Indexes
    __table_args__ = (Index("idx_module_memory_items_memory", "memory_id"),)

    def __repr__(self) -> str:
        """Return string representation of ModuleMemoryItem."""
        return (
            f"<ModuleMemoryItem(module_id={self.module_id!r}, "
            f"memory_id={self.memory_id!r}, ordering={self.ordering})>"
        )


# =============================================================================
# Composite Artifact Models (composite-artifact-infrastructure-v1)
# =============================================================================


class CompositeArtifact(Base):
    """Deployable multi-artifact bundle tracked in the cache.

    A CompositeArtifact groups one or more child artifacts (skills, commands,
    agents, hooks, mcp servers) into a single installable unit.  The specific
    variant of the bundle is determined by ``composite_type``, which maps to
    ``CompositeType`` in ``skillmeat.core.artifact_detection`` (currently only
    ``"plugin"`` is implemented; ``"stack"``, ``"suite"``, and ``"skill"`` are
    reserved for future use).

    Primary key format
    ------------------
    ``id`` uses the ``type:name`` composite string used throughout the cache
    layer (e.g., ``"composite:my-plugin"``), matching the convention already
    established for ``Artifact.id``.

    Relationship to CompositeMembership
    ------------------------------------
    Each CompositeArtifact has zero or more CompositeMembership rows that
    reference individual child ``Artifact`` rows via ``artifacts.uuid``
    (not ``artifacts.id``).  Referencing the stable UUID column instead of the
    mutable ``type:name`` primary key satisfies the ADR-007 requirement for
    cross-context artifact identity.  Deleting a CompositeArtifact cascades to
    all its membership rows.

    Attributes:
        id: Primary key in ``type:name`` format (e.g., ``"composite:my-plugin"``)
        collection_id: Owning collection identifier (non-null; mirrors the
            ``collection_id`` stored on each CompositeMembership row for
            denormalised queries)
        composite_type: Variant classifier — ``"plugin"`` (default),
            ``"stack"``, ``"suite"``, or ``"skill"`` — maps to ``CompositeType`` enum
        display_name: Human-readable label for the composite (nullable)
        description: Free-text description (nullable)
        metadata_json: Raw JSON string for future extension (nullable Text,
            not a typed JSON column so that schema migrations are minimised)
        created_at: UTC timestamp when first cached
        updated_at: UTC timestamp on last update (auto-refreshed on writes)
        memberships: List of CompositeMembership children

    Indexes:
        - idx_composite_artifacts_collection_id: Filter by owning collection
        - idx_composite_artifacts_composite_type: Filter by variant
    """

    __tablename__ = "composite_artifacts"

    # Primary key — type:name string (e.g., "composite:my-plugin")
    id: Mapped[str] = mapped_column(String, primary_key=True)

    # Owning collection
    collection_id: Mapped[str] = mapped_column(String, nullable=False)

    # Composite variant — maps to CompositeType enum ("plugin" | "stack" | "suite" | "skill")
    composite_type: Mapped[str] = mapped_column(
        String, nullable=False, default="plugin", server_default="plugin"
    )

    # Display fields
    display_name: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Extensibility — raw JSON string kept as Text to avoid schema churn
    metadata_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    memberships: Mapped[List["CompositeMembership"]] = relationship(
        "CompositeMembership",
        back_populates="composite",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    # Constraints and indexes
    __table_args__ = (
        CheckConstraint(
            "composite_type IN ('plugin', 'stack', 'suite', 'skill')",
            name="check_composite_artifact_type",
        ),
        Index("idx_composite_artifacts_collection_id", "collection_id"),
        Index("idx_composite_artifacts_composite_type", "composite_type"),
    )

    def __repr__(self) -> str:
        """Return string representation of CompositeArtifact."""
        return (
            f"<CompositeArtifact(id={self.id!r}, "
            f"composite_type={self.composite_type!r}, "
            f"collection_id={self.collection_id!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert CompositeArtifact to dictionary for JSON serialisation.

        Returns:
            Dictionary representation of the composite artifact.
        """
        return {
            "id": self.id,
            "collection_id": self.collection_id,
            "composite_type": self.composite_type,
            "display_name": self.display_name,
            "description": self.description,
            "metadata_json": self.metadata_json,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "memberships": [m.to_dict() for m in self.memberships],
        }


class CompositeMembership(Base):
    """Child-artifact membership within a CompositeArtifact.

    Records that a specific ``Artifact`` (identified by its stable UUID per
    ADR-007) is a member of a ``CompositeArtifact``.  Multiple composites can
    include the same child artifact; the composite primary key covers
    ``(collection_id, composite_id, child_artifact_uuid)`` to enforce
    uniqueness within a collection context while allowing cross-collection
    sharing of the same child.

    Foreign-key semantics
    ---------------------
    - ``composite_id`` → ``composite_artifacts.id`` (``ON DELETE CASCADE``):
      removing the parent composite automatically removes all its membership
      rows, preventing orphaned references.
    - ``child_artifact_uuid`` → ``artifacts.uuid`` (``ON DELETE CASCADE``):
      referencing the stable UUID column (not the mutable ``type:name`` id)
      satisfies the ADR-007 cross-context identity requirement and means
      renaming an artifact does not break membership records.  Deleting the
      child artifact from the cache also purges its membership rows.

    Bidirectional relationship note
    --------------------------------
    Both ``Artifact.composite_memberships`` and the ``child_artifact``
    relationship here carry an explicit ``foreign_keys=`` argument.  Without
    it SQLAlchemy raises ``AmbiguousForeignKeysError`` because
    ``CompositeMembership`` contains two foreign keys that both ultimately
    reference tables related to artifacts (``composite_artifacts`` and
    ``artifacts``).

    Attributes:
        collection_id: Owning collection (part of composite PK; denormalised
            from ``CompositeArtifact.collection_id`` for partition-style queries)
        composite_id: FK to ``composite_artifacts.id``, CASCADE delete
            (part of composite PK)
        child_artifact_uuid: FK to ``artifacts.uuid``, CASCADE delete
            (part of composite PK)
        relationship_type: Semantic label for the membership edge, default
            ``"contains"`` (reserved for future graph-style queries)
        pinned_version_hash: Optional content hash locking the child to a
            specific snapshot; ``None`` means "always use latest"
        membership_metadata: Raw JSON string for future per-edge metadata
        created_at: UTC timestamp when membership was created

    Indexes:
        - Primary key covers (collection_id, composite_id, child_artifact_uuid)
        - idx_composite_memberships_composite_id: fast child lookup by parent
        - idx_composite_memberships_child_uuid: reverse lookup — all composites
          containing a given child artifact
    """

    __tablename__ = "composite_memberships"

    # Composite primary key
    collection_id: Mapped[str] = mapped_column(String, primary_key=True)
    composite_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("composite_artifacts.id", ondelete="CASCADE"),
        primary_key=True,
    )
    child_artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        primary_key=True,
    )

    # Edge semantics
    relationship_type: Mapped[str] = mapped_column(
        String, nullable=False, default="contains", server_default="contains"
    )

    # Optional version pin — None means "track latest"
    pinned_version_hash: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Display order within the composite (0-based, nullable for backward compat)
    position: Mapped[Optional[int]] = mapped_column(
        Integer, nullable=True, default=None
    )

    # Extensibility — raw JSON string for future per-membership metadata
    membership_metadata: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Relationships — explicit foreign_keys= on both sides avoids
    # AmbiguousForeignKeysError (see docstring for rationale).
    composite: Mapped["CompositeArtifact"] = relationship(
        "CompositeArtifact",
        back_populates="memberships",
        lazy="joined",
    )
    child_artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[child_artifact_uuid],
        back_populates="composite_memberships",
        lazy="joined",
    )

    # Indexes
    __table_args__ = (
        Index("idx_composite_memberships_composite_id", "composite_id"),
        Index("idx_composite_memberships_child_uuid", "child_artifact_uuid"),
    )

    def __repr__(self) -> str:
        """Return string representation of CompositeMembership."""
        return (
            f"<CompositeMembership(composite_id={self.composite_id!r}, "
            f"child_artifact_uuid={self.child_artifact_uuid!r}, "
            f"relationship_type={self.relationship_type!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert CompositeMembership to dictionary for JSON serialisation.

        Returns:
            Dictionary representation of the membership edge, including a
            summary of the child artifact when it has been loaded.
        """
        result: Dict[str, Any] = {
            "collection_id": self.collection_id,
            "composite_id": self.composite_id,
            "child_artifact_uuid": self.child_artifact_uuid,
            "relationship_type": self.relationship_type,
            "pinned_version_hash": self.pinned_version_hash,
            "position": self.position,
            "membership_metadata": self.membership_metadata,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
        # Include a lightweight child summary when the relationship is loaded
        if self.child_artifact is not None:
            result["child_artifact"] = {
                "id": self.child_artifact.id,
                "uuid": self.child_artifact.uuid,
                "name": self.child_artifact.name,
                "type": self.child_artifact.type,
            }
        return result


# =============================================================================
# Bundle Models (ADR-008: artifact-bundle-v1)
# =============================================================================


class BundleStatus(enum.Enum):
    """Lifecycle status for a BundleEntity.

    Mirrors the ``status`` string stored in the ``bundles.status`` column.
    Values map directly to the string representation written to the DB so
    that ``bundle.status`` can be compared to ``BundleStatus.draft.value``
    without a round-trip through the enum.

    Members:
        draft:       Bundle is being assembled; not visible in the marketplace.
        published:   Bundle is publicly listed and available for install.
        deprecated:  Bundle is no longer recommended; preserved for history.
    """

    draft = "draft"
    published = "published"
    deprecated = "deprecated"


class BundleEntity(Base):
    """Publishable, versioned collection of artifacts tracked in the cache.

    A BundleEntity represents a curated, named set of artifacts that can be
    published to the marketplace, versioned with semver, and installed by other
    users as a single unit.  It is the ADR-008 successor to the informal
    "composite" concept: where ``CompositeArtifact`` (ADR-007) focuses on
    deployment-time composition within a single project, ``BundleEntity``
    focuses on distribution and sharing across projects and users.

    Primary key format
    ------------------
    ``id`` stores a UUID hex string generated by ``uuid.uuid4().hex``,
    matching the convention used by ``DeploymentSet`` and other post-ADR-007
    models that no longer embed semantic information in the PK.

    Relationship to BundleMembership
    ---------------------------------
    Each BundleEntity has zero or more BundleMembership rows that link
    individual ``Artifact`` rows (via the stable ``artifacts.uuid`` column)
    to the bundle.  Deleting a BundleEntity cascades to all its membership
    rows.

    Attributes:
        id: UUID hex primary key (e.g., ``"a1b2c3d4..."``)
        collection_id: FK to ``collections.id`` — the owning collection (non-null)
        name: Human-readable bundle name, indexed for fast search
        description: Optional free-text description
        version: Optional semver string (e.g., ``"1.2.0"``); ``None`` before
            first publish
        status: Lifecycle state — one of ``"draft"``, ``"published"``,
            ``"deprecated"`` (see ``BundleStatus``); default ``"draft"``
        tags: JSON array of tag strings stored as a Text column for
            schema-migration simplicity (e.g., ``'["python", "llm"]'``)
        license: Optional SPDX license identifier (e.g., ``"MIT"``)
        homepage: Optional URL for the bundle's homepage or documentation
        repository: Optional URL for the bundle's source repository
        created_at: UTC timestamp when first cached
        updated_at: UTC timestamp on last update (auto-refreshed on writes)
        published_at: UTC timestamp when the bundle was first published;
            ``None`` for drafts
        memberships: List of BundleMembership children

    Indexes:
        - idx_bundles_collection_id: Filter bundles by owning collection
        - idx_bundles_name: Fast name-based search and uniqueness checks
        - idx_bundles_status: Filter by lifecycle state (e.g., published only)
    """

    __tablename__ = "bundles"

    # Primary key — UUID hex
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Owning collection
    collection_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("collections.id"),
        nullable=False,
    )

    # Core descriptive fields
    name: Mapped[str] = mapped_column(String, nullable=False, index=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Versioning
    version: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Lifecycle status — stored as string; see BundleStatus enum
    status: Mapped[str] = mapped_column(
        String, nullable=False, default="draft", server_default="draft"
    )

    # Tags — JSON array stored as Text to avoid schema-migration overhead
    tags: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Publishing metadata
    license: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    homepage: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    repository: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )
    published_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    memberships: Mapped[List["BundleMembership"]] = relationship(
        "BundleMembership",
        back_populates="bundle",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    scaffold_template: Mapped[Optional["ScaffoldTemplate"]] = relationship(
        "ScaffoldTemplate",
        back_populates="bundle",
        uselist=False,
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    # Constraints and indexes
    __table_args__ = (
        Index("idx_bundles_collection_id", "collection_id"),
        Index("idx_bundles_name", "name"),
        Index("idx_bundles_status", "status"),
    )

    def __repr__(self) -> str:
        """Return string representation of BundleEntity."""
        return (
            f"<BundleEntity(id={self.id!r}, "
            f"name={self.name!r}, "
            f"status={self.status!r}, "
            f"collection_id={self.collection_id!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert BundleEntity to dictionary for JSON serialisation.

        Returns:
            Dictionary representation of the bundle, including a list of
            serialised BundleMembership children when the relationship has
            been loaded.
        """
        return {
            "id": self.id,
            "collection_id": self.collection_id,
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "status": self.status,
            "tags": self.tags,
            "license": self.license,
            "homepage": self.homepage,
            "repository": self.repository,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "published_at": (
                self.published_at.isoformat() if self.published_at else None
            ),
            "memberships": [m.to_dict() for m in self.memberships],
        }


class BundleMembership(Base):
    """Polymorphic membership record within a BundleEntity.

    Each row represents one member of a ``BundleEntity``.  Members may be
    either a collection artifact (``member_type="artifact"``) or a context
    entity (``member_type="context_entity"``).  The discriminator column
    ``member_type`` controls which reference column is populated:

    - ``member_type="artifact"``       → ``artifact_uuid`` is set,
                                         ``context_entity_id`` is NULL
    - ``member_type="context_entity"`` → ``context_entity_id`` is set,
                                         ``artifact_uuid`` is NULL

    Primary key
    -----------
    A standalone UUID ``id`` column is used as the sole primary key.  This
    replaces the previous ``(bundle_id, artifact_uuid)`` composite PK, which
    could not accommodate NULL values required by the polymorphic design.
    A unique constraint on ``(bundle_id, artifact_uuid)`` (partial, filtered
    to non-NULL ``artifact_uuid``) preserves the one-artifact-per-bundle
    invariant at the application layer; the same logic is enforced by the
    repository on insert.

    Foreign-key semantics
    ---------------------
    - ``bundle_id`` → ``bundles.id`` (``ON DELETE CASCADE``):
      removing the parent bundle automatically removes all its membership
      rows, preventing orphaned references.
    - ``artifact_uuid`` → ``artifacts.uuid`` (``ON DELETE CASCADE``):
      referencing the stable UUID column (not the mutable ``type:name`` id)
      satisfies the ADR-007 cross-context identity requirement.  Deleting
      the artifact from the cache also purges its bundle membership rows.
    - ``context_entity_id``: plain ``String``, **no FK constraint** — context
      entities are not yet an ORM model; application-level lookups are used
      instead.  This avoids SQLite FK complications until a ``ContextEntity``
      table is formally introduced.

    Bidirectional relationship note
    --------------------------------
    Both ORM relationships carry an explicit ``foreign_keys=`` argument to
    avoid ``AmbiguousForeignKeysError``, following the same pattern used
    in ``CompositeMembership``.

    No ``ContextEntity`` ORM model currently exists; the relationship to
    context entities is handled at the application level via
    ``context_entity_id`` lookups.

    Attributes:
        id: Unique row identifier (UUID hex, primary key)
        bundle_id: FK to ``bundles.id``, CASCADE delete (required)
        member_type: Discriminator — ``"artifact"`` or ``"context_entity"``
        artifact_uuid: FK to ``artifacts.uuid``, CASCADE delete; NULL for
            context-entity members
        context_entity_id: Plain string reference to a context entity; NULL
            for artifact members (no ORM FK — application-level lookup)
        artifact_tier: Integer tier classification for the artifact within
            the bundle: 0 = standalone, 1 = composable, 2 = orchestrator
        relationship_type: Semantic label for the membership edge, default
            ``"contains"`` (reserved for future graph-style queries)
        pinned_version_hash: Optional content hash locking the artifact to a
            specific snapshot; ``None`` means "always use latest"
        added_at: UTC timestamp when the member was added to the bundle

    Indexes:
        - idx_bundle_memberships_bundle_id: fast member lookup by bundle
        - idx_bundle_memberships_artifact_uuid: reverse lookup — all bundles
          containing a given artifact
        - idx_bundle_memberships_context_entity_id: reverse lookup — all
          bundles containing a given context entity
        - idx_bundle_memberships_member_type: filter by member type
    """

    __tablename__ = "bundle_memberships"

    # Standalone primary key — UUID hex (replaces former composite PK so that
    # artifact_uuid can be NULL for context-entity members).
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Parent bundle FK
    bundle_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("bundles.id", ondelete="CASCADE"),
        nullable=False,
    )

    # Polymorphic discriminator — "artifact" | "context_entity"
    member_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        server_default="artifact",
        comment='Discriminator: "artifact" or "context_entity"',
    )

    # Artifact reference — NULL for context-entity members
    artifact_uuid: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        nullable=True,
        comment="ADR-007 stable artifact UUID; NULL when member_type='context_entity'",
    )

    # Context entity reference — plain String, no FK (no ORM model yet)
    context_entity_id: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Context entity ID; NULL when member_type='artifact'",
    )

    # Tier classification — 0=standalone, 1=composable, 2=orchestrator
    artifact_tier: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Edge semantics
    relationship_type: Mapped[str] = mapped_column(
        String, nullable=False, default="contains", server_default="contains"
    )

    # Optional version pin — None means "track latest"
    pinned_version_hash: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Timestamp
    added_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Relationships — explicit foreign_keys= on both sides avoids
    # AmbiguousForeignKeysError (see docstring for rationale).
    # No relationship for context_entity_id — no ORM model exists yet.
    bundle: Mapped["BundleEntity"] = relationship(
        "BundleEntity",
        back_populates="memberships",
        foreign_keys=[bundle_id],
        lazy="joined",
    )
    child_artifact: Mapped[Optional["Artifact"]] = relationship(
        "Artifact",
        foreign_keys=[artifact_uuid],
        primaryjoin="BundleMembership.artifact_uuid == Artifact.uuid",
        lazy="joined",
    )

    # Indexes
    __table_args__ = (
        Index("idx_bundle_memberships_bundle_id", "bundle_id"),
        Index("idx_bundle_memberships_artifact_uuid", "artifact_uuid"),
        Index("idx_bundle_memberships_context_entity_id", "context_entity_id"),
        Index("idx_bundle_memberships_member_type", "member_type"),
    )

    def __repr__(self) -> str:
        """Return string representation of BundleMembership."""
        return (
            f"<BundleMembership(id={self.id!r}, "
            f"bundle_id={self.bundle_id!r}, "
            f"member_type={self.member_type!r}, "
            f"artifact_uuid={self.artifact_uuid!r}, "
            f"context_entity_id={self.context_entity_id!r}, "
            f"relationship_type={self.relationship_type!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert BundleMembership to dictionary for JSON serialisation.

        Returns:
            Dictionary representation of the membership edge, including a
            summary of the child artifact when it has been loaded (artifact
            members only).
        """
        result: Dict[str, Any] = {
            "id": self.id,
            "bundle_id": self.bundle_id,
            "member_type": self.member_type,
            "artifact_uuid": self.artifact_uuid,
            "context_entity_id": self.context_entity_id,
            "artifact_tier": self.artifact_tier,
            "relationship_type": self.relationship_type,
            "pinned_version_hash": self.pinned_version_hash,
            "added_at": self.added_at.isoformat() if self.added_at else None,
        }
        # Include a lightweight child summary when the relationship is loaded
        # (only populated for artifact members).
        if self.child_artifact is not None:
            result["child_artifact"] = {
                "id": self.child_artifact.id,
                "uuid": self.child_artifact.uuid,
                "name": self.child_artifact.name,
                "type": self.child_artifact.type,
            }
        return result


# =============================================================================
# Deployment Set Models (deployment-sets-v1)
# =============================================================================


class DeploymentSet(Base):
    """Named, ordered set of artifacts/groups for batch deployment.

    A DeploymentSet groups collection artifacts, artifact groups, and/or
    nested deployment sets into a single deployable unit.  Membership is
    tracked via ``DeploymentSetMember`` rows that use a polymorphic
    reference: exactly one of ``artifact_uuid``, ``group_id``, or
    ``member_set_id`` must be non-null on each member row (enforced by a
    DB CHECK constraint on that table).

    Attributes:
        id: Unique identifier (UUID hex, primary key)
        name: Human-readable set name (required)
        description: Optional free-text description
        color: Optional hex color code (e.g. ``"#7c3aed"``), max 7 chars
        icon: Optional icon identifier string (e.g. ``"layers"``), max 64 chars
        tags_json: JSON-serialized list of tag strings, default ``"[]"``
        owner_id: Owning user / identity scope (required)
        remote_url: Remote Git repository URL; populated when platform is
            ``"remote_git"`` (e.g. Backstage / IDP deployments). ``None``
            for all local deployment sets.
        provisioned_by: Audit field identifying the provisioning agent or
            system (e.g. ``"idp"``, ``"backstage"``). ``None`` for sets
            created through standard local workflows.
        created_at: UTC timestamp when the set was created
        updated_at: UTC timestamp on last modification (auto-refreshed)
        members: Ordered list of ``DeploymentSetMember`` children

    Indexes:
        - idx_deployment_sets_owner_id: Fast lookup by owner
        - idx_deployment_sets_created_at: Chronological queries
    """

    __tablename__ = "deployment_sets"

    # Primary key — UUID hex
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Core fields
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    color: Mapped[Optional[str]] = mapped_column(String(7), nullable=True)
    icon: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    tags_json: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        default="[]",
        server_default="[]",
        comment="JSON-serialized list of tag strings",
    )

    # Ownership
    owner_id: Mapped[str] = mapped_column(String, nullable=False)

    # Remote deployment fields (populated when platform="remote_git")
    remote_url: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        default=None,
        comment="Remote Git repository URL for remote_git platform deployments",
    )
    provisioned_by: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        default=None,
        comment="Audit field: provisioning agent/system (e.g. 'idp', 'backstage')",
    )

    # Backstage v2 integration fields
    bundle_id: Mapped[Optional[str]] = mapped_column(
        String(36),
        nullable=True,
        default=None,
        comment="UUID of the associated bundle (stored as string for SQLite compat)",
    )
    bundle_version: Mapped[Optional[str]] = mapped_column(
        String(100),
        nullable=True,
        default=None,
        comment="Version string of the associated bundle",
    )
    platform: Mapped[Optional[str]] = mapped_column(
        String(50),
        nullable=True,
        default=None,
        comment="Target deployment platform (e.g. 'backstage', 'local', 'remote_git')",
    )
    requested_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        default=None,
        comment="Identity of the actor who requested this deployment set",
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    members: Mapped[List["DeploymentSetMember"]] = relationship(
        "DeploymentSetMember",
        foreign_keys="[DeploymentSetMember.set_id]",
        back_populates="deployment_set",
        cascade="all, delete-orphan",
        lazy="selectin",
        order_by="DeploymentSetMember.position",
    )
    tag_objects: Mapped[List["Tag"]] = relationship(
        "Tag",
        secondary="deployment_set_tags",
        primaryjoin="DeploymentSet.id == DeploymentSetTag.deployment_set_id",
        secondaryjoin="foreign(DeploymentSetTag.tag_id) == Tag.id",
        lazy="selectin",
        viewonly=True,
    )
    drift_check_results: Mapped[List["DriftCheckResult"]] = relationship(
        "DriftCheckResult",
        back_populates="deployment_set",
        cascade="all, delete-orphan",
        lazy="selectin",
        order_by="DriftCheckResult.checked_at",
    )

    # Constraints and indexes
    __table_args__ = (
        CheckConstraint(
            "length(name) > 0 AND length(name) <= 255",
            name="check_deployment_set_name_length",
        ),
        Index("idx_deployment_sets_owner_id", "owner_id"),
        Index("idx_deployment_sets_created_at", "created_at"),
    )

    def __repr__(self) -> str:
        """Return string representation of DeploymentSet."""
        return (
            f"<DeploymentSet(id={self.id!r}, name={self.name!r}, "
            f"owner_id={self.owner_id!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert DeploymentSet to dictionary for JSON serialisation."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "tags": self.get_tags(),
            "owner_id": self.owner_id,
            "remote_url": self.remote_url,
            "provisioned_by": self.provisioned_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "members": [m.to_dict() for m in self.members],
        }

    def get_tags(self) -> List[str]:
        """Return tag names from the relational tag_objects relationship.

        Falls back to parsing tags_json for backward compatibility during
        migration when tag_objects may not yet be populated.
        """
        if self.tag_objects:
            return [t.name for t in self.tag_objects]
        # Fallback to tags_json for backward compatibility during migration
        if not self.tags_json:
            return []
        try:
            parsed = json.loads(self.tags_json)
        except json.JSONDecodeError:
            return []
        return parsed if isinstance(parsed, list) else []

    def set_tags(self, tags: List[str]) -> None:
        """Persist tags from a list as JSON text (legacy — prefer junction table).

        Kept for backward compatibility. New code should use the repository's
        _sync_tags() method which writes to the deployment_set_tags junction table.
        """
        self.tags_json = json.dumps(tags or [])


class DeploymentSetMember(Base):
    """Polymorphic member entry within a DeploymentSet.

    Each row references exactly one of four target types via a mutually
    exclusive nullable column — artifact, group, a nested deployment set,
    or a workflow.  A DB CHECK constraint enforces that exactly one reference
    is non-null.

    Member type semantics
    ---------------------
    - ``artifact_uuid`` set  → member is a collection artifact (ADR-007 UUID)
    - ``group_id`` set       → member is an artifact group
    - ``member_set_id`` set  → member is a nested DeploymentSet (nesting)
    - ``workflow_id`` set    → member is a Workflow definition

    Attributes:
        id: Unique identifier (UUID hex, primary key)
        set_id: FK to ``deployment_sets.id``, CASCADE delete (required)
        artifact_uuid: Collection artifact UUID (nullable; one-of-four)
        group_id: Artifact group id (nullable; one-of-four)
        member_set_id: Nested deployment set id (nullable; one-of-four)
        workflow_id: Workflow id (nullable; one-of-four)
        position: Display/deployment order within the set (0-based, default 0)
        created_at: UTC timestamp when membership was created

    CHECK constraint:
        Exactly one of ``artifact_uuid``, ``group_id``, ``member_set_id``,
        ``workflow_id`` must be non-null.  Uses ``CASE WHEN … THEN 1 ELSE 0
        END`` summation for dual-dialect compatibility (SQLite + PostgreSQL).

    Indexes:
        - idx_deployment_set_members_set_id: Fast child lookup by parent set
        - idx_deployment_set_members_member_set_id: Reverse lookup for nesting
        - idx_deployment_set_members_set_position: Ordered retrieval within set
        - idx_deployment_set_members_workflow_id: Fast lookup by workflow
    """

    __tablename__ = "deployment_set_members"

    # Primary key — UUID hex
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Parent set FK
    set_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("deployment_sets.id", ondelete="CASCADE"),
        nullable=False,
    )

    # Polymorphic references — exactly one must be non-null (CHECK constraint)
    artifact_uuid: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Collection artifact UUID (ADR-007 stable identity)",
    )
    group_id: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Artifact group id",
    )
    member_set_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("deployment_sets.id", ondelete="SET NULL"),
        nullable=True,
        comment="Nested deployment set id for hierarchical sets",
    )
    workflow_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("workflows.id", ondelete="CASCADE"),
        nullable=True,
        comment="Workflow id (WAW-P1.1)",
    )

    # Ordering
    position: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )

    # Timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Relationships
    deployment_set: Mapped["DeploymentSet"] = relationship(
        "DeploymentSet",
        back_populates="members",
        foreign_keys=[set_id],
        lazy="joined",
    )
    nested_set: Mapped[Optional["DeploymentSet"]] = relationship(
        "DeploymentSet",
        foreign_keys=[member_set_id],
        lazy="joined",
    )
    workflow: Mapped[Optional["Workflow"]] = relationship(
        "Workflow",
        back_populates="deployment_set_members",
        foreign_keys="[DeploymentSetMember.workflow_id]",
        lazy="select",
    )

    # Constraints and indexes
    __table_args__ = (
        CheckConstraint(
            "(CASE WHEN artifact_uuid IS NOT NULL THEN 1 ELSE 0 END)"
            " + (CASE WHEN group_id IS NOT NULL THEN 1 ELSE 0 END)"
            " + (CASE WHEN member_set_id IS NOT NULL THEN 1 ELSE 0 END)"
            " + (CASE WHEN workflow_id IS NOT NULL THEN 1 ELSE 0 END) = 1",
            name="check_deployment_set_member_one_ref",
        ),
        CheckConstraint("position >= 0", name="check_deployment_set_member_position"),
        Index("idx_deployment_set_members_set_id", "set_id"),
        Index("idx_deployment_set_members_member_set_id", "member_set_id"),
        Index("idx_deployment_set_members_set_position", "set_id", "position"),
        Index("idx_deployment_set_members_workflow_id", "workflow_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of DeploymentSetMember."""
        if self.artifact_uuid:
            ref = f"artifact_uuid={self.artifact_uuid!r}"
        elif self.group_id:
            ref = f"group_id={self.group_id!r}"
        elif self.workflow_id:
            ref = f"workflow_id={self.workflow_id!r}"
        else:
            ref = f"member_set_id={self.member_set_id!r}"
        return (
            f"<DeploymentSetMember(id={self.id!r}, set_id={self.set_id!r}, "
            f"{ref}, position={self.position})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert DeploymentSetMember to dictionary for JSON serialisation."""
        return {
            "id": self.id,
            "set_id": self.set_id,
            "artifact_uuid": self.artifact_uuid,
            "group_id": self.group_id,
            "member_set_id": self.member_set_id,
            "workflow_id": self.workflow_id,
            "position": self.position,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    @property
    def member_type(self) -> str:
        """Return the member type as a string: 'artifact', 'group', 'set', or 'workflow'."""
        if self.artifact_uuid is not None:
            return "artifact"
        if self.group_id is not None:
            return "group"
        if self.workflow_id is not None:
            return "workflow"
        return "set"


class CustomColor(Base):
    """User-defined custom color stored in the palette registry.

    Tracks hex color values that users have added to the site-wide color
    management system. Each color is uniquely identified by its hex code
    and may carry an optional human-readable name.

    Attributes:
        id: Unique color identifier (primary key, UUID hex)
        hex: CSS hex color string, e.g. ``#7c3aed`` (7 chars, UNIQUE, NOT NULL)
        name: Optional human-readable label for the color
        created_at: Timestamp when the color was first registered

    Indexes:
        - idx_custom_colors_hex (UNIQUE): Fast lookup and uniqueness enforcement
    """

    __tablename__ = "custom_colors"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Core fields
    hex: Mapped[str] = mapped_column(
        String(7),
        nullable=False,
        unique=True,
        comment="CSS hex color string including leading '#', e.g. #7c3aed",
    )
    name: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="Optional human-readable label for the color",
    )

    # Timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Constraints and indexes
    __table_args__ = (
        CheckConstraint(
            "hex LIKE '#______' OR hex LIKE '#___'",
            name="check_custom_color_hex_format",
        ),
        Index("idx_custom_colors_hex", "hex", unique=True),
    )

    def __repr__(self) -> str:
        """Return string representation of CustomColor."""
        return f"<CustomColor(id={self.id!r}, hex={self.hex!r}, name={self.name!r})>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert CustomColor to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the custom color
        """
        return {
            "id": self.id,
            "hex": self.hex,
            "name": self.name,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# =============================================================================
# Similar Artifacts
# =============================================================================


class DuplicatePair(Base):
    """Persisted record of a similar/duplicate artifact pair.

    Stores the result of pairwise similarity analysis between two collection
    artifacts.  When users dismiss a suggestion (e.g. "these are not really
    duplicates") the ``ignored`` flag is set to ``True`` so the pair is
    excluded from future results without being permanently deleted.

    Attributes:
        id: Unique record identifier (primary key, UUID hex)
        artifact1_uuid: UUID of the first artifact in the pair
        artifact2_uuid: UUID of the second artifact in the pair
        similarity_score: Normalised similarity score in the range [0.0, 1.0]
        match_reasons: JSON-encoded list of human-readable reasons for the match
        ignored: When True the user has dismissed this pair; excluded from UI
        created_at: Timestamp when the pair was first detected
        updated_at: Timestamp of the most recent update to this record

    Constraints:
        - check_duplicate_pair_score: similarity_score must be in [0.0, 1.0]
        - uq_duplicate_pair_artifacts: (artifact1_uuid, artifact2_uuid) is UNIQUE
          so the same ordered pair cannot be inserted twice

    Indexes:
        - idx_duplicate_pairs_artifact1: Fast lookup by artifact1_uuid
        - idx_duplicate_pairs_artifact2: Fast lookup by artifact2_uuid
        - idx_duplicate_pairs_ignored: Filter on ignored flag efficiently
    """

    __tablename__ = "duplicate_pairs"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Pair members — reference collection_artifacts by UUID
    artifact1_uuid: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        comment="UUID of the first artifact in the similar pair",
    )
    artifact2_uuid: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        comment="UUID of the second artifact in the similar pair",
    )

    # Similarity data
    similarity_score: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        comment="Normalised similarity score in the range [0.0, 1.0]",
    )
    match_reasons: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        default="[]",
        server_default="[]",
        comment="JSON-encoded list of human-readable match reason strings",
    )

    # User-controlled dismissal flag
    ignored: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="0",
        comment="True when the user has dismissed this pair from the UI",
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Constraints and indexes
    __table_args__ = (
        CheckConstraint(
            "similarity_score >= 0.0 AND similarity_score <= 1.0",
            name="check_duplicate_pair_score",
        ),
        UniqueConstraint(
            "artifact1_uuid",
            "artifact2_uuid",
            name="uq_duplicate_pair_artifacts",
        ),
        Index("idx_duplicate_pairs_artifact1", "artifact1_uuid"),
        Index("idx_duplicate_pairs_artifact2", "artifact2_uuid"),
        Index("idx_duplicate_pairs_ignored", "ignored"),
    )

    def __repr__(self) -> str:
        """Return string representation of DuplicatePair."""
        return (
            f"<DuplicatePair(id={self.id!r}, "
            f"artifact1={self.artifact1_uuid!r}, "
            f"artifact2={self.artifact2_uuid!r}, "
            f"score={self.similarity_score!r}, "
            f"ignored={self.ignored!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert DuplicatePair to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the duplicate pair
        """
        import json as _json

        reasons: List[str] = []
        if self.match_reasons:
            try:
                reasons = _json.loads(self.match_reasons)
            except (ValueError, TypeError):
                reasons = []

        return {
            "id": self.id,
            "artifact1_uuid": self.artifact1_uuid,
            "artifact2_uuid": self.artifact2_uuid,
            "similarity_score": self.similarity_score,
            "match_reasons": reasons,
            "ignored": self.ignored,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


# =============================================================================
# SimilarityCache (SSO-2.2)
# =============================================================================


class SimilarityCache(Base):
    """Cached pairwise composite similarity score between two collection artifacts.

    Stores precomputed similarity results so that expensive scoring operations
    are not repeated on every request.  The entry is keyed by the ordered pair
    ``(source_artifact_uuid, target_artifact_uuid)`` — each direction is stored
    independently, allowing asymmetric scoring if the underlying algorithm
    supports it.

    Attributes:
        source_artifact_uuid: UUID of the artifact being compared from
        target_artifact_uuid: UUID of the artifact being compared to
        composite_score: Final weighted composite score in [0.0, 1.0]
        breakdown_json: Optional JSON-encoded dict of per-dimension scores
        computed_at: Timestamp when the score was last computed

    Constraints:
        - Composite primary key on (source_artifact_uuid, target_artifact_uuid)
        - FK CASCADE DELETE on both UUID columns referencing collection_artifacts.uuid

    Indexes:
        - idx_similarity_cache_source_score: Fast retrieval of top-N similar
          artifacts for a given source, ordered by score descending
    """

    __tablename__ = "similarity_cache"

    # Composite primary key — ordered pair of artifact UUIDs
    source_artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        primary_key=True,
        comment="UUID of the source artifact (the 'query' side of the comparison)",
    )
    target_artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        primary_key=True,
        comment="UUID of the target artifact (the 'candidate' side of the comparison)",
    )

    # Similarity result
    composite_score: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        comment="Final weighted composite similarity score in [0.0, 1.0]",
    )
    breakdown_json: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-encoded dict of per-dimension scores (e.g. name, tags, text)",
    )

    # Timestamp for cache invalidation
    computed_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="Timestamp when this score was computed; used for cache invalidation",
    )

    # Constraints and indexes
    __table_args__ = (
        # Composite index on source + score DESC for efficient top-N lookups
        Index(
            "idx_similarity_cache_source_score",
            "source_artifact_uuid",
            "composite_score",
        ),
    )

    def __repr__(self) -> str:
        """Return string representation of SimilarityCache."""
        return (
            f"<SimilarityCache("
            f"source={self.source_artifact_uuid!r}, "
            f"target={self.target_artifact_uuid!r}, "
            f"score={self.composite_score!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert SimilarityCache to dictionary for JSON serialization."""
        breakdown: Optional[Dict[str, Any]] = None
        if self.breakdown_json:
            try:
                breakdown = json.loads(self.breakdown_json)
            except (ValueError, TypeError):
                breakdown = None

        return {
            "source_artifact_uuid": self.source_artifact_uuid,
            "target_artifact_uuid": self.target_artifact_uuid,
            "composite_score": self.composite_score,
            "breakdown": breakdown,
            "computed_at": self.computed_at.isoformat() if self.computed_at else None,
        }


# =============================================================================
# ArtifactEmbedding (SSO-3.3)
# =============================================================================


class ArtifactEmbedding(Base):
    """Persisted vector embedding for a collection artifact.

    Stores the dense vector representation (embedding) produced by a sentence-
    transformer model so that embedding generation is not repeated on every
    similarity-scoring request.  The embedding is serialised as a raw byte blob
    (numpy ``ndarray.tobytes()`` / ``frombuffer()``).

    NOTE: A file-based embedding cache also exists at ``~/.skillmeat/embeddings.db``
    (used by ``AnthropicEmbedder`` / ``HaikuEmbedder`` in
    ``skillmeat/core/scoring/haiku_embedder.py``).  That store is keyed on text
    hash rather than artifact UUID and is unrelated to this table.  The ORM table
    is the canonical, artifact-scoped embedding store going forward; the file-based
    cache is a legacy implementation detail of the (currently unavailable)
    Anthropic embedder stub.

    Attributes:
        artifact_uuid: UUID of the collection artifact this embedding belongs to.
            Acts as the primary key and references ``artifacts.uuid`` with
            CASCADE DELETE so that removing an artifact automatically removes
            its embedding row.
        embedding: Raw bytes of the embedding vector.  Deserialise with
            ``numpy.frombuffer(embedding, dtype=numpy.float32)``.
        model_name: Identifier of the model that produced the embedding
            (e.g. ``"all-MiniLM-L6-v2"``).
        embedding_dim: Length of the embedding vector (e.g. 384 for
            ``all-MiniLM-L6-v2``).  Stored explicitly so consumers can
            deserialise without knowing the model ahead of time.
        computed_at: Timestamp when the embedding was last computed.  Used for
            TTL-based invalidation when the underlying artifact content changes.

    Constraints:
        - Primary key on ``artifact_uuid``
        - FK CASCADE DELETE on ``artifact_uuid`` referencing ``artifacts.uuid``

    Indexes:
        - idx_artifact_embeddings_model: Fast lookup of all embeddings produced
          by a given model (useful for bulk re-embedding when a model is updated)
    """

    __tablename__ = "artifact_embeddings"

    # Primary key — one embedding row per artifact (per model update cycle)
    artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        primary_key=True,
        comment="UUID of the artifact this embedding belongs to",
    )

    # The vector payload
    embedding: Mapped[bytes] = mapped_column(
        LargeBinary,
        nullable=False,
        comment=(
            "Raw float32 bytes of the embedding vector "
            "(numpy ndarray.tobytes() / frombuffer(dtype=float32))"
        ),
    )

    # Model provenance
    model_name: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Model that produced this embedding (e.g. 'all-MiniLM-L6-v2')",
    )
    embedding_dim: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        comment="Number of dimensions in the embedding vector (e.g. 384)",
    )

    # Cache-invalidation timestamp
    computed_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="Timestamp when the embedding was computed; used for TTL invalidation",
    )

    # Constraints and indexes
    __table_args__ = (Index("idx_artifact_embeddings_model", "model_name"),)

    def __repr__(self) -> str:
        """Return string representation of ArtifactEmbedding."""
        return (
            f"<ArtifactEmbedding("
            f"artifact_uuid={self.artifact_uuid!r}, "
            f"model={self.model_name!r}, "
            f"dim={self.embedding_dim!r})>"
        )


# =============================================================================
# Workflow ORM Models
# =============================================================================


class Workflow(Base):
    """Workflow definition parsed from SWDL YAML."""

    __tablename__ = "workflows"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Core fields
    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    version: Mapped[str] = mapped_column(String, nullable=False, default="1.0.0")
    status: Mapped[str] = mapped_column(String, nullable=False, default="draft")
    definition_yaml: Mapped[str] = mapped_column(Text, nullable=False)
    definition_hash: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # JSON-serialised fields (stored as Text)
    tags_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    global_context_module_ids_json: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True
    )
    config_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    error_policy_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    hooks_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    ui_metadata_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Authoring metadata
    created_by: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    stages: Mapped[List["WorkflowStage"]] = relationship(
        "WorkflowStage",
        back_populates="workflow",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    executions: Mapped[List["WorkflowExecution"]] = relationship(
        "WorkflowExecution",
        back_populates="workflow",
        cascade="save-update, merge",
        lazy="selectin",
    )
    deployment_set_members: Mapped[List["DeploymentSetMember"]] = relationship(
        "DeploymentSetMember",
        back_populates="workflow",
        cascade="all, delete-orphan",
        lazy="select",
    )

    def __repr__(self) -> str:
        """Return string representation of Workflow."""
        return (
            f"<Workflow(id={self.id!r}, name={self.name!r}, "
            f"version={self.version!r}, status={self.status!r})>"
        )


class WorkflowStage(Base):
    """Individual stage definition belonging to a Workflow."""

    __tablename__ = "workflow_stages"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Foreign key
    workflow_id: Mapped[str] = mapped_column(
        String, ForeignKey("workflows.id", ondelete="CASCADE"), nullable=False
    )

    # Core fields
    stage_id_ref: Mapped[str] = mapped_column(String, nullable=False)
    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    condition: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    stage_type: Mapped[str] = mapped_column(String, nullable=False, default="agent")

    # JSON-serialised fields (stored as Text)
    depends_on_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    roles_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    inputs_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    outputs_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    context_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    error_policy_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    handoff_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    gate_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    ui_metadata_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    workflow: Mapped["Workflow"] = relationship(
        "Workflow",
        back_populates="stages",
    )

    def __repr__(self) -> str:
        """Return string representation of WorkflowStage."""
        return (
            f"<WorkflowStage(id={self.id!r}, workflow_id={self.workflow_id!r}, "
            f"stage_id_ref={self.stage_id_ref!r}, order_index={self.order_index!r})>"
        )


class WorkflowExecution(Base):
    """Runtime execution record for a Workflow invocation."""

    __tablename__ = "workflow_executions"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Foreign key — SET NULL to preserve executions after workflow deletion
    workflow_id: Mapped[Optional[str]] = mapped_column(
        String, ForeignKey("workflows.id", ondelete="SET NULL"), nullable=True
    )

    # Snapshot of workflow identity at execution time
    workflow_name: Mapped[str] = mapped_column(String, nullable=False)
    workflow_version: Mapped[str] = mapped_column(String, nullable=False)
    workflow_definition_hash: Mapped[Optional[str]] = mapped_column(
        String, nullable=True
    )

    # Execution state
    status: Mapped[str] = mapped_column(String, nullable=False, default="pending")
    trigger: Mapped[str] = mapped_column(String, nullable=False, default="manual")

    # JSON-serialised fields (stored as Text)
    parameters_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    overrides_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timing
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Error tracking
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    workflow: Mapped["Workflow"] = relationship(
        "Workflow",
        back_populates="executions",
    )
    steps: Mapped[List["ExecutionStep"]] = relationship(
        "ExecutionStep",
        back_populates="execution",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    def __repr__(self) -> str:
        """Return string representation of WorkflowExecution."""
        return (
            f"<WorkflowExecution(id={self.id!r}, workflow_id={self.workflow_id!r}, "
            f"status={self.status!r})>"
        )


class ExecutionStep(Base):
    """Per-stage execution record within a WorkflowExecution."""

    __tablename__ = "execution_steps"

    # Primary key
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Foreign key
    execution_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("workflow_executions.id", ondelete="CASCADE"),
        nullable=False,
    )

    # Stage identity snapshot
    stage_id_ref: Mapped[str] = mapped_column(String, nullable=False)
    stage_name: Mapped[str] = mapped_column(String, nullable=False)

    # Execution state
    status: Mapped[str] = mapped_column(String, nullable=False, default="pending")
    attempt_number: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    agent_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # JSON-serialised fields (stored as Text)
    context_consumed_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    inputs_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    outputs_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    logs_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Error tracking
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timing
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    duration_seconds: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    execution: Mapped["WorkflowExecution"] = relationship(
        "WorkflowExecution",
        back_populates="steps",
    )

    def __repr__(self) -> str:
        """Return string representation of ExecutionStep."""
        return (
            f"<ExecutionStep(id={self.id!r}, execution_id={self.execution_id!r}, "
            f"stage_id_ref={self.stage_id_ref!r}, status={self.status!r})>"
        )


class EntityTypeConfig(Base):
    """Configuration for a context entity type.

    Stores the definition of each built-in (and future user-defined) context
    entity type. The five built-in types mirror the validators in
    ``skillmeat/core/validators/context_entity.py`` and the defaults defined in
    ``skillmeat/core/platform_defaults.py``.

    Attributes:
        id: Auto-incrementing integer primary key.
        slug: Machine-readable unique identifier (e.g. "skill", "command").
        display_name: Human-readable name shown in the UI.
        description: Optional long-form description of this entity type.
        icon: Optional icon identifier for UI rendering.
        color: Optional hex color code for UI card indicators
               (e.g. ``'#3B82F6'``).  ``None`` uses default theme colors.
        path_prefix: Default filesystem path prefix for this type
                     (e.g. ".claude/skills").
        required_frontmatter_keys: JSON list of frontmatter keys that MUST be
                                   present in files of this type.
        optional_frontmatter_keys: JSON list of frontmatter keys that MAY be
                                   present.
        validation_rules: JSON object of additional validation config.
        content_template: Default Markdown template used when creating a new
                          entity of this type.
        is_builtin: ``True`` for the five shipped types; ``False`` for any
                    user-created types (protected from deletion when ``True``).
        sort_order: Display ordering in the UI (ascending).
        created_at: Row creation timestamp (UTC).
        updated_at: Row last-modified timestamp (UTC).

    Indexes:
        - idx_entity_type_configs_slug (UNIQUE): Fast lookup by slug.
        - idx_entity_type_configs_sort_order: Ordered listing in the UI.
        - idx_entity_type_configs_is_builtin: Filter built-in vs custom types.
    """

    __tablename__ = "entity_type_configs"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Identity fields
    slug: Mapped[str] = mapped_column(String, nullable=False, unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    icon: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    color: Mapped[Optional[str]] = mapped_column(
        String(7),
        nullable=True,
        comment="Optional hex color code for UI card indicators (e.g. '#3B82F6')",
    )

    # Path configuration
    path_prefix: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Example path illustrating this entity type
    example_path: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Frontmatter schema — stored as JSON arrays/objects
    required_frontmatter_keys: Mapped[Optional[Any]] = mapped_column(
        JSON, nullable=True
    )
    optional_frontmatter_keys: Mapped[Optional[Any]] = mapped_column(
        JSON, nullable=True
    )
    validation_rules: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)

    # Content template
    content_template: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Platform applicability — JSON list of platform slugs (None means all platforms)
    applicable_platforms: Mapped[Optional[Any]] = mapped_column(
        JSON,
        nullable=True,
        comment=(
            "JSON list of platform slugs this type applies to. "
            "None means applicable to all platforms."
        ),
    )

    # Frontmatter JSON Schema subset for custom type validation
    frontmatter_schema: Mapped[Optional[Any]] = mapped_column(
        JSON,
        nullable=True,
        comment=(
            "JSON Schema subset for validating custom type frontmatter. "
            'Structure: {"required": ["key1"], "properties": {"key1": {"type": "string"}}}'
        ),
    )

    # Metadata
    is_builtin: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default="1"
    )
    sort_order: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Table-level constraints and extra indexes
    __table_args__ = (
        Index("idx_entity_type_configs_sort_order", "sort_order"),
        Index("idx_entity_type_configs_is_builtin", "is_builtin"),
    )

    def __repr__(self) -> str:
        """Return string representation of EntityTypeConfig."""
        return (
            f"<EntityTypeConfig(id={self.id!r}, slug={self.slug!r}, "
            f"display_name={self.display_name!r}, is_builtin={self.is_builtin!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert EntityTypeConfig to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the entity type config.
        """
        return {
            "id": self.id,
            "slug": self.slug,
            "display_name": self.display_name,
            "description": self.description,
            "icon": self.icon,
            "color": self.color,
            "path_prefix": self.path_prefix,
            "example_path": self.example_path,
            "required_frontmatter_keys": self.required_frontmatter_keys,
            "optional_frontmatter_keys": self.optional_frontmatter_keys,
            "validation_rules": self.validation_rules,
            "content_template": self.content_template,
            "applicable_platforms": self.applicable_platforms,
            "frontmatter_schema": self.frontmatter_schema,
            "is_builtin": self.is_builtin,
            "sort_order": self.sort_order,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ArtifactCategoryAssociation(Base):
    """Association between Artifact and ContextEntityCategory (many-to-many).

    Links artifacts to structured categories for browsing and filtering. Each
    artifact can belong to multiple categories, and each category can contain
    multiple artifacts.

    Attributes:
        artifact_uuid: FK to artifacts.uuid (part of composite PK; CASCADE
            delete so removing an artifact purges its category associations)
        category_id: Foreign key to entity_categories.id (part of composite PK)
        created_at: Timestamp when category was applied to artifact

    Indexes:
        - idx_artifact_category_assoc_artifact_uuid: Fast lookup by artifact UUID
        - idx_artifact_category_assoc_category_id: Fast lookup by category
    """

    __tablename__ = "entity_category_associations"

    # Composite primary key — uses artifacts.uuid (stable cross-context identity)
    artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        primary_key=True,
    )
    category_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("entity_categories.id", ondelete="CASCADE"),
        primary_key=True,
    )

    # Timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Indexes
    __table_args__ = (
        Index("idx_artifact_category_assoc_artifact_uuid", "artifact_uuid"),
        Index("idx_artifact_category_assoc_category_id", "category_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of ArtifactCategoryAssociation."""
        return (
            f"<ArtifactCategoryAssociation(artifact_uuid={self.artifact_uuid!r}, "
            f"category_id={self.category_id!r})>"
        )


class ContextEntityCategory(Base):
    """A structured category for grouping context entity artifacts.

    Categories allow users to organise artifacts (skills, rules, specs, etc.)
    into named buckets that can optionally be scoped to a specific entity type
    or platform.  The five built-in entity types use ``is_builtin=False`` for
    categories; categories themselves are always user-manageable.

    Attributes:
        id: Auto-incrementing integer primary key.
        name: Human-readable label shown in the UI (e.g. "Testing Utilities").
        slug: URL-safe machine identifier (e.g. "testing-utilities").
        description: Optional longer description of the category's purpose.
        color: Optional hex colour code for UI badge rendering (e.g. "#3B82F6").
        entity_type_slug: Optional FK-style filter; when set, this category
                          only applies to artifacts whose type matches this slug
                          (e.g. "skill", "rule_file").
        platform: Optional platform filter (e.g. "github-actions", "cursor").
        sort_order: Ascending display order in the UI; defaults to 0.
        is_builtin: True for system-seeded categories that should be protected
                    from deletion.
        created_at: Row creation timestamp (UTC).
        updated_at: Row last-modified timestamp (UTC).
        artifacts: Artifacts associated with this category via the join table.

    Indexes:
        - uq_entity_categories_slug (UNIQUE): fast lookup by slug.
        - idx_entity_categories_entity_type_platform: composite filter.
        - idx_entity_categories_sort_order: ordered listing.
        - idx_entity_categories_is_builtin: filter built-in vs. custom.
    """

    __tablename__ = "entity_categories"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Identity fields
    name: Mapped[str] = mapped_column(
        String(100), nullable=False, comment="Human-readable label shown in the UI"
    )
    slug: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        unique=True,
        index=True,
        comment="URL-safe machine identifier, e.g. 'testing-utilities'",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True, comment="Optional longer description of the category"
    )

    # Display hints
    color: Mapped[Optional[str]] = mapped_column(
        String(7),
        nullable=True,
        comment="Hex colour code for UI badge rendering, e.g. '#3B82F6'",
    )

    # Optional scope filters
    entity_type_slug: Mapped[Optional[str]] = mapped_column(
        String(50),
        nullable=True,
        comment="When set, restrict this category to artifacts of this entity type",
    )
    platform: Mapped[Optional[str]] = mapped_column(
        String(50),
        nullable=True,
        comment="When set, restrict this category to artifacts targeting this platform",
    )

    # Metadata
    sort_order: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    is_builtin: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="0"
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    artifacts: Mapped[List["Artifact"]] = relationship(
        "Artifact",
        secondary="entity_category_associations",
        primaryjoin="ContextEntityCategory.id == foreign(ArtifactCategoryAssociation.category_id)",
        secondaryjoin="foreign(ArtifactCategoryAssociation.artifact_uuid) == Artifact.uuid",
        back_populates="categories",
        lazy="selectin",
    )

    # Table-level constraints and extra indexes
    __table_args__ = (
        Index(
            "idx_entity_categories_entity_type_platform",
            "entity_type_slug",
            "platform",
        ),
        Index("idx_entity_categories_sort_order", "sort_order"),
        Index("idx_entity_categories_is_builtin", "is_builtin"),
    )

    def __repr__(self) -> str:
        """Return string representation of ContextEntityCategory."""
        return (
            f"<ContextEntityCategory(id={self.id!r}, slug={self.slug!r}, "
            f"name={self.name!r}, is_builtin={self.is_builtin!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert ContextEntityCategory to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the category.
        """
        return {
            "id": self.id,
            "name": self.name,
            "slug": self.slug,
            "description": self.description,
            "color": self.color,
            "entity_type_slug": self.entity_type_slug,
            "platform": self.platform,
            "sort_order": self.sort_order,
            "is_builtin": self.is_builtin,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


# =============================================================================
# Auth / RBAC Models  (AAA/RBAC Foundation — PRD-2, DB-001)
# =============================================================================


class User(Base):
    """Local-mode user account.

    In single-user local deployments the row is created automatically at
    startup with ``id = LOCAL_ADMIN_USER_ID`` (see ``skillmeat/cache/constants.py``).
    The ``external_id`` column stores the Clerk user_id when the web UI is
    connected to a Clerk-backed authentication provider.

    Attributes:
        id:           Auto-increment integer primary key.
        external_id:  Optional external identity (e.g. Clerk ``user_id``); unique.
        email:        Optional user email address.
        display_name: Optional human-readable display name.
        role:         System-wide role string; stores a ``UserRole`` enum value.
                      Defaults to ``"viewer"``; set to ``"system_admin"`` for the
                      implicit local admin.
        is_active:    Soft-delete flag; ``False`` prevents login without deleting
                      the row.
        created_at:   UTC creation timestamp (server default).
        updated_at:   UTC last-modified timestamp (app-managed on write).
        team_memberships: Back-reference to all ``TeamMember`` rows for this user.

    Constraints:
        uq_users_external_id: UNIQUE (external_id) — one account per external ID.

    Indexes:
        idx_users_external_id: Fast Clerk user_id lookup.
        idx_users_email: Fast email lookup.
        idx_users_role: Filter by system role.
    """

    __tablename__ = "users"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # External identity — maps to Clerk user_id when web auth is enabled
    external_id: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        unique=True,
        comment="External identity provider ID (e.g. Clerk user_id); unique when set",
    )

    # Contact
    email: Mapped[Optional[str]] = mapped_column(
        String(320),
        nullable=True,
        comment="User email address; not enforced unique in local mode",
    )
    display_name: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="Human-readable display name shown in the UI",
    )

    # System-wide role — stores UserRole enum value as a plain string
    role: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="viewer",
        server_default="viewer",
        comment="System-wide role; one of UserRole enum values (viewer, team_member, team_admin, system_admin)",
    )

    # Soft-delete
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default="1",
        comment="When False the account is disabled; row is retained for audit",
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="UTC creation timestamp",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        comment="UTC last-modified timestamp; updated by app on every write",
    )

    # Relationships
    team_memberships: Mapped[List["TeamMember"]] = relationship(
        "TeamMember",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # Constraints and indexes
    __table_args__ = (
        Index("idx_users_external_id", "external_id"),
        Index("idx_users_email", "email"),
        Index("idx_users_role", "role"),
    )

    def __repr__(self) -> str:
        """Return string representation of User."""
        return (
            f"<User(id={self.id!r}, external_id={self.external_id!r}, "
            f"email={self.email!r}, role={self.role!r}, is_active={self.is_active!r})>"
        )


class Team(Base):
    """Named group of users for collaborative artifact management.

    Teams allow multiple users to share ownership of artifacts and deployment
    sets.  In local single-user mode no teams are created by default.

    Attributes:
        id:          Auto-increment integer primary key.
        name:        Unique team name (human-readable, e.g. "platform-eng").
        description: Optional description of the team's purpose.
        is_active:   Soft-delete flag.
        created_at:  UTC creation timestamp.
        updated_at:  UTC last-modified timestamp.
        members:     Back-reference to all ``TeamMember`` rows for this team.

    Constraints:
        uq_teams_name: UNIQUE (name)

    Indexes:
        idx_teams_name: Fast lookup by name.
        idx_teams_is_active: Filter active teams.
    """

    __tablename__ = "teams"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Identity
    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        unique=True,
        comment="Unique human-readable team name",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional description of the team's purpose",
    )

    # Soft-delete
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default="1",
        comment="When False the team is dissolved but rows are retained for audit",
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="UTC creation timestamp",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        comment="UTC last-modified timestamp",
    )

    # Relationships
    members: Mapped[List["TeamMember"]] = relationship(
        "TeamMember",
        back_populates="team",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # Indexes
    __table_args__ = (
        Index("idx_teams_name", "name"),
        Index("idx_teams_is_active", "is_active"),
    )

    def __repr__(self) -> str:
        """Return string representation of Team."""
        return (
            f"<Team(id={self.id!r}, name={self.name!r}, "
            f"is_active={self.is_active!r})>"
        )


class TeamMember(Base):
    """Junction table recording a user's membership in a team.

    Each row grants one user access to one team at a specific team-level role.
    The ``role`` column stores a ``UserRole`` enum value restricted to
    ``team_admin`` or ``team_member`` (system-level roles are on ``User.role``).

    Attributes:
        id:        Auto-increment integer primary key.
        team_id:   FK → teams.id (CASCADE on delete).
        user_id:   FK → users.id (CASCADE on delete).
        role:      Team-level role; one of ``UserRole`` values.
                   Defaults to ``"team_member"``.
        joined_at: UTC timestamp when the user joined the team.

    Constraints:
        uq_team_members_team_user: UNIQUE (team_id, user_id) — one membership
            row per (team, user) pair.

    Indexes:
        idx_team_members_team_id: Fast member listing per team.
        idx_team_members_user_id: Reverse lookup — which teams is a user in?
    """

    __tablename__ = "team_members"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Foreign keys
    team_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("teams.id", ondelete="CASCADE"),
        nullable=False,
        comment="Parent team; cascade-deletes this membership when team is removed",
    )
    user_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        comment="Member user; cascade-deletes this membership when user is removed",
    )

    # Team-level role
    role: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="team_member",
        server_default="team_member",
        comment="Role within the team; one of team_admin, team_member",
    )

    # Join timestamp — intentionally not an onupdate column (join date is immutable)
    joined_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="UTC timestamp when the user joined the team",
    )

    # Relationships
    team: Mapped["Team"] = relationship(
        "Team",
        back_populates="members",
        lazy="joined",
    )
    user: Mapped["User"] = relationship(
        "User",
        back_populates="team_memberships",
        lazy="joined",
    )

    # Constraints and indexes
    __table_args__ = (
        UniqueConstraint(
            "team_id",
            "user_id",
            name="uq_team_members_team_user",
        ),
        Index("idx_team_members_team_id", "team_id"),
        Index("idx_team_members_user_id", "user_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of TeamMember."""
        return (
            f"<TeamMember(id={self.id!r}, team_id={self.team_id!r}, "
            f"user_id={self.user_id!r}, role={self.role!r})>"
        )


# =============================================================================
# Database Engine and Session Setup
# =============================================================================


def create_db_engine(db_path: Optional[str | Path] = None) -> Engine:
    """Create SQLAlchemy engine for cache database.

    Creates an engine with optimal SQLite settings including WAL mode,
    foreign key enforcement, and performance tuning.

    Args:
        db_path: Path to database file. If None, uses default location
                 at ~/.skillmeat/cache/cache.db

    Returns:
        SQLAlchemy Engine configured with optimal settings

    Example:
        >>> from skillmeat.cache.models import create_db_engine
        >>> engine = create_db_engine()
        >>> # Use with session
    """
    # Resolve database path
    if db_path is None:
        db_path = Path.home() / ".skillmeat" / "cache" / "cache.db"
    else:
        db_path = Path(db_path)

    # Ensure parent directory exists
    db_path.parent.mkdir(parents=True, exist_ok=True)

    # Create engine with SQLite-specific options
    engine = create_engine(
        f"sqlite:///{db_path}",
        echo=False,  # Set to True for SQL debugging
        connect_args={
            "check_same_thread": False,  # Allow multi-threaded access
            "timeout": 30.0,  # 30 second lock timeout
        },
    )

    # Configure SQLite PRAGMA settings
    @event.listens_for(engine, "connect")
    def set_sqlite_pragma(dbapi_conn, connection_record):
        """Set SQLite PRAGMA settings on connection."""
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA temp_store=MEMORY")
        cursor.execute("PRAGMA cache_size=-64000")  # 64MB cache
        cursor.execute("PRAGMA mmap_size=268435456")  # 256MB mmap
        cursor.close()

    return engine


# ---------------------------------------------------------------------------
# Environment-based engine factory (ENT-1.9)
# ---------------------------------------------------------------------------

import logging as _logging
import os as _os
import re as _re

_engine_singleton: Optional[Engine] = None


def _redact_db_url(url: str) -> str:
    """Return *url* with the password component replaced by '***'."""
    return _re.sub(r"(:)[^:@]+(@)", r"\1***\2", url)


def get_engine(db_path: Optional[str | Path] = None) -> Engine:
    """Return a module-level singleton engine, creating it on first call.

    Selection priority (highest → lowest):

    1. ``DATABASE_URL`` environment variable
    2. ``SKILLMEAT_DATABASE_URL`` environment variable
    3. Existing SQLite path logic (``db_path`` arg or default
       ``~/.skillmeat/cache/cache.db``)

    When a PostgreSQL URL is detected (scheme ``postgresql://`` or
    ``postgresql+psycopg2://``) the engine is created with a connection
    pool suitable for server workloads.  For all other URLs (SQLite) the
    existing ``create_db_engine`` path is used unchanged.

    The function is idempotent: subsequent calls return the same engine
    instance regardless of arguments.

    Args:
        db_path: Forwarded to ``create_db_engine`` when the SQLite
                 fallback is used.  Ignored when an env-var URL is set.

    Returns:
        SQLAlchemy :class:`~sqlalchemy.engine.Engine` instance.

    Example::

        from skillmeat.cache.models import get_engine
        engine = get_engine()
    """
    global _engine_singleton
    if _engine_singleton is not None:
        return _engine_singleton

    logger = _logging.getLogger(__name__)

    database_url: Optional[str] = _os.environ.get("DATABASE_URL") or _os.environ.get(
        "SKILLMEAT_DATABASE_URL"
    )

    if database_url and (
        database_url.startswith("postgresql://")
        or database_url.startswith("postgresql+psycopg2://")
    ):
        logger.info("Using PostgreSQL database: %s", _redact_db_url(database_url))
        _engine_singleton = create_engine(
            database_url,
            pool_size=5,
            max_overflow=10,
            pool_pre_ping=True,
            connect_args={},
        )
    else:
        # Fall back to the existing SQLite path — behaviour is identical to
        # before ENT-1.9; no changes to SQLite configuration.
        _engine_singleton = create_db_engine(db_path)

    return _engine_singleton


# Session factory (to be initialized with engine)
SessionLocal = None


def init_session_factory(db_path: Optional[str | Path] = None) -> None:
    """Initialize the session factory with the given database path.

    When ``DATABASE_URL`` or ``SKILLMEAT_DATABASE_URL`` is set in the
    environment, the factory is bound to that engine (PostgreSQL or
    otherwise) instead of the SQLite path.  In all other cases the
    existing SQLite behaviour is preserved.

    Args:
        db_path: Path to database file. Forwarded to ``get_engine`` and
                 only used when the SQLite fallback is active.

    Example:
        >>> from skillmeat.cache.models import init_session_factory
        >>> init_session_factory()  # Initialize with default path
    """
    global SessionLocal
    engine = get_engine(db_path)
    SessionLocal = sessionmaker(
        autocommit=False,
        autoflush=False,
        bind=engine,
    )


def get_session(db_path: Optional[str | Path] = None):
    """Get a database session.

    Creates a new session for database operations. The session should be
    closed after use, preferably in a try/finally block or context manager.

    Args:
        db_path: Path to database file. If None, uses default location

    Returns:
        SQLAlchemy Session instance

    Example:
        >>> from skillmeat.cache.models import get_session, Project
        >>> session = get_session()
        >>> try:
        ...     projects = session.query(Project).all()
        ...     for project in projects:
        ...         print(project.name)
        ... finally:
        ...     session.close()

    Note:
        For more Pythonic usage, consider implementing a context manager:

        >>> with get_session() as session:
        ...     projects = session.query(Project).all()
    """
    global SessionLocal

    # Initialize session factory if not already done
    if SessionLocal is None:
        init_session_factory(db_path)

    return SessionLocal()


# =============================================================================
# Database Initialization
# =============================================================================


def create_tables(db_path: Optional[str | Path] = None) -> None:
    """Create all tables in the database.

    This creates the tables defined by the ORM models. It's safe to call
    multiple times - existing tables will not be modified.

    Schema migrations are managed by Alembic (see ``skillmeat/cache/migrations/``).
    The Phase 1 compatibility migration for ``artifact_tags`` FK has been
    superseded by the proper Alembic migration ``20260219_1300`` (CAI-P5-08).

    Args:
        db_path: Path to database file. If None, uses default location

    Example:
        >>> from skillmeat.cache.models import create_tables
        >>> create_tables()  # Create tables in default location
    """
    engine = create_db_engine(db_path)
    Base.metadata.create_all(engine)


def drop_tables(db_path: Optional[str | Path] = None) -> None:
    """Drop all tables from the database.

    WARNING: This destroys all data. Use only for testing or when
    cache corruption is detected.

    Args:
        db_path: Path to database file. If None, uses default location

    Example:
        >>> from skillmeat.cache.models import drop_tables
        >>> drop_tables()  # Drop all tables
    """
    engine = create_db_engine(db_path)
    Base.metadata.drop_all(engine)


# =============================================================================
# SkillBOM & Attestation Models
# =============================================================================


class AttestationRecord(Base):
    """Owner-scoped attestation metadata for an artifact.

    Records which owner (user or team) has attested to an artifact, including
    the RBAC roles and scopes they assert, and the visibility level of the
    attestation.  One artifact can have multiple attestation records from
    different owners.

    Attributes:
        id: Auto-incrementing primary key.
        artifact_id: Foreign key to artifacts.id (CASCADE delete).
        owner_type: Discriminator for the owning principal ('user' or 'team').
        owner_id: Opaque identifier for the owning user or team.
        roles: JSON list of role strings asserted by this attestation.
        scopes: JSON list of scope strings granted by this attestation.
        visibility: Access-visibility level ('private', 'team', or 'public').
        created_at: Timestamp when the attestation was created.
        updated_at: Timestamp when the attestation was last modified.
        artifact: Relationship back to the attested Artifact.

    Indexes:
        - idx_attestation_records_owner: Fast owner look-ups.
        - idx_attestation_records_artifact_id: Join performance.
    """

    __tablename__ = "attestation_records"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Foreign key
    artifact_id: Mapped[str] = mapped_column(
        String, ForeignKey("artifacts.id", ondelete="CASCADE"), nullable=False
    )

    # Owner fields
    owner_type: Mapped[str] = mapped_column(
        String, nullable=False, default=OwnerType.user.value
    )
    owner_id: Mapped[str] = mapped_column(String, nullable=False)

    # RBAC payloads
    roles: Mapped[Optional[List[Any]]] = mapped_column(JSON, nullable=True)
    scopes: Mapped[Optional[List[Any]]] = mapped_column(JSON, nullable=True)

    # Visibility
    visibility: Mapped[str] = mapped_column(
        String, nullable=False, default=Visibility.private.value
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    artifact: Mapped["Artifact"] = relationship("Artifact", lazy="select")

    # Constraints / indexes
    __table_args__ = (
        Index("idx_attestation_records_owner", "owner_type", "owner_id"),
        Index("idx_attestation_records_artifact_id", "artifact_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of AttestationRecord."""
        return (
            f"<AttestationRecord(id={self.id!r}, artifact_id={self.artifact_id!r}, "
            f"owner_type={self.owner_type!r}, owner_id={self.owner_id!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert AttestationRecord to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "artifact_id": self.artifact_id,
            "owner_type": self.owner_type,
            "owner_id": self.owner_id,
            "roles": self.roles,
            "scopes": self.scopes,
            "visibility": self.visibility,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ArtifactHistoryEvent(Base):
    """Immutable audit log entry for an artifact lifecycle event.

    Records every significant state change for an artifact: creation, updates,
    deployments, un-deployments, and sync operations.  Rows are append-only by
    application convention — never update or delete individual events.

    Attributes:
        id: Auto-incrementing primary key.
        artifact_id: Foreign key to artifacts.id (CASCADE delete).
        event_type: One of 'create', 'update', 'delete', 'deploy',
                    'undeploy', or 'sync'.
        actor_id: Opaque identifier for the user or system that triggered
                  the event; nullable for automated/system events.
        owner_type: Owner context at the time of the event.
        timestamp: Wall-clock time of the event (UTC).
        diff_json: JSON-serialised diff payload describing what changed.
        content_hash: SHA-256 hash of artifact content at event time.

    Indexes:
        - idx_artifact_history_artifact_ts: Artifact timeline queries.
        - idx_artifact_history_type_ts: Event-type filtered queries.
        - idx_artifact_history_actor_id: Actor audit queries.
    """

    __tablename__ = "artifact_history_events"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Foreign key
    artifact_id: Mapped[str] = mapped_column(
        String, ForeignKey("artifacts.id", ondelete="CASCADE"), nullable=False
    )

    # Event metadata
    event_type: Mapped[str] = mapped_column(String, nullable=False)
    actor_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    owner_type: Mapped[str] = mapped_column(
        String, nullable=False, default=OwnerType.user.value
    )

    # Timestamp (immutable after insert)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Change payload
    diff_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    content_hash: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Constraints / indexes
    __table_args__ = (
        CheckConstraint(
            "event_type IN ('create', 'update', 'delete', 'deploy', 'undeploy', 'sync', "
            "'restore', 'promote', 'force_sync', 'baseline_set')",
            name="check_artifact_history_event_type",
        ),
        Index("idx_artifact_history_artifact_ts", "artifact_id", "timestamp"),
        Index("idx_artifact_history_type_ts", "event_type", "timestamp"),
        Index("idx_artifact_history_actor_id", "actor_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of ArtifactHistoryEvent."""
        return (
            f"<ArtifactHistoryEvent(id={self.id!r}, artifact_id={self.artifact_id!r}, "
            f"event_type={self.event_type!r}, timestamp={self.timestamp!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert ArtifactHistoryEvent to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "artifact_id": self.artifact_id,
            "event_type": self.event_type,
            "actor_id": self.actor_id,
            "owner_type": self.owner_type,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "diff_json": self.diff_json,
            "content_hash": self.content_hash,
        }


class BomSnapshot(Base):
    """Point-in-time Bill-of-Materials snapshot.

    Captures the full BOM for a project at a given moment (or at a specific
    git commit).  The serialised BOM is stored as text in ``bom_json`` and may
    be optionally signed for integrity verification.

    Attributes:
        id: Auto-incrementing primary key.
        project_id: Opaque project identifier; nullable for collection-level BOMs.
        commit_sha: Git commit SHA associated with this snapshot; nullable.
        bom_json: Serialised BOM payload (JSON text).
        signature: Optional cryptographic signature over ``bom_json``.
        signature_algorithm: Algorithm used to produce the signature (e.g. 'ed25519').
        signing_key_id: SHA-256 fingerprint (hex) of the public key used to sign.
        owner_type: Owner context at snapshot time.
        created_at: Timestamp when the snapshot was captured.

    Indexes:
        - idx_bom_snapshots_project_created: Project timeline queries.
        - idx_bom_snapshots_commit_sha: Commit-based look-ups.
    """

    __tablename__ = "bom_snapshots"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Scope identifiers
    project_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    commit_sha: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # BOM payload
    bom_json: Mapped[str] = mapped_column(Text, nullable=False)

    # Optional signing
    signature: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    signature_algorithm: Mapped[Optional[str]] = mapped_column(
        String(50), nullable=True
    )
    signing_key_id: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        comment="SHA-256 fingerprint (hex) of the signing public key",
    )

    # Owner context
    owner_type: Mapped[str] = mapped_column(
        String, nullable=False, default=OwnerType.user.value
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Constraints / indexes
    __table_args__ = (
        Index("idx_bom_snapshots_project_created", "project_id", "created_at"),
        Index("idx_bom_snapshots_commit_sha", "commit_sha"),
    )

    def __repr__(self) -> str:
        """Return string representation of BomSnapshot."""
        return (
            f"<BomSnapshot(id={self.id!r}, project_id={self.project_id!r}, "
            f"commit_sha={self.commit_sha!r}, created_at={self.created_at!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert BomSnapshot to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "project_id": self.project_id,
            "commit_sha": self.commit_sha,
            "bom_json": self.bom_json,
            "signature": self.signature,
            "signature_algorithm": self.signature_algorithm,
            "owner_type": self.owner_type,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AttestationPolicy(Base):
    """Enterprise policy for enforcing attestation requirements.

    Defines which artifacts and scopes must be attested before a project can
    be considered compliant.  In local (SQLite) mode this table exists but is
    not enforced; policy evaluation is an enterprise-only runtime behaviour.

    Attributes:
        id: Auto-incrementing primary key.
        tenant_id: Enterprise tenant identifier; nullable in local mode.
        name: Human-readable policy name (unique per installation).
        required_artifacts: JSON list of artifact identifiers that must be attested.
        required_scopes: JSON list of scope strings that must be present.
        compliance_metadata: Arbitrary JSON metadata for compliance tooling.
        created_at: Timestamp when the policy was created.
        updated_at: Timestamp when the policy was last modified.

    Indexes:
        - idx_attestation_policies_tenant_id: Tenant-scoped look-ups.
        - idx_attestation_policies_name: Name look-ups.
    """

    __tablename__ = "attestation_policies"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Tenant scope (enterprise only; nullable in local mode)
    tenant_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Policy definition
    name: Mapped[str] = mapped_column(String, nullable=False)
    required_artifacts: Mapped[Optional[List[Any]]] = mapped_column(JSON, nullable=True)
    required_scopes: Mapped[Optional[List[Any]]] = mapped_column(JSON, nullable=True)
    compliance_metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSON, nullable=True
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Constraints / indexes
    __table_args__ = (
        Index("idx_attestation_policies_tenant_id", "tenant_id"),
        Index("idx_attestation_policies_name", "name"),
    )

    def __repr__(self) -> str:
        """Return string representation of AttestationPolicy."""
        return (
            f"<AttestationPolicy(id={self.id!r}, name={self.name!r}, "
            f"tenant_id={self.tenant_id!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert AttestationPolicy to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "tenant_id": self.tenant_id,
            "name": self.name,
            "required_artifacts": self.required_artifacts,
            "required_scopes": self.required_scopes,
            "compliance_metadata": self.compliance_metadata,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class BomMetadata(Base):
    """BOM version and format metadata.

    Stores versioning information for the BOM schema and generator toolchain.
    One row is typically inserted per BOM generation run and referenced by the
    associated BomSnapshot.

    Attributes:
        id: Auto-incrementing primary key.
        schema_version: Version of the BOM schema (default '1.0.0').
        format_version: Version of the serialisation format.
        generator_version: Version of the SkillMeat release that produced the BOM.
        created_at: Timestamp when this metadata record was created.
    """

    __tablename__ = "bom_metadata"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Version fields
    schema_version: Mapped[str] = mapped_column(
        String, nullable=False, default="1.0.0", server_default="1.0.0"
    )
    format_version: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    generator_version: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    def __repr__(self) -> str:
        """Return string representation of BomMetadata."""
        return (
            f"<BomMetadata(id={self.id!r}, schema_version={self.schema_version!r}, "
            f"format_version={self.format_version!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert BomMetadata to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "schema_version": self.schema_version,
            "format_version": self.format_version,
            "generator_version": self.generator_version,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ScopeValidator(Base):
    """Utility model for RBAC scope pattern validation.

    Stores the authoritative list of recognised scope patterns and their
    associated owner context.  At runtime, scope strings on attestation
    records are checked against these patterns to detect invalid or
    out-of-date scopes.

    Attributes:
        id: Auto-incrementing primary key.
        scope_pattern: Unique scope pattern string (e.g. 'artifact:read').
        owner_type: Owner context for which this scope is valid.
        description: Human-readable description of what the scope grants.
        created_at: Timestamp when the scope was registered.

    Indexes:
        - idx_scope_validators_scope_pattern: Unique look-up by pattern.
        - idx_scope_validators_owner_type: Filter by owner context.
    """

    __tablename__ = "scope_validators"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Scope definition
    scope_pattern: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    owner_type: Mapped[str] = mapped_column(
        String, nullable=False, default=OwnerType.user.value
    )
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Constraints / indexes
    __table_args__ = (
        Index("idx_scope_validators_scope_pattern", "scope_pattern", unique=True),
        Index("idx_scope_validators_owner_type", "owner_type"),
    )

    def __repr__(self) -> str:
        """Return string representation of ScopeValidator."""
        return (
            f"<ScopeValidator(id={self.id!r}, scope_pattern={self.scope_pattern!r}, "
            f"owner_type={self.owner_type!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert ScopeValidator to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "scope_pattern": self.scope_pattern,
            "owner_type": self.owner_type,
            "description": self.description,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class DriftCheckResult(Base):
    """Drift detection results for a DeploymentSet (backstage-plugin-v2).

    Records the outcome of a drift-check run against a specific DeploymentSet.
    Each row captures boolean drift indicators for three independent dimensions
    (version, content, policy) and a JSON details blob for extended diagnostics.
    Rows are append-only; staleness is tracked via the ``is_stale`` flag so that
    older results can be retained for audit history without being surfaced in the
    active UI.

    Attributes:
        id: Auto-incrementing integer primary key.
        deployment_set_id: FK to ``deployment_sets.id`` (CASCADE delete).
        version_drift: True when the deployed version differs from the upstream
            source version; None if the check was not run for this dimension.
        content_drift: True when file content of deployed artifacts differs from
            the upstream source; None if not checked.
        policy_drift: True when policy or access-control definitions have changed
            since last deployment; None if not checked.
        checked_at: UTC timestamp of when the drift check was performed
            (server default: current time).
        is_stale: Flag indicating this result has been superseded by a newer
            drift check; defaults to False.
        details: Arbitrary JSON blob for extended drift diagnostics (diff paths,
            affected artifacts, error messages, etc.).
        deployment_set: Back-reference to the owning ``DeploymentSet``.

    Indexes:
        - idx_drift_check_results_deployment_set_id: Fast lookup by parent set.
        - idx_drift_check_results_checked_at: Chronological ordering / pruning.
    """

    __tablename__ = "drift_check_results"

    # Primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Parent FK
    deployment_set_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("deployment_sets.id", ondelete="CASCADE"),
        nullable=False,
        comment="FK to deployment_sets.id",
    )

    # Drift indicators — nullable so a partial check (only some dimensions run)
    # is representable without loss of information.
    version_drift: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        comment="True when deployed version differs from upstream",
    )
    content_drift: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        comment="True when deployed file content differs from upstream",
    )
    policy_drift: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        comment="True when policy/access-control definitions have changed",
    )

    # Timestamp
    checked_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="UTC timestamp of the drift check run",
    )

    # Staleness flag
    is_stale: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="0",
        comment="True when superseded by a more recent drift check",
    )

    # Extended diagnostics
    details: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSON,
        nullable=True,
        comment="Arbitrary JSON blob for extended drift diagnostics",
    )

    # Relationship back to parent
    deployment_set: Mapped["DeploymentSet"] = relationship(
        "DeploymentSet",
        back_populates="drift_check_results",
    )

    # Constraints and indexes
    __table_args__ = (
        Index("idx_drift_check_results_deployment_set_id", "deployment_set_id"),
        Index("idx_drift_check_results_checked_at", "checked_at"),
    )

    def __repr__(self) -> str:
        """Return string representation of DriftCheckResult."""
        return (
            f"<DriftCheckResult(id={self.id!r}, "
            f"deployment_set_id={self.deployment_set_id!r}, "
            f"checked_at={self.checked_at!r}, "
            f"is_stale={self.is_stale!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert DriftCheckResult to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "deployment_set_id": self.deployment_set_id,
            "version_drift": self.version_drift,
            "content_drift": self.content_drift,
            "policy_drift": self.policy_drift,
            "checked_at": self.checked_at.isoformat() if self.checked_at else None,
            "is_stale": self.is_stale,
            "details": self.details,
        }


# =============================================================================
# Scaffold Template Models (template-management)
# =============================================================================


class ScaffoldTemplate(Base):
    """Backstage scaffold template configuration linked to a BundleEntity.

    A ScaffoldTemplate stores the configuration required to render and publish
    a Backstage scaffold template (``template.yaml``) for a given bundle.
    Each bundle may have at most one ScaffoldTemplate (one-to-one via
    ``bundle_id`` UNIQUE constraint).

    The model captures both the static scaffolding metadata (owner, type, tags)
    and the dynamic variable contract (``required_variables``,
    ``variable_type_map``) that the template exposes to Backstage consumers.
    A running log of past generation events is kept in ``generation_history``
    (capped to 20 entries at the service layer).

    Primary key format
    ------------------
    ``id`` stores a UUID hex string generated by ``uuid.uuid4().hex``,
    matching the convention used by ``BundleEntity`` and other post-ADR-007
    models.

    Relationship to BundleEntity
    ----------------------------
    ``bundle_id`` carries a UNIQUE constraint so that the ORM ``uselist=False``
    relationship on ``BundleEntity.scaffold_template`` is backed by a DB-level
    guarantee.  Deleting the parent ``BundleEntity`` cascades to this row.

    Attributes:
        id: UUID hex primary key.
        bundle_id: FK to ``bundles.id`` (UNIQUE, CASCADE delete, non-null).
        enabled: Whether the template is active; default ``True``.
        required_variables: JSON list of variable name strings that the
            template requires callers to supply.
        variable_type_map: JSON dict mapping variable names to Backstage UI
            field type strings (e.g. ``{"owner": "EntityPicker"}``).
        skeleton_ref: Optional GitHub URL used as the ``fetch:template``
            source step URL in the generated ``template.yaml``.
        backstage_owner: Optional Backstage entity reference for the
            template owner (e.g. ``"group:default/platform"``).
        backstage_type: Backstage template ``spec.type`` value;
            default ``"service"``.
        backstage_tags: JSON list of tag strings applied to the template
            spec in Backstage.
        bundle_version_at_last_generation: The bundle ``version`` string at
            the time the template was last generated; ``None`` if never
            generated.
        generation_history: JSON list of generation event dicts (max 20,
            enforced at service layer).  Each entry typically contains
            ``{"generated_at": ISO-string, "bundle_version": str,
            "generated_by": str}``.
        created_at: UTC timestamp when first persisted.
        updated_at: UTC timestamp on last update (auto-refreshed on writes).
        bundle: Back-reference to the owning ``BundleEntity``.

    Indexes:
        - idx_scaffold_templates_bundle_id: Fast lookup by owning bundle.
    """

    __tablename__ = "scaffold_templates"

    # Primary key — UUID hex
    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # Owning bundle — UNIQUE enforces 1-to-1 with BundleEntity
    bundle_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("bundles.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )

    # Template activation flag
    enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default="1"
    )

    # Variable contract
    required_variables: Mapped[Optional[Any]] = mapped_column(
        JSON,
        nullable=True,
        default=list,
        comment="JSON list of required variable name strings",
    )
    variable_type_map: Mapped[Optional[Any]] = mapped_column(
        JSON,
        nullable=True,
        default=dict,
        comment="JSON dict mapping variable names to Backstage UI field types",
    )

    # Skeleton source
    skeleton_ref: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="GitHub URL for the fetch:template step in template.yaml",
    )

    # Backstage metadata
    backstage_owner: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    backstage_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default="service",
        server_default="service",
    )
    backstage_tags: Mapped[Optional[Any]] = mapped_column(
        JSON,
        nullable=True,
        default=list,
        comment="JSON list of tag strings for the Backstage template spec",
    )

    # Generation tracking
    bundle_version_at_last_generation: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Bundle version string at the time of the last template generation",
    )
    generation_history: Mapped[Optional[Any]] = mapped_column(
        JSON,
        nullable=True,
        default=list,
        comment="JSON list of generation event dicts, capped at 20 by service layer",
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationship back to parent bundle
    bundle: Mapped["BundleEntity"] = relationship(
        "BundleEntity",
        back_populates="scaffold_template",
    )

    # Constraints and indexes
    __table_args__ = (Index("idx_scaffold_templates_bundle_id", "bundle_id"),)

    def __repr__(self) -> str:
        """Return string representation of ScaffoldTemplate."""
        return (
            f"<ScaffoldTemplate(id={self.id!r}, "
            f"bundle_id={self.bundle_id!r}, "
            f"enabled={self.enabled!r}, "
            f"backstage_type={self.backstage_type!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert ScaffoldTemplate to dictionary for JSON serialisation.

        Returns:
            Dictionary representation of the scaffold template configuration.
        """
        return {
            "id": self.id,
            "bundle_id": self.bundle_id,
            "enabled": self.enabled,
            "required_variables": self.required_variables,
            "variable_type_map": self.variable_type_map,
            "skeleton_ref": self.skeleton_ref,
            "backstage_owner": self.backstage_owner,
            "backstage_type": self.backstage_type,
            "backstage_tags": self.backstage_tags,
            "bundle_version_at_last_generation": self.bundle_version_at_last_generation,
            "generation_history": self.generation_history,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


# =============================================================================
# Artifact VCS v2 Models
# =============================================================================


class VersionSet(Base):
    """Logical grouping of related ArtifactVersions (artifact-vcs-v2).

    A VersionSet represents a bounded lineage of artifact versions that
    share a common ancestor chain.  The ``depth_limit`` controls how many
    historical versions are retained before the oldest are pruned.

    Attributes:
        id: UUID hex primary key.
        depth_limit: Maximum number of versions retained in this set (default 1).
        created_at: UTC timestamp when the set was created.
        versions: Back-reference to ArtifactVersion rows belonging to this set.
    """

    __tablename__ = "version_sets"

    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )
    depth_limit: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Back-reference from ArtifactVersion.  Uses explicit primaryjoin + foreign()
    # because ArtifactVersion.version_set_id does NOT carry a SQLAlchemy FK
    # declaration (to preserve test-fixture compatibility — see comment on
    # ArtifactVersion.version_set_id).
    versions: Mapped[List["ArtifactVersion"]] = relationship(
        "ArtifactVersion",
        primaryjoin="foreign(ArtifactVersion.version_set_id) == VersionSet.id",
        lazy="select",
        viewonly=True,
    )

    def __repr__(self) -> str:
        return f"<VersionSet(id={self.id!r}, depth_limit={self.depth_limit!r})>"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "depth_limit": self.depth_limit,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ArtifactCollectionVersion(Base):
    """Tracks the current collection-side version for each artifact (artifact-vcs-v2).

    One row per artifact (enforced by the UNIQUE constraint on ``artifact_id``).
    Points at the ``ArtifactVersion`` that represents the content currently
    held in the collection, along with its raw content hash.

    Attributes:
        id: UUID hex primary key.
        artifact_id: FK to ``artifacts.id`` (UNIQUE — one record per artifact).
        version_id: FK to ``artifact_versions.id`` — the current collection version.
        current_hash: SHA-256 content hash matching the version's ``content_hash``.
        updated_at: UTC timestamp, refreshed on every write.
        artifact: Related Artifact object.
        version: Related ArtifactVersion object.
    """

    __tablename__ = "artifact_collection_versions"

    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )
    artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    version_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifact_versions.id", ondelete="RESTRICT"),
        nullable=False,
    )
    current_hash: Mapped[str] = mapped_column(String, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # DVCS-2.1: nullable FK to BundleCommit — populated only for composite-type
    # artifacts (Tier 1+).  NULL for Tier 0 atoms.
    composite_commit_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("bundle_commits.id", ondelete="SET NULL"),
        nullable=True,
        comment=(
            "FK to bundle_commits.id — active BundleCommit for composite "
            "artifacts; NULL for Tier 0 atoms (DVCS-2.1)."
        ),
    )

    # Relationships
    artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[artifact_id],
        lazy="select",
    )
    version: Mapped["ArtifactVersion"] = relationship(
        "ArtifactVersion",
        foreign_keys=[version_id],
        lazy="select",
    )
    composite_commit: Mapped[Optional["BundleCommit"]] = relationship(
        "BundleCommit",
        foreign_keys=[composite_commit_id],
        lazy="select",
    )

    __table_args__ = (
        Index("idx_acv_artifact_id", "artifact_id", unique=True),
        Index("idx_acv_version_id", "version_id"),
        Index("idx_acv_composite_commit", "composite_commit_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<ArtifactCollectionVersion(id={self.id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"current_hash={self.current_hash[:8]}...)>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "artifact_id": self.artifact_id,
            "version_id": self.version_id,
            "current_hash": self.current_hash,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "composite_commit_id": self.composite_commit_id,
        }


class ProjectVersionDeployment(Base):
    """Append-only log of content-addressed artifact deployments (artifact-vcs-v2).

    Each row records a single deployment event: which artifact was deployed to
    which project, what content hash it had, and whether it was pinned.  Rows
    are never modified after insert (append-only audit log).

    ``ProjectArtifact.latest_deployment_id`` points to the most recent row for
    a given ``(artifact_id, project_id)`` pair, providing O(1) latest-pointer
    access without a subquery.

    Attributes:
        id: UUID hex primary key.
        artifact_id: FK to ``artifacts.id``.
        project_id: FK to ``projects.id``.
        content_hash: SHA-256 hash of the deployed artifact content.
        pinned: When True the deployed version is locked against auto-updates.
        deployed_at: UTC timestamp of the deployment event.
        updated_at: UTC timestamp (set once at insert; not updated thereafter).
        artifact: Related Artifact object.
        project: Related Project object.

    Indexes:
        - ix_pvd_artifact_project: Composite lookup by artifact + project.
        - ix_pvd_deployed_at_desc: Ordering by deployment time.
    """

    __tablename__ = "project_version_deployments"

    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )
    artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.id", ondelete="CASCADE"),
        nullable=False,
    )
    project_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=False,
    )
    content_hash: Mapped[str] = mapped_column(String, nullable=False)
    pinned: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="0"
    )
    deployed_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Relationships
    artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[artifact_id],
        lazy="select",
    )
    project: Mapped["Project"] = relationship(
        "Project",
        foreign_keys=[project_id],
        lazy="select",
    )

    __table_args__ = (
        Index("ix_pvd_artifact_project", "artifact_id", "project_id"),
        Index("ix_pvd_deployed_at_desc", "deployed_at"),
    )

    def __repr__(self) -> str:
        return (
            f"<ProjectVersionDeployment(id={self.id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"project_id={self.project_id!r}, "
            f"content_hash={self.content_hash[:8]}..., "
            f"pinned={self.pinned!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "artifact_id": self.artifact_id,
            "project_id": self.project_id,
            "content_hash": self.content_hash,
            "pinned": self.pinned,
            "deployed_at": self.deployed_at.isoformat() if self.deployed_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


# =============================================================================
# Git Repo Connector models  (GRC-DB-004)
# =============================================================================


class GitRepoConnection(Base):
    """Registered Git repository connection for artifact discovery scanning (GRC).

    Each row represents one branch of one Git repository that SkillMeat should
    scan for Claude Code artifacts.  The combination ``(project_id, repo_url,
    branch)`` is unique — a project cannot register the same branch twice.

    ``last_scan_id`` is a plain integer reference (no FK constraint) to the
    most recent ``GitRepoScan`` row.  The FK is omitted to avoid a circular
    dependency at schema-creation time (the two tables reference each other).
    Referential integrity for this column is enforced at the application layer.

    Attributes:
        id:             Integer PK (autoincrement).
        project_id:     FK to ``projects.id`` (cascade-delete); nullable for
                        enterprise use where project is identified via tenant context.
        repo_url:       Full clone URL of the Git repository.
        branch:         Branch to scan (default 'main').
        developer_id:   Optional FK to ``users.id`` identifying the owning developer.
        scan_schedule:  Reserved for future cron expression.
        webhook_secret: HMAC secret for webhook push-event validation.
        last_scan_at:   UTC timestamp of the most recently completed scan.
        last_scan_id:   Plain integer reference to the latest ``GitRepoScan``
                        (no FK — see above).
        is_active:      When False the connection is paused.
        created_at:     UTC creation timestamp.
        created_by:     Optional FK to ``users.id`` of the registering user.
        scans:          All ``GitRepoScan`` rows belonging to this connection.

    Constraints:
        uq_git_repo_connections_project_url_branch:
            UNIQUE (project_id, repo_url, branch)

    Indexes:
        idx_git_repo_connections_project_id   (project_id)
        idx_git_repo_connections_is_active    (is_active)
        idx_git_repo_connections_developer_id (developer_id)
    """

    __tablename__ = "git_repo_connections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    project_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("projects.id", ondelete="SET NULL", name="fk_grc_project_id"),
        nullable=True,
        comment="Convenience back-reference to the owning project; SET NULL on delete so connections survive project deletion",
    )
    repo_url: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Full clone URL of the Git repository (HTTPS or SSH)",
    )
    branch: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default="main",
        server_default="main",
        comment="Branch to scan; defaults to 'main'",
    )
    developer_id: Mapped[Optional[int]] = mapped_column(
        Integer,
        ForeignKey("users.id", name="fk_grc_developer_id"),
        nullable=True,
        comment="Optional FK to users.id identifying the developer who owns this connection",
    )
    scan_schedule: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Reserved: future cron expression for scheduled scans (e.g. '0 * * * *')",
    )
    webhook_secret: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Webhook HMAC secret for validating incoming push events; treat as sensitive",
    )
    last_scan_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        comment="UTC timestamp of the most recently completed scan",
    )
    last_scan_id: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        comment=(
            "Plain reference (no FK) to the most recent git_repo_scans.id. "
            "No FK constraint is defined to avoid a circular dependency."
        ),
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default="1",
        comment="When False the connection is paused and will not be scanned",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        comment="UTC creation timestamp",
    )
    created_by: Mapped[Optional[int]] = mapped_column(
        Integer,
        ForeignKey("users.id", name="fk_grc_created_by"),
        nullable=True,
        comment="Optional FK to users.id of the user who registered this connection",
    )
    access_token: Mapped[Optional[str]] = mapped_column(
        EncryptedString(),
        nullable=True,
        comment="Encrypted personal access token for authenticated git operations on this connection",
    )

    # Relationships
    project: Mapped[Optional["Project"]] = relationship(
        "Project",
        foreign_keys=[project_id],
        lazy="select",
    )
    developer: Mapped[Optional["User"]] = relationship(
        "User",
        foreign_keys=[developer_id],
        lazy="select",
    )
    scans: Mapped[List["GitRepoScan"]] = relationship(
        "GitRepoScan",
        back_populates="connection",
        cascade="all, delete-orphan",
        lazy="select",
    )
    linked_projects: Mapped[List["ProjectGitConnection"]] = relationship(
        "ProjectGitConnection",
        back_populates="connection",
        cascade="all, delete-orphan",
        lazy="select",
    )

    __table_args__ = (
        UniqueConstraint(
            "repo_url",
            "branch",
            name="uq_git_repo_connections_url_branch",
        ),
        Index("idx_git_repo_connections_project_id", "project_id"),
        Index("idx_git_repo_connections_is_active", "is_active"),
        Index("idx_git_repo_connections_developer_id", "developer_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<GitRepoConnection(id={self.id!r}, "
            f"repo_url={self.repo_url!r}, "
            f"branch={self.branch!r}, "
            f"is_active={self.is_active!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "repo_url": self.repo_url,
            "branch": self.branch,
            "developer_id": self.developer_id,
            "scan_schedule": self.scan_schedule,
            "last_scan_at": (
                self.last_scan_at.isoformat() if self.last_scan_at else None
            ),
            "last_scan_id": self.last_scan_id,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
        }


class GitRepoScan(Base):
    """Single execution of an artifact-discovery scan for a Git repo connection (GRC).

    Each scan is triggered manually, by schedule, or by a webhook push event.
    The scan transitions through ``pending`` → ``running`` → ``completed`` /
    ``failed``.  After the scan completes the aggregate counters report how many
    artifacts were found, added, changed, or removed relative to the previous run.

    Attributes:
        id:                Integer PK (autoincrement).
        connection_id:     FK to ``git_repo_connections.id`` (cascade-delete).
        triggered_by:      How the scan was initiated ('manual', 'schedule', 'webhook').
        trigger_sha:       Git commit SHA that triggered the scan (40-char hex); nullable.
        status:            Current lifecycle state ('pending', 'running', 'completed', 'failed').
        started_at:        UTC timestamp when the worker started processing.
        completed_at:      UTC timestamp when the scan finished.
        artifacts_found:   Total artifacts detected.
        artifacts_new:     Artifacts not seen in previous scans.
        artifacts_changed: Artifacts whose content changed.
        artifacts_removed: Artifacts absent from this scan vs. the previous one.
        error_message:     Human-readable failure detail when status is 'failed'.
        created_at:        UTC creation timestamp.
        connection:        Back-reference to the parent ``GitRepoConnection``.
        scan_artifacts:    All ``GitScanArtifact`` rows produced by this scan.

    Constraints:
        ck_git_repo_scans_triggered_by:  triggered_by IN ('manual', 'schedule', 'webhook')
        ck_git_repo_scans_status:        status IN ('pending', 'running', 'completed', 'failed')

    Indexes:
        idx_git_repo_scans_connection_id  (connection_id)
        idx_git_repo_scans_status         (status)
        idx_git_repo_scans_created_at     (created_at)
    """

    __tablename__ = "git_repo_scans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    connection_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey(
            "git_repo_connections.id",
            ondelete="CASCADE",
            name="fk_grs_connection_id",
        ),
        nullable=False,
        comment="FK to git_repo_connections.id; cascade-delete on connection removal",
    )
    triggered_by: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="How this scan was initiated: 'manual', 'schedule', or 'webhook'",
    )
    trigger_sha: Mapped[Optional[str]] = mapped_column(
        String(40),
        nullable=True,
        comment="Git commit SHA (40-char hex) that triggered this scan; NULL for manual/schedule",
    )
    status: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default="pending",
        server_default="pending",
        comment="Current scan lifecycle state: 'pending', 'running', 'completed', or 'failed'",
    )
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        comment="UTC timestamp when the scan worker picked up the job",
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        comment="UTC timestamp when the scan finished (success or failure)",
    )
    artifacts_found: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
        comment="Total artifacts detected in this scan run",
    )
    artifacts_new: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
        comment="Artifacts newly discovered (not seen in previous scans)",
    )
    artifacts_changed: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
        comment="Artifacts whose content changed since the last scan",
    )
    artifacts_removed: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
        comment="Artifacts present in the previous scan but no longer found",
    )
    error_message: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Human-readable error detail when status is 'failed'",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        comment="UTC timestamp when the scan record was created",
    )

    # Relationships
    connection: Mapped["GitRepoConnection"] = relationship(
        "GitRepoConnection",
        back_populates="scans",
        lazy="select",
    )
    scan_artifacts: Mapped[List["GitScanArtifact"]] = relationship(
        "GitScanArtifact",
        back_populates="scan",
        cascade="all, delete-orphan",
        lazy="select",
    )

    __table_args__ = (
        CheckConstraint(
            "triggered_by IN ('manual', 'schedule', 'webhook')",
            name="ck_git_repo_scans_triggered_by",
        ),
        CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed')",
            name="ck_git_repo_scans_status",
        ),
        Index("idx_git_repo_scans_connection_id", "connection_id"),
        Index("idx_git_repo_scans_status", "status"),
        Index("idx_git_repo_scans_created_at", "created_at"),
    )

    def __repr__(self) -> str:
        return (
            f"<GitRepoScan(id={self.id!r}, "
            f"connection_id={self.connection_id!r}, "
            f"triggered_by={self.triggered_by!r}, "
            f"status={self.status!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "connection_id": self.connection_id,
            "triggered_by": self.triggered_by,
            "trigger_sha": self.trigger_sha,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": (
                self.completed_at.isoformat() if self.completed_at else None
            ),
            "artifacts_found": self.artifacts_found,
            "artifacts_new": self.artifacts_new,
            "artifacts_changed": self.artifacts_changed,
            "artifacts_removed": self.artifacts_removed,
            "error_message": self.error_message,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class GitScanArtifact(Base):
    """Single artifact observation produced by a Git repo scan run (GRC).

    Each row records one artifact found (or noted as removed/unchanged) during
    a ``GitRepoScan`` run.  After a scan completes, rows with ``indexed_at``
    set have been imported into the local cache and ``artifact_id`` points to
    the corresponding ``Artifact`` row.

    Attributes:
        id:             Integer PK (autoincrement).
        scan_id:        FK to ``git_repo_scans.id`` (cascade-delete).
        artifact_path:  Repository-relative path to the artifact directory/file.
        artifact_type:  Detected artifact type label (e.g. 'skill', 'agent').
        detected_name:  Human-readable name parsed from frontmatter; nullable.
        content_hash:   SHA-256 hex digest (64 chars) of artifact content at
                        scan time; nullable when content could not be hashed.
        change_type:    Classification relative to previous scan
                        ('new', 'changed', 'removed', 'unchanged').
        indexed_at:     UTC timestamp when imported into cache; NULL until then.
        artifact_id:    FK to ``artifacts.id`` once indexed; NULL until import.
        created_at:     UTC creation timestamp.
        scan:           Back-reference to the parent ``GitRepoScan``.

    Constraints:
        ck_git_scan_artifacts_change_type:
            change_type IN ('new', 'changed', 'removed', 'unchanged')

    Indexes:
        idx_git_scan_artifacts_scan_id       (scan_id)
        idx_git_scan_artifacts_artifact_path (artifact_path)
        idx_git_scan_artifacts_change_type   (change_type)
        idx_git_scan_artifacts_artifact_id   (artifact_id)
    """

    __tablename__ = "git_scan_artifacts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    scan_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey(
            "git_repo_scans.id",
            ondelete="CASCADE",
            name="fk_gsa_scan_id",
        ),
        nullable=False,
        comment="FK to git_repo_scans.id; cascade-delete when the parent scan is removed",
    )
    artifact_path: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Repository-relative path to the artifact directory or file",
    )
    artifact_type: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        comment="Detected artifact type label (e.g. 'skill', 'agent', 'command')",
    )
    detected_name: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Human-readable artifact name parsed from CLAUDE.md or SKILL.md frontmatter",
    )
    content_hash: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="SHA-256 hex digest (64 chars) of the artifact's content at scan time",
    )
    change_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment=(
            "How this artifact changed since the last scan: "
            "'new', 'changed', 'removed', or 'unchanged'"
        ),
    )
    indexed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        comment="UTC timestamp when this artifact was imported into the local cache",
    )
    artifact_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("artifacts.id", name="fk_gsa_artifact_id"),
        nullable=True,
        comment=(
            "FK to artifacts.id once the artifact has been indexed/imported. "
            "NULL until import completes."
        ),
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        comment="UTC timestamp when this observation record was created",
    )

    # Relationships
    scan: Mapped["GitRepoScan"] = relationship(
        "GitRepoScan",
        back_populates="scan_artifacts",
        lazy="select",
    )
    artifact: Mapped[Optional["Artifact"]] = relationship(
        "Artifact",
        foreign_keys=[artifact_id],
        lazy="select",
    )

    __table_args__ = (
        CheckConstraint(
            "change_type IN ('new', 'changed', 'removed', 'unchanged')",
            name="ck_git_scan_artifacts_change_type",
        ),
        Index("idx_git_scan_artifacts_scan_id", "scan_id"),
        Index("idx_git_scan_artifacts_artifact_path", "artifact_path"),
        Index("idx_git_scan_artifacts_change_type", "change_type"),
        Index("idx_git_scan_artifacts_artifact_id", "artifact_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<GitScanArtifact(id={self.id!r}, "
            f"scan_id={self.scan_id!r}, "
            f"artifact_path={self.artifact_path!r}, "
            f"change_type={self.change_type!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "scan_id": self.scan_id,
            "artifact_path": self.artifact_path,
            "artifact_type": self.artifact_type,
            "detected_name": self.detected_name,
            "content_hash": self.content_hash,
            "change_type": self.change_type,
            "indexed_at": self.indexed_at.isoformat() if self.indexed_at else None,
            "artifact_id": self.artifact_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ProjectGitConnection(Base):
    """Join table linking Projects to GitRepoConnections (many-to-many).

    Introduced in GCD-1.2 to decouple connections from projects.  A connection
    is a long-lived, project-independent object; this table records which
    projects have linked which connections and when.

    Attributes:
        project_id:    FK to ``projects.id`` (ON DELETE CASCADE); part of composite PK.
        connection_id: FK to ``git_repo_connections.id`` (ON DELETE CASCADE); part of composite PK.
        linked_at:     UTC timestamp when the link was created.
        linked_by:     Optional actor identifier (user ID, ``'migration'``, etc.).
        project:       Back-reference to the linked ``Project``.
        connection:    Back-reference to the linked ``GitRepoConnection``.

    Constraints:
        pk_pgc: PRIMARY KEY (project_id, connection_id)

    Indexes:
        ix_pgc_project_id    (project_id)
        ix_pgc_connection_id (connection_id)
    """

    __tablename__ = "project_git_connections"

    project_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("projects.id", ondelete="CASCADE", name="fk_pgc_project_id"),
        primary_key=True,
        nullable=False,
        comment="FK to projects.id; row deleted when project is deleted",
    )
    connection_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey(
            "git_repo_connections.id", ondelete="CASCADE", name="fk_pgc_connection_id"
        ),
        primary_key=True,
        nullable=False,
        comment="FK to git_repo_connections.id; row deleted when connection is deleted",
    )
    linked_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="UTC timestamp when the connection was linked to the project",
    )
    linked_by: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Optional actor identifier that created the link (user ID, 'migration', etc.)",
    )

    # Relationships
    project: Mapped["Project"] = relationship(
        "Project",
        foreign_keys=[project_id],
        lazy="select",
    )
    connection: Mapped["GitRepoConnection"] = relationship(
        "GitRepoConnection",
        back_populates="linked_projects",
        lazy="select",
    )

    __table_args__ = (
        Index("ix_pgc_project_id", "project_id"),
        Index("ix_pgc_connection_id", "connection_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<ProjectGitConnection(project_id={self.project_id!r}, "
            f"connection_id={self.connection_id!r}, "
            f"linked_at={self.linked_at!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "project_id": self.project_id,
            "connection_id": self.connection_id,
            "linked_at": self.linked_at.isoformat() if self.linked_at else None,
            "linked_by": self.linked_by,
        }


# =============================================================================
# DVCS Phase 2 Models (DVCS-2.1)
# =============================================================================


class BundleCommit(Base):
    """Atomic snapshot of a composite artifact's member state (DVCS-2.1).

    Each row records a complete, validated snapshot of all child artifacts
    within a composite artifact (Plugin, Bundle, ContextModule) at a point in
    time.  The ``bundle_hash`` is a deterministic SHA-256 over sorted
    ``(artifact_uuid, content_hash)`` pairs, enabling idempotency detection
    and change diffing without re-fetching members.

    Commits form a singly-linked list via ``parent_id``.  Rollback operations
    always create a *new* commit (``is_rollback=1``) pointing at the target
    via ``rolled_back_to``, preserving full lineage.

    Attributes:
        id: UUIDv4 hex primary key (32 chars).
        composite_artifact_id: FK to ``artifacts.uuid`` ON DELETE CASCADE.
        composite_type: Artifact type label of the composite (e.g. "plugin").
        bundle_hash: Deterministic SHA-256 of sorted member (uuid, hash) pairs.
        parent_id: Nullable self-FK to prior commit; NULL for the first commit.
        sequence_number: Monotonic counter per composite (UNIQUE with
            composite_artifact_id).
        change_origin: Origin of the commit — "manual", "sync", "deploy",
            "capture", or "rollback".
        created_at: UTC timestamp when the commit was created.
        created_by: Optional actor identifier (user or agent).
        message: Optional human-readable commit message.
        is_rollback: 1 when this commit is a rollback/restore operation.
        rolled_back_to: Nullable FK to the target commit when is_rollback=1.
        members: Back-reference to BundleCommitMember rows.
        parent: Related prior BundleCommit (self-referential).
        rolled_back_to_commit: Related target BundleCommit (self-referential).

    Indexes:
        - idx_bc_composite_id: Fast lookup by composite artifact
        - idx_bc_parent_id: Walk commit chain via parent_id
        - idx_bc_composite_hash: Idempotency check by (composite, hash)

    Constraints:
        - uq_bc_composite_sequence: UNIQUE(composite_artifact_id, sequence_number)
        - ck_bundle_commits_change_origin: Enum CHECK on change_origin
    """

    __tablename__ = "bundle_commits"

    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )
    composite_artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        nullable=False,
    )
    composite_type: Mapped[str] = mapped_column(String, nullable=False)
    bundle_hash: Mapped[str] = mapped_column(String, nullable=False)
    parent_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("bundle_commits.id", ondelete="SET NULL"),
        nullable=True,
    )
    sequence_number: Mapped[int] = mapped_column(Integer, nullable=False)
    change_origin: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Enum: manual, sync, deploy, capture, rollback",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    created_by: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_rollback: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    rolled_back_to: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("bundle_commits.id", ondelete="SET NULL"),
        nullable=True,
    )

    # Relationships
    members: Mapped[List["BundleCommitMember"]] = relationship(
        "BundleCommitMember",
        back_populates="commit",
        cascade="all, delete-orphan",
        lazy="select",
    )
    parent: Mapped[Optional["BundleCommit"]] = relationship(
        "BundleCommit",
        foreign_keys=[parent_id],
        remote_side="BundleCommit.id",
        lazy="select",
    )
    rolled_back_to_commit: Mapped[Optional["BundleCommit"]] = relationship(
        "BundleCommit",
        foreign_keys=[rolled_back_to],
        remote_side="BundleCommit.id",
        lazy="select",
    )
    composite_artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[composite_artifact_id],
        primaryjoin="BundleCommit.composite_artifact_id == Artifact.uuid",
        lazy="select",
    )

    __table_args__ = (
        UniqueConstraint(
            "composite_artifact_id",
            "sequence_number",
            name="uq_bc_composite_sequence",
        ),
        CheckConstraint(
            "change_origin IN ('manual', 'sync', 'deploy', 'capture', 'rollback')",
            name="ck_bundle_commits_change_origin",
        ),
        Index("idx_bc_composite_id", "composite_artifact_id"),
        Index("idx_bc_parent_id", "parent_id"),
        Index("idx_bc_composite_hash", "composite_artifact_id", "bundle_hash"),
    )

    def __repr__(self) -> str:
        return (
            f"<BundleCommit(id={self.id!r}, "
            f"composite_artifact_id={self.composite_artifact_id!r}, "
            f"sequence_number={self.sequence_number!r}, "
            f"bundle_hash={self.bundle_hash[:8]}..., "
            f"is_rollback={self.is_rollback!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "composite_artifact_id": self.composite_artifact_id,
            "composite_type": self.composite_type,
            "bundle_hash": self.bundle_hash,
            "parent_id": self.parent_id,
            "sequence_number": self.sequence_number,
            "change_origin": self.change_origin,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "message": self.message,
            "is_rollback": self.is_rollback,
            "rolled_back_to": self.rolled_back_to,
        }


class BundleCommitMember(Base):
    """Per-member snapshot payload within a BundleCommit (DVCS-2.1).

    Each row records the exact ``ArtifactVersion`` and content hash for one
    member artifact at the time the parent ``BundleCommit`` was created.
    The content hash is stored redundantly for fast conflict detection during
    rollback pre-flight analysis (avoids joining to ``artifact_versions``).

    ON DELETE RESTRICT on ``artifact_version_id`` prevents orphaned member
    rows if an ``ArtifactVersion`` is garbage-collected; the GC service must
    remove ``BundleCommitMember`` rows before deleting versions.

    Attributes:
        bundle_commit_id: FK to ``bundle_commits.id`` ON DELETE CASCADE.
        artifact_id: Human-readable artifact identifier (e.g. "my-skill").
        artifact_uuid: Stable UUID FK to ``artifacts.uuid`` ON DELETE CASCADE.
        artifact_version_id: FK to ``artifact_versions.id`` ON DELETE RESTRICT.
        content_hash: Snapshot of the content hash at commit time.
        commit: Related BundleCommit parent.

    Indexes:
        - idx_bcm_artifact_uuid: Reverse lookup — all commits containing an artifact
        - idx_bcm_version_id: Lookup by specific artifact version
    """

    __tablename__ = "bundle_commit_members"

    # Composite PK: (bundle_commit_id, artifact_uuid)
    bundle_commit_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("bundle_commits.id", ondelete="CASCADE"),
        nullable=False,
        primary_key=True,
    )
    artifact_id: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Human-readable artifact identifier",
    )
    artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        nullable=False,
        primary_key=True,
    )
    artifact_version_id: Mapped[str] = mapped_column(
        String,
        ForeignKey(
            "artifact_versions.id",
            ondelete="RESTRICT",
            name="fk_bcm_artifact_version_id",
        ),
        nullable=False,
    )
    content_hash: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Snapshot of content_hash at commit time (for conflict detection)",
    )

    # Relationships
    commit: Mapped["BundleCommit"] = relationship(
        "BundleCommit",
        back_populates="members",
        lazy="select",
    )
    artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[artifact_uuid],
        primaryjoin="BundleCommitMember.artifact_uuid == Artifact.uuid",
        lazy="select",
    )
    artifact_version: Mapped["ArtifactVersion"] = relationship(
        "ArtifactVersion",
        foreign_keys=[artifact_version_id],
        lazy="select",
    )

    __table_args__ = (
        Index("idx_bcm_artifact_uuid", "artifact_uuid"),
        Index("idx_bcm_version_id", "artifact_version_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<BundleCommitMember("
            f"bundle_commit_id={self.bundle_commit_id!r}, "
            f"artifact_uuid={self.artifact_uuid!r}, "
            f"artifact_version_id={self.artifact_version_id!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "bundle_commit_id": self.bundle_commit_id,
            "artifact_id": self.artifact_id,
            "artifact_uuid": self.artifact_uuid,
            "artifact_version_id": self.artifact_version_id,
            "content_hash": self.content_hash,
        }


class ArtifactDependency(Base):
    """General-purpose DAG edge table for cross-tier dependency traversal (DVCS-2.1).

    Represents a directed dependency from ``parent_artifact_id`` to
    ``child_artifact_id`` within the scope of ``composite_artifact_id``.
    Designed for O(log N + K) indexed range queries supporting topological sort
    (Kahn's BFS), reverse lookups ("which composites contain artifact X?"), and
    recursive CTE traversal.

    The ADR-008 Downward Dependency Rule enforces strict tier monotonicity
    (Tier N → Tier N-1 or lower), making cycles structurally impossible.
    Application-layer cycle detection in ``add_dependency()`` provides
    defense-in-depth.

    Attributes:
        id: UUIDv4 hex primary key.
        composite_artifact_id: FK to ``artifacts.uuid`` — the owning composite.
        parent_artifact_id: FK to ``artifacts.uuid`` — parent in the DAG edge.
        child_artifact_id: FK to ``artifacts.uuid`` — child in the DAG edge.
        dependency_type: Edge semantics — "composition" (structural),
            "reference" (soft dep), or "build" (dev-only).
        ordering: Optional integer hint for UI display ordering.
        created_at: UTC timestamp when the dependency was recorded.

    Indexes:
        - idx_ad_composite_id: Filter edges by owning composite
        - idx_ad_parent_id: Outgoing edges from a parent (forward traversal)
        - idx_ad_child_id: Incoming edges to a child (reverse lookup)

    Constraints:
        - uq_ad_composite_parent_child: UNIQUE per (composite, parent, child)
        - ck_artifact_dependencies_dependency_type: Enum CHECK on dependency_type
    """

    __tablename__ = "artifact_dependencies"

    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: uuid.uuid4().hex
    )
    composite_artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        nullable=False,
    )
    parent_artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        nullable=False,
    )
    child_artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        nullable=False,
    )
    dependency_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Enum: composition, reference, build",
    )
    ordering: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )

    # Relationships — three FKs to artifacts.uuid require explicit foreign_keys=
    composite_artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[composite_artifact_id],
        primaryjoin="ArtifactDependency.composite_artifact_id == Artifact.uuid",
        lazy="select",
    )
    parent_artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[parent_artifact_id],
        primaryjoin="ArtifactDependency.parent_artifact_id == Artifact.uuid",
        lazy="select",
    )
    child_artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[child_artifact_id],
        primaryjoin="ArtifactDependency.child_artifact_id == Artifact.uuid",
        lazy="select",
    )

    __table_args__ = (
        UniqueConstraint(
            "composite_artifact_id",
            "parent_artifact_id",
            "child_artifact_id",
            name="uq_ad_composite_parent_child",
        ),
        CheckConstraint(
            "dependency_type IN ('composition', 'reference', 'build')",
            name="ck_artifact_dependencies_dependency_type",
        ),
        Index("idx_ad_composite_id", "composite_artifact_id"),
        Index("idx_ad_parent_id", "parent_artifact_id"),
        Index("idx_ad_child_id", "child_artifact_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<ArtifactDependency(id={self.id!r}, "
            f"composite_artifact_id={self.composite_artifact_id!r}, "
            f"parent_artifact_id={self.parent_artifact_id!r}, "
            f"child_artifact_id={self.child_artifact_id!r}, "
            f"dependency_type={self.dependency_type!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "composite_artifact_id": self.composite_artifact_id,
            "parent_artifact_id": self.parent_artifact_id,
            "child_artifact_id": self.child_artifact_id,
            "dependency_type": self.dependency_type,
            "ordering": self.ordering,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# =============================================================================
# TierNamespace (DVCS-3.1)
# =============================================================================


class TierNamespace(Base):
    """Registry of namespaces within each DVCS collection tier.

    A namespace is a slug that groups related artifacts within a tier
    (e.g. "platform-eng" at the team tier, "personal" at the dev tier).
    Namespaces can optionally form a parent–child hierarchy for organisational
    sub-divisions.

    This table is the authoritative source for valid ``Artifact.namespace``
    values at each tier.  The application enforces referential integrity at
    the service layer (not as a DB-level FK) to avoid migration complexity.

    Attributes:
        id: Integer surrogate primary key (autoincrement).
        tier: Collection tier this namespace belongs to.  Mirrors
              ``CollectionTier`` enum values.
        namespace: URL-safe slug identifying the namespace within the tier.
        display_name: Optional human-readable label for the namespace.
        description: Optional free-text description.
        parent_namespace_id: Optional FK to ``tier_namespaces.id`` for
                             hierarchical sub-namespace relationships.
        created_at: UTC timestamp when the namespace was registered.
        updated_at: UTC timestamp of the last modification.

    Constraints:
        - ``(tier, namespace)`` is UNIQUE — a slug is unique within its tier.
        - ``tier`` must be one of the five ``CollectionTier`` values.

    Example:
        >>> ns = TierNamespace(tier="team", namespace="platform-eng",
        ...                    display_name="Platform Engineering")
        >>> ns.tier
        'team'
    """

    __tablename__ = "tier_namespaces"

    # Surrogate primary key
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Which tier this namespace belongs to
    tier: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment=(
            "Collection tier for this namespace: "
            "'marketplace'|'enterprise'|'team'|'dev'|'project'."
        ),
    )

    # URL-safe namespace slug
    namespace: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="URL-safe slug identifying the namespace within the tier.",
    )

    # Optional human-friendly label
    display_name: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, comment="Human-readable display name."
    )

    # Optional free-text description
    description: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True, comment="Optional description of the namespace."
    )

    # Self-referential parent for hierarchical namespaces
    parent_namespace_id: Mapped[Optional[int]] = mapped_column(
        Integer,
        ForeignKey("tier_namespaces.id", ondelete="SET NULL"),
        nullable=True,
        comment="FK to tier_namespaces.id for hierarchical sub-namespaces.",
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    parent: Mapped[Optional["TierNamespace"]] = relationship(
        "TierNamespace",
        remote_side="TierNamespace.id",
        back_populates="children",
        lazy="select",
    )
    children: Mapped[List["TierNamespace"]] = relationship(
        "TierNamespace",
        back_populates="parent",
        lazy="select",
    )

    # Constraints
    __table_args__ = (
        # Tier domain guard — mirrors CollectionTier enum values
        CheckConstraint(
            "tier IN ('marketplace', 'enterprise', 'team', 'dev', 'project')",
            name="check_tier_namespaces_tier",
        ),
        # Uniqueness: a namespace slug must be unique within a tier
        UniqueConstraint("tier", "namespace", name="uq_tier_namespaces_tier_namespace"),
    )

    def __repr__(self) -> str:
        """Return string representation of TierNamespace."""
        return (
            f"<TierNamespace(id={self.id!r}, tier={self.tier!r}, "
            f"namespace={self.namespace!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert TierNamespace to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "tier": self.tier,
            "namespace": self.namespace,
            "display_name": self.display_name,
            "description": self.description,
            "parent_namespace_id": self.parent_namespace_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class TrustLevel(enum.Enum):
    """Trust level for artifact signatures.

    Mirrors the ``trust_level`` string stored in the ``artifact_signatures.trust_level`` column.
    Values map directly to the string representation written to the DB so
    that ``signature.trust_level`` can be compared to ``TrustLevel.untrusted.value``
    without a round-trip through the enum.

    Members:
        untrusted:   Signature is present but not verified or trusted.
        community:   Signature is verified by community members or automated checks.
        verified:    Signature is verified by a trusted authority or maintainer.
        official:    Signature is from an official source (e.g., Anthropic).
    """

    untrusted = "untrusted"
    community = "community"
    verified = "verified"
    official = "official"


class ArtifactSignature(Base):
    """Cryptographic signature for an artifact.

    Stores Ed25519 public keys and signatures for cryptographic trust verification
    of artifacts in the DVCS system (DVCS-4.1).

    Attributes:
        id: Unique signature identifier (primary key)
        artifact_uuid: Foreign key to artifacts.uuid
        public_key: Ed25519 public key (hex-encoded, 64 characters)
        signature: Cryptographic signature (hex-encoded)
        trust_level: Trust level enum (untrusted, community, verified, official)
        signer_id: Optional identifier for the signing entity
        created_at: Timestamp when signature was created
        updated_at: Timestamp when signature was last updated
        artifact: Related Artifact object

    Indexes:
        - idx_artifact_signatures_artifact_uuid: Join performance
        - idx_artifact_signatures_trust_level: Filter by trust level
        - idx_artifact_signatures_public_key: Lookup by public key
    """

    __tablename__ = "artifact_signatures"

    # Primary key
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=lambda: uuid.uuid4().hex,
        comment="Unique signature identifier",
    )

    # Foreign key to artifacts
    artifact_uuid: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.uuid", ondelete="CASCADE"),
        nullable=False,
        comment="Foreign key to artifacts.uuid",
    )

    # Ed25519 public key (hex-encoded, 64 chars)
    public_key: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        comment="Ed25519 public key (hex-encoded, 64 characters)",
    )

    # Cryptographic signature (hex-encoded)
    signature: Mapped[str] = mapped_column(
        Text, nullable=False, comment="Cryptographic signature (hex-encoded)"
    )

    # Trust level
    trust_level: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default=TrustLevel.untrusted.value,
        comment="Trust level: untrusted, community, verified, official",
    )

    # Optional signer identifier
    signer_id: Mapped[Optional[str]] = mapped_column(
        String, nullable=True, comment="Optional identifier for the signing entity"
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=datetime.utcnow,
        nullable=False,
        comment="Timestamp when signature was created",
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=False,
        comment="Timestamp when signature was last updated",
    )

    # Relationships
    artifact: Mapped["Artifact"] = relationship(
        "Artifact", back_populates="signatures", lazy="select"
    )

    # Table constraints and indexes
    __table_args__ = (
        # Check constraint for trust level
        CheckConstraint(
            "trust_level IN ('untrusted', 'community', 'verified', 'official')",
            name="check_artifact_signatures_trust_level",
        ),
        # Check constraint for public key length (64 hex chars)
        CheckConstraint(
            "length(public_key) = 64",
            name="check_artifact_signatures_public_key_length",
        ),
        # Indexes
        Index("idx_artifact_signatures_artifact_uuid", "artifact_uuid"),
        Index("idx_artifact_signatures_trust_level", "trust_level"),
        Index("idx_artifact_signatures_public_key", "public_key"),
        # Unique constraint: one signature per artifact per public key
        UniqueConstraint(
            "artifact_uuid",
            "public_key",
            name="uq_artifact_signatures_artifact_public_key",
        ),
    )

    def __repr__(self) -> str:
        """Return string representation of ArtifactSignature."""
        return (
            f"<ArtifactSignature(id={self.id!r}, artifact_uuid={self.artifact_uuid!r}, "
            f"trust_level={self.trust_level!r}, public_key={self.public_key[:16]}...)>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert ArtifactSignature to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "artifact_uuid": self.artifact_uuid,
            "public_key": self.public_key,
            "signature": self.signature,
            "trust_level": self.trust_level,
            "signer_id": self.signer_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


# =============================================================================
# SyncDebounceEntry (dvcs-unified-sync)
# =============================================================================


class SyncDebounceEntry(Base):
    """DB-backed debounce state for sync-driven version capture (dvcs-unified-sync).

    One row tracks the pending change detection state for a single
    ``(artifact_id, project_id)`` pair.  The background poller queries rows
    where ``quiet_until <= now()`` and ``status = 'pending'``, re-computes
    the content hash, and either captures a new ``ArtifactVersion`` or
    restarts the quiet window if the content is still changing.

    Design rationale (SPIKE-2026-03-31-UNIFIED-SYNC, RQ-1):
        - DB-backed so state survives API restarts and works across multiple
          workers.
        - ``quiet_until`` restart semantics: every re-detected change while
          ``status='pending'`` updates ``detected_hash`` and extends
          ``quiet_until``.
        - ``parent_hash`` is set to the most recently captured version's
          ``content_hash``; used to detect content reversions (revert =
          ``current_hash == parent_hash``, no new version needed).
        - UNIQUE on ``(artifact_id, project_id, status)`` with partial-index
          semantics enforced at the application layer: only one ``pending``
          entry per ``(artifact_id, project_id)`` is maintained.

    Attributes:
        id: UUID hex primary key.
        artifact_id: FK to ``artifacts.id`` (CASCADE DELETE).
        project_id: FK to ``projects.id`` (CASCADE DELETE); NULL for
            collection-level debounce (no project context).
        detected_hash: Content hash when the change was first (or last) seen.
        parent_hash: Content hash of the last captured version for this
            artifact; used to detect reversions.
        detected_at: UTC timestamp when the change was first (or last)
            detected.
        quiet_until: UTC timestamp; background poller ignores rows where
            ``now() < quiet_until``.
        captured_at: UTC timestamp when the ``ArtifactVersion`` was
            created; NULL while ``status != 'captured'``.
        status: One of ``'pending'``, ``'captured'``, ``'skipped'``,
            ``'expired'``, ``'rate_limited'``.
        trigger_source: Attribution for who created this entry: ``'manual'``
            (sync check), ``'on_access'`` (check_drift hook),
            ``'periodic'`` (background scan), ``'fs_watcher'`` (FS daemon).
        created_at: UTC timestamp when this row was first inserted.

    Indexes:
        - idx_debounce_status_quiet_until: Primary poller query
          (``status='pending'`` + ``quiet_until`` ordering).
        - idx_debounce_artifact_status: Lookup pending entry for a given
          artifact (upsert path).
        - idx_debounce_project_id: Lookup all entries for a project.
    """

    __tablename__ = "sync_debounce_entries"

    # Primary key
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=lambda: uuid.uuid4().hex,
        comment="UUID hex primary key",
    )

    # Artifact reference (required)
    artifact_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("artifacts.id", ondelete="CASCADE"),
        nullable=False,
        comment="FK to artifacts.id — the artifact being debounced",
    )

    # Optional project scope
    project_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=True,
        comment="FK to projects.id — NULL for collection-level debounce",
    )

    # Change detection hashes
    detected_hash: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Content hash when change was first or last detected",
    )
    parent_hash: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Content hash of last captured version; used to detect reversions",
    )

    # Timing
    detected_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        comment="UTC timestamp when change was first (or last) detected",
    )
    quiet_until: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        comment="UTC timestamp; poller skips rows where now() < quiet_until",
    )
    captured_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        comment="UTC timestamp when ArtifactVersion was created; NULL while pending",
    )

    # State machine
    status: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default="pending",
        server_default="pending",
        comment="One of: pending, captured, skipped, expired, rate_limited",
    )
    trigger_source: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default="manual",
        server_default="manual",
        comment="One of: manual, on_access, periodic, fs_watcher",
    )

    # Created timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        comment="UTC timestamp when this debounce entry was first inserted",
    )

    # Relationships
    artifact: Mapped["Artifact"] = relationship(
        "Artifact",
        foreign_keys=[artifact_id],
        lazy="select",
    )
    project: Mapped[Optional["Project"]] = relationship(
        "Project",
        foreign_keys=[project_id],
        lazy="select",
    )

    # Table constraints and indexes
    __table_args__ = (
        CheckConstraint(
            "status IN ('pending', 'captured', 'skipped', 'expired', 'rate_limited')",
            name="ck_sync_debounce_entries_status",
        ),
        CheckConstraint(
            "trigger_source IN ('manual', 'on_access', 'periodic', 'fs_watcher')",
            name="ck_sync_debounce_entries_trigger_source",
        ),
        # Primary poller query: find expired pending entries
        Index("idx_debounce_status_quiet_until", "status", "quiet_until"),
        # Upsert / exists check: find pending entry for a given artifact
        Index("idx_debounce_artifact_status", "artifact_id", "status"),
        # Project-scoped lookups
        Index("idx_debounce_project_id", "project_id"),
    )

    def __repr__(self) -> str:
        """Return string representation of SyncDebounceEntry."""
        return (
            f"<SyncDebounceEntry(id={self.id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"status={self.status!r}, "
            f"quiet_until={self.quiet_until!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert SyncDebounceEntry to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "artifact_id": self.artifact_id,
            "project_id": self.project_id,
            "detected_hash": self.detected_hash,
            "parent_hash": self.parent_hash,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
            "quiet_until": self.quiet_until.isoformat() if self.quiet_until else None,
            "captured_at": self.captured_at.isoformat() if self.captured_at else None,
            "status": self.status,
            "trigger_source": self.trigger_source,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# =============================================================================
# SyncCaptureConfig (dvcs-unified-sync SYNC-5.2)
# =============================================================================


class SyncCaptureConfig(Base):
    """Per-scope configuration overrides for the sync-capture subsystem.

    Supports a three-level hierarchy: global < tier < project.  The most
    specific scope that has a row wins when :meth:`effective_config` resolves
    settings for a given context.

    Attributes:
        id: Integer surrogate primary key.
        scope: Scope level — one of ``'global'``, ``'tier'``, or
            ``'project'``.  The ``'global'`` row has ``scope_id=None`` and
            acts as the fallback when no more-specific override exists.
        scope_id: Discriminator value within the scope.  For ``'tier'``
            scopes this is the tier name (e.g. ``'enterprise'``); for
            ``'project'`` scopes this is the project ID string.  Must be
            ``None`` for the ``'global'`` scope.
        quiet_window_seconds: Number of seconds in the debounce quiet window
            before a pending entry is eligible for capture.  Defaults to 30.
        auto_scan_enabled: When ``False``, the background scanner is
            disabled for this scope.  Defaults to ``True``.
        sync_capture_enabled: Master switch for sync capture within this
            scope.  Defaults to ``True``.
        max_captures_per_hour: Rate-limit cap on how many version captures
            may be triggered per hour for artifacts within this scope.
            Defaults to 10.
        created_at: UTC timestamp of row insertion.
        updated_at: UTC timestamp of most recent update.

    Unique Constraint:
        ``(scope, scope_id)`` — only one config row per scope/scope_id pair.

    Example::

        # Global fallback
        SyncCaptureConfig(scope="global", scope_id=None, quiet_window_seconds=30)

        # Enterprise tier: longer quiet window
        SyncCaptureConfig(scope="tier", scope_id="enterprise",
                          quiet_window_seconds=120)

        # Specific project: disabled
        SyncCaptureConfig(scope="project", scope_id="proj-abc",
                          sync_capture_enabled=False)
    """

    __tablename__ = "sync_capture_config"

    id: int = Column(
        Integer,
        primary_key=True,
        autoincrement=True,
        comment="Surrogate integer primary key",
    )
    scope: str = Column(
        String(),
        nullable=False,
        comment="Scope level: global | tier | project",
    )
    scope_id: Optional[str] = Column(
        String(),
        nullable=True,
        comment=(
            "Discriminator within scope: tier name or project ID. "
            "NULL for global scope."
        ),
    )
    quiet_window_seconds: int = Column(
        Integer,
        nullable=False,
        default=30,
        server_default="30",
        comment="Debounce quiet-window duration in seconds",
    )
    auto_scan_enabled: bool = Column(
        Boolean,
        nullable=False,
        default=True,
        server_default="1",
        comment="Whether background auto-scan is active for this scope",
    )
    sync_capture_enabled: bool = Column(
        Boolean,
        nullable=False,
        default=True,
        server_default="1",
        comment="Master switch for sync capture within this scope",
    )
    max_captures_per_hour: int = Column(
        Integer,
        nullable=False,
        default=10,
        server_default="10",
        comment="Max version captures permitted per hour within this scope",
    )
    created_at: datetime = Column(
        DateTime(),
        nullable=False,
        default=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="UTC timestamp when this config row was inserted",
    )
    updated_at: datetime = Column(
        DateTime(),
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        server_default=text("CURRENT_TIMESTAMP"),
        comment="UTC timestamp of the most recent update",
    )

    __table_args__ = (
        UniqueConstraint("scope", "scope_id", name="uq_sync_capture_config_scope"),
        CheckConstraint(
            "scope IN ('global', 'tier', 'project')",
            name="ck_sync_capture_config_scope",
        ),
        CheckConstraint(
            "(scope = 'global' AND scope_id IS NULL) "
            "OR (scope != 'global' AND scope_id IS NOT NULL)",
            name="ck_sync_capture_config_scope_id_null",
        ),
    )

    def __repr__(self) -> str:
        """Return string representation of SyncCaptureConfig."""
        return (
            f"<SyncCaptureConfig(id={self.id!r}, "
            f"scope={self.scope!r}, "
            f"scope_id={self.scope_id!r}, "
            f"sync_capture_enabled={self.sync_capture_enabled!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert SyncCaptureConfig to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "scope": self.scope,
            "scope_id": self.scope_id,
            "quiet_window_seconds": self.quiet_window_seconds,
            "auto_scan_enabled": self.auto_scan_enabled,
            "sync_capture_enabled": self.sync_capture_enabled,
            "max_captures_per_hour": self.max_captures_per_hour,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class GitCredential(Base):
    """Scoped credential record for authenticated Git operations (GCD-2.3).

    Stores an encrypted token that can be attached to a ``GitRepoConnection``
    or used independently for a given org, team, or developer scope.  The
    ``scope_type``/``scope_id`` pair identifies who the credential belongs to;
    ``connection_id`` optionally pins it to a specific connection (cascade-delete).

    Attributes:
        id:               UUID string PK.
        scope_type:       Owner scope: ``'org'``, ``'team'``, or ``'developer'``.
        scope_id:         Identifier of the scope owner (org slug, team id, or user id).
        connection_id:    Optional FK to ``git_repo_connections.id`` (cascade-delete).
        token_encrypted:  Encrypted personal access token or app-installation token.
        credential_type:  Token kind: ``'pat'`` (default) or ``'app_installation'``.
        created_by:       Optional identifier of the user who created the credential.
        created_at:       UTC creation timestamp.
        connection:       Back-reference to the optional parent ``GitRepoConnection``.

    Indexes:
        idx_git_credentials_scope  (scope_type, scope_id)
        idx_git_credentials_conn   (connection_id)
    """

    __tablename__ = "git_credentials"

    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
        comment="Globally unique credential identifier (UUID string)",
    )
    scope_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Owner scope: 'org', 'team', or 'developer'",
    )
    scope_id: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Identifier of the scope owner (org slug, team id, or user id as string)",
    )
    connection_id: Mapped[Optional[int]] = mapped_column(
        Integer,
        ForeignKey(
            "git_repo_connections.id",
            ondelete="CASCADE",
            name="fk_git_credentials_connection_id",
        ),
        nullable=True,
        comment="Optional FK to git_repo_connections.id; row deleted when connection is deleted",
    )
    token_encrypted: Mapped[str] = mapped_column(
        EncryptedString(),
        nullable=False,
        comment="Encrypted credential token (PAT or app-installation token)",
    )
    credential_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default="pat",
        server_default="pat",
        comment="Token kind: 'pat' or 'app_installation'",
    )
    created_by: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Optional identifier of the user who created this credential",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        comment="UTC creation timestamp",
    )

    # Relationships
    connection: Mapped[Optional["GitRepoConnection"]] = relationship(
        "GitRepoConnection",
        foreign_keys=[connection_id],
        lazy="select",
    )

    __table_args__ = (
        Index("idx_git_credentials_scope", "scope_type", "scope_id"),
        Index("idx_git_credentials_conn", "connection_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<GitCredential(id={self.id!r}, "
            f"scope_type={self.scope_type!r}, "
            f"scope_id={self.scope_id!r}, "
            f"credential_type={self.credential_type!r})>"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "scope_type": self.scope_type,
            "scope_id": self.scope_id,
            "connection_id": self.connection_id,
            "credential_type": self.credential_type,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
