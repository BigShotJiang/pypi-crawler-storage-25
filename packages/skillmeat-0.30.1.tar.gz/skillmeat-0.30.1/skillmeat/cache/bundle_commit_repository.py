"""BundleCommitRepository: session-injected CRUD for BundleCommit snapshots (DVCS-2.2).

This repository manages atomic composite versioning records:

- ``BundleCommit`` rows represent complete, validated snapshots of all child
  artifacts within a composite at a point in time.
- ``BundleCommitMember`` rows are the per-member payload records belonging to
  each commit.

Design notes
------------
- Uses SQLAlchemy 1.x ``session.query()`` style — do NOT convert to 2.x
  ``select()`` style.  The 2.x style is reserved for enterprise (PostgreSQL)
  repositories.
- The caller supplies an active ``Session`` via constructor injection and
  controls the transaction lifecycle (commit / rollback / close).
- ``create_with_members`` sets ``SERIALIZABLE`` isolation for the
  sequence-number allocation + insert, preventing concurrent writes from
  producing duplicate sequence numbers.
- ``bundle_hash`` enables idempotency detection: callers should call
  ``find_by_hash`` before ``create_with_members`` to skip duplicate commits.

References
----------
- SPIKE: ``docs/dev/architecture/spikes/dvcs-atomic-versioning/``
- Models: ``skillmeat/cache/models.py`` — ``BundleCommit``, ``BundleCommitMember``
- Hash utility: ``skillmeat/core/cas/hash_utils.py``
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from skillmeat.cache.models import BundleCommit, BundleCommitMember
from skillmeat.cache.repositories import ConstraintError, RepositoryError

logger = logging.getLogger(__name__)


class BundleCommitRepository:
    """Repository for BundleCommit CRUD operations.

    All public methods operate on the injected ``session``.  The caller is
    responsible for committing or rolling back transactions and for closing
    the session when done.

    Uses SQLAlchemy 1.x ``session.query()`` style throughout.  Do not use
    with the enterprise (PostgreSQL) session — that layer uses the 2.x
    ``select()`` style.

    Args:
        session: Active SQLAlchemy ORM session (local / SQLite backend).

    Example::

        from sqlalchemy.orm import Session
        repo = BundleCommitRepository(session)

        commit = repo.create_with_members(
            commit_data={
                "composite_artifact_id": "abc123...",
                "composite_type": "plugin",
                "bundle_hash": "deadbeef...",
                "parent_id": None,
                "change_origin": "manual",
                "message": "Initial snapshot",
            },
            members=[
                {
                    "artifact_id": "my-skill",
                    "artifact_uuid": "uuid1...",
                    "artifact_version_id": "ver1...",
                    "content_hash": "hash1...",
                }
            ],
        )
    """

    def __init__(self, session: Session) -> None:
        """Initialise the repository with an injected session.

        Args:
            session: An active SQLAlchemy session.  The caller controls the
                transaction lifecycle (commit / rollback / close).
        """
        self.session = session

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def create_with_members(
        self,
        commit_data: Dict[str, Any],
        members: List[Dict[str, Any]],
    ) -> BundleCommit:
        """Create a BundleCommit with its member rows in a single transaction.

        The operation runs at ``SERIALIZABLE`` isolation level to prevent
        concurrent writers from producing duplicate sequence numbers for the
        same composite artifact.

        ``commit_data`` must contain:

        - ``composite_artifact_id`` (str): FK to ``artifacts.uuid``.
        - ``composite_type`` (str): Artifact type label (e.g. ``"plugin"``).
        - ``bundle_hash`` (str): Pre-computed SHA-256 from
          :func:`skillmeat.core.cas.hash_utils.compute_bundle_hash`.
        - ``change_origin`` (str): One of ``manual``, ``sync``, ``deploy``,
          ``capture``, ``rollback``.

        Optional keys in ``commit_data``:

        - ``id`` (str): Override the auto-generated UUIDv4 hex.
        - ``parent_id`` (str | None): FK to prior commit; ``None`` for first.
        - ``message`` (str | None): Human-readable commit message.
        - ``created_by`` (str | None): Actor identifier.
        - ``is_rollback`` (int): ``1`` when this is a rollback commit.
        - ``rolled_back_to`` (str | None): Target commit FK for rollbacks.

        Each entry in ``members`` must contain:

        - ``artifact_id`` (str): Human-readable artifact identifier.
        - ``artifact_uuid`` (str): Stable UUID FK to ``artifacts.uuid``.
        - ``artifact_version_id`` (str): FK to ``artifact_versions.id``.
        - ``content_hash`` (str): Snapshot of content hash at commit time.

        Args:
            commit_data: Dict of BundleCommit field values.
            members: List of member field-value dicts.

        Returns:
            The newly created :class:`~skillmeat.cache.models.BundleCommit`
            instance with ``members`` eagerly loaded.

        Raises:
            ConstraintError: When a unique constraint is violated (e.g.
                ``(composite_artifact_id, sequence_number)`` collision).
            RepositoryError: On any other database error.
        """
        try:
            # Escalate isolation level for atomic sequence-number allocation.
            self.session.connection().execution_options(isolation_level="SERIALIZABLE")

            sequence_number = self.get_next_sequence_number(
                commit_data["composite_artifact_id"]
            )

            commit = BundleCommit(
                id=commit_data.get("id") or uuid.uuid4().hex,
                composite_artifact_id=commit_data["composite_artifact_id"],
                composite_type=commit_data["composite_type"],
                bundle_hash=commit_data["bundle_hash"],
                parent_id=commit_data.get("parent_id"),
                sequence_number=sequence_number,
                change_origin=commit_data["change_origin"],
                created_at=commit_data.get("created_at", datetime.utcnow()),
                created_by=commit_data.get("created_by"),
                message=commit_data.get("message"),
                is_rollback=commit_data.get("is_rollback", 0),
                rolled_back_to=commit_data.get("rolled_back_to"),
            )
            self.session.add(commit)

            for member_data in members:
                member = BundleCommitMember(
                    bundle_commit_id=commit.id,
                    artifact_id=member_data["artifact_id"],
                    artifact_uuid=member_data["artifact_uuid"],
                    artifact_version_id=member_data["artifact_version_id"],
                    content_hash=member_data["content_hash"],
                )
                self.session.add(member)

            self.session.flush()
            # Re-query with members eagerly loaded to return a fully
            # populated instance without relying on lazy-load after flush.
            self.session.refresh(commit)
            result = (
                self.session.query(BundleCommit)
                .options(joinedload(BundleCommit.members))
                .filter(BundleCommit.id == commit.id)
                .one()
            )
            logger.info(
                "BundleCommitRepository.create_with_members: "
                "commit_id=%s composite=%s sequence=%d members=%d",
                commit.id,
                commit.composite_artifact_id,
                sequence_number,
                len(members),
            )
            return result

        except IntegrityError as exc:
            self.session.rollback()
            raise ConstraintError(
                f"Failed to create BundleCommit (constraint violation): {exc}"
            ) from exc
        except Exception as exc:
            self.session.rollback()
            raise RepositoryError(f"Failed to create BundleCommit: {exc}") from exc

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def get_by_id(self, commit_id: str) -> Optional[BundleCommit]:
        """Get a single commit with members eagerly loaded.

        Args:
            commit_id: UUID hex primary key of the commit.

        Returns:
            :class:`~skillmeat.cache.models.BundleCommit` with ``members``
            populated, or ``None`` if no matching row exists.
        """
        return (
            self.session.query(BundleCommit)
            .options(joinedload(BundleCommit.members))
            .filter(BundleCommit.id == commit_id)
            .first()
        )

    def get_history(
        self,
        composite_artifact_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> List[BundleCommit]:
        """Get commit history for a composite, ordered by sequence_number DESC.

        Returns commits from newest to oldest, making the first element the
        most recent state of the composite artifact.  Use ``offset`` together
        with ``limit`` for cursor-style pagination.

        Args:
            composite_artifact_id: FK to ``artifacts.uuid`` identifying the
                composite whose history is requested.
            limit: Maximum number of commits to return.  Defaults to ``50``.
            offset: Number of commits to skip before returning results.
                Defaults to ``0``.

        Returns:
            Ordered list of :class:`~skillmeat.cache.models.BundleCommit`
            instances (newest first) with ``members`` eagerly loaded.
        """
        return (
            self.session.query(BundleCommit)
            .options(joinedload(BundleCommit.members))
            .filter(BundleCommit.composite_artifact_id == composite_artifact_id)
            .order_by(BundleCommit.sequence_number.desc())
            .limit(limit)
            .offset(offset)
            .all()
        )

    def find_by_hash(
        self,
        composite_artifact_id: str,
        bundle_hash: str,
    ) -> Optional[BundleCommit]:
        """Find a commit by bundle_hash for idempotency detection.

        Callers should invoke this method before ``create_with_members`` to
        detect duplicate commits — i.e. when the composite's member set has
        not changed since the last commit.

        Args:
            composite_artifact_id: FK to ``artifacts.uuid``.
            bundle_hash: Deterministic SHA-256 from
                :func:`skillmeat.core.cas.hash_utils.compute_bundle_hash`.

        Returns:
            The existing :class:`~skillmeat.cache.models.BundleCommit` if one
            with a matching hash already exists, otherwise ``None``.
        """
        return (
            self.session.query(BundleCommit)
            .filter(
                BundleCommit.composite_artifact_id == composite_artifact_id,
                BundleCommit.bundle_hash == bundle_hash,
            )
            .first()
        )

    def get_latest(self, composite_artifact_id: str) -> Optional[BundleCommit]:
        """Get the most recent commit for a composite (highest sequence_number).

        Args:
            composite_artifact_id: FK to ``artifacts.uuid``.

        Returns:
            The :class:`~skillmeat.cache.models.BundleCommit` with the
            highest ``sequence_number`` for this composite, with ``members``
            eagerly loaded, or ``None`` if no commits exist.
        """
        return (
            self.session.query(BundleCommit)
            .options(joinedload(BundleCommit.members))
            .filter(BundleCommit.composite_artifact_id == composite_artifact_id)
            .order_by(BundleCommit.sequence_number.desc())
            .first()
        )

    def get_next_sequence_number(self, composite_artifact_id: str) -> int:
        """Get the next sequence number for a composite artifact.

        Returns ``max(sequence_number) + 1`` for the given composite, or ``1``
        if no commits exist yet.

        This method is called inside ``create_with_members`` under
        ``SERIALIZABLE`` isolation to prevent concurrent writers from
        allocating the same sequence number.  It can also be called directly
        to preview the next value without writing.

        Args:
            composite_artifact_id: FK to ``artifacts.uuid``.

        Returns:
            Next integer sequence number (1-based, monotonically increasing).
        """
        from sqlalchemy import func

        result = (
            self.session.query(func.max(BundleCommit.sequence_number))
            .filter(BundleCommit.composite_artifact_id == composite_artifact_id)
            .scalar()
        )
        return (result or 0) + 1

    def count_history(self, composite_artifact_id: str) -> int:
        """Count total commits for a composite (for pagination).

        Args:
            composite_artifact_id: FK to ``artifacts.uuid``.

        Returns:
            Total number of commits recorded for this composite.
        """
        return (
            self.session.query(BundleCommit)
            .filter(BundleCommit.composite_artifact_id == composite_artifact_id)
            .count()
        )
