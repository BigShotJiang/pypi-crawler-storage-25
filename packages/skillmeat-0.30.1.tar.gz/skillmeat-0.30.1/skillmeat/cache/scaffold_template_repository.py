"""Repository for ScaffoldTemplate entities.

Follows the BaseRepository pattern established in repositories.py and
workflow_repository.py:
- Session-per-operation: open session, close in finally block
- IntegrityError → ConstraintError, generic exceptions → RepositoryError
- session.query() style (SQLAlchemy 1.x) — NOT select() (2.x)
- db_path accepted in __init__ for test isolation

The ``ScaffoldTemplate`` model has a 1-to-1 relationship with ``BundleEntity``
enforced by a UNIQUE constraint on ``bundle_id``.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from skillmeat.cache.models import ScaffoldTemplate, create_db_engine, create_tables
from skillmeat.cache.repositories import (
    ConstraintError,
    NotFoundError,
    RepositoryError,
)

logger = logging.getLogger(__name__)


class ScaffoldTemplateRepository:
    """Data-access layer for ScaffoldTemplate CRUD operations.

    All public methods accept a SQLAlchemy ``Session`` object as their first
    parameter, following the session-per-operation convention used in the local
    repository layer.  Each method opens a fresh session internally (via
    ``_get_session()``), performs the operation, and closes the session in a
    ``finally`` block.

    Attributes:
        db_path: Resolved path to the SQLite database file.
        engine: SQLAlchemy engine created for ``db_path``.

    Example:
        >>> repo = ScaffoldTemplateRepository()
        >>> template = repo.create(session, {
        ...     "bundle_id": "abc123",
        ...     "enabled": True,
        ...     "backstage_type": "service",
        ... })
        >>> fetched = repo.get(session, template.id)
        >>> repo.delete(session, template.id)
    """

    def __init__(self, db_path: Optional[str | Path] = None) -> None:
        """Initialise the repository with a database path.

        Args:
            db_path: Optional path to the SQLite database file.  Defaults to
                ``~/.skillmeat/cache/cache.db`` when omitted.
        """
        if db_path is None:
            self.db_path = Path.home() / ".skillmeat" / "cache" / "cache.db"
        else:
            self.db_path = Path(db_path)

        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_db_engine(self.db_path)

        from sqlalchemy.orm import sessionmaker as _sessionmaker

        self._session_factory = _sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine,
        )

        create_tables(self.db_path)

        logger.debug(
            "Initialised ScaffoldTemplateRepository with database: %s", self.db_path
        )

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _get_session(self) -> Session:
        """Return a new session bound to this repository's engine.

        The caller is responsible for closing the session.

        Returns:
            A fresh ``Session`` bound to this repository's engine.
        """
        return self._session_factory()

    # -------------------------------------------------------------------------
    # CRUD
    # -------------------------------------------------------------------------

    def create(self, session: Session, data: Dict[str, Any]) -> ScaffoldTemplate:
        """Persist a new ScaffoldTemplate record.

        A new UUID hex ``id`` is generated when ``data`` does not supply one.
        ``created_at`` and ``updated_at`` are set to the current UTC time when
        absent from ``data``.

        Args:
            session: SQLAlchemy session (opened by the caller or internally).
                When this method opens its own session internally the caller's
                ``session`` argument is **ignored** — the canonical usage is to
                call this method without holding a separate session and let the
                repository manage the lifecycle.

                .. note::
                    The method signature accepts ``session`` to match the
                    interface contract specified by the task, but internally
                    opens a fresh session per the local-repository convention.
                    Future refactoring may unify these approaches.
            data: Dictionary of field values to set on the new record.
                Required: ``bundle_id``.
                Optional fields mirror ``ScaffoldTemplate`` column names.

        Returns:
            The newly created and refreshed ``ScaffoldTemplate`` ORM instance.

        Raises:
            ConstraintError: When a unique constraint is violated (e.g. a
                ``ScaffoldTemplate`` already exists for ``bundle_id``).
            RepositoryError: On any other database error.

        Example:
            >>> template = repo.create(session, {
            ...     "bundle_id": "bundle-abc",
            ...     "enabled": True,
            ...     "backstage_type": "website",
            ...     "required_variables": ["appName", "owner"],
            ... })
        """
        now = datetime.utcnow()
        template = ScaffoldTemplate(
            id=data.get("id") or uuid.uuid4().hex,
            bundle_id=data["bundle_id"],
            enabled=data.get("enabled", True),
            required_variables=data.get("required_variables"),
            variable_type_map=data.get("variable_type_map"),
            skeleton_ref=data.get("skeleton_ref"),
            backstage_owner=data.get("backstage_owner"),
            backstage_type=data.get("backstage_type", "service"),
            backstage_tags=data.get("backstage_tags"),
            bundle_version_at_last_generation=data.get(
                "bundle_version_at_last_generation"
            ),
            generation_history=data.get("generation_history"),
            created_at=data.get("created_at", now),
            updated_at=data.get("updated_at", now),
        )

        internal_session = self._get_session()
        try:
            internal_session.add(template)
            internal_session.commit()
            internal_session.refresh(template)
            logger.info(
                "Created ScaffoldTemplate id=%s bundle_id=%s enabled=%s",
                template.id,
                template.bundle_id,
                template.enabled,
            )
            return template
        except IntegrityError as exc:
            internal_session.rollback()
            raise ConstraintError(
                f"Failed to create ScaffoldTemplate (constraint violation): {exc}"
            ) from exc
        except Exception as exc:
            internal_session.rollback()
            raise RepositoryError(f"Failed to create ScaffoldTemplate: {exc}") from exc
        finally:
            internal_session.close()

    def get(self, session: Session, id: str) -> Optional[ScaffoldTemplate]:
        """Retrieve a ScaffoldTemplate by primary key.

        Args:
            session: SQLAlchemy session (used for interface consistency; the
                method opens its own internal session per the local-repo
                convention).
            id: UUID hex primary key of the scaffold template.

        Returns:
            ``ScaffoldTemplate`` ORM instance, or ``None`` if not found.

        Example:
            >>> template = repo.get(session, "abc123def456...")
        """
        internal_session = self._get_session()
        try:
            return (
                internal_session.query(ScaffoldTemplate)
                .options(joinedload(ScaffoldTemplate.bundle))
                .filter(ScaffoldTemplate.id == id)
                .first()
            )
        finally:
            internal_session.close()

    def update(
        self, session: Session, id: str, data: Dict[str, Any]
    ) -> Optional[ScaffoldTemplate]:
        """Update mutable fields on an existing ScaffoldTemplate.

        Only fields present in ``data`` are updated; absent keys leave the
        corresponding columns unchanged.  ``updated_at`` is always refreshed
        to the current UTC time.

        Args:
            session: SQLAlchemy session (interface parameter; method opens its
                own session internally).
            id: UUID hex primary key of the scaffold template to update.
            data: Dictionary of fields to update.  ``id`` and ``bundle_id``
                keys are silently ignored (immutable after creation).

        Returns:
            The updated and refreshed ``ScaffoldTemplate`` instance, or
            ``None`` if no record with ``id`` exists.

        Raises:
            ConstraintError: On a unique-constraint violation (rare for
                updates, but possible if ``bundle_id`` is changed externally).
            RepositoryError: On any other database error.

        Example:
            >>> updated = repo.update(session, "abc123", {"enabled": False})
        """
        # Immutable fields that callers must not overwrite
        _IMMUTABLE = {"id", "bundle_id", "created_at"}

        internal_session = self._get_session()
        try:
            template = (
                internal_session.query(ScaffoldTemplate)
                .options(joinedload(ScaffoldTemplate.bundle))
                .filter(ScaffoldTemplate.id == id)
                .first()
            )
            if template is None:
                logger.debug("update: ScaffoldTemplate id=%s not found", id)
                return None

            for field, value in data.items():
                if field in _IMMUTABLE:
                    continue
                if hasattr(template, field):
                    setattr(template, field, value)

            template.updated_at = datetime.utcnow()

            internal_session.commit()
            internal_session.refresh(template)
            logger.info("Updated ScaffoldTemplate id=%s", id)
            return template
        except IntegrityError as exc:
            internal_session.rollback()
            raise ConstraintError(
                f"Failed to update ScaffoldTemplate (constraint violation): {exc}"
            ) from exc
        except Exception as exc:
            internal_session.rollback()
            raise RepositoryError(
                f"Failed to update ScaffoldTemplate {id}: {exc}"
            ) from exc
        finally:
            internal_session.close()

    def delete(self, session: Session, id: str) -> bool:
        """Delete a ScaffoldTemplate by primary key.

        Args:
            session: SQLAlchemy session (interface parameter; method opens its
                own session internally).
            id: UUID hex primary key of the scaffold template to delete.

        Returns:
            ``True`` if a row was deleted, ``False`` if no matching row existed.

        Raises:
            RepositoryError: On any database error.

        Example:
            >>> deleted = repo.delete(session, "abc123")
            >>> print("Gone" if deleted else "Not found")
        """
        internal_session = self._get_session()
        try:
            template = (
                internal_session.query(ScaffoldTemplate)
                .filter(ScaffoldTemplate.id == id)
                .first()
            )
            if template is None:
                logger.debug("delete: ScaffoldTemplate id=%s not found", id)
                return False
            internal_session.delete(template)
            internal_session.commit()
            logger.info("Deleted ScaffoldTemplate id=%s", id)
            return True
        except Exception as exc:
            internal_session.rollback()
            raise RepositoryError(
                f"Failed to delete ScaffoldTemplate {id}: {exc}"
            ) from exc
        finally:
            internal_session.close()

    def list(
        self, session: Session, enabled_only: bool = False
    ) -> List[ScaffoldTemplate]:
        """Return all ScaffoldTemplate records, optionally filtered to enabled ones.

        Results are ordered by ``created_at`` ascending so that the earliest
        templates appear first.

        Args:
            session: SQLAlchemy session (interface parameter; method opens its
                own session internally).
            enabled_only: When ``True``, only rows where ``enabled=True`` are
                returned.  Defaults to ``False`` (return all records).

        Returns:
            List of ``ScaffoldTemplate`` ORM instances.  Empty list when no
            records match the filter.

        Example:
            >>> all_templates = repo.list(session)
            >>> active_only = repo.list(session, enabled_only=True)
        """
        internal_session = self._get_session()
        try:
            q = internal_session.query(ScaffoldTemplate).options(
                joinedload(ScaffoldTemplate.bundle)
            )
            if enabled_only:
                q = q.filter(ScaffoldTemplate.enabled.is_(True))
            return q.order_by(ScaffoldTemplate.created_at.asc()).all()
        finally:
            internal_session.close()

    def get_by_bundle_id(
        self, session: Session, bundle_id: str
    ) -> Optional[ScaffoldTemplate]:
        """Retrieve the ScaffoldTemplate associated with a given BundleEntity.

        Because ``bundle_id`` carries a UNIQUE constraint, at most one row can
        match.

        Args:
            session: SQLAlchemy session (interface parameter; method opens its
                own session internally).
            bundle_id: Primary key of the owning ``BundleEntity``.

        Returns:
            ``ScaffoldTemplate`` ORM instance, or ``None`` if the bundle has no
            associated template.

        Example:
            >>> template = repo.get_by_bundle_id(session, "bundle-abc123")
        """
        internal_session = self._get_session()
        try:
            return (
                internal_session.query(ScaffoldTemplate)
                .options(joinedload(ScaffoldTemplate.bundle))
                .filter(ScaffoldTemplate.bundle_id == bundle_id)
                .first()
            )
        finally:
            internal_session.close()

    def get_enabled(self, session: Session) -> List[ScaffoldTemplate]:
        """Return all ScaffoldTemplate records where ``enabled=True``.

        Convenience shortcut for ``list(session, enabled_only=True)``.

        Args:
            session: SQLAlchemy session (interface parameter; method opens its
                own session internally).

        Returns:
            List of enabled ``ScaffoldTemplate`` ORM instances ordered by
            ``created_at`` ascending.

        Example:
            >>> enabled = repo.get_enabled(session)
        """
        return self.list(session, enabled_only=True)
