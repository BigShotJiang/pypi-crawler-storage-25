"""Repository for ExecutionOutcome telemetry records (TEL-1.1).

Provides batch-insert (with idempotency via ON CONFLICT DO NOTHING) and
query operations for ``execution_outcomes`` rows.  The repository is
session-injected — the caller supplies an active SQLAlchemy ``Session``
(e.g. via FastAPI dependency injection) and manages the transaction
lifecycle.

This module targets the enterprise (PostgreSQL) backend.  All methods use
SQLAlchemy 2.x ``select()`` style consistent with other enterprise
repositories in this package.

Design invariants
-----------------
- ``ExecutionOutcome`` rows are **append-only**.  Status transitions are
  final once written; do not issue UPDATE statements outside the ingestion
  path.
- ``batch_insert`` silently skips rows whose ``execution_id`` already
  exists (``ON CONFLICT DO NOTHING``), returning a ``BatchInsertResult``
  that reports how many were accepted vs. skipped.
- All public query methods return plain dataclasses (``ExecutionOutcomeData``),
  never ORM model instances, so callers are decoupled from the SQLAlchemy
  session.

Usage::

    from skillmeat.cache.execution_outcome_repository import (
        ExecutionOutcomeRepository,
        ExecutionOutcomeCreate,
    )

    repo = ExecutionOutcomeRepository(session)
    result = repo.batch_insert([
        ExecutionOutcomeCreate(
            execution_id="exec-abc",
            project_id="proj-1",
            status="success",
            ...
        )
    ])
    print(result.accepted, result.skipped)
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from skillmeat.cache.models_telemetry import ExecutionOutcome

logger = logging.getLogger(__name__)


# =============================================================================
# Result / DTO types
# =============================================================================


@dataclass
class BatchInsertResult:
    """Summary returned by :meth:`ExecutionOutcomeRepository.batch_insert`.

    Attributes:
        accepted: Number of rows actually written to the database.
        skipped:  Number of rows silently ignored due to a duplicate
                  ``execution_id`` (``ON CONFLICT DO NOTHING``).
        total:    Total number of input records submitted (``accepted + skipped``).
    """

    accepted: int
    skipped: int
    total: int


@dataclass
class ExecutionOutcomeData:
    """Plain-data representation of an ``ExecutionOutcome`` row.

    This dataclass mirrors the columns of the ``execution_outcomes`` table
    but is **not** an ORM instance.  All repository query methods return
    this type so that callers are decoupled from the SQLAlchemy session.

    Attributes:
        id:               UUID primary key of the row.
        execution_id:     Caller-supplied unique execution token.
        project_id:       Project that owns this execution record.
        workflow_id:      Optional workflow identifier (``None`` for ad-hoc runs).
        bundle_id:        Optional bundle identifier (``None`` for non-bundle executions).
        status:           Final execution status (``success`` | ``failure`` |
                          ``partial`` | ``timeout`` | ``error``).
        metrics:          Arbitrary JSONB metrics payload; may be ``None``.
        started_at:       Timezone-aware wall-clock start time; may be ``None``.
        completed_at:     Timezone-aware wall-clock end time; may be ``None``.
        duration_seconds: Wall-clock duration in seconds; may be ``None``.
        cost_usd:         Estimated monetary cost in USD; may be ``None``.
        client_version:   Agent/CLI client version string; may be ``None``.
        created_at:       Timezone-aware row creation timestamp.
        updated_at:       Timezone-aware last-modified timestamp.
    """

    id: uuid.UUID
    execution_id: str
    project_id: str
    status: str
    created_at: datetime
    updated_at: datetime
    workflow_id: Optional[str] = None
    bundle_id: Optional[str] = None
    metrics: Optional[Dict[str, Any]] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    cost_usd: Optional[float] = None
    client_version: Optional[str] = None


@dataclass
class ExecutionOutcomeCreate:
    """Input record for :meth:`ExecutionOutcomeRepository.batch_insert`.

    Contains only the fields that the caller must or may supply when
    creating a new ``ExecutionOutcome`` row.  Server-generated fields
    (``id``, ``created_at``, ``updated_at``) are omitted — the database
    populates them via server defaults.

    Attributes:
        execution_id:     **Required.** Caller-supplied unique token; enforces
                          ingestion idempotency via the unique constraint.
        project_id:       **Required.** Project that triggered this execution.
        status:           **Required.** Final execution status from the
                          vocabulary: ``success`` | ``failure`` | ``partial``
                          | ``timeout`` | ``error``.
        workflow_id:      Optional workflow identifier.
        bundle_id:        Optional bundle identifier.
        metrics:          Optional JSONB payload for execution-specific metrics.
        started_at:       Optional timezone-aware wall-clock start time.
        completed_at:     Optional timezone-aware wall-clock end time.
        duration_seconds: Optional wall-clock duration in seconds.
        cost_usd:         Optional estimated monetary cost in USD.
        client_version:   Optional agent/CLI client version string.
    """

    execution_id: str
    project_id: str
    status: str
    workflow_id: Optional[str] = None
    bundle_id: Optional[str] = None
    metrics: Optional[Dict[str, Any]] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    cost_usd: Optional[float] = None
    client_version: Optional[str] = None


# =============================================================================
# Repository
# =============================================================================


class ExecutionOutcomeRepository:
    """Data-access layer for :class:`~skillmeat.cache.models_telemetry.ExecutionOutcome`.

    All methods operate on the injected ``session``; the caller is
    responsible for committing or rolling back transactions and for closing
    the session when done.

    This repository targets the **enterprise (PostgreSQL)** backend and uses
    SQLAlchemy 2.x ``select()`` style throughout.  Do not use it with the
    local SQLite session.

    Args:
        session: Active SQLAlchemy ORM session bound to a PostgreSQL engine.

    Example::

        repo = ExecutionOutcomeRepository(session)

        result = repo.batch_insert([
            ExecutionOutcomeCreate(
                execution_id="exec-001",
                project_id="proj-abc",
                status="success",
                duration_seconds=4.2,
                cost_usd=0.003,
            )
        ])
        print(f"Accepted: {result.accepted}, Skipped: {result.skipped}")

        outcomes = repo.get_by_project(
            project_id="proj-abc",
            period_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
            period_end=datetime(2026, 2, 1, tzinfo=timezone.utc),
        )
    """

    def __init__(self, session: Session) -> None:
        """Initialise the repository with an injected session.

        Args:
            session: An active SQLAlchemy session.  Lifecycle
                (commit / rollback / close) is managed by the caller.
        """
        self.session = session

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def batch_insert(self, records: List[ExecutionOutcomeCreate]) -> BatchInsertResult:
        """Insert multiple ``ExecutionOutcome`` rows, skipping duplicates.

        Uses a PostgreSQL ``INSERT ... ON CONFLICT (execution_id) DO NOTHING``
        statement so that re-submitted execution IDs are silently ignored
        rather than raising an error.  This makes the ingestion path fully
        idempotent.

        The method flushes within the caller's transaction but does **not**
        commit — the caller controls the transaction boundary.

        Args:
            records: List of :class:`ExecutionOutcomeCreate` instances
                describing the rows to insert.  An empty list is a no-op.

        Returns:
            :class:`BatchInsertResult` with ``accepted``, ``skipped``, and
            ``total`` counts.

        Raises:
            sqlalchemy.exc.SQLAlchemyError: On unexpected database errors
                (not including expected conflict skips).
        """
        total = len(records)
        if total == 0:
            return BatchInsertResult(accepted=0, skipped=0, total=0)

        from dataclasses import asdict

        values = [asdict(record) for record in records]
        stmt = (
            pg_insert(ExecutionOutcome)
            .values(values)
            .on_conflict_do_nothing(index_elements=["execution_id"])
        )
        result = self.session.execute(stmt)
        self.session.flush()

        accepted = result.rowcount  # type: ignore[union-attr]
        skipped = total - accepted
        logger.debug(
            "batch_insert: total=%d accepted=%d skipped=%d", total, accepted, skipped
        )
        return BatchInsertResult(accepted=accepted, skipped=skipped, total=total)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_by_project(
        self,
        project_id: str,
        period_start: datetime,
        period_end: datetime,
    ) -> List[ExecutionOutcomeData]:
        """Return all execution outcomes for a project within a time window.

        Filters on ``started_at >= period_start`` and
        ``started_at < period_end`` (half-open interval, consistent with
        the ``ProjectAgenticMetrics`` aggregation convention).

        Results are ordered ``started_at ASC`` so that callers can iterate
        chronologically without additional sorting.

        Args:
            project_id:    Project to query.
            period_start:  Inclusive lower bound on ``started_at``
                           (timezone-aware datetime).
            period_end:    Exclusive upper bound on ``started_at``
                           (timezone-aware datetime).

        Returns:
            List of :class:`ExecutionOutcomeData` instances, possibly empty.
        """
        stmt = (
            select(ExecutionOutcome)
            .where(
                ExecutionOutcome.project_id == project_id,
                ExecutionOutcome.started_at >= period_start,
                ExecutionOutcome.started_at < period_end,
            )
            .order_by(ExecutionOutcome.started_at.asc())
        )
        rows = self.session.execute(stmt).scalars().all()
        return [self._to_data(row) for row in rows]

    def get_by_execution_id(self, execution_id: str) -> Optional[ExecutionOutcomeData]:
        """Return a single execution outcome by its caller-supplied token.

        ``execution_id`` has a unique constraint on the table, so at most
        one row is returned.

        Args:
            execution_id: The caller-supplied unique execution token
                (``ExecutionOutcome.execution_id``).

        Returns:
            :class:`ExecutionOutcomeData` if a matching row exists,
            ``None`` otherwise.
        """
        stmt = select(ExecutionOutcome).where(
            ExecutionOutcome.execution_id == execution_id
        )
        row = self.session.execute(stmt).scalars().first()
        if row is None:
            return None
        return self._to_data(row)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _to_data(self, row: ExecutionOutcome) -> ExecutionOutcomeData:
        """Convert an ORM ``ExecutionOutcome`` instance to a plain dataclass.

        Args:
            row: An ORM-mapped ``ExecutionOutcome`` instance.

        Returns:
            :class:`ExecutionOutcomeData` with all fields copied from the row.
        """
        return ExecutionOutcomeData(
            id=row.id,
            execution_id=row.execution_id,
            project_id=row.project_id,
            workflow_id=row.workflow_id,
            bundle_id=row.bundle_id,
            status=row.status,
            metrics=row.metrics,
            started_at=row.started_at,
            completed_at=row.completed_at,
            duration_seconds=row.duration_seconds,
            cost_usd=row.cost_usd,
            client_version=row.client_version,
            created_at=row.created_at,
            updated_at=row.updated_at,
        )
