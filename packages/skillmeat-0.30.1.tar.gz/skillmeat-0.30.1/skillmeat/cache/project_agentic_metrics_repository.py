"""Repository for ProjectAgenticMetrics persistence (TEL-1.2).

Provides upsert and query operations for pre-computed agentic effectiveness
rollup rows.  The repository is session-injected — callers supply an active
SQLAlchemy ``Session`` (e.g. via FastAPI dependency injection) rather than
having the repository manage its own connection lifecycle.

This module targets the PostgreSQL enterprise schema (``EnterpriseBase``).
All queries use SQLAlchemy 2.x ``select()`` style to match the enterprise
repository conventions documented in ``skillmeat/cache/CLAUDE.md``.

Usage::

    from sqlalchemy.orm import Session
    from skillmeat.cache.project_agentic_metrics_repository import (
        AgenticMetricsRepository,
        AgenticMetricsUpsert,
    )

    repo = AgenticMetricsRepository(session)

    upsert_data = AgenticMetricsUpsert(
        project_id="proj-abc",
        workflow_id="wf-1",
        bundle_id=None,
        execution_count=42,
        success_rate=0.95,
        avg_duration_seconds=12.3,
        avg_cost_usd=0.004,
        effectiveness_score=0.87,
        period_start=datetime(2026, 3, 1, tzinfo=timezone.utc),
        period_end=datetime(2026, 3, 2, tzinfo=timezone.utc),
    )
    result = repo.upsert_rollup(upsert_data)
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Optional

from sqlalchemy import desc, insert, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from skillmeat.cache.models_telemetry import ProjectAgenticMetrics

logger = logging.getLogger(__name__)

# Valid column names accepted by get_global_metrics(sort_by=...).
_SORT_COLUMNS: dict[str, Any] = {
    "effectiveness_score": ProjectAgenticMetrics.effectiveness_score,
    "avg_cost_usd": ProjectAgenticMetrics.avg_cost_usd,
    "execution_count": ProjectAgenticMetrics.execution_count,
    "success_rate": ProjectAgenticMetrics.success_rate,
}

SortByLiteral = Literal[
    "effectiveness_score",
    "avg_cost_usd",
    "execution_count",
    "success_rate",
]


# =============================================================================
# Data-transfer objects
# =============================================================================


@dataclass(frozen=True)
class AgenticMetricsData:
    """Read-only snapshot of a ``ProjectAgenticMetrics`` row.

    All fields mirror the ORM model columns.  Instances are returned from
    repository query methods so callers never hold references to live ORM
    objects after the session is closed.

    Attributes:
        id:                   UUID primary key of the row.
        project_id:           Project whose executions are summarised.
        workflow_id:          Workflow scope; ``None`` = project-wide aggregate.
        bundle_id:            Bundle scope; ``None`` = not bundle-scoped.
        execution_count:      Total executions in the period.
        success_rate:         Fraction of successful executions (0.0–1.0).
        avg_duration_seconds: Mean wall-clock duration across executions.
        avg_cost_usd:         Mean monetary cost across executions.
        effectiveness_score:  Composite effectiveness score (0.0–1.0).
        rollup_computed_at:   When the most-recent rollup computation ran.
        period_start:         Inclusive start of the aggregation window.
        period_end:           Exclusive end of the aggregation window.
        created_at:           Row creation timestamp.
        updated_at:           Last-modified timestamp.
    """

    id: uuid.UUID
    project_id: str
    workflow_id: Optional[str]
    bundle_id: Optional[str]
    execution_count: int
    success_rate: Optional[float]
    avg_duration_seconds: Optional[float]
    avg_cost_usd: Optional[float]
    effectiveness_score: Optional[float]
    rollup_computed_at: Optional[datetime]
    period_start: datetime
    period_end: datetime
    created_at: datetime
    updated_at: datetime


@dataclass(frozen=True)
class AgenticMetricsUpsert:
    """Input payload for :meth:`AgenticMetricsRepository.upsert_rollup`.

    All numeric metric fields are optional so partial rollups can be stored
    without requiring every dimension to be computed at write time.

    Attributes:
        project_id:           Project whose executions are being summarised.
        workflow_id:          Workflow scope; ``None`` = project-wide aggregate.
        bundle_id:            Bundle scope; ``None`` = not bundle-scoped.
        execution_count:      Total executions counted in the period.
        success_rate:         Fraction of successful executions (0.0–1.0).
        avg_duration_seconds: Mean wall-clock duration in seconds.
        avg_cost_usd:         Mean monetary cost in USD.
        effectiveness_score:  Composite effectiveness score (0.0–1.0).
        period_start:         Inclusive start of the aggregation time window.
        period_end:           Exclusive end of the aggregation time window.
    """

    project_id: str
    workflow_id: Optional[str]
    bundle_id: Optional[str]
    execution_count: int
    success_rate: Optional[float]
    avg_duration_seconds: Optional[float]
    avg_cost_usd: Optional[float]
    effectiveness_score: Optional[float]
    period_start: datetime
    period_end: datetime


# =============================================================================
# Repository
# =============================================================================


class AgenticMetricsRepository:
    """Data-access layer for :class:`~skillmeat.cache.models_telemetry.ProjectAgenticMetrics`.

    Provides idempotent upsert and read operations for pre-computed agentic
    effectiveness rollup rows.  The upsert uses PostgreSQL
    ``INSERT ... ON CONFLICT DO UPDATE`` keyed on the unique constraint
    ``(project_id, workflow_id, period_start, period_end)``.

    All query methods return plain :class:`AgenticMetricsData` dataclasses —
    never ORM model instances — so callers are safe to use results after the
    session is closed.

    Args:
        session: Active SQLAlchemy ``Session``.  The caller is responsible for
            committing, rolling back, and closing the session.

    Example::

        repo = AgenticMetricsRepository(session)

        result = repo.upsert_rollup(AgenticMetricsUpsert(
            project_id="proj-abc",
            workflow_id="wf-1",
            bundle_id=None,
            execution_count=10,
            success_rate=0.9,
            avg_duration_seconds=5.2,
            avg_cost_usd=0.002,
            effectiveness_score=0.85,
            period_start=datetime(2026, 3, 1, tzinfo=timezone.utc),
            period_end=datetime(2026, 3, 2, tzinfo=timezone.utc),
        ))

        rows = repo.get_by_project("proj-abc", workflow_id="wf-1")
        top = repo.get_global_metrics(limit=10, sort_by="effectiveness_score")
    """

    def __init__(self, session: Session) -> None:
        """Initialise the repository with an injected session.

        Args:
            session: An active SQLAlchemy session.  Lifecycle (commit /
                rollback / close) is managed by the caller.
        """
        self.session = session

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _to_data(self, row: ProjectAgenticMetrics) -> AgenticMetricsData:
        """Convert an ORM instance to a plain :class:`AgenticMetricsData` dataclass.

        Args:
            row: A hydrated :class:`ProjectAgenticMetrics` ORM object.

        Returns:
            Detached :class:`AgenticMetricsData` snapshot safe to use after
            the session is closed.
        """
        return AgenticMetricsData(
            id=row.id,
            project_id=row.project_id,
            workflow_id=row.workflow_id,
            bundle_id=row.bundle_id,
            execution_count=row.execution_count,
            success_rate=row.success_rate,
            avg_duration_seconds=row.avg_duration_seconds,
            avg_cost_usd=row.avg_cost_usd,
            effectiveness_score=row.effectiveness_score,
            rollup_computed_at=row.rollup_computed_at,
            period_start=row.period_start,
            period_end=row.period_end,
            created_at=row.created_at,
            updated_at=row.updated_at,
        )

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def upsert_rollup(self, metrics: AgenticMetricsUpsert) -> AgenticMetricsData:
        """Insert or update a rollup row for the given project/workflow/period.

        Uses PostgreSQL ``INSERT ... ON CONFLICT (project_id, workflow_id,
        period_start, period_end) DO UPDATE SET ...`` so that re-running the
        aggregation job for the same time window is idempotent.

        The ``rollup_computed_at`` column is set to the current UTC timestamp
        on every upsert so callers can tell when the row was last refreshed.

        Args:
            metrics: Upsert payload containing scope, metric values, and the
                aggregation time window.

        Returns:
            :class:`AgenticMetricsData` reflecting the row state after the
            upsert (including server-generated ``id``, ``created_at``, and
            ``updated_at`` values).
        """
        now = datetime.utcnow()

        values: dict = {
            "project_id": metrics.project_id,
            "workflow_id": metrics.workflow_id,
            "bundle_id": metrics.bundle_id,
            "execution_count": metrics.execution_count,
            "success_rate": metrics.success_rate,
            "avg_duration_seconds": metrics.avg_duration_seconds,
            "avg_cost_usd": metrics.avg_cost_usd,
            "effectiveness_score": metrics.effectiveness_score,
            "period_start": metrics.period_start,
            "period_end": metrics.period_end,
            "rollup_computed_at": now,
        }

        stmt = (
            pg_insert(ProjectAgenticMetrics)
            .values(**values)
            .on_conflict_do_update(
                constraint="uq_project_agentic_metrics_period",
                set_={
                    "execution_count": metrics.execution_count,
                    "success_rate": metrics.success_rate,
                    "avg_duration_seconds": metrics.avg_duration_seconds,
                    "avg_cost_usd": metrics.avg_cost_usd,
                    "effectiveness_score": metrics.effectiveness_score,
                    "rollup_computed_at": now,
                    "bundle_id": metrics.bundle_id,
                },
            )
            .returning(ProjectAgenticMetrics)
        )

        result = self.session.execute(stmt)
        self.session.flush()

        row = result.scalars().first()
        if row is None:
            raise ValueError("Upsert failed: no row returned from INSERT ... RETURNING")
        return self._to_data(row)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_by_project(
        self,
        project_id: str,
        workflow_id: Optional[str] = None,
    ) -> list[AgenticMetricsData]:
        """Return all rollup rows for a project, optionally filtered by workflow.

        Results are ordered ``period_end DESC`` so the most-recent period
        comes first.

        Args:
            project_id: Project identifier to query.
            workflow_id: If provided, restrict results to this workflow scope.
                Pass ``None`` to return rows for all workflows (including
                project-wide aggregates where ``workflow_id IS NULL``).

        Returns:
            List of :class:`AgenticMetricsData` instances, ordered by
            ``period_end`` descending.  Returns an empty list when no rows
            match.
        """
        stmt = select(ProjectAgenticMetrics).where(
            ProjectAgenticMetrics.project_id == project_id
        )

        if workflow_id is not None:
            stmt = stmt.where(ProjectAgenticMetrics.workflow_id == workflow_id)

        stmt = stmt.order_by(desc(ProjectAgenticMetrics.period_end))

        rows = self.session.execute(stmt).scalars().all()
        return [self._to_data(row) for row in rows]

    def get_global_metrics(
        self,
        limit: int = 20,
        sort_by: SortByLiteral = "effectiveness_score",
    ) -> list[AgenticMetricsData]:
        """Return the top-N rollup rows across all projects, sorted by a metric.

        This method is intended for dashboard / leaderboard views where a
        caller wants to surface the best- or worst-performing projects without
        pre-filtering by project.  Results include one row per unique
        ``(project_id, workflow_id, period_start, period_end)`` tuple — no
        deduplication is performed.

        Args:
            limit: Maximum number of rows to return (default ``20``).
            sort_by: Column to sort by, descending.  Must be one of:

                - ``"effectiveness_score"`` (default)
                - ``"avg_cost_usd"``
                - ``"execution_count"``
                - ``"success_rate"``

        Returns:
            List of up to *limit* :class:`AgenticMetricsData` instances ordered
            by *sort_by* descending, with ``NULL`` values sorted last.

        Raises:
            ValueError: If *sort_by* is not one of the accepted column names.
        """
        if sort_by not in _SORT_COLUMNS:
            raise ValueError(
                f"Invalid sort_by value {sort_by!r}. "
                f"Must be one of: {sorted(_SORT_COLUMNS)}"
            )

        sort_column = _SORT_COLUMNS[sort_by]
        stmt = select(ProjectAgenticMetrics).order_by(desc(sort_column)).limit(limit)

        rows = self.session.execute(stmt).scalars().all()
        return [self._to_data(row) for row in rows]
