"""SQLAlchemy ORM models for enterprise (PostgreSQL) schema.

This module defines the enterprise-tier ORM models that map to the PostgreSQL
schema introduced by the enterprise-db-storage feature. These models are
intentionally separate from the SQLite-backed models in models.py and share
a dedicated DeclarativeBase (EnterpriseBase) so that enterprise table metadata
never contaminates the local-mode SQLite schema.

Tables defined here:
    - EnterpriseArtifact                    (enterprise_artifacts)                        — ENT-1.2
    - EnterpriseArtifactVersion             (artifact_versions, PG)                       — ENT-1.3
    - EnterpriseArtifactVersionScope        (artifact_version_scopes)                     — CAI-P5
    - EnterpriseCollection                  (enterprise_collections)                      — ENT-1.4
    - EnterpriseCollectionArtifact          (enterprise_collection_artifacts)             — ENT-1.5
    - EnterpriseUser                        (enterprise_users)                            — DB-001
    - EnterpriseTeam                        (enterprise_teams)                            — DB-001
    - EnterpriseTeamMember                  (enterprise_team_members)                     — DB-001
    - EnterpriseTag                         (enterprise_tags)                             — ENT2-2.1
    - EnterpriseArtifactTag                 (enterprise_artifact_tags)                    — ENT2-2.1
    - EnterpriseGroup                       (enterprise_groups)                           — ENT2-2.1
    - EnterpriseGroupArtifact               (enterprise_group_artifacts)                  — ENT2-2.1
    - EnterpriseSettings                    (enterprise_settings)                         — ENT2-2.1
    - EnterpriseEntityTypeConfig            (enterprise_entity_type_configs)              — ENT2-2.1
    - EnterpriseEntityCategory              (enterprise_entity_categories)                — ENT2-2.1
    - EnterpriseContextEntity               (enterprise_context_entities)                 — ENT2-2.2
    - EnterpriseEntityCategoryAssociation   (enterprise_entity_category_associations)     — ENT2-2.2
    - EnterpriseProject                     (enterprise_projects)                         — ENT2-2.3
    - EnterpriseProjectArtifact             (enterprise_project_artifacts)                — ENT2-2.3
    - EnterpriseDeployment                  (enterprise_deployments)                      — ENT2-2.3
    - EnterpriseDeploymentSet               (enterprise_deployment_sets)                  — ENT2-2.3
    - EnterpriseDeploymentSetMember         (enterprise_deployment_set_members)           — ENT2-2.3
    - EnterpriseDeploymentSetTag            (enterprise_deployment_set_tags)              — ENT2-2.3
    - EnterpriseDeploymentProfile           (enterprise_deployment_profiles)              — ENT2-2.3
    - EnterpriseMarketplaceSource           (enterprise_marketplace_sources)              — ENT2-2.4
    - EnterpriseMarketplaceCatalogEntry     (enterprise_marketplace_catalog_entries)      — ENT2-2.4
    - EnterpriseProjectTemplate             (enterprise_project_templates)                — ent_012
    - EnterpriseProjectTemplateEntity       (enterprise_project_template_entities)        — ent_012
    - EnterpriseArtifactBlob                (artifact_blobs)                              — CAS-1.3
    - EnterpriseWorkflow                    (enterprise_workflows)                        — EGCF-2.1
    - EnterpriseWorkflowStage               (enterprise_workflow_stages)                  — EGCF-2.1
    - EnterpriseWorkflowExecution           (enterprise_workflow_executions)              — EGCF-2.1
    - EnterpriseExecutionStep               (enterprise_execution_steps)                  — EGCF-2.1
    - EnterpriseMemoryItem                  (enterprise_memory_items)                     — EGCF-2.2
    - EnterpriseContextModule               (enterprise_context_modules)                  — EGCF-2.2
    - EnterpriseModuleMemoryItem            (enterprise_module_memory_items)              — EGCF-2.2
    - EnterpriseBundleEntity                (enterprise_bundle_entities)                  — EGCF-2.3
    - EnterpriseBundleMembership            (enterprise_bundle_memberships)               — EGCF-2.3
    - EnterpriseBundleCommit                (enterprise_bundle_commits)                   — EGCF-2.3
    - EnterpriseBundleCommitMember          (enterprise_bundle_commit_members)            — EGCF-2.3
    - EnterpriseBomSnapshot                 (enterprise_bom_snapshots)                    — EGCF-2.4
    - EnterpriseAttestationPolicy           (enterprise_attestation_policies)             — EGCF-2.4
    - EnterpriseAttestationRecord           (enterprise_attestation_records)              — EGCF-2.4
    - EnterpriseBomMetadata                 (enterprise_bom_metadata)                     — EGCF-2.4
    - EnterpriseContextEntityCategory       (enterprise_context_entity_categories)        — EGCF-5.1
    - EnterpriseArtifactCategoryAssociation (enterprise_artifact_category_associations)   — EGCF-5.1
    - EnterpriseArtifactHistoryEvent        (enterprise_artifact_history_events)          — EGCF-5.2
    - EnterpriseProjectGitConnection        (enterprise_project_git_connections)          — GCD-1.3
    - EnterpriseCascadePolicy               (enterprise_cascade_policies)                 — DS-4
    - EnterpriseCascadePolicyAudit          (enterprise_cascade_policy_audit)             — DS-4
    - EnterpriseDuplicatePair               (enterprise_duplicate_pairs)                  — enterprise-stub-promotion-v1
    - EnterpriseScaffoldTemplate            (enterprise_scaffold_templates)               — enterprise-stub-promotion-v1 TASK-3.1

Naming note (ENT-1.3):
    The local-mode SQLite schema (models.py) contains an ``ArtifactVersion``
    class backed by a same-named SQLite table used for change-origin tracking.
    To avoid a class-name collision at import time the enterprise counterpart is
    named ``EnterpriseArtifactVersion``. It maps to the PostgreSQL
    ``artifact_versions`` table, which lives in a different database engine and
    is unrelated to the SQLite table of the same DDL name.

Design invariants:
    - All enterprise tables are PostgreSQL-only (UUID PKs, JSONB, TIMESTAMPTZ).
    - Every query against an enterprise table MUST include a tenant_id predicate.
    - EnterpriseBase is the single shared base for all enterprise models.
      Do NOT use the local-mode Base from models.py for these models.

Exports:
    EnterpriseBase: Shared DeclarativeBase for all enterprise ORM models.
    EnterpriseArtifact: Primary artifact store for enterprise deployments.
    EnterpriseArtifactVersion: Immutable content snapshot per artifact version.
    EnterpriseArtifactVersionScope: Per-owner, per-project version scope for divergence tracking.
    EnterpriseCollection: Named artifact grouping per tenant.
    EnterpriseCollectionArtifact: Junction table linking collections to artifacts.
    EnterpriseUser: Enterprise user account scoped to a tenant.
    EnterpriseTeam: Named user group scoped to a tenant.
    EnterpriseTeamMember: Junction table linking users to teams.
    EnterpriseTag: Tenant-scoped label for artifacts.
    EnterpriseArtifactTag: Junction table linking tags to artifacts.
    EnterpriseGroup: Named grouping of artifacts within a collection.
    EnterpriseGroupArtifact: Junction table linking groups to artifacts.
    EnterpriseSettings: One-row-per-tenant configuration store.
    EnterpriseEntityTypeConfig: Display configuration for artifact entity types.
    EnterpriseEntityCategory: Category taxonomy for context entities.
    EnterpriseContextEntity: Tenant-scoped context entity (CLAUDE.md, rules, specs).
    EnterpriseEntityCategoryAssociation: Junction linking context entities to categories.
    EnterpriseProject: Enterprise project record (informational path, DB-backed).
    EnterpriseProjectArtifact: Junction table tracking deployed artifacts per project.
    EnterpriseDeployment: Per-deployment record linking artifact to project.
    EnterpriseDeploymentSet: Named group of artifacts for coordinated deployment.
    EnterpriseDeploymentSetMember: Junction table linking artifacts to deployment sets.
    EnterpriseDeploymentSetTag: String tags for deployment sets.
    EnterpriseDeploymentProfile: Deployment configuration profile (scope, path, rules).
    EnterpriseMarketplaceSource: Registered GitHub repo for marketplace scanning.
    EnterpriseMarketplaceCatalogEntry: Discovered artifact listing from a scanned source.
    EnterpriseProjectTemplate: Named project scaffold template scoped to a tenant.
    EnterpriseProjectTemplateEntity: Ordered artifact entity belonging to a project template.
    EnterpriseArtifactBlob: Content-addressed binary blob for CAS file storage.
    EnterpriseWorkflow: Tenant-scoped workflow definition (name, description, status, config).
    EnterpriseWorkflowStage: Ordered stage within a workflow definition.
    EnterpriseWorkflowExecution: A single run of a workflow, tracking status and result.
    EnterpriseExecutionStep: An individual step within a workflow execution run.
    EnterpriseBundleEntity: Tenant-scoped bundle definition (name, type, status, config).
    EnterpriseBundleMembership: Junction table mapping artifacts to bundle entities.
    EnterpriseBundleCommit: Versioned snapshot of a bundle entity's membership state.
    EnterpriseBundleCommitMember: Per-artifact row within a bundle commit snapshot.
    EnterpriseBomSnapshot: Bill-of-materials snapshot for an artifact version.
    EnterpriseAttestationPolicy: Policy definition for attestation checks (rules, type, status).
    EnterpriseAttestationRecord: Result of an attestation check against a BOM snapshot.
    EnterpriseBomMetadata: Additional metadata record for a BOM snapshot (one-per-snapshot).
    EnterpriseContextEntityCategory: Tenant-scoped category taxonomy for context entity classification.
    EnterpriseArtifactCategoryAssociation: Junction linking artifacts to context entity categories.
    EnterpriseArtifactHistoryEvent: Immutable audit event recording lifecycle changes to an artifact.
    EnterpriseProjectGitConnection: Join table linking enterprise projects to git-repo connections.
    EnterpriseCascadePolicy: Org/artifact/team-scoped cascade policy configuration row.
    EnterpriseCascadePolicyAudit: Immutable audit log entry for cascade policy mutations.
    EnterpriseDuplicatePair: Tenant-scoped candidate duplicate artifact pair record.
    EnterpriseScaffoldTemplate: Tenant-scoped Backstage scaffold template for a bundle entity.

References:
    docs/dev/architecture/enterprise-db-schema-v1.md
    .claude/findings/ENT2_TRIAGE.md
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB, TSVECTOR, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from skillmeat.cache.column_types import EncryptedString

if TYPE_CHECKING:
    # Forward references for relationships whose classes are defined later in
    # this same module.  Imported under TYPE_CHECKING only so that static type
    # checkers can resolve the Mapped[] annotations on relationship() fields.
    # At runtime the string-based relationship() targets resolve lazily at
    # SQLAlchemy mapper configuration time — no import is needed.
    from skillmeat.cache.models_enterprise import (  # noqa: F401
        EnterpriseArtifactVersion,
        EnterpriseArtifactVersionScope,
        EnterpriseCollectionArtifact,
    )


# =============================================================================
# Enterprise DeclarativeBase
# =============================================================================


class EnterpriseBase(DeclarativeBase):
    """Shared DeclarativeBase for all enterprise (PostgreSQL) ORM models.

    This base is separate from the local-mode ``Base`` in models.py so that
    enterprise table metadata is never mixed into the SQLite schema used by the
    CLI's local cache.

    ENT-1.2 (EnterpriseArtifact), ENT-1.3 (EnterpriseArtifactVersion), and
    ENT-1.4 (EnterpriseCollection) all subclass this base. ENT-1.5
    (EnterpriseCollectionArtifact) likewise imports it.
    """

    pass


# =============================================================================
# EnterpriseArtifact model  (ENT-1.2)
# =============================================================================


class EnterpriseArtifact(EnterpriseBase):
    """Primary artifact store for enterprise (cloud/PostgreSQL) deployments.

    Each row represents one artifact belonging to one tenant. This is the
    PostgreSQL-native counterpart to the SQLite-backed ``Artifact`` model in
    models.py. The two schemas are intentionally parallel and do not share
    tables or rows at runtime.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate. Omitting it is a security defect that leaks cross-tenant
        data. See the repository layer (ENT-2.x) for the TenantScopedRepository
        base class that enforces this rule structurally.

    Attributes:
        id:           UUID primary key, server-generated via gen_random_uuid().
        tenant_id:    Tenant scope; every query MUST filter by this column.
        name:         Human-readable artifact name (e.g. "canvas-design").
        artifact_type: Artifact type matching existing type vocabulary.
        description:  Optional human-readable description from frontmatter.
        source_url:   GitHub origin URL for upstream sync tracking.
        scope:        Storage scope — 'user' (global) or 'local' (project).
        tags:         JSONB array of tag strings; GIN-indexed for containment.
        custom_fields: Arbitrary JSONB key-value pairs for extensibility.
        is_active:    Soft-delete flag; False = logically deleted, row retained.
        created_at:   Timezone-aware creation timestamp (server default: now()).
        updated_at:   Timezone-aware last-modified timestamp (app-managed).
        created_by:   User ID or "system"; NULL until PRD-2 AuthContext lands.
        versions:     Immutable content snapshots (EnterpriseArtifactVersion, ENT-1.3).
        collection_memberships: Junction rows linking to collections (ENT-1.5).

    Constraints:
        uq_enterprise_artifacts_tenant_name_type:
            UNIQUE (tenant_id, name, type) — one artifact of a given type per
            name per tenant.
        ck_enterprise_artifacts_type:
            type must be one of the recognised artifact type values.
        ck_enterprise_artifacts_scope:
            scope must be 'user' or 'local'.
        ck_enterprise_artifacts_name_length:
            name must be 1–255 characters.

    Indexes:
        idx_enterprise_artifacts_tenant_id:       (tenant_id)
        idx_enterprise_artifacts_tenant_type:     (tenant_id, type)
        idx_enterprise_artifacts_tenant_created_at: (tenant_id, created_at)
        idx_enterprise_artifacts_tags_gin:        GIN (tags jsonb_path_ops)
        idx_enterprise_artifacts_source_url:      (source_url) WHERE NOT NULL
            — partial index; declared in the Alembic migration (ENT-1.7) with
            CONCURRENTLY to avoid table locks during deployment.

    Schema reference:
        docs/dev/architecture/enterprise-db-schema-v1.md §2.1
    """

    __tablename__ = "enterprise_artifacts"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique artifact identifier; FK target for artifact_versions and enterprise_collection_artifacts",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Core metadata
    # -------------------------------------------------------------------------

    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        comment="Human-readable artifact name, e.g. canvas-design, dev-execution",
    )
    # The DDL column is named 'type'; Python attribute is artifact_type to avoid
    # shadowing the built-in and for clarity at call sites.
    artifact_type: Mapped[str] = mapped_column(
        "type",
        String(50),
        nullable=False,
        comment="Artifact type; matches ck_enterprise_artifacts_type values",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional human-readable description from frontmatter",
    )
    source_url: Mapped[Optional[str]] = mapped_column(
        String(512),
        nullable=True,
        comment="GitHub origin URL (github:owner/repo/path); used for upstream sync",
    )
    scope: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="user",
        server_default=text("'user'"),
        comment="user = global collection; local = project-scoped",
    )

    # -------------------------------------------------------------------------
    # Flexible storage
    # -------------------------------------------------------------------------

    tags: Mapped[List[str]] = mapped_column(
        JSONB,
        nullable=False,
        default=list,
        server_default=text("'[]'::jsonb"),
        comment="Array of tag strings for filtering; GIN-indexed for @> containment queries",
    )
    custom_fields: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="Arbitrary key-value pairs for schema-less extensibility",
    )

    # -------------------------------------------------------------------------
    # Soft-delete flag
    # -------------------------------------------------------------------------

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default=text("true"),
        comment="Soft-delete: False = logically deleted but row retained for audit",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )
    created_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="User ID or 'system'; NULL until PRD-2 AuthContext is available",
    )

    # -------------------------------------------------------------------------
    # Ownership and visibility  (DB-003)
    # -------------------------------------------------------------------------

    owner_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="UUID of the user who owns this artifact; NULL = system/unowned",
    )
    owner_type: Mapped[Optional[str]] = mapped_column(
        String(20),
        nullable=True,
        default="user",
        comment="Owner type; stores OwnerType enum value, e.g. 'user' or 'team'",
    )
    visibility: Mapped[Optional[str]] = mapped_column(
        String(20),
        nullable=True,
        default="private",
        comment="Visibility level; stores Visibility enum value, e.g. 'private', 'internal', 'public'",
    )
    enforce_override: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
        comment="When True, governance policy overrides apply to this artifact regardless of owner settings",
    )

    # -------------------------------------------------------------------------
    # Schema parity columns (ent_024)
    # -------------------------------------------------------------------------

    # Mirrors artifacts.core_content (local schema).  Stores platform-agnostic
    # content before assembly when modular_content_architecture is enabled.
    core_content: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment=(
            "Platform-agnostic content before assembly. "
            "Mirrors artifacts.core_content from the local schema."
        ),
    )

    # O(1) latest-deployment pointer.  Enterprise counterpart of
    # artifacts.latest_deployment_id (which is a String FK to
    # project_version_deployments.id in the local schema).  Here it is a
    # UUID FK to enterprise_deployments.id.  No ORM-level relationship is
    # declared — the FK is enforced at the DB level by ent_024.
    latest_deployment_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment=(
            "UUID FK to enterprise_deployments.id (SET NULL on delete). "
            "O(1) latest-deployment pointer; enforced by migration ent_024, not ORM."
        ),
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    # ENT-1.3: EnterpriseArtifactVersion is defined below in this same module.
    # The string reference resolves lazily at mapper configuration time.
    versions: Mapped[List["EnterpriseArtifactVersion"]] = relationship(
        "EnterpriseArtifactVersion",
        back_populates="artifact",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseArtifactVersion.created_at.desc()",
    )

    # ENT-1.5 defines EnterpriseCollectionArtifact. Same lazy resolution.
    collection_memberships: Mapped[List["EnterpriseCollectionArtifact"]] = relationship(
        "EnterpriseCollectionArtifact",
        back_populates="artifact",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # DB-1.3: per-owner-per-project version scope state rows (artifact_version_scopes).
    version_scopes: Mapped[List["EnterpriseArtifactVersionScope"]] = relationship(
        "EnterpriseArtifactVersionScope",
        back_populates="artifact",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Unique: one artifact of a given type per name per tenant
        UniqueConstraint(
            "tenant_id",
            "name",
            "type",
            name="uq_enterprise_artifacts_tenant_name_type",
        ),
        # Check: restrict to valid artifact type vocabulary
        CheckConstraint(
            "type IN ("
            "'skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', "
            "'workflow', 'composite', 'project_config', 'spec_file', "
            "'rule_file', 'context_file', 'progress_template', "
            "'context_module', 'template', 'group', "
            "'deployment_set', 'context_pack', 'bundle'"
            ")",
            name="ck_enterprise_artifacts_type",
        ),
        # Check: scope must be 'user' or 'local'
        CheckConstraint(
            "scope IN ('user', 'local')",
            name="ck_enterprise_artifacts_scope",
        ),
        # Check: name must be between 1 and 255 characters
        CheckConstraint(
            "length(name) > 0 AND length(name) <= 255",
            name="ck_enterprise_artifacts_name_length",
        ),
        # B-tree: primary tenant filter (every query starts here)
        Index(
            "idx_enterprise_artifacts_tenant_id",
            "tenant_id",
        ),
        # B-tree: type-filtered listing within a tenant
        Index(
            "idx_enterprise_artifacts_tenant_type",
            "tenant_id",
            "type",
        ),
        # B-tree: default sort order (newest artifacts first per tenant)
        Index(
            "idx_enterprise_artifacts_tenant_created_at",
            "tenant_id",
            "created_at",
        ),
        # GIN: JSONB tag containment — supports tags @> '["frontend"]'::jsonb
        # The Alembic migration (ENT-1.7) must create this with CONCURRENTLY
        # and postgresql_ops={"tags": "jsonb_path_ops"} to avoid table locks.
        Index(
            "idx_enterprise_artifacts_tags_gin",
            "tags",
            postgresql_using="gin",
            postgresql_ops={"tags": "jsonb_path_ops"},
        ),
        # Partial B-tree: source_url lookup for upstream sync matching.
        # The WHERE clause (source_url IS NOT NULL) must be declared in the
        # Alembic migration using postgresql_where; SQLAlchemy Index() does
        # not render WHERE portably enough for inline declaration here.
        # Migration snippet (ENT-1.7):
        #   op.create_index(
        #       "idx_enterprise_artifacts_source_url", "enterprise_artifacts",
        #       ["source_url"],
        #       postgresql_where="source_url IS NOT NULL",
        #       postgresql_concurrently=True,
        #   )
        # B-tree: owner lookup — find all artifacts owned by a given user (DB-003)
        Index(
            "ix_enterprise_artifacts_owner_id",
            "owner_id",
        ),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseArtifact."""
        return (
            f"<EnterpriseArtifact("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"artifact_type={self.artifact_type!r}, "
            f"name={self.name!r}, "
            f"is_active={self.is_active!r}"
            f")>"
        )


# =============================================================================
# EnterpriseArtifactVersion model  (ENT-1.3)
# =============================================================================


class EnterpriseArtifactVersion(EnterpriseBase):
    """Immutable content snapshot for a single version of an enterprise artifact.

    Each row captures one version of an artifact's Markdown payload.  Rows are
    write-once: they are never updated after insertion.  The ``content_hash``
    column (SHA256 hex digest of ``markdown_payload``) is globally unique across
    all tenants, enabling cross-tenant deduplication without exposing content:
    the repository checks for an existing row by hash before inserting, then
    re-uses the existing row's ID if the hash already exists.  See Section 5 of
    the schema reference for the full deduplication rationale.

    Naming rationale:
        The local-mode SQLite cache has an ``ArtifactVersion`` model in
        ``models.py`` that tracks change-origin history for the CLI.  That model
        is backed by a same-named SQLite table and is unrelated to this class.
        This class is named ``EnterpriseArtifactVersion`` to avoid a Python
        class-name collision when both modules are imported into the same
        process.  At the DDL level the table is named ``artifact_versions`` and
        lives in the PostgreSQL database, not the SQLite database.

    Tenant isolation invariant:
        ``tenant_id`` is denormalized from the parent ``EnterpriseArtifact`` row
        for query performance.  The application layer (ENT-2.x repository) is
        responsible for ensuring that ``tenant_id`` on this row matches
        ``tenant_id`` on the parent artifact at write time.  There is no DB
        foreign key from ``tenant_id`` to a ``tenants`` table in Phase 1.

    Immutability invariant:
        No UPDATE is ever issued against this table.  To supersede a version the
        caller inserts a new row.  The ``content_hash`` uniqueness constraint is
        the deduplication guard: identical content always maps to the same row.

    Attributes:
        id:               UUID PK, server-generated via gen_random_uuid().
        tenant_id:        Denormalized tenant scope for efficient querying.
        artifact_id:      FK to enterprise_artifacts.id; CASCADE on delete.
        version_tag:      Human-readable label, e.g. "v1.2.0", "latest", SHA prefix.
        content_hash:     SHA256 hex digest (64 chars) of markdown_payload; globally unique.
        markdown_payload: Full Markdown content of the artifact at this version.
        commit_sha:       GitHub commit SHA (40 chars) for git-provenance tracing; nullable.
        changelog:        Optional free-text description of changes in this version.
        created_by:       User ID or "system"; NULL until PRD-2 AuthContext lands.
        created_at:       Immutable creation timestamp; server-generated.
        artifact:         Many-to-one back-reference to EnterpriseArtifact.

    Constraints:
        fk_artifact_versions_artifact_id:
            FK (artifact_id) -> enterprise_artifacts(id) ON DELETE CASCADE
        uq_artifact_versions_artifact_version:
            UNIQUE (artifact_id, version_tag) — one tag per artifact
        uq_artifact_versions_content_hash:
            UNIQUE (content_hash) — global deduplication across all tenants
        ck_artifact_versions_content_hash_length:
            length(content_hash) = 64 — SHA256 hex is exactly 64 chars
        ck_artifact_versions_commit_sha_length:
            commit_sha IS NULL OR length(commit_sha) = 40 — full SHA1 is 40 chars

    Indexes:
        idx_artifact_versions_tenant_id:
            (tenant_id) — mandatory per-tenant filter on version queries
        idx_artifact_versions_artifact_id:
            (artifact_id) — covers the FK and single-artifact version listing
        idx_artifact_versions_artifact_created:
            (artifact_id, created_at DESC) — paginated version history per artifact
        idx_artifact_versions_tenant_created:
            (tenant_id, created_at DESC) — recent-versions queries across a tenant
        idx_artifact_versions_commit_sha:
            (commit_sha) WHERE NOT NULL — upstream sync: commit already ingested?

    Schema reference:
        docs/dev/architecture/enterprise-db-schema-v1.md §2.2
    """

    __tablename__ = "artifact_versions"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Version record primary key; globally unique",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment=(
            "Denormalized tenant scope for query performance; "
            "must equal the parent artifact's tenant_id — validated at write time"
        ),
    )

    # -------------------------------------------------------------------------
    # Foreign key
    # -------------------------------------------------------------------------

    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_artifact_versions_artifact_id",
        ),
        nullable=False,
        comment="Parent artifact; cascade-deletes all version rows when artifact is removed",
    )

    # -------------------------------------------------------------------------
    # Version labeling
    # -------------------------------------------------------------------------

    version_tag: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        comment=(
            "Human-readable version label, e.g. 'v1.2.0', 'latest', or a short SHA prefix. "
            "Unique per artifact (enforced by uq_artifact_versions_artifact_version)."
        ),
    )

    # -------------------------------------------------------------------------
    # Content
    # -------------------------------------------------------------------------

    content_hash: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        comment=(
            "SHA256 hex digest of markdown_payload (64 chars). "
            "Globally unique — enables cross-tenant deduplication without exposing content. "
            "Repository MUST check for an existing row by hash before inserting."
        ),
    )
    markdown_payload: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Full Markdown content of the artifact at this version; no size cap in Phase 1",
    )
    content_payload: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
        comment=(
            "CAS file manifest: maps artifact-relative path strings to their SHA-256 "
            "hex digests. NULL for single-file artifacts that carry all content in "
            "markdown_payload. Example: {'commands/foo.md': '<sha256>', "
            "'hooks/bar.sh': '<sha256>'}. Each hash must correspond to an "
            "artifact_blobs.sha256_hash row. Written at version creation time; "
            "never updated (versions are write-once)."
        ),
    )

    # -------------------------------------------------------------------------
    # Git provenance
    # -------------------------------------------------------------------------

    commit_sha: Mapped[Optional[str]] = mapped_column(
        String(40),
        nullable=True,
        comment=(
            "GitHub commit SHA (40 chars) for the source of this version. "
            "NULL for versions not sourced from GitHub. "
            "Checked via idx_artifact_versions_commit_sha during upstream sync."
        ),
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    changelog: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of changes introduced in this version",
    )
    created_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="User ID or 'system'; NULL until PRD-2 AuthContext is available",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment=(
            "Immutable creation timestamp; server-generated. "
            "This column is NEVER updated — versions are write-once."
        ),
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    artifact: Mapped["EnterpriseArtifact"] = relationship(
        "EnterpriseArtifact",
        back_populates="versions",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Unique: one version_tag per artifact
        UniqueConstraint(
            "artifact_id",
            "version_tag",
            name="uq_artifact_versions_artifact_version",
        ),
        # Unique: global content deduplication by SHA256 hash
        UniqueConstraint(
            "content_hash",
            name="uq_artifact_versions_content_hash",
        ),
        # Check: SHA256 hex digest is exactly 64 characters
        CheckConstraint(
            "length(content_hash) = 64",
            name="ck_artifact_versions_content_hash_length",
        ),
        # Check: GitHub SHA1 is exactly 40 characters when present
        CheckConstraint(
            "commit_sha IS NULL OR length(commit_sha) = 40",
            name="ck_artifact_versions_commit_sha_length",
        ),
        # B-tree: mandatory per-tenant filter on cross-artifact version queries
        Index(
            "idx_artifact_versions_tenant_id",
            "tenant_id",
        ),
        # B-tree: covers the FK and single-artifact "list all versions" query
        Index(
            "idx_artifact_versions_artifact_id",
            "artifact_id",
        ),
        # B-tree composite: paginated version history for a single artifact,
        # newest first — satisfies the EnterpriseArtifact.versions order_by
        Index(
            "idx_artifact_versions_artifact_created",
            "artifact_id",
            "created_at",
        ),
        # B-tree composite: recent-versions queries across an entire tenant
        # (e.g. "show me the last 20 changes across all my artifacts")
        Index(
            "idx_artifact_versions_tenant_created",
            "tenant_id",
            "created_at",
        ),
        # Partial B-tree: upstream sync check "have we already ingested this
        # commit?".  The WHERE clause keeps the index small by excluding the
        # majority of rows where commit_sha IS NULL.
        # The postgresql_where must be declared in the Alembic migration with
        # CONCURRENTLY to avoid table locks; it is noted here for reference.
        # Migration snippet (ENT-1.7):
        #   op.create_index(
        #       "idx_artifact_versions_commit_sha", "artifact_versions",
        #       ["commit_sha"],
        #       postgresql_where="commit_sha IS NOT NULL",
        #       postgresql_concurrently=True,
        #   )
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseArtifactVersion."""
        return (
            f"<EnterpriseArtifactVersion("
            f"id={self.id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"version_tag={self.version_tag!r}, "
            f"content_hash={self.content_hash!r}"
            f")>"
        )


# =============================================================================
# EnterpriseArtifactVersionScope model  (CAI-P5 / VCS-v2)
# =============================================================================


class EnterpriseArtifactVersionScope(EnterpriseBase):
    """Per-owner, per-project version scope for enterprise artifact tracking.

    Tracks which content hash each owner (user, team, or enterprise) currently
    has for a given artifact within a project. Enables divergence detection
    between a user's local version and the team/enterprise baseline, and
    supports a promotion workflow for propagating changes upward.

    Ownership hierarchy::

        enterprise baseline  (owner_type='enterprise')
          └── team baseline  (owner_type='team')
                └── user fork  (owner_type='user')

    Attributes:
        id: Server-generated UUID primary key.
        tenant_id: Tenant scope; every query MUST filter on this.
        project_id: Project that this scope entry belongs to.
        artifact_id: FK to enterprise_artifacts; cascade-deletes scope rows.
        owner_type: Owner category ('user', 'team', 'enterprise').
        owner_id: UUID of the owning entity.
        head_hash: SHA-256 hex digest (64 chars) of current head content.
        baseline_hash: SHA-256 hex digest of last approved baseline (NULL initially).
        is_diverged: True when head_hash differs from baseline_hash.
        promotion_state: Workflow state ('none', 'pending', 'approved', 'rejected').
        promotion_requested_at: When promotion was requested.
        promotion_reviewed_by: UUID of the reviewer.
        promotion_reviewed_at: When the promotion was reviewed.
        created_at: Immutable creation timestamp.
        updated_at: Last-modified timestamp (maintained by DB trigger).
    """

    __tablename__ = "artifact_version_scopes"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Server-generated UUID primary key",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Foreign keys
    # -------------------------------------------------------------------------

    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Project that this scope entry belongs to",
    )
    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_version_scopes_artifact_id",
        ),
        nullable=False,
        comment="Parent artifact; cascade-deletes scope rows",
    )

    # -------------------------------------------------------------------------
    # Ownership
    # -------------------------------------------------------------------------

    owner_type: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Owner category: 'user', 'team', or 'enterprise'",
    )
    owner_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="UUID of the owning user, team, or enterprise entity",
    )

    # -------------------------------------------------------------------------
    # Content tracking
    # -------------------------------------------------------------------------

    head_hash: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        comment="SHA-256 hex digest of current head content (64 chars)",
    )
    baseline_hash: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="SHA-256 hex digest of last approved baseline; NULL until first set",
    )
    is_diverged: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("FALSE"),
        comment="True when head_hash differs from baseline_hash",
    )
    sync_status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        server_default=text("'pending'"),
        comment=(
            "Denormalised sync state: 'current', 'outdated', 'diverged', or 'pending'. "
            "Kept in sync with head_hash/baseline_hash/is_diverged by the service layer. "
            "Indexed for fast aggregation queries on the admin sync dashboard."
        ),
    )

    # -------------------------------------------------------------------------
    # Promotion workflow
    # -------------------------------------------------------------------------

    promotion_state: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Promotion state: 'none', 'pending', 'approved', or 'rejected'",
    )
    promotion_requested_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="When promotion was requested; NULL if not in promotion flow",
    )
    promotion_reviewed_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="UUID of the reviewer who approved or rejected",
    )
    promotion_reviewed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="When the promotion was reviewed",
    )

    # -------------------------------------------------------------------------
    # Audit timestamps
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Immutable creation timestamp",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Last-modified; maintained by DB trigger",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    artifact: Mapped["EnterpriseArtifact"] = relationship(
        "EnterpriseArtifact",
        back_populates="version_scopes",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "project_id",
            "artifact_id",
            "owner_type",
            "owner_id",
            name="uq_version_scopes_owner_artifact_project",
        ),
        CheckConstraint(
            "owner_type IN ('user', 'team', 'enterprise')",
            name="ck_version_scopes_owner_type",
        ),
        CheckConstraint(
            "length(head_hash) = 64",
            name="ck_version_scopes_head_hash_length",
        ),
        CheckConstraint(
            "promotion_state IN ('none', 'pending', 'approved', 'rejected')",
            name="ck_version_scopes_promotion_state",
        ),
        CheckConstraint(
            "sync_status IN ('current', 'outdated', 'diverged', 'pending')",
            name="chk_sync_status",
        ),
        Index(
            "idx_version_scopes_tenant_project",
            "tenant_id",
            "project_id",
        ),
        Index(
            "idx_version_scopes_artifact",
            "artifact_id",
        ),
        Index(
            "idx_version_scopes_diverged",
            "tenant_id",
            "is_diverged",
            postgresql_where=text("is_diverged = TRUE"),
        ),
        # PREREQ-3.2: aggregation indexes for the admin sync dashboard.
        Index(
            "idx_version_scopes_tenant_owner",
            "tenant_id",
            "owner_type",
            "owner_id",
        ),
        Index(
            "idx_version_scopes_tenant_owner_status",
            "tenant_id",
            "owner_type",
            "sync_status",
        ),
    )

    def __repr__(self) -> str:
        return (
            f"<EnterpriseArtifactVersionScope("
            f"id={self.id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"owner_type={self.owner_type!r}, "
            f"owner_id={self.owner_id!r}, "
            f"is_diverged={self.is_diverged!r}"
            f")>"
        )


# =============================================================================
# EnterpriseCollection model  (ENT-1.4)
# =============================================================================


class EnterpriseCollection(EnterpriseBase):
    """Named grouping of enterprise artifacts scoped to a single tenant.

    Mirrors the intent of the existing local-mode ``Collection`` table but is
    PostgreSQL-native, tenant-scoped, and uses UUID primary keys.

    One collection per tenant may be designated as default (``is_default=True``).
    The uniqueness of the default flag is enforced at the application/repository
    layer (not by a database constraint) to keep cross-PostgreSQL-version
    compatibility simple. The repository ``set_default`` method clears
    ``is_default`` on all sibling collections in the same transaction before
    setting the new default.

    Attributes:
        id:           UUID primary key, generated server-side.
        tenant_id:    Tenant scope.  Every query MUST filter by this column.
        name:         Human-readable collection name; unique per tenant.
        description:  Optional free-text description.
        is_default:   When True the CLI uses this collection implicitly.
        created_by:   User ID or ``"system"``; NULL until PRD-2 AuthContext.
        created_at:   Timezone-aware creation timestamp.
        updated_at:   Timezone-aware last-modified timestamp.
        memberships:  Ordered list of EnterpriseCollectionArtifact join rows.

    Constraints:
        pk_enterprise_collections:          PRIMARY KEY (id)
        uq_enterprise_collections_tenant_name:
                                            UNIQUE (tenant_id, name)
        ck_enterprise_collections_name_length:
                                            length(name) BETWEEN 1 AND 255

    Indexes:
        idx_enterprise_collections_tenant_id:
                                            (tenant_id)
        idx_enterprise_collections_tenant_name:
                                            (tenant_id, name)
        idx_enterprise_collections_tenant_default:
                                            (tenant_id, is_default)
                                            WHERE is_default = TRUE  [partial]

    Schema reference:
        docs/dev/architecture/enterprise-db-schema-v1.md §2.3
    """

    __tablename__ = "enterprise_collections"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique collection identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Core metadata
    # -------------------------------------------------------------------------

    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        comment="Human-readable collection name; unique within a tenant",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description",
    )
    is_default: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default=text("false"),
        comment=(
            "When TRUE, CLI uses this collection implicitly for deploy. "
            "At most one TRUE per tenant; enforced at application layer."
        ),
    )
    created_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="User ID or 'system'; NULL until PRD-2 AuthContext is available",
    )

    # -------------------------------------------------------------------------
    # Ownership and visibility  (DB-003)
    # -------------------------------------------------------------------------

    owner_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="UUID of the user who owns this collection; NULL = system/unowned",
    )
    owner_type: Mapped[Optional[str]] = mapped_column(
        String(20),
        nullable=True,
        default="user",
        comment="Owner type; stores OwnerType enum value, e.g. 'user' or 'team'",
    )
    visibility: Mapped[Optional[str]] = mapped_column(
        String(20),
        nullable=True,
        default="private",
        comment="Visibility level; stores Visibility enum value, e.g. 'private', 'internal', 'public'",
    )
    enforce_override: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
        comment="When True, governance policy overrides apply to this collection regardless of owner settings",
    )
    is_global_collection: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
        comment=(
            "When True, marks this collection as enterprise-wide; "
            "it is automatically distributed to all users and teams in the tenant"
        ),
    )
    auto_bind: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
        comment=(
            "When True, new users and teams automatically receive this collection "
            "on Day-0 provisioning"
        ),
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    # ENT-1.5 defines EnterpriseCollectionArtifact.  The string reference
    # resolves at mapper configuration time; no circular-import risk.
    memberships: Mapped[List["EnterpriseCollectionArtifact"]] = relationship(
        "EnterpriseCollectionArtifact",
        back_populates="collection",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseCollectionArtifact.order_index",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Uniqueness: one name per tenant
        UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_enterprise_collections_tenant_name",
        ),
        # Guard against empty or overlong names (mirrors DDL CHECK)
        CheckConstraint(
            "length(name) > 0 AND length(name) <= 255",
            name="ck_enterprise_collections_name_length",
        ),
        # B-tree on tenant for the mandatory per-query tenant filter
        # (the simple index=True on tenant_id above covers this, but we add an
        # explicit named index here to match the migration-generated name)
        Index(
            "idx_enterprise_collections_tenant_id",
            "tenant_id",
        ),
        # B-tree on (tenant_id, name) for alphabetical listing within a tenant
        Index(
            "idx_enterprise_collections_tenant_name",
            "tenant_id",
            "name",
        ),
        # Partial B-tree: accelerates the single-row "which collection is
        # default?" query without indexing the overwhelming majority of rows
        # where is_default = FALSE.  postgresql_where is a no-op on non-PG
        # dialects (SQLite in tests) and will be ignored gracefully.
        Index(
            "idx_enterprise_collections_tenant_default",
            "tenant_id",
            "is_default",
            postgresql_where=text("is_default = TRUE"),
        ),
        # B-tree: owner lookup — find all collections owned by a given user (DB-003)
        Index(
            "ix_enterprise_collections_owner_id",
            "owner_id",
        ),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"<EnterpriseCollection("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"is_default={self.is_default!r}"
            f")>"
        )


# =============================================================================
# EnterpriseCollectionArtifact model  (ENT-1.5)
# =============================================================================


class EnterpriseCollectionArtifact(EnterpriseBase):
    """Junction table linking enterprise collections to enterprise artifacts.

    Each row represents the membership of one artifact in one collection,
    carrying an ``order_index`` so that artifacts can be presented in a
    deterministic, user-controlled order within a collection.

    Cascade behaviour:
        Deleting an ``EnterpriseCollection`` cascades to all of its membership
        rows (ON DELETE CASCADE on ``collection_id``).  Likewise, deleting an
        ``EnterpriseArtifact`` cascades to all membership rows that reference it
        (ON DELETE CASCADE on ``artifact_id``).  No orphaned join rows can exist
        after either parent is removed.

    Unique membership invariant:
        ``uq_collection_artifacts_collection_artifact`` ensures that the same
        artifact cannot be added to the same collection twice.

    Ordering:
        ``order_index`` is a 0-based integer managed by the application.  The
        ``EnterpriseCollection.memberships`` relationship is ordered by this
        column ascending so callers receive a stable sequence without an
        explicit ORDER BY.

    Attributes:
        id:            UUID primary key, server-generated via gen_random_uuid().
        collection_id: FK → enterprise_collections.id, NOT NULL, CASCADE.
        artifact_id:   FK → enterprise_artifacts.id, NOT NULL, CASCADE.
        order_index:   Ordering position within the collection; default 0.
        added_at:      Timezone-aware timestamp when artifact was added.
        added_by:      User ID or "system"; NULL until PRD-2 AuthContext.
        collection:    Many-to-one back-reference to EnterpriseCollection.
        artifact:      Many-to-one back-reference to EnterpriseArtifact.

    Constraints:
        uq_collection_artifacts_collection_artifact:
            UNIQUE (collection_id, artifact_id)

    Indexes:
        idx_ent_ca_collection_id:   (collection_id)
        idx_ent_ca_artifact_id:     (artifact_id)
        idx_ent_ca_collection_order: (collection_id, order_index)

    Schema reference:
        docs/dev/architecture/enterprise-db-schema-v1.md §2.4
    """

    __tablename__ = "enterprise_collection_artifacts"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique join-row identifier",
    )

    # -------------------------------------------------------------------------
    # Foreign keys
    # -------------------------------------------------------------------------

    collection_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("enterprise_collections.id", ondelete="CASCADE"),
        nullable=False,
        comment="Parent collection; cascade-deletes this row when collection is removed",
    )
    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("enterprise_artifacts.id", ondelete="CASCADE"),
        nullable=False,
        comment="Member artifact; cascade-deletes this row when artifact is removed",
    )

    # -------------------------------------------------------------------------
    # Ordering and audit
    # -------------------------------------------------------------------------

    order_index: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default=text("0"),
        comment="0-based position of the artifact within the collection; lower = earlier",
    )
    added_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware timestamp when the artifact was added to the collection",
    )
    added_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="User ID or 'system'; NULL until PRD-2 AuthContext is available",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    collection: Mapped["EnterpriseCollection"] = relationship(
        "EnterpriseCollection",
        back_populates="memberships",
        lazy="joined",
    )
    artifact: Mapped["EnterpriseArtifact"] = relationship(
        "EnterpriseArtifact",
        back_populates="collection_memberships",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Uniqueness: one artifact per collection (no duplicates)
        UniqueConstraint(
            "collection_id",
            "artifact_id",
            name="uq_collection_artifacts_collection_artifact",
        ),
        # B-tree: primary filter when loading a collection's members
        Index(
            "idx_ent_ca_collection_id",
            "collection_id",
        ),
        # B-tree: reverse lookup — which collections contain a given artifact?
        Index(
            "idx_ent_ca_artifact_id",
            "artifact_id",
        ),
        # B-tree composite: ordered membership scan within a single collection
        # (used by EnterpriseCollection.memberships order_by clause)
        Index(
            "idx_ent_ca_collection_order",
            "collection_id",
            "order_index",
        ),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseCollectionArtifact."""
        return (
            f"<EnterpriseCollectionArtifact("
            f"id={self.id!r}, "
            f"collection_id={self.collection_id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"order_index={self.order_index!r}"
            f")>"
        )


# =============================================================================
# EnterpriseCollectionBinding model  (EG-2.6 Auto-bind)
# =============================================================================


class EnterpriseCollectionBinding(EnterpriseBase):
    """Binding record linking a user or team entity to a global enterprise collection.

    When a new User or Team is provisioned under a tenant, the auto-bind service
    creates read-only binding rows for every active global enterprise collection
    (is_global_collection=True AND auto_bind=True).  This ensures Day-0 inheritance
    of enterprise artifacts without requiring manual configuration.

    The ``is_readonly`` flag controls who may remove the binding:
        - read-only bindings (auto-created) require system_admin privilege to unbind
        - non-read-only bindings can be removed by the entity owner or team admin

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.

    Attributes:
        id:                UUID primary key, server-generated via gen_random_uuid().
        tenant_id:         Tenant scope; every query MUST filter by this column.
        collection_id:     FK → enterprise_collections.id, NOT NULL, CASCADE.
        bound_entity_type: Type of the bound entity: 'user' or 'team'.
        bound_entity_id:   UUID of the bound user or team entity.
        is_readonly:       When TRUE only a system admin may remove this binding.
        created_at:        Timezone-aware creation timestamp.
        collection:        Many-to-one back-reference to EnterpriseCollection.

    Constraints:
        uq_ecb_tenant_collection_entity:
            UNIQUE (tenant_id, collection_id, bound_entity_type, bound_entity_id)
        ck_ecb_bound_entity_type:
            bound_entity_type IN ('user', 'team')

    Indexes:
        idx_ecb_tenant_entity:   (tenant_id, bound_entity_type, bound_entity_id)
        idx_ecb_collection_id:   (collection_id)

    Schema reference:
        Migration ent_009_enterprise_collection_bindings
        skillmeat/core/auth/auto_bind.py
    """

    __tablename__ = "enterprise_collection_bindings"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique binding identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Foreign keys
    # -------------------------------------------------------------------------

    collection_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("enterprise_collections.id", ondelete="CASCADE"),
        nullable=False,
        comment="Collection being bound; cascades on collection deletion",
    )

    # -------------------------------------------------------------------------
    # Binding target
    # -------------------------------------------------------------------------

    bound_entity_type: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        comment="Type of the bound entity: 'user' or 'team'",
    )
    bound_entity_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="UUID of the bound user or team entity",
    )

    # -------------------------------------------------------------------------
    # Access control
    # -------------------------------------------------------------------------

    is_readonly: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default=text("true"),
        comment=(
            "When TRUE only a system administrator may remove this binding; "
            "auto-created bindings are always read-only"
        ),
    )

    # -------------------------------------------------------------------------
    # Timestamps
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    collection: Mapped["EnterpriseCollection"] = relationship(
        "EnterpriseCollection",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Uniqueness: one binding per (tenant, collection, entity-type, entity)
        UniqueConstraint(
            "tenant_id",
            "collection_id",
            "bound_entity_type",
            "bound_entity_id",
            name="uq_ecb_tenant_collection_entity",
        ),
        # CHECK guard for bound_entity_type values
        CheckConstraint(
            "bound_entity_type IN ('user', 'team')",
            name="ck_ecb_bound_entity_type",
        ),
        # Index: accelerate "which collections is this entity bound to?"
        Index(
            "idx_ecb_tenant_entity",
            "tenant_id",
            "bound_entity_type",
            "bound_entity_id",
        ),
        # Index: accelerate "which entities are bound to this collection?"
        Index(
            "idx_ecb_collection_id",
            "collection_id",
        ),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseCollectionBinding."""
        return (
            f"<EnterpriseCollectionBinding("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"collection_id={self.collection_id!r}, "
            f"bound_entity_type={self.bound_entity_type!r}, "
            f"bound_entity_id={self.bound_entity_id!r}, "
            f"is_readonly={self.is_readonly!r}"
            f")>"
        )


# =============================================================================
# EnterpriseUser model  (AAA/RBAC Foundation — PRD-2, DB-001)
# =============================================================================


class EnterpriseUser(EnterpriseBase):
    """Enterprise user account scoped to a single tenant.

    Stores the identity and system-level role for each user within a tenant.
    The ``clerk_user_id`` column provides the mapping to the Clerk-managed
    external identity; it is nullable so that service accounts and seed rows
    can be created before Clerk integration is active.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.  The repository layer (PRD-2 AAA repositories) enforces this
        structurally via a ``TenantScopedRepository`` base class.

    Attributes:
        id:            UUID PK, server-generated via gen_random_uuid().
        tenant_id:     Tenant scope; every query MUST filter by this column.
        clerk_user_id: External Clerk user identifier; unique within a tenant
                       when set.
        email:         User email address; unique within a tenant when set.
        display_name:  Optional human-readable display name.
        role:          System-wide role string; stores a ``UserRole`` enum value.
                       Defaults to ``"viewer"``.
        is_active:     Soft-delete flag.
        created_at:    Timezone-aware creation timestamp (server default: now()).
        updated_at:    Timezone-aware last-modified timestamp (app-managed).
        created_by:    User ID or ``"system"``; NULL until AuthContext is fully
                       wired.
        team_memberships: Back-reference to ``EnterpriseTeamMember`` rows.

    Constraints:
        uq_enterprise_users_tenant_clerk: UNIQUE (tenant_id, clerk_user_id)
        uq_enterprise_users_tenant_email: UNIQUE (tenant_id, email)

    Indexes:
        idx_enterprise_users_tenant_id:    (tenant_id)
        idx_enterprise_users_tenant_clerk: (tenant_id, clerk_user_id)
        idx_enterprise_users_tenant_email: (tenant_id, email)
        idx_enterprise_users_tenant_role:  (tenant_id, role)

    Schema reference:
        docs/dev/architecture/enterprise-db-schema-v1.md §3 (PRD-2)
    """

    __tablename__ = "enterprise_users"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique user identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # External identity
    # -------------------------------------------------------------------------

    clerk_user_id: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment=(
            "Clerk user_id for the external authentication provider. "
            "NULL for service accounts or before Clerk integration is active. "
            "Unique within a tenant (uq_enterprise_users_tenant_clerk)."
        ),
    )

    # -------------------------------------------------------------------------
    # Contact
    # -------------------------------------------------------------------------

    email: Mapped[Optional[str]] = mapped_column(
        String(320),
        nullable=True,
        comment=(
            "User email address. "
            "Unique within a tenant (uq_enterprise_users_tenant_email) when set."
        ),
    )
    display_name: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="Human-readable display name shown in the UI",
    )

    # -------------------------------------------------------------------------
    # Role
    # -------------------------------------------------------------------------

    role: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="viewer",
        server_default=text("'viewer'"),
        comment=(
            "System-wide role; one of UserRole enum values "
            "(viewer, team_member, team_admin, system_admin)"
        ),
    )

    # -------------------------------------------------------------------------
    # Soft-delete
    # -------------------------------------------------------------------------

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default=text("true"),
        comment="Soft-delete: False = account disabled, row retained for audit",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )
    created_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="User ID or 'system'; NULL until PRD-2 AuthContext is fully wired",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    team_memberships: Mapped[List["EnterpriseTeamMember"]] = relationship(
        "EnterpriseTeamMember",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Unique: one account per Clerk user_id per tenant
        UniqueConstraint(
            "tenant_id",
            "clerk_user_id",
            name="uq_enterprise_users_tenant_clerk",
        ),
        # Unique: one account per email address per tenant
        UniqueConstraint(
            "tenant_id",
            "email",
            name="uq_enterprise_users_tenant_email",
        ),
        # B-tree: mandatory per-tenant filter (every query starts here)
        Index(
            "idx_enterprise_users_tenant_id",
            "tenant_id",
        ),
        # B-tree: Clerk user_id lookup during authentication
        Index(
            "idx_enterprise_users_tenant_clerk",
            "tenant_id",
            "clerk_user_id",
        ),
        # B-tree: email lookup for invitation and login flows
        Index(
            "idx_enterprise_users_tenant_email",
            "tenant_id",
            "email",
        ),
        # B-tree: role-filtered listing (e.g. "show all system admins")
        Index(
            "idx_enterprise_users_tenant_role",
            "tenant_id",
            "role",
        ),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseUser."""
        return (
            f"<EnterpriseUser("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"email={self.email!r}, "
            f"role={self.role!r}, "
            f"is_active={self.is_active!r}"
            f")>"
        )


# =============================================================================
# EnterpriseTeam model  (AAA/RBAC Foundation — PRD-2, DB-001)
# =============================================================================


class EnterpriseTeam(EnterpriseBase):
    """Named group of enterprise users scoped to a single tenant.

    Teams allow multiple users to share ownership of artifacts and deployment
    sets within the same tenant.  One team name is unique per tenant.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:          UUID PK, server-generated via gen_random_uuid().
        tenant_id:   Tenant scope.
        name:        Human-readable team name; unique within a tenant.
        description: Optional free-text description.
        is_active:   Soft-delete flag.
        created_at:  Timezone-aware creation timestamp.
        updated_at:  Timezone-aware last-modified timestamp.
        created_by:  User ID or ``"system"``; NULL until AuthContext is wired.
        members:     Back-reference to ``EnterpriseTeamMember`` rows.

    Constraints:
        uq_enterprise_teams_tenant_name: UNIQUE (tenant_id, name)

    Indexes:
        idx_enterprise_teams_tenant_id:   (tenant_id)
        idx_enterprise_teams_tenant_name: (tenant_id, name)

    Schema reference:
        docs/dev/architecture/enterprise-db-schema-v1.md §3 (PRD-2)
    """

    __tablename__ = "enterprise_teams"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique team identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Core metadata
    # -------------------------------------------------------------------------

    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        comment="Human-readable team name; unique within a tenant",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of the team's purpose",
    )

    # -------------------------------------------------------------------------
    # Soft-delete
    # -------------------------------------------------------------------------

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default=text("true"),
        comment="Soft-delete: False = team dissolved, row retained for audit",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated on every write",
    )
    created_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="User ID or 'system'; NULL until PRD-2 AuthContext is fully wired",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    members: Mapped[List["EnterpriseTeamMember"]] = relationship(
        "EnterpriseTeamMember",
        back_populates="team",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Unique: one team name per tenant
        UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_enterprise_teams_tenant_name",
        ),
        # B-tree: mandatory per-tenant filter
        Index(
            "idx_enterprise_teams_tenant_id",
            "tenant_id",
        ),
        # B-tree: name lookup within a tenant
        Index(
            "idx_enterprise_teams_tenant_name",
            "tenant_id",
            "name",
        ),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseTeam."""
        return (
            f"<EnterpriseTeam("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"is_active={self.is_active!r}"
            f")>"
        )


# =============================================================================
# EnterpriseTeamMember model  (AAA/RBAC Foundation — PRD-2, DB-001)
# =============================================================================


class EnterpriseTeamMember(EnterpriseBase):
    """Junction table recording an enterprise user's membership in a team.

    Each row grants one user membership in one team at a specific team-level
    role.  Both ``team_id`` and ``user_id`` carry ``ON DELETE CASCADE`` foreign
    keys so orphaned membership rows are automatically removed when either the
    team or the user is deleted.

    ``tenant_id`` is denormalized from the parent ``EnterpriseTeam`` row for
    query performance — every cross-membership query can be filtered by tenant
    without joining back to the teams table.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:         UUID PK, server-generated via gen_random_uuid().
        tenant_id:  Denormalized tenant scope for efficient querying.
        team_id:    FK → enterprise_teams.id, CASCADE on delete.
        user_id:    FK → enterprise_users.id, CASCADE on delete.
        role:       Team-level role string; stores a ``UserRole`` enum value.
                    Defaults to ``"team_member"``.
        joined_at:  UTC timestamp when the user joined (immutable after insert).
        created_by: User ID or ``"system"``; NULL until AuthContext is wired.
        team:       Many-to-one back-reference to ``EnterpriseTeam``.
        user:       Many-to-one back-reference to ``EnterpriseUser``.

    Constraints:
        uq_enterprise_team_members_tenant_team_user:
            UNIQUE (tenant_id, team_id, user_id) — one membership per user per team
            per tenant.

    Indexes:
        idx_enterprise_team_members_tenant_id:   (tenant_id)
        idx_enterprise_team_members_team_id:     (team_id)
        idx_enterprise_team_members_user_id:     (user_id)

    Schema reference:
        docs/dev/architecture/enterprise-db-schema-v1.md §3 (PRD-2)
    """

    __tablename__ = "enterprise_team_members"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique membership row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment=(
            "Denormalized tenant scope for query performance; "
            "must equal the parent team's tenant_id — validated at write time"
        ),
    )

    # -------------------------------------------------------------------------
    # Foreign keys
    # -------------------------------------------------------------------------

    team_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_teams.id",
            ondelete="CASCADE",
            name="fk_enterprise_team_members_team_id",
        ),
        nullable=False,
        comment="Parent team; cascade-deletes this membership when team is removed",
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_users.id",
            ondelete="CASCADE",
            name="fk_enterprise_team_members_user_id",
        ),
        nullable=False,
        comment="Member user; cascade-deletes this membership when user is removed",
    )

    # -------------------------------------------------------------------------
    # Team-level role
    # -------------------------------------------------------------------------

    role: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="team_member",
        server_default=text("'team_member'"),
        comment="Role within the team; one of team_admin, team_member",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    # joined_at is intentionally NOT an onupdate column — join date is immutable
    joined_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware timestamp when the user joined the team; immutable",
    )
    created_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="User ID or 'system'; NULL until PRD-2 AuthContext is fully wired",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    team: Mapped["EnterpriseTeam"] = relationship(
        "EnterpriseTeam",
        back_populates="members",
        lazy="joined",
    )
    user: Mapped["EnterpriseUser"] = relationship(
        "EnterpriseUser",
        back_populates="team_memberships",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Unique: one membership row per (tenant, team, user) triple
        UniqueConstraint(
            "tenant_id",
            "team_id",
            "user_id",
            name="uq_enterprise_team_members_tenant_team_user",
        ),
        # B-tree: mandatory per-tenant filter on cross-team membership queries
        Index(
            "idx_enterprise_team_members_tenant_id",
            "tenant_id",
        ),
        # B-tree: list all members of a given team
        Index(
            "idx_enterprise_team_members_team_id",
            "team_id",
        ),
        # B-tree: reverse lookup — which teams is a user in?
        Index(
            "idx_enterprise_team_members_user_id",
            "user_id",
        ),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseTeamMember."""
        return (
            f"<EnterpriseTeamMember("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"team_id={self.team_id!r}, "
            f"user_id={self.user_id!r}, "
            f"role={self.role!r}"
            f")>"
        )


# =============================================================================
# EnterpriseTag model  (ENT2-2.1)
# =============================================================================


class EnterpriseTag(EnterpriseBase):
    """Tenant-scoped label that can be applied to enterprise artifacts.

    Tags are lightweight string identifiers (with an optional display colour)
    used to categorise and filter artifacts within a tenant.  The ``slug``
    column provides a URL-safe normalised identifier derived from ``name`` at
    write time by the repository layer.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:         UUID PK, client-generated via uuid.uuid4.
        tenant_id:  Tenant scope; every query MUST filter by this column.
        name:       Human-readable label, e.g. "frontend", "experimental".
        slug:       URL-safe normalised form of name, e.g. "frontend".
        color:      Optional hex or CSS colour for UI display.
        created_at: Timezone-aware creation timestamp.
        updated_at: Timezone-aware last-modified timestamp.
        artifact_tags: Back-reference to EnterpriseArtifactTag join rows.

    Constraints:
        uq_enterprise_tags_tenant_slug: UNIQUE (tenant_id, slug)

    Indexes:
        idx_enterprise_tags_tenant_id:   (tenant_id)
        idx_enterprise_tags_tenant_slug: (tenant_id, slug)
    """

    __tablename__ = "enterprise_tags"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique tag identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable tag label, e.g. 'frontend', 'experimental'",
    )
    slug: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="URL-safe normalised form of name; unique within a tenant",
    )
    color: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional hex or CSS colour string for UI display, e.g. '#3B82F6'",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    artifact_tags: Mapped[List["EnterpriseArtifactTag"]] = relationship(
        "EnterpriseArtifactTag",
        back_populates="tag",
        cascade="all, delete-orphan",
        lazy="select",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "slug",
            name="uq_enterprise_tags_tenant_slug",
        ),
        Index("idx_enterprise_tags_tenant_id", "tenant_id"),
        Index("idx_enterprise_tags_tenant_slug", "tenant_id", "slug"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseTag."""
        return (
            f"<EnterpriseTag("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"slug={self.slug!r}"
            f")>"
        )


# =============================================================================
# EnterpriseArtifactTag model  (ENT2-2.1 — join table)
# =============================================================================


class EnterpriseArtifactTag(EnterpriseBase):
    """Junction table associating enterprise artifacts with tags.

    Each row records that one artifact belongs to one tag within a tenant.
    Both FK columns carry ``ON DELETE CASCADE`` so orphaned rows are removed
    automatically when either the artifact or the tag is deleted.

    ``tenant_id`` is denormalized for query performance and to support
    tenant-scoped bulk queries without joining parent tables.

    Constraints:
        uq_enterprise_artifact_tags_tenant_tag_artifact:
            UNIQUE (tenant_id, tag_id, artifact_uuid) — one membership per pair

    Indexes:
        idx_ent_atag_tenant_id:    (tenant_id)
        idx_ent_atag_tag_id:       (tag_id)
        idx_ent_atag_artifact_uuid: (artifact_uuid)
    """

    __tablename__ = "enterprise_artifact_tags"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique join-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalized tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    tag_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_tags.id",
            ondelete="CASCADE",
            name="fk_enterprise_artifact_tags_tag_id",
        ),
        nullable=False,
        comment="Parent tag; cascade-deletes this row when tag is removed",
    )
    artifact_uuid: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_artifact_tags_artifact_uuid",
        ),
        nullable=False,
        comment="Tagged artifact; cascade-deletes this row when artifact is removed",
    )

    tag: Mapped["EnterpriseTag"] = relationship(
        "EnterpriseTag",
        back_populates="artifact_tags",
        lazy="joined",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "tag_id",
            "artifact_uuid",
            name="uq_enterprise_artifact_tags_tenant_tag_artifact",
        ),
        Index("idx_ent_atag_tenant_id", "tenant_id"),
        Index("idx_ent_atag_tag_id", "tag_id"),
        Index("idx_ent_atag_artifact_uuid", "artifact_uuid"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseArtifactTag."""
        return (
            f"<EnterpriseArtifactTag("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"tag_id={self.tag_id!r}, "
            f"artifact_uuid={self.artifact_uuid!r}"
            f")>"
        )


# =============================================================================
# EnterpriseGroup model  (ENT2-2.1)
# =============================================================================


class EnterpriseGroup(EnterpriseBase):
    """Named grouping of artifacts within a collection, scoped to a tenant.

    Groups allow users to organise artifacts into named sections within a
    collection.  The ``position`` column controls display order.  An optional
    ``collection_id`` FK ties a group to a specific collection; NULL means the
    group is collection-agnostic.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:            UUID PK.
        tenant_id:     Tenant scope.
        name:          Human-readable group name.
        collection_id: Optional FK to enterprise_collections.id.
        description:   Optional free-text description.
        position:      Display order within the collection; lower = earlier.
        created_at:    Timezone-aware creation timestamp.
        updated_at:    Timezone-aware last-modified timestamp.
        group_artifacts: Back-reference to EnterpriseGroupArtifact join rows.

    Indexes:
        idx_enterprise_groups_tenant_id:         (tenant_id)
        idx_enterprise_groups_collection_id:     (collection_id)
        idx_enterprise_groups_tenant_collection: (tenant_id, collection_id)
    """

    __tablename__ = "enterprise_groups"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique group identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Human-readable group name displayed in the UI",
    )
    collection_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_collections.id",
            ondelete="SET NULL",
            name="fk_enterprise_groups_collection_id",
        ),
        nullable=True,
        comment="Optional parent collection; NULL = collection-agnostic group",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of the group",
    )
    position: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        default=0,
        server_default=text("0"),
        comment="Display order within the collection; lower = earlier",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    group_artifacts: Mapped[List["EnterpriseGroupArtifact"]] = relationship(
        "EnterpriseGroupArtifact",
        back_populates="group",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseGroupArtifact.position",
    )

    __table_args__ = (
        Index("idx_enterprise_groups_tenant_id", "tenant_id"),
        Index("idx_enterprise_groups_collection_id", "collection_id"),
        Index(
            "idx_enterprise_groups_tenant_collection",
            "tenant_id",
            "collection_id",
        ),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseGroup."""
        return (
            f"<EnterpriseGroup("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"collection_id={self.collection_id!r}"
            f")>"
        )


# =============================================================================
# EnterpriseGroupArtifact model  (ENT2-2.1 — join table)
# =============================================================================


class EnterpriseGroupArtifact(EnterpriseBase):
    """Junction table recording artifact membership within an enterprise group.

    Each row places one artifact in one group at an explicit ``position``.
    Both FK columns carry ``ON DELETE CASCADE`` so orphaned rows are removed
    automatically when either parent is deleted.

    ``tenant_id`` is denormalized for per-tenant bulk queries.

    Constraints:
        uq_enterprise_group_artifacts_tenant_group_artifact:
            UNIQUE (tenant_id, group_id, artifact_uuid)

    Indexes:
        idx_ent_ga_tenant_id:    (tenant_id)
        idx_ent_ga_group_id:     (group_id)
        idx_ent_ga_artifact_uuid: (artifact_uuid)
        idx_ent_ga_group_position: (group_id, position)
    """

    __tablename__ = "enterprise_group_artifacts"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique join-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalized tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    group_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_groups.id",
            ondelete="CASCADE",
            name="fk_enterprise_group_artifacts_group_id",
        ),
        nullable=False,
        comment="Parent group; cascade-deletes this row when group is removed",
    )
    artifact_uuid: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_group_artifacts_artifact_uuid",
        ),
        nullable=False,
        comment="Member artifact; cascade-deletes this row when artifact is removed",
    )
    position: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        default=0,
        server_default=text("0"),
        comment="Display order within the group; lower = earlier",
    )

    group: Mapped["EnterpriseGroup"] = relationship(
        "EnterpriseGroup",
        back_populates="group_artifacts",
        lazy="joined",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "group_id",
            "artifact_uuid",
            name="uq_enterprise_group_artifacts_tenant_group_artifact",
        ),
        Index("idx_ent_ga_tenant_id", "tenant_id"),
        Index("idx_ent_ga_group_id", "group_id"),
        Index("idx_ent_ga_artifact_uuid", "artifact_uuid"),
        Index("idx_ent_ga_group_position", "group_id", "position"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseGroupArtifact."""
        return (
            f"<EnterpriseGroupArtifact("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"group_id={self.group_id!r}, "
            f"artifact_uuid={self.artifact_uuid!r}, "
            f"position={self.position!r}"
            f")>"
        )


# =============================================================================
# EnterpriseSettings model  (ENT2-2.1 — one row per tenant)
# =============================================================================


class EnterpriseSettings(EnterpriseBase):
    """Per-tenant settings record — exactly one row per tenant.

    Stores tenant-level configuration that in local mode is persisted to
    ``~/.skillmeat/config.toml``.  In enterprise mode all settings are stored
    in this DB table so that each tenant has independent configuration.

    The ``extra`` JSONB column provides forward-compatible extension for
    settings not yet promoted to first-class columns.

    Tenant isolation invariant:
        ``tenant_id`` is UNIQUE — one row per tenant enforced at DB level.
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:               UUID PK.
        tenant_id:        Tenant scope; UNIQUE constraint ensures one row per tenant.
        github_token:     Encrypted or plaintext GitHub API token for this tenant.
        collection_path:  Override path for the tenant's local collection root.
        default_scope:    Default artifact scope ('user' or 'local').
        edition:          Active edition string, e.g. 'enterprise'.
        indexing_mode:    Indexing mode for artifact search.
        extra:            JSONB bag for forward-compatible extension.
        updated_at:       Timezone-aware last-modified timestamp.

    Constraints:
        uq_enterprise_settings_tenant: UNIQUE (tenant_id)

    Indexes:
        idx_enterprise_settings_tenant_id: (tenant_id)
    """

    __tablename__ = "enterprise_settings"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique settings-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment=(
            "Tenant scope; UNIQUE constraint ensures exactly one settings row per tenant. "
            "Every query MUST include WHERE tenant_id = ?"
        ),
    )
    github_token: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="GitHub API token for this tenant (may be encrypted at rest)",
    )
    collection_path: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Override path for the tenant's local collection root directory",
    )
    default_scope: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Default artifact scope when not specified; 'user' or 'local'",
    )
    edition: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Active edition string for this tenant, e.g. 'enterprise'",
    )
    indexing_mode: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Artifact indexing mode; controls which indexer strategy is used",
    )
    extra: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB bag for forward-compatible extension; initialized to empty object",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            name="uq_enterprise_settings_tenant",
        ),
        Index("idx_enterprise_settings_tenant_id", "tenant_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseSettings."""
        return (
            f"<EnterpriseSettings("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"edition={self.edition!r}"
            f")>"
        )


# =============================================================================
# EnterpriseEntityTypeConfig model  (ENT2-2.1)
# =============================================================================


class EnterpriseEntityTypeConfig(EnterpriseBase):
    """Display and behaviour configuration for a specific artifact entity type.

    Stores per-tenant overrides for how each artifact type (skill, command,
    agent, etc.) is displayed and labelled in the UI.  System-supplied defaults
    are rows where ``is_system = True``; tenant customisations use
    ``is_system = False``.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:           UUID PK.
        tenant_id:    Tenant scope.
        entity_type:  Artifact type identifier, e.g. 'skill', 'command'.
        display_name: Human-readable label for the type in the UI.
        description:  Optional description shown in type selectors.
        icon:         Optional icon identifier or URL.
        color:        Optional hex or CSS colour for UI badges.
        is_system:    True = shipped default; False = tenant customisation.

    Constraints:
        uq_enterprise_entity_type_configs_tenant_type:
            UNIQUE (tenant_id, entity_type)

    Indexes:
        idx_enterprise_etc_tenant_id:   (tenant_id)
        idx_enterprise_etc_tenant_type: (tenant_id, entity_type)
    """

    __tablename__ = "enterprise_entity_type_configs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique config row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    entity_type: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Artifact type identifier, e.g. 'skill', 'command', 'agent'",
    )
    display_name: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Human-readable label for this type in the UI",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional description shown in type selector dropdowns",
    )
    icon: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional icon identifier or URL for UI display",
    )
    color: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional hex or CSS colour for type badges in the UI",
    )
    is_system: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        default=False,
        server_default=text("false"),
        comment="True = shipped default config; False = tenant override",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "entity_type",
            name="uq_enterprise_entity_type_configs_tenant_type",
        ),
        Index("idx_enterprise_etc_tenant_id", "tenant_id"),
        Index("idx_enterprise_etc_tenant_type", "tenant_id", "entity_type"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseEntityTypeConfig."""
        return (
            f"<EnterpriseEntityTypeConfig("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"entity_type={self.entity_type!r}, "
            f"is_system={self.is_system!r}"
            f")>"
        )


# =============================================================================
# EnterpriseEntityCategory model  (ENT2-2.1)
# =============================================================================


class EnterpriseEntityCategory(EnterpriseBase):
    """Category taxonomy entry for classifying context entities.

    Categories group context entities (CLAUDE.md files, rule files, spec files,
    etc.) into named buckets for filtering and display.  Each category optionally
    targets a specific ``entity_type`` and ``platform``.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:          UUID PK.
        tenant_id:   Tenant scope.
        name:        Human-readable category name.
        slug:        URL-safe normalised identifier; unique per tenant.
        entity_type: Optional entity type this category applies to.
        description: Optional free-text description.
        color:       Optional hex or CSS colour for UI display.
        platform:    Optional platform filter, e.g. 'claude', 'cursor'.
        sort_order:  Display order; lower = earlier.

    Constraints:
        uq_enterprise_entity_categories_tenant_slug: UNIQUE (tenant_id, slug)

    Indexes:
        idx_enterprise_ec_tenant_id:   (tenant_id)
        idx_enterprise_ec_tenant_slug: (tenant_id, slug)
        idx_enterprise_ec_entity_type: (tenant_id, entity_type)
    """

    __tablename__ = "enterprise_entity_categories"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique category identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable category name displayed in the UI",
    )
    slug: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="URL-safe normalised identifier; unique within a tenant",
    )
    entity_type: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional entity type this category applies to, e.g. 'rule_file'",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of the category",
    )
    color: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional hex or CSS colour for category badges in the UI",
    )
    platform: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional platform filter, e.g. 'claude', 'cursor', 'windsurf'",
    )
    sort_order: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        default=0,
        server_default=text("0"),
        comment="Display order; lower = earlier",
    )

    entity_category_associations: Mapped[
        List["EnterpriseEntityCategoryAssociation"]
    ] = relationship(
        "EnterpriseEntityCategoryAssociation",
        back_populates="category",
        cascade="all, delete-orphan",
        lazy="select",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "slug",
            name="uq_enterprise_entity_categories_tenant_slug",
        ),
        Index("idx_enterprise_ec_tenant_id", "tenant_id"),
        Index("idx_enterprise_ec_tenant_slug", "tenant_id", "slug"),
        Index("idx_enterprise_ec_entity_type", "tenant_id", "entity_type"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseEntityCategory."""
        return (
            f"<EnterpriseEntityCategory("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"slug={self.slug!r}"
            f")>"
        )


# =============================================================================
# EnterpriseContextEntity model  (ENT2-2.2)
# =============================================================================


class EnterpriseContextEntity(EnterpriseBase):
    """Tenant-scoped context entity stored in the enterprise database.

    Context entities represent files like CLAUDE.md, rule files, spec files, and
    other configuration entities that the Claude Code agent loads at runtime.
    In local mode these are stored as ``Artifact`` rows in SQLite; in enterprise
    mode they are stored here with richer metadata and multi-tenant isolation.

    The ``deploy()`` operation writes content to a caller-supplied
    ``project_path`` on the local filesystem; all other operations are pure DB.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:               UUID PK.
        tenant_id:        Tenant scope.
        name:             Human-readable entity name, e.g. 'CLAUDE.md'.
        entity_type:      Entity type discriminator, e.g. 'context_file', 'rule_file'.
        content:          Entity file content; NULL until content is loaded.
        path_pattern:     Target path pattern for deployment, e.g. '.claude/rules/*.md'.
        description:      Optional free-text description.
        category:         Optional category label string.
        auto_load:        Whether this entity should be auto-loaded by the agent.
        version:          Optional version label.
        target_platforms: JSONB array of platform identifiers, e.g. ['claude', 'cursor'].
        created_at:       Timezone-aware creation timestamp.
        updated_at:       Timezone-aware last-modified timestamp.
        category_associations: Back-reference to EnterpriseEntityCategoryAssociation rows.

    Indexes:
        idx_enterprise_ce_tenant_id:      (tenant_id)
        idx_enterprise_ce_tenant_type:    (tenant_id, entity_type)
        idx_enterprise_ce_tenant_autoload: (tenant_id, auto_load) WHERE auto_load = TRUE
    """

    __tablename__ = "enterprise_context_entities"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique context entity identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable entity name, e.g. 'CLAUDE.md', 'debugging-rule'",
    )
    entity_type: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Entity type discriminator, e.g. 'context_file', 'rule_file', 'spec_file'",
    )
    content: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Entity file content; NULL when only metadata has been loaded",
    )
    path_pattern: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Target path pattern for deployment, e.g. '.claude/rules/*.md'",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of this entity's purpose",
    )
    category: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional category label string; use category_associations for structured FK refs",
    )
    auto_load: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        default=False,
        server_default=text("false"),
        comment="When TRUE, the agent should auto-load this entity at startup",
    )
    version: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional version label, e.g. 'v1.0.0' or a SHA prefix",
    )
    target_platforms: Mapped[Optional[List[str]]] = mapped_column(
        JSONB,
        nullable=True,
        comment="JSONB array of platform identifiers this entity targets, e.g. ['claude', 'cursor']",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    category_associations: Mapped[List["EnterpriseEntityCategoryAssociation"]] = (
        relationship(
            "EnterpriseEntityCategoryAssociation",
            back_populates="entity",
            cascade="all, delete-orphan",
            lazy="select",
            order_by="EnterpriseEntityCategoryAssociation.position",
        )
    )

    __table_args__ = (
        Index("idx_enterprise_ce_tenant_id", "tenant_id"),
        Index("idx_enterprise_ce_tenant_type", "tenant_id", "entity_type"),
        Index(
            "idx_enterprise_ce_tenant_autoload",
            "tenant_id",
            "auto_load",
            postgresql_where=text("auto_load = TRUE"),
        ),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseContextEntity."""
        return (
            f"<EnterpriseContextEntity("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"entity_type={self.entity_type!r}"
            f")>"
        )


# =============================================================================
# EnterpriseEntityCategoryAssociation model  (ENT2-2.2 — join table)
# =============================================================================


class EnterpriseEntityCategoryAssociation(EnterpriseBase):
    """Junction table linking context entities to entity categories.

    Each row places one context entity in one category at an optional
    ``position`` for display ordering.  Both FK columns carry
    ``ON DELETE CASCADE``.

    Note: this table is distinct from any future settings-domain association
    table.  It links ``enterprise_context_entities`` to
    ``enterprise_entity_categories`` only.

    ``tenant_id`` is denormalized for per-tenant bulk queries.

    Constraints:
        uq_ent_eca_tenant_entity_category:
            UNIQUE (tenant_id, entity_id, category_id)

    Indexes:
        idx_ent_eca_tenant_id:   (tenant_id)
        idx_ent_eca_entity_id:   (entity_id)
        idx_ent_eca_category_id: (category_id)
    """

    __tablename__ = "enterprise_entity_category_associations"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique join-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalized tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    entity_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_context_entities.id",
            ondelete="CASCADE",
            name="fk_ent_eca_entity_id",
        ),
        nullable=False,
        comment="Parent context entity; cascade-deletes this row when entity is removed",
    )
    category_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_entity_categories.id",
            ondelete="CASCADE",
            name="fk_ent_eca_category_id",
        ),
        nullable=False,
        comment="Parent category; cascade-deletes this row when category is removed",
    )
    position: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        default=0,
        server_default=text("0"),
        comment="Display order within the category; lower = earlier",
    )

    entity: Mapped["EnterpriseContextEntity"] = relationship(
        "EnterpriseContextEntity",
        back_populates="category_associations",
        lazy="joined",
    )
    category: Mapped["EnterpriseEntityCategory"] = relationship(
        "EnterpriseEntityCategory",
        back_populates="entity_category_associations",
        lazy="joined",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "entity_id",
            "category_id",
            name="uq_ent_eca_tenant_entity_category",
        ),
        Index("idx_ent_eca_tenant_id", "tenant_id"),
        Index("idx_ent_eca_entity_id", "entity_id"),
        Index("idx_ent_eca_category_id", "category_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseEntityCategoryAssociation."""
        return (
            f"<EnterpriseEntityCategoryAssociation("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"entity_id={self.entity_id!r}, "
            f"category_id={self.category_id!r}"
            f")>"
        )


# =============================================================================
# EnterpriseProject model  (ENT2-2.3)
# =============================================================================


class EnterpriseProject(EnterpriseBase):
    """Enterprise project record — DB-backed, informational filesystem path.

    Projects represent named Claude Code project workspaces.  In enterprise mode
    the ``path`` column is informational: it records where the project *was* when
    registered, but repository methods that require live filesystem access are
    treated as caller-driven side effects and do not scan disk within repository
    methods.

    Path uniqueness invariant:
        ``path`` is unique per tenant (one tenant cannot register the same path
        twice; two tenants may share the same path string).

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:          UUID PK.
        tenant_id:   Tenant scope.
        name:        Human-readable project name.
        path:        Filesystem path at registration time (informational only).
        status:      Project status string, e.g. 'active', 'archived'.
        description: Optional free-text description.
        created_at:  Timezone-aware creation timestamp.
        updated_at:  Timezone-aware last-modified timestamp.
        project_artifacts: Back-reference to EnterpriseProjectArtifact join rows.
        deployments:       Back-reference to EnterpriseDeployment rows.

    Constraints:
        uq_enterprise_projects_tenant_path: UNIQUE (tenant_id, path)

    Indexes:
        idx_enterprise_projects_tenant_id:   (tenant_id)
        idx_enterprise_projects_tenant_path: (tenant_id, path)
    """

    __tablename__ = "enterprise_projects"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique project identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable project name",
    )
    path: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment=(
            "Filesystem path at registration time — INFORMATIONAL ONLY in enterprise mode. "
            "The enterprise IProjectRepository never scans this path directly; "
            "FS operations remain in the CLI layer and are synced via write-through."
        ),
    )
    status: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Project status string, e.g. 'active', 'archived', 'initializing'",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of this project",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    project_artifacts: Mapped[List["EnterpriseProjectArtifact"]] = relationship(
        "EnterpriseProjectArtifact",
        back_populates="project",
        cascade="all, delete-orphan",
        lazy="select",
    )
    deployments: Mapped[List["EnterpriseDeployment"]] = relationship(
        "EnterpriseDeployment",
        back_populates="project",
        cascade="all, delete-orphan",
        lazy="select",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "path",
            name="uq_enterprise_projects_tenant_path",
        ),
        Index("idx_enterprise_projects_tenant_id", "tenant_id"),
        Index("idx_enterprise_projects_tenant_path", "tenant_id", "path"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseProject."""
        return (
            f"<EnterpriseProject("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"path={self.path!r}, "
            f"status={self.status!r}"
            f")>"
        )


# =============================================================================
# EnterpriseProjectArtifact model  (ENT2-2.3 — join table)
# =============================================================================


class EnterpriseProjectArtifact(EnterpriseBase):
    """Junction table tracking artifacts deployed to an enterprise project.

    Each row records that one artifact has been deployed to one project, along
    with deployment metadata (when, content hash, local modification flag).

    Both FK columns carry ``ON DELETE CASCADE``.  ``tenant_id`` is denormalized
    for per-tenant bulk queries.

    Constraints:
        uq_enterprise_project_artifacts_tenant_project_artifact:
            UNIQUE (tenant_id, project_id, artifact_uuid)

    Indexes:
        idx_ent_pa_tenant_id:    (tenant_id)
        idx_ent_pa_project_id:   (project_id)
        idx_ent_pa_artifact_uuid: (artifact_uuid)
    """

    __tablename__ = "enterprise_project_artifacts"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique join-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalized tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_projects.id",
            ondelete="CASCADE",
            name="fk_enterprise_project_artifacts_project_id",
        ),
        nullable=False,
        comment="Parent project; cascade-deletes this row when project is removed",
    )
    artifact_uuid: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_project_artifacts_artifact_uuid",
        ),
        nullable=False,
        comment="Deployed artifact; cascade-deletes this row when artifact is removed",
    )
    deployed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp when this artifact was deployed to the project",
    )
    content_hash: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="SHA256 hex digest of the artifact content at deployment time",
    )
    local_modifications: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        default=False,
        server_default=text("false"),
        comment="True when local project file has been modified since deployment",
    )

    project: Mapped["EnterpriseProject"] = relationship(
        "EnterpriseProject",
        back_populates="project_artifacts",
        lazy="joined",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "project_id",
            "artifact_uuid",
            name="uq_enterprise_project_artifacts_tenant_project_artifact",
        ),
        Index("idx_ent_pa_tenant_id", "tenant_id"),
        Index("idx_ent_pa_project_id", "project_id"),
        Index("idx_ent_pa_artifact_uuid", "artifact_uuid"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseProjectArtifact."""
        return (
            f"<EnterpriseProjectArtifact("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"project_id={self.project_id!r}, "
            f"artifact_uuid={self.artifact_uuid!r}"
            f")>"
        )


# =============================================================================
# EnterpriseDeployment model  (ENT2-2.3)
# =============================================================================


class EnterpriseDeployment(EnterpriseBase):
    """Per-deployment record tracking artifact deployment to a project.

    Each row records one deployment event: which artifact was deployed, to which
    project, and the resulting state.  The ``artifact_id`` column stores the
    text-format artifact identifier (e.g. ``"skill:canvas-design"``) for
    compatibility with the existing ``sync_deployment_cache()`` interface.
    ``artifact_uuid`` is the FK to ``enterprise_artifacts.id`` and is the
    preferred reference in enterprise-mode queries.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:                    UUID PK.
        tenant_id:             Tenant scope.
        artifact_id:           Text-format artifact identifier (type:name) for
                               backward compatibility with sync interfaces.
        artifact_uuid:         UUID FK to enterprise_artifacts.id (preferred ref).
        project_id:            Optional FK to enterprise_projects.id.
        status:                Deployment status, e.g. 'deployed', 'undeployed'.
        deployed_at:           Timestamp of the deployment event.
        content_hash:          SHA256 hash of content at deployment time.
        deployment_profile_id: Optional FK UUID for the deployment profile used.
        local_modifications:   True when local file has diverged from deployed content.
        platform:              Target platform, e.g. 'claude', 'cursor'.
        created_at:            Timezone-aware creation timestamp.
        updated_at:            Timezone-aware last-modified timestamp.
        project:               Many-to-one back-reference to EnterpriseProject.

    Indexes:
        idx_enterprise_deployments_tenant_id:       (tenant_id)
        idx_enterprise_deployments_artifact_id:     (artifact_id)
        idx_enterprise_deployments_artifact_uuid:   (artifact_uuid)
        idx_enterprise_deployments_project_id:      (project_id)
        idx_enterprise_deployments_tenant_status:   (tenant_id, status)
    """

    __tablename__ = "enterprise_deployments"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique deployment record identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    artifact_id: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment=(
            "Text-format artifact identifier, e.g. 'skill:canvas-design'. "
            "Preserved for backward compatibility with sync_deployment_cache() callers. "
            "In enterprise mode prefer artifact_uuid for FK-backed queries."
        ),
    )
    artifact_uuid: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="SET NULL",
            name="fk_enterprise_deployments_artifact_uuid",
        ),
        nullable=True,
        comment=(
            "UUID FK to enterprise_artifacts.id — preferred reference in enterprise queries. "
            "NULL for deployments recorded before the artifact was indexed in enterprise DB."
        ),
    )
    project_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_projects.id",
            ondelete="SET NULL",
            name="fk_enterprise_deployments_project_id",
        ),
        nullable=True,
        comment="Optional parent project; SET NULL when project is removed",
    )
    status: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Deployment status string, e.g. 'deployed', 'undeployed', 'pending'",
    )
    deployed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp of the deployment event",
    )
    content_hash: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="SHA256 hex digest of artifact content at deployment time",
    )
    deployment_profile_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="Optional UUID reference to the deployment profile used; no FK enforced",
    )
    local_modifications: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        default=False,
        server_default=text("false"),
        comment="True when the local project file has diverged from the deployed content",
    )
    platform: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Target platform for this deployment, e.g. 'claude', 'cursor', 'windsurf'",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    project: Mapped[Optional["EnterpriseProject"]] = relationship(
        "EnterpriseProject",
        back_populates="deployments",
        lazy="joined",
    )

    __table_args__ = (
        Index("idx_enterprise_deployments_tenant_id", "tenant_id"),
        Index("idx_enterprise_deployments_artifact_id", "artifact_id"),
        Index("idx_enterprise_deployments_artifact_uuid", "artifact_uuid"),
        Index("idx_enterprise_deployments_project_id", "project_id"),
        Index("idx_enterprise_deployments_tenant_status", "tenant_id", "status"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseDeployment."""
        return (
            f"<EnterpriseDeployment("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"project_id={self.project_id!r}, "
            f"status={self.status!r}"
            f")>"
        )


# =============================================================================
# EnterpriseDeploymentSet model  (ENT2-2.3)
# =============================================================================


class EnterpriseDeploymentSet(EnterpriseBase):
    """Named group of artifacts for coordinated deployment (IDP provisioning).

    Deployment sets represent a curated bundle of artifacts that are deployed
    together, e.g. for an IDP (Internal Developer Platform) provisioning
    workflow.  The ``provisioned_by`` column records the system or user that
    created the set.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:              UUID PK.
        tenant_id:       Tenant scope.
        name:            Human-readable set name; unique within a tenant.
        remote_url:      Optional URL linking to the canonical definition.
        provisioned_by:  System or user that provisioned this set.
        description:     Optional free-text description.
        tags_json:       Serialized tag list (TEXT, not JSONB) for compatibility
                         with the local DeploymentSetRepository tag filter.
        created_at:      Timezone-aware creation timestamp.
        updated_at:      Timezone-aware last-modified timestamp.
        members:         Back-reference to EnterpriseDeploymentSetMember rows.
        set_tags:        Back-reference to EnterpriseDeploymentSetTag rows.

    Constraints:
        uq_enterprise_deployment_sets_tenant_name: UNIQUE (tenant_id, name)

    Indexes:
        idx_enterprise_dsets_tenant_id:   (tenant_id)
        idx_enterprise_dsets_tenant_name: (tenant_id, name)
    """

    __tablename__ = "enterprise_deployment_sets"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique deployment set identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable set name; unique within a tenant",
    )
    remote_url: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional URL linking to the canonical definition of this set",
    )
    provisioned_by: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="System or user identifier that provisioned this deployment set",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of the set's purpose",
    )
    tags_json: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment=(
            "Serialized tag list as TEXT (e.g. JSON array string). "
            "Kept as TEXT for compatibility with the local DeploymentSetRepository "
            "tag-filter pattern. Prefer EnterpriseDeploymentSetTag rows for structured access."
        ),
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    members: Mapped[List["EnterpriseDeploymentSetMember"]] = relationship(
        "EnterpriseDeploymentSetMember",
        back_populates="deployment_set",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseDeploymentSetMember.position",
    )
    set_tags: Mapped[List["EnterpriseDeploymentSetTag"]] = relationship(
        "EnterpriseDeploymentSetTag",
        back_populates="deployment_set",
        cascade="all, delete-orphan",
        lazy="select",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_enterprise_deployment_sets_tenant_name",
        ),
        Index("idx_enterprise_dsets_tenant_id", "tenant_id"),
        Index("idx_enterprise_dsets_tenant_name", "tenant_id", "name"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseDeploymentSet."""
        return (
            f"<EnterpriseDeploymentSet("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}"
            f")>"
        )


# =============================================================================
# EnterpriseDeploymentSetMember model  (ENT2-2.3 — join table)
# =============================================================================


class EnterpriseDeploymentSetMember(EnterpriseBase):
    """Junction table linking artifacts to an enterprise deployment set.

    Each row places one artifact (by text identifier) in one deployment set
    at an explicit ``position``.  The FK to ``enterprise_deployment_sets``
    carries ``ON DELETE CASCADE``.

    Note: ``artifact_id`` is a text-format identifier (e.g. ``"skill:canvas"``)
    matching the local ``DeploymentSetMember`` pattern; no FK to
    ``enterprise_artifacts`` is required here since the identifier may refer
    to artifacts not yet indexed in the enterprise DB.

    ``tenant_id`` is denormalized for per-tenant bulk queries.

    Constraints:
        uq_enterprise_dsm_tenant_set_artifact:
            UNIQUE (tenant_id, set_id, artifact_id)

    Indexes:
        idx_ent_dsm_tenant_id: (tenant_id)
        idx_ent_dsm_set_id:    (set_id)
    """

    __tablename__ = "enterprise_deployment_set_members"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique join-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalized tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    set_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_deployment_sets.id",
            ondelete="CASCADE",
            name="fk_enterprise_dsm_set_id",
        ),
        nullable=False,
        comment="Parent deployment set; cascade-deletes this row when set is removed",
    )
    artifact_id: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Text-format artifact identifier, e.g. 'skill:canvas-design'",
    )
    position: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        default=0,
        server_default=text("0"),
        comment="Ordering position within the deployment set; lower = earlier",
    )

    deployment_set: Mapped["EnterpriseDeploymentSet"] = relationship(
        "EnterpriseDeploymentSet",
        back_populates="members",
        lazy="joined",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "set_id",
            "artifact_id",
            name="uq_enterprise_dsm_tenant_set_artifact",
        ),
        Index("idx_ent_dsm_tenant_id", "tenant_id"),
        Index("idx_ent_dsm_set_id", "set_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseDeploymentSetMember."""
        return (
            f"<EnterpriseDeploymentSetMember("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"set_id={self.set_id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"position={self.position!r}"
            f")>"
        )


# =============================================================================
# EnterpriseDeploymentSetTag model  (ENT2-2.3 — join table)
# =============================================================================


class EnterpriseDeploymentSetTag(EnterpriseBase):
    """String tags for enterprise deployment sets.

    Each row associates one string tag with one deployment set.  This mirrors
    the local ``DeploymentSetTag`` model and supports tag-based filtering in
    the deployment set repository.

    The ``tag`` column holds a plain string (not a FK to ``enterprise_tags``)
    to remain consistent with the local implementation's string-based tag
    model.  ``tenant_id`` is denormalized for per-tenant bulk queries.

    Constraints:
        uq_enterprise_dst_set_tag: UNIQUE (set_id, tag)

    Indexes:
        idx_ent_dst_tenant_id: (tenant_id)
        idx_ent_dst_set_id:    (set_id)
        idx_ent_dst_tag:       (tag)
    """

    __tablename__ = "enterprise_deployment_set_tags"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique tag-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalized tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    set_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_deployment_sets.id",
            ondelete="CASCADE",
            name="fk_enterprise_dst_set_id",
        ),
        nullable=False,
        comment="Parent deployment set; cascade-deletes this row when set is removed",
    )
    tag: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="String tag for filtering and grouping deployment sets",
    )

    deployment_set: Mapped["EnterpriseDeploymentSet"] = relationship(
        "EnterpriseDeploymentSet",
        back_populates="set_tags",
        lazy="joined",
    )

    __table_args__ = (
        UniqueConstraint(
            "set_id",
            "tag",
            name="uq_enterprise_dst_set_tag",
        ),
        Index("idx_ent_dst_tenant_id", "tenant_id"),
        Index("idx_ent_dst_set_id", "set_id"),
        Index("idx_ent_dst_tag", "tag"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseDeploymentSetTag."""
        return (
            f"<EnterpriseDeploymentSetTag("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"set_id={self.set_id!r}, "
            f"tag={self.tag!r}"
            f")>"
        )


# =============================================================================
# EnterpriseDeploymentProfile model  (ENT2-2.3)
# =============================================================================


class EnterpriseDeploymentProfile(EnterpriseBase):
    """Deployment configuration profile governing how artifacts are deployed.

    A deployment profile captures the configuration for a deployment operation:
    target scope, destination path, overwrite rules, and platform targeting.
    Each profile belongs to one tenant.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:         UUID PK.
        tenant_id:  Tenant scope.
        name:       Human-readable profile name; unique within a tenant.
        scope:      Deployment scope, e.g. 'user', 'local', 'project'.
        dest_path:  Destination path template for deployed artifacts.
        overwrite:  When True, existing files are overwritten without prompt.
        platform:   Target platform, e.g. 'claude', 'cursor', 'windsurf'.
        metadata:   JSONB bag for forward-compatible extension.
        created_at: Timezone-aware creation timestamp.
        updated_at: Timezone-aware last-modified timestamp.

    Constraints:
        uq_enterprise_deployment_profiles_tenant_name: UNIQUE (tenant_id, name)

    Indexes:
        idx_enterprise_dp_tenant_id:   (tenant_id)
        idx_enterprise_dp_tenant_name: (tenant_id, name)
    """

    __tablename__ = "enterprise_deployment_profiles"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique deployment profile identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable profile name; unique within a tenant",
    )
    scope: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Deployment scope, e.g. 'user', 'local', 'project'",
    )
    dest_path: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Destination path template; may contain placeholders like {artifact_name}",
    )
    overwrite: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        default=False,
        server_default=text("false"),
        comment="When TRUE, existing destination files are overwritten without prompt",
    )
    platform: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Target platform for deployments using this profile, e.g. 'claude', 'cursor'",
    )
    # Named extra_metadata (not metadata) to avoid shadowing
    # SQLAlchemy's reserved DeclarativeBase.metadata attribute.
    extra_metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
        comment="JSONB bag for forward-compatible extension; NULL until explicitly set",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_enterprise_deployment_profiles_tenant_name",
        ),
        Index("idx_enterprise_dp_tenant_id", "tenant_id"),
        Index("idx_enterprise_dp_tenant_name", "tenant_id", "name"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseDeploymentProfile."""
        return (
            f"<EnterpriseDeploymentProfile("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"scope={self.scope!r}"
            f")>"
        )


# =============================================================================
# EnterpriseMarketplaceSource model  (ENT2-2.4)
# =============================================================================


class EnterpriseMarketplaceSource(EnterpriseBase):
    """Registered GitHub repository available as a marketplace artifact source.

    Each row represents a GitHub repo that a tenant has registered for artifact
    discovery scanning.  The scanner populates ``artifact_count`` and
    ``last_sync_at`` after each scan run.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:             UUID PK.
        tenant_id:      Tenant scope.
        repo_url:       Full GitHub repository URL (required).
        owner:          GitHub repository owner (org or username).
        repo_name:      GitHub repository name.
        ref:            Git ref to scan, e.g. 'main', 'v1.2.0'.
        scan_status:    Current scan state, e.g. 'pending', 'scanning', 'done', 'error'.
        artifact_count: Number of artifacts discovered in the last scan.
        last_sync_at:   Timestamp of the last completed scan.
        created_at:     Timezone-aware creation timestamp.
        updated_at:     Timezone-aware last-modified timestamp.
        catalog_entries: Back-reference to EnterpriseMarketplaceCatalogEntry rows.

    Constraints:
        uq_enterprise_marketplace_sources_tenant_url: UNIQUE (tenant_id, repo_url)

    Indexes:
        idx_enterprise_ms_tenant_id:  (tenant_id)
        idx_enterprise_ms_tenant_url: (tenant_id, repo_url)
        idx_enterprise_ms_scan_status: (tenant_id, scan_status)
    """

    __tablename__ = "enterprise_marketplace_sources"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique marketplace source identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    repo_url: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Full GitHub repository URL, e.g. 'https://github.com/owner/repo'",
    )
    owner: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="GitHub repository owner (organisation or username)",
    )
    repo_name: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="GitHub repository name",
    )
    ref: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Git ref to scan, e.g. 'main', 'master', 'v1.2.0'",
    )
    scan_status: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Current scan state: 'pending', 'scanning', 'done', 'error'",
    )
    artifact_count: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        comment="Number of artifacts discovered in the most recent scan run",
    )
    last_sync_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp of the last completed scan run",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    catalog_entries: Mapped[List["EnterpriseMarketplaceCatalogEntry"]] = relationship(
        "EnterpriseMarketplaceCatalogEntry",
        back_populates="source",
        cascade="all, delete-orphan",
        lazy="select",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "repo_url",
            name="uq_enterprise_marketplace_sources_tenant_url",
        ),
        Index("idx_enterprise_ms_tenant_id", "tenant_id"),
        Index("idx_enterprise_ms_tenant_url", "tenant_id", "repo_url"),
        Index("idx_enterprise_ms_scan_status", "tenant_id", "scan_status"),
    )

    # ------------------------------------------------------------------
    # Columns promoted from compatibility stubs (ent_011).
    # These match the migration spec in
    # ent_011_enterprise_marketplace_source_columns.py exactly.
    # ------------------------------------------------------------------

    root_hint: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional root path hint used to narrow artifact discovery within the repository",
    )
    manual_map: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-serialised manual path-to-artifact-type mapping overrides",
    )
    single_artifact_mode: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default=text("false"),
        comment="When true the entire repository is treated as a single artifact",
    )
    single_artifact_type: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Artifact type to use when single_artifact_mode is true",
    )
    trust_level: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Trust tier for artifacts originating from this source (e.g. 'verified', 'community')",
    )
    visibility: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Visibility scope of the source (e.g. 'public', 'internal', 'private')",
    )
    last_error: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Most recent error message from indexing or sync operations; NULL when healthy",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Human-readable description of the marketplace source",
    )
    notes: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Free-form operator notes attached to the source record",
    )
    enable_frontmatter_detection: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default=text("false"),
        comment="Enable YAML/TOML frontmatter parsing during artifact indexing",
    )
    repo_description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Repository description fetched from the upstream VCS provider",
    )
    repo_readme: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Raw README content fetched from the upstream VCS provider",
    )
    indexing_enabled: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        comment="Whether scheduled indexing is enabled for this source; NULL means unset (inherits default)",
    )
    deep_indexing_enabled: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default=text("false"),
        comment="Enable deep content inspection during indexing (slower but more accurate)",
    )
    path_tag_config: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-serialised configuration mapping repository path prefixes to tags",
    )
    counts_by_type: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-serialised artifact-type-to-count map; refreshed after each indexing run",
    )
    tags: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-serialised list of tags associated with this source",
    )

    # ------------------------------------------------------------------
    # Columns promoted from compatibility stubs
    # ------------------------------------------------------------------

    supports_publish: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default=text("false"),
        comment="Whether this source supports publishing artifacts back to the repository",
    )

    # ------------------------------------------------------------------
    # Transient attribute: clone_target is not stored in the DB.
    # The scanner sets it on the instance at runtime.
    # ------------------------------------------------------------------

    @property
    def clone_target(self) -> "Optional[object]":
        """Clone target metadata (transient, not persisted to DB)."""
        return self._clone_target if hasattr(self, "_clone_target") else None

    @clone_target.setter
    def clone_target(self, value: "object") -> None:
        """Allow scanner to set clone_target on the instance."""
        self._clone_target = value

    # ------------------------------------------------------------------
    # JSON helper methods
    # ------------------------------------------------------------------

    def get_manual_map_dict(self) -> dict:
        """Parse and return manual_map as dictionary.

        Returns:
            Parsed manual_map dictionary, or empty dict if None/invalid JSON.
        """
        if not self.manual_map:
            return {}
        try:
            return json.loads(self.manual_map)
        except json.JSONDecodeError:
            return {}

    def set_manual_map_dict(self, value: Optional[dict]) -> None:
        """Serialize dict to JSON and store in manual_map.

        Args:
            value: Dictionary to serialize, or None to clear the column.
        """
        if value is None:
            self.manual_map = None
        else:
            self.manual_map = json.dumps(value)

    def get_tags_list(self) -> list:
        """Parse and return tags as list.

        Returns:
            Parsed tags list, or empty list if None/invalid JSON.
        """
        if not self.tags:
            return []
        try:
            return json.loads(self.tags)
        except json.JSONDecodeError:
            return []

    def set_tags_list(self, value: Optional[list]) -> None:
        """Serialize list to JSON and store in tags.

        Args:
            value: List to serialize, or None to clear the column.
        """
        if value is None:
            self.tags = None
        else:
            self.tags = json.dumps(value)

    def get_counts_by_type_dict(self) -> dict:
        """Parse and return counts_by_type as dictionary.

        Returns:
            Parsed counts dict, or empty dict if None/invalid JSON.
        """
        if not self.counts_by_type:
            return {}
        try:
            return json.loads(self.counts_by_type)
        except json.JSONDecodeError:
            return {}

    def set_counts_by_type_dict(self, value: Optional[dict]) -> None:
        """Serialize dict to JSON and store in counts_by_type.

        Args:
            value: Dictionary to serialize, or None to clear the column.
        """
        if value is None:
            self.counts_by_type = None
        else:
            self.counts_by_type = json.dumps(value)

    def to_dict(self) -> Dict[str, Any]:
        """Convert EnterpriseMarketplaceSource to dictionary for JSON serialization.

        Returns:
            Dictionary representation of all fields.  UUID and datetime fields
            are cast to str/isoformat so the result is directly JSON-serialisable.
            JSON-encoded columns (manual_map, tags, counts_by_type) are returned
            as parsed Python objects via the helper getter methods.
        """
        return {
            "id": str(self.id),
            "tenant_id": str(self.tenant_id),
            "repo_url": self.repo_url,
            "owner": self.owner,
            "repo_name": self.repo_name,
            "ref": self.ref,
            "root_hint": self.root_hint,
            "description": self.description,
            "notes": self.notes,
            "repo_description": self.repo_description,
            "repo_readme": self.repo_readme,
            "tags": self.get_tags_list(),
            "manual_map": self.get_manual_map_dict(),
            "trust_level": self.trust_level,
            "visibility": self.visibility,
            "enable_frontmatter_detection": self.enable_frontmatter_detection,
            "indexing_enabled": self.indexing_enabled,
            "single_artifact_mode": self.single_artifact_mode,
            "single_artifact_type": self.single_artifact_type,
            "clone_target": self.clone_target.to_dict() if self.clone_target else None,
            "deep_indexing_enabled": self.deep_indexing_enabled,
            "path_tag_config": self.path_tag_config,
            "last_sync_at": (
                self.last_sync_at.isoformat() if self.last_sync_at else None
            ),
            "last_error": self.last_error,
            "scan_status": self.scan_status,
            "artifact_count": self.artifact_count,
            "counts_by_type": self.get_counts_by_type_dict(),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseMarketplaceSource."""
        return (
            f"<EnterpriseMarketplaceSource("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"repo_url={self.repo_url!r}, "
            f"scan_status={self.scan_status!r}"
            f")>"
        )


# =============================================================================
# EnterpriseMarketplaceCatalogEntry model  (ENT2-2.4)
# =============================================================================


class EnterpriseMarketplaceCatalogEntry(EnterpriseBase):
    """Discovered artifact listing from a scanned marketplace source.

    Each row represents one artifact found during a scan of an
    ``EnterpriseMarketplaceSource``.  The ``search_vector`` column is a
    PostgreSQL ``TSVECTOR`` pre-computed from the artifact's name and path for
    full-text search.  It must be populated by a trigger or application-level
    update — it is not auto-computed by this model.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:               UUID PK.
        tenant_id:        Tenant scope.
        source_id:        FK to enterprise_marketplace_sources.id (CASCADE).
        artifact_type:    Artifact type string, e.g. 'skill', 'command'.
        name:             Artifact name from the source repository.
        path:             Relative path within the source repository.
        upstream_url:     Full URL to the artifact in the source repository.
        status:           Catalog entry status, e.g. 'available', 'imported', 'deprecated'.
        confidence_score: Integer confidence score (0-100) from the scanner.
        detected_sha:     Git commit SHA at the time of detection.
        search_vector:    PostgreSQL TSVECTOR for full-text search.
        created_at:       Timezone-aware creation timestamp.
        updated_at:       Timezone-aware last-modified timestamp.
        source:           Many-to-one back-reference to EnterpriseMarketplaceSource.

    Indexes:
        idx_enterprise_mce_tenant_id:      (tenant_id)
        idx_enterprise_mce_source_id:      (source_id)
        idx_enterprise_mce_tenant_type:    (tenant_id, artifact_type)
        idx_enterprise_mce_search_vector:  GIN (search_vector) — full-text search
    """

    __tablename__ = "enterprise_marketplace_catalog_entries"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique catalog entry identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    source_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_marketplace_sources.id",
            ondelete="CASCADE",
            name="fk_enterprise_mce_source_id",
        ),
        nullable=False,
        comment="Parent marketplace source; cascade-deletes entries when source is removed",
    )
    artifact_type: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Artifact type string detected by the scanner, e.g. 'skill', 'command'",
    )
    name: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Artifact name as detected in the source repository",
    )
    path: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Relative path to the artifact within the source repository",
    )
    upstream_url: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Full URL to the artifact in the source repository for direct access",
    )
    status: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Catalog entry status: 'available', 'imported', 'deprecated', 'error'",
    )
    confidence_score: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        comment="Scanner confidence score 0-100; higher = more certain this is an artifact",
    )
    detected_sha: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Git commit SHA at the time of detection for provenance tracking",
    )
    search_vector: Mapped[Optional[Any]] = mapped_column(
        TSVECTOR,
        nullable=True,
        comment=(
            "PostgreSQL TSVECTOR for full-text search over name and path. "
            "Must be populated by application code or a DB trigger — not auto-computed."
        ),
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Human-readable description of the catalog entry",
    )
    publisher: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Publisher name or identifier for the catalog entry",
    )
    bundle_url: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="URL to download the artifact bundle",
    )
    signature: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Cryptographic signature for artifact integrity verification",
    )
    rating: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment="Community rating for the catalog entry",
    )
    price: Mapped[Optional[Any]] = mapped_column(
        Numeric(10, 2),
        nullable=True,
        comment="Price for the catalog entry; NULL means free",
    )

    source: Mapped["EnterpriseMarketplaceSource"] = relationship(
        "EnterpriseMarketplaceSource",
        back_populates="catalog_entries",
        lazy="joined",
    )

    __table_args__ = (
        Index("idx_enterprise_mce_tenant_id", "tenant_id"),
        Index("idx_enterprise_mce_source_id", "source_id"),
        Index("idx_enterprise_mce_tenant_type", "tenant_id", "artifact_type"),
        # GIN index for full-text search over search_vector
        # The Alembic migration (ent_008) must create this with CONCURRENTLY:
        #   op.create_index(
        #       "idx_enterprise_mce_search_vector",
        #       "enterprise_marketplace_catalog_entries",
        #       ["search_vector"],
        #       postgresql_using="gin",
        #       postgresql_concurrently=True,
        #   )
        Index(
            "idx_enterprise_mce_search_vector",
            "search_vector",
            postgresql_using="gin",
        ),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseMarketplaceCatalogEntry."""
        return (
            f"<EnterpriseMarketplaceCatalogEntry("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"source_id={self.source_id!r}, "
            f"name={self.name!r}, "
            f"artifact_type={self.artifact_type!r}"
            f")>"
        )


# =============================================================================
# EnterpriseProjectTemplate model  (ent_012 — enterprise project templates)
# =============================================================================


class EnterpriseProjectTemplate(EnterpriseBase):
    """Named project scaffold template scoped to a tenant.

    Each row represents one reusable project template owned by a tenant.
    Template names are unique within a tenant (UNIQUE constraint on
    ``(tenant_id, name)``).  An ordered list of artifact entities is stored in
    the companion ``EnterpriseProjectTemplateEntity`` table.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:                       UUID PK, server-generated via gen_random_uuid().
        tenant_id:                Tenant scope.
        name:                     Human-readable template name; unique within tenant.
        description:              Optional free-text description.
        collection_id:            Optional ID of the owning collection.
        default_project_config_id: Optional artifact ID for the default project config.
        created_at:               Timezone-aware creation timestamp.
        updated_at:               Timezone-aware last-modified timestamp.
        entities:                 Ordered list of EnterpriseProjectTemplateEntity rows.

    Constraints:
        uq_project_templates_tenant_name:  UNIQUE (tenant_id, name)

    Indexes:
        idx_project_templates_tenant:  (tenant_id)
    """

    __tablename__ = "enterprise_project_templates"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Primary key; server-generated UUID",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable template name; unique within a tenant",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of the template",
    )
    collection_id: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional ID of the owning collection",
    )
    default_project_config_id: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional artifact ID for the default project config applied on scaffold",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Immutable creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    entities: Mapped[List["EnterpriseProjectTemplateEntity"]] = relationship(
        "EnterpriseProjectTemplateEntity",
        back_populates="template",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseProjectTemplateEntity.position",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_project_templates_tenant_name",
        ),
        Index("idx_project_templates_tenant", "tenant_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseProjectTemplate."""
        return (
            f"<EnterpriseProjectTemplate("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}"
            f")>"
        )


# =============================================================================
# EnterpriseProjectTemplateEntity model  (ent_012 — join table)
# =============================================================================


class EnterpriseProjectTemplateEntity(EnterpriseBase):
    """Ordered artifact entity belonging to an enterprise project template.

    Each row places one artifact entity at a specific ``position`` within a
    parent template.  Rows are cascade-deleted when the parent template is
    removed.

    Attributes:
        id:          UUID PK, server-generated via gen_random_uuid().
        template_id: FK to enterprise_project_templates.id (ON DELETE CASCADE).
        entity_id:   Artifact entity identifier in 'type:name' format.
        position:    0-based deploy order within the template.
        template:    Back-reference to the parent EnterpriseProjectTemplate.

    Indexes:
        idx_project_template_entities_template:  (template_id)
    """

    __tablename__ = "enterprise_project_template_entities"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Primary key; server-generated UUID",
    )
    template_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_project_templates.id",
            ondelete="CASCADE",
            name="fk_project_template_entities_template_id",
        ),
        nullable=False,
        comment="Parent template; cascade-deletes all entity rows when template is removed",
    )
    entity_id: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Artifact entity identifier in 'type:name' format",
    )
    position: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        comment="0-based deploy order within the template",
    )

    template: Mapped["EnterpriseProjectTemplate"] = relationship(
        "EnterpriseProjectTemplate",
        back_populates="entities",
        lazy="joined",
    )

    __table_args__ = (Index("idx_project_template_entities_template", "template_id"),)

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseProjectTemplateEntity."""
        return (
            f"<EnterpriseProjectTemplateEntity("
            f"id={self.id!r}, "
            f"template_id={self.template_id!r}, "
            f"entity_id={self.entity_id!r}, "
            f"position={self.position!r}"
            f")>"
        )


# =============================================================================
# Enterprise Git Repo Connector models  (GRC-DB-004)
# =============================================================================


class EnterpriseGitRepoConnection(EnterpriseBase):
    """Enterprise counterpart to ``GitRepoConnection`` (GRC-DB-004).

    Stores a registered Git repository connection scoped to a tenant.  All
    columns mirror the shared ``git_repo_connections`` table with the addition
    of ``tenant_id`` (UUID, non-nullable) and UUID primary/foreign keys as
    required by the enterprise schema.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.  Omitting it is a security defect that leaks cross-tenant data.

    Attributes:
        id:             UUID PK, server-generated via gen_random_uuid().
        tenant_id:      Tenant scope; every query MUST filter by this column.
        project_id:     Optional UUID referencing the enterprise project.
        repo_url:       Full clone URL of the Git repository.
        branch:         Branch to scan; defaults to 'main'.
        developer_id:   Optional UUID referencing the owning enterprise user.
        scan_schedule:  Reserved for future cron expression.
        webhook_secret: HMAC secret for webhook push-event validation.
        last_scan_at:   Timezone-aware UTC timestamp of the most recent scan.
        last_scan_id:   Plain UUID reference (no FK) to the latest scan row.
        is_active:      When False the connection is paused.
        created_at:     Timezone-aware UTC creation timestamp.
        created_by:     Optional UUID referencing the registering enterprise user.
        team_id:        Optional UUID referencing the owning team (ON DELETE SET NULL).
        scans:          All ``EnterpriseGitRepoScan`` rows for this connection.
        team:           Back-reference to the owning ``EnterpriseTeam``.
        linked_projects: All ``EnterpriseProjectGitConnection`` join rows for this connection.

    Table:
        enterprise_git_repo_connections

    Constraints:
        uq_ent_git_repo_connections_tenant_url_branch:
            UNIQUE (tenant_id, repo_url, branch)
    """

    __tablename__ = "enterprise_git_repo_connections"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique connection identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Core metadata
    # -------------------------------------------------------------------------

    project_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="Optional UUID of the owning enterprise project",
    )
    repo_url: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Full clone URL of the Git repository (HTTPS or SSH)",
    )
    branch: Mapped[str] = mapped_column(
        String,
        nullable=False,
        server_default=text("'main'"),
        comment="Branch to scan; defaults to 'main'",
    )
    developer_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="Optional UUID of the enterprise user who owns this connection",
    )
    scan_schedule: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Reserved: future cron expression for scheduled scans",
    )
    webhook_secret: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Webhook HMAC secret; treat as sensitive",
    )

    # -------------------------------------------------------------------------
    # Scan state pointers
    # -------------------------------------------------------------------------

    last_scan_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware UTC timestamp of the most recently completed scan",
    )
    last_scan_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment=(
            "Plain UUID reference (no FK) to the most recent enterprise_git_repo_scans.id. "
            "No FK constraint is defined to avoid a circular dependency."
        ),
    )

    # -------------------------------------------------------------------------
    # Status and audit
    # -------------------------------------------------------------------------

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("TRUE"),
        comment="When False the connection is paused and will not be scanned",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Immutable timezone-aware creation timestamp",
    )
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="Optional UUID of the enterprise user who registered this connection",
    )
    access_token: Mapped[Optional[str]] = mapped_column(
        EncryptedString(),
        nullable=True,
        comment="Encrypted personal access token for authenticated git operations on this connection",
    )

    # -------------------------------------------------------------------------
    # Team association (GCD-1.3)
    # -------------------------------------------------------------------------

    team_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_teams.id",
            ondelete="SET NULL",
            name="fk_ent_grc_team_id",
        ),
        nullable=True,
        comment=(
            "Optional FK to enterprise_teams.id. "
            "SET NULL on team deletion so the connection persists."
        ),
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    scans: Mapped[List["EnterpriseGitRepoScan"]] = relationship(
        "EnterpriseGitRepoScan",
        back_populates="connection",
        cascade="all, delete-orphan",
        lazy="select",
    )
    team: Mapped[Optional["EnterpriseTeam"]] = relationship(
        "EnterpriseTeam",
        foreign_keys=[team_id],
        lazy="select",
    )
    linked_projects: Mapped[List["EnterpriseProjectGitConnection"]] = relationship(
        "EnterpriseProjectGitConnection",
        back_populates="connection",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "repo_url",
            "branch",
            name="uq_ent_git_repo_connections_tenant_url_branch",
        ),
        Index("idx_ent_git_repo_connections_tenant_id", "tenant_id"),
        Index("idx_ent_git_repo_connections_project_id", "project_id"),
        Index("idx_ent_git_repo_connections_is_active", "is_active"),
        Index("idx_ent_grc_tenant_team_id", "tenant_id", "team_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseGitRepoConnection."""
        return (
            f"<EnterpriseGitRepoConnection("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"repo_url={self.repo_url!r}, "
            f"branch={self.branch!r}"
            f")>"
        )


class EnterpriseGitRepoScan(EnterpriseBase):
    """Enterprise counterpart to ``GitRepoScan`` (GRC-DB-004).

    Records a single artifact-discovery scan execution scoped to a tenant.
    Mirrors the shared ``git_repo_scans`` schema with UUID PKs and
    timezone-aware timestamps.

    Attributes:
        id:                UUID PK, server-generated via gen_random_uuid().
        tenant_id:         Tenant scope; every query MUST filter by this column.
        connection_id:     UUID FK to ``enterprise_git_repo_connections.id``
                           (ON DELETE CASCADE).
        triggered_by:      How the scan was initiated ('manual', 'schedule', 'webhook').
        trigger_sha:       Git commit SHA that triggered the scan (40-char hex); nullable.
        status:            Lifecycle state ('pending', 'running', 'completed', 'failed').
        started_at:        Timezone-aware UTC timestamp when the worker started.
        completed_at:      Timezone-aware UTC timestamp when the scan finished.
        artifacts_found:   Total artifacts detected.
        artifacts_new:     Artifacts not seen in previous scans.
        artifacts_changed: Artifacts whose content changed.
        artifacts_removed: Artifacts absent from this scan vs. the previous one.
        error_message:     Failure detail when status is 'failed'.
        created_at:        Timezone-aware UTC creation timestamp.
        connection:        Back-reference to parent ``EnterpriseGitRepoConnection``.
        scan_artifacts:    All ``EnterpriseGitScanArtifact`` rows for this scan.

    Table:
        enterprise_git_repo_scans

    Constraints:
        ck_ent_git_repo_scans_triggered_by:
            triggered_by IN ('manual', 'schedule', 'webhook')
        ck_ent_git_repo_scans_status:
            status IN ('pending', 'running', 'completed', 'failed')
    """

    __tablename__ = "enterprise_git_repo_scans"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique scan identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Parent connection
    # -------------------------------------------------------------------------

    connection_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_git_repo_connections.id",
            ondelete="CASCADE",
            name="fk_ent_grs_connection_id",
        ),
        nullable=False,
        comment="FK to enterprise_git_repo_connections.id; cascade-delete on connection removal",
    )

    # -------------------------------------------------------------------------
    # Trigger metadata
    # -------------------------------------------------------------------------

    triggered_by: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="How this scan was initiated: 'manual', 'schedule', or 'webhook'",
    )
    trigger_sha: Mapped[Optional[str]] = mapped_column(
        String(40),
        nullable=True,
        comment="Git commit SHA (40-char hex) that triggered this scan; NULL for manual/schedule",
    )

    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------

    status: Mapped[str] = mapped_column(
        String,
        nullable=False,
        server_default=text("'pending'"),
        comment="Current scan lifecycle state: 'pending', 'running', 'completed', or 'failed'",
    )
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware UTC timestamp when the scan worker picked up the job",
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware UTC timestamp when the scan finished",
    )

    # -------------------------------------------------------------------------
    # Artifact counters
    # -------------------------------------------------------------------------

    artifacts_found: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        server_default=text("0"),
        comment="Total artifacts detected in this scan run",
    )
    artifacts_new: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        server_default=text("0"),
        comment="Artifacts newly discovered (not seen in previous scans)",
    )
    artifacts_changed: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        server_default=text("0"),
        comment="Artifacts whose content changed since the last scan",
    )
    artifacts_removed: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        server_default=text("0"),
        comment="Artifacts present in the previous scan but no longer found",
    )

    # -------------------------------------------------------------------------
    # Error reporting and audit
    # -------------------------------------------------------------------------

    error_message: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Human-readable error detail when status is 'failed'",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Immutable timezone-aware creation timestamp",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    connection: Mapped["EnterpriseGitRepoConnection"] = relationship(
        "EnterpriseGitRepoConnection",
        back_populates="scans",
        lazy="select",
    )
    scan_artifacts: Mapped[List["EnterpriseGitScanArtifact"]] = relationship(
        "EnterpriseGitScanArtifact",
        back_populates="scan",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        CheckConstraint(
            "triggered_by IN ('manual', 'schedule', 'webhook')",
            name="ck_ent_git_repo_scans_triggered_by",
        ),
        CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed')",
            name="ck_ent_git_repo_scans_status",
        ),
        Index("idx_ent_git_repo_scans_tenant_id", "tenant_id"),
        Index("idx_ent_git_repo_scans_connection_id", "connection_id"),
        Index("idx_ent_git_repo_scans_status", "status"),
        Index("idx_ent_git_repo_scans_created_at", "created_at"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseGitRepoScan."""
        return (
            f"<EnterpriseGitRepoScan("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"connection_id={self.connection_id!r}, "
            f"status={self.status!r}"
            f")>"
        )


class EnterpriseGitScanArtifact(EnterpriseBase):
    """Enterprise counterpart to ``GitScanArtifact`` (GRC-DB-004).

    Records a single artifact observation produced during an enterprise scan
    run, scoped to a tenant.  Mirrors the shared ``git_scan_artifacts`` schema
    with UUID PKs and timezone-aware timestamps.

    Attributes:
        id:             UUID PK, server-generated via gen_random_uuid().
        tenant_id:      Tenant scope; every query MUST filter by this column.
        scan_id:        UUID FK to ``enterprise_git_repo_scans.id``
                        (ON DELETE CASCADE).
        artifact_path:  Repository-relative path to the artifact directory/file.
        artifact_type:  Detected artifact type label (e.g. 'skill', 'agent').
        detected_name:  Human-readable name parsed from frontmatter; nullable.
        content_hash:   SHA-256 hex digest (64 chars) of artifact content; nullable.
        change_type:    Classification relative to previous scan
                        ('new', 'changed', 'removed', 'unchanged').
        indexed_at:     Timezone-aware UTC timestamp when imported into the cache.
        artifact_id:    UUID FK to the enterprise artifact once indexed; nullable.
        created_at:     Timezone-aware UTC creation timestamp.
        scan:           Back-reference to parent ``EnterpriseGitRepoScan``.

    Table:
        enterprise_git_scan_artifacts

    Constraints:
        ck_ent_git_scan_artifacts_change_type:
            change_type IN ('new', 'changed', 'removed', 'unchanged')
    """

    __tablename__ = "enterprise_git_scan_artifacts"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique artifact observation identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Parent scan
    # -------------------------------------------------------------------------

    scan_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_git_repo_scans.id",
            ondelete="CASCADE",
            name="fk_ent_gsa_scan_id",
        ),
        nullable=False,
        comment="FK to enterprise_git_repo_scans.id; cascade-delete when scan is removed",
    )

    # -------------------------------------------------------------------------
    # Artifact metadata
    # -------------------------------------------------------------------------

    artifact_path: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Repository-relative path to the artifact directory or file",
    )
    artifact_type: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        comment="Detected artifact type label (e.g. 'skill', 'agent', 'command')",
    )
    detected_name: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        comment="Human-readable artifact name parsed from CLAUDE.md or SKILL.md frontmatter",
    )
    content_hash: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="SHA-256 hex digest (64 chars) of the artifact's content at scan time",
    )
    change_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment=(
            "How this artifact changed since the last scan: "
            "'new', 'changed', 'removed', or 'unchanged'"
        ),
    )

    # -------------------------------------------------------------------------
    # Import linkage and audit
    # -------------------------------------------------------------------------

    indexed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware UTC timestamp when this artifact was imported into the cache",
    )
    artifact_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            name="fk_ent_gsa_artifact_id",
        ),
        nullable=True,
        comment=(
            "UUID FK to enterprise_artifacts.id once the artifact has been indexed. "
            "NULL until import completes."
        ),
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Immutable timezone-aware creation timestamp",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    scan: Mapped["EnterpriseGitRepoScan"] = relationship(
        "EnterpriseGitRepoScan",
        back_populates="scan_artifacts",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        CheckConstraint(
            "change_type IN ('new', 'changed', 'removed', 'unchanged')",
            name="ck_ent_git_scan_artifacts_change_type",
        ),
        Index("idx_ent_git_scan_artifacts_tenant_id", "tenant_id"),
        Index("idx_ent_git_scan_artifacts_scan_id", "scan_id"),
        Index("idx_ent_git_scan_artifacts_artifact_path", "artifact_path"),
        Index("idx_ent_git_scan_artifacts_change_type", "change_type"),
        Index("idx_ent_git_scan_artifacts_artifact_id", "artifact_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseGitScanArtifact."""
        return (
            f"<EnterpriseGitScanArtifact("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"scan_id={self.scan_id!r}, "
            f"artifact_path={self.artifact_path!r}, "
            f"change_type={self.change_type!r}"
            f")>"
        )


# =============================================================================
# EnterpriseArtifactBlob model  (CAS-1.3)
# =============================================================================


class EnterpriseArtifactBlob(EnterpriseBase):
    """Content-Addressed Storage (CAS) blob for enterprise artifact file content.

    Each row holds the binary or text content of one artifact file, keyed by
    its SHA-256 hex digest.  Because the key is derived from content, identical
    bytes written by multiple artifact versions (or multiple tenants) always map
    to the same row, achieving storage deduplication across the entire enterprise
    collection without duplicating bytes.

    Storage modes:
        Inline mode  — ``content`` is non-NULL, ``storage_uri`` is NULL.
                       Used for small payloads (e.g. single Markdown files).
        External mode — ``storage_uri`` is non-NULL, ``content`` is NULL.
                       Used for large binaries offloaded to object storage (S3,
                       GCS, etc.).  The application layer enforces the invariant
                       that exactly one of the two is non-NULL at write time.

    Immutability invariant:
        Blob rows are write-once.  Once written for a given ``sha256_hash``,
        neither ``content`` nor ``storage_uri`` is ever updated.  The repository
        MUST check for an existing row by hash before inserting.

    Reference counting:
        ``ref_count`` is a soft counter incremented by the repository on each
        new ``artifact_versions.content_payload`` reference.  It drives GC
        eligibility but is not authoritative — the GC process performs a full
        join scan before evicting any blob.

    Tenant isolation note:
        Unlike most enterprise tables this model has NO ``tenant_id`` column.
        Blobs are content-addressed and tenant-agnostic — the same blob row may
        be referenced by versions belonging to different tenants.  Tenant
        isolation is enforced at the version layer, not the blob layer.

    Attributes:
        id:           UUID PK, server-generated via gen_random_uuid().
        sha256_hash:  SHA-256 hex digest (exactly 64 chars); globally unique.
        content:      Inline BYTEA payload; NULL when stored externally.
        storage_uri:  External storage URI; NULL when stored inline.
        size_bytes:   Byte length of the original content.
        mime_type:    IANA media type, e.g. 'text/markdown'; nullable.
        created_at:   Immutable creation timestamp; server-generated.
        last_ref_at:  UTC timestamp of the most recent version reference; nullable.
        ref_count:    Soft reference counter; drives GC eligibility.

    Constraints:
        uq_artifact_blobs_sha256_hash:
            UNIQUE (sha256_hash) — primary deduplication guard.

    Indexes:
        idx_artifact_blobs_sha256_hash:
            (sha256_hash) — O(log n) lookup by content hash.

    Schema reference:
        ent_013_enterprise_artifact_blobs_cas migration (CAS-1.1)
    """

    __tablename__ = "artifact_blobs"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Primary key; server-generated UUID",
    )

    # -------------------------------------------------------------------------
    # Content-addressable key
    # -------------------------------------------------------------------------

    sha256_hash: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        comment=(
            "SHA-256 hex digest of the blob content (exactly 64 chars). "
            "Immutable once written — the application layer MUST NOT update "
            "the content column for an existing hash. "
            "Unique constraint enforces global deduplication."
        ),
    )

    # -------------------------------------------------------------------------
    # Content storage (exactly one of content / storage_uri is non-NULL)
    # -------------------------------------------------------------------------

    content: Mapped[Optional[bytes]] = mapped_column(
        LargeBinary(),
        nullable=True,
        comment=(
            "Raw binary content of the blob stored inline. "
            "NULL when the blob is stored externally (see storage_uri). "
            "Exactly one of content / storage_uri MUST be non-NULL."
        ),
    )
    storage_uri: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment=(
            "External storage pointer (e.g. S3 URI, GCS URI). "
            "NULL when content is stored inline. "
            "Exactly one of content / storage_uri MUST be non-NULL."
        ),
    )

    # -------------------------------------------------------------------------
    # Size and type metadata
    # -------------------------------------------------------------------------

    size_bytes: Mapped[int] = mapped_column(
        BigInteger(),
        nullable=False,
        comment=(
            "Byte length of the original content. "
            "Redundant but avoids full content reads for size queries."
        ),
    )
    mime_type: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        comment=(
            "IANA media type of the content, e.g. 'text/markdown', "
            "'application/json'. NULL when type is unknown or not needed."
        ),
    )

    # -------------------------------------------------------------------------
    # Timestamps and reference tracking
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="UTC timestamp when the blob was first written; immutable",
    )
    last_ref_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment=(
            "UTC timestamp of the most recent artifact_versions reference to "
            "this blob. Updated (never cleared) by the repository on each new "
            "version write. NULL until at least one version references this blob."
        ),
    )
    ref_count: Mapped[int] = mapped_column(
        Integer(),
        nullable=False,
        server_default=text("0"),
        comment=(
            "Soft reference count incremented by the repository on each new "
            "version reference. Drives GC eligibility but is not authoritative; "
            "the GC process performs a full join scan before evicting any blob."
        ),
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # UNIQUE: content-addressed deduplication across all tenants
        UniqueConstraint(
            "sha256_hash",
            name="uq_artifact_blobs_sha256_hash",
        ),
        # B-tree: primary lookup path — O(log n) by content hash
        Index(
            "idx_artifact_blobs_sha256_hash",
            "sha256_hash",
        ),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseArtifactBlob."""
        return (
            f"<EnterpriseArtifactBlob("
            f"id={self.id!r}, "
            f"sha256_hash={self.sha256_hash!r}, "
            f"size_bytes={self.size_bytes!r}, "
            f"ref_count={self.ref_count!r}"
            f")>"
        )


# =============================================================================
# EnterpriseWorkflow model  (EGCF-2.1)
# =============================================================================


class EnterpriseWorkflow(EnterpriseBase):
    """Tenant-scoped workflow definition.

    Each row represents one named workflow owned by a tenant. A workflow
    contains an ordered set of stages (EnterpriseWorkflowStage) and may be
    instantiated into one or more executions (EnterpriseWorkflowExecution).

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate. Omitting it leaks cross-tenant workflow definitions.

    Attributes:
        id:          UUID primary key.
        tenant_id:   Tenant scope; every query MUST filter by this column.
        name:        Human-readable workflow name (unique per tenant).
        description: Optional description of the workflow's purpose.
        status:      Lifecycle status — 'draft', 'active', or 'archived'.
        config:      Arbitrary JSONB configuration for workflow-level settings.
        created_at:  Timezone-aware creation timestamp (server default: now()).
        updated_at:  Timezone-aware last-modified timestamp (app-managed).

    Indexes:
        ix_enterprise_workflows_tenant_id: (tenant_id)
    """

    __tablename__ = "enterprise_workflows"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique workflow identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Core metadata
    # -------------------------------------------------------------------------

    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        comment="Human-readable workflow name; unique within a tenant",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional description of the workflow's purpose",
    )
    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="draft",
        server_default=text("'draft'"),
        comment="Lifecycle status: draft, active, or archived",
    )
    config: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="Arbitrary JSONB configuration for workflow-level settings",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    stages: Mapped[List["EnterpriseWorkflowStage"]] = relationship(
        "EnterpriseWorkflowStage",
        back_populates="workflow",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseWorkflowStage.position",
    )
    executions: Mapped[List["EnterpriseWorkflowExecution"]] = relationship(
        "EnterpriseWorkflowExecution",
        back_populates="workflow",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseWorkflowExecution.started_at.desc()",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_enterprise_workflows_tenant_name",
        ),
        CheckConstraint(
            "status IN ('draft', 'active', 'archived')",
            name="ck_enterprise_workflows_status",
        ),
        Index("ix_enterprise_workflows_tenant_id", "tenant_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseWorkflow."""
        return (
            f"<EnterpriseWorkflow("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"status={self.status!r}"
            f")>"
        )


# =============================================================================
# EnterpriseWorkflowStage model  (EGCF-2.1)
# =============================================================================


class EnterpriseWorkflowStage(EnterpriseBase):
    """An ordered stage within a workflow definition.

    Each row represents one stage belonging to one workflow. Stages define the
    discrete steps that an execution will progress through. The ``position``
    column establishes the canonical ordering of stages within a workflow.

    Tenant isolation invariant:
        Stages are reached via their parent workflow, but tenant_id is stored
        directly on every row so that cross-table queries can still apply a
        tenant predicate without a join.

    Attributes:
        id:           UUID primary key.
        workflow_id:  FK to enterprise_workflows.id (CASCADE DELETE).
        tenant_id:    Denormalised tenant scope for predicate pushdown.
        name:         Human-readable stage name.
        description:  Optional description of what this stage does.
        position:     Ascending integer that defines the stage order within a workflow.
        stage_type:   Semantic category of the stage (e.g. 'action', 'condition', 'wait').
        config:       Arbitrary JSONB configuration for stage-level settings.
        created_at:   Timezone-aware creation timestamp (server default: now()).
        updated_at:   Timezone-aware last-modified timestamp (app-managed).

    Indexes:
        ix_enterprise_workflow_stages_tenant_id:   (tenant_id)
        ix_enterprise_workflow_stages_workflow_id: (workflow_id)
    """

    __tablename__ = "enterprise_workflow_stages"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique stage identifier",
    )
    workflow_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("enterprise_workflows.id", ondelete="CASCADE"),
        nullable=False,
        comment="FK to enterprise_workflows.id; CASCADE DELETE removes stages with workflow",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; enables predicate pushdown without join",
    )

    # -------------------------------------------------------------------------
    # Stage definition
    # -------------------------------------------------------------------------

    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        comment="Human-readable stage name",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional description of what this stage does",
    )
    position: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        comment="Ascending integer defining stage order within the workflow",
    )
    stage_type: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="action",
        server_default=text("'action'"),
        comment="Semantic category of the stage: action, condition, wait, etc.",
    )
    config: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="Arbitrary JSONB configuration for stage-level settings",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    workflow: Mapped["EnterpriseWorkflow"] = relationship(
        "EnterpriseWorkflow",
        back_populates="stages",
        lazy="joined",
    )
    execution_steps: Mapped[List["EnterpriseExecutionStep"]] = relationship(
        "EnterpriseExecutionStep",
        back_populates="stage",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "workflow_id",
            "position",
            name="uq_enterprise_workflow_stages_workflow_position",
        ),
        CheckConstraint(
            "position >= 0",
            name="ck_enterprise_workflow_stages_position_nonneg",
        ),
        Index("ix_enterprise_workflow_stages_tenant_id", "tenant_id"),
        Index("ix_enterprise_workflow_stages_workflow_id", "workflow_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseWorkflowStage."""
        return (
            f"<EnterpriseWorkflowStage("
            f"id={self.id!r}, "
            f"workflow_id={self.workflow_id!r}, "
            f"name={self.name!r}, "
            f"position={self.position!r}"
            f")>"
        )


# =============================================================================
# EnterpriseWorkflowExecution model  (EGCF-2.1)
# =============================================================================


class EnterpriseWorkflowExecution(EnterpriseBase):
    """A single run of a workflow.

    Each row represents one execution instance of a workflow. An execution
    tracks the overall run status, timing, runtime context supplied at launch,
    and the final result once the run completes or fails.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate. Omitting it leaks cross-tenant execution records.

    Attributes:
        id:           UUID primary key.
        workflow_id:  FK to enterprise_workflows.id (CASCADE DELETE).
        tenant_id:    Denormalised tenant scope for predicate pushdown.
        status:       Run status — 'pending', 'running', 'completed', 'failed', or 'cancelled'.
        started_at:   Timezone-aware timestamp when execution began; NULL until started.
        completed_at: Timezone-aware timestamp when execution finished; NULL until done.
        context:      JSONB input context supplied at launch time.
        result:       JSONB result payload written on completion or failure.
        created_at:   Timezone-aware creation timestamp (server default: now()).
        updated_at:   Timezone-aware last-modified timestamp (app-managed).

    Indexes:
        ix_enterprise_workflow_executions_tenant_id:   (tenant_id)
        ix_enterprise_workflow_executions_workflow_id: (workflow_id)
        ix_enterprise_workflow_executions_status:      (status)
    """

    __tablename__ = "enterprise_workflow_executions"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique execution identifier",
    )
    workflow_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("enterprise_workflows.id", ondelete="CASCADE"),
        nullable=False,
        comment="FK to enterprise_workflows.id; CASCADE DELETE removes executions with workflow",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; enables predicate pushdown without join",
    )

    # -------------------------------------------------------------------------
    # Run state
    # -------------------------------------------------------------------------

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="pending",
        server_default=text("'pending'"),
        comment="Run status: pending, running, completed, failed, or cancelled",
    )
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp when the execution began; NULL until started",
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp when execution finished; NULL until complete",
    )

    # -------------------------------------------------------------------------
    # Runtime data
    # -------------------------------------------------------------------------

    context: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB input context supplied at launch time",
    )
    result: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB result payload written on completion or failure",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    workflow: Mapped["EnterpriseWorkflow"] = relationship(
        "EnterpriseWorkflow",
        back_populates="executions",
        lazy="joined",
    )
    steps: Mapped[List["EnterpriseExecutionStep"]] = relationship(
        "EnterpriseExecutionStep",
        back_populates="execution",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseExecutionStep.started_at",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed', 'cancelled')",
            name="ck_enterprise_workflow_executions_status",
        ),
        Index("ix_enterprise_workflow_executions_tenant_id", "tenant_id"),
        Index("ix_enterprise_workflow_executions_workflow_id", "workflow_id"),
        Index("ix_enterprise_workflow_executions_status", "status"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseWorkflowExecution."""
        return (
            f"<EnterpriseWorkflowExecution("
            f"id={self.id!r}, "
            f"workflow_id={self.workflow_id!r}, "
            f"status={self.status!r}, "
            f"started_at={self.started_at!r}"
            f")>"
        )


# =============================================================================
# EnterpriseExecutionStep model  (EGCF-2.1)
# =============================================================================


class EnterpriseExecutionStep(EnterpriseBase):
    """An individual step within a workflow execution run.

    Each row represents one stage's execution within a specific run. Steps link
    both to the parent execution and to the workflow stage definition they
    correspond to, allowing the step to inherit stage metadata while recording
    step-specific runtime input, output, and error information.

    Tenant isolation invariant:
        Steps are reached via their parent execution, but tenant_id is stored
        directly on every row so that cross-table queries can still apply a
        tenant predicate without a join.

    Attributes:
        id:           UUID primary key.
        execution_id: FK to enterprise_workflow_executions.id (CASCADE DELETE).
        stage_id:     FK to enterprise_workflow_stages.id (SET NULL on stage delete).
        tenant_id:    Denormalised tenant scope for predicate pushdown.
        status:       Step status — 'pending', 'running', 'completed', 'failed', or 'skipped'.
        started_at:   Timezone-aware timestamp when the step began; NULL until started.
        completed_at: Timezone-aware timestamp when the step finished; NULL until done.
        input:        JSONB payload passed into the step.
        output:       JSONB payload produced by the step on success.
        error:        TEXT error message written on failure; NULL on success.
        created_at:   Timezone-aware creation timestamp (server default: now()).
        updated_at:   Timezone-aware last-modified timestamp (app-managed).

    Indexes:
        ix_enterprise_execution_steps_tenant_id:   (tenant_id)
        ix_enterprise_execution_steps_execution_id: (execution_id)
        ix_enterprise_execution_steps_stage_id:    (stage_id)
    """

    __tablename__ = "enterprise_execution_steps"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique step identifier",
    )
    execution_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("enterprise_workflow_executions.id", ondelete="CASCADE"),
        nullable=False,
        comment="FK to enterprise_workflow_executions.id; CASCADE DELETE removes steps with execution",
    )
    stage_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("enterprise_workflow_stages.id", ondelete="SET NULL"),
        nullable=True,
        comment="FK to enterprise_workflow_stages.id; SET NULL if stage is deleted",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; enables predicate pushdown without join",
    )

    # -------------------------------------------------------------------------
    # Step state
    # -------------------------------------------------------------------------

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="pending",
        server_default=text("'pending'"),
        comment="Step status: pending, running, completed, failed, or skipped",
    )
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp when the step began; NULL until started",
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp when the step finished; NULL until complete",
    )

    # -------------------------------------------------------------------------
    # Step I/O
    # -------------------------------------------------------------------------

    input: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB payload passed into the step",
    )
    output: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB payload produced by the step on success",
    )
    error: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Error message written on failure; NULL on success",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    execution: Mapped["EnterpriseWorkflowExecution"] = relationship(
        "EnterpriseWorkflowExecution",
        back_populates="steps",
        lazy="joined",
    )
    stage: Mapped[Optional["EnterpriseWorkflowStage"]] = relationship(
        "EnterpriseWorkflowStage",
        back_populates="execution_steps",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed', 'skipped')",
            name="ck_enterprise_execution_steps_status",
        ),
        Index("ix_enterprise_execution_steps_tenant_id", "tenant_id"),
        Index("ix_enterprise_execution_steps_execution_id", "execution_id"),
        Index("ix_enterprise_execution_steps_stage_id", "stage_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseExecutionStep."""
        return (
            f"<EnterpriseExecutionStep("
            f"id={self.id!r}, "
            f"execution_id={self.execution_id!r}, "
            f"stage_id={self.stage_id!r}, "
            f"status={self.status!r}"
            f")>"
        )


# =============================================================================
# EnterpriseMemoryItem model  (EGCF-2.2)
# =============================================================================


class EnterpriseMemoryItem(EnterpriseBase):
    """Persistent memory item for project-level development knowledge.

    Stores a single unit of knowledge captured during development work — such
    as a decision rationale, a gotcha, or a learned pattern — associated with
    a project and scoped to a tenant.

    Attributes:
        id:           UUID primary key; globally unique.
        tenant_id:    Denormalised tenant scope; every query MUST include
                      WHERE tenant_id = ?.
        project_id:   FK to enterprise_projects.id; CASCADE DELETE removes
                      memory items when the project is deleted.
        type:         Memory type — one of 'decision', 'constraint', 'gotcha',
                      'style_rule', or 'learning'.
        content:      Full-text content of the memory item (required).
        confidence:   Floating-point confidence score in [0.0, 1.0].
        status:       Lifecycle status — 'candidate', 'validated', 'rejected',
                      or 'superseded'.
        anchor:       Optional text anchor referencing the source location,
                      e.g. 'skillmeat/cache/models_enterprise.py:code:42-58'.
        provenance:   JSONB metadata recording how this item was produced
                      (branch, commit, agent type, model).
        created_at:   Timezone-aware creation timestamp (server default: now()).
        updated_at:   Timezone-aware last-modified timestamp (app-managed).

    Constraints:
        ck_enterprise_memory_items_type:
            type IN ('decision', 'constraint', 'gotcha', 'style_rule', 'learning')
        ck_enterprise_memory_items_status:
            status IN ('candidate', 'validated', 'rejected', 'superseded')

    Indexes:
        ix_enterprise_memory_items_tenant_id:  (tenant_id)
        ix_enterprise_memory_items_project_id: (project_id)
    """

    __tablename__ = "enterprise_memory_items"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique memory item identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    project_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("enterprise_projects.id", ondelete="CASCADE"),
        nullable=True,
        comment="FK to enterprise_projects.id; CASCADE DELETE removes item with project",
    )

    # -------------------------------------------------------------------------
    # Classification
    # -------------------------------------------------------------------------

    type: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Memory type: decision, constraint, gotcha, style_rule, or learning",
    )
    status: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        default="candidate",
        server_default=text("'candidate'"),
        comment="Lifecycle status: candidate, validated, rejected, or superseded",
    )

    # -------------------------------------------------------------------------
    # Content
    # -------------------------------------------------------------------------

    content: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Full-text content of the memory item",
    )
    confidence: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment="Confidence score in [0.0, 1.0]; NULL when not assessed",
    )
    anchor: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Source location anchor, e.g. 'path/to/file.py:code:42-58'",
    )
    provenance: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB metadata: branch, commit, agent_type, model, etc.",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    module_links: Mapped[List["EnterpriseModuleMemoryItem"]] = relationship(
        "EnterpriseModuleMemoryItem",
        back_populates="memory_item",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        CheckConstraint(
            "type IN ('decision', 'constraint', 'gotcha', 'style_rule', 'learning')",
            name="ck_enterprise_memory_items_type",
        ),
        CheckConstraint(
            "status IN ('candidate', 'validated', 'rejected', 'superseded')",
            name="ck_enterprise_memory_items_status",
        ),
        Index("ix_enterprise_memory_items_tenant_id", "tenant_id"),
        Index("ix_enterprise_memory_items_project_id", "project_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseMemoryItem."""
        return (
            f"<EnterpriseMemoryItem("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"type={self.type!r}, "
            f"status={self.status!r}"
            f")>"
        )


# =============================================================================
# EnterpriseContextModule model  (EGCF-2.2)
# =============================================================================


class EnterpriseContextModule(EnterpriseBase):
    """A named grouping of memory items for use in context packs.

    Context modules collect related memory items so they can be assembled into
    a context pack and injected into agent sessions.  Each module belongs to a
    tenant and carries optional configuration controlling how items are selected
    and ranked.

    Attributes:
        id:          UUID primary key; globally unique.
        tenant_id:   Denormalised tenant scope; every query MUST include
                     WHERE tenant_id = ?.
        name:        Human-readable module name (required).
        description: Optional free-text description of the module's purpose.
        module_type: Optional tag indicating the module's role, e.g.
                     'domain', 'session', 'project'.
        config:      JSONB configuration controlling item selection, ranking,
                     or token budgets.
        created_at:  Timezone-aware creation timestamp (server default: now()).
        updated_at:  Timezone-aware last-modified timestamp (app-managed).

    Indexes:
        ix_enterprise_context_modules_tenant_id: (tenant_id)
    """

    __tablename__ = "enterprise_context_modules"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique context module identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Module metadata
    # -------------------------------------------------------------------------

    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable name for this context module",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of the module's purpose",
    )
    module_type: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional type tag, e.g. 'domain', 'session', or 'project'",
    )
    config: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB configuration for item selection, ranking, and token budgets",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    memory_item_links: Mapped[List["EnterpriseModuleMemoryItem"]] = relationship(
        "EnterpriseModuleMemoryItem",
        back_populates="context_module",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (Index("ix_enterprise_context_modules_tenant_id", "tenant_id"),)

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseContextModule."""
        return (
            f"<EnterpriseContextModule("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"module_type={self.module_type!r}"
            f")>"
        )


# =============================================================================
# EnterpriseModuleMemoryItem model  (EGCF-2.2 — join table)
# =============================================================================


class EnterpriseModuleMemoryItem(EnterpriseBase):
    """Junction table linking memory items to context modules.

    Each row places one memory item in one context module.  Both FKs carry
    ``ON DELETE CASCADE`` so the join row is automatically removed when either
    the module or the memory item is deleted.

    ``tenant_id`` is denormalized for per-tenant bulk queries without joins.

    Constraints:
        uq_enterprise_module_memory_item:
            UNIQUE (module_id, memory_item_id, tenant_id)

    Indexes:
        ix_enterprise_module_memory_items_tenant_id:     (tenant_id)
        ix_enterprise_module_memory_items_module_id:     (module_id)
        ix_enterprise_module_memory_items_memory_item_id: (memory_item_id)
    """

    __tablename__ = "enterprise_module_memory_items"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique join-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    module_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_context_modules.id",
            ondelete="CASCADE",
            name="fk_enterprise_mmi_module_id",
        ),
        nullable=False,
        comment="FK to enterprise_context_modules.id; CASCADE DELETE removes join row",
    )
    memory_item_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_memory_items.id",
            ondelete="CASCADE",
            name="fk_enterprise_mmi_memory_item_id",
        ),
        nullable=False,
        comment="FK to enterprise_memory_items.id; CASCADE DELETE removes join row",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    context_module: Mapped["EnterpriseContextModule"] = relationship(
        "EnterpriseContextModule",
        back_populates="memory_item_links",
        lazy="joined",
    )
    memory_item: Mapped["EnterpriseMemoryItem"] = relationship(
        "EnterpriseMemoryItem",
        back_populates="module_links",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "module_id",
            "memory_item_id",
            "tenant_id",
            name="uq_enterprise_module_memory_item",
        ),
        Index("ix_enterprise_module_memory_items_tenant_id", "tenant_id"),
        Index("ix_enterprise_module_memory_items_module_id", "module_id"),
        Index("ix_enterprise_module_memory_items_memory_item_id", "memory_item_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseModuleMemoryItem."""
        return (
            f"<EnterpriseModuleMemoryItem("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"module_id={self.module_id!r}, "
            f"memory_item_id={self.memory_item_id!r}"
            f")>"
        )


# =============================================================================
# EnterpriseBundleEntity model  (EGCF-2.3)
# =============================================================================


class EnterpriseBundleEntity(EnterpriseBase):
    """Tenant-scoped bundle definition.

    A bundle entity is the top-level record describing a named, typed
    collection of artifacts that can be versioned via ``EnterpriseBundleCommit``
    and deployed as a unit.  Configuration and schema-level constraints are
    stored in the ``config`` JSONB column so the table remains stable as bundle
    types evolve.

    OQ-2 note: This model is distinct from the local DVCS ``BundleCommit``
    (models.py, DVCS-2.1), which snapshots composite artifacts in the
    filesystem/SQLite stack.  Enterprise bundle entities are higher-level named
    definitions; their commit history is stored in ``EnterpriseBundleCommit``
    as JSONB snapshots — no FK to the CAS blob tables is required.

    Attributes:
        id:           UUID primary key; globally unique.
        tenant_id:    Denormalised tenant scope; every query MUST include
                      WHERE tenant_id = ?.
        name:         Human-readable name for this bundle (required).
        description:  Optional free-text description.
        bundle_type:  Discriminator for bundle variant (e.g. 'skill', 'workflow',
                      'mixed').  Nullable to allow schema-less bundles.
        config:       JSONB bundle-level configuration (schema validated by app).
        status:       Lifecycle status — 'draft', 'published', or 'archived'.
        created_at:   Timezone-aware creation timestamp (server default: now()).
        updated_at:   Timezone-aware last-modified timestamp (app-managed).

    Constraints:
        ck_enterprise_bundle_entities_status:
            status IN ('draft', 'published', 'archived')

    Indexes:
        ix_enterprise_bundle_entities_tenant_id: (tenant_id)
        ix_enterprise_bundle_entities_status:    (status)
    """

    __tablename__ = "enterprise_bundle_entities"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique bundle entity identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Definition
    # -------------------------------------------------------------------------

    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable name for the bundle",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of the bundle's purpose",
    )
    bundle_type: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Bundle variant discriminator, e.g. 'skill', 'workflow', 'mixed'",
    )
    config: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB bundle-level configuration; schema validated by the application layer",
    )
    status: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        default="draft",
        server_default=text("'draft'"),
        comment="Lifecycle status: draft, published, or archived",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    memberships: Mapped[List["EnterpriseBundleMembership"]] = relationship(
        "EnterpriseBundleMembership",
        back_populates="bundle",
        cascade="all, delete-orphan",
        lazy="select",
    )
    commits: Mapped[List["EnterpriseBundleCommit"]] = relationship(
        "EnterpriseBundleCommit",
        back_populates="bundle",
        cascade="all, delete-orphan",
        lazy="select",
        order_by="EnterpriseBundleCommit.committed_at",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        CheckConstraint(
            "status IN ('draft', 'published', 'archived')",
            name="ck_enterprise_bundle_entities_status",
        ),
        Index("ix_enterprise_bundle_entities_tenant_id", "tenant_id"),
        Index("ix_enterprise_bundle_entities_status", "status"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseBundleEntity."""
        return (
            f"<EnterpriseBundleEntity("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"status={self.status!r}"
            f")>"
        )


# =============================================================================
# EnterpriseBundleMembership model  (EGCF-2.3 — join table)
# =============================================================================


class EnterpriseBundleMembership(EnterpriseBase):
    """Junction table mapping enterprise artifacts to bundle entities.

    Each row represents one artifact's membership within a bundle.  The
    ``position`` column provides optional ordering for bundles where display
    or apply order matters.  Per-membership configuration overrides are
    available via the ``config`` JSONB column.

    Tenant isolation invariant:
        ``tenant_id`` is denormalised onto every join row so that cross-bundle
        queries can filter by tenant without joining back to the parent tables.

    Attributes:
        id:          UUID primary key; globally unique join-row identifier.
        tenant_id:   Denormalised tenant scope; every query MUST include
                     WHERE tenant_id = ?.
        bundle_id:   FK to enterprise_bundle_entities.id; CASCADE DELETE
                     removes membership when the bundle is deleted.
        artifact_id: FK to enterprise_artifacts.id; CASCADE DELETE removes
                     membership when the artifact is deleted.
        position:    Optional integer ordering hint (NULL = unordered).
        config:      JSONB per-membership configuration overrides.

    Constraints:
        uq_enterprise_bundle_membership: UNIQUE(bundle_id, artifact_id, tenant_id)

    Indexes:
        ix_enterprise_bundle_memberships_tenant_id:   (tenant_id)
        ix_enterprise_bundle_memberships_bundle_id:   (bundle_id)
        ix_enterprise_bundle_memberships_artifact_id: (artifact_id)
    """

    __tablename__ = "enterprise_bundle_memberships"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique join-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    bundle_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_bundle_entities.id",
            ondelete="CASCADE",
            name="fk_enterprise_bundle_membership_bundle_id",
        ),
        nullable=False,
        comment="FK to enterprise_bundle_entities.id; CASCADE DELETE removes join row",
    )
    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_bundle_membership_artifact_id",
        ),
        nullable=False,
        comment="FK to enterprise_artifacts.id; CASCADE DELETE removes join row",
    )

    # -------------------------------------------------------------------------
    # Membership metadata
    # -------------------------------------------------------------------------

    position: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        comment="Optional ordering hint; NULL means unordered within the bundle",
    )
    config: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB per-membership configuration overrides",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    bundle: Mapped["EnterpriseBundleEntity"] = relationship(
        "EnterpriseBundleEntity",
        back_populates="memberships",
        lazy="joined",
    )
    artifact: Mapped["EnterpriseArtifact"] = relationship(
        "EnterpriseArtifact",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "bundle_id",
            "artifact_id",
            "tenant_id",
            name="uq_enterprise_bundle_membership",
        ),
        Index("ix_enterprise_bundle_memberships_tenant_id", "tenant_id"),
        Index("ix_enterprise_bundle_memberships_bundle_id", "bundle_id"),
        Index("ix_enterprise_bundle_memberships_artifact_id", "artifact_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseBundleMembership."""
        return (
            f"<EnterpriseBundleMembership("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"bundle_id={self.bundle_id!r}, "
            f"artifact_id={self.artifact_id!r}"
            f")>"
        )


# =============================================================================
# EnterpriseBundleCommit model  (EGCF-2.3)
# =============================================================================


class EnterpriseBundleCommit(EnterpriseBase):
    """Versioned snapshot of an enterprise bundle entity's membership state.

    Each row records an immutable, labelled point-in-time snapshot of which
    artifacts belonged to a bundle and their configuration at that moment.
    The full membership payload is captured in ``snapshot_data`` (JSONB) so
    that historical state can be reconstructed without re-joining membership
    rows.  Commits form a singly-linked chain via ``parent_hash``.

    OQ-2 — distinct from local DVCS BundleCommit:
        The local-mode ``BundleCommit`` (models.py, DVCS-2.1) is a per-composite-
        artifact DVCS snapshot linked to ``artifacts.uuid`` and ``ArtifactBlob``
        (CAS).  ``EnterpriseBundleCommit`` is a higher-level versioning primitive
        for named bundle *definitions* (``EnterpriseBundleEntity``) — it does not
        participate in the CAS pipeline and therefore carries no FK to
        ``EnterpriseArtifactBlob``.  Snapshot data is stored inline as JSONB.

    Attributes:
        id:            UUID primary key; globally unique.
        tenant_id:     Denormalised tenant scope; every query MUST include
                       WHERE tenant_id = ?.
        bundle_id:     FK to enterprise_bundle_entities.id; CASCADE DELETE
                       removes commits when the bundle is deleted.
        commit_hash:   Deterministic or app-generated content identifier
                       (max 64 chars), e.g. a SHA-256 hex digest.
        message:       Optional human-readable commit message.
        committed_at:  Timezone-aware timestamp when the commit was recorded.
        parent_hash:   Optional hash of the preceding commit; NULL for the
                       first commit in a bundle's history.
        snapshot_data: JSONB full-membership snapshot at commit time.
        created_at:    Timezone-aware creation timestamp (server default: now()).

    Indexes:
        ix_enterprise_bundle_commits_tenant_id:   (tenant_id)
        ix_enterprise_bundle_commits_bundle_id:   (bundle_id)
        ix_enterprise_bundle_commits_commit_hash: (commit_hash)
    """

    __tablename__ = "enterprise_bundle_commits"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique bundle commit identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    bundle_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_bundle_entities.id",
            ondelete="CASCADE",
            name="fk_enterprise_bundle_commit_bundle_id",
        ),
        nullable=False,
        comment="FK to enterprise_bundle_entities.id; CASCADE DELETE removes commits with bundle",
    )

    # -------------------------------------------------------------------------
    # Commit identity
    # -------------------------------------------------------------------------

    commit_hash: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        comment="Deterministic or app-generated content hash (max 64 chars); not globally unique across tenants",
    )
    message: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional human-readable commit message",
    )
    committed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware timestamp when the commit was recorded",
    )
    parent_hash: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="Hash of the preceding commit in this bundle's history; NULL for the first commit",
    )

    # -------------------------------------------------------------------------
    # Snapshot payload
    # -------------------------------------------------------------------------

    snapshot_data: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB full-membership snapshot at commit time; enables point-in-time reconstruction",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    bundle: Mapped["EnterpriseBundleEntity"] = relationship(
        "EnterpriseBundleEntity",
        back_populates="commits",
        lazy="joined",
    )
    members: Mapped[List["EnterpriseBundleCommitMember"]] = relationship(
        "EnterpriseBundleCommitMember",
        back_populates="commit",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        Index("ix_enterprise_bundle_commits_tenant_id", "tenant_id"),
        Index("ix_enterprise_bundle_commits_bundle_id", "bundle_id"),
        Index("ix_enterprise_bundle_commits_commit_hash", "commit_hash"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseBundleCommit."""
        return (
            f"<EnterpriseBundleCommit("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"bundle_id={self.bundle_id!r}, "
            f"commit_hash={self.commit_hash!r}"
            f")>"
        )


# =============================================================================
# EnterpriseBundleCommitMember model  (EGCF-2.3 — join table)
# =============================================================================


class EnterpriseBundleCommitMember(EnterpriseBase):
    """Per-artifact membership row within a bundle commit snapshot.

    Records exactly which artifacts were included in a specific bundle commit,
    at which version reference they were pinned, and any additional metadata
    captured at snapshot time.  Together with ``EnterpriseBundleCommit.snapshot_data``
    this provides two levels of snapshot fidelity: a quick JSONB summary on
    the commit row and normalised per-artifact rows here for structured querying.

    Tenant isolation invariant:
        ``tenant_id`` is denormalised onto every join row so that per-tenant
        cross-commit queries remain efficient without joining parent tables.

    Attributes:
        id:          UUID primary key; globally unique join-row identifier.
        tenant_id:   Denormalised tenant scope; every query MUST include
                     WHERE tenant_id = ?.
        commit_id:   FK to enterprise_bundle_commits.id; CASCADE DELETE
                     removes member rows when the commit is deleted.
        artifact_id: FK to enterprise_artifacts.id; CASCADE DELETE removes
                     member row when the artifact is deleted.
        version_ref:    Optional version reference string pinned at commit time
                        (e.g. a SHA, tag, or semver).
        extra_metadata: JSONB additional metadata captured at snapshot time.
                        Named ``extra_metadata`` (not ``metadata``) to avoid
                        shadowing SQLAlchemy's reserved DeclarativeBase.metadata.

    Constraints:
        uq_enterprise_bundle_commit_member: UNIQUE(commit_id, artifact_id, tenant_id)

    Indexes:
        ix_enterprise_bundle_commit_members_tenant_id:   (tenant_id)
        ix_enterprise_bundle_commit_members_commit_id:   (commit_id)
        ix_enterprise_bundle_commit_members_artifact_id: (artifact_id)
    """

    __tablename__ = "enterprise_bundle_commit_members"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique join-row identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    commit_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_bundle_commits.id",
            ondelete="CASCADE",
            name="fk_enterprise_bundle_commit_member_commit_id",
        ),
        nullable=False,
        comment="FK to enterprise_bundle_commits.id; CASCADE DELETE removes member rows with commit",
    )
    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_bundle_commit_member_artifact_id",
        ),
        nullable=False,
        comment="FK to enterprise_artifacts.id; CASCADE DELETE removes member row with artifact",
    )

    # -------------------------------------------------------------------------
    # Snapshot metadata
    # -------------------------------------------------------------------------

    version_ref: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Version reference pinned at commit time, e.g. a SHA, tag, or semver; NULL if unversioned",
    )
    # Named extra_metadata (not metadata) to avoid shadowing
    # SQLAlchemy's reserved DeclarativeBase.metadata attribute.
    extra_metadata: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB additional metadata captured at snapshot time",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    commit: Mapped["EnterpriseBundleCommit"] = relationship(
        "EnterpriseBundleCommit",
        back_populates="members",
        lazy="joined",
    )
    artifact: Mapped["EnterpriseArtifact"] = relationship(
        "EnterpriseArtifact",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "commit_id",
            "artifact_id",
            "tenant_id",
            name="uq_enterprise_bundle_commit_member",
        ),
        Index("ix_enterprise_bundle_commit_members_tenant_id", "tenant_id"),
        Index("ix_enterprise_bundle_commit_members_commit_id", "commit_id"),
        Index("ix_enterprise_bundle_commit_members_artifact_id", "artifact_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseBundleCommitMember."""
        return (
            f"<EnterpriseBundleCommitMember("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"commit_id={self.commit_id!r}, "
            f"artifact_id={self.artifact_id!r}"
            f")>"
        )


# =============================================================================
# EnterpriseBomSnapshot model  (EGCF-2.4)
# =============================================================================


class EnterpriseBomSnapshot(EnterpriseBase):
    """Bill-of-materials snapshot for an artifact.

    Each row captures a point-in-time BOM for an artifact, recording the full
    dependency graph (or other BOM-format data) in ``snapshot_data``.  The
    optional ``format_version`` discriminates SPDX, CycloneDX, and custom
    schema variants so that consumers can parse ``snapshot_data`` correctly.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.

    Attributes:
        id:              UUID primary key; globally unique.
        tenant_id:       Tenant scope; every query MUST filter by this column.
        artifact_id:     FK to enterprise_artifacts.id; CASCADE DELETE removes
                         snapshots when the artifact is deleted.
        snapshot_data:   JSONB BOM payload (components, dependencies, etc.).
        generated_at:    Timezone-aware timestamp when the BOM was generated.
        format_version:  Optional format discriminator, e.g. 'spdx-2.3',
                         'cyclonedx-1.5'; NULL means unspecified / custom.
        created_at:      Timezone-aware creation timestamp (server default: now()).

    Relationships:
        artifact:    Back-reference to the parent EnterpriseArtifact.
        metadata:    One-to-one back-reference to EnterpriseBomMetadata.
        attestations: Back-reference to EnterpriseAttestationRecord rows.

    Indexes:
        ix_enterprise_bom_snapshots_tenant_id:   (tenant_id)
        ix_enterprise_bom_snapshots_artifact_id: (artifact_id)
    """

    __tablename__ = "enterprise_bom_snapshots"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique BOM snapshot identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_bom_snapshot_artifact_id",
        ),
        nullable=False,
        comment="FK to enterprise_artifacts.id; CASCADE DELETE removes snapshot with artifact",
    )

    # -------------------------------------------------------------------------
    # BOM payload
    # -------------------------------------------------------------------------

    snapshot_data: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB BOM payload capturing components, dependencies, and metadata",
    )
    generated_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp when the BOM was generated; NULL if unknown",
    )
    format_version: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Format discriminator, e.g. 'spdx-2.3', 'cyclonedx-1.5'; NULL if unspecified",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    artifact: Mapped["EnterpriseArtifact"] = relationship(
        "EnterpriseArtifact",
        lazy="joined",
    )
    bom_metadata: Mapped[Optional["EnterpriseBomMetadata"]] = relationship(
        "EnterpriseBomMetadata",
        back_populates="snapshot",
        cascade="all, delete-orphan",
        lazy="select",
        uselist=False,
    )
    attestations: Mapped[List["EnterpriseAttestationRecord"]] = relationship(
        "EnterpriseAttestationRecord",
        back_populates="snapshot",
        cascade="all, delete-orphan",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        Index("ix_enterprise_bom_snapshots_tenant_id", "tenant_id"),
        Index("ix_enterprise_bom_snapshots_artifact_id", "artifact_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseBomSnapshot."""
        return (
            f"<EnterpriseBomSnapshot("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"format_version={self.format_version!r}"
            f")>"
        )


# =============================================================================
# EnterpriseAttestationPolicy model  (EGCF-2.4)
# =============================================================================


class EnterpriseAttestationPolicy(EnterpriseBase):
    """Policy definition governing attestation checks.

    An attestation policy captures the rules and criteria used to evaluate a
    BOM snapshot for compliance, security, or quality.  The ``rules`` JSONB
    column holds the machine-readable rule set; ``policy_type`` provides a
    semantic discriminator (e.g. 'security', 'license', 'quality').

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.

    Attributes:
        id:           UUID primary key; globally unique.
        tenant_id:    Tenant scope; every query MUST filter by this column.
        name:         Human-readable policy name (required, unique per tenant).
        description:  Optional free-text description of the policy's purpose.
        policy_type:  Semantic category, e.g. 'security', 'license', 'quality'.
        rules:        JSONB rule set evaluated during attestation checks.
        status:       Lifecycle status — 'active', 'inactive', or 'archived'.
        created_at:   Timezone-aware creation timestamp (server default: now()).
        updated_at:   Timezone-aware last-modified timestamp (app-managed).

    Constraints:
        uq_enterprise_attestation_policies_tenant_name:
            UNIQUE (tenant_id, name)
        ck_enterprise_attestation_policies_status:
            status IN ('active', 'inactive', 'archived')

    Indexes:
        ix_enterprise_attestation_policies_tenant_id: (tenant_id)
    """

    __tablename__ = "enterprise_attestation_policies"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique attestation policy identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Policy definition
    # -------------------------------------------------------------------------

    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable policy name; unique within a tenant",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of the policy's purpose",
    )
    policy_type: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Semantic category of the policy, e.g. 'security', 'license', 'quality'",
    )
    rules: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB rule set evaluated during attestation checks",
    )
    status: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        default="active",
        server_default=text("'active'"),
        comment="Lifecycle status: active, inactive, or archived",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    records: Mapped[List["EnterpriseAttestationRecord"]] = relationship(
        "EnterpriseAttestationRecord",
        back_populates="policy",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_enterprise_attestation_policies_tenant_name",
        ),
        CheckConstraint(
            "status IN ('active', 'inactive', 'archived')",
            name="ck_enterprise_attestation_policies_status",
        ),
        Index("ix_enterprise_attestation_policies_tenant_id", "tenant_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseAttestationPolicy."""
        return (
            f"<EnterpriseAttestationPolicy("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"name={self.name!r}, "
            f"status={self.status!r}"
            f")>"
        )


# =============================================================================
# EnterpriseAttestationRecord model  (EGCF-2.4)
# =============================================================================


class EnterpriseAttestationRecord(EnterpriseBase):
    """Result of an attestation check run against a BOM snapshot.

    Each row records the outcome of evaluating one attestation policy against
    one BOM snapshot.  The ``result`` column captures the binary outcome; the
    ``evidence`` JSONB column stores supporting data (rule failures, scores,
    tool output) that produced the result.

    Tenant isolation invariant:
        ``tenant_id`` is denormalised onto every record so that cross-snapshot
        queries can apply a tenant predicate without joining parent tables.

    Attributes:
        id:          UUID primary key; globally unique.
        tenant_id:   Denormalised tenant scope; every query MUST include
                     WHERE tenant_id = ?.
        snapshot_id: FK to enterprise_bom_snapshots.id; CASCADE DELETE removes
                     records when the snapshot is deleted.
        policy_id:   FK to enterprise_attestation_policies.id; SET NULL when
                     the policy is deleted (record is retained for audit).
        result:      Attestation outcome — 'pass', 'fail', 'warning', or 'error'.
        attested_at: Timezone-aware timestamp when the attestation was run.
        evidence:    JSONB supporting data (rule failures, scores, tool output).
        created_at:  Timezone-aware creation timestamp (server default: now()).

    Constraints:
        ck_enterprise_attestation_records_result:
            result IN ('pass', 'fail', 'warning', 'error')

    Indexes:
        ix_enterprise_attestation_records_tenant_id:   (tenant_id)
        ix_enterprise_attestation_records_snapshot_id: (snapshot_id)
        ix_enterprise_attestation_records_policy_id:   (policy_id)
    """

    __tablename__ = "enterprise_attestation_records"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique attestation record identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    snapshot_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_bom_snapshots.id",
            ondelete="CASCADE",
            name="fk_enterprise_attestation_record_snapshot_id",
        ),
        nullable=False,
        comment="FK to enterprise_bom_snapshots.id; CASCADE DELETE removes record with snapshot",
    )
    policy_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_attestation_policies.id",
            ondelete="SET NULL",
            name="fk_enterprise_attestation_record_policy_id",
        ),
        nullable=True,
        comment="FK to enterprise_attestation_policies.id; SET NULL retains record when policy deleted",
    )

    # -------------------------------------------------------------------------
    # Attestation result
    # -------------------------------------------------------------------------

    result: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Attestation outcome: pass, fail, warning, or error",
    )
    attested_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp when the attestation was performed",
    )
    evidence: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB supporting data: rule failures, scores, tool output",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    snapshot: Mapped["EnterpriseBomSnapshot"] = relationship(
        "EnterpriseBomSnapshot",
        back_populates="attestations",
        lazy="joined",
    )
    policy: Mapped[Optional["EnterpriseAttestationPolicy"]] = relationship(
        "EnterpriseAttestationPolicy",
        back_populates="records",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        CheckConstraint(
            "result IN ('pass', 'fail', 'warning', 'error')",
            name="ck_enterprise_attestation_records_result",
        ),
        Index("ix_enterprise_attestation_records_tenant_id", "tenant_id"),
        Index("ix_enterprise_attestation_records_snapshot_id", "snapshot_id"),
        Index("ix_enterprise_attestation_records_policy_id", "policy_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseAttestationRecord."""
        return (
            f"<EnterpriseAttestationRecord("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"snapshot_id={self.snapshot_id!r}, "
            f"result={self.result!r}"
            f")>"
        )


# =============================================================================
# EnterpriseBomMetadata model  (EGCF-2.4)
# =============================================================================


class EnterpriseBomMetadata(EnterpriseBase):
    """Additional metadata for a BOM snapshot (one-per-snapshot).

    Stores tooling, provenance, and tagging information that is logically
    separate from the BOM payload itself.  A UNIQUE constraint on
    ``snapshot_id`` enforces the one-metadata-per-snapshot invariant.

    Tenant isolation invariant:
        ``tenant_id`` is denormalised onto every metadata row so that
        per-tenant queries remain efficient without joining the snapshot table.

    Attributes:
        id:            UUID primary key; globally unique.
        tenant_id:     Denormalised tenant scope; every query MUST include
                       WHERE tenant_id = ?.
        snapshot_id:   FK to enterprise_bom_snapshots.id (CASCADE DELETE,
                       UNIQUE — one metadata row per snapshot).
        tool_name:     Name of the tool that generated the BOM, e.g. 'syft'.
        tool_version:  Version of the BOM generation tool, e.g. '0.98.0'.
        source_info:   JSONB provenance metadata (VCS URL, commit, branch).
        tags:          JSONB array of string tags for filtering / grouping.
        created_at:    Timezone-aware creation timestamp (server default: now()).

    Constraints:
        uq_enterprise_bom_metadata_snapshot_id: UNIQUE (snapshot_id)

    Indexes:
        ix_enterprise_bom_metadata_tenant_id:   (tenant_id)
        ix_enterprise_bom_metadata_snapshot_id: (snapshot_id)
    """

    __tablename__ = "enterprise_bom_metadata"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Globally unique BOM metadata identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    snapshot_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_bom_snapshots.id",
            ondelete="CASCADE",
            name="fk_enterprise_bom_metadata_snapshot_id",
        ),
        nullable=False,
        comment="FK to enterprise_bom_snapshots.id; CASCADE DELETE removes metadata with snapshot",
    )

    # -------------------------------------------------------------------------
    # Tooling provenance
    # -------------------------------------------------------------------------

    tool_name: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Name of the BOM generation tool, e.g. 'syft', 'cdxgen'",
    )
    tool_version: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Version string of the BOM generation tool, e.g. '0.98.0'",
    )
    source_info: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB provenance metadata: VCS URL, commit SHA, branch, etc.",
    )
    tags: Mapped[List[Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=list,
        server_default=text("'[]'::jsonb"),
        comment="JSONB array of string tags for filtering and grouping BOM snapshots",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    snapshot: Mapped["EnterpriseBomSnapshot"] = relationship(
        "EnterpriseBomSnapshot",
        back_populates="bom_metadata",
        lazy="joined",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "snapshot_id",
            name="uq_enterprise_bom_metadata_snapshot_id",
        ),
        Index("ix_enterprise_bom_metadata_tenant_id", "tenant_id"),
        Index("ix_enterprise_bom_metadata_snapshot_id", "snapshot_id"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseBomMetadata."""
        return (
            f"<EnterpriseBomMetadata("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"snapshot_id={self.snapshot_id!r}, "
            f"tool_name={self.tool_name!r}"
            f")>"
        )


# =============================================================================
# Important-tier domain models (Phase 5)
# =============================================================================


# =============================================================================
# EnterpriseContextEntityCategory model  (EGCF-5.1)
# =============================================================================


class EnterpriseContextEntityCategory(EnterpriseBase):
    """Tenant-scoped category taxonomy for context entity classification.

    Each row represents a named category used to classify artifacts and context
    entities within a tenant.  Categories are uniquely identified within a
    tenant by their ``slug`` (URL-safe identifier).  An optional ``sort_order``
    controls display ordering in the UI.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:           UUID PK, server-generated via gen_random_uuid().
        tenant_id:    Tenant scope.
        name:         Human-readable category label.
        slug:         URL-safe identifier; unique within the tenant.
        description:  Optional free-text description of the category.
        sort_order:   Optional integer controlling display order; defaults to 0.
        created_at:   Timezone-aware creation timestamp.
        updated_at:   Timezone-aware last-modified timestamp.

    Constraints:
        uq_enterprise_cec_tenant_slug: UNIQUE (tenant_id, slug)

    Indexes:
        idx_enterprise_cec_tenant_id:   (tenant_id)
        idx_enterprise_cec_tenant_slug: (tenant_id, slug)
    """

    __tablename__ = "enterprise_context_entity_categories"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique category identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Human-readable category label shown in the UI",
    )
    slug: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="URL-safe identifier for the category; unique within tenant",
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text description of this category",
    )
    sort_order: Mapped[Optional[int]] = mapped_column(
        Integer,
        nullable=True,
        default=0,
        comment="Display sort order; lower values appear first; defaults to 0",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "slug",
            name="uq_enterprise_cec_tenant_slug",
        ),
        Index("idx_enterprise_cec_tenant_id", "tenant_id"),
        Index("idx_enterprise_cec_tenant_slug", "tenant_id", "slug"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseContextEntityCategory."""
        return (
            f"<EnterpriseContextEntityCategory("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"slug={self.slug!r}, "
            f"name={self.name!r}"
            f")>"
        )


# =============================================================================
# EnterpriseArtifactCategoryAssociation model  (EGCF-5.1)
# =============================================================================


class EnterpriseArtifactCategoryAssociation(EnterpriseBase):
    """Junction table linking artifacts to context entity categories.

    Each row records the membership of one artifact in one category within a
    tenant.  The combination of ``(artifact_id, category_id, tenant_id)`` is
    unique, preventing duplicate associations.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:          UUID PK, server-generated via gen_random_uuid().
        tenant_id:   Tenant scope (denormalised for query isolation).
        artifact_id: FK to enterprise_artifacts.id; CASCADE DELETE.
        category_id: FK to enterprise_context_entity_categories.id; CASCADE DELETE.
        created_at:  Timezone-aware creation timestamp.

    Constraints:
        uq_enterprise_aca_artifact_category_tenant: UNIQUE (artifact_id, category_id, tenant_id)

    Indexes:
        idx_enterprise_aca_tenant_id:   (tenant_id)
        idx_enterprise_aca_artifact_id: (artifact_id)
        idx_enterprise_aca_category_id: (category_id)
    """

    __tablename__ = "enterprise_artifact_category_associations"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique association identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_aca_artifact_id",
        ),
        nullable=False,
        comment="FK to enterprise_artifacts.id; CASCADE DELETE removes association with artifact",
    )
    category_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_context_entity_categories.id",
            ondelete="CASCADE",
            name="fk_enterprise_aca_category_id",
        ),
        nullable=False,
        comment="FK to enterprise_context_entity_categories.id; CASCADE DELETE removes association with category",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )

    __table_args__ = (
        UniqueConstraint(
            "artifact_id",
            "category_id",
            "tenant_id",
            name="uq_enterprise_aca_artifact_category_tenant",
        ),
        Index("idx_enterprise_aca_tenant_id", "tenant_id"),
        Index("idx_enterprise_aca_artifact_id", "artifact_id"),
        Index("idx_enterprise_aca_category_id", "category_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseArtifactCategoryAssociation."""
        return (
            f"<EnterpriseArtifactCategoryAssociation("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"category_id={self.category_id!r}"
            f")>"
        )


# =============================================================================
# EnterpriseArtifactHistoryEvent model  (EGCF-5.2)
# =============================================================================


class EnterpriseArtifactHistoryEvent(EnterpriseBase):
    """Immutable audit event recording lifecycle changes to an artifact.

    Each row captures a single lifecycle event (creation, update, deployment,
    version addition, etc.) that occurred on an artifact.  Rows are
    append-only; once written they are never updated.  The optional ``actor_id``
    records who triggered the event, and the JSONB ``payload`` carries
    event-specific metadata.

    Tenant isolation invariant:
        Every query MUST include ``WHERE tenant_id = ?``.

    Attributes:
        id:           UUID PK, server-generated via gen_random_uuid().
        tenant_id:    Tenant scope (denormalised for query isolation).
        artifact_id:  FK to enterprise_artifacts.id; CASCADE DELETE.
        event_type:   String event discriminator, e.g. 'created', 'updated',
                      'deployed', 'version_added'.
        owner_type:   Owner context at the time of the event; defaults to
                      'user'.  Added by ent_026.
        actor_id:     Optional UUID of the user who performed the action.
        payload:      JSONB bag carrying event-specific metadata; NOT NULL,
                      defaults to {}.
        diff_json:    Optional JSON-serialised diff payload describing what
                      changed.  Added by ent_026.
        content_hash: Optional SHA-256 hex digest of artifact content at
                      event time.  Added by ent_026.
        created_at:   Timezone-aware event timestamp; server-generated.

    Indexes:
        idx_enterprise_ahe_tenant_id:         (tenant_id)
        idx_enterprise_ahe_artifact_id:       (artifact_id)
        idx_enterprise_ahe_tenant_event_type: (tenant_id, event_type)
        idx_enterprise_ahe_tenant_created:    (tenant_id, created_at)
                                              — added by ent_022; declared
                                              here for autogenerate visibility.
    """

    __tablename__ = "enterprise_artifact_history_events"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique history event identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Denormalised tenant scope; every query MUST include WHERE tenant_id = ?",
    )
    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_ahe_artifact_id",
        ),
        nullable=False,
        comment="FK to enterprise_artifacts.id; CASCADE DELETE removes events with artifact",
    )
    event_type: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Lifecycle event discriminator, e.g. 'created', 'updated', 'deployed', 'version_added'",
    )
    owner_type: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        default="user",
        server_default=text("'user'"),
        comment="Owner context at the time of the event; defaults to 'user'",
    )
    actor_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="UUID of the user who triggered the event; NULL for system-generated events",
    )
    payload: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        server_default=text("'{}'::jsonb"),
        comment="JSONB bag of event-specific metadata; initialized to empty object",
    )
    diff_json: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="JSON-serialised diff payload describing what changed; NULL when unavailable",
    )
    content_hash: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="SHA-256 hex digest of artifact content at event time; NULL when unavailable",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware event timestamp; server-generated; rows are immutable",
    )

    __table_args__ = (
        Index("idx_enterprise_ahe_tenant_id", "tenant_id"),
        Index("idx_enterprise_ahe_artifact_id", "artifact_id"),
        Index("idx_enterprise_ahe_tenant_event_type", "tenant_id", "event_type"),
        # Added by ent_022_admin_sync_prereq; declared here for autogenerate
        # visibility.  The migration does NOT recreate it — only the ORM
        # declaration was missing.
        Index("idx_enterprise_ahe_tenant_created", "tenant_id", "created_at"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseArtifactHistoryEvent."""
        return (
            f"<EnterpriseArtifactHistoryEvent("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"event_type={self.event_type!r}"
            f")>"
        )


# =============================================================================
# Enterprise Git Connection Join Table  (GCD-1.3)
# =============================================================================


class EnterpriseProjectGitConnection(EnterpriseBase):
    """Join table linking enterprise projects to enterprise git-repo connections (GCD-1.3).

    Supports a many-to-many relationship between projects and git-repo connections
    in the enterprise edition.  All rows carry ``tenant_id`` for the mandatory
    tenant-isolation query pattern.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.  Omitting it is a security defect that leaks cross-tenant data.

    Attributes:
        project_id:    UUID FK to ``enterprise_projects.id`` (ON DELETE CASCADE); part of composite PK.
        connection_id: UUID FK to ``enterprise_git_repo_connections.id`` (ON DELETE CASCADE); part of composite PK.
        linked_at:     Timezone-aware UTC timestamp when the link was created.
        linked_by:     Optional UUID of the enterprise user who created the link.
        tenant_id:     Tenant scope; every query MUST filter by this column.
        project:       Back-reference to the linked ``EnterpriseProject``.
        connection:    Back-reference to the linked ``EnterpriseGitRepoConnection``.

    Table:
        enterprise_project_git_connections

    Constraints:
        pk_enterprise_project_git_connections: PRIMARY KEY (project_id, connection_id)

    Indexes:
        idx_ent_pgc_tenant_project    (tenant_id, project_id)
        idx_ent_pgc_tenant_connection (tenant_id, connection_id)
    """

    __tablename__ = "enterprise_project_git_connections"

    # -------------------------------------------------------------------------
    # Composite primary key
    # -------------------------------------------------------------------------

    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_projects.id",
            ondelete="CASCADE",
            name="fk_ent_pgc_project_id",
        ),
        primary_key=True,
        nullable=False,
        comment="FK to enterprise_projects.id; row deleted when project is deleted",
    )
    connection_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_git_repo_connections.id",
            ondelete="CASCADE",
            name="fk_ent_pgc_connection_id",
        ),
        primary_key=True,
        nullable=False,
        comment="FK to enterprise_git_repo_connections.id; row deleted when connection is deleted",
    )

    # -------------------------------------------------------------------------
    # Audit / provenance
    # -------------------------------------------------------------------------

    linked_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware UTC timestamp when the connection was linked to the project",
    )
    linked_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment=(
            "Optional UUID of the enterprise user who created the link. "
            "Stored as a plain reference (no FK) to avoid cascade complexity."
        ),
    )

    # -------------------------------------------------------------------------
    # Tenant isolation
    # -------------------------------------------------------------------------

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    project: Mapped["EnterpriseProject"] = relationship(
        "EnterpriseProject",
        foreign_keys=[project_id],
        lazy="select",
    )
    connection: Mapped["EnterpriseGitRepoConnection"] = relationship(
        "EnterpriseGitRepoConnection",
        back_populates="linked_projects",
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        Index("idx_ent_pgc_tenant_project", "tenant_id", "project_id"),
        Index("idx_ent_pgc_tenant_connection", "tenant_id", "connection_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseProjectGitConnection."""
        return (
            f"<EnterpriseProjectGitConnection("
            f"project_id={self.project_id!r}, "
            f"connection_id={self.connection_id!r}, "
            f"tenant_id={self.tenant_id!r}"
            f")>"
        )


class EnterpriseGitCredential(EnterpriseBase):
    """Enterprise-scoped credential record for authenticated Git operations (GCD-2.3).

    Stores an encrypted token that can be attached to an
    ``EnterpriseGitRepoConnection`` or used independently for a given org,
    team, or developer scope.  All identifiers are UUIDs and every row is
    tenant-scoped.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.  Omitting it is a security defect that leaks cross-tenant data.

    Attributes:
        id:               UUID PK, server-generated via gen_random_uuid().
        tenant_id:        Tenant scope; every query MUST filter by this column.
        scope_type:       Owner scope: ``'org'``, ``'team'``, or ``'developer'``.
        scope_id:         UUID identifying the scope owner.
        connection_id:    Optional UUID FK to ``enterprise_git_repo_connections.id``
                          (ON DELETE CASCADE).
        token_encrypted:  Encrypted personal access token or app-installation token.
        credential_type:  Token kind: ``'pat'`` (default) or ``'app_installation'``.
        created_by:       Optional UUID of the enterprise user who created the credential.
        created_at:       Timezone-aware UTC creation timestamp.
        connection:       Back-reference to the optional parent
                          ``EnterpriseGitRepoConnection``.

    Table:
        enterprise_git_credentials

    Indexes:
        idx_ent_git_credentials_tenant_scope  (tenant_id, scope_type, scope_id)
        idx_ent_git_credentials_conn          (tenant_id, connection_id)
    """

    __tablename__ = "enterprise_git_credentials"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique credential identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Scope
    # -------------------------------------------------------------------------

    scope_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        comment="Owner scope: 'org', 'team', or 'developer'",
    )
    scope_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="UUID identifying the scope owner (org, team, or user)",
    )

    # -------------------------------------------------------------------------
    # Connection linkage (optional)
    # -------------------------------------------------------------------------

    connection_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_git_repo_connections.id",
            ondelete="CASCADE",
            name="fk_ent_git_credentials_connection_id",
        ),
        nullable=True,
        comment="Optional FK to enterprise_git_repo_connections.id; row deleted when connection is deleted",
    )

    # -------------------------------------------------------------------------
    # Token data
    # -------------------------------------------------------------------------

    token_encrypted: Mapped[str] = mapped_column(
        EncryptedString(),
        nullable=False,
        comment="Encrypted credential token (PAT or app-installation token)",
    )
    credential_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        server_default=text("'pat'"),
        comment="Token kind: 'pat' or 'app_installation'",
    )

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="Optional UUID of the enterprise user who created this credential",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Immutable timezone-aware creation timestamp",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    connection: Mapped[Optional["EnterpriseGitRepoConnection"]] = relationship(
        "EnterpriseGitRepoConnection",
        foreign_keys=[connection_id],
        lazy="select",
    )

    # -------------------------------------------------------------------------
    # Constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        Index(
            "idx_ent_git_credentials_tenant_scope",
            "tenant_id",
            "scope_type",
            "scope_id",
        ),
        Index("idx_ent_git_credentials_conn", "tenant_id", "connection_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseGitCredential."""
        return (
            f"<EnterpriseGitCredential("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"scope_type={self.scope_type!r}, "
            f"credential_type={self.credential_type!r}"
            f")>"
        )


# =============================================================================
# EnterpriseCascadePolicy model  (DS-4)
# =============================================================================


class EnterpriseCascadePolicy(EnterpriseBase):
    """Cascade policy configuration for tier propagation in enterprise deployments.

    Implements the three-level policy inheritance chain described in DS-4 §2.2:

        Org-Level Default Policy
            │
            ├── Per-Artifact Override  (artifact_id set, team_id is NULL)
            │       │
            │       └── Per-Team Exemption  (both artifact_id and team_id set)

    The org-level default is represented by a row where both ``artifact_id``
    and ``team_id`` are NULL.  The effective policy for a given (artifact,
    team) is resolved at propagation time by the cascade policy engine:
    1. Start with the org-default row.
    2. Replace with the per-artifact override if one exists.
    3. Replace with the per-team exemption if one exists for (artifact, team).

    ``tenant_id`` is denormalised from ``org_id`` (i.e. the ``EnterpriseSettings``
    row's owning tenant) to keep the standard tenant-isolation query pattern
    uniform across all enterprise tables.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.  Omitting it is a security defect that leaks cross-tenant data.

    Attributes:
        id:               UUID PK, server-generated via gen_random_uuid().
        tenant_id:        Tenant scope; every query MUST filter by this column.
        org_id:           FK to enterprise_settings.id — the org this policy belongs to.
        artifact_id:      Optional FK to enterprise_artifacts.id.
                          NULL  → org-level default policy row.
                          Set   → per-artifact override (if team_id is also NULL)
                                  or per-team exemption (if team_id is set).
        team_id:          Optional FK to enterprise_teams.id.
                          NULL  → applies to all teams (org or artifact level).
                          Set   → per-team exemption for the specified team.
        policy_type:      Cascade action: 'soft_update' or 'hard_update'.
        is_auto_propagate: True → triggers automatically on upstream version bump;
                           False → requires explicit admin action to propagate.
        created_by:       UUID of the enterprise user who created this policy row.
        created_at:       Timezone-aware creation timestamp; server-generated.
        updated_at:       Timezone-aware last-modified timestamp; app-managed.

    Constraints:
        uq_ent_cascade_policy_scope: UNIQUE (org_id, artifact_id, team_id) —
            enforces at most one policy entry per (org, artifact, team) combination.
        ck_ent_cascade_policy_type: CHECK policy_type IN ('soft_update', 'hard_update').
        ck_ent_cascade_policy_team_scope: CHECK that team_id cannot be set without
            artifact_id (no team-only org-wide exemptions — must be per-artifact).

    Indexes:
        idx_ent_cp_tenant_id:       (tenant_id)
        idx_ent_cp_org_id:          (org_id)
        idx_ent_cp_tenant_artifact: (tenant_id, artifact_id) — for artifact-level lookups.
        idx_ent_cp_tenant_team:     (tenant_id, team_id)     — for team-level lookups.
    """

    __tablename__ = "enterprise_cascade_policies"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique cascade policy identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Org linkage
    # -------------------------------------------------------------------------

    org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_settings.id",
            ondelete="CASCADE",
            name="fk_ent_cp_org_id",
        ),
        nullable=False,
        comment="FK to enterprise_settings.id — the organisation this policy is scoped to",
    )

    # -------------------------------------------------------------------------
    # Scope selectors (nullable to represent org-default / per-artifact / per-team)
    # -------------------------------------------------------------------------

    artifact_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_ent_cp_artifact_id",
        ),
        nullable=True,
        comment=(
            "NULL → org-level default policy. "
            "Set  → per-artifact override (team_id NULL) or per-team exemption (team_id set)."
        ),
    )
    team_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_teams.id",
            ondelete="CASCADE",
            name="fk_ent_cp_team_id",
        ),
        nullable=True,
        comment=(
            "NULL → applies to all teams at this scope level. "
            "Set  → per-team exemption; requires artifact_id to also be set."
        ),
    )

    # -------------------------------------------------------------------------
    # Policy configuration
    # -------------------------------------------------------------------------

    policy_type: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        comment="Cascade action: 'soft_update' (prompt developers) or 'hard_update' (auto GitOps PR)",
    )
    is_auto_propagate: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default=text("false"),
        comment=(
            "True  → policy triggers automatically when upstream source bumps a version; "
            "False → policy only activates on explicit admin action."
        ),
    )

    # -------------------------------------------------------------------------
    # Audit / provenance
    # -------------------------------------------------------------------------

    created_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="UUID of the enterprise user who created this policy row",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Only one explicit policy entry per (org, artifact, team) triple.
        # NULLs are treated as distinct by most DB engines for unique constraints,
        # so (org_id, NULL, NULL) — the org default — is unique by standard
        # NULL semantics; this constraint protects the non-NULL combinations.
        UniqueConstraint(
            "org_id",
            "artifact_id",
            "team_id",
            name="uq_ent_cascade_policy_scope",
        ),
        # Domain guard: only the two defined policy types are valid.
        CheckConstraint(
            "policy_type IN ('soft_update', 'hard_update')",
            name="ck_ent_cascade_policy_type",
        ),
        # Structural guard: a team exemption must always be tied to an artifact.
        # (A team_id without an artifact_id has no defined semantics in DS-4.)
        CheckConstraint(
            "team_id IS NULL OR artifact_id IS NOT NULL",
            name="ck_ent_cascade_policy_team_requires_artifact",
        ),
        Index("idx_ent_cp_tenant_id", "tenant_id"),
        Index("idx_ent_cp_org_id", "org_id"),
        Index("idx_ent_cp_tenant_artifact", "tenant_id", "artifact_id"),
        Index("idx_ent_cp_tenant_team", "tenant_id", "team_id"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseCascadePolicy."""
        return (
            f"<EnterpriseCascadePolicy("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"policy_type={self.policy_type!r}, "
            f"artifact_id={self.artifact_id!r}, "
            f"team_id={self.team_id!r}"
            f")>"
        )


# =============================================================================
# EnterpriseCascadePolicyAudit model  (DS-4 §5)
# =============================================================================


class EnterpriseCascadePolicyAudit(EnterpriseBase):
    """Immutable audit log entry for cascade policy mutations.

    Every policy create, update, or delete operation appended to this table
    within the same DB transaction as the policy change itself.  Rows are
    append-only: no UPDATE or DELETE operations are permitted on this table.

    The old/new snapshot columns are nullable:
    - ``old_policy_type`` / ``old_auto_propagate`` are NULL on 'create'.
    - ``new_policy_type`` / ``new_auto_propagate`` are NULL on 'delete'.

    ``tenant_id`` is denormalised for consistent tenant-isolation query patterns.

    Tenant isolation invariant:
        Every query against this table MUST include a ``WHERE tenant_id = ?``
        predicate.  Omitting it is a security defect that leaks cross-tenant data.

    Attributes:
        id:                  UUID PK, server-generated via gen_random_uuid().
        tenant_id:           Tenant scope; every query MUST filter by this column.
        org_id:              UUID of the org whose policy was changed.
        artifact_id:         Optional artifact scope selector (mirrors policy row).
        team_id:             Optional team scope selector (mirrors policy row).
        changed_by:          UUID of the enterprise user who made the change.
        changed_at:          Timezone-aware timestamp when the change was recorded.
        action:              Mutation type: 'create', 'update', or 'delete'.
        old_policy_type:     Policy type value before the change; NULL on 'create'.
        new_policy_type:     Policy type value after the change; NULL on 'delete'.
        old_auto_propagate:  is_auto_propagate before the change; NULL on 'create'.
        new_auto_propagate:  is_auto_propagate after the change; NULL on 'delete'.
        change_reason:       Optional free-text reason supplied by the admin.

    Constraints:
        ck_ent_cpa_action: CHECK action IN ('create', 'update', 'delete').

    Indexes:
        idx_ent_cpa_tenant_id:       (tenant_id)
        idx_ent_cpa_org_id:          (org_id)
        idx_ent_cpa_tenant_artifact: (tenant_id, artifact_id)
        idx_ent_cpa_changed_at:      (tenant_id, changed_at DESC) — for chronological audit views.
    """

    __tablename__ = "enterprise_cascade_policy_audit"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique audit log entry identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Scope selectors (mirror the corresponding policy row)
    # -------------------------------------------------------------------------

    org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="UUID of the org whose cascade policy was mutated",
    )
    artifact_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="Artifact scope of the mutated policy row; NULL for org-level default",
    )
    team_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="Team scope of the mutated policy row; NULL for org or artifact level",
    )

    # -------------------------------------------------------------------------
    # Who / when
    # -------------------------------------------------------------------------

    changed_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="UUID of the enterprise user who triggered this policy mutation",
    )
    changed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware timestamp when the mutation was recorded; immutable once written",
    )

    # -------------------------------------------------------------------------
    # Mutation type
    # -------------------------------------------------------------------------

    action: Mapped[str] = mapped_column(
        String(10),
        nullable=False,
        comment="Mutation type: 'create', 'update', or 'delete'",
    )

    # -------------------------------------------------------------------------
    # Before / after snapshot
    # -------------------------------------------------------------------------

    old_policy_type: Mapped[Optional[str]] = mapped_column(
        String(20),
        nullable=True,
        comment="policy_type value before this change; NULL when action is 'create'",
    )
    new_policy_type: Mapped[Optional[str]] = mapped_column(
        String(20),
        nullable=True,
        comment="policy_type value after this change; NULL when action is 'delete'",
    )
    old_auto_propagate: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        comment="is_auto_propagate value before this change; NULL when action is 'create'",
    )
    new_auto_propagate: Mapped[Optional[bool]] = mapped_column(
        Boolean,
        nullable=True,
        comment="is_auto_propagate value after this change; NULL when action is 'delete'",
    )

    # -------------------------------------------------------------------------
    # Optional context
    # -------------------------------------------------------------------------

    change_reason: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Optional free-text rationale provided by the admin at change time",
    )

    # -------------------------------------------------------------------------
    # Constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        CheckConstraint(
            "action IN ('create', 'update', 'delete')",
            name="ck_ent_cpa_action",
        ),
        Index("idx_ent_cpa_tenant_id", "tenant_id"),
        Index("idx_ent_cpa_org_id", "org_id"),
        Index("idx_ent_cpa_tenant_artifact", "tenant_id", "artifact_id"),
        Index("idx_ent_cpa_changed_at", "tenant_id", "changed_at"),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseCascadePolicyAudit."""
        return (
            f"<EnterpriseCascadePolicyAudit("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"action={self.action!r}, "
            f"org_id={self.org_id!r}, "
            f"changed_by={self.changed_by!r}"
            f")>"
        )


# =============================================================================
# EnterpriseDuplicatePair model  (enterprise-stub-promotion-v1 TASK-0.2)
# =============================================================================


class EnterpriseDuplicatePair(EnterpriseBase):
    """Tenant-scoped record of a candidate duplicate artifact pair.

    ## Purpose

    Tracks pairs of enterprise artifacts that have been identified as potential
    duplicates by the deduplication pipeline.  Each row represents an unordered
    pair ``{artifact_a_id, artifact_b_id}`` within a tenant, along with an
    optional similarity score, the reasons the pair was flagged, and an
    ``ignored`` flag for user dismissal.

    ## Tenant Scoping Policy

    ``tenant_id`` is denormalized on this table (copied from the parent artifact
    rows) for query performance and row-level security alignment.  The
    application layer MUST ensure that both referenced artifacts belong to the
    same ``tenant_id`` as the pair row at write time.  There is no DB-level
    constraint enforcing this invariant — it is enforced by the repository.

    Every query against this table MUST include a ``WHERE tenant_id = ?``
    predicate.  Cross-tenant queries are a data-isolation violation.

    ## Canonical Pair Ordering Invariant

    The unique constraint ``uq_enterprise_duplicate_pairs_tenant_pair`` covers
    ``(tenant_id, artifact_a_id, artifact_b_id)`` and treats ``(a, b)`` and
    ``(b, a)`` as distinct rows — which would break pair-uniqueness.  Therefore,
    the **application layer is responsible for enforcing canonical ordering**
    before insert: always store the pair such that
    ``artifact_a_id < artifact_b_id`` (UUID byte comparison).  Any code path
    that inserts or upserts a pair MUST sort the two UUIDs and assign the
    lesser to ``artifact_a_id``.

    ## JSONB Column Shapes

    ``match_reasons`` — list of short strings describing why the pair was
    flagged, e.g.::

        ["same_content_hash", "same_display_name", "similar_metadata"]

    ``metadata_`` (DDL column name ``metadata``) — open-ended dict for
    pipeline-specific annotations, e.g.::

        {
            "pipeline_version": "2.1.0",
            "score_method": "cosine_tfidf",
            "cluster_id": "clus-abc123"
        }

    Both columns are nullable.  Absence of ``match_reasons`` means the pair
    was inserted without a scored reason list (e.g. exact hash match shortcut).

    ## Schema Proposal (TASK-0.2 review checkpoint)

    Column-by-column rationale (mirrors local ``DuplicatePair`` where noted):

    - ``id``              UUID PK with gen_random_uuid() — standard enterprise PK.
    - ``tenant_id``       Denormalized for RLS and query perf (matches every other
                          enterprise table; plan's "project_id" wording was loose —
                          tenant scoping is the correct level for dedup state).
    - ``artifact_a_id``   FK → enterprise_artifacts.id CASCADE; canonical "lesser"
                          UUID of the pair; NOT NULL.
    - ``artifact_b_id``   FK → enterprise_artifacts.id CASCADE; canonical "greater"
                          UUID of the pair; NOT NULL.
    - ``similarity_score`` Float [0,1] nullable (local uses NOT NULL but enterprise
                          allows NULL for pairs stored without a numeric score, e.g.
                          exact hash matches where a score is redundant).
    - ``match_reasons``   JSONB list replaces local Text-encoded JSON for native
                          PostgreSQL JSON operators and GIN indexability.
    - ``ignored``         Boolean NOT NULL server_default false — mirrors local.
    - ``ignored_at``      DateTime nullable — new in enterprise; records when the
                          pair was dismissed for audit trail.
    - ``ignored_by``      String(255) nullable — user ID of the dismisser; audit.
    - ``metadata_``       JSONB open-ended annotations; column attr uses trailing
                          underscore to avoid clash with SQLAlchemy's DeclarativeBase
                          reserved ``metadata`` attribute; DDL column name is
                          ``metadata`` via ``name="metadata"`` kwarg.
    - ``created_at``      Server-generated; mirrors local.
    - ``updated_at``      Server-generated with onupdate; mirrors local.
    - ``ck_enterprise_duplicate_pairs_distinct_artifacts``  new constraint absent
                          from local schema — prevents self-referential pair rows.

    Attributes:
        id:               UUID PK; server-generated.
        tenant_id:        Denormalized tenant scope; every query MUST filter by it.
        artifact_a_id:    FK to enterprise_artifacts.id; canonical lesser UUID.
        artifact_b_id:    FK to enterprise_artifacts.id; canonical greater UUID.
        similarity_score: Float in [0.0, 1.0], nullable.
        match_reasons:    JSONB list of reason strings, nullable.
        ignored:          True when a user has dismissed this pair.
        ignored_at:       Timestamp of dismissal, nullable.
        ignored_by:       User ID of the dismisser, nullable.
        metadata_:        Open-ended JSONB annotations (DDL name: ``metadata``).
        created_at:       Creation timestamp; server-generated.
        updated_at:       Last-modified timestamp; server-generated with onupdate.

    Constraints:
        uq_enterprise_duplicate_pairs_tenant_pair:
            UNIQUE (tenant_id, artifact_a_id, artifact_b_id)
        ck_enterprise_duplicate_pairs_score:
            similarity_score IS NULL OR (similarity_score >= 0.0 AND
            similarity_score <= 1.0)
        ck_enterprise_duplicate_pairs_distinct_artifacts:
            artifact_a_id <> artifact_b_id

    Indexes:
        idx_enterprise_duplicate_pairs_tenant_id:     (tenant_id)
        idx_enterprise_duplicate_pairs_artifact_a:    (tenant_id, artifact_a_id)
        idx_enterprise_duplicate_pairs_artifact_b:    (tenant_id, artifact_b_id)
        idx_enterprise_duplicate_pairs_ignored:       (tenant_id, ignored)
    """

    __tablename__ = "enterprise_duplicate_pairs"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Globally unique pair record identifier",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment=(
            "Denormalized tenant scope for query performance and RLS alignment; "
            "every query MUST include WHERE tenant_id = ?"
        ),
    )

    # -------------------------------------------------------------------------
    # Artifact pair foreign keys
    # -------------------------------------------------------------------------

    artifact_a_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_duplicate_pairs_artifact_a_id",
        ),
        nullable=False,
        comment=(
            "Canonical 'lesser' UUID of the artifact pair; application layer MUST "
            "sort the two artifact UUIDs and assign the lesser to this column before "
            "insert to ensure the unique constraint works as a true pair-uniqueness "
            "guarantee across (a, b) and (b, a) orderings."
        ),
    )
    artifact_b_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_artifacts.id",
            ondelete="CASCADE",
            name="fk_enterprise_duplicate_pairs_artifact_b_id",
        ),
        nullable=False,
        comment=(
            "Canonical 'greater' UUID of the artifact pair; must satisfy "
            "artifact_b_id > artifact_a_id (enforced by app layer, not DB)."
        ),
    )

    # -------------------------------------------------------------------------
    # Similarity scoring
    # -------------------------------------------------------------------------

    similarity_score: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True,
        comment=(
            "Similarity score in [0.0, 1.0]; NULL when the pair was flagged by an "
            "exact-match rule (e.g. identical content hash) where a numeric score is "
            "redundant.  Validated by ck_enterprise_duplicate_pairs_score."
        ),
    )
    match_reasons: Mapped[Optional[List[Any]]] = mapped_column(
        JSONB,
        nullable=True,
        comment=(
            "JSONB list of short reason strings explaining why this pair was flagged, "
            "e.g. ['same_content_hash', 'similar_metadata']. NULL when the pipeline "
            "did not record individual reasons."
        ),
    )

    # -------------------------------------------------------------------------
    # Dismissal / ignore state
    # -------------------------------------------------------------------------

    ignored: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default=text("false"),
        comment=(
            "True when a user has dismissed this pair as a false positive. "
            "Dismissed pairs are excluded from active deduplication queues."
        ),
    )
    ignored_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timezone-aware timestamp when the pair was dismissed; NULL while active.",
    )
    ignored_by: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="User ID of the person who dismissed this pair; NULL while active.",
    )

    # -------------------------------------------------------------------------
    # Open-ended annotations
    # -------------------------------------------------------------------------

    # Column attribute name uses a trailing underscore to avoid a name clash
    # with SQLAlchemy's DeclarativeBase reserved ``metadata`` attribute.
    # The DDL column name is "metadata" (via name= kwarg).
    metadata_: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        "metadata",
        JSONB,
        nullable=True,
        comment=(
            "Open-ended JSONB dict for pipeline-specific annotations, e.g. "
            "{'pipeline_version': '2.1.0', 'score_method': 'cosine_tfidf', "
            "'cluster_id': 'clus-abc123'}. Attribute name is metadata_ to avoid "
            "clash with SQLAlchemy DeclarativeBase.metadata reserved attribute."
        ),
    )

    # -------------------------------------------------------------------------
    # Audit timestamps
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Timezone-aware creation timestamp; server-generated.",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=text("now()"),
        comment="Timezone-aware last-modified timestamp; server-generated with onupdate.",
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        # Unique: one row per ordered pair within a tenant.
        # App layer MUST enforce artifact_a_id < artifact_b_id before insert.
        UniqueConstraint(
            "tenant_id",
            "artifact_a_id",
            "artifact_b_id",
            name="uq_enterprise_duplicate_pairs_tenant_pair",
        ),
        # Check: similarity score must be in [0.0, 1.0] when present.
        CheckConstraint(
            "similarity_score IS NULL OR (similarity_score >= 0.0 AND similarity_score <= 1.0)",
            name="ck_enterprise_duplicate_pairs_score",
        ),
        # Check: a pair must reference two distinct artifacts (no self-loops).
        CheckConstraint(
            "artifact_a_id <> artifact_b_id",
            name="ck_enterprise_duplicate_pairs_distinct_artifacts",
        ),
        # B-tree: mandatory per-tenant filter for all dedup queries.
        Index(
            "idx_enterprise_duplicate_pairs_tenant_id",
            "tenant_id",
        ),
        # B-tree composite: look up all pairs where artifact A is a given artifact.
        Index(
            "idx_enterprise_duplicate_pairs_artifact_a",
            "tenant_id",
            "artifact_a_id",
        ),
        # B-tree composite: look up all pairs where artifact B is a given artifact.
        Index(
            "idx_enterprise_duplicate_pairs_artifact_b",
            "tenant_id",
            "artifact_b_id",
        ),
        # B-tree composite: filter active (non-ignored) pairs per tenant.
        Index(
            "idx_enterprise_duplicate_pairs_ignored",
            "tenant_id",
            "ignored",
        ),
    )

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseDuplicatePair."""
        return (
            f"<EnterpriseDuplicatePair("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"artifact_a_id={self.artifact_a_id!r}, "
            f"artifact_b_id={self.artifact_b_id!r}, "
            f"similarity_score={self.similarity_score!r}, "
            f"ignored={self.ignored!r}"
            f")>"
        )


# =============================================================================
# EnterpriseScaffoldTemplate model  (enterprise-stub-promotion-v1 TASK-3.1)
# =============================================================================


class EnterpriseScaffoldTemplate(EnterpriseBase):
    """Tenant-scoped Backstage scaffold template for a bundle entity.

    One record exists per bundle entity per tenant, enforced by the
    UNIQUE (tenant_id, bundle_id) constraint.  The template captures the
    variable contract, skeleton source, Backstage metadata, and generation
    history for the scaffold YAML that is rendered via TemplateGenerator.

    Attributes:
        id:                              UUID primary key; server-generated.
        tenant_id:                       Tenant scope; every query MUST include
                                         WHERE tenant_id = ?.
        bundle_id:                       TEXT FK to enterprise_bundle_entities.id;
                                         TEXT (not UUID) so the constraint holds
                                         when the bundle UUID is rendered as hex.
        enabled:                         Whether this template participates in
                                         Backstage catalog sync.
        required_variables:              JSONB list of required variable name strings.
        variable_type_map:               JSONB dict mapping variable names to
                                         Backstage UI field types.
        skeleton_ref:                    GitHub URL for the fetch:template step.
        backstage_owner:                 Backstage spec.owner entity ref.
        backstage_type:                  Backstage template type (service/website/library).
        backstage_tags:                  JSONB list of tag strings for the Backstage spec.
        bundle_version_at_last_generation: Bundle version at last template generation.
        generation_history:              JSONB list of generation event dicts (capped at 20).
        created_at:                      Timezone-aware creation timestamp.
        updated_at:                      Timezone-aware last-modified timestamp.

    Constraints:
        uq_ent_scaffold_templates_tenant_bundle:
            UNIQUE (tenant_id, bundle_id) — 1-to-1 mapping per tenant.
        fk_ent_scaffold_templates_bundle_id:
            FK to enterprise_bundle_entities.id ON DELETE CASCADE.

    Indexes:
        idx_ent_scaffold_templates_tenant:         (tenant_id)
        idx_ent_scaffold_templates_tenant_enabled: (tenant_id, enabled)
    """

    __tablename__ = "enterprise_scaffold_templates"

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
        comment="Primary key; server-generated UUID",
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
    )

    # -------------------------------------------------------------------------
    # Bundle association (1-to-1 within tenant)
    # -------------------------------------------------------------------------

    bundle_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        nullable=False,
        comment=(
            "FK to enterprise_bundle_entities.id (UUID). Stored as native UUID "
            "for FK type compatibility; surfaced as str in Python."
        ),
    )

    # -------------------------------------------------------------------------
    # Activation flag
    # -------------------------------------------------------------------------

    enabled: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default=text("true"),
        comment="Whether this template participates in Backstage catalog sync",
    )

    # -------------------------------------------------------------------------
    # Variable contract
    # -------------------------------------------------------------------------

    required_variables: Mapped[Optional[List[Any]]] = mapped_column(
        JSONB,
        nullable=True,
        comment="JSONB list of required variable name strings",
    )
    variable_type_map: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=True,
        comment="JSONB dict mapping variable names to Backstage UI field types",
    )

    # -------------------------------------------------------------------------
    # Skeleton source
    # -------------------------------------------------------------------------

    skeleton_ref: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="GitHub URL for the fetch:template step in template.yaml",
    )

    # -------------------------------------------------------------------------
    # Backstage metadata
    # -------------------------------------------------------------------------

    backstage_owner: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Backstage spec.owner entity ref",
    )
    backstage_type: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        default="service",
        server_default=text("'service'"),
        comment="Backstage template type: service, website, or library",
    )
    backstage_tags: Mapped[Optional[List[Any]]] = mapped_column(
        JSONB,
        nullable=True,
        comment="JSONB list of tag strings for the Backstage template spec",
    )

    # -------------------------------------------------------------------------
    # Generation tracking
    # -------------------------------------------------------------------------

    bundle_version_at_last_generation: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Bundle version string at the time of the last template generation",
    )
    generation_history: Mapped[Optional[List[Any]]] = mapped_column(
        JSONB,
        nullable=True,
        comment="JSONB list of generation event dicts, capped at 20 by service layer",
    )

    # -------------------------------------------------------------------------
    # Timestamps
    # -------------------------------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        comment="Immutable creation timestamp; server-generated",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
        comment="Timezone-aware last-modified timestamp; updated by app on every write",
    )

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    bundle: Mapped[Optional["EnterpriseBundleEntity"]] = relationship(
        "EnterpriseBundleEntity",
        foreign_keys=[bundle_id],
        primaryjoin="EnterpriseScaffoldTemplate.bundle_id == EnterpriseBundleEntity.id",
        lazy="select",
        viewonly=True,
    )

    # -------------------------------------------------------------------------
    # Table-level constraints and indexes
    # -------------------------------------------------------------------------

    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "bundle_id",
            name="uq_ent_scaffold_templates_tenant_bundle",
        ),
        Index("idx_ent_scaffold_templates_tenant", "tenant_id"),
        Index("idx_ent_scaffold_templates_tenant_enabled", "tenant_id", "enabled"),
    )

    # -------------------------------------------------------------------------
    # Dunder methods
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return unambiguous string representation of EnterpriseScaffoldTemplate."""
        return (
            f"<EnterpriseScaffoldTemplate("
            f"id={self.id!r}, "
            f"tenant_id={self.tenant_id!r}, "
            f"bundle_id={self.bundle_id!r}, "
            f"enabled={self.enabled!r}, "
            f"backstage_type={self.backstage_type!r}"
            f")>"
        )
