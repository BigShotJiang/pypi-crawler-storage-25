"""Enterprise repository base with automatic tenant filtering.

This module provides the foundational repository infrastructure for the
enterprise (PostgreSQL) data tier introduced in the enterprise-db-storage
feature (Phase 2).

The central design goal is *structural* tenant isolation: subclass repositories
never need to manually add ``WHERE tenant_id = ?`` predicates — the base class
injects them automatically via ``_apply_tenant_filter()``.

Architecture notes
------------------
- ``EnterpriseRepositoryBase`` accepts an injected ``Session`` rather than
  managing its own engine/db_path.  This fits the FastAPI dependency-injection
  model (``get_db_session`` / ``DbSessionDep``) and makes repositories easy to
  test with in-memory or temporary databases.
- Tenant identity is stored in a ``contextvars.ContextVar`` so it is naturally
  isolated across concurrent async tasks and threads — no ``threading.local``
  needed.
- SQLAlchemy 2.x ``select()`` style is used throughout (not the legacy 1.x
  ``session.query()`` API) because enterprise models target PostgreSQL and the
  project already uses 2.x-style ``select`` in newer code.

Exports
-------
TenantContext
    Module-level ``ContextVar[Optional[UUID]]`` holding the current tenant.
tenant_scope
    Context manager that sets ``TenantContext`` for the duration of a block.
TenantIsolationError
    Domain exception raised when a cross-tenant access attempt is detected.
EnterpriseRepositoryBase
    Generic base for all enterprise repository implementations.

Repository Classes
~~~~~~~~~~~~~~~~~~~
Core artifact management:
- ``EnterpriseArtifactRepository``
- ``EnterpriseDbCollectionArtifactRepository``
- ``EnterpriseArtifactActivityRepository``
- ``EnterpriseArtifactVersionScopeRepository``
- ``EnterpriseArtifactHistoryStub``

Collection and settings:
- ``EnterpriseCollectionRepository``
- ``EnterpriseSettingsRepository``

Organization and grouping:
- ``EnterpriseTagRepository``
- ``EnterpriseGroupRepository``

Projects and deployment:
- ``EnterpriseProjectRepository``
- ``EnterpriseDeploymentRepository``
- ``EnterpriseDeploymentSetRepository``
- ``EnterpriseDeploymentProfileRepository``

Marketplace and sources:
- ``EnterpriseMarketplaceSourceRepository``
- ``EnterpriseProjectTemplateRepository``

Git integration:
- ``EnterpriseGitRepoConnectionRepository``
- ``EnterpriseGitRepoScanRepository``
- ``EnterpriseGitScanArtifactRepository``
- ``EnterpriseProjectGitConnectionRepository``

Advanced features:
- ``EnterpriseWorkflowRepository`` (Phase 3)
- ``EnterpriseMemoryItemRepository`` (Phase 3)
- ``EnterpriseBundleRepository`` (Phase 3)
- ``EnterpriseBomRepository`` (Phase 5)
- ``EnterpriseContextEntityRepository`` (Phase 5)

Team Sync Dashboard:
- ``EnterpriseTeamSyncRepository`` (BE-2.2)

Specialized implementations:
- ``ArtifactBlobsRepository``
- ``EnterpriseContextEntityCategoryStub`` (Phase 5)
- ``EnterpriseArtifactHistoryEventRepository`` (enterprise-stub-promotion-v1 TASK-1.2)
- ``EnterpriseArtifactHistoryEventStub`` (Phase 5 — superseded, kept for downgrade safety)
- ``EnterpriseUserCollectionAdapter``
- ``EnterpriseDuplicatePairStub``
- ``EnterpriseDuplicatePairRepository``
- ``EnterpriseScaffoldTemplateRepository`` (enterprise-stub-promotion-v1 TASK-3.1)

Usage::

    from skillmeat.cache.enterprise_repositories import (
        EnterpriseRepositoryBase,
        TenantContext,
        TenantIsolationError,
        tenant_scope,
    )
    from skillmeat.cache.models_enterprise import EnterpriseArtifact

    class ArtifactRepository(EnterpriseRepositoryBase[EnterpriseArtifact]):
        def __init__(self, session: Session) -> None:
            super().__init__(session, EnterpriseArtifact)

        def get_by_name(self, name: str) -> Optional[EnterpriseArtifact]:
            stmt = self._apply_tenant_filter(
                select(EnterpriseArtifact).where(EnterpriseArtifact.name == name)
            )
            return self.session.execute(stmt).scalar_one_or_none()

    # In a FastAPI route (tenant set per-request by middleware):
    with tenant_scope(uuid.UUID("...")):
        repo = ArtifactRepository(db_session)
        artifact = repo.get_by_name("canvas-design")

References
----------
ENT-2.1 implementation task.
Phase 1 foundation: skillmeat/cache/models_enterprise.py,
                    skillmeat/cache/repositories.py,
                    skillmeat/cache/constants.py
"""

from __future__ import annotations

import hashlib
import logging
import uuid
from contextlib import contextmanager
from contextvars import ContextVar, Token
from datetime import datetime
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Generator,
    Generic,
    List,
    Optional,
    Tuple,
    Type,
    TypeVar,
)

from sqlalchemy import delete, select
from sqlalchemy.orm import Session
from sqlalchemy.sql import Select

from skillmeat.cache.constants import DEFAULT_TENANT_ID

from skillmeat.core.interfaces.repositories import (
    IArtifactActivityRepository,
    IBomRepository,
    IBundleRepository,
    IDbArtifactHistoryRepository,
    IDbCollectionArtifactRepository,
    IDbUserCollectionRepository,
    IGitCredentialRepository,
    IGitRepoConnectionRepository,
    IGitRepoScanRepository,
    IGitScanArtifactRepository,
    IMemoryItemRepository,
    IProjectGitConnectionRepository,
    IWorkflowRepository,
)

if TYPE_CHECKING:
    from skillmeat.api.schemas.auth import AuthContext
    from skillmeat.core.auth.ownership_context import ResolvedOwnershipContext

logger = logging.getLogger(__name__)


def _derive_sync_status(
    head_hash: str,
    baseline_hash: Optional[str],
    is_diverged: bool,
) -> str:
    """Derive ``sync_status`` from scope hash fields.

    Mirrors the SQL CASE expression in migration ent_022 and the identical
    helpers in ``enterprise_context_sync`` and ``enterprise_version_scope``
    so all mutation sites remain consistent without a shared import.

    Priority: diverged > pending (no baseline) > current (equal hashes) > outdated.
    """
    if is_diverged:
        return "diverged"
    if baseline_hash is None:
        return "pending"
    if head_hash == baseline_hash:
        return "current"
    return "outdated"


def _ensure_uuid(value) -> uuid.UUID:
    """Coerce value to uuid.UUID, handling Python 3.12 strict UUID constructor."""
    if isinstance(value, uuid.UUID):
        return value
    return uuid.UUID(str(value))


# ---------------------------------------------------------------------------
# Type variable
# ---------------------------------------------------------------------------

T = TypeVar("T")

# ---------------------------------------------------------------------------
# Tenant context — request-scoped tenant identity
# ---------------------------------------------------------------------------

#: Module-level ContextVar holding the active tenant UUID for the current
#: execution context (async task, thread, or coroutine).  ``None`` signals
#: "not set"; ``_get_tenant_id()`` falls back to ``DEFAULT_TENANT_ID``.
TenantContext: ContextVar[Optional[uuid.UUID]] = ContextVar(
    "TenantContext", default=None
)


@contextmanager
def tenant_scope(tenant_id: uuid.UUID) -> Generator[None, None, None]:
    """Context manager that sets ``TenantContext`` for the duration of a block.

    Restores the previous value (or ``None``) when the block exits, even if an
    exception is raised — making nested ``tenant_scope`` calls safe.

    Parameters
    ----------
    tenant_id:
        The UUID identifying the tenant that should own all repository
        operations performed inside this block.

    Yields
    ------
    None

    Examples
    --------
    ::

        with tenant_scope(uuid.UUID("acme-tenant-uuid")):
            artifacts = artifact_repo.list_active()

        # Nested scopes are supported — inner scope restores outer on exit.
        with tenant_scope(tenant_a):
            with tenant_scope(tenant_b):
                ...  # tenant_b is active here
            ...  # tenant_a is active again here
    """
    token = TenantContext.set(tenant_id)
    try:
        yield
    finally:
        TenantContext.reset(token)


# ---------------------------------------------------------------------------
# Imperative tenant context helpers (SVR-003)
# ---------------------------------------------------------------------------


def set_tenant_context(tenant_id: uuid.UUID) -> Token:
    """Set the current tenant in ``TenantContext`` and return a reset token.

    The returned token must be passed to :func:`clear_tenant_context` to
    restore the previous value.  Prefer the :func:`tenant_scope` context
    manager when possible — it handles cleanup automatically.

    Parameters
    ----------
    tenant_id:
        The UUID of the tenant to activate for the current execution context.

    Returns
    -------
    contextvars.Token
        Opaque token that can be passed to :func:`clear_tenant_context` to
        undo this set operation.

    Examples
    --------
    ::

        token = set_tenant_context(my_tenant_id)
        try:
            ...
        finally:
            clear_tenant_context(token)
    """
    return TenantContext.set(tenant_id)


def get_tenant_context() -> Optional[uuid.UUID]:
    """Return the tenant UUID currently stored in ``TenantContext``.

    Returns ``None`` when no tenant has been set for this execution context,
    allowing callers to decide their own fallback behaviour (e.g. default to
    ``DEFAULT_TENANT_ID`` for single-tenant mode, or raise for strict
    multi-tenant enforcement).

    Returns
    -------
    uuid.UUID or None
        The active tenant UUID, or ``None`` if not set.
    """
    return TenantContext.get(None)


def clear_tenant_context(token: Token) -> None:
    """Reset ``TenantContext`` to the value it held before a :func:`set_tenant_context` call.

    Parameters
    ----------
    token:
        The token returned by the corresponding :func:`set_tenant_context`
        call.  Passing any other token is undefined behaviour (mirrors the
        underlying ``ContextVar.reset`` contract).

    Examples
    --------
    ::

        token = set_tenant_context(my_tenant_id)
        try:
            ...
        finally:
            clear_tenant_context(token)
    """
    TenantContext.reset(token)


# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class TenantIsolationError(Exception):
    """Raised when a cross-tenant data access attempt is detected.

    This exception is thrown by ``EnterpriseRepositoryBase._assert_tenant_owns``
    when an ORM object's ``tenant_id`` does not match the tenant currently
    active in ``TenantContext``.

    It is intentionally a plain ``Exception`` subclass (not an HTTP exception)
    so that it can be caught at any layer and mapped to an appropriate HTTP 403
    or 404 response by the API boundary.

    Attributes
    ----------
    object_tenant_id:
        The ``tenant_id`` found on the retrieved object.
    current_tenant_id:
        The tenant UUID that was active in ``TenantContext`` at the time of the
        check.
    """

    def __init__(
        self,
        object_tenant_id: uuid.UUID,
        current_tenant_id: uuid.UUID,
        detail: Optional[str] = None,
    ) -> None:
        self.object_tenant_id = object_tenant_id
        self.current_tenant_id = current_tenant_id
        message = (
            f"Tenant isolation violation: object belongs to tenant "
            f"{object_tenant_id!s} but current tenant is {current_tenant_id!s}."
        )
        if detail:
            message = f"{message} {detail}"
        super().__init__(message)


# ---------------------------------------------------------------------------
# Enterprise repository base
# ---------------------------------------------------------------------------


class EnterpriseRepositoryBase(Generic[T]):
    """Base repository for all enterprise (PostgreSQL) data access operations.

    Provides automatic tenant filtering so that every query issued by a
    subclass is scoped to the tenant currently stored in ``TenantContext``.
    Subclasses must call ``_apply_tenant_filter(stmt)`` on any ``select()``
    statement before executing it.

    Design contract
    ---------------
    * The ``Session`` is *injected* at construction time — this class does not
      create engines or manage connection pools.  Use the FastAPI
      ``get_db_session`` dependency (``skillmeat.cache.session``) or the
      ``DbSessionDep`` alias (``skillmeat.api.dependencies``) to supply it.
    * All query statements are SQLAlchemy 2.x ``select()`` style.
    * ``tenant_id`` columns on enterprise models are ``UUID(as_uuid=True)``
      — Python values are ``uuid.UUID`` instances, not strings.
    * Transaction management (commit / rollback) is the caller's
      responsibility; this class only manages *query construction*.

    Type Parameters
    ---------------
    T:
        The SQLAlchemy ORM model class this repository operates on.  Must be
        a subclass of ``EnterpriseBase`` and must have a ``tenant_id``
        column of type ``UUID``.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.
    model_class:
        The ORM model class (e.g. ``EnterpriseArtifact``).

    Examples
    --------
    Minimal subclass::

        class CollectionRepository(EnterpriseRepositoryBase[EnterpriseCollection]):
            def __init__(self, session: Session) -> None:
                super().__init__(session, EnterpriseCollection)

            def list_all(self) -> list[EnterpriseCollection]:
                stmt = self._apply_tenant_filter(select(EnterpriseCollection))
                return list(self.session.execute(stmt).scalars())
    """

    def __init__(self, session: Session, model_class: Type[T]) -> None:
        """Initialise the repository.

        Parameters
        ----------
        session:
            Injected SQLAlchemy session.  The session's lifecycle (commit,
            rollback, close) is managed by the caller — typically a FastAPI
            dependency or a ``with repo.transaction()`` block in tests.
        model_class:
            The ORM model class this repository is typed against.
        """
        self.session: Session = session
        self.model_class: Type[T] = model_class
        logger.debug(
            "Initialised %s for model %s",
            self.__class__.__name__,
            model_class.__name__,
        )

    # ------------------------------------------------------------------
    # Tenant identity resolution
    # ------------------------------------------------------------------

    def _get_tenant_id(self) -> uuid.UUID:
        """Return the active tenant UUID.

        Resolution order:

        1. ``TenantContext`` ContextVar — set per-request by middleware or
           ``tenant_scope()`` in tests.
        2. ``DEFAULT_TENANT_ID`` constant from ``skillmeat.cache.constants``
           — used in Phase 1 single-tenant mode and as a safe fallback.

        Returns
        -------
        uuid.UUID
            The UUID of the tenant that should own all current repository
            operations.
        """
        tenant_id = TenantContext.get()
        if tenant_id is None:
            logger.debug(
                "TenantContext not set; falling back to DEFAULT_TENANT_ID (%s)",
                DEFAULT_TENANT_ID,
            )
            return DEFAULT_TENANT_ID
        return tenant_id

    # ------------------------------------------------------------------
    # Automatic tenant filtering
    # ------------------------------------------------------------------

    def _apply_tenant_filter(self, stmt: Select) -> Select:
        """Append a ``WHERE tenant_id = <current_tenant>`` clause to *stmt*.

        This method must be called on every ``select()`` statement that
        targets an enterprise model table before the statement is executed.
        Subclasses should not bypass this call — doing so is a security defect.

        Parameters
        ----------
        stmt:
            A SQLAlchemy 2.x ``Select`` statement targeting ``self.model_class``
            (or a join that includes it).

        Returns
        -------
        Select
            The same statement with an additional ``WHERE tenant_id = ?``
            predicate appended via ``.where()``.

        Example
        -------
        ::

            stmt = self._apply_tenant_filter(
                select(EnterpriseArtifact)
                .where(EnterpriseArtifact.is_active.is_(True))
                .order_by(EnterpriseArtifact.created_at.desc())
            )
            result = self.session.execute(stmt).scalars().all()
        """
        tenant_id = self._get_tenant_id()
        return stmt.where(self.model_class.tenant_id == tenant_id)

    # ------------------------------------------------------------------
    # Ownership assertion
    # ------------------------------------------------------------------

    def _assert_tenant_owns(self, obj: T) -> None:
        """Verify that *obj* belongs to the currently active tenant.

        Use this after retrieving an object by primary key (where the query
        may not have gone through ``_apply_tenant_filter``), or after any
        cross-join that might surface rows from another tenant.

        Parameters
        ----------
        obj:
            An ORM instance that has a ``tenant_id`` attribute of type
            ``uuid.UUID``.

        Raises
        ------
        TenantIsolationError
            If ``obj.tenant_id`` does not equal ``_get_tenant_id()``.
        AttributeError
            If *obj* does not have a ``tenant_id`` attribute.  This would
            indicate a programming error — using this base with a model that
            lacks tenant isolation.

        Example
        -------
        ::

            artifact = self.session.get(EnterpriseArtifact, artifact_id)
            if artifact is None:
                raise NotFoundError(artifact_id)
            self._assert_tenant_owns(artifact)
        """
        current_tenant_id = self._get_tenant_id()
        object_tenant_id: uuid.UUID = obj.tenant_id  # type: ignore[attr-defined]
        if object_tenant_id != current_tenant_id:
            logger.warning(
                "Tenant isolation violation detected: object tenant=%s, "
                "current tenant=%s, model=%s",
                object_tenant_id,
                current_tenant_id,
                self.model_class.__name__,
            )
            raise TenantIsolationError(
                object_tenant_id=object_tenant_id,
                current_tenant_id=current_tenant_id,
            )

    # ------------------------------------------------------------------
    # Convenience: bare select scoped to current tenant
    # ------------------------------------------------------------------

    def _tenant_select(self) -> Select:
        """Return ``select(model_class).where(tenant_id == current_tenant)``.

        Shorthand for the most common query opening pattern.  Equivalent to::

            self._apply_tenant_filter(select(self.model_class))

        Returns
        -------
        Select
            A tenant-filtered ``Select`` statement ready for additional
            ``.where()``, ``.order_by()``, ``.limit()``, etc. chaining.
        """
        return self._apply_tenant_filter(select(self.model_class))

    # ------------------------------------------------------------------
    # Audit logging
    # ------------------------------------------------------------------

    def _log_operation(
        self,
        operation: str,
        entity_type: str,
        entity_id: Optional[object],
        metadata: Optional[Dict[str, object]] = None,
    ) -> None:
        """Emit a structured audit log entry for a mutating repository operation.

        This method is intended to be called at the end of any state-changing
        operation (create, update, delete).  Read operations are deliberately
        excluded to keep audit volume manageable and to avoid leaking query
        patterns into the audit trail.

        No ``AuditLog`` SQLAlchemy model exists in Phase 1, so entries are
        written to the Python ``logging`` subsystem at ``INFO`` level as a JSON-
        serialisable dict.  This makes them easy to ingest by log-aggregation
        tools (Loki, CloudWatch, Datadog) without a schema migration.

        Parameters
        ----------
        operation:
            Short verb describing the mutation, e.g. ``"create"``,
            ``"update"``, ``"delete"``, ``"soft_delete"``.
        entity_type:
            The ORM model class name or table-name token that was mutated,
            e.g. ``"EnterpriseArtifact"``, ``"EnterpriseCollection"``.
            Conventionally pass ``self.model_class.__name__``.
        entity_id:
            The primary key of the affected row, or ``None`` when the PK is
            not yet available (e.g. before a flush).  Converted to ``str`` for
            JSON-safe serialisation.
        metadata:
            Optional dict of additional key-value pairs to include in the log
            entry.  Useful for recording old/new values, operation-specific
            flags, or caller context.  Values must be JSON-serialisable.

        Examples
        --------
        Typical usage at the end of a create method::

            def create(self, artifact: EnterpriseArtifact) -> EnterpriseArtifact:
                self.session.add(artifact)
                self.session.flush()
                self._log_operation(
                    operation="create",
                    entity_type=self.model_class.__name__,
                    entity_id=artifact.id,
                )
                return artifact

        With extra metadata on a delete::

            def delete(self, artifact: EnterpriseArtifact) -> None:
                self.session.delete(artifact)
                self.session.flush()
                self._log_operation(
                    operation="delete",
                    entity_type=self.model_class.__name__,
                    entity_id=artifact.id,
                    metadata={"name": artifact.name, "artifact_type": artifact.artifact_type},
                )
        """
        tenant_id = self._get_tenant_id()
        entry: Dict[str, object] = {
            "tenant_id": str(tenant_id),
            "operation": operation,
            "entity_type": entity_type,
            "entity_id": str(entity_id) if entity_id is not None else None,
            "timestamp": datetime.utcnow().isoformat() + "Z",
        }
        if metadata:
            entry["metadata"] = metadata
        logger.info("audit %s", entry)

    # ------------------------------------------------------------------
    # Auth context helpers (SVR-006)
    # ------------------------------------------------------------------

    def _apply_auth_context(
        self, auth_context: Optional["AuthContext"]
    ) -> Optional[uuid.UUID]:
        """Apply auth_context tenant to TenantContext and return the owner_id.

        When *auth_context* is provided and carries a ``tenant_id``, this
        method sets ``TenantContext`` so that all subsequent ``_apply_tenant_filter``
        / ``_get_tenant_id`` calls in the same operation use the authenticated
        tenant rather than any previously set value.

        Parameters
        ----------
        auth_context:
            The authenticated request context, or ``None`` for local/zero-auth
            mode.  When ``None`` the method is a no-op.

        Returns
        -------
        uuid.UUID or None
            The ``user_id`` from *auth_context* (to use as ``owner_id`` on new
            records), or ``None`` when *auth_context* is absent.
        """
        if auth_context is None:
            return None
        if auth_context.tenant_id is not None:
            set_tenant_context(auth_context.tenant_id)
        return auth_context.user_id


# ---------------------------------------------------------------------------
# EnterpriseArtifactRepository — write operations (ENT-2.4, ENT-2.5)
# ---------------------------------------------------------------------------


class EnterpriseArtifactRepository(EnterpriseRepositoryBase):  # type: ignore[type-arg]
    """Repository for enterprise artifact write operations.

    Provides create, update, soft_delete, and hard_delete methods for
    ``EnterpriseArtifact`` rows in the PostgreSQL enterprise schema.

    All methods assert tenant ownership before any mutation and use
    SQLAlchemy 2.x style queries throughout.

    Lookup and list methods (get, list_active, etc.) are added by a
    companion agent (ENT-2.2/ENT-2.3) to the same class — this file
    contains only the write-path methods to avoid concurrent conflicts.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        super().__init__(session, EnterpriseArtifact)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _next_version(current_tag: str) -> str:
        """Increment the patch component of a semver string.

        If *current_tag* does not match ``vM.m.p`` or ``M.m.p``, falls
        back to a UTC-timestamp-based tag to guarantee uniqueness.

        Parameters
        ----------
        current_tag:
            The version string of the most recent ``EnterpriseArtifactVersion``
            for this artifact (e.g. ``"v1.0.0"`` or ``"1.2.3"``).

        Returns
        -------
        str
            Next patch-incremented version string in the same format as
            *current_tag*, or ``"v<epoch_ms>"`` as fallback.
        """
        tag = current_tag.lstrip("v")
        parts = tag.split(".")
        if len(parts) == 3 and all(p.isdigit() for p in parts):
            major, minor, patch = parts
            new_tag = f"{int(major)}.{int(minor)}.{int(patch) + 1}"
            # Preserve leading "v" if original had it
            if current_tag.startswith("v"):
                return f"v{new_tag}"
            return new_tag
        # Non-semver fallback: timestamp-based unique tag
        epoch_ms = int(datetime.utcnow().timestamp() * 1000)
        return f"v{epoch_ms}"

    @staticmethod
    def _compute_content_hash(content: str) -> str:
        """Return the SHA256 hex digest of *content* (64 hex chars)."""
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    @staticmethod
    def _artifact_to_dto(row: "EnterpriseArtifact") -> "ArtifactDTO":
        """Convert an :class:`EnterpriseArtifact` ORM row to an :class:`ArtifactDTO`.

        Resolves the following ORM divergences between local and enterprise
        models:

        - DIV-5: enterprise ``id: UUID`` (native UUID object) → normalised to
          32-char hex string via ``str(row.id)`` so the DTO always carries a
          consistent ``uuid`` value regardless of edition.
        - DIV-6: enterprise stores the upstream URL in ``source_url`` while the
          local model uses ``source`` — mapped here so callers always read
          ``ArtifactDTO.source``.
        - DIV-7: enterprise stores arbitrary metadata in ``custom_fields: Dict``
          (JSONB column) while the local model uses a plain ``metadata: dict``
          attribute — both land in ``ArtifactDTO.metadata`` as a plain dict.
          JSON-encoding to a string is deferred to callers that need
          ``metadata_json`` (e.g. ``EnterpriseArtifactResponseDTO``).

        Uses ``getattr`` with fallbacks throughout so that this method stays
        safe when called with MagicMock stubs in tests.
        """
        from skillmeat.core.interfaces.dtos import ArtifactDTO

        created = getattr(row, "created_at", None)
        updated = getattr(row, "updated_at", None)
        return ArtifactDTO(
            id=f"{row.artifact_type}:{row.name}",
            name=row.name,
            artifact_type=row.artifact_type or "",
            # DIV-5: enterprise PK is a UUID object — normalise to hex string.
            uuid=str(row.id),
            # DIV-6: enterprise uses source_url; local uses source.
            source=getattr(row, "source_url", None),
            version=None,
            scope=getattr(row, "scope", None),
            description=getattr(row, "description", None),
            # DIV-7: enterprise uses custom_fields (JSONB dict); local uses metadata dict.
            metadata=dict(getattr(row, "custom_fields", None) or {}),
            tags=list(getattr(row, "tags", None) or []),
            created_at=created.isoformat() if created is not None else None,
            updated_at=updated.isoformat() if updated is not None else None,
        )

    # ------------------------------------------------------------------
    # ENT-2.2: Lookup methods with tenant scoping
    # ------------------------------------------------------------------

    def get(
        self,
        id,  # str ("type:name") per IArtifactRepository, or uuid.UUID for legacy callers
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "Optional[ArtifactDTO]":
        """Fetch an artifact by composite ``type:name`` id or legacy UUID primary key.

        Implements the :class:`~skillmeat.core.interfaces.repositories.IArtifactRepository`
        contract.  To maintain backward compatibility with internal callers that
        pass a ``uuid.UUID`` primary key, the method also accepts ``uuid.UUID``
        objects and falls back to the legacy PK lookup path in that case.

        Parameters
        ----------
        id:
            Either a composite string ``"type:name"`` (e.g. ``"skill:canvas-design"``)
            per the interface contract, or a ``uuid.UUID`` for legacy PK lookups.
        ctx:
            Optional per-request metadata (currently unused).
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        ArtifactDTO or None
            The matching artifact as a DTO, or ``None`` if absent or owned by
            another tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        from skillmeat.core.repositories.filters import apply_visibility_filter_stmt

        # Legacy path: called with a UUID primary key directly.
        if isinstance(id, uuid.UUID):
            artifact_id: uuid.UUID = id
            self._apply_auth_context(auth_context)
            obj = self.session.get(EnterpriseArtifact, artifact_id)
            if obj is None:
                return None
            try:
                self._assert_tenant_owns(obj)
            except TenantIsolationError:
                logger.debug(
                    "get(%s): artifact exists but belongs to a different tenant; "
                    "returning None to avoid tenant-existence disclosure",
                    artifact_id,
                )
                return None
            if auth_context is not None:
                stmt = apply_visibility_filter_stmt(
                    select(EnterpriseArtifact).where(
                        EnterpriseArtifact.id == artifact_id
                    ),
                    EnterpriseArtifact,
                    auth_context,
                )
                obj = self.session.execute(stmt).scalar_one_or_none()
            # Return the raw ORM object for legacy callers (tests assert `result is art`)
            return obj  # type: ignore[return-value]

        # Interface path: composite "type:name" string.
        art_type, art_name = str(id).split(":", 1)
        self._apply_auth_context(auth_context)
        stmt = (
            self._tenant_select()
            .where(EnterpriseArtifact.artifact_type == art_type)
            .where(EnterpriseArtifact.name == art_name)
            .limit(1)
        )
        if auth_context is not None:
            stmt = apply_visibility_filter_stmt(stmt, EnterpriseArtifact, auth_context)
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return None
        return self._artifact_to_dto(row)

    def get_by_uuid(
        self,
        uuid: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "Optional[ArtifactDTO]":
        """Fetch an artifact by its stable UUID string with tenant filter at query time.

        Implements the :class:`~skillmeat.core.interfaces.repositories.IArtifactRepository`
        contract.  Unlike ``get()``, accepts a *string* UUID and applies the tenant
        predicate directly in the SELECT so that only the owning tenant's row is
        ever returned.

        Parameters
        ----------
        uuid:
            UUID of the artifact as a string; will be parsed to ``uuid.UUID``.
        ctx:
            Optional per-request metadata (currently unused).
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        ArtifactDTO or None
            The matching artifact as a DTO, or ``None`` if not found for the
            current tenant.

        Raises
        ------
        ValueError
            If *uuid* is not a valid UUID string.
        """
        import uuid as _uuid_mod

        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        from skillmeat.core.repositories.filters import apply_visibility_filter_stmt

        self._apply_auth_context(auth_context)
        parsed: _uuid_mod.UUID = _uuid_mod.UUID(uuid)
        stmt = self._tenant_select().where(EnterpriseArtifact.id == parsed)
        # ENT-002: Enforce visibility access control when auth context is present.
        # Returns None for both not-found and not-visible (prevents existence
        # disclosure — callers cannot distinguish the two cases).
        if auth_context is not None:
            stmt = apply_visibility_filter_stmt(stmt, EnterpriseArtifact, auth_context)
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return None
        return self._artifact_to_dto(row)

    def get_by_name(
        self,
        name: str,
        auth_context: Optional["AuthContext"] = None,
    ) -> "Optional[EnterpriseArtifact]":
        """Fetch an artifact by name within the current tenant's scope.

        Name uniqueness is enforced by ``uq_enterprise_artifacts_tenant_name_type``,
        but this method returns the *first* match ordered by ``created_at`` to
        handle any edge cases in test data.

        Parameters
        ----------
        name:
            Human-readable artifact name (e.g. ``"canvas-design"``).
            Exact, case-sensitive match.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        EnterpriseArtifact or None
            The matching row, or ``None`` if not found.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        from skillmeat.core.repositories.filters import apply_visibility_filter_stmt

        self._apply_auth_context(auth_context)
        stmt = (
            self._tenant_select()
            .where(EnterpriseArtifact.name == name)
            .order_by(EnterpriseArtifact.created_at)
            .limit(1)
        )
        # ENT-002: Enforce visibility access control when auth context is present.
        # Returns None for both not-found and not-visible (prevents existence
        # disclosure — callers cannot distinguish the two cases).
        if auth_context is not None:
            stmt = apply_visibility_filter_stmt(stmt, EnterpriseArtifact, auth_context)
        return self.session.execute(stmt).scalar_one_or_none()

    def resolve_uuid_by_id(self, artifact_id: str) -> "str | None":
        """Resolve the stable UUID for an artifact by its ``type:name`` ID.

        Implements the :class:`~skillmeat.core.interfaces.repositories.IArtifactRepository`
        contract method used by helpers (e.g. ``artifacts/_helpers.py``) to
        obtain a 32-char hex UUID from a composite ``"type:name"`` identifier.

        Parameters
        ----------
        artifact_id:
            Composite ``"type:name"`` artifact identifier string
            (e.g. ``"skill:canvas-design"``).

        Returns
        -------
        str or None
            32-char hex UUID string when found, ``None`` if the artifact does
            not exist in the current tenant or the *artifact_id* format is
            invalid.
        """
        logger.debug(
            "EnterpriseArtifactRepository.resolve_uuid_by_id: %r",
            artifact_id,
        )
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        if ":" not in artifact_id:
            return None
        artifact_type, _, name = artifact_id.partition(":")
        tenant_id = self._get_tenant_id()
        stmt = select(EnterpriseArtifact.id).where(
            EnterpriseArtifact.name == name,
            EnterpriseArtifact.artifact_type == artifact_type,
            EnterpriseArtifact.tenant_id == tenant_id,
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return str(row).replace("-", "") if row is not None else None

    # ------------------------------------------------------------------
    # ENT-2.3: Paginated listing and JSONB tag search
    # ------------------------------------------------------------------

    def list(
        self,
        filters: "Optional[Dict[str, Any]]" = None,
        offset: int = 0,
        limit: int = 50,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[ArtifactDTO]":
        """Return a paginated list of artifacts for the current tenant.

        Filters are additive (AND logic).  Results are ordered newest-first by
        ``created_at`` so callers always see recently added artifacts at the top.

        Parameters
        ----------
        filters:
            Optional key/value filter map.  Recognised keys:
            ``artifact_type``, ``name_contains``, ``tags``, ``owner_scope``,
            ``owner_id``.
        offset:
            Number of rows to skip.  Combine with *limit* for page-based
            navigation: ``offset = page * limit``.
        limit:
            Maximum number of rows to return.
        ctx:
            Optional per-request metadata (unused).
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        list[ArtifactDTO]
            Ordered list of matching artifacts (may be empty).
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact
        from skillmeat.core.interfaces.dtos import ArtifactDTO
        from skillmeat.core.repositories.filters import apply_visibility_filter_stmt

        filters = filters or {}
        artifact_type: Optional[str] = filters.get("artifact_type")
        name_contains: Optional[str] = filters.get("name_contains")

        self._apply_auth_context(auth_context)
        stmt = self._tenant_select().order_by(EnterpriseArtifact.created_at.desc())
        if artifact_type is not None:
            stmt = stmt.where(EnterpriseArtifact.artifact_type == artifact_type)
        if name_contains is not None:
            stmt = stmt.where(EnterpriseArtifact.name.ilike(f"%{name_contains}%"))
        # ENT-002: Apply visibility-based access control when auth context is
        # present.  Public and team items are visible to all tenant members;
        # private items are restricted to their owner.
        # Visibility-excluded items are silently omitted from results.
        if auth_context is not None:
            stmt = apply_visibility_filter_stmt(stmt, EnterpriseArtifact, auth_context)
        stmt = stmt.offset(offset).limit(limit)
        rows = list(self.session.execute(stmt).scalars().all())
        return [self._artifact_to_dto(row) for row in rows]

    def count(
        self,
        filters: "Optional[Dict[str, Any]]" = None,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> int:
        """Return the number of artifacts for the current tenant.

        Parameters
        ----------
        filters:
            Optional key/value filter map.  Recognised key: ``artifact_type``.
        ctx:
            Optional per-request metadata (unused).
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        int
            Row count matching the filter (0 if none).
        """
        from sqlalchemy import func

        from skillmeat.cache.models_enterprise import EnterpriseArtifact
        from skillmeat.core.repositories.filters import apply_visibility_filter_stmt

        filters = filters or {}
        artifact_type: Optional[str] = filters.get("artifact_type")

        self._apply_auth_context(auth_context)
        # ENT-002: For count with visibility, use a subquery approach so that
        # apply_visibility_filter_stmt (which works on a Select of the model)
        # can add its WHERE predicates before wrapping in count().
        # Counts only visibility-filtered results — excluded artifacts are not counted.
        if auth_context is not None:
            inner = self._tenant_select()
            if artifact_type is not None:
                inner = inner.where(EnterpriseArtifact.artifact_type == artifact_type)
            inner = apply_visibility_filter_stmt(
                inner, EnterpriseArtifact, auth_context
            )
            stmt = select(func.count()).select_from(inner.subquery())
        else:
            stmt = self._apply_tenant_filter(
                select(func.count()).select_from(EnterpriseArtifact)
            )
            if artifact_type is not None:
                stmt = stmt.where(EnterpriseArtifact.artifact_type == artifact_type)
        result = self.session.execute(stmt).scalar_one()
        return int(result)

    def search(
        self,
        query: str,
        filters: "Optional[Dict[str, Any]]" = None,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[ArtifactDTO]":
        """Full-text / fuzzy search across artifact names and descriptions.

        Performs a case-insensitive substring match (``ILIKE``) on both
        ``name`` and ``description`` columns.  Results with a name match are
        ordered before description-only matches to approximate relevance
        ranking.  Additional filter constraints from *filters* are applied on
        top of the text match.

        Parameters
        ----------
        query:
            Free-form search string.  An empty string returns all artifacts
            (subject to filters).
        filters:
            Optional key/value filter map.  Recognised key: ``artifact_type``.
        ctx:
            Optional per-request metadata (unused).
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        list[ArtifactDTO]
            Matching artifacts: name matches first, then description matches.
        """
        from sqlalchemy import case, or_

        from skillmeat.cache.models_enterprise import EnterpriseArtifact
        from skillmeat.core.interfaces.dtos import ArtifactDTO
        from skillmeat.core.repositories.filters import apply_visibility_filter_stmt

        filters = filters or {}
        artifact_type: Optional[str] = filters.get("artifact_type")
        pattern = f"%{query}%"

        self._apply_auth_context(auth_context)

        # Relevance: name match scores 1, description-only match scores 0.
        # ORDER BY relevance DESC puts name matches first.
        relevance = case(
            (EnterpriseArtifact.name.ilike(pattern), 1),
            else_=0,
        )

        stmt = (
            self._tenant_select()
            .where(
                or_(
                    EnterpriseArtifact.name.ilike(pattern),
                    EnterpriseArtifact.description.ilike(pattern),
                )
            )
            .order_by(relevance.desc(), EnterpriseArtifact.name)
        )

        if artifact_type is not None:
            stmt = stmt.where(EnterpriseArtifact.artifact_type == artifact_type)

        if auth_context is not None:
            stmt = apply_visibility_filter_stmt(stmt, EnterpriseArtifact, auth_context)

        rows = list(self.session.execute(stmt).scalars().all())
        return [self._artifact_to_dto(row) for row in rows]

    def search_by_tags(
        self,
        tags: List[str],
        match_all: bool = False,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[EnterpriseArtifact]":
        """Return artifacts whose ``tags`` JSONB array contains the given tags.

        Two matching modes are supported:

        ``match_all=True``
            The artifact's ``tags`` must contain *every* tag in *tags*.
            Uses the PostgreSQL ``@>`` containment operator on the
            GIN-indexed ``tags`` column (O(log n) via
            ``idx_enterprise_artifacts_tags_gin``).

        ``match_all=False`` (default)
            The artifact's ``tags`` must contain *at least one* of the given
            tags.  Implemented as OR-joined ``@>`` predicates so each
            individual tag lookup still hits the GIN index.

        Parameters
        ----------
        tags:
            List of tag strings to search for.  Empty list returns no rows.
        match_all:
            When ``True``, require all listed tags to be present.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        list[EnterpriseArtifact]
            Matching artifacts ordered by ``created_at`` descending.
        """
        import json

        from sqlalchemy import cast, or_
        from sqlalchemy.dialects.postgresql import JSONB

        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        self._apply_auth_context(auth_context)
        if not tags:
            return []

        # Use the PostgreSQL @> (contains) operator resolved by the GIN index
        # (idx_enterprise_artifacts_tags_gin).  The cast is required so
        # SQLAlchemy renders the right-hand side as a JSONB literal rather than
        # a plain text bind parameter.
        tags_col = cast(EnterpriseArtifact.tags, JSONB)

        if match_all:
            # tags_col @> '["a", "b"]'::jsonb -- single predicate, most efficient
            required_jsonb = cast(json.dumps(tags), JSONB)
            predicate = tags_col.op("@>")(required_jsonb)
            stmt = (
                self._tenant_select()
                .where(predicate)
                .order_by(EnterpriseArtifact.created_at.desc())
            )
        else:
            # OR of: tags_col @> '["a"]', tags_col @> '["b"]', ...
            predicates = [
                tags_col.op("@>")(cast(json.dumps([tag]), JSONB)) for tag in tags
            ]
            stmt = (
                self._tenant_select()
                .where(or_(*predicates))
                .order_by(EnterpriseArtifact.created_at.desc())
            )

        # ENT-002: Enforce visibility access control when auth context is present.
        # Visibility-excluded items are silently omitted from results.
        if auth_context is not None:
            from skillmeat.core.repositories.filters import apply_visibility_filter_stmt

            stmt = apply_visibility_filter_stmt(stmt, EnterpriseArtifact, auth_context)

        return list(self.session.execute(stmt).scalars().all())

    def batch_resolve_uuids(
        self,
        artifacts: List[Tuple[str, str]],
        ctx: Optional["RequestContext"] = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> Dict[Tuple[str, str], str]:
        """Batch-resolve UUIDs for multiple (artifact_type, name) pairs.

        Executes a single query with OR conditions for all pairs, applying
        tenant scoping per EnterpriseRepositoryBase conventions.

        Parameters
        ----------
        artifacts:
            List of (artifact_type, name) tuples to resolve.
        ctx:
            Optional per-request metadata (unused in enterprise repo).
        auth_context:
            Optional authentication context for tenant scoping.

        Returns
        -------
        dict
            Mapping from (artifact_type, name) tuple to 32-char hex UUID string.
            Pairs that cannot be resolved are omitted.
        """
        from sqlalchemy import and_, or_

        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        if not artifacts:
            return {}

        self._apply_auth_context(auth_context)

        # Build OR conditions for each (type, name) pair
        conditions = [
            and_(
                EnterpriseArtifact.artifact_type == atype,
                EnterpriseArtifact.name == name,
            )
            for atype, name in artifacts
        ]

        stmt = self._tenant_select().where(or_(*conditions))
        rows = self.session.execute(stmt).scalars().all()

        # Map results back to (type, name) tuple keys
        return {(row.artifact_type, row.name): row.id.hex for row in rows}

    # ------------------------------------------------------------------
    # ENT-2.6: Version history retrieval
    # ------------------------------------------------------------------

    def get_content(
        self,
        artifact_id: uuid.UUID,
        version: Optional[str] = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> Optional[str]:
        """Return the Markdown content for a specific or the latest artifact version.

        Validates the artifact against the current tenant before querying
        version rows, so a caller cannot read content from another tenant's
        artifact by guessing its UUID.

        Parameters
        ----------
        artifact_id:
            UUID primary key of the parent artifact.
        version:
            Optional ``version_tag`` string (e.g. ``"v1.2.0"``, ``"latest"``).
            When ``None``, the newest version by ``created_at`` is returned.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        str or None
            The ``markdown_payload`` of the matching version, or ``None`` if
            the artifact does not exist for this tenant or has no versions.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersion

        self._apply_auth_context(auth_context)
        # get() returns None for both not-found and not-visible (prevents existence
        # disclosure).  Propagate None immediately — no separate access-denied path.
        artifact = self.get(artifact_id, auth_context=auth_context)
        if artifact is None:
            return None

        stmt = select(EnterpriseArtifactVersion).where(
            EnterpriseArtifactVersion.artifact_id == artifact_id
        )
        if version is not None:
            stmt = stmt.where(EnterpriseArtifactVersion.version_tag == version)
        else:
            stmt = stmt.order_by(EnterpriseArtifactVersion.created_at.desc())
        stmt = stmt.limit(1)

        version_row = self.session.execute(stmt).scalar_one_or_none()
        if version_row is None:
            return None
        return version_row.markdown_payload

    def list_versions(
        self,
        artifact_id: uuid.UUID,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[EnterpriseArtifactVersion]":
        """Return all version records for an artifact, newest first.

        Validates the artifact against the current tenant before querying
        version rows to prevent enumeration of another tenant's version history.

        Parameters
        ----------
        artifact_id:
            UUID primary key of the parent artifact.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        list[EnterpriseArtifactVersion]
            Ordered list of version rows (newest first by ``created_at``).
            Returns an empty list if the artifact does not exist for this
            tenant or has no recorded versions.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersion

        self._apply_auth_context(auth_context)
        # get() returns None for both not-found and not-visible (prevents existence
        # disclosure).  Propagate empty list immediately — no separate access-denied path.
        artifact = self.get(artifact_id, auth_context=auth_context)
        if artifact is None:
            return []

        stmt = (
            select(EnterpriseArtifactVersion)
            .where(EnterpriseArtifactVersion.artifact_id == artifact_id)
            .order_by(EnterpriseArtifactVersion.created_at.desc())
        )
        return list(self.session.execute(stmt).scalars().all())

        # ------------------------------------------------------------------

    # ENT-2.4: Create
    # ------------------------------------------------------------------

    def create(
        self,
        dto_or_name=None,
        artifact_type: Optional[str] = None,
        source: Optional[str] = None,
        content: Optional[str] = None,
        metadata: Optional[Dict] = None,
        tags: Optional[List[str]] = None,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
        owner_target: "Optional[object]" = None,
        # Legacy keyword-only alias so old callers ``create(name="x", ...)`` still work
        name: Optional[str] = None,
    ) -> "ArtifactDTO":
        """Create a new artifact row and optionally an initial version.

        Implements the :class:`~skillmeat.core.interfaces.repositories.IArtifactRepository`
        contract.  The first positional argument accepts either an
        :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO` (interface-compliant
        callers) or a plain string artifact name (legacy callers that previously
        called ``create(name=..., artifact_type=...)``.

        Parameters
        ----------
        dto_or_name:
            Either an :class:`ArtifactDTO` (preferred), or a string artifact
            name for backward compatibility with legacy callers.
        artifact_type:
            Artifact type string (legacy kwarg; ignored when *dto_or_name* is a
            :class:`ArtifactDTO`).
        source:
            Optional GitHub origin URL (legacy kwarg).
        content:
            If provided, an ``EnterpriseArtifactVersion`` row at
            ``version_tag="1.0.0"`` is created alongside the artifact.
        metadata:
            Arbitrary JSONB key-value pairs stored in ``custom_fields``
            (legacy kwarg).
        tags:
            List of tag strings stored in the ``tags`` JSONB column
            (legacy kwarg).
        ctx:
            Optional per-request metadata (currently unused).
        auth_context:
            Optional authentication context.  When provided, the active tenant
            is set via ``TenantContext`` and ``owner_id`` is populated from
            ``auth_context.user_id``.
        owner_target:
            Explicit ownership target (currently unused; reserved for future
            team-owned artifact support).
        name:
            Legacy keyword alias for the artifact name when called without a
            positional DTO argument.

        Returns
        -------
        ArtifactDTO
            The persisted artifact represented as a DTO.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseArtifactVersion,
        )
        from skillmeat.core.interfaces.dtos import ArtifactDTO as _ArtifactDTO

        # Resolve arguments: ArtifactDTO path vs. legacy kwargs path.
        if isinstance(dto_or_name, _ArtifactDTO):
            dto = dto_or_name
            _name: str = dto.name
            _artifact_type: str = dto.artifact_type
            _source: Optional[str] = dto.source
            _content: Optional[str] = None  # ArtifactDTO has no content field
            _metadata: Optional[Dict] = dict(dto.metadata) if dto.metadata else None
            _tags: Optional[List[str]] = list(dto.tags) if dto.tags else None
        else:
            # Legacy: first arg is name string (or name was passed as kwarg)
            _name = str(dto_or_name) if dto_or_name is not None else (name or "")
            _artifact_type = artifact_type or ""
            _source = source
            _content = content
            _metadata = metadata
            _tags = tags

        owner_id = self._apply_auth_context(auth_context)
        tenant_id = self._get_tenant_id()
        artifact = EnterpriseArtifact(
            tenant_id=tenant_id,
            owner_id=owner_id,
            name=_name,
            artifact_type=_artifact_type,
            source_url=_source,
            tags=_tags or [],
            custom_fields=_metadata or {},
        )
        self.session.add(artifact)
        self.session.flush()  # Populate artifact.id before version FK reference

        if _content is not None:
            content_hash = self._compute_content_hash(_content)
            version = EnterpriseArtifactVersion(
                tenant_id=tenant_id,
                artifact_id=artifact.id,
                version_tag="1.0.0",
                content_hash=content_hash,
                markdown_payload=_content,
                content_payload={"files": {}},  # Initialize empty CAS manifest
            )
            self.session.add(version)

        self.session.commit()
        self.session.refresh(artifact)
        self._log_operation(
            operation="create",
            entity_type="EnterpriseArtifact",
            entity_id=artifact.id,
            metadata={"name": _name, "artifact_type": _artifact_type},
        )
        return self._artifact_to_dto(artifact)

    # ------------------------------------------------------------------
    # ENT-2.4: Update
    # ------------------------------------------------------------------

    def update(
        self,
        id,  # str ("type:name") per IArtifactRepository, or uuid.UUID for legacy callers
        updates: Optional[Dict] = None,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
        # Legacy keyword kwargs — used when called as update(uuid, name=..., content=...)
        name: Optional[str] = None,
        content: Optional[str] = None,
        metadata: Optional[Dict] = None,
        tags: Optional[List[str]] = None,
    ) -> "ArtifactDTO":
        """Apply a partial update to an existing artifact.

        Implements the :class:`~skillmeat.core.interfaces.repositories.IArtifactRepository`
        contract.  Accepts the new interface signature ``update(id_str, updates_dict)``
        as well as the legacy ``update(uuid, name=..., content=..., ...)`` form so
        that existing callers continue to work without modification.

        If *content* changes (i.e. it differs from the latest stored
        version's ``markdown_payload``), a new ``EnterpriseArtifactVersion``
        row is created with an auto-incremented version tag.

        Parameters
        ----------
        id:
            Either a composite string ``"type:name"`` (interface-compliant
            callers) or a ``uuid.UUID`` primary key (legacy callers).
        updates:
            Dict of field names to new values (interface-compliant callers).
            Recognised keys: ``name``, ``content``, ``metadata``, ``tags``.
            Ignored when legacy keyword arguments are supplied.
        ctx:
            Optional per-request metadata (currently unused).
        auth_context:
            Optional authentication context.  When provided, the active tenant
            is set via ``TenantContext`` and the update is further restricted to
            artifacts owned by ``auth_context.user_id``.
        name:
            Legacy kwarg — new artifact name.
        content:
            Legacy kwarg — new Markdown content.
        metadata:
            Legacy kwarg — replacement ``custom_fields`` dict.
        tags:
            Legacy kwarg — replacement tag list.

        Returns
        -------
        ArtifactDTO
            The updated artifact represented as a DTO.

        Raises
        ------
        KeyError
            If no artifact with *id* exists (interface contract).
        ValueError
            If the artifact exists but belongs to a different tenant or owner
            (legacy contract, also raised on UUID path).
        TenantIsolationError
            If the artifact belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseArtifactVersion,
        )

        # Resolve the update kwargs from either the dict or legacy keyword args.
        _updates: Dict = updates or {}
        _name: Optional[str] = _updates.get("name", name)
        _content: Optional[str] = _updates.get("content", content)
        _metadata: Optional[Dict] = _updates.get("metadata", metadata)
        _tags: Optional[List[str]] = _updates.get("tags", tags)

        owner_id = self._apply_auth_context(auth_context)

        # Resolve the artifact: UUID PK (legacy) or type:name (interface).
        if isinstance(id, uuid.UUID):
            artifact_id: uuid.UUID = id
            artifact: Optional[EnterpriseArtifact] = self.session.get(
                EnterpriseArtifact, artifact_id
            )
            if artifact is None:
                raise ValueError(f"EnterpriseArtifact {artifact_id!r} not found.")
        else:
            art_type, art_name = str(id).split(":", 1)
            stmt = (
                self._tenant_select()
                .where(EnterpriseArtifact.artifact_type == art_type)
                .where(EnterpriseArtifact.name == art_name)
                .limit(1)
            )
            artifact = self.session.execute(stmt).scalar_one_or_none()
            if artifact is None:
                raise KeyError(f"Artifact {id!r} not found.")
            artifact_id = artifact.id

        self._assert_tenant_owns(artifact)
        # When an authenticated user is present, enforce owner-level access.
        if owner_id is not None and artifact.owner_id != owner_id:
            raise ValueError(
                f"EnterpriseArtifact {artifact_id!r} is not owned by the "
                f"authenticated user."
            )

        changed_fields: Dict[str, object] = {}
        if _name is not None:
            changed_fields["name"] = _name
            artifact.name = _name
        if _metadata is not None:
            artifact.custom_fields = _metadata
        if _tags is not None:
            artifact.tags = _tags

        artifact.updated_at = datetime.utcnow()

        if _content is not None:
            new_hash = self._compute_content_hash(_content)
            # Only create a new version when content actually changed
            latest_version: Optional[EnterpriseArtifactVersion] = None
            if artifact.versions:
                latest_version = artifact.versions[0]  # ordered by created_at desc
            if latest_version is None or latest_version.content_hash != new_hash:
                next_tag = (
                    self._next_version(latest_version.version_tag)
                    if latest_version
                    else "1.0.0"
                )
                new_version = EnterpriseArtifactVersion(
                    tenant_id=artifact.tenant_id,
                    artifact_id=artifact.id,
                    version_tag=next_tag,
                    content_hash=new_hash,
                    markdown_payload=_content,
                    content_payload={"files": {}},  # Initialize empty CAS manifest
                )
                self.session.add(new_version)
                changed_fields["new_version_tag"] = next_tag

        self.session.commit()
        self.session.refresh(artifact)
        self._log_operation(
            operation="update",
            entity_type="EnterpriseArtifact",
            entity_id=artifact_id,
            metadata=changed_fields or None,
        )
        return self._artifact_to_dto(artifact)

    # ------------------------------------------------------------------
    # ENT-2.5: Soft delete
    # ------------------------------------------------------------------

    def soft_delete(
        self,
        artifact_id: uuid.UUID,
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Logically delete an artifact by clearing ``is_active``.

        The row is retained in the database for audit purposes.  Subsequent
        reads that filter on ``is_active = TRUE`` will exclude this artifact.

        Parameters
        ----------
        artifact_id:
            UUID primary key of the artifact to soft-delete.
        auth_context:
            Optional authentication context.  When provided, the active tenant
            is set via ``TenantContext`` and the operation is restricted to
            artifacts owned by ``auth_context.user_id``.

        Returns
        -------
        bool
            ``True`` on success.

        Raises
        ------
        ValueError
            If no artifact with *artifact_id* exists in the current tenant (or
            owned by the authenticated user when *auth_context* is provided).
        TenantIsolationError
            If the artifact belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        owner_id = self._apply_auth_context(auth_context)
        artifact: Optional[EnterpriseArtifact] = self.session.get(
            EnterpriseArtifact, artifact_id
        )
        if artifact is None:
            raise ValueError(f"EnterpriseArtifact {artifact_id!r} not found.")
        self._assert_tenant_owns(artifact)
        if owner_id is not None and artifact.owner_id != owner_id:
            raise ValueError(
                f"EnterpriseArtifact {artifact_id!r} is not owned by the "
                f"authenticated user."
            )

        artifact.is_active = False
        artifact.updated_at = datetime.utcnow()
        self.session.flush()
        self.session.commit()
        self._log_operation(
            operation="soft_delete",
            entity_type="EnterpriseArtifact",
            entity_id=artifact_id,
        )
        return True

    # ------------------------------------------------------------------
    # ENT-2.5: Hard delete
    # ------------------------------------------------------------------

    def hard_delete(
        self,
        artifact_id: uuid.UUID,
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Permanently remove an artifact and all related rows.

        Removal order:
        1. Assert tenant ownership.
        2. Delete ``EnterpriseCollectionArtifact`` membership rows so that
           collections that hold this artifact do not end up with dangling
           references (the DB ON DELETE CASCADE handles this too, but we
           do it explicitly for clarity and to avoid relying on cascade
           configuration in test environments).
        3. Delete the ``EnterpriseArtifact`` row — the
           ``cascade="all, delete-orphan"`` on ``versions`` removes all
           associated ``EnterpriseArtifactVersion`` rows automatically via
           the SQLAlchemy ORM cascade.

        Parameters
        ----------
        artifact_id:
            UUID primary key of the artifact to permanently remove.
        auth_context:
            Optional authentication context.  When provided, the active tenant
            is set via ``TenantContext`` and the operation is restricted to
            artifacts owned by ``auth_context.user_id``.

        Returns
        -------
        bool
            ``True`` on success.

        Raises
        ------
        ValueError
            If no artifact with *artifact_id* exists in the current tenant (or
            owned by the authenticated user when *auth_context* is provided).
        TenantIsolationError
            If the artifact belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseCollectionArtifact,
        )

        owner_id = self._apply_auth_context(auth_context)
        artifact: Optional[EnterpriseArtifact] = self.session.get(
            EnterpriseArtifact, artifact_id
        )
        if artifact is None:
            raise ValueError(f"EnterpriseArtifact {artifact_id!r} not found.")
        self._assert_tenant_owns(artifact)
        if owner_id is not None and artifact.owner_id != owner_id:
            raise ValueError(
                f"EnterpriseArtifact {artifact_id!r} is not owned by the "
                f"authenticated user."
            )

        # Explicitly remove collection membership rows before the artifact
        # itself so that intent is clear regardless of cascade settings.
        self.session.execute(
            delete(EnterpriseCollectionArtifact).where(
                EnterpriseCollectionArtifact.artifact_id == artifact_id
            )
        )

        # Deleting the artifact cascades to EnterpriseArtifactVersion via the
        # "all, delete-orphan" relationship cascade defined on EnterpriseArtifact.
        self.session.delete(artifact)
        self.session.commit()
        self._log_operation(
            operation="hard_delete",
            entity_type="EnterpriseArtifact",
            entity_id=artifact_id,
        )
        return True

    # ------------------------------------------------------------------
    # IArtifactRepository: delete()
    # ------------------------------------------------------------------

    def delete(
        self,
        id: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Delete an artifact by its composite ``type:name`` primary key.

        Implements the :class:`~skillmeat.core.interfaces.repositories.IArtifactRepository`
        contract.  Delegates to :meth:`hard_delete` after resolving the artifact
        UUID from the ``type:name`` composite key.

        Parameters
        ----------
        id:
            Composite string ``"type:name"`` (e.g. ``"skill:canvas-design"``).
        ctx:
            Optional per-request metadata (currently unused).
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before the lookup.

        Returns
        -------
        bool
            ``True`` when the artifact was found and deleted, ``False`` when no
            matching record existed.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        art_type, art_name = str(id).split(":", 1)
        self._apply_auth_context(auth_context)
        stmt = (
            self._tenant_select()
            .where(EnterpriseArtifact.artifact_type == art_type)
            .where(EnterpriseArtifact.name == art_name)
            .limit(1)
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return False
        return self.hard_delete(row.id, auth_context=auth_context)

    # ------------------------------------------------------------------
    # CAI-P5 / enterprise parity: resolve / batch-resolve helpers
    # ------------------------------------------------------------------

    def resolve_uuid_by_type_name(
        self, artifact_type: str, name: str
    ) -> "Optional[str]":
        """Return the UUID hex string for the artifact matching *artifact_type* and *name*.

        Parameters
        ----------
        artifact_type:
            Artifact type string (e.g. ``"skill"``).
        name:
            Human-readable artifact name (e.g. ``"canvas-design"``).

        Returns
        -------
        str or None
            32-char hex UUID string (``row.id.hex``) if found, ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        stmt = (
            self._tenant_select()
            .where(EnterpriseArtifact.artifact_type == artifact_type)
            .where(EnterpriseArtifact.name == name)
            .limit(1)
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return None
        return str(row.id)

    def get_ids_by_uuids(self, uuids: "List[str]") -> "Dict[str, str]":
        """Batch-resolve ``type:name`` composite IDs from a list of UUID strings.

        Parameters
        ----------
        uuids:
            List of UUID strings to look up.  Empty list returns ``{}``.

        Returns
        -------
        dict
            Mapping from UUID hex string to ``"type:name"`` composite ID string.
            UUIDs that have no matching row are omitted from the result.
        """
        import uuid as _uuid_mod

        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        if not uuids:
            return {}

        parsed: List[_uuid_mod.UUID] = []
        for u in uuids:
            try:
                parsed.append(_uuid_mod.UUID(str(u)))
            except (ValueError, AttributeError):
                pass

        if not parsed:
            return {}

        stmt = self._apply_tenant_filter(
            select(EnterpriseArtifact).where(EnterpriseArtifact.id.in_(parsed))
        )
        rows = self.session.execute(stmt).scalars().all()
        return {str(row.id): f"{row.artifact_type}:{row.name}" for row in rows}

    def update_collection_tags(self, uuid: str, tags: "List[str]") -> None:
        """Replace the ``tags`` JSONB array for the artifact identified by *uuid*.

        Parameters
        ----------
        uuid:
            UUID string of the target artifact.
        tags:
            New list of tag strings to store.

        Raises
        ------
        KeyError
            If no artifact with *uuid* exists in the current tenant.
        """
        import uuid as _uuid_mod

        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        try:
            parsed_uuid = _uuid_mod.UUID(str(uuid))
        except (ValueError, AttributeError) as exc:
            raise KeyError(uuid) from exc

        stmt = self._apply_tenant_filter(
            select(EnterpriseArtifact).where(EnterpriseArtifact.id == parsed_uuid)
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            raise KeyError(uuid)

        row.tags = list(tags)
        self.session.flush()

    def get_collection_description(self, uuid: str) -> "Optional[str]":
        """Return the ``description`` for the artifact identified by *uuid*.

        Parameters
        ----------
        uuid:
            UUID string of the target artifact.

        Returns
        -------
        str or None
            Description string if present, ``None`` if the artifact is not
            found for the current tenant or has no description.
        """
        import uuid as _uuid_mod

        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        try:
            parsed_uuid = _uuid_mod.UUID(str(uuid))
        except (ValueError, AttributeError):
            return None

        stmt = self._apply_tenant_filter(
            select(EnterpriseArtifact).where(EnterpriseArtifact.id == parsed_uuid)
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return None
        return row.description

    # ------------------------------------------------------------------
    # IArtifactRepository stubs — methods not yet implemented in enterprise
    # edition.  These raise NotImplementedError rather than AttributeError so
    # callers receive a clear, actionable error message at runtime.
    # ------------------------------------------------------------------

    def update_content(
        self,
        id: str,
        content: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Not yet implemented for the enterprise edition.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError(
            "Enterprise edition: update_content not yet implemented"
        )

    def get_tags(
        self,
        id: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[TagDTO]":
        """Not yet implemented for the enterprise edition.

        Tags on enterprise artifacts are stored in the ``tags`` JSONB column
        and managed via :meth:`update_collection_tags`.  A dedicated
        ``get_tags`` path against the ``EnterpriseTag`` join table is a
        planned future enhancement.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError("Enterprise edition: get_tags not yet implemented")

    def set_tags(
        self,
        id: str,
        tag_ids: "List[str]",
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Not yet implemented for the enterprise edition.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError("Enterprise edition: set_tags not yet implemented")

    def get_with_collection_context(
        self,
        uuid: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "Optional[ArtifactDTO]":
        """Not yet implemented for the enterprise edition.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError(
            "Enterprise edition: get_with_collection_context not yet implemented"
        )

    def get_collection_memberships(
        self,
        uuid: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[CollectionMembershipDTO]":
        """Not yet implemented for the enterprise edition.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError(
            "Enterprise edition: get_collection_memberships not yet implemented"
        )

    def get_duplicate_cluster_members(
        self,
        cluster_id: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[ArtifactDTO]":
        """Not yet implemented for the enterprise edition.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError(
            "Enterprise edition: get_duplicate_cluster_members not yet implemented"
        )

    def validate_exists(
        self,
        uuid: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Not yet implemented for the enterprise edition.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError(
            "Enterprise edition: validate_exists not yet implemented"
        )

    def get_by_type(
        self,
        artifact_type: str,
        ctx: "Optional[object]" = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[ArtifactDTO]":
        """Not yet implemented for the enterprise edition.

        Delegates to :meth:`list` with an ``artifact_type`` filter.  Kept as
        a separate method per the :class:`IArtifactRepository` contract.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError("Enterprise edition: get_by_type not yet implemented")


# ---------------------------------------------------------------------------
# EnterpriseCollectionRepository  (ENT-2.7, ENT-2.8)
# ---------------------------------------------------------------------------


class EnterpriseCollectionRepository(EnterpriseRepositoryBase["EnterpriseCollection"]):
    """Repository for tenant-scoped CRUD on EnterpriseCollection.

    All queries are automatically scoped to the tenant stored in
    ``TenantContext``.  Membership helpers (ENT-2.8) additionally validate
    that the target artifact belongs to the same tenant before creating a
    link.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.  Lifecycle (commit/rollback/close) is managed by the caller.

    Examples
    --------
    ::

        with tenant_scope(tenant_uuid):
            repo = EnterpriseCollectionRepository(db_session)
            col = repo.create("My Collection", description="Personal picks")
            repo.add_artifact(col.id, artifact_uuid)
            artifacts = repo.list_artifacts(col.id)
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseCollection as _EC

        super().__init__(session, _EC)

    # ------------------------------------------------------------------
    # ENT-2.7: Collection CRUD
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None,
        auth_context: Optional["AuthContext"] = None,
        is_default: bool = False,
    ) -> "EnterpriseCollection":
        """Create a new collection scoped to the current tenant.

        Parameters
        ----------
        name:
            Human-readable collection name; must be unique per tenant.
        description:
            Optional free-text description.
        metadata:
            Reserved for future extensibility; unused by the model today.
        auth_context:
            Optional authentication context.  When provided, the active tenant
            is set via ``TenantContext`` and ``owner_id`` is populated from
            ``auth_context.user_id``.
        is_default:
            When ``True`` the collection is designated as the implicit default
            for the tenant (e.g. the bootstrap collection created on first
            startup).  Only one collection per tenant should have this flag set;
            enforcement is at the application layer.

        Returns
        -------
        EnterpriseCollection
            The newly persisted ORM instance (added and flushed).
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollection

        owner_id = self._apply_auth_context(auth_context)
        tenant_id = self._get_tenant_id()
        collection = EnterpriseCollection(
            tenant_id=tenant_id,
            owner_id=owner_id,
            name=name,
            description=description,
            is_default=is_default,
        )
        self.session.add(collection)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseCollection",
            entity_id=collection.id,
            metadata={"name": name},
        )
        return collection

    def get(
        self,
        collection_id: uuid.UUID,
        auth_context: Optional["AuthContext"] = None,
    ) -> "Optional[EnterpriseCollection]":
        """Retrieve a collection by primary key, asserting tenant ownership.

        .. note::
            Collections are intentionally **not** visibility-filtered.
            ``EnterpriseCollection`` has no ``visibility`` column — all tenant
            members share access to every collection (shared-library model).
            Visibility filtering applies only to the *artifacts* returned
            through a collection (see :meth:`list_artifacts`).

        Parameters
        ----------
        collection_id:
            UUID primary key of the collection to fetch.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before the ownership assertion.

        Returns
        -------
        EnterpriseCollection or None
            The collection instance, or ``None`` if it does not exist.

        Raises
        ------
        TenantIsolationError
            If the retrieved collection belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollection

        self._apply_auth_context(auth_context)
        collection = self.session.get(EnterpriseCollection, collection_id)
        if collection is None:
            return None
        self._assert_tenant_owns(collection)
        return collection

    def get_by_name(
        self,
        name: str,
        auth_context: Optional["AuthContext"] = None,
    ) -> "Optional[EnterpriseCollection]":
        """Retrieve a collection by name within the current tenant.

        .. note::
            Collections are intentionally **not** visibility-filtered.
            ``EnterpriseCollection`` has no ``visibility`` column — all tenant
            members share access to every collection (shared-library model).
            Visibility filtering applies only to the *artifacts* returned
            through a collection (see :meth:`list_artifacts`).

        Parameters
        ----------
        name:
            The exact collection name to look up.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        EnterpriseCollection or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollection

        self._apply_auth_context(auth_context)
        stmt = self._tenant_select().where(EnterpriseCollection.name == name)
        return self.session.execute(stmt).scalar_one_or_none()

    def list(
        self,
        offset: int = 0,
        limit: int = 50,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[EnterpriseCollection]":
        """Return a paginated list of collections for the current tenant.

        .. note::
            Collections are intentionally **not** visibility-filtered.
            ``EnterpriseCollection`` has no ``visibility`` column — all tenant
            members share access to every collection (shared-library model).
            Visibility filtering applies only to the *artifacts* returned
            through a collection (see :meth:`list_artifacts`).

        Parameters
        ----------
        offset:
            Number of rows to skip (0-based).
        limit:
            Maximum number of rows to return.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before filtering.

        Returns
        -------
        List[EnterpriseCollection]
            Collections ordered alphabetically by name.
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollection

        self._apply_auth_context(auth_context)
        stmt = (
            self._tenant_select()
            .order_by(EnterpriseCollection.name)
            .offset(offset)
            .limit(limit)
        )
        return list(self.session.execute(stmt).scalars())

    def update(
        self,
        collection_id: uuid.UUID,
        name: Optional[str] = None,
        description: Optional[str] = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "EnterpriseCollection":
        """Update mutable fields on an existing collection.

        Only non-``None`` arguments are applied; passing ``None`` leaves the
        field unchanged.

        Parameters
        ----------
        collection_id:
            UUID of the collection to update.
        name:
            New name, or ``None`` to leave unchanged.
        description:
            New description, or ``None`` to leave unchanged.
        auth_context:
            Optional authentication context.  When provided, the active tenant
            is set via ``TenantContext`` and the update is restricted to
            collections owned by ``auth_context.user_id``.

        Returns
        -------
        EnterpriseCollection
            The updated ORM instance (already flushed).

        Raises
        ------
        ValueError
            If the collection does not exist (or is not owned by the
            authenticated user when *auth_context* is provided).
        TenantIsolationError
            If the collection belongs to a different tenant.
        """
        owner_id = self._apply_auth_context(auth_context)
        collection = self.get(collection_id)
        if collection is None:
            raise ValueError(f"EnterpriseCollection {collection_id!r} not found.")
        if owner_id is not None and collection.owner_id != owner_id:
            raise ValueError(
                f"EnterpriseCollection {collection_id!r} is not owned by the "
                f"authenticated user."
            )
        changed: Dict[str, object] = {}
        if name is not None:
            changed["name"] = name
            collection.name = name
        if description is not None:
            changed["description"] = description
            collection.description = description
        collection.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseCollection",
            entity_id=collection_id,
            metadata=changed or None,
        )
        return collection

    def delete(
        self,
        collection_id: uuid.UUID,
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Delete a collection and all of its membership rows.

        Membership rows are removed first (in case the DB engine does not
        honour cascade deletes in the same flush), then the collection itself
        is deleted.

        Parameters
        ----------
        collection_id:
            UUID of the collection to delete.
        auth_context:
            Optional authentication context.  When provided, the active tenant
            is set via ``TenantContext`` and the operation is restricted to
            collections owned by ``auth_context.user_id``.

        Returns
        -------
        bool
            ``True`` if the collection existed and was deleted; ``False`` if it
            was not found.

        Raises
        ------
        ValueError
            If the collection is not owned by the authenticated user when
            *auth_context* is provided.
        TenantIsolationError
            If the collection belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        owner_id = self._apply_auth_context(auth_context)
        collection = self.get(collection_id)
        if collection is None:
            return False
        if owner_id is not None and collection.owner_id != owner_id:
            raise ValueError(
                f"EnterpriseCollection {collection_id!r} is not owned by the "
                f"authenticated user."
            )
        # Remove membership rows explicitly alongside the ORM cascade.
        self.session.execute(
            delete(EnterpriseCollectionArtifact).where(
                EnterpriseCollectionArtifact.collection_id == collection_id
            )
        )
        self.session.delete(collection)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseCollection",
            entity_id=collection_id,
        )
        return True

    # ------------------------------------------------------------------
    # ENT-2.8: Collection membership
    # ------------------------------------------------------------------

    def _get_artifact_for_tenant(
        self,
        artifact_id: uuid.UUID,
        auth_context: Optional["AuthContext"] = None,
    ) -> "Optional[EnterpriseArtifact]":
        """Return an EnterpriseArtifact if it exists and belongs to the current tenant.

        This is a write-path helper (called from :meth:`add_artifact`).
        Visibility filtering is intentionally not applied here: write
        operations check tenant isolation only, not per-user visibility.

        Parameters
        ----------
        artifact_id:
            UUID of the artifact to look up.
        auth_context:
            Optional authentication context.  Reserved for future use;
            currently unused in write-path existence checks (``None`` is the
            expected default).

        Raises
        ------
        TenantIsolationError
            If the artifact exists but belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        artifact = self.session.get(EnterpriseArtifact, artifact_id)
        if artifact is None:
            return None
        current_tenant = self._get_tenant_id()
        if artifact.tenant_id != current_tenant:
            raise TenantIsolationError(
                object_tenant_id=artifact.tenant_id,
                current_tenant_id=current_tenant,
                detail=(
                    f"EnterpriseArtifact {artifact_id!r} belongs to a different tenant."
                ),
            )
        return artifact

    def add_artifact(
        self,
        collection_id: uuid.UUID,
        artifact_id: uuid.UUID,
        position: Optional[int] = None,
        auth_context: Optional["AuthContext"] = None,
    ) -> "EnterpriseCollectionArtifact":
        """Add an artifact to a collection.

        Both the collection and the artifact must belong to the current tenant.
        If *position* is ``None`` the artifact is appended after all existing
        members (``max(order_index) + 1``).

        Parameters
        ----------
        collection_id:
            UUID of the target collection.
        artifact_id:
            UUID of the artifact to add.
        position:
            Explicit 0-based position index; ``None`` = append.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before all ownership checks.

        Returns
        -------
        EnterpriseCollectionArtifact
            The newly created membership row (flushed but not committed).

        Raises
        ------
        ValueError
            If the collection or artifact does not exist.
        TenantIsolationError
            If either belongs to a different tenant.
        """
        from sqlalchemy import func as _func
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        self._apply_auth_context(auth_context)
        collection = self.get(collection_id)
        if collection is None:
            raise ValueError(f"EnterpriseCollection {collection_id!r} not found.")
        artifact = self._get_artifact_for_tenant(artifact_id)
        if artifact is None:
            raise ValueError(f"EnterpriseArtifact {artifact_id!r} not found.")

        if position is None:
            result = self.session.execute(
                select(_func.max(EnterpriseCollectionArtifact.order_index)).where(
                    EnterpriseCollectionArtifact.collection_id == collection_id
                )
            ).scalar()
            position = 0 if result is None else result + 1

        membership = EnterpriseCollectionArtifact(
            collection_id=collection_id,
            artifact_id=artifact_id,
            order_index=position,
        )
        self.session.add(membership)
        self.session.flush()
        self._log_operation(
            operation="add_artifact",
            entity_type="EnterpriseCollectionArtifact",
            entity_id=membership.id,
            metadata={
                "collection_id": str(collection_id),
                "artifact_id": str(artifact_id),
                "position": position,
            },
        )
        return membership

    def remove_artifact(
        self,
        collection_id: uuid.UUID,
        artifact_id: uuid.UUID,
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Remove an artifact from a collection.

        Parameters
        ----------
        collection_id:
            UUID of the collection.
        artifact_id:
            UUID of the artifact to remove.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before the ownership check.

        Returns
        -------
        bool
            ``True`` if a membership row was found and deleted; ``False`` if
            the membership did not exist.

        Raises
        ------
        TenantIsolationError
            If the collection belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        self._apply_auth_context(auth_context)
        collection = self.get(collection_id)
        if collection is None:
            return False

        result = self.session.execute(
            delete(EnterpriseCollectionArtifact).where(
                EnterpriseCollectionArtifact.collection_id == collection_id,
                EnterpriseCollectionArtifact.artifact_id == artifact_id,
            )
        )
        deleted = result.rowcount > 0
        if deleted:
            self.session.flush()
            self._log_operation(
                operation="remove_artifact",
                entity_type="EnterpriseCollectionArtifact",
                entity_id=None,
                metadata={
                    "collection_id": str(collection_id),
                    "artifact_id": str(artifact_id),
                },
            )
        return deleted

    def list_artifacts(
        self,
        collection_id: uuid.UUID,
        auth_context: Optional["AuthContext"] = None,
    ) -> "List[EnterpriseArtifact]":
        """Return the visibility-filtered artifacts in a collection, ordered by position.

        Collections themselves are public-within-tenant (no ``visibility``
        column on ``EnterpriseCollection``).  However, the *artifacts* inside
        a collection DO carry per-row visibility, so a tenant member must not
        see private artifacts owned by someone else just because they share a
        collection.  When *auth_context* is provided,
        :func:`~skillmeat.core.repositories.filters.apply_visibility_filter_stmt`
        is applied to the ``EnterpriseArtifact`` half of the join so that only
        rows the caller is permitted to see are returned.

        Parameters
        ----------
        collection_id:
            UUID of the collection.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before the ownership check and applies
            per-user visibility filtering to the returned artifacts.

        Returns
        -------
        List[EnterpriseArtifact]
            Artifacts ordered by ``order_index`` ascending, filtered by the
            caller's visibility permissions when *auth_context* is not ``None``.

        Raises
        ------
        TenantIsolationError
            If the collection belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseCollectionArtifact,
        )
        from skillmeat.core.repositories.filters import apply_visibility_filter_stmt

        self._apply_auth_context(auth_context)
        collection = self.get(collection_id)
        if collection is None:
            return []

        stmt = (
            select(EnterpriseArtifact)
            .join(
                EnterpriseCollectionArtifact,
                EnterpriseCollectionArtifact.artifact_id == EnterpriseArtifact.id,
            )
            .where(
                EnterpriseCollectionArtifact.collection_id == collection_id,
                EnterpriseArtifact.tenant_id == self._get_tenant_id(),
            )
            .order_by(EnterpriseCollectionArtifact.order_index)
        )
        # ENT-002: Visibility-excluded artifacts are silently omitted from
        # results.  Members cannot see private artifacts owned by others even
        # when they share the same collection.
        if auth_context is not None:
            stmt = apply_visibility_filter_stmt(stmt, EnterpriseArtifact, auth_context)
        return list(self.session.execute(stmt).scalars())

    def reorder_artifacts(
        self,
        collection_id: uuid.UUID,
        artifact_ids: List[uuid.UUID],
        auth_context: Optional["AuthContext"] = None,
    ) -> bool:
        """Reorder artifacts within a collection.

        Sets ``order_index`` for each membership to the position of that
        artifact in *artifact_ids* (0-based).  Artifacts that are currently
        members but absent from *artifact_ids* retain their existing
        ``order_index`` values.

        Parameters
        ----------
        collection_id:
            UUID of the collection to reorder.
        artifact_ids:
            Ordered list of artifact UUIDs.  Position 0 → ``order_index = 0``.
        auth_context:
            Optional authentication context.  When provided, sets the active
            tenant via ``TenantContext`` before the ownership check.

        Returns
        -------
        bool
            ``True`` if the collection exists and the update was applied;
            ``False`` if the collection was not found.

        Raises
        ------
        TenantIsolationError
            If the collection belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        self._apply_auth_context(auth_context)
        collection = self.get(collection_id)
        if collection is None:
            return False

        for index, artifact_id in enumerate(artifact_ids):
            self.session.execute(
                EnterpriseCollectionArtifact.__table__.update()
                .where(
                    EnterpriseCollectionArtifact.collection_id == collection_id,
                    EnterpriseCollectionArtifact.artifact_id == artifact_id,
                )
                .values(order_index=index)
            )

        self.session.flush()
        self._log_operation(
            operation="reorder_artifacts",
            entity_type="EnterpriseCollection",
            entity_id=collection_id,
            metadata={"count": len(artifact_ids)},
        )

    # ------------------------------------------------------------------
    # EG-2.5: Enterprise-owner queries
    # ------------------------------------------------------------------

    def list_by_enterprise(
        self,
        session: Session,
        tenant_id: str,
    ) -> "List[EnterpriseCollection]":
        """Return all collections owned at the enterprise level for *tenant_id*.

        Queries for rows where ``owner_type = 'enterprise'`` AND
        ``owner_id = str(tenant_id)`` within the currently active tenant scope.
        Enterprise-owned collections are those governed at the tenant level
        (e.g. ``is_global_collection=True`` collections provisioned by admins).

        Parameters
        ----------
        session:
            Open SQLAlchemy ``Session`` bound to the enterprise PostgreSQL
            database.
        tenant_id:
            String representation of the tenant UUID.  All returned collections
            have ``owner_id = tenant_id`` and ``owner_type = 'enterprise'``.

        Returns
        -------
        list[EnterpriseCollection]
            All enterprise-owned collections for the tenant (may be empty).
        """
        from skillmeat.cache.auth_types import OwnerType
        from skillmeat.cache.models_enterprise import EnterpriseCollection

        stmt = self._apply_tenant_filter(
            select(EnterpriseCollection).where(
                EnterpriseCollection.owner_type == OwnerType.enterprise.value,
                EnterpriseCollection.owner_id == _ensure_uuid(tenant_id),
            )
        )
        return list(session.execute(stmt).scalars().all())

    def list_by_owner_scope(
        self,
        session: Session,
        ownership_ctx: "ResolvedOwnershipContext",
    ) -> "List[EnterpriseCollection]":
        """Return all collections visible to the caller given their ownership scopes.

        Builds a compound ``OR`` predicate covering every
        :class:`~skillmeat.core.auth.ownership_context.ResolvedOwnerScope`
        in *ownership_ctx.visible_owner_scopes*:

        - ``owner_type = 'user'  AND owner_id = <actor_user_id>``
        - ``owner_type = 'team'  AND owner_id IN (<team_ids>)``  (when non-empty)
        - ``owner_type = 'enterprise'``  (when enterprise scope is present)

        System admins (``is_system_admin=True``) implicitly have an enterprise
        scope in ``visible_owner_scopes``, so they see all resources in the
        tenant.

        Parameters
        ----------
        session:
            Open SQLAlchemy ``Session`` bound to the enterprise PostgreSQL
            database.
        ownership_ctx:
            Fully resolved ownership context for the authenticated actor.

        Returns
        -------
        list[EnterpriseCollection]
            All collections visible to the caller within the current tenant
            (may be empty).
        """
        from sqlalchemy import and_, or_

        from skillmeat.cache.auth_types import OwnerType
        from skillmeat.cache.models_enterprise import EnterpriseCollection

        predicates = []
        team_ids: list[uuid.UUID] = []

        for scope in ownership_ctx.visible_owner_scopes:
            if scope.owner_type == OwnerType.user.value:
                predicates.append(
                    and_(
                        EnterpriseCollection.owner_type == OwnerType.user.value,
                        EnterpriseCollection.owner_id == _ensure_uuid(scope.owner_id),
                    )
                )
            elif scope.owner_type == OwnerType.team.value:
                team_ids.append(_ensure_uuid(scope.owner_id))
            elif scope.owner_type == OwnerType.enterprise.value:
                # Enterprise scope: all collections in the tenant are visible
                predicates.append(
                    EnterpriseCollection.owner_type == OwnerType.enterprise.value
                )

        # Batch all team scopes into a single IN clause to avoid per-team predicates
        if team_ids:
            predicates.append(
                and_(
                    EnterpriseCollection.owner_type == OwnerType.team.value,
                    EnterpriseCollection.owner_id.in_(team_ids),
                )
            )

        if not predicates:
            # No visible scopes — return empty list without hitting the DB
            return []

        stmt = self._apply_tenant_filter(
            select(EnterpriseCollection).where(or_(*predicates))
        )
        return list(session.execute(stmt).scalars().all())


# =============================================================================
# EnterpriseUserCollectionAdapter
# =============================================================================


class EnterpriseUserCollectionAdapter(IDbUserCollectionRepository):
    """Adapts :class:`EnterpriseCollectionRepository` to
    :class:`~skillmeat.core.interfaces.repositories.IDbUserCollectionRepository`.

    In enterprise mode the ``user_collections`` router must query PostgreSQL
    instead of SQLite.  This adapter wraps the existing
    :class:`EnterpriseCollectionRepository` and translates its ORM results to
    :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO` frozen
    dataclasses, satisfying the interface contract without modifying the
    underlying repository or the router.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.  Lifecycle is managed by the FastAPI DI layer via
        ``get_db_session``.
    """

    def __init__(self, session: Session) -> None:
        self._repo = EnterpriseCollectionRepository(session=session)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_dto(collection: "EnterpriseCollection") -> "UserCollectionDTO":  # type: ignore[name-defined]
        """Convert an :class:`EnterpriseCollection` ORM instance to a DTO."""
        from skillmeat.core.interfaces.dtos import UserCollectionDTO

        created_at_iso: Optional[str] = None
        updated_at_iso: Optional[str] = None
        if collection.created_at is not None:
            created_at_iso = collection.created_at.isoformat()
        if collection.updated_at is not None:
            updated_at_iso = collection.updated_at.isoformat()

        # created_by on EnterpriseCollection is a string (user ID or "system")
        created_by = collection.created_by

        # Membership count — available only when the relationship is loaded;
        # fall back to 0 rather than triggering a lazy load.
        try:
            artifact_count = len(collection.memberships)
        except Exception:
            artifact_count = 0

        return UserCollectionDTO(
            id=str(collection.id),
            name=collection.name,
            description=collection.description,
            created_by=created_by,
            collection_type=None,
            context_category=None,
            created_at=created_at_iso,
            updated_at=updated_at_iso,
            artifact_count=artifact_count,
        )

    # ------------------------------------------------------------------
    # IDbUserCollectionRepository implementation
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        created_by: Optional[str] = None,
        collection_type: Optional[str] = None,
        context_category: Optional[str] = None,
        owner_type: Optional[str] = None,
        owner_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        ctx: Optional[object] = None,
    ) -> "list[UserCollectionDTO]":  # type: ignore[override]
        """Return a paginated list of enterprise collections as DTOs.

        The *created_by*, *collection_type*, and *context_category* filters
        map as follows against the enterprise schema:

        * ``created_by`` — filters by ``EnterpriseCollection.created_by``
          (string user-ID column).
        * ``collection_type`` and ``context_category`` — the enterprise schema
          has no direct equivalents; these filters are silently ignored so the
          adapter remains forward-compatible.
        * ``owner_type`` and ``owner_id`` — the enterprise schema has no direct
          equivalents; these filters are silently ignored so the adapter
          remains forward-compatible.
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollection

        collections = self._repo.list(offset=offset, limit=limit)

        if created_by is not None:
            collections = [c for c in collections if c.created_by == created_by]

        return [self._to_dto(c) for c in collections]

    def get_by_id(
        self,
        collection_id: str,
        ctx: Optional[object] = None,
    ) -> "UserCollectionDTO | None":
        """Return a collection by its UUID string primary key.

        Special case: When *collection_id* is ``"default"``, the method
        delegates to :meth:`_get_default_collection` which looks up the
        collection marked ``is_default=True`` for the current tenant.  This
        allows the frontend to request ``GET /api/v1/user-collections/default``
        without needing to know the actual UUID.
        """
        if collection_id == "default":
            return self._get_default_collection()

        try:
            uid = _ensure_uuid(collection_id)
        except (ValueError, AttributeError):
            return None

        collection = self._repo.get(uid)
        if collection is None:
            return None
        return self._to_dto(collection)

    def _get_default_collection(self) -> "UserCollectionDTO | None":
        """Return the collection marked ``is_default=True`` for the current tenant."""
        from skillmeat.cache.models_enterprise import EnterpriseCollection
        from sqlalchemy import select as sa_select

        tenant_id = self._repo._get_tenant_id()
        stmt = sa_select(EnterpriseCollection).where(
            EnterpriseCollection.tenant_id == tenant_id,
            EnterpriseCollection.is_default.is_(True),
        )
        collection = self._repo.session.execute(stmt).scalar_one_or_none()
        if collection is None:
            return None
        return self._to_dto(collection)

    def get_by_name(
        self,
        name: str,
        ctx: Optional[object] = None,
    ) -> "UserCollectionDTO | None":
        """Return a collection by its human-readable name."""
        collection = self._repo.get_by_name(name)
        if collection is None:
            return None
        return self._to_dto(collection)

    def create(
        self,
        *,
        name: str,
        description: Optional[str] = None,
        created_by: Optional[str] = None,
        collection_type: Optional[str] = None,
        context_category: Optional[str] = None,
        ctx: Optional[object] = None,
    ) -> "UserCollectionDTO":
        """Persist a new enterprise collection and return its DTO."""
        collection = self._repo.create(name=name, description=description)
        # Populate created_by when provided and the ORM model supports it.
        if created_by is not None and hasattr(collection, "created_by"):
            collection.created_by = created_by
            self._repo.session.flush()
        return self._to_dto(collection)

    def update(
        self,
        collection_id: str,
        ctx: Optional[object] = None,
        **kwargs: object,
    ) -> "UserCollectionDTO":
        """Apply a partial update to an existing enterprise collection."""
        try:
            uid = _ensure_uuid(collection_id)
        except (ValueError, AttributeError):
            raise KeyError(f"Collection {collection_id!r} not found.")

        collection = self._repo.update(
            uid,
            name=kwargs.get("name"),
            description=kwargs.get("description"),
        )
        return self._to_dto(collection)

    def delete(
        self,
        collection_id: str,
        ctx: Optional[object] = None,
    ) -> bool:
        """Delete an enterprise collection and all its membership records."""
        try:
            uid = _ensure_uuid(collection_id)
        except (ValueError, AttributeError):
            return False

        return self._repo.delete(uid)

    def ensure_default(
        self,
        *,
        created_by: Optional[str] = None,
        ctx: Optional[object] = None,
    ) -> "UserCollectionDTO":
        """Return the default collection, creating it if it does not exist."""
        default_name = "Default Collection"
        existing = self._repo.get_by_name(default_name)
        if existing is not None:
            return self._to_dto(existing)

        collection = self._repo.create(
            name=default_name, description="Default collection"
        )
        if created_by is not None and hasattr(collection, "created_by"):
            collection.created_by = created_by
            self._repo.session.flush()
        return self._to_dto(collection)

    def ensure_sentinel_project(self) -> None:
        """No-op for enterprise mode — enterprise uses different FK relationships."""
        pass

    def get_artifact_count(
        self,
        collection_id: str,
        ctx: Optional[object] = None,
    ) -> int:
        """Return the number of artifacts in the given enterprise collection."""
        from sqlalchemy import func
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        try:
            uid = _ensure_uuid(collection_id)
        except (ValueError, AttributeError):
            return 0

        result = self._repo.session.execute(
            select(func.count())
            .select_from(EnterpriseCollectionArtifact)
            .where(EnterpriseCollectionArtifact.collection_id == uid)
        )
        return result.scalar_one() or 0

    def get_groups(
        self,
        collection_id: str,
        ctx: Optional[object] = None,
    ) -> "list[str]":
        """Enterprise does not have the same group association model; returns empty list."""
        return []

    def list_with_artifact_stats(
        self,
        *,
        created_by: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        ctx: Optional[object] = None,
    ) -> "list[UserCollectionDTO]":
        """Return collections with artifact_count populated.

        Delegates to :meth:`list`; the DTO already carries ``artifact_count``
        from :meth:`_to_dto`.
        """
        return self.list(
            created_by=created_by,
            limit=limit,
            offset=offset,
            ctx=ctx,
        )

    def add_group(
        self,
        collection_id: str,
        group_id: str,
        ctx: Optional[object] = None,
    ) -> bool:
        """Enterprise does not support the same group model; returns False."""
        return False

    def remove_group(
        self,
        collection_id: str,
        group_id: str,
        ctx: Optional[object] = None,
    ) -> bool:
        """Enterprise does not support the same group model; returns False."""
        return False


# ---------------------------------------------------------------------------
# EnterpriseTagRepository  (ENT2-3.1)
# ---------------------------------------------------------------------------


class EnterpriseTagRepository(
    EnterpriseRepositoryBase["EnterpriseTag"],
):
    """Repository for tenant-scoped CRUD on EnterpriseTag.

    Implements :class:`~skillmeat.core.interfaces.repositories.ITagRepository`
    for the enterprise PostgreSQL backend.

    All queries are automatically scoped to the tenant stored in
    ``TenantContext`` via ``_apply_tenant_filter()``.  Slug generation
    normalises the tag name using a simple regex: lowercase, replace
    non-alphanumeric runs with hyphens, strip leading/trailing hyphens.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Notes
    -----
    The interface defines ``id`` as ``str``; enterprise tag PKs are
    ``uuid.UUID``.  All public methods accept and return ``str`` IDs and
    convert internally.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseTag as _ET

        super().__init__(session, _ET)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _slugify(name: str) -> str:
        """Derive a URL-safe slug from *name*.

        Lowercases the string, replaces every run of non-alphanumeric
        characters (including spaces) with a single hyphen, and strips
        leading/trailing hyphens.

        Parameters
        ----------
        name:
            Human-readable tag name, e.g. ``"AI & ML"``.

        Returns
        -------
        str
            Normalised slug, e.g. ``"ai-ml"``.
        """
        import re

        slug = name.lower()
        slug = re.sub(r"[^a-z0-9]+", "-", slug)
        return slug.strip("-")

    def _to_dto(self, tag: "EnterpriseTag", artifact_count: int = 0) -> "TagDTO":
        """Map an ``EnterpriseTag`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.TagDTO`.

        Parameters
        ----------
        tag:
            ORM instance to convert.
        artifact_count:
            Number of artifacts currently carrying this tag.  Defaults to
            ``0`` when the caller does not supply a pre-computed count.

        Returns
        -------
        TagDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import TagDTO

        return TagDTO(
            id=str(tag.id),
            name=tag.name,
            slug=tag.slug,
            color=tag.color,
            artifact_count=artifact_count,
            deployment_set_count=0,
            created_at=tag.created_at.isoformat() if tag.created_at else None,
            updated_at=tag.updated_at.isoformat() if tag.updated_at else None,
        )

    # ------------------------------------------------------------------
    # ITagRepository: get
    # ------------------------------------------------------------------

    def get(
        self,
        id: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[TagDTO]":
        """Return a :class:`~skillmeat.core.interfaces.dtos.TagDTO` by string UUID.

        Parameters
        ----------
        id:
            Tag UUID as a string (e.g. from an API path parameter).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        TagDTO or None
            The matching DTO when found within the current tenant, ``None``
            otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseTag

        try:
            tag_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError):
            return None
        stmt = self._tenant_select().where(EnterpriseTag.id == tag_uuid)
        tag = self.session.execute(stmt).scalar_one_or_none()
        if tag is None:
            return None
        return self._to_dto(tag, artifact_count=len(tag.artifact_tags))

    # ------------------------------------------------------------------
    # ITagRepository: get_by_slug
    # ------------------------------------------------------------------

    def get_by_slug(
        self,
        slug: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[TagDTO]":
        """Return a :class:`~skillmeat.core.interfaces.dtos.TagDTO` by slug.

        Parameters
        ----------
        slug:
            URL-safe normalised tag slug (e.g. ``"ai-ml"``).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        TagDTO or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseTag

        stmt = self._tenant_select().where(EnterpriseTag.slug == slug)
        tag = self.session.execute(stmt).scalar_one_or_none()
        if tag is None:
            return None
        return self._to_dto(tag, artifact_count=len(tag.artifact_tags))

    # ------------------------------------------------------------------
    # ITagRepository: list
    # ------------------------------------------------------------------

    def list(
        self,
        filters: "Optional[dict]" = None,
        ctx: "Optional[object]" = None,
    ) -> "list[TagDTO]":
        """Return all tags for the current tenant.

        Parameters
        ----------
        filters:
            Optional filter map.  Recognised key: ``"name"`` — performs a
            case-insensitive prefix filter.  Unknown keys are ignored.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[TagDTO]
            Tags ordered alphabetically by name.
        """
        from sqlalchemy import func
        from skillmeat.cache.models_enterprise import EnterpriseTag

        stmt = self._tenant_select().order_by(EnterpriseTag.name)
        if filters:
            name_filter = filters.get("name")
            if name_filter:
                stmt = stmt.where(
                    func.lower(EnterpriseTag.name).like(f"{name_filter.lower()}%")
                )
        tags = list(self.session.execute(stmt).scalars())
        return [self._to_dto(t, artifact_count=len(t.artifact_tags)) for t in tags]

    # ------------------------------------------------------------------
    # ITagRepository: create
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        color: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> "TagDTO":
        """Create a new tenant-scoped tag.

        The slug is automatically derived from *name* via :meth:`_slugify`.

        Parameters
        ----------
        name:
            Human-readable tag name.  Must be unique within the tenant.
        color:
            Optional hex or CSS colour string (e.g. ``"#3B82F6"``).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        TagDTO
            The newly created tag.

        Raises
        ------
        ValueError
            If a tag with the same derived slug already exists for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseTag

        tenant_id = self._get_tenant_id()
        slug = self._slugify(name)

        # Guard: uniqueness check on (tenant_id, slug) before insert.
        existing = self.get_by_slug(slug)
        if existing is not None:
            raise ValueError(f"A tag with slug {slug!r} already exists in this tenant.")

        tag = EnterpriseTag(
            tenant_id=tenant_id,
            name=name,
            slug=slug,
            color=color,
        )
        self.session.add(tag)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseTag",
            entity_id=tag.id,
            metadata={"name": name, "slug": slug},
        )
        return self._to_dto(tag)

    # ------------------------------------------------------------------
    # ITagRepository: update
    # ------------------------------------------------------------------

    def update(
        self,
        id: str,
        updates: "dict",
        ctx: "Optional[object]" = None,
    ) -> "TagDTO":
        """Apply a partial update to an existing tag.

        Parameters
        ----------
        id:
            Tag UUID as a string.
        updates:
            Map of field names to new values.  Recognised keys:
            ``"name"``, ``"color"``.  An updated ``"name"`` automatically
            regenerates the slug unless ``"slug"`` is also provided
            explicitly.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        TagDTO
            The updated tag DTO.

        Raises
        ------
        KeyError
            If no tag with *id* exists in the current tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseTag

        try:
            tag_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(id) from exc

        stmt = self._tenant_select().where(EnterpriseTag.id == tag_uuid)
        tag = self.session.execute(stmt).scalar_one_or_none()
        if tag is None:
            raise KeyError(id)

        changed: Dict[str, object] = {}
        if "name" in updates:
            tag.name = updates["name"]
            changed["name"] = updates["name"]
            # Auto-regenerate slug when name changes unless slug is explicit.
            if "slug" not in updates:
                tag.slug = self._slugify(updates["name"])
                changed["slug"] = tag.slug
        if "slug" in updates:
            tag.slug = updates["slug"]
            changed["slug"] = updates["slug"]
        if "color" in updates:
            tag.color = updates["color"]
            changed["color"] = updates["color"]

        tag.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseTag",
            entity_id=tag_uuid,
            metadata=changed or None,
        )
        return self._to_dto(tag, artifact_count=len(tag.artifact_tags))

    # ------------------------------------------------------------------
    # ITagRepository: delete
    # ------------------------------------------------------------------

    def delete(
        self,
        id: str,
        ctx: "Optional[object]" = None,
    ) -> bool:
        """Delete a tag and remove all its artifact associations.

        The ``ON DELETE CASCADE`` on ``enterprise_artifact_tags.tag_id``
        removes association rows automatically at the database level.

        Parameters
        ----------
        id:
            Tag UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        bool
            ``True`` when the tag was found and deleted, ``False`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseTag

        try:
            tag_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError):
            return False

        stmt = self._tenant_select().where(EnterpriseTag.id == tag_uuid)
        tag = self.session.execute(stmt).scalar_one_or_none()
        if tag is None:
            return False

        self.session.delete(tag)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseTag",
            entity_id=tag_uuid,
        )
        return True

    # ------------------------------------------------------------------
    # ITagRepository: assign
    # ------------------------------------------------------------------

    def assign(
        self,
        tag_id: str,
        artifact_id: str,
        ctx: "Optional[object]" = None,
    ) -> bool:
        """Associate a tag with an artifact (idempotent).

        Parameters
        ----------
        tag_id:
            Tag UUID as a string.
        artifact_id:
            Artifact UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        bool
            ``True`` on success (including when the association already existed).

        Raises
        ------
        KeyError
            If *tag_id* or *artifact_id* does not exist within the current
            tenant.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseArtifactTag,
            EnterpriseTag,
        )

        try:
            tag_uuid = _ensure_uuid(tag_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(tag_id) from exc

        tenant_id = self._get_tenant_id()

        # Validate tag exists within the tenant.
        tag_stmt = self._tenant_select().where(EnterpriseTag.id == tag_uuid)
        tag = self.session.execute(tag_stmt).scalar_one_or_none()
        if tag is None:
            raise KeyError(tag_id)

        # Resolve artifact_id: accept both "type:name" format and raw UUID strings.
        if ":" in artifact_id:
            art_type, art_name = artifact_id.split(":", 1)
            art_stmt = self._apply_tenant_filter(
                select(EnterpriseArtifact).where(
                    EnterpriseArtifact.artifact_type == art_type,
                    EnterpriseArtifact.name == art_name,
                )
            )
        else:
            try:
                _art_uuid = _ensure_uuid(artifact_id)
            except (ValueError, AttributeError) as exc:
                raise KeyError(artifact_id) from exc
            art_stmt = self._apply_tenant_filter(
                select(EnterpriseArtifact).where(EnterpriseArtifact.id == _art_uuid)
            )
        artifact = self.session.execute(art_stmt).scalar_one_or_none()
        if artifact is None:
            raise KeyError(artifact_id)
        artifact_uuid = artifact.id

        # Idempotent: check if the association already exists.
        existing_stmt = select(EnterpriseArtifactTag).where(
            EnterpriseArtifactTag.tenant_id == tenant_id,
            EnterpriseArtifactTag.tag_id == tag_uuid,
            EnterpriseArtifactTag.artifact_uuid == artifact_uuid,
        )
        existing = self.session.execute(existing_stmt).scalar_one_or_none()
        if existing is not None:
            return True

        assoc = EnterpriseArtifactTag(
            tenant_id=tenant_id,
            tag_id=tag_uuid,
            artifact_uuid=artifact_uuid,
        )
        self.session.add(assoc)
        self.session.flush()
        self._log_operation(
            operation="assign",
            entity_type="EnterpriseArtifactTag",
            entity_id=assoc.id,
            metadata={"tag_id": str(tag_uuid), "artifact_uuid": str(artifact_uuid)},
        )
        return True

    # ------------------------------------------------------------------
    # ITagRepository: unassign
    # ------------------------------------------------------------------

    def unassign(
        self,
        tag_id: str,
        artifact_id: str,
        ctx: "Optional[object]" = None,
    ) -> bool:
        """Remove the association between a tag and an artifact.

        Parameters
        ----------
        tag_id:
            Tag UUID as a string.
        artifact_id:
            Artifact UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        bool
            ``True`` when the association existed and was removed, ``False``
            if there was no such association.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseArtifactTag,
        )

        try:
            tag_uuid = _ensure_uuid(tag_id)
        except (ValueError, AttributeError):
            return False

        # Resolve artifact_id: accept both "type:name" format and raw UUID strings.
        if ":" in artifact_id:
            art_type, art_name = artifact_id.split(":", 1)
            art_stmt = self._apply_tenant_filter(
                select(EnterpriseArtifact).where(
                    EnterpriseArtifact.artifact_type == art_type,
                    EnterpriseArtifact.name == art_name,
                )
            )
            artifact = self.session.execute(art_stmt).scalar_one_or_none()
            if artifact is None:
                return False
            artifact_uuid = artifact.id
        else:
            try:
                artifact_uuid = _ensure_uuid(artifact_id)
            except (ValueError, AttributeError):
                return False

        tenant_id = self._get_tenant_id()
        result = self.session.execute(
            delete(EnterpriseArtifactTag).where(
                EnterpriseArtifactTag.tenant_id == tenant_id,
                EnterpriseArtifactTag.tag_id == tag_uuid,
                EnterpriseArtifactTag.artifact_uuid == artifact_uuid,
            )
        )
        removed = result.rowcount > 0
        if removed:
            self.session.flush()
            self._log_operation(
                operation="unassign",
                entity_type="EnterpriseArtifactTag",
                entity_id=None,
                metadata={
                    "tag_id": str(tag_uuid),
                    "artifact_uuid": str(artifact_uuid),
                },
            )
        return removed


# ---------------------------------------------------------------------------
# EnterpriseGroupRepository  (ENT2-3.2)
# ---------------------------------------------------------------------------


class EnterpriseGroupRepository(
    EnterpriseRepositoryBase["EnterpriseGroup"],
):
    """Repository for tenant-scoped CRUD on EnterpriseGroup.

    Implements :class:`~skillmeat.core.interfaces.repositories.IGroupRepository`
    for the enterprise PostgreSQL backend.

    Groups are named, position-ordered buckets within a collection.  All
    queries are automatically scoped to the tenant stored in ``TenantContext``
    via ``_apply_tenant_filter()``.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Notes
    -----
    The IGroupRepository interface uses ``int`` group IDs for historical
    reasons (local SQLite model uses autoincrement integers).  The enterprise
    model uses ``uuid.UUID`` PKs.  All public methods accept ``int | str``
    IDs, attempt UUID parse first, and raise ``KeyError`` for invalid values.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseGroup as _EG

        super().__init__(session, _EG)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _to_dto(
        self,
        group: "EnterpriseGroup",
        artifact_count: int = 0,
    ) -> "GroupDTO":
        """Map an ``EnterpriseGroup`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.GroupDTO`.

        Parameters
        ----------
        group:
            ORM instance to convert.
        artifact_count:
            Number of artifacts currently in this group.

        Returns
        -------
        GroupDTO
        """
        from skillmeat.core.interfaces.dtos import GroupDTO

        return GroupDTO(
            id=str(group.id),
            name=group.name or "",
            collection_id=str(group.collection_id) if group.collection_id else "",
            description=group.description,
            position=group.position or 0,
            artifact_count=artifact_count,
            tags=[],
            color="slate",
            icon="layers",
            created_at=group.created_at.isoformat() if group.created_at else None,
            updated_at=group.updated_at.isoformat() if group.updated_at else None,
        )

    def _ga_to_dto(
        self,
        ga: "EnterpriseGroupArtifact",
    ) -> "GroupArtifactDTO":
        """Map an ``EnterpriseGroupArtifact`` join row to a :class:`~skillmeat.core.interfaces.dtos.GroupArtifactDTO`.

        Parameters
        ----------
        ga:
            ORM join-table instance to convert.

        Returns
        -------
        GroupArtifactDTO
        """
        from skillmeat.core.interfaces.dtos import GroupArtifactDTO

        return GroupArtifactDTO(
            group_id=str(ga.group_id),
            artifact_uuid=str(ga.artifact_uuid),
            position=ga.position or 0,
            added_at=None,
        )

    def _resolve_group_uuid(self, group_id: "int | str") -> "Optional[uuid.UUID]":
        """Coerce *group_id* to a ``uuid.UUID``, returning ``None`` on failure.

        Accepts integer IDs (silently converted via ``str()`` before UUID
        parse) or string UUIDs.

        Parameters
        ----------
        group_id:
            Raw group identifier from an API path or interface call.

        Returns
        -------
        uuid.UUID or None
        """
        try:
            return _ensure_uuid(group_id)
        except (ValueError, AttributeError):
            return None

    def _fetch_group(
        self,
        group_uuid: uuid.UUID,
    ) -> "Optional[EnterpriseGroup]":
        """Fetch a tenant-filtered group by UUID.

        Parameters
        ----------
        group_uuid:
            UUID of the group to retrieve.

        Returns
        -------
        EnterpriseGroup or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseGroup

        stmt = self._tenant_select().where(EnterpriseGroup.id == group_uuid)
        return self.session.execute(stmt).scalar_one_or_none()

    # ------------------------------------------------------------------
    # IGroupRepository: get_with_artifacts
    # ------------------------------------------------------------------

    def get_with_artifacts(
        self,
        group_id: int,
        ctx: "Optional[object]" = None,
    ) -> "Optional[GroupDTO]":
        """Return a group by ID, including its artifact membership count.

        Parameters
        ----------
        group_id:
            Group primary key (integer or UUID string accepted).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        GroupDTO or None
        """
        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            return None
        group = self._fetch_group(gid)
        if group is None:
            return None
        artifact_count = len(group.group_artifacts)
        return self._to_dto(group, artifact_count=artifact_count)

    # ------------------------------------------------------------------
    # IGroupRepository: list
    # ------------------------------------------------------------------

    def list(
        self,
        collection_id: str,
        filters: "Optional[dict]" = None,
        ctx: "Optional[object]" = None,
    ) -> "list[GroupDTO]":
        """Return all groups belonging to a collection, ordered by position.

        Parameters
        ----------
        collection_id:
            Collection UUID as a string.
        filters:
            Optional additional filter map.  Recognised key: ``"name"`` —
            case-insensitive exact match.  Unknown keys are ignored.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[GroupDTO]
        """
        from skillmeat.cache.models_enterprise import EnterpriseGroup

        try:
            col_uuid = _ensure_uuid(collection_id)
        except (ValueError, AttributeError):
            return []

        stmt = (
            self._tenant_select()
            .where(EnterpriseGroup.collection_id == col_uuid)
            .order_by(EnterpriseGroup.position)
        )
        if filters:
            name_filter = filters.get("name")
            if name_filter:
                stmt = stmt.where(EnterpriseGroup.name == name_filter)

        groups = list(self.session.execute(stmt).scalars())
        return [self._to_dto(g, artifact_count=len(g.group_artifacts)) for g in groups]

    # ------------------------------------------------------------------
    # IGroupRepository: create
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        collection_id: str,
        description: "Optional[str]" = None,
        position: "Optional[int]" = None,
        ctx: "Optional[object]" = None,
        owner_target: "Optional[object]" = None,
    ) -> "GroupDTO":
        """Create a new group in the given collection.

        If *position* is ``None``, the group is appended after all existing
        groups in the collection (``max(position) + 1``).

        Parameters
        ----------
        name:
            Human-readable group name.
        collection_id:
            Owning collection UUID as a string.
        description:
            Optional free-text description.
        position:
            Explicit display position.  ``None`` = append at the end.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).
        owner_target:
            Optional ownership target (reserved for future use; unused in
            the enterprise backend today).

        Returns
        -------
        GroupDTO
            The newly created group.

        Raises
        ------
        ValueError
            If a group with the same *name* already exists in the collection.
        """
        from sqlalchemy import func
        from skillmeat.cache.models_enterprise import EnterpriseGroup

        try:
            col_uuid = _ensure_uuid(collection_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError(
                f"Invalid collection_id {collection_id!r}: not a valid UUID."
            ) from exc

        tenant_id = self._get_tenant_id()

        # Guard: name uniqueness within (tenant, collection).
        dup_stmt = self._tenant_select().where(
            EnterpriseGroup.collection_id == col_uuid,
            EnterpriseGroup.name == name,
        )
        if self.session.execute(dup_stmt).scalar_one_or_none() is not None:
            raise ValueError(
                f"A group named {name!r} already exists in collection "
                f"{collection_id!r}."
            )

        if position is None:
            max_pos_result = self.session.execute(
                select(func.max(EnterpriseGroup.position)).where(
                    EnterpriseGroup.tenant_id == tenant_id,
                    EnterpriseGroup.collection_id == col_uuid,
                )
            ).scalar()
            position = 0 if max_pos_result is None else max_pos_result + 1

        group = EnterpriseGroup(
            tenant_id=tenant_id,
            name=name,
            collection_id=col_uuid,
            description=description,
            position=position,
        )
        self.session.add(group)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseGroup",
            entity_id=group.id,
            metadata={"name": name, "collection_id": str(col_uuid)},
        )
        return self._to_dto(group)

    # ------------------------------------------------------------------
    # IGroupRepository: update
    # ------------------------------------------------------------------

    def update(
        self,
        group_id: int,
        updates: "dict",
        ctx: "Optional[object]" = None,
    ) -> "GroupDTO":
        """Apply a partial update to an existing group's metadata.

        Parameters
        ----------
        group_id:
            Group primary key.
        updates:
            Map of field names to new values.  Recognised keys:
            ``"name"``, ``"description"``, ``"position"``.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        GroupDTO
            The updated group DTO.

        Raises
        ------
        KeyError
            If no group with *group_id* exists in the current tenant.
        """
        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            raise KeyError(group_id)
        group = self._fetch_group(gid)
        if group is None:
            raise KeyError(group_id)

        changed: Dict[str, object] = {}
        if "name" in updates:
            group.name = updates["name"]
            changed["name"] = updates["name"]
        if "description" in updates:
            group.description = updates["description"]
            changed["description"] = updates["description"]
        if "position" in updates:
            group.position = updates["position"]
            changed["position"] = updates["position"]

        group.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseGroup",
            entity_id=gid,
            metadata=changed or None,
        )
        return self._to_dto(group, artifact_count=len(group.group_artifacts))

    # ------------------------------------------------------------------
    # IGroupRepository: delete
    # ------------------------------------------------------------------

    def delete(
        self,
        group_id: int,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Delete a group and all its artifact membership records.

        The ``ON DELETE CASCADE`` on ``enterprise_group_artifacts.group_id``
        removes membership rows automatically at the database level.

        Parameters
        ----------
        group_id:
            Group primary key.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If no group with *group_id* exists in the current tenant.
        """
        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            raise KeyError(group_id)
        group = self._fetch_group(gid)
        if group is None:
            raise KeyError(group_id)

        self.session.delete(group)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseGroup",
            entity_id=gid,
        )

    # ------------------------------------------------------------------
    # IGroupRepository: copy_to_collection
    # ------------------------------------------------------------------

    def copy_to_collection(
        self,
        group_id: int,
        target_collection_id: str,
        ctx: "Optional[object]" = None,
    ) -> "GroupDTO":
        """Duplicate a group and its artifact memberships into another collection.

        The new group gets the same name, description, and position as the
        source.  Artifact UUIDs are preserved.

        Parameters
        ----------
        group_id:
            Integer primary key of the source group.
        target_collection_id:
            UUID string of the destination collection.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        GroupDTO
            The newly created group DTO in the target collection.

        Raises
        ------
        KeyError
            If *group_id* does not exist in the current tenant.
        ValueError
            If *target_collection_id* is not a valid UUID.
        """
        from sqlalchemy import func
        from skillmeat.cache.models_enterprise import (
            EnterpriseGroup,
            EnterpriseGroupArtifact,
        )

        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            raise KeyError(group_id)
        source = self._fetch_group(gid)
        if source is None:
            raise KeyError(group_id)

        try:
            target_col_uuid = _ensure_uuid(target_collection_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError(
                f"Invalid target_collection_id {target_collection_id!r}."
            ) from exc

        tenant_id = self._get_tenant_id()

        # Compute append position in the target collection.
        max_pos_result = self.session.execute(
            select(func.max(EnterpriseGroup.position)).where(
                EnterpriseGroup.tenant_id == tenant_id,
                EnterpriseGroup.collection_id == target_col_uuid,
            )
        ).scalar()
        new_position = 0 if max_pos_result is None else max_pos_result + 1

        new_group = EnterpriseGroup(
            tenant_id=tenant_id,
            name=source.name,
            collection_id=target_col_uuid,
            description=source.description,
            position=new_position,
        )
        self.session.add(new_group)
        self.session.flush()

        # Copy artifact memberships preserving positions.
        source_memberships = list(
            self.session.execute(
                select(EnterpriseGroupArtifact).where(
                    EnterpriseGroupArtifact.group_id == gid,
                    EnterpriseGroupArtifact.tenant_id == tenant_id,
                )
            ).scalars()
        )
        for mem in source_memberships:
            new_mem = EnterpriseGroupArtifact(
                tenant_id=tenant_id,
                group_id=new_group.id,
                artifact_uuid=mem.artifact_uuid,
                position=mem.position,
            )
            self.session.add(new_mem)

        self.session.flush()
        self._log_operation(
            operation="copy_to_collection",
            entity_type="EnterpriseGroup",
            entity_id=new_group.id,
            metadata={
                "source_group_id": str(gid),
                "target_collection_id": str(target_col_uuid),
            },
        )
        return self._to_dto(
            new_group,
            artifact_count=len(source_memberships),
        )

    # ------------------------------------------------------------------
    # IGroupRepository: reorder_groups
    # ------------------------------------------------------------------

    def reorder_groups(
        self,
        collection_id: str,
        ordered_ids: "list[int]",
        ctx: "Optional[object]" = None,
    ) -> None:
        """Bulk-update the display positions of all groups in a collection.

        Parameters
        ----------
        collection_id:
            Collection UUID as a string.
        ordered_ids:
            Complete list of group primary keys in the desired display order.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If *collection_id* does not map to a valid UUID or any group in
            *ordered_ids* is not found in the current tenant.
        ValueError
            If *ordered_ids* does not include all groups in the collection.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGroup

        try:
            col_uuid = _ensure_uuid(collection_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(collection_id) from exc

        # Fetch all groups in the collection for this tenant.
        stmt = self._tenant_select().where(EnterpriseGroup.collection_id == col_uuid)
        groups = {g.id: g for g in self.session.execute(stmt).scalars()}

        # Validate completeness.
        ordered_uuids: list[uuid.UUID] = []
        for raw_id in ordered_ids:
            uid = self._resolve_group_uuid(raw_id)
            if uid is None or uid not in groups:
                raise KeyError(raw_id)
            ordered_uuids.append(uid)

        if len(ordered_uuids) != len(groups):
            raise ValueError(
                f"ordered_ids must include all {len(groups)} groups in the "
                f"collection; got {len(ordered_uuids)}."
            )

        for position, gid in enumerate(ordered_uuids):
            groups[gid].position = position
            groups[gid].updated_at = datetime.utcnow()

        self.session.flush()

    # ------------------------------------------------------------------
    # IGroupRepository: add_artifacts
    # ------------------------------------------------------------------

    def add_artifacts(
        self,
        group_id: int,
        artifact_uuids: "list[str]",
        ctx: "Optional[object]" = None,
    ) -> None:
        """Add one or more artifacts to a group (idempotent).

        Artifacts already in the group are silently skipped.  Newly added
        artifacts are appended after existing members.

        Parameters
        ----------
        group_id:
            Group primary key.
        artifact_uuids:
            List of artifact UUID strings to add.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If *group_id* does not exist in the current tenant.
        """
        from sqlalchemy import func
        from skillmeat.cache.models_enterprise import EnterpriseGroupArtifact

        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            raise KeyError(group_id)
        group = self._fetch_group(gid)
        if group is None:
            raise KeyError(group_id)

        tenant_id = self._get_tenant_id()

        # Fetch current max position.
        max_pos_result = self.session.execute(
            select(func.max(EnterpriseGroupArtifact.position)).where(
                EnterpriseGroupArtifact.group_id == gid,
                EnterpriseGroupArtifact.tenant_id == tenant_id,
            )
        ).scalar()
        next_position = 0 if max_pos_result is None else max_pos_result + 1

        # Collect existing artifact UUIDs to deduplicate.
        existing_stmt = select(EnterpriseGroupArtifact.artifact_uuid).where(
            EnterpriseGroupArtifact.group_id == gid,
            EnterpriseGroupArtifact.tenant_id == tenant_id,
        )
        existing_uuids: set[uuid.UUID] = {
            row for row in self.session.execute(existing_stmt).scalars()
        }

        for raw_uuid in artifact_uuids:
            try:
                art_uuid = _ensure_uuid(raw_uuid)
            except (ValueError, AttributeError):
                continue
            if art_uuid in existing_uuids:
                continue
            mem = EnterpriseGroupArtifact(
                tenant_id=tenant_id,
                group_id=gid,
                artifact_uuid=art_uuid,
                position=next_position,
            )
            self.session.add(mem)
            existing_uuids.add(art_uuid)
            next_position += 1

        self.session.flush()

    # ------------------------------------------------------------------
    # IGroupRepository: remove_artifact
    # ------------------------------------------------------------------

    def remove_artifact(
        self,
        group_id: int,
        artifact_uuid: str,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Remove a single artifact from a group.

        Parameters
        ----------
        group_id:
            Group primary key.
        artifact_uuid:
            Artifact UUID string to remove.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If *group_id* does not exist or *artifact_uuid* is not a member.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGroupArtifact

        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            raise KeyError(group_id)
        group = self._fetch_group(gid)
        if group is None:
            raise KeyError(group_id)

        try:
            art_uuid = _ensure_uuid(artifact_uuid)
        except (ValueError, AttributeError) as exc:
            raise KeyError(artifact_uuid) from exc

        tenant_id = self._get_tenant_id()
        result = self.session.execute(
            delete(EnterpriseGroupArtifact).where(
                EnterpriseGroupArtifact.group_id == gid,
                EnterpriseGroupArtifact.artifact_uuid == art_uuid,
                EnterpriseGroupArtifact.tenant_id == tenant_id,
            )
        )
        if result.rowcount == 0:
            raise KeyError(artifact_uuid)
        self.session.flush()

    # ------------------------------------------------------------------
    # IGroupRepository: update_artifact_position
    # ------------------------------------------------------------------

    def update_artifact_position(
        self,
        group_id: int,
        artifact_uuid: str,
        position: int,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Update the display position of a single artifact within a group.

        Parameters
        ----------
        group_id:
            Group primary key.
        artifact_uuid:
            Artifact UUID string whose position to update.
        position:
            New zero-based display position.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If *group_id* does not exist or *artifact_uuid* is not a member.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGroupArtifact

        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            raise KeyError(group_id)
        group = self._fetch_group(gid)
        if group is None:
            raise KeyError(group_id)

        try:
            art_uuid = _ensure_uuid(artifact_uuid)
        except (ValueError, AttributeError) as exc:
            raise KeyError(artifact_uuid) from exc

        tenant_id = self._get_tenant_id()
        stmt = select(EnterpriseGroupArtifact).where(
            EnterpriseGroupArtifact.group_id == gid,
            EnterpriseGroupArtifact.artifact_uuid == art_uuid,
            EnterpriseGroupArtifact.tenant_id == tenant_id,
        )
        mem = self.session.execute(stmt).scalar_one_or_none()
        if mem is None:
            raise KeyError(artifact_uuid)

        mem.position = position
        self.session.flush()

    # ------------------------------------------------------------------
    # IGroupRepository: reorder_artifacts
    # ------------------------------------------------------------------

    def reorder_artifacts(
        self,
        group_id: int,
        ordered_uuids: "list[str]",
        ctx: "Optional[object]" = None,
    ) -> None:
        """Bulk-update the display positions of all artifacts in a group.

        Parameters
        ----------
        group_id:
            Group primary key.
        ordered_uuids:
            Complete list of artifact UUID strings in the desired display
            order.  Must include all current members.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If *group_id* does not exist in the current tenant.
        ValueError
            If *ordered_uuids* does not cover all current members.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGroupArtifact

        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            raise KeyError(group_id)
        group = self._fetch_group(gid)
        if group is None:
            raise KeyError(group_id)

        tenant_id = self._get_tenant_id()
        memberships_stmt = select(EnterpriseGroupArtifact).where(
            EnterpriseGroupArtifact.group_id == gid,
            EnterpriseGroupArtifact.tenant_id == tenant_id,
        )
        memberships = {
            m.artifact_uuid: m for m in self.session.execute(memberships_stmt).scalars()
        }

        parsed_uuids: list[uuid.UUID] = []
        for raw in ordered_uuids:
            try:
                parsed_uuids.append(_ensure_uuid(raw))
            except (ValueError, AttributeError):
                continue

        if len(parsed_uuids) != len(memberships):
            raise ValueError(
                f"ordered_uuids must include all {len(memberships)} current "
                f"members; got {len(parsed_uuids)}."
            )

        for position, art_uuid in enumerate(parsed_uuids):
            if art_uuid not in memberships:
                raise ValueError(
                    f"Artifact {art_uuid!s} is not a member of group {group_id!r}."
                )
            memberships[art_uuid].position = position

        self.session.flush()

    # ------------------------------------------------------------------
    # IGroupRepository: list_group_artifacts
    # ------------------------------------------------------------------

    def list_group_artifacts(
        self,
        group_id: str,
        ctx: "Optional[object]" = None,
    ) -> "list[GroupArtifactDTO]":
        """Return the ordered artifact membership records for a group.

        Parameters
        ----------
        group_id:
            Group primary key (string or integer).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[GroupArtifactDTO]
            Membership records ordered by ``position`` ascending.  Returns an
            empty list when the group does not exist or has no members.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGroupArtifact

        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            return []

        tenant_id = self._get_tenant_id()
        stmt = (
            select(EnterpriseGroupArtifact)
            .where(
                EnterpriseGroupArtifact.group_id == gid,
                EnterpriseGroupArtifact.tenant_id == tenant_id,
            )
            .order_by(EnterpriseGroupArtifact.position)
        )
        members = list(self.session.execute(stmt).scalars())
        return [self._ga_to_dto(m) for m in members]

    # ------------------------------------------------------------------
    # IGroupRepository: add_artifacts_at_position
    # ------------------------------------------------------------------

    def add_artifacts_at_position(
        self,
        group_id: str,
        artifact_uuids: "list[str]",
        position: int,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Insert artifacts at a specific position within a group.

        Existing artifacts at or after *position* are shifted down by the
        count of new insertions.  Artifacts already in the group are silently
        skipped (deduplicated).

        Parameters
        ----------
        group_id:
            Group primary key string.
        artifact_uuids:
            Ordered list of artifact UUID strings to insert.
        position:
            Zero-based target position for the first inserted artifact.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If *group_id* does not exist in the current tenant.
        RuntimeError
            On unexpected database errors.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGroupArtifact

        gid = self._resolve_group_uuid(group_id)
        if gid is None:
            raise KeyError(group_id)
        group = self._fetch_group(gid)
        if group is None:
            raise KeyError(group_id)

        tenant_id = self._get_tenant_id()

        # Deduplicate: skip UUIDs already in the group.
        existing_stmt = select(EnterpriseGroupArtifact.artifact_uuid).where(
            EnterpriseGroupArtifact.group_id == gid,
            EnterpriseGroupArtifact.tenant_id == tenant_id,
        )
        existing_uuids: set[uuid.UUID] = {
            row for row in self.session.execute(existing_stmt).scalars()
        }

        new_uuids: list[uuid.UUID] = []
        for raw in artifact_uuids:
            try:
                art_uuid = _ensure_uuid(raw)
            except (ValueError, AttributeError):
                continue
            if art_uuid not in existing_uuids:
                new_uuids.append(art_uuid)

        if not new_uuids:
            return

        # Shift existing members at or after *position* down by len(new_uuids).
        shift = len(new_uuids)
        shift_stmt = select(EnterpriseGroupArtifact).where(
            EnterpriseGroupArtifact.group_id == gid,
            EnterpriseGroupArtifact.tenant_id == tenant_id,
            EnterpriseGroupArtifact.position >= position,
        )
        for mem in self.session.execute(shift_stmt).scalars():
            if mem.position is not None:
                mem.position = mem.position + shift

        # Insert new membership rows starting at *position*.
        for offset, art_uuid in enumerate(new_uuids):
            new_mem = EnterpriseGroupArtifact(
                tenant_id=tenant_id,
                group_id=gid,
                artifact_uuid=art_uuid,
                position=position + offset,
            )
            self.session.add(new_mem)

        self.session.flush()


# =============================================================================
# EnterpriseSettingsRepository  (ENT2-3.3)
# =============================================================================


class EnterpriseSettingsRepository(
    EnterpriseRepositoryBase["EnterpriseSettings"],
):
    """Repository for tenant-scoped reads and writes on EnterpriseSettings.

    Implements :class:`~skillmeat.core.interfaces.repositories.ISettingsRepository`
    for the enterprise PostgreSQL backend.

    The ``EnterpriseSettings`` table has a ``UNIQUE (tenant_id)`` constraint —
    exactly one settings row per tenant.  :meth:`update` uses an ORM
    check-then-insert/update pattern (no raw ``INSERT ON CONFLICT``) so it
    works portably across SQLAlchemy dialects in unit tests.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Notes
    -----
    The interface defines ``github_token``, ``collection_path``,
    ``default_scope``, ``edition``, and ``indexing_mode`` as first-class
    fields; additional keys in the ``updates`` dict are stored in the JSONB
    ``extra`` column.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseSettings as _ES

        super().__init__(session, _ES)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    _KNOWN_FIELDS = frozenset(
        {"github_token", "collection_path", "default_scope", "edition", "indexing_mode"}
    )

    def _to_dto(self, row: "EnterpriseSettings") -> "SettingsDTO":
        """Map an ``EnterpriseSettings`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.SettingsDTO`.

        Parameters
        ----------
        row:
            ORM instance to convert.

        Returns
        -------
        SettingsDTO
        """
        from skillmeat.core.interfaces.dtos import SettingsDTO

        return SettingsDTO(
            github_token=row.github_token,
            collection_path=row.collection_path,
            default_scope=row.default_scope or "user",
            edition=row.edition or "enterprise",
            indexing_mode=row.indexing_mode or "opt_in",
            extra=dict(row.extra) if row.extra else {},
        )

    def _fetch_row(self) -> "Optional[EnterpriseSettings]":
        """Fetch the single settings row for the current tenant.

        Returns
        -------
        EnterpriseSettings or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseSettings

        stmt = self._tenant_select()
        return self.session.execute(stmt).scalar_one_or_none()

    # ------------------------------------------------------------------
    # ISettingsRepository: get
    # ------------------------------------------------------------------

    def get(
        self,
        ctx: "Optional[object]" = None,
    ) -> "SettingsDTO":
        """Return the current application settings snapshot for this tenant.

        If no settings row exists yet, a default :class:`~skillmeat.core.interfaces.dtos.SettingsDTO`
        is returned without writing to the database.

        Parameters
        ----------
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        SettingsDTO
        """
        from skillmeat.core.interfaces.dtos import SettingsDTO

        row = self._fetch_row()
        if row is None:
            return SettingsDTO(edition="enterprise")
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # ISettingsRepository: update
    # ------------------------------------------------------------------

    def update(
        self,
        updates: "dict",
        ctx: "Optional[object]" = None,
    ) -> "SettingsDTO":
        """Apply a partial update to the application settings for this tenant.

        Only provided keys are changed.  If no settings row exists yet, a new
        one is created (upsert semantics via ORM check-then-insert/update).
        Unknown keys are stored in the ``extra`` JSONB column.

        Parameters
        ----------
        updates:
            Map of setting keys to new values.  Recognised first-class keys:
            ``github_token``, ``collection_path``, ``default_scope``,
            ``edition``, ``indexing_mode``.  All other keys go into ``extra``.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        SettingsDTO
            The updated settings snapshot.
        """
        from skillmeat.cache.models_enterprise import EnterpriseSettings

        tenant_id = self._get_tenant_id()
        row = self._fetch_row()

        if row is None:
            # No row yet — create one with defaults then apply updates.
            row = EnterpriseSettings(
                tenant_id=tenant_id,
                extra={},
            )
            self.session.add(row)

        # Apply first-class field updates.
        for field_name in self._KNOWN_FIELDS:
            if field_name in updates:
                setattr(row, field_name, updates[field_name])

        # Remaining keys go into the extra JSONB bag.
        extra_updates = {
            k: v for k, v in updates.items() if k not in self._KNOWN_FIELDS
        }
        if extra_updates:
            merged_extra = dict(row.extra or {})
            merged_extra.update(extra_updates)
            row.extra = merged_extra

        row.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseSettings",
            entity_id=row.id,
            metadata={k: str(v)[:80] for k, v in updates.items()},
        )
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # ISettingsRepository: validate_github_token
    # ------------------------------------------------------------------

    def validate_github_token(
        self,
        token: str,
        ctx: "Optional[object]" = None,
    ) -> bool:
        """Validate a GitHub Personal Access Token against the API.

        Delegates to the centralised :func:`~skillmeat.core.github_client.get_github_client`
        singleton.  Returns ``False`` on any error rather than raising.

        Parameters
        ----------
        token:
            Raw GitHub PAT string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        bool
            ``True`` if the token authenticates successfully, ``False``
            otherwise.
        """
        try:
            from skillmeat.core.github_client import GitHubClient

            client = GitHubClient(token=token)
            rate_limit = client.get_rate_limit()
            return rate_limit is not None
        except Exception:
            return False

    # ------------------------------------------------------------------
    # ISettingsRepository: list_entity_type_configs
    # ------------------------------------------------------------------

    def list_entity_type_configs(
        self,
        ctx: "Optional[object]" = None,
    ) -> "list[EntityTypeConfigDTO]":
        """Return all registered entity type configurations for this tenant.

        Parameters
        ----------
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[EntityTypeConfigDTO]
            Both system-defined (``is_system=True``) and user-created entries,
            ordered by ``entity_type``.
        """
        from skillmeat.cache.models_enterprise import EnterpriseEntityTypeConfig
        from skillmeat.core.interfaces.dtos import EntityTypeConfigDTO

        stmt = self._apply_tenant_filter(select(EnterpriseEntityTypeConfig)).order_by(
            EnterpriseEntityTypeConfig.entity_type
        )
        rows = list(self.session.execute(stmt).scalars())
        return [
            EntityTypeConfigDTO(
                id=str(row.id),
                entity_type=row.entity_type,
                display_name=row.display_name or row.entity_type,
                description=row.description,
                icon=row.icon,
                color=row.color,
                is_system=bool(row.is_system),
            )
            for row in rows
        ]

    # ------------------------------------------------------------------
    # ISettingsRepository: create_entity_type_config
    # ------------------------------------------------------------------

    def create_entity_type_config(
        self,
        entity_type: str,
        display_name: str,
        description: "Optional[str]" = None,
        icon: "Optional[str]" = None,
        color: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> "EntityTypeConfigDTO":
        """Create a new user-defined entity type configuration.

        Parameters
        ----------
        entity_type:
            Machine-readable entity type key, e.g. ``"workflow"``.  Must be
            unique within the tenant.
        display_name:
            Human-readable display name.
        description:
            Optional description text.
        icon:
            Optional icon identifier or URL.
        color:
            Optional hex color code, e.g. ``"#FF5733"``.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        EntityTypeConfigDTO
            The newly created config.

        Raises
        ------
        ValueError
            If an entity type config with the same *entity_type* already exists
            in this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseEntityTypeConfig
        from skillmeat.core.interfaces.dtos import EntityTypeConfigDTO

        tenant_id = self._get_tenant_id()

        # Guard: uniqueness check on (tenant_id, entity_type).
        dup_stmt = self._apply_tenant_filter(
            select(EnterpriseEntityTypeConfig).where(
                EnterpriseEntityTypeConfig.entity_type == entity_type
            )
        )
        if self.session.execute(dup_stmt).scalar_one_or_none() is not None:
            raise ValueError(
                f"An entity type config for {entity_type!r} already exists in this tenant."
            )

        row = EnterpriseEntityTypeConfig(
            tenant_id=tenant_id,
            entity_type=entity_type,
            display_name=display_name,
            description=description,
            icon=icon,
            color=color,
            is_system=False,
        )
        self.session.add(row)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseEntityTypeConfig",
            entity_id=row.id,
            metadata={"entity_type": entity_type},
        )
        return EntityTypeConfigDTO(
            id=str(row.id),
            entity_type=row.entity_type,
            display_name=row.display_name or row.entity_type,
            description=row.description,
            icon=row.icon,
            color=row.color,
            is_system=False,
        )

    # ------------------------------------------------------------------
    # ISettingsRepository: update_entity_type_config
    # ------------------------------------------------------------------

    def update_entity_type_config(
        self,
        config_id: str,
        updates: "dict",
        ctx: "Optional[object]" = None,
    ) -> "EntityTypeConfigDTO":
        """Apply a partial update to an existing entity type configuration.

        Parameters
        ----------
        config_id:
            UUID string of the config record to update.
        updates:
            Map of field names to new values.  Recognised keys:
            ``display_name``, ``description``, ``icon``, ``color``.
            ``entity_type`` and ``is_system`` are immutable.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        EntityTypeConfigDTO
            The updated config.

        Raises
        ------
        KeyError
            If no config with *config_id* exists in this tenant.
        ValueError
            If the update attempts to mutate ``entity_type`` or ``is_system``.
        """
        from skillmeat.cache.models_enterprise import EnterpriseEntityTypeConfig
        from skillmeat.core.interfaces.dtos import EntityTypeConfigDTO

        if "entity_type" in updates or "is_system" in updates:
            raise ValueError(
                "The 'entity_type' and 'is_system' fields are immutable after creation."
            )

        try:
            cfg_uuid = _ensure_uuid(config_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(config_id) from exc

        stmt = self._apply_tenant_filter(
            select(EnterpriseEntityTypeConfig).where(
                EnterpriseEntityTypeConfig.id == cfg_uuid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            raise KeyError(config_id)

        for field_name in ("display_name", "description", "icon", "color"):
            if field_name in updates:
                setattr(row, field_name, updates[field_name])

        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseEntityTypeConfig",
            entity_id=cfg_uuid,
            metadata=updates or None,
        )
        return EntityTypeConfigDTO(
            id=str(row.id),
            entity_type=row.entity_type,
            display_name=row.display_name or row.entity_type,
            description=row.description,
            icon=row.icon,
            color=row.color,
            is_system=bool(row.is_system),
        )

    # ------------------------------------------------------------------
    # ISettingsRepository: delete_entity_type_config
    # ------------------------------------------------------------------

    def delete_entity_type_config(
        self,
        config_id: str,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Delete a user-defined entity type configuration.

        System-defined configs (``is_system=True``) cannot be deleted.

        Parameters
        ----------
        config_id:
            UUID string of the config record to delete.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If no config with *config_id* exists in this tenant.
        ValueError
            If the config is system-defined.
        """
        from skillmeat.cache.models_enterprise import EnterpriseEntityTypeConfig

        try:
            cfg_uuid = _ensure_uuid(config_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(config_id) from exc

        stmt = self._apply_tenant_filter(
            select(EnterpriseEntityTypeConfig).where(
                EnterpriseEntityTypeConfig.id == cfg_uuid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            raise KeyError(config_id)
        if row.is_system:
            raise ValueError(
                f"Cannot delete system-defined entity type config {config_id!r}."
            )

        self.session.delete(row)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseEntityTypeConfig",
            entity_id=cfg_uuid,
        )

    # ------------------------------------------------------------------
    # ISettingsRepository: list_categories
    # ------------------------------------------------------------------

    def list_categories(
        self,
        entity_type: "Optional[str]" = None,
        platform: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> "list[CategoryDTO]":
        """Return all categories for this tenant, optionally filtered.

        Parameters
        ----------
        entity_type:
            When provided, return only categories scoped to this entity type.
        platform:
            When provided, return only categories scoped to this platform.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[CategoryDTO]
            Categories ordered by ``sort_order`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseEntityCategory
        from skillmeat.core.interfaces.dtos import CategoryDTO

        stmt = self._apply_tenant_filter(select(EnterpriseEntityCategory)).order_by(
            EnterpriseEntityCategory.sort_order
        )

        if entity_type is not None:
            stmt = stmt.where(EnterpriseEntityCategory.entity_type == entity_type)
        if platform is not None:
            stmt = stmt.where(EnterpriseEntityCategory.platform == platform)

        rows = list(self.session.execute(stmt).scalars())
        return [
            CategoryDTO(
                id=str(row.id),
                name=row.name,
                slug=row.slug or "",
                entity_type=row.entity_type,
                description=row.description,
                color=row.color,
                platform=row.platform,
                sort_order=row.sort_order or 0,
            )
            for row in rows
        ]

    # ------------------------------------------------------------------
    # ISettingsRepository: create_category
    # ------------------------------------------------------------------

    def create_category(
        self,
        name: str,
        slug: "Optional[str]" = None,
        entity_type: "Optional[str]" = None,
        description: "Optional[str]" = None,
        color: "Optional[str]" = None,
        platform: "Optional[str]" = None,
        sort_order: "Optional[int]" = None,
        ctx: "Optional[object]" = None,
    ) -> "CategoryDTO":
        """Create a new category for this tenant.

        Parameters
        ----------
        name:
            Human-readable category name.
        slug:
            Optional URL-safe slug; auto-generated from *name* when omitted.
        entity_type:
            Optional entity type this category applies to.
        description:
            Optional description text.
        color:
            Optional hex color code for UI display.
        platform:
            Optional platform scope filter.
        sort_order:
            Optional explicit display order; defaults to 0.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        CategoryDTO
            The newly created category.

        Raises
        ------
        ValueError
            If a category with the same resolved slug already exists in this
            tenant.
        """
        import re

        from skillmeat.cache.models_enterprise import EnterpriseEntityCategory
        from skillmeat.core.interfaces.dtos import CategoryDTO

        tenant_id = self._get_tenant_id()

        if slug is None:
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")

        # Guard: uniqueness check on (tenant_id, slug).
        dup_stmt = self._apply_tenant_filter(
            select(EnterpriseEntityCategory).where(
                EnterpriseEntityCategory.slug == slug
            )
        )
        if self.session.execute(dup_stmt).scalar_one_or_none() is not None:
            raise ValueError(
                f"A category with slug {slug!r} already exists in this tenant."
            )

        row = EnterpriseEntityCategory(
            tenant_id=tenant_id,
            name=name,
            slug=slug,
            entity_type=entity_type,
            description=description,
            color=color,
            platform=platform,
            sort_order=sort_order or 0,
        )
        self.session.add(row)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseEntityCategory",
            entity_id=row.id,
            metadata={"name": name, "slug": slug},
        )
        return CategoryDTO(
            id=str(row.id),
            name=row.name,
            slug=row.slug or "",
            entity_type=row.entity_type,
            description=row.description,
            color=row.color,
            platform=row.platform,
            sort_order=row.sort_order or 0,
        )

    # ------------------------------------------------------------------
    # ISettingsRepository: update_category
    # ------------------------------------------------------------------

    def update_category(
        self,
        category_id: int,
        updates: "dict",
        ctx: "Optional[object]" = None,
    ) -> "CategoryDTO":
        """Apply a partial update to an existing category.

        Parameters
        ----------
        category_id:
            UUID or integer primary key of the category to update.
        updates:
            Map of field names to new values.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        CategoryDTO
            The updated category.

        Raises
        ------
        KeyError
            If no category with *category_id* exists in this tenant.
        ValueError
            If the requested new slug is already taken.
        """
        import re

        from skillmeat.cache.models_enterprise import EnterpriseEntityCategory
        from skillmeat.core.interfaces.dtos import CategoryDTO

        try:
            cat_uuid = _ensure_uuid(category_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(category_id) from exc

        stmt = self._apply_tenant_filter(
            select(EnterpriseEntityCategory).where(
                EnterpriseEntityCategory.id == cat_uuid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            raise KeyError(category_id)

        if "slug" in updates:
            new_slug = updates["slug"]
            dup_stmt = self._apply_tenant_filter(
                select(EnterpriseEntityCategory).where(
                    EnterpriseEntityCategory.slug == new_slug,
                    EnterpriseEntityCategory.id != cat_uuid,
                )
            )
            if self.session.execute(dup_stmt).scalar_one_or_none() is not None:
                raise ValueError(
                    f"Slug {new_slug!r} is already used by another category in this tenant."
                )

        for field_name in (
            "name",
            "slug",
            "entity_type",
            "description",
            "color",
            "platform",
            "sort_order",
        ):
            if field_name in updates:
                setattr(row, field_name, updates[field_name])

        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseEntityCategory",
            entity_id=cat_uuid,
            metadata=updates or None,
        )
        return CategoryDTO(
            id=str(row.id),
            name=row.name,
            slug=row.slug or "",
            entity_type=row.entity_type,
            description=row.description,
            color=row.color,
            platform=row.platform,
            sort_order=row.sort_order or 0,
        )

    # ------------------------------------------------------------------
    # ISettingsRepository: delete_category
    # ------------------------------------------------------------------

    def delete_category(
        self,
        category_id: int,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Delete a category by primary key.

        Parameters
        ----------
        category_id:
            UUID or integer primary key of the category to delete.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If no category with *category_id* exists in this tenant.
        ValueError
            If the category has artifact associations.
        """
        from skillmeat.cache.models_enterprise import EnterpriseEntityCategory

        try:
            cat_uuid = _ensure_uuid(category_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(category_id) from exc

        stmt = self._apply_tenant_filter(
            select(EnterpriseEntityCategory).where(
                EnterpriseEntityCategory.id == cat_uuid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            raise KeyError(category_id)

        if row.entity_category_associations:
            raise ValueError(
                f"Category {category_id!r} has existing associations and cannot be deleted."
            )

        self.session.delete(row)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseEntityCategory",
            entity_id=cat_uuid,
        )


# =============================================================================
# EnterpriseContextEntityRepository  (ENT2-3.4)
# =============================================================================


class EnterpriseContextEntityRepository(
    EnterpriseRepositoryBase["EnterpriseContextEntity"],
):
    """Repository for tenant-scoped CRUD on EnterpriseContextEntity.

    Implements :class:`~skillmeat.core.interfaces.repositories.IContextEntityRepository`
    for the enterprise PostgreSQL backend.

    Context entities are special artifacts (CLAUDE.md, spec files, rule files,
    context files, progress templates) stored in ``enterprise_context_entities``.
    All queries are automatically scoped to the tenant stored in ``TenantContext``
    via ``_apply_tenant_filter()``.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Notes
    -----
    The ``artifact_id`` FK is nullable — context entities may exist
    independently of any artifact row.  The ``target_platforms`` and
    ``category_associations`` fields are JSONB/relational respectively; JSONB
    filters use standard equality (not ``@>``), so they are safe in SQLite-
    backed unit tests.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseContextEntity as _ECE

        super().__init__(session, _ECE)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_content_hash(content: "Optional[str]") -> "Optional[str]":
        """Return the SHA-256 hex digest of *content*, or ``None`` when empty.

        Parameters
        ----------
        content:
            Raw string content to hash.

        Returns
        -------
        str or None
        """
        if not content:
            return None
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def _to_dto(self, row: "EnterpriseContextEntity") -> "ContextEntityDTO":
        """Map an ``EnterpriseContextEntity`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.ContextEntityDTO`.

        Parameters
        ----------
        row:
            ORM instance to convert.

        Returns
        -------
        ContextEntityDTO
        """
        from skillmeat.core.interfaces.dtos import ContextEntityDTO

        category_ids: List[int] = []
        if row.category_associations:
            for assoc in row.category_associations:
                try:
                    category_ids.append(int(str(assoc.category_id)))
                except (TypeError, ValueError):
                    pass

        return ContextEntityDTO(
            id=str(row.id),
            name=row.name,
            entity_type=row.entity_type,
            content=row.content or "",
            path_pattern=row.path_pattern or "",
            description=row.description,
            category=row.category,
            auto_load=bool(row.auto_load),
            version=row.version,
            target_platforms=list(row.target_platforms or []),
            content_hash=self._compute_content_hash(row.content),
            category_ids=category_ids,
            created_at=row.created_at.isoformat() if row.created_at else None,
            updated_at=row.updated_at.isoformat() if row.updated_at else None,
        )

    def _fetch_entity(
        self,
        entity_uuid: uuid.UUID,
    ) -> "Optional[EnterpriseContextEntity]":
        """Fetch a tenant-filtered context entity by UUID.

        Parameters
        ----------
        entity_uuid:
            UUID of the entity to retrieve.

        Returns
        -------
        EnterpriseContextEntity or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseContextEntity

        stmt = self._tenant_select().where(EnterpriseContextEntity.id == entity_uuid)
        return self.session.execute(stmt).scalar_one_or_none()

    # ------------------------------------------------------------------
    # IContextEntityRepository: list
    # ------------------------------------------------------------------

    def list(
        self,
        filters: "Optional[dict]" = None,
        limit: int = 20,
        after: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> "list[ContextEntityDTO]":
        """Return a page of context entities matching optional filter criteria.

        Supported filter keys: ``entity_type``, ``category``, ``auto_load``,
        ``search`` (case-insensitive prefix on ``name``).

        Parameters
        ----------
        filters:
            Optional key/value filter map.
        limit:
            Maximum number of records to return (1-100).
        after:
            Opaque cursor (base64-encoded UUID string) for keyset pagination.
            Pass the ``id`` of the last seen item.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[ContextEntityDTO]
        """
        import base64

        from sqlalchemy import func
        from skillmeat.cache.models_enterprise import EnterpriseContextEntity

        stmt = self._tenant_select().order_by(EnterpriseContextEntity.created_at)

        if filters:
            entity_type = filters.get("entity_type")
            if entity_type is not None:
                stmt = stmt.where(EnterpriseContextEntity.entity_type == entity_type)

            category = filters.get("category")
            if category is not None:
                stmt = stmt.where(EnterpriseContextEntity.category == category)

            auto_load = filters.get("auto_load")
            if auto_load is not None:
                stmt = stmt.where(
                    EnterpriseContextEntity.auto_load.is_(bool(auto_load))
                )

            search = filters.get("search")
            if search:
                stmt = stmt.where(
                    func.lower(EnterpriseContextEntity.name).like(f"{search.lower()}%")
                )

        # Keyset pagination: skip rows whose id <= after cursor.
        if after:
            try:
                cursor_id = _ensure_uuid(base64.b64decode(after.encode()).decode())
                stmt = stmt.where(EnterpriseContextEntity.id > cursor_id)
            except Exception:
                pass  # Ignore invalid cursor; return from beginning.

        limit = max(1, min(limit, 100))
        stmt = stmt.limit(limit)

        rows = list(self.session.execute(stmt).scalars())
        return [self._to_dto(row) for row in rows]

    # ------------------------------------------------------------------
    # IContextEntityRepository: get
    # ------------------------------------------------------------------

    def get(
        self,
        entity_id: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[ContextEntityDTO]":
        """Return a context entity by its identifier.

        Parameters
        ----------
        entity_id:
            Entity UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ContextEntityDTO or None
        """
        try:
            entity_uuid = _ensure_uuid(entity_id)
        except (ValueError, AttributeError):
            return None

        row = self._fetch_entity(entity_uuid)
        if row is None:
            return None
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IContextEntityRepository: create
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        entity_type: str,
        content: str,
        path_pattern: str,
        description: "Optional[str]" = None,
        category: "Optional[str]" = None,
        auto_load: bool = False,
        version: "Optional[str]" = None,
        target_platforms: "Optional[list[str]]" = None,
        category_ids: "Optional[list[int]]" = None,
        ctx: "Optional[object]" = None,
    ) -> "ContextEntityDTO":
        """Persist a new context entity and return the stored representation.

        Parameters
        ----------
        name:
            Human-readable entity name.
        entity_type:
            Entity type key, e.g. ``"context_file"``, ``"rule_file"``.
        content:
            Assembled markdown content.
        path_pattern:
            Target deployment path (must start with ``".claude/"`` or a
            supported prefix).
        description:
            Optional description.
        category:
            Optional category label string.
        auto_load:
            Whether to auto-load on platform startup.
        version:
            Optional version string.
        target_platforms:
            Optional list of platform identifiers.
        category_ids:
            Ordered list of category IDs to associate.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ContextEntityDTO
            The persisted entity.

        Raises
        ------
        ValueError
            If *path_pattern* is blank.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseContextEntity,
            EnterpriseEntityCategoryAssociation,
        )

        if not path_pattern:
            raise ValueError("path_pattern must not be empty.")

        tenant_id = self._get_tenant_id()

        row = EnterpriseContextEntity(
            tenant_id=tenant_id,
            name=name,
            entity_type=entity_type,
            content=content,
            path_pattern=path_pattern,
            description=description,
            category=category,
            auto_load=auto_load,
            version=version,
            target_platforms=target_platforms or [],
        )
        self.session.add(row)
        self.session.flush()  # Populate row.id before associations.

        if category_ids:
            for position, cat_id in enumerate(category_ids):
                try:
                    cat_uuid = _ensure_uuid(cat_id)
                except (ValueError, AttributeError):
                    continue
                assoc = EnterpriseEntityCategoryAssociation(
                    tenant_id=tenant_id,
                    entity_id=row.id,
                    category_id=cat_uuid,
                    position=position,
                )
                self.session.add(assoc)
            self.session.flush()

        self._log_operation(
            operation="create",
            entity_type="EnterpriseContextEntity",
            entity_id=row.id,
            metadata={"name": name, "entity_type": entity_type},
        )
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IContextEntityRepository: update
    # ------------------------------------------------------------------

    def update(
        self,
        entity_id: str,
        updates: "dict",
        ctx: "Optional[object]" = None,
    ) -> "ContextEntityDTO":
        """Apply a partial update to an existing context entity.

        Parameters
        ----------
        entity_id:
            Entity UUID as a string.
        updates:
            Map of field names to new values.  Supported keys:
            ``name``, ``entity_type``, ``content``, ``path_pattern``,
            ``description``, ``category``, ``auto_load``, ``version``,
            ``target_platforms``, ``category_ids``.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ContextEntityDTO
            The updated entity.

        Raises
        ------
        KeyError
            If no entity with *entity_id* exists in this tenant.
        ValueError
            If *updates* contains invalid field values.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseContextEntity,
            EnterpriseEntityCategoryAssociation,
        )

        try:
            entity_uuid = _ensure_uuid(entity_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(entity_id) from exc

        row = self._fetch_entity(entity_uuid)
        if row is None:
            raise KeyError(entity_id)

        for field_name in (
            "name",
            "entity_type",
            "content",
            "path_pattern",
            "description",
            "category",
            "auto_load",
            "version",
            "target_platforms",
        ):
            if field_name in updates:
                setattr(row, field_name, updates[field_name])

        if "category_ids" in updates:
            tenant_id = self._get_tenant_id()
            # Replace all existing associations.
            for assoc in list(row.category_associations):
                self.session.delete(assoc)
            self.session.flush()

            for position, cat_id in enumerate(updates["category_ids"] or []):
                try:
                    cat_uuid = _ensure_uuid(cat_id)
                except (ValueError, AttributeError):
                    continue
                assoc = EnterpriseEntityCategoryAssociation(
                    tenant_id=tenant_id,
                    entity_id=row.id,
                    category_id=cat_uuid,
                    position=position,
                )
                self.session.add(assoc)

        row.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseContextEntity",
            entity_id=entity_uuid,
            metadata={k: str(v)[:80] for k, v in updates.items() if k != "content"},
        )
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IContextEntityRepository: delete
    # ------------------------------------------------------------------

    def delete(
        self,
        entity_id: str,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Delete a context entity permanently.

        The ``ON DELETE CASCADE`` on ``enterprise_entity_category_associations``
        removes association rows automatically at the database level.

        Parameters
        ----------
        entity_id:
            Entity UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If no entity with *entity_id* exists in this tenant.
        """
        try:
            entity_uuid = _ensure_uuid(entity_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(entity_id) from exc

        row = self._fetch_entity(entity_uuid)
        if row is None:
            raise KeyError(entity_id)

        self.session.delete(row)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseContextEntity",
            entity_id=entity_uuid,
        )

    # ------------------------------------------------------------------
    # IContextEntityRepository: deploy
    # ------------------------------------------------------------------

    def deploy(
        self,
        entity_id: str,
        project_path: str,
        options: "Optional[dict]" = None,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Deploy a context entity's content to a filesystem project path.

        Writes the assembled content to the location specified by
        ``path_pattern``, resolved against *project_path*.

        Parameters
        ----------
        entity_id:
            Entity UUID as a string.
        project_path:
            Absolute filesystem path to the target project directory.
        options:
            Optional deployment options: ``overwrite`` (bool, default False).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Raises
        ------
        KeyError
            If *entity_id* does not exist.
        FileExistsError
            If the target file already exists and ``options["overwrite"]`` is
            ``False``.
        ValueError
            If *project_path* does not exist or ``path_pattern`` is missing.
        """
        from pathlib import Path

        try:
            entity_uuid = _ensure_uuid(entity_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(entity_id) from exc

        row = self._fetch_entity(entity_uuid)
        if row is None:
            raise KeyError(entity_id)

        if not row.path_pattern:
            raise ValueError(f"Entity {entity_id!r} has no path_pattern set.")

        project = Path(project_path)
        if not project.exists():
            raise ValueError(f"project_path {project_path!r} does not exist.")

        target = project / row.path_pattern.lstrip("/")
        overwrite = (options or {}).get("overwrite", False)

        if target.exists() and not overwrite:
            raise FileExistsError(
                f"Target file {target} already exists. Pass overwrite=True to replace it."
            )

        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(row.content or "", encoding="utf-8")

        self._log_operation(
            operation="deploy",
            entity_type="EnterpriseContextEntity",
            entity_id=entity_uuid,
            metadata={"project_path": project_path, "target": str(target)},
        )

    # ------------------------------------------------------------------
    # IContextEntityRepository: get_content
    # ------------------------------------------------------------------

    def get_content(
        self,
        entity_id: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[str]":
        """Return the raw markdown content of a context entity.

        Parameters
        ----------
        entity_id:
            Entity UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        str or None
            Raw content string when the entity exists, ``None`` otherwise.
        """
        try:
            entity_uuid = _ensure_uuid(entity_id)
        except (ValueError, AttributeError):
            return None

        row = self._fetch_entity(entity_uuid)
        if row is None:
            return None
        return row.content


# =============================================================================
# EnterpriseProjectRepository  (ENT2-4.1)
# =============================================================================


class EnterpriseProjectRepository(
    EnterpriseRepositoryBase["EnterpriseProject"],
):
    """Repository for tenant-scoped CRUD on EnterpriseProject.

    Implements :class:`~skillmeat.core.interfaces.repositories.IProjectRepository`
    for the enterprise PostgreSQL backend.

    Enterprise projects are DB records — ``path`` is an informational metadata
    field recorded at registration time, NOT a live filesystem reference.
    Methods that carry filesystem semantics in the local backend (e.g.
    ``refresh``, ``get_artifacts``) operate purely on DB data and never touch
    the filesystem.  A debug-level log is emitted for every method where
    enterprise behaviour meaningfully diverges from the local implementation.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Notes
    -----
    - ``path`` is unique per tenant (``uq_enterprise_projects_tenant_path``).
    - ``_apply_tenant_filter()`` is called on every ``select()`` statement.
    - No filesystem operations are performed anywhere in this class.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseProject as _EP

        super().__init__(session, _EP)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _to_dto(self, row: "EnterpriseProject") -> "ProjectDTO":
        """Map an ``EnterpriseProject`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.ProjectDTO`.

        Parameters
        ----------
        row:
            ORM instance to convert.

        Returns
        -------
        ProjectDTO
        """
        from skillmeat.core.interfaces.dtos import ProjectDTO

        return ProjectDTO(
            id=str(row.id),
            name=row.name,
            path=row.path or "",
            description=row.description,
            status=row.status or "active",
            artifact_count=len(row.deployments) if row.deployments else 0,
            created_at=row.created_at.isoformat() if row.created_at else None,
            updated_at=row.updated_at.isoformat() if row.updated_at else None,
        )

    def _fetch_project(
        self,
        project_uuid: "uuid.UUID",
    ) -> "Optional[EnterpriseProject]":
        """Fetch a tenant-filtered project by UUID.

        Parameters
        ----------
        project_uuid:
            UUID of the project to retrieve.

        Returns
        -------
        EnterpriseProject or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseProject

        stmt = self._tenant_select().where(EnterpriseProject.id == project_uuid)
        return self.session.execute(stmt).scalar_one_or_none()

    # ------------------------------------------------------------------
    # IProjectRepository: get
    # ------------------------------------------------------------------

    def get(
        self,
        id: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[ProjectDTO]":
        """Return the project with the given identifier.

        Parameters
        ----------
        id:
            Project UUID as a string (enterprise PK).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ProjectDTO or None
        """
        try:
            project_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError):
            return None

        row = self._fetch_project(project_uuid)
        if row is None:
            return None
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IProjectRepository: list
    # ------------------------------------------------------------------

    def list(
        self,
        filters: "Optional[dict]" = None,
        ctx: "Optional[object]" = None,
    ) -> "list[ProjectDTO]":
        """Return all known projects for the current tenant.

        Parameters
        ----------
        filters:
            Optional filter map.  Supported keys: ``status``, ``search``
            (case-insensitive prefix on ``name``).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[ProjectDTO]
        """
        from sqlalchemy import func
        from skillmeat.cache.models_enterprise import EnterpriseProject

        stmt = self._tenant_select().order_by(EnterpriseProject.created_at)

        if filters:
            status = filters.get("status")
            if status is not None:
                stmt = stmt.where(EnterpriseProject.status == status)

            search = filters.get("search")
            if search:
                stmt = stmt.where(
                    func.lower(EnterpriseProject.name).like(f"{search.lower()}%")
                )

        from sqlalchemy.orm import selectinload as _selectinload

        stmt = stmt.options(_selectinload(EnterpriseProject.deployments))
        rows = list(self.session.execute(stmt).scalars())
        return [self._to_dto(row) for row in rows]

    # ------------------------------------------------------------------
    # IProjectRepository: create
    # ------------------------------------------------------------------

    def create(
        self,
        dto: "ProjectDTO",
        ctx: "Optional[object]" = None,
    ) -> "ProjectDTO":
        """Register a new project record.

        Parameters
        ----------
        dto:
            Project data.  ``dto.path`` is stored as an informational field;
            no filesystem access is performed.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ProjectDTO
            The persisted project.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProject

        tenant_id = self._get_tenant_id()

        row = EnterpriseProject(
            tenant_id=tenant_id,
            name=dto.name,
            path=dto.path or "",
            status=dto.status or "active",
            description=dto.description,
        )
        self.session.add(row)
        self.session.flush()

        self._log_operation(
            operation="create",
            entity_type="EnterpriseProject",
            entity_id=row.id,
            metadata={"name": dto.name, "path": dto.path},
        )
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IProjectRepository: update
    # ------------------------------------------------------------------

    def update(
        self,
        id: str,
        updates: "dict",
        ctx: "Optional[object]" = None,
    ) -> "ProjectDTO":
        """Apply a partial update to an existing project.

        Parameters
        ----------
        id:
            Project UUID as a string.
        updates:
            Map of field names to new values.  Supported keys:
            ``name``, ``path``, ``status``, ``description``.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ProjectDTO
            The updated project.

        Raises
        ------
        KeyError
            If no project with *id* exists in this tenant.
        """
        try:
            project_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(id) from exc

        row = self._fetch_project(project_uuid)
        if row is None:
            raise KeyError(id)

        for field_name in ("name", "path", "status", "description"):
            if field_name in updates:
                setattr(row, field_name, updates[field_name])

        row.updated_at = datetime.utcnow()
        self.session.flush()

        self._log_operation(
            operation="update",
            entity_type="EnterpriseProject",
            entity_id=row.id,
            metadata={k: str(v)[:80] for k, v in updates.items()},
        )
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IProjectRepository: delete
    # ------------------------------------------------------------------

    def delete(
        self,
        id: str,
        ctx: "Optional[object]" = None,
    ) -> bool:
        """Remove a project record.

        Does not delete anything on disk — only removes the DB entry.

        Parameters
        ----------
        id:
            Project UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        bool
            ``True`` when the project was found and deleted, ``False``
            otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProject

        try:
            project_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError):
            return False

        row = self._fetch_project(project_uuid)
        if row is None:
            return False

        self.session.delete(row)
        self.session.flush()

        self._log_operation(
            operation="delete",
            entity_type="EnterpriseProject",
            entity_id=project_uuid,
            metadata={"id": id},
        )
        return True

    # ------------------------------------------------------------------
    # IProjectRepository: get_artifacts
    # ------------------------------------------------------------------

    def get_artifacts(
        self,
        project_id: str,
        ctx: "Optional[object]" = None,
    ) -> "list[ArtifactDTO]":
        """Return all artifacts deployed to a project.

        Queries ``enterprise_project_artifacts`` and resolves the associated
        ``EnterpriseArtifact`` rows.  No filesystem access is performed.

        Parameters
        ----------
        project_id:
            Project UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[ArtifactDTO]
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseProjectArtifact,
        )
        from skillmeat.core.interfaces.dtos import ArtifactDTO

        logger.debug(
            "EnterpriseProjectRepository.get_artifacts: querying DB only "
            "(no filesystem scan) for project_id=%s",
            project_id,
        )

        try:
            project_uuid = _ensure_uuid(project_id)
        except (ValueError, AttributeError):
            return []

        tenant_id = self._get_tenant_id()

        stmt = (
            select(EnterpriseArtifact)
            .join(
                EnterpriseProjectArtifact,
                EnterpriseProjectArtifact.artifact_uuid == EnterpriseArtifact.id,
            )
            .where(
                EnterpriseProjectArtifact.project_id == project_uuid,
                EnterpriseProjectArtifact.tenant_id == tenant_id,
                EnterpriseArtifact.tenant_id == tenant_id,
            )
        )

        rows = list(self.session.execute(stmt).scalars())
        return [
            ArtifactDTO(
                id=row.id or f"{row.artifact_type}:{row.name}",
                name=row.name,
                artifact_type=row.artifact_type or "",
                uuid=str(row.id),
                source=row.source,
                version=row.version,
                scope=row.scope,
                description=row.description,
                project_id=str(project_uuid),
                created_at=row.created_at.isoformat() if row.created_at else None,
                updated_at=row.updated_at.isoformat() if row.updated_at else None,
            )
            for row in rows
        ]

    # ------------------------------------------------------------------
    # IProjectRepository: refresh
    # ------------------------------------------------------------------

    def refresh(
        self,
        id: str,
        ctx: "Optional[object]" = None,
    ) -> "ProjectDTO":
        """Trigger a cache refresh for a single project.

        In the enterprise backend, the DB is the source of truth — no
        filesystem rescan is possible from within the repository layer.
        This method reloads the project record from DB (touching
        ``updated_at``) and returns the current state.

        Parameters
        ----------
        id:
            Project UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ProjectDTO
            The current project state.

        Raises
        ------
        KeyError
            If no project with *id* exists in this tenant.
        """
        logger.debug(
            "EnterpriseProjectRepository.refresh: enterprise backend has no "
            "filesystem rescan; returning current DB state for project_id=%s",
            id,
        )
        try:
            project_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(id) from exc

        row = self._fetch_project(project_uuid)
        if row is None:
            raise KeyError(id)

        row.updated_at = datetime.utcnow()
        self.session.flush()
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IProjectRepository: get_by_path
    # ------------------------------------------------------------------

    def get_by_path(
        self,
        path: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[ProjectDTO]":
        """Return the project whose stored path matches *path*.

        Matches against the ``path`` column (informational, stored at
        registration time).  No live filesystem access is performed.

        Parameters
        ----------
        path:
            Path string to match against.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ProjectDTO or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseProject

        logger.debug(
            "EnterpriseProjectRepository.get_by_path: matching stored path "
            "column only (no filesystem resolution) for path=%s",
            path,
        )

        stmt = self._tenant_select().where(EnterpriseProject.path == path)
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return None
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IProjectRepository: get_or_create_by_path
    # ------------------------------------------------------------------

    def get_or_create_by_path(
        self,
        path: str,
        ctx: "Optional[object]" = None,
    ) -> "ProjectDTO":
        """Return the project for *path*, creating a DB record if absent.

        Looks up an existing project by its stored ``path`` column and
        creates a new one if none is found.  No filesystem resolution
        is performed.

        Parameters
        ----------
        path:
            Path string to match or register.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        ProjectDTO
            Existing or newly created project.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProject
        from skillmeat.core.interfaces.dtos import ProjectDTO as _ProjectDTO

        logger.debug(
            "EnterpriseProjectRepository.get_or_create_by_path: using stored "
            "path column only (no filesystem resolution) for path=%s",
            path,
        )

        existing = self.get_by_path(path, ctx=ctx)
        if existing is not None:
            return existing

        # No existing record — create one using the path as both path and name.
        # Derive a display name from the last path component (string-only, no I/O).
        name = path.rstrip("/\\").rsplit("/", 1)[-1] or path
        tenant_id = self._get_tenant_id()

        row = EnterpriseProject(
            tenant_id=tenant_id,
            name=name,
            path=path,
            status="active",
        )
        self.session.add(row)
        self.session.flush()

        self._log_operation(
            operation="create",
            entity_type="EnterpriseProject",
            entity_id=row.id,
            metadata={"name": name, "path": path, "via": "get_or_create_by_path"},
        )
        return self._to_dto(row)


# =============================================================================
# EnterpriseDeploymentRepository  (ENT2-4.2)
# =============================================================================


class EnterpriseDeploymentRepository(
    EnterpriseRepositoryBase["EnterpriseDeployment"],
):
    """Repository for tenant-scoped CRUD on EnterpriseDeployment.

    Implements :class:`~skillmeat.core.interfaces.repositories.IDeploymentRepository`
    for the enterprise PostgreSQL backend.

    Deployment records reference projects via ``project_id`` (nullable FK) and
    artifacts via ``artifact_uuid`` (nullable FK) plus the text ``artifact_id``
    field for backward compatibility with the ``sync_deployment_cache`` callers.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Notes
    -----
    - Both ``project_id`` and ``artifact_uuid`` are nullable FKs (SET NULL
      on delete); callers must handle ``None`` values gracefully.
    - ``artifact_id`` (text ``"type:name"`` format) is kept for write-through
      compatibility with ``sync_deployment_cache`` and ``remove_deployment_cache``.
    - ``_apply_tenant_filter()`` is called on every ``select()`` statement.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseDeployment as _ED

        super().__init__(session, _ED)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _to_dto(self, row: "EnterpriseDeployment") -> "DeploymentDTO":
        """Map an ``EnterpriseDeployment`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.DeploymentDTO`.

        Parameters
        ----------
        row:
            ORM instance to convert.

        Returns
        -------
        DeploymentDTO
        """
        from skillmeat.core.interfaces.dtos import DeploymentDTO

        artifact_id = row.artifact_id or ""
        # Derive name and type from text identifier "type:name" when possible.
        parts = artifact_id.split(":", 1)
        artifact_type = parts[0] if len(parts) == 2 else ""
        artifact_name = parts[1] if len(parts) == 2 else artifact_id

        project_path: Optional[str] = None
        project_name: Optional[str] = None
        if row.project is not None:
            project_path = row.project.path
            project_name = row.project.name

        return DeploymentDTO(
            id=str(row.id),
            artifact_id=artifact_id,
            artifact_name=artifact_name,
            artifact_type=artifact_type,
            project_id=str(row.project_id) if row.project_id else None,
            project_path=project_path,
            project_name=project_name,
            status=row.status or "deployed",
            deployed_at=row.deployed_at.isoformat() if row.deployed_at else None,
            collection_sha=row.content_hash,
            local_modifications=bool(row.local_modifications),
            deployment_profile_id=(
                str(row.deployment_profile_id) if row.deployment_profile_id else None
            ),
            platform=row.platform,
        )

    def _fetch_deployment(
        self,
        deployment_uuid: "uuid.UUID",
    ) -> "Optional[EnterpriseDeployment]":
        """Fetch a tenant-filtered deployment record by UUID.

        Parameters
        ----------
        deployment_uuid:
            UUID of the deployment to retrieve.

        Returns
        -------
        EnterpriseDeployment or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeployment

        stmt = self._tenant_select().where(EnterpriseDeployment.id == deployment_uuid)
        return self.session.execute(stmt).scalar_one_or_none()

    # ------------------------------------------------------------------
    # IDeploymentRepository: get
    # ------------------------------------------------------------------

    def get(
        self,
        id: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[DeploymentDTO]":
        """Return a deployment record by its identifier.

        Parameters
        ----------
        id:
            Deployment UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        DeploymentDTO or None
        """
        try:
            deployment_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError):
            return None

        row = self._fetch_deployment(deployment_uuid)
        if row is None:
            return None
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IDeploymentRepository: list
    # ------------------------------------------------------------------

    def list(
        self,
        filters: "Optional[dict]" = None,
        ctx: "Optional[object]" = None,
    ) -> "list[DeploymentDTO]":
        """Return deployment records matching optional filter criteria.

        Parameters
        ----------
        filters:
            Optional filter map.  Supported keys: ``project_id``,
            ``artifact_id``, ``artifact_type``, ``status``.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[DeploymentDTO]
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeployment

        stmt = self._tenant_select().order_by(EnterpriseDeployment.deployed_at.desc())

        if filters:
            project_id = filters.get("project_id")
            if project_id is not None:
                try:
                    proj_uuid = _ensure_uuid(project_id)
                    stmt = stmt.where(EnterpriseDeployment.project_id == proj_uuid)
                except (ValueError, AttributeError):
                    pass

            artifact_id = filters.get("artifact_id")
            if artifact_id is not None:
                stmt = stmt.where(EnterpriseDeployment.artifact_id == artifact_id)

            artifact_type = filters.get("artifact_type")
            if artifact_type is not None:
                # artifact_id is stored as "type:name" — filter by prefix.
                stmt = stmt.where(
                    EnterpriseDeployment.artifact_id.like(f"{artifact_type}:%")
                )

            status = filters.get("status")
            if status is not None:
                stmt = stmt.where(EnterpriseDeployment.status == status)

        rows = list(self.session.execute(stmt).scalars())
        return [self._to_dto(row) for row in rows]

    # ------------------------------------------------------------------
    # IDeploymentRepository: deploy
    # ------------------------------------------------------------------

    def deploy(
        self,
        artifact_id: str,
        project_id: str,
        options: "Optional[dict]" = None,
        ctx: "Optional[object]" = None,
    ) -> "DeploymentDTO":
        """Record an artifact deployment to a project.

        Creates a new ``EnterpriseDeployment`` row.  Does not perform any
        filesystem copy — the enterprise layer treats deployment tracking as
        a DB write-through from the CLI layer.

        Parameters
        ----------
        artifact_id:
            Artifact primary key in ``"type:name"`` format.
        project_id:
            Target project UUID as a string.
        options:
            Optional deployment options.  Recognised keys: ``status``,
            ``content_hash``, ``deployment_profile_id``, ``platform``,
            ``local_modifications``.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        DeploymentDTO
            The created deployment record.

        Raises
        ------
        KeyError
            If *project_id* is not a valid UUID or does not exist for this
            tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeployment

        try:
            proj_uuid = _ensure_uuid(project_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(project_id) from exc

        opts = options or {}
        tenant_id = self._get_tenant_id()

        profile_id: Optional[uuid.UUID] = None
        raw_profile = opts.get("deployment_profile_id")
        if raw_profile:
            try:
                profile_id = _ensure_uuid(raw_profile)
            except (ValueError, AttributeError):
                pass

        row = EnterpriseDeployment(
            tenant_id=tenant_id,
            artifact_id=artifact_id,
            project_id=proj_uuid,
            status=opts.get("status", "deployed"),
            deployed_at=datetime.utcnow(),
            content_hash=opts.get("content_hash"),
            deployment_profile_id=profile_id,
            local_modifications=bool(opts.get("local_modifications", False)),
            platform=opts.get("platform"),
        )
        self.session.add(row)
        self.session.flush()

        self._log_operation(
            operation="deploy",
            entity_type="EnterpriseDeployment",
            entity_id=row.id,
            metadata={"artifact_id": artifact_id, "project_id": project_id},
        )
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # IDeploymentRepository: undeploy
    # ------------------------------------------------------------------

    def undeploy(
        self,
        id: str,
        ctx: "Optional[object]" = None,
    ) -> bool:
        """Remove a deployment record.

        Parameters
        ----------
        id:
            Deployment UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        bool
            ``True`` when the record was found and deleted, ``False``
            otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeployment

        id_str = str(id)
        if ":" in id_str:
            # "type:name" format — look up by artifact_id text column.
            stmt = self._apply_tenant_filter(
                select(EnterpriseDeployment).where(
                    EnterpriseDeployment.artifact_id == id_str,
                )
            )
            row = self.session.execute(stmt).scalar_one_or_none()
        else:
            try:
                deployment_uuid = _ensure_uuid(id_str)
            except (ValueError, AttributeError):
                return False
            row = self._fetch_deployment(deployment_uuid)

        if row is None:
            return False

        self.session.delete(row)
        self.session.flush()

        self._log_operation(
            operation="undeploy",
            entity_type="EnterpriseDeployment",
            entity_id=deployment_uuid,
            metadata={"id": id},
        )
        return True

    # ------------------------------------------------------------------
    # IDeploymentRepository: get_status
    # ------------------------------------------------------------------

    def get_status(
        self,
        id: str,
        ctx: "Optional[object]" = None,
    ) -> str:
        """Return the current status string for a deployment.

        Parameters
        ----------
        id:
            Deployment UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        str
            Status string, e.g. ``"deployed"``, ``"undeployed"``.

        Raises
        ------
        KeyError
            If no deployment with *id* exists in this tenant.
        """
        try:
            deployment_uuid = _ensure_uuid(id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(id) from exc

        row = self._fetch_deployment(deployment_uuid)
        if row is None:
            raise KeyError(id)

        return row.status or "deployed"

    # ------------------------------------------------------------------
    # IDeploymentRepository: get_by_artifact
    # ------------------------------------------------------------------

    def get_by_artifact(
        self,
        identifier: "str | uuid.UUID",
        ctx: "Optional[object]" = None,
    ) -> "list[DeploymentDTO]":
        """Return all deployments for a given artifact.

        Accepts either a stable UUID (preferred, per ADR-007) or a legacy
        ``"type:name"`` composite string (retained during the deprecation
        window).

        Parameters
        ----------
        identifier:
            Either a ``uuid.UUID`` (canonical form per ADR-007) or a composite
            ``"type:name"`` string (e.g. ``"skill:Canvas Design"``).
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[DeploymentDTO]
            All deployments for the artifact, ordered by ``deployed_at`` desc.
            Returns ``[]`` if the artifact is not found for the current tenant.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseDeployment,
        )

        if isinstance(identifier, uuid.UUID):
            # This direct-FK filter is collision-safe independent of
            # UNIQUE(tenant_id, name, type) on enterprise_artifacts because
            # artifact_uuid is a PK-backed foreign key (enterprise_artifacts.id).
            # The legacy composite branch below relies on that unique constraint
            # for safety and should be removed once the deprecation window closes.
            stmt = (
                self._tenant_select()
                .where(EnterpriseDeployment.artifact_uuid == identifier)
                .order_by(EnterpriseDeployment.deployed_at.desc())
            )
            rows = list(self.session.execute(stmt).scalars())
            return [self._to_dto(row) for row in rows]

        # DEPRECATED: composite-key lookup — prefer UUID per ADR-007. Retained for backward compatibility during deprecation window.
        try:
            art_type, art_name = str(identifier).split(":", 1)
        except ValueError:
            return []

        stmt = (
            self._tenant_select()
            .join(
                EnterpriseArtifact,
                EnterpriseArtifact.id == EnterpriseDeployment.artifact_uuid,
            )
            .where(EnterpriseArtifact.artifact_type == art_type)
            .where(EnterpriseArtifact.name == art_name)
            .order_by(EnterpriseDeployment.deployed_at.desc())
        )
        rows = list(self.session.execute(stmt).scalars())
        return [self._to_dto(row) for row in rows]

    # ------------------------------------------------------------------
    # IDeploymentRepository: get_by_project  (enterprise extra)
    # ------------------------------------------------------------------

    def get_by_project(
        self,
        project_id: str,
        ctx: "Optional[object]" = None,
    ) -> "list[DeploymentDTO]":
        """Return all deployments for a given project.

        This is an enterprise-specific helper method.  The
        :class:`~skillmeat.core.interfaces.repositories.IDeploymentRepository`
        interface exposes the same via ``list(filters={"project_id": ...})``,
        but this dedicated method is provided for clarity.

        Parameters
        ----------
        project_id:
            Project UUID as a string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[DeploymentDTO]
        """
        return self.list(filters={"project_id": project_id}, ctx=ctx)

    # ------------------------------------------------------------------
    # IDeploymentRepository: list_by_status  (enterprise extra)
    # ------------------------------------------------------------------

    def list_by_status(
        self,
        status: str,
        ctx: "Optional[object]" = None,
    ) -> "list[DeploymentDTO]":
        """Return all deployments with the given status.

        Enterprise-specific filtered query helper backed by the
        ``idx_enterprise_deployments_tenant_status`` index.

        Parameters
        ----------
        status:
            Deployment status string, e.g. ``"deployed"``, ``"undeployed"``.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        list[DeploymentDTO]
        """
        return self.list(filters={"status": status}, ctx=ctx)

    # ------------------------------------------------------------------
    # IDeploymentRepository: upsert_idp_deployment_set
    # ------------------------------------------------------------------

    def upsert_idp_deployment_set(
        self,
        *,
        remote_url: str,
        name: str,
        provisioned_by: str,
        description: "Optional[str]" = None,
        bundle_id: "Optional[str]" = None,
        bundle_version: "Optional[str]" = None,
        platform: "Optional[str]" = None,
        requested_by: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> "Tuple[str, bool]":
        """Idempotently create or update a DeploymentSet for an IDP registration.

        Parameters
        ----------
        remote_url:
            Remote Git repository URL.
        name:
            Artifact target identifier used as the set name.
        provisioned_by:
            Audit field identifying the provisioning agent.
        description:
            Optional JSON-serialised metadata string.
        bundle_id:
            Optional UUID or slug of the associated bundle.
        bundle_version:
            Optional version string of the associated bundle.
        platform:
            Optional deployment platform identifier.
        requested_by:
            Optional user identity string (e.g. from ``X-Backstage-User-Entity``
            header).  Accepted for interface compatibility; not yet persisted
            because ``EnterpriseDeploymentSet`` does not have a ``requested_by``
            column in the current schema.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        tuple[str, bool]
            ``(deployment_set_id, created)`` where *created* is ``True``
            when a new record was inserted.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentSet

        tenant_id = self._get_tenant_id()

        stmt = select(EnterpriseDeploymentSet).where(
            EnterpriseDeploymentSet.tenant_id == tenant_id,
            EnterpriseDeploymentSet.remote_url == remote_url,
            EnterpriseDeploymentSet.name == name,
        )
        row = self.session.execute(stmt).scalar_one_or_none()

        created = False
        if row is None:
            row = EnterpriseDeploymentSet(
                tenant_id=tenant_id,
                remote_url=remote_url,
                name=name,
                provisioned_by=provisioned_by,
                description=description,
                bundle_id=bundle_id,
                bundle_version=bundle_version,
                platform=platform,
            )
            self.session.add(row)
            created = True
        else:
            row.provisioned_by = provisioned_by
            if description is not None:
                row.description = description
            if bundle_id is not None:
                row.bundle_id = bundle_id
            if bundle_version is not None:
                row.bundle_version = bundle_version
            if platform is not None:
                row.platform = platform
            row.updated_at = datetime.utcnow()

        self.session.flush()

        self._log_operation(
            operation="upsert_idp_deployment_set",
            entity_type="EnterpriseDeploymentSet",
            entity_id=row.id,
            metadata={
                "remote_url": remote_url,
                "name": name,
                "created": created,
            },
        )
        return str(row.id), created

    # ------------------------------------------------------------------
    # IDeploymentRepository: sync_deployment_cache
    # ------------------------------------------------------------------

    def sync_deployment_cache(
        self,
        artifact_id: str,
        project_path: str,
        project_name: str,
        deployed_at: "Any",
        content_hash: "Optional[str]" = None,
        deployment_profile_id: "Optional[str]" = None,
        local_modifications: bool = False,
        platform: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> bool:
        """Upsert a single deployment entry into the enterprise deployments table.

        Performs a write-through update: looks up an existing active
        deployment record for the ``(artifact_id, project_path)`` pair and
        updates it, or creates a new row if none exists.

        Parameters
        ----------
        artifact_id:
            Artifact primary key in ``"type:name"`` format.
        project_path:
            Stored path of the target project.
        project_name:
            Human-readable project directory name.
        deployed_at:
            Deployment timestamp (``datetime`` or ISO string).
        content_hash:
            Optional SHA of the deployed content.
        deployment_profile_id:
            Optional deployment profile identifier.
        local_modifications:
            Whether local modifications are present.
        platform:
            Optional platform identifier string.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        bool
            Always ``True`` for the enterprise backend (upsert always succeeds).
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseDeployment,
            EnterpriseProject,
        )

        tenant_id = self._get_tenant_id()

        # Resolve or create project row by stored path.
        proj_stmt = select(EnterpriseProject).where(
            EnterpriseProject.tenant_id == tenant_id,
            EnterpriseProject.path == project_path,
        )
        project_row = self.session.execute(proj_stmt).scalar_one_or_none()
        if project_row is None:
            project_row = EnterpriseProject(
                tenant_id=tenant_id,
                name=project_name,
                path=project_path,
                status="active",
            )
            self.session.add(project_row)
            self.session.flush()

        # Normalise deployed_at to a datetime.
        if isinstance(deployed_at, str):
            try:
                from datetime import timezone

                deployed_dt = datetime.fromisoformat(deployed_at)
            except (ValueError, TypeError):
                deployed_dt = datetime.utcnow()
        elif isinstance(deployed_at, datetime):
            deployed_dt = deployed_at
        else:
            deployed_dt = datetime.utcnow()

        # Look for an existing active deployment row for this artifact+project.
        existing_stmt = self._tenant_select().where(
            EnterpriseDeployment.artifact_id == artifact_id,
            EnterpriseDeployment.project_id == project_row.id,
            EnterpriseDeployment.status == "deployed",
        )
        row = self.session.execute(existing_stmt).scalar_one_or_none()

        profile_id: Optional[uuid.UUID] = None
        if deployment_profile_id:
            try:
                profile_id = _ensure_uuid(deployment_profile_id)
            except (ValueError, AttributeError):
                pass

        if row is None:
            row = EnterpriseDeployment(
                tenant_id=tenant_id,
                artifact_id=artifact_id,
                project_id=project_row.id,
                status="deployed",
                deployed_at=deployed_dt,
                content_hash=content_hash,
                deployment_profile_id=profile_id,
                local_modifications=local_modifications,
                platform=platform,
            )
            self.session.add(row)
        else:
            row.deployed_at = deployed_dt
            row.content_hash = content_hash
            row.deployment_profile_id = profile_id
            row.local_modifications = local_modifications
            row.platform = platform
            row.updated_at = datetime.utcnow()

        self.session.flush()

        self._log_operation(
            operation="sync_deployment_cache",
            entity_type="EnterpriseDeployment",
            entity_id=row.id,
            metadata={"artifact_id": artifact_id, "project_path": project_path},
        )
        return True

    # ------------------------------------------------------------------
    # IDeploymentRepository: remove_deployment_cache
    # ------------------------------------------------------------------

    def remove_deployment_cache(
        self,
        artifact_id: str,
        project_path: str,
        profile_id: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> bool:
        """Remove a deployment entry from the enterprise deployments table.

        Marks matching ``EnterpriseDeployment`` rows as ``"undeployed"``
        (soft delete) rather than physically removing them, so audit history
        is preserved.

        Parameters
        ----------
        artifact_id:
            Artifact primary key in ``"type:name"`` format.
        project_path:
            Stored path of the target project.
        profile_id:
            Optional profile ID to narrow the removal to a specific entry.
        ctx:
            Optional per-request metadata (unused by the enterprise backend).

        Returns
        -------
        bool
            ``True`` when at least one matching record was found and updated,
            ``False`` otherwise.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseDeployment,
            EnterpriseProject,
        )

        tenant_id = self._get_tenant_id()

        # Resolve project by stored path.
        proj_stmt = select(EnterpriseProject).where(
            EnterpriseProject.tenant_id == tenant_id,
            EnterpriseProject.path == project_path,
        )
        project_row = self.session.execute(proj_stmt).scalar_one_or_none()
        if project_row is None:
            logger.debug(
                "EnterpriseDeploymentRepository.remove_deployment_cache: "
                "project not found for path=%s — nothing to remove",
                project_path,
            )
            return False

        stmt = self._tenant_select().where(
            EnterpriseDeployment.artifact_id == artifact_id,
            EnterpriseDeployment.project_id == project_row.id,
        )

        if profile_id:
            try:
                prof_uuid = _ensure_uuid(profile_id)
                stmt = stmt.where(
                    EnterpriseDeployment.deployment_profile_id == prof_uuid
                )
            except (ValueError, AttributeError):
                pass

        rows = list(self.session.execute(stmt).scalars())
        if not rows:
            return False

        for row in rows:
            row.status = "undeployed"
            row.updated_at = datetime.utcnow()

        self.session.flush()

        self._log_operation(
            operation="remove_deployment_cache",
            entity_type="EnterpriseDeployment",
            entity_id=None,
            metadata={
                "artifact_id": artifact_id,
                "project_path": project_path,
                "rows_updated": len(rows),
            },
        )
        return True


# =============================================================================
# EnterpriseDeploymentSetRepository  (ENT2-4.3)
# =============================================================================


class EnterpriseDeploymentSetRepository(
    EnterpriseRepositoryBase["EnterpriseDeploymentSet"]
):
    """Enterprise repository for DeploymentSet CRUD with tenant-scoped access.

    Implements the same callable interface as the local ``DeploymentSetRepository``
    in ``repositories.py``, replacing the ``owner_id`` scope parameter with
    automatic tenant filtering via ``TenantContext``.

    Tag filtering uses the ``EnterpriseDeploymentSetTag`` join table rather
    than the ``tags_json`` TEXT column so that queries leverage the indexed
    ``tag`` column.

    FR-10 delete semantics: Before deleting a set, any
    ``EnterpriseDeploymentSetMember`` rows in *other* sets that reference the
    doomed set via ``member_set_id`` are deleted first, preventing orphan
    references.

    Usage::

        with tenant_scope(tenant_uuid):
            repo = EnterpriseDeploymentSetRepository(db_session)
            ds = repo.create(name="My Set", owner_id="user-1")
            fetched = repo.get(str(ds.id), owner_id="user-1")
            sets = repo.list(owner_id="user-1", tag="prod")
            ok = repo.delete(str(ds.id), owner_id="user-1")

    Notes
    -----
    * ``owner_id`` parameters are accepted for interface compatibility but are
      not used for filtering — tenant isolation is enforced structurally via
      ``TenantContext``.
    * SQLAlchemy 2.x ``select()`` style throughout.
    * UUID primary keys.
    """

    def __init__(self, session: Session) -> None:
        """Initialise the enterprise deployment set repository.

        Parameters
        ----------
        session:
            Injected SQLAlchemy session bound to the PostgreSQL enterprise
            database.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentSet

        super().__init__(session, EnterpriseDeploymentSet)

    # =========================================================================
    # Internal helpers
    # =========================================================================

    @staticmethod
    def _to_dto(row: "EnterpriseDeploymentSet") -> "DeploymentSetDTO":
        """Convert an :class:`EnterpriseDeploymentSet` ORM row to a :class:`DeploymentSetDTO`.

        Resolves the following ORM divergences:

        - DIV-5: enterprise ``id: UUID`` (native UUID object) → normalised to
          32-char hex string via ``row.id.hex``.
        - DIV-8: ``tenant_id`` present in enterprise model is stripped and
          must never be exposed to the router or client layer.

        Parameters
        ----------
        row:
            An ``EnterpriseDeploymentSet`` ORM instance.

        Returns
        -------
        DeploymentSetDTO
        """
        from skillmeat.core.interfaces.dtos import DeploymentSetDTO

        created = getattr(row, "created_at", None)
        updated = getattr(row, "updated_at", None)
        return DeploymentSetDTO(
            # DIV-5: enterprise PK is a UUID object — normalise to hex string.
            id=row.id.hex,
            name=row.name or "",
            description=getattr(row, "description", None),
            # DIV-8: owner_id is None for enterprise records — ownership is
            # implicit from tenant context; tenant_id is stripped entirely.
            owner_id=None,
            icon=getattr(row, "icon", None),
            tags=[],  # Tags come from EnterpriseDeploymentSetTag join table; callers must enrich.
            created_at=created.isoformat() if created is not None else None,
            updated_at=updated.isoformat() if updated is not None else None,
            member_count=0,  # Caller must populate from get_members() if needed.
        )

    def _resolve_artifact_uuids(self, artifact_ids: "List[str]") -> "Dict[str, str]":
        """Batch-resolve enterprise artifact_id text IDs to UUID hex strings.

        DIV-1 resolution: Enterprise ``EnterpriseDeploymentSetMember.artifact_id``
        stores text identifiers like ``"skill:canvas"``.  This method batch-queries
        ``EnterpriseArtifact`` to find matching UUIDs, returning a
        ``{artifact_id: uuid_hex}`` mapping.

        Each text identifier is expected to follow the ``"<type>:<name>"`` format
        (e.g. ``"skill:canvas-design"``).  Identifiers that do not contain a
        colon, or that have no matching row in ``EnterpriseArtifact``, are omitted
        from the returned mapping (callers receive ``None`` for those keys and
        should fall back to the text identifier or log a warning).

        Tenant isolation is maintained via ``_apply_tenant_filter``.

        Parameters
        ----------
        artifact_ids:
            List of text artifact identifiers to resolve.  Duplicates are
            deduplicated automatically.

        Returns
        -------
        Dict[str, str]
            Mapping from original text identifier to resolved UUID hex string.
            Entries are absent for IDs that could not be resolved.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        if not artifact_ids:
            return {}

        # Parse "type:name" pairs, skipping any that do not match the format.
        parsed: "Dict[str, tuple[str, str]]" = {}  # artifact_id -> (type, name)
        for aid in set(artifact_ids):
            if not aid:
                continue
            parts = aid.split(":", 1)
            if len(parts) != 2:
                logger.warning(
                    "EnterpriseDeploymentSetRepository: artifact_id %r does not match "
                    "'type:name' format — skipping UUID resolution",
                    aid,
                )
                continue
            artifact_type, name = parts[0].strip(), parts[1].strip()
            if artifact_type and name:
                parsed[aid] = (artifact_type, name)

        if not parsed:
            return {}

        # Collect (type, name) pairs for the IN-style batch query.
        type_name_pairs = list(parsed.values())

        # Build a batch query: fetch all EnterpriseArtifact rows whose
        # (artifact_type, name) matches any of the parsed pairs, scoped to the
        # current tenant.
        #
        # We use a Python-side filter after a tenant-scoped fetch rather than
        # constructing a complex OR chain, which keeps the SQLAlchemy 2.x
        # statement simple and avoids dialect-specific tuple IN syntax issues.
        all_types = list({t for t, _ in type_name_pairs})
        all_names = list({n for _, n in type_name_pairs})

        stmt = self._apply_tenant_filter(
            select(
                EnterpriseArtifact.artifact_type,
                EnterpriseArtifact.name,
                EnterpriseArtifact.id,
            ).where(
                EnterpriseArtifact.artifact_type.in_(all_types),
                EnterpriseArtifact.name.in_(all_names),
            )
        )
        rows = self.session.execute(stmt).all()

        # Build a lookup: (type, name) -> uuid_hex
        type_name_to_uuid: "Dict[tuple[str, str], str]" = {
            (row.artifact_type, row.name): row.id.hex for row in rows
        }

        # Map original text IDs to resolved UUIDs.
        result: "Dict[str, str]" = {}
        for aid, (artifact_type, name) in parsed.items():
            resolved = type_name_to_uuid.get((artifact_type, name))
            if resolved is not None:
                result[aid] = resolved
            else:
                logger.warning(
                    "EnterpriseDeploymentSetRepository: no EnterpriseArtifact found "
                    "for artifact_id %r (type=%r, name=%r) — artifact_uuid will be None",
                    aid,
                    artifact_type,
                    name,
                )
        return result

    @staticmethod
    def _member_to_dto(
        row: "EnterpriseDeploymentSetMember",
        resolved_uuid: "Optional[str]" = None,
    ) -> "DeploymentSetMemberDTO":
        """Convert an :class:`EnterpriseDeploymentSetMember` ORM row to a :class:`DeploymentSetMemberDTO`.

        Resolves the following ORM divergences:

        - DIV-1: enterprise ``artifact_id: str`` (text identifier like
          ``"skill:canvas"``) is resolved to a UUID hex string via the
          ``resolved_uuid`` parameter supplied by the batch resolver
          ``_resolve_artifact_uuids()``.  When ``resolved_uuid`` is ``None``
          (e.g. the artifact no longer exists in ``EnterpriseArtifact``),
          ``artifact_uuid`` is set to ``None`` to signal the gap to the caller.
        - DIV-5: enterprise ``id: UUID`` and ``set_id: UUID`` are normalised to
          hex strings.

        Parameters
        ----------
        row:
            An ``EnterpriseDeploymentSetMember`` ORM instance.
        resolved_uuid:
            Pre-resolved ADR-007 UUID hex string for the artifact, obtained by
            ``_resolve_artifact_uuids()``.  Pass ``None`` when resolution failed.

        Returns
        -------
        DeploymentSetMemberDTO
        """
        from skillmeat.core.interfaces.dtos import DeploymentSetMemberDTO

        created = getattr(row, "created_at", None)
        return DeploymentSetMemberDTO(
            # DIV-5: enterprise PKs are UUID objects — normalise to hex strings.
            id=row.id.hex,
            deployment_set_id=row.set_id.hex,
            # DIV-1 resolved: resolved_uuid comes from _resolve_artifact_uuids()
            # batch join.  None signals that the artifact was not found in
            # EnterpriseArtifact (deleted or not yet synced).
            artifact_uuid=resolved_uuid,
            artifact_type=None,  # Not stored on EnterpriseDeploymentSetMember; enrich via artifact lookup.
            artifact_name=None,  # Not stored on EnterpriseDeploymentSetMember; enrich via artifact lookup.
            position=getattr(row, "position", 0) or 0,
            config_overrides=None,
            created_at=created.isoformat() if created is not None else None,
        )

    def _sync_tags(
        self,
        deployment_set_id: uuid.UUID,
        tag_names: List[str],
    ) -> None:
        """Replace all tag associations for a deployment set.

        Deletes existing ``EnterpriseDeploymentSetTag`` rows for the set, then
        inserts one row per non-empty tag name.

        Parameters
        ----------
        deployment_set_id:
            UUID primary key of the parent deployment set.
        tag_names:
            List of tag name strings to associate with the set.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentSetTag

        tenant_id = self._get_tenant_id()

        # Clear existing tag rows for this set.
        self.session.execute(
            delete(EnterpriseDeploymentSetTag).where(
                EnterpriseDeploymentSetTag.set_id == deployment_set_id
            )
        )

        now = datetime.utcnow()
        for raw_name in tag_names:
            name = raw_name.strip()
            if not name:
                continue
            tag_row = EnterpriseDeploymentSetTag(
                id=uuid.uuid4(),
                tenant_id=tenant_id,
                set_id=deployment_set_id,
                tag=name,
                created_at=now,
            )
            self.session.add(tag_row)

    # =========================================================================
    # Create
    # =========================================================================

    def create(
        self,
        *,
        name: str,
        owner_id: str,
        description: Optional[str] = None,
        color: Optional[str] = None,
        icon: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> "EnterpriseDeploymentSet":
        """Create and return a new ``EnterpriseDeploymentSet``.

        Parameters
        ----------
        name:
            Human-readable set name (required).
        owner_id:
            Accepted for interface compatibility; tenant filtering is applied
            automatically via ``TenantContext``.
        description:
            Optional free-text description.
        color:
            Ignored — ``EnterpriseDeploymentSet`` has no ``color`` column.
            Accepted for interface parity with the local repository.
        icon:
            Ignored — ``EnterpriseDeploymentSet`` has no ``icon`` column.
            Accepted for interface parity with the local repository.
        tags:
            Optional list of tag name strings.

        Returns
        -------
        EnterpriseDeploymentSet
            Newly created and flushed instance.

        Raises
        ------
        Exception
            Re-raises any database error after rolling back the session.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentSet

        tenant_id = self._get_tenant_id()
        now = datetime.utcnow()

        ds = EnterpriseDeploymentSet(
            id=uuid.uuid4(),
            tenant_id=tenant_id,
            name=name,
            description=description,
            provisioned_by=owner_id,
            created_at=now,
            updated_at=now,
        )
        try:
            self.session.add(ds)
            self.session.flush()
            if tags:
                self._sync_tags(ds.id, tags)
            self.session.flush()
            logger.debug(
                "Created EnterpriseDeploymentSet id=%s tenant=%s",
                ds.id,
                tenant_id,
            )
            self._log_operation(
                operation="create",
                entity_type="EnterpriseDeploymentSet",
                entity_id=ds.id,
                metadata={"name": name, "owner_id": owner_id},
            )
            return ds
        except Exception:
            self.session.rollback()
            raise

    # =========================================================================
    # Read
    # =========================================================================

    def get(
        self,
        set_id: str,
        owner_id: str,
    ) -> "Optional[EnterpriseDeploymentSet]":
        """Fetch a single deployment set by ID, scoped to the current tenant.

        Parameters
        ----------
        set_id:
            String representation of the deployment set UUID.
        owner_id:
            Accepted for interface compatibility; not used for filtering.

        Returns
        -------
        EnterpriseDeploymentSet or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentSet

        try:
            set_uuid = _ensure_uuid(set_id)
        except (ValueError, AttributeError):
            return None

        stmt = self._tenant_select().where(EnterpriseDeploymentSet.id == set_uuid)
        return self.session.execute(stmt).scalar_one_or_none()

    # =========================================================================
    # List
    # =========================================================================

    def list(
        self,
        owner_id: str,
        *,
        name: Optional[str] = None,
        tag: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> "List[EnterpriseDeploymentSet]":
        """Return a paginated, filterable list of deployment sets for the current tenant.

        Parameters
        ----------
        owner_id:
            Accepted for interface compatibility; not used for filtering.
        name:
            Optional substring filter on ``name`` (case-insensitive).
        tag:
            Optional tag string to filter by; matches via the
            ``EnterpriseDeploymentSetTag`` join table.
        limit:
            Maximum rows to return (default 50).
        offset:
            Rows to skip for pagination (default 0).

        Returns
        -------
        List[EnterpriseDeploymentSet]
            Ordered by ``created_at`` descending.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseDeploymentSet,
            EnterpriseDeploymentSetTag,
        )

        stmt = self._tenant_select().order_by(EnterpriseDeploymentSet.created_at.desc())

        if name is not None:
            stmt = stmt.where(EnterpriseDeploymentSet.name.ilike(f"%{name}%"))

        if tag is not None:
            stmt = stmt.join(
                EnterpriseDeploymentSetTag,
                EnterpriseDeploymentSetTag.set_id == EnterpriseDeploymentSet.id,
            ).where(EnterpriseDeploymentSetTag.tag == tag)

        stmt = stmt.limit(limit).offset(offset)
        return list(self.session.execute(stmt).scalars())

    # =========================================================================
    # Count
    # =========================================================================

    def count(
        self,
        owner_id: str,
        *,
        name: Optional[str] = None,
        tag: Optional[str] = None,
    ) -> int:
        """Count deployment sets matching the given filters for the current tenant.

        Parameters
        ----------
        owner_id:
            Accepted for interface compatibility; not used for filtering.
        name:
            Optional substring filter on ``name``.
        tag:
            Optional tag filter.

        Returns
        -------
        int
            Count of matching sets.
        """
        from sqlalchemy import func as sa_func

        from skillmeat.cache.models_enterprise import (
            EnterpriseDeploymentSet,
            EnterpriseDeploymentSetTag,
        )

        stmt = self._apply_tenant_filter(
            select(sa_func.count(EnterpriseDeploymentSet.id))
        )

        if name is not None:
            stmt = stmt.where(EnterpriseDeploymentSet.name.ilike(f"%{name}%"))

        if tag is not None:
            stmt = stmt.join(
                EnterpriseDeploymentSetTag,
                EnterpriseDeploymentSetTag.set_id == EnterpriseDeploymentSet.id,
            ).where(EnterpriseDeploymentSetTag.tag == tag)

        return self.session.execute(stmt).scalar() or 0

    # =========================================================================
    # Update
    # =========================================================================

    def update(
        self,
        set_id: str,
        owner_id: str,
        **kwargs: object,
    ) -> "Optional[EnterpriseDeploymentSet]":
        """Update mutable fields on a deployment set.

        Accepted keyword arguments: ``name`` (str), ``description`` (str | None),
        ``tags`` (list[str]).  ``color`` and ``icon`` are silently ignored as
        ``EnterpriseDeploymentSet`` has no such columns.  ``updated_at`` is
        refreshed on every successful update.

        Parameters
        ----------
        set_id:
            String UUID of the deployment set to update.
        owner_id:
            Accepted for interface compatibility; not used for filtering.
        **kwargs:
            Keyword arguments for fields to update.

        Returns
        -------
        EnterpriseDeploymentSet or None
            Updated instance, or ``None`` if not found.

        Raises
        ------
        Exception
            Re-raises any database error after rolling back the session.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentSet

        try:
            set_uuid = _ensure_uuid(set_id)
        except (ValueError, AttributeError):
            return None

        stmt = self._tenant_select().where(EnterpriseDeploymentSet.id == set_uuid)
        ds = self.session.execute(stmt).scalar_one_or_none()
        if ds is None:
            return None

        try:
            if "name" in kwargs:
                ds.name = kwargs["name"]  # type: ignore[assignment]
            if "description" in kwargs:
                ds.description = kwargs["description"]  # type: ignore[assignment]
            if "tags" in kwargs:
                tag_list = kwargs["tags"]
                self._sync_tags(ds.id, list(tag_list) if tag_list else [])  # type: ignore[arg-type]

            ds.updated_at = datetime.utcnow()
            self.session.flush()
            logger.debug(
                "Updated EnterpriseDeploymentSet id=%s tenant=%s",
                set_id,
                self._get_tenant_id(),
            )
            self._log_operation(
                operation="update",
                entity_type="EnterpriseDeploymentSet",
                entity_id=ds.id,
                metadata={"fields": list(kwargs.keys())},
            )
            return ds
        except Exception:
            self.session.rollback()
            raise

    # =========================================================================
    # Delete  (FR-10)
    # =========================================================================

    def delete(self, set_id: str, owner_id: str) -> bool:
        """Delete a deployment set, cleaning up cross-set member references first.

        FR-10 semantics: Before deleting the target set, any
        ``EnterpriseDeploymentSetMember`` rows in *other* sets that reference the
        target via ``member_set_id`` are deleted to prevent orphan references.
        The target set's own members are removed by the ``ON DELETE CASCADE``
        on ``enterprise_deployment_set_members.set_id``.

        Parameters
        ----------
        set_id:
            String UUID of the deployment set to delete.
        owner_id:
            Accepted for interface compatibility; not used for filtering.

        Returns
        -------
        bool
            ``True`` if the set was found and deleted, ``False`` otherwise.

        Raises
        ------
        Exception
            Re-raises any database error after rolling back the session.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseDeploymentSet,
            EnterpriseDeploymentSetMember,
        )

        try:
            set_uuid = _ensure_uuid(set_id)
        except (ValueError, AttributeError):
            return False

        stmt = self._tenant_select().where(EnterpriseDeploymentSet.id == set_uuid)
        ds = self.session.execute(stmt).scalar_one_or_none()
        if ds is None:
            return False

        try:
            # FR-10: remove member rows in OTHER sets referencing this set as a
            # nested member before deleting the set itself.
            orphan_stmt = select(EnterpriseDeploymentSetMember).where(
                EnterpriseDeploymentSetMember.member_set_id == set_uuid,
                EnterpriseDeploymentSetMember.set_id != set_uuid,
            )
            orphans = list(self.session.execute(orphan_stmt).scalars())
            for member in orphans:
                self.session.delete(member)

            self.session.delete(ds)
            self.session.flush()
            logger.debug(
                "Deleted EnterpriseDeploymentSet id=%s (removed %d orphan member refs)",
                set_id,
                len(orphans),
            )
            self._log_operation(
                operation="delete",
                entity_type="EnterpriseDeploymentSet",
                entity_id=set_uuid,
                metadata={"orphan_members_removed": len(orphans)},
            )
            return True
        except Exception:
            self.session.rollback()
            raise

    # =========================================================================
    # Member management
    # =========================================================================

    def add_member(
        self,
        set_id: str,
        owner_id: str,
        *,
        artifact_id: Optional[str] = None,
        position: Optional[int] = None,
    ) -> "EnterpriseDeploymentSetMember":
        """Add a member artifact to a deployment set.

        Parameters
        ----------
        set_id:
            String UUID of the parent deployment set.
        owner_id:
            Accepted for interface compatibility; not used for filtering.
        artifact_id:
            Text artifact identifier (e.g. ``"skill:canvas"``).
        position:
            Explicit 0-based ordering position.  Auto-assigned (max + 1) when
            omitted.

        Returns
        -------
        EnterpriseDeploymentSetMember
            Newly created member row.

        Raises
        ------
        ValueError
            If the parent set does not exist in the current tenant.
        Exception
            Re-raises any database error after rolling back the session.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseDeploymentSet,
            EnterpriseDeploymentSetMember,
        )

        try:
            set_uuid = _ensure_uuid(set_id)
        except (ValueError, AttributeError) as exc:
            raise ValueError(f"Invalid set_id: {set_id!r}") from exc

        tenant_id = self._get_tenant_id()

        # Verify the parent set belongs to this tenant.
        stmt = self._tenant_select().where(EnterpriseDeploymentSet.id == set_uuid)
        ds = self.session.execute(stmt).scalar_one_or_none()
        if ds is None:
            raise ValueError(
                f"EnterpriseDeploymentSet {set_id!r} not found for current tenant"
            )

        # Auto-assign position if not supplied.
        if position is None:
            pos_stmt = select(EnterpriseDeploymentSetMember.position).where(
                EnterpriseDeploymentSetMember.set_id == set_uuid
            )
            positions = list(self.session.execute(pos_stmt).scalars())
            position = (max(positions) + 1) if positions else 0

        try:
            member = EnterpriseDeploymentSetMember(
                id=uuid.uuid4(),
                tenant_id=tenant_id,
                set_id=set_uuid,
                artifact_id=artifact_id or "",
                position=position,
            )
            self.session.add(member)
            self.session.flush()
            logger.debug(
                "Added member artifact_id=%s to EnterpriseDeploymentSet id=%s",
                artifact_id,
                set_id,
            )
            return member
        except Exception:
            self.session.rollback()
            raise

    def remove_member(
        self,
        set_id: str,
        owner_id: str,
        artifact_id: str,
    ) -> bool:
        """Remove a member artifact from a deployment set.

        Parameters
        ----------
        set_id:
            String UUID of the parent deployment set.
        owner_id:
            Accepted for interface compatibility; not used for filtering.
        artifact_id:
            Text artifact identifier of the member to remove.

        Returns
        -------
        bool
            ``True`` if a matching member was found and deleted, ``False``
            otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentSetMember

        try:
            set_uuid = _ensure_uuid(set_id)
        except (ValueError, AttributeError):
            return False

        stmt = select(EnterpriseDeploymentSetMember).where(
            EnterpriseDeploymentSetMember.set_id == set_uuid,
            EnterpriseDeploymentSetMember.artifact_id == artifact_id,
            EnterpriseDeploymentSetMember.tenant_id == self._get_tenant_id(),
        )
        member = self.session.execute(stmt).scalar_one_or_none()
        if member is None:
            return False

        try:
            self.session.delete(member)
            self.session.flush()
            return True
        except Exception:
            self.session.rollback()
            raise

    def list_members(
        self,
        set_id: str,
        owner_id: str,
    ) -> "List[EnterpriseDeploymentSetMember]":
        """List all members of a deployment set ordered by position.

        Parameters
        ----------
        set_id:
            String UUID of the parent deployment set.
        owner_id:
            Accepted for interface compatibility; not used for filtering.

        Returns
        -------
        List[EnterpriseDeploymentSetMember]
            Members ordered by ``position`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentSetMember

        try:
            set_uuid = _ensure_uuid(set_id)
        except (ValueError, AttributeError):
            return []

        stmt = (
            select(EnterpriseDeploymentSetMember)
            .where(EnterpriseDeploymentSetMember.set_id == set_uuid)
            .order_by(EnterpriseDeploymentSetMember.position.asc())
        )
        return list(self.session.execute(stmt).scalars())

    def get_members(
        self,
        set_id: str,
        owner_id: str,
    ) -> "List[EnterpriseDeploymentSetMember]":
        """Return all members of a deployment set ordered by position.

        Verifies that the parent deployment set belongs to the current tenant;
        returns ``[]`` when the set does not exist (never raises).  This method
        is the enterprise equivalent of ``DeploymentSetRepository.get_members``
        in ``repositories.py``.

        Parameters
        ----------
        set_id:
            String UUID of the parent deployment set.
        owner_id:
            Accepted for interface compatibility; NOT used for filtering —
            tenant isolation is enforced structurally via ``TenantContext``.

        Returns
        -------
        List[EnterpriseDeploymentSetMember]
            Member rows ordered by ``position`` ascending.  Empty list when
            the set is not found for the current tenant.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseDeploymentSet,
            EnterpriseDeploymentSetMember,
        )

        try:
            set_uuid = _ensure_uuid(set_id)
        except (ValueError, AttributeError):
            return []

        # Verify the parent set exists within the current tenant.
        ds_stmt = self._tenant_select().where(EnterpriseDeploymentSet.id == set_uuid)
        ds = self.session.execute(ds_stmt).scalar_one_or_none()
        if ds is None:
            return []

        member_stmt = (
            select(EnterpriseDeploymentSetMember)
            .where(EnterpriseDeploymentSetMember.set_id == set_uuid)
            .order_by(EnterpriseDeploymentSetMember.position.asc())
        )
        return list(self.session.execute(member_stmt).scalars())

    def get_member_dtos(
        self,
        set_id: str,
        owner_id: str,
    ) -> "List[DeploymentSetMemberDTO]":
        """Return all members of a deployment set as :class:`DeploymentSetMemberDTO` objects.

        This is the DTO-returning companion to :meth:`get_members`.  It uses
        :meth:`_resolve_artifact_uuids` to batch-resolve the enterprise
        ``artifact_id`` text identifiers (e.g. ``"skill:canvas"``) to ADR-007
        UUID hex strings before constructing the DTOs, eliminating the N+1
        per-member lookup that the router layer previously performed.

        DIV-1 resolution: All artifact text IDs are resolved in a single
        ``SELECT … WHERE artifact_type IN (…) AND name IN (…)`` query rather
        than one round-trip per member.

        Parameters
        ----------
        set_id:
            String UUID of the parent deployment set.
        owner_id:
            Accepted for interface compatibility; NOT used for filtering —
            tenant isolation is enforced structurally via ``TenantContext``.

        Returns
        -------
        List[DeploymentSetMemberDTO]
            DTO list ordered by ``position`` ascending.  Empty list when
            the set is not found for the current tenant.
        """
        from skillmeat.core.interfaces.dtos import DeploymentSetMemberDTO  # noqa: F401

        members = self.get_members(set_id, owner_id)
        if not members:
            return []

        # Batch-resolve all artifact text IDs to UUID hex strings (DIV-1).
        artifact_ids = [getattr(m, "artifact_id", None) or "" for m in members]
        uuid_map = self._resolve_artifact_uuids([aid for aid in artifact_ids if aid])

        return [
            self._member_to_dto(
                m,
                resolved_uuid=uuid_map.get(getattr(m, "artifact_id", None) or ""),
            )
            for m in members
        ]

    def update_member_position(
        self,
        member_id: str,
        owner_id: str,
        position: int,
    ) -> "Optional[EnterpriseDeploymentSetMember]":
        """Update the ordering ``position`` of a deployment set member.

        Fetches the member by *member_id* UUID and joins to the parent
        deployment set through the tenant filter to ensure isolation.  Sets
        ``member.position = position`` and flushes the session.

        Parameters
        ----------
        member_id:
            String UUID of the ``EnterpriseDeploymentSetMember`` row.
        owner_id:
            Accepted for interface compatibility; NOT used for filtering.
        position:
            New 0-based position value.

        Returns
        -------
        EnterpriseDeploymentSetMember or None
            Updated member ORM row, or ``None`` if the member was not found
            for the current tenant.
        """
        from sqlalchemy import join as sa_join

        from skillmeat.cache.models_enterprise import (
            EnterpriseDeploymentSet,
            EnterpriseDeploymentSetMember,
        )

        try:
            member_uuid = _ensure_uuid(member_id)
        except (ValueError, AttributeError):
            return None

        tenant_id = self._get_tenant_id()

        # Join member → set, filter by tenant on the set side.
        stmt = (
            select(EnterpriseDeploymentSetMember)
            .join(
                EnterpriseDeploymentSet,
                EnterpriseDeploymentSet.id == EnterpriseDeploymentSetMember.set_id,
            )
            .where(EnterpriseDeploymentSetMember.id == member_uuid)
            .where(EnterpriseDeploymentSet.tenant_id == tenant_id)
        )
        member = self.session.execute(stmt).scalar_one_or_none()
        if member is None:
            return None

        member.position = position
        self.session.flush()
        return member


# =============================================================================
# EnterpriseDeploymentProfileRepository  (ENT2-4.4)
# =============================================================================


class EnterpriseDeploymentProfileRepository(
    EnterpriseRepositoryBase["EnterpriseDeploymentProfile"]
):
    """Enterprise repository for DeploymentProfile CRUD with tenant-scoped access.

    Implements the same callable interface as the local ``DeploymentProfileRepository``
    in ``repositories.py``.

    The ``EnterpriseDeploymentProfile`` model stores flexible configuration in
    the ``extra_metadata`` JSONB column (NOT ``metadata`` — that name conflicts
    with SQLAlchemy's reserved ``DeclarativeBase.metadata`` attribute).

    Usage::

        with tenant_scope(tenant_uuid):
            repo = EnterpriseDeploymentProfileRepository(db_session)
            profile = repo.create(
                project_id="proj-1",
                profile_id="claude_code",
                platform="claude_code",
                root_dir=".claude",
            )
            fetched = repo.read_by_project_and_profile_id("proj-1", "claude_code")

    Notes
    -----
    * ``project_id`` parameters are stored in ``extra_metadata["project_id"]``
      since ``EnterpriseDeploymentProfile`` has no dedicated ``project_id``
      column.
    * ``profile_id`` is stored as a plain name tag in ``extra_metadata["profile_id"]``.
    * SQLAlchemy 2.x ``select()`` style throughout.
    * UUID primary keys.
    """

    def __init__(self, session: Session) -> None:
        """Initialise the enterprise deployment profile repository.

        Parameters
        ----------
        session:
            Injected SQLAlchemy session bound to the PostgreSQL enterprise
            database.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentProfile

        super().__init__(session, EnterpriseDeploymentProfile)

    # =========================================================================
    # DTO converter
    # =========================================================================

    @staticmethod
    def _to_dto(model: "EnterpriseDeploymentProfile") -> "DeploymentProfileDTO":
        """Convert an ``EnterpriseDeploymentProfile`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.DeploymentProfileDTO`.

        Parameters
        ----------
        model:
            ORM instance to convert.

        Returns
        -------
        DeploymentProfileDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import DeploymentProfileDTO

        return DeploymentProfileDTO(
            id=str(model.id),
            tenant_id=str(model.tenant_id),
            name=model.name,
            scope=model.scope,
            dest_path=model.dest_path,
            overwrite=bool(model.overwrite),
            platform=model.platform,
            extra_metadata=dict(model.extra_metadata) if model.extra_metadata else {},
            created_at=model.created_at.isoformat() if model.created_at else None,
            updated_at=model.updated_at.isoformat() if model.updated_at else None,
        )

    # =========================================================================
    # Create
    # =========================================================================

    def create(
        self,
        *,
        project_id: str,
        profile_id: str,
        platform: str,
        root_dir: str,
        description: Optional[str] = None,
        artifact_path_map: Optional[Dict[str, str]] = None,
        config_filenames: Optional[List[str]] = None,
        context_prefixes: Optional[List[str]] = None,
        supported_types: Optional[List[str]] = None,
    ) -> "DeploymentProfileDTO":
        """Create a deployment profile.

        Parameters
        ----------
        project_id:
            Project identifier; stored in ``extra_metadata["project_id"]``.
        profile_id:
            Profile identifier string (e.g. ``"claude_code"``); stored in
            ``extra_metadata["profile_id"]``.
        platform:
            Target platform string (e.g. ``"claude_code"``).
        root_dir:
            Destination root directory (e.g. ``".claude"``).
        description:
            Optional free-text description.
        artifact_path_map:
            Optional mapping of artifact type to destination path.
        config_filenames:
            Optional list of config file names for this profile.
        context_prefixes:
            Optional list of context path prefixes.
        supported_types:
            Optional list of artifact type strings this profile supports.

        Returns
        -------
        DeploymentProfileDTO
            DTO representation of the newly created and flushed instance.

        Raises
        ------
        Exception
            Re-raises any database error after rolling back.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentProfile

        tenant_id = self._get_tenant_id()
        now = datetime.utcnow()

        meta: Dict[str, object] = {
            "project_id": project_id,
            "profile_id": profile_id,
            "root_dir": root_dir,
        }
        if artifact_path_map is not None:
            meta["artifact_path_map"] = artifact_path_map
        if config_filenames is not None:
            meta["config_filenames"] = config_filenames
        if context_prefixes is not None:
            meta["context_prefixes"] = context_prefixes
        if supported_types is not None:
            meta["supported_types"] = supported_types

        profile = EnterpriseDeploymentProfile(
            id=uuid.uuid4(),
            tenant_id=tenant_id,
            name=f"{project_id}/{profile_id}",
            scope="project",
            dest_path=root_dir,
            platform=platform,
            overwrite=False,
            extra_metadata=meta,
            created_at=now,
            updated_at=now,
        )
        if description is not None:
            # Store in extra_metadata since the model has no description column.
            profile.extra_metadata = {**meta, "description": description}

        try:
            self.session.add(profile)
            self.session.flush()
            logger.debug(
                "Created EnterpriseDeploymentProfile id=%s project=%s profile_id=%s",
                profile.id,
                project_id,
                profile_id,
            )
            self._log_operation(
                operation="create",
                entity_type="EnterpriseDeploymentProfile",
                entity_id=profile.id,
                metadata={"project_id": project_id, "profile_id": profile_id},
            )
            return self._to_dto(profile)
        except Exception:
            self.session.rollback()
            raise

    # =========================================================================
    # Read
    # =========================================================================

    def read_by_id(self, profile_db_id: str) -> "Optional[DeploymentProfileDTO]":
        """Read a deployment profile by its UUID primary key.

        Parameters
        ----------
        profile_db_id:
            String representation of the profile UUID.

        Returns
        -------
        DeploymentProfileDTO or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentProfile

        try:
            profile_uuid = _ensure_uuid(profile_db_id)
        except (ValueError, AttributeError):
            return None

        stmt = self._tenant_select().where(
            EnterpriseDeploymentProfile.id == profile_uuid
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._to_dto(row) if row is not None else None

    def read_by_project_and_profile_id(
        self, project_id: str, profile_id: str
    ) -> "Optional[DeploymentProfileDTO]":
        """Read a deployment profile by project and profile ID.

        Matches against ``extra_metadata["project_id"]`` and
        ``extra_metadata["profile_id"]`` stored in the JSONB column.

        Parameters
        ----------
        project_id:
            Project identifier.
        profile_id:
            Profile identifier string (e.g. ``"claude_code"``).

        Returns
        -------
        DeploymentProfileDTO or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentProfile

        # Construct a JSONB containment filter: extra_metadata @> {...}
        # This requires the psycopg2 / asyncpg JSONB operator support.
        # We use the canonical name match as a fallback via the stored name.
        canonical_name = f"{project_id}/{profile_id}"
        stmt = self._tenant_select().where(
            EnterpriseDeploymentProfile.name == canonical_name
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._to_dto(row) if row is not None else None

    # =========================================================================
    # List
    # =========================================================================

    def list_by_project(self, project_id: str) -> "List[DeploymentProfileDTO]":
        """List all deployment profiles for a project.

        Matches profiles whose ``name`` starts with ``"{project_id}/"``
        (the canonical naming format used by ``create()``).

        Parameters
        ----------
        project_id:
            Project identifier.

        Returns
        -------
        List[DeploymentProfileDTO]
            Profiles ordered by ``name`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentProfile

        stmt = (
            self._tenant_select()
            .where(EnterpriseDeploymentProfile.name.like(f"{project_id}/%"))
            .order_by(EnterpriseDeploymentProfile.name.asc())
        )
        return [self._to_dto(row) for row in self.session.execute(stmt).scalars()]

    def list_all_profiles(self, project_id: str) -> "List[DeploymentProfileDTO]":
        """Alias for ``list_by_project()`` — interface parity with local repo.

        Parameters
        ----------
        project_id:
            Project identifier.

        Returns
        -------
        List[DeploymentProfileDTO]
        """
        return self.list_by_project(project_id)

    # =========================================================================
    # Platform / primary-profile helpers
    # =========================================================================

    def get_profile_by_platform(
        self,
        project_id: str,
        platform: "str | object",
    ) -> "Optional[DeploymentProfileDTO]":
        """Get the first deployment profile matching a project and platform.

        Parameters
        ----------
        project_id:
            Project identifier.
        platform:
            Platform string or enum with ``.value``.

        Returns
        -------
        DeploymentProfileDTO or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentProfile

        platform_value = (
            platform.value  # type: ignore[union-attr]
            if hasattr(platform, "value")
            else str(platform)
        )
        stmt = (
            self._tenant_select()
            .where(
                EnterpriseDeploymentProfile.name.like(f"{project_id}/%"),
                EnterpriseDeploymentProfile.platform == platform_value,
            )
            .order_by(EnterpriseDeploymentProfile.name.asc())
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._to_dto(row) if row is not None else None

    def get_primary_profile(self, project_id: str) -> "Optional[DeploymentProfileDTO]":
        """Get the primary deployment profile for a project.

        Preference order:
        1. Explicit ``claude_code`` platform profile.
        2. Profile whose name ends with ``/claude_code``.
        3. First profile alphabetically.

        Parameters
        ----------
        project_id:
            Project identifier.

        Returns
        -------
        DeploymentProfileDTO or None
        """
        primary = self.get_profile_by_platform(project_id, "claude_code")
        if primary:
            return primary

        profile = self.read_by_project_and_profile_id(project_id, "claude_code")
        if profile:
            return profile

        profiles = self.list_by_project(project_id)
        return profiles[0] if profiles else None

    def ensure_default_claude_profile(self, project_id: str) -> "DeploymentProfileDTO":
        """Ensure a backward-compatible default Claude Code profile exists.

        Returns an existing profile if one is found; otherwise creates a new
        ``claude_code`` profile with sensible defaults.

        Parameters
        ----------
        project_id:
            Project identifier.

        Returns
        -------
        DeploymentProfileDTO
        """
        primary = self.get_primary_profile(project_id)
        if primary:
            return primary

        return self.create(
            project_id=project_id,
            profile_id="claude_code",
            platform="claude_code",
            root_dir=".claude",
            artifact_path_map={
                "skill": ".claude/skills",
                "command": ".claude/commands",
                "agent": ".claude/agents",
                "hook": ".claude/hooks",
                "mcp": ".claude/mcp",
            },
            config_filenames=["CLAUDE.md", "settings.json"],
            context_prefixes=[".claude/context/", ".claude/"],
            supported_types=["skill", "command", "agent", "hook", "mcp"],
        )

    def get_project_id_by_path(self, project_path: str) -> "Optional[str]":
        """Return the project ID for the given filesystem path.

        Delegates to the ``EnterpriseProject`` table.

        Parameters
        ----------
        project_path:
            Absolute path string to match against ``EnterpriseProject.path``.

        Returns
        -------
        str or None
            Project ID string when a matching row exists, ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProject

        tenant_id = self._get_tenant_id()
        stmt = select(EnterpriseProject).where(
            EnterpriseProject.tenant_id == tenant_id,
            EnterpriseProject.path == project_path,
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return str(row.id) if row else None

    # =========================================================================
    # Update
    # =========================================================================

    def update(
        self,
        project_id: str,
        profile_id: str,
        **updates: object,
    ) -> "Optional[DeploymentProfileDTO]":
        """Update an existing deployment profile.

        Parameters
        ----------
        project_id:
            Project identifier.
        profile_id:
            Profile identifier string.
        **updates:
            Keyword arguments for fields to update.  Supported: ``platform``,
            ``dest_path``, ``scope``, ``overwrite``, ``extra_metadata``.
            Any key present in ``extra_metadata`` is merged in.

        Returns
        -------
        DeploymentProfileDTO or None
            DTO of the updated instance, or ``None`` if not found.

        Raises
        ------
        Exception
            Re-raises any database error after rolling back.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentProfile

        # Fetch the raw ORM row (we need the mutable ORM object to mutate).
        canonical_name = f"{project_id}/{profile_id}"
        stmt = self._tenant_select().where(
            EnterpriseDeploymentProfile.name == canonical_name
        )
        profile = self.session.execute(stmt).scalar_one_or_none()
        if profile is None:
            return None

        try:
            direct_fields = {"platform", "dest_path", "scope", "overwrite"}
            meta_updates: Dict[str, object] = {}

            for key, value in updates.items():
                if key in direct_fields and value is not None:
                    setattr(profile, key, value)
                elif key not in {"project_id", "profile_id"}:
                    meta_updates[key] = value

            if meta_updates:
                existing_meta = profile.extra_metadata or {}
                profile.extra_metadata = {**existing_meta, **meta_updates}

            profile.updated_at = datetime.utcnow()
            self.session.flush()
            logger.debug(
                "Updated EnterpriseDeploymentProfile name=%s/%s",
                project_id,
                profile_id,
            )
            self._log_operation(
                operation="update",
                entity_type="EnterpriseDeploymentProfile",
                entity_id=profile.id,
                metadata={"project_id": project_id, "profile_id": profile_id},
            )
            return self._to_dto(profile)
        except Exception:
            self.session.rollback()
            raise

    # =========================================================================
    # Delete
    # =========================================================================

    def delete(self, project_id: str, profile_id: str) -> bool:
        """Delete a deployment profile by project and profile ID.

        Parameters
        ----------
        project_id:
            Project identifier.
        profile_id:
            Profile identifier string.

        Returns
        -------
        bool
            ``True`` if found and deleted, ``False`` otherwise.

        Raises
        ------
        Exception
            Re-raises any database error after rolling back.
        """
        from skillmeat.cache.models_enterprise import EnterpriseDeploymentProfile

        # Fetch raw ORM row (cannot session.delete() a DTO).
        canonical_name = f"{project_id}/{profile_id}"
        stmt = self._tenant_select().where(
            EnterpriseDeploymentProfile.name == canonical_name
        )
        profile = self.session.execute(stmt).scalar_one_or_none()
        if profile is None:
            return False

        try:
            self.session.delete(profile)
            self.session.flush()
            logger.debug(
                "Deleted EnterpriseDeploymentProfile name=%s/%s",
                project_id,
                profile_id,
            )
            self._log_operation(
                operation="delete",
                entity_type="EnterpriseDeploymentProfile",
                entity_id=profile.id,
                metadata={"project_id": project_id, "profile_id": profile_id},
            )
            return True
        except Exception:
            self.session.rollback()
            raise


# =============================================================================
# EnterpriseMarketplaceSourceRepository  (ENT2-5.1)
# =============================================================================


class EnterpriseMarketplaceSourceRepository(
    EnterpriseRepositoryBase["EnterpriseMarketplaceSource"],
):
    """Enterprise repository for marketplace source and catalog-entry operations.

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IMarketplaceSourceRepository`
    for the enterprise PostgreSQL backend.

    The enterprise model (``EnterpriseMarketplaceSource``) is GitHub-repo-
    centric — each row represents a scanned GitHub repository — whereas the
    interface's :class:`~skillmeat.core.interfaces.dtos.MarketplaceSourceDTO`
    uses broker-centric terminology (``endpoint``, ``supports_publish``).
    The ``_source_to_dto`` helper bridges the two schemas by mapping:

    - ``repo_url`` → ``endpoint``
    - ``name`` synthesised as ``"owner/repo_name"``
    - ``scan_status == "done"`` → ``enabled = True``
    - ``supports_publish = False`` (GitHub repos are read-only sources)

    Catalog operations are backed by ``EnterpriseMarketplaceCatalogEntry``
    which has a leaner schema than the local SQLite catalog model (no
    ``excluded_at``, ``excluded_reason``, or ``path_segments`` columns).
    Methods that reference those local-only columns are implemented with
    best-effort equivalents using the available ``status`` column.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Notes
    -----
    * SQLAlchemy 2.x ``select()`` style throughout.
    * ``_apply_tenant_filter()`` is called on every query.
    * UUID primary keys for both sources and catalog entries.
    * ``import_item`` and ``get_composite_members`` are not directly
      supported by the enterprise schema; both return empty results and
      log a debug note.  Full implementation is deferred to v3.
    """

    def __init__(self, session: Session) -> None:
        """Initialise the enterprise marketplace source repository.

        Parameters
        ----------
        session:
            Injected SQLAlchemy session bound to the PostgreSQL enterprise
            database.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        super().__init__(session, EnterpriseMarketplaceSource)

    # ------------------------------------------------------------------
    # DTO helpers
    # ------------------------------------------------------------------

    def _source_to_dto(
        self, row: "EnterpriseMarketplaceSource"
    ) -> "MarketplaceSourceDTO":
        """Convert an ``EnterpriseMarketplaceSource`` ORM row to a DTO.

        Parameters
        ----------
        row:
            ORM instance to convert.

        Returns
        -------
        MarketplaceSourceDTO
        """
        from skillmeat.core.interfaces.dtos import MarketplaceSourceDTO

        name = (
            f"{row.owner}/{row.repo_name}"
            if row.owner and row.repo_name
            else (row.owner or row.repo_name or str(row.id))
        )
        enabled = row.scan_status in ("done", "success") if row.scan_status else False
        return MarketplaceSourceDTO(
            id=str(row.id),
            name=name,
            enabled=enabled,
            endpoint=row.repo_url or "",
            description=row.description,
            supports_publish=row.supports_publish,
            created_at=row.created_at.isoformat() if row.created_at else None,
            updated_at=row.updated_at.isoformat() if row.updated_at else None,
        )

    def _entry_to_catalog_dto(
        self, row: "EnterpriseMarketplaceCatalogEntry"
    ) -> "CatalogItemDTO":
        """Convert an ``EnterpriseMarketplaceCatalogEntry`` ORM row to a DTO.

        Parameters
        ----------
        row:
            ORM instance to convert.

        Returns
        -------
        CatalogItemDTO
        """
        from skillmeat.core.interfaces.dtos import CatalogItemDTO

        return CatalogItemDTO(
            listing_id=str(row.id),
            name=row.name or "",
            source_id=str(row.source_id),
            publisher=row.publisher,
            description=row.description,
            license=None,
            version=row.detected_sha,
            artifact_count=1,
            tags=[row.artifact_type] if row.artifact_type else [],
            source_url=row.upstream_url,
            bundle_url=row.bundle_url,
            signature=row.signature,
            downloads=0,
            rating=float(row.rating) if row.rating is not None else None,
            price=float(row.price) if row.price is not None else None,
            created_at=row.created_at.isoformat() if row.created_at else None,
        )

    # ------------------------------------------------------------------
    # Source CRUD — IMarketplaceSourceRepository
    # ------------------------------------------------------------------

    def list_paginated(
        self, limit: int = 50, cursor: "Optional[str]" = None
    ) -> "PaginatedResult":
        """List marketplace sources with cursor-based pagination.

        Uses UUID-keyed cursor pagination for stable, efficient paging through
        large result sets without the performance penalty of OFFSET.

        Parameters
        ----------
        limit:
            Maximum number of items to return per page (default: 50).
        cursor:
            Opaque cursor string from the previous page's ``next_cursor``
            field.  Pass ``None`` (or omit) to start from the first page.

        Returns
        -------
        PaginatedResult
            Container with ``items`` (list of ``EnterpriseMarketplaceSource``
            ORM rows), ``next_cursor`` (str UUID or ``None``), and
            ``has_more`` (bool).

        Notes
        -----
        * Pagination is ordered by primary-key UUID, which is monotonically
          increasing (UUID v4 ordering is lexicographic on the hex string
          representation as stored in PostgreSQL's ``uuid`` column type).
        * SQLAlchemy 2.x ``select()`` style — no ``session.query()`` here.
        * ``_apply_tenant_filter`` is always applied so cross-tenant leakage
          is impossible.
        """
        import uuid as _uuid

        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource
        from skillmeat.cache.repositories import PaginatedResult

        stmt = select(EnterpriseMarketplaceSource)
        stmt = self._apply_tenant_filter(stmt)

        if cursor:
            try:
                cursor_uuid = _ensure_uuid(cursor)
                stmt = stmt.where(EnterpriseMarketplaceSource.id > cursor_uuid)
            except ValueError:
                logger.debug(
                    "EnterpriseMarketplaceSourceRepository.list_paginated: "
                    "invalid cursor UUID %r — ignoring",
                    cursor,
                )

        stmt = stmt.order_by(EnterpriseMarketplaceSource.id)

        # Fetch limit + 1 to detect whether another page follows.
        rows = list(self.session.execute(stmt.limit(limit + 1)).scalars())

        has_more = len(rows) > limit
        if has_more:
            rows = rows[:limit]

        next_cursor = str(rows[-1].id) if rows and has_more else None

        logger.debug(
            "EnterpriseMarketplaceSourceRepository.list_paginated: "
            "returned %d items (cursor=%r, has_more=%s)",
            len(rows),
            cursor,
            has_more,
        )

        return PaginatedResult(
            items=rows,
            next_cursor=next_cursor,
            has_more=has_more,
        )

    def list_sources(
        self,
        filters: "Optional[Dict[str, object]]" = None,
        ctx: "Optional[object]" = None,
    ) -> "List[MarketplaceSourceDTO]":
        """Return all marketplace sources for the current tenant.

        Parameters
        ----------
        filters:
            Optional filter map.  Supported keys: ``enabled`` (bool).
        ctx:
            Optional per-request metadata (unused by enterprise backend).

        Returns
        -------
        list[MarketplaceSourceDTO]
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        stmt = self._tenant_select().order_by(
            EnterpriseMarketplaceSource.created_at.asc()
        )
        rows = list(self.session.execute(stmt).scalars())

        dtos = [self._source_to_dto(r) for r in rows]

        if filters and "enabled" in filters:
            want_enabled = bool(filters["enabled"])
            dtos = [d for d in dtos if d.enabled == want_enabled]

        return dtos

    def get_source(
        self,
        source_id: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[MarketplaceSourceDTO]":
        """Return a marketplace source by its identifier.

        Parameters
        ----------
        source_id:
            UUID string of the source row.
        ctx:
            Optional per-request metadata (unused by enterprise backend).

        Returns
        -------
        MarketplaceSourceDTO or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        try:
            uid = (
                uuid.UUID(source_id)
                if not isinstance(source_id, uuid.UUID)
                else source_id
            )
        except ValueError:
            logger.debug(
                "EnterpriseMarketplaceSourceRepository.get_source: invalid UUID %r",
                source_id,
            )
            return None

        stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceSource).where(
                EnterpriseMarketplaceSource.id == uid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._source_to_dto(row) if row is not None else None

    def create_source(
        self,
        name: str,
        endpoint: str,
        enabled: bool = True,
        description: "Optional[str]" = None,
        supports_publish: bool = False,
        ctx: "Optional[object]" = None,
    ) -> "MarketplaceSourceDTO":
        """Register a new marketplace source.

        Maps the broker-centric interface fields onto the GitHub-repo-centric
        enterprise schema: ``endpoint`` is stored as ``repo_url``,
        ``name`` is parsed into ``owner``/``repo_name`` when it contains a
        ``"/"`` separator.  ``enabled`` is translated to an initial
        ``scan_status``.

        Parameters
        ----------
        name:
            Human-readable name (``"owner/repo"`` convention for GitHub repos).
        endpoint:
            Base URL for the broker API / repository URL.
        enabled:
            Whether to activate the source immediately.
        description:
            Ignored by the enterprise backend (no description column on source).
        supports_publish:
            Ignored by the enterprise backend (GitHub sources are read-only).
        ctx:
            Optional per-request metadata (unused by enterprise backend).

        Returns
        -------
        MarketplaceSourceDTO
            The created source.

        Raises
        ------
        ValueError
            If a source with the same ``endpoint`` (repo URL) already exists
            for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        # Check uniqueness within tenant.
        existing_stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceSource).where(
                EnterpriseMarketplaceSource.repo_url == endpoint
            )
        )
        existing = self.session.execute(existing_stmt).scalar_one_or_none()
        if existing is not None:
            raise ValueError(
                f"A marketplace source with endpoint {endpoint!r} already exists "
                f"for this tenant (id={existing.id})."
            )

        tenant_id = self._get_tenant_id()
        now = datetime.utcnow()

        # Parse owner / repo_name from the name field if possible.
        owner: Optional[str] = None
        repo_name: Optional[str] = None
        if "/" in name:
            parts = name.split("/", 1)
            owner = parts[0] or None
            repo_name = parts[1] or None

        # Translate ``enabled`` to an initial scan_status.
        initial_scan_status = "pending" if enabled else "disabled"

        row = EnterpriseMarketplaceSource(
            id=uuid.uuid4(),
            tenant_id=tenant_id,
            repo_url=endpoint,
            owner=owner,
            repo_name=repo_name or name,
            ref="main",
            scan_status=initial_scan_status,
            artifact_count=0,
            created_at=now,
            updated_at=now,
        )
        try:
            self.session.add(row)
            self.session.flush()
            self._log_operation(
                operation="create",
                entity_type="EnterpriseMarketplaceSource",
                entity_id=row.id,
                metadata={"name": name, "endpoint": endpoint},
            )
            return self._source_to_dto(row)
        except Exception:
            self.session.rollback()
            raise

    def update_source(
        self,
        source_id: str,
        updates: "Dict[str, object]",
        ctx: "Optional[object]" = None,
    ) -> "MarketplaceSourceDTO":
        """Apply a partial update to a marketplace source configuration.

        Recognised update keys: ``enabled`` (bool), ``endpoint`` (str),
        ``description`` (ignored — no column), ``supports_publish`` (ignored).
        Additional keys in ``updates`` are silently ignored to avoid errors
        when the caller passes broker-centric fields not present in the
        enterprise schema.

        Parameters
        ----------
        source_id:
            UUID string of the source to update.
        updates:
            Map of field names to new values.
        ctx:
            Optional per-request metadata (unused by enterprise backend).

        Returns
        -------
        MarketplaceSourceDTO
            The updated source.

        Raises
        ------
        KeyError
            If no source with *source_id* exists for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        try:
            uid = (
                uuid.UUID(source_id)
                if not isinstance(source_id, uuid.UUID)
                else source_id
            )
        except ValueError:
            raise KeyError(source_id)

        stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceSource).where(
                EnterpriseMarketplaceSource.id == uid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            raise KeyError(source_id)

        if "enabled" in updates:
            row.scan_status = "pending" if updates["enabled"] else "disabled"
        if "endpoint" in updates:
            row.repo_url = str(updates["endpoint"])
        if "ref" in updates:
            row.ref = str(updates["ref"])
        if "scan_status" in updates:
            row.scan_status = str(updates["scan_status"])

        row.updated_at = datetime.utcnow()

        try:
            self.session.flush()
            self._log_operation(
                operation="update",
                entity_type="EnterpriseMarketplaceSource",
                entity_id=row.id,
                metadata={k: str(v)[:80] for k, v in updates.items()},
            )
            return self._source_to_dto(row)
        except Exception:
            self.session.rollback()
            raise

    def delete_source(
        self,
        source_id: str,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Remove a marketplace source configuration.

        Cascade-deletes all associated catalog entries (via the FK
        ``ON DELETE CASCADE`` on ``enterprise_marketplace_catalog_entries``).

        Parameters
        ----------
        source_id:
            UUID string of the source to remove.
        ctx:
            Optional per-request metadata (unused by enterprise backend).

        Raises
        ------
        KeyError
            If no source with *source_id* exists for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        try:
            uid = (
                uuid.UUID(source_id)
                if not isinstance(source_id, uuid.UUID)
                else source_id
            )
        except ValueError:
            raise KeyError(source_id)

        stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceSource).where(
                EnterpriseMarketplaceSource.id == uid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            raise KeyError(source_id)

        try:
            self.session.delete(row)
            self.session.flush()
            self._log_operation(
                operation="delete",
                entity_type="EnterpriseMarketplaceSource",
                entity_id=uid,
                metadata={"source_id": source_id},
            )
        except Exception:
            self.session.rollback()
            raise

    # ------------------------------------------------------------------
    # Concrete ORM helpers (used by marketplace_sources router)
    # ------------------------------------------------------------------

    def get_by_id(self, source_id: str) -> "Optional[EnterpriseMarketplaceSource]":
        """Return the raw ORM row for a marketplace source.

        Used by router code that needs direct ORM attribute access (e.g.
        ``_perform_scan`` which mutates ``scan_status`` and calls
        ``get_manual_map_dict()``).  Callers needing a DTO should use
        ``get_source()`` instead.

        Parameters
        ----------
        source_id:
            UUID string of the source row.

        Returns
        -------
        EnterpriseMarketplaceSource or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        try:
            uid = (
                uuid.UUID(source_id)
                if not isinstance(source_id, uuid.UUID)
                else source_id
            )
        except ValueError:
            return None

        stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceSource).where(
                EnterpriseMarketplaceSource.id == uid
            )
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def update(
        self, source: "EnterpriseMarketplaceSource"
    ) -> "EnterpriseMarketplaceSource":
        """Flush pending ORM mutations on a marketplace source row.

        Used by router code that directly mutates ORM attributes (e.g.
        ``source.scan_status = 'scanning'``) and needs to persist them.

        Parameters
        ----------
        source:
            An ORM instance with pending attribute changes.

        Returns
        -------
        EnterpriseMarketplaceSource
            The same instance after flush.
        """
        try:
            self.session.add(source)
            self.session.flush()
            self._log_operation(
                operation="update",
                entity_type="EnterpriseMarketplaceSource",
                entity_id=source.id,
                metadata={"repo_url": getattr(source, "repo_url", "") or ""},
            )
            return source
        except Exception:
            self.session.rollback()
            raise

    def create(
        self,
        source: "Any",
    ) -> "EnterpriseMarketplaceSource":
        """Create a new marketplace source from a local ORM instance or enterprise instance.

        The router builds a ``MarketplaceSource`` (local SQLite model) and passes
        it here.  This method maps the local model fields onto a new
        ``EnterpriseMarketplaceSource`` row and persists it.

        Parameters
        ----------
        source:
            Either a ``MarketplaceSource`` (local model) or an
            ``EnterpriseMarketplaceSource`` instance.  When the router runs in
            enterprise edition, it still constructs a local model — this method
            bridges the two schemas.

        Returns
        -------
        EnterpriseMarketplaceSource
            The persisted enterprise row.

        Raises
        ------
        ValueError
            If a source with the same ``repo_url`` already exists for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        # If already the enterprise model, just persist it.
        if isinstance(source, EnterpriseMarketplaceSource):
            tenant_id = self._get_tenant_id()
            if source.tenant_id is None:
                source.tenant_id = tenant_id

            existing_stmt = self._apply_tenant_filter(
                select(EnterpriseMarketplaceSource).where(
                    EnterpriseMarketplaceSource.repo_url == source.repo_url
                )
            )
            existing = self.session.execute(existing_stmt).scalar_one_or_none()
            if existing is not None:
                raise ValueError(
                    f"A marketplace source with repo_url {source.repo_url!r} already exists "
                    f"for this tenant (id={existing.id})."
                )

            self.session.add(source)
            self.session.flush()
            self._log_operation(
                operation="create",
                entity_type="EnterpriseMarketplaceSource",
                entity_id=source.id,
                metadata={"repo_url": source.repo_url or ""},
            )
            return source

        # Local MarketplaceSource → map to enterprise schema.
        tenant_id = self._get_tenant_id()
        repo_url = getattr(source, "repo_url", None) or ""

        existing_stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceSource).where(
                EnterpriseMarketplaceSource.repo_url == repo_url
            )
        )
        existing = self.session.execute(existing_stmt).scalar_one_or_none()
        if existing is not None:
            raise ValueError(
                f"A marketplace source with repo_url {repo_url!r} already exists "
                f"for this tenant (id={existing.id})."
            )

        # Parse raw source_id — local model uses string UUIDs.
        source_id_raw = getattr(source, "id", None)
        try:
            source_uuid = _ensure_uuid(source_id_raw) if source_id_raw else uuid.uuid4()
        except (ValueError, AttributeError):
            source_uuid = uuid.uuid4()

        now = datetime.utcnow()
        row = EnterpriseMarketplaceSource(
            id=source_uuid,
            tenant_id=tenant_id,
            repo_url=repo_url,
            owner=getattr(source, "owner", None),
            repo_name=getattr(source, "repo_name", None),
            ref=getattr(source, "ref", None) or "main",
            scan_status=getattr(source, "scan_status", None) or "pending",
            artifact_count=getattr(source, "artifact_count", 0) or 0,
            created_at=getattr(source, "created_at", None) or now,
            updated_at=getattr(source, "updated_at", None) or now,
        )
        self.session.add(row)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseMarketplaceSource",
            entity_id=row.id,
            metadata={"repo_url": repo_url},
        )
        return row

    def delete(self, source_id: str) -> bool:
        """Delete a marketplace source by its identifier.

        Mirrors the ``MarketplaceSourceRepository.delete()`` interface expected
        by the ``marketplace_sources`` router.

        Parameters
        ----------
        source_id:
            UUID string of the source row.

        Returns
        -------
        bool
            ``True`` if the row was found and deleted; ``False`` if not found
            (or if *source_id* is not a valid UUID).
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        try:
            uid = (
                uuid.UUID(source_id)
                if not isinstance(source_id, uuid.UUID)
                else source_id
            )
        except ValueError:
            logger.debug(
                "EnterpriseMarketplaceSourceRepository.delete: "
                "invalid UUID %r — returning False",
                source_id,
            )
            return False

        stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceSource).where(
                EnterpriseMarketplaceSource.id == uid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return False

        self.session.delete(row)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseMarketplaceSource",
            entity_id=uid,
            metadata={"source_id": source_id},
        )
        return True

    def list_all(self) -> "List[EnterpriseMarketplaceSource]":
        """Return all marketplace sources for the current tenant as raw ORM rows.

        The ``marketplace_sources`` router calls this method when filters are
        present so it can apply in-memory filtering via ``SourceManager``.
        Rows are returned in ascending ``created_at`` order for stable sorting.

        Returns
        -------
        list[EnterpriseMarketplaceSource]
            All source rows belonging to the current tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        stmt = self._apply_tenant_filter(select(EnterpriseMarketplaceSource)).order_by(
            EnterpriseMarketplaceSource.created_at.asc()
        )
        rows = list(self.session.execute(stmt).scalars())
        logger.debug(
            "EnterpriseMarketplaceSourceRepository.list_all: returned %d rows",
            len(rows),
        )
        return rows

    def get_by_repo_url(self, repo_url: str) -> "Optional[EnterpriseMarketplaceSource]":
        """Return the raw ORM row for a marketplace source by repository URL.

        Repository URLs are unique per tenant.  Used by the
        ``marketplace_sources`` router to check for duplicates before creating
        a new source.

        Parameters
        ----------
        repo_url:
            Full repository URL (e.g. ``"https://github.com/owner/repo"``).

        Returns
        -------
        EnterpriseMarketplaceSource or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceSource).where(
                EnterpriseMarketplaceSource.repo_url == repo_url
            )
        )
        return self.session.execute(stmt).scalar_one_or_none()

    # ------------------------------------------------------------------
    # Catalog operations — IMarketplaceSourceRepository
    # ------------------------------------------------------------------

    def list_catalog_items(
        self,
        source_id: "Optional[str]" = None,
        filters: "Optional[Dict[str, object]]" = None,
        page: int = 1,
        limit: int = 50,
        ctx: "Optional[object]" = None,
    ) -> "List[CatalogItemDTO]":
        """Return paginated catalog listings from one or all sources.

        Parameters
        ----------
        source_id:
            When provided, restrict results to entries belonging to this
            source UUID.  When ``None`` all tenant catalog entries are returned.
        filters:
            Optional filter map.  Supported keys: ``query`` (substring match
            on ``name``), ``artifact_type``.
        page:
            One-based page number.
        limit:
            Maximum results per page (1-100).
        ctx:
            Optional per-request metadata (unused by enterprise backend).

        Returns
        -------
        list[CatalogItemDTO]
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceCatalogEntry

        stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceCatalogEntry)
        ).order_by(EnterpriseMarketplaceCatalogEntry.created_at.desc())

        if source_id is not None:
            try:
                src_uid = (
                    uuid.UUID(source_id)
                    if not isinstance(source_id, uuid.UUID)
                    else source_id
                )
                stmt = stmt.where(
                    EnterpriseMarketplaceCatalogEntry.source_id == src_uid
                )
            except ValueError:
                logger.debug(
                    "EnterpriseMarketplaceSourceRepository.list_catalog_items: "
                    "invalid source_id UUID %r — returning empty list",
                    source_id,
                )
                return []

        if filters:
            if "query" in filters and filters["query"]:
                q = f"%{filters['query']}%"
                stmt = stmt.where(EnterpriseMarketplaceCatalogEntry.name.ilike(q))
            if "artifact_type" in filters and filters["artifact_type"]:
                stmt = stmt.where(
                    EnterpriseMarketplaceCatalogEntry.artifact_type
                    == filters["artifact_type"]
                )

        offset = (max(1, page) - 1) * limit
        stmt = stmt.offset(offset).limit(limit)

        rows = list(self.session.execute(stmt).scalars())
        return [self._entry_to_catalog_dto(r) for r in rows]

    def import_item(
        self,
        listing_id: str,
        source_id: "Optional[str]" = None,
        strategy: str = "keep",
        ctx: "Optional[object]" = None,
    ) -> "List[ArtifactDTO]":
        """Download and import a marketplace listing.

        .. note::
            Full import orchestration is not implemented at the enterprise DB
            repository layer (it requires the CLI/source pipeline).  This
            method logs a debug note and returns an empty list.  The API
            layer's ``MarketplaceBrokerService`` handles the actual import
            flow independently of this repository.

        Parameters
        ----------
        listing_id:
            Catalog entry primary key.
        source_id:
            Optional source UUID string.
        strategy:
            Conflict resolution strategy (unused by this stub).
        ctx:
            Optional per-request metadata.

        Returns
        -------
        list[ArtifactDTO]
            Always empty — import orchestration is handled outside this repo.
        """
        logger.debug(
            "EnterpriseMarketplaceSourceRepository.import_item: "
            "import orchestration is deferred to the broker service layer; "
            "listing_id=%r source_id=%r",
            listing_id,
            source_id,
        )
        return []

    def get_composite_members(
        self,
        composite_id: str,
        ctx: "Optional[object]" = None,
    ) -> "List[ArtifactDTO]":
        """Return child artifacts for a composite listing.

        .. note::
            Composite membership tracking is not modelled in the enterprise
            schema.  Returns an empty list and logs a debug note.

        Parameters
        ----------
        composite_id:
            Artifact primary key of the composite artifact.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        list[ArtifactDTO]
            Always empty.
        """
        logger.debug(
            "EnterpriseMarketplaceSourceRepository.get_composite_members: "
            "composite membership not modelled in enterprise schema; "
            "composite_id=%r",
            composite_id,
        )
        return []

    @staticmethod
    def _to_catalog_entry_dto(row: "object") -> "CatalogEntryDTO":
        """Convert an ``EnterpriseMarketplaceCatalogEntry`` ORM row to a
        :class:`~skillmeat.core.interfaces.dtos.CatalogEntryDTO`.

        The enterprise schema is a subset of the local schema: fields such as
        ``excluded_at``, ``excluded_reason``, ``path_segments``,
        ``detected_version``, ``raw_score``, ``score_breakdown``,
        ``import_date``, and ``import_id`` do not exist in the enterprise
        model and are returned as ``None``.

        Parameters
        ----------
        row:
            An ``EnterpriseMarketplaceCatalogEntry`` ORM instance.

        Returns
        -------
        CatalogEntryDTO
        """
        from skillmeat.core.interfaces.dtos import CatalogEntryDTO

        detected_at_val = getattr(row, "created_at", None)
        detected_at_str: "Optional[str]" = (
            detected_at_val.isoformat() if detected_at_val is not None else None
        )
        confidence = getattr(row, "confidence_score", None)
        return CatalogEntryDTO(
            id=str(row.id),
            source_id=str(row.source_id),
            artifact_type=getattr(row, "artifact_type", "") or "",
            name=getattr(row, "name", "") or "",
            path=getattr(row, "path", "") or "",
            upstream_url=getattr(row, "upstream_url", "") or "",
            detected_version=None,
            detected_sha=getattr(row, "detected_sha", None),
            detected_at=detected_at_str,
            confidence_score=int(confidence) if confidence is not None else 0,
            raw_score=None,
            score_breakdown=None,
            status=getattr(row, "status", "new") or "new",
            import_date=None,
            import_id=None,
            excluded_at=None,
            excluded_reason=None,
            path_segments=None,
        )

    def _get_catalog_entry_orm(
        self,
        entry_id: str,
        source_id: "Optional[str]" = None,
    ) -> "Optional[object]":
        """Internal helper: return the raw ORM row or ``None``."""
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceCatalogEntry

        try:
            entry_uid = _ensure_uuid(entry_id)
        except ValueError:
            return None

        stmt = self._apply_tenant_filter(
            select(EnterpriseMarketplaceCatalogEntry).where(
                EnterpriseMarketplaceCatalogEntry.id == entry_uid
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()

        if row is None:
            return None

        if source_id is not None:
            try:
                src_uid = (
                    uuid.UUID(source_id)
                    if not isinstance(source_id, uuid.UUID)
                    else source_id
                )
            except ValueError:
                return None
            if row.source_id != src_uid:
                return None

        return row

    def get_catalog_entry(
        self,
        entry_id: str,
        source_id: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> "Optional[CatalogEntryDTO]":
        """Return a typed DTO for a catalog entry.

        Parameters
        ----------
        entry_id:
            UUID string of the catalog entry.
        source_id:
            When provided, verify the entry belongs to this source.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        CatalogEntryDTO or None
        """
        from skillmeat.core.interfaces.dtos import CatalogEntryDTO  # noqa: F401

        row = self._get_catalog_entry_orm(entry_id, source_id=source_id)
        if row is None:
            return None
        return self._to_catalog_entry_dto(row)

    def update_catalog_entry_exclusion(
        self,
        entry_id: str,
        source_id: str,
        excluded: bool,
        reason: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> "CatalogEntryDTO":
        """Toggle the exclusion status of a catalog entry.

        The enterprise schema has no ``excluded_at`` or ``excluded_reason``
        columns.  Exclusion is approximated by setting ``status`` to
        ``"excluded"`` (when *excluded* is ``True``) or reverting to
        ``"available"`` (when *excluded* is ``False``).

        Parameters
        ----------
        entry_id:
            UUID string of the catalog entry.
        source_id:
            Source the entry must belong to.
        excluded:
            ``True`` to exclude, ``False`` to restore.
        reason:
            Ignored by the enterprise backend (no ``excluded_reason`` column).
        ctx:
            Optional per-request metadata.

        Returns
        -------
        CatalogEntryDTO
            Typed DTO for the updated entry.

        Raises
        ------
        KeyError
            If *entry_id* is not found or does not belong to *source_id*.
        """
        from skillmeat.core.interfaces.dtos import CatalogEntryDTO  # noqa: F401

        row = self._get_catalog_entry_orm(entry_id, source_id=source_id)
        if row is None:
            raise KeyError(entry_id)

        row.status = "excluded" if excluded else "available"
        row.updated_at = datetime.utcnow()

        try:
            self.session.flush()
            self._log_operation(
                operation="update_exclusion",
                entity_type="EnterpriseMarketplaceCatalogEntry",
                entity_id=row.id,
                metadata={"excluded": excluded, "reason": reason},
            )
            return self._to_catalog_entry_dto(row)
        except Exception:
            self.session.rollback()
            raise

    def update_catalog_entry_path_tags(
        self,
        entry_id: str,
        source_id: str,
        path_segments_json: str,
        ctx: "Optional[object]" = None,
    ) -> "CatalogEntryDTO":
        """Persist updated path_segments for a catalog entry.

        The enterprise schema has no ``path_segments`` column.  This method
        records the operation via audit log for traceability but does not
        write the JSON to a column.  The catalog entry's ``updated_at`` is
        refreshed so that callers can detect a change.

        Parameters
        ----------
        entry_id:
            UUID string of the catalog entry.
        source_id:
            Source the entry must belong to.
        path_segments_json:
            Serialised JSON (logged only; no enterprise column stores it).
        ctx:
            Optional per-request metadata.

        Returns
        -------
        CatalogEntryDTO
            Typed DTO for the updated entry.

        Raises
        ------
        KeyError
            If *entry_id* is not found or does not belong to *source_id*.
        """
        from skillmeat.core.interfaces.dtos import CatalogEntryDTO  # noqa: F401

        row = self._get_catalog_entry_orm(entry_id, source_id=source_id)
        if row is None:
            raise KeyError(entry_id)

        logger.debug(
            "EnterpriseMarketplaceSourceRepository.update_catalog_entry_path_tags: "
            "path_segments column not present in enterprise schema; "
            "entry_id=%r path_segments_json=%r",
            entry_id,
            path_segments_json,
        )
        row.updated_at = datetime.utcnow()

        try:
            self.session.flush()
            self._log_operation(
                operation="update_path_tags",
                entity_type="EnterpriseMarketplaceCatalogEntry",
                entity_id=row.id,
                metadata={"path_segments_json": path_segments_json[:200]},
            )
            return self._to_catalog_entry_dto(row)
        except Exception:
            self.session.rollback()
            raise

    def upsert_composite_memberships(
        self,
        composite_id: str,
        child_artifact_ids: "List[str]",
        collection_id: str,
        ctx: "Optional[object]" = None,
    ) -> int:
        """Create or update CompositeMembership rows for a composite artifact.

        .. note::
            Composite membership is not modelled in the enterprise schema.
            Returns 0 and logs a debug note.

        Parameters
        ----------
        composite_id:
            Primary key of the composite artifact.
        child_artifact_ids:
            Ordered list of child ``type:name`` artifact primary keys.
        collection_id:
            Collection the composite belongs to.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        int
            Always 0.
        """
        logger.debug(
            "EnterpriseMarketplaceSourceRepository.upsert_composite_memberships: "
            "composite membership not modelled in enterprise schema; "
            "composite_id=%r child_count=%d",
            composite_id,
            len(child_artifact_ids),
        )
        return 0

    def commit_source_session(
        self,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Flush pending changes on the source repository session.

        Parameters
        ----------
        ctx:
            Optional per-request metadata (unused by enterprise backend).
        """
        try:
            self.session.flush()
        except Exception:
            self.session.rollback()
            raise


# =============================================================================
# EnterpriseProjectTemplateRepository  (ENT2-5.2)
# =============================================================================


class EnterpriseProjectTemplateRepository(
    EnterpriseRepositoryBase["EnterpriseRepositoryBase"],
):
    """Safe stub for project template operations in the enterprise backend.

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IProjectTemplateRepository`
    for the enterprise PostgreSQL backend.

    .. note::
        Full implementation is deferred to v3.  No database queries are
        issued; all methods return empty collections or ``None`` and emit
        a ``DEBUG`` log so callers know the stub was reached.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        The session is stored but never queried by this stub.
    """

    def __init__(self, session: Session) -> None:
        """Initialise the enterprise project template repository.

        Parameters
        ----------
        session:
            Injected SQLAlchemy session bound to the PostgreSQL enterprise
            database.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProjectTemplate

        super().__init__(session, EnterpriseProjectTemplate)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _template_to_dto(
        self,
        row: "EnterpriseProjectTemplate",
        entities: "Optional[List[EnterpriseProjectTemplateEntity]]" = None,
    ) -> "ProjectTemplateDTO":
        """Convert an ORM row to a :class:`ProjectTemplateDTO`.

        Parameters
        ----------
        row:
            An ``EnterpriseProjectTemplate`` ORM instance.
        entities:
            Pre-loaded ``EnterpriseProjectTemplateEntity`` rows for this
            template, or ``None`` to produce an empty entities list (used by
            ``list()`` where entity loading is deferred to ``get()``).

        Returns
        -------
        ProjectTemplateDTO
            Fully populated DTO.
        """
        from skillmeat.core.interfaces.dtos import ProjectTemplateDTO, TemplateEntityDTO

        entity_dtos: List[TemplateEntityDTO] = []
        if entities:
            entity_dtos = [
                TemplateEntityDTO(
                    artifact_id=e.entity_id,
                    name=e.entity_id,
                    deploy_order=e.position,
                )
                for e in entities
            ]

        return ProjectTemplateDTO(
            id=str(row.id),
            name=row.name,
            description=row.description,
            collection_id=row.collection_id,
            default_project_config_id=row.default_project_config_id,
            entities=entity_dtos,
            entity_count=len(entity_dtos),
            created_at=row.created_at.isoformat() if row.created_at else None,
            updated_at=row.updated_at.isoformat() if row.updated_at else None,
        )

    # ------------------------------------------------------------------
    # IProjectTemplateRepository: collection queries
    # ------------------------------------------------------------------

    def list(
        self,
        filters: "Optional[Dict[str, object]]" = None,
        limit: int = 50,
        offset: int = 0,
        ctx: "Optional[object]" = None,
    ) -> "List[ProjectTemplateDTO]":
        """Return a page of project templates for the current tenant.

        Parameters
        ----------
        filters:
            Optional mapping of filter predicates.  Currently supports the
            ``collection_id`` key to restrict results to a single collection.
        limit:
            Maximum number of rows to return (default 50).
        offset:
            Number of rows to skip for pagination (default 0).
        ctx:
            Unused; accepted for interface compatibility.

        Returns
        -------
        list[ProjectTemplateDTO]
            Ordered by ``created_at`` descending; ``entities`` is always an
            empty list — entity detail is loaded on demand by :meth:`get`.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProjectTemplate

        stmt = self._tenant_select().order_by(
            EnterpriseProjectTemplate.created_at.desc()
        )

        if filters:
            collection_id = filters.get("collection_id")
            if collection_id is not None:
                stmt = stmt.where(
                    EnterpriseProjectTemplate.collection_id == str(collection_id)
                )

        stmt = stmt.limit(limit).offset(offset)
        rows = list(self.session.execute(stmt).scalars())
        return [self._template_to_dto(row) for row in rows]

    def count(
        self,
        filters: "Optional[Dict[str, object]]" = None,
        ctx: "Optional[object]" = None,
    ) -> int:
        """Return the total number of project templates for the current tenant.

        Parameters
        ----------
        filters:
            Optional mapping of filter predicates.  Supports ``collection_id``
            (same semantics as :meth:`list`).
        ctx:
            Unused; accepted for interface compatibility.

        Returns
        -------
        int
            Count of matching templates.
        """
        from sqlalchemy import func as sa_func

        from skillmeat.cache.models_enterprise import EnterpriseProjectTemplate

        stmt = self._apply_tenant_filter(
            select(sa_func.count(EnterpriseProjectTemplate.id))
        )

        if filters:
            collection_id = filters.get("collection_id")
            if collection_id is not None:
                stmt = stmt.where(
                    EnterpriseProjectTemplate.collection_id == str(collection_id)
                )

        return self.session.execute(stmt).scalar() or 0

    # ------------------------------------------------------------------
    # IProjectTemplateRepository: single-item lookup
    # ------------------------------------------------------------------

    def get(
        self,
        template_id: str,
        ctx: "Optional[object]" = None,
    ) -> "Optional[ProjectTemplateDTO]":
        """Return a project template by its UUID, with entities loaded.

        Parameters
        ----------
        template_id:
            String representation of the template UUID.
        ctx:
            Unused; accepted for interface compatibility.

        Returns
        -------
        ProjectTemplateDTO or None
            The template DTO with ``entities`` populated in ``position``
            order, or ``None`` if no matching template exists for the
            current tenant.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseProjectTemplate,
            EnterpriseProjectTemplateEntity,
        )

        try:
            tmpl_uuid = _ensure_uuid(template_id)
        except (ValueError, AttributeError):
            return None

        stmt = self._tenant_select().where(EnterpriseProjectTemplate.id == tmpl_uuid)
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return None

        entity_stmt = (
            select(EnterpriseProjectTemplateEntity)
            .where(EnterpriseProjectTemplateEntity.template_id == tmpl_uuid)
            .order_by(EnterpriseProjectTemplateEntity.position)
        )
        entities = list(self.session.execute(entity_stmt).scalars())
        return self._template_to_dto(row, entities)

    # ------------------------------------------------------------------
    # IProjectTemplateRepository: mutations
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        entity_ids: "List[str]",
        description: "Optional[str]" = None,
        collection_id: "Optional[str]" = None,
        default_project_config_id: "Optional[str]" = None,
        ctx: "Optional[object]" = None,
    ) -> "ProjectTemplateDTO":
        """Create a new project template with optional entity associations.

        Parameters
        ----------
        name:
            Human-readable template name (required).
        entity_ids:
            Ordered list of entity/artifact IDs to associate with the
            template.  Each ID is stored as an
            ``EnterpriseProjectTemplateEntity`` row with a 0-based
            ``position`` value matching its index in the list.
        description:
            Optional free-text description.
        collection_id:
            Optional UUID string of the owning collection.
        default_project_config_id:
            Optional UUID string of the default project-config artifact.
        ctx:
            Unused; accepted for interface compatibility.

        Returns
        -------
        ProjectTemplateDTO
            Fully populated DTO for the newly created template.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseProjectTemplate,
            EnterpriseProjectTemplateEntity,
        )

        tenant_id = self._get_tenant_id()

        template = EnterpriseProjectTemplate(
            tenant_id=tenant_id,
            name=name,
            description=description,
            collection_id=collection_id,
            default_project_config_id=default_project_config_id,
        )
        self.session.add(template)
        # Flush to obtain the auto-generated ``template.id`` before creating
        # the child entity rows.
        self.session.flush()

        entity_objects: "List[EnterpriseProjectTemplateEntity]" = []
        for position, entity_id in enumerate(entity_ids or []):
            entity = EnterpriseProjectTemplateEntity(
                template_id=template.id,
                entity_id=str(entity_id),
                position=position,
            )
            self.session.add(entity)
            entity_objects.append(entity)

        if entity_objects:
            self.session.flush()

        return self._template_to_dto(template, entities=entity_objects)

    def update(
        self,
        template_id: str,
        updates: "Dict[str, object]",
        ctx: "Optional[object]" = None,
    ) -> "ProjectTemplateDTO":
        """Apply a partial update to an existing project template.

        Parameters
        ----------
        template_id:
            String representation of the template UUID.
        updates:
            Mapping of fields to update.  Supported scalar keys:
            ``name``, ``description``, ``collection_id``,
            ``default_project_config_id``.  When ``entity_ids`` is
            present its value (a list of string IDs) replaces *all*
            existing entity associations in order.
        ctx:
            Unused; accepted for interface compatibility.

        Returns
        -------
        ProjectTemplateDTO
            DTO reflecting the post-update state, with entities loaded
            in ``position`` order.

        Raises
        ------
        KeyError
            If no template with the given ``template_id`` exists for the
            current tenant.
        """
        from sqlalchemy import delete as sa_delete

        from skillmeat.cache.models_enterprise import (
            EnterpriseProjectTemplate,
            EnterpriseProjectTemplateEntity,
        )

        try:
            tmpl_uuid = _ensure_uuid(template_id)
        except (ValueError, AttributeError) as exc:
            raise KeyError(f"Template {template_id} not found") from exc

        stmt = self._tenant_select().where(EnterpriseProjectTemplate.id == tmpl_uuid)
        template = self.session.execute(stmt).scalar_one_or_none()
        if template is None:
            raise KeyError(f"Template {template_id} not found")

        _SCALAR_FIELDS = {
            "name",
            "description",
            "collection_id",
            "default_project_config_id",
        }
        for key, value in (updates or {}).items():
            if key in _SCALAR_FIELDS:
                setattr(template, key, value)

        if "entity_ids" in updates:
            # Replace all existing entity associations.
            self.session.execute(
                sa_delete(EnterpriseProjectTemplateEntity).where(
                    EnterpriseProjectTemplateEntity.template_id == tmpl_uuid
                )
            )
            self.session.flush()

            new_entity_ids = updates["entity_ids"] or []
            for position, entity_id in enumerate(new_entity_ids):
                self.session.add(
                    EnterpriseProjectTemplateEntity(
                        template_id=tmpl_uuid,
                        entity_id=str(entity_id),
                        position=position,
                    )
                )

        self.session.flush()

        # Re-fetch entities ordered by position to build the return DTO.
        entity_stmt = (
            select(EnterpriseProjectTemplateEntity)
            .where(EnterpriseProjectTemplateEntity.template_id == tmpl_uuid)
            .order_by(EnterpriseProjectTemplateEntity.position)
        )
        entities = list(self.session.execute(entity_stmt).scalars())
        return self._template_to_dto(template, entities=entities)

    def delete(
        self,
        template_id: str,
        ctx: "Optional[object]" = None,
    ) -> None:
        """Delete a project template and its associated entities.

        Parameters
        ----------
        template_id:
            String representation of the template UUID.
        ctx:
            Unused; accepted for interface compatibility.

        Notes
        -----
        If no matching template exists for the current tenant this method
        returns silently (no-op).  FK cascade on
        ``enterprise_project_template_entities`` removes child rows
        automatically when the parent template row is deleted.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProjectTemplate

        try:
            tmpl_uuid = _ensure_uuid(template_id)
        except (ValueError, AttributeError):
            return

        stmt = self._tenant_select().where(EnterpriseProjectTemplate.id == tmpl_uuid)
        template = self.session.execute(stmt).scalar_one_or_none()
        if template is None:
            return

        self.session.delete(template)
        self.session.flush()

    # ------------------------------------------------------------------
    # IProjectTemplateRepository: deployment
    # ------------------------------------------------------------------

    def deploy(
        self,
        template_id: str,
        project_path: "Optional[str]" = None,
        options: "Optional[Dict[str, object]]" = None,
        ctx: "Optional[object]" = None,
    ) -> "Dict[str, object]":
        """Return a deployment manifest for the given template.

        This repository method does not perform file I/O.  It resolves
        the template and its ordered entities and returns a manifest dict
        describing what the service layer above should deploy.

        Parameters
        ----------
        template_id:
            String representation of the template UUID.
        project_path:
            Optional path of the target project directory.  Passed through
            into the manifest; no filesystem operations are performed here.
        options:
            Optional behavioural flags.  When ``dry_run=True`` the manifest
            lists entity metadata without populating ``deployed_files``.
        ctx:
            Unused; accepted for interface compatibility.

        Returns
        -------
        dict
            A deployment manifest with the following keys:

            * ``success`` — ``True`` on success, ``False`` when the
              template was not found.
            * ``dry_run`` — present and ``True`` only for dry-run requests.
            * ``template_name`` — human-readable template name.
            * ``project_path`` — stringified *project_path* argument.
            * ``deployed_files`` — ordered list of entity IDs to deploy
              (empty for dry-run; populated with ``entity_id`` values
              otherwise).
            * ``skipped_files`` — always an empty list (skipping logic
              belongs to the service layer).
            * ``entities`` — present only for dry-run; list of
              ``{entity_id, position}`` dicts.
            * ``error`` — present only when ``success`` is ``False``.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseProjectTemplate,
            EnterpriseProjectTemplateEntity,
        )

        try:
            tmpl_uuid = _ensure_uuid(template_id)
        except (ValueError, AttributeError):
            return {
                "success": False,
                "error": f"Template {template_id} not found",
                "deployed_files": [],
                "skipped_files": [],
            }

        stmt = self._tenant_select().where(EnterpriseProjectTemplate.id == tmpl_uuid)
        template = self.session.execute(stmt).scalar_one_or_none()
        if template is None:
            return {
                "success": False,
                "error": f"Template {template_id} not found",
                "deployed_files": [],
                "skipped_files": [],
            }

        entity_stmt = (
            select(EnterpriseProjectTemplateEntity)
            .where(EnterpriseProjectTemplateEntity.template_id == tmpl_uuid)
            .order_by(EnterpriseProjectTemplateEntity.position)
        )
        entities = list(self.session.execute(entity_stmt).scalars())

        if (options or {}).get("dry_run"):
            return {
                "success": True,
                "dry_run": True,
                "entities": [
                    {"entity_id": e.entity_id, "position": e.position} for e in entities
                ],
                "deployed_files": [],
                "skipped_files": [],
            }

        return {
            "success": True,
            "template_name": template.name,
            "project_path": str(project_path),
            "deployed_files": [e.entity_id for e in entities],
            "skipped_files": [],
        }


# =============================================================================
# EnterpriseMarketplaceTransactionHandler  (ENT2-5.3)
# =============================================================================


class EnterpriseMarketplaceTransactionHandler:
    """Coordinates transactional marketplace operations for the enterprise backend.

    Mirrors the interface of the local
    :class:`~skillmeat.cache.repositories.MarketplaceTransactionHandler` but
    operates on the enterprise PostgreSQL session rather than opening its own
    SQLite connection.

    Unlike most enterprise repositories this class does NOT extend
    ``EnterpriseRepositoryBase`` because it manages multi-table operations
    across both ``EnterpriseMarketplaceSource`` and
    ``EnterpriseMarketplaceCatalogEntry`` and therefore cannot be bound to a
    single model class.

    Tenant filtering is applied explicitly inside each context method using the
    current ``TenantContext``.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        The caller (FastAPI DI layer) is responsible for commit/rollback/close.
    tenant_id:
        Explicit tenant UUID for this handler instance.  Stored and used
        to scope all queries without relying on ``TenantContext`` alone.

    Example::

        handler = EnterpriseMarketplaceTransactionHandler(
            session=db_session, tenant_id=tenant_id
        )
        with handler.scan_update_transaction(source_id) as ctx:
            ctx.update_source_status("success", artifact_count=5)
            ctx.replace_catalog_entries(new_entries)
    """

    def __init__(self, session: Session, tenant_id: uuid.UUID) -> None:
        """Initialise the enterprise marketplace transaction handler.

        Parameters
        ----------
        session:
            Injected SQLAlchemy session bound to the PostgreSQL enterprise
            database.
        tenant_id:
            Tenant UUID that scopes all queries issued by this handler.
        """
        self.session = session
        self.tenant_id = tenant_id

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_enterprise_source(self, source_id: str) -> "EnterpriseMarketplaceSource":
        """Fetch an ``EnterpriseMarketplaceSource`` row scoped to the current tenant.

        Parameters
        ----------
        source_id:
            String representation of the source UUID.

        Returns
        -------
        EnterpriseMarketplaceSource

        Raises
        ------
        KeyError
            If no matching row is found for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        try:
            source_uuid = (
                uuid.UUID(source_id)
                if not isinstance(source_id, uuid.UUID)
                else source_id
            )
        except (ValueError, AttributeError):
            raise KeyError(f"Invalid source UUID: {source_id!r}")

        stmt = select(EnterpriseMarketplaceSource).where(
            EnterpriseMarketplaceSource.id == source_uuid,
            EnterpriseMarketplaceSource.tenant_id == self.tenant_id,
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            raise KeyError(f"Source not found: {source_id!r}")
        return row  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Context managers
    # ------------------------------------------------------------------

    @contextmanager
    def scan_update_transaction(
        self, source_id: str
    ) -> Generator["EnterpriseScanUpdateContext", None, None]:
        """Context manager for updating source and catalog after a scan.

        Wraps the operation in a savepoint so that on error only this
        logical unit is rolled back rather than the entire session.

        Parameters
        ----------
        source_id:
            The enterprise marketplace source UUID being updated.

        Yields
        ------
        EnterpriseScanUpdateContext
            Context object with helper methods for the scan update.

        Raises
        ------
        RuntimeError
            If the database operation fails.
        """
        logger.debug(
            "EnterpriseMarketplaceTransactionHandler: starting scan_update_transaction "
            "source=%s tenant=%s",
            source_id,
            self.tenant_id,
        )
        try:
            context = EnterpriseScanUpdateContext(
                session=self.session,
                source_id=source_id,
                tenant_id=self.tenant_id,
            )
            yield context
            self.session.flush()
            logger.info(
                "EnterpriseMarketplaceTransactionHandler: scan_update_transaction "
                "flushed source=%s",
                source_id,
            )
        except Exception as exc:
            logger.error(
                "EnterpriseMarketplaceTransactionHandler: scan_update_transaction "
                "failed source=%s error=%s",
                source_id,
                exc,
            )
            raise RuntimeError(
                f"Enterprise scan update transaction failed: {exc}"
            ) from exc

    @contextmanager
    def import_transaction(
        self, source_id: str
    ) -> Generator["EnterpriseImportContext", None, None]:
        """Context manager for importing catalog entries to the collection.

        Parameters
        ----------
        source_id:
            The enterprise marketplace source UUID being imported from.

        Yields
        ------
        EnterpriseImportContext
            Context object with helper methods for marking import results.

        Raises
        ------
        RuntimeError
            If the database operation fails.
        """
        logger.debug(
            "EnterpriseMarketplaceTransactionHandler: starting import_transaction "
            "source=%s tenant=%s",
            source_id,
            self.tenant_id,
        )
        try:
            context = EnterpriseImportContext(
                session=self.session,
                source_id=source_id,
                tenant_id=self.tenant_id,
            )
            yield context
            self.session.flush()
            logger.info(
                "EnterpriseMarketplaceTransactionHandler: import_transaction "
                "flushed source=%s",
                source_id,
            )
        except Exception as exc:
            logger.error(
                "EnterpriseMarketplaceTransactionHandler: import_transaction "
                "failed source=%s error=%s",
                source_id,
                exc,
            )
            raise RuntimeError(f"Enterprise import transaction failed: {exc}") from exc


class EnterpriseScanUpdateContext:
    """Context for scan update operations within an enterprise transaction.

    Mirrors :class:`~skillmeat.cache.repositories.ScanUpdateContext` for the
    enterprise PostgreSQL backend using SQLAlchemy 2.x ``select()`` style.

    Parameters
    ----------
    session:
        Active SQLAlchemy session (managed by
        :class:`EnterpriseMarketplaceTransactionHandler`).
    source_id:
        UUID string of the marketplace source being updated.
    tenant_id:
        Tenant UUID for row-level isolation.
    """

    def __init__(self, session: Session, source_id: str, tenant_id: uuid.UUID) -> None:
        self.session = session
        self.source_id = source_id
        self.tenant_id = tenant_id

    def update_source_status(
        self,
        status: str,
        artifact_count: Optional[int] = None,
        error_message: Optional[str] = None,
        ref: Optional[str] = None,
    ) -> None:
        """Update source scan status and metadata.

        Parameters
        ----------
        status:
            New scan status (e.g. ``"success"``, ``"error"``).
        artifact_count:
            Number of artifacts discovered (``None`` leaves unchanged).
        error_message:
            Error message when *status* is ``"error"`` (``None`` clears).
        ref:
            Resolved git ref used during scan (``None`` leaves unchanged).

        Raises
        ------
        KeyError
            If no matching source row is found for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        try:
            source_uuid = (
                uuid.UUID(self.source_id)
                if not isinstance(self.source_id, uuid.UUID)
                else self.source_id
            )
        except (ValueError, AttributeError):
            raise KeyError(f"Invalid source UUID: {self.source_id!r}")

        stmt = select(EnterpriseMarketplaceSource).where(
            EnterpriseMarketplaceSource.id == source_uuid,
            EnterpriseMarketplaceSource.tenant_id == self.tenant_id,
        )
        source = self.session.execute(stmt).scalar_one_or_none()
        if source is None:
            raise KeyError(f"Source not found: {self.source_id!r}")

        source.scan_status = status
        source.last_sync_at = datetime.utcnow()

        if artifact_count is not None:
            source.artifact_count = artifact_count

        source.last_error = error_message

        if ref is not None:
            source.ref = ref
            logger.info(
                "EnterpriseScanUpdateContext: updated source %s ref to %r",
                self.source_id,
                ref,
            )

        logger.info(
            "EnterpriseScanUpdateContext: updated source=%s status=%s count=%s",
            self.source_id,
            status,
            artifact_count,
        )

    def replace_catalog_entries(
        self, entries: "List[EnterpriseMarketplaceCatalogEntry]"
    ) -> int:
        """Delete existing catalog entries for the source and insert new ones.

        Parameters
        ----------
        entries:
            List of new ``EnterpriseMarketplaceCatalogEntry`` instances to insert.

        Returns
        -------
        int
            Number of entries inserted.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseMarketplaceCatalogEntry,
            EnterpriseMarketplaceSource,
        )

        try:
            source_uuid = (
                uuid.UUID(self.source_id)
                if not isinstance(self.source_id, uuid.UUID)
                else self.source_id
            )
        except (ValueError, AttributeError):
            raise KeyError(f"Invalid source UUID: {self.source_id!r}")

        # Delete existing entries scoped to this tenant's source
        del_stmt = delete(EnterpriseMarketplaceCatalogEntry).where(
            EnterpriseMarketplaceCatalogEntry.source_id == source_uuid,
            EnterpriseMarketplaceCatalogEntry.tenant_id == self.tenant_id,
        )
        result = self.session.execute(del_stmt)
        deleted_count = result.rowcount
        logger.debug(
            "EnterpriseScanUpdateContext: deleted %d existing entries for source=%s",
            deleted_count,
            self.source_id,
        )

        # Insert new entries
        for entry in entries:
            self.session.add(entry)

        logger.info(
            "EnterpriseScanUpdateContext: inserted %d entries for source=%s",
            len(entries),
            self.source_id,
        )
        return len(entries)

    def update_source_counts(
        self,
        counts_by_type: dict,
        clone_target: Optional[Any] = None,
    ) -> None:
        """Update counts_by_type and optionally clone_target on the source row.

        Mirrors :meth:`~skillmeat.cache.repositories.ScanUpdateContext.update_source_counts`
        for the enterprise backend using SQLAlchemy 2.x ``select()`` style.

        Parameters
        ----------
        counts_by_type:
            Dict mapping artifact type strings to integer counts.
        clone_target:
            Optional clone target to persist on the source row (transient field).
            When ``None`` the field is left unchanged.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceSource

        try:
            source_uuid = (
                uuid.UUID(self.source_id)
                if not isinstance(self.source_id, uuid.UUID)
                else self.source_id
            )
        except (ValueError, AttributeError):
            logger.warning(
                "update_source_counts: invalid source UUID %r, skipping",
                self.source_id,
            )
            return

        stmt = select(EnterpriseMarketplaceSource).where(
            EnterpriseMarketplaceSource.id == source_uuid,
            EnterpriseMarketplaceSource.tenant_id == self.tenant_id,
        )
        source = self.session.execute(stmt).scalar_one_or_none()
        if source is None:
            logger.warning(
                "update_source_counts: source %s not found, skipping", self.source_id
            )
            return

        source.set_counts_by_type_dict(counts_by_type)
        if clone_target is not None:
            source.clone_target = clone_target
        logger.debug(
            "update_source_counts: updated counts for source %s", self.source_id
        )


class EnterpriseImportContext:
    """Context for import operations within an enterprise transaction.

    Mirrors :class:`~skillmeat.cache.repositories.ImportContext` for the
    enterprise PostgreSQL backend using SQLAlchemy 2.x ``select()`` style.

    Parameters
    ----------
    session:
        Active SQLAlchemy session (managed by
        :class:`EnterpriseMarketplaceTransactionHandler`).
    source_id:
        UUID string of the marketplace source being imported from.
    tenant_id:
        Tenant UUID for row-level isolation.
    """

    def __init__(self, session: Session, source_id: str, tenant_id: uuid.UUID) -> None:
        self.session = session
        self.source_id = source_id
        self.tenant_id = tenant_id

    def mark_imported(self, entry_ids: List[str], import_id: str) -> int:
        """Mark catalog entries as imported.

        Parameters
        ----------
        entry_ids:
            List of catalog entry UUID strings to update.
        import_id:
            Unique identifier for this import operation.

        Returns
        -------
        int
            Number of entries updated.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceCatalogEntry

        updated_count = 0
        now = datetime.utcnow()

        for entry_id_str in entry_ids:
            try:
                entry_uuid = _ensure_uuid(entry_id_str)
            except (ValueError, AttributeError):
                logger.warning(
                    "EnterpriseImportContext.mark_imported: skipping invalid UUID %r",
                    entry_id_str,
                )
                continue

            stmt = select(EnterpriseMarketplaceCatalogEntry).where(
                EnterpriseMarketplaceCatalogEntry.id == entry_uuid,
                EnterpriseMarketplaceCatalogEntry.tenant_id == self.tenant_id,
            )
            entry = self.session.execute(stmt).scalar_one_or_none()
            if entry is None:
                continue

            entry.status = "imported"
            entry.updated_at = now
            updated_count += 1

        logger.info(
            "EnterpriseImportContext: marked %d entries imported (import_id=%s)",
            updated_count,
            import_id,
        )
        return updated_count

    def mark_failed(self, entry_ids: List[str], error: str) -> int:
        """Mark catalog entries as failed import.

        Parameters
        ----------
        entry_ids:
            List of catalog entry UUID strings to mark as failed.
        error:
            Error message describing the failure reason.

        Returns
        -------
        int
            Number of entries updated.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMarketplaceCatalogEntry

        updated_count = 0
        now = datetime.utcnow()

        for entry_id_str in entry_ids:
            try:
                entry_uuid = _ensure_uuid(entry_id_str)
            except (ValueError, AttributeError):
                logger.warning(
                    "EnterpriseImportContext.mark_failed: skipping invalid UUID %r",
                    entry_id_str,
                )
                continue

            stmt = select(EnterpriseMarketplaceCatalogEntry).where(
                EnterpriseMarketplaceCatalogEntry.id == entry_uuid,
                EnterpriseMarketplaceCatalogEntry.tenant_id == self.tenant_id,
            )
            entry = self.session.execute(stmt).scalar_one_or_none()
            if entry is None:
                continue

            entry.status = "error"
            entry.updated_at = now
            updated_count += 1

        logger.info(
            "EnterpriseImportContext: marked %d entries failed error=%r",
            updated_count,
            error,
        )
        return updated_count


# =============================================================================
# EnterpriseDbCollectionArtifactRepository  (ENT2-6.1)
# =============================================================================


class EnterpriseDbCollectionArtifactRepository(
    EnterpriseRepositoryBase["EnterpriseCollectionArtifact"],
    IDbCollectionArtifactRepository,
):
    """Enterprise repository for collection-artifact membership.

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IDbCollectionArtifactRepository`
    for the enterprise PostgreSQL backend.

    The underlying ``EnterpriseCollectionArtifact`` join table carries only
    structural membership data (``collection_id``, ``artifact_id``,
    ``order_index``, ``added_at``).  Richer metadata fields present on the
    local ``CollectionArtifact`` ORM model (``description``, ``tags_json``,
    ``source``, etc.) are resolved by joining through ``EnterpriseArtifact``.

    Methods that have no meaningful enterprise equivalent (bootstrap helpers,
    group lookups, etc.) return safe empty values rather than raising.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import (
            EnterpriseCollectionArtifact as _ECA,
        )

        super().__init__(session, _ECA)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _row_to_dto(
        self, row: "EnterpriseCollectionArtifact"
    ) -> "CollectionArtifactDTO":
        """Convert an ``EnterpriseCollectionArtifact`` ORM row to a DTO.

        Joins are lazy-loaded by SQLAlchemy; ``row.artifact`` and
        ``row.collection`` relationships are expected to be accessible.
        """
        from skillmeat.core.interfaces.dtos import CollectionArtifactDTO

        artifact = row.artifact  # type: ignore[attr-defined]
        tags: List[str] = []
        description: Optional[str] = None
        source_url: Optional[str] = None
        artifact_uuid: str = (
            str(artifact.id).replace("-", "") if artifact is not None else ""
        )

        if artifact is not None:
            description = getattr(artifact, "description", None)
            raw_tags = getattr(artifact, "tags", None)
            if isinstance(raw_tags, list):
                tags = [str(t) for t in raw_tags]
            source_url = getattr(artifact, "source_url", None)

        added_at_val = row.added_at  # type: ignore[attr-defined]
        added_at_str: Optional[str] = (
            added_at_val.isoformat() if added_at_val is not None else None
        )

        return CollectionArtifactDTO(
            collection_id=str(row.collection_id).replace("-", ""),  # type: ignore[attr-defined]
            artifact_uuid=artifact_uuid,
            added_at=added_at_str,
            description=description,
            tags=tags,
            source=source_url,
        )

    def _parse_collection_uuid(self, collection_id: str) -> Optional[uuid.UUID]:
        """Parse a collection_id string to a UUID, returning None on failure."""
        try:
            return _ensure_uuid(collection_id)
        except (ValueError, AttributeError):
            logger.warning(
                "EnterpriseDbCollectionArtifactRepository: invalid collection_id %r",
                collection_id,
            )
            return None

    # ------------------------------------------------------------------
    # Tenant-safety helpers
    # ------------------------------------------------------------------

    def _validate_collection_tenant(self, collection_uuid: uuid.UUID) -> None:
        """Verify *collection_uuid* belongs to the current tenant.

        ``EnterpriseCollectionArtifact`` is a pure join table with no
        ``tenant_id`` column of its own.  Tenant isolation for all
        collection-scoped membership queries is enforced by confirming that the
        parent ``EnterpriseCollection`` row is visible under the current tenant
        before any membership query is executed.

        We cannot use ``_apply_tenant_filter()`` here because that helper
        filters against ``self.model_class.tenant_id``
        (``EnterpriseCollectionArtifact.tenant_id``), which does not exist.
        Instead we apply the filter manually against ``EnterpriseCollection``.

        Raises
        ------
        ValueError
            If no ``EnterpriseCollection`` row with that UUID exists for the
            current tenant (either the collection does not exist, or it belongs
            to a different tenant).
        """
        from skillmeat.cache.models_enterprise import EnterpriseCollection

        tenant_id = self._get_tenant_id()
        stmt = select(EnterpriseCollection).where(
            EnterpriseCollection.id == collection_uuid,
            EnterpriseCollection.tenant_id == tenant_id,
        )
        result = self.session.execute(stmt).scalar_one_or_none()
        if result is None:
            raise ValueError(
                f"Collection {collection_uuid} not found for current tenant"
            )

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def list_by_collection(
        self,
        collection_id: str,
        *,
        limit: int = 50,
        offset: int = 0,
        search: "str | None" = None,
        artifact_type: "str | None" = None,
        ctx: "Any | None" = None,
    ) -> "list":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.list_by_collection: %r",
            collection_id,
        )
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseCollectionArtifact,
        )

        coll_uuid = self._parse_collection_uuid(collection_id)
        if coll_uuid is None:
            return []
        self._validate_collection_tenant(coll_uuid)

        tenant_id = self._get_tenant_id()
        stmt = (
            select(EnterpriseCollectionArtifact)
            .join(
                EnterpriseArtifact,
                EnterpriseArtifact.id == EnterpriseCollectionArtifact.artifact_id,
            )
            .where(
                EnterpriseCollectionArtifact.collection_id == coll_uuid,
                EnterpriseArtifact.tenant_id == tenant_id,
            )
        )
        if artifact_type is not None:
            stmt = stmt.where(EnterpriseArtifact.artifact_type == artifact_type)
        if search is not None:
            stmt = stmt.where(EnterpriseArtifact.name.ilike(f"%{search}%"))
        stmt = (
            stmt.order_by(EnterpriseCollectionArtifact.order_index)
            .offset(offset)
            .limit(limit)
        )

        rows = self.session.execute(stmt).scalars().all()
        return [self._row_to_dto(r) for r in rows]

    def get_by_pk(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: "Any | None" = None,
    ) -> "Any | None":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.get_by_pk: %r %r",
            collection_id,
            artifact_uuid,
        )
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        coll_uuid = self._parse_collection_uuid(collection_id)
        if coll_uuid is None:
            return None
        try:
            art_uuid = _ensure_uuid(artifact_uuid)
        except (ValueError, AttributeError):
            return None
        self._validate_collection_tenant(coll_uuid)

        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        tenant_id = self._get_tenant_id()
        stmt = (
            select(EnterpriseCollectionArtifact)
            .join(
                EnterpriseArtifact,
                EnterpriseArtifact.id == EnterpriseCollectionArtifact.artifact_id,
            )
            .where(
                EnterpriseCollectionArtifact.collection_id == coll_uuid,
                EnterpriseCollectionArtifact.artifact_id == art_uuid,
                EnterpriseArtifact.tenant_id == tenant_id,
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._row_to_dto(row) if row is not None else None

    def count_by_collection(
        self,
        collection_id: str,
        ctx: "Any | None" = None,
    ) -> int:
        from sqlalchemy import func
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        coll_uuid = self._parse_collection_uuid(collection_id)
        if coll_uuid is None:
            return 0
        self._validate_collection_tenant(coll_uuid)

        stmt = (
            select(func.count())
            .select_from(EnterpriseCollectionArtifact)
            .where(EnterpriseCollectionArtifact.collection_id == coll_uuid)
        )
        result = self.session.execute(stmt).scalar()
        return int(result) if result is not None else 0

    def list_with_tags(
        self,
        collection_id: str,
        *,
        tag: "str | None" = None,
        ctx: "Any | None" = None,
    ) -> "list":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.list_with_tags: %r tag=%r",
            collection_id,
            tag,
        )
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseCollectionArtifact,
        )

        coll_uuid = self._parse_collection_uuid(collection_id)
        if coll_uuid is None:
            return []
        self._validate_collection_tenant(coll_uuid)

        tenant_id = self._get_tenant_id()
        stmt = (
            select(EnterpriseCollectionArtifact)
            .join(
                EnterpriseArtifact,
                EnterpriseArtifact.id == EnterpriseCollectionArtifact.artifact_id,
            )
            .where(
                EnterpriseCollectionArtifact.collection_id == coll_uuid,
                EnterpriseArtifact.tenant_id == tenant_id,
            )
        )
        if tag is not None:
            # PostgreSQL JSONB array contains operator
            stmt = stmt.where(EnterpriseArtifact.tags.contains([tag]))
        stmt = stmt.order_by(EnterpriseCollectionArtifact.order_index)

        rows = self.session.execute(stmt).scalars().all()
        return [self._row_to_dto(r) for r in rows]

    def list_deployment_info(
        self,
        collection_id: str,
        ctx: "Any | None" = None,
    ) -> "list":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.list_deployment_info: %r",
            collection_id,
        )
        # EnterpriseCollectionArtifact does not carry deployment_json; return basic membership
        return self.list_by_collection(collection_id, limit=1000, ctx=ctx)

    def get_source_deployments_batch(
        self,
        artifact_ids: "list[str]",
        ctx: "Any | None" = None,
    ) -> "list[dict]":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.get_source_deployments_batch: %d ids",
            len(artifact_ids),
        )
        # EnterpriseCollectionArtifact does not carry deployments_json
        return []

    def add_artifacts(
        self,
        collection_id: str,
        artifact_uuids: "list[str]",
        ctx: "Any | None" = None,
    ) -> "list":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.add_artifacts: %r %d uuids",
            collection_id,
            len(artifact_uuids),
        )
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        coll_uuid = self._parse_collection_uuid(collection_id)
        if coll_uuid is None:
            raise KeyError(f"Invalid collection_id: {collection_id!r}")
        self._validate_collection_tenant(coll_uuid)

        results = []
        for art_uuid_str in artifact_uuids:
            try:
                art_uuid = _ensure_uuid(art_uuid_str)
            except (ValueError, AttributeError):
                logger.warning(
                    "EnterpriseDbCollectionArtifactRepository.add_artifacts: skipping invalid UUID %r",
                    art_uuid_str,
                )
                continue

            # Check for existing membership (idempotent)
            stmt = select(EnterpriseCollectionArtifact).where(
                EnterpriseCollectionArtifact.collection_id == coll_uuid,
                EnterpriseCollectionArtifact.artifact_id == art_uuid,
            )
            existing = self.session.execute(stmt).scalar_one_or_none()
            if existing is not None:
                results.append(self._row_to_dto(existing))
                continue

            row = EnterpriseCollectionArtifact(
                collection_id=coll_uuid,
                artifact_id=art_uuid,
            )
            self.session.add(row)
            self.session.flush()
            results.append(self._row_to_dto(row))

        self.session.flush()
        return results

    def remove_artifact(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: "Any | None" = None,
    ) -> bool:
        from sqlalchemy import delete as sa_delete
        from skillmeat.cache.models_enterprise import EnterpriseCollectionArtifact

        coll_uuid = self._parse_collection_uuid(collection_id)
        if coll_uuid is None:
            return False
        try:
            art_uuid = _ensure_uuid(artifact_uuid)
        except (ValueError, AttributeError):
            return False
        self._validate_collection_tenant(coll_uuid)

        result = self.session.execute(
            sa_delete(EnterpriseCollectionArtifact).where(
                EnterpriseCollectionArtifact.collection_id == coll_uuid,
                EnterpriseCollectionArtifact.artifact_id == art_uuid,
            )
        )
        self.session.flush()
        return (result.rowcount or 0) > 0

    def upsert_metadata(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: "Any | None" = None,
        **metadata: "Any",
    ) -> "Any":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.upsert_metadata: %r %r — metadata not stored in enterprise schema",
            collection_id,
            artifact_uuid,
        )
        # Enterprise schema does not carry rich metadata columns; return existing DTO
        dto = self.get_by_pk(collection_id, artifact_uuid, ctx=ctx)
        if dto is None:
            from skillmeat.core.interfaces.dtos import CollectionArtifactDTO

            return CollectionArtifactDTO(
                collection_id=collection_id, artifact_uuid=artifact_uuid
            )
        return dto

    def update_source_tracking(
        self,
        collection_id: str,
        artifact_uuid: str,
        *,
        source: "str | None" = None,
        origin: "str | None" = None,
        resolved_sha: "str | None" = None,
        resolved_version: "str | None" = None,
        ctx: "Any | None" = None,
    ) -> "Any":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.update_source_tracking: %r %r — not stored in enterprise schema",
            collection_id,
            artifact_uuid,
        )
        dto = self.get_by_pk(collection_id, artifact_uuid, ctx=ctx)
        if dto is None:
            raise KeyError(f"No membership for ({collection_id!r}, {artifact_uuid!r})")
        return dto

    # ------------------------------------------------------------------
    # Bootstrap / migration helpers
    # ------------------------------------------------------------------

    def get_existing_artifact_ids(self) -> "set[str]":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.get_existing_artifact_ids"
        )
        return set()

    def ensure_artifact_rows(self, artifacts: "list", *, project_id: str) -> int:
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.ensure_artifact_rows: stub — enterprise manages artifact rows separately"
        )
        return 0

    def list_artifact_ids_in_collection(self, collection_id: str) -> "set[str]":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.list_artifact_ids_in_collection: %r",
            collection_id,
        )
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseCollectionArtifact,
        )

        coll_uuid = self._parse_collection_uuid(collection_id)
        if coll_uuid is None:
            return set()
        self._validate_collection_tenant(coll_uuid)

        tenant_id = self._get_tenant_id()
        stmt = (
            select(EnterpriseArtifact.name, EnterpriseArtifact.artifact_type)
            .join(
                EnterpriseCollectionArtifact,
                EnterpriseCollectionArtifact.artifact_id == EnterpriseArtifact.id,
            )
            .where(
                EnterpriseCollectionArtifact.collection_id == coll_uuid,
                EnterpriseArtifact.tenant_id == tenant_id,
            )
        )
        rows = self.session.execute(stmt).all()
        return {f"{r.artifact_type}:{r.name}" for r in rows}

    def resolve_uuid_by_id(self, artifact_id: str) -> "str | None":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.resolve_uuid_by_id: %r",
            artifact_id,
        )
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        if ":" not in artifact_id:
            return None
        artifact_type, _, name = artifact_id.partition(":")
        tenant_id = self._get_tenant_id()
        stmt = select(EnterpriseArtifact.id).where(
            EnterpriseArtifact.name == name,
            EnterpriseArtifact.artifact_type == artifact_type,
            EnterpriseArtifact.tenant_id == tenant_id,
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return str(row).replace("-", "") if row is not None else None

    def list_all_with_tags(self) -> "list":
        logger.debug("EnterpriseDbCollectionArtifactRepository.list_all_with_tags")
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseCollectionArtifact,
        )

        tenant_id = self._get_tenant_id()
        stmt = (
            select(EnterpriseCollectionArtifact)
            .join(
                EnterpriseArtifact,
                EnterpriseArtifact.id == EnterpriseCollectionArtifact.artifact_id,
            )
            .where(
                EnterpriseArtifact.tags != None,  # noqa: E711
                EnterpriseArtifact.tenant_id == tenant_id,
            )
        )
        rows = self.session.execute(stmt).scalars().all()
        return [self._row_to_dto(r) for r in rows if getattr(r.artifact, "tags", None)]

    def resolve_uuid_to_id_batch(
        self,
        uuids: "list[str]",
        ctx: "Any | None" = None,
    ) -> "dict[str, str]":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.resolve_uuid_to_id_batch: %d uuids",
            len(uuids),
        )
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        if not uuids:
            return {}

        parsed: List[uuid.UUID] = []
        for u in uuids:
            try:
                parsed.append(_ensure_uuid(u))
            except (ValueError, AttributeError):
                pass

        if not parsed:
            return {}

        tenant_id = self._get_tenant_id()
        stmt = select(
            EnterpriseArtifact.id,
            EnterpriseArtifact.name,
            EnterpriseArtifact.artifact_type,
        ).where(
            EnterpriseArtifact.id.in_(parsed),
            EnterpriseArtifact.tenant_id == tenant_id,
        )
        rows = self.session.execute(stmt).all()
        return {str(r.id).replace("-", ""): f"{r.artifact_type}:{r.name}" for r in rows}

    def list_all_ordered(
        self,
        collection_id: str,
        ctx: "Any | None" = None,
    ) -> "list":
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseCollectionArtifact,
        )

        coll_uuid = self._parse_collection_uuid(collection_id)
        if coll_uuid is None:
            return []
        self._validate_collection_tenant(coll_uuid)

        tenant_id = self._get_tenant_id()
        stmt = (
            select(EnterpriseCollectionArtifact)
            .join(
                EnterpriseArtifact,
                EnterpriseArtifact.id == EnterpriseCollectionArtifact.artifact_id,
            )
            .where(
                EnterpriseCollectionArtifact.collection_id == coll_uuid,
                EnterpriseArtifact.tenant_id == tenant_id,
            )
            .order_by(EnterpriseArtifact.artifact_type, EnterpriseArtifact.name)
        )
        rows = self.session.execute(stmt).scalars().all()
        return [self._row_to_dto(r) for r in rows]

    def get_group_artifact_uuids(
        self,
        group_id: str,
        ctx: "Any | None" = None,
    ) -> "set[str]":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.get_group_artifact_uuids: %r — not supported in enterprise v1",
            group_id,
        )
        return set()

    def get_source_for_uuids(
        self,
        artifact_uuids: "list[str]",
        ctx: "Any | None" = None,
    ) -> "dict[str, str]":
        logger.debug(
            "EnterpriseDbCollectionArtifactRepository.get_source_for_uuids: %d uuids — source not stored in enterprise v1 schema",
            len(artifact_uuids),
        )
        return {}

    # No-op stubs for local-only features

    def get_group_memberships_batch(
        self,
        artifact_uuids: "list[str]",
        collection_id: str,
        ctx: "Any | None" = None,
    ) -> "list[dict]":
        """Return empty list for enterprise — group lookups are local-only."""
        return []

    def get_staleness_stats(
        self,
        collection_id: str,
        ttl_seconds: int,
        ctx: "Any | None" = None,
    ) -> dict:
        """Return empty staleness stats — staleness tracking is local-only."""
        return {
            "total_artifacts": 0,
            "stale_count": 0,
            "fresh_count": 0,
            "oldest_sync_age_seconds": 0,
            "percentage_stale": 0.0,
            "ttl_seconds": ttl_seconds,
            "collection_id": collection_id,
        }

    def update_deployments_by_name(
        self,
        collection_id: str,
        artifact_name: str,
        deployments_json: str,
        ctx: "Any | None" = None,
    ) -> int:
        """No-op for enterprise — deployment tracking is local-only."""
        return 0

    def bulk_update_metadata(
        self,
        updates: "list[dict]",
        ctx: "Any | None" = None,
    ) -> int:
        """No-op for enterprise — bulk metadata updates are local-only."""
        return 0


# =============================================================================
# EnterpriseArtifactHistoryRepository  (TASK-1.1)
# =============================================================================


class EnterpriseArtifactHistoryRepository(
    EnterpriseRepositoryBase["EnterpriseArtifactVersion"],  # type: ignore[type-arg]
    IDbArtifactHistoryRepository,
):
    """Enterprise (PostgreSQL) implementation of :class:`IDbArtifactHistoryRepository`.

    Thin reader over the :class:`~skillmeat.cache.models_enterprise.EnterpriseArtifactVersion`
    ORM model (``artifact_versions`` table), which is the enterprise counterpart to the
    local-mode ``artifact_versions`` SQLite table.

    Design notes
    ------------
    * All query methods call ``_apply_tenant_filter()`` before executing — this is
      a security boundary that prevents cross-tenant data leakage.
    * ``get_cache_artifact_by_uuid`` and ``list_cache_artifacts_by_name_type`` query
      ``EnterpriseArtifact`` (the parent table). They apply the tenant filter manually
      against ``EnterpriseArtifact.tenant_id`` because ``_apply_tenant_filter()`` is
      wired to ``EnterpriseArtifactVersion.tenant_id`` (the base model class).
    * ``list_versions_for_artifacts`` accepts ``artifact_ids`` as UUID strings (enterprise
      format), not ``type:name`` strings (local format). Empty list short-circuits without
      a DB round-trip.
    * DTO field synthesis: ``EnterpriseArtifactVersion`` lacks ``change_origin``,
      ``parent_hash``, ``version_lineage``, and ``metadata_json`` — we synthesize sensible
      defaults (``change_origin`` derived from ``commit_sha`` presence, others ``None``).

    Security invariant
    ------------------
    Every ``select()`` statement that queries enterprise model tables **MUST** include a
    tenant filter before execution.  Bypassing this check is a cross-tenant data leakage
    defect.

    Parameters
    ----------
    session:
        Injected SQLAlchemy ``Session`` (PostgreSQL enterprise database).
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersion

        super().__init__(session, EnterpriseArtifactVersion)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _version_to_dto(
        version: "EnterpriseArtifactVersion",
    ) -> "ArtifactVersionDTO":
        """Map an :class:`EnterpriseArtifactVersion` ORM row to an :class:`ArtifactVersionDTO`.

        Missing local-model fields are synthesised:
        * ``change_origin``: ``"sync"`` when ``commit_sha`` is present, else ``"local_modification"``.
        * ``parent_hash``: ``None`` (enterprise versions are content-addressed, not lineage-linked).
        * ``version_lineage``: ``None`` (not tracked in enterprise schema).
        * ``metadata_json``: populated from ``changelog`` when set.
        """
        from skillmeat.core.interfaces.dtos import ArtifactVersionDTO

        created_at_iso: Optional[str] = None
        if version.created_at is not None:
            if hasattr(version.created_at, "isoformat"):
                created_at_iso = version.created_at.isoformat()
            else:
                created_at_iso = str(version.created_at)

        change_origin = "sync" if version.commit_sha else "local_modification"

        return ArtifactVersionDTO(
            id=str(version.id),
            artifact_id=str(version.artifact_id),
            content_hash=version.content_hash,
            change_origin=change_origin,
            created_at=created_at_iso,
            parent_hash=None,
            version_lineage=None,
            metadata_json=version.changelog,
        )

    @staticmethod
    def _artifact_to_summary_dto(
        artifact: "EnterpriseArtifact",
    ) -> "CacheArtifactSummaryDTO":
        """Map an :class:`EnterpriseArtifact` ORM row to a :class:`CacheArtifactSummaryDTO`.

        The ``id`` field is synthesised as ``"{artifact_type}:{name}"`` to match the
        local-edition ``type:name`` primary key format expected by consumers.

        The ``uuid`` field is the canonical artifact UUID (enterprise PK).

        ``project_path`` is ``None`` — enterprise artifacts are tenant-scoped, not
        project-path–scoped.
        """
        from skillmeat.core.interfaces.dtos import CacheArtifactSummaryDTO

        synthesised_id = f"{artifact.artifact_type}:{artifact.name}"
        return CacheArtifactSummaryDTO(
            id=synthesised_id,
            uuid=str(artifact.id),
            name=artifact.name,
            type=artifact.artifact_type,
            project_path=None,
        )

    # ------------------------------------------------------------------
    # IDbArtifactHistoryRepository implementation
    # ------------------------------------------------------------------

    def get_cache_artifact_by_uuid(
        self,
        uuid: str,
        ctx: "Any | None" = None,
    ) -> "CacheArtifactSummaryDTO | None":
        """Return a summary of the ``enterprise_artifacts`` row identified by *uuid*.

        Applies tenant filter against ``EnterpriseArtifact.tenant_id``.

        Args:
            uuid: Artifact UUID string (hex or standard hyphenated format).
            ctx: Optional per-request metadata (unused, reserved).

        Returns:
            :class:`~skillmeat.core.interfaces.dtos.CacheArtifactSummaryDTO` when
            the artifact exists within the current tenant, ``None`` otherwise.
        """
        from uuid import UUID as _UUID

        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        try:
            artifact_uuid = _UUID(uuid)
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseArtifactHistoryRepository.get_cache_artifact_by_uuid: "
                "invalid UUID string %r — returning None",
                uuid,
            )
            return None

        tenant_id = self._get_tenant_id()
        stmt = select(EnterpriseArtifact).where(
            EnterpriseArtifact.id == artifact_uuid,
            EnterpriseArtifact.tenant_id == tenant_id,  # security: tenant filter
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._artifact_to_summary_dto(row) if row is not None else None

    def list_cache_artifacts_by_name_type(
        self,
        name: str,
        artifact_type: str,
        ctx: "Any | None" = None,
    ) -> "list[CacheArtifactSummaryDTO]":
        """Return all ``enterprise_artifacts`` rows matching *name* and *artifact_type*.

        Applies tenant filter against ``EnterpriseArtifact.tenant_id``.

        Args:
            name: Artifact name (e.g. ``"canvas-design"``).
            artifact_type: Artifact type string (e.g. ``"skill"``).
            ctx: Optional per-request metadata (unused, reserved).

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.CacheArtifactSummaryDTO`.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifact

        tenant_id = self._get_tenant_id()
        stmt = select(EnterpriseArtifact).where(
            EnterpriseArtifact.name == name,
            EnterpriseArtifact.artifact_type == artifact_type,
            EnterpriseArtifact.tenant_id == tenant_id,  # security: tenant filter
        )
        rows = self.session.execute(stmt).scalars().all()
        return [self._artifact_to_summary_dto(row) for row in rows]

    def list_versions_for_artifacts(
        self,
        artifact_ids: "list[str]",
        ctx: "Any | None" = None,
    ) -> "list[ArtifactVersionDTO]":
        """Return version records for a set of artifact UUIDs, ordered newest-first.

        Applies tenant filter against ``EnterpriseArtifactVersion.tenant_id`` via
        ``_apply_tenant_filter()``.

        Args:
            artifact_ids: List of artifact UUID strings (enterprise format).
                The query is skipped and an empty list returned when *artifact_ids*
                is empty.
            ctx: Optional per-request metadata (unused, reserved).

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ArtifactVersionDTO` ordered by
            ``created_at`` descending.
        """
        from uuid import UUID as _UUID

        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersion

        if not artifact_ids:
            return []

        parsed_uuids: list[_UUID] = []
        for aid in artifact_ids:
            try:
                parsed_uuids.append(_UUID(aid))
            except (ValueError, AttributeError):
                logger.debug(
                    "EnterpriseArtifactHistoryRepository.list_versions_for_artifacts: "
                    "skipping invalid UUID string %r",
                    aid,
                )

        if not parsed_uuids:
            return []

        stmt = (
            select(EnterpriseArtifactVersion)
            .where(EnterpriseArtifactVersion.artifact_id.in_(parsed_uuids))
            .order_by(EnterpriseArtifactVersion.created_at.desc())
        )
        stmt = self._apply_tenant_filter(stmt)  # security: tenant filter
        rows = self.session.execute(stmt).scalars().all()
        return [self._version_to_dto(row) for row in rows]

    def get_by_composite_key(
        self,
        artifact_id: str,
        content_hash: str,
        ctx: "Any | None" = None,
    ) -> "ArtifactVersionDTO | None":
        """Return the ``EnterpriseArtifactVersion`` matching the composite key.

        Looks up by ``(artifact_id, content_hash)`` — globally unique per the
        ``uq_artifact_versions_content_hash`` constraint on the enterprise schema.
        Applies tenant filter before execution.

        Args:
            artifact_id: Artifact UUID string.
            content_hash: SHA-256 content hash of the target version (64 hex chars).
            ctx: Optional per-request metadata (unused, reserved).

        Returns:
            :class:`~skillmeat.core.interfaces.dtos.ArtifactVersionDTO` when the
            row exists within the current tenant, ``None`` otherwise.
        """
        from uuid import UUID as _UUID

        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersion

        try:
            artifact_uuid = _UUID(artifact_id)
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseArtifactHistoryRepository.get_by_composite_key: "
                "invalid artifact_id UUID string %r — returning None",
                artifact_id,
            )
            return None

        stmt = select(EnterpriseArtifactVersion).where(
            EnterpriseArtifactVersion.artifact_id == artifact_uuid,
            EnterpriseArtifactVersion.content_hash == content_hash,
        )
        stmt = self._apply_tenant_filter(stmt)  # security: tenant filter
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._version_to_dto(row) if row is not None else None

    def get_paginated_version_history(
        self,
        artifact_id: str,
        limit: int = 50,
        after: "Optional[str]" = None,
        owner_type: "Optional[str]" = None,
        owner_id: "Optional[str]" = None,
        ctx: "Any | None" = None,
    ) -> "tuple[list[dict[Any, Any]], bool]":
        """Return paginated version history for *artifact_id* with tenant isolation.

        Replaces the raw ``text()`` SQL at CS-1 / CS-2 in ``versions.py``.  Uses
        the limit+1 sentinel technique to derive ``has_next_page`` without a
        separate ``COUNT(*)`` query.

        Applies ``_apply_tenant_filter()`` before execution — this is a security
        boundary that prevents cross-tenant data leakage.

        Args:
            artifact_id: Artifact UUID string (enterprise format).
            limit: Maximum items per page (1–100).
            after: Opaque cursor — ISO-8601 timestamp string of the last seen
                item.  When provided, only rows older than this timestamp are
                returned (timestamp-based keyset pagination).
            owner_type: Optional owner type filter (reserved; not yet applied
                to the enterprise query — will be used in a future phase when
                ownership scoping is fully modelled).
            owner_id: Optional owner ID filter (reserved; same as owner_type).
            ctx: Optional per-request metadata (unused).

        Returns:
            A two-element tuple ``(items, has_next_page)``.  Each item dict
            contains: ``content_hash``, ``parent_hash``, ``change_origin``,
            ``event_type``, ``created_at``, ``actor_id``, ``diff_summary``,
            ``metadata_json``, ``version_tag``, ``version_label``,
            ``changelog``, and ``message``.
        """
        import json as _json
        from uuid import UUID as _UUID

        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersion

        try:
            artifact_uuid = _UUID(artifact_id)
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseArtifactHistoryRepository.get_paginated_version_history: "
                "invalid artifact_id UUID string %r — returning empty",
                artifact_id,
            )
            return [], False

        # Clamp limit; fetch one extra row to determine has_next_page without
        # a separate COUNT(*) query.
        clamped_limit = min(max(1, limit), 100)
        fetch_limit = clamped_limit + 1

        stmt = (
            select(EnterpriseArtifactVersion)
            .where(EnterpriseArtifactVersion.artifact_id == artifact_uuid)
            .order_by(EnterpriseArtifactVersion.created_at.desc())
        )

        # Timestamp-based keyset pagination: treat `after` as an ISO-8601
        # timestamp and return only rows strictly older than that point.
        if after:
            from datetime import datetime as _dt

            try:
                cursor_ts = _dt.fromisoformat(after.replace("Z", "+00:00"))
                stmt = stmt.where(EnterpriseArtifactVersion.created_at < cursor_ts)
            except (ValueError, AttributeError):
                # Fallback: ignore malformed cursor rather than erroring.
                logger.debug(
                    "EnterpriseArtifactHistoryRepository.get_paginated_version_history: "
                    "malformed cursor %r — ignoring",
                    after,
                )

        stmt = stmt.limit(fetch_limit)
        stmt = self._apply_tenant_filter(
            stmt
        )  # security: MUST come last before execution

        rows = self.session.execute(stmt).scalars().all()

        has_next_page = len(rows) > clamped_limit
        visible_rows = rows[:clamped_limit]

        items: list[dict[Any, Any]] = []
        for version in visible_rows:
            created_at_iso: Optional[str] = None
            if version.created_at is not None:
                if hasattr(version.created_at, "isoformat"):
                    created_at_iso = version.created_at.isoformat()
                else:
                    created_at_iso = str(version.created_at)

            change_origin = "sync" if version.commit_sha else "user"
            event_type = "created" if getattr(version, "is_ghost", False) else "updated"

            meta_val = getattr(version, "metadata_json", None)
            metadata_json = None
            if meta_val and isinstance(meta_val, str):
                try:
                    metadata_json = _json.loads(meta_val)
                except Exception:
                    pass

            items.append(
                {
                    "content_hash": version.content_hash,
                    "parent_hash": None,  # enterprise schema has no parent_hash
                    "change_origin": change_origin,
                    "event_type": event_type,
                    "created_at": created_at_iso,
                    "actor_id": (
                        str(version.created_by)
                        if getattr(version, "created_by", None)
                        else None
                    ),
                    "diff_summary": None,  # enterprise schema has no diff_summary
                    "metadata_json": metadata_json,
                    # Enterprise-specific enrichment fields
                    "version_tag": getattr(version, "version_tag", None),
                    "version_label": getattr(version, "version_label", None),
                    "changelog": getattr(version, "changelog", None),
                    "message": getattr(version, "message", None),
                }
            )

        return items, has_next_page


# =============================================================================
# EnterpriseArtifactHistoryStub  (ENT2-6.2)
# =============================================================================


class EnterpriseArtifactHistoryStub(IDbArtifactHistoryRepository):
    """Stub implementation of IDbArtifactHistoryRepository for enterprise mode.

    Artifact history is a local-SQLite feature not yet ported to the enterprise
    PostgreSQL schema.  All read methods return empty/None to keep the API
    operational while suppressing expensive or impossible DB queries.
    """

    def get_cache_artifact_by_uuid(
        self,
        uuid_str: str,
        ctx: "Any | None" = None,
    ) -> "Any | None":
        logger.debug(
            "EnterpriseArtifactHistoryStub: stub — full implementation deferred"
        )
        return None

    def list_cache_artifacts_by_name_type(
        self,
        name: str,
        artifact_type: str,
        ctx: "Any | None" = None,
    ) -> "list":
        logger.debug(
            "EnterpriseArtifactHistoryStub: stub — full implementation deferred"
        )
        return []

    def list_versions_for_artifacts(
        self,
        artifact_ids: "list[str]",
        ctx: "Any | None" = None,
    ) -> "list":
        logger.debug(
            "EnterpriseArtifactHistoryStub: stub — full implementation deferred"
        )
        return []

    def get_by_composite_key(
        self,
        artifact_id: str,
        content_hash: str,
        ctx: "Any | None" = None,
    ) -> "Any | None":
        logger.debug(
            "EnterpriseArtifactHistoryStub: stub — full implementation deferred"
        )
        return None

    def get_paginated_version_history(
        self,
        artifact_id: str,
        limit: int = 50,
        after: "Optional[str]" = None,
        owner_type: "Optional[str]" = None,
        owner_id: "Optional[str]" = None,
        ctx: "Any | None" = None,
    ) -> "tuple[list, bool]":
        logger.debug(
            "EnterpriseArtifactHistoryStub: stub — full implementation deferred"
        )
        return [], False


# =============================================================================
# EnterpriseDuplicatePairStub  (ENT2-6.3)
# =============================================================================


class EnterpriseDuplicatePairStub:
    """Stub implementation of DuplicatePairRepository for enterprise mode.

    Duplicate detection is a local-SQLite feature based on a single-tenant
    similarity scan.  It is not ported to the enterprise multi-tenant schema
    in v2.  All methods return empty/False results.
    """

    def get_by_id(self, pair_id: str) -> None:
        logger.debug(
            "DuplicatePairRepository: enterprise stub — dedup is local-only in v2"
        )
        return None

    def list_active(self, min_score: float = 0.0) -> "list":
        logger.debug(
            "DuplicatePairRepository: enterprise stub — dedup is local-only in v2"
        )
        return []

    def mark_pair_ignored(self, pair_id: str) -> bool:
        logger.debug(
            "DuplicatePairRepository: enterprise stub — dedup is local-only in v2"
        )
        return False

    def unmark_pair_ignored(self, pair_id: str) -> bool:
        logger.debug(
            "DuplicatePairRepository: enterprise stub — dedup is local-only in v2"
        )
        return False

    def list_pairs_for_artifact(self, artifact_uuid: str) -> "list":
        logger.debug(
            "DuplicatePairRepository: enterprise stub — dedup is local-only in v2"
        )
        return []


# =============================================================================
# EnterpriseDuplicatePairRepository  (enterprise-stub-promotion-v1 TASK-1.4)
# =============================================================================


class EnterpriseDuplicatePairRepository(
    EnterpriseRepositoryBase["EnterpriseDuplicatePair"],
):
    """Enterprise (PostgreSQL) implementation of the duplicate-pair repository.

    Replaces :class:`EnterpriseDuplicatePairStub` with real persistence over
    the :class:`~skillmeat.cache.models_enterprise.EnterpriseDuplicatePair`
    ORM model (``enterprise_duplicate_pairs`` table).

    Design notes
    ------------
    * All query methods call ``_apply_tenant_filter()`` before executing — this
      is a security boundary that prevents cross-tenant data leakage.
    * **Canonical pair ordering**: the application layer is responsible for
      ensuring ``artifact_a_id < artifact_b_id`` (UUID byte comparison) before
      calling :meth:`create_pair`.  The unique constraint
      ``uq_enterprise_duplicate_pairs_tenant_pair`` covers
      ``(tenant_id, artifact_a_id, artifact_b_id)`` in that fixed order; if
      callers swap the IDs they will produce duplicate rows rather than
      triggering a constraint violation.
    * **Scoring engine deferred**: the similarity score is a caller-supplied
      value; this repository never computes scores.  Pass ``None`` when no
      numeric score is available (e.g. exact hash matches).
    * **Soft-delete semantics**: :meth:`mark_pair_ignored` /
      :meth:`unmark_pair_ignored` flip the ``ignored`` flag and update
      ``ignored_at`` / ``ignored_by`` audit columns.  No rows are ever deleted
      by this repository.
    * The session lifecycle is owned by the caller (FastAPI DI or test harness).
      This class calls ``session.flush()`` after inserts to obtain generated
      primary keys and ``session.commit()`` after updates.

    Security invariant
    ------------------
    Every ``select()`` statement that queries ``enterprise_duplicate_pairs``
    **MUST** pass through ``_apply_tenant_filter()`` before execution.
    Bypassing this check is a cross-tenant data leakage defect.

    Parameters
    ----------
    session:
        Injected SQLAlchemy ``Session`` (PostgreSQL enterprise database).
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseDuplicatePair

        super().__init__(session, EnterpriseDuplicatePair)

    # ------------------------------------------------------------------
    # Read helpers
    # ------------------------------------------------------------------

    def get_by_id(self, pair_id: str) -> "Optional[EnterpriseDuplicatePair]":
        """Return the ``EnterpriseDuplicatePair`` row with the given UUID, or ``None``.

        Applies tenant filter so cross-tenant lookups return ``None`` rather
        than a foreign row.

        Args:
            pair_id: UUID string (hyphenated or hex) of the pair record.

        Returns:
            The matching ORM row, or ``None`` when not found or not visible
            to the current tenant.

        Example:
            >>> pair = repo.get_by_id("aaaaaaaa-0000-4000-a000-000000000001")
        """
        from uuid import UUID as _UUID

        from skillmeat.cache.models_enterprise import EnterpriseDuplicatePair

        try:
            pair_uuid = _UUID(str(pair_id))
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseDuplicatePairRepository.get_by_id: "
                "invalid UUID string %r — returning None",
                pair_id,
            )
            return None

        stmt = self._apply_tenant_filter(
            select(EnterpriseDuplicatePair).where(
                EnterpriseDuplicatePair.id == pair_uuid,
            )
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def list_active(self, min_score: float = 0.0) -> "List[EnterpriseDuplicatePair]":
        """Return all non-ignored pairs whose similarity score is >= *min_score*.

        ``NULL`` similarity scores (exact-match pairs without a numeric score)
        are **included** regardless of *min_score* because they represent
        certain duplicates.  Pairs are returned ordered by
        ``similarity_score`` descending (``NULL`` sorts last in PostgreSQL).

        Applies tenant filter via ``_apply_tenant_filter()``.

        Args:
            min_score: Minimum similarity threshold (0.0 = all non-ignored pairs).

        Returns:
            Tenant-scoped list of active (non-ignored) pair ORM rows.  May be
            empty.

        Example:
            >>> pairs = repo.list_active(min_score=0.5)
            >>> for p in pairs:
            ...     print(p.artifact_a_id, p.artifact_b_id, p.similarity_score)
        """
        from sqlalchemy import or_

        from skillmeat.cache.models_enterprise import EnterpriseDuplicatePair

        stmt = self._apply_tenant_filter(
            select(EnterpriseDuplicatePair).where(
                EnterpriseDuplicatePair.ignored.is_(False),
                # Include rows where score IS NULL (exact-match pairs) or
                # score meets the threshold.
                or_(
                    EnterpriseDuplicatePair.similarity_score.is_(None),
                    EnterpriseDuplicatePair.similarity_score >= min_score,
                ),
            )
        ).order_by(EnterpriseDuplicatePair.similarity_score.desc())
        return list(self.session.execute(stmt).scalars().all())

    def list_pairs_for_artifact(
        self, artifact_uuid: str
    ) -> "List[EnterpriseDuplicatePair]":
        """Return all non-ignored pair rows where *artifact_uuid* is either member.

        Queries rows where ``artifact_a_id`` OR ``artifact_b_id`` equals the
        provided UUID and ``ignored`` is ``False``.  Applies tenant filter.

        Args:
            artifact_uuid: UUID string (hyphenated or hex) of the artifact.

        Returns:
            Tenant-scoped list of active pair ORM rows.  May be empty.

        Example:
            >>> pairs = repo.list_pairs_for_artifact(str(some_uuid))
        """
        from uuid import UUID as _UUID

        from sqlalchemy import or_

        from skillmeat.cache.models_enterprise import EnterpriseDuplicatePair

        try:
            art_uuid = _UUID(str(artifact_uuid))
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseDuplicatePairRepository.list_pairs_for_artifact: "
                "invalid UUID string %r — returning empty list",
                artifact_uuid,
            )
            return []

        stmt = self._apply_tenant_filter(
            select(EnterpriseDuplicatePair).where(
                EnterpriseDuplicatePair.ignored.is_(False),
                or_(
                    EnterpriseDuplicatePair.artifact_a_id == art_uuid,
                    EnterpriseDuplicatePair.artifact_b_id == art_uuid,
                ),
            )
        )
        return list(self.session.execute(stmt).scalars().all())

    # ------------------------------------------------------------------
    # Write helpers
    # ------------------------------------------------------------------

    def create_pair(
        self,
        artifact_a_id: "uuid.UUID",
        artifact_b_id: "uuid.UUID",
        tenant_id: "uuid.UUID",
        similarity_score: "Optional[float]" = None,
        match_reasons: "Optional[List[Any]]" = None,
        metadata: "Optional[Dict[str, Any]]" = None,
    ) -> "EnterpriseDuplicatePair":
        """Persist a new duplicate-pair record and return the ORM row.

        **Canonical ordering**: the caller is responsible for ensuring
        ``artifact_a_id < artifact_b_id`` (UUID byte comparison) before
        calling this method.  The unique constraint on
        ``(tenant_id, artifact_a_id, artifact_b_id)`` treats ``(a, b)`` and
        ``(b, a)`` as distinct entries; incorrect ordering will create a
        duplicate row instead of triggering a constraint violation.

        Args:
            artifact_a_id:    UUID of the "lesser" artifact in the pair.
            artifact_b_id:    UUID of the "greater" artifact in the pair.
            tenant_id:        Tenant scope for the pair row.
            similarity_score: Pre-computed score [0.0, 1.0] or ``None`` for
                              exact-match pairs where a numeric score is
                              redundant.  Score validation is performed by the
                              DB-level check constraint.
            match_reasons:    List of reason strings (e.g.
                              ``["same_content_hash"]``), stored as JSONB.
                              Pass ``None`` or an empty list when no reasons
                              are available.
            metadata:         Open-ended JSONB annotations (e.g. pipeline
                              version, cluster ID).  Pass ``None`` when not
                              needed.

        Returns:
            The newly created and flushed :class:`EnterpriseDuplicatePair`
            ORM row (``id`` is populated after flush).

        Raises:
            sqlalchemy.exc.IntegrityError: On unique-constraint violation
                (duplicate pair already exists for this tenant).

        Example:
            >>> a, b = sorted([uuid_1, uuid_2])  # enforce canonical order
            >>> pair = repo.create_pair(a, b, tenant_id, similarity_score=0.92)
        """
        from skillmeat.cache.models_enterprise import EnterpriseDuplicatePair

        row = EnterpriseDuplicatePair(
            tenant_id=tenant_id,
            artifact_a_id=artifact_a_id,
            artifact_b_id=artifact_b_id,
            similarity_score=similarity_score,
            match_reasons=match_reasons if match_reasons else None,
            metadata_=metadata,
            ignored=False,
        )
        self.session.add(row)
        self.session.flush()

        logger.info(
            "EnterpriseDuplicatePairRepository.create_pair: "
            "created pair id=%s (a=%s, b=%s, score=%s)",
            row.id,
            artifact_a_id,
            artifact_b_id,
            similarity_score,
        )
        return row

    def mark_pair_ignored(
        self,
        pair_id: str,
        ignored_by: "Optional[str]" = None,
    ) -> bool:
        """Set ``ignored=True`` on the pair row identified by *pair_id*.

        Idempotent: if the pair is already ignored the call still succeeds and
        returns ``True``.  Sets ``ignored_at`` to the current UTC timestamp and
        ``ignored_by`` to *ignored_by* when provided.

        Applies tenant filter so callers cannot ignore pairs belonging to other
        tenants.

        Args:
            pair_id:   UUID string of the pair record.
            ignored_by: Optional user ID of the dismisser (stored for audit).

        Returns:
            ``True`` when the pair was found (and was updated or was already
            ignored), ``False`` when no visible pair with *pair_id* exists.

        Raises:
            sqlalchemy.exc.SQLAlchemyError: On unexpected database errors.

        Example:
            >>> success = repo.mark_pair_ignored(str(pair.id), ignored_by="user-abc")
        """
        from uuid import UUID as _UUID

        from skillmeat.cache.models_enterprise import EnterpriseDuplicatePair

        try:
            pair_uuid = _UUID(str(pair_id))
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseDuplicatePairRepository.mark_pair_ignored: "
                "invalid UUID string %r — returning False",
                pair_id,
            )
            return False

        stmt = self._apply_tenant_filter(
            select(EnterpriseDuplicatePair).where(
                EnterpriseDuplicatePair.id == pair_uuid,
            )
        )
        pair = self.session.execute(stmt).scalar_one_or_none()

        if pair is None:
            logger.debug(
                "EnterpriseDuplicatePairRepository.mark_pair_ignored: "
                "pair id=%r not found (or not visible for current tenant).",
                pair_id,
            )
            return False

        pair.ignored = True
        pair.ignored_at = datetime.utcnow()
        pair.ignored_by = ignored_by

        self.session.commit()

        logger.info(
            "EnterpriseDuplicatePairRepository: marked pair id=%r as ignored "
            "(ignored_by=%r).",
            pair_id,
            ignored_by,
        )
        return True

    def unmark_pair_ignored(self, pair_id: str) -> bool:
        """Set ``ignored=False`` on the pair row identified by *pair_id*.

        Idempotent: if the pair is already active the call still succeeds and
        returns ``True``.  Clears ``ignored_at`` and ``ignored_by`` to ``None``.

        Applies tenant filter so callers cannot un-ignore pairs belonging to
        other tenants.

        Args:
            pair_id: UUID string of the pair record.

        Returns:
            ``True`` when the pair was found (and was updated or was already
            active), ``False`` when no visible pair with *pair_id* exists.

        Raises:
            sqlalchemy.exc.SQLAlchemyError: On unexpected database errors.

        Example:
            >>> repo.mark_pair_ignored(str(pair.id))
            True
            >>> repo.unmark_pair_ignored(str(pair.id))
            True
        """
        from uuid import UUID as _UUID

        from skillmeat.cache.models_enterprise import EnterpriseDuplicatePair

        try:
            pair_uuid = _UUID(str(pair_id))
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseDuplicatePairRepository.unmark_pair_ignored: "
                "invalid UUID string %r — returning False",
                pair_id,
            )
            return False

        stmt = self._apply_tenant_filter(
            select(EnterpriseDuplicatePair).where(
                EnterpriseDuplicatePair.id == pair_uuid,
            )
        )
        pair = self.session.execute(stmt).scalar_one_or_none()

        if pair is None:
            logger.debug(
                "EnterpriseDuplicatePairRepository.unmark_pair_ignored: "
                "pair id=%r not found (or not visible for current tenant).",
                pair_id,
            )
            return False

        pair.ignored = False
        pair.ignored_at = None
        pair.ignored_by = None

        self.session.commit()

        logger.info(
            "EnterpriseDuplicatePairRepository: unmarked pair id=%r (now active).",
            pair_id,
        )
        return True


# =============================================================================
# EnterpriseArtifactActivityRepository  (TASK-3.3)
# =============================================================================


class EnterpriseArtifactActivityRepository(IArtifactActivityRepository):
    """Enterprise (PostgreSQL) implementation of ``IArtifactActivityRepository``.

    Manages :class:`~skillmeat.cache.models.ArtifactHistoryEvent` rows using
    SQLAlchemy 2.x ``select()`` style, consistent with all other enterprise
    repositories in this module.

    Design notes
    ------------
    * ``ArtifactHistoryEvent`` is a shared model (not an enterprise-only model)
      and does **not** carry a ``tenant_id`` column.  Multi-tenant scoping is
      achieved via the ``owner_type`` column, which callers populate with the
      active tenant / owner context string.  The ``list_events``,
      ``count_events``, and ``list_provenance_slice`` methods accept an
      optional ``owner_type`` filter to restrict results to a single tenant.
    * Events are **immutable** once written.  No ``update`` or ``delete``
      methods are provided.
    * The session lifecycle is owned by the caller (FastAPI DI or test
      harness).  This class only calls ``session.flush()`` after an insert to
      obtain the generated primary key; commit/rollback is the caller's
      responsibility.

    Parameters
    ----------
    session:
        An open :class:`sqlalchemy.orm.Session` bound to the enterprise
        PostgreSQL database.
    """

    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # DTO converter
    # ------------------------------------------------------------------

    @staticmethod
    def _to_dto(event: "ArtifactHistoryEvent") -> "ActivityEventDTO":
        """Convert an ``ArtifactHistoryEvent`` ORM instance to an :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO`.

        Parameters
        ----------
        event:
            ORM instance to convert.

        Returns
        -------
        ActivityEventDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import ActivityEventDTO

        return ActivityEventDTO(
            id=str(event.id),
            artifact_id=str(event.artifact_id),
            event_type=event.event_type,
            owner_type=event.owner_type,
            timestamp=event.timestamp.isoformat() if event.timestamp else None,
            actor_id=str(event.actor_id) if event.actor_id is not None else None,
            diff_json=event.diff_json,
            content_hash=event.content_hash,
        )

    # ------------------------------------------------------------------
    # Mutations (insert-only)
    # ------------------------------------------------------------------

    def create_event(
        self,
        artifact_id: str,
        event_type: str,
        actor_id: Optional[str],
        owner_type: str,
        diff_json: Optional[str],
        content_hash: Optional[str],
        ctx: "Any | None" = None,
    ) -> "ActivityEventDTO":
        """Append a new lifecycle event to the activity log.

        Args:
            artifact_id: Primary key of the artifact (``"type:name"`` format).
            event_type: One of ``'create'``, ``'update'``, ``'delete'``,
                ``'deploy'``, ``'undeploy'``, or ``'sync'``.
            actor_id: Opaque identifier for the user or system that triggered
                the event; ``None`` for automated/system events.
            owner_type: Owner context string at the time of the event.  Used
                as the multi-tenant scope key in the absence of a dedicated
                ``tenant_id`` column on this model.
            diff_json: JSON-serialised diff payload, or ``None``.
            content_hash: SHA-256 hex digest of artifact content, or ``None``.
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            The newly created :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO`
            instance with ``id`` populated after flush.
        """
        from skillmeat.cache.auth_types import OwnerType
        from skillmeat.cache.models import ArtifactHistoryEvent

        resolved_owner_type = owner_type or OwnerType.user.value
        event = ArtifactHistoryEvent(
            artifact_id=artifact_id,
            event_type=event_type,
            actor_id=actor_id,
            owner_type=resolved_owner_type,
            diff_json=diff_json,
            content_hash=content_hash,
        )
        self.session.add(event)
        self.session.flush()
        logger.debug(
            "EnterpriseArtifactActivityRepository.create_event: "
            "id=%s artifact_id=%s event_type=%s owner_type=%s",
            event.id,
            artifact_id,
            event_type,
            resolved_owner_type,
        )
        return self._to_dto(event)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def list_events(
        self,
        artifact_id: Optional[str] = None,
        event_type: Optional[str] = None,
        actor_id: Optional[str] = None,
        owner_type: Optional[str] = None,
        time_range: Optional[Tuple[datetime, datetime]] = None,
        limit: int = 100,
        offset: int = 0,
        ctx: "Any | None" = None,
    ) -> "list[ActivityEventDTO]":
        """Return a filtered, paginated slice of activity events.

        All filter arguments are optional and AND-ed together when provided.

        Args:
            artifact_id: Restrict to events for this artifact primary key.
            event_type: Restrict to events of this type.
            actor_id: Restrict to events triggered by this actor.
            owner_type: Restrict to events with this owner context.  Use this
                to scope results to a specific tenant in multi-tenant
                deployments.
            time_range: ``(start, end)`` inclusive window in UTC.
            limit: Maximum number of rows to return (default 100).
            offset: Number of rows to skip for pagination (default 0).
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO` ordered
            by ``timestamp`` ascending, then ``id`` ascending.
        """
        from skillmeat.cache.models import ArtifactHistoryEvent

        stmt = select(ArtifactHistoryEvent)

        if artifact_id is not None:
            stmt = stmt.where(ArtifactHistoryEvent.artifact_id == artifact_id)
        if event_type is not None:
            stmt = stmt.where(ArtifactHistoryEvent.event_type == event_type)
        if actor_id is not None:
            stmt = stmt.where(ArtifactHistoryEvent.actor_id == actor_id)
        if owner_type is not None:
            stmt = stmt.where(ArtifactHistoryEvent.owner_type == owner_type)
        if time_range is not None:
            start, end = time_range
            stmt = stmt.where(ArtifactHistoryEvent.timestamp >= start)
            stmt = stmt.where(ArtifactHistoryEvent.timestamp <= end)

        stmt = (
            stmt.order_by(
                ArtifactHistoryEvent.timestamp.asc(),
                ArtifactHistoryEvent.id.asc(),
            )
            .offset(offset)
            .limit(limit)
        )
        return [self._to_dto(e) for e in self.session.execute(stmt).scalars().all()]

    def get_event(
        self,
        event_id: str,
        ctx: "Any | None" = None,
    ) -> "ActivityEventDTO | None":
        """Return a single event by its string-form primary key.

        Accepts a UUID string as per the updated
        :class:`~skillmeat.core.interfaces.repositories.IArtifactActivityRepository`
        contract.  The string is coerced to ``uuid.UUID`` before querying
        because the local ``ArtifactHistoryEvent`` ORM (currently backing
        this stub) uses an integer PK.  When this stub is replaced by a real
        enterprise implementation the model import and coercion will change
        to ``EnterpriseArtifactHistoryEvent``.

        Args:
            event_id: String-form primary key of the event row.
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            The matching :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO`
            when found, ``None`` otherwise.
        """
        from skillmeat.cache.models import ArtifactHistoryEvent

        try:
            numeric_id = int(event_id)
        except (ValueError, TypeError):
            return None
        stmt = select(ArtifactHistoryEvent).where(ArtifactHistoryEvent.id == numeric_id)
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._to_dto(row) if row is not None else None

    def count_events(
        self,
        artifact_id: Optional[str] = None,
        event_type: Optional[str] = None,
        owner_type: Optional[str] = None,
        ctx: "Any | None" = None,
    ) -> int:
        """Return the count of events matching the given filters.

        Args:
            artifact_id: Restrict count to events for this artifact.
            event_type: Restrict count to events of this type.
            owner_type: Restrict count to events with this owner context.
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            Non-negative integer count of matching event rows.
        """
        from sqlalchemy import func

        from skillmeat.cache.models import ArtifactHistoryEvent

        stmt = select(func.count()).select_from(ArtifactHistoryEvent)

        if artifact_id is not None:
            stmt = stmt.where(ArtifactHistoryEvent.artifact_id == artifact_id)
        if event_type is not None:
            stmt = stmt.where(ArtifactHistoryEvent.event_type == event_type)
        if owner_type is not None:
            stmt = stmt.where(ArtifactHistoryEvent.owner_type == owner_type)

        result = self.session.execute(stmt).scalar_one()
        return int(result)

    def list_provenance_slice(
        self,
        artifact_id: str,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        ctx: "Any | None" = None,
    ) -> "list[ActivityEventDTO]":
        """Return the ordered provenance timeline for a single artifact.

        Returns all events for *artifact_id* within the optional time window,
        ordered chronologically ascending.

        Args:
            artifact_id: Primary key of the artifact whose provenance is
                requested.
            since: Lower bound (inclusive) of the time window in UTC.
                When ``None``, no lower bound is applied.
            until: Upper bound (inclusive) of the time window in UTC.
                When ``None``, no upper bound is applied.
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO` ordered
            by ``timestamp`` ascending, then ``id`` ascending.
        """
        from skillmeat.cache.models import ArtifactHistoryEvent

        stmt = select(ArtifactHistoryEvent).where(
            ArtifactHistoryEvent.artifact_id == artifact_id
        )

        if since is not None:
            stmt = stmt.where(ArtifactHistoryEvent.timestamp >= since)
        if until is not None:
            stmt = stmt.where(ArtifactHistoryEvent.timestamp <= until)

        stmt = stmt.order_by(
            ArtifactHistoryEvent.timestamp.asc(),
            ArtifactHistoryEvent.id.asc(),
        )
        return [self._to_dto(e) for e in self.session.execute(stmt).scalars().all()]


# ---------------------------------------------------------------------------
# EnterpriseArtifactVersionScopeRepository  (REPO-2.2)
# ---------------------------------------------------------------------------


class EnterpriseArtifactVersionScopeRepository(
    EnterpriseRepositoryBase["EnterpriseArtifactVersionScope"]
):
    """CRUD repository for ``artifact_version_scopes`` rows.

    Manages per-owner-per-project version scope state for enterprise
    artifacts.  Every query is scoped to the current tenant via
    ``_apply_tenant_filter`` / ``_tenant_select`` — cross-tenant data
    access is structurally prevented.

    Design contract
    ---------------
    - Mutations call ``session.flush()`` so that the caller's transaction
      includes the change without an implicit commit.
    - Transaction lifecycle (commit/rollback) is the caller's responsibility.
    - ``lazy_bootstrap_scope`` is idempotent: calling it multiple times with
      the same key returns the existing row without raising or modifying it.

    Tenant isolation invariant
    --------------------------
    ALL queries MUST include a ``WHERE tenant_id = ?`` predicate.  This is
    guaranteed structurally by always calling ``_tenant_select()`` or
    ``_apply_tenant_filter()`` before executing any statement.

    Parameters
    ----------
    session:
        Injected SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.  Typically provided via ``DbSessionDep`` in FastAPI routes.

    References
    ----------
    REPO-2.2 task — artifact-version-history-restore Phase 1.
    Model: ``skillmeat.cache.models_enterprise.EnterpriseArtifactVersionScope``
    Migration: ``ent_010_version_scopes_and_history_tenant``
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        super().__init__(session, EnterpriseArtifactVersionScope)

    # ------------------------------------------------------------------
    # DTO converter
    # ------------------------------------------------------------------

    @staticmethod
    def _to_dto(model: "EnterpriseArtifactVersionScope") -> "ArtifactVersionScopeDTO":
        """Convert an ``EnterpriseArtifactVersionScope`` ORM instance to an :class:`~skillmeat.core.interfaces.dtos.ArtifactVersionScopeDTO`.

        Parameters
        ----------
        model:
            ORM instance to convert.

        Returns
        -------
        ArtifactVersionScopeDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import ArtifactVersionScopeDTO

        return ArtifactVersionScopeDTO(
            id=str(model.id),
            tenant_id=str(model.tenant_id),
            project_id=str(model.project_id),
            artifact_id=str(model.artifact_id),
            owner_type=model.owner_type,
            owner_id=str(model.owner_id),
            head_hash=model.head_hash,
            baseline_hash=model.baseline_hash,
            is_diverged=bool(model.is_diverged),
            promotion_state=model.promotion_state,
            created_at=model.created_at.isoformat() if model.created_at else None,
            updated_at=model.updated_at.isoformat() if model.updated_at else None,
        )

    # ------------------------------------------------------------------
    # Create
    # ------------------------------------------------------------------

    def create(
        self,
        tenant_id: uuid.UUID,
        project_id: uuid.UUID,
        artifact_id: uuid.UUID,
        owner_type: str,
        owner_id: uuid.UUID,
        head_hash: str,
        baseline_hash: Optional[str] = None,
    ) -> "ArtifactVersionScopeDTO":
        """Create and persist a new version scope row.

        Parameters
        ----------
        tenant_id:
            Tenant the scope belongs to.  Must match the current
            ``TenantContext`` value (enforced by ``_assert_tenant_owns``
            after flush).
        project_id:
            Project UUID this scope entry belongs to.
        artifact_id:
            FK to ``enterprise_artifacts.id`` for the scoped artifact.
        owner_type:
            Owner category: ``'user'``, ``'team'``, or ``'enterprise'``.
        owner_id:
            UUID of the owning user, team, or enterprise entity.
        head_hash:
            SHA-256 hex digest (64 chars) of the current head content.
        baseline_hash:
            Optional SHA-256 hex digest of the last approved baseline.
            Defaults to ``None`` (no baseline established yet).

        Returns
        -------
        ArtifactVersionScopeDTO
            DTO representation of the newly created, flushed scope row (not yet committed).
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        scope = EnterpriseArtifactVersionScope(
            tenant_id=tenant_id,
            project_id=project_id,
            artifact_id=artifact_id,
            owner_type=owner_type,
            owner_id=owner_id,
            head_hash=head_hash,
            baseline_hash=baseline_hash,
            is_diverged=False,
            sync_status=_derive_sync_status(
                head_hash=head_hash,
                baseline_hash=baseline_hash,
                is_diverged=False,
            ),
        )
        self.session.add(scope)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type=self.model_class.__name__,
            entity_id=scope.id,
            metadata={
                "project_id": str(project_id),
                "artifact_id": str(artifact_id),
                "owner_type": owner_type,
                "owner_id": str(owner_id),
            },
        )
        logger.debug(
            "Created %s id=%s tenant=%s artifact=%s owner=%s/%s",
            self.model_class.__name__,
            scope.id,
            tenant_id,
            artifact_id,
            owner_type,
            owner_id,
        )
        return self._to_dto(scope)

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read_by_owner(
        self,
        tenant_id: uuid.UUID,
        project_id: uuid.UUID,
        artifact_id: uuid.UUID,
        owner_type: str,
        owner_id: uuid.UUID,
    ) -> "Optional[ArtifactVersionScopeDTO]":
        """Return the scope row for a specific owner, or ``None`` if absent.

        Looks up the unique ``(tenant_id, project_id, artifact_id,
        owner_type, owner_id)`` combination guaranteed by the
        ``uq_version_scopes_owner_artifact_project`` constraint.

        Parameters
        ----------
        tenant_id:
            Tenant scope — used both for tenant filter and explicit column
            predicate.
        project_id:
            Project UUID to filter on.
        artifact_id:
            Artifact UUID to filter on.
        owner_type:
            Owner category (``'user'``, ``'team'``, or ``'enterprise'``).
        owner_id:
            UUID of the owning entity.

        Returns
        -------
        ArtifactVersionScopeDTO or None
            DTO for the matching scope row, or ``None`` if no row exists for
            this owner combination.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        stmt = (
            self._apply_tenant_filter(select(EnterpriseArtifactVersionScope))
            .where(EnterpriseArtifactVersionScope.tenant_id == tenant_id)
            .where(EnterpriseArtifactVersionScope.project_id == project_id)
            .where(EnterpriseArtifactVersionScope.artifact_id == artifact_id)
            .where(EnterpriseArtifactVersionScope.owner_type == owner_type)
            .where(EnterpriseArtifactVersionScope.owner_id == owner_id)
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._to_dto(row) if row is not None else None

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    def update_head_hash(
        self,
        scope_id: uuid.UUID,
        tenant_id: uuid.UUID,
        new_hash: str,
    ) -> "ArtifactVersionScopeDTO":
        """Update ``head_hash`` and ``updated_at`` for an existing scope row.

        Fetches the row by primary key, asserts tenant ownership, then
        applies the hash update and flushes.

        Parameters
        ----------
        scope_id:
            UUID primary key of the scope row to update.
        tenant_id:
            Tenant that must own the row; used to verify isolation.
        new_hash:
            New SHA-256 hex digest (64 chars) for the head content.

        Returns
        -------
        ArtifactVersionScopeDTO
            DTO of the updated scope row (not yet committed).

        Raises
        ------
        ValueError
            If no scope row exists for *scope_id* under *tenant_id*.
        TenantIsolationError
            If the retrieved row belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        scope = self.session.get(EnterpriseArtifactVersionScope, scope_id)
        if scope is None:
            raise ValueError(
                f"EnterpriseArtifactVersionScope id={scope_id!s} not found"
            )
        self._assert_tenant_owns(scope)
        old_hash = scope.head_hash
        scope.head_hash = new_hash
        scope.sync_status = _derive_sync_status(
            head_hash=new_hash,
            baseline_hash=scope.baseline_hash,
            is_diverged=scope.is_diverged,
        )
        scope.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update_head_hash",
            entity_type=self.model_class.__name__,
            entity_id=scope_id,
            metadata={"old_hash": old_hash, "new_hash": new_hash},
        )
        return self._to_dto(scope)

    def mark_diverged(
        self,
        scope_id: uuid.UUID,
        tenant_id: uuid.UUID,
        is_diverged: bool,
    ) -> "ArtifactVersionScopeDTO":
        """Set the ``is_diverged`` flag on a scope row.

        Parameters
        ----------
        scope_id:
            UUID primary key of the scope row to update.
        tenant_id:
            Tenant that must own the row; used to verify isolation.
        is_diverged:
            New divergence state to apply.

        Returns
        -------
        ArtifactVersionScopeDTO
            DTO of the updated scope row (not yet committed).

        Raises
        ------
        ValueError
            If no scope row exists for *scope_id* under *tenant_id*.
        TenantIsolationError
            If the retrieved row belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        scope = self.session.get(EnterpriseArtifactVersionScope, scope_id)
        if scope is None:
            raise ValueError(
                f"EnterpriseArtifactVersionScope id={scope_id!s} not found"
            )
        self._assert_tenant_owns(scope)
        scope.is_diverged = is_diverged
        scope.sync_status = _derive_sync_status(
            head_hash=scope.head_hash,
            baseline_hash=scope.baseline_hash,
            is_diverged=is_diverged,
        )
        scope.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="mark_diverged",
            entity_type=self.model_class.__name__,
            entity_id=scope_id,
            metadata={"is_diverged": is_diverged, "sync_status": scope.sync_status},
        )
        return self._to_dto(scope)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_all_diverged_by_project(
        self,
        tenant_id: uuid.UUID,
        project_id: uuid.UUID,
    ) -> "List[ArtifactVersionScopeDTO]":
        """Return all scope rows where ``is_diverged=True`` for a project.

        Uses the partial index ``idx_version_scopes_diverged``
        (``WHERE is_diverged = TRUE``) created by migration ``ent_010``
        for efficient filtering on PostgreSQL.

        Parameters
        ----------
        tenant_id:
            Tenant scope — applied both via ``_apply_tenant_filter`` and
            as an explicit predicate to guarantee isolation.
        project_id:
            Project UUID to restrict results to.

        Returns
        -------
        list[ArtifactVersionScopeDTO]
            DTOs for all diverged scope rows for the given project, ordered by
            ``created_at`` ascending for deterministic iteration.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        stmt = (
            self._apply_tenant_filter(select(EnterpriseArtifactVersionScope))
            .where(EnterpriseArtifactVersionScope.tenant_id == tenant_id)
            .where(EnterpriseArtifactVersionScope.project_id == project_id)
            .where(EnterpriseArtifactVersionScope.is_diverged.is_(True))
            .order_by(EnterpriseArtifactVersionScope.created_at.asc())
        )
        return [self._to_dto(row) for row in self.session.execute(stmt).scalars().all()]

    # ------------------------------------------------------------------
    # Idempotent bootstrap
    # ------------------------------------------------------------------

    def lazy_bootstrap_scope(
        self,
        tenant_id: uuid.UUID,
        project_id: uuid.UUID,
        artifact_id: uuid.UUID,
        owner_type: str,
        owner_id: uuid.UUID,
        head_hash: str,
    ) -> "ArtifactVersionScopeDTO":
        """Return an existing scope row or create a new one if absent.

        This method is idempotent: calling it multiple times with the same
        key ``(tenant_id, project_id, artifact_id, owner_type, owner_id)``
        will always return the same row.  When a row already exists, no
        mutation occurs — the existing scope is returned as-is.  When no
        row exists, a new one is created with *head_hash* used as both
        ``head_hash`` and ``baseline_hash``, establishing the initial
        approved baseline.

        Parameters
        ----------
        tenant_id:
            Tenant scope for the scope row.
        project_id:
            Project UUID this scope belongs to.
        artifact_id:
            FK to ``enterprise_artifacts.id``.
        owner_type:
            Owner category: ``'user'``, ``'team'``, or ``'enterprise'``.
        owner_id:
            UUID of the owning entity.
        head_hash:
            SHA-256 hex digest used as ``head_hash`` (and ``baseline_hash``)
            when a new row is created.  Ignored when an existing row is
            returned.

        Returns
        -------
        ArtifactVersionScopeDTO
            DTO for the existing scope row if one was found, otherwise the
            newly created row (flushed but not committed).
        """
        existing = self.read_by_owner(
            tenant_id=tenant_id,
            project_id=project_id,
            artifact_id=artifact_id,
            owner_type=owner_type,
            owner_id=owner_id,
        )
        if existing is not None:
            logger.debug(
                "lazy_bootstrap_scope: found existing scope id=%s for "
                "artifact=%s owner=%s/%s — skipping create",
                existing.id,
                artifact_id,
                owner_type,
                owner_id,
            )
            return existing

        logger.debug(
            "lazy_bootstrap_scope: no scope found for artifact=%s owner=%s/%s "
            "— creating with head_hash=%s...",
            artifact_id,
            owner_type,
            owner_id,
            head_hash[:12],
        )
        return self.create(
            tenant_id=tenant_id,
            project_id=project_id,
            artifact_id=artifact_id,
            owner_type=owner_type,
            owner_id=owner_id,
            head_hash=head_hash,
            baseline_hash=head_hash,
        )

    # ------------------------------------------------------------------
    # Topology helpers
    # ------------------------------------------------------------------

    def get_scopes_by_hash(
        self,
        artifact_id: uuid.UUID,
        tenant_id: uuid.UUID,
        content_hash: str,
    ) -> "List[Dict[str, object]]":
        """Return all scope rows whose ``head_hash`` matches *content_hash*.

        Single JOIN-free query filtered by ``artifact_id``, ``tenant_id``,
        and ``head_hash``.  Returns a list of plain dicts so the caller does
        not need to import the ORM model.

        Parameters
        ----------
        artifact_id:
            UUID of the artifact to filter scopes on.
        tenant_id:
            Tenant that must own every returned row.
        content_hash:
            SHA-256 hex digest (64 chars) to match against ``head_hash``.

        Returns
        -------
        list[dict]
            Each dict contains:
            ``owner_type`` (str), ``owner_id`` (str — UUID as hex string),
            ``head_hash`` (str), ``is_diverged`` (bool),
            ``promotion_state`` (str).
            Returns an empty list when no matching rows exist.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        stmt = (
            self._apply_tenant_filter(
                select(
                    EnterpriseArtifactVersionScope.owner_type,
                    EnterpriseArtifactVersionScope.owner_id,
                    EnterpriseArtifactVersionScope.head_hash,
                    EnterpriseArtifactVersionScope.is_diverged,
                    EnterpriseArtifactVersionScope.promotion_state,
                )
            )
            .where(EnterpriseArtifactVersionScope.tenant_id == tenant_id)
            .where(EnterpriseArtifactVersionScope.artifact_id == artifact_id)
            .where(EnterpriseArtifactVersionScope.head_hash == content_hash)
        )
        rows = self.session.execute(stmt).all()
        return [
            {
                "owner_type": row.owner_type,
                "owner_id": str(row.owner_id),
                "head_hash": row.head_hash,
                "is_diverged": row.is_diverged,
                "promotion_state": row.promotion_state or "none",
            }
            for row in rows
        ]

    # ------------------------------------------------------------------
    # Pair comparison
    # ------------------------------------------------------------------

    def get_scope_pair(
        self,
        artifact_id: uuid.UUID,
        left_owner_type: str,
        right_owner_type: str,
        tenant_id: uuid.UUID,
        team_id: Optional[uuid.UUID] = None,
        developer_id: Optional[uuid.UUID] = None,
    ) -> "Tuple[ArtifactVersionScopeDTO, ArtifactVersionScopeDTO]":
        """Return a (left, right) pair of scope rows for tier comparison.

        Fetches two :class:`EnterpriseArtifactVersionScope` rows for the same
        artifact under different ownership tiers, enabling divergence comparison
        between e.g. a user's local version and the team or enterprise baseline.

        Both queries hit the composite index
        ``(tenant_id, project_id, artifact_id, owner_type)`` — no additional
        round-trips are incurred.

        Ownership resolution
        --------------------
        The ``owner_id`` used for each query depends on ``owner_type``:

        - ``'enterprise'``: ``owner_id`` is inferred from ``tenant_id``
          (the enterprise entity *is* the tenant in single-tenant deployments).
        - ``'team'``: ``owner_id`` is taken from *team_id*.  Raises
          ``ValueError`` if *team_id* is ``None``.
        - ``'user'``: ``owner_id`` is taken from *developer_id*.  Raises
          ``ValueError`` if *developer_id* is ``None``.

        Parameters
        ----------
        artifact_id:
            UUID of the artifact whose scope rows are being compared.
        left_owner_type:
            Ownership tier for the left side of the comparison
            (``'user'``, ``'team'``, or ``'enterprise'``).
        right_owner_type:
            Ownership tier for the right side of the comparison
            (``'user'``, ``'team'``, or ``'enterprise'``).
        tenant_id:
            Tenant scope — applied to both queries.
        team_id:
            UUID of the team; required when either *left_owner_type* or
            *right_owner_type* is ``'team'``.
        developer_id:
            UUID of the developer/user; required when either
            *left_owner_type* or *right_owner_type* is ``'user'``.

        Returns
        -------
        tuple[ArtifactVersionScopeDTO, ArtifactVersionScopeDTO]
            ``(left_scope, right_scope)`` DTOs for the requested tiers.

        Raises
        ------
        ValueError
            If *team_id* is ``None`` when a team-level owner type is
            requested, or if *developer_id* is ``None`` when a user-level
            owner type is requested.
        ValueError
            If either the left or right scope row does not exist for the
            given *artifact_id* and *tenant_id* combination.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        def _resolve_owner_id(owner_type: str) -> uuid.UUID:
            """Map owner_type to the appropriate owner_id UUID."""
            if owner_type == "enterprise":
                # The enterprise entity is identified by tenant_id itself in
                # single-tenant deployments.
                return tenant_id
            if owner_type == "team":
                if team_id is None:
                    raise ValueError(
                        "team_id is required when owner_type='team' but was not provided"
                    )
                return team_id
            if owner_type == "user":
                if developer_id is None:
                    raise ValueError(
                        "developer_id is required when owner_type='user' but was not provided"
                    )
                return developer_id
            raise ValueError(
                f"Unknown owner_type {owner_type!r}; expected 'user', 'team', or 'enterprise'"
            )

        def _fetch_one(
            owner_type: str, owner_id: uuid.UUID
        ) -> "EnterpriseArtifactVersionScope":
            """Execute a single-row query for one scope, raise on miss."""
            stmt = (
                self._apply_tenant_filter(select(EnterpriseArtifactVersionScope))
                .where(EnterpriseArtifactVersionScope.tenant_id == tenant_id)
                .where(EnterpriseArtifactVersionScope.artifact_id == artifact_id)
                .where(EnterpriseArtifactVersionScope.owner_type == owner_type)
                .where(EnterpriseArtifactVersionScope.owner_id == owner_id)
            )
            row = self.session.execute(stmt).scalar_one_or_none()
            if row is None:
                raise ValueError(
                    f"No scope row found for artifact_id={artifact_id!s}, "
                    f"owner_type={owner_type!r}, owner_id={owner_id!s}, "
                    f"tenant_id={tenant_id!s}"
                )
            return row

        left_owner_id = _resolve_owner_id(left_owner_type)
        right_owner_id = _resolve_owner_id(right_owner_type)

        left_row = _fetch_one(left_owner_type, left_owner_id)
        right_row = _fetch_one(right_owner_type, right_owner_id)

        logger.debug(
            "get_scope_pair: artifact=%s left=%s/%s right=%s/%s tenant=%s",
            artifact_id,
            left_owner_type,
            left_owner_id,
            right_owner_type,
            right_owner_id,
            tenant_id,
        )

        return self._to_dto(left_row), self._to_dto(right_row)


# =============================================================================
# EnterpriseGitRepoConnectionRepository
# =============================================================================


class EnterpriseGitRepoConnectionRepository(
    EnterpriseRepositoryBase["EnterpriseGitRepoConnection"],
    IGitRepoConnectionRepository,
):
    """Enterprise (PostgreSQL) repository for Git repository connection records (GRC).

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IGitRepoConnectionRepository`
    for the enterprise PostgreSQL backend using SQLAlchemy 2.x ``select()`` style
    with automatic tenant filtering via :meth:`_apply_tenant_filter`.

    Every query MUST go through ``_apply_tenant_filter`` or ``_tenant_select``
    to enforce the tenant isolation invariant.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.  Lifecycle (commit/rollback/close) is managed by the caller.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        super().__init__(session, EnterpriseGitRepoConnection)

    def create(
        self,
        project_id: Optional[uuid.UUID] = None,
        repo_url: str = "",
        branch: str = "main",
        developer_id: Optional[uuid.UUID] = None,
        scan_schedule: Optional[str] = None,
        webhook_secret: Optional[str] = None,
        ctx: Optional[Any] = None,
    ) -> "EnterpriseGitRepoConnection":
        """Register a new Git repository connection scoped to the current tenant.

        Args:
            project_id: Optional UUID of the owning enterprise project.
            repo_url: Full clone URL of the Git repository.
            branch: Branch to scan (default ``'main'``).
            developer_id: Optional UUID of the owning enterprise user.
            scan_schedule: Reserved cron expression.
            webhook_secret: HMAC secret for webhook validation.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            The newly created ``EnterpriseGitRepoConnection`` ORM instance
            (flushed, not committed — caller owns the transaction).
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        tenant_id = self._get_tenant_id()
        conn = EnterpriseGitRepoConnection(
            tenant_id=tenant_id,
            project_id=project_id,
            repo_url=repo_url,
            branch=branch,
            developer_id=developer_id,
            scan_schedule=scan_schedule,
            webhook_secret=webhook_secret,
            is_active=True,
        )
        self.session.add(conn)
        self.session.flush()
        self._log_operation("create", "EnterpriseGitRepoConnection", conn.id)
        return conn

    def get_by_id(
        self,
        id: uuid.UUID,
        ctx: Optional[Any] = None,
    ) -> Optional["EnterpriseGitRepoConnection"]:
        """Return the connection with the given UUID PK, or ``None``.

        Args:
            id: UUID primary key of the connection row.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            ``EnterpriseGitRepoConnection`` when found and owned by current
            tenant, ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitRepoConnection).where(
                EnterpriseGitRepoConnection.id == id
            )
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def list_by_project_id(
        self,
        project_id: uuid.UUID,
        limit: int = 50,
        offset: int = 0,
        ctx: Optional[Any] = None,
    ) -> List["EnterpriseGitRepoConnection"]:
        """Return a page of connections belonging to *project_id*.

        Args:
            project_id: UUID FK value to filter on.
            limit: Maximum records to return (default 50).
            offset: Records to skip for pagination (default 0).
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of ``EnterpriseGitRepoConnection`` instances ordered by
            ``created_at`` descending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        stmt = (
            self._apply_tenant_filter(
                select(EnterpriseGitRepoConnection).where(
                    EnterpriseGitRepoConnection.project_id == project_id
                )
            )
            .order_by(EnterpriseGitRepoConnection.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list(self.session.execute(stmt).scalars())

    def get_by_url(
        self,
        project_id: uuid.UUID,
        repo_url: str,
        branch: str,
        ctx: Optional[Any] = None,
    ) -> Optional["EnterpriseGitRepoConnection"]:
        """Return the connection matching the unique tenant/project/url/branch key.

        Args:
            project_id: UUID FK to the owning enterprise project.
            repo_url: Full clone URL.
            branch: Branch name.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            ``EnterpriseGitRepoConnection`` when found, ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitRepoConnection).where(
                EnterpriseGitRepoConnection.project_id == project_id,
                EnterpriseGitRepoConnection.repo_url == repo_url,
                EnterpriseGitRepoConnection.branch == branch,
            )
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def get_by_repo_url_branch(
        self,
        repo_url: str,
        branch: str,
        ctx: Optional[Any] = None,
    ) -> Optional["EnterpriseGitRepoConnection"]:
        """Return the connection matching the unique tenant/url/branch key.

        Used for M2M-decoupled uniqueness checks where connections are not
        tied to a single project.

        Args:
            repo_url: Full clone URL.
            branch: Branch name.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            ``EnterpriseGitRepoConnection`` when found, ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitRepoConnection).where(
                EnterpriseGitRepoConnection.repo_url == repo_url,
                EnterpriseGitRepoConnection.branch == branch,
            )
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def update(
        self,
        id: uuid.UUID,
        ctx: Optional[Any] = None,
        **kwargs: Any,
    ) -> Optional["EnterpriseGitRepoConnection"]:
        """Update fields on an existing connection and return the refreshed row.

        Args:
            id: UUID primary key of the connection to update.
            ctx: Unused; accepted for interface compatibility.
            **kwargs: Column names and their new values.

        Returns:
            Refreshed ``EnterpriseGitRepoConnection``, or ``None`` if not found.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        conn = self.get_by_id(id)
        if conn is None:
            return None
        for key, value in kwargs.items():
            if hasattr(conn, key):
                setattr(conn, key, value)
        self.session.flush()
        self._log_operation("update", "EnterpriseGitRepoConnection", id, kwargs)
        return conn

    def list_all(
        self,
        ctx: Optional[Any] = None,
    ) -> List["EnterpriseGitRepoConnection"]:
        """Return all git repo connections for the current tenant.

        Args:
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of all ``EnterpriseGitRepoConnection`` instances owned by the
            current tenant, ordered by ``created_at`` descending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        stmt = self._apply_tenant_filter(select(EnterpriseGitRepoConnection)).order_by(
            EnterpriseGitRepoConnection.created_at.desc()
        )
        return list(self.session.execute(stmt).scalars())

    def list_by_team_id(
        self,
        team_id: Any,
        ctx: Optional[Any] = None,
    ) -> List["EnterpriseGitRepoConnection"]:
        """Return connections filtered by team ID for the current tenant.

        Unlike the local edition (which always returns an empty list), the
        enterprise edition supports teams, so this filter is applied against
        the ``team_id`` column of ``enterprise_git_repo_connections``.

        Args:
            team_id: UUID primary key of the team to filter on.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of ``EnterpriseGitRepoConnection`` instances belonging to
            *team_id* within the current tenant, ordered by ``created_at``
            descending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitRepoConnection).where(
                EnterpriseGitRepoConnection.team_id == team_id
            )
        ).order_by(EnterpriseGitRepoConnection.created_at.desc())
        return list(self.session.execute(stmt).scalars())

    def list_unlinked(
        self,
        ctx: Optional[Any] = None,
    ) -> List["EnterpriseGitRepoConnection"]:
        """Return connections not linked to any project via the join table.

        A connection is considered *unlinked* when no row in
        ``enterprise_project_git_connections`` references its ``id``.  Both the
        main query and the correlated subquery are filtered by ``tenant_id`` to
        enforce tenant isolation.

        Args:
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of unlinked ``EnterpriseGitRepoConnection`` instances ordered
            by ``created_at`` descending.
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseGitRepoConnection,
            EnterpriseProjectGitConnection,
        )

        tenant_id = self._get_tenant_id()
        linked_subq = select(EnterpriseProjectGitConnection.connection_id).where(
            EnterpriseProjectGitConnection.tenant_id == tenant_id,
        )
        stmt = self._apply_tenant_filter(
            select(EnterpriseGitRepoConnection).where(
                ~EnterpriseGitRepoConnection.id.in_(linked_subq)
            )
        ).order_by(EnterpriseGitRepoConnection.created_at.desc())
        return list(self.session.execute(stmt).scalars())

    def delete(
        self,
        id: uuid.UUID,
        ctx: Optional[Any] = None,
    ) -> bool:
        """Delete the connection with the given UUID primary key.

        Args:
            id: UUID primary key of the connection to delete.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            ``True`` if a row was deleted, ``False`` if it was not found.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoConnection

        tenant_id = self._get_tenant_id()
        result = self.session.execute(
            delete(EnterpriseGitRepoConnection).where(
                EnterpriseGitRepoConnection.id == id,
                EnterpriseGitRepoConnection.tenant_id == tenant_id,
            )
        )
        self._log_operation("delete", "EnterpriseGitRepoConnection", id)
        return result.rowcount > 0


# =============================================================================
# EnterpriseGitRepoScanRepository
# =============================================================================


class EnterpriseGitRepoScanRepository(
    EnterpriseRepositoryBase["EnterpriseGitRepoScan"],
    IGitRepoScanRepository,
):
    """Enterprise (PostgreSQL) repository for Git repository scan records (GRC).

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IGitRepoScanRepository`
    for the enterprise PostgreSQL backend using SQLAlchemy 2.x ``select()`` style
    with automatic tenant filtering.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoScan

        super().__init__(session, EnterpriseGitRepoScan)

    def create(
        self,
        connection_id: uuid.UUID,
        triggered_by: str,
        trigger_sha: Optional[str] = None,
        ctx: Optional[Any] = None,
    ) -> "EnterpriseGitRepoScan":
        """Create a new scan record in ``'pending'`` status.

        Args:
            connection_id: UUID FK to the parent ``EnterpriseGitRepoConnection``.
            triggered_by: Initiation method (``'manual'``, ``'schedule'``,
                or ``'webhook'``).
            trigger_sha: 40-char git commit SHA; ``None`` for manual/schedule.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            The newly created ``EnterpriseGitRepoScan`` ORM instance (flushed).
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoScan

        tenant_id = self._get_tenant_id()
        scan = EnterpriseGitRepoScan(
            tenant_id=tenant_id,
            connection_id=connection_id,
            triggered_by=triggered_by,
            trigger_sha=trigger_sha,
            status="pending",
            artifacts_found=0,
            artifacts_new=0,
            artifacts_changed=0,
            artifacts_removed=0,
        )
        self.session.add(scan)
        self.session.flush()
        self._log_operation("create", "EnterpriseGitRepoScan", scan.id)
        return scan

    def get_by_id(
        self,
        id: uuid.UUID,
        ctx: Optional[Any] = None,
    ) -> Optional["EnterpriseGitRepoScan"]:
        """Return the scan with the given UUID PK, or ``None``.

        Args:
            id: UUID primary key of the scan row.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            ``EnterpriseGitRepoScan`` when found and owned by current tenant,
            ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoScan

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitRepoScan).where(EnterpriseGitRepoScan.id == id)
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def list_by_connection_id(
        self,
        connection_id: uuid.UUID,
        limit: int = 20,
        offset: int = 0,
        ctx: Optional[Any] = None,
    ) -> List["EnterpriseGitRepoScan"]:
        """Return a page of scans belonging to *connection_id*.

        Args:
            connection_id: UUID FK value to filter on.
            limit: Maximum records to return (default 20).
            offset: Records to skip for pagination (default 0).
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of ``EnterpriseGitRepoScan`` instances ordered by
            ``created_at`` descending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoScan

        stmt = (
            self._apply_tenant_filter(
                select(EnterpriseGitRepoScan).where(
                    EnterpriseGitRepoScan.connection_id == connection_id
                )
            )
            .order_by(EnterpriseGitRepoScan.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list(self.session.execute(stmt).scalars())

    def update_status(
        self,
        scan_id: uuid.UUID,
        status: str,
        error_message: Optional[str] = None,
        ctx: Optional[Any] = None,
    ) -> Optional["EnterpriseGitRepoScan"]:
        """Update the lifecycle status of a scan.

        Sets ``started_at`` when transitioning to ``'running'`` and
        ``completed_at`` when transitioning to ``'completed'`` or ``'failed'``.

        Args:
            scan_id: UUID primary key of the scan to update.
            status: New status value.
            error_message: Failure detail; only used when ``status == 'failed'``.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            Refreshed ``EnterpriseGitRepoScan``, or ``None`` if not found.
        """
        scan = self.get_by_id(scan_id)
        if scan is None:
            return None
        scan.status = status
        if status == "running" and scan.started_at is None:
            scan.started_at = datetime.utcnow()
        if status in ("completed", "failed"):
            scan.completed_at = datetime.utcnow()
        if error_message is not None:
            scan.error_message = error_message
        self.session.flush()
        return scan

    def update_counts(
        self,
        scan_id: uuid.UUID,
        found: int,
        new: int,
        changed: int,
        removed: int,
        ctx: Optional[Any] = None,
    ) -> Optional["EnterpriseGitRepoScan"]:
        """Update the artifact count fields after a scan run completes.

        Args:
            scan_id: UUID primary key of the scan to update.
            found: Total artifacts detected.
            new: Newly discovered artifacts.
            changed: Artifacts whose content changed.
            removed: Artifacts no longer present.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            Refreshed ``EnterpriseGitRepoScan``, or ``None`` if not found.
        """
        scan = self.get_by_id(scan_id)
        if scan is None:
            return None
        scan.artifacts_found = found
        scan.artifacts_new = new
        scan.artifacts_changed = changed
        scan.artifacts_removed = removed
        self.session.flush()
        return scan

    def get_by_connection_and_sha(
        self,
        connection_id: uuid.UUID,
        trigger_sha: str,
        ctx: Optional[Any] = None,
    ) -> Optional["EnterpriseGitRepoScan"]:
        """Return an existing scan for the given connection and commit SHA.

        Args:
            connection_id: UUID FK to the parent ``EnterpriseGitRepoConnection``.
            trigger_sha: 40-char git commit SHA to match.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            ``EnterpriseGitRepoScan`` when found, ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitRepoScan

        stmt = (
            self._apply_tenant_filter(
                select(EnterpriseGitRepoScan).where(
                    EnterpriseGitRepoScan.connection_id == connection_id,
                    EnterpriseGitRepoScan.trigger_sha == trigger_sha,
                )
            )
            .order_by(EnterpriseGitRepoScan.created_at.desc())
            .limit(1)
        )
        return self.session.execute(stmt).scalar_one_or_none()


# =============================================================================
# EnterpriseGitScanArtifactRepository
# =============================================================================


class EnterpriseGitScanArtifactRepository(
    EnterpriseRepositoryBase["EnterpriseGitScanArtifact"],
    IGitScanArtifactRepository,
):
    """Enterprise (PostgreSQL) repository for Git scan artifact observations (GRC).

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IGitScanArtifactRepository`
    for the enterprise PostgreSQL backend using SQLAlchemy 2.x ``select()`` style
    with automatic tenant filtering.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseGitScanArtifact

        super().__init__(session, EnterpriseGitScanArtifact)

    def create(
        self,
        scan_id: uuid.UUID,
        artifact_path: str,
        artifact_type: str,
        change_type: str,
        detected_name: Optional[str] = None,
        content_hash: Optional[str] = None,
        ctx: Optional[Any] = None,
    ) -> "EnterpriseGitScanArtifact":
        """Create a single artifact observation for a scan run.

        Args:
            scan_id: UUID FK to the parent ``EnterpriseGitRepoScan`` row.
            artifact_path: Repository-relative path.
            artifact_type: Detected artifact type label.
            change_type: Classification vs. previous scan.
            detected_name: Human-readable name from frontmatter; ``None`` if absent.
            content_hash: SHA-256 hex digest (64 chars); ``None`` if unavailable.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            The newly created ``EnterpriseGitScanArtifact`` ORM instance (flushed).
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitScanArtifact

        tenant_id = self._get_tenant_id()
        artifact = EnterpriseGitScanArtifact(
            tenant_id=tenant_id,
            scan_id=scan_id,
            artifact_path=artifact_path,
            artifact_type=artifact_type,
            change_type=change_type,
            detected_name=detected_name,
            content_hash=content_hash,
        )
        self.session.add(artifact)
        self.session.flush()
        return artifact

    def list_by_scan_id(
        self,
        scan_id: uuid.UUID,
        ctx: Optional[Any] = None,
    ) -> List["EnterpriseGitScanArtifact"]:
        """Return all artifact observations for a scan.

        Args:
            scan_id: UUID FK value to filter on.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of ``EnterpriseGitScanArtifact`` instances ordered by
            ``artifact_path`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitScanArtifact

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitScanArtifact).where(
                EnterpriseGitScanArtifact.scan_id == scan_id
            )
        ).order_by(EnterpriseGitScanArtifact.artifact_path.asc())
        return list(self.session.execute(stmt).scalars())

    def bulk_upsert(
        self,
        scan_id: uuid.UUID,
        artifacts: List[Dict[str, Any]],
        ctx: Optional[Any] = None,
    ) -> List["EnterpriseGitScanArtifact"]:
        """Efficiently insert or update a complete set of artifact observations.

        Existing rows for *scan_id* matching on ``artifact_path`` are updated
        in-place.  New paths are inserted.

        Args:
            scan_id: UUID FK to the parent ``EnterpriseGitRepoScan`` row.
            artifacts: List of dicts with required keys ``artifact_path``,
                ``artifact_type``, ``change_type``; optional keys
                ``detected_name``, ``content_hash``.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of created/updated ``EnterpriseGitScanArtifact`` instances.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitScanArtifact

        # Fetch existing rows for this scan scoped to current tenant.
        existing_stmt = self._apply_tenant_filter(
            select(EnterpriseGitScanArtifact).where(
                EnterpriseGitScanArtifact.scan_id == scan_id
            )
        )
        existing_rows: Dict[str, "EnterpriseGitScanArtifact"] = {
            row.artifact_path: row
            for row in self.session.execute(existing_stmt).scalars()
        }

        tenant_id = self._get_tenant_id()
        results: List["EnterpriseGitScanArtifact"] = []
        for data in artifacts:
            path = data["artifact_path"]
            if path in existing_rows:
                row = existing_rows[path]
                row.artifact_type = data["artifact_type"]
                row.change_type = data["change_type"]
                row.detected_name = data.get("detected_name")
                row.content_hash = data.get("content_hash")
                results.append(row)
            else:
                row = EnterpriseGitScanArtifact(
                    tenant_id=tenant_id,
                    scan_id=scan_id,
                    artifact_path=path,
                    artifact_type=data["artifact_type"],
                    change_type=data["change_type"],
                    detected_name=data.get("detected_name"),
                    content_hash=data.get("content_hash"),
                )
                self.session.add(row)
                results.append(row)

        self.session.flush()
        return results

    def update_indexed(
        self,
        artifact_id: uuid.UUID,
        indexed_at: datetime,
        artifact_id_ref: str,
        ctx: Optional[Any] = None,
    ) -> Optional["EnterpriseGitScanArtifact"]:
        """Mark an artifact observation as indexed into the main cache.

        The enterprise schema stores ``artifact_id`` as a UUID FK to
        ``enterprise_artifacts.id``.  *artifact_id_ref* is accepted as a string
        per the interface contract (local edition uses ``type:name`` strings);
        callers targeting the enterprise backend should pass a UUID hex string so
        that coercion here succeeds.  Passing a non-UUID string will raise
        ``ValueError`` at assignment time.

        Args:
            artifact_id: UUID primary key of the ``EnterpriseGitScanArtifact`` row.
            indexed_at: UTC timestamp when the artifact was imported.
            artifact_id_ref: Enterprise artifact UUID as a hex string.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            Refreshed ``EnterpriseGitScanArtifact``, or ``None`` if not found.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitScanArtifact

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitScanArtifact).where(
                EnterpriseGitScanArtifact.id == artifact_id
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return None
        row.indexed_at = indexed_at
        # Coerce hex string to UUID for the enterprise UUID FK column.
        row.artifact_id = (
            uuid.UUID(artifact_id_ref)
            if isinstance(artifact_id_ref, str)
            else artifact_id_ref
        )
        self.session.flush()
        return row


# =============================================================================
# EnterpriseProjectGitConnectionRepository
# =============================================================================


class EnterpriseProjectGitConnectionRepository(
    EnterpriseRepositoryBase["EnterpriseProjectGitConnection"],
    IProjectGitConnectionRepository,
):
    """Enterprise (PostgreSQL) repository for the project↔git-connection join table (GCD-1.8).

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IProjectGitConnectionRepository`
    for the enterprise PostgreSQL backend using SQLAlchemy 2.x ``select()`` style
    with automatic tenant filtering via :meth:`_apply_tenant_filter`.

    Every query MUST go through ``_apply_tenant_filter`` to enforce the
    tenant isolation invariant on all rows in ``enterprise_project_git_connections``.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.  Lifecycle (commit/rollback/close) is managed by the caller.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseProjectGitConnection

        super().__init__(session, EnterpriseProjectGitConnection)

    # ------------------------------------------------------------------
    # DTO converter
    # ------------------------------------------------------------------

    @staticmethod
    def _to_dto(row: "EnterpriseProjectGitConnection") -> "ProjectGitConnectionDTO":
        """Convert an ``EnterpriseProjectGitConnection`` ORM row to a DTO.

        Args:
            row: ORM instance to convert.

        Returns:
            Immutable :class:`~skillmeat.core.interfaces.dtos.ProjectGitConnectionDTO`.
        """
        from skillmeat.core.interfaces.dtos import ProjectGitConnectionDTO

        return ProjectGitConnectionDTO(
            project_id=str(row.project_id),
            connection_id=str(row.connection_id),
            tenant_id=str(row.tenant_id),
            linked_at=row.linked_at.isoformat() if row.linked_at is not None else None,
            linked_by=str(row.linked_by) if row.linked_by is not None else None,
        )

    def link(
        self,
        project_id: uuid.UUID,
        connection_id: uuid.UUID,
        linked_by: Optional[uuid.UUID] = None,
        ctx: Optional[Any] = None,
    ) -> "ProjectGitConnectionDTO":
        """Link a git connection to a project.

        Creates a row in ``enterprise_project_git_connections`` for the given
        ``(project_id, connection_id)`` composite primary key pair, scoped to
        the current tenant.

        Args:
            project_id: UUID FK to ``enterprise_projects.id``.
            connection_id: UUID FK to ``enterprise_git_repo_connections.id``.
            linked_by: Optional UUID of the enterprise user creating the link.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            The newly created ``EnterpriseProjectGitConnection`` ORM instance
            (flushed, not committed — caller owns the transaction).

        Raises:
            ValueError: If the ``(project_id, connection_id)`` pair already
                exists for this tenant (duplicate composite PK).
        """
        from skillmeat.cache.models_enterprise import EnterpriseProjectGitConnection
        from sqlalchemy.exc import IntegrityError

        tenant_id = self._get_tenant_id()
        link_row = EnterpriseProjectGitConnection(
            project_id=_ensure_uuid(project_id),
            connection_id=_ensure_uuid(connection_id),
            linked_by=_ensure_uuid(linked_by) if linked_by is not None else None,
            tenant_id=tenant_id,
        )
        self.session.add(link_row)
        try:
            self.session.flush()
        except IntegrityError as exc:
            self.session.rollback()
            raise ValueError(
                f"Connection {connection_id} is already linked to project {project_id}"
            ) from exc
        self._log_operation(
            "link",
            "EnterpriseProjectGitConnection",
            f"{project_id}:{connection_id}",
        )
        return self._to_dto(link_row)

    def unlink(
        self,
        project_id: uuid.UUID,
        connection_id: uuid.UUID,
        ctx: Optional[Any] = None,
    ) -> bool:
        """Unlink a git connection from a project.

        Deletes the join-table row matching ``(project_id, connection_id)`` for
        the current tenant.

        Args:
            project_id: UUID FK to ``enterprise_projects.id``.
            connection_id: UUID FK to ``enterprise_git_repo_connections.id``.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            ``True`` if the link existed and was deleted, ``False`` if the row
            was not found.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProjectGitConnection

        tenant_id = self._get_tenant_id()
        result = self.session.execute(
            delete(EnterpriseProjectGitConnection).where(
                EnterpriseProjectGitConnection.project_id == _ensure_uuid(project_id),
                EnterpriseProjectGitConnection.connection_id
                == _ensure_uuid(connection_id),
                EnterpriseProjectGitConnection.tenant_id == tenant_id,
            )
        )
        deleted = result.rowcount > 0
        self._log_operation(
            "unlink",
            "EnterpriseProjectGitConnection",
            f"{project_id}:{connection_id}",
        )
        return deleted

    def list_by_project(
        self,
        project_id: uuid.UUID,
        ctx: Optional[Any] = None,
    ) -> "List[ProjectGitConnectionDTO]":
        """List all git connections linked to a project.

        Args:
            project_id: UUID FK to ``enterprise_projects.id``; filters the
                join table on this column.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of DTOs ordered by ``linked_at`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProjectGitConnection

        stmt = self._apply_tenant_filter(
            select(EnterpriseProjectGitConnection).where(
                EnterpriseProjectGitConnection.project_id == _ensure_uuid(project_id)
            )
        ).order_by(EnterpriseProjectGitConnection.linked_at.asc())
        return [self._to_dto(row) for row in self.session.execute(stmt).scalars()]

    def list_by_connection(
        self,
        connection_id: uuid.UUID,
        ctx: Optional[Any] = None,
    ) -> "List[ProjectGitConnectionDTO]":
        """List all projects linked to a connection.

        Args:
            connection_id: UUID FK to ``enterprise_git_repo_connections.id``;
                filters the join table on this column.
            ctx: Unused; accepted for interface compatibility.

        Returns:
            List of DTOs ordered by ``linked_at`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseProjectGitConnection

        stmt = self._apply_tenant_filter(
            select(EnterpriseProjectGitConnection).where(
                EnterpriseProjectGitConnection.connection_id
                == _ensure_uuid(connection_id)
            )
        ).order_by(EnterpriseProjectGitConnection.linked_at.asc())
        return [self._to_dto(row) for row in self.session.execute(stmt).scalars()]


# =============================================================================
# ArtifactBlobsRepository
# =============================================================================


class ArtifactBlobsRepository:
    """Repository for Content-Addressed Storage (CAS) blob management.

    Manages ``EnterpriseArtifactBlob`` rows keyed by their SHA-256 hex digest.
    Blobs are tenant-agnostic — the same blob row may be referenced by artifact
    versions belonging to different tenants.  Tenant isolation is enforced at
    the version layer, not here.

    This repository does **not** subclass ``EnterpriseRepositoryBase`` because
    ``artifact_blobs`` has no ``tenant_id`` column.  Instead it holds a plain
    SQLAlchemy ``Session`` and uses SQLAlchemy 2.x ``select()`` style throughout.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise PostgreSQL
        database.  The caller (FastAPI DI) owns the session lifecycle.

    References
    ----------
    CAS-1.4 implementation task.
    """

    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def upsert_blob(
        self,
        sha256_hash: str,
        content: bytes,
        size_bytes: int,
        mime_type: Optional[str] = None,
    ) -> "EnterpriseArtifactBlob":
        """Insert a new blob or update the reference tracking of an existing one.

        When a blob with *sha256_hash* already exists the method increments
        ``ref_count`` and refreshes ``last_ref_at`` without touching the
        immutable content columns (``content``, ``storage_uri``).  When no
        matching row exists, a new row is created with ``ref_count=1``.

        Parameters
        ----------
        sha256_hash:
            SHA-256 hex digest of the blob content (exactly 64 hex chars).
        content:
            Raw binary payload to store inline.
        size_bytes:
            Byte length of the original content.
        mime_type:
            Optional IANA media type, e.g. ``'text/markdown'``.

        Returns
        -------
        EnterpriseArtifactBlob
            The created or updated ORM instance (flushed, not committed).
        """
        from datetime import timezone

        from skillmeat.cache.models_enterprise import EnterpriseArtifactBlob

        now = datetime.now(timezone.utc)

        stmt = select(EnterpriseArtifactBlob).where(
            EnterpriseArtifactBlob.sha256_hash == sha256_hash
        )
        existing = self.session.execute(stmt).scalar_one_or_none()

        if existing is not None:
            existing.ref_count = existing.ref_count + 1
            existing.last_ref_at = now
            self.session.flush()
            return existing

        blob = EnterpriseArtifactBlob(
            sha256_hash=sha256_hash,
            content=content,
            size_bytes=size_bytes,
            mime_type=mime_type,
            ref_count=1,
            last_ref_at=now,
        )
        self.session.add(blob)
        self.session.flush()
        return blob

    def get_blob_by_hash(
        self,
        sha256_hash: str,
    ) -> "Optional[EnterpriseArtifactBlob]":
        """Return the blob row for *sha256_hash*, or ``None`` if absent.

        Parameters
        ----------
        sha256_hash:
            SHA-256 hex digest (64 hex chars).

        Returns
        -------
        EnterpriseArtifactBlob | None
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactBlob

        stmt = select(EnterpriseArtifactBlob).where(
            EnterpriseArtifactBlob.sha256_hash == sha256_hash
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def increment_ref_count(self, sha256_hash: str) -> None:
        """Increment the reference count for the blob identified by *sha256_hash*.

        Also refreshes ``last_ref_at`` to the current UTC timestamp to record
        the most recent reference time.

        Parameters
        ----------
        sha256_hash:
            SHA-256 hex digest of the target blob (64 hex chars).

        Raises
        ------
        ValueError
            When no blob with *sha256_hash* exists in the database.
        """
        from datetime import timezone

        from skillmeat.cache.models_enterprise import EnterpriseArtifactBlob

        stmt = select(EnterpriseArtifactBlob).where(
            EnterpriseArtifactBlob.sha256_hash == sha256_hash
        )
        blob = self.session.execute(stmt).scalar_one_or_none()
        if blob is None:
            raise ValueError(
                f"No blob found with sha256_hash={sha256_hash!r}. "
                "Cannot increment ref_count for a non-existent blob."
            )
        blob.ref_count = blob.ref_count + 1
        blob.last_ref_at = datetime.now(timezone.utc)
        self.session.flush()

    def decrement_ref_count(self, sha256_hash: str) -> None:
        """Decrement the reference count for the blob identified by *sha256_hash*.

        The count is floored at 0.  When the count reaches 0 the blob is
        flagged as a GC candidate by setting ``last_ref_at`` to ``None``.

        Parameters
        ----------
        sha256_hash:
            SHA-256 hex digest of the target blob (64 hex chars).

        Raises
        ------
        ValueError
            When no blob with *sha256_hash* exists in the database.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactBlob

        stmt = select(EnterpriseArtifactBlob).where(
            EnterpriseArtifactBlob.sha256_hash == sha256_hash
        )
        blob = self.session.execute(stmt).scalar_one_or_none()
        if blob is None:
            raise ValueError(
                f"No blob found with sha256_hash={sha256_hash!r}. "
                "Cannot decrement ref_count for a non-existent blob."
            )
        new_count = max(0, blob.ref_count - 1)
        blob.ref_count = new_count
        if new_count == 0:
            blob.last_ref_at = None
        self.session.flush()


# =============================================================================
# EnterpriseWorkflowRepository  (EGCF-3.1)
# =============================================================================


class EnterpriseWorkflowRepository(
    IWorkflowRepository,
    EnterpriseRepositoryBase["EnterpriseWorkflow"],
):
    """Repository for tenant-scoped CRUD on EnterpriseWorkflow.

    Implements :class:`~skillmeat.core.interfaces.repositories.IWorkflowRepository`
    for the enterprise PostgreSQL backend.

    All queries are automatically scoped to the tenant stored in
    ``TenantContext`` via ``_apply_tenant_filter()``.  Every ``select()``
    statement in this class must go through that method — skipping it is a
    security defect.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Examples
    --------
    ::

        with tenant_scope(tenant_uuid):
            repo = EnterpriseWorkflowRepository(db_session)
            wf = repo.create("nightly-deploy", status="draft")
            exe = repo.create_execution(wf.id, context={"env": "prod"})
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseWorkflow as _EW

        super().__init__(session, _EW)

    # ------------------------------------------------------------------
    # DTO converters
    # ------------------------------------------------------------------

    def _to_dto(self, model: "EnterpriseWorkflow") -> "WorkflowDTO":
        """Map an ``EnterpriseWorkflow`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.WorkflowDTO`.

        Parameters
        ----------
        model:
            ORM instance to convert.

        Returns
        -------
        WorkflowDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import WorkflowDTO

        return WorkflowDTO(
            id=str(model.id),
            tenant_id=str(model.tenant_id),
            name=model.name,
            description=model.description,
            status=model.status,
            config=dict(model.config) if model.config else {},
            created_at=model.created_at.isoformat() if model.created_at else None,
            updated_at=model.updated_at.isoformat() if model.updated_at else None,
        )

    def _execution_to_dto(
        self, model: "EnterpriseWorkflowExecution"
    ) -> "WorkflowExecutionDTO":
        """Map an ``EnterpriseWorkflowExecution`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.WorkflowExecutionDTO`.

        Parameters
        ----------
        model:
            ORM instance to convert.

        Returns
        -------
        WorkflowExecutionDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import WorkflowExecutionDTO

        return WorkflowExecutionDTO(
            id=str(model.id),
            workflow_id=str(model.workflow_id),
            tenant_id=str(model.tenant_id),
            status=model.status,
            started_at=model.started_at.isoformat() if model.started_at else None,
            completed_at=model.completed_at.isoformat() if model.completed_at else None,
            context=dict(model.context) if model.context else {},
            result=dict(model.result) if model.result else {},
            created_at=model.created_at.isoformat() if model.created_at else None,
            updated_at=model.updated_at.isoformat() if model.updated_at else None,
        )

    def _get_orm(self, workflow_id: uuid.UUID) -> "Optional[EnterpriseWorkflow]":
        """Return the raw ORM instance for internal mutation methods.

        Unlike :meth:`get`, this method returns the ``EnterpriseWorkflow`` ORM
        object rather than a DTO, so that :meth:`update` and :meth:`delete` can
        mutate and flush it.  Tenant ownership is still asserted.

        Parameters
        ----------
        workflow_id:
            UUID primary key of the workflow.

        Returns
        -------
        EnterpriseWorkflow or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseWorkflow

        workflow = self.session.get(EnterpriseWorkflow, workflow_id)
        if workflow is None:
            return None
        self._assert_tenant_owns(workflow)
        return workflow

    # ------------------------------------------------------------------
    # Workflow CRUD
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        description: Optional[str] = None,
        status: str = "draft",
        config: Optional[Dict[str, Any]] = None,
    ) -> "WorkflowDTO":
        """Create a new workflow definition scoped to the current tenant.

        Parameters
        ----------
        name:
            Human-readable workflow name; must be unique per tenant.
        description:
            Optional free-text description.
        status:
            Initial lifecycle status.  Defaults to ``"draft"``.
        config:
            Arbitrary JSONB configuration blob.  Defaults to an empty dict.

        Returns
        -------
        WorkflowDTO
            The newly persisted workflow as a DTO (added and flushed).
        """
        from skillmeat.cache.models_enterprise import EnterpriseWorkflow

        tenant_id = self._get_tenant_id()
        workflow = EnterpriseWorkflow(
            tenant_id=tenant_id,
            name=name,
            description=description,
            status=status,
            config=config or {},
        )
        self.session.add(workflow)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseWorkflow",
            entity_id=workflow.id,
            metadata={"name": name, "status": status},
        )
        return self._to_dto(workflow)

    def get(
        self,
        workflow_id: uuid.UUID,
    ) -> "Optional[WorkflowDTO]":
        """Retrieve a workflow by primary key, asserting tenant ownership.

        Parameters
        ----------
        workflow_id:
            UUID primary key of the workflow to fetch.

        Returns
        -------
        WorkflowDTO or None
            The workflow DTO, or ``None`` if it does not exist.

        Raises
        ------
        TenantIsolationError
            If the retrieved workflow belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseWorkflow

        workflow = self.session.get(EnterpriseWorkflow, workflow_id)
        if workflow is None:
            return None
        self._assert_tenant_owns(workflow)
        return self._to_dto(workflow)

    def list(
        self,
        offset: int = 0,
        limit: int = 50,
        status: Optional[str] = None,
        after: Optional[str] = None,
    ) -> "List[WorkflowDTO]":
        """Return a paginated list of workflow definitions for the current tenant.

        Supports both offset-based and cursor-based (keyset) pagination.
        When *after* is provided it takes precedence over *offset*.

        Parameters
        ----------
        offset:
            Number of rows to skip (0-based).  Ignored when *after* is given.
        limit:
            Maximum number of rows to return (capped at 100).
        status:
            Optional lifecycle-status filter (e.g. ``"active"``).
        after:
            Opaque cursor string (base64-encoded UUID) from a previous call;
            when supplied, rows with ``created_at`` older than or equal to the
            cursor row are excluded.

        Returns
        -------
        List[WorkflowDTO]
            Workflow DTOs ordered by ``created_at`` ascending.
        """
        import base64

        from skillmeat.cache.models_enterprise import EnterpriseWorkflow

        stmt = self._tenant_select().order_by(EnterpriseWorkflow.created_at)

        if status is not None:
            stmt = stmt.where(EnterpriseWorkflow.status == status)

        # Keyset pagination: skip rows whose id <= cursor.
        if after:
            try:
                cursor_id = _ensure_uuid(base64.b64decode(after.encode()).decode())
                stmt = stmt.where(EnterpriseWorkflow.id > cursor_id)
            except Exception:
                pass  # Ignore invalid cursor; return from beginning.
        else:
            stmt = stmt.offset(offset)

        limit = max(1, min(limit, 100))
        stmt = stmt.limit(limit)
        rows = list(self.session.execute(stmt).scalars())
        return [self._to_dto(row) for row in rows]

    def update(
        self,
        workflow_id: uuid.UUID,
        name: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> "WorkflowDTO":
        """Update mutable fields on an existing workflow.

        Only non-``None`` arguments are applied; passing ``None`` leaves the
        field unchanged.

        Parameters
        ----------
        workflow_id:
            UUID of the workflow to update.
        name:
            New human-readable name (must remain unique per tenant).
        description:
            New free-text description.
        status:
            New lifecycle status.
        config:
            Replacement JSONB configuration blob.

        Returns
        -------
        WorkflowDTO
            The updated workflow as a DTO (already flushed).

        Raises
        ------
        ValueError
            If the workflow does not exist.
        TenantIsolationError
            If the workflow belongs to a different tenant.
        """
        workflow = self._get_orm(workflow_id)
        if workflow is None:
            raise ValueError(f"EnterpriseWorkflow {workflow_id!r} not found.")

        changed: Dict[str, object] = {}
        if name is not None:
            changed["name"] = name
            workflow.name = name
        if description is not None:
            changed["description"] = description
            workflow.description = description
        if status is not None:
            changed["status"] = status
            workflow.status = status
        if config is not None:
            changed["config"] = config
            workflow.config = config

        workflow.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseWorkflow",
            entity_id=workflow_id,
            metadata=changed or None,
        )
        return self._to_dto(workflow)

    def delete(
        self,
        workflow_id: uuid.UUID,
    ) -> bool:
        """Delete a workflow and its cascade-deleted executions and stages.

        Parameters
        ----------
        workflow_id:
            UUID of the workflow to delete.

        Returns
        -------
        bool
            ``True`` if the workflow existed and was deleted; ``False`` if it
            was not found.

        Raises
        ------
        TenantIsolationError
            If the workflow belongs to a different tenant.
        """
        workflow = self._get_orm(workflow_id)
        if workflow is None:
            return False

        self.session.delete(workflow)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseWorkflow",
            entity_id=workflow_id,
        )
        return True

    # ------------------------------------------------------------------
    # Workflow execution helpers
    # ------------------------------------------------------------------

    def list_executions(
        self,
        workflow_id: uuid.UUID,
        offset: int = 0,
        limit: int = 50,
        status: Optional[str] = None,
    ) -> "List[WorkflowExecutionDTO]":
        """Return executions for *workflow_id* ordered by ``started_at`` descending.

        Parameters
        ----------
        workflow_id:
            UUID of the parent workflow.  The parent must belong to the active
            tenant (validated via :meth:`_get_orm`).
        offset:
            Number of rows to skip.
        limit:
            Maximum number of rows to return (capped at 100).
        status:
            Optional status filter (e.g. ``"failed"``).

        Returns
        -------
        List[WorkflowExecutionDTO]
            Execution DTOs ordered by ``started_at`` descending.

        Raises
        ------
        TenantIsolationError
            If the parent workflow belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseWorkflowExecution

        # Validate parent ownership before fetching children.
        parent = self._get_orm(workflow_id)
        if parent is None:
            return []

        tenant_id = self._get_tenant_id()
        stmt = (
            self._apply_tenant_filter(select(EnterpriseWorkflowExecution))
            .where(EnterpriseWorkflowExecution.workflow_id == workflow_id)
            .order_by(EnterpriseWorkflowExecution.started_at.desc())
        )

        if status is not None:
            stmt = stmt.where(EnterpriseWorkflowExecution.status == status)

        limit = max(1, min(limit, 100))
        stmt = stmt.offset(offset).limit(limit)
        rows = list(self.session.execute(stmt).scalars())
        return [self._execution_to_dto(row) for row in rows]

    def get_execution(
        self,
        execution_id: uuid.UUID,
    ) -> "Optional[WorkflowExecutionDTO]":
        """Return the execution with *execution_id*, or ``None`` if absent.

        Parameters
        ----------
        execution_id:
            UUID primary key of the execution.

        Returns
        -------
        WorkflowExecutionDTO or None
            The execution DTO, or ``None`` if not found.

        Raises
        ------
        TenantIsolationError
            If the record belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseWorkflowExecution

        stmt = self._apply_tenant_filter(
            select(EnterpriseWorkflowExecution).where(
                EnterpriseWorkflowExecution.id == execution_id
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is None:
            return None
        return self._execution_to_dto(row)

    def create_execution(
        self,
        workflow_id: uuid.UUID,
        context: Optional[Dict[str, Any]] = None,
    ) -> "WorkflowExecutionDTO":
        """Create a new execution record for *workflow_id*.

        Parameters
        ----------
        workflow_id:
            UUID of the parent workflow.  The parent must belong to the active
            tenant.
        context:
            Arbitrary JSONB input context supplied at launch time.  Defaults
            to an empty dict.

        Returns
        -------
        WorkflowExecutionDTO
            The newly persisted execution as a DTO (added and flushed).

        Raises
        ------
        ValueError
            If the parent workflow does not exist.
        TenantIsolationError
            If the parent workflow belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseWorkflowExecution

        parent = self._get_orm(workflow_id)
        if parent is None:
            raise ValueError(
                f"EnterpriseWorkflow {workflow_id!r} not found; "
                "cannot create execution for non-existent workflow."
            )

        tenant_id = self._get_tenant_id()
        execution = EnterpriseWorkflowExecution(
            workflow_id=workflow_id,
            tenant_id=tenant_id,
            status="pending",
            context=context or {},
            result={},
        )
        self.session.add(execution)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseWorkflowExecution",
            entity_id=execution.id,
            metadata={"workflow_id": str(workflow_id)},
        )
        return self._execution_to_dto(execution)


# =============================================================================
# EnterpriseMemoryItemRepository
# =============================================================================


class EnterpriseMemoryItemRepository(
    IMemoryItemRepository,
    EnterpriseRepositoryBase["EnterpriseMemoryItem"],
):
    """Repository for tenant-scoped CRUD on EnterpriseMemoryItem.

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IMemoryItemRepository`
    for the enterprise PostgreSQL backend.

    All queries are automatically scoped to the tenant stored in
    ``TenantContext`` via ``_apply_tenant_filter()``.  Every ``select()``
    statement in this class must go through that method — skipping it is a
    security defect.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Examples
    --------
    ::

        with tenant_scope(tenant_uuid):
            repo = EnterpriseMemoryItemRepository(db_session)
            item = repo.create(
                content="Use select() not session.query()",
                type="gotcha",
                status="candidate",
            )
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseMemoryItem as _EMI

        super().__init__(session, _EMI)

    # ------------------------------------------------------------------
    # Converter
    # ------------------------------------------------------------------

    def _to_dto(self, model: "EnterpriseMemoryItem") -> "MemoryItemDTO":
        """Map an ``EnterpriseMemoryItem`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.MemoryItemDTO`.

        Parameters
        ----------
        model:
            ORM instance to convert.

        Returns
        -------
        MemoryItemDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import MemoryItemDTO

        return MemoryItemDTO(
            id=str(model.id),
            tenant_id=str(model.tenant_id),
            project_id=str(model.project_id) if model.project_id is not None else None,
            type=model.type,
            status=model.status,
            content=model.content,
            confidence=model.confidence,
            anchor=model.anchor,
            provenance=dict(model.provenance) if model.provenance else {},
            created_at=model.created_at.isoformat() if model.created_at else None,
            updated_at=model.updated_at.isoformat() if model.updated_at else None,
        )

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def create(
        self,
        content: str,
        type: str,
        status: str = "candidate",
        confidence: Optional[float] = None,
        anchor: Optional[str] = None,
        provenance: Optional[Dict[str, Any]] = None,
        project_id: Optional[uuid.UUID] = None,
    ) -> "MemoryItemDTO":
        """Create a new memory item scoped to the current tenant.

        Parameters
        ----------
        content:
            Full-text content of the memory item (required).
        type:
            Memory type — one of ``'decision'``, ``'constraint'``,
            ``'gotcha'``, ``'style_rule'``, or ``'learning'``.
        status:
            Initial lifecycle status.  Defaults to ``"candidate"``.
        confidence:
            Confidence score in ``[0.0, 1.0]``; ``None`` when not assessed.
        anchor:
            Optional source-location anchor string.
        provenance:
            Arbitrary JSONB provenance metadata.  Defaults to an empty dict.
        project_id:
            Optional FK to the owning enterprise project.

        Returns
        -------
        EnterpriseMemoryItem
            The newly persisted ORM instance (added and flushed).
        """
        from skillmeat.cache.models_enterprise import EnterpriseMemoryItem

        tenant_id = self._get_tenant_id()
        item = EnterpriseMemoryItem(
            tenant_id=tenant_id,
            content=content,
            type=type,
            status=status,
            confidence=confidence,
            anchor=anchor,
            provenance=provenance or {},
            project_id=project_id,
        )
        self.session.add(item)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseMemoryItem",
            entity_id=item.id,
            metadata={"type": type, "status": status},
        )
        return self._to_dto(item)

    def _get_orm_item(self, item_id: uuid.UUID) -> "Optional[EnterpriseMemoryItem]":
        """Return the raw ORM instance for internal mutation methods.

        Unlike :meth:`get`, this method returns the ``EnterpriseMemoryItem`` ORM
        object rather than a DTO, so that :meth:`update` and :meth:`delete` can
        mutate and flush it.  Tenant ownership is still asserted.

        Parameters
        ----------
        item_id:
            UUID primary key of the memory item.

        Returns
        -------
        EnterpriseMemoryItem or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseMemoryItem

        item = self.session.get(EnterpriseMemoryItem, item_id)
        if item is None:
            return None
        self._assert_tenant_owns(item)
        return item

    def get(
        self,
        item_id: uuid.UUID,
    ) -> "Optional[MemoryItemDTO]":
        """Retrieve a memory item by primary key, asserting tenant ownership.

        Parameters
        ----------
        item_id:
            UUID primary key of the memory item to fetch.

        Returns
        -------
        MemoryItemDTO or None
            The memory item DTO, or ``None`` if it does not exist.

        Raises
        ------
        TenantIsolationError
            If the retrieved record belongs to a different tenant.
        """
        item = self._get_orm_item(item_id)
        if item is None:
            return None
        return self._to_dto(item)

    def list(
        self,
        offset: int = 0,
        limit: int = 50,
        status: Optional[str] = None,
        after: Optional[str] = None,
    ) -> "List[MemoryItemDTO]":
        """Return a paginated list of memory items for the current tenant.

        Supports both offset-based and cursor-based (keyset) pagination.
        When *after* is provided it takes precedence over *offset*.

        Parameters
        ----------
        offset:
            Number of rows to skip (0-based).  Ignored when *after* is given.
        limit:
            Maximum number of rows to return (capped at 100).
        status:
            Optional lifecycle-status filter (e.g. ``"candidate"``).
        after:
            Opaque cursor string (base64-encoded UUID) from a previous call;
            when supplied, rows with ``created_at`` older than or equal to the
            cursor row are excluded.

        Returns
        -------
        List[EnterpriseMemoryItem]
            Memory items ordered by ``created_at`` ascending.
        """
        import base64

        from skillmeat.cache.models_enterprise import EnterpriseMemoryItem

        stmt = self._tenant_select().order_by(EnterpriseMemoryItem.created_at)

        if status is not None:
            stmt = stmt.where(EnterpriseMemoryItem.status == status)

        # Keyset pagination: skip rows whose id <= cursor.
        if after:
            try:
                cursor_id = _ensure_uuid(base64.b64decode(after.encode()).decode())
                stmt = stmt.where(EnterpriseMemoryItem.id > cursor_id)
            except Exception:
                pass  # Ignore invalid cursor; return from beginning.
        else:
            stmt = stmt.offset(offset)

        limit = max(1, min(limit, 100))
        stmt = stmt.limit(limit)
        rows = list(self.session.execute(stmt).scalars())
        return [self._to_dto(row) for row in rows]

    def update(
        self,
        item_id: uuid.UUID,
        content: Optional[str] = None,
        type: Optional[str] = None,
        status: Optional[str] = None,
        confidence: Optional[float] = None,
        anchor: Optional[str] = None,
        provenance: Optional[Dict[str, Any]] = None,
    ) -> "MemoryItemDTO":
        """Update mutable fields on an existing memory item.

        Only non-``None`` arguments are applied; passing ``None`` leaves the
        field unchanged.

        Parameters
        ----------
        item_id:
            UUID of the memory item to update.
        content:
            Replacement full-text content.
        type:
            New memory type.
        status:
            New lifecycle status.
        confidence:
            New confidence score.
        anchor:
            New source-location anchor.
        provenance:
            Replacement provenance blob.

        Returns
        -------
        MemoryItemDTO
            The updated memory item as a DTO (already flushed).

        Raises
        ------
        ValueError
            If the memory item does not exist.
        TenantIsolationError
            If the record belongs to a different tenant.
        """
        item = self._get_orm_item(item_id)
        if item is None:
            raise ValueError(f"EnterpriseMemoryItem {item_id!r} not found.")

        changed: Dict[str, object] = {}
        if content is not None:
            changed["content"] = content
            item.content = content
        if type is not None:
            changed["type"] = type
            item.type = type
        if status is not None:
            changed["status"] = status
            item.status = status
        if confidence is not None:
            changed["confidence"] = confidence
            item.confidence = confidence
        if anchor is not None:
            changed["anchor"] = anchor
            item.anchor = anchor
        if provenance is not None:
            changed["provenance"] = provenance
            item.provenance = provenance

        item.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseMemoryItem",
            entity_id=item_id,
            metadata=changed or None,
        )
        return self._to_dto(item)

    def delete(
        self,
        item_id: uuid.UUID,
    ) -> bool:
        """Delete a memory item.

        Parameters
        ----------
        item_id:
            UUID of the memory item to delete.

        Returns
        -------
        bool
            ``True`` if the item existed and was deleted; ``False`` if it was
            not found.

        Raises
        ------
        TenantIsolationError
            If the record belongs to a different tenant.
        """
        item = self._get_orm_item(item_id)
        if item is None:
            return False

        self.session.delete(item)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseMemoryItem",
            entity_id=item_id,
        )
        return True

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        offset: int = 0,
        limit: int = 50,
    ) -> "List[MemoryItemDTO]":
        """Search memory items by content using case-insensitive matching.

        Filters rows where ``content ILIKE '%query%'``.  An empty *query*
        string returns all items for the current tenant (up to *limit*).

        Parameters
        ----------
        query:
            Free-form search string; wrapped in ``%…%`` wildcards automatically.
        offset:
            Number of rows to skip.
        limit:
            Maximum number of rows to return (capped at 100).

        Returns
        -------
        List[EnterpriseMemoryItem]
            Matching memory items ordered by ``created_at`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseMemoryItem

        pattern = f"%{query}%"
        stmt = (
            self._tenant_select()
            .where(EnterpriseMemoryItem.content.ilike(pattern))
            .order_by(EnterpriseMemoryItem.created_at)
        )

        limit = max(1, min(limit, 100))
        stmt = stmt.offset(offset).limit(limit)
        rows = list(self.session.execute(stmt).scalars())
        return [self._to_dto(row) for row in rows]


# =============================================================================
# EnterpriseBundleRepository
# =============================================================================


class EnterpriseBundleRepository(
    IBundleRepository,
    EnterpriseRepositoryBase["EnterpriseBundleEntity"],
):
    """Repository for tenant-scoped CRUD on EnterpriseBundleEntity.

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IBundleRepository`
    for the enterprise PostgreSQL backend.

    All queries are automatically scoped to the tenant stored in
    ``TenantContext`` via ``_apply_tenant_filter()``.  Every ``select()``
    statement in this class must go through that method — skipping it is a
    security defect.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Examples
    --------
    ::

        with tenant_scope(tenant_uuid):
            repo = EnterpriseBundleRepository(db_session)
            bundle = repo.create_bundle("my-bundle", collection_id="col-1")
            members = repo.list_members(str(bundle["id"]))
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import (
            EnterpriseBundleEntity as _EBE,
        )

        super().__init__(session, _EBE)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_bundle_or_raise(self, bundle_id: str) -> "EnterpriseBundleEntity":
        """Fetch a bundle by UUID string, asserting tenant ownership.

        Parameters
        ----------
        bundle_id:
            UUID hex string of the bundle.

        Returns
        -------
        EnterpriseBundleEntity
            The ORM instance.

        Raises
        ------
        ValueError
            If no bundle with *bundle_id* exists.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseBundleEntity

        bid = _ensure_uuid(bundle_id)
        bundle = self.session.get(EnterpriseBundleEntity, bid)
        if bundle is None:
            raise ValueError(f"EnterpriseBundleEntity {bundle_id!r} not found.")
        self._assert_tenant_owns(bundle)
        return bundle

    # ------------------------------------------------------------------
    # Bundle CRUD
    # ------------------------------------------------------------------

    def create_bundle(
        self,
        name: str,
        collection_id: str,
        description: Optional[str] = None,
        version: Optional[str] = None,
        tags: Optional[List[str]] = None,
        license: Optional[str] = None,
        homepage: Optional[str] = None,
        repository: Optional[str] = None,
        ctx=None,
    ) -> "BundleDTO":
        """Create a new bundle in draft status.

        Parameters
        ----------
        name:
            Human-readable bundle name (unique within the collection).
        collection_id:
            Owning collection identifier stored in ``config``.
        description:
            Optional free-text description.
        version:
            Optional initial semver string; stored in ``config``.
        tags:
            Optional list of tag strings; stored in ``config``.
        license:
            Optional SPDX license identifier; stored in ``config``.
        homepage:
            Optional homepage URL; stored in ``config``.
        repository:
            Optional source repository URL; stored in ``config``.
        ctx:
            Optional per-request metadata (unused by this implementation).

        Returns
        -------
        BundleDTO
            DTO representation of the newly created bundle (status ``"draft"``).

        Raises
        ------
        ValueError
            If a bundle with *name* already exists in *collection_id*.
        """
        from skillmeat.cache.models_enterprise import EnterpriseBundleEntity

        tenant_id = self._get_tenant_id()

        # Check for name uniqueness within the collection.
        existing = self.get_bundle_by_name(name, collection_id, ctx=ctx)
        if existing is not None:
            raise ValueError(
                f"Bundle {name!r} already exists in collection {collection_id!r}."
            )

        config: Dict[str, Any] = {"collection_id": collection_id}
        if version is not None:
            config["version"] = version
        if tags is not None:
            config["tags"] = tags
        if license is not None:
            config["license"] = license
        if homepage is not None:
            config["homepage"] = homepage
        if repository is not None:
            config["repository"] = repository

        bundle = EnterpriseBundleEntity(
            tenant_id=tenant_id,
            name=name,
            description=description,
            status="draft",
            config=config,
        )
        self.session.add(bundle)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseBundleEntity",
            entity_id=bundle.id,
            metadata={"name": name, "collection_id": collection_id},
        )
        return self._to_dto(bundle)

    def get_bundle(
        self,
        bundle_id: str,
        ctx=None,
    ) -> "BundleDTO":
        """Return the bundle with the given identifier.

        Parameters
        ----------
        bundle_id:
            UUID hex primary key.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        BundleDTO
            DTO representation of the bundle including its membership list.

        Raises
        ------
        ValueError
            If no bundle with *bundle_id* exists.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        bundle = self._get_bundle_or_raise(bundle_id)
        return self._to_dto(bundle)

    def get_bundle_by_name(
        self,
        name: str,
        collection_id: str,
        ctx=None,
    ) -> "Optional[BundleDTO]":
        """Return the bundle matching *name* within *collection_id*, or ``None``.

        Parameters
        ----------
        name:
            Bundle name to look up.
        collection_id:
            Owning collection identifier.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        BundleDTO or None
            DTO representation of the bundle when found, ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseBundleEntity

        stmt = (
            self._apply_tenant_filter(select(EnterpriseBundleEntity))
            .where(EnterpriseBundleEntity.name == name)
            .where(
                EnterpriseBundleEntity.config["collection_id"].astext == collection_id
            )
        )
        bundle = self.session.execute(stmt).scalar_one_or_none()
        if bundle is None:
            return None
        return self._to_dto(bundle)

    def list_bundles(
        self,
        collection_id: Optional[str] = None,
        status: Optional[str] = None,
        tags: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 50,
        ctx=None,
    ) -> "BundleListDTO":
        """Return a paginated list of bundles matching the given filters.

        Parameters
        ----------
        collection_id:
            Restrict results to a specific collection.
        status:
            Restrict results to a specific lifecycle status.
        tags:
            Restrict results to bundles containing all listed tags (AND logic).
        page:
            1-based page number.
        page_size:
            Maximum items per page (capped at 100).
        ctx:
            Optional per-request metadata.

        Returns
        -------
        BundleListDTO
            Paginated result with ``items`` (list of :class:`BundleDTO`),
            ``total``, ``page``, and ``page_size`` fields.
        """
        from skillmeat.cache.models_enterprise import EnterpriseBundleEntity

        page = max(1, page)
        page_size = max(1, min(page_size, 100))

        stmt = self._apply_tenant_filter(select(EnterpriseBundleEntity)).order_by(
            EnterpriseBundleEntity.created_at
        )

        if collection_id is not None:
            stmt = stmt.where(
                EnterpriseBundleEntity.config["collection_id"].astext == collection_id
            )
        if status is not None:
            stmt = stmt.where(EnterpriseBundleEntity.status == status)
        if tags:
            for tag in tags:
                stmt = stmt.where(
                    EnterpriseBundleEntity.config["tags"].contains(f'"{tag}"')
                )

        # Count total matching rows (re-apply same filters, no pagination).
        count_stmt = self._apply_tenant_filter(select(EnterpriseBundleEntity))
        if collection_id is not None:
            count_stmt = count_stmt.where(
                EnterpriseBundleEntity.config["collection_id"].astext == collection_id
            )
        if status is not None:
            count_stmt = count_stmt.where(EnterpriseBundleEntity.status == status)
        total = len(list(self.session.execute(count_stmt).scalars()))

        offset = (page - 1) * page_size
        stmt = stmt.offset(offset).limit(page_size)
        items = list(self.session.execute(stmt).scalars())

        from skillmeat.core.interfaces.dtos import BundleListDTO

        return BundleListDTO(
            items=[self._to_dto(b) for b in items],
            total=total,
            page=page,
            page_size=page_size,
        )

    def update_bundle(
        self,
        bundle_id: str,
        ctx=None,
        **kwargs: Any,
    ) -> "BundleDTO":
        """Apply a partial update to an existing draft bundle.

        Only bundles in ``"draft"`` status may be updated.

        Parameters
        ----------
        bundle_id:
            UUID hex primary key of the bundle to update.
        ctx:
            Optional per-request metadata.
        **kwargs:
            Field names and new values to apply.

        Returns
        -------
        BundleDTO
            DTO representation of the updated bundle.

        Raises
        ------
        ValueError
            If no bundle with *bundle_id* exists, or if the bundle is not in
            ``"draft"`` status.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        bundle = self._get_bundle_or_raise(bundle_id)

        if bundle.status != "draft":
            raise ValueError(
                f"Bundle {bundle_id!r} is in {bundle.status!r} status; "
                "only draft bundles may be updated."
            )

        changed: Dict[str, Any] = {}
        config_updates: Dict[str, Any] = {}

        # Simple scalar fields.
        for field in ("name", "description", "bundle_type", "status"):
            if field in kwargs and kwargs[field] is not None:
                setattr(bundle, field, kwargs[field])
                changed[field] = kwargs[field]

        # Config-backed fields.
        for field in ("version", "tags", "license", "homepage", "repository"):
            if field in kwargs and kwargs[field] is not None:
                config_updates[field] = kwargs[field]
                changed[field] = kwargs[field]

        if config_updates:
            current_config = dict(bundle.config or {})
            current_config.update(config_updates)
            bundle.config = current_config

        bundle.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseBundleEntity",
            entity_id=_ensure_uuid(bundle_id),
            metadata=changed or None,
        )
        return self._to_dto(bundle)

    def delete_bundle(
        self,
        bundle_id: str,
        ctx=None,
    ) -> None:
        """Delete or archive a bundle depending on its current status.

        * ``"draft"`` -> hard delete (cascade removes memberships).
        * ``"published"`` -> set status to ``"archived"`` (soft delete).
        * ``"archived"`` -> no-op (already archived).

        Parameters
        ----------
        bundle_id:
            UUID hex primary key of the bundle.
        ctx:
            Optional per-request metadata.

        Raises
        ------
        ValueError
            If no bundle with *bundle_id* exists.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        bundle = self._get_bundle_or_raise(bundle_id)

        if bundle.status == "draft":
            self.session.delete(bundle)
            self.session.flush()
            self._log_operation(
                operation="delete",
                entity_type="EnterpriseBundleEntity",
                entity_id=_ensure_uuid(bundle_id),
                metadata={"status_at_delete": "draft"},
            )
        elif bundle.status == "published":
            bundle.status = "archived"
            bundle.updated_at = datetime.utcnow()
            self.session.flush()
            self._log_operation(
                operation="archive",
                entity_type="EnterpriseBundleEntity",
                entity_id=_ensure_uuid(bundle_id),
                metadata={"previous_status": "published"},
            )
        # "archived" is a no-op.

    # ------------------------------------------------------------------
    # Membership management
    # ------------------------------------------------------------------

    def add_member(
        self,
        bundle_id: str,
        artifact_uuid: Optional[str] = None,
        artifact_tier: int = 0,
        relationship_type: str = "contains",
        pinned_version_hash: Optional[str] = None,
        member_type: str = "artifact",
        context_entity_id: Optional[str] = None,
        ctx=None,
    ) -> "BundleMembershipDTO":
        """Add an artifact or context entity to a bundle.

        Parameters
        ----------
        bundle_id:
            UUID hex primary key of the bundle.
        artifact_uuid:
            Stable ``enterprise_artifacts.id`` of the artifact to add.
            Required when ``member_type="artifact"``.
        artifact_tier:
            Tier classification (0=standalone, 1=composable, 2=orchestrator).
        relationship_type:
            Semantic edge label (default ``"contains"``).
        pinned_version_hash:
            Optional content hash pinning the artifact to a specific snapshot.
        member_type:
            Discriminator — ``"artifact"`` (default) or ``"context_entity"``.
        context_entity_id:
            Context entity identifier. Required when
            ``member_type="context_entity"``.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        BundleMembershipDTO
            DTO representation of the created BundleMembership row.

        Raises
        ------
        ValueError
            If the artifact is already a member, or if the bundle does not
            exist.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseBundleMembership

        bundle = self._get_bundle_or_raise(bundle_id)
        tenant_id = self._get_tenant_id()
        bid = _ensure_uuid(bundle_id)

        # Resolve the artifact UUID.
        if member_type == "artifact":
            if artifact_uuid is None:
                raise ValueError(
                    "artifact_uuid is required when member_type='artifact'."
                )
            aid = _ensure_uuid(artifact_uuid)
        elif member_type == "context_entity":
            if context_entity_id is None:
                raise ValueError(
                    "context_entity_id is required when member_type='context_entity'."
                )
            aid = _ensure_uuid(context_entity_id)
        else:
            raise ValueError(f"Unknown member_type {member_type!r}.")

        # Check for duplicate membership.
        existing_stmt = (
            self._apply_tenant_filter(select(EnterpriseBundleMembership))
            .where(EnterpriseBundleMembership.bundle_id == bid)
            .where(EnterpriseBundleMembership.artifact_id == aid)
        )
        existing = self.session.execute(existing_stmt).scalar_one_or_none()
        if existing is not None:
            raise ValueError(
                f"Artifact {artifact_uuid!r} is already a member of bundle "
                f"{bundle_id!r}."
            )

        config: Dict[str, Any] = {
            "artifact_tier": artifact_tier,
            "relationship_type": relationship_type,
            "member_type": member_type,
        }
        if pinned_version_hash is not None:
            config["pinned_version_hash"] = pinned_version_hash
        if context_entity_id is not None:
            config["context_entity_id"] = context_entity_id

        membership = EnterpriseBundleMembership(
            tenant_id=tenant_id,
            bundle_id=bid,
            artifact_id=aid,
            config=config,
        )
        self.session.add(membership)
        self.session.flush()
        self._log_operation(
            operation="add_member",
            entity_type="EnterpriseBundleMembership",
            entity_id=membership.id,
            metadata={"bundle_id": bundle_id, "artifact_uuid": str(aid)},
        )
        return self._membership_to_dto(membership)

    def remove_member(
        self,
        bundle_id: str,
        artifact_uuid: str,
        ctx=None,
    ) -> None:
        """Remove an artifact from a bundle.

        Only bundles in ``"draft"`` status permit member removal.

        Parameters
        ----------
        bundle_id:
            UUID hex primary key of the bundle.
        artifact_uuid:
            Stable ``enterprise_artifacts.id`` of the artifact to remove.
        ctx:
            Optional per-request metadata.

        Raises
        ------
        ValueError
            If the bundle is not in ``"draft"`` status, or if the membership
            record does not exist.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseBundleMembership

        bundle = self._get_bundle_or_raise(bundle_id)

        if bundle.status != "draft":
            raise ValueError(
                f"Bundle {bundle_id!r} is in {bundle.status!r} status; "
                "member removal is only permitted on draft bundles."
            )

        bid = _ensure_uuid(bundle_id)
        aid = _ensure_uuid(artifact_uuid)

        stmt = (
            self._apply_tenant_filter(select(EnterpriseBundleMembership))
            .where(EnterpriseBundleMembership.bundle_id == bid)
            .where(EnterpriseBundleMembership.artifact_id == aid)
        )
        membership = self.session.execute(stmt).scalar_one_or_none()
        if membership is None:
            raise ValueError(
                f"Artifact {artifact_uuid!r} is not a member of bundle "
                f"{bundle_id!r}."
            )

        self.session.delete(membership)
        self.session.flush()
        self._log_operation(
            operation="remove_member",
            entity_type="EnterpriseBundleMembership",
            entity_id=membership.id,
            metadata={"bundle_id": bundle_id, "artifact_uuid": artifact_uuid},
        )

    def list_members(
        self,
        bundle_id: str,
        ctx=None,
    ) -> "List[BundleMembershipDTO]":
        """Return all membership records for a bundle.

        Parameters
        ----------
        bundle_id:
            UUID hex primary key of the bundle.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        list[BundleMembershipDTO]
            List of membership DTOs ordered by ``id`` ascending.

        Raises
        ------
        ValueError
            If no bundle with *bundle_id* exists.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseBundleMembership

        # Validate bundle ownership.
        self._get_bundle_or_raise(bundle_id)

        bid = _ensure_uuid(bundle_id)
        stmt = (
            self._apply_tenant_filter(select(EnterpriseBundleMembership))
            .where(EnterpriseBundleMembership.bundle_id == bid)
            .order_by(EnterpriseBundleMembership.id)
        )
        memberships = list(self.session.execute(stmt).scalars())
        return [self._membership_to_dto(m) for m in memberships]

    # ------------------------------------------------------------------
    # Lifecycle transitions
    # ------------------------------------------------------------------

    def publish_bundle(
        self,
        bundle_id: str,
        ctx=None,
    ) -> "BundleDTO":
        """Transition a bundle from ``"draft"`` to ``"published"``.

        Parameters
        ----------
        bundle_id:
            UUID hex primary key of the bundle.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        BundleDTO
            DTO representation of the newly published bundle.

        Raises
        ------
        ValueError
            If the bundle is not in ``"draft"`` status, or if no bundle with
            *bundle_id* exists.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        bundle = self._get_bundle_or_raise(bundle_id)

        if bundle.status != "draft":
            raise ValueError(
                f"Bundle {bundle_id!r} is in {bundle.status!r} status; "
                "only draft bundles may be published."
            )

        bundle.status = "published"
        bundle.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="publish",
            entity_type="EnterpriseBundleEntity",
            entity_id=_ensure_uuid(bundle_id),
        )
        return self._to_dto(bundle)

    def deprecate_bundle(
        self,
        bundle_id: str,
        ctx=None,
    ) -> "BundleDTO":
        """Transition a bundle from ``"published"`` to ``"archived"``.

        Parameters
        ----------
        bundle_id:
            UUID hex primary key of the bundle.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        BundleDTO
            DTO representation of the archived bundle.

        Raises
        ------
        ValueError
            If the bundle is not in ``"published"`` status, or if no bundle
            with *bundle_id* exists.
        TenantIsolationError
            If the bundle belongs to a different tenant.
        """
        bundle = self._get_bundle_or_raise(bundle_id)

        if bundle.status != "published":
            raise ValueError(
                f"Bundle {bundle_id!r} is in {bundle.status!r} status; "
                "only published bundles may be deprecated/archived."
            )

        bundle.status = "archived"
        bundle.updated_at = datetime.utcnow()
        self.session.flush()
        self._log_operation(
            operation="deprecate",
            entity_type="EnterpriseBundleEntity",
            entity_id=_ensure_uuid(bundle_id),
        )
        return self._to_dto(bundle)

    # ------------------------------------------------------------------
    # Serialisation helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _bundle_to_dict(bundle: "EnterpriseBundleEntity") -> Dict[str, Any]:
        """Convert an ``EnterpriseBundleEntity`` ORM instance to a plain dict.

        Parameters
        ----------
        bundle:
            ORM instance to serialise.

        Returns
        -------
        dict
            Plain dict with all scalar fields.
        """
        return {
            "id": str(bundle.id),
            "tenant_id": str(bundle.tenant_id),
            "name": bundle.name,
            "description": bundle.description,
            "bundle_type": bundle.bundle_type,
            "status": bundle.status,
            "config": bundle.config or {},
            "created_at": bundle.created_at.isoformat() if bundle.created_at else None,
            "updated_at": bundle.updated_at.isoformat() if bundle.updated_at else None,
        }

    @staticmethod
    def _membership_to_dict(
        membership: "EnterpriseBundleMembership",
    ) -> Dict[str, Any]:
        """Convert an ``EnterpriseBundleMembership`` ORM instance to a plain dict.

        Parameters
        ----------
        membership:
            ORM instance to serialise.

        Returns
        -------
        dict
            Plain dict with all scalar fields.
        """
        return {
            "id": str(membership.id),
            "tenant_id": str(membership.tenant_id),
            "bundle_id": str(membership.bundle_id),
            "artifact_id": str(membership.artifact_id),
            "position": membership.position,
            "config": membership.config or {},
        }

    @staticmethod
    def _membership_to_dto(
        membership: "EnterpriseBundleMembership",
    ) -> "BundleMembershipDTO":
        """Convert an ``EnterpriseBundleMembership`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.BundleMembershipDTO`.

        Parameters
        ----------
        membership:
            ORM instance to convert.

        Returns
        -------
        BundleMembershipDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import BundleMembershipDTO

        cfg = membership.config or {}
        return BundleMembershipDTO(
            bundle_id=str(membership.bundle_id),
            member_type=cfg.get("member_type", "artifact"),
            artifact_uuid=str(membership.artifact_id),
            context_entity_id=cfg.get("context_entity_id"),
            artifact_tier=int(cfg.get("artifact_tier") or 0),
            relationship_type=cfg.get("relationship_type", "contains"),
            pinned_version_hash=cfg.get("pinned_version_hash"),
            added_at=None,
        )

    @staticmethod
    def _to_dto(bundle: "EnterpriseBundleEntity") -> "BundleDTO":
        """Convert an ``EnterpriseBundleEntity`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.BundleDTO`.

        Embeds all loaded membership rows as :class:`~skillmeat.core.interfaces.dtos.BundleMembershipDTO`
        instances.  If the ORM relationship is unloaded (lazy load boundary),
        ``memberships`` will be an empty list — callers that need memberships
        should use :meth:`get_bundle` which triggers the relationship load.

        Parameters
        ----------
        bundle:
            ORM instance to convert.

        Returns
        -------
        BundleDTO
            Immutable DTO with embedded membership list.
        """
        from skillmeat.core.interfaces.dtos import BundleDTO, BundleMembershipDTO

        cfg = bundle.config or {}

        # Load memberships if the relationship attribute is accessible without
        # triggering an implicit lazy load in a closed-session context.
        try:
            raw_memberships = list(bundle.memberships)
        except Exception:
            raw_memberships = []

        membership_dtos: List[BundleMembershipDTO] = []
        for m in raw_memberships:
            m_cfg = m.config or {}
            membership_dtos.append(
                BundleMembershipDTO(
                    bundle_id=str(m.bundle_id),
                    member_type=m_cfg.get("member_type", "artifact"),
                    artifact_uuid=str(m.artifact_id),
                    context_entity_id=m_cfg.get("context_entity_id"),
                    artifact_tier=int(m_cfg.get("artifact_tier") or 0),
                    relationship_type=m_cfg.get("relationship_type", "contains"),
                    pinned_version_hash=m_cfg.get("pinned_version_hash"),
                    added_at=None,
                )
            )

        return BundleDTO(
            id=str(bundle.id),
            name=bundle.name,
            collection_id=cfg.get("collection_id", ""),
            description=bundle.description,
            version=cfg.get("version"),
            status=bundle.status or "draft",
            tags=list(cfg.get("tags") or []),
            license=cfg.get("license"),
            homepage=cfg.get("homepage"),
            repository=cfg.get("repository"),
            created_at=bundle.created_at.isoformat() if bundle.created_at else None,
            updated_at=bundle.updated_at.isoformat() if bundle.updated_at else None,
            published_at=None,
            memberships=membership_dtos,
        )


# =============================================================================
# EnterpriseBomRepository
# =============================================================================


class EnterpriseBomRepository(
    IBomRepository,
    EnterpriseRepositoryBase["EnterpriseBomSnapshot"],
):
    """Repository for tenant-scoped CRUD on EnterpriseBomSnapshot and
    read/create on EnterpriseAttestationRecord.

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IBomRepository`
    for the enterprise PostgreSQL backend.

    All queries are automatically scoped to the tenant stored in
    ``TenantContext`` via ``_apply_tenant_filter()``.  Every ``select()``
    statement in this class must go through that method — skipping it is a
    security defect.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise database.
        Lifecycle (commit/rollback/close) is managed by the caller.

    Examples
    --------
    ::

        with tenant_scope(tenant_uuid):
            repo = EnterpriseBomRepository(db_session)
            snap = repo.create_snapshot(artifact_id, {"components": []})
            att = repo.create_attestation(snap.id, result="pass")
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import (
            EnterpriseBomSnapshot as _EBS,
        )

        super().__init__(session, _EBS)

    # ------------------------------------------------------------------
    # DTO converters
    # ------------------------------------------------------------------

    def _snapshot_to_dto(self, model: "EnterpriseBomSnapshot") -> "BomSnapshotDTO":
        """Map an ``EnterpriseBomSnapshot`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.BomSnapshotDTO`.

        Parameters
        ----------
        model:
            ORM instance to convert.

        Returns
        -------
        BomSnapshotDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import BomSnapshotDTO

        return BomSnapshotDTO(
            id=str(model.id),
            tenant_id=str(model.tenant_id),
            artifact_id=str(model.artifact_id),
            snapshot_data=dict(model.snapshot_data) if model.snapshot_data else {},
            generated_at=model.generated_at.isoformat() if model.generated_at else None,
            format_version=model.format_version,
            created_at=model.created_at.isoformat() if model.created_at else None,
        )

    def _attestation_to_dto(
        self, model: "EnterpriseAttestationRecord"
    ) -> "AttestationRecordDTO":
        """Map an ``EnterpriseAttestationRecord`` ORM instance to a :class:`~skillmeat.core.interfaces.dtos.AttestationRecordDTO`.

        Parameters
        ----------
        model:
            ORM instance to convert.

        Returns
        -------
        AttestationRecordDTO
            Immutable DTO ready for serialisation.
        """
        from skillmeat.core.interfaces.dtos import AttestationRecordDTO

        return AttestationRecordDTO(
            id=str(model.id),
            tenant_id=str(model.tenant_id),
            snapshot_id=str(model.snapshot_id),
            policy_id=str(model.policy_id) if model.policy_id is not None else None,
            result=model.result,
            attested_at=model.attested_at.isoformat() if model.attested_at else None,
            evidence=dict(model.evidence) if model.evidence else {},
            created_at=model.created_at.isoformat() if model.created_at else None,
        )

    # ------------------------------------------------------------------
    # Snapshot CRUD
    # ------------------------------------------------------------------

    def list_snapshots(
        self,
        artifact_id: Optional[uuid.UUID] = None,
        offset: int = 0,
        limit: int = 50,
        after: Optional[str] = None,
        ctx=None,
    ) -> "List[BomSnapshotDTO]":
        """Return a paginated list of BOM snapshots for the current tenant.

        Supports both offset-based and cursor-based (keyset) pagination.
        When *after* is provided it takes precedence over *offset*.

        Parameters
        ----------
        artifact_id:
            Optional filter to restrict results to a specific artifact UUID.
        offset:
            Number of rows to skip (0-based).  Ignored when *after* is given.
        limit:
            Maximum number of rows to return (capped at 100).
        after:
            Opaque cursor string (base64-encoded UUID) from a previous call.
        ctx:
            Optional per-request metadata (unused by this implementation).

        Returns
        -------
        List[BomSnapshotDTO]
            Snapshots ordered by ``created_at`` ascending.
        """
        import base64

        from skillmeat.cache.models_enterprise import EnterpriseBomSnapshot

        stmt = self._tenant_select().order_by(EnterpriseBomSnapshot.created_at)

        if artifact_id is not None:
            stmt = stmt.where(EnterpriseBomSnapshot.artifact_id == artifact_id)

        if after:
            try:
                cursor_id = _ensure_uuid(base64.b64decode(after.encode()).decode())
                stmt = stmt.where(EnterpriseBomSnapshot.id > cursor_id)
            except Exception:
                pass  # Ignore invalid cursor; return from beginning.
        else:
            stmt = stmt.offset(offset)

        limit = max(1, min(limit, 100))
        stmt = stmt.limit(limit)
        return [
            self._snapshot_to_dto(row) for row in self.session.execute(stmt).scalars()
        ]

    def _get_snapshot_orm(
        self,
        snapshot_id: uuid.UUID,
    ) -> "Optional[EnterpriseBomSnapshot]":
        """Fetch a BOM snapshot ORM instance for internal use (e.g. delete).

        Applies tenant isolation check before returning.
        """
        from skillmeat.cache.models_enterprise import EnterpriseBomSnapshot

        snapshot = self.session.get(EnterpriseBomSnapshot, snapshot_id)
        if snapshot is None:
            return None
        self._assert_tenant_owns(snapshot)
        return snapshot

    def get_snapshot(
        self,
        snapshot_id: uuid.UUID,
        ctx=None,
    ) -> "Optional[BomSnapshotDTO]":
        """Retrieve a BOM snapshot by primary key, asserting tenant ownership.

        Parameters
        ----------
        snapshot_id:
            UUID primary key of the snapshot to fetch.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        BomSnapshotDTO or None
            The snapshot DTO, or ``None`` if it does not exist.

        Raises
        ------
        TenantIsolationError
            If the retrieved snapshot belongs to a different tenant.
        """
        snapshot = self._get_snapshot_orm(snapshot_id)
        if snapshot is None:
            return None
        return self._snapshot_to_dto(snapshot)

    def create_snapshot(
        self,
        artifact_id: uuid.UUID,
        snapshot_data: Dict[str, Any],
        format_version: Optional[str] = None,
        generated_at: Optional[datetime] = None,
        ctx=None,
    ) -> "BomSnapshotDTO":
        """Create a new BOM snapshot scoped to the current tenant.

        Parameters
        ----------
        artifact_id:
            FK to the enterprise artifact this snapshot describes.
        snapshot_data:
            JSONB BOM payload (components, dependencies, etc.).
        format_version:
            Optional format discriminator (e.g. ``'spdx-2.3'``,
            ``'cyclonedx-1.5'``); ``None`` means unspecified/custom.
        generated_at:
            Optional timezone-aware datetime when the BOM was generated.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        BomSnapshotDTO
            The newly persisted snapshot as a DTO (added and flushed).
        """
        from skillmeat.cache.models_enterprise import EnterpriseBomSnapshot

        tenant_id = self._get_tenant_id()
        snapshot = EnterpriseBomSnapshot(
            tenant_id=tenant_id,
            artifact_id=artifact_id,
            snapshot_data=snapshot_data,
            format_version=format_version,
            generated_at=generated_at,
        )
        self.session.add(snapshot)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseBomSnapshot",
            entity_id=snapshot.id,
            metadata={
                "artifact_id": str(artifact_id),
                "format_version": format_version,
            },
        )
        return self._snapshot_to_dto(snapshot)

    def delete_snapshot(
        self,
        snapshot_id: uuid.UUID,
        ctx=None,
    ) -> bool:
        """Delete a BOM snapshot, cascade-deleting its attestation records.

        Parameters
        ----------
        snapshot_id:
            UUID of the snapshot to delete.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        bool
            ``True`` if the snapshot existed and was deleted; ``False`` if it
            was not found.

        Raises
        ------
        TenantIsolationError
            If the snapshot belongs to a different tenant.
        """
        snapshot = self._get_snapshot_orm(snapshot_id)
        if snapshot is None:
            return False
        self.session.delete(snapshot)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseBomSnapshot",
            entity_id=snapshot_id,
        )
        return True

    # ------------------------------------------------------------------
    # Attestation operations
    # ------------------------------------------------------------------

    def list_attestations(
        self,
        snapshot_id: Optional[uuid.UUID] = None,
        offset: int = 0,
        limit: int = 50,
        after: Optional[str] = None,
        ctx=None,
    ) -> "List[AttestationRecordDTO]":
        """Return a paginated list of attestation records for the current tenant.

        Parameters
        ----------
        snapshot_id:
            Optional filter to restrict results to a specific snapshot UUID.
        offset:
            Number of rows to skip (0-based).  Ignored when *after* is given.
        limit:
            Maximum number of rows to return (capped at 100).
        after:
            Opaque cursor string (base64-encoded UUID) from a previous call.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        List[AttestationRecordDTO]
            Attestation records ordered by ``created_at`` ascending.
        """
        import base64

        from sqlalchemy import select as sa_select

        from skillmeat.cache.models_enterprise import EnterpriseAttestationRecord

        stmt = self._apply_tenant_filter(
            sa_select(EnterpriseAttestationRecord)
        ).order_by(EnterpriseAttestationRecord.created_at)

        if snapshot_id is not None:
            stmt = stmt.where(EnterpriseAttestationRecord.snapshot_id == snapshot_id)

        if after:
            try:
                cursor_id = _ensure_uuid(base64.b64decode(after.encode()).decode())
                stmt = stmt.where(EnterpriseAttestationRecord.id > cursor_id)
            except Exception:
                pass

        else:
            stmt = stmt.offset(offset)

        limit = max(1, min(limit, 100))
        stmt = stmt.limit(limit)
        return [
            self._attestation_to_dto(row)
            for row in self.session.execute(stmt).scalars()
        ]

    def get_attestation(
        self,
        attestation_id: uuid.UUID,
        ctx=None,
    ) -> "Optional[AttestationRecordDTO]":
        """Retrieve an attestation record by primary key.

        Parameters
        ----------
        attestation_id:
            UUID primary key of the attestation record.
        ctx:
            Optional per-request metadata.

        Returns
        -------
        AttestationRecordDTO or None
            The record DTO, or ``None`` if it does not exist.

        Raises
        ------
        TenantIsolationError
            If the record belongs to a different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseAttestationRecord

        record = self.session.get(EnterpriseAttestationRecord, attestation_id)
        if record is None:
            return None
        self._assert_tenant_owns(record)
        return self._attestation_to_dto(record)

    def create_attestation(
        self,
        snapshot_id: uuid.UUID,
        result: str,
        policy_id: Optional[uuid.UUID] = None,
        attested_at: Optional[datetime] = None,
        evidence: Optional[Dict[str, Any]] = None,
        ctx=None,
    ) -> "AttestationRecordDTO":
        """Create a new attestation record for a BOM snapshot.

        Parameters
        ----------
        snapshot_id:
            FK to the ``EnterpriseBomSnapshot`` being attested.
        result:
            Attestation outcome — one of ``'pass'``, ``'fail'``,
            ``'warning'``, or ``'error'``.
        policy_id:
            Optional FK to ``EnterpriseAttestationPolicy``.
        attested_at:
            Optional timezone-aware datetime when the attestation was run.
        evidence:
            Optional JSONB supporting data (rule failures, scores, tool
            output).
        ctx:
            Optional per-request metadata.

        Returns
        -------
        AttestationRecordDTO
            The newly persisted attestation record as a DTO (added and flushed).

        Raises
        ------
        ValueError
            If the referenced snapshot does not exist or belongs to a
            different tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseAttestationRecord

        # Validate the parent snapshot exists and is owned by this tenant.
        snapshot_dto = self.get_snapshot(snapshot_id, ctx=ctx)
        if snapshot_dto is None:
            raise ValueError(f"EnterpriseBomSnapshot {snapshot_id!r} not found.")

        tenant_id = self._get_tenant_id()
        record = EnterpriseAttestationRecord(
            tenant_id=tenant_id,
            snapshot_id=snapshot_id,
            policy_id=policy_id,
            result=result,
            attested_at=attested_at,
            evidence=evidence or {},
        )
        self.session.add(record)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseAttestationRecord",
            entity_id=record.id,
            metadata={
                "snapshot_id": str(snapshot_id),
                "result": result,
            },
        )
        return self._attestation_to_dto(record)


class EnterpriseContextEntityCategoryStub:
    """Enterprise stub for context entity categories.

    Returns empty results in enterprise mode. Promoted to full implementation
    when EnterpriseContextEntity write path is enterprise-enabled and category
    management is prioritized.

    Deferral decision: docs/dev/architecture/enterprise-intentional-stubs.md
    """

    def list(self, *args, **kwargs):
        """Return empty list — stub implementation."""
        return []

    def get(self, *args, **kwargs):
        """Return None — stub implementation."""
        return None

    def create(self, *args, **kwargs):
        """No-op — stub implementation."""
        return None

    def delete(self, *args, **kwargs):
        """No-op — stub implementation."""
        return None


class EnterpriseContextEntityCategoryRepository(
    EnterpriseRepositoryBase["EnterpriseContextEntityCategory"],
):
    """Enterprise (PostgreSQL) repository for context entity categories (EGCF-5.1).

    Implements CRUD operations over ``enterprise_context_entity_categories``
    using SQLAlchemy 2.x ``select()`` style with automatic tenant filtering
    via ``_apply_tenant_filter``.

    Every query MUST go through ``_apply_tenant_filter`` to enforce the tenant
    isolation invariant.

    DTO synthesis notes (Phase 0 guidance)
    ---------------------------------------
    The ``EnterpriseContextEntityCategory`` ORM model stores ``name``,
    ``slug``, ``description``, ``sort_order``, ``created_at``, and
    ``updated_at`` columns only.  The ``CategoryDTO`` additionally requires
    ``color``, ``entity_type``, ``platform``, ``is_builtin``, and
    ``artifact_count`` -- none of which are schema columns:

    - ``color``          -> synthesized as ``None``
    - ``entity_type``    -> synthesized as ``None``
    - ``platform``       -> synthesized as ``None``
    - ``is_builtin``     -> synthesized as ``False``
    - ``artifact_count`` -> COUNT subquery against
                           ``enterprise_artifact_category_associations``
                           filtered by the same ``tenant_id``.

    Forward-compat risk: if callers need to filter by ``entity_type`` or
    ``platform``, a schema migration will be required.  Track in tech-debt log.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.  Lifecycle is managed by the caller.
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseContextEntityCategory

        super().__init__(session, EnterpriseContextEntityCategory)

    # ------------------------------------------------------------------
    # DTO converter
    # ------------------------------------------------------------------

    def _to_dto(
        self,
        row: "EnterpriseContextEntityCategory",
        artifact_count: int = 0,
    ) -> "CategoryDTO":
        """Convert an ORM row to a ``CategoryDTO``.

        ``color``, ``entity_type``, ``platform``, and ``is_builtin`` are not
        schema columns and are synthesized with safe defaults.  ``artifact_count``
        is supplied by the caller (pre-computed via COUNT subquery).

        Args:
            row: ORM instance to convert.
            artifact_count: Pre-computed association count for this category.

        Returns:
            Immutable :class:`~skillmeat.core.interfaces.dtos.CategoryDTO`.
        """
        from skillmeat.core.interfaces.dtos import CategoryDTO

        return CategoryDTO(
            id=str(row.id),
            name=row.name,
            slug=row.slug or "",
            entity_type=None,  # not a schema column -- synthesized default
            description=row.description,
            color=None,  # not a schema column -- synthesized default
            platform=None,  # not a schema column -- synthesized default
            sort_order=int(row.sort_order or 0),
            is_builtin=False,  # not a schema column -- synthesized default
            artifact_count=artifact_count,
            created_at=(
                row.created_at.isoformat() if row.created_at is not None else None
            ),
            updated_at=(
                row.updated_at.isoformat() if row.updated_at is not None else None
            ),
        )

    # ------------------------------------------------------------------
    # Artifact count helpers
    # ------------------------------------------------------------------

    def _fetch_artifact_counts(
        self, category_ids: List[uuid.UUID]
    ) -> Dict[uuid.UUID, int]:
        """Return a mapping of category_id -> artifact count for given IDs.

        The count query is tenant-scoped via the ``tenant_id`` column on
        ``enterprise_artifact_category_associations``.

        Args:
            category_ids: List of category UUIDs to count for.

        Returns:
            Dict mapping each category UUID to its association count.
            Categories with zero associations are absent (use ``.get(cid, 0)``).
        """
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifactCategoryAssociation,
        )
        from sqlalchemy import func

        if not category_ids:
            return {}

        tenant_id = self._get_tenant_id()
        stmt = (
            select(
                EnterpriseArtifactCategoryAssociation.category_id,
                func.count(EnterpriseArtifactCategoryAssociation.id).label("cnt"),
            )
            .where(
                EnterpriseArtifactCategoryAssociation.tenant_id == tenant_id,
                EnterpriseArtifactCategoryAssociation.category_id.in_(category_ids),
            )
            .group_by(EnterpriseArtifactCategoryAssociation.category_id)
        )
        rows = self.session.execute(stmt).all()
        return {row.category_id: row.cnt for row in rows}

    def _fetch_artifact_count(self, category_id: uuid.UUID) -> int:
        """Return the artifact association count for a single category.

        Args:
            category_id: UUID of the category to count associations for.

        Returns:
            Integer count of artifact associations (0 when none exist).
        """
        counts = self._fetch_artifact_counts([category_id])
        return counts.get(category_id, 0)

    # ------------------------------------------------------------------
    # list()
    # ------------------------------------------------------------------

    def list(
        self,
        entity_type: Optional[str] = None,
        platform: Optional[str] = None,
        ctx: Any = None,
    ) -> "List[CategoryDTO]":
        """Return all tenant-scoped categories ordered by sort_order.

        ``entity_type`` and ``platform`` filters are accepted for interface
        parity with ``IContextEntityRepository.list_categories`` but are
        no-ops because neither is a schema column.  A follow-up migration is
        required to support filter-by-entity_type or filter-by-platform.

        Args:
            entity_type: Ignored (not a schema column; accepted for parity).
            platform: Ignored (not a schema column; accepted for parity).
            ctx: Optional per-request metadata (unused).

        Returns:
            List of :class:`~skillmeat.core.interfaces.dtos.CategoryDTO` objects
            ordered by ``sort_order`` ascending, ``name`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseContextEntityCategory

        stmt = self._apply_tenant_filter(
            select(EnterpriseContextEntityCategory).order_by(
                EnterpriseContextEntityCategory.sort_order.asc(),
                EnterpriseContextEntityCategory.name.asc(),
            )
        )
        rows = list(self.session.execute(stmt).scalars())
        if not rows:
            return []

        category_ids = [row.id for row in rows]
        counts = self._fetch_artifact_counts(category_ids)

        return [self._to_dto(row, artifact_count=counts.get(row.id, 0)) for row in rows]

    # ------------------------------------------------------------------
    # get()
    # ------------------------------------------------------------------

    def get(
        self,
        category_id: str,
        ctx: Any = None,
    ) -> "Optional[CategoryDTO]":
        """Return a single category by UUID primary key.

        Args:
            category_id: UUID string of the category to retrieve.
            ctx: Optional per-request metadata (unused).

        Returns:
            :class:`~skillmeat.core.interfaces.dtos.CategoryDTO` if found,
            ``None`` if no matching row exists for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseContextEntityCategory

        uid = _ensure_uuid(category_id)
        stmt = self._apply_tenant_filter(
            select(EnterpriseContextEntityCategory).where(
                EnterpriseContextEntityCategory.id == uid
            )
        )
        row = self.session.execute(stmt).scalars().first()
        if row is None:
            return None
        artifact_count = self._fetch_artifact_count(row.id)
        return self._to_dto(row, artifact_count=artifact_count)

    # ------------------------------------------------------------------
    # create()
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        slug: Optional[str] = None,
        entity_type: Optional[str] = None,
        description: Optional[str] = None,
        color: Optional[str] = None,
        platform: Optional[str] = None,
        sort_order: Optional[int] = None,
        ctx: Any = None,
    ) -> "CategoryDTO":
        """Create a new tenant-scoped context entity category.

        The ``entity_type``, ``color``, and ``platform`` parameters are accepted
        for interface parity but are silently dropped (not schema columns).

        Args:
            name: Human-readable category label.
            slug: URL-safe identifier.  Auto-generated from ``name`` when omitted.
            entity_type: Ignored (not a schema column).
            description: Optional free-text description.
            color: Ignored (not a schema column).
            platform: Ignored (not a schema column).
            sort_order: Display order; defaults to 0 when omitted.
            ctx: Optional per-request metadata (unused).

        Returns:
            The created :class:`~skillmeat.core.interfaces.dtos.CategoryDTO`.

        Raises:
            ValueError: If a category with the same slug already exists for
                this tenant (unique constraint violation).
        """
        from skillmeat.cache.models_enterprise import EnterpriseContextEntityCategory

        tenant_id = self._get_tenant_id()
        resolved_slug = slug or name.lower().replace(" ", "-")

        record = EnterpriseContextEntityCategory(
            tenant_id=tenant_id,
            name=name,
            slug=resolved_slug,
            description=description,
            sort_order=sort_order if sort_order is not None else 0,
        )
        self.session.add(record)
        try:
            self.session.flush()
        except Exception as exc:
            self.session.rollback()
            raise ValueError(
                f"Category with slug {resolved_slug!r} already exists "
                f"for tenant {tenant_id}"
            ) from exc

        self._log_operation("create", "EnterpriseContextEntityCategory", str(record.id))
        return self._to_dto(record, artifact_count=0)

    # ------------------------------------------------------------------
    # update()
    # ------------------------------------------------------------------

    def update(
        self,
        category_id: str,
        updates: Dict[str, Any],
        ctx: Any = None,
    ) -> "CategoryDTO":
        """Apply a partial update to an existing category.

        Recognised update keys: ``name``, ``slug``, ``description``,
        ``sort_order``.  Unknown keys (e.g. ``color``, ``entity_type``,
        ``platform``) are silently ignored.

        Args:
            category_id: UUID string of the category to update.
            updates: Partial field map.
            ctx: Optional per-request metadata (unused).

        Returns:
            The updated :class:`~skillmeat.core.interfaces.dtos.CategoryDTO`.

        Raises:
            KeyError: If no category with ``category_id`` exists for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseContextEntityCategory

        uid = _ensure_uuid(category_id)
        stmt = self._apply_tenant_filter(
            select(EnterpriseContextEntityCategory).where(
                EnterpriseContextEntityCategory.id == uid
            )
        )
        row = self.session.execute(stmt).scalars().first()
        if row is None:
            raise KeyError(f"Category {category_id!r} not found for current tenant")

        _UPDATABLE = {"name", "slug", "description", "sort_order"}
        for field, value in updates.items():
            if field in _UPDATABLE:
                setattr(row, field, value)

        self.session.flush()
        self._log_operation("update", "EnterpriseContextEntityCategory", str(row.id))
        artifact_count = self._fetch_artifact_count(row.id)
        return self._to_dto(row, artifact_count=artifact_count)

    # ------------------------------------------------------------------
    # delete()
    # ------------------------------------------------------------------

    def delete(
        self,
        category_id: str,
        ctx: Any = None,
    ) -> None:
        """Delete a category by UUID primary key.

        Associations in ``enterprise_artifact_category_associations`` are
        cascade-deleted by the FK constraint (``ON DELETE CASCADE``).

        Args:
            category_id: UUID string of the category to delete.
            ctx: Optional per-request metadata (unused).

        Raises:
            KeyError: If no category with ``category_id`` exists for this tenant.
        """
        from skillmeat.cache.models_enterprise import EnterpriseContextEntityCategory

        uid = _ensure_uuid(category_id)
        stmt = self._apply_tenant_filter(
            select(EnterpriseContextEntityCategory).where(
                EnterpriseContextEntityCategory.id == uid
            )
        )
        row = self.session.execute(stmt).scalars().first()
        if row is None:
            raise KeyError(f"Category {category_id!r} not found for current tenant")

        self.session.delete(row)
        self.session.flush()
        self._log_operation("delete", "EnterpriseContextEntityCategory", category_id)


# =============================================================================
# EnterpriseArtifactHistoryEventRepository  (enterprise-stub-promotion-v1 TASK-1.2)
# =============================================================================


class EnterpriseArtifactHistoryEventRepository(
    EnterpriseRepositoryBase["EnterpriseArtifactHistoryEvent"],
    IArtifactActivityRepository,
):
    """Enterprise (PostgreSQL) implementation of ``IArtifactActivityRepository``.

    Replaces :class:`EnterpriseArtifactHistoryEventStub` with real persistence
    over the :class:`~skillmeat.cache.models_enterprise.EnterpriseArtifactHistoryEvent`
    ORM model (``enterprise_artifact_history_events`` table).

    Design notes
    ------------
    * **Append-only semantics**: Events are immutable once written.  No ``UPDATE``
      or ``DELETE`` SQL is issued by this repository.  :meth:`create_event` is
      the sole write path.
    * All query methods call ``_apply_tenant_filter()`` before executing — this
      is a security boundary that prevents cross-tenant data leakage.
    * ``artifact_id`` on the enterprise model is a ``UUID`` FK to
      ``enterprise_artifacts.id``, whereas the interface contract passes it as a
      ``str`` in ``"type:name"`` format.  Callers are responsible for resolving
      the logical artifact ID to the enterprise artifact UUID before calling
      :meth:`create_event`.  Within the repository, the string is coerced via
      ``_ensure_uuid``; if the string is not a valid UUID, the call is rejected
      gracefully.
    * ``created_at`` (not ``timestamp``) is the ORM column name for the event
      wall-clock time; it is aliased to ``timestamp`` in the DTO.
    * The session lifecycle is owned by the caller (FastAPI DI or test harness).
      This class calls ``session.flush()`` after inserts to materialise generated
      PKs; commit/rollback is the caller's responsibility.

    Security invariant
    ------------------
    Every ``select()`` statement that queries ``enterprise_artifact_history_events``
    **MUST** pass through ``_apply_tenant_filter()`` before execution.

    Parameters
    ----------
    session:
        Injected SQLAlchemy ``Session`` (PostgreSQL enterprise database).
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseArtifactHistoryEvent

        super().__init__(session, EnterpriseArtifactHistoryEvent)

    # ------------------------------------------------------------------
    # DTO converter
    # ------------------------------------------------------------------

    @staticmethod
    def _to_dto(event: "EnterpriseArtifactHistoryEvent") -> "ActivityEventDTO":
        """Convert an ``EnterpriseArtifactHistoryEvent`` ORM row to an :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO`.

        UUID fields (``id``, ``artifact_id``, ``actor_id``) are stringified so
        the DTO remains backend-agnostic.  ``created_at`` is mapped to the DTO
        ``timestamp`` field.

        Args:
            event: ORM instance to convert.

        Returns:
            Immutable :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO`.
        """
        from skillmeat.core.interfaces.dtos import ActivityEventDTO

        return ActivityEventDTO(
            id=str(event.id),
            artifact_id=str(event.artifact_id),
            event_type=event.event_type,
            owner_type=event.owner_type,
            timestamp=(
                event.created_at.isoformat() if event.created_at is not None else None
            ),
            actor_id=str(event.actor_id) if event.actor_id is not None else None,
            diff_json=event.diff_json,
            content_hash=event.content_hash,
        )

    # ------------------------------------------------------------------
    # Mutations (insert-only — append-only semantics)
    # ------------------------------------------------------------------

    def create_event(
        self,
        artifact_id: str,
        event_type: str,
        actor_id: Optional[str],
        owner_type: str,
        diff_json: Optional[str],
        content_hash: Optional[str],
        ctx: "Any | None" = None,
    ) -> "ActivityEventDTO":
        """Append a new lifecycle event to the enterprise activity log.

        This is the **only** write path for this repository; events are
        immutable once persisted (no UPDATE or DELETE is ever issued).

        A structured INFO log line is emitted on every successful insert so
        that operations teams can correlate audit-trail events with application
        activity without touching the database directly.

        Args:
            artifact_id: UUID string identifying the enterprise artifact.
                Must be parseable by ``uuid.UUID``; invalid values raise
                ``ValueError`` from ``_ensure_uuid``.
            event_type: One of ``'create'``, ``'update'``, ``'delete'``,
                ``'deploy'``, ``'undeploy'``, ``'sync'``, or any other
                lifecycle discriminator recognised by the application.
            actor_id: Optional UUID string for the user who triggered the
                event; ``None`` for automated/system-generated events.
            owner_type: Owner context at the time of the event (e.g.
                ``'user'``, ``'org'``).  Defaults to ``'user'`` when an
                empty string is supplied.
            diff_json: JSON-serialised diff payload, or ``None``.
            content_hash: SHA-256 hex digest of artifact content at event
                time, or ``None``.
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            The newly created and flushed :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO`
            (``id`` is populated after flush).
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactHistoryEvent

        tenant_id = self._get_tenant_id()
        artifact_uuid = _ensure_uuid(artifact_id)
        resolved_actor_id: Optional[uuid.UUID] = (
            _ensure_uuid(actor_id) if actor_id is not None else None
        )
        resolved_owner_type = owner_type or "user"

        row = EnterpriseArtifactHistoryEvent(
            tenant_id=tenant_id,
            artifact_id=artifact_uuid,
            event_type=event_type,
            owner_type=resolved_owner_type,
            actor_id=resolved_actor_id,
            diff_json=diff_json,
            content_hash=content_hash,
        )
        self.session.add(row)
        self.session.flush()

        logger.info(
            "EnterpriseArtifactHistoryEventRepository.create_event: "
            "id=%s event_type=%s artifact_id=%s actor_id=%s tenant_id=%s",
            row.id,
            event_type,
            artifact_id,
            actor_id,
            tenant_id,
        )
        return self._to_dto(row)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def list_events(
        self,
        artifact_id: Optional[str] = None,
        event_type: Optional[str] = None,
        actor_id: Optional[str] = None,
        owner_type: Optional[str] = None,
        time_range: Optional[Tuple[datetime, datetime]] = None,
        limit: int = 100,
        offset: int = 0,
        ctx: "Any | None" = None,
    ) -> "list[ActivityEventDTO]":
        """Return a filtered, paginated slice of enterprise activity events.

        All filter arguments are optional and AND-ed together when provided.
        Results are ordered by ``created_at`` ascending, then ``id`` ascending,
        matching the provenance-timeline ordering mandated by the interface.

        Every invocation calls ``_apply_tenant_filter()`` to enforce the tenant
        isolation invariant.

        Args:
            artifact_id: Restrict to events for this artifact UUID string.
                Invalid UUID strings are silently ignored (return empty list).
            event_type: Restrict to events of this type.
            actor_id: Restrict to events triggered by this actor UUID string.
            owner_type: Restrict to events with this owner context.
            time_range: ``(start, end)`` inclusive window in UTC; restricts
                to events where ``created_at >= start`` and
                ``created_at <= end``.
            limit: Maximum number of events to return (default 100).
            offset: Number of events to skip for pagination (default 0).
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO` ordered
            by ``created_at`` ascending, then ``id`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactHistoryEvent

        stmt = self._apply_tenant_filter(select(EnterpriseArtifactHistoryEvent))

        if artifact_id is not None:
            try:
                art_uuid = _ensure_uuid(artifact_id)
                stmt = stmt.where(
                    EnterpriseArtifactHistoryEvent.artifact_id == art_uuid
                )
            except (ValueError, AttributeError):
                logger.debug(
                    "EnterpriseArtifactHistoryEventRepository.list_events: "
                    "invalid artifact_id UUID %r — returning empty list",
                    artifact_id,
                )
                return []

        if event_type is not None:
            stmt = stmt.where(EnterpriseArtifactHistoryEvent.event_type == event_type)

        if actor_id is not None:
            try:
                actor_uuid = _ensure_uuid(actor_id)
                stmt = stmt.where(EnterpriseArtifactHistoryEvent.actor_id == actor_uuid)
            except (ValueError, AttributeError):
                logger.debug(
                    "EnterpriseArtifactHistoryEventRepository.list_events: "
                    "invalid actor_id UUID %r — returning empty list",
                    actor_id,
                )
                return []

        if owner_type is not None:
            stmt = stmt.where(EnterpriseArtifactHistoryEvent.owner_type == owner_type)

        if time_range is not None:
            start, end = time_range
            stmt = stmt.where(EnterpriseArtifactHistoryEvent.created_at >= start)
            stmt = stmt.where(EnterpriseArtifactHistoryEvent.created_at <= end)

        stmt = (
            stmt.order_by(
                EnterpriseArtifactHistoryEvent.created_at.asc(),
                EnterpriseArtifactHistoryEvent.id.asc(),
            )
            .offset(offset)
            .limit(limit)
        )
        return [self._to_dto(e) for e in self.session.execute(stmt).scalars().all()]

    def get_event(
        self,
        event_id: str,
        ctx: "Any | None" = None,
    ) -> "ActivityEventDTO | None":
        """Return a single enterprise activity event by its UUID string PK.

        Args:
            event_id: UUID string (hyphenated or hex) of the event row.
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            The matching :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO`
            when found and owned by the current tenant, ``None`` otherwise.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactHistoryEvent

        try:
            event_uuid = _ensure_uuid(event_id)
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseArtifactHistoryEventRepository.get_event: "
                "invalid UUID string %r — returning None",
                event_id,
            )
            return None

        stmt = self._apply_tenant_filter(
            select(EnterpriseArtifactHistoryEvent).where(
                EnterpriseArtifactHistoryEvent.id == event_uuid,
            )
        )
        row = self.session.execute(stmt).scalar_one_or_none()
        return self._to_dto(row) if row is not None else None

    def count_events(
        self,
        artifact_id: Optional[str] = None,
        event_type: Optional[str] = None,
        owner_type: Optional[str] = None,
        ctx: "Any | None" = None,
    ) -> int:
        """Return the count of enterprise activity events matching the given filters.

        All filter arguments are optional and AND-ed together.  Every invocation
        calls ``_apply_tenant_filter()`` to enforce tenant isolation.

        Args:
            artifact_id: Restrict count to events for this artifact UUID string.
            event_type: Restrict count to events of this type.
            owner_type: Restrict count to events with this owner context.
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            Non-negative integer count of matching event rows.
        """
        from sqlalchemy import func

        from skillmeat.cache.models_enterprise import EnterpriseArtifactHistoryEvent

        stmt = self._apply_tenant_filter(
            select(func.count()).select_from(EnterpriseArtifactHistoryEvent)
        )

        if artifact_id is not None:
            try:
                art_uuid = _ensure_uuid(artifact_id)
                stmt = stmt.where(
                    EnterpriseArtifactHistoryEvent.artifact_id == art_uuid
                )
            except (ValueError, AttributeError):
                return 0

        if event_type is not None:
            stmt = stmt.where(EnterpriseArtifactHistoryEvent.event_type == event_type)

        if owner_type is not None:
            stmt = stmt.where(EnterpriseArtifactHistoryEvent.owner_type == owner_type)

        result = self.session.execute(stmt).scalar_one()
        return int(result)

    def list_provenance_slice(
        self,
        artifact_id: str,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        ctx: "Any | None" = None,
    ) -> "list[ActivityEventDTO]":
        """Return the ordered provenance timeline for a single enterprise artifact.

        Returns all events for *artifact_id* within the optional time window,
        ordered chronologically ascending.  Every invocation calls
        ``_apply_tenant_filter()`` to enforce tenant isolation.

        Args:
            artifact_id: UUID string of the enterprise artifact.
            since: Lower bound (inclusive) of the time window in UTC.
                When ``None``, no lower bound is applied.
            until: Upper bound (inclusive) of the time window in UTC.
                When ``None``, no upper bound is applied.
            ctx: Optional per-request metadata (unused in this backend).

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ActivityEventDTO` ordered
            by ``created_at`` ascending, then ``id`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactHistoryEvent

        try:
            art_uuid = _ensure_uuid(artifact_id)
        except (ValueError, AttributeError):
            logger.debug(
                "EnterpriseArtifactHistoryEventRepository.list_provenance_slice: "
                "invalid artifact_id UUID %r — returning empty list",
                artifact_id,
            )
            return []

        stmt = self._apply_tenant_filter(
            select(EnterpriseArtifactHistoryEvent).where(
                EnterpriseArtifactHistoryEvent.artifact_id == art_uuid,
            )
        )

        if since is not None:
            stmt = stmt.where(EnterpriseArtifactHistoryEvent.created_at >= since)
        if until is not None:
            stmt = stmt.where(EnterpriseArtifactHistoryEvent.created_at <= until)

        stmt = stmt.order_by(
            EnterpriseArtifactHistoryEvent.created_at.asc(),
            EnterpriseArtifactHistoryEvent.id.asc(),
        )
        return [self._to_dto(e) for e in self.session.execute(stmt).scalars().all()]


class EnterpriseArtifactHistoryEventStub:
    """Enterprise stub for artifact history events.

    Returns empty results in enterprise mode. Promoted to full implementation
    when artifact write paths are enterprise-enabled and audit history
    recording is prioritized.

    Deferral decision: docs/dev/architecture/enterprise-intentional-stubs.md

    .. deprecated::
        Superseded by :class:`EnterpriseArtifactHistoryEventRepository`
        (enterprise-stub-promotion-v1 TASK-1.2).  Kept in source for downgrade
        safety only; do not wire into DI factories.
    """

    def list(self, *args, **kwargs):
        """Return empty list -- stub implementation."""
        return []

    def get(self, *args, **kwargs):
        """Return None -- stub implementation."""
        return None

    def record(self, *args, **kwargs):
        """No-op -- stub implementation for recording events."""
        return None


# =============================================================================
# EnterpriseGitCredentialRepository
# =============================================================================


class EnterpriseGitCredentialRepository(
    EnterpriseRepositoryBase["EnterpriseGitCredential"],
    IGitCredentialRepository,
):
    """Enterprise (PostgreSQL) repository for git credentials (GCD-2.4).

    Implements
    :class:`~skillmeat.core.interfaces.repositories.IGitCredentialRepository`
    for the enterprise PostgreSQL backend using SQLAlchemy 2.x ``select()``
    style with automatic tenant filtering via ``_apply_tenant_filter``.

    Every query MUST go through ``_apply_tenant_filter`` to enforce the tenant
    isolation invariant on all rows in ``enterprise_git_credentials``.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.  Lifecycle (commit/rollback/close) is managed by the caller.
    tenant_id:
        UUID of the current tenant; injected by the DI layer and applied to
        every read and write operation.
    """

    def __init__(self, session: Session, tenant_id: uuid.UUID) -> None:
        from skillmeat.cache.models_enterprise import EnterpriseGitCredential

        super().__init__(session, EnterpriseGitCredential)
        self._tenant_id = _ensure_uuid(tenant_id)

    # ------------------------------------------------------------------
    # DTO converter
    # ------------------------------------------------------------------

    @staticmethod
    def _to_dto(row: "EnterpriseGitCredential") -> "GitCredentialDTO":
        """Convert an ``EnterpriseGitCredential`` ORM row to a DTO.

        The ``token_encrypted`` field is intentionally excluded to prevent
        accidental leakage of credential material through the DTO layer.

        Args:
            row: ORM instance to convert.

        Returns:
            Immutable :class:`~skillmeat.core.interfaces.dtos.GitCredentialDTO`.
        """
        from skillmeat.core.interfaces.dtos import GitCredentialDTO

        return GitCredentialDTO(
            id=str(row.id),
            tenant_id=str(row.tenant_id),
            scope_type=str(row.scope_type),
            scope_id=str(row.scope_id),
            connection_id=(
                str(row.connection_id) if row.connection_id is not None else None
            ),
            credential_type=str(row.credential_type),
            created_by=str(row.created_by) if row.created_by is not None else None,
            created_at=(
                row.created_at.isoformat() if row.created_at is not None else None
            ),
        )

    def create(
        self,
        scope_type: str,
        scope_id: str,
        token: str,
        credential_type: str = "pat",
        connection_id: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> "GitCredentialDTO":
        """Create a new enterprise git credential.

        Args:
            scope_type: Owner scope label — one of ``'org'``, ``'team'``, or
                ``'developer'``.
            scope_id: UUID string identifying the scope owner (org, team, or
                user); coerced to ``uuid.UUID``.
            token: Plaintext credential token; encrypted transparently by the
                ``EncryptedString`` column type.
            credential_type: Token kind — ``'pat'`` (default) or
                ``'app_installation'``.
            connection_id: Optional UUID string FK to the parent
                ``enterprise_git_repo_connections.id``; cascade-deleted with the
                connection.
            created_by: Optional UUID string of the enterprise user creating
                this credential.

        Returns:
            The newly created ``EnterpriseGitCredential`` ORM instance (flushed;
            caller owns the transaction commit).
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitCredential

        record = EnterpriseGitCredential(
            tenant_id=self._tenant_id,
            scope_type=scope_type,
            scope_id=_ensure_uuid(scope_id),
            token_encrypted=token,
            credential_type=credential_type,
            connection_id=(
                _ensure_uuid(connection_id) if connection_id is not None else None
            ),
            created_by=_ensure_uuid(created_by) if created_by is not None else None,
        )
        self.session.add(record)
        self.session.flush()
        self._log_operation("create", "EnterpriseGitCredential", str(record.id))
        return self._to_dto(record)

    def get_by_id(self, credential_id: str) -> "GitCredentialDTO | None":
        """Get a credential by its UUID primary key.

        Args:
            credential_id: UUID string PK of the credential.

        Returns:
            DTO for the matching credential, or ``None`` if not found
            (including rows belonging to a different tenant).
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitCredential

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitCredential).where(
                EnterpriseGitCredential.id == _ensure_uuid(credential_id)
            )
        )
        row = self.session.execute(stmt).scalars().first()
        return self._to_dto(row) if row is not None else None

    def list_by_scope(self, scope_type: str, scope_id: str) -> "List[GitCredentialDTO]":
        """List credentials filtered by scope type and scope ID.

        Args:
            scope_type: Owner scope label (``'org'``, ``'team'``, or
                ``'developer'``).
            scope_id: UUID string identifying the scope owner.

        Returns:
            List of DTOs ordered by ``created_at`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitCredential

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitCredential).where(
                EnterpriseGitCredential.scope_type == scope_type,
                EnterpriseGitCredential.scope_id == _ensure_uuid(scope_id),
            )
        ).order_by(EnterpriseGitCredential.created_at.asc())
        return [self._to_dto(row) for row in self.session.execute(stmt).scalars()]

    def list_by_connection(self, connection_id: str) -> "List[GitCredentialDTO]":
        """List credentials pinned to a specific connection.

        Args:
            connection_id: UUID string FK to
                ``enterprise_git_repo_connections.id``.

        Returns:
            List of DTOs ordered by ``created_at`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitCredential

        stmt = self._apply_tenant_filter(
            select(EnterpriseGitCredential).where(
                EnterpriseGitCredential.connection_id == _ensure_uuid(connection_id)
            )
        ).order_by(EnterpriseGitCredential.created_at.asc())
        return [self._to_dto(row) for row in self.session.execute(stmt).scalars()]

    def delete(self, credential_id: str) -> bool:
        """Delete a credential by its UUID primary key.

        Verifies tenant ownership before deleting to prevent cross-tenant
        data removal.

        Args:
            credential_id: UUID string PK of the credential to delete.

        Returns:
            ``True`` if the credential existed and was deleted, ``False`` if it
            was not found (or belongs to a different tenant).
        """
        from skillmeat.cache.models_enterprise import EnterpriseGitCredential

        result = self.session.execute(
            delete(EnterpriseGitCredential).where(
                EnterpriseGitCredential.id == _ensure_uuid(credential_id),
                EnterpriseGitCredential.tenant_id == self._tenant_id,
            )
        )
        deleted = result.rowcount > 0
        self._log_operation("delete", "EnterpriseGitCredential", credential_id)
        return deleted


# =============================================================================
# EnterpriseTeamSyncRepository  (Team Sync Dashboard — BE-2.2)
# =============================================================================


class EnterpriseTeamSyncRepository:
    """Repository for team sync dashboard aggregate queries.

    Provides batch-fetch methods for the Team Sync Dashboard feature.  All
    methods apply mandatory tenant isolation via explicit ``WHERE tenant_id``
    predicates and use SQLAlchemy 2.x ``select()`` style — consistent with
    the rest of the enterprise repository layer.

    This repository is *read-only* and intentionally does not extend
    ``EnterpriseRepositoryBase`` because it operates across multiple model
    classes (``EnterpriseTeam``, ``EnterpriseTeamMember``,
    ``EnterpriseArtifactVersionScope``) rather than a single primary entity.
    Tenant filtering is applied explicitly on every statement.

    Design contract
    ---------------
    - No N+1 query patterns.  Members are loaded with ``selectin`` strategy
      via ``options(selectinload(...))``.  Scope rows are fetched in a single
      ``IN`` batch.
    - Transaction management (commit/rollback) is the caller's responsibility.
    - All ID parameters are ``uuid.UUID`` instances (not strings).

    Parameters
    ----------
    session:
        Injected SQLAlchemy ``Session`` bound to the PostgreSQL enterprise
        database.  Typically provided via ``DbSessionDep`` in FastAPI routes.

    References
    ----------
    Task BE-2.2 — Team Sync Dashboard aggregate queries.
    """

    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_tenant_id(self) -> uuid.UUID:
        """Resolve the active tenant UUID from ``TenantContext``.

        Falls back to ``DEFAULT_TENANT_ID`` when the context var is not set,
        mirroring the behaviour of ``EnterpriseRepositoryBase._get_tenant_id``.
        """
        tenant_id = TenantContext.get()
        if tenant_id is None:
            logger.debug(
                "TenantContext not set in EnterpriseTeamSyncRepository; "
                "falling back to DEFAULT_TENANT_ID (%s)",
                DEFAULT_TENANT_ID,
            )
            return DEFAULT_TENANT_ID
        return tenant_id

    # ------------------------------------------------------------------
    # Public query methods
    # ------------------------------------------------------------------

    def get_team_with_members(
        self, team_id: uuid.UUID, tenant_id: uuid.UUID
    ) -> "Optional[EnterpriseTeam]":
        """Return an ``EnterpriseTeam`` with its ``members`` collection pre-loaded.

        Uses a ``selectinload`` strategy so that the members are fetched in a
        second batched SQL statement rather than triggering lazy-load N+1
        queries when the caller iterates ``team.members``.

        Parameters
        ----------
        team_id:
            Primary key of the team to retrieve.
        tenant_id:
            Tenant scope.  The query is restricted to rows where
            ``enterprise_teams.tenant_id = tenant_id``.

        Returns
        -------
        EnterpriseTeam or None
            The ORM instance with ``members`` eagerly loaded, or ``None`` if
            no active team with that ID exists in this tenant.
        """
        from sqlalchemy.orm import selectinload

        from skillmeat.cache.models_enterprise import (
            EnterpriseTeam,
            EnterpriseTeamMember,
        )

        stmt = (
            select(EnterpriseTeam)
            .where(
                EnterpriseTeam.id == team_id,
                EnterpriseTeam.tenant_id == tenant_id,
                EnterpriseTeam.is_active.is_(True),
            )
            .options(selectinload(EnterpriseTeam.members))
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def get_all_scope_rows_for_team(
        self, team_id: uuid.UUID, tenant_id: uuid.UUID
    ) -> "List[EnterpriseArtifactVersionScope]":
        """Fetch all ``artifact_version_scopes`` rows owned by a team.

        Returns every scope row where ``owner_type = 'team'`` and
        ``owner_id = team_id`` for the given tenant.  This is a single
        batch query — no per-artifact loops.

        Parameters
        ----------
        team_id:
            UUID of the team whose scope rows are requested.  Matched against
            ``artifact_version_scopes.owner_id``.
        tenant_id:
            Tenant scope applied as an additional ``WHERE`` predicate.

        Returns
        -------
        list[EnterpriseArtifactVersionScope]
            All matching scope rows, ordered by ``artifact_id`` for stable
            iteration.  May be empty if the team owns no tracked artifacts.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        stmt = (
            select(EnterpriseArtifactVersionScope)
            .where(
                EnterpriseArtifactVersionScope.tenant_id == tenant_id,
                EnterpriseArtifactVersionScope.owner_type == "team",
                EnterpriseArtifactVersionScope.owner_id == team_id,
            )
            .order_by(EnterpriseArtifactVersionScope.artifact_id)
        )
        return list(self.session.execute(stmt).scalars())

    def get_developer_scopes_for_team(
        self, team_id: uuid.UUID, tenant_id: uuid.UUID
    ) -> "List[EnterpriseArtifactVersionScope]":
        """Fetch all user-owned scope rows for artifacts tracked by a team.

        Two-phase batch fetch (no per-artifact N+1):

        1. Collect the distinct set of ``artifact_id`` values from all
           ``owner_type='team'`` scope rows for this team.
        2. Return all ``owner_type='user'`` scope rows whose ``artifact_id``
           is in that set.

        This gives the caller the full picture of per-developer divergence
        for every artifact in the team's catalog.

        Parameters
        ----------
        team_id:
            UUID of the team.  Used in phase 1 to identify team-owned
            artifact IDs.
        tenant_id:
            Tenant scope applied on both queries.

        Returns
        -------
        list[EnterpriseArtifactVersionScope]
            All user-owned scope rows for the team's artifacts, ordered by
            ``artifact_id``, then ``owner_id``.  Empty when the team owns no
            tracked artifacts or no developers have individual scope rows.
        """
        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope

        # Phase 1: collect artifact IDs tracked by the team (single query)
        team_artifact_id_stmt = select(
            EnterpriseArtifactVersionScope.artifact_id
        ).where(
            EnterpriseArtifactVersionScope.tenant_id == tenant_id,
            EnterpriseArtifactVersionScope.owner_type == "team",
            EnterpriseArtifactVersionScope.owner_id == team_id,
        )
        team_artifact_ids: List[uuid.UUID] = list(
            self.session.execute(team_artifact_id_stmt).scalars()
        )

        if not team_artifact_ids:
            return []

        # Phase 2: fetch all user-owned scope rows for those artifacts (single IN query)
        stmt = (
            select(EnterpriseArtifactVersionScope)
            .where(
                EnterpriseArtifactVersionScope.tenant_id == tenant_id,
                EnterpriseArtifactVersionScope.owner_type == "user",
                EnterpriseArtifactVersionScope.artifact_id.in_(team_artifact_ids),
            )
            .order_by(
                EnterpriseArtifactVersionScope.artifact_id,
                EnterpriseArtifactVersionScope.owner_id,
            )
        )
        return list(self.session.execute(stmt).scalars())

    def list_teams_for_tenant(self, tenant_id: uuid.UUID) -> "List[EnterpriseTeam]":
        """List all active teams scoped to a tenant.

        Returns every ``EnterpriseTeam`` row where ``tenant_id`` matches and
        ``is_active = True``, ordered alphabetically by name.  Does not
        eagerly load members — use :meth:`get_team_with_members` when member
        data is needed.

        Parameters
        ----------
        tenant_id:
            Tenant scope.

        Returns
        -------
        list[EnterpriseTeam]
            Active teams in alphabetical order, or an empty list if none exist.
        """
        from skillmeat.cache.models_enterprise import EnterpriseTeam

        stmt = (
            select(EnterpriseTeam)
            .where(
                EnterpriseTeam.tenant_id == tenant_id,
                EnterpriseTeam.is_active.is_(True),
            )
            .order_by(EnterpriseTeam.name)
        )
        return list(self.session.execute(stmt).scalars())


# ---------------------------------------------------------------------------
# EnterpriseScaffoldTemplateRepository  (enterprise-stub-promotion-v1 TASK-3.1)
# ---------------------------------------------------------------------------


class EnterpriseScaffoldTemplateRepository(
    EnterpriseRepositoryBase["EnterpriseScaffoldTemplate"],
):
    """Repository for tenant-scoped CRUD on EnterpriseScaffoldTemplate.

    Mirrors the public API of the local
    :class:`~skillmeat.cache.scaffold_template_repository.ScaffoldTemplateRepository`
    so that :class:`~skillmeat.core.services.scaffold_template_service.ScaffoldTemplateService`
    can use either implementation transparently.

    All queries are automatically scoped to the tenant stored in
    ``TenantContext`` via ``_apply_tenant_filter()``.  Every ``select()``
    statement in this class must go through that method.

    Parameters
    ----------
    session:
        An open SQLAlchemy ``Session`` bound to the enterprise PostgreSQL
        database.  Lifecycle (commit/rollback/close) is managed by the caller.

    Examples
    --------
    ::

        with tenant_scope(tenant_uuid):
            repo = EnterpriseScaffoldTemplateRepository(db_session)
            tmpl = repo.create(session, {"bundle_id": "abc123", "enabled": True})
            fetched = repo.get(session, tmpl.id)
    """

    def __init__(self, session: Session) -> None:
        from skillmeat.cache.models_enterprise import (
            EnterpriseScaffoldTemplate as _EST,
        )

        super().__init__(session, _EST)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_or_none(self, id: str) -> "Optional[EnterpriseScaffoldTemplate]":
        """Return the template with *id* scoped to the current tenant, or None.

        Parameters
        ----------
        id:
            UUID string primary key of the scaffold template.

        Returns
        -------
        EnterpriseScaffoldTemplate or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseScaffoldTemplate

        stmt = self._apply_tenant_filter(
            select(EnterpriseScaffoldTemplate).where(
                EnterpriseScaffoldTemplate.id == id
            )
        )
        return self.session.execute(stmt).scalar_one_or_none()

    # ------------------------------------------------------------------
    # CRUD — matches ScaffoldTemplateRepository public signatures
    # ------------------------------------------------------------------

    def create(
        self,
        session: Session,
        data: "Dict[str, Any]",
    ) -> "EnterpriseScaffoldTemplate":
        """Persist a new EnterpriseScaffoldTemplate record.

        A new UUID hex ``id`` is generated when ``data`` does not supply one.
        ``created_at`` and ``updated_at`` are set by the server default.

        Parameters
        ----------
        session:
            SQLAlchemy session (accepted for interface compatibility; the
            repository uses ``self.session`` which is injected at construction
            time via FastAPI DI).
        data:
            Dict of field values.  ``bundle_id`` is required.

        Returns
        -------
        EnterpriseScaffoldTemplate
            The newly flushed ORM instance.

        Raises
        ------
        sqlalchemy.exc.IntegrityError
            When UNIQUE (tenant_id, bundle_id) is violated.
        """
        import uuid as _uuid

        from skillmeat.cache.models_enterprise import EnterpriseScaffoldTemplate

        tenant_id = self._get_tenant_id()
        now = datetime.utcnow()

        template = EnterpriseScaffoldTemplate(
            id=data.get("id") or str(_uuid.uuid4()),
            tenant_id=tenant_id,
            bundle_id=data["bundle_id"],
            enabled=data.get("enabled", True),
            required_variables=data.get("required_variables"),
            variable_type_map=data.get("variable_type_map"),
            skeleton_ref=data.get("skeleton_ref"),
            backstage_owner=data.get("backstage_owner"),
            backstage_type=data.get("backstage_type", "service"),
            backstage_tags=data.get("backstage_tags"),
            bundle_version_at_last_generation=data.get(
                "bundle_version_at_last_generation"
            ),
            generation_history=data.get("generation_history"),
        )

        self.session.add(template)
        self.session.flush()
        self._log_operation(
            operation="create",
            entity_type="EnterpriseScaffoldTemplate",
            entity_id=template.id,
            metadata={"bundle_id": template.bundle_id, "enabled": template.enabled},
        )
        return template

    def get(
        self,
        session: Session,
        id: str,
    ) -> "Optional[EnterpriseScaffoldTemplate]":
        """Retrieve a scaffold template by primary key.

        Parameters
        ----------
        session:
            Accepted for interface compatibility; uses ``self.session``.
        id:
            UUID string primary key.

        Returns
        -------
        EnterpriseScaffoldTemplate or None
        """
        return self._get_or_none(id)

    def update(
        self,
        session: Session,
        id: str,
        data: "Dict[str, Any]",
    ) -> "Optional[EnterpriseScaffoldTemplate]":
        """Update mutable fields on an existing EnterpriseScaffoldTemplate.

        Only fields present in ``data`` are updated; ``id``, ``bundle_id``,
        and ``created_at`` are silently ignored (immutable).  ``updated_at``
        is set to the current UTC time.

        Parameters
        ----------
        session:
            Accepted for interface compatibility; uses ``self.session``.
        id:
            UUID string primary key of the template to update.
        data:
            Dict of fields to update.

        Returns
        -------
        EnterpriseScaffoldTemplate or None
            Updated ORM instance, or ``None`` if not found.

        Raises
        ------
        sqlalchemy.exc.IntegrityError
            On unique-constraint violation.
        """
        _IMMUTABLE = {"id", "bundle_id", "created_at", "tenant_id"}

        template = self._get_or_none(id)
        if template is None:
            return None

        for field, value in data.items():
            if field in _IMMUTABLE:
                continue
            if hasattr(template, field):
                setattr(template, field, value)

        template.updated_at = datetime.utcnow()

        self.session.flush()
        self._log_operation(
            operation="update",
            entity_type="EnterpriseScaffoldTemplate",
            entity_id=template.id,
        )
        return template

    def delete(
        self,
        session: Session,
        id: str,
    ) -> bool:
        """Delete a scaffold template by primary key.

        Parameters
        ----------
        session:
            Accepted for interface compatibility; uses ``self.session``.
        id:
            UUID string primary key of the template to delete.

        Returns
        -------
        bool
            ``True`` if a row was deleted, ``False`` if not found.
        """
        template = self._get_or_none(id)
        if template is None:
            return False

        self.session.delete(template)
        self.session.flush()
        self._log_operation(
            operation="delete",
            entity_type="EnterpriseScaffoldTemplate",
            entity_id=id,
        )
        return True

    def list(
        self,
        session: Session,
        enabled_only: bool = False,
    ) -> "List[EnterpriseScaffoldTemplate]":
        """Return all scaffold templates for the current tenant.

        Parameters
        ----------
        session:
            Accepted for interface compatibility; uses ``self.session``.
        enabled_only:
            When ``True``, only templates where ``enabled=True`` are returned.

        Returns
        -------
        list[EnterpriseScaffoldTemplate]
            Templates ordered by ``created_at`` ascending.
        """
        from skillmeat.cache.models_enterprise import EnterpriseScaffoldTemplate

        stmt = self._apply_tenant_filter(select(EnterpriseScaffoldTemplate))
        if enabled_only:
            stmt = stmt.where(EnterpriseScaffoldTemplate.enabled.is_(True))
        stmt = stmt.order_by(EnterpriseScaffoldTemplate.created_at.asc())
        return list(self.session.execute(stmt).scalars())

    def get_by_bundle_id(
        self,
        session: Session,
        bundle_id: str,
    ) -> "Optional[EnterpriseScaffoldTemplate]":
        """Retrieve the scaffold template associated with a given bundle entity.

        Because UNIQUE (tenant_id, bundle_id) is enforced, at most one row
        can match.

        Parameters
        ----------
        session:
            Accepted for interface compatibility; uses ``self.session``.
        bundle_id:
            Primary key (TEXT) of the owning ``EnterpriseBundleEntity``.

        Returns
        -------
        EnterpriseScaffoldTemplate or None
        """
        from skillmeat.cache.models_enterprise import EnterpriseScaffoldTemplate

        stmt = self._apply_tenant_filter(
            select(EnterpriseScaffoldTemplate).where(
                EnterpriseScaffoldTemplate.bundle_id == bundle_id
            )
        )
        return self.session.execute(stmt).scalar_one_or_none()

    def get_enabled(
        self,
        session: Session,
    ) -> "List[EnterpriseScaffoldTemplate]":
        """Return all scaffold templates where ``enabled=True``.

        Convenience shortcut for ``list(session, enabled_only=True)``.

        Parameters
        ----------
        session:
            Accepted for interface compatibility; uses ``self.session``.

        Returns
        -------
        list[EnterpriseScaffoldTemplate]
        """
        return self.list(session, enabled_only=True)
