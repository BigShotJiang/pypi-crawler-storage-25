"""Dialect-aware SQL helpers for Alembic migrations.

This module centralizes database dialect detection and trigger creation so
that migration files can be made dialect-aware without duplicating
boilerplate.  All helpers use ``op.get_bind()`` to inspect the live
connection's dialect at migration time, meaning they are safe to call from
both ``upgrade()`` and ``downgrade()`` bodies.

Supported dialects
------------------
* **SQLite** – used for the default local/single-tenant configuration.
* **PostgreSQL** – used for the enterprise multi-tenant configuration.

Usage example
-------------
::

    from alembic import op
    from skillmeat.cache.migrations.dialect_helpers import (
        is_sqlite,
        is_postgresql,
        create_updated_at_trigger,
        drop_updated_at_trigger,
    )

    def upgrade() -> None:
        op.create_table("my_table", ...)
        create_updated_at_trigger("my_table")          # default column: updated_at
        create_updated_at_trigger("my_table", "synced_at")  # custom column

    def downgrade() -> None:
        drop_updated_at_trigger("my_table")
        op.drop_table("my_table")
"""

from __future__ import annotations

from alembic import op

# ---------------------------------------------------------------------------
# dialect_compatibility convention
# ---------------------------------------------------------------------------
# Each migration file may declare a module-level string constant named
# ``dialect_compatibility`` that advertises which database backends the
# migration supports.  The env.py ``include_object`` callback reads this
# constant and skips migrations that are incompatible with the active dialect.
#
# Valid values (defined in DIALECT_COMPATIBILITY_VALUES below):
#
#   "postgresql_only"
#       Migration contains operations that only work on PostgreSQL — e.g. JSONB
#       columns, RLS policies, ``enterprise_*`` tables, or advanced index types.
#       It will be silently skipped when Alembic runs against SQLite.
#
#   "sqlite_only"
#       Migration contains operations that only work on SQLite — e.g. SQLite
#       FTS5 virtual tables or PRAGMA statements.  It will be silently skipped
#       when Alembic runs against PostgreSQL.
#
#   "all"  (default when the constant is absent)
#       Migration is dialect-safe and will run on both SQLite and PostgreSQL.
#       This is the correct value for new shared-schema migrations.
#
# Usage example in a migration file
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ::
#
#     # ent_025_my_feature.py
#     from __future__ import annotations
#
#     from typing import Sequence, Union
#
#     from alembic import op
#     from skillmeat.cache.migrations.dialect_helpers import is_postgresql
#
#     revision: str = "ent_025_my_feature"
#     down_revision: Union[str, None] = "ent_024_enterprise_artifact_parity_columns"
#     branch_labels = None
#     depends_on = None
#
#     # --- dialect declaration ------------------------------------------------
#     dialect_compatibility: str = "postgresql_only"
#     # -----------------------------------------------------------------------
#
#     def upgrade() -> None:
#         if not is_postgresql():
#             return  # defense-in-depth guard (layer 2); env.py filter is layer 1
#         op.create_table("enterprise_feature", ...)
#
# Migration files that support both dialects simply omit the constant (defaults
# to ``"all"``) or set it explicitly to ``"all"``.

#: Frozenset of all valid ``dialect_compatibility`` values.  Validation is
#: intentionally lenient in env.py (unknown values are treated as ``"all"`` to
#: avoid hard failures on future values), but migration authors should use only
#: these three strings.
DIALECT_COMPATIBILITY_VALUES: frozenset[str] = frozenset(
    {"postgresql_only", "sqlite_only", "all"}
)


def is_compatible(declared: str, current_dialect: str) -> bool:
    """Return True when a migration's declared compatibility allows the given dialect.

    This helper is used by the env.py callback to decide whether to include a
    migration in the current run.  It is intentionally permissive: any
    unrecognised value of *declared* is treated as ``"all"`` so that future
    compatibility strings do not cause hard failures.

    Args:
        declared: The value of the migration module's ``dialect_compatibility``
            attribute (e.g. ``"postgresql_only"``).  Pass ``"all"`` if the
            attribute is absent.
        current_dialect: The SQLAlchemy dialect name for the active connection,
            e.g. ``"sqlite"`` or ``"postgresql"``.

    Returns:
        ``True`` if the migration should run against *current_dialect*.

    Examples::

        >>> is_compatible("postgresql_only", "sqlite")
        False
        >>> is_compatible("postgresql_only", "postgresql")
        True
        >>> is_compatible("sqlite_only", "sqlite")
        True
        >>> is_compatible("sqlite_only", "postgresql")
        False
        >>> is_compatible("all", "sqlite")
        True
        >>> is_compatible("all", "postgresql")
        True
        >>> is_compatible("", "postgresql")   # unrecognised → treat as "all"
        True
    """
    if declared == "postgresql_only":
        return current_dialect == "postgresql"
    if declared == "sqlite_only":
        return current_dialect == "sqlite"
    # "all", missing, or any unrecognised value → include on all dialects
    return True


# ---------------------------------------------------------------------------
# Dialect detection
# ---------------------------------------------------------------------------


def is_sqlite() -> bool:
    """Return True when the current migration connection targets SQLite.

    Uses ``op.get_bind()`` to inspect the active dialect, so this function
    must only be called from within a migration ``upgrade()`` or
    ``downgrade()`` body.

    Returns:
        True if the database dialect is SQLite, False otherwise.

    Example:
        >>> if is_sqlite():
        ...     op.execute("PRAGMA journal_mode=WAL")
    """
    return op.get_bind().dialect.name == "sqlite"


def is_postgresql() -> bool:
    """Return True when the current migration connection targets PostgreSQL.

    Uses ``op.get_bind()`` to inspect the active dialect, so this function
    must only be called from within a migration ``upgrade()`` or
    ``downgrade()`` body.

    Returns:
        True if the database dialect is PostgreSQL, False otherwise.

    Example:
        >>> if is_postgresql():
        ...     op.execute("SET search_path TO app_schema")
    """
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Trigger helpers
# ---------------------------------------------------------------------------


def create_updated_at_trigger(
    table_name: str,
    column: str = "updated_at",
    pk_column: str = "id",
) -> None:
    """Create a dialect-appropriate trigger to maintain an auto-updated timestamp.

    The trigger fires on every UPDATE to the target table and sets the
    specified column to the current wall-clock time.

    Trigger naming conventions
    ~~~~~~~~~~~~~~~~~~~~~~~~~~
    * **SQLite trigger name**: ``{table_name}_{column}``
    * **PostgreSQL function name**: ``update_{table_name}_{column}``
    * **PostgreSQL trigger name**: ``{table_name}_{column}_trigger``

    SQLite implementation
    ~~~~~~~~~~~~~~~~~~~~~
    Creates an ``AFTER UPDATE`` trigger that issues a follow-up
    ``UPDATE … SET {column} = CURRENT_TIMESTAMP WHERE id = NEW.id``.
    This matches the style established in ``001_initial_schema.py`` and all
    subsequent migration files in this project.

    PostgreSQL implementation
    ~~~~~~~~~~~~~~~~~~~~~~~~~
    1. Creates (or replaces) a trigger *function*
       ``update_{table_name}_{column}()`` that sets ``NEW.{column} = NOW()``
       and returns ``NEW``.
    2. Creates a ``BEFORE UPDATE`` trigger
       ``{table_name}_{column}_trigger`` on the table that calls the
       function for each row.

    Args:
        table_name: Name of the table to attach the trigger to.
        column: Name of the timestamp column to maintain.
                Defaults to ``"updated_at"``.

    Example:
        >>> create_updated_at_trigger("projects")
        >>> create_updated_at_trigger("collection_artifacts", "synced_at")
    """
    if is_postgresql():
        fn_name = f"update_{table_name}_{column}"
        trigger_name = f"{table_name}_{column}_trigger"

        # Create or replace the trigger function.
        op.execute(f"""
            CREATE OR REPLACE FUNCTION {fn_name}()
            RETURNS TRIGGER
            LANGUAGE plpgsql
            AS $$
            BEGIN
                NEW.{column} = NOW();
                RETURN NEW;
            END;
            $$;
            """)

        # Attach the trigger to the table.
        op.execute(f"""
            CREATE TRIGGER {trigger_name}
            BEFORE UPDATE ON {table_name}
            FOR EACH ROW
            EXECUTE FUNCTION {fn_name}();
            """)
    else:
        # SQLite — matches the naming and body style used throughout this
        # project's existing migration files.
        trigger_name = f"{table_name}_{column}"

        op.execute(f"""
            CREATE TRIGGER {trigger_name}
            AFTER UPDATE ON {table_name}
            FOR EACH ROW
            BEGIN
                UPDATE {table_name} SET {column} = CURRENT_TIMESTAMP WHERE {pk_column} = NEW.{pk_column};
            END;
            """)


def drop_updated_at_trigger(
    table_name: str,
    column: str = "updated_at",
) -> None:
    """Drop the trigger (and, on PostgreSQL, its backing function) created by
    :func:`create_updated_at_trigger`.

    Args:
        table_name: Name of the table whose trigger should be removed.
        column: Name of the timestamp column the trigger maintained.
                Defaults to ``"updated_at"``.

    Example:
        >>> drop_updated_at_trigger("projects")
        >>> drop_updated_at_trigger("collection_artifacts", "synced_at")
    """
    if is_postgresql():
        fn_name = f"update_{table_name}_{column}"
        trigger_name = f"{table_name}_{column}_trigger"

        op.execute(f"DROP TRIGGER IF EXISTS {trigger_name} ON {table_name};")
        op.execute(f"DROP FUNCTION IF EXISTS {fn_name}();")
    else:
        # SQLite
        trigger_name = f"{table_name}_{column}"
        op.execute(f"DROP TRIGGER IF EXISTS {trigger_name}")


__all__ = [
    # Dialect detection (migration-time, requires op.get_bind() context)
    "is_sqlite",
    "is_postgresql",
    # dialect_compatibility convention
    "DIALECT_COMPATIBILITY_VALUES",
    "is_compatible",
    # Trigger helpers
    "create_updated_at_trigger",
    "drop_updated_at_trigger",
]
