"""Alembic environment configuration for SkillMeat cache database.

This module configures the Alembic migration environment for the standalone
SQLite cache database. It handles both online (direct database connection)
and offline (SQL script generation) migration modes.

Key Features:
    - SQLite-specific configuration (no connection pooling)
    - WAL mode and foreign key enforcement
    - Support for both online and offline migrations
    - Automatic schema comparison for autogenerate

Usage:
    This file is used by Alembic internally. You typically won't import it directly.
    Instead, use the helper functions in skillmeat.cache.migrations:

    >>> from skillmeat.cache.migrations import run_migrations
    >>> run_migrations()

Migration Safety Pattern - FK Migrations Requiring Populated artifacts Table:
    Some migrations JOIN against the artifacts table to resolve type:name IDs
    to stable UUIDs (per ADR-007).  If the cache has never been populated (or
    was wiped), those JOINs silently produce zero rows and no data is migrated,
    causing permanent data loss for association rows.

    Any migration that reads from or JOINs against artifacts MUST call
    ``ensure_artifacts_populated()`` at the top of its ``upgrade()`` function:

    .. code-block:: python

        from skillmeat.cache.migrations.env import ensure_artifacts_populated

        def upgrade() -> None:
            ensure_artifacts_populated()   # Raises RuntimeError if table empty
            # ... rest of migration

    This guard is deliberately loud: it raises an unrecoverable error rather
    than silently migrating zero rows, which would be much harder to diagnose
    after the fact.
"""

from __future__ import annotations

import logging
import sys
from logging.config import fileConfig
from pathlib import Path
from typing import Any

from alembic import context, op
from sqlalchemy import engine_from_config, pool, text

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Migration safety helpers
# ---------------------------------------------------------------------------

_ARTIFACTS_LOW_WATERMARK = 10  # Warn when row count is suspiciously low


def ensure_artifacts_populated() -> None:
    """Assert that the artifacts table has been populated before proceeding.

    Call this at the top of any ``upgrade()`` function that JOINs against the
    artifacts table to resolve ``type:name`` identifiers to UUIDs.  If the
    cache has not been refreshed, the JOIN produces zero rows and the migration
    silently migrates nothing, leaving association tables empty.

    Raises:
        RuntimeError: If the artifacts table contains zero rows.

    Side-effects:
        Logs a WARNING when the row count is above zero but below
        ``_ARTIFACTS_LOW_WATERMARK`` (currently {watermark}), which may
        indicate a partially-populated cache.

    Example::

        from skillmeat.cache.migrations.env import ensure_artifacts_populated

        def upgrade() -> None:
            ensure_artifacts_populated()
            # ... rest of migration
    """.format(watermark=_ARTIFACTS_LOW_WATERMARK)
    conn = op.get_bind()
    result = conn.execute(text("SELECT COUNT(*) FROM artifacts"))
    count: int = result.scalar() or 0

    if count == 0:
        raise RuntimeError(
            "Cannot run migration: artifacts table is empty. "
            "Run 'skillmeat cache refresh' (or 'skillmeat web dev' which "
            "triggers a refresh on startup) and then re-run migrations."
        )

    if count < _ARTIFACTS_LOW_WATERMARK:
        logger.warning(
            "ensure_artifacts_populated: artifacts table has only %d row(s). "
            "This is unexpectedly low and may indicate a partially-populated "
            "cache. Migration will proceed, but verify results afterwards.",
            count,
        )


# ---------------------------------------------------------------------------
# Dialect-based migration filter
# ---------------------------------------------------------------------------
# Layer 1 of the two-layer defense: env.py reads each migration module's
# ``dialect_compatibility`` constant and skips incompatible revisions before
# their upgrade()/downgrade() functions are ever called.
#
# Implementation lives in ``dialect_filter.py`` (importable without an active
# Alembic context) so that the logic can be unit-tested in isolation.
#
# Rationale for wrapping ``fn`` vs other Alembic hooks:
#   - ``include_name`` with type_="table" filters schema objects — wrong hook.
#   - ``process_revision_directives`` fires only during ``--autogenerate``.
#   - The correct hook for filtering *which revision scripts execute* during
#     ``alembic upgrade`` is to wrap the ``fn`` callable supplied via
#     ``context.configure(fn=...)``.  Alembic's ``alembic.command.upgrade``
#     sets this ``fn`` on ``EnvironmentContext.context_opts``; we read it here
#     via ``context._proxy.context_opts["fn"]`` before calling configure, then
#     pass the wrapped version back as ``fn=`` in our configure call.
#
# Dialect is determined from the connection URL string (not from
# ``op.get_bind()``, which requires an active migration transaction).

from skillmeat.cache.migrations.dialect_filter import (  # noqa: E402
    _get_dialect_from_url,
    _make_dialect_filter_fn,
)


def _get_original_fn():
    """Return the migration step function (``fn``) set by alembic.command on
    the current ``EnvironmentContext`` before ``context.configure()`` is called.

    Alembic stores this in ``EnvironmentContext.context_opts["fn"]``.  The
    ``context`` module is a proxy whose underlying instance is accessible as
    ``context._proxy`` (set by ``EnvironmentContext.create_module_class_proxy``).
    Returns ``None`` when running outside a real Alembic command (e.g. in unit
    tests that construct a bare ``MigrationContext`` without going through
    ``alembic.command.upgrade``).
    """
    try:
        env_ctx = getattr(context, "_proxy", None)
        if env_ctx is None:
            return None
        return env_ctx.context_opts.get("fn")
    except Exception:
        return None


def _versions_dir() -> str:
    """Return the filesystem path to the Alembic versions directory."""
    return str(Path(__file__).parent / "versions")


# ---------------------------------------------------------------------------
# Add skillmeat to Python path for imports
skillmeat_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(skillmeat_root))

# Alembic Config object (provides access to .ini values)
config = context.config

# Interpret the config file for Python logging (if present and has logging sections)
if config.config_file_name is not None:
    try:
        fileConfig(config.config_file_name)
    except KeyError:
        # Logging sections not present in alembic.ini, skip logging config
        pass

# SQLAlchemy MetaData object for autogenerate support
from skillmeat.cache.models import Base, create_db_engine  # noqa: E402

target_metadata = Base.metadata

# Resolve DB URL: DATABASE_URL env var > alembic.ini > ConfigManager > default SQLite
import os  # noqa: E402

if config.get_main_option("sqlalchemy.url") is None:
    database_url = os.environ.get("DATABASE_URL", "").strip()
    if database_url:
        # Use DATABASE_URL from environment (e.g. postgresql://... for enterprise)
        config.set_main_option("sqlalchemy.url", database_url)
    else:
        try:
            from skillmeat.core.config import ConfigManager  # noqa: E402

            cfg_mgr = ConfigManager()
            db_path = cfg_mgr.get("cache.db-path") or (
                Path.home() / ".skillmeat" / "cache" / "cache.db"
            )
        except Exception:
            db_path = Path.home() / ".skillmeat" / "cache" / "cache.db"
        config.set_main_option("sqlalchemy.url", f"sqlite:///{db_path}")


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL and not an Engine,
    though an Engine is also acceptable here. By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the script output.

    This is useful for generating SQL migration scripts without database access.
    """
    url = config.get_main_option("sqlalchemy.url")

    # Determine active dialect from URL so the filter can work without a live
    # connection (offline mode has no engine).
    current_dialect = _get_dialect_from_url(url)
    # Read the fn that alembic.command.upgrade() wired onto the EnvironmentContext
    # before we call context.configure().  We wrap it to add dialect filtering.
    original_fn = _get_original_fn()

    filtered_fn = (
        _make_dialect_filter_fn(current_dialect, _versions_dir(), original_fn)
        if original_fn is not None
        else None
    )

    configure_kwargs: dict[str, Any] = dict(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        # SQLite-specific settings
        render_as_batch=True,  # Required for SQLite ALTER TABLE support
    )
    if filtered_fn is not None:
        configure_kwargs["fn"] = filtered_fn

    context.configure(**configure_kwargs)

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine and associate a connection
    with the context.

    This is the standard mode for applying migrations directly to a database.
    Supports both SQLite and PostgreSQL backends.
    """
    configuration = config.get_section(config.config_ini_section) or {}
    db_url = config.get_main_option("sqlalchemy.url")
    if db_url:
        configuration["sqlalchemy.url"] = db_url

    is_sqlite = db_url and db_url.startswith("sqlite")

    # Determine the active dialect for the migration filter.
    current_dialect = _get_dialect_from_url(db_url)

    # Engine kwargs differ by backend
    engine_kwargs: dict = {
        "prefix": "sqlalchemy.",
        "poolclass": pool.NullPool,
    }
    if is_sqlite:
        engine_kwargs["connect_args"] = {
            "check_same_thread": False,
            "timeout": 30.0,
        }

    connectable = engine_from_config(configuration, **engine_kwargs)

    # Ensure alembic_version.version_num is wide enough for date-based revision IDs
    # (e.g. '20260311_0003_add_skillbom_attestation_tables' = 46 chars > default 32).
    # Done in a separate connection to avoid disrupting migration transactions.
    if not is_sqlite:
        with connectable.connect() as pre_conn:
            result = pre_conn.execute(
                text(
                    "SELECT character_maximum_length FROM information_schema.columns "
                    "WHERE table_name = 'alembic_version' AND column_name = 'version_num'"
                )
            )
            row = result.fetchone()
            if row is None:
                # Table doesn't exist yet — pre-create with correct width so Alembic
                # doesn't create it with the default VARCHAR(32).
                pre_conn.execute(
                    text(
                        "CREATE TABLE IF NOT EXISTS alembic_version ("
                        "version_num VARCHAR(128) NOT NULL, "
                        "CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num))"
                    )
                )
            elif row[0] is not None and row[0] < 128:
                pre_conn.execute(
                    text(
                        "ALTER TABLE alembic_version ALTER COLUMN version_num TYPE VARCHAR(128)"
                    )
                )
            pre_conn.commit()

    with connectable.connect() as connection:
        # SQLite-specific PRAGMA tuning
        if is_sqlite:
            connection.execute(text("PRAGMA journal_mode = WAL"))
            connection.execute(text("PRAGMA synchronous = NORMAL"))
            connection.execute(text("PRAGMA foreign_keys = ON"))
            connection.execute(text("PRAGMA temp_store = MEMORY"))
            connection.execute(text("PRAGMA cache_size = -64000"))
            connection.execute(text("PRAGMA mmap_size = 268435456"))
            connection.commit()

        # Read the fn that alembic.command.upgrade() set on the EnvironmentContext
        # and wrap it with dialect-based filtering.  This is how env.py controls
        # which revision scripts are actually executed during an upgrade run.
        original_fn = _get_original_fn()
        filtered_fn = (
            _make_dialect_filter_fn(current_dialect, _versions_dir(), original_fn)
            if original_fn is not None
            else None
        )

        configure_kwargs: dict[str, Any] = dict(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=is_sqlite,  # Required for SQLite ALTER TABLE
            compare_type=True,
            compare_server_default=True,
        )
        if filtered_fn is not None:
            configure_kwargs["fn"] = filtered_fn

        context.configure(**configure_kwargs)

        with context.begin_transaction():
            context.run_migrations()


# Determine which mode to run in
if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
