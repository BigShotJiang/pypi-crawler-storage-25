"""Add artifact_blobs table and CAS columns to artifact_versions (DVCS-1.1).

Revision ID: 20260330_0005_add_artifact_blobs_cas
Revises: 20260330_0004_add_git_scan_artifacts
Create Date: 2026-03-30 00:05:00.000000+00:00

Background
----------
Introduces the Content-Addressed Storage (CAS) layer described in the DVCS CAS
Architecture spike and codified in ADR-013.  Two schema changes are applied:

1. New table ``artifact_blobs``
   Stores deduplicated artifact file content keyed by SHA-256 hash.  One blob
   may be referenced by many ``ArtifactVersion`` rows, enabling storage
   deduplication across the collection and across time.

2. New columns on ``artifact_versions``
   - ``content_tree``:       TEXT — JSON map of {relative_path: sha256_hex}
   - ``upstream_hash``:      VARCHAR(64) — hash of upstream content at capture
   - ``upstream_tier``:      INTEGER — upstream source tier (0 = canonical)
   - ``is_complete_capture``: BOOLEAN — True when all blob hashes are present

This is a SCHEMA-ONLY migration.  No data is moved.  Existing
``content_payload`` rows are untouched.  The DVCS-1.4 backfill migration will
populate ``content_tree`` and set ``is_complete_capture`` for historic versions.

artifact_blobs table
--------------------
    hash            VARCHAR(64)  PRIMARY KEY  SHA-256 hex digest (64 chars)
    content         TEXT         NOT NULL     Raw artifact file text
    encoding        VARCHAR(8)   NOT NULL     DEFAULT 'utf8'
    size_bytes      INTEGER      NOT NULL     Byte length of content
    created_at      DATETIME     NOT NULL     DEFAULT CURRENT_TIMESTAMP
    compression     VARCHAR(8)   NOT NULL     DEFAULT 'none'
    gc_eligible_at  DATETIME     NULL         GC candidate timestamp

Indexes:
    idx_artifact_blobs_created_at   (created_at)  — time-ordered GC sweeps
    idx_artifact_blobs_gc_eligible  (gc_eligible_at) — fast GC candidate lookup

artifact_versions additions
---------------------------
    content_tree        TEXT         NULL
    upstream_hash       VARCHAR(64)  NULL
    upstream_tier       INTEGER      NULL
    is_complete_capture BOOLEAN      NULL  DEFAULT 0

Dialect Strategy
----------------
All columns use portable SQLAlchemy types.  The GC partial-index
(WHERE gc_eligible_at IS NOT NULL) would be ideal on PostgreSQL for
performance but is not universally supported.  A regular index on
``gc_eligible_at`` is used here for full SQLite compat; a follow-up
PostgreSQL-only migration can replace it with a partial index if needed.

``op.batch_alter_table`` is used for the ``artifact_versions`` column
additions to support SQLite ALTER TABLE limitations.

Downgrade
---------
Drops the four new ``artifact_versions`` columns and the ``artifact_blobs``
table in the correct order (columns first, then table).
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0005_add_artifact_blobs_cas"
down_revision: Union[str, None] = "20260330_0004_add_git_scan_artifacts"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_BLOBS_TABLE = "artifact_blobs"
_VERSIONS_TABLE = "artifact_versions"

# New column names on artifact_versions
_COL_TREE = "content_tree"
_COL_UPSTREAM_HASH = "upstream_hash"
_COL_UPSTREAM_TIER = "upstream_tier"
_COL_COMPLETE = "is_complete_capture"


def _column_exists(bind: sa.engine.Connection, table: str, column: str) -> bool:
    if bind.dialect.name == "sqlite":
        result = bind.execute(text(f"PRAGMA table_info({table})"))
        return any(row[1] == column for row in result.fetchall())
    else:
        result = bind.execute(
            text(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = :t AND column_name = :c"
            ),
            {"t": table, "c": column},
        )
        return result.fetchone() is not None


def _table_exists(bind: sa.engine.Connection, table: str) -> bool:
    if bind.dialect.name == "sqlite":
        result = bind.execute(
            text("SELECT 1 FROM sqlite_master WHERE type='table' AND name=:t"),
            {"t": table},
        )
        return result.fetchone() is not None
    else:
        result = bind.execute(
            text(
                "SELECT 1 FROM information_schema.tables "
                "WHERE table_name = :t AND table_schema = 'public'"
            ),
            {"t": table},
        )
        return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create artifact_blobs table and add CAS columns to artifact_versions."""
    bind = op.get_bind()

    # ------------------------------------------------------------------
    # Dialect guard: PostgreSQL is handled entirely by the enterprise
    # migration chain (ent_013_enterprise_artifact_blobs_cas).  Running
    # this migration on PostgreSQL would create artifact_blobs with the
    # SQLite-oriented schema (PK "hash", TEXT content) which is
    # incompatible with the enterprise schema.  Skip on PostgreSQL.
    # ------------------------------------------------------------------
    if bind.dialect.name == "postgresql":
        log.info(
            "20260330_0005: PostgreSQL dialect detected — "
            "artifact_blobs is managed by ent_013; skipping."
        )
        return

    # ------------------------------------------------------------------
    # 1. Create artifact_blobs (idempotent)
    # ------------------------------------------------------------------
    if not _table_exists(bind, _BLOBS_TABLE):
        op.create_table(
            _BLOBS_TABLE,
            sa.Column(
                "hash",
                sa.String(64),
                primary_key=True,
                comment=(
                    "SHA-256 hex digest of content (64 chars). "
                    "Immutable once written — never update content for an existing hash."
                ),
            ),
            sa.Column(
                "content",
                sa.Text(),
                nullable=False,
                comment="Raw text content of the blob.",
            ),
            sa.Column(
                "encoding",
                sa.String(8),
                nullable=False,
                server_default="utf8",
                comment="Character encoding of content. Default: utf8.",
            ),
            sa.Column(
                "size_bytes",
                sa.Integer(),
                nullable=False,
                comment="Byte length of content (redundant for fast size queries).",
            ),
            sa.Column(
                "created_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("CURRENT_TIMESTAMP"),
                comment="UTC timestamp when the blob was first stored.",
            ),
            sa.Column(
                "compression",
                sa.String(8),
                nullable=False,
                server_default="none",
                comment=(
                    "Compression applied before storage. "
                    "'none' = raw text. Future: 'zstd', 'gzip'."
                ),
            ),
            sa.Column(
                "gc_eligible_at",
                sa.DateTime(),
                nullable=True,
                comment=(
                    "When set, blob is a GC candidate after this timestamp if "
                    "unreferenced. NULL = permanently retained."
                ),
            ),
        )

        op.create_index(
            "idx_artifact_blobs_created_at",
            _BLOBS_TABLE,
            ["created_at"],
        )
        op.create_index(
            "idx_artifact_blobs_gc_eligible",
            _BLOBS_TABLE,
            ["gc_eligible_at"],
        )

        log.info("upgrade: created %s table.", _BLOBS_TABLE)

    # ------------------------------------------------------------------
    # 2. Add CAS columns to artifact_versions
    #
    # Use plain op.add_column() instead of batch_alter_table.
    # All columns are nullable, so ALTER TABLE ADD COLUMN works on both
    # SQLite and PostgreSQL without table recreation.  batch_alter_table
    # with recreate="auto" triggers a full table copy on SQLite which
    # fails when PRAGMA foreign_keys=ON and other tables reference this
    # table via FKs (the INSERT into the temp copy violates FK checks).
    # ------------------------------------------------------------------
    _cas_columns = [
        (
            _COL_TREE,
            sa.Column(
                _COL_TREE,
                sa.Text(),
                nullable=True,
                comment=(
                    "JSON map of {relative_path: sha256_hex} for CAS blob references. "
                    "NULL until DVCS-1.4 backfill migration populates it."
                ),
            ),
        ),
        (
            _COL_UPSTREAM_HASH,
            sa.Column(
                _COL_UPSTREAM_HASH,
                sa.String(64),
                nullable=True,
                comment=(
                    "SHA-256 hex of upstream (GitHub) content at capture time. "
                    "Used for fast divergence detection without re-fetching upstream."
                ),
            ),
        ),
        (
            _COL_UPSTREAM_TIER,
            sa.Column(
                _COL_UPSTREAM_TIER,
                sa.Integer(),
                nullable=True,
                comment="Upstream source tier (0 = direct/canonical, >0 = fork depth).",
            ),
        ),
        (
            _COL_COMPLETE,
            sa.Column(
                _COL_COMPLETE,
                sa.Boolean(),
                nullable=True,
                server_default="0",
                comment=(
                    "True when all content_tree blob hashes exist in artifact_blobs. "
                    "Set by DVCS-1.4 backfill migration."
                ),
            ),
        ),
    ]

    for col_name, col_def in _cas_columns:
        if not _column_exists(bind, _VERSIONS_TABLE, col_name):
            op.add_column(_VERSIONS_TABLE, col_def)
            log.info("upgrade: added %s to %s.", col_name, _VERSIONS_TABLE)

    log.info(
        "upgrade: CAS columns on %s complete.",
        _VERSIONS_TABLE,
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove CAS columns from artifact_versions and drop artifact_blobs."""
    bind = op.get_bind()

    # PostgreSQL: ent_013 owns the artifact_blobs table; skip.
    if bind.dialect.name == "postgresql":
        log.info(
            "20260330_0005 downgrade: PostgreSQL dialect detected — "
            "artifact_blobs is managed by ent_013; skipping."
        )
        return

    # Remove new artifact_versions columns (reverse order of addition).
    # On SQLite, dropping columns requires batch_alter_table with recreation.
    # Temporarily disable FK checks to avoid the FK constraint failure during
    # the table copy that batch_alter_table performs.
    if is_sqlite():
        bind.execute(text("PRAGMA foreign_keys = OFF"))

    if _column_exists(bind, _VERSIONS_TABLE, _COL_COMPLETE):
        with op.batch_alter_table(_VERSIONS_TABLE, schema=None) as batch_op:
            batch_op.drop_column(_COL_COMPLETE)
            batch_op.drop_column(_COL_UPSTREAM_TIER)
            batch_op.drop_column(_COL_UPSTREAM_HASH)
            batch_op.drop_column(_COL_TREE)

    if is_sqlite():
        bind.execute(text("PRAGMA foreign_keys = ON"))

    log.info(
        "downgrade: removed CAS columns from %s.",
        _VERSIONS_TABLE,
    )

    # Drop artifact_blobs table (indexes dropped automatically)
    if _table_exists(bind, _BLOBS_TABLE):
        op.drop_table(_BLOBS_TABLE)

    log.info("downgrade: dropped %s table.", _BLOBS_TABLE)
