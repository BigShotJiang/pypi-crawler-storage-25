"""Fix bom_snapshot_id type and add FK constraint (DVCS-6.1)

Revision ID: 20260331_0001_fix_bom_snapshot_id_fk
Revises: 20260330_0003_add_git_repo_scans
Create Date: 2026-03-31 00:01:00.000000+00:00

Background
----------
DVCS-6.1 — Add foreign key constraint from artifact_versions.bom_snapshot_id
to bom_snapshots.id.

The `bom_snapshot_id` column was added in migration 20260327_0002_artifact_vcs_v2
as String(100), but the target `bom_snapshots.id` is Integer. This migration
fixes the type mismatch and adds the proper foreign key constraint.

Changes
-------
1. Change `artifact_versions.bom_snapshot_id` from String(100) to Integer
2. Add foreign key constraint from `artifact_versions.bom_snapshot_id`
   to `bom_snapshots.id` with ON DELETE SET NULL

Dialect Strategy
----------------
SQLite: Uses batch_alter_table with recreate="always" for column type changes
and FK constraint addition since SQLite has limited ALTER TABLE support.

PostgreSQL: Uses native ALTER COLUMN TYPE and ADD CONSTRAINT operations.

Compatibility
-------------
- Handles both empty tables and tables with existing NULL values
- The migration assumes bom_snapshot_id values are NULL (no data loss risk)
- FK constraint uses SET NULL on delete for referential integrity

Rollback
--------
Removes the FK constraint and reverts bom_snapshot_id back to String(100).
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260331_0001_fix_bom_snapshot_id_fk"
down_revision: Union[str, None] = "20260330_0003_add_git_repo_scans"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_TABLE = "artifact_versions"
_COLUMN = "bom_snapshot_id"
_FK_NAME = "fk_artifact_versions_bom_snapshot_id"
_TARGET_TABLE = "bom_snapshots"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_is_integer_sqlite(bind: sa.engine.Connection) -> bool:
    """Check if bom_snapshot_id is already Integer type in SQLite."""
    result = bind.execute(text(f"PRAGMA table_info({_TABLE})"))
    for row in result.fetchall():
        if row[1] == _COLUMN:  # column name
            # row[2] is the type - check if it's INTEGER
            return "INTEGER" in str(row[2]).upper()
    return False


def _column_is_integer_pg(bind: sa.engine.Connection) -> bool:
    """Check if bom_snapshot_id is already Integer type in PostgreSQL."""
    result = bind.execute(
        text("""
            SELECT data_type
            FROM information_schema.columns
            WHERE table_name = :table AND column_name = :column
            """),
        {"table": _TABLE, "column": _COLUMN},
    )
    row = result.fetchone()
    if row is None:
        return False
    return "integer" in str(row[0]).lower()


def _fk_constraint_exists_pg(bind: sa.engine.Connection) -> bool:
    """Check if the FK constraint already exists in PostgreSQL."""
    result = bind.execute(
        text("""
            SELECT 1 FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :fk_name AND t.relname = :table_name
            """),
        {"fk_name": _FK_NAME, "table_name": _TABLE},
    )
    return result.fetchone() is not None


def _fk_constraint_exists_sqlite(bind: sa.engine.Connection) -> bool:
    """Check if the FK constraint exists in SQLite by examining table schema."""
    result = bind.execute(
        text("SELECT sql FROM sqlite_master WHERE type='table' AND name=?"), (_TABLE,)
    )
    row = result.fetchone()
    if row is None:
        return False

    schema_sql = str(row[0])
    # Look for FK reference to bom_snapshots table
    return f"REFERENCES {_TARGET_TABLE}" in schema_sql and _COLUMN in schema_sql


def _column_exists_sqlite(bind: sa.engine.Connection, table: str, column: str) -> bool:
    """Check if a column exists in SQLite."""
    result = bind.execute(text(f"PRAGMA table_info({table})"))
    return any(row[1] == column for row in result.fetchall())


def _column_exists_pg(bind: sa.engine.Connection, table: str, column: str) -> bool:
    """Check if a column exists in PostgreSQL."""
    result = bind.execute(
        text("""
            SELECT 1 FROM information_schema.columns
            WHERE table_name = :table AND column_name = :column
            """),
        {"table": table, "column": column},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Fix bom_snapshot_id type and add FK constraint."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("fix_bom_snapshot_id_fk: SQLite upgrade path")
        _upgrade_sqlite(bind)
    elif is_postgresql():
        log.info("fix_bom_snapshot_id_fk: PostgreSQL upgrade path")
        _upgrade_postgresql(bind)
    else:
        log.warning(
            "fix_bom_snapshot_id_fk: Unknown dialect %r; skipping", bind.dialect.name
        )


def _upgrade_sqlite(bind: sa.engine.Connection) -> None:
    """SQLite upgrade: use batch_alter_table to change column type and add FK."""

    # Check if column exists
    if not _column_exists_sqlite(bind, _TABLE, _COLUMN):
        log.warning(
            "fix_bom_snapshot_id_fk (SQLite): Column %s.%s does not exist; skipping",
            _TABLE,
            _COLUMN,
        )
        return

    # Check if already upgraded
    if _column_is_integer_sqlite(bind) and _fk_constraint_exists_sqlite(bind):
        log.info("fix_bom_snapshot_id_fk (SQLite): Already upgraded; skipping")
        return

    # Use batch_alter_table to modify column type and add FK constraint
    with op.batch_alter_table(_TABLE, recreate="always") as batch_op:
        # Change column type from String to Integer
        batch_op.alter_column(_COLUMN, type_=sa.Integer, nullable=True)

        # Add foreign key constraint
        batch_op.create_foreign_key(
            _FK_NAME, _TARGET_TABLE, [_COLUMN], ["id"], ondelete="SET NULL"
        )

    log.info(
        "fix_bom_snapshot_id_fk (SQLite): Upgraded column type and added FK constraint"
    )


def _upgrade_postgresql(bind: sa.engine.Connection) -> None:
    """PostgreSQL upgrade: alter column type and add FK constraint."""

    # Check if column exists
    if not _column_exists_pg(bind, _TABLE, _COLUMN):
        log.warning(
            "fix_bom_snapshot_id_fk (PostgreSQL): Column %s.%s does not exist; skipping",
            _TABLE,
            _COLUMN,
        )
        return

    # Check if already upgraded
    if _column_is_integer_pg(bind) and _fk_constraint_exists_pg(bind):
        log.info("fix_bom_snapshot_id_fk (PostgreSQL): Already upgraded; skipping")
        return

    # Change column type if needed
    if not _column_is_integer_pg(bind):
        op.execute(
            text(
                f"ALTER TABLE {_TABLE} ALTER COLUMN {_COLUMN} TYPE INTEGER USING {_COLUMN}::INTEGER"
            )
        )
        log.info("fix_bom_snapshot_id_fk (PostgreSQL): Changed column type to Integer")

    # Add FK constraint if needed
    if not _fk_constraint_exists_pg(bind):
        op.create_foreign_key(
            _FK_NAME, _TABLE, _TARGET_TABLE, [_COLUMN], ["id"], ondelete="SET NULL"
        )
        log.info("fix_bom_snapshot_id_fk (PostgreSQL): Added FK constraint")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Revert bom_snapshot_id type and remove FK constraint."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("fix_bom_snapshot_id_fk: SQLite downgrade path")
        _downgrade_sqlite(bind)
    elif is_postgresql():
        log.info("fix_bom_snapshot_id_fk: PostgreSQL downgrade path")
        _downgrade_postgresql(bind)
    else:
        log.warning(
            "fix_bom_snapshot_id_fk: Unknown dialect %r; skipping", bind.dialect.name
        )


def _downgrade_sqlite(bind: sa.engine.Connection) -> None:
    """SQLite downgrade: remove FK and revert column type."""

    if not _column_exists_sqlite(bind, _TABLE, _COLUMN):
        log.info(
            "fix_bom_snapshot_id_fk (SQLite): Column does not exist; nothing to downgrade"
        )
        return

    # Use batch_alter_table to remove FK and change column type back
    with op.batch_alter_table(_TABLE, recreate="always") as batch_op:
        # Remove foreign key constraint
        batch_op.drop_constraint(_FK_NAME, type_="foreignkey")

        # Change column type back to String
        batch_op.alter_column(_COLUMN, type_=sa.String(100), nullable=True)

    log.info("fix_bom_snapshot_id_fk (SQLite): Reverted to String type and removed FK")


def _downgrade_postgresql(bind: sa.engine.Connection) -> None:
    """PostgreSQL downgrade: remove FK and revert column type."""

    if not _column_exists_pg(bind, _TABLE, _COLUMN):
        log.info(
            "fix_bom_snapshot_id_fk (PostgreSQL): Column does not exist; nothing to downgrade"
        )
        return

    # Remove FK constraint if it exists
    if _fk_constraint_exists_pg(bind):
        op.drop_constraint(_FK_NAME, _TABLE, type_="foreignkey")
        log.info("fix_bom_snapshot_id_fk (PostgreSQL): Removed FK constraint")

    # Change column type back to String
    if _column_is_integer_pg(bind):
        op.execute(
            text(f"ALTER TABLE {_TABLE} ALTER COLUMN {_COLUMN} TYPE VARCHAR(100)")
        )
        log.info(
            "fix_bom_snapshot_id_fk (PostgreSQL): Reverted column type to String(100)"
        )
