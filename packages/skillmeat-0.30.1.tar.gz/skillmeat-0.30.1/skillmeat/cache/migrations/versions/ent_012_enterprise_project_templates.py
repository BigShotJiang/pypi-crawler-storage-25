"""Add enterprise_project_templates and enterprise_project_template_entities tables.

Revision ID: ent_012_enterprise_project_templates
Revises: ent_010_version_scopes_and_history_tenant
Create Date: 2026-03-30 00:00:00.000000+00:00

Background
----------
Enterprise Project Templates feature.  Adds two PostgreSQL tables that let
tenants define reusable project scaffolds — a named template that bundles an
ordered list of artifact entities and an optional default project config.

This migration is a no-op on any non-PostgreSQL dialect.

Tables created
--------------
1. ``enterprise_project_templates``

    Stores one named template per tenant.  Template names are unique within a
    tenant (UNIQUE constraint on ``(tenant_id, name)``).

    Schema:
        id                          UUID PRIMARY KEY DEFAULT gen_random_uuid()
        tenant_id                   UUID NOT NULL
        name                        TEXT NOT NULL
        description                 TEXT NULL
        collection_id               TEXT NULL
        default_project_config_id   TEXT NULL
        created_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
        updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now()

    Constraints:
        uq_project_templates_tenant_name  UNIQUE (tenant_id, name)

    Indexes:
        idx_project_templates_tenant  (tenant_id)

2. ``enterprise_project_template_entities``

    Ordered list of artifact entities belonging to a template.  Rows are
    cascade-deleted when the parent template is removed.

    Schema:
        id           UUID PRIMARY KEY DEFAULT gen_random_uuid()
        template_id  UUID NOT NULL FK -> enterprise_project_templates.id ON DELETE CASCADE
        entity_id    TEXT NOT NULL
        position     INTEGER NOT NULL  (0-based deploy order)

    Indexes:
        idx_project_template_entities_template  (template_id)

Downgrade
---------
Drop ``enterprise_project_template_entities`` first (FK dependency), then
``enterprise_project_templates``.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_012_enterprise_project_templates"
down_revision: Union[str, Sequence[str], None] = (
    "ent_010_version_scopes_and_history_tenant"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TEMPLATES_TABLE = "enterprise_project_templates"
_ENTITIES_TABLE = "enterprise_project_template_entities"


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _table_exists(bind: sa.engine.Connection, table_name: str) -> bool:
    """Return True if *table_name* already exists (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.tables
            WHERE table_name = :tname
            """),
        {"tname": table_name},
    )
    return result.fetchone() is not None


def _index_exists(bind: sa.engine.Connection, index_name: str) -> bool:
    """Return True if *index_name* already exists (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM pg_indexes
            WHERE indexname = :iname
            """),
        {"iname": index_name},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create enterprise_project_templates and enterprise_project_template_entities."""
    if not _is_postgresql():
        log.info(
            "ent_012_enterprise_project_templates: non-PostgreSQL dialect detected; "
            "skipping enterprise-only migration."
        )
        return

    log.info("ent_012_enterprise_project_templates upgrade: running PostgreSQL path.")
    _upgrade_project_templates()
    _upgrade_project_template_entities()


def _upgrade_project_templates() -> None:
    """Create enterprise_project_templates table with unique constraint and index."""
    bind = op.get_bind()

    if _table_exists(bind, _TEMPLATES_TABLE):
        log.info(
            "ent_012: %s already exists; skipping table creation.",
            _TEMPLATES_TABLE,
        )
    else:
        op.create_table(
            _TEMPLATES_TABLE,
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                primary_key=True,
                server_default=text("gen_random_uuid()"),
                comment="Primary key; server-generated UUID",
            ),
            sa.Column(
                "tenant_id",
                postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
            ),
            sa.Column(
                "name",
                sa.Text(),
                nullable=False,
                comment="Human-readable template name; unique within a tenant",
            ),
            sa.Column(
                "description",
                sa.Text(),
                nullable=True,
                comment="Optional free-text description of the template",
            ),
            sa.Column(
                "collection_id",
                sa.Text(),
                nullable=True,
                comment="Optional ID of the owning collection",
            ),
            sa.Column(
                "default_project_config_id",
                sa.Text(),
                nullable=True,
                comment="Optional artifact ID for the default project config applied on scaffold",
            ),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=text("now()"),
                comment="Immutable creation timestamp",
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=text("now()"),
                comment="Last-modified timestamp",
            ),
            # UNIQUE: template names must be unique within a tenant
            sa.UniqueConstraint(
                "tenant_id",
                "name",
                name="uq_project_templates_tenant_name",
            ),
        )
        log.info("ent_012: created table %s.", _TEMPLATES_TABLE)

    # B-tree: fast tenant filter
    if not _index_exists(bind, "idx_project_templates_tenant"):
        op.create_index(
            "idx_project_templates_tenant",
            _TEMPLATES_TABLE,
            ["tenant_id"],
        )
        log.info("ent_012: created index idx_project_templates_tenant.")


def _upgrade_project_template_entities() -> None:
    """Create enterprise_project_template_entities table with FK and index."""
    bind = op.get_bind()

    if _table_exists(bind, _ENTITIES_TABLE):
        log.info(
            "ent_012: %s already exists; skipping table creation.",
            _ENTITIES_TABLE,
        )
    else:
        op.create_table(
            _ENTITIES_TABLE,
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                primary_key=True,
                server_default=text("gen_random_uuid()"),
                comment="Primary key; server-generated UUID",
            ),
            sa.Column(
                "template_id",
                postgresql.UUID(as_uuid=True),
                sa.ForeignKey(
                    f"{_TEMPLATES_TABLE}.id",
                    ondelete="CASCADE",
                    name="fk_project_template_entities_template_id",
                ),
                nullable=False,
                comment="Parent template; cascade-deletes all entity rows when template is removed",
            ),
            sa.Column(
                "entity_id",
                sa.Text(),
                nullable=False,
                comment="Artifact entity identifier in 'type:name' format",
            ),
            sa.Column(
                "position",
                sa.Integer(),
                nullable=False,
                comment="0-based deploy order within the template",
            ),
        )
        log.info("ent_012: created table %s.", _ENTITIES_TABLE)

    # B-tree: FK index for fast template lookups
    if not _index_exists(bind, "idx_project_template_entities_template"):
        op.create_index(
            "idx_project_template_entities_template",
            _ENTITIES_TABLE,
            ["template_id"],
        )
        log.info("ent_012: created index idx_project_template_entities_template.")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop enterprise_project_template_entities, then enterprise_project_templates."""
    if not _is_postgresql():
        log.info(
            "ent_012_enterprise_project_templates downgrade: "
            "non-PostgreSQL dialect detected; skipping."
        )
        return

    log.info("ent_012_enterprise_project_templates downgrade: running PostgreSQL path.")
    _downgrade_project_template_entities()
    _downgrade_project_templates()


def _downgrade_project_template_entities() -> None:
    """Drop enterprise_project_template_entities table."""
    bind = op.get_bind()

    if not _table_exists(bind, _ENTITIES_TABLE):
        log.info("ent_012: %s does not exist; skipping drop.", _ENTITIES_TABLE)
        return

    # Indexes are dropped automatically with the table.
    op.drop_table(_ENTITIES_TABLE)
    log.info("ent_012: dropped table %s.", _ENTITIES_TABLE)


def _downgrade_project_templates() -> None:
    """Drop enterprise_project_templates table."""
    bind = op.get_bind()

    if not _table_exists(bind, _TEMPLATES_TABLE):
        log.info("ent_012: %s does not exist; skipping drop.", _TEMPLATES_TABLE)
        return

    # Indexes and the unique constraint are dropped automatically with the table.
    op.drop_table(_TEMPLATES_TABLE)
    log.info("ent_012: dropped table %s.", _TEMPLATES_TABLE)
