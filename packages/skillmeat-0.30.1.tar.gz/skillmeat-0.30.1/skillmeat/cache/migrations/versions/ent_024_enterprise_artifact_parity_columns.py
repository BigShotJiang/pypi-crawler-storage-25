"""Add core_content and latest_deployment_id to enterprise_artifacts.

Revision ID: ent_024_enterprise_artifact_parity_columns
Revises: ent_023_enterprise_cas_columns
Create Date: 2026-04-07 00:00:00.000000+00:00

Background
----------
Two columns added to the local ``artifacts`` table by prior migrations were
never paired into the enterprise migration chain, leaving ``enterprise_artifacts``
missing both columns (schema drift):

1. ``core_content`` (TEXT, nullable) — added to local ``artifacts`` in the initial
   consolidated schema migration. Stores platform-agnostic content before assembly
   when modular_content_architecture is enabled.

2. ``latest_deployment_id`` (UUID, nullable FK -> enterprise_deployments.id) —
   added to local ``artifacts`` in ``20260327_0002_artifact_vcs_v2`` as a
   ``String`` FK to ``project_version_deployments.id``.  On enterprise the column
   is UUID-typed (matching enterprise UUID PKs) and the FK target is
   ``enterprise_deployments.id`` (the enterprise deployment table), NOT
   ``project_version_deployments``.

Schema change
-------------
    Table:  enterprise_artifacts  (PostgreSQL only)

    New columns (both nullable):
        core_content          TEXT         NULL
        latest_deployment_id  UUID         NULL  FK -> enterprise_deployments.id
                                                 ON DELETE SET NULL

    New index:
        ix_enterprise_artifacts_latest_deployment_id
            ON enterprise_artifacts (latest_deployment_id)

    FK constraint:
        fk_enterprise_artifacts_latest_deployment_id
            enterprise_artifacts.latest_deployment_id -> enterprise_deployments.id
            ON DELETE SET NULL

Design notes
------------
- SQLite branch is a no-op: ``enterprise_artifacts`` is PostgreSQL-only.
- Both columns are nullable so existing rows remain valid after ALTER.
- Idempotent via ``_column_exists_pg`` guard — safe to re-run.
- The FK constraint is named explicitly so downgrade can drop it by name.

Downgrade
---------
Drop index, FK constraint, and both columns from ``enterprise_artifacts``.
No-op on SQLite.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

from skillmeat.cache.migrations.dialect_helpers import is_postgresql, is_sqlite

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_024_enterprise_artifact_parity_columns"
down_revision: Union[str, Sequence[str], None] = "ent_023_enterprise_cas_columns"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TABLE = "enterprise_artifacts"
_FK_NAME = "fk_enterprise_artifacts_latest_deployment_id"
_IDX_NAME = "ix_enterprise_artifacts_latest_deployment_id"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists_pg(bind: sa.engine.Connection, table: str, column: str) -> bool:
    """Return True if *column* already exists on *table* (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name   = :tname
              AND column_name  = :cname
        """),
        {"tname": table, "cname": column},
    )
    return result.fetchone() is not None


def _constraint_exists_pg(
    bind: sa.engine.Connection, constraint: str, table: str
) -> bool:
    """Return True if *constraint* already exists on *table* (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :cname
              AND t.relname = :tname
        """),
        {"cname": constraint, "tname": table},
    )
    return result.fetchone() is not None


def _index_exists_pg(bind: sa.engine.Connection, index: str) -> bool:
    """Return True if *index* already exists (PostgreSQL)."""
    result = bind.execute(
        text("SELECT 1 FROM pg_indexes WHERE indexname = :i"),
        {"i": index},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add core_content and latest_deployment_id columns to enterprise_artifacts."""
    if is_sqlite():
        # enterprise_artifacts only exists on PostgreSQL — no-op on SQLite.
        log.info(
            "ent_024_enterprise_artifact_parity_columns: SQLite dialect detected; "
            "enterprise_artifacts is PostgreSQL-only. Skipping."
        )
        return

    if is_postgresql():
        log.info(
            "ent_024_enterprise_artifact_parity_columns upgrade: PostgreSQL dialect path."
        )
        _upgrade_postgresql(op.get_bind())
    else:
        log.warning(
            "ent_024_enterprise_artifact_parity_columns: unknown dialect; skipping."
        )


def _upgrade_postgresql(bind: sa.engine.Connection) -> None:
    # ------------------------------------------------------------------
    # 1. core_content — TEXT, nullable
    # ------------------------------------------------------------------
    if not _column_exists_pg(bind, _TABLE, "core_content"):
        op.add_column(
            _TABLE,
            sa.Column(
                "core_content",
                sa.Text(),
                nullable=True,
                comment=(
                    "Platform-agnostic content before assembly. "
                    "Mirrors artifacts.core_content from the local schema. "
                    "NULL until populated by the seed mirror or a write-through update."
                ),
            ),
        )
        log.info("ent_024: added %s.core_content.", _TABLE)
    else:
        log.info("ent_024: %s.core_content already exists; skipping.", _TABLE)

    # ------------------------------------------------------------------
    # 2. latest_deployment_id — UUID, nullable, FK -> enterprise_deployments.id
    # ------------------------------------------------------------------
    if not _column_exists_pg(bind, _TABLE, "latest_deployment_id"):
        op.add_column(
            _TABLE,
            sa.Column(
                "latest_deployment_id",
                postgresql.UUID(as_uuid=True),
                nullable=True,
                comment=(
                    "O(1) latest-deployment pointer for this artifact. "
                    "UUID FK to enterprise_deployments.id (SET NULL on delete). "
                    "Enterprise counterpart of artifacts.latest_deployment_id (which is "
                    "a String FK to project_version_deployments.id in the local schema)."
                ),
            ),
        )
        log.info("ent_024: added %s.latest_deployment_id.", _TABLE)
    else:
        log.info("ent_024: %s.latest_deployment_id already exists; skipping.", _TABLE)

    # ------------------------------------------------------------------
    # 2b. Repair: drop stray FK from 20260327_0002 that targets the wrong table.
    #
    # 20260327_0002_artifact_vcs_v2 adds `fk_enterprise_artifacts_latest_deployment_id`
    # to `enterprise_artifacts` but incorrectly points it at `project_version_deployments`
    # (the local/SQLite deployment table) instead of `enterprise_deployments`.  That
    # migration is already applied to production so we cannot modify it; we fix forward
    # here instead.
    #
    # Idempotency states:
    #   A. FK exists and targets `project_version_deployments` (or any wrong table)
    #      → drop it; the create block below will recreate it correctly.
    #   B. FK exists and already targets `enterprise_deployments`
    #      → no-op; it was already repaired (e.g. ent_024 ran before on this DB).
    #   C. FK does not exist at all
    #      → no-op; the create block below will create it fresh.
    # ------------------------------------------------------------------
    _repair_row = bind.execute(
        text("""
            SELECT c.relname AS referenced_table
            FROM pg_constraint con
            JOIN pg_class c ON c.oid = con.confrelid
            WHERE con.conname = :fk_name
              AND con.conrelid = 'enterprise_artifacts'::regclass
        """),
        {"fk_name": _FK_NAME},
    ).fetchone()

    if _repair_row is not None:
        _referenced_table = _repair_row[0]
        if _referenced_table != "enterprise_deployments":
            # State A: wrong target — drop so the create block recreates it correctly.
            op.drop_constraint(_FK_NAME, _TABLE, type_="foreignkey")
            log.info(
                "ent_024: dropped stray FK %s targeting wrong table (%s); will recreate",
                _FK_NAME,
                _referenced_table,
            )
        else:
            # State B: already correct — nothing to do.
            log.info(
                "ent_024: FK %s already targets enterprise_deployments; no repair needed.",
                _FK_NAME,
            )
    # State C: FK absent — repair_row is None; the create block below will add it.

    # ------------------------------------------------------------------
    # 3. FK constraint: latest_deployment_id -> enterprise_deployments.id
    # ------------------------------------------------------------------
    if not _constraint_exists_pg(bind, _FK_NAME, _TABLE):
        op.create_foreign_key(
            _FK_NAME,
            _TABLE,
            "enterprise_deployments",
            ["latest_deployment_id"],
            ["id"],
            ondelete="SET NULL",
        )
        log.info("ent_024: created FK %s.", _FK_NAME)
    else:
        log.info("ent_024: FK %s already exists; skipping.", _FK_NAME)

    # ------------------------------------------------------------------
    # 4. Index on latest_deployment_id for FK-lookup performance
    # ------------------------------------------------------------------
    if not _index_exists_pg(bind, _IDX_NAME):
        op.create_index(
            _IDX_NAME,
            _TABLE,
            ["latest_deployment_id"],
        )
        log.info("ent_024: created index %s.", _IDX_NAME)
    else:
        log.info("ent_024: index %s already exists; skipping.", _IDX_NAME)


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove core_content and latest_deployment_id from enterprise_artifacts."""
    if is_sqlite():
        # enterprise_artifacts only exists on PostgreSQL — no-op on SQLite.
        log.info(
            "ent_024_enterprise_artifact_parity_columns downgrade: SQLite dialect; "
            "no enterprise_artifacts table to revert. Skipping."
        )
        return

    if is_postgresql():
        log.info(
            "ent_024_enterprise_artifact_parity_columns downgrade: PostgreSQL dialect path."
        )
        _downgrade_postgresql(op.get_bind())
    else:
        log.warning(
            "ent_024_enterprise_artifact_parity_columns downgrade: unknown dialect; skipping."
        )


def _downgrade_postgresql(bind: sa.engine.Connection) -> None:
    # Drop index first (before the FK constraint or column)
    if _index_exists_pg(bind, _IDX_NAME):
        op.drop_index(_IDX_NAME, table_name=_TABLE)
        log.info("ent_024 downgrade: dropped index %s.", _IDX_NAME)

    # Drop FK constraint before dropping the column.
    # NOTE: We do NOT restore the original FK from 20260327_0002 that pointed at
    # `project_version_deployments` — that was a bug, not the intended state.
    # After downgrade the column is removed entirely, so no FK is needed.
    if _constraint_exists_pg(bind, _FK_NAME, _TABLE):
        op.drop_constraint(_FK_NAME, _TABLE, type_="foreignkey")
        log.info("ent_024 downgrade: dropped FK %s.", _FK_NAME)

    # Drop latest_deployment_id
    if _column_exists_pg(bind, _TABLE, "latest_deployment_id"):
        op.drop_column(_TABLE, "latest_deployment_id")
        log.info("ent_024 downgrade: dropped %s.latest_deployment_id.", _TABLE)

    # Drop core_content
    if _column_exists_pg(bind, _TABLE, "core_content"):
        op.drop_column(_TABLE, "core_content")
        log.info("ent_024 downgrade: dropped %s.core_content.", _TABLE)
