"""add is_ghost column to artifact_versions

Revision ID: a789b1d5a033
Revises: 20260327_0002_artifact_vcs_v2
Create Date: 2026-03-28 13:35:24.144818+00:00

Adds ``is_ghost`` boolean column to ``artifact_versions``.  Ghost rows
represent upstream GitHub changes that have not yet been pulled into the
local collection; they are inserted by ``GhostVersionDetector`` with
``change_origin='github_update'`` and ``is_ghost=True``.

The column is nullable with a server-side default of ``0`` (False) for
backward compatibility with rows created before this migration.
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite

# revision identifiers, used by Alembic.
revision: str = "a789b1d5a033"
down_revision: Union[str, None] = "20260327_0002_artifact_vcs_v2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    return column in {col["name"] for col in insp.get_columns(table)}


def upgrade() -> None:
    """Add is_ghost column to artifact_versions table."""
    if _column_exists("artifact_versions", "is_ghost"):
        return
    op.add_column(
        "artifact_versions",
        sa.Column(
            "is_ghost",
            sa.Boolean(),
            nullable=True,
            server_default="0",
            comment=(
                "True when this version represents an upstream GitHub change "
                "not yet pulled into the collection (ghost version)."
            ),
        ),
    )


def downgrade() -> None:
    """Remove is_ghost column from artifact_versions table."""
    if is_sqlite():
        op.execute(text("PRAGMA foreign_keys = OFF"))
        try:
            with op.batch_alter_table("artifact_versions", schema=None) as batch_op:
                batch_op.drop_column("is_ghost")
        finally:
            op.execute(text("PRAGMA foreign_keys = ON"))
    else:
        op.drop_column("artifact_versions", "is_ghost")
