"""Add sync_capture_config table for per-scope sync-capture overrides (SYNC-5.2).

Revision ID: 20260401_0003_add_sync_capture_config
Revises: 20260401_0001_add_sync_debounce_entries,
         20260401_0002_add_auto_capture_change_origin
Create Date: 2026-04-01 00:03:00.000000+00:00

Background
----------
Introduces the ``sync_capture_config`` table to support enterprise-level
configuration overrides for the Sync-as-Version-Capture (SaVC) subsystem.

Admins can configure sync capture settings per scope:
- ``global``: fallback defaults (one row, ``scope_id=NULL``)
- ``tier``:    per-tier overrides (e.g. ``scope_id='enterprise'``)
- ``project``: per-project overrides (``scope_id=<project_id>``)

Resolution uses the most-specific matching scope: project > tier > global.

See SYNC-5.2 in the dvcs-unified-sync feature plan.

Changes
-------
1. New table ``sync_capture_config``:
   - ``id``                    (INTEGER PK, autoincrement)
   - ``scope``                 (TEXT, NOT NULL)    — global | tier | project
   - ``scope_id``              (TEXT, NULL)        — tier name or project ID
   - ``quiet_window_seconds``  (INTEGER, NOT NULL) — default 30
   - ``auto_scan_enabled``     (BOOLEAN, NOT NULL) — default 1 (true)
   - ``sync_capture_enabled``  (BOOLEAN, NOT NULL) — default 1 (true)
   - ``max_captures_per_hour`` (INTEGER, NOT NULL) — default 10
   - ``created_at``            (DATETIME, NOT NULL)
   - ``updated_at``            (DATETIME, NOT NULL)

2. UNIQUE constraint on ``(scope, scope_id)``.

3. CHECK constraints:
   - ``ck_sync_capture_config_scope``          — scope domain guard.
   - ``ck_sync_capture_config_scope_id_null``  — global rows must have
     NULL scope_id; tier/project rows must have non-NULL scope_id.

4. Indexes:
   - ``idx_sync_capture_config_scope``    — filtered lookups by scope.
   - ``idx_sync_capture_config_scope_id`` — scope_id resolution queries.

Dialect Strategy
----------------
Both SQLite (local edition) and PostgreSQL (enterprise edition) are supported
via the standard ``sa.inspect()`` idempotency guard.  Inline
``sa.UniqueConstraint()`` is used (not ``op.create_unique_constraint()``)
because SQLite does not support adding unique constraints after table creation.

Downgrade
---------
Drops indexes first (via raw SQL for SQLite compat), then drops the table.
Idempotent: silently skips if the table does not exist.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260401_0003_add_sync_capture_config"
down_revision: Union[str, tuple[str, ...], None] = (
    "20260401_0001_add_sync_debounce_entries",
    "20260401_0002_add_auto_capture_change_origin",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

logger = logging.getLogger(__name__)

_TABLE = "sync_capture_config"


def upgrade() -> None:
    """Create sync_capture_config table with constraints and indexes."""
    logger.info("SYNC-5.2 upgrade: creating %s table", _TABLE)

    conn = op.get_bind()
    inspector = sa.inspect(conn)
    if _TABLE in inspector.get_table_names():
        logger.info("Table %s already exists — skipping creation", _TABLE)
        return

    op.create_table(
        _TABLE,
        # ----------------------------------------------------------------
        # Primary key
        # ----------------------------------------------------------------
        sa.Column(
            "id",
            sa.Integer(),
            primary_key=True,
            autoincrement=True,
            comment="Surrogate integer primary key",
        ),
        # ----------------------------------------------------------------
        # Scope discriminators
        # ----------------------------------------------------------------
        sa.Column(
            "scope",
            sa.String(),
            nullable=False,
            comment="Scope level: global | tier | project",
        ),
        sa.Column(
            "scope_id",
            sa.String(),
            nullable=True,
            comment=(
                "Discriminator within scope: tier name or project ID. "
                "NULL for global scope."
            ),
        ),
        # ----------------------------------------------------------------
        # Configuration knobs
        # ----------------------------------------------------------------
        sa.Column(
            "quiet_window_seconds",
            sa.Integer(),
            nullable=False,
            server_default="30",
            comment="Debounce quiet-window duration in seconds",
        ),
        sa.Column(
            "auto_scan_enabled",
            sa.Boolean(),
            nullable=False,
            server_default="1",
            comment="Whether background auto-scan is active for this scope",
        ),
        sa.Column(
            "sync_capture_enabled",
            sa.Boolean(),
            nullable=False,
            server_default="1",
            comment="Master switch for sync capture within this scope",
        ),
        sa.Column(
            "max_captures_per_hour",
            sa.Integer(),
            nullable=False,
            server_default="10",
            comment="Max version captures permitted per hour within this scope",
        ),
        # ----------------------------------------------------------------
        # Timestamps
        # ----------------------------------------------------------------
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
            comment="UTC timestamp when this config row was inserted",
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
            comment="UTC timestamp of the most recent update",
        ),
        # ----------------------------------------------------------------
        # Unique constraint — inline for SQLite compatibility
        # ----------------------------------------------------------------
        sa.UniqueConstraint(
            "scope",
            "scope_id",
            name="uq_sync_capture_config_scope",
        ),
        # ----------------------------------------------------------------
        # CHECK constraints
        # ----------------------------------------------------------------
        sa.CheckConstraint(
            "scope IN ('global', 'tier', 'project')",
            name="ck_sync_capture_config_scope",
        ),
        sa.CheckConstraint(
            "(scope = 'global' AND scope_id IS NULL) "
            "OR (scope != 'global' AND scope_id IS NOT NULL)",
            name="ck_sync_capture_config_scope_id_null",
        ),
    )

    logger.info("SYNC-5.2: creating indexes on %s", _TABLE)

    # Filtered lookups by scope level
    op.create_index(
        "idx_sync_capture_config_scope",
        _TABLE,
        ["scope"],
    )

    # Scope-id resolution queries (tier name / project ID lookups)
    op.create_index(
        "idx_sync_capture_config_scope_id",
        _TABLE,
        ["scope_id"],
    )

    logger.info("SYNC-5.2 upgrade: %s table created successfully", _TABLE)


def downgrade() -> None:
    """Drop sync_capture_config table and associated indexes."""
    logger.info("SYNC-5.2 downgrade: removing %s table", _TABLE)

    conn = op.get_bind()
    inspector = sa.inspect(conn)
    if _TABLE not in inspector.get_table_names():
        logger.info("Table %s does not exist — skipping removal", _TABLE)
        return

    # Drop indexes via raw SQL (belt-and-suspenders; handles SQLite + PostgreSQL)
    for idx in (
        "idx_sync_capture_config_scope_id",
        "idx_sync_capture_config_scope",
    ):
        try:
            conn.execute(sa.text(f"DROP INDEX IF EXISTS {idx}"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not drop index %s: %s", idx, exc)

    op.drop_table(_TABLE)

    logger.info("SYNC-5.2 downgrade: %s table removed", _TABLE)
