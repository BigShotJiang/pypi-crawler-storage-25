"""Add shadowed_from_enterprise_id nullable column to cached_artifacts table.

Revision ID: 20260326_0003_add_shadowed_from_enterprise_id
Revises: 20260326_0002_add_global_collection_fields
Create Date: 2026-03-26 00:03:00.000000+00:00

Background
----------
Enterprise Governance 3-Tier feature (EG-4.5).  Shadow tracking for enterprise
artifacts with ``enforce_override=False``.

When an enterprise artifact has ``enforce_override=False``, users may create a
"shadow" — a local customization that preserves a link back to the enterprise
original.  During sync:

  * Shadow exists   → standard three-way merge (``resolve_sync_behavior`` returns "merge")
  * No shadow, no override → inherit, allow shadowing later ("inherit")
  * No shadow, enforce_override=True → read-only, no local edits allowed ("read_only")

Column specification
~~~~~~~~~~~~~~~~~~~~
* Name:            ``shadowed_from_enterprise_id``
* Table:           ``cached_artifacts``  (local SQLite cache)
* Type:            VARCHAR(64)  (nullable)
* Default:         NULL  (not a shadow by default)
* Server default:  NULL
* FK constraint:   None  (enterprise artifact may live in a separate database)
* Index:           Yes — ``ix_cached_artifacts_shadow_enterprise_id`` for efficient
                   shadow lookups (find all local shadows of a given enterprise artifact)

No FK constraint rationale
--------------------------
The enterprise artifact ID is stored as a plain string rather than a FK because
the enterprise source may reside in a different database (PostgreSQL for enterprise,
SQLite for local).  Application-layer validation in ``ShadowTracker`` enforces
referential integrity at the service boundary.

Backward Compatibility
----------------------
All existing rows receive NULL for this column, which is the correct default
(no shadow relationship).  No data migration is required.

Rollback
--------
``downgrade()`` drops the index and column.  SQLite uses ``batch_alter_table``
for the column drop for compatibility with SQLite versions below 3.35.

Schema reference
----------------
skillmeat/cache/models.py                        (Artifact / cached_artifacts)
skillmeat/core/shadow_tracker.py                  (ShadowTracker, ShadowInfo)
.claude/progress/enterprise-governance-3-tier/
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260326_0003_add_shadowed_from_enterprise_id"
down_revision: Union[str, None] = "20260326_0002_add_global_collection_fields"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TABLE = "cached_artifacts"
_COLUMN = "shadowed_from_enterprise_id"
_INDEX = "ix_cached_artifacts_shadow_enterprise_id"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _table_exists(bind: sa.engine.Connection, table_name: str) -> bool:
    """Return True if *table_name* exists in the current database."""
    insp = sa.inspect(bind)
    return table_name in insp.get_table_names()


def _column_exists(
    bind: sa.engine.Connection, table_name: str, column_name: str
) -> bool:
    """Return True if *column_name* already exists on *table_name*."""
    insp = sa.inspect(bind)
    columns = [col["name"] for col in insp.get_columns(table_name)]
    return column_name in columns


def _index_exists(bind: sa.engine.Connection, table_name: str, index_name: str) -> bool:
    """Return True if *index_name* already exists on *table_name*."""
    insp = sa.inspect(bind)
    indexes = [idx["name"] for idx in insp.get_indexes(table_name)]
    return index_name in indexes


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add ``shadowed_from_enterprise_id`` column and index to ``cached_artifacts``."""
    bind = op.get_bind()

    if is_sqlite():
        log.info(
            "add_shadowed_from_enterprise_id upgrade: running SQLite dialect path."
        )
        _add_column_and_index_sqlite(bind)
    elif is_postgresql():
        if not _table_exists(bind, _TABLE):
            log.info(
                "add_shadowed_from_enterprise_id upgrade: table %s does not exist "
                "on PostgreSQL (enterprise schema); skipping.",
                _TABLE,
            )
            return
        log.info(
            "add_shadowed_from_enterprise_id upgrade: running PostgreSQL dialect path."
        )
        _add_column_and_index_postgresql(bind)
    else:
        log.warning(
            "add_shadowed_from_enterprise_id upgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _add_column_and_index_sqlite(bind: sa.engine.Connection) -> None:
    """Add column and index on SQLite."""
    if not _column_exists(bind, _TABLE, _COLUMN):
        log.info(
            "add_shadowed_from_enterprise_id (SQLite): adding %s.%s.",
            _TABLE,
            _COLUMN,
        )
        op.add_column(
            _TABLE,
            sa.Column(
                _COLUMN,
                sa.String(64),
                nullable=True,
                comment=(
                    "ID of the enterprise artifact this local artifact shadows. "
                    "NULL means no shadow relationship."
                ),
            ),
        )
    else:
        log.info(
            "add_shadowed_from_enterprise_id (SQLite): %s.%s already exists; skipping column.",
            _TABLE,
            _COLUMN,
        )

    if not _index_exists(bind, _TABLE, _INDEX):
        log.info(
            "add_shadowed_from_enterprise_id (SQLite): creating index %s.",
            _INDEX,
        )
        op.create_index(
            _INDEX,
            _TABLE,
            [_COLUMN],
        )
    else:
        log.info(
            "add_shadowed_from_enterprise_id (SQLite): index %s already exists; skipping.",
            _INDEX,
        )


def _add_column_and_index_postgresql(bind: sa.engine.Connection) -> None:
    """Add column and index on PostgreSQL."""
    if not _column_exists(bind, _TABLE, _COLUMN):
        log.info(
            "add_shadowed_from_enterprise_id (PostgreSQL): adding %s.%s.",
            _TABLE,
            _COLUMN,
        )
        op.add_column(
            _TABLE,
            sa.Column(
                _COLUMN,
                sa.String(64),
                nullable=True,
                comment=(
                    "ID of the enterprise artifact this local artifact shadows. "
                    "NULL means no shadow relationship."
                ),
            ),
        )
    else:
        log.info(
            "add_shadowed_from_enterprise_id (PostgreSQL): %s.%s already exists; skipping column.",
            _TABLE,
            _COLUMN,
        )

    if not _index_exists(bind, _TABLE, _INDEX):
        log.info(
            "add_shadowed_from_enterprise_id (PostgreSQL): creating index %s.",
            _INDEX,
        )
        op.create_index(
            _INDEX,
            _TABLE,
            [_COLUMN],
        )
    else:
        log.info(
            "add_shadowed_from_enterprise_id (PostgreSQL): index %s already exists; skipping.",
            _INDEX,
        )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove ``shadowed_from_enterprise_id`` column and index from ``cached_artifacts``."""
    bind = op.get_bind()

    if is_sqlite():
        log.info(
            "add_shadowed_from_enterprise_id downgrade: running SQLite dialect path."
        )
        _drop_index_and_column_sqlite(bind)
    elif is_postgresql():
        if not _table_exists(bind, _TABLE):
            log.info(
                "add_shadowed_from_enterprise_id downgrade: table %s does not exist; skipping.",
                _TABLE,
            )
            return
        log.info(
            "add_shadowed_from_enterprise_id downgrade: running PostgreSQL dialect path."
        )
        _drop_index_and_column_postgresql(bind)
    else:
        log.warning(
            "add_shadowed_from_enterprise_id downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _drop_index_and_column_sqlite(bind: sa.engine.Connection) -> None:
    """Drop index and column on SQLite using batch_alter_table for compatibility."""
    if _index_exists(bind, _TABLE, _INDEX):
        log.info(
            "add_shadowed_from_enterprise_id (SQLite): dropping index %s.",
            _INDEX,
        )
        op.drop_index(_INDEX, table_name=_TABLE)
    else:
        log.info(
            "add_shadowed_from_enterprise_id (SQLite): index %s not found; skipping drop.",
            _INDEX,
        )

    if _column_exists(bind, _TABLE, _COLUMN):
        log.info(
            "add_shadowed_from_enterprise_id (SQLite): dropping column %s.%s via batch.",
            _TABLE,
            _COLUMN,
        )
        with op.batch_alter_table(_TABLE) as batch_op:
            batch_op.drop_column(_COLUMN)
    else:
        log.info(
            "add_shadowed_from_enterprise_id (SQLite): %s.%s not found; skipping drop.",
            _TABLE,
            _COLUMN,
        )


def _drop_index_and_column_postgresql(bind: sa.engine.Connection) -> None:
    """Drop index and column on PostgreSQL."""
    if _index_exists(bind, _TABLE, _INDEX):
        log.info(
            "add_shadowed_from_enterprise_id (PostgreSQL): dropping index %s.",
            _INDEX,
        )
        op.drop_index(_INDEX, table_name=_TABLE)
    else:
        log.info(
            "add_shadowed_from_enterprise_id (PostgreSQL): index %s not found; skipping drop.",
            _INDEX,
        )

    if _column_exists(bind, _TABLE, _COLUMN):
        log.info(
            "add_shadowed_from_enterprise_id (PostgreSQL): dropping column %s.%s.",
            _TABLE,
            _COLUMN,
        )
        op.drop_column(_TABLE, _COLUMN)
    else:
        log.info(
            "add_shadowed_from_enterprise_id (PostgreSQL): %s.%s not found; skipping drop.",
            _TABLE,
            _COLUMN,
        )
