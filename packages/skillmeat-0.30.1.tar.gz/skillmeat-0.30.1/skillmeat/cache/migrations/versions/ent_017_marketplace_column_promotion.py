"""Promote marketplace stub properties to real mapped columns.

Revision ID: ent_017_marketplace_column_promotion
Revises: ent_016_enterprise_critical_domains
Create Date: 2026-04-02 00:00:00.000000+00:00

Background
----------
EGCF-4.2 promoted seven stub properties on two enterprise marketplace models
to proper ``mapped_column`` fields.  This migration adds the corresponding
ALTER TABLE statements so that the PostgreSQL schema matches the ORM layer.

Tables modified
---------------
enterprise_marketplace_sources (1 column):
    - supports_publish  — whether this source supports artifact publishing

enterprise_marketplace_catalog_entries (6 columns):
    - description  — human-readable description of the catalog entry
    - publisher    — name/identifier of the publishing organisation
    - bundle_url   — download URL for the artifact bundle
    - signature    — cryptographic signature string for integrity verification
    - rating       — floating-point community rating (0.0 – 5.0 scale)
    - price        — optional monetary price (NUMERIC 10,2; NULL = free)

Design notes
------------
- All new columns are added with ``nullable=True`` where data may be absent, or
  with a ``server_default`` where a NOT NULL constraint is required (boolean).
- Downgrade drops the columns in reverse promotion order.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_017_marketplace_column_promotion"
down_revision: Union[str, Sequence[str], None] = "ent_016_enterprise_critical_domains"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    if not _is_postgresql():
        log.info(
            "ent_017: skipping — enterprise marketplace migrations only run on PostgreSQL"
        )
        return

    # -- enterprise_marketplace_sources ----------------------------------
    op.add_column(
        "enterprise_marketplace_sources",
        sa.Column(
            "supports_publish",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("false"),
        ),
    )

    # -- enterprise_marketplace_catalog_entries --------------------------
    op.add_column(
        "enterprise_marketplace_catalog_entries",
        sa.Column("description", sa.Text(), nullable=True),
    )
    op.add_column(
        "enterprise_marketplace_catalog_entries",
        sa.Column("publisher", sa.Text(), nullable=True),
    )
    op.add_column(
        "enterprise_marketplace_catalog_entries",
        sa.Column("bundle_url", sa.Text(), nullable=True),
    )
    op.add_column(
        "enterprise_marketplace_catalog_entries",
        sa.Column("signature", sa.Text(), nullable=True),
    )
    op.add_column(
        "enterprise_marketplace_catalog_entries",
        sa.Column("rating", sa.Float(), nullable=True),
    )
    op.add_column(
        "enterprise_marketplace_catalog_entries",
        sa.Column("price", sa.Numeric(10, 2), nullable=True),
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    if not _is_postgresql():
        log.info(
            "ent_017: skipping downgrade — enterprise marketplace migrations only run on PostgreSQL"
        )
        return

    # Drop in reverse promotion order
    op.drop_column("enterprise_marketplace_catalog_entries", "price")
    op.drop_column("enterprise_marketplace_catalog_entries", "rating")
    op.drop_column("enterprise_marketplace_catalog_entries", "signature")
    op.drop_column("enterprise_marketplace_catalog_entries", "bundle_url")
    op.drop_column("enterprise_marketplace_catalog_entries", "publisher")
    op.drop_column("enterprise_marketplace_catalog_entries", "description")

    op.drop_column("enterprise_marketplace_sources", "supports_publish")
