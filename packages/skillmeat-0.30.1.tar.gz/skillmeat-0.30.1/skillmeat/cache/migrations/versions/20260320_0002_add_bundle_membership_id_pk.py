"""Add standalone ``id`` primary key to bundle_memberships (replaces composite PK).

Revision ID: 20260320_0002_add_bundle_membership_id_pk
Revises: 20260320_0001_add_polymorphic_bundle_membership
Create Date: 2026-03-20 00:02:00.000000+00:00

Background
----------
The ``BundleMembership`` ORM model was updated to use a standalone UUID ``id``
column as its sole primary key.  The previous composite PK
``(bundle_id, artifact_uuid)`` cannot accommodate NULL values in
``artifact_uuid``, which the polymorphic membership design requires for
``member_type='context_entity'`` rows.

At the time the polymorphic columns were added
(``20260320_0001_add_polymorphic_bundle_membership``), the composite PK was
left in place.  This migration completes the transition.

Changes Applied
---------------
1. Add ``id`` column (``String``, not-null) — populated with ``uuid4().hex``
   values for all existing rows before the PK switch.
2. Recreate the table (required by SQLite — SQLite cannot drop/add PRIMARY KEY
   constraints via ``ALTER TABLE``) with:
   - ``id`` as the sole ``PRIMARY KEY``
   - ``artifact_uuid`` changed from ``PRIMARY KEY, NOT NULL`` to ``NOT NULL=False``
     (nullable), matching the polymorphic design intent and the ORM model
3. Re-create the four membership indexes that were defined by the ORM but only
   partially present from previous migrations:
   - ``idx_bundle_memberships_bundle_id`` (already existed — recreated)
   - ``idx_bundle_memberships_artifact_uuid`` (already existed — recreated)
   - ``idx_bundle_memberships_context_entity_id`` (new — added by this migration)
   - ``idx_bundle_memberships_member_type`` (new — added by this migration)

SQLite Strategy
---------------
SQLite does not support ``ALTER TABLE ... DROP CONSTRAINT`` or ``ALTER TABLE
... ADD PRIMARY KEY``.  Alembic's ``batch_alter_table(recreate="always")``
performs a transparent full-table rebuild:
  1. Create a new table with the target schema.
  2. Copy all rows.
  3. Drop the old table.
  4. Rename the new table.

This is safe for both SQLite (local edition) and PostgreSQL (enterprise
edition).

Downgrade
---------
Reverses the PK swap: recreates the table with the original composite PK
``(bundle_id, artifact_uuid)`` and drops the ``id`` column.  Rows that have
a NULL ``artifact_uuid`` (context-entity members introduced after the
polymorphic migration) **cannot be round-tripped** through the composite PK
because ``artifact_uuid`` would violate NOT NULL — those rows are dropped
during downgrade.  This is acceptable: downgrading past the polymorphic
migration itself would also remove context-entity support.

Schema reference
----------------
skillmeat/cache/models.py  (BundleMembership)
"""

from __future__ import annotations

import uuid
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260320_0002_add_bundle_membership_id_pk"
down_revision: Union[str, None] = "20260320_0001_add_polymorphic_bundle_membership"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Swap composite PK (bundle_id, artifact_uuid) for standalone id PK."""

    conn = op.get_bind()

    # ------------------------------------------------------------------
    # Step 1: Populate a temporary id value for every existing row.
    #
    # We cannot add a PRIMARY KEY column directly via ALTER TABLE in
    # SQLite (or safely in PostgreSQL without careful sequencing).
    # Instead we use Alembic batch mode to rebuild the table.  But first
    # we need id values for existing rows — we compute them here in
    # Python and write them into a throwaway TEXT column so they survive
    # the copy during batch recreation.
    #
    # The throwaway column (_id_tmp) is included in the batch schema as
    # a plain nullable TEXT column; after the batch, we reference it as
    # the source for the real ``id`` PK.  Alembic's batch copy preserves
    # all columns listed in the new table definition, so we define ``id``
    # directly in the new schema and rely on the fact that for the INSERT
    # ... SELECT copy Alembic uses column names — meaning we need ``id``
    # to exist in the source table before the copy.
    #
    # Simplest safe approach for both dialects:
    #   a. Add a nullable TEXT column ``id`` via add_column.
    #   b. Populate it for all existing rows.
    #   c. Recreate the table via batch_alter_table with ``id`` as PK.
    # ------------------------------------------------------------------

    # (a) Add nullable ``id`` column to the live table.
    op.add_column(
        "bundle_memberships",
        sa.Column("id", sa.String(), nullable=True),
    )

    # (b) Populate ``id`` for all existing rows.
    rows = conn.execute(
        sa.text("SELECT bundle_id, artifact_uuid FROM bundle_memberships")
    ).fetchall()

    for bundle_id, artifact_uuid in rows:
        new_id = uuid.uuid4().hex
        conn.execute(
            sa.text(
                "UPDATE bundle_memberships"
                " SET id = :new_id"
                " WHERE bundle_id = :bundle_id"
                "   AND artifact_uuid = :artifact_uuid"
            ),
            {"new_id": new_id, "bundle_id": bundle_id, "artifact_uuid": artifact_uuid},
        )

    # (c) Recreate the table with ``id`` as sole PRIMARY KEY and
    #     ``artifact_uuid`` nullable.
    with op.batch_alter_table("bundle_memberships", recreate="always") as batch_op:
        # Define the target schema.  batch_alter_table copies all columns
        # present in the new definition from the source table by name.
        batch_op.alter_column("id", existing_type=sa.String(), nullable=False)

        # Make artifact_uuid nullable (was NOT NULL / part of composite PK)
        batch_op.alter_column(
            "artifact_uuid",
            existing_type=sa.String(),
            nullable=True,
        )

        # Drop the old composite primary key.  In batch+recreate mode
        # Alembic rebuilds the full CREATE TABLE from the reflected
        # schema plus our alterations, so explicitly dropping the old PK
        # and creating the new one via the column definition is the
        # correct approach.  We express this by creating a new PK
        # constraint naming only ``id``.
        batch_op.create_primary_key("pk_bundle_memberships", ["id"])

    # ------------------------------------------------------------------
    # Step 2: Ensure all four indexes exist (two were created by the
    #         original migration; two are new from the polymorphic model).
    # ------------------------------------------------------------------

    # Drop pre-existing indexes before recreating so we don't error on
    # "already exists" in databases that were fully migrated from scratch.
    _drop_index_if_exists(conn, "idx_bundle_memberships_bundle_id")
    _drop_index_if_exists(conn, "idx_bundle_memberships_artifact_uuid")

    op.create_index(
        "idx_bundle_memberships_bundle_id",
        "bundle_memberships",
        ["bundle_id"],
    )
    op.create_index(
        "idx_bundle_memberships_artifact_uuid",
        "bundle_memberships",
        ["artifact_uuid"],
    )
    op.create_index(
        "idx_bundle_memberships_context_entity_id",
        "bundle_memberships",
        ["context_entity_id"],
    )
    op.create_index(
        "idx_bundle_memberships_member_type",
        "bundle_memberships",
        ["member_type"],
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Revert to composite PK (bundle_id, artifact_uuid); drop id column.

    WARNING: rows where artifact_uuid IS NULL (context-entity members) cannot
    be preserved under the composite PK constraint and are dropped silently.
    This mirrors the semantics of downgrading the polymorphic migration itself.
    """

    conn = op.get_bind()

    # Remove rows that cannot satisfy the old NOT NULL artifact_uuid constraint.
    conn.execute(sa.text("DELETE FROM bundle_memberships WHERE artifact_uuid IS NULL"))

    # Drop all four indexes; we will recreate only the two that existed before.
    _drop_index_if_exists(conn, "idx_bundle_memberships_member_type")
    _drop_index_if_exists(conn, "idx_bundle_memberships_context_entity_id")
    _drop_index_if_exists(conn, "idx_bundle_memberships_artifact_uuid")
    _drop_index_if_exists(conn, "idx_bundle_memberships_bundle_id")

    # Recreate the table with the original composite PK and remove ``id``.
    with op.batch_alter_table("bundle_memberships", recreate="always") as batch_op:
        # Restore composite primary key.
        batch_op.create_primary_key(
            "pk_bundle_memberships_composite", ["bundle_id", "artifact_uuid"]
        )
        # Make artifact_uuid NOT NULL again (was nullable after upgrade).
        batch_op.alter_column(
            "artifact_uuid",
            existing_type=sa.String(),
            nullable=False,
        )
        # Drop the standalone id column.
        batch_op.drop_column("id")

    # Restore the two original indexes.
    op.create_index(
        "idx_bundle_memberships_bundle_id",
        "bundle_memberships",
        ["bundle_id"],
    )
    op.create_index(
        "idx_bundle_memberships_artifact_uuid",
        "bundle_memberships",
        ["artifact_uuid"],
    )


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def _drop_index_if_exists(conn: sa.engine.Connection, index_name: str) -> None:
    """Drop an index by name if it exists; no-op otherwise.

    SQLite does not support ``IF EXISTS`` on ``DROP INDEX`` in all versions,
    so we check the sqlite_master / pg_indexes catalog first.
    """
    dialect = conn.dialect.name
    if dialect == "sqlite":
        exists = conn.execute(
            sa.text("SELECT 1 FROM sqlite_master" " WHERE type='index' AND name=:name"),
            {"name": index_name},
        ).fetchone()
        if exists:
            conn.execute(sa.text(f"DROP INDEX {index_name}"))
    else:
        # PostgreSQL supports DROP INDEX IF EXISTS
        conn.execute(sa.text(f"DROP INDEX IF EXISTS {index_name}"))
