"""Admin sync prerequisite: sync_status column, backfill, CHECK constraint, and indexes.

Revision ID: ent_022_admin_sync_prereq
Revises: ent_021_enterprise_access_token_credentials
Create Date: 2026-04-04 00:00:00.000000+00:00

Background
----------
PREREQ-3.1 / PREREQ-3.2 — Prerequisites for Phase 3 of the Enterprise Admin
Sync dashboard.

PREREQ-3.1: ``sync_status`` stored column on ``artifact_version_scopes``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
The sync state was previously derived at query time from the combination of
``head_hash``, ``baseline_hash``, and ``is_diverged``.  Storing it as a
denormalised column enables O(1) GROUP BY aggregation on the admin dashboard
without joining or computing state per row.

Column definition::

    sync_status  VARCHAR(20)  NOT NULL  DEFAULT 'pending'
    CHECK sync_status IN ('current', 'outdated', 'diverged', 'pending')

Backfill logic for existing rows::

    is_diverged = TRUE              → 'diverged'
    baseline_hash IS NULL           → 'pending'
    head_hash = baseline_hash       → 'current'
    head_hash != baseline_hash      → 'outdated'

PREREQ-3.2: Composite indexes for aggregation queries
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Three new covering indexes:

1. ``idx_version_scopes_tenant_owner``
   Columns: ``(tenant_id, owner_type, owner_id)``
   Use:     GROUP BY aggregation — "how many artifacts does each team own?"

2. ``idx_version_scopes_tenant_owner_status``
   Columns: ``(tenant_id, owner_type, sync_status)``
   Use:     Primary covering index for the admin sync dashboard summary query.

3. ``idx_enterprise_ahe_tenant_created``
   Columns: ``(tenant_id, created_at DESC)``
   Table:   ``enterprise_artifact_history_events``
   Use:     Operations log pagination — ordered time-series queries per tenant.

PostgreSQL indexes are created CONCURRENTLY to avoid table locks.  SQLite
receives plain non-concurrent indexes (``CREATE INDEX IF NOT EXISTS``).

Dialect Strategy
----------------
Both upgrade() and downgrade() detect the dialect at runtime via
``op.get_bind().dialect.name``.  Behaviour that is PostgreSQL-specific (CHECK
constraints, CONCURRENT indexes) is guarded accordingly so that the migration
can run safely against a SQLite test database.

Downgrade
---------
Provided for development rollback only.  Production deployments are
forward-only for enterprise migrations.

1. Drop ``idx_enterprise_ahe_tenant_created``.
2. Drop ``idx_version_scopes_tenant_owner_status``.
3. Drop ``idx_version_scopes_tenant_owner``.
4. Drop CHECK constraint ``chk_sync_status`` (PostgreSQL only).
5. Drop ``sync_status`` column.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

from skillmeat.cache.migrations.dialect_helpers import is_sqlite

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_022_admin_sync_prereq"
down_revision: Union[str, Sequence[str], None] = (
    "ent_021_enterprise_access_token_credentials"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Table / column names
# ---------------------------------------------------------------------------

_SCOPES_TABLE = "artifact_version_scopes"
_HISTORY_TABLE = "enterprise_artifact_history_events"

# ---------------------------------------------------------------------------
# Dialect helpers
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when executing against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# PREREQ-3.1 helpers
# ---------------------------------------------------------------------------


def _add_sync_status_column() -> None:
    """Add sync_status VARCHAR(20) NOT NULL DEFAULT 'pending' to artifact_version_scopes."""
    op.add_column(
        _SCOPES_TABLE,
        sa.Column(
            "sync_status",
            sa.String(20),
            nullable=False,
            server_default=sa.text("'pending'"),
            comment=(
                "Denormalised sync state: 'current', 'outdated', 'diverged', or 'pending'. "
                "Maintained by the service layer on every scope mutation."
            ),
        ),
    )
    log.info("upgrade: added sync_status column to %s.", _SCOPES_TABLE)


def _backfill_sync_status() -> None:
    """Populate sync_status for all pre-existing rows using derivation logic.

    Backfill priority (applied in a single UPDATE CASE expression):
        is_diverged = TRUE              → 'diverged'
        baseline_hash IS NULL           → 'pending'
        head_hash = baseline_hash       → 'current'
        head_hash != baseline_hash      → 'outdated'
    """
    conn = op.get_bind()
    conn.execute(sa.text("""
            UPDATE artifact_version_scopes
            SET sync_status = CASE
                WHEN is_diverged = TRUE                   THEN 'diverged'
                WHEN baseline_hash IS NULL                THEN 'pending'
                WHEN head_hash = baseline_hash            THEN 'current'
                ELSE                                           'outdated'
            END
            """))
    log.info("upgrade: backfilled sync_status on existing rows in %s.", _SCOPES_TABLE)


def _add_sync_status_check_constraint() -> None:
    """Add CHECK constraint ensuring sync_status stays within the valid enum set.

    PostgreSQL supports ADD CONSTRAINT inline; SQLite's limited ALTER TABLE
    dialect does not support adding named CHECK constraints after table
    creation, so we skip this step on SQLite (the model-level constraint
    still documents intent for SQLite tests).
    """
    if not _is_postgresql():
        log.info(
            "upgrade: skipping chk_sync_status CHECK constraint on SQLite "
            "(dialect does not support post-creation named CHECK constraints)."
        )
        return

    op.create_check_constraint(
        "chk_sync_status",
        _SCOPES_TABLE,
        "sync_status IN ('current', 'outdated', 'diverged', 'pending')",
    )
    log.info("upgrade: added CHECK constraint chk_sync_status on %s.", _SCOPES_TABLE)


# ---------------------------------------------------------------------------
# PREREQ-3.2 helpers
# ---------------------------------------------------------------------------


def _create_scopes_indexes() -> None:
    """Create the two covering indexes on artifact_version_scopes.

    Uses CREATE INDEX IF NOT EXISTS for both PostgreSQL and SQLite.
    CONCURRENTLY was removed because Alembic runs migrations inside
    transaction blocks, and CONCURRENTLY cannot run in a transaction.
    """
    is_pg = _is_postgresql()

    # 1. (tenant_id, owner_type, owner_id) — GROUP BY aggregation
    if is_pg:
        op.execute(
            sa.text(
                "CREATE INDEX IF NOT EXISTS "
                "idx_version_scopes_tenant_owner "
                "ON artifact_version_scopes (tenant_id, owner_type, owner_id)"
            )
        )
    else:
        op.create_index(
            "idx_version_scopes_tenant_owner",
            _SCOPES_TABLE,
            ["tenant_id", "owner_type", "owner_id"],
            if_not_exists=True,
        )
    log.info("upgrade: created idx_version_scopes_tenant_owner.")

    # 2. (tenant_id, owner_type, sync_status) — primary dashboard covering index
    if is_pg:
        op.execute(
            sa.text(
                "CREATE INDEX IF NOT EXISTS "
                "idx_version_scopes_tenant_owner_status "
                "ON artifact_version_scopes (tenant_id, owner_type, sync_status)"
            )
        )
    else:
        op.create_index(
            "idx_version_scopes_tenant_owner_status",
            _SCOPES_TABLE,
            ["tenant_id", "owner_type", "sync_status"],
            if_not_exists=True,
        )
    log.info("upgrade: created idx_version_scopes_tenant_owner_status.")


def _create_history_index() -> None:
    """Create the (tenant_id, created_at DESC) index on enterprise_artifact_history_events.

    PostgreSQL: CREATE INDEX with explicit DESC sort order.
    SQLite:     plain CREATE INDEX IF NOT EXISTS (no DESC modifier in
                op.create_index — handled via raw DDL with IF NOT EXISTS).
    """
    is_pg = _is_postgresql()

    if is_pg:
        op.execute(
            sa.text(
                "CREATE INDEX IF NOT EXISTS "
                "idx_enterprise_ahe_tenant_created "
                "ON enterprise_artifact_history_events (tenant_id, created_at DESC)"
            )
        )
    else:
        # SQLite supports DESC key ordering in index DDL (available since 3.28),
        # but op.create_index() does not forward sort_order args.  Use raw DDL.
        op.execute(
            sa.text(
                "CREATE INDEX IF NOT EXISTS "
                "idx_enterprise_ahe_tenant_created "
                "ON enterprise_artifact_history_events (tenant_id, created_at DESC)"
            )
        )
    log.info("upgrade: created idx_enterprise_ahe_tenant_created.")


# ---------------------------------------------------------------------------
# Downgrade helpers
# ---------------------------------------------------------------------------


def _drop_history_index() -> None:
    if _is_postgresql():
        op.execute(sa.text("DROP INDEX IF EXISTS idx_enterprise_ahe_tenant_created"))
    else:
        op.drop_index(
            "idx_enterprise_ahe_tenant_created",
            table_name=_HISTORY_TABLE,
            if_exists=True,
        )
    log.info("downgrade: dropped idx_enterprise_ahe_tenant_created.")


def _drop_scopes_indexes() -> None:
    if _is_postgresql():
        op.execute(
            sa.text("DROP INDEX IF EXISTS idx_version_scopes_tenant_owner_status")
        )
        op.execute(sa.text("DROP INDEX IF EXISTS idx_version_scopes_tenant_owner"))
    else:
        op.drop_index(
            "idx_version_scopes_tenant_owner_status",
            table_name=_SCOPES_TABLE,
            if_exists=True,
        )
        op.drop_index(
            "idx_version_scopes_tenant_owner",
            table_name=_SCOPES_TABLE,
            if_exists=True,
        )
    log.info("downgrade: dropped scopes aggregation indexes.")


def _drop_sync_status_check_constraint() -> None:
    if not _is_postgresql():
        return
    op.drop_constraint("chk_sync_status", _SCOPES_TABLE, type_="check")
    log.info("downgrade: dropped CHECK constraint chk_sync_status.")


def _drop_sync_status_column() -> None:
    op.drop_column(_SCOPES_TABLE, "sync_status")
    log.info("downgrade: dropped sync_status column from %s.", _SCOPES_TABLE)


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Apply PREREQ-3.1 and PREREQ-3.2 schema changes.

    Step order matters:
    0. Guard: artifact_version_scopes only exists on PostgreSQL; no-op on SQLite.
    1. Add column first (with server_default so existing rows get 'pending').
    2. Backfill immediately using derived values from existing hash fields.
    3. Add CHECK constraint (PostgreSQL only — locks table briefly, safe after
       backfill since all values are already valid).
    4. Create indexes (non-CONCURRENTLY — Alembic runs in a transaction
       block which is incompatible with CONCURRENTLY; acceptable since
       these tables are new/small during migration).
    """
    if is_sqlite():
        return  # defense-in-depth guard (layer 2); env.py filter is layer 1

    # PREREQ-3.1
    _add_sync_status_column()
    _backfill_sync_status()
    _add_sync_status_check_constraint()

    # PREREQ-3.2
    _create_scopes_indexes()
    _create_history_index()

    log.info("upgrade: ent_022 complete (PREREQ-3.1 + PREREQ-3.2).")


def downgrade() -> None:
    """Reverse PREREQ-3.1 and PREREQ-3.2 changes (development rollback only).

    Reverse order: indexes → constraint → column.
    """
    if is_sqlite():
        return  # defense-in-depth guard (layer 2); env.py filter is layer 1

    _drop_history_index()
    _drop_scopes_indexes()
    _drop_sync_status_check_constraint()
    _drop_sync_status_column()

    log.info("downgrade: ent_022 complete.")
