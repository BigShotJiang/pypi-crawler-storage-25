"""GCD local decouple nullable fk and join table.

Revision ID: 20260403_0001_gcd_local_decouple_nullable_fk_join_table
Revises: ent_019_enterprise_artifacts_type_constraint
Create Date: 2026-04-03 00:01:00.000000+00:00

Background
----------
Task GCD-1.2 — decouple ``GitRepoConnection`` from ``Project`` in the local
(SQLite) edition.  Previously a ``git_repo_connections`` row held a direct
``project_id`` foreign key with ``ON DELETE CASCADE``, meaning project deletion
silently destroyed all associated connections.

After this migration connections are long-lived, project-independent objects.
The link between a project and its connections is modelled in a new
``project_git_connections`` join table (many-to-many).  The ``project_id``
column on ``git_repo_connections`` is retained as a nullable convenience
reference (for backwards compatibility with existing queries) but its ``ON
DELETE`` action is changed from ``CASCADE`` to ``SET NULL``, so connections
survive project deletion.

Changes
-------
1. Create ``project_git_connections`` join table
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   Schema:
       project_id    TEXT NOT NULL  FK -> projects.id ON DELETE CASCADE
       connection_id TEXT NOT NULL  FK -> git_repo_connections.id ON DELETE CASCADE
       linked_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
       linked_by     TEXT NULL
   Primary key: (project_id, connection_id)

   Indexes:
       ix_pgc_project_id    (project_id)
       ix_pgc_connection_id (connection_id)

2. Backfill join rows
   ~~~~~~~~~~~~~~~~~~
   INSERT INTO project_git_connections (project_id, connection_id, linked_at, linked_by)
   SELECT project_id, id, CURRENT_TIMESTAMP, 'migration'
   FROM git_repo_connections
   WHERE project_id IS NOT NULL

3. Change FK action on git_repo_connections.project_id
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   Old: FK -> projects.id ON DELETE CASCADE (deleting a project deletes connections)
   New: FK -> projects.id ON DELETE SET NULL (deleting a project orphans connections)

   SQLite does not support ALTER TABLE … DROP CONSTRAINT or ALTER COLUMN; the
   table is therefore recreated via ``op.batch_alter_table(recreate='always')``.

Dialect Strategy
----------------
This migration targets the **local (SQLite)** edition only.  The enterprise
edition has its own migration track (``ent_*`` prefix) and uses PostgreSQL.

``op.batch_alter_table`` is used for step 3 because SQLite cannot alter foreign
key constraints in-place.  The ``recreate='always'`` mode rebuilds the table
and copies all data, making the FK change atomic and safe.

Downgrade
---------
1. Drop indexes on ``project_git_connections``.
2. Drop ``project_git_connections``.
3. Rebuild ``git_repo_connections`` (via batch) restoring the CASCADE FK.

Note: rows that were null-ified during step 3 of the upgrade (i.e. connections
whose project was deleted between upgrade and downgrade) will remain NULL after
downgrade — their project no longer exists and cannot be recovered.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260403_0001_gcd_local_decouple_nullable_fk_join_table"
down_revision: Union[str, None] = "ent_019_enterprise_artifacts_type_constraint"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_JOIN_TABLE = "project_git_connections"
_GRC_TABLE = "git_repo_connections"

# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create join table, backfill, and change git_repo_connections FK to SET NULL."""

    # ------------------------------------------------------------------
    # Step 1: Create project_git_connections join table
    # ------------------------------------------------------------------
    log.info("upgrade: creating %s join table", _JOIN_TABLE)

    op.create_table(
        _JOIN_TABLE,
        sa.Column(
            "project_id",
            sa.String(),
            sa.ForeignKey(
                "projects.id",
                ondelete="CASCADE",
                name="fk_pgc_project_id",
            ),
            nullable=False,
            comment="FK to projects.id; row deleted when project is deleted",
        ),
        sa.Column(
            "connection_id",
            sa.Integer(),
            sa.ForeignKey(
                "git_repo_connections.id",
                ondelete="CASCADE",
                name="fk_pgc_connection_id",
            ),
            nullable=False,
            comment="FK to git_repo_connections.id; row deleted when connection is deleted",
        ),
        sa.Column(
            "linked_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
            comment="UTC timestamp when the connection was linked to the project",
        ),
        sa.Column(
            "linked_by",
            sa.String(),
            nullable=True,
            comment="Optional identifier of the actor that created the link (user, 'migration', etc.)",
        ),
        sa.PrimaryKeyConstraint("project_id", "connection_id", name="pk_pgc"),
    )

    # ------------------------------------------------------------------
    # Step 2: Backfill join rows from existing project_id values
    # ------------------------------------------------------------------
    log.info("upgrade: backfilling %s from existing project_id values", _JOIN_TABLE)

    op.execute(
        sa.text(
            """
            INSERT INTO project_git_connections
                (project_id, connection_id, linked_at, linked_by)
            SELECT
                project_id,
                id,
                CURRENT_TIMESTAMP,
                'migration'
            FROM git_repo_connections
            WHERE project_id IS NOT NULL
            """
        )
    )

    # ------------------------------------------------------------------
    # Step 3: Add indexes on the join table
    # ------------------------------------------------------------------
    op.create_index("ix_pgc_project_id", _JOIN_TABLE, ["project_id"])
    op.create_index("ix_pgc_connection_id", _JOIN_TABLE, ["connection_id"])

    log.info("upgrade: created indexes on %s", _JOIN_TABLE)

    # ------------------------------------------------------------------
    # Step 4: Change git_repo_connections.project_id FK to SET NULL
    #
    # Dialect strategy:
    #   PostgreSQL — supports ALTER TABLE … DROP/ADD CONSTRAINT directly;
    #                batch_alter_table(recreate='always') would drop the PK
    #                which PostgreSQL refuses when dependent FKs exist on
    #                git_repo_scans and project_git_connections.
    #   SQLite      — cannot ALTER FK constraints in-place; must use
    #                batch_alter_table(recreate='always') to rebuild the
    #                table.  All data is preserved by the batch rebuild.
    # ------------------------------------------------------------------
    log.info(
        "upgrade: rebuilding %s with ON DELETE SET NULL for project_id FK",
        _GRC_TABLE,
    )

    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        # PostgreSQL: alter constraints directly without table recreation.
        op.drop_constraint("fk_grc_project_id", _GRC_TABLE, type_="foreignkey")
        op.create_foreign_key(
            "fk_grc_project_id",
            _GRC_TABLE,
            "projects",
            ["project_id"],
            ["id"],
            ondelete="SET NULL",
        )
        # Replace (project_id, repo_url, branch) unique with (repo_url, branch)
        # since connections are now first-class entities shared across projects.
        op.drop_constraint(
            "uq_git_repo_connections_project_url_branch", _GRC_TABLE, type_="unique"
        )
        op.create_unique_constraint(
            "uq_git_repo_connections_url_branch",
            _GRC_TABLE,
            ["repo_url", "branch"],
        )
    else:
        # SQLite: use batch recreate (cannot alter constraints in-place).
        with op.batch_alter_table(_GRC_TABLE, recreate="always") as batch_op:
            # Drop the old CASCADE foreign key and recreate with SET NULL.
            batch_op.drop_constraint("fk_grc_project_id", type_="foreignkey")
            batch_op.create_foreign_key(
                "fk_grc_project_id",
                "projects",
                ["project_id"],
                ["id"],
                ondelete="SET NULL",
            )
            # Replace (project_id, repo_url, branch) unique with (repo_url, branch)
            # since connections are now first-class entities shared across projects.
            batch_op.drop_constraint(
                "uq_git_repo_connections_project_url_branch", type_="unique"
            )
            batch_op.create_unique_constraint(
                "uq_git_repo_connections_url_branch", ["repo_url", "branch"]
            )

    log.info("upgrade: complete — %s now uses ON DELETE SET NULL", _GRC_TABLE)


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop join table and restore CASCADE FK on git_repo_connections.project_id."""

    # ------------------------------------------------------------------
    # Step 1: Drop join table indexes and join table itself
    # ------------------------------------------------------------------
    log.info("downgrade: dropping %s indexes and table", _JOIN_TABLE)

    op.drop_index("ix_pgc_connection_id", table_name=_JOIN_TABLE)
    op.drop_index("ix_pgc_project_id", table_name=_JOIN_TABLE)
    op.drop_table(_JOIN_TABLE)

    log.info("downgrade: dropped %s", _JOIN_TABLE)

    # ------------------------------------------------------------------
    # Step 2: Rebuild git_repo_connections restoring CASCADE FK
    #
    # Connections whose projects were deleted between upgrade and downgrade
    # will have project_id = NULL; their project no longer exists so the
    # original CASCADE behaviour cannot be restored for those rows.
    #
    # Same dialect strategy as upgrade step 4 — PostgreSQL alters directly;
    # SQLite requires a full batch table recreation.
    # ------------------------------------------------------------------
    log.info(
        "downgrade: rebuilding %s to restore ON DELETE CASCADE for project_id FK",
        _GRC_TABLE,
    )

    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        # PostgreSQL: alter constraints directly without table recreation.
        op.drop_constraint("fk_grc_project_id", _GRC_TABLE, type_="foreignkey")
        op.create_foreign_key(
            "fk_grc_project_id",
            _GRC_TABLE,
            "projects",
            ["project_id"],
            ["id"],
            ondelete="CASCADE",
        )
        # Restore original (project_id, repo_url, branch) unique constraint.
        op.drop_constraint(
            "uq_git_repo_connections_url_branch", _GRC_TABLE, type_="unique"
        )
        op.create_unique_constraint(
            "uq_git_repo_connections_project_url_branch",
            _GRC_TABLE,
            ["project_id", "repo_url", "branch"],
        )
    else:
        # SQLite: use batch recreate (cannot alter constraints in-place).
        with op.batch_alter_table(_GRC_TABLE, recreate="always") as batch_op:
            batch_op.drop_constraint("fk_grc_project_id", type_="foreignkey")
            batch_op.create_foreign_key(
                "fk_grc_project_id",
                "projects",
                ["project_id"],
                ["id"],
                ondelete="CASCADE",
            )
            # Restore original (project_id, repo_url, branch) unique constraint.
            batch_op.drop_constraint(
                "uq_git_repo_connections_url_branch", type_="unique"
            )
            batch_op.create_unique_constraint(
                "uq_git_repo_connections_project_url_branch",
                ["project_id", "repo_url", "branch"],
            )

    log.info(
        "downgrade: complete — %s project_id FK restored to ON DELETE CASCADE",
        _GRC_TABLE,
    )
