"""Add content_payload column to artifact_versions for inline content storage.

Revision ID: 20260328_1400
Revises: a789b1d5a033
Create Date: 2026-03-28

Adds ``content_payload`` TEXT column to ``artifact_versions``.  This column
stores the diffable text representation of the artifact at capture time:
raw file text for single-file artifacts, or a concatenated file representation
for directory artifacts.  Used to support inline diff computation in the
local edition without requiring filesystem access at diff time.
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite

# revision identifiers, used by Alembic.
revision: str = "20260328_1400"
down_revision: Union[str, None] = "a789b1d5a033"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    return column in {col["name"] for col in insp.get_columns(table)}


def upgrade() -> None:
    """Add content_payload column to artifact_versions table."""
    if _column_exists("artifact_versions", "content_payload"):
        return
    op.add_column(
        "artifact_versions",
        sa.Column(
            "content_payload",
            sa.Text(),
            nullable=True,
            comment=(
                "Diffable text representation of the artifact at this version. "
                "Raw file text for single-file artifacts; concatenated file "
                "representation for directory artifacts."
            ),
        ),
    )


def downgrade() -> None:
    """Remove content_payload column from artifact_versions table."""
    if is_sqlite():
        op.execute(text("PRAGMA foreign_keys = OFF"))
        try:
            with op.batch_alter_table("artifact_versions", schema=None) as batch_op:
                batch_op.drop_column("content_payload")
        finally:
            op.execute(text("PRAGMA foreign_keys = ON"))
    else:
        op.drop_column("artifact_versions", "content_payload")
