"""Add context_module_id column to artifacts for context entity module filtering.

Revision ID: 20260328_1500
Revises: 20260328_0001_merge_heads
Create Date: 2026-03-28

Adds ``context_module_id`` (String, nullable) to ``artifacts``.  When set
on a context entity row, this column associates the entity with a context
module so it can be retrieved via the
``GET /api/v1/context-entities?module_id=<id>`` filter.

No FK constraint is added at the DB level to keep the column lightweight and
avoid circular-reference issues between the artifacts and context_modules
tables during test fixture construction.  Referential integrity is enforced
at the application layer.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite

# ---------------------------------------------------------------------------
# Revision identifiers — used by Alembic
# ---------------------------------------------------------------------------

revision = "20260328_1500"
down_revision = "20260328_0001_merge_heads"
branch_labels = None
depends_on = None


# ---------------------------------------------------------------------------
# Migration helpers
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add context_module_id column to artifacts table."""
    inspector = sa.inspect(op.get_bind())
    existing_cols = {col["name"] for col in inspector.get_columns("artifacts")}
    if "context_module_id" not in existing_cols:
        op.add_column(
            "artifacts",
            sa.Column(
                "context_module_id",
                sa.String(),
                nullable=True,
                comment=(
                    "Optional FK to context_modules.id. When set, this context entity "
                    "belongs to the specified context module and can be filtered via "
                    "GET /api/v1/context-entities?module_id=<id>."
                ),
            ),
        )
        op.create_index(
            "idx_artifacts_context_module_id",
            "artifacts",
            ["context_module_id"],
        )


def downgrade() -> None:
    """Remove context_module_id column from artifacts table."""
    if is_sqlite():
        op.execute(text("PRAGMA foreign_keys = OFF"))
        try:
            with op.batch_alter_table("artifacts", schema=None) as batch_op:
                batch_op.drop_index("idx_artifacts_context_module_id")
                batch_op.drop_column("context_module_id")
        finally:
            op.execute(text("PRAGMA foreign_keys = ON"))
    else:
        op.drop_index("idx_artifacts_context_module_id", table_name="artifacts")
        op.drop_column("artifacts", "context_module_id")
