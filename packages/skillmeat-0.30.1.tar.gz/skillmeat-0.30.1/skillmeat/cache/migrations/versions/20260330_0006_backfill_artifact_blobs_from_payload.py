"""Backfill artifact_blobs from existing content_payload rows (DVCS-1.4).

Revision ID: 20260330_0006_backfill_artifact_blobs_from_payload
Revises: 20260330_0005_add_artifact_blobs_cas
Create Date: 2026-03-30 00:06:00.000000+00:00

Background
----------
This is the DATA migration companion to the SCHEMA migration in DVCS-1.1
(20260330_0005_add_artifact_blobs_cas).  It backfills the ``artifact_blobs``
table and the two new ``artifact_versions`` columns from existing
``content_payload`` rows.

For each ``artifact_versions`` row where:
  - ``content_payload IS NOT NULL``  (has inline content to migrate)
  - ``content_tree IS NULL``         (not yet migrated)

the migration:

  1. Computes SHA-256(content_payload) → *blob_hash*
  2. Inserts ``(blob_hash, content_payload, 'utf8', size_bytes, ...)``
     into ``artifact_blobs`` with ``ON CONFLICT (hash) DO NOTHING``
     (deduplication — one blob row per unique content, regardless of
     how many versions share it).
  3. Sets ``content_tree = '{"content": "<blob_hash>"}'`` on the version row
     (single-file artifact convention — the original filename is not known for
     historic versions; "content" is the canonical placeholder key).
  4. Sets ``is_complete_capture = 1`` (True) for the migrated row.

Dual-write safety
-----------------
``content_payload`` is NOT cleared.  The existing read path continues to work
unchanged during the CAS transition period.  ``content_payload`` will be
nulled out only after ``dvcs.cas_enabled`` has been enabled and validated in
production.

Batch processing
----------------
Rows are processed in batches of 500 to bound peak memory use and allow
partial-progress restarts (each iteration is its own implicit SAVEPOINT on
databases that support them).  Progress is printed to stdout so Alembic's
``-v`` output shows activity for large collections.

ON CONFLICT compatibility
-------------------------
``ON CONFLICT (hash) DO NOTHING`` is supported by:
  - SQLite >= 3.24.0  (released 2018-06-04)
  - PostgreSQL >= 9.5

SQLite ships with Python 3.x at version >= 3.35, so this is safe for all
supported SkillMeat environments.

Downgrade
---------
Sets ``content_tree = NULL`` and ``is_complete_capture = NULL`` on all
``artifact_versions`` rows (rolling back the CAS pointers).  Does NOT delete
``artifact_blobs`` rows — they are harmless and may be referenced by versions
created via the live CAS write path (if ``dvcs_cas_enabled`` was ever True).
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Sequence, Union

from alembic import op
from sqlalchemy import text

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0006_backfill_artifact_blobs_from_payload"
down_revision: Union[str, None] = "20260330_0005_add_artifact_blobs_cas"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_BATCH_SIZE = 500

# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Backfill artifact_blobs from content_payload in artifact_versions."""

    conn = op.get_bind()

    # PostgreSQL guard: the local CAS schema (content_tree column on
    # artifact_versions) is not created on PostgreSQL — ent_013 manages
    # the enterprise CAS schema independently. Skip to avoid querying
    # a non-existent column.
    if conn.dialect.name == "postgresql":
        log.info(
            "20260330_0006: PostgreSQL dialect detected — "
            "CAS backfill is managed by enterprise migration chain; skipping."
        )
        return

    # Count rows to migrate for progress reporting.
    total_result = conn.execute(
        text(
            "SELECT COUNT(*) FROM artifact_versions "
            "WHERE content_payload IS NOT NULL AND content_tree IS NULL"
        )
    )
    total_rows = total_result.scalar() or 0
    print(
        f"[DVCS-1.4] backfill: {total_rows} artifact_versions rows to migrate "
        f"(batch_size={_BATCH_SIZE})"
    )

    if total_rows == 0:
        log.info("upgrade: no rows to backfill — already complete or table is empty.")
        return

    offset = 0
    migrated = 0

    while True:
        rows = conn.execute(
            text(
                "SELECT id, content_payload FROM artifact_versions "
                "WHERE content_payload IS NOT NULL AND content_tree IS NULL "
                "ORDER BY id "
                "LIMIT :limit OFFSET :offset"
            ),
            {"limit": _BATCH_SIZE, "offset": offset},
        ).fetchall()

        if not rows:
            break

        for row in rows:
            version_id, payload = row

            if payload is None:
                # Guard against unlikely NULL slipping through the WHERE clause.
                log.warning(
                    "upgrade: skipping version_id=%r — content_payload is NULL "
                    "(unexpected; WHERE clause should have filtered this row).",
                    version_id,
                )
                continue

            # 1. SHA-256 hash the payload bytes.
            payload_bytes = payload.encode("utf-8")
            content_hash = hashlib.sha256(payload_bytes).hexdigest()
            size_bytes = len(payload_bytes)

            # 2. Upsert blob (ON CONFLICT DO NOTHING for deduplication).
            conn.execute(
                text(
                    "INSERT INTO artifact_blobs "
                    "(hash, content, encoding, size_bytes, created_at, compression) "
                    "VALUES (:hash, :content, 'utf8', :size, CURRENT_TIMESTAMP, 'none') "
                    "ON CONFLICT (hash) DO NOTHING"
                ),
                {"hash": content_hash, "content": payload, "size": size_bytes},
            )

            # 3. Build single-file content_tree using canonical placeholder key.
            #    Historic versions don't carry the original filename, so we use
            #    "content" as the key — consistent with the DVCS-1.4 spec.
            content_tree = json.dumps({"content": content_hash})

            # 4. Update artifact_versions row with CAS pointer + completeness flag.
            conn.execute(
                text(
                    "UPDATE artifact_versions "
                    "SET content_tree = :tree, is_complete_capture = 1 "
                    "WHERE id = :id"
                ),
                {"tree": content_tree, "id": version_id},
            )

        migrated += len(rows)
        print(f"[DVCS-1.4] backfill progress: {migrated}/{total_rows} rows migrated")
        log.info(
            "upgrade: backfill batch complete — migrated=%d total=%d offset=%d",
            migrated,
            total_rows,
            offset,
        )

        offset += _BATCH_SIZE

    print(f"[DVCS-1.4] backfill complete: {migrated} rows migrated.")
    log.info("upgrade: backfill finished — total_migrated=%d", migrated)


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Roll back CAS pointers on artifact_versions.

    Sets content_tree and is_complete_capture back to NULL for all rows that
    were populated by the backfill.  Does NOT delete artifact_blobs rows.
    """

    conn = op.get_bind()

    if conn.dialect.name == "postgresql":
        log.info("20260330_0006 downgrade: skipping on PostgreSQL (no local CAS schema).")
        return

    result = conn.execute(
        text(
            "UPDATE artifact_versions "
            "SET content_tree = NULL, is_complete_capture = NULL "
            "WHERE content_tree IS NOT NULL"
        )
    )

    # rowcount is -1 on databases that don't support it (SQLite before 3.35).
    # Use a best-effort log message.
    rows_affected = getattr(result, "rowcount", -1)
    print(
        f"[DVCS-1.4] downgrade: cleared content_tree / is_complete_capture "
        f"on {rows_affected} artifact_versions rows."
    )
    log.info(
        "downgrade: CAS pointers cleared — rows_affected=%d "
        "(artifact_blobs rows retained).",
        rows_affected,
    )
