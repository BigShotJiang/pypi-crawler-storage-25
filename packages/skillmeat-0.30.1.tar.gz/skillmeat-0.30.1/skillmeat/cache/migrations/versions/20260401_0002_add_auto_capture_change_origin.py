"""Add 'auto_capture' to artifact_versions change_origin CHECK constraint (SYNC-1.6).

Revision ID: 20260401_0002_add_auto_capture_change_origin
Revises: 20260401_0001_add_sync_debounce_entries
Create Date: 2026-04-01 00:02:00.000000+00:00

Background
----------
DVCS Unified Sync introduces automatic version capture when local edits are
detected during sync checks.  These versions use ``change_origin='auto_capture'``.

The existing CHECK constraint on ``artifact_versions.change_origin`` does not
include ``'auto_capture'``, so any INSERT with that value would be rejected.

Changes
-------
1. Update the CHECK constraint ``check_artifact_versions_change_origin`` on
   ``artifact_versions`` to include ``'auto_capture'`` in the allowed values.

Dialect Strategy
----------------
- **SQLite**: ``batch_alter_table(recreate='always')`` with FK pragma off.
- **PostgreSQL**: Drop + recreate the CHECK constraint.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_postgresql, is_sqlite

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260401_0002_add_auto_capture_change_origin"
down_revision: Union[str, None] = "20260401_0001_add_sync_debounce_entries"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_VERSIONS_TABLE = "artifact_versions"
_CK_ORIGIN = "check_artifact_versions_change_origin"

_ORIGIN_VALUES_WITHOUT_AUTO_CAPTURE = (
    "'initial_seed', 'deployment', 'sync', 'local_modification', "
    "'restore', 'promotion', 'push', 'github_update', 'import', "
    "'policy_enforcement', 'composite_update', 'rename', 'patch'"
)
_ORIGIN_VALUES_WITH_AUTO_CAPTURE = (
    "'initial_seed', 'deployment', 'sync', 'local_modification', "
    "'restore', 'promotion', 'push', 'github_update', 'import', "
    "'policy_enforcement', 'composite_update', 'rename', 'patch', 'auto_capture'"
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _constraint_exists_pg(
    bind: sa.engine.Connection, constraint: str, table: str
) -> bool:
    """Check whether a named constraint exists on a PostgreSQL table."""
    result = bind.execute(
        text(
            "SELECT 1 FROM pg_constraint c "
            "JOIN pg_class t ON t.oid = c.conrelid "
            "WHERE c.conname = :cname AND t.relname = :tname"
        ),
        {"cname": constraint, "tname": table},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add 'auto_capture' to artifact_versions change_origin CHECK constraint."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_auto_capture_change_origin upgrade: SQLite path.")
        _upgrade_sqlite()
    elif is_postgresql():
        log.info("add_auto_capture_change_origin upgrade: PostgreSQL path.")
        _upgrade_postgresql(bind)
    else:
        log.warning(
            "add_auto_capture_change_origin upgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _upgrade_sqlite() -> None:
    """Recreate artifact_versions with updated CHECK to include 'auto_capture'."""
    bind = op.get_bind()
    bind.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table(_VERSIONS_TABLE, recreate="always") as batch_op:
            batch_op.create_check_constraint(
                _CK_ORIGIN,
                f"change_origin IN ({_ORIGIN_VALUES_WITH_AUTO_CAPTURE})",
            )
        log.info(
            "add_auto_capture_change_origin (SQLite): updated %s change_origin CHECK.",
            _VERSIONS_TABLE,
        )
    finally:
        bind.execute(text("PRAGMA foreign_keys = ON"))


def _upgrade_postgresql(bind: sa.engine.Connection) -> None:
    """Update artifact_versions CHECK constraint on PostgreSQL."""
    if _constraint_exists_pg(bind, _CK_ORIGIN, _VERSIONS_TABLE):
        op.drop_constraint(_CK_ORIGIN, _VERSIONS_TABLE, type_="check")
    op.create_check_constraint(
        _CK_ORIGIN,
        _VERSIONS_TABLE,
        f"change_origin IN ({_ORIGIN_VALUES_WITH_AUTO_CAPTURE})",
    )
    log.info(
        "add_auto_capture_change_origin (PG): updated %s change_origin CHECK.",
        _VERSIONS_TABLE,
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove 'auto_capture' from artifact_versions change_origin CHECK constraint."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_auto_capture_change_origin downgrade: SQLite path.")
        _downgrade_sqlite()
    elif is_postgresql():
        log.info("add_auto_capture_change_origin downgrade: PostgreSQL path.")
        _downgrade_postgresql(bind)
    else:
        log.warning(
            "add_auto_capture_change_origin downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _downgrade_sqlite() -> None:
    """Restore artifact_versions CHECK to exclude 'auto_capture'."""
    bind = op.get_bind()
    bind.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table(_VERSIONS_TABLE, recreate="always") as batch_op:
            batch_op.create_check_constraint(
                _CK_ORIGIN,
                f"change_origin IN ({_ORIGIN_VALUES_WITHOUT_AUTO_CAPTURE})",
            )
        log.info(
            "add_auto_capture_change_origin (SQLite) downgrade: restored %s CHECK.",
            _VERSIONS_TABLE,
        )
    finally:
        bind.execute(text("PRAGMA foreign_keys = ON"))


def _downgrade_postgresql(bind: sa.engine.Connection) -> None:
    """Restore artifact_versions CHECK to exclude 'auto_capture' on PostgreSQL."""
    if _constraint_exists_pg(bind, _CK_ORIGIN, _VERSIONS_TABLE):
        op.drop_constraint(_CK_ORIGIN, _VERSIONS_TABLE, type_="check")
    op.create_check_constraint(
        _CK_ORIGIN,
        _VERSIONS_TABLE,
        f"change_origin IN ({_ORIGIN_VALUES_WITHOUT_AUTO_CAPTURE})",
    )
    log.info(
        "add_auto_capture_change_origin (PG) downgrade: restored %s CHECK.",
        _VERSIONS_TABLE,
    )
