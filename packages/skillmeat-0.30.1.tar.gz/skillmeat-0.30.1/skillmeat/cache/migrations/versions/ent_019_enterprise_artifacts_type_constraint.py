"""Extend ck_enterprise_artifacts_type CHECK constraint to include six new artifact types.

Revision ID: ent_019_enterprise_artifacts_type_constraint
Revises: ent_018_important_tier_tables
Create Date: 2026-04-02 00:00:00.000000+00:00

Background
----------
The ``enterprise_artifacts`` table carries a CHECK constraint
``ck_enterprise_artifacts_type`` that restricts the ``type`` column to 13
values.  Six additional artifact types introduced in the unified artifact
expansion are missing from that constraint:

  context_module, template, group, deployment_set, context_pack, bundle

This migration extends the constraint on ``enterprise_artifacts`` to match the
full 19-value set already accepted by ``artifacts.check_artifact_type``
(updated by migration ``20260324_0001_add_new_artifact_types_to_constraints``).

Changes
-------
``enterprise_artifacts`` — replace ``ck_enterprise_artifacts_type`` with the
complete 19-value list:

  ``('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'workflow',
  'composite', 'project_config', 'spec_file', 'rule_file', 'context_file',
  'progress_template', 'context_module', 'template', 'group',
  'deployment_set', 'context_pack', 'bundle')``

PostgreSQL Strategy
-------------------
PostgreSQL supports native ``ALTER TABLE ... DROP CONSTRAINT`` followed by
``ALTER TABLE ... ADD CONSTRAINT``, so no table rebuild is required.  This is
an enterprise-only migration; SQLite is not used for enterprise deployments.

Idempotency
-----------
The upgrade path checks whether ``context_module`` is already present in the
existing constraint definition via ``pg_constraint``.  If so, the migration is
a no-op.  This handles databases where ``Base.metadata.create_all()`` ran
against an updated ORM model before this migration was applied.

Backward Compatibility
----------------------
All 13 previously accepted type values remain valid.  Existing rows are
unaffected.

Rollback
--------
Restores the original 13-value constraint.  Any rows carrying one of the six
new type values will violate the restored constraint; callers are responsible
for removing or migrating such rows before running the downgrade.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_019_enterprise_artifacts_type_constraint"
down_revision: Union[str, Sequence[str], None] = "ent_018_important_tier_tables"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constraint name and canonical type lists
# ---------------------------------------------------------------------------

_TABLE = "enterprise_artifacts"
_CONSTRAINT = "ck_enterprise_artifacts_type"

_TYPES_NEW = (
    "('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'workflow', "
    "'composite', 'project_config', 'spec_file', 'rule_file', 'context_file', "
    "'progress_template', 'context_module', 'template', 'group', "
    "'deployment_set', 'context_pack', 'bundle')"
)

_TYPES_OLD = (
    "('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'workflow', "
    "'composite', 'project_config', 'spec_file', 'rule_file', 'context_file', "
    "'progress_template')"
)

# Sentinel value used for idempotency — one of the six new types.
_SENTINEL = "context_module"


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _constraint_already_updated(bind: sa.engine.Connection) -> bool:
    """Return True if ck_enterprise_artifacts_type already includes the new types."""
    result = bind.execute(
        text("""
            SELECT pg_get_constraintdef(c.oid)
            FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :cname
              AND t.relname = :tname
              AND c.contype = 'c'
            """),
        {"cname": _CONSTRAINT, "tname": _TABLE},
    )
    row = result.fetchone()
    if row is None:
        # Constraint does not exist yet — treat as not-yet-updated.
        return False
    constraint_def: str = row[0] or ""
    return _SENTINEL in constraint_def


def _constraint_exists(bind: sa.engine.Connection) -> bool:
    """Return True if ck_enterprise_artifacts_type exists on enterprise_artifacts."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :cname
              AND t.relname = :tname
              AND c.contype = 'c'
            """),
        {"cname": _CONSTRAINT, "tname": _TABLE},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Extend ck_enterprise_artifacts_type to include the six new artifact types."""
    if not _is_postgresql():
        log.info(
            "Skipping ent_019_enterprise_artifacts_type_constraint: "
            "non-PostgreSQL dialect detected."
        )
        return

    bind = op.get_bind()

    if _constraint_already_updated(bind):
        log.info(
            "ent_019: ck_enterprise_artifacts_type already contains new types; "
            "skipping upgrade."
        )
        return

    log.info("ent_019: extending ck_enterprise_artifacts_type on enterprise_artifacts.")

    if _constraint_exists(bind):
        op.execute(text(f"ALTER TABLE {_TABLE} DROP CONSTRAINT {_CONSTRAINT}"))

    op.execute(
        text(
            f"ALTER TABLE {_TABLE} ADD CONSTRAINT {_CONSTRAINT} "
            f"CHECK (type IN {_TYPES_NEW})"
        )
    )

    log.info("ent_019_enterprise_artifacts_type_constraint upgrade complete.")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Restore ck_enterprise_artifacts_type to the original 13-value list.

    WARNING: rows carrying one of the six new type values
    (``context_module``, ``template``, ``group``, ``deployment_set``,
    ``context_pack``, ``bundle``) will violate the restored constraint.
    Remove or migrate those rows before running this downgrade.
    """
    if not _is_postgresql():
        log.info(
            "Skipping ent_019_enterprise_artifacts_type_constraint downgrade: "
            "non-PostgreSQL dialect detected."
        )
        return

    bind = op.get_bind()

    log.info(
        "ent_019: restoring ck_enterprise_artifacts_type to original 13-value list."
    )

    if _constraint_exists(bind):
        op.execute(text(f"ALTER TABLE {_TABLE} DROP CONSTRAINT {_CONSTRAINT}"))

    op.execute(
        text(
            f"ALTER TABLE {_TABLE} ADD CONSTRAINT {_CONSTRAINT} "
            f"CHECK (type IN {_TYPES_OLD})"
        )
    )

    log.info("ent_019_enterprise_artifacts_type_constraint downgrade complete.")
