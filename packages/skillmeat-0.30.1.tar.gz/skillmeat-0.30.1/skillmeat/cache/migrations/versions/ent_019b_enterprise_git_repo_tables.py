"""Create enterprise git repo connection, scan, and scan-artifact tables.

Revision ID: ent_019b_enterprise_git_repo_tables
Revises: 20260403_0001_gcd_local_decouple_nullable_fk_join_table
Create Date: 2026-04-03 00:00:00.000000+00:00

Background
----------
GCD-1.3 pre-requisite: creates the three enterprise git-connector base tables
that ``ent_020_enterprise_git_connection_join_table`` later extends.

Without these tables, ``ent_020`` cannot ALTER ``enterprise_git_repo_connections``
(the table does not exist yet).  This migration is inserted between
``20260403_0001_gcd_local_decouple_nullable_fk_join_table`` and ``ent_020``.

Tables created
--------------
1. ``enterprise_git_repo_connections``

   Stores registered Git repository connections scoped to a tenant.  Each row
   represents a repo+branch combination that SkillMeat enterprise can scan for
   artifacts.

   Columns:
       id             UUID PK, gen_random_uuid()
       tenant_id      UUID NOT NULL
       project_id     UUID NULL
       repo_url       TEXT NOT NULL
       branch         TEXT NOT NULL DEFAULT 'main'
       developer_id   UUID NULL
       scan_schedule  TEXT NULL
       webhook_secret TEXT NULL
       last_scan_at   TIMESTAMPTZ NULL
       last_scan_id   UUID NULL
       is_active      BOOLEAN NOT NULL DEFAULT TRUE
       created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
       created_by     UUID NULL
       access_token   TEXT NULL   (encrypted at application layer)

   Unique constraint: (tenant_id, repo_url, branch)
   Indexes: tenant_id, project_id, is_active

2. ``enterprise_git_repo_scans``

   Records a single artifact-discovery scan run scoped to a tenant.

   Columns:
       id                 UUID PK, gen_random_uuid()
       tenant_id          UUID NOT NULL
       connection_id      UUID NOT NULL   FK -> enterprise_git_repo_connections.id CASCADE
       triggered_by       TEXT NOT NULL   ('manual'|'schedule'|'webhook')
       trigger_sha        VARCHAR(40) NULL
       status             TEXT NOT NULL DEFAULT 'pending'
       started_at         TIMESTAMPTZ NULL
       completed_at       TIMESTAMPTZ NULL
       artifacts_found    INTEGER NOT NULL DEFAULT 0
       artifacts_new      INTEGER NOT NULL DEFAULT 0
       artifacts_changed  INTEGER NOT NULL DEFAULT 0
       artifacts_removed  INTEGER NOT NULL DEFAULT 0
       error_message      TEXT NULL
       created_at         TIMESTAMPTZ NOT NULL DEFAULT now()

   Check constraints: triggered_by values, status values
   Indexes: tenant_id, connection_id, status, created_at

3. ``enterprise_git_scan_artifacts``

   Records a single artifact observation produced during a scan.

   Columns:
       id             UUID PK, gen_random_uuid()
       tenant_id      UUID NOT NULL
       scan_id        UUID NOT NULL   FK -> enterprise_git_repo_scans.id CASCADE
       artifact_path  TEXT NOT NULL
       artifact_type  VARCHAR(64) NOT NULL
       detected_name  TEXT NULL
       content_hash   VARCHAR(64) NULL
       change_type    TEXT NOT NULL   ('new'|'changed'|'removed'|'unchanged')
       indexed_at     TIMESTAMPTZ NULL
       artifact_id    UUID NULL   FK -> enterprise_artifacts.id
       created_at     TIMESTAMPTZ NOT NULL DEFAULT now()

   Check constraint: change_type values
   Indexes: tenant_id, scan_id, artifact_path, change_type, artifact_id

Dialect
-------
Enterprise-only (PostgreSQL).  The ``upgrade()`` and ``downgrade()`` functions
are no-ops when executed against a non-PostgreSQL backend to prevent accidental
execution against the SQLite local-mode database.

Downgrade
---------
Drop all three tables in reverse dependency order:
  1. enterprise_git_scan_artifacts
  2. enterprise_git_repo_scans
  3. enterprise_git_repo_connections
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_019b_enterprise_git_repo_tables"
down_revision: Union[str, Sequence[str], None] = (
    "20260403_0001_gcd_local_decouple_nullable_fk_join_table"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Table names
# ---------------------------------------------------------------------------

_GRC_TABLE = "enterprise_git_repo_connections"
_GRS_TABLE = "enterprise_git_repo_scans"
_GSA_TABLE = "enterprise_git_scan_artifacts"

# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Upgrade helpers
# ---------------------------------------------------------------------------


def _create_git_repo_connections_table() -> None:
    """Create enterprise_git_repo_connections."""

    op.create_table(
        _GRC_TABLE,
        # Identity
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            comment="Globally unique connection identifier",
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
        ),
        # Core metadata
        sa.Column(
            "project_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment="Optional UUID of the owning enterprise project",
        ),
        sa.Column(
            "repo_url",
            sa.Text(),
            nullable=False,
            comment="Full clone URL of the Git repository (HTTPS or SSH)",
        ),
        sa.Column(
            "branch",
            sa.Text(),
            nullable=False,
            server_default=sa.text("'main'"),
            comment="Branch to scan; defaults to 'main'",
        ),
        sa.Column(
            "developer_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment="Optional UUID of the enterprise user who owns this connection",
        ),
        sa.Column(
            "scan_schedule",
            sa.Text(),
            nullable=True,
            comment="Reserved: future cron expression for scheduled scans",
        ),
        sa.Column(
            "webhook_secret",
            sa.Text(),
            nullable=True,
            comment="Webhook HMAC secret; treat as sensitive",
        ),
        # Scan state pointers
        sa.Column(
            "last_scan_at",
            sa.DateTime(timezone=True),
            nullable=True,
            comment="Timezone-aware UTC timestamp of the most recently completed scan",
        ),
        sa.Column(
            "last_scan_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment=(
                "Plain UUID reference (no FK) to the most recent enterprise_git_repo_scans.id. "
                "No FK constraint to avoid circular dependency."
            ),
        ),
        # Status and audit
        sa.Column(
            "is_active",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("TRUE"),
            comment="When False the connection is paused and will not be scanned",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
            comment="Immutable timezone-aware creation timestamp",
        ),
        sa.Column(
            "created_by",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment="Optional UUID of the enterprise user who registered this connection",
        ),
        sa.Column(
            "access_token",
            sa.Text(),
            nullable=True,
            comment="Encrypted personal access token for authenticated git operations",
        ),
        # Unique constraint
        sa.UniqueConstraint(
            "tenant_id",
            "repo_url",
            "branch",
            name="uq_ent_git_repo_connections_tenant_url_branch",
        ),
    )

    op.create_index(
        "idx_ent_git_repo_connections_tenant_id",
        _GRC_TABLE,
        ["tenant_id"],
    )
    op.create_index(
        "idx_ent_git_repo_connections_project_id",
        _GRC_TABLE,
        ["project_id"],
    )
    op.create_index(
        "idx_ent_git_repo_connections_is_active",
        _GRC_TABLE,
        ["is_active"],
    )

    log.info("upgrade: created %s table.", _GRC_TABLE)


def _create_git_repo_scans_table() -> None:
    """Create enterprise_git_repo_scans."""

    op.create_table(
        _GRS_TABLE,
        # Identity
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            comment="Globally unique scan identifier",
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
        ),
        # Parent connection
        sa.Column(
            "connection_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="FK to enterprise_git_repo_connections.id; cascade-delete on connection removal",
        ),
        # Trigger metadata
        sa.Column(
            "triggered_by",
            sa.Text(),
            nullable=False,
            comment="How this scan was initiated: 'manual', 'schedule', or 'webhook'",
        ),
        sa.Column(
            "trigger_sha",
            sa.String(40),
            nullable=True,
            comment="Git commit SHA (40-char hex) that triggered this scan; NULL for manual/schedule",
        ),
        # Lifecycle
        sa.Column(
            "status",
            sa.Text(),
            nullable=False,
            server_default=sa.text("'pending'"),
            comment="Current scan lifecycle state: 'pending', 'running', 'completed', or 'failed'",
        ),
        sa.Column(
            "started_at",
            sa.DateTime(timezone=True),
            nullable=True,
            comment="Timezone-aware UTC timestamp when the scan worker picked up the job",
        ),
        sa.Column(
            "completed_at",
            sa.DateTime(timezone=True),
            nullable=True,
            comment="Timezone-aware UTC timestamp when the scan finished",
        ),
        # Artifact counters
        sa.Column(
            "artifacts_found",
            sa.Integer(),
            nullable=False,
            server_default=sa.text("0"),
            comment="Total artifacts detected in this scan run",
        ),
        sa.Column(
            "artifacts_new",
            sa.Integer(),
            nullable=False,
            server_default=sa.text("0"),
            comment="Artifacts newly discovered (not seen in previous scans)",
        ),
        sa.Column(
            "artifacts_changed",
            sa.Integer(),
            nullable=False,
            server_default=sa.text("0"),
            comment="Artifacts whose content changed since the last scan",
        ),
        sa.Column(
            "artifacts_removed",
            sa.Integer(),
            nullable=False,
            server_default=sa.text("0"),
            comment="Artifacts present in the previous scan but no longer found",
        ),
        # Error reporting and audit
        sa.Column(
            "error_message",
            sa.Text(),
            nullable=True,
            comment="Human-readable error detail when status is 'failed'",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
            comment="Immutable timezone-aware creation timestamp",
        ),
        # Foreign key
        sa.ForeignKeyConstraint(
            ["connection_id"],
            ["enterprise_git_repo_connections.id"],
            ondelete="CASCADE",
            name="fk_ent_grs_connection_id",
        ),
        # Check constraints
        sa.CheckConstraint(
            "triggered_by IN ('manual', 'schedule', 'webhook')",
            name="ck_ent_git_repo_scans_triggered_by",
        ),
        sa.CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed')",
            name="ck_ent_git_repo_scans_status",
        ),
    )

    op.create_index(
        "idx_ent_git_repo_scans_tenant_id",
        _GRS_TABLE,
        ["tenant_id"],
    )
    op.create_index(
        "idx_ent_git_repo_scans_connection_id",
        _GRS_TABLE,
        ["connection_id"],
    )
    op.create_index(
        "idx_ent_git_repo_scans_status",
        _GRS_TABLE,
        ["status"],
    )
    op.create_index(
        "idx_ent_git_repo_scans_created_at",
        _GRS_TABLE,
        ["created_at"],
    )

    log.info("upgrade: created %s table.", _GRS_TABLE)


def _create_git_scan_artifacts_table() -> None:
    """Create enterprise_git_scan_artifacts."""

    op.create_table(
        _GSA_TABLE,
        # Identity
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            comment="Globally unique artifact observation identifier",
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
        ),
        # Parent scan
        sa.Column(
            "scan_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="FK to enterprise_git_repo_scans.id; cascade-delete when scan is removed",
        ),
        # Artifact metadata
        sa.Column(
            "artifact_path",
            sa.Text(),
            nullable=False,
            comment="Repository-relative path to the artifact directory or file",
        ),
        sa.Column(
            "artifact_type",
            sa.String(64),
            nullable=False,
            comment="Detected artifact type label (e.g. 'skill', 'agent', 'command')",
        ),
        sa.Column(
            "detected_name",
            sa.Text(),
            nullable=True,
            comment="Human-readable artifact name parsed from CLAUDE.md or SKILL.md frontmatter",
        ),
        sa.Column(
            "content_hash",
            sa.String(64),
            nullable=True,
            comment="SHA-256 hex digest (64 chars) of the artifact's content at scan time",
        ),
        sa.Column(
            "change_type",
            sa.Text(),
            nullable=False,
            comment=(
                "How this artifact changed since the last scan: "
                "'new', 'changed', 'removed', or 'unchanged'"
            ),
        ),
        # Import linkage and audit
        sa.Column(
            "indexed_at",
            sa.DateTime(timezone=True),
            nullable=True,
            comment="Timezone-aware UTC timestamp when this artifact was imported into the cache",
        ),
        sa.Column(
            "artifact_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment=(
                "UUID FK to enterprise_artifacts.id once the artifact has been indexed. "
                "NULL until import completes."
            ),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
            comment="Immutable timezone-aware creation timestamp",
        ),
        # Foreign keys
        sa.ForeignKeyConstraint(
            ["scan_id"],
            ["enterprise_git_repo_scans.id"],
            ondelete="CASCADE",
            name="fk_ent_gsa_scan_id",
        ),
        sa.ForeignKeyConstraint(
            ["artifact_id"],
            ["enterprise_artifacts.id"],
            name="fk_ent_gsa_artifact_id",
        ),
        # Check constraint
        sa.CheckConstraint(
            "change_type IN ('new', 'changed', 'removed', 'unchanged')",
            name="ck_ent_git_scan_artifacts_change_type",
        ),
    )

    op.create_index(
        "idx_ent_git_scan_artifacts_tenant_id",
        _GSA_TABLE,
        ["tenant_id"],
    )
    op.create_index(
        "idx_ent_git_scan_artifacts_scan_id",
        _GSA_TABLE,
        ["scan_id"],
    )
    op.create_index(
        "idx_ent_git_scan_artifacts_artifact_path",
        _GSA_TABLE,
        ["artifact_path"],
    )
    op.create_index(
        "idx_ent_git_scan_artifacts_change_type",
        _GSA_TABLE,
        ["change_type"],
    )
    op.create_index(
        "idx_ent_git_scan_artifacts_artifact_id",
        _GSA_TABLE,
        ["artifact_id"],
    )

    log.info("upgrade: created %s table.", _GSA_TABLE)


# ---------------------------------------------------------------------------
# Downgrade helpers
# ---------------------------------------------------------------------------


def _drop_git_scan_artifacts_table() -> None:
    """Drop enterprise_git_scan_artifacts (indexes dropped implicitly)."""
    op.drop_table(_GSA_TABLE)
    log.info("downgrade: dropped %s table.", _GSA_TABLE)


def _drop_git_repo_scans_table() -> None:
    """Drop enterprise_git_repo_scans (indexes dropped implicitly)."""
    op.drop_table(_GRS_TABLE)
    log.info("downgrade: dropped %s table.", _GRS_TABLE)


def _drop_git_repo_connections_table() -> None:
    """Drop enterprise_git_repo_connections (indexes dropped implicitly)."""
    op.drop_table(_GRC_TABLE)
    log.info("downgrade: dropped %s table.", _GRC_TABLE)


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create enterprise git repo tables (PostgreSQL only)."""
    if not _is_postgresql():
        log.info(
            "upgrade: skipping enterprise migration on non-PostgreSQL backend (%s).",
            op.get_bind().dialect.name,
        )
        return

    # Order matters: connections → scans (FK to connections) → scan_artifacts (FK to scans).
    _create_git_repo_connections_table()
    _create_git_repo_scans_table()
    _create_git_scan_artifacts_table()

    log.info("upgrade: ent_019b complete.")


def downgrade() -> None:
    """Drop enterprise git repo tables (PostgreSQL only)."""
    if not _is_postgresql():
        log.info(
            "downgrade: skipping enterprise migration on non-PostgreSQL backend (%s).",
            op.get_bind().dialect.name,
        )
        return

    # Reverse order: drop leaf tables before parents to satisfy FK constraints.
    _drop_git_scan_artifacts_table()
    _drop_git_repo_scans_table()
    _drop_git_repo_connections_table()

    log.info("downgrade: ent_019b complete.")
