"""Create enterprise_duplicate_pairs table.

Revision ID: ent_025_enterprise_duplicate_pairs
Revises: ent_024_enterprise_artifact_parity_columns
Create Date: 2026-04-07 00:00:00.000000+00:00

Background
----------
This migration creates the ``enterprise_duplicate_pairs`` table, which backs
the ``EnterpriseDuplicatePair`` ORM model introduced in TASK-0.2 of the
enterprise-stub-promotion-v1 feature branch.

The table stores tenant-scoped candidate duplicate artifact pairs produced by
the deduplication pipeline.  Each row represents an unordered pair
``{artifact_a_id, artifact_b_id}`` within a tenant with an optional similarity
score, flagging reasons, and a user-dismissal (``ignored``) workflow.

TASK-0.2 inline schema proposal review outcomes:
- ``similarity_score`` is nullable (unlike the local SQLite schema) to support
  exact-match pairs where a numeric score is redundant.
- ``match_reasons`` uses JSONB (replaces local TEXT-encoded JSON) for native
  PostgreSQL JSON operators and GIN indexability.
- ``metadata_`` attribute maps to DDL column ``metadata`` via ``name=`` kwarg
  to avoid a clash with SQLAlchemy's ``DeclarativeBase.metadata`` reserved
  attribute.
- ``ignored_at`` / ``ignored_by`` are new enterprise-only audit columns absent
  from the local schema.
- The ``ck_enterprise_duplicate_pairs_distinct_artifacts`` check constraint
  is also new vs. the local schema — it prevents self-referential pair rows.
- Canonical pair ordering (``artifact_a_id < artifact_b_id``) is enforced by
  the application/repository layer, not at DB level.

Tables created
--------------
1. enterprise_duplicate_pairs

Indexes created (B-tree)
------------------------
- idx_enterprise_duplicate_pairs_tenant_id     on (tenant_id)
- idx_enterprise_duplicate_pairs_artifact_a    on (tenant_id, artifact_a_id)
- idx_enterprise_duplicate_pairs_artifact_b    on (tenant_id, artifact_b_id)
- idx_enterprise_duplicate_pairs_ignored       on (tenant_id, ignored)

Downgrade order
---------------
1. Drop indexes (reverse creation order)
2. Drop enterprise_duplicate_pairs

PostgreSQL-only
---------------
This migration is a **no-op on SQLite** (and any other non-PostgreSQL dialect).
The upgrade and downgrade bodies return immediately when
``op.get_bind().dialect.name != "postgresql"``.

No ``PRAGMA foreign_keys`` calls are used in this migration — the entire body
is dialect-guarded for PostgreSQL only, so the PRAGMA-guard invariant
(``is_sqlite()`` guard required around any PRAGMA statement) is satisfied by
omission.
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_025_enterprise_duplicate_pairs"
down_revision: Union[str, None] = "ent_024_enterprise_artifact_parity_columns"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    bind = op.get_bind()
    return bind.dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create enterprise_duplicate_pairs table (PostgreSQL only)."""
    if not _is_postgresql():
        return  # No-op for SQLite and any other non-PostgreSQL dialect

    # ------------------------------------------------------------------
    # 1. enterprise_duplicate_pairs
    # ------------------------------------------------------------------
    op.create_table(
        "enterprise_duplicate_pairs",
        # ------------------------------------------------------------------
        # Identity
        # ------------------------------------------------------------------
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            comment="Globally unique pair record identifier",
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment=(
                "Denormalized tenant scope for query performance and RLS alignment; "
                "every query MUST include WHERE tenant_id = ?"
            ),
        ),
        # ------------------------------------------------------------------
        # Artifact pair foreign keys
        # ------------------------------------------------------------------
        sa.Column(
            "artifact_a_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_artifacts.id",
                ondelete="CASCADE",
                name="fk_enterprise_duplicate_pairs_artifact_a_id",
            ),
            nullable=False,
            comment=(
                "Canonical 'lesser' UUID of the artifact pair; application layer MUST "
                "sort the two artifact UUIDs and assign the lesser to this column before "
                "insert to ensure the unique constraint works as a true pair-uniqueness "
                "guarantee across (a, b) and (b, a) orderings."
            ),
        ),
        sa.Column(
            "artifact_b_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_artifacts.id",
                ondelete="CASCADE",
                name="fk_enterprise_duplicate_pairs_artifact_b_id",
            ),
            nullable=False,
            comment=(
                "Canonical 'greater' UUID of the artifact pair; must satisfy "
                "artifact_b_id > artifact_a_id (enforced by app layer, not DB)."
            ),
        ),
        # ------------------------------------------------------------------
        # Similarity scoring
        # ------------------------------------------------------------------
        sa.Column(
            "similarity_score",
            sa.Float,
            nullable=True,
            comment=(
                "Similarity score in [0.0, 1.0]; NULL when the pair was flagged by an "
                "exact-match rule (e.g. identical content hash) where a numeric score is "
                "redundant.  Validated by ck_enterprise_duplicate_pairs_score."
            ),
        ),
        sa.Column(
            "match_reasons",
            postgresql.JSONB,
            nullable=True,
            comment=(
                "JSONB list of short reason strings explaining why this pair was flagged, "
                "e.g. ['same_content_hash', 'similar_metadata']. NULL when the pipeline "
                "did not record individual reasons."
            ),
        ),
        # ------------------------------------------------------------------
        # Dismissal / ignore state
        # ------------------------------------------------------------------
        sa.Column(
            "ignored",
            sa.Boolean,
            nullable=False,
            server_default=sa.text("false"),
            comment=(
                "True when a user has dismissed this pair as a false positive. "
                "Dismissed pairs are excluded from active deduplication queues."
            ),
        ),
        sa.Column(
            "ignored_at",
            sa.DateTime(timezone=True),
            nullable=True,
            comment="Timezone-aware timestamp when the pair was dismissed; NULL while active.",
        ),
        sa.Column(
            "ignored_by",
            sa.String(255),
            nullable=True,
            comment="User ID of the person who dismissed this pair; NULL while active.",
        ),
        # ------------------------------------------------------------------
        # Open-ended annotations
        # ------------------------------------------------------------------
        sa.Column(
            "metadata",
            postgresql.JSONB,
            nullable=True,
            comment=(
                "Open-ended JSONB dict for pipeline-specific annotations, e.g. "
                "{'pipeline_version': '2.1.0', 'score_method': 'cosine_tfidf', "
                "'cluster_id': 'clus-abc123'}. ORM attribute name is metadata_ to avoid "
                "clash with SQLAlchemy DeclarativeBase.metadata reserved attribute."
            ),
        ),
        # ------------------------------------------------------------------
        # Audit timestamps
        # ------------------------------------------------------------------
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
            comment="Timezone-aware creation timestamp; server-generated.",
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
            comment="Timezone-aware last-modified timestamp; server-generated with onupdate.",
        ),
        # ------------------------------------------------------------------
        # Table-level constraints
        # ------------------------------------------------------------------
        sa.UniqueConstraint(
            "tenant_id",
            "artifact_a_id",
            "artifact_b_id",
            name="uq_enterprise_duplicate_pairs_tenant_pair",
        ),
        sa.CheckConstraint(
            "similarity_score IS NULL OR (similarity_score >= 0.0 AND similarity_score <= 1.0)",
            name="ck_enterprise_duplicate_pairs_score",
        ),
        sa.CheckConstraint(
            "artifact_a_id <> artifact_b_id",
            name="ck_enterprise_duplicate_pairs_distinct_artifacts",
        ),
    )

    # ------------------------------------------------------------------
    # 2. B-tree indexes
    # ------------------------------------------------------------------
    op.create_index(
        "idx_enterprise_duplicate_pairs_tenant_id",
        "enterprise_duplicate_pairs",
        ["tenant_id"],
    )
    op.create_index(
        "idx_enterprise_duplicate_pairs_artifact_a",
        "enterprise_duplicate_pairs",
        ["tenant_id", "artifact_a_id"],
    )
    op.create_index(
        "idx_enterprise_duplicate_pairs_artifact_b",
        "enterprise_duplicate_pairs",
        ["tenant_id", "artifact_b_id"],
    )
    op.create_index(
        "idx_enterprise_duplicate_pairs_ignored",
        "enterprise_duplicate_pairs",
        ["tenant_id", "ignored"],
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop enterprise_duplicate_pairs table and its indexes (PostgreSQL only)."""
    if not _is_postgresql():
        return  # No-op for SQLite and any other non-PostgreSQL dialect

    # Drop indexes in reverse creation order before dropping the table.
    op.drop_index(
        "idx_enterprise_duplicate_pairs_ignored",
        table_name="enterprise_duplicate_pairs",
    )
    op.drop_index(
        "idx_enterprise_duplicate_pairs_artifact_b",
        table_name="enterprise_duplicate_pairs",
    )
    op.drop_index(
        "idx_enterprise_duplicate_pairs_artifact_a",
        table_name="enterprise_duplicate_pairs",
    )
    op.drop_index(
        "idx_enterprise_duplicate_pairs_tenant_id",
        table_name="enterprise_duplicate_pairs",
    )

    op.drop_table("enterprise_duplicate_pairs")
