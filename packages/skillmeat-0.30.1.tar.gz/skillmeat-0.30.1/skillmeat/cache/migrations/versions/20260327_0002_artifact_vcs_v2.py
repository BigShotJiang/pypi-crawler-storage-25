"""Artifact VCS v2: new tables, latest-pointer column, and constraint updates.

Revision ID: 20260327_0002_artifact_vcs_v2
Revises: 20260327_0001_expand_version_history_constraints, 20260326_0003_add_shadowed_from_enterprise_id
Create Date: 2026-03-27 00:02:00.000000+00:00

Overview
--------
This migration implements Phase 1 of the Artifact VCS v2 feature
(tasks VCS2-P1.1 through VCS2-P1.5):

VCS2-P1.4  ``version_sets`` table — logical grouping of related versions with
           a configurable depth limit.

VCS2-P1.1  ``artifact_collection_versions`` table — per-artifact pointer to the
           current collection-side version and its content hash.

VCS2-P1.2  ``project_version_deployments`` table — append-only log of
           content-addressed deployment events per (artifact, project) pair.

VCS2-P1.3  ``artifacts.latest_deployment_id`` nullable FK column — O(1)
           latest-pointer into ``project_version_deployments``.

VCS2-P1.4b ``artifact_versions.version_set_id`` nullable FK column pointing to
           ``version_sets.id``.

VCS2-P1.5  ``artifact_versions`` constraint and column changes:
           (a) Drop the global ``content_hash`` UNIQUE constraint.
           (b) Add composite UNIQUE ``(artifact_id, content_hash)``.
           (c) Drop and recreate ``check_artifact_versions_change_origin``
               with 11 values (was 5 after the previous migration).
           (d) Add nullable columns ``version_label``, ``bom_snapshot_id``,
               ``message``.

SQLite Strategy
---------------
SQLite does not support ``ALTER TABLE … DROP CONSTRAINT``.  All constraint
modifications on existing tables use ``batch_alter_table(recreate="always")``
which performs a full-table rebuild transparently.

For ``artifact_versions`` FK enforcement from child tables is temporarily
disabled (``PRAGMA foreign_keys = OFF/ON``) during the rebuild to prevent
cascading FK-violation errors.

PostgreSQL Strategy
-------------------
PostgreSQL supports native ``ALTER TABLE … DROP CONSTRAINT`` followed by
``ALTER TABLE … ADD CONSTRAINT``.  New columns use ``ALTER TABLE … ADD COLUMN``.

Rollback
--------
``downgrade()`` reverses every operation in reverse order:
- Drop the three new ``artifact_versions`` columns.
- Restore the original ``change_origin`` CHECK (5 values).
- Drop the composite UNIQUE and restore the global UNIQUE on ``content_hash``.
- Drop ``artifacts.latest_deployment_id``.
- Drop ``artifact_versions.version_set_id``.
- Drop ``artifact_collection_versions``.
- Drop ``project_version_deployments``.
- Drop ``version_sets``.

WARNING: rows carrying any of the new ``change_origin`` values, or rows in the
new tables, will prevent a clean downgrade.  Remove them before running
``downgrade()``.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260327_0002_artifact_vcs_v2"
down_revision: Union[str, tuple[str, ...], None] = (
    "20260327_0001_expand_version_history_constraints",
    "20260326_0003_add_shadowed_from_enterprise_id",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ---------------------------------------------------------------------------
# Constraint value strings — single source of truth
# ---------------------------------------------------------------------------

# Full 11-value set (VCS2-P1.5)
_CHANGE_ORIGIN_NEW = (
    "('initial_seed', 'deployment', 'sync', 'local_modification', "
    "'restore', 'promotion', 'push', 'github_update', 'import', "
    "'policy_enforcement', 'composite_update')"
)
# Previous 5-value set (established by migration 20260327_0001)
_CHANGE_ORIGIN_OLD = (
    "('deployment', 'sync', 'local_modification', 'restore', 'promotion')"
)

_CHANGE_ORIGIN_CONSTRAINT = "check_artifact_versions_change_origin"
# Sentinel for idempotency checks — a value present only in the new set.
_SENTINEL_NEW = "'initial_seed'"
_SENTINEL_OLD = "'restore'"  # present in old set but not in the original 3-value set


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _change_origin_already_updated_sqlite(bind: sa.engine.Connection) -> bool:
    result = bind.execute(
        text(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='artifact_versions'"
        ),
    )
    row = result.fetchone()
    if row is None:
        return False
    return "initial_seed" in (row[0] or "")


def _change_origin_already_updated_pg(bind: sa.engine.Connection) -> bool:
    result = bind.execute(
        text("""
            SELECT pg_get_constraintdef(c.oid)
            FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :cname AND t.relname = 'artifact_versions' AND c.contype = 'c'
            """),
        {"cname": _CHANGE_ORIGIN_CONSTRAINT},
    )
    row = result.fetchone()
    if row is None:
        return False
    return "initial_seed" in (row[0] or "")


def _global_unique_exists_sqlite(bind: sa.engine.Connection) -> bool:
    """Return True if artifact_versions still has a global UNIQUE on content_hash (SQLite)."""
    result = bind.execute(
        text(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='artifact_versions'"
        )
    )
    row = result.fetchone()
    if row is None:
        return False
    sql = row[0] or ""
    # The global constraint is defined as UNIQUE on a single column without artifact_id.
    # We check for the index rather than the inline constraint.
    idx_result = bind.execute(
        text(
            "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='artifact_versions' "
            "AND name='idx_artifact_versions_content_hash'"
        )
    )
    return idx_result.fetchone() is not None


def _composite_unique_exists_sqlite(bind: sa.engine.Connection) -> bool:
    idx_result = bind.execute(
        text(
            "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='artifact_versions' "
            "AND name='idx_artifact_versions_artifact_hash'"
        )
    )
    return idx_result.fetchone() is not None


def _column_exists_sqlite(bind: sa.engine.Connection, table: str, column: str) -> bool:
    result = bind.execute(text(f"PRAGMA table_info({table})"))
    return any(row[1] == column for row in result.fetchall())


def _column_exists_pg(bind: sa.engine.Connection, table: str, column: str) -> bool:
    result = bind.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = :t AND column_name = :c"
        ),
        {"t": table, "c": column},
    )
    return result.fetchone() is not None


def _table_exists_pg(bind: sa.engine.Connection, table: str) -> bool:
    result = bind.execute(
        text(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_name = :t AND table_schema = 'public'"
        ),
        {"t": table},
    )
    return result.fetchone() is not None


def _table_exists_sqlite(bind: sa.engine.Connection, table: str) -> bool:
    result = bind.execute(
        text("SELECT 1 FROM sqlite_master WHERE type='table' AND name=:t"),
        {"t": table},
    )
    return result.fetchone() is not None


def _index_exists_pg(bind: sa.engine.Connection, index: str) -> bool:
    result = bind.execute(
        text("SELECT 1 FROM pg_indexes WHERE indexname = :i"),
        {"i": index},
    )
    return result.fetchone() is not None


def _constraint_exists_pg(
    bind: sa.engine.Connection, constraint: str, table: str
) -> bool:
    result = bind.execute(
        text(
            "SELECT 1 FROM pg_constraint c "
            "JOIN pg_class t ON t.oid = c.conrelid "
            "WHERE c.conname = :cname AND t.relname = :tname"
        ),
        {"cname": constraint, "tname": table},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Apply all VCS v2 Phase 1 schema changes."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("artifact_vcs_v2 upgrade: SQLite dialect path.")
        _upgrade_sqlite(bind)
    elif is_postgresql():
        log.info("artifact_vcs_v2 upgrade: PostgreSQL dialect path.")
        _upgrade_postgresql(bind)
    else:
        log.warning(
            "artifact_vcs_v2 upgrade: unknown dialect %r; skipping.", bind.dialect.name
        )


# ---- SQLite upgrade --------------------------------------------------------


def _upgrade_sqlite(bind: sa.engine.Connection) -> None:
    # P1.4: version_sets
    if not _table_exists_sqlite(bind, "version_sets"):
        op.create_table(
            "version_sets",
            sa.Column("id", sa.String(), nullable=False),
            sa.Column("depth_limit", sa.Integer(), nullable=False, server_default="1"),
            sa.Column("created_at", sa.DateTime(), nullable=False),
            sa.PrimaryKeyConstraint("id"),
        )
        log.info("artifact_vcs_v2 (SQLite): created version_sets.")

    # P1.1: artifact_collection_versions
    if not _table_exists_sqlite(bind, "artifact_collection_versions"):
        op.create_table(
            "artifact_collection_versions",
            sa.Column("id", sa.String(), nullable=False),
            sa.Column("artifact_id", sa.String(), nullable=False),
            sa.Column("version_id", sa.String(), nullable=False),
            sa.Column("current_hash", sa.String(), nullable=False),
            sa.Column("updated_at", sa.DateTime(), nullable=False),
            sa.ForeignKeyConstraint(
                ["artifact_id"], ["artifacts.id"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["version_id"], ["artifact_versions.id"], ondelete="RESTRICT"
            ),
            sa.PrimaryKeyConstraint("id"),
            sa.UniqueConstraint("artifact_id", name="uq_acv_artifact_id"),
        )
        op.create_index(
            "idx_acv_artifact_id",
            "artifact_collection_versions",
            ["artifact_id"],
            unique=True,
        )
        op.create_index(
            "idx_acv_version_id", "artifact_collection_versions", ["version_id"]
        )
        log.info("artifact_vcs_v2 (SQLite): created artifact_collection_versions.")

    # P1.2: project_version_deployments
    if not _table_exists_sqlite(bind, "project_version_deployments"):
        op.create_table(
            "project_version_deployments",
            sa.Column("id", sa.String(), nullable=False),
            sa.Column("artifact_id", sa.String(), nullable=False),
            sa.Column("project_id", sa.String(), nullable=False),
            sa.Column("content_hash", sa.String(), nullable=False),
            sa.Column("pinned", sa.Boolean(), nullable=False, server_default="0"),
            sa.Column("deployed_at", sa.DateTime(), nullable=False),
            sa.Column("updated_at", sa.DateTime(), nullable=False),
            sa.ForeignKeyConstraint(
                ["artifact_id"], ["artifacts.id"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["project_id"], ["projects.id"], ondelete="CASCADE"
            ),
            sa.PrimaryKeyConstraint("id"),
        )
        op.create_index(
            "ix_pvd_artifact_project",
            "project_version_deployments",
            ["artifact_id", "project_id"],
        )
        op.create_index(
            "ix_pvd_deployed_at_desc", "project_version_deployments", ["deployed_at"]
        )
        log.info("artifact_vcs_v2 (SQLite): created project_version_deployments.")

    # P1.3: artifacts.latest_deployment_id
    if not _column_exists_sqlite(bind, "artifacts", "latest_deployment_id"):
        op.add_column(
            "artifacts",
            sa.Column("latest_deployment_id", sa.String(), nullable=True),
        )
        log.info("artifact_vcs_v2 (SQLite): added artifacts.latest_deployment_id.")

    # P1.4b + P1.5a/b/c/d: Rebuild artifact_versions with new columns, updated
    # CHECK constraint, and composite unique.  version_set_id is included here
    # (not in a separate step) to avoid a partial-state FK that references
    # version_sets before the rebuild is done.
    op.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        _upgrade_artifact_versions_sqlite(bind)
    finally:
        op.execute(text("PRAGMA foreign_keys = ON"))

    # P1.5b: composite unique index (created inside the raw-SQL rebuild above)
    # Drop the old global unique index if the raw-SQL rebuild didn't remove it.
    try:
        op.drop_index(
            "idx_artifact_versions_content_hash", table_name="artifact_versions"
        )
    except Exception:
        pass  # Already removed by the table rebuild


def _upgrade_artifact_versions_sqlite(bind: sa.engine.Connection) -> None:
    """Rebuild artifact_versions with updated constraints and new columns (SQLite).

    Uses raw SQL CREATE/INSERT/DROP/RENAME rather than batch_alter_table so that
    we have full control over the target schema regardless of how the constraint
    was embedded in the source table's CREATE TABLE text.
    """
    already_updated = _change_origin_already_updated_sqlite(bind)
    composite_exists = _composite_unique_exists_sqlite(bind)
    has_version_label = _column_exists_sqlite(
        bind, "artifact_versions", "version_label"
    )

    if already_updated and composite_exists and has_version_label:
        log.info(
            "artifact_vcs_v2 (SQLite): artifact_versions already fully updated; skipping."
        )
        return

    # Determine which extra columns exist — used to build the INSERT SELECT list.
    has_vsid = _column_exists_sqlite(bind, "artifact_versions", "version_set_id")

    bind.execute(text(f"""
        CREATE TABLE _av_upgrade_tmp (
            id VARCHAR NOT NULL,
            artifact_id VARCHAR NOT NULL,
            content_hash VARCHAR NOT NULL,
            parent_hash VARCHAR,
            change_origin VARCHAR NOT NULL,
            version_lineage TEXT,
            version_label VARCHAR(100),
            bom_snapshot_id VARCHAR(100),
            message TEXT,
            version_set_id VARCHAR,
            created_at DATETIME NOT NULL,
            metadata TEXT,
            PRIMARY KEY (id),
            CONSTRAINT {_CHANGE_ORIGIN_CONSTRAINT}
                CHECK (change_origin IN {_CHANGE_ORIGIN_NEW}),
            FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE CASCADE,
            FOREIGN KEY(version_set_id) REFERENCES version_sets (id) ON DELETE SET NULL
        )
    """))

    # Determine which of the source columns exist for the INSERT SELECT.
    # version_set_id may have been added in a prior partial run.
    all_possible_src_cols = [
        "id",
        "artifact_id",
        "content_hash",
        "parent_hash",
        "change_origin",
        "version_lineage",
        "created_at",
        "metadata",
        "version_set_id",
    ]
    cols_present = {
        row[1]
        for row in bind.execute(text("PRAGMA table_info(artifact_versions)")).fetchall()
    }
    src_cols = [c for c in all_possible_src_cols if c in cols_present]
    dst_cols = src_cols  # same names; new cols default to NULL

    src_list = ", ".join(src_cols)
    dst_list = ", ".join(dst_cols)

    bind.execute(
        text(
            f"INSERT INTO _av_upgrade_tmp ({dst_list}) SELECT {src_list} FROM artifact_versions"
        )
    )

    bind.execute(text("DROP TABLE artifact_versions"))
    bind.execute(text("ALTER TABLE _av_upgrade_tmp RENAME TO artifact_versions"))

    # Recreate indexes (including composite unique replacing the old global unique)
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_artifact_id ON artifact_versions (artifact_id)"
        )
    )
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_parent_hash ON artifact_versions (parent_hash)"
        )
    )
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_artifact_created ON artifact_versions (artifact_id, created_at)"
        )
    )
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_change_origin ON artifact_versions (change_origin)"
        )
    )
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_version_set_id ON artifact_versions (version_set_id)"
        )
    )
    bind.execute(
        text(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_artifact_versions_artifact_hash ON artifact_versions (artifact_id, content_hash)"
        )
    )

    log.info("artifact_vcs_v2 (SQLite): artifact_versions rebuilt with VCS v2 schema.")


# ---- PostgreSQL upgrade ----------------------------------------------------


def _upgrade_postgresql(bind: sa.engine.Connection) -> None:
    # Detect enterprise schema: enterprise tables use UUID PKs with different names
    _is_enterprise = _table_exists_pg(bind, "enterprise_artifacts")
    _artifacts_table = "enterprise_artifacts" if _is_enterprise else "artifacts"
    _projects_table = "enterprise_projects" if _is_enterprise else "projects"

    # P1.4: version_sets
    if not _table_exists_pg(bind, "version_sets"):
        op.create_table(
            "version_sets",
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                server_default=sa.text("gen_random_uuid()"),
                nullable=False,
            ),
            sa.Column("depth_limit", sa.Integer(), nullable=False, server_default="1"),
            sa.Column("created_at", sa.DateTime(), nullable=False),
            sa.PrimaryKeyConstraint("id"),
        )
        log.info("artifact_vcs_v2 (PG): created version_sets.")

    # P1.1: artifact_collection_versions
    if not _table_exists_pg(bind, "artifact_collection_versions"):
        op.create_table(
            "artifact_collection_versions",
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                server_default=sa.text("gen_random_uuid()"),
                nullable=False,
            ),
            sa.Column("artifact_id", postgresql.UUID(as_uuid=True), nullable=False),
            sa.Column("version_id", postgresql.UUID(as_uuid=True), nullable=False),
            sa.Column("current_hash", sa.String(), nullable=False),
            sa.Column("updated_at", sa.DateTime(), nullable=False),
            sa.ForeignKeyConstraint(
                ["artifact_id"], [f"{_artifacts_table}.id"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["version_id"], ["artifact_versions.id"], ondelete="RESTRICT"
            ),
            sa.PrimaryKeyConstraint("id"),
            sa.UniqueConstraint("artifact_id", name="uq_acv_artifact_id"),
        )
        op.create_index(
            "idx_acv_artifact_id",
            "artifact_collection_versions",
            ["artifact_id"],
            unique=True,
        )
        op.create_index(
            "idx_acv_version_id", "artifact_collection_versions", ["version_id"]
        )
        log.info("artifact_vcs_v2 (PG): created artifact_collection_versions.")

    # P1.2: project_version_deployments
    if not _table_exists_pg(bind, "project_version_deployments"):
        op.create_table(
            "project_version_deployments",
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                server_default=sa.text("gen_random_uuid()"),
                nullable=False,
            ),
            sa.Column("artifact_id", postgresql.UUID(as_uuid=True), nullable=False),
            sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=False),
            sa.Column("content_hash", sa.String(), nullable=False),
            sa.Column("pinned", sa.Boolean(), nullable=False, server_default="false"),
            sa.Column("deployed_at", sa.DateTime(), nullable=False),
            sa.Column("updated_at", sa.DateTime(), nullable=False),
            sa.ForeignKeyConstraint(
                ["artifact_id"], [f"{_artifacts_table}.id"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["project_id"], [f"{_projects_table}.id"], ondelete="CASCADE"
            ),
            sa.PrimaryKeyConstraint("id"),
        )
        op.create_index(
            "ix_pvd_artifact_project",
            "project_version_deployments",
            ["artifact_id", "project_id"],
        )
        op.create_index(
            "ix_pvd_deployed_at_desc", "project_version_deployments", ["deployed_at"]
        )
        log.info("artifact_vcs_v2 (PG): created project_version_deployments.")

    # P1.4b: artifact_versions.version_set_id
    if not _column_exists_pg(bind, "artifact_versions", "version_set_id"):
        op.add_column(
            "artifact_versions",
            sa.Column("version_set_id", postgresql.UUID(as_uuid=True), nullable=True),
        )
        op.create_foreign_key(
            "fk_av_version_set_id",
            "artifact_versions",
            "version_sets",
            ["version_set_id"],
            ["id"],
            ondelete="SET NULL",
        )
        if not _index_exists_pg(bind, "idx_artifact_versions_version_set_id"):
            op.create_index(
                "idx_artifact_versions_version_set_id",
                "artifact_versions",
                ["version_set_id"],
            )
        log.info("artifact_vcs_v2 (PG): added artifact_versions.version_set_id.")

    # P1.3: artifacts.latest_deployment_id
    # In enterprise mode, _artifacts_table is "enterprise_artifacts" — add to both
    # tables so the ORM Artifact model (which maps to "artifacts") can read it too.
    for _tbl in ([_artifacts_table, "artifacts"] if _is_enterprise else [_artifacts_table]):
        if not _column_exists_pg(bind, _tbl, "latest_deployment_id"):
            _col_type = postgresql.UUID(as_uuid=True) if _tbl == "enterprise_artifacts" else sa.String()
            op.add_column(
                _tbl,
                sa.Column("latest_deployment_id", _col_type, nullable=True),
            )
            _fk_name = f"fk_{_tbl}_latest_deployment_id"
            if _tbl != "artifacts":
                # Only add FK on enterprise_artifacts — artifacts table uses string IDs
                # and project_version_deployments uses UUID PKs in enterprise mode.
                op.create_foreign_key(
                    _fk_name,
                    _tbl,
                    "project_version_deployments",
                    ["latest_deployment_id"],
                    ["id"],
                    ondelete="SET NULL",
                )
            log.info("artifact_vcs_v2 (PG): added %s.latest_deployment_id.", _tbl)

    # P1.5a-c: constraint/index changes on artifact_versions columns that only
    # exist in the local schema (change_origin, content_hash unique).  Enterprise
    # artifact_versions has a different column set — skip these operations.
    if not _is_enterprise:
        # P1.5a: drop global unique index on content_hash
        if _index_exists_pg(bind, "idx_artifact_versions_content_hash"):
            op.drop_index(
                "idx_artifact_versions_content_hash", table_name="artifact_versions"
            )
            log.info(
                "artifact_vcs_v2 (PG): dropped global unique index on content_hash."
            )

        # P1.5b: composite unique (artifact_id, content_hash)
        if not _index_exists_pg(bind, "idx_artifact_versions_artifact_hash"):
            op.create_index(
                "idx_artifact_versions_artifact_hash",
                "artifact_versions",
                ["artifact_id", "content_hash"],
                unique=True,
            )
            log.info(
                "artifact_vcs_v2 (PG): created composite unique idx on (artifact_id, content_hash)."
            )

        # P1.5c: extend change_origin CHECK constraint
        if not _change_origin_already_updated_pg(bind):
            if _constraint_exists_pg(
                bind, _CHANGE_ORIGIN_CONSTRAINT, "artifact_versions"
            ):
                op.execute(
                    text(
                        f"ALTER TABLE artifact_versions DROP CONSTRAINT {_CHANGE_ORIGIN_CONSTRAINT}"
                    )
                )
            op.execute(
                text(
                    f"ALTER TABLE artifact_versions ADD CONSTRAINT {_CHANGE_ORIGIN_CONSTRAINT} "
                    f"CHECK (change_origin IN {_CHANGE_ORIGIN_NEW})"
                )
            )
            log.info("artifact_vcs_v2 (PG): extended change_origin CHECK constraint.")
    else:
        log.info(
            "artifact_vcs_v2 (PG): skipping P1.5a-c (enterprise schema has different constraints)."
        )

    # P1.5d: new nullable columns on artifact_versions
    for col_name, col_def in [
        ("version_label", sa.Column("version_label", sa.String(100), nullable=True)),
        (
            "bom_snapshot_id",
            sa.Column("bom_snapshot_id", sa.String(100), nullable=True),
        ),
        ("message", sa.Column("message", sa.Text(), nullable=True)),
    ]:
        if not _column_exists_pg(bind, "artifact_versions", col_name):
            op.add_column("artifact_versions", col_def)
            log.info("artifact_vcs_v2 (PG): added artifact_versions.%s.", col_name)


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Reverse all VCS v2 Phase 1 schema changes."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("artifact_vcs_v2 downgrade: SQLite dialect path.")
        _downgrade_sqlite(bind)
    elif is_postgresql():
        log.info("artifact_vcs_v2 downgrade: PostgreSQL dialect path.")
        _downgrade_postgresql(bind)
    else:
        log.warning(
            "artifact_vcs_v2 downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


# ---- SQLite downgrade ------------------------------------------------------


def _downgrade_sqlite(bind: sa.engine.Connection) -> None:
    # SQLite does not support DROP COLUMN/CONSTRAINT natively.
    # Strategy: disable FK enforcement, do a full artifact_versions table
    # rebuild using a hand-crafted copy_from table that omits the new columns
    # and uses the old constraint set.  Then drop new tables in dependency order.

    op.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        # Rebuild artifact_versions without the new VCS v2 columns and with the
        # old 5-value change_origin CHECK constraint.
        # We pass `copy_from` with a hand-crafted Table so that Alembic copies
        # only the columns that existed before this migration.
        _rebuild_artifact_versions_downgrade_sqlite(bind)
    finally:
        op.execute(text("PRAGMA foreign_keys = ON"))

    # Restore global unique index (was dropped in upgrade)
    op.create_index(
        "idx_artifact_versions_content_hash",
        "artifact_versions",
        ["content_hash"],
        unique=True,
    )

    # Reverse P1.3: artifacts.latest_deployment_id
    if _column_exists_sqlite(bind, "artifacts", "latest_deployment_id"):
        op.execute(text("PRAGMA foreign_keys = OFF"))
        try:
            with op.batch_alter_table("artifacts") as batch_op:
                batch_op.drop_column("latest_deployment_id")
        finally:
            op.execute(text("PRAGMA foreign_keys = ON"))

    # Reverse P1.1 / P1.2 / P1.4 — drop in FK-dependency order
    for table in (
        "artifact_collection_versions",
        "project_version_deployments",
        "version_sets",
    ):
        if _table_exists_sqlite(bind, table):
            op.drop_table(table)


def _rebuild_artifact_versions_downgrade_sqlite(bind: sa.engine.Connection) -> None:
    """Rebuild artifact_versions table to its pre-VCS-v2 schema (SQLite).

    This performs a manual CREATE + copy + rename sequence equivalent to what
    batch_alter_table(recreate="always") would do, but using an explicit table
    definition rather than ORM reflection so we don't accidentally include the
    new VCS v2 columns or indexes in the target schema.
    """
    # Determine which pre-existing columns are present (guard for idempotency).
    cols_present = {
        row[1]
        for row in bind.execute(text("PRAGMA table_info(artifact_versions)")).fetchall()
    }
    old_cols = [
        c
        for c in (
            "id",
            "artifact_id",
            "content_hash",
            "parent_hash",
            "change_origin",
            "version_lineage",
            "created_at",
            "metadata",
        )
        if c in cols_present
    ]
    col_list = ", ".join(old_cols)

    # 1. Create replacement table
    bind.execute(text(f"""
        CREATE TABLE _av_downgrade_tmp (
            id VARCHAR NOT NULL,
            artifact_id VARCHAR NOT NULL,
            content_hash VARCHAR NOT NULL,
            parent_hash VARCHAR,
            change_origin VARCHAR NOT NULL,
            version_lineage TEXT,
            created_at DATETIME NOT NULL,
            metadata TEXT,
            PRIMARY KEY (id),
            CONSTRAINT {_CHANGE_ORIGIN_CONSTRAINT}
                CHECK (change_origin IN {_CHANGE_ORIGIN_OLD}),
            FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE CASCADE,
            UNIQUE (content_hash)
        )
    """))

    # 2. Copy rows (exclude new columns via explicit column list)
    bind.execute(
        text(
            f"INSERT INTO _av_downgrade_tmp ({col_list}) SELECT {col_list} FROM artifact_versions"
        )
    )

    # 3. Drop old table
    bind.execute(text("DROP TABLE artifact_versions"))

    # 4. Rename
    bind.execute(text("ALTER TABLE _av_downgrade_tmp RENAME TO artifact_versions"))

    # 5. Recreate pre-existing indexes (minus the composite unique and version_set idx)
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_artifact_id ON artifact_versions (artifact_id)"
        )
    )
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_parent_hash ON artifact_versions (parent_hash)"
        )
    )
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_artifact_created ON artifact_versions (artifact_id, created_at)"
        )
    )
    bind.execute(
        text(
            "CREATE INDEX IF NOT EXISTS idx_artifact_versions_change_origin ON artifact_versions (change_origin)"
        )
    )
    log.info(
        "artifact_vcs_v2 (SQLite): artifact_versions rebuilt to pre-VCS-v2 schema."
    )


# ---- PostgreSQL downgrade --------------------------------------------------


def _downgrade_postgresql(bind: sa.engine.Connection) -> None:
    _is_enterprise = _table_exists_pg(bind, "enterprise_artifacts")
    _artifacts_table = "enterprise_artifacts" if _is_enterprise else "artifacts"

    # Reverse P1.5d: drop new columns
    for col_name in ("version_label", "bom_snapshot_id", "message"):
        if _column_exists_pg(bind, "artifact_versions", col_name):
            op.drop_column("artifact_versions", col_name)

    # Reverse P1.5c: restore old change_origin CHECK
    if _constraint_exists_pg(bind, _CHANGE_ORIGIN_CONSTRAINT, "artifact_versions"):
        op.execute(
            text(
                f"ALTER TABLE artifact_versions DROP CONSTRAINT {_CHANGE_ORIGIN_CONSTRAINT}"
            )
        )
    op.execute(
        text(
            f"ALTER TABLE artifact_versions ADD CONSTRAINT {_CHANGE_ORIGIN_CONSTRAINT} "
            f"CHECK (change_origin IN {_CHANGE_ORIGIN_OLD})"
        )
    )

    # Reverse P1.5b: drop composite unique
    if _index_exists_pg(bind, "idx_artifact_versions_artifact_hash"):
        op.drop_index(
            "idx_artifact_versions_artifact_hash", table_name="artifact_versions"
        )

    # Reverse P1.5a: restore global unique on content_hash
    if not _index_exists_pg(bind, "idx_artifact_versions_content_hash"):
        op.create_index(
            "idx_artifact_versions_content_hash",
            "artifact_versions",
            ["content_hash"],
            unique=True,
        )

    # Reverse P1.4b: artifact_versions.version_set_id
    if _column_exists_pg(bind, "artifact_versions", "version_set_id"):
        if _index_exists_pg(bind, "idx_artifact_versions_version_set_id"):
            op.drop_index(
                "idx_artifact_versions_version_set_id", table_name="artifact_versions"
            )
        if _constraint_exists_pg(bind, "fk_av_version_set_id", "artifact_versions"):
            op.drop_constraint(
                "fk_av_version_set_id", "artifact_versions", type_="foreignkey"
            )
        op.drop_column("artifact_versions", "version_set_id")

    # Reverse P1.3: latest_deployment_id on artifacts table
    if _column_exists_pg(bind, _artifacts_table, "latest_deployment_id"):
        if _constraint_exists_pg(
            bind, "fk_artifacts_latest_deployment_id", _artifacts_table
        ):
            op.drop_constraint(
                "fk_artifacts_latest_deployment_id",
                _artifacts_table,
                type_="foreignkey",
            )
        op.drop_column(_artifacts_table, "latest_deployment_id")

    # Reverse P1.1 / P1.2 / P1.4
    for table in (
        "artifact_collection_versions",
        "project_version_deployments",
        "version_sets",
    ):
        if _table_exists_pg(bind, table):
            op.drop_table(table)
