"""Add enterprise_scaffold_templates table.

Revision ID: ent_027_enterprise_scaffold_templates
Revises: ent_026_ahe_schema_gap_fill
Create Date: 2026-04-07 00:00:00.000000+00:00

Background
----------
enterprise-stub-promotion-v1 TASK-3.1 promotes the scaffold-templates router
from a hard 501-gate to a fully enterprise-aware implementation.  This
migration creates the ``enterprise_scaffold_templates`` table that backs the
:class:`~skillmeat.cache.models_enterprise.EnterpriseScaffoldTemplate` ORM
model.

Table Created
-------------
``enterprise_scaffold_templates`` — Backstage scaffold template configuration
scoped to a tenant, with a 1-to-1 mapping to an enterprise bundle entity.

Key design choices
------------------
- UUID primary key (server-generated via gen_random_uuid()).
- ``tenant_id UUID NOT NULL`` — required on every query (tenant isolation).
- ``bundle_id TEXT NOT NULL`` — FK to enterprise_bundle_entities.id; the
  column is TEXT (not UUID) so the constraint holds even when the bundle
  entity UUID is rendered as a hex string by the application layer.
- JSONB columns for variable contracts, tag lists, and generation history so
  the schema stays stable as scaffold configuration evolves.
- UNIQUE (tenant_id, bundle_id) enforces the 1-to-1 relationship per tenant.

PostgreSQL-only
---------------
This migration is a **no-op on SQLite** (and any other non-PostgreSQL
dialect).  The scaffold-templates feature in enterprise mode requires
PostgreSQL; the equivalent SQLite table is managed by the local migration
``20260318_0001_add_scaffold_templates_table``.

No PRAGMA statements are used.  The is_sqlite() invariant is satisfied by
omission — we never enter the non-PostgreSQL branch for a migration that
only targets enterprise tables.

Downgrade
---------
Drops indexes first, then the table.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_027_enterprise_scaffold_templates"
down_revision: Union[str, None] = "ent_026_ahe_schema_gap_fill"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

log = logging.getLogger("alembic.runtime.migration")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TABLE = "enterprise_scaffold_templates"

# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when running against a PostgreSQL database."""
    bind = op.get_bind()
    return bind.dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helper
# ---------------------------------------------------------------------------


def _table_exists(bind: sa.engine.Connection) -> bool:
    """Return True if enterprise_scaffold_templates already exists."""
    result = bind.execute(
        text(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_name = :t"
        ),
        {"t": _TABLE},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create enterprise_scaffold_templates table (PostgreSQL only)."""
    if not _is_postgresql():
        log.info("upgrade: non-PostgreSQL dialect — skipping %s creation", _TABLE)
        return

    bind = op.get_bind()
    if _table_exists(bind):
        log.info("upgrade: %s already exists — skipping creation", _TABLE)
        return

    op.create_table(
        _TABLE,
        # Primary key
        sa.Column(
            "id",
            sa.dialects.postgresql.UUID(as_uuid=False),
            nullable=False,
            server_default=text("gen_random_uuid()"),
            comment="Primary key; server-generated UUID",
        ),
        # Tenant scope
        sa.Column(
            "tenant_id",
            sa.dialects.postgresql.UUID(as_uuid=False),
            nullable=False,
            comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
        ),
        # Bundle association (1-to-1 within tenant)
        sa.Column(
            "bundle_id",
            sa.dialects.postgresql.UUID(as_uuid=False),
            nullable=False,
            comment="FK to enterprise_bundle_entities.id; unique within tenant",
        ),
        # Activation flag
        sa.Column(
            "enabled",
            sa.Boolean(),
            nullable=False,
            server_default=text("true"),
            comment="Whether this template participates in Backstage catalog sync",
        ),
        # Variable contract
        sa.Column(
            "required_variables",
            sa.dialects.postgresql.JSONB(),
            nullable=True,
            comment="JSONB list of required variable name strings",
        ),
        sa.Column(
            "variable_type_map",
            sa.dialects.postgresql.JSONB(),
            nullable=True,
            comment="JSONB dict mapping variable names to Backstage UI field types",
        ),
        # Skeleton source
        sa.Column(
            "skeleton_ref",
            sa.Text(),
            nullable=True,
            comment="GitHub URL for the fetch:template step in template.yaml",
        ),
        # Backstage metadata
        sa.Column(
            "backstage_owner",
            sa.Text(),
            nullable=True,
            comment="Backstage spec.owner entity ref",
        ),
        sa.Column(
            "backstage_type",
            sa.Text(),
            nullable=False,
            server_default=text("'service'"),
            comment="Backstage template type: service, website, or library",
        ),
        sa.Column(
            "backstage_tags",
            sa.dialects.postgresql.JSONB(),
            nullable=True,
            comment="JSONB list of tag strings for the Backstage template spec",
        ),
        # Generation tracking
        sa.Column(
            "bundle_version_at_last_generation",
            sa.Text(),
            nullable=True,
            comment="Bundle version string at the time of the last template generation",
        ),
        sa.Column(
            "generation_history",
            sa.dialects.postgresql.JSONB(),
            nullable=True,
            comment="JSONB list of generation event dicts, capped at 20 by service layer",
        ),
        # Timestamps
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=text("now()"),
            comment="Immutable creation timestamp; server-generated",
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=text("now()"),
            comment="Timezone-aware last-modified timestamp; updated by app on every write",
        ),
        # Constraints
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["bundle_id"],
            ["enterprise_bundle_entities.id"],
            name="fk_ent_scaffold_templates_bundle_id",
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "bundle_id",
            name="uq_ent_scaffold_templates_tenant_bundle",
        ),
    )

    # Indexes
    op.create_index(
        "idx_ent_scaffold_templates_tenant",
        _TABLE,
        ["tenant_id"],
    )
    op.create_index(
        "idx_ent_scaffold_templates_tenant_enabled",
        _TABLE,
        ["tenant_id", "enabled"],
    )

    log.info("upgrade: created %s with indexes", _TABLE)


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop enterprise_scaffold_templates table (PostgreSQL only)."""
    if not _is_postgresql():
        log.info("downgrade: non-PostgreSQL dialect — skipping %s drop", _TABLE)
        return

    bind = op.get_bind()
    if not _table_exists(bind):
        log.info("downgrade: %s does not exist — skipping drop", _TABLE)
        return

    op.drop_index("idx_ent_scaffold_templates_tenant_enabled", table_name=_TABLE)
    op.drop_index("idx_ent_scaffold_templates_tenant", table_name=_TABLE)
    op.drop_table(_TABLE)

    log.info("downgrade: dropped %s", _TABLE)
