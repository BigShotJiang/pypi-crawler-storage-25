"""Add missing columns to enterprise_marketplace_sources (enterprise).

Revision ID: ent_011_enterprise_marketplace_source_columns
Revises: ent_010_version_scopes_and_history_tenant
Create Date: 2026-03-30 00:00:00.000000+00:00

Background
----------
Enterprise-PostgreSQL-only migration.  This migration is a no-op on any
non-PostgreSQL dialect.

The ``enterprise_marketplace_sources`` table was created with only the basic
identifying columns (id, tenant_id, repo_url, name, etc.).  The local
``marketplace_sources`` table carries 17 additional columns that were never
backfilled into the enterprise schema.  This migration adds the missing
columns so that the enterprise and local schemas are structurally equivalent
for the marketplace source domain.

Changes
-------
Adds the following 17 columns to ``enterprise_marketplace_sources``:

    root_hint                       TEXT        NULL
    manual_map                      TEXT        NULL
    single_artifact_mode            BOOLEAN     NOT NULL DEFAULT false
    single_artifact_type            TEXT        NULL
    trust_level                     TEXT        NULL
    visibility                      TEXT        NULL
    last_error                      TEXT        NULL
    description                     TEXT        NULL
    notes                           TEXT        NULL
    enable_frontmatter_detection    BOOLEAN     NOT NULL DEFAULT false
    repo_description                TEXT        NULL
    repo_readme                     TEXT        NULL
    indexing_enabled                BOOLEAN     NULL
    deep_indexing_enabled           BOOLEAN     NOT NULL DEFAULT false
    path_tag_config                 TEXT        NULL
    counts_by_type                  TEXT        NULL
    tags                            TEXT        NULL

All additions are idempotent: each column is only added when it does not
already exist on the table.

Downgrade
---------
Drops all 17 columns in the reverse order they were added.  Only columns
that exist at downgrade time are dropped.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_011_enterprise_marketplace_source_columns"
down_revision: Union[str, Sequence[str], None] = (
    "ent_010_version_scopes_and_history_tenant"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TABLE = "enterprise_marketplace_sources"

# Ordered list of (column_name, Column definition) for upgrade; reversed for
# downgrade.  Boolean NOT NULL columns carry a server_default so that the ADD
# COLUMN statement satisfies the NOT NULL constraint for any pre-existing rows.
_COLUMNS: list[tuple[str, sa.Column]] = [
    (
        "root_hint",
        sa.Column(
            "root_hint",
            sa.Text(),
            nullable=True,
            comment="Optional root path hint used to narrow artifact discovery within the repository",
        ),
    ),
    (
        "manual_map",
        sa.Column(
            "manual_map",
            sa.Text(),
            nullable=True,
            comment="JSON-serialised manual path-to-artifact-type mapping overrides",
        ),
    ),
    (
        "single_artifact_mode",
        sa.Column(
            "single_artifact_mode",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("false"),
            comment="When true the entire repository is treated as a single artifact",
        ),
    ),
    (
        "single_artifact_type",
        sa.Column(
            "single_artifact_type",
            sa.Text(),
            nullable=True,
            comment="Artifact type to use when single_artifact_mode is true",
        ),
    ),
    (
        "trust_level",
        sa.Column(
            "trust_level",
            sa.Text(),
            nullable=True,
            comment="Trust tier for artifacts originating from this source (e.g. 'verified', 'community')",
        ),
    ),
    (
        "visibility",
        sa.Column(
            "visibility",
            sa.Text(),
            nullable=True,
            comment="Visibility scope of the source (e.g. 'public', 'internal', 'private')",
        ),
    ),
    (
        "last_error",
        sa.Column(
            "last_error",
            sa.Text(),
            nullable=True,
            comment="Most recent error message from indexing or sync operations; NULL when healthy",
        ),
    ),
    (
        "description",
        sa.Column(
            "description",
            sa.Text(),
            nullable=True,
            comment="Human-readable description of the marketplace source",
        ),
    ),
    (
        "notes",
        sa.Column(
            "notes",
            sa.Text(),
            nullable=True,
            comment="Free-form operator notes attached to the source record",
        ),
    ),
    (
        "enable_frontmatter_detection",
        sa.Column(
            "enable_frontmatter_detection",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("false"),
            comment="Enable YAML/TOML frontmatter parsing during artifact indexing",
        ),
    ),
    (
        "repo_description",
        sa.Column(
            "repo_description",
            sa.Text(),
            nullable=True,
            comment="Repository description fetched from the upstream VCS provider",
        ),
    ),
    (
        "repo_readme",
        sa.Column(
            "repo_readme",
            sa.Text(),
            nullable=True,
            comment="Raw README content fetched from the upstream VCS provider",
        ),
    ),
    (
        "indexing_enabled",
        sa.Column(
            "indexing_enabled",
            sa.Boolean(),
            nullable=True,
            comment="Whether scheduled indexing is enabled for this source; NULL means unset (inherits default)",
        ),
    ),
    (
        "deep_indexing_enabled",
        sa.Column(
            "deep_indexing_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("false"),
            comment="Enable deep content inspection during indexing (slower but more accurate)",
        ),
    ),
    (
        "path_tag_config",
        sa.Column(
            "path_tag_config",
            sa.Text(),
            nullable=True,
            comment="JSON-serialised configuration mapping repository path prefixes to tags",
        ),
    ),
    (
        "counts_by_type",
        sa.Column(
            "counts_by_type",
            sa.Text(),
            nullable=True,
            comment="JSON-serialised artifact-type-to-count map; refreshed after each indexing run",
        ),
    ),
    (
        "tags",
        sa.Column(
            "tags",
            sa.Text(),
            nullable=True,
            comment="JSON-serialised list of tags associated with this source",
        ),
    ),
]


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(
    bind: sa.engine.Connection, table_name: str, column_name: str
) -> bool:
    """Return True if *column_name* already exists on *table_name* (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.columns
            WHERE table_name = :tname
              AND column_name = :cname
            """),
        {"tname": table_name, "cname": column_name},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add 17 missing columns to enterprise_marketplace_sources."""
    if not _is_postgresql():
        log.info(
            "ent_011_enterprise_marketplace_source_columns: non-PostgreSQL dialect detected; "
            "skipping enterprise-only migration."
        )
        return

    log.info(
        "ent_011_enterprise_marketplace_source_columns upgrade: running PostgreSQL path."
    )

    bind = op.get_bind()
    added: list[str] = []
    skipped: list[str] = []

    for col_name, col_def in _COLUMNS:
        if _column_exists(bind, _TABLE, col_name):
            skipped.append(col_name)
            log.debug(
                "ent_011: column %s already exists on %s; skipping.", col_name, _TABLE
            )
        else:
            op.add_column(_TABLE, col_def)
            added.append(col_name)

    log.info(
        "ent_011 upgrade complete: added %d column(s) to %s (%s); "
        "skipped %d already-present column(s) (%s).",
        len(added),
        _TABLE,
        ", ".join(added) if added else "none",
        len(skipped),
        ", ".join(skipped) if skipped else "none",
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop the 17 columns added to enterprise_marketplace_sources.

    WARNING: dropping these columns is destructive and cannot be undone without
    re-running the upgrade.  Ensure the data stored in these columns has been
    backed up or is no longer needed before running this downgrade.
    """
    if not _is_postgresql():
        log.info(
            "ent_011_enterprise_marketplace_source_columns downgrade: "
            "non-PostgreSQL dialect detected; skipping."
        )
        return

    log.info(
        "ent_011_enterprise_marketplace_source_columns downgrade: running PostgreSQL path."
    )

    bind = op.get_bind()
    dropped: list[str] = []
    skipped: list[str] = []

    # Drop in reverse order to mirror the upgrade sequence.
    for col_name, _col_def in reversed(_COLUMNS):
        if _column_exists(bind, _TABLE, col_name):
            op.drop_column(_TABLE, col_name)
            dropped.append(col_name)
        else:
            skipped.append(col_name)
            log.debug(
                "ent_011 downgrade: column %s not found on %s; skipping drop.",
                col_name,
                _TABLE,
            )

    log.info(
        "ent_011 downgrade complete: dropped %d column(s) from %s (%s); "
        "skipped %d missing column(s) (%s).",
        len(dropped),
        _TABLE,
        ", ".join(dropped) if dropped else "none",
        len(skipped),
        ", ".join(skipped) if skipped else "none",
    )
