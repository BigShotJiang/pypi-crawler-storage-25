"""Add git_repo_connections table for Git Repo Connector feature (GRC-DB-001).

Revision ID: 20260330_0002_add_git_repo_connections
Revises: 20260330_0001_merge_grc_heads
Create Date: 2026-03-30 00:02:00.000000+00:00

Background
----------
Phase 1 of the Git Repo Connector (GRC) feature.  A ``git_repo_connections``
row represents a registered Git repository that SkillMeat should scan for
Claude Code artifacts.  One project may have multiple connections (multiple
branches of the same repo, or multiple repos); the combination
``(project_id, repo_url, branch)`` is unique.

Table Created
-------------
``git_repo_connections``

    Stores one registered Git repository connection per project/branch pair.

    Schema:
        id             INTEGER PRIMARY KEY AUTOINCREMENT
        project_id     TEXT NULL    FK -> projects.id ON DELETE CASCADE
        repo_url       TEXT NOT NULL
        branch         TEXT NOT NULL  DEFAULT 'main'
        developer_id   INTEGER NULL  FK -> users.id (soft — nullable)
        scan_schedule  TEXT NULL     Reserved for future cron expression
        webhook_secret TEXT NULL     Encrypted webhook validation secret
        last_scan_at   DATETIME NULL Set after each completed scan
        last_scan_id   INTEGER NULL  Plain reference to latest scan (no FK
                                     constraint — avoids circular dependency
                                     with git_repo_scans)
        is_active      BOOLEAN NOT NULL DEFAULT 1
        created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        created_by     INTEGER NULL  FK -> users.id (soft — nullable)

    Constraints:
        uq_git_repo_connections_project_url_branch
            UNIQUE (project_id, repo_url, branch)

    Indexes:
        idx_git_repo_connections_project_id   (project_id)
        idx_git_repo_connections_is_active    (is_active)
        idx_git_repo_connections_developer_id (developer_id)

Dialect Strategy
----------------
All operations use dialect-agnostic Alembic constructs compatible with both
SQLite (local mode) and PostgreSQL (enterprise mode).  No JSONB, TSVECTOR, or
UUID columns are used; server_default uses ``sa.text('CURRENT_TIMESTAMP')``
which is portable across both dialects.

The ``last_scan_id`` column intentionally carries NO foreign-key constraint to
avoid a circular dependency between ``git_repo_connections`` and the
``git_repo_scans`` table that is created in the next migration.  Referential
integrity for this column is enforced at the application layer.

Downgrade
---------
Drop ``git_repo_connections`` (indexes and the unique constraint are dropped
automatically by the database engine).
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0002_add_git_repo_connections"
down_revision: Union[str, None] = "20260330_0001_merge_grc_heads"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_TABLE = "git_repo_connections"


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create the git_repo_connections table."""
    op.create_table(
        _TABLE,
        # Primary key — autoincrement integer for cross-dialect compatibility.
        sa.Column(
            "id",
            sa.Integer(),
            primary_key=True,
            autoincrement=True,
            comment="Auto-incrementing surrogate primary key",
        ),
        # Project FK (nullable so enterprise connections can omit it and rely
        # on tenant_id at the application/enterprise-model layer instead).
        sa.Column(
            "project_id",
            sa.String(),
            sa.ForeignKey("projects.id", ondelete="CASCADE", name="fk_grc_project_id"),
            nullable=True,
            comment="Owning project; cascade-delete removes all connections for a project",
        ),
        # Repository location
        sa.Column(
            "repo_url",
            sa.String(),
            nullable=False,
            comment="Full clone URL of the Git repository (HTTPS or SSH)",
        ),
        sa.Column(
            "branch",
            sa.String(),
            nullable=False,
            server_default="main",
            comment="Branch to scan; defaults to 'main'",
        ),
        # Identity linkage
        sa.Column(
            "developer_id",
            sa.Integer(),
            sa.ForeignKey("users.id", name="fk_grc_developer_id"),
            nullable=True,
            comment="Optional FK to users.id identifying the developer who owns this connection",
        ),
        # Future scheduling hook
        sa.Column(
            "scan_schedule",
            sa.String(),
            nullable=True,
            comment="Reserved: future cron expression for scheduled scans (e.g. '0 * * * *')",
        ),
        # Webhook secret stored as text; encryption at rest is the caller's responsibility.
        sa.Column(
            "webhook_secret",
            sa.String(),
            nullable=True,
            comment="Webhook HMAC secret for validating incoming push events; treat as sensitive",
        ),
        # Scan state pointers
        sa.Column(
            "last_scan_at",
            sa.DateTime(),
            nullable=True,
            comment="UTC timestamp of the most recently completed scan",
        ),
        sa.Column(
            "last_scan_id",
            sa.Integer(),
            nullable=True,
            comment=(
                "Plain reference (no FK) to the most recent git_repo_scans.id. "
                "No FK constraint is defined here to avoid a circular dependency "
                "with the git_repo_scans table."
            ),
        ),
        # Status
        sa.Column(
            "is_active",
            sa.Boolean(),
            nullable=False,
            server_default="1",
            comment="When False the connection is paused and will not be scanned",
        ),
        # Audit timestamps
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
            comment="UTC creation timestamp",
        ),
        sa.Column(
            "created_by",
            sa.Integer(),
            sa.ForeignKey("users.id", name="fk_grc_created_by"),
            nullable=True,
            comment="Optional FK to users.id of the user who registered this connection",
        ),
        # Unique constraint: one connection per (project, repo, branch) triple.
        sa.UniqueConstraint(
            "project_id",
            "repo_url",
            "branch",
            name="uq_git_repo_connections_project_url_branch",
        ),
    )

    op.create_index(
        "idx_git_repo_connections_project_id",
        _TABLE,
        ["project_id"],
    )
    op.create_index(
        "idx_git_repo_connections_is_active",
        _TABLE,
        ["is_active"],
    )
    op.create_index(
        "idx_git_repo_connections_developer_id",
        _TABLE,
        ["developer_id"],
    )

    log.info("upgrade: created %s table.", _TABLE)


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop git_repo_connections table."""
    op.drop_table(_TABLE)
    log.info("downgrade: dropped %s table.", _TABLE)
