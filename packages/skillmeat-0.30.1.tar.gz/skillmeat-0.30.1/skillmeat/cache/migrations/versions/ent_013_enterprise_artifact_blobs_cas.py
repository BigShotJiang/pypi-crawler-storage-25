"""Add enterprise artifact_blobs table for Content-Addressed Storage (CAS-1.1).

Revision ID: ent_013_enterprise_artifact_blobs_cas
Revises: ent_012_enterprise_project_templates
Create Date: 2026-03-31 00:00:00.000000+00:00

Background
----------
CAS-1.1 enterprise schema change.  Introduces the ``artifact_blobs`` table that
backs the Content-Addressed Storage layer for enterprise PostgreSQL deployments.

One blob row stores the binary or text content of a single artifact file, keyed
by its SHA-256 hex digest.  Because the key is a content hash, identical content
written by multiple artifact versions maps to the same row, achieving storage
deduplication across the enterprise collection without duplicating bytes.

This migration is PostgreSQL-only.  It is a no-op on any other dialect.

artifact_blobs table
--------------------
    id            UUID          PRIMARY KEY DEFAULT gen_random_uuid()
    sha256_hash   VARCHAR(64)   NOT NULL UNIQUE
    content       BYTEA         NULL  (inline blob; NULL when storage_uri is set)
    storage_uri   TEXT          NULL  (external storage pointer; NULL when content is inline)
    size_bytes    BIGINT        NOT NULL
    mime_type     VARCHAR(128)  NULL
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT now()
    last_ref_at   TIMESTAMPTZ   NULL  (updated when a version references this blob)
    ref_count     INTEGER       NOT NULL DEFAULT 0

Constraints:
    uq_artifact_blobs_sha256_hash   UNIQUE (sha256_hash)

Indexes:
    idx_artifact_blobs_sha256_hash  (sha256_hash) — primary lookup by content hash

Design notes
------------
- ``content`` and ``storage_uri`` are mutually exclusive; the application layer
  enforces the invariant (exactly one is non-NULL at write time).
- ``ref_count`` is a soft counter incremented by the repository on each version
  reference; it drives GC eligibility but is not authoritative — the GC process
  performs a full join scan before evicting any blob.
- ``last_ref_at`` is updated (never NULL-ed) each time a new version references
  this blob; it provides a staleness signal for cache warming.
- SHA-256 hex digest is exactly 64 characters; the UNIQUE constraint on
  ``sha256_hash`` is the primary deduplication guard.

Downgrade
---------
Drop the ``artifact_blobs`` table.  Indexes and the unique constraint are
dropped automatically with the table on PostgreSQL.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_013_enterprise_artifact_blobs_cas"
down_revision: Union[str, Sequence[str], None] = "ent_012_enterprise_project_templates"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_BLOBS_TABLE = "artifact_blobs"


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _table_exists(bind: sa.engine.Connection, table_name: str) -> bool:
    """Return True if *table_name* already exists (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = 'public'
              AND table_name = :tname
            """),
        {"tname": table_name},
    )
    return result.fetchone() is not None


def _index_exists(bind: sa.engine.Connection, index_name: str) -> bool:
    """Return True if *index_name* already exists in the current database."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM pg_indexes
            WHERE indexname = :iname
            """),
        {"iname": index_name},
    )
    return result.fetchone() is not None


def _column_exists(
    bind: sa.engine.Connection, table_name: str, column_name: str
) -> bool:
    """Return True if *column_name* exists on *table_name* (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = :tname
              AND column_name = :cname
            """),
        {"tname": table_name, "cname": column_name},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create the artifact_blobs table for enterprise CAS storage (CAS-1.1)."""
    if not _is_postgresql():
        log.info(
            "ent_013_enterprise_artifact_blobs_cas: non-PostgreSQL dialect detected; "
            "skipping enterprise-only migration."
        )
        return

    log.info("ent_013_enterprise_artifact_blobs_cas upgrade: running PostgreSQL path.")
    _upgrade_artifact_blobs()


def _upgrade_artifact_blobs() -> None:
    """Create the artifact_blobs table with CAS schema."""
    bind = op.get_bind()

    if _table_exists(bind, _BLOBS_TABLE):
        log.info(
            "ent_013: %s already exists; skipping table creation.",
            _BLOBS_TABLE,
        )
    else:
        op.create_table(
            _BLOBS_TABLE,
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                primary_key=True,
                server_default=text("gen_random_uuid()"),
                comment="Primary key; server-generated UUID",
            ),
            sa.Column(
                "sha256_hash",
                sa.String(64),
                nullable=False,
                comment=(
                    "SHA-256 hex digest of the blob content (exactly 64 chars). "
                    "Immutable once written — the application layer MUST NOT update "
                    "the content column for an existing hash. "
                    "Unique constraint enforces global deduplication."
                ),
            ),
            sa.Column(
                "content",
                sa.LargeBinary(),
                nullable=True,
                comment=(
                    "Raw binary content of the blob stored inline. "
                    "NULL when the blob is stored externally (see storage_uri). "
                    "Exactly one of content / storage_uri MUST be non-NULL."
                ),
            ),
            sa.Column(
                "storage_uri",
                sa.Text(),
                nullable=True,
                comment=(
                    "External storage pointer (e.g. S3 URI, GCS URI). "
                    "NULL when content is stored inline. "
                    "Exactly one of content / storage_uri MUST be non-NULL."
                ),
            ),
            sa.Column(
                "size_bytes",
                sa.BigInteger(),
                nullable=False,
                comment=(
                    "Byte length of the original content. "
                    "Redundant but avoids full content reads for size queries."
                ),
            ),
            sa.Column(
                "mime_type",
                sa.String(128),
                nullable=True,
                comment=(
                    "IANA media type of the content, e.g. 'text/markdown', "
                    "'application/json'. NULL when type is unknown or not needed."
                ),
            ),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=text("now()"),
                comment="UTC timestamp when the blob was first written; immutable",
            ),
            sa.Column(
                "last_ref_at",
                sa.DateTime(timezone=True),
                nullable=True,
                comment=(
                    "UTC timestamp of the most recent artifact_versions reference to "
                    "this blob. Updated (never cleared) by the repository on each new "
                    "version write. NULL until at least one version references this blob."
                ),
            ),
            sa.Column(
                "ref_count",
                sa.Integer(),
                nullable=False,
                server_default=text("0"),
                comment=(
                    "Soft reference count incremented by the repository on each new "
                    "version reference. Drives GC eligibility but is not authoritative; "
                    "the GC process performs a full join scan before evicting any blob."
                ),
            ),
            # UNIQUE: content-addressed deduplication
            sa.UniqueConstraint(
                "sha256_hash",
                name="uq_artifact_blobs_sha256_hash",
            ),
        )
        log.info("ent_013: created table %s.", _BLOBS_TABLE)

    # B-tree index on sha256_hash for O(log n) lookup by content hash.
    if not _index_exists(bind, "idx_artifact_blobs_sha256_hash"):
        op.create_index(
            "idx_artifact_blobs_sha256_hash",
            _BLOBS_TABLE,
            ["sha256_hash"],
        )
        log.info("ent_013: created index idx_artifact_blobs_sha256_hash.")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop the artifact_blobs table."""
    if not _is_postgresql():
        log.info(
            "ent_013_enterprise_artifact_blobs_cas downgrade: "
            "non-PostgreSQL dialect detected; skipping."
        )
        return

    log.info(
        "ent_013_enterprise_artifact_blobs_cas downgrade: running PostgreSQL path."
    )
    _downgrade_artifact_blobs()


def _downgrade_artifact_blobs() -> None:
    """Drop artifact_blobs table (indexes and unique constraint drop automatically)."""
    bind = op.get_bind()

    if not _table_exists(bind, _BLOBS_TABLE):
        log.info("ent_013: %s does not exist; skipping drop.", _BLOBS_TABLE)
        return

    op.drop_table(_BLOBS_TABLE)
    log.info("ent_013: dropped table %s.", _BLOBS_TABLE)
