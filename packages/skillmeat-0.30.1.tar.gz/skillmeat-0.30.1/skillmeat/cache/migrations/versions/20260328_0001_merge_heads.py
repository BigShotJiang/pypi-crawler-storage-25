"""Merge 4 divergent heads into single migration chain.

Revision ID: 20260328_0001_merge_heads
Revises: 20260326_0003_add_shadowed_from_enterprise_id, 20260327_0001_expand_version_history_constraints, ent_009_enterprise_collection_bindings, ent_010_version_scopes_and_history_tenant, 20260328_1400
Create Date: 2026-03-28 00:01:00.000000+00:00

Background
----------
Multiple parallel development branches created divergent migration heads:
- Date-based branch split at 20260324_0001
- Enterprise branch split at ent_008

This merge migration unifies all heads without schema changes.
"""

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = "20260328_0001_merge_heads"
down_revision = (
    "ent_009_enterprise_collection_bindings",
    "ent_010_version_scopes_and_history_tenant",
    "20260328_1400",
)
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
