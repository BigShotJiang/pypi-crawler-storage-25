"""Enterprise access token and git_credentials table (PostgreSQL edition).

Revision ID: ent_021_enterprise_access_token_credentials
Revises: 20260403_0002_gcd_access_token_credentials
Create Date: 2026-04-03 00:03:00.000000+00:00

Background
----------
Task GCD-2.1 / GCD-2.2 — Phase 2 (Token Management) of the Git Connection
Decoupling feature — enterprise / PostgreSQL counterpart to the local
migration ``20260403_0002_gcd_access_token_credentials``.

This migration extends the enterprise edition with:

1. ``access_token`` column on ``enterprise_git_repo_connections``
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   A nullable TEXT column for a Fernet-encrypted PAT directly associated with
   a single connection.  Nullable to avoid locking during the ALTER TABLE on
   large tables.

2. ``enterprise_git_credentials`` table
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   Scoped credential store with full tenant isolation.

   Schema::

       id              UUID PK  DEFAULT gen_random_uuid()
       tenant_id       UUID NOT NULL  FK -> enterprise_tenants.id
       scope_type      VARCHAR NOT NULL  CHECK IN ('org', 'team', 'developer')
       scope_id        UUID NOT NULL
       connection_id   UUID NULL  FK -> enterprise_git_repo_connections.id
                                  ON DELETE CASCADE
       token_encrypted TEXT NOT NULL  (Fernet ciphertext)
       credential_type VARCHAR NOT NULL DEFAULT 'pat'
                            CHECK IN ('pat', 'app_installation')
       created_by      UUID NULL
       created_at      TIMESTAMP DEFAULT NOW()

   Indexes::

       ix_egc_scope  (tenant_id, scope_type, scope_id)
       ix_egc_conn   (tenant_id, connection_id)

Tenant Isolation Invariant
--------------------------
Every query against ``enterprise_git_credentials`` MUST include a
``WHERE tenant_id = ?`` predicate.  Omitting it is a security defect that
leaks cross-tenant data.

Dialect Strategy
----------------
Enterprise (PostgreSQL) only.  ``upgrade()`` and ``downgrade()`` are no-ops
when executed against a non-PostgreSQL backend.

UUID PKs use ``gen_random_uuid()`` (available from PostgreSQL 13+, or via
pgcrypto on earlier versions) consistent with other enterprise tables.

Downgrade
---------
1. Drop ``ix_egc_conn`` and ``ix_egc_scope`` indexes (implicit on table drop).
2. Drop ``enterprise_git_credentials`` table.
3. Drop ``access_token`` column from ``enterprise_git_repo_connections``.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_021_enterprise_access_token_credentials"
down_revision: Union[str, Sequence[str], None] = (
    "20260403_0002_gcd_access_token_credentials"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Table / column names
# ---------------------------------------------------------------------------

_GRC_TABLE = "enterprise_git_repo_connections"
_CREDS_TABLE = "enterprise_git_credentials"

# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Upgrade helpers
# ---------------------------------------------------------------------------


def _column_exists(table: str, column: str) -> bool:
    """Check if a column exists on a table (PostgreSQL only)."""
    result = op.get_bind().execute(
        sa.text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = :t AND column_name = :c"
        ),
        {"t": table, "c": column},
    )
    return result.fetchone() is not None


def _add_access_token_column() -> None:
    """Add access_token (nullable TEXT) to enterprise_git_repo_connections."""

    if _column_exists(_GRC_TABLE, "access_token"):
        log.info(
            "upgrade: access_token column already exists on %s; skipping.", _GRC_TABLE
        )
        return

    op.add_column(
        _GRC_TABLE,
        sa.Column(
            "access_token",
            sa.Text(),
            nullable=True,
            comment=(
                "Fernet-encrypted PAT directly associated with this connection. "
                "NULL means no per-connection token is configured."
            ),
        ),
    )

    log.info("upgrade: added access_token column to %s.", _GRC_TABLE)


def _table_exists(table: str) -> bool:
    """Check if a table exists in public schema (PostgreSQL only)."""
    result = op.get_bind().execute(
        sa.text(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_name = :t AND table_schema = 'public'"
        ),
        {"t": table},
    )
    return result.fetchone() is not None


def _create_credentials_table() -> None:
    """Create enterprise_git_credentials table with tenant isolation."""

    if _table_exists(_CREDS_TABLE):
        log.info("upgrade: %s table already exists; skipping.", _CREDS_TABLE)
        return

    op.create_table(
        _CREDS_TABLE,
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            comment="UUID primary key generated by PostgreSQL",
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="Tenant scope; every query MUST filter by tenant_id",
        ),
        sa.Column(
            "scope_type",
            sa.String(),
            nullable=False,
            comment="Credential scope: 'org', 'team', or 'developer'",
        ),
        sa.Column(
            "scope_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="UUID of the scoped entity (org, team, or developer)",
        ),
        sa.Column(
            "connection_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment="Optional FK to enterprise_git_repo_connections.id",
        ),
        sa.Column(
            "token_encrypted",
            sa.Text(),
            nullable=False,
            comment="Fernet-encrypted credential token (plaintext never stored)",
        ),
        sa.Column(
            "credential_type",
            sa.String(),
            nullable=False,
            server_default=sa.text("'pat'"),
            comment="Token type: 'pat' (personal access token) or 'app_installation'",
        ),
        sa.Column(
            "created_by",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment="Optional UUID of the enterprise user who stored this credential",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=True,
            server_default=sa.text("NOW()"),
            comment="UTC timestamp when this credential was stored",
        ),
        # Constraints
        sa.CheckConstraint(
            "scope_type IN ('org', 'team', 'developer')",
            name="ck_egc_scope_type",
        ),
        sa.CheckConstraint(
            "credential_type IN ('pat', 'app_installation')",
            name="ck_egc_credential_type",
        ),
        # Foreign keys
        # Note: tenant_id has no FK — enterprise_tenants table does not exist.
        # Tenant isolation is enforced at the application layer (RLS / query filters).
        sa.ForeignKeyConstraint(
            ["connection_id"],
            ["enterprise_git_repo_connections.id"],
            name="fk_egc_connection_id",
            ondelete="CASCADE",
        ),
    )

    # Composite indexes for tenant-scoped queries on scope and connection axes.
    op.create_index(
        "ix_egc_scope",
        _CREDS_TABLE,
        ["tenant_id", "scope_type", "scope_id"],
    )
    op.create_index(
        "ix_egc_conn",
        _CREDS_TABLE,
        ["tenant_id", "connection_id"],
    )

    log.info("upgrade: created %s table with indexes.", _CREDS_TABLE)


# ---------------------------------------------------------------------------
# Downgrade helpers
# ---------------------------------------------------------------------------


def _drop_credentials_table() -> None:
    """Drop enterprise_git_credentials table (indexes dropped implicitly)."""
    op.drop_table(_CREDS_TABLE)
    log.info("downgrade: dropped %s table.", _CREDS_TABLE)


def _remove_access_token_column() -> None:
    """Drop access_token column from enterprise_git_repo_connections."""
    op.drop_column(_GRC_TABLE, "access_token")
    log.info("downgrade: removed access_token column from %s.", _GRC_TABLE)


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Apply GCD-2.1/2.2 enterprise schema changes (PostgreSQL only)."""
    if not _is_postgresql():
        log.info(
            "upgrade: skipping enterprise migration on non-PostgreSQL backend (%s).",
            op.get_bind().dialect.name,
        )
        return

    _add_access_token_column()
    _create_credentials_table()

    log.info("upgrade: ent_021 complete.")


def downgrade() -> None:
    """Reverse GCD-2.1/2.2 enterprise schema changes (PostgreSQL only)."""
    if not _is_postgresql():
        log.info(
            "downgrade: skipping enterprise migration on non-PostgreSQL backend (%s).",
            op.get_bind().dialect.name,
        )
        return

    # Reverse order: drop the credentials table before removing the column it
    # references via FK.
    _drop_credentials_table()
    _remove_access_token_column()

    log.info("downgrade: ent_021 complete.")
