"""add enterprise_collection_bindings table for Day-0 auto-binding

Revision ID: ent_009_enterprise_collection_bindings
Revises: ent_008_enterprise_parity_tables
Create Date: 2026-03-26 00:09:00.000000+00:00

Background
----------
EG-2.6 enterprise-governance auto-bind feature.  When a new User or Team is
provisioned under a tenant they must automatically receive a read-only
dependency link to every active global enterprise collection
(is_global_collection=True AND auto_bind=True).  This table stores those
binding records and is the authoritative source for which entities have
inherited which collections.

Table created
-------------
  enterprise_collection_bindings
      Binding record linking a user or team entity to a global enterprise
      collection.  The ``is_readonly`` flag is TRUE by default; only a
      system administrator may remove a read-only binding.

Downgrade
---------
Drop the table unconditionally (it only exists on PostgreSQL).

Schema reference
----------------
skillmeat/cache/models_enterprise.py  (EG-2.6 EnterpriseCollectionBinding)
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# ---------------------------------------------------------------------------
# Revision metadata
# ---------------------------------------------------------------------------

revision: str = "ent_009_enterprise_collection_bindings"
down_revision: Union[str, None] = "ent_008_enterprise_parity_tables"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    bind = op.get_bind()
    return bind.dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create enterprise_collection_bindings table (PostgreSQL only)."""
    if not _is_postgresql():
        return  # No-op for SQLite

    op.create_table(
        "enterprise_collection_bindings",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            comment="Globally unique binding identifier",
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
        ),
        sa.Column(
            "collection_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_collections.id",
                ondelete="CASCADE",
                name="fk_ecb_collection_id",
            ),
            nullable=False,
            comment="Collection being bound; cascades on collection deletion",
        ),
        sa.Column(
            "bound_entity_type",
            sa.String(20),
            nullable=False,
            comment="Type of the bound entity: 'user' or 'team'",
        ),
        sa.Column(
            "bound_entity_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="UUID of the bound user or team entity",
        ),
        sa.Column(
            "is_readonly",
            sa.Boolean,
            nullable=False,
            server_default=sa.text("true"),
            comment=(
                "When TRUE only a system administrator may remove this binding; "
                "auto-created bindings are always read-only"
            ),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
            comment="Timezone-aware creation timestamp",
        ),
        # Unique constraint: one binding per (tenant, collection, entity-type, entity)
        sa.UniqueConstraint(
            "tenant_id",
            "collection_id",
            "bound_entity_type",
            "bound_entity_id",
            name="uq_ecb_tenant_collection_entity",
        ),
        # CHECK guard for bound_entity_type values
        sa.CheckConstraint(
            "bound_entity_type IN ('user', 'team')",
            name="ck_ecb_bound_entity_type",
        ),
    )

    # Index to accelerate "which collections is this entity bound to?"
    op.create_index(
        "idx_ecb_tenant_entity",
        "enterprise_collection_bindings",
        ["tenant_id", "bound_entity_type", "bound_entity_id"],
    )

    # Index to accelerate "which entities are bound to this collection?"
    op.create_index(
        "idx_ecb_collection_id",
        "enterprise_collection_bindings",
        ["collection_id"],
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop enterprise_collection_bindings table (PostgreSQL only)."""
    if not _is_postgresql():
        return  # No-op for SQLite

    op.drop_index("idx_ecb_collection_id", table_name="enterprise_collection_bindings")
    op.drop_index("idx_ecb_tenant_entity", table_name="enterprise_collection_bindings")
    op.drop_table("enterprise_collection_bindings")
