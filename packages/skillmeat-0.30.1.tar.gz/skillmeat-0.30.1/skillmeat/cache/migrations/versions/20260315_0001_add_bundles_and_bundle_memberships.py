"""Add bundles and bundle_memberships tables (ADR-008 bundle distribution model).

Revision ID: bundle_001
Revises: 20260314_0001_fix_workflow_execution_fk
Create Date: 2026-03-15 00:01:00.000000+00:00

Background
----------
ADR-008 introduces a distribution-focused bundle concept as the successor to
the informal "composite" concept (ADR-007).  Where ``CompositeArtifact``
targets deployment-time composition within a single project,
``BundleEntity`` targets publishing, versioning, and cross-project sharing.

Tables Created
--------------
1. ``bundles`` — Versioned, publishable sets of artifacts owned by a
   collection.  Supports draft → published → deprecated lifecycle,
   semver versioning, SPDX license metadata, and JSON tag storage.

2. ``bundle_memberships`` — Association table linking individual
   ``artifacts`` rows (via the stable ``artifacts.uuid`` ADR-007 column)
   to a ``bundles`` row.  Composite primary key ``(bundle_id,
   artifact_uuid)`` ensures an artifact can appear in multiple bundles
   but only once per bundle.

Foreign-Key Semantics
---------------------
* ``bundles.collection_id`` → ``collections.id`` (plain reference —
  deleting a collection should be guarded at the application layer;
  no cascade defined here to match existing collection FK patterns).
* ``bundle_memberships.bundle_id`` → ``bundles.id`` ON DELETE CASCADE:
  removing a bundle automatically purges all its membership rows.
* ``bundle_memberships.artifact_uuid`` → ``artifacts.uuid`` ON DELETE
  CASCADE: removing an artifact from the cache also purges its bundle
  membership rows (references the stable UUID, not the mutable id).

Dialect Strategy
----------------
All operations use dialect-agnostic Alembic constructs:
* ``op.create_table()`` / ``op.create_index()`` — supported by SQLite
  and PostgreSQL.
* ``sa.text('CURRENT_TIMESTAMP')`` for DateTime server_default —
  portable across both dialects (matches the pattern in
  ``001_consolidated_schema.py``).
* ``sa.Text()`` for the ``tags`` column — avoids JSONB divergence;
  application layer serialises/deserialises JSON.

Downgrade
---------
Drops ``bundle_memberships`` first (carries FKs to both ``bundles`` and
``artifacts``), then drops ``bundles``.

Schema reference
----------------
skillmeat/cache/models.py  (BundleEntity, BundleMembership)
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "bundle_001"
down_revision: Union[str, None] = "20260315_0001_add_backstage_v2_deployment_drift"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create the bundles and bundle_memberships tables."""

    # ------------------------------------------------------------------
    # 1. bundles
    # ------------------------------------------------------------------
    op.create_table(
        "bundles",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column(
            "collection_id",
            sa.String(),
            sa.ForeignKey("collections.id"),
            nullable=False,
        ),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("version", sa.String(), nullable=True),
        sa.Column(
            "status",
            sa.String(),
            nullable=False,
            server_default="draft",
        ),
        sa.Column("tags", sa.Text(), nullable=True),
        sa.Column("license", sa.String(), nullable=True),
        sa.Column("homepage", sa.String(), nullable=True),
        sa.Column("repository", sa.String(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.Column("published_at", sa.DateTime(), nullable=True),
    )
    op.create_index(
        "idx_bundles_collection_id",
        "bundles",
        ["collection_id"],
    )
    op.create_index(
        "idx_bundles_name",
        "bundles",
        ["name"],
    )
    op.create_index(
        "idx_bundles_status",
        "bundles",
        ["status"],
    )

    # ------------------------------------------------------------------
    # 2. bundle_memberships
    # ------------------------------------------------------------------
    op.create_table(
        "bundle_memberships",
        sa.Column(
            "bundle_id",
            sa.String(),
            sa.ForeignKey("bundles.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column(
            "artifact_uuid",
            sa.String(),
            sa.ForeignKey("artifacts.uuid", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column(
            "artifact_tier",
            sa.Integer(),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "relationship_type",
            sa.String(),
            nullable=False,
            server_default="contains",
        ),
        sa.Column("pinned_version_hash", sa.String(), nullable=True),
        sa.Column(
            "added_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
    )
    op.create_index(
        "idx_bundle_memberships_bundle_id",
        "bundle_memberships",
        ["bundle_id"],
    )
    op.create_index(
        "idx_bundle_memberships_artifact_uuid",
        "bundle_memberships",
        ["artifact_uuid"],
    )

    log.info("upgrade: created bundles and bundle_memberships tables.")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop bundle_memberships then bundles in reverse dependency order."""

    # Drop FK-bearing table first
    op.drop_index(
        "idx_bundle_memberships_artifact_uuid", table_name="bundle_memberships"
    )
    op.drop_index("idx_bundle_memberships_bundle_id", table_name="bundle_memberships")
    op.drop_table("bundle_memberships")

    # Then the parent table
    op.drop_index("idx_bundles_status", table_name="bundles")
    op.drop_index("idx_bundles_name", table_name="bundles")
    op.drop_index("idx_bundles_collection_id", table_name="bundles")
    op.drop_table("bundles")

    log.info("downgrade: dropped bundle_memberships and bundles tables.")
