"""Add artifact_signatures table for DVCS cryptographic trust (DVCS-4.1).

Revision ID: 20260331_0001_add_artifact_signatures_table
Revises: 20260330_0009_add_tier_fqan_columns
Create Date: 2026-03-31 00:01:00.000000+00:00

Background
----------
Introduces the artifact_signatures table to support cryptographic trust verification
for artifacts in the DVCS system (DVCS Phase 4, Task 4.1).

Changes
-------
1. New table ``artifact_signatures``:
   - ``id``            (TEXT)     — Unique signature identifier (primary key, UUID hex).
   - ``artifact_uuid`` (TEXT)     — Foreign key to artifacts.uuid (CASCADE DELETE).
   - ``public_key``    (TEXT(64)) — Ed25519 public key (hex-encoded, 64 characters).
   - ``signature``     (TEXT)     — Cryptographic signature (hex-encoded).
   - ``trust_level``   (TEXT)     — Trust level enum (untrusted, community, verified, official).
   - ``signer_id``     (TEXT)     — Optional identifier for the signing entity.
   - ``created_at``    (DATETIME) — Timestamp when signature was created.
   - ``updated_at``    (DATETIME) — Timestamp when signature was last updated.

2. Indexes on ``artifact_signatures``:
   - ``idx_artifact_signatures_artifact_uuid`` — Join performance with artifacts.
   - ``idx_artifact_signatures_trust_level``   — Filter by trust level.
   - ``idx_artifact_signatures_public_key``    — Lookup by public key.

3. Constraints on ``artifact_signatures``:
   - ``check_artifact_signatures_trust_level``     — Trust level domain guard.
   - ``check_artifact_signatures_public_key_length``— Public key length validation (64 chars).
   - ``uq_artifact_signatures_artifact_public_key`` — Unique constraint: one signature per artifact per public key.

4. Foreign key:
   - ``artifact_signatures.artifact_uuid`` → ``artifacts.uuid`` (CASCADE DELETE).

Dialect Strategy
----------------
- SQLite: ``batch_alter_table`` not needed as this is a new table creation.
- PostgreSQL: standard ``CREATE TABLE`` with all constraints inline.

Both dialects use idempotency guards (table existence checks) so the migration
is safe to re-run.

Downgrade
---------
Drops the ``artifact_signatures`` table and all associated indexes and constraints.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260331_0001_add_artifact_signatures_table"
down_revision: Union[str, None] = "20260330_0009_add_tier_fqan_columns"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

logger = logging.getLogger(__name__)


def upgrade() -> None:
    """Add artifact_signatures table for cryptographic trust verification."""
    logger.info("Starting DVCS-4.1: Add artifact_signatures table")

    # Check if table already exists (idempotency guard)
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    existing_tables = inspector.get_table_names()

    if "artifact_signatures" in existing_tables:
        logger.info("Table artifact_signatures already exists, skipping creation")
        return

    # Create artifact_signatures table
    op.create_table(
        "artifact_signatures",
        # Primary key
        sa.Column(
            "id",
            sa.String(),
            primary_key=True,
            comment="Unique signature identifier (UUID hex)",
        ),
        # Foreign key to artifacts
        sa.Column(
            "artifact_uuid",
            sa.String(),
            sa.ForeignKey("artifacts.uuid", ondelete="CASCADE"),
            nullable=False,
            comment="Foreign key to artifacts.uuid",
        ),
        # Ed25519 public key (hex-encoded, 64 chars)
        sa.Column(
            "public_key",
            sa.String(64),
            nullable=False,
            comment="Ed25519 public key (hex-encoded, 64 characters)",
        ),
        # Cryptographic signature (hex-encoded)
        sa.Column(
            "signature",
            sa.Text(),
            nullable=False,
            comment="Cryptographic signature (hex-encoded)",
        ),
        # Trust level enum
        sa.Column(
            "trust_level",
            sa.String(),
            nullable=False,
            default="untrusted",
            comment="Trust level: untrusted, community, verified, official",
        ),
        # Optional signer identifier
        sa.Column(
            "signer_id",
            sa.String(),
            nullable=True,
            comment="Optional identifier for the signing entity",
        ),
        # Timestamps
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
            comment="Timestamp when signature was created",
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
            comment="Timestamp when signature was last updated",
        ),
        # Check constraints
        sa.CheckConstraint(
            "trust_level IN ('untrusted', 'community', 'verified', 'official')",
            name="check_artifact_signatures_trust_level",
        ),
        sa.CheckConstraint(
            "length(public_key) = 64",
            name="check_artifact_signatures_public_key_length",
        ),
        # Unique constraint: one signature per artifact per public key
        sa.UniqueConstraint(
            "artifact_uuid",
            "public_key",
            name="uq_artifact_signatures_artifact_public_key",
        ),
    )

    # Create indexes
    logger.info("Creating indexes for artifact_signatures table")

    op.create_index(
        "idx_artifact_signatures_artifact_uuid",
        "artifact_signatures",
        ["artifact_uuid"],
    )

    op.create_index(
        "idx_artifact_signatures_trust_level", "artifact_signatures", ["trust_level"]
    )

    op.create_index(
        "idx_artifact_signatures_public_key", "artifact_signatures", ["public_key"]
    )

    logger.info("DVCS-4.1: artifact_signatures table creation completed")


def downgrade() -> None:
    """Remove artifact_signatures table and all associated indexes."""
    logger.info("Starting DVCS-4.1 downgrade: Remove artifact_signatures table")

    # Check if table exists before trying to drop it
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    existing_tables = inspector.get_table_names()

    if "artifact_signatures" not in existing_tables:
        logger.info("Table artifact_signatures does not exist, skipping removal")
        return

    # Drop indexes first (they will be dropped with table anyway, but explicit is better)
    try:
        op.drop_index("idx_artifact_signatures_public_key", "artifact_signatures")
    except Exception as e:
        logger.warning(f"Could not drop idx_artifact_signatures_public_key: {e}")

    try:
        op.drop_index("idx_artifact_signatures_trust_level", "artifact_signatures")
    except Exception as e:
        logger.warning(f"Could not drop idx_artifact_signatures_trust_level: {e}")

    try:
        op.drop_index("idx_artifact_signatures_artifact_uuid", "artifact_signatures")
    except Exception as e:
        logger.warning(f"Could not drop idx_artifact_signatures_artifact_uuid: {e}")

    # Drop the table
    op.drop_table("artifact_signatures")

    logger.info("DVCS-4.1 downgrade: artifact_signatures table removal completed")
