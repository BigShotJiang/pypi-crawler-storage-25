"""Fix workflow_executions.workflow_id FK: make nullable with SET NULL on delete.

Revision ID: 20260314_0001_fix_workflow_execution_fk
Revises: 20260312_0001_add_bom_signature_fields
Create Date: 2026-03-14 00:01:00.000000+00:00

Background
----------
The ``WorkflowExecution`` ORM model (``skillmeat/cache/models.py``) declares
``workflow_id`` as ``nullable=True`` with ``ondelete="SET NULL"``, allowing
execution history to be preserved after a workflow is deleted.

However, the database schema created via earlier ORM ``create_all`` calls or a
prior migration may have the column defined as ``NOT NULL`` with a plain
``CASCADE`` (or no explicit ``ondelete``) foreign-key constraint.  This causes
``IntegrityError`` at runtime when a workflow is deleted and the execution
orphan-cleanup logic expects ``SET NULL`` semantics.

Changes
-------
1. Alter ``workflow_executions.workflow_id`` to be nullable (``NULL`` allowed).
2. Drop the existing FK constraint on that column.
3. Recreate the FK with ``ON DELETE SET NULL``.

Dialect Strategy
----------------
* SQLite cannot drop or alter FK constraints via plain ``ALTER TABLE``.
  ``batch_alter_table`` is used unconditionally; Alembic performs a
  full table-rebuild on SQLite to apply the changes atomically.
* PostgreSQL supports ``ALTER TABLE … DROP CONSTRAINT`` and
  ``ALTER TABLE … ALTER COLUMN … DROP NOT NULL`` natively.
  ``batch_alter_table`` delegates to those statements on PostgreSQL.

Idempotency
-----------
The upgrade function inspects the live column nullable flag before applying
changes.  If ``workflow_id`` is already nullable the migration exits early,
making it safe to run against databases already migrated or bootstrapped via
``Base.metadata.create_all``.

Downgrade
---------
Reverses the change: recreates the FK as plain ``CASCADE`` (the previous
implicit semantics) and re-applies ``NOT NULL`` to ``workflow_id``.

Schema reference
----------------
skillmeat/cache/models.py  (WorkflowExecution)
skillmeat/core/workflow/executor.py
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260314_0001_fix_workflow_execution_fk"
down_revision: Union[str, None] = "20260312_0001_add_bom_signature_fields"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_TABLE = "workflow_executions"
_COLUMN = "workflow_id"


# ---------------------------------------------------------------------------
# Idempotency helper
# ---------------------------------------------------------------------------


def _column_is_nullable(bind: sa.engine.Connection) -> bool:
    """Return True if ``workflow_id`` on ``workflow_executions`` is already nullable."""
    if is_sqlite():
        result = bind.execute(text(f"PRAGMA table_info({_TABLE})"))
        for row in result.fetchall():
            # PRAGMA table_info columns: cid, name, type, notnull, dflt_value, pk
            if row[1] == _COLUMN:
                not_null = row[3]
                return not_null == 0  # 0 means nullable
        # Column not found — assume migration is needed
        return False
    else:
        result = bind.execute(
            text("""
                SELECT is_nullable
                FROM information_schema.columns
                WHERE table_name = :tbl
                  AND column_name = :col
                """),
            {"tbl": _TABLE, "col": _COLUMN},
        )
        row = result.fetchone()
        if row is None:
            return False
        return row[0].upper() == "YES"


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Make workflow_executions.workflow_id nullable with SET NULL on delete."""
    bind = op.get_bind()

    if _column_is_nullable(bind):
        log.info(
            "fix_workflow_execution_fk: column %r on %r is already nullable; skipping.",
            _COLUMN,
            _TABLE,
        )
        return

    log.info(
        "fix_workflow_execution_fk: altering %r.%r to nullable=True with SET NULL FK.",
        _TABLE,
        _COLUMN,
    )

    if is_sqlite():
        # SQLite: Anonymous FKs can't be dropped by name. Use raw SQL to rebuild
        # the table with the correct schema.
        op.execute("PRAGMA foreign_keys=OFF")
        # Create new table with nullable workflow_id and SET NULL FK
        op.execute("""
            CREATE TABLE workflow_executions_new (
                id VARCHAR PRIMARY KEY,
                workflow_id VARCHAR REFERENCES workflows(id) ON DELETE SET NULL,
                workflow_name VARCHAR NOT NULL,
                workflow_version VARCHAR NOT NULL,
                workflow_definition_hash VARCHAR,
                status VARCHAR NOT NULL DEFAULT 'pending',
                trigger VARCHAR NOT NULL DEFAULT 'manual',
                parameters_json TEXT,
                overrides_json TEXT,
                started_at DATETIME,
                completed_at DATETIME,
                error_message TEXT,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            )
            """)
        # Copy data
        op.execute("""
            INSERT INTO workflow_executions_new
            SELECT id, workflow_id, workflow_name, workflow_version,
                   workflow_definition_hash, status, trigger, parameters_json,
                   overrides_json, started_at, completed_at, error_message,
                   created_at, updated_at
            FROM workflow_executions
            """)
        # Drop old table
        op.execute("DROP TABLE workflow_executions")
        # Rename new table
        op.execute("ALTER TABLE workflow_executions_new RENAME TO workflow_executions")
        op.execute("PRAGMA foreign_keys=ON")
    else:
        # PostgreSQL: Use proper ALTER TABLE statements
        with op.batch_alter_table(_TABLE, recreate="auto") as batch_op:
            batch_op.alter_column(
                _COLUMN,
                existing_type=sa.String(),
                nullable=True,
            )
            # PostgreSQL FKs have auto-generated names, find and drop it
            batch_op.drop_constraint(
                f"{_TABLE}_{_COLUMN}_fkey",
                type_="foreignkey",
            )
            batch_op.create_foreign_key(
                f"fk_{_TABLE}_{_COLUMN}_workflows",
                "workflows",
                [_COLUMN],
                ["id"],
                ondelete="SET NULL",
            )

    log.info("fix_workflow_execution_fk: upgrade complete.")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Revert workflow_executions.workflow_id to NOT NULL with CASCADE delete.

    Uses batch_alter_table for SQLite compatibility.
    """
    log.info(
        "fix_workflow_execution_fk: reverting %r.%r to NOT NULL with CASCADE FK.",
        _TABLE,
        _COLUMN,
    )

    if is_sqlite():
        # SQLite: Rebuild table with NOT NULL workflow_id and CASCADE FK
        op.execute("PRAGMA foreign_keys=OFF")
        op.execute("""
            CREATE TABLE workflow_executions_new (
                id VARCHAR PRIMARY KEY,
                workflow_id VARCHAR NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
                workflow_name VARCHAR NOT NULL,
                workflow_version VARCHAR NOT NULL,
                workflow_definition_hash VARCHAR,
                status VARCHAR NOT NULL DEFAULT 'pending',
                trigger VARCHAR NOT NULL DEFAULT 'manual',
                parameters_json TEXT,
                overrides_json TEXT,
                started_at DATETIME,
                completed_at DATETIME,
                error_message TEXT,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            )
            """)
        # Copy data (only rows with non-null workflow_id)
        op.execute("""
            INSERT INTO workflow_executions_new
            SELECT id, workflow_id, workflow_name, workflow_version,
                   workflow_definition_hash, status, trigger, parameters_json,
                   overrides_json, started_at, completed_at, error_message,
                   created_at, updated_at
            FROM workflow_executions
            WHERE workflow_id IS NOT NULL
            """)
        op.execute("DROP TABLE workflow_executions")
        op.execute("ALTER TABLE workflow_executions_new RENAME TO workflow_executions")
        op.execute("PRAGMA foreign_keys=ON")
    else:
        # PostgreSQL
        with op.batch_alter_table(_TABLE, recreate="auto") as batch_op:
            batch_op.drop_constraint(
                f"fk_{_TABLE}_{_COLUMN}_workflows",
                type_="foreignkey",
            )
            batch_op.create_foreign_key(
                f"{_TABLE}_{_COLUMN}_fkey",
                "workflows",
                [_COLUMN],
                ["id"],
                ondelete="CASCADE",
            )
            batch_op.alter_column(
                _COLUMN,
                existing_type=sa.String(),
                nullable=False,
            )

    log.info("fix_workflow_execution_fk: downgrade complete.")
