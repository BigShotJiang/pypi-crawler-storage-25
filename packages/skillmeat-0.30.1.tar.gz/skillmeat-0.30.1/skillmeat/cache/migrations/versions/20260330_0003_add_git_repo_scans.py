"""Add git_repo_scans table for Git Repo Connector feature (GRC-DB-002).

Revision ID: 20260330_0003_add_git_repo_scans
Revises: 20260330_0002_add_git_repo_connections
Create Date: 2026-03-30 00:03:00.000000+00:00

Background
----------
Phase 1 of the Git Repo Connector (GRC) feature.  A ``git_repo_scans`` row
represents a single execution of an artifact-discovery scan against a
registered Git repository connection.  Multiple scan records accumulate over
time, providing a history of scan results per connection.

Table Created
-------------
``git_repo_scans``

    Stores one scan execution record per connection/run.

    Schema:
        id                INTEGER PRIMARY KEY AUTOINCREMENT
        connection_id     INTEGER NOT NULL  FK -> git_repo_connections.id ON DELETE CASCADE
        triggered_by      TEXT NOT NULL     CHECK ('manual', 'schedule', 'webhook')
        trigger_sha       TEXT(40) NULL     Git commit SHA that triggered the scan
        status            TEXT NOT NULL     CHECK ('pending', 'running', 'completed', 'failed')
                                            DEFAULT 'pending'
        started_at        DATETIME NULL
        completed_at      DATETIME NULL
        artifacts_found   INTEGER NOT NULL DEFAULT 0
        artifacts_new     INTEGER NOT NULL DEFAULT 0
        artifacts_changed INTEGER NOT NULL DEFAULT 0
        artifacts_removed INTEGER NOT NULL DEFAULT 0
        error_message     TEXT NULL
        created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP

    Constraints:
        ck_git_repo_scans_triggered_by  triggered_by IN ('manual','schedule','webhook')
        ck_git_repo_scans_status        status IN ('pending','running','completed','failed')

    Indexes:
        idx_git_repo_scans_connection_id  (connection_id)
        idx_git_repo_scans_status         (status)
        idx_git_repo_scans_created_at     (created_at)

Dialect Strategy
----------------
``sa.CheckConstraint`` is used for the ``triggered_by`` and ``status`` enums.
SQLite silently ignores CHECK constraints but PostgreSQL enforces them — this
is the documented intentional behaviour for shared migrations in this codebase
(see the project's migration policy).

Downgrade
---------
Drop ``git_repo_scans`` (cascade will also remove any child ``git_scan_artifacts``
rows if that table already exists, but the child table is created in the next
migration so the FK direction is child → parent).
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0003_add_git_repo_scans"
down_revision: Union[str, None] = "20260330_0002_add_git_repo_connections"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_TABLE = "git_repo_scans"


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create the git_repo_scans table."""
    op.create_table(
        _TABLE,
        # Primary key
        sa.Column(
            "id",
            sa.Integer(),
            primary_key=True,
            autoincrement=True,
            comment="Auto-incrementing surrogate primary key",
        ),
        # Parent connection (cascade-delete: removing a connection removes all scan history)
        sa.Column(
            "connection_id",
            sa.Integer(),
            sa.ForeignKey(
                "git_repo_connections.id",
                ondelete="CASCADE",
                name="fk_grs_connection_id",
            ),
            nullable=False,
            comment="FK to git_repo_connections.id; cascade-delete on connection removal",
        ),
        # Trigger metadata
        sa.Column(
            "triggered_by",
            sa.String(),
            nullable=False,
            comment="How this scan was initiated: 'manual', 'schedule', or 'webhook'",
        ),
        sa.Column(
            "trigger_sha",
            sa.String(40),
            nullable=True,
            comment="Git commit SHA that triggered this scan (40-char hex); NULL for manual/schedule",
        ),
        # Lifecycle status
        sa.Column(
            "status",
            sa.String(),
            nullable=False,
            server_default="pending",
            comment="Current scan lifecycle state: 'pending', 'running', 'completed', or 'failed'",
        ),
        # Timing
        sa.Column(
            "started_at",
            sa.DateTime(),
            nullable=True,
            comment="UTC timestamp when the scan worker picked up the job",
        ),
        sa.Column(
            "completed_at",
            sa.DateTime(),
            nullable=True,
            comment="UTC timestamp when the scan finished (success or failure)",
        ),
        # Artifact counters
        sa.Column(
            "artifacts_found",
            sa.Integer(),
            nullable=False,
            server_default="0",
            comment="Total artifacts detected in this scan run",
        ),
        sa.Column(
            "artifacts_new",
            sa.Integer(),
            nullable=False,
            server_default="0",
            comment="Artifacts newly discovered (not seen in previous scans)",
        ),
        sa.Column(
            "artifacts_changed",
            sa.Integer(),
            nullable=False,
            server_default="0",
            comment="Artifacts whose content changed since the last scan",
        ),
        sa.Column(
            "artifacts_removed",
            sa.Integer(),
            nullable=False,
            server_default="0",
            comment="Artifacts present in the previous scan but no longer found",
        ),
        # Error reporting
        sa.Column(
            "error_message",
            sa.Text(),
            nullable=True,
            comment="Human-readable error detail when status is 'failed'",
        ),
        # Audit timestamp
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
            comment="UTC timestamp when the scan record was created",
        ),
        # CHECK constraints — enforced on PostgreSQL; silently ignored on SQLite.
        sa.CheckConstraint(
            "triggered_by IN ('manual', 'schedule', 'webhook')",
            name="ck_git_repo_scans_triggered_by",
        ),
        sa.CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed')",
            name="ck_git_repo_scans_status",
        ),
    )

    op.create_index(
        "idx_git_repo_scans_connection_id",
        _TABLE,
        ["connection_id"],
    )
    op.create_index(
        "idx_git_repo_scans_status",
        _TABLE,
        ["status"],
    )
    op.create_index(
        "idx_git_repo_scans_created_at",
        _TABLE,
        ["created_at"],
    )

    log.info("upgrade: created %s table.", _TABLE)


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop git_repo_scans table."""
    op.drop_table(_TABLE)
    log.info("downgrade: dropped %s table.", _TABLE)
