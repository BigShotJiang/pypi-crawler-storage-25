"""Add enforce_override boolean column to artifacts, collections, enterprise_artifacts, enterprise_collections.

Revision ID: 20260326_0001_add_enforce_override_column
Revises: 20260324_0001_add_new_artifact_types_to_constraints
Create Date: 2026-03-26 00:01:00.000000+00:00

Background
----------
Enterprise Governance 3-Tier feature (EG-1).  A new ``enforce_override`` flag is
introduced on the four core ownership tables to support governance policy enforcement:

  Column specification
  ~~~~~~~~~~~~~~~~~~~~
  * Type:           BOOLEAN (NOT NULL)
  * Default:        False  (application layer)
  * Server default: 'false'  (database layer)
  * Comment:        "When True, governance policy overrides apply to this resource
                     regardless of owner settings"

Affected tables
---------------
Local (SQLite) schema:
  1. ``artifacts``    — adds ``enforce_override BOOLEAN NOT NULL DEFAULT false``
  2. ``collections``  — adds ``enforce_override BOOLEAN NOT NULL DEFAULT false``

Enterprise (PostgreSQL) schema:
  3. ``enterprise_artifacts``    — adds ``enforce_override BOOLEAN NOT NULL DEFAULT false``
  4. ``enterprise_collections``  — adds ``enforce_override BOOLEAN NOT NULL DEFAULT false``

OwnerType enum note
-------------------
``OwnerType.enterprise`` was added to ``auth_types.py`` and documented in migration
``ent_007_enterprise_owner_type``.  The ``owner_type`` column is stored as
``VARCHAR(20)`` (not a database-level enum), so no additional DDL is needed here.

Backward Compatibility
----------------------
All existing rows receive ``enforce_override = false`` via the server_default,
preserving current behavior.  No data migration is required.

Rollback
--------
``downgrade()`` drops the column from all four tables.  SQLite uses
``batch_alter_table`` for the drop (SQLite cannot ALTER TABLE ... DROP COLUMN
without a full table rebuild in older versions; using batch ensures compatibility).

Schema reference
----------------
skillmeat/cache/models.py                    (Artifact, Collection)
skillmeat/cache/models_enterprise.py         (EnterpriseArtifact, EnterpriseCollection)
.claude/progress/enterprise-governance-3-tier/
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260326_0001_add_enforce_override_column"
down_revision: Union[str, None] = "20260324_0001_add_new_artifact_types_to_constraints"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ---------------------------------------------------------------------------
# Column definition shared across all four tables
# ---------------------------------------------------------------------------

_COLUMN_NAME = "enforce_override"
_COLUMN_TYPE = sa.Boolean()
_SERVER_DEFAULT = "false"

# Local (SQLite) tables that need the column
_LOCAL_TABLES = ("artifacts", "collections")

# Enterprise (PostgreSQL) tables that need the column
_ENTERPRISE_TABLES = ("enterprise_artifacts", "enterprise_collections")


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(
    bind: sa.engine.Connection, table_name: str, column_name: str
) -> bool:
    """Return True if *column_name* already exists on *table_name*.

    Works for both SQLite and PostgreSQL by inspecting the reflected column list.
    Uses ``sa.inspect()`` which is dialect-agnostic.
    """
    insp = sa.inspect(bind)
    columns = [col["name"] for col in insp.get_columns(table_name)]
    return column_name in columns


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add ``enforce_override`` to all four core ownership tables."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_enforce_override upgrade: running SQLite dialect path.")
        _add_columns_sqlite(bind, _LOCAL_TABLES)
    elif is_postgresql():
        log.info("add_enforce_override upgrade: running PostgreSQL dialect path.")
        # PostgreSQL hosts both local-schema and enterprise-schema tables
        _add_columns_postgresql(bind, _LOCAL_TABLES)
        _add_columns_postgresql(bind, _ENTERPRISE_TABLES)
    else:
        log.warning(
            "add_enforce_override upgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _add_columns_sqlite(bind: sa.engine.Connection, tables: tuple[str, ...]) -> None:
    """Add enforce_override to the given tables on SQLite.

    SQLite requires ``batch_alter_table`` for schema changes that are not
    supported natively (e.g. adding a NOT NULL column without a default in
    very old SQLite versions).  However, SQLite 3.37+ supports
    ``ALTER TABLE … ADD COLUMN`` for NOT NULL columns with a default value,
    so ``op.add_column`` is sufficient here.  We use ``op.add_column`` for
    simplicity and fall back to a batch rebuild path only if needed.
    """
    for table_name in tables:
        if _column_exists(bind, table_name, _COLUMN_NAME):
            log.info(
                "add_enforce_override (SQLite): %s.%s already exists; skipping.",
                table_name,
                _COLUMN_NAME,
            )
            continue

        log.info(
            "add_enforce_override (SQLite): adding %s.%s.",
            table_name,
            _COLUMN_NAME,
        )
        op.add_column(
            table_name,
            sa.Column(
                _COLUMN_NAME,
                _COLUMN_TYPE,
                nullable=False,
                server_default=_SERVER_DEFAULT,
            ),
        )


def _add_columns_postgresql(
    bind: sa.engine.Connection, tables: tuple[str, ...]
) -> None:
    """Add enforce_override to the given tables on PostgreSQL.

    Uses ``op.add_column`` directly — PostgreSQL supports adding a NOT NULL
    column with a server_default in a single statement, and the server_default
    backfills all existing rows atomically.
    """
    for table_name in tables:
        if _column_exists(bind, table_name, _COLUMN_NAME):
            log.info(
                "add_enforce_override (PostgreSQL): %s.%s already exists; skipping.",
                table_name,
                _COLUMN_NAME,
            )
            continue

        log.info(
            "add_enforce_override (PostgreSQL): adding %s.%s.",
            table_name,
            _COLUMN_NAME,
        )
        op.add_column(
            table_name,
            sa.Column(
                _COLUMN_NAME,
                _COLUMN_TYPE,
                nullable=False,
                server_default=_SERVER_DEFAULT,
            ),
        )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove ``enforce_override`` from all four core ownership tables."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_enforce_override downgrade: running SQLite dialect path.")
        _drop_columns_sqlite(bind, _LOCAL_TABLES)
    elif is_postgresql():
        log.info("add_enforce_override downgrade: running PostgreSQL dialect path.")
        _drop_columns_postgresql(bind, _LOCAL_TABLES)
        _drop_columns_postgresql(bind, _ENTERPRISE_TABLES)
    else:
        log.warning(
            "add_enforce_override downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _drop_columns_sqlite(bind: sa.engine.Connection, tables: tuple[str, ...]) -> None:
    """Drop enforce_override from the given tables on SQLite.

    SQLite does not natively support ``ALTER TABLE … DROP COLUMN`` in
    versions below 3.35.  Use ``batch_alter_table`` to perform a safe
    full-table rebuild that is compatible with all supported SQLite versions.

    FK checks are disabled during the rebuild to prevent cascading FK-violation
    errors from child tables that reference the target table.
    """
    for table_name in tables:
        if not _column_exists(bind, table_name, _COLUMN_NAME):
            log.info(
                "add_enforce_override (SQLite): %s.%s does not exist; skipping drop.",
                table_name,
                _COLUMN_NAME,
            )
            continue
        log.info(
            "add_enforce_override (SQLite): dropping %s.%s.",
            table_name,
            _COLUMN_NAME,
        )
        op.execute(text("PRAGMA foreign_keys = OFF"))
        try:
            with op.batch_alter_table(table_name) as batch_op:
                batch_op.drop_column(_COLUMN_NAME)
        finally:
            op.execute(text("PRAGMA foreign_keys = ON"))


def _drop_columns_postgresql(
    bind: sa.engine.Connection, tables: tuple[str, ...]
) -> None:
    """Drop enforce_override from the given tables on PostgreSQL."""
    for table_name in tables:
        if not _column_exists(bind, table_name, _COLUMN_NAME):
            log.info(
                "add_enforce_override (PostgreSQL): %s.%s does not exist; skipping drop.",
                table_name,
                _COLUMN_NAME,
            )
            continue

        log.info(
            "add_enforce_override (PostgreSQL): dropping %s.%s.",
            table_name,
            _COLUMN_NAME,
        )
        op.drop_column(table_name, _COLUMN_NAME)
