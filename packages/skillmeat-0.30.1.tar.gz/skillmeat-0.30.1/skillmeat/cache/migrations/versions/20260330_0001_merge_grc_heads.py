"""Merge three divergent heads before adding git repo connector tables.

Revision ID: 20260330_0001_merge_grc_heads
Revises: 20260328_1500, ent_011_enterprise_marketplace_source_columns,
         ent_012_enterprise_project_templates
Create Date: 2026-03-30 00:01:00.000000+00:00

Background
----------
Three parallel development branches created divergent migration heads:
- Shared branch leaf:      20260328_1500
- Enterprise branch leaf:  ent_011_enterprise_marketplace_source_columns
- Enterprise branch leaf:  ent_012_enterprise_project_templates

This merge migration unifies all three heads without schema changes so that
the git repo connector migrations (GRC-DB-001 through GRC-DB-003) can be
added as a linear chain.
"""

from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0001_merge_grc_heads"
down_revision: Union[str, tuple[str, ...], None] = (
    "20260328_1500",
    "ent_011_enterprise_marketplace_source_columns",
    "ent_012_enterprise_project_templates",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
