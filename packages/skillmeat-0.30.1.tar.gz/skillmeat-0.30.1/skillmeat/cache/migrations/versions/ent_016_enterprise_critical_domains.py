"""Create enterprise critical-domain tables: workflow, memory, bundle, and BOM/attestation.

Revision ID: ent_016_enterprise_critical_domains
Revises: 20260402_0001_merge_heads
Create Date: 2026-04-02 00:00:00.000000+00:00

Background
----------
This migration creates 15 new PostgreSQL tables introduced across EGCF Phase 2
(tasks 2.1 – 2.4).  All tables are enterprise-only (PostgreSQL dialect) and
participate in the tenant-isolation invariant — every query against them MUST
include a ``WHERE tenant_id = ?`` predicate.

Tables created (dependency order)
----------------------------------
Workflow domain (EGCF-2.1):
    1.  enterprise_workflows           — tenant-scoped workflow definition
    2.  enterprise_workflow_stages     — ordered stages within a workflow
    3.  enterprise_workflow_executions — single run of a workflow
    4.  enterprise_execution_steps     — individual step within an execution

Memory domain (EGCF-2.2):
    5.  enterprise_memory_items        — persistent development-knowledge items
    6.  enterprise_context_modules     — named grouping of memory items
    7.  enterprise_module_memory_items — junction: modules ↔ memory items

Bundle domain (EGCF-2.3):
    8.  enterprise_bundle_entities     — top-level named bundle definition
    9.  enterprise_bundle_memberships  — junction: bundles ↔ artifacts
    10. enterprise_bundle_commits      — versioned snapshot of a bundle
    11. enterprise_bundle_commit_members — per-artifact rows within a commit

BOM / Attestation domain (EGCF-2.4):
    12. enterprise_bom_snapshots          — point-in-time BOM for an artifact
    13. enterprise_attestation_policies   — policy definition for attestation checks
    14. enterprise_attestation_records    — attestation result against a snapshot
    15. enterprise_bom_metadata           — tooling provenance metadata for a snapshot

Design notes
------------
- All tables use ``gen_random_uuid()`` as the server-side PK default.
- JSONB columns default to ``'{}'::jsonb`` or ``'[]'::jsonb`` as appropriate.
- Indexes use ``op.create_index()``; GIN indexes are not required here since
  JSONB columns are accessed via FK navigation rather than containment queries.
- CHECK constraints enforce status/result enumerations at the DB layer.
- Foreign keys reference tables created earlier in the same migration or in
  prior migrations (enterprise_artifacts, enterprise_projects).

Downgrade order
---------------
Tables are dropped in reverse dependency order so that FK references are
satisfied at the time each DROP TABLE executes:
    15 → 14 → 13 → 12 → 11 → 10 → 9 → 8 → 7 → 6 → 5 → 4 → 3 → 2 → 1
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_016_enterprise_critical_domains"
down_revision: Union[str, Sequence[str], None] = "20260402_0001_merge_heads"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Upgrade helpers — one function per domain for readability
# ---------------------------------------------------------------------------


def _create_workflow_tables() -> None:
    """Create the four workflow-domain tables (EGCF-2.1)."""

    # 1. enterprise_workflows ------------------------------------------------
    op.create_table(
        "enterprise_workflows",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "name",
            sa.String(255),
            nullable=False,
        ),
        sa.Column(
            "description",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "status",
            sa.String(50),
            nullable=False,
            server_default=sa.text("'draft'"),
        ),
        sa.Column(
            "config",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_enterprise_workflows_tenant_name",
        ),
        sa.CheckConstraint(
            "status IN ('draft', 'active', 'archived')",
            name="ck_enterprise_workflows_status",
        ),
    )
    op.create_index(
        "ix_enterprise_workflows_tenant_id",
        "enterprise_workflows",
        ["tenant_id"],
    )

    # 2. enterprise_workflow_stages ------------------------------------------
    op.create_table(
        "enterprise_workflow_stages",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "workflow_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_workflows.id",
                ondelete="CASCADE",
                name="fk_enterprise_workflow_stages_workflow_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "name",
            sa.String(255),
            nullable=False,
        ),
        sa.Column(
            "description",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "position",
            sa.Integer,
            nullable=False,
        ),
        sa.Column(
            "stage_type",
            sa.String(50),
            nullable=False,
            server_default=sa.text("'action'"),
        ),
        sa.Column(
            "config",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.UniqueConstraint(
            "workflow_id",
            "position",
            name="uq_enterprise_workflow_stages_workflow_position",
        ),
        sa.CheckConstraint(
            "position >= 0",
            name="ck_enterprise_workflow_stages_position_nonneg",
        ),
    )
    op.create_index(
        "ix_enterprise_workflow_stages_tenant_id",
        "enterprise_workflow_stages",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_workflow_stages_workflow_id",
        "enterprise_workflow_stages",
        ["workflow_id"],
    )

    # 3. enterprise_workflow_executions --------------------------------------
    op.create_table(
        "enterprise_workflow_executions",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "workflow_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_workflows.id",
                ondelete="CASCADE",
                name="fk_enterprise_workflow_executions_workflow_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "status",
            sa.String(50),
            nullable=False,
            server_default=sa.text("'pending'"),
        ),
        sa.Column(
            "started_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "completed_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "context",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "result",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed', 'cancelled')",
            name="ck_enterprise_workflow_executions_status",
        ),
    )
    op.create_index(
        "ix_enterprise_workflow_executions_tenant_id",
        "enterprise_workflow_executions",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_workflow_executions_workflow_id",
        "enterprise_workflow_executions",
        ["workflow_id"],
    )
    op.create_index(
        "ix_enterprise_workflow_executions_status",
        "enterprise_workflow_executions",
        ["status"],
    )

    # 4. enterprise_execution_steps ------------------------------------------
    op.create_table(
        "enterprise_execution_steps",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "execution_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_workflow_executions.id",
                ondelete="CASCADE",
                name="fk_enterprise_execution_steps_execution_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "stage_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_workflow_stages.id",
                ondelete="SET NULL",
                name="fk_enterprise_execution_steps_stage_id",
            ),
            nullable=True,
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "status",
            sa.String(50),
            nullable=False,
            server_default=sa.text("'pending'"),
        ),
        sa.Column(
            "started_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "completed_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "input",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "output",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "error",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed', 'skipped')",
            name="ck_enterprise_execution_steps_status",
        ),
    )
    op.create_index(
        "ix_enterprise_execution_steps_tenant_id",
        "enterprise_execution_steps",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_execution_steps_execution_id",
        "enterprise_execution_steps",
        ["execution_id"],
    )
    op.create_index(
        "ix_enterprise_execution_steps_stage_id",
        "enterprise_execution_steps",
        ["stage_id"],
    )


def _create_memory_tables() -> None:
    """Create the three memory-domain tables (EGCF-2.2)."""

    # 5. enterprise_memory_items ---------------------------------------------
    op.create_table(
        "enterprise_memory_items",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "project_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_projects.id",
                ondelete="CASCADE",
                name="fk_enterprise_memory_items_project_id",
            ),
            nullable=True,
        ),
        sa.Column(
            "type",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "status",
            sa.Text,
            nullable=False,
            server_default=sa.text("'candidate'"),
        ),
        sa.Column(
            "content",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "confidence",
            sa.Float,
            nullable=True,
        ),
        sa.Column(
            "anchor",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "provenance",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "type IN ('decision', 'constraint', 'gotcha', 'style_rule', 'learning')",
            name="ck_enterprise_memory_items_type",
        ),
        sa.CheckConstraint(
            "status IN ('candidate', 'validated', 'rejected', 'superseded')",
            name="ck_enterprise_memory_items_status",
        ),
    )
    op.create_index(
        "ix_enterprise_memory_items_tenant_id",
        "enterprise_memory_items",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_memory_items_project_id",
        "enterprise_memory_items",
        ["project_id"],
    )

    # 6. enterprise_context_modules ------------------------------------------
    op.create_table(
        "enterprise_context_modules",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "name",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "description",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "module_type",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "config",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    op.create_index(
        "ix_enterprise_context_modules_tenant_id",
        "enterprise_context_modules",
        ["tenant_id"],
    )

    # 7. enterprise_module_memory_items (junction) ---------------------------
    op.create_table(
        "enterprise_module_memory_items",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "module_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_context_modules.id",
                ondelete="CASCADE",
                name="fk_enterprise_mmi_module_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "memory_item_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_memory_items.id",
                ondelete="CASCADE",
                name="fk_enterprise_mmi_memory_item_id",
            ),
            nullable=False,
        ),
        sa.UniqueConstraint(
            "module_id",
            "memory_item_id",
            "tenant_id",
            name="uq_enterprise_module_memory_item",
        ),
    )
    op.create_index(
        "ix_enterprise_module_memory_items_tenant_id",
        "enterprise_module_memory_items",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_module_memory_items_module_id",
        "enterprise_module_memory_items",
        ["module_id"],
    )
    op.create_index(
        "ix_enterprise_module_memory_items_memory_item_id",
        "enterprise_module_memory_items",
        ["memory_item_id"],
    )


def _create_bundle_tables() -> None:
    """Create the four bundle-domain tables (EGCF-2.3)."""

    # 8. enterprise_bundle_entities ------------------------------------------
    op.create_table(
        "enterprise_bundle_entities",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "name",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "description",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "bundle_type",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "config",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "status",
            sa.Text,
            nullable=False,
            server_default=sa.text("'draft'"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "status IN ('draft', 'published', 'archived')",
            name="ck_enterprise_bundle_entities_status",
        ),
    )
    op.create_index(
        "ix_enterprise_bundle_entities_tenant_id",
        "enterprise_bundle_entities",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_bundle_entities_status",
        "enterprise_bundle_entities",
        ["status"],
    )

    # 9. enterprise_bundle_memberships (junction) ----------------------------
    op.create_table(
        "enterprise_bundle_memberships",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "bundle_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_bundle_entities.id",
                ondelete="CASCADE",
                name="fk_enterprise_bundle_membership_bundle_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "artifact_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_artifacts.id",
                ondelete="CASCADE",
                name="fk_enterprise_bundle_membership_artifact_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "position",
            sa.Integer,
            nullable=True,
        ),
        sa.Column(
            "config",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.UniqueConstraint(
            "bundle_id",
            "artifact_id",
            "tenant_id",
            name="uq_enterprise_bundle_membership",
        ),
    )
    op.create_index(
        "ix_enterprise_bundle_memberships_tenant_id",
        "enterprise_bundle_memberships",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_bundle_memberships_bundle_id",
        "enterprise_bundle_memberships",
        ["bundle_id"],
    )
    op.create_index(
        "ix_enterprise_bundle_memberships_artifact_id",
        "enterprise_bundle_memberships",
        ["artifact_id"],
    )

    # 10. enterprise_bundle_commits ------------------------------------------
    op.create_table(
        "enterprise_bundle_commits",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "bundle_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_bundle_entities.id",
                ondelete="CASCADE",
                name="fk_enterprise_bundle_commit_bundle_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "commit_hash",
            sa.String(64),
            nullable=False,
        ),
        sa.Column(
            "message",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "committed_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "parent_hash",
            sa.String(64),
            nullable=True,
        ),
        sa.Column(
            "snapshot_data",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    op.create_index(
        "ix_enterprise_bundle_commits_tenant_id",
        "enterprise_bundle_commits",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_bundle_commits_bundle_id",
        "enterprise_bundle_commits",
        ["bundle_id"],
    )
    op.create_index(
        "ix_enterprise_bundle_commits_commit_hash",
        "enterprise_bundle_commits",
        ["commit_hash"],
    )

    # 11. enterprise_bundle_commit_members -----------------------------------
    op.create_table(
        "enterprise_bundle_commit_members",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "commit_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_bundle_commits.id",
                ondelete="CASCADE",
                name="fk_enterprise_bundle_commit_member_commit_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "artifact_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_artifacts.id",
                ondelete="CASCADE",
                name="fk_enterprise_bundle_commit_member_artifact_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "version_ref",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "extra_metadata",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.UniqueConstraint(
            "commit_id",
            "artifact_id",
            "tenant_id",
            name="uq_enterprise_bundle_commit_member",
        ),
    )
    op.create_index(
        "ix_enterprise_bundle_commit_members_tenant_id",
        "enterprise_bundle_commit_members",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_bundle_commit_members_commit_id",
        "enterprise_bundle_commit_members",
        ["commit_id"],
    )
    op.create_index(
        "ix_enterprise_bundle_commit_members_artifact_id",
        "enterprise_bundle_commit_members",
        ["artifact_id"],
    )


def _create_bom_attestation_tables() -> None:
    """Create the four BOM/attestation-domain tables (EGCF-2.4)."""

    # 12. enterprise_bom_snapshots -------------------------------------------
    op.create_table(
        "enterprise_bom_snapshots",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "artifact_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_artifacts.id",
                ondelete="CASCADE",
                name="fk_enterprise_bom_snapshot_artifact_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "snapshot_data",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "generated_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "format_version",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    op.create_index(
        "ix_enterprise_bom_snapshots_tenant_id",
        "enterprise_bom_snapshots",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_bom_snapshots_artifact_id",
        "enterprise_bom_snapshots",
        ["artifact_id"],
    )

    # 13. enterprise_attestation_policies ------------------------------------
    op.create_table(
        "enterprise_attestation_policies",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "name",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "description",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "policy_type",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "rules",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "status",
            sa.Text,
            nullable=False,
            server_default=sa.text("'active'"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "name",
            name="uq_enterprise_attestation_policies_tenant_name",
        ),
        sa.CheckConstraint(
            "status IN ('active', 'inactive', 'archived')",
            name="ck_enterprise_attestation_policies_status",
        ),
    )
    op.create_index(
        "ix_enterprise_attestation_policies_tenant_id",
        "enterprise_attestation_policies",
        ["tenant_id"],
    )

    # 14. enterprise_attestation_records -------------------------------------
    op.create_table(
        "enterprise_attestation_records",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "snapshot_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_bom_snapshots.id",
                ondelete="CASCADE",
                name="fk_enterprise_attestation_record_snapshot_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "policy_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_attestation_policies.id",
                ondelete="SET NULL",
                name="fk_enterprise_attestation_record_policy_id",
            ),
            nullable=True,
        ),
        sa.Column(
            "result",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "attested_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "evidence",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.CheckConstraint(
            "result IN ('pass', 'fail', 'warning', 'error')",
            name="ck_enterprise_attestation_records_result",
        ),
    )
    op.create_index(
        "ix_enterprise_attestation_records_tenant_id",
        "enterprise_attestation_records",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_attestation_records_snapshot_id",
        "enterprise_attestation_records",
        ["snapshot_id"],
    )
    op.create_index(
        "ix_enterprise_attestation_records_policy_id",
        "enterprise_attestation_records",
        ["policy_id"],
    )

    # 15. enterprise_bom_metadata --------------------------------------------
    op.create_table(
        "enterprise_bom_metadata",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "snapshot_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "enterprise_bom_snapshots.id",
                ondelete="CASCADE",
                name="fk_enterprise_bom_metadata_snapshot_id",
            ),
            nullable=False,
        ),
        sa.Column(
            "tool_name",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "tool_version",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "source_info",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "tags",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'[]'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.UniqueConstraint(
            "snapshot_id",
            name="uq_enterprise_bom_metadata_snapshot_id",
        ),
    )
    op.create_index(
        "ix_enterprise_bom_metadata_tenant_id",
        "enterprise_bom_metadata",
        ["tenant_id"],
    )
    op.create_index(
        "ix_enterprise_bom_metadata_snapshot_id",
        "enterprise_bom_metadata",
        ["snapshot_id"],
    )


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create all 15 enterprise critical-domain tables (PostgreSQL only)."""
    if not _is_postgresql():
        log.info(
            "ent_016_enterprise_critical_domains: non-PostgreSQL dialect detected; "
            "skipping enterprise-only migration."
        )
        return

    log.info("ent_016_enterprise_critical_domains upgrade: running PostgreSQL path.")

    _create_workflow_tables()
    _create_memory_tables()
    _create_bundle_tables()
    _create_bom_attestation_tables()

    log.info(
        "ent_016_enterprise_critical_domains upgrade: all 15 tables created successfully."
    )


# ---------------------------------------------------------------------------
# Downgrade helpers
# ---------------------------------------------------------------------------


def _drop_bom_attestation_tables() -> None:
    """Drop BOM/attestation tables in reverse dependency order."""
    op.drop_index("ix_enterprise_bom_metadata_snapshot_id", "enterprise_bom_metadata")
    op.drop_index("ix_enterprise_bom_metadata_tenant_id", "enterprise_bom_metadata")
    op.drop_table("enterprise_bom_metadata")

    op.drop_index(
        "ix_enterprise_attestation_records_policy_id",
        "enterprise_attestation_records",
    )
    op.drop_index(
        "ix_enterprise_attestation_records_snapshot_id",
        "enterprise_attestation_records",
    )
    op.drop_index(
        "ix_enterprise_attestation_records_tenant_id",
        "enterprise_attestation_records",
    )
    op.drop_table("enterprise_attestation_records")

    op.drop_index(
        "ix_enterprise_attestation_policies_tenant_id",
        "enterprise_attestation_policies",
    )
    op.drop_table("enterprise_attestation_policies")

    op.drop_index("ix_enterprise_bom_snapshots_artifact_id", "enterprise_bom_snapshots")
    op.drop_index("ix_enterprise_bom_snapshots_tenant_id", "enterprise_bom_snapshots")
    op.drop_table("enterprise_bom_snapshots")


def _drop_bundle_tables() -> None:
    """Drop bundle tables in reverse dependency order."""
    op.drop_index(
        "ix_enterprise_bundle_commit_members_artifact_id",
        "enterprise_bundle_commit_members",
    )
    op.drop_index(
        "ix_enterprise_bundle_commit_members_commit_id",
        "enterprise_bundle_commit_members",
    )
    op.drop_index(
        "ix_enterprise_bundle_commit_members_tenant_id",
        "enterprise_bundle_commit_members",
    )
    op.drop_table("enterprise_bundle_commit_members")

    op.drop_index(
        "ix_enterprise_bundle_commits_commit_hash", "enterprise_bundle_commits"
    )
    op.drop_index("ix_enterprise_bundle_commits_bundle_id", "enterprise_bundle_commits")
    op.drop_index("ix_enterprise_bundle_commits_tenant_id", "enterprise_bundle_commits")
    op.drop_table("enterprise_bundle_commits")

    op.drop_index(
        "ix_enterprise_bundle_memberships_artifact_id",
        "enterprise_bundle_memberships",
    )
    op.drop_index(
        "ix_enterprise_bundle_memberships_bundle_id", "enterprise_bundle_memberships"
    )
    op.drop_index(
        "ix_enterprise_bundle_memberships_tenant_id", "enterprise_bundle_memberships"
    )
    op.drop_table("enterprise_bundle_memberships")

    op.drop_index("ix_enterprise_bundle_entities_status", "enterprise_bundle_entities")
    op.drop_index(
        "ix_enterprise_bundle_entities_tenant_id", "enterprise_bundle_entities"
    )
    op.drop_table("enterprise_bundle_entities")


def _drop_memory_tables() -> None:
    """Drop memory tables in reverse dependency order."""
    op.drop_index(
        "ix_enterprise_module_memory_items_memory_item_id",
        "enterprise_module_memory_items",
    )
    op.drop_index(
        "ix_enterprise_module_memory_items_module_id",
        "enterprise_module_memory_items",
    )
    op.drop_index(
        "ix_enterprise_module_memory_items_tenant_id",
        "enterprise_module_memory_items",
    )
    op.drop_table("enterprise_module_memory_items")

    op.drop_index(
        "ix_enterprise_context_modules_tenant_id", "enterprise_context_modules"
    )
    op.drop_table("enterprise_context_modules")

    op.drop_index("ix_enterprise_memory_items_project_id", "enterprise_memory_items")
    op.drop_index("ix_enterprise_memory_items_tenant_id", "enterprise_memory_items")
    op.drop_table("enterprise_memory_items")


def _drop_workflow_tables() -> None:
    """Drop workflow tables in reverse dependency order."""
    op.drop_index(
        "ix_enterprise_execution_steps_stage_id", "enterprise_execution_steps"
    )
    op.drop_index(
        "ix_enterprise_execution_steps_execution_id", "enterprise_execution_steps"
    )
    op.drop_index(
        "ix_enterprise_execution_steps_tenant_id", "enterprise_execution_steps"
    )
    op.drop_table("enterprise_execution_steps")

    op.drop_index(
        "ix_enterprise_workflow_executions_status",
        "enterprise_workflow_executions",
    )
    op.drop_index(
        "ix_enterprise_workflow_executions_workflow_id",
        "enterprise_workflow_executions",
    )
    op.drop_index(
        "ix_enterprise_workflow_executions_tenant_id",
        "enterprise_workflow_executions",
    )
    op.drop_table("enterprise_workflow_executions")

    op.drop_index(
        "ix_enterprise_workflow_stages_workflow_id", "enterprise_workflow_stages"
    )
    op.drop_index(
        "ix_enterprise_workflow_stages_tenant_id", "enterprise_workflow_stages"
    )
    op.drop_table("enterprise_workflow_stages")

    op.drop_index("ix_enterprise_workflows_tenant_id", "enterprise_workflows")
    op.drop_table("enterprise_workflows")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop all 15 enterprise critical-domain tables (PostgreSQL only)."""
    if not _is_postgresql():
        log.info(
            "ent_016_enterprise_critical_domains downgrade: "
            "non-PostgreSQL dialect detected; skipping."
        )
        return

    log.info("ent_016_enterprise_critical_domains downgrade: running PostgreSQL path.")

    # Drop in reverse dependency order: BOM → bundle → memory → workflow
    _drop_bom_attestation_tables()
    _drop_bundle_tables()
    _drop_memory_tables()
    _drop_workflow_tables()

    log.info(
        "ent_016_enterprise_critical_domains downgrade: all 15 tables dropped successfully."
    )
