"""Add collection_tier, namespace, fqan to artifacts; create tier_namespaces (DVCS-3.1).

Revision ID: 20260330_0009_add_tier_fqan_columns
Revises: 20260330_0008_backfill_bundle_commits_from_membership
Create Date: 2026-03-30 00:09:00.000000+00:00

Background
----------
Introduces the schema foundation for the DVCS 4-tier collection inheritance
system (DVCS Phase 3, Task 3.1).

Changes
-------
1. Three new nullable columns on ``artifacts``:
   - ``collection_tier`` (TEXT) — one of 'marketplace'|'enterprise'|'team'|'dev'|'project'.
   - ``namespace``        (TEXT) — namespace slug within the tier.
   - ``fqan``             (TEXT) — canonical DVCS address (scope://namespace/name@version).

2. New indexes on ``artifacts``:
   - ``idx_artifacts_fqan``                   — lookup by FQAN (partial: WHERE fqan IS NOT NULL).
   - ``idx_artifacts_upper_tier_fqan_unique`` — UNIQUE on (collection_tier, namespace, name, type)
                                                 WHERE collection_tier IN ('enterprise','team','dev').
   - ``idx_artifacts_project_tier_fqan_unique``— UNIQUE on (project_id, namespace, name, type)
                                                  WHERE collection_tier = 'project'.

3. CHECK constraints on ``artifacts``:
   - ``check_artifacts_collection_tier`` — tier domain guard.
   - ``check_artifacts_fqan_format``     — lightweight FQAN format guard (LIKE '%://%/%@%').

4. New table ``tier_namespaces``:
   - Registry of valid (tier, namespace) combinations with optional hierarchy.
   - CHECK constraint on ``tier`` column mirrors CollectionTier enum values.
   - UNIQUE on ``(tier, namespace)``.

5. Backfill existing ``artifacts`` rows:
   - ``collection_tier`` → 'dev'
   - ``namespace``        → 'personal'
   - ``fqan``             → 'dev://personal/<name>@<deployed_version_or_unknown>'

6. Update ``change_origin`` CHECK constraint on ``artifact_versions`` to include 'rename'.

Dialect Strategy
----------------
- SQLite: ``batch_alter_table`` for all ALTER TABLE operations; partial indexes via
  ``sqlite_where`` expressed as raw SQL strings in ``op.create_index()``.
- PostgreSQL: standard ``ADD COLUMN`` + ``CREATE INDEX`` with WHERE clause.

Both dialects use idempotency guards (column/table/index existence checks) so
the migration is safe to re-run.

Downgrade
---------
Reverses all changes in reverse dependency order:
1. Restore ``artifact_versions`` CHECK constraint (remove 'rename').
2. Drop ``tier_namespaces`` table.
3. Drop FQAN/tier indexes on ``artifacts``.
4. Drop ``collection_tier``, ``namespace``, ``fqan`` columns from ``artifacts``.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0009_add_tier_fqan_columns"
down_revision: Union[str, None] = (
    "20260330_0008_backfill_bundle_commits_from_membership"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ARTIFACTS_TABLE = "artifacts"
_VERSIONS_TABLE = "artifact_versions"
_NS_TABLE = "tier_namespaces"

# New artifact columns
_COL_TIER = "collection_tier"
_COL_NS = "namespace"
_COL_FQAN = "fqan"

# Index names
_IDX_FQAN = "idx_artifacts_fqan"
_IDX_UPPER_UNIQ = "idx_artifacts_upper_tier_fqan_unique"
_IDX_PROJECT_UNIQ = "idx_artifacts_project_tier_fqan_unique"

# Check constraint names
_CK_TIER = "check_artifacts_collection_tier"
_CK_FQAN_FMT = "check_artifacts_fqan_format"
_CK_NS_TIER = "check_tier_namespaces_tier"

# artifact_versions change_origin constraint
_CK_ORIGIN_OLD = "check_artifact_versions_change_origin"
_ORIGIN_VALUES_OLD = (
    "'initial_seed', 'deployment', 'sync', 'local_modification', "
    "'restore', 'promotion', 'push', 'github_update', 'import', "
    "'policy_enforcement', 'composite_update'"
)
_ORIGIN_VALUES_NEW = (
    "'initial_seed', 'deployment', 'sync', 'local_modification', "
    "'restore', 'promotion', 'push', 'github_update', 'import', "
    "'policy_enforcement', 'composite_update', 'rename'"
)


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(bind: sa.engine.Connection, table: str, column: str) -> bool:
    if bind.dialect.name == "sqlite":
        result = bind.execute(text(f"PRAGMA table_info({table})"))
        return any(row[1] == column for row in result.fetchall())
    else:
        result = bind.execute(
            text(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = :t AND column_name = :c"
            ),
            {"t": table, "c": column},
        )
        return result.fetchone() is not None


def _table_exists(bind: sa.engine.Connection, table: str) -> bool:
    if bind.dialect.name == "sqlite":
        result = bind.execute(
            text("SELECT 1 FROM sqlite_master WHERE type='table' AND name=:t"),
            {"t": table},
        )
        return result.fetchone() is not None
    else:
        result = bind.execute(
            text(
                "SELECT 1 FROM information_schema.tables "
                "WHERE table_name = :t AND table_schema = 'public'"
            ),
            {"t": table},
        )
        return result.fetchone() is not None


def _index_exists(bind: sa.engine.Connection, index: str) -> bool:
    if bind.dialect.name == "sqlite":
        result = bind.execute(
            text("SELECT 1 FROM sqlite_master WHERE type='index' AND name=:i"),
            {"i": index},
        )
        return result.fetchone() is not None
    else:
        result = bind.execute(
            text("SELECT 1 FROM pg_indexes WHERE indexname = :i"),
            {"i": index},
        )
        return result.fetchone() is not None


def _constraint_exists_pg(
    bind: sa.engine.Connection, constraint: str, table: str
) -> bool:
    result = bind.execute(
        text(
            "SELECT 1 FROM pg_constraint c "
            "JOIN pg_class t ON t.oid = c.conrelid "
            "WHERE c.conname = :cname AND t.relname = :tname"
        ),
        {"cname": constraint, "tname": table},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add collection_tier, namespace, fqan columns; create tier_namespaces table."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_tier_fqan_columns upgrade: SQLite path.")
        _upgrade_sqlite(bind)
    elif is_postgresql():
        log.info("add_tier_fqan_columns upgrade: PostgreSQL path.")
        _upgrade_postgresql(bind)
    else:
        log.warning(
            "add_tier_fqan_columns upgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


# ---------------------------------------------------------------------------
# SQLite upgrade
# ---------------------------------------------------------------------------


def _upgrade_sqlite(bind: sa.engine.Connection) -> None:
    # ------------------------------------------------------------------
    # 1. Add columns to artifacts via plain ADD COLUMN
    #
    # Use op.add_column() instead of batch_alter_table.  All columns are
    # nullable, so ALTER TABLE ADD COLUMN works natively on SQLite.
    # batch_alter_table with recreate="auto" triggers a full table copy
    # which fails when PRAGMA foreign_keys=ON and other tables (e.g.
    # artifact_versions) reference artifacts via FK constraints.
    # ------------------------------------------------------------------
    _tier_columns = [
        (
            _COL_TIER,
            sa.Column(
                _COL_TIER,
                sa.String(),
                nullable=True,
                comment=(
                    "DVCS collection tier: 'marketplace'|'enterprise'|"
                    "'team'|'dev'|'project'."
                ),
            ),
        ),
        (
            _COL_NS,
            sa.Column(
                _COL_NS,
                sa.String(),
                nullable=True,
                comment="Namespace slug within the collection_tier.",
            ),
        ),
        (
            _COL_FQAN,
            sa.Column(
                _COL_FQAN,
                sa.String(),
                nullable=True,
                comment=(
                    "Canonical FQAN: scope://namespace/name@version. "
                    "Application-computed."
                ),
            ),
        ),
    ]

    for col_name, col_def in _tier_columns:
        if not _column_exists(bind, _ARTIFACTS_TABLE, col_name):
            op.add_column(_ARTIFACTS_TABLE, col_def)
            log.info(
                "add_tier_fqan_columns (SQLite): added %s to %s.",
                col_name,
                _ARTIFACTS_TABLE,
            )

    # CHECK constraints: SQLite doesn't support ADD CONSTRAINT via ALTER
    # TABLE, so these are only enforceable via table recreation.  Since we
    # avoid recreation to prevent FK failures, we skip CHECK constraints
    # on SQLite — they are enforced at the application layer instead.
    # PostgreSQL path adds them properly via ADD CONSTRAINT.

    # ------------------------------------------------------------------
    # 2. Create partial indexes on artifacts
    # ------------------------------------------------------------------
    if not _index_exists(bind, _IDX_FQAN):
        op.create_index(
            _IDX_FQAN,
            _ARTIFACTS_TABLE,
            [_COL_FQAN],
            sqlite_where=text("fqan IS NOT NULL"),
        )
        log.info("add_tier_fqan_columns (SQLite): created index %s.", _IDX_FQAN)

    if not _index_exists(bind, _IDX_UPPER_UNIQ):
        op.create_index(
            _IDX_UPPER_UNIQ,
            _ARTIFACTS_TABLE,
            [_COL_TIER, _COL_NS, "name", "type"],
            unique=True,
            sqlite_where=text("collection_tier IN ('enterprise', 'team', 'dev')"),
        )
        log.info("add_tier_fqan_columns (SQLite): created index %s.", _IDX_UPPER_UNIQ)

    if not _index_exists(bind, _IDX_PROJECT_UNIQ):
        op.create_index(
            _IDX_PROJECT_UNIQ,
            _ARTIFACTS_TABLE,
            ["project_id", _COL_NS, "name", "type"],
            unique=True,
            sqlite_where=text("collection_tier = 'project'"),
        )
        log.info("add_tier_fqan_columns (SQLite): created index %s.", _IDX_PROJECT_UNIQ)

    # ------------------------------------------------------------------
    # 3. Create tier_namespaces table
    # ------------------------------------------------------------------
    if not _table_exists(bind, _NS_TABLE):
        op.create_table(
            _NS_TABLE,
            sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
            sa.Column("tier", sa.String(), nullable=False),
            sa.Column("namespace", sa.String(), nullable=False),
            sa.Column("display_name", sa.String(), nullable=True),
            sa.Column("description", sa.Text(), nullable=True),
            sa.Column(
                "parent_namespace_id",
                sa.Integer(),
                sa.ForeignKey("tier_namespaces.id", ondelete="SET NULL"),
                nullable=True,
            ),
            sa.Column("created_at", sa.DateTime(), nullable=False),
            sa.Column("updated_at", sa.DateTime(), nullable=False),
            # Constraints
            sa.CheckConstraint(
                "tier IN ('marketplace', 'enterprise', 'team', 'dev', 'project')",
                name=_CK_NS_TIER,
            ),
            sa.UniqueConstraint(
                "tier", "namespace", name="uq_tier_namespaces_tier_namespace"
            ),
        )
        log.info("add_tier_fqan_columns (SQLite): created %s.", _NS_TABLE)

    # ------------------------------------------------------------------
    # 4. Backfill existing artifacts with default tier/namespace/fqan
    # ------------------------------------------------------------------
    _backfill_artifacts(bind)

    # ------------------------------------------------------------------
    # 5. Update artifact_versions change_origin CHECK constraint
    # ------------------------------------------------------------------
    _upgrade_change_origin_sqlite(bind)


def _upgrade_change_origin_sqlite(bind: sa.engine.Connection) -> None:
    """Recreate artifact_versions with updated change_origin CHECK.

    SQLite does not expose named CHECK constraints to Alembic's reflection
    engine, so ``drop_constraint`` with a name will fail.  Instead we force a
    full table recreation via ``recreate='always'`` and provide the updated
    constraint directly in the new constraint list.  The old CHECK is implicitly
    replaced by the table copy.

    FK safety: We must disable PRAGMA foreign_keys before the batch recreation.
    When foreign_keys=ON, the INSERT INTO _alembic_tmp_* ... SELECT FROM
    original_table fails because other tables (bundle_commit_members,
    artifact_collection_versions) hold FK references to artifact_versions.id,
    and SQLite validates FKs on the *source* table during the copy.
    """
    bind.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table(
            _VERSIONS_TABLE,
            recreate="always",
        ) as batch_op:
            batch_op.create_check_constraint(
                _CK_ORIGIN_OLD,
                f"change_origin IN ({_ORIGIN_VALUES_NEW})",
            )
        log.info(
            "add_tier_fqan_columns (SQLite): updated %s change_origin CHECK.",
            _VERSIONS_TABLE,
        )
    finally:
        bind.execute(text("PRAGMA foreign_keys = ON"))


# ---------------------------------------------------------------------------
# PostgreSQL upgrade
# ---------------------------------------------------------------------------


def _upgrade_postgresql(bind: sa.engine.Connection) -> None:
    # ------------------------------------------------------------------
    # 1. Add columns to artifacts
    # ------------------------------------------------------------------
    if not _column_exists(bind, _ARTIFACTS_TABLE, _COL_TIER):
        op.add_column(
            _ARTIFACTS_TABLE,
            sa.Column(
                _COL_TIER,
                sa.String(),
                nullable=True,
                comment=(
                    "DVCS collection tier: 'marketplace'|'enterprise'|"
                    "'team'|'dev'|'project'."
                ),
            ),
        )
        op.add_column(
            _ARTIFACTS_TABLE,
            sa.Column(
                _COL_NS,
                sa.String(),
                nullable=True,
                comment="Namespace slug within the collection_tier.",
            ),
        )
        op.add_column(
            _ARTIFACTS_TABLE,
            sa.Column(
                _COL_FQAN,
                sa.String(),
                nullable=True,
                comment=(
                    "Canonical FQAN: scope://namespace/name@version. "
                    "Application-computed."
                ),
            ),
        )
        # CHECK constraints
        op.create_check_constraint(
            _CK_TIER,
            _ARTIFACTS_TABLE,
            (
                "collection_tier IN ('marketplace', 'enterprise', 'team', 'dev', "
                "'project') OR collection_tier IS NULL"
            ),
        )
        op.create_check_constraint(
            _CK_FQAN_FMT,
            _ARTIFACTS_TABLE,
            "fqan LIKE '%://%/%@%' OR fqan IS NULL",
        )
        log.info(
            "add_tier_fqan_columns (PG): added %s, %s, %s to %s.",
            _COL_TIER,
            _COL_NS,
            _COL_FQAN,
            _ARTIFACTS_TABLE,
        )

    # ------------------------------------------------------------------
    # 2. Partial indexes on artifacts
    # ------------------------------------------------------------------
    if not _index_exists(bind, _IDX_FQAN):
        op.create_index(
            _IDX_FQAN,
            _ARTIFACTS_TABLE,
            [_COL_FQAN],
            postgresql_where=text("fqan IS NOT NULL"),
        )
        log.info("add_tier_fqan_columns (PG): created index %s.", _IDX_FQAN)

    if not _index_exists(bind, _IDX_UPPER_UNIQ):
        op.create_index(
            _IDX_UPPER_UNIQ,
            _ARTIFACTS_TABLE,
            [_COL_TIER, _COL_NS, "name", "type"],
            unique=True,
            postgresql_where=text("collection_tier IN ('enterprise', 'team', 'dev')"),
        )
        log.info("add_tier_fqan_columns (PG): created index %s.", _IDX_UPPER_UNIQ)

    if not _index_exists(bind, _IDX_PROJECT_UNIQ):
        op.create_index(
            _IDX_PROJECT_UNIQ,
            _ARTIFACTS_TABLE,
            ["project_id", _COL_NS, "name", "type"],
            unique=True,
            postgresql_where=text("collection_tier = 'project'"),
        )
        log.info("add_tier_fqan_columns (PG): created index %s.", _IDX_PROJECT_UNIQ)

    # ------------------------------------------------------------------
    # 3. Create tier_namespaces
    # ------------------------------------------------------------------
    if not _table_exists(bind, _NS_TABLE):
        op.create_table(
            _NS_TABLE,
            sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
            sa.Column("tier", sa.String(), nullable=False),
            sa.Column("namespace", sa.String(), nullable=False),
            sa.Column("display_name", sa.String(), nullable=True),
            sa.Column("description", sa.Text(), nullable=True),
            sa.Column(
                "parent_namespace_id",
                sa.Integer(),
                sa.ForeignKey("tier_namespaces.id", ondelete="SET NULL"),
                nullable=True,
            ),
            sa.Column(
                "created_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("NOW()"),
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("NOW()"),
            ),
            sa.CheckConstraint(
                "tier IN ('marketplace', 'enterprise', 'team', 'dev', 'project')",
                name=_CK_NS_TIER,
            ),
            sa.UniqueConstraint(
                "tier", "namespace", name="uq_tier_namespaces_tier_namespace"
            ),
        )
        log.info("add_tier_fqan_columns (PG): created %s.", _NS_TABLE)

    # ------------------------------------------------------------------
    # 4. Backfill
    # ------------------------------------------------------------------
    _backfill_artifacts(bind)

    # ------------------------------------------------------------------
    # 5. Update artifact_versions change_origin CHECK
    # ------------------------------------------------------------------
    # Enterprise PG schema lacks change_origin — nothing to constrain.
    col_check = bind.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = 'artifact_versions' AND column_name = 'change_origin'"
        )
    )
    if not col_check.fetchone():
        log.info(
            "add_tier_fqan_columns (PG): artifact_versions.change_origin "
            "does not exist (enterprise schema); skipping constraint update."
        )
    else:
        if _constraint_exists_pg(bind, _CK_ORIGIN_OLD, _VERSIONS_TABLE):
            op.drop_constraint(_CK_ORIGIN_OLD, _VERSIONS_TABLE, type_="check")
        op.create_check_constraint(
            _CK_ORIGIN_OLD,
            _VERSIONS_TABLE,
            f"change_origin IN ({_ORIGIN_VALUES_NEW})",
        )
        log.info(
            "add_tier_fqan_columns (PG): updated %s change_origin CHECK.",
            _VERSIONS_TABLE,
        )


# ---------------------------------------------------------------------------
# Backfill helper (dialect-agnostic SQL)
# ---------------------------------------------------------------------------


def _backfill_artifacts(bind: sa.engine.Connection) -> None:
    """Set collection_tier/namespace/fqan for all existing artifacts.

    Existing artifacts had no tier information, so they are bootstrapped
    to the personal developer workspace:
    - ``collection_tier`` = 'dev'
    - ``namespace``        = 'personal'
    - ``fqan``             = 'dev://personal/<name>@<deployed_version>'
      (uses 'unknown' when deployed_version is NULL)
    """
    bind.execute(text("""
            UPDATE artifacts
            SET
                collection_tier = 'dev',
                namespace       = 'personal',
                fqan            = 'dev://personal/' || name || '@' ||
                                  COALESCE(deployed_version, 'unknown')
            WHERE collection_tier IS NULL
            """))
    log.info(
        "add_tier_fqan_columns: backfilled artifacts with "
        "collection_tier='dev', namespace='personal'."
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove tier/FQAN columns, drop tier_namespaces, restore old CHECK."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_tier_fqan_columns downgrade: SQLite path.")
        _downgrade_sqlite(bind)
    elif is_postgresql():
        log.info("add_tier_fqan_columns downgrade: PostgreSQL path.")
        _downgrade_postgresql(bind)
    else:
        log.warning(
            "add_tier_fqan_columns downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


# ---------------------------------------------------------------------------
# SQLite downgrade
# ---------------------------------------------------------------------------


def _downgrade_sqlite(bind: sa.engine.Connection) -> None:
    # Disable FK checks for all batch_alter_table operations that use
    # recreate (table copy fails when other tables hold FK references).
    bind.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        # 1. Restore artifact_versions change_origin CHECK (remove 'rename')
        with op.batch_alter_table(_VERSIONS_TABLE, recreate="always") as batch_op:
            batch_op.create_check_constraint(
                _CK_ORIGIN_OLD,
                f"change_origin IN ({_ORIGIN_VALUES_OLD})",
            )
        log.info(
            "add_tier_fqan_columns (SQLite) downgrade: restored change_origin CHECK."
        )

        # 2. Drop tier_namespaces
        if _table_exists(bind, _NS_TABLE):
            op.drop_table(_NS_TABLE)
            log.info("add_tier_fqan_columns (SQLite) downgrade: dropped %s.", _NS_TABLE)

        # 3. Drop partial indexes on artifacts
        for idx in (_IDX_PROJECT_UNIQ, _IDX_UPPER_UNIQ, _IDX_FQAN):
            if _index_exists(bind, idx):
                op.drop_index(idx, table_name=_ARTIFACTS_TABLE)
                log.info(
                    "add_tier_fqan_columns (SQLite) downgrade: dropped index %s.", idx
                )

        # 4. Drop columns from artifacts via batch_alter_table
        if _column_exists(bind, _ARTIFACTS_TABLE, _COL_FQAN):
            with op.batch_alter_table(_ARTIFACTS_TABLE, recreate="auto") as batch_op:
                for ck in (_CK_TIER, _CK_FQAN_FMT):
                    try:
                        batch_op.drop_constraint(ck, type_="check")
                    except Exception:
                        pass  # Constraint may not exist if migration was partial
                batch_op.drop_column(_COL_FQAN)
                batch_op.drop_column(_COL_NS)
                batch_op.drop_column(_COL_TIER)
            log.info(
                "add_tier_fqan_columns (SQLite) downgrade: dropped %s, %s, %s from %s.",
                _COL_FQAN,
                _COL_NS,
                _COL_TIER,
                _ARTIFACTS_TABLE,
            )
    finally:
        bind.execute(text("PRAGMA foreign_keys = ON"))


# ---------------------------------------------------------------------------
# PostgreSQL downgrade
# ---------------------------------------------------------------------------


def _downgrade_postgresql(bind: sa.engine.Connection) -> None:
    # 1. Restore artifact_versions change_origin CHECK
    col_check = bind.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = 'artifact_versions' AND column_name = 'change_origin'"
        )
    )
    if col_check.fetchone():
        if _constraint_exists_pg(bind, _CK_ORIGIN_OLD, _VERSIONS_TABLE):
            op.drop_constraint(_CK_ORIGIN_OLD, _VERSIONS_TABLE, type_="check")
        op.create_check_constraint(
            _CK_ORIGIN_OLD,
            _VERSIONS_TABLE,
            f"change_origin IN ({_ORIGIN_VALUES_OLD})",
        )
        log.info("add_tier_fqan_columns (PG) downgrade: restored change_origin CHECK.")
    else:
        log.info(
            "add_tier_fqan_columns (PG) downgrade: artifact_versions.change_origin "
            "does not exist (enterprise schema); skipping."
        )

    # 2. Drop tier_namespaces
    if _table_exists(bind, _NS_TABLE):
        op.drop_table(_NS_TABLE)
        log.info("add_tier_fqan_columns (PG) downgrade: dropped %s.", _NS_TABLE)

    # 3. Drop partial indexes
    for idx in (_IDX_PROJECT_UNIQ, _IDX_UPPER_UNIQ, _IDX_FQAN):
        if _index_exists(bind, idx):
            op.drop_index(idx, table_name=_ARTIFACTS_TABLE)
            log.info("add_tier_fqan_columns (PG) downgrade: dropped index %s.", idx)

    # 4. Drop CHECK constraints
    for ck in (_CK_TIER, _CK_FQAN_FMT):
        if _constraint_exists_pg(bind, ck, _ARTIFACTS_TABLE):
            op.drop_constraint(ck, _ARTIFACTS_TABLE, type_="check")

    # 5. Drop columns
    for col in (_COL_FQAN, _COL_NS, _COL_TIER):
        if _column_exists(bind, _ARTIFACTS_TABLE, col):
            op.drop_column(_ARTIFACTS_TABLE, col)
    log.info(
        "add_tier_fqan_columns (PG) downgrade: dropped %s, %s, %s from %s.",
        _COL_FQAN,
        _COL_NS,
        _COL_TIER,
        _ARTIFACTS_TABLE,
    )
