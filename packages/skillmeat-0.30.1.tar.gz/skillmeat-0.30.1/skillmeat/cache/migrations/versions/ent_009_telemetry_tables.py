"""create telemetry tables: execution_outcomes, project_agentic_metrics

Revision ID: ent_009_telemetry_tables
Revises: ent_008_enterprise_parity_tables
Create Date: 2026-03-25 00:09:00.000000+00:00

Background
----------
TEL-1 telemetry integration feature.  Adds 2 new PostgreSQL tables for
execution telemetry ingestion (TEL-1.1) and aggregated agentic metrics
(TEL-1.2).  The existing SQLite cache is left completely untouched — the
migration is a no-op on any non-PostgreSQL dialect.

Tables created (dependency order)
----------------------------------
1. execution_outcomes
       Per-execution telemetry record for workflow and bundle runs.
       UUID PK (gen_random_uuid()), String project_id/workflow_id/bundle_id,
       String status, JSONB metrics, timing floats, cost float.
       UNIQUE (execution_id) enforces ingestion idempotency.

2. project_agentic_metrics
       Aggregated agentic effectiveness metrics per project and time period.
       UUID PK (gen_random_uuid()), rollup floats, TIMESTAMPTZ period window.
       UNIQUE (project_id, workflow_id, period_start, period_end) supports
       INSERT ... ON CONFLICT DO UPDATE (upsert) for idempotent rollup writes.

Indexes
-------
execution_outcomes:
    uq_execution_outcomes_execution_id     UNIQUE (execution_id)
    idx_execution_outcomes_project_id      (project_id)
    idx_execution_outcomes_project_workflow (project_id, workflow_id)

project_agentic_metrics:
    uq_project_agentic_metrics_period      UNIQUE (project_id, workflow_id, period_start, period_end)
    idx_project_agentic_metrics_project_workflow (project_id, workflow_id)

Downgrade order
---------------
2. project_agentic_metrics  (no FK deps on execution_outcomes)
1. execution_outcomes

Schema reference
----------------
skillmeat/cache/models_telemetry.py  (ExecutionOutcome, ProjectAgenticMetrics)
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_009_telemetry_tables"
down_revision: Union[str, None] = "ent_008_enterprise_parity_tables"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    bind = op.get_bind()
    return bind.dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _table_exists(table_name: str) -> bool:
    """Return True if *table_name* already exists in the current schema."""
    bind = op.get_bind()
    insp = sa.inspect(bind)
    return insp.has_table(table_name)


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create execution_outcomes and project_agentic_metrics (PostgreSQL only)."""
    if not _is_postgresql():
        return  # No-op for SQLite and any other non-PostgreSQL dialect

    # ------------------------------------------------------------------
    # 1. execution_outcomes  (TEL-1.1)
    # ------------------------------------------------------------------
    if not _table_exists("execution_outcomes"):
        op.create_table(
            "execution_outcomes",
            # --- Identity ---
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                primary_key=True,
                server_default=sa.text("gen_random_uuid()"),
                comment="Globally unique row identifier",
            ),
            sa.Column(
                "execution_id",
                sa.String(256),
                nullable=False,
                comment="Caller-supplied unique execution token; enforces ingestion idempotency",
            ),
            # --- Scope ---
            sa.Column(
                "project_id",
                sa.String(256),
                nullable=False,
                comment="Project identifier that owns this execution record",
            ),
            sa.Column(
                "workflow_id",
                sa.String(256),
                nullable=True,
                comment="Workflow identifier; NULL for ad-hoc or non-workflow executions",
            ),
            sa.Column(
                "bundle_id",
                sa.String(256),
                nullable=True,
                comment="Bundle identifier; NULL when the execution is not bundle-driven",
            ),
            # --- Result ---
            sa.Column(
                "status",
                sa.String(50),
                nullable=False,
                comment="Final execution status: success | failure | partial | timeout | error",
            ),
            sa.Column(
                "metrics",
                postgresql.JSONB(astext_type=sa.Text()),
                nullable=True,
                comment="Arbitrary execution-specific metrics payload (token counts, step results, etc.)",
            ),
            # --- Timing ---
            sa.Column(
                "started_at",
                sa.DateTime(timezone=True),
                nullable=True,
                comment="Timezone-aware wall-clock start time of the execution",
            ),
            sa.Column(
                "completed_at",
                sa.DateTime(timezone=True),
                nullable=True,
                comment="Timezone-aware wall-clock end time of the execution",
            ),
            sa.Column(
                "duration_seconds",
                sa.Float,
                nullable=True,
                comment="Wall-clock execution duration in seconds; derived from started_at/completed_at",
            ),
            # --- Cost and client metadata ---
            sa.Column(
                "cost_usd",
                sa.Float,
                nullable=True,
                comment="Estimated monetary cost of the execution in USD",
            ),
            sa.Column(
                "client_version",
                sa.String(50),
                nullable=True,
                comment="Version string of the agent or CLI client that submitted this record",
            ),
            # --- Audit ---
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.text("now()"),
                comment="Timezone-aware row creation timestamp; server-generated",
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.text("now()"),
                comment="Timezone-aware last-modified timestamp; updated by app on every write",
            ),
            # --- Named constraints ---
            sa.UniqueConstraint(
                "execution_id",
                name="uq_execution_outcomes_execution_id",
            ),
        )

        # B-tree: primary project filter (covers most listing queries)
        op.create_index(
            "idx_execution_outcomes_project_id",
            "execution_outcomes",
            ["project_id"],
        )

        # B-tree: workflow-scoped execution history within a project
        op.create_index(
            "idx_execution_outcomes_project_workflow",
            "execution_outcomes",
            ["project_id", "workflow_id"],
        )

    # ------------------------------------------------------------------
    # 2. project_agentic_metrics  (TEL-1.2)
    # ------------------------------------------------------------------
    if not _table_exists("project_agentic_metrics"):
        op.create_table(
            "project_agentic_metrics",
            # --- Identity ---
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                primary_key=True,
                server_default=sa.text("gen_random_uuid()"),
                comment="Globally unique row identifier",
            ),
            # --- Scope ---
            sa.Column(
                "project_id",
                sa.String(256),
                nullable=False,
                comment="Project identifier whose executions are aggregated",
            ),
            sa.Column(
                "workflow_id",
                sa.String(256),
                nullable=True,
                comment="Workflow scope for this rollup; NULL = project-wide aggregate",
            ),
            sa.Column(
                "bundle_id",
                sa.String(256),
                nullable=True,
                comment="Bundle scope for this rollup; NULL = not bundle-scoped",
            ),
            # --- Aggregated metrics ---
            sa.Column(
                "execution_count",
                sa.Integer,
                nullable=False,
                server_default=sa.text("0"),
                comment="Total executions recorded in the period",
            ),
            sa.Column(
                "success_rate",
                sa.Float,
                nullable=True,
                comment="Fraction of executions with status 'success'; range 0.0-1.0",
            ),
            sa.Column(
                "avg_duration_seconds",
                sa.Float,
                nullable=True,
                comment="Mean wall-clock duration in seconds across executions in the period",
            ),
            sa.Column(
                "avg_cost_usd",
                sa.Float,
                nullable=True,
                comment="Mean monetary cost in USD across executions in the period",
            ),
            sa.Column(
                "effectiveness_score",
                sa.Float,
                nullable=True,
                comment="Composite effectiveness score (domain-defined); range 0.0-1.0",
            ),
            # --- Rollup bookkeeping ---
            sa.Column(
                "rollup_computed_at",
                sa.DateTime(timezone=True),
                nullable=True,
                comment="Timestamp of the most recent rollup computation for this row",
            ),
            # --- Time window ---
            sa.Column(
                "period_start",
                sa.DateTime(timezone=True),
                nullable=False,
                comment="Inclusive start of the aggregation time window",
            ),
            sa.Column(
                "period_end",
                sa.DateTime(timezone=True),
                nullable=False,
                comment="Exclusive end of the aggregation time window",
            ),
            # --- Audit ---
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.text("now()"),
                comment="Timezone-aware row creation timestamp; server-generated",
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=sa.text("now()"),
                comment="Timezone-aware last-modified timestamp; updated by app on every write",
            ),
            # --- Named constraints ---
            # UNIQUE on the period slice: supports INSERT ... ON CONFLICT DO UPDATE
            # upsert idempotency for the telemetry aggregation job.
            sa.UniqueConstraint(
                "project_id",
                "workflow_id",
                "period_start",
                "period_end",
                name="uq_project_agentic_metrics_period",
            ),
        )

        # B-tree: workflow-scoped metric history within a project
        op.create_index(
            "idx_project_agentic_metrics_project_workflow",
            "project_agentic_metrics",
            ["project_id", "workflow_id"],
        )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop project_agentic_metrics then execution_outcomes (PostgreSQL only)."""
    if not _is_postgresql():
        return  # No-op for SQLite and any other non-PostgreSQL dialect

    # 2. project_agentic_metrics (no FK dependency on execution_outcomes)
    if _table_exists("project_agentic_metrics"):
        op.drop_index(
            "idx_project_agentic_metrics_project_workflow",
            table_name="project_agentic_metrics",
        )
        op.drop_table("project_agentic_metrics")

    # 1. execution_outcomes
    if _table_exists("execution_outcomes"):
        op.drop_index(
            "idx_execution_outcomes_project_workflow",
            table_name="execution_outcomes",
        )
        op.drop_index(
            "idx_execution_outcomes_project_id",
            table_name="execution_outcomes",
        )
        op.drop_table("execution_outcomes")
