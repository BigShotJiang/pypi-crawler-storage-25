"""Merge two divergent heads (community + enterprise tracks).

Revision ID: 20260402_0001_merge_heads
Revises: 20260401_0004_add_rate_limited_status,
         ent_015_artifact_versions_missing_columns
Create Date: 2026-04-02 00:01:00.000000+00:00

Background
----------
Two parallel development tracks created divergent migration heads:
- Community track leaf:   20260401_0004_add_rate_limited_status
- Enterprise track leaf:  ent_015_artifact_versions_missing_columns

This merge migration unifies both heads without schema changes so that
future migrations can be added as a linear chain.
"""

from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260402_0001_merge_heads"
down_revision: Union[str, tuple[str, ...], None] = (
    "20260401_0004_add_rate_limited_status",
    "ent_015_artifact_versions_missing_columns",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
