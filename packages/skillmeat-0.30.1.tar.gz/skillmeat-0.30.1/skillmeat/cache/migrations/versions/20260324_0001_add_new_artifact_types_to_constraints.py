"""Add new artifact type values to check_artifact_type and check_catalog_artifact_type.

Revision ID: 20260324_0001_add_new_artifact_types_to_constraints
Revises: 20260320_0002_add_bundle_membership_id_pk
Create Date: 2026-03-24 00:01:00.000000+00:00

Background
----------
Six new artifact type values are being introduced to support expanded artifact
detection and the unified artifacts page:

  context_module, template, group, deployment_set, context_pack, bundle

Both of the following CHECK constraints must be extended to permit these values:

1. ``artifacts.type``                — constraint ``check_artifact_type``
2. ``marketplace_catalog_entries.artifact_type`` — constraint ``check_catalog_artifact_type``

Changes
-------
1. ``artifacts`` — extend ``check_artifact_type`` to include the six new types.

   Updated type list:
   ``('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'workflow',
   'composite', 'project_config', 'spec_file', 'rule_file', 'context_file',
   'progress_template', 'context_module', 'template', 'group',
   'deployment_set', 'context_pack', 'bundle')``

2. ``marketplace_catalog_entries`` — extend ``check_catalog_artifact_type`` to
   include the six new types.

   Updated type list:
   ``('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'composite',
   'project_config', 'spec_file', 'rule_file', 'context_file',
   'progress_template', 'context_module', 'template', 'group',
   'deployment_set', 'context_pack', 'bundle')``

SQLite Strategy
---------------
SQLite does not support ``ALTER TABLE ... DROP/ADD CONSTRAINT``.  The
``batch_alter_table(recreate="always")`` approach performs a transparent
full-table rebuild (create new table, copy rows, drop old table, rename).

For the ``artifacts`` table, FK enforcement is temporarily disabled around
the rebuild to prevent FK violations from child tables that reference
``artifacts.uuid`` (e.g. ``collection_artifacts``, ``group_artifacts``,
``artifact_tags``).

For ``marketplace_catalog_entries``, no child tables hold FKs referencing it,
so FK enforcement does not need to be toggled.

PostgreSQL Strategy
-------------------
PostgreSQL supports native ``ALTER TABLE ... DROP CONSTRAINT`` followed by
``ALTER TABLE ... ADD CONSTRAINT``, so no table rebuild is required.

Idempotency
-----------
Both upgrade paths are idempotent: if a new type value is already present in
the existing constraint definition (e.g. because ``Base.metadata.create_all()``
ran against an updated model before this migration), the operation is skipped.

Backward Compatibility
----------------------
Existing rows are unaffected.  All previously valid type values remain in the
updated constraints.  Code that does not use the new types continues to work
unchanged.

Rollback
--------
Rebuilds both tables (or re-applies the ALTER TABLE on PostgreSQL) with the
original constraint definitions that do not include the six new type values.
Rows that carry one of the new type values will violate the restored
constraints; callers are responsible for removing or migrating such rows
before running the downgrade.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260324_0001_add_new_artifact_types_to_constraints"
down_revision: Union[str, None] = "20260320_0002_add_bundle_membership_id_pk"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ---------------------------------------------------------------------------
# Canonical type-list strings — single source of truth for this migration.
# ---------------------------------------------------------------------------

# artifacts.type — check_artifact_type
_ARTIFACTS_TYPES_NEW = (
    "('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'workflow', "
    "'composite', 'project_config', 'spec_file', 'rule_file', 'context_file', "
    "'progress_template', 'context_module', 'template', 'group', "
    "'deployment_set', 'context_pack', 'bundle')"
)
_ARTIFACTS_TYPES_OLD = (
    "('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'workflow', "
    "'composite', 'project_config', 'spec_file', 'rule_file', 'context_file', "
    "'progress_template')"
)

# marketplace_catalog_entries.artifact_type — check_catalog_artifact_type
_CATALOG_TYPES_NEW = (
    "('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'composite', "
    "'project_config', 'spec_file', 'rule_file', 'context_file', "
    "'progress_template', 'context_module', 'template', 'group', "
    "'deployment_set', 'context_pack', 'bundle')"
)
_CATALOG_TYPES_OLD = (
    "('skill', 'command', 'agent', 'mcp', 'mcp_server', 'hook', 'composite', "
    "'project_config', 'spec_file', 'rule_file', 'context_file', "
    "'progress_template')"
)

# PostgreSQL constraint names — must match ORM model definitions.
_PG_ARTIFACTS_CONSTRAINT = "check_artifact_type"
_PG_CATALOG_CONSTRAINT = "check_catalog_artifact_type"

# Sentinel: one of the new values used for idempotency checks.
_SENTINEL = "'context_module'"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _new_types_already_in_constraint_sqlite(
    bind: sa.engine.Connection, table_name: str
) -> bool:
    """Return True if the constraint for *table_name* already contains the new types (SQLite).

    SQLite stores the original SQL text of CHECK constraints in
    ``sqlite_master``.  We check for the presence of the sentinel value
    ``'context_module'`` to determine whether this migration has already run.
    """
    result = bind.execute(
        text("SELECT sql FROM sqlite_master " "WHERE type='table' AND name=:tname"),
        {"tname": table_name},
    )
    row = result.fetchone()
    if row is None:
        return False
    create_sql: str = row[0] or ""
    return _SENTINEL in create_sql


def _new_types_already_in_constraint_pg(
    bind: sa.engine.Connection, constraint_name: str, table_name: str
) -> bool:
    """Return True if *constraint_name* on *table_name* already lists the new types (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT pg_get_constraintdef(c.oid)
            FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :cname
              AND t.relname = :tname
              AND c.contype = 'c'
            """),
        {"cname": constraint_name, "tname": table_name},
    )
    row = result.fetchone()
    if row is None:
        return False
    constraint_def: str = row[0] or ""
    return "context_module" in constraint_def


def _get_pg_constraint_name(
    bind: sa.engine.Connection, constraint_name: str, table_name: str
) -> str | None:
    """Return the constraint name if it exists on *table_name* (PostgreSQL), else None."""
    result = bind.execute(
        text("""
            SELECT c.conname
            FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :cname
              AND t.relname = :tname
              AND c.contype = 'c'
            """),
        {"cname": constraint_name, "tname": table_name},
    )
    row = result.fetchone()
    return row[0] if row else None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Extend both artifact-type CHECK constraints with the six new values."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_new_artifact_types upgrade: running SQLite dialect path.")
        _upgrade_artifacts_sqlite(bind)
        _upgrade_catalog_sqlite(bind)
    elif is_postgresql():
        log.info("add_new_artifact_types upgrade: running PostgreSQL dialect path.")
        _upgrade_artifacts_postgresql(bind)
        _upgrade_catalog_postgresql(bind)
    else:
        log.warning(
            "add_new_artifact_types upgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _upgrade_artifacts_sqlite(bind: sa.engine.Connection) -> None:
    if _new_types_already_in_constraint_sqlite(bind, "artifacts"):
        log.info(
            "add_new_artifact_types (SQLite): artifacts constraint already "
            "contains new types; skipping."
        )
        return

    # Disable FK enforcement to prevent violations from child tables that
    # reference artifacts.uuid during the table rebuild.
    op.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table("artifacts", recreate="always") as batch_op:
            batch_op.drop_constraint("check_artifact_type", type_="check")
            batch_op.create_check_constraint(
                "check_artifact_type",
                f"type IN {_ARTIFACTS_TYPES_NEW}",
            )
    finally:
        op.execute(text("PRAGMA foreign_keys = ON"))


def _upgrade_catalog_sqlite(bind: sa.engine.Connection) -> None:
    if _new_types_already_in_constraint_sqlite(bind, "marketplace_catalog_entries"):
        log.info(
            "add_new_artifact_types (SQLite): marketplace_catalog_entries constraint "
            "already contains new types; skipping."
        )
        return

    with op.batch_alter_table(
        "marketplace_catalog_entries", recreate="always"
    ) as batch_op:
        batch_op.drop_constraint("check_catalog_artifact_type", type_="check")
        batch_op.create_check_constraint(
            "check_catalog_artifact_type",
            f"artifact_type IN {_CATALOG_TYPES_NEW}",
        )


def _upgrade_artifacts_postgresql(bind: sa.engine.Connection) -> None:
    if _new_types_already_in_constraint_pg(bind, _PG_ARTIFACTS_CONSTRAINT, "artifacts"):
        log.info(
            "add_new_artifact_types (PostgreSQL): artifacts constraint already "
            "contains new types; skipping."
        )
        return

    existing_name = _get_pg_constraint_name(bind, _PG_ARTIFACTS_CONSTRAINT, "artifacts")
    if existing_name:
        op.execute(text(f"ALTER TABLE artifacts DROP CONSTRAINT {existing_name}"))

    op.execute(
        text(
            f"ALTER TABLE artifacts ADD CONSTRAINT {_PG_ARTIFACTS_CONSTRAINT} "
            f"CHECK (type IN ('skill', 'command', 'agent', 'mcp', 'mcp_server', "
            f"'hook', 'workflow', 'composite', 'project_config', 'spec_file', "
            f"'rule_file', 'context_file', 'progress_template', "
            f"'context_module', 'template', 'group', 'deployment_set', "
            f"'context_pack', 'bundle'))"
        )
    )


def _upgrade_catalog_postgresql(bind: sa.engine.Connection) -> None:
    if _new_types_already_in_constraint_pg(
        bind, _PG_CATALOG_CONSTRAINT, "marketplace_catalog_entries"
    ):
        log.info(
            "add_new_artifact_types (PostgreSQL): marketplace_catalog_entries constraint "
            "already contains new types; skipping."
        )
        return

    existing_name = _get_pg_constraint_name(
        bind, _PG_CATALOG_CONSTRAINT, "marketplace_catalog_entries"
    )
    if existing_name:
        op.execute(
            text(
                f"ALTER TABLE marketplace_catalog_entries "
                f"DROP CONSTRAINT {existing_name}"
            )
        )

    op.execute(
        text(
            f"ALTER TABLE marketplace_catalog_entries "
            f"ADD CONSTRAINT {_PG_CATALOG_CONSTRAINT} "
            f"CHECK (artifact_type IN ('skill', 'command', 'agent', 'mcp', "
            f"'mcp_server', 'hook', 'composite', 'project_config', 'spec_file', "
            f"'rule_file', 'context_file', 'progress_template', "
            f"'context_module', 'template', 'group', 'deployment_set', "
            f"'context_pack', 'bundle'))"
        )
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Restore both CHECK constraints to exclude the six new type values.

    WARNING: rows carrying one of the new type values
    (``context_module``, ``template``, ``group``, ``deployment_set``,
    ``context_pack``, ``bundle``) will violate the restored constraints.
    Remove or migrate those rows before running the downgrade.
    """
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_new_artifact_types downgrade: running SQLite dialect path.")
        _downgrade_artifacts_sqlite()
        _downgrade_catalog_sqlite()
    elif is_postgresql():
        log.info("add_new_artifact_types downgrade: running PostgreSQL dialect path.")
        _downgrade_artifacts_postgresql(bind)
        _downgrade_catalog_postgresql(bind)
    else:
        log.warning(
            "add_new_artifact_types downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _downgrade_artifacts_sqlite() -> None:
    op.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table("artifacts", recreate="always") as batch_op:
            batch_op.drop_constraint("check_artifact_type", type_="check")
            batch_op.create_check_constraint(
                "check_artifact_type",
                f"type IN {_ARTIFACTS_TYPES_OLD}",
            )
    finally:
        op.execute(text("PRAGMA foreign_keys = ON"))


def _downgrade_catalog_sqlite() -> None:
    with op.batch_alter_table(
        "marketplace_catalog_entries", recreate="always"
    ) as batch_op:
        batch_op.drop_constraint("check_catalog_artifact_type", type_="check")
        batch_op.create_check_constraint(
            "check_catalog_artifact_type",
            f"artifact_type IN {_CATALOG_TYPES_OLD}",
        )


def _downgrade_artifacts_postgresql(bind: sa.engine.Connection) -> None:
    existing_name = _get_pg_constraint_name(bind, _PG_ARTIFACTS_CONSTRAINT, "artifacts")
    if existing_name:
        op.execute(text(f"ALTER TABLE artifacts DROP CONSTRAINT {existing_name}"))

    op.execute(
        text(
            f"ALTER TABLE artifacts ADD CONSTRAINT {_PG_ARTIFACTS_CONSTRAINT} "
            f"CHECK (type IN ('skill', 'command', 'agent', 'mcp', 'mcp_server', "
            f"'hook', 'workflow', 'composite', 'project_config', 'spec_file', "
            f"'rule_file', 'context_file', 'progress_template'))"
        )
    )


def _downgrade_catalog_postgresql(bind: sa.engine.Connection) -> None:
    existing_name = _get_pg_constraint_name(
        bind, _PG_CATALOG_CONSTRAINT, "marketplace_catalog_entries"
    )
    if existing_name:
        op.execute(
            text(
                f"ALTER TABLE marketplace_catalog_entries "
                f"DROP CONSTRAINT {existing_name}"
            )
        )

    op.execute(
        text(
            f"ALTER TABLE marketplace_catalog_entries "
            f"ADD CONSTRAINT {_PG_CATALOG_CONSTRAINT} "
            f"CHECK (artifact_type IN ('skill', 'command', 'agent', 'mcp', "
            f"'mcp_server', 'hook', 'composite', 'project_config', 'spec_file', "
            f"'rule_file', 'context_file', 'progress_template'))"
        )
    )
