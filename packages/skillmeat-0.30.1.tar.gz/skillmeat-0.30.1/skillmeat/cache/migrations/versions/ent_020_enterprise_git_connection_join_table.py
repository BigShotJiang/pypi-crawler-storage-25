"""Add team_id to enterprise_git_repo_connections and create enterprise_project_git_connections join table.

Revision ID: ent_020_enterprise_git_connection_join_table
Revises: ent_019_enterprise_artifacts_type_constraint
Create Date: 2026-04-03 00:00:00.000000+00:00

Background
----------
GCD-1.3: Enterprise counterpart to the local ``project_git_connections``
migration (GCD-1.2).  This migration extends the enterprise git-connector
schema with two changes:

1. ``team_id`` column on ``enterprise_git_repo_connections``
   A nullable UUID FK to ``enterprise_teams.id`` (ON DELETE SET NULL).
   Allows connections to be scoped to a team rather than (or in addition to)
   an individual project.  Indexed as ``(tenant_id, team_id)`` for the
   mandatory tenant-scoped query pattern.

2. ``enterprise_project_git_connections`` join table
   A composite-PK junction linking enterprise projects to enterprise git-repo
   connections, supporting a many-to-many relationship.  All rows carry
   ``tenant_id`` for tenant isolation.  ``linked_by`` records the UUID of the
   enterprise user who created the link.

Table created
-------------
``enterprise_project_git_connections``

    project_id    UUID NOT NULL   FK -> enterprise_projects.id   CASCADE DELETE
    connection_id UUID NOT NULL   FK -> enterprise_git_repo_connections.id   CASCADE DELETE
    linked_at     TIMESTAMPTZ NOT NULL  DEFAULT now()
    linked_by     UUID NULL
    tenant_id     UUID NOT NULL

    PRIMARY KEY (project_id, connection_id)

    Indexes:
        idx_ent_pgc_tenant_project    (tenant_id, project_id)
        idx_ent_pgc_tenant_connection (tenant_id, connection_id)

Column added
------------
``enterprise_git_repo_connections.team_id``

    UUID NULL   FK -> enterprise_teams.id   ON DELETE SET NULL

    Index:
        idx_ent_grc_tenant_team_id (tenant_id, team_id)

Tenant isolation invariant
--------------------------
Every query against ``enterprise_project_git_connections`` MUST include a
``WHERE tenant_id = ?`` predicate.  Omitting it is a security defect that
leaks cross-tenant data.

Dialect
-------
Enterprise-only (PostgreSQL).  The ``upgrade()`` and ``downgrade()`` functions
are no-ops when executed against a non-PostgreSQL backend to prevent accidental
execution against the SQLite local-mode database.

Downgrade
---------
1. Drop ``enterprise_project_git_connections`` table (indexes dropped implicitly).
2. Drop the FK constraint on ``enterprise_git_repo_connections.team_id``.
3. Drop the ``idx_ent_grc_tenant_team_id`` index.
4. Drop the ``team_id`` column from ``enterprise_git_repo_connections``.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_020_enterprise_git_connection_join_table"
down_revision: Union[str, Sequence[str], None] = "ent_019b_enterprise_git_repo_tables"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Table / column names
# ---------------------------------------------------------------------------

_GRC_TABLE = "enterprise_git_repo_connections"
_PGC_TABLE = "enterprise_project_git_connections"

# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Upgrade helpers
# ---------------------------------------------------------------------------


def _add_team_id_column() -> None:
    """Add team_id (nullable UUID FK) to enterprise_git_repo_connections."""

    op.add_column(
        _GRC_TABLE,
        sa.Column(
            "team_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment=(
                "Optional FK to enterprise_teams.id. "
                "SET NULL on team deletion so the connection persists."
            ),
        ),
    )

    # FK constraint: ON DELETE SET NULL so connection survives team removal.
    op.create_foreign_key(
        "fk_ent_grc_team_id",
        _GRC_TABLE,
        "enterprise_teams",
        ["team_id"],
        ["id"],
        ondelete="SET NULL",
    )

    # Composite index for the required tenant-scoped query pattern.
    op.create_index(
        "idx_ent_grc_tenant_team_id",
        _GRC_TABLE,
        ["tenant_id", "team_id"],
    )

    log.info("upgrade: added team_id column to %s.", _GRC_TABLE)


def _create_project_git_connections_table() -> None:
    """Create enterprise_project_git_connections join table."""

    op.create_table(
        _PGC_TABLE,
        # Composite primary key
        sa.Column(
            "project_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="FK to enterprise_projects.id; part of composite PK",
        ),
        sa.Column(
            "connection_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment="FK to enterprise_git_repo_connections.id; part of composite PK",
        ),
        # Audit / provenance
        sa.Column(
            "linked_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
            comment="Timezone-aware UTC timestamp when the link was created",
        ),
        sa.Column(
            "linked_by",
            postgresql.UUID(as_uuid=True),
            nullable=True,
            comment=(
                "Optional UUID of the enterprise user who created the link. "
                "Stored as a plain reference (no FK) to avoid cascade complexity."
            ),
        ),
        # Tenant isolation — denormalized for query performance
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
            comment=(
                "Tenant scope; every query against this table MUST filter by tenant_id"
            ),
        ),
        # Primary key
        sa.PrimaryKeyConstraint(
            "project_id",
            "connection_id",
            name="pk_enterprise_project_git_connections",
        ),
        # Foreign keys
        sa.ForeignKeyConstraint(
            ["project_id"],
            ["enterprise_projects.id"],
            ondelete="CASCADE",
            name="fk_ent_pgc_project_id",
        ),
        sa.ForeignKeyConstraint(
            ["connection_id"],
            ["enterprise_git_repo_connections.id"],
            ondelete="CASCADE",
            name="fk_ent_pgc_connection_id",
        ),
    )

    # Composite indexes for tenant-scoped queries on each FK axis.
    op.create_index(
        "idx_ent_pgc_tenant_project",
        _PGC_TABLE,
        ["tenant_id", "project_id"],
    )
    op.create_index(
        "idx_ent_pgc_tenant_connection",
        _PGC_TABLE,
        ["tenant_id", "connection_id"],
    )

    log.info("upgrade: created %s table.", _PGC_TABLE)


# ---------------------------------------------------------------------------
# Downgrade helpers
# ---------------------------------------------------------------------------


def _drop_project_git_connections_table() -> None:
    """Drop enterprise_project_git_connections (indexes dropped implicitly)."""
    op.drop_table(_PGC_TABLE)
    log.info("downgrade: dropped %s table.", _PGC_TABLE)


def _remove_team_id_column() -> None:
    """Remove team_id column (and its index/FK) from enterprise_git_repo_connections."""

    op.drop_index("idx_ent_grc_tenant_team_id", table_name=_GRC_TABLE)
    op.drop_constraint("fk_ent_grc_team_id", _GRC_TABLE, type_="foreignkey")
    op.drop_column(_GRC_TABLE, "team_id")

    log.info("downgrade: removed team_id column from %s.", _GRC_TABLE)


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Apply GCD-1.3 enterprise schema changes (PostgreSQL only)."""
    if not _is_postgresql():
        log.info(
            "upgrade: skipping enterprise migration on non-PostgreSQL backend (%s).",
            op.get_bind().dialect.name,
        )
        return

    # Order matters: add team_id before creating the join table so that all
    # referenced tables and columns exist when FKs are validated.
    _add_team_id_column()
    _create_project_git_connections_table()

    log.info("upgrade: ent_020 complete.")


def downgrade() -> None:
    """Reverse GCD-1.3 enterprise schema changes (PostgreSQL only)."""
    if not _is_postgresql():
        log.info(
            "downgrade: skipping enterprise migration on non-PostgreSQL backend (%s).",
            op.get_bind().dialect.name,
        )
        return

    # Reverse order: drop join table before removing the column it references.
    _drop_project_git_connections_table()
    _remove_team_id_column()

    log.info("downgrade: ent_020 complete.")
