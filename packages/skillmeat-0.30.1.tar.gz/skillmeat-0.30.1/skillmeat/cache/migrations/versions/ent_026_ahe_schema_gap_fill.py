"""Fill schema gap in enterprise_artifact_history_events.

Revision ID: ent_026_ahe_schema_gap_fill
Revises: ent_025_enterprise_duplicate_pairs
Create Date: 2026-04-07 00:00:00.000000+00:00

Background
----------
Phase 0 TASK-0.4 model validation (enterprise-stub-promotion-v1) identified
several gaps between the ``enterprise_artifact_history_events`` table schema
and the ``ActivityEventDTO`` definition that were blocking Phase 1 TASK-1.2
(EnterpriseArtifactHistoryEventRepository implementation).

Gaps addressed
--------------
1. Missing column ``owner_type TEXT NOT NULL DEFAULT 'user'``
   ActivityEventDTO.owner_type is non-nullable with no server default on the
   current schema. Every from_dict call would fail for enterprise rows.

2. Missing column ``diff_json TEXT NULL``
   ActivityEventDTO.diff_json requires a column to read from / write to.

3. Missing column ``content_hash TEXT NULL``
   ActivityEventDTO.content_hash requires a column to read from / write to.

4. ``payload`` NOT NULL reconciliation
   The ORM already declares ``payload`` as ``nullable=False`` with
   ``server_default="'{}'::jsonb"`` but the migration that created the table
   (ent_001) left the column nullable.  This migration backfills any NULL
   rows and then applies the NOT NULL constraint.

Columns added
-------------
- owner_type  TEXT NOT NULL DEFAULT 'user'
- diff_json   TEXT NULL
- content_hash TEXT NULL

Constraint tightened
--------------------
- enterprise_artifact_history_events.payload: NULL → NOT NULL (after backfill)

ORM note
--------
Index ``idx_enterprise_ahe_tenant_created`` was created by ent_022 via raw
SQL and is already present in the database.  This migration does NOT
recreate it — the ORM ``__table_args__`` is updated separately to reconcile
autogenerate visibility.

PostgreSQL-only
---------------
This migration is a **no-op on SQLite** (and any other non-PostgreSQL
dialect).  The upgrade and downgrade bodies return immediately when not
running against PostgreSQL.

No PRAGMA statements are used.  The is_sqlite() invariant is satisfied by
omission — we never enter the non-PostgreSQL branch for a migration that
only targets enterprise tables.

Downgrade order
---------------
1. Drop NOT NULL constraint on payload (revert to nullable)
2. Drop owner_type, diff_json, content_hash columns (reverse creation order)
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_026_ahe_schema_gap_fill"
down_revision: Union[str, None] = "ent_025_enterprise_duplicate_pairs"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

log = logging.getLogger("alembic.runtime.migration")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TABLE = "enterprise_artifact_history_events"

# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when running against a PostgreSQL database."""
    bind = op.get_bind()
    return bind.dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Column existence helpers (idempotency)
# ---------------------------------------------------------------------------


def _column_exists(bind: sa.engine.Connection, table: str, column: str) -> bool:
    """Check whether *column* exists on *table* (PostgreSQL)."""
    result = bind.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_schema = 'public' "
            "AND table_name = :t AND column_name = :c"
        ),
        {"t": table, "c": column},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade helpers
# ---------------------------------------------------------------------------


def _add_owner_type(bind: sa.engine.Connection) -> None:
    """Add owner_type TEXT NOT NULL DEFAULT 'user' if not already present."""
    if _column_exists(bind, _TABLE, "owner_type"):
        log.info("upgrade: owner_type already present on %s — skipping", _TABLE)
        return
    op.add_column(
        _TABLE,
        sa.Column(
            "owner_type",
            sa.Text,
            nullable=False,
            server_default=text("'user'"),
            comment="Owner context at the time of the event; defaults to 'user'",
        ),
    )
    log.info("upgrade: added owner_type to %s", _TABLE)


def _add_diff_json(bind: sa.engine.Connection) -> None:
    """Add diff_json TEXT NULL if not already present."""
    if _column_exists(bind, _TABLE, "diff_json"):
        log.info("upgrade: diff_json already present on %s — skipping", _TABLE)
        return
    op.add_column(
        _TABLE,
        sa.Column(
            "diff_json",
            sa.Text,
            nullable=True,
            comment="JSON-serialised diff payload describing what changed; NULL when unavailable",
        ),
    )
    log.info("upgrade: added diff_json to %s", _TABLE)


def _add_content_hash(bind: sa.engine.Connection) -> None:
    """Add content_hash TEXT NULL if not already present."""
    if _column_exists(bind, _TABLE, "content_hash"):
        log.info("upgrade: content_hash already present on %s — skipping", _TABLE)
        return
    op.add_column(
        _TABLE,
        sa.Column(
            "content_hash",
            sa.Text,
            nullable=True,
            comment="SHA-256 hex digest of artifact content at event time; NULL when unavailable",
        ),
    )
    log.info("upgrade: added content_hash to %s", _TABLE)


def _tighten_payload_not_null(bind: sa.engine.Connection) -> None:
    """Backfill NULL payload values then add NOT NULL constraint.

    The ORM already declares payload nullable=False with server_default='{}',
    but ent_001 created the column as nullable.  This step reconciles the two.
    """
    # Backfill any NULLs before applying the NOT NULL constraint.
    affected = bind.execute(
        text(
            f"UPDATE {_TABLE} "  # noqa: S608 — table name is a module constant
            "SET payload = '{}'::jsonb "
            "WHERE payload IS NULL"
        )
    )
    rowcount = getattr(affected, "rowcount", "?")
    log.info(
        "upgrade: backfilled %s NULL payload rows in %s",
        rowcount,
        _TABLE,
    )
    op.alter_column(_TABLE, "payload", nullable=False)
    log.info("upgrade: tightened payload to NOT NULL on %s", _TABLE)


# ---------------------------------------------------------------------------
# Downgrade helpers
# ---------------------------------------------------------------------------


def _revert_payload_nullable(bind: sa.engine.Connection) -> None:  # noqa: ARG001
    """Revert payload column back to nullable."""
    op.alter_column(_TABLE, "payload", nullable=True)
    log.info("downgrade: reverted payload to nullable on %s", _TABLE)


def _drop_content_hash(bind: sa.engine.Connection) -> None:
    """Drop content_hash column if present."""
    if not _column_exists(bind, _TABLE, "content_hash"):
        log.info("downgrade: content_hash absent from %s — skipping", _TABLE)
        return
    op.drop_column(_TABLE, "content_hash")
    log.info("downgrade: dropped content_hash from %s", _TABLE)


def _drop_diff_json(bind: sa.engine.Connection) -> None:
    """Drop diff_json column if present."""
    if not _column_exists(bind, _TABLE, "diff_json"):
        log.info("downgrade: diff_json absent from %s — skipping", _TABLE)
        return
    op.drop_column(_TABLE, "diff_json")
    log.info("downgrade: dropped diff_json from %s", _TABLE)


def _drop_owner_type(bind: sa.engine.Connection) -> None:
    """Drop owner_type column if present."""
    if not _column_exists(bind, _TABLE, "owner_type"):
        log.info("downgrade: owner_type absent from %s — skipping", _TABLE)
        return
    op.drop_column(_TABLE, "owner_type")
    log.info("downgrade: dropped owner_type from %s", _TABLE)


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add owner_type, diff_json, content_hash; tighten payload NOT NULL."""
    if not _is_postgresql():
        log.info(
            "upgrade: non-PostgreSQL dialect — skipping ent_026 (enterprise-only tables)"
        )
        return

    bind = op.get_bind()

    _add_owner_type(bind)
    _add_diff_json(bind)
    _add_content_hash(bind)
    _tighten_payload_not_null(bind)


def downgrade() -> None:
    """Revert payload nullable; drop owner_type, diff_json, content_hash."""
    if not _is_postgresql():
        log.info(
            "downgrade: non-PostgreSQL dialect — skipping ent_026 (enterprise-only tables)"
        )
        return

    bind = op.get_bind()

    # Reverse order: revert constraint first, then drop columns.
    _revert_payload_nullable(bind)
    _drop_content_hash(bind)
    _drop_diff_json(bind)
    _drop_owner_type(bind)
