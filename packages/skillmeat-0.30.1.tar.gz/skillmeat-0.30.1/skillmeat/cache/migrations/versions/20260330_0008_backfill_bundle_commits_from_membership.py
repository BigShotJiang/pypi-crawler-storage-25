"""Backfill bundle_commits from composite_memberships (DVCS-2.5).

Revision ID: 20260330_0008_backfill_bundle_commits_from_membership
Revises: 20260330_0007_add_bundle_commits_tables
Create Date: 2026-03-30 00:08:00.000000+00:00

Background
----------
This is the DATA migration companion to the SCHEMA migration in DVCS-2.1
(20260330_0007_add_bundle_commits_tables).  It seeds the ``bundle_commits``
and ``bundle_commit_members`` tables from existing ``composite_memberships``
rows so that composites already present in the cache have a baseline commit
representing their current state.

For each distinct composite in ``composite_memberships``:

1.  Resolve ``composite_artifact_id`` by joining
    ``composite_memberships.composite_id`` → ``artifacts.id`` → ``artifacts.uuid``.
    The ``bundle_commits.composite_artifact_id`` column is an FK to
    ``artifacts.uuid`` (stable identity per ADR-007).

2.  For each child (``child_artifact_uuid``), find the latest
    ``artifact_versions`` row ordered by ``created_at DESC`` to obtain
    ``artifact_version_id`` and ``content_hash``.  If no version row exists
    for a child the child is skipped with a WARNING (no orphaned member rows
    are created).

3.  Compute ``bundle_hash`` using the canonical SHA-256 algorithm over
    sorted ``(artifact_uuid, content_hash)`` pairs (same algorithm as
    ``skillmeat.core.cas.hash_utils.compute_bundle_hash`` — inlined here to
    avoid importing application code inside a migration).

4.  Insert one ``bundle_commits`` row per composite (``sequence_number=1``,
    ``change_origin='capture'``) and one ``bundle_commit_members`` row per
    child.

5.  Update ``ArtifactCollectionVersion.composite_commit_id`` for any ACV
    rows whose ``artifact_version_id`` matches one of the inserted member
    rows.

Idempotency
-----------
If a ``bundle_commits`` row already exists for a composite
(``bundle_commits.composite_artifact_id = <uuid>``), that composite is
skipped — the migration never overwrites existing commit history.

Graceful no-op conditions
--------------------------
- ``composite_memberships`` table does not exist → skip entirely.
- ``artifacts`` table does not exist → skip entirely.
- A composite has no children in ``composite_memberships`` → skip that
  composite (creating an empty commit is meaningless).
- A child has no ``artifact_versions`` rows → skip that child (WARNING logged).

Downgrade
---------
The downgrade is a no-op.  Deleting backfilled commit rows would risk
destroying commit history created by the application after the migration ran,
so the downgrade does nothing and leaves existing rows in place.
"""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
from datetime import datetime
from typing import Sequence, Union

from alembic import op
from sqlalchemy import inspect as sa_inspect, text

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0008_backfill_bundle_commits_from_membership"
down_revision: Union[str, None] = "20260330_0007_add_bundle_commits_tables"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Inline hash algorithm (mirrors skillmeat.core.cas.hash_utils.compute_bundle_hash)
# ---------------------------------------------------------------------------


def _compute_bundle_hash(members: list) -> str:
    """SHA-256 of sorted (artifact_uuid, content_hash) pairs.

    Inlined to avoid importing application code from inside a migration.
    Must stay in sync with ``skillmeat.core.cas.hash_utils.compute_bundle_hash``.

    Args:
        members: List of dicts with ``artifact_uuid`` and ``content_hash`` keys.

    Returns:
        64-character lowercase hex digest.
    """
    pairs = sorted(
        [(m["artifact_uuid"], m["content_hash"]) for m in members],
        key=lambda p: p[0],
    )
    canonical = json.dumps(pairs, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Backfill bundle_commits from existing composite_memberships rows."""

    conn = op.get_bind()
    inspector = sa_inspect(conn)

    # Enterprise (PostgreSQL) uses enterprise_artifacts with UUID PKs.
    # composite_memberships is a local-mode table with string IDs that are
    # incompatible with the enterprise artifact_versions.artifact_id (UUID).
    # Skip the entire backfill on PostgreSQL.
    if conn.dialect.name == "postgresql":
        log.info(
            "upgrade: skipping composite_memberships backfill on PostgreSQL "
            "(enterprise uses enterprise_artifacts with UUID PKs)."
        )
        return

    existing_tables = set(inspector.get_table_names())

    # --- Graceful no-op checks -----------------------------------------------
    if "composite_memberships" not in existing_tables:
        log.info(
            "upgrade: 'composite_memberships' table does not exist — "
            "skipping backfill (no composite data to migrate)."
        )
        return

    if "artifacts" not in existing_tables:
        log.info("upgrade: 'artifacts' table does not exist — " "skipping backfill.")
        return

    if "bundle_commits" not in existing_tables:
        log.warning(
            "upgrade: 'bundle_commits' table does not exist — "
            "skipping backfill.  Run DVCS-2.1 schema migration first."
        )
        return

    # --- Enumerate distinct composite_ids in membership table ----------------
    composite_rows = conn.execute(
        text("SELECT DISTINCT composite_id FROM composite_memberships")
    ).fetchall()

    if not composite_rows:
        log.info(
            "upgrade: no composites found in composite_memberships — nothing to backfill."
        )
        return

    print(
        f"[DVCS-2.5] backfill: found {len(composite_rows)} distinct composite(s) in "
        "composite_memberships — creating baseline bundle_commits."
    )

    inserted = 0
    skipped_existing = 0
    skipped_no_children = 0

    for (composite_type_name_id,) in composite_rows:
        # 1. Resolve composite_artifact_id → artifacts.uuid
        artifact_row = conn.execute(
            text("SELECT uuid FROM artifacts WHERE id = :id"),
            {"id": composite_type_name_id},
        ).fetchone()

        if artifact_row is None:
            log.warning(
                "upgrade: composite_id=%r not found in artifacts table — skipping.",
                composite_type_name_id,
            )
            continue

        composite_artifact_uuid = artifact_row[0]

        # 2. Check idempotency — skip if a commit already exists for this composite
        existing_commit = conn.execute(
            text(
                "SELECT id FROM bundle_commits "
                "WHERE composite_artifact_id = :uuid LIMIT 1"
            ),
            {"uuid": composite_artifact_uuid},
        ).fetchone()

        if existing_commit is not None:
            log.debug(
                "upgrade: composite_artifact_id=%r already has bundle_commits — skipping.",
                composite_artifact_uuid,
            )
            skipped_existing += 1
            continue

        # 3. Resolve composite_type from composite_artifacts (fallback to "composite")
        composite_type_row = conn.execute(
            text(
                "SELECT composite_type FROM composite_artifacts "
                "WHERE id = :id LIMIT 1"
            ),
            {"id": composite_type_name_id},
        ).fetchone()
        composite_type = composite_type_row[0] if composite_type_row else "composite"

        # 4. Enumerate children and resolve their latest artifact_versions rows
        children = conn.execute(
            text(
                "SELECT child_artifact_uuid FROM composite_memberships "
                "WHERE composite_id = :cid"
            ),
            {"cid": composite_type_name_id},
        ).fetchall()

        if not children:
            log.info(
                "upgrade: composite_id=%r has no children — skipping (empty composite).",
                composite_type_name_id,
            )
            skipped_no_children += 1
            continue

        member_dicts = []
        for (child_uuid,) in children:
            # Resolve artifacts.id for this child uuid
            child_artifact_row = conn.execute(
                text("SELECT id FROM artifacts WHERE uuid = :uuid"),
                {"uuid": child_uuid},
            ).fetchone()
            if child_artifact_row is None:
                log.warning(
                    "upgrade: child_artifact_uuid=%r not found in artifacts — skipping child.",
                    child_uuid,
                )
                continue

            child_artifact_id = child_artifact_row[0]

            # Get the latest version for this child
            version_row = conn.execute(
                text(
                    "SELECT id, content_hash FROM artifact_versions "
                    "WHERE artifact_id = :aid "
                    "ORDER BY created_at DESC "
                    "LIMIT 1"
                ),
                {"aid": child_artifact_id},
            ).fetchone()

            if version_row is None:
                log.warning(
                    "upgrade: no artifact_versions found for artifact_id=%r "
                    "(child_uuid=%r) — skipping child.",
                    child_artifact_id,
                    child_uuid,
                )
                continue

            artifact_version_id, content_hash = version_row
            member_dicts.append(
                {
                    "artifact_id": child_artifact_id,
                    "artifact_uuid": child_uuid,
                    "artifact_version_id": artifact_version_id,
                    "content_hash": content_hash or "",
                }
            )

        if not member_dicts:
            log.info(
                "upgrade: composite_id=%r has no resolvable members — skipping.",
                composite_type_name_id,
            )
            skipped_no_children += 1
            continue

        # 5. Compute bundle_hash
        bundle_hash = _compute_bundle_hash(member_dicts)

        # 6. Insert bundle_commits row
        commit_id = uuid.uuid4().hex
        now = datetime.utcnow().isoformat()
        conn.execute(
            text(
                "INSERT INTO bundle_commits "
                "(id, composite_artifact_id, composite_type, bundle_hash, "
                " parent_id, sequence_number, change_origin, created_at, "
                " created_by, message, is_rollback, rolled_back_to) "
                "VALUES "
                "(:id, :composite_artifact_id, :composite_type, :bundle_hash, "
                " NULL, 1, 'capture', :created_at, "
                " 'migration', 'Backfilled from composite_memberships (DVCS-2.5)', "
                " 0, NULL)"
            ),
            {
                "id": commit_id,
                "composite_artifact_id": composite_artifact_uuid,
                "composite_type": composite_type,
                "bundle_hash": bundle_hash,
                "created_at": now,
            },
        )

        # 7. Insert bundle_commit_members rows
        for m in member_dicts:
            conn.execute(
                text(
                    "INSERT INTO bundle_commit_members "
                    "(bundle_commit_id, artifact_id, artifact_uuid, "
                    " artifact_version_id, content_hash) "
                    "VALUES "
                    "(:commit_id, :artifact_id, :artifact_uuid, "
                    " :artifact_version_id, :content_hash)"
                ),
                {
                    "commit_id": commit_id,
                    "artifact_id": m["artifact_id"],
                    "artifact_uuid": m["artifact_uuid"],
                    "artifact_version_id": m["artifact_version_id"],
                    "content_hash": m["content_hash"],
                },
            )

        # 8. Update ArtifactCollectionVersion.composite_commit_id where applicable
        if "artifact_collection_versions" in existing_tables:
            for m in member_dicts:
                conn.execute(
                    text(
                        "UPDATE artifact_collection_versions "
                        "SET composite_commit_id = :commit_id "
                        "WHERE artifact_version_id = :ver_id "
                        "  AND composite_commit_id IS NULL"
                    ),
                    {
                        "commit_id": commit_id,
                        "ver_id": m["artifact_version_id"],
                    },
                )

        inserted += 1
        log.info(
            "upgrade: created bundle_commit id=%s for composite=%s "
            "(type=%s, members=%d, hash=%s)",
            commit_id,
            composite_artifact_uuid,
            composite_type,
            len(member_dicts),
            bundle_hash[:12],
        )

    print(
        f"[DVCS-2.5] backfill complete: "
        f"inserted={inserted}, "
        f"skipped_existing={skipped_existing}, "
        f"skipped_no_children={skipped_no_children}"
    )
    log.info(
        "upgrade: backfill complete — inserted=%d skipped_existing=%d skipped_no_children=%d",
        inserted,
        skipped_existing,
        skipped_no_children,
    )


# ---------------------------------------------------------------------------
# Downgrade — intentional no-op
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """No-op downgrade.

    Deleting backfilled rows risks destroying commit history that may have
    been extended by the application after the migration ran.  The safest
    course is to leave rows in place and let a human decide whether to clean
    them up manually.
    """
    log.info(
        "downgrade: no-op — backfilled bundle_commits rows are not removed "
        "to avoid destroying post-migration commit history."
    )
