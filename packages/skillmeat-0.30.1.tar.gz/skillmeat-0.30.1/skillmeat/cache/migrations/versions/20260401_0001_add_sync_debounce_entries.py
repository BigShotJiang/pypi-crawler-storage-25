"""Add sync_debounce_entries table for DVCS unified sync (SYNC-1.1).

Revision ID: 20260401_0001_add_sync_debounce_entries
Revises: 20260331_0001_add_patch_change_origin,
         20260331_0001_add_artifact_signatures_table,
         20260331_0001_fix_bom_snapshot_id_fk
Create Date: 2026-04-01 00:01:00.000000+00:00

Background
----------
Introduces the ``sync_debounce_entries`` table to support the DB-backed
debounce mechanism for Sync-as-Version-Capture (SaVC).

When a local filesystem edit is detected on a deployed artifact, a
``SyncDebounceEntry`` row is created (or upserted) with a ``quiet_until``
timestamp.  The background poller only promotes the change to an
``ArtifactVersion`` once the quiet window has expired *and* the content hash
is stable — preventing intermediate "auto-save" noise from polluting version
history.

See SPIKE-2026-03-31-UNIFIED-SYNC (RQ-1) for full design rationale.

Changes
-------
1. New table ``sync_debounce_entries``:
   - ``id``             (TEXT PK)     — UUID hex primary key.
   - ``artifact_id``    (TEXT)        — FK → ``artifacts.id`` CASCADE DELETE.
   - ``project_id``     (TEXT, NULL)  — FK → ``projects.id`` CASCADE DELETE;
                                        NULL for collection-level entries.
   - ``detected_hash``  (TEXT)        — Content hash when change was detected.
   - ``parent_hash``    (TEXT, NULL)  — Hash of last captured version (reversion
                                        detection).
   - ``detected_at``    (DATETIME)    — When change was first/last seen.
   - ``quiet_until``    (DATETIME)    — Poller ignores rows where now() <
                                        quiet_until.
   - ``captured_at``    (DATETIME, NULL) — When ArtifactVersion was created.
   - ``status``         (TEXT)        — State machine: pending | captured |
                                        skipped | expired.
   - ``trigger_source`` (TEXT)        — Attribution: manual | on_access |
                                        periodic | fs_watcher.
   - ``created_at``     (DATETIME)    — Row insertion timestamp.

2. CHECK constraints:
   - ``ck_sync_debounce_entries_status``         — status domain guard.
   - ``ck_sync_debounce_entries_trigger_source`` — trigger_source domain guard.

3. Indexes:
   - ``idx_debounce_status_quiet_until`` — Primary poller query
     (status, quiet_until).
   - ``idx_debounce_artifact_status``    — Upsert path / pending-entry lookup
     (artifact_id, status).
   - ``idx_debounce_project_id``         — Project-scoped lookups.

NOT in this migration
---------------------
- ``change_origin`` CHECK constraint extension (``'auto_capture'`` value) is
  handled by SYNC-1.6 to keep constraint changes isolated and independently
  reviewable.

Dialect Strategy
----------------
Both SQLite (local edition) and PostgreSQL (enterprise edition) are supported
via the standard ``sa.inspect()`` idempotency guard.  No ``batch_alter_table``
is needed here because this migration only creates a new table.

Downgrade
---------
Drops indexes first, then drops the table.  Idempotent: silently skips if the
table does not exist.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260401_0001_add_sync_debounce_entries"
down_revision: Union[str, tuple[str, ...], None] = (
    "20260331_0001_add_patch_change_origin",
    "20260331_0001_add_artifact_signatures_table",
    "20260331_0001_fix_bom_snapshot_id_fk",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

logger = logging.getLogger(__name__)

_TABLE = "sync_debounce_entries"


def upgrade() -> None:
    """Create sync_debounce_entries table with indexes and constraints."""
    logger.info("SYNC-1.1 upgrade: creating %s table", _TABLE)

    conn = op.get_bind()
    inspector = sa.inspect(conn)
    if _TABLE in inspector.get_table_names():
        logger.info("Table %s already exists — skipping creation", _TABLE)
        return

    op.create_table(
        _TABLE,
        # ----------------------------------------------------------------
        # Primary key
        # ----------------------------------------------------------------
        sa.Column(
            "id",
            sa.String(),
            primary_key=True,
            comment="UUID hex primary key",
        ),
        # ----------------------------------------------------------------
        # Artifact reference
        # ----------------------------------------------------------------
        sa.Column(
            "artifact_id",
            sa.String(),
            sa.ForeignKey("artifacts.id", ondelete="CASCADE"),
            nullable=False,
            comment="FK to artifacts.id — the artifact being debounced",
        ),
        # ----------------------------------------------------------------
        # Optional project scope
        # ----------------------------------------------------------------
        sa.Column(
            "project_id",
            sa.String(),
            sa.ForeignKey("projects.id", ondelete="CASCADE"),
            nullable=True,
            comment="FK to projects.id — NULL for collection-level debounce",
        ),
        # ----------------------------------------------------------------
        # Change detection hashes
        # ----------------------------------------------------------------
        sa.Column(
            "detected_hash",
            sa.String(),
            nullable=False,
            comment="Content hash when change was first or last detected",
        ),
        sa.Column(
            "parent_hash",
            sa.String(),
            nullable=True,
            comment="Hash of last captured version; used to detect reversions",
        ),
        # ----------------------------------------------------------------
        # Timing
        # ----------------------------------------------------------------
        sa.Column(
            "detected_at",
            sa.DateTime(),
            nullable=False,
            comment="UTC timestamp when change was first (or last) detected",
        ),
        sa.Column(
            "quiet_until",
            sa.DateTime(),
            nullable=False,
            comment="UTC timestamp; poller skips rows where now() < quiet_until",
        ),
        sa.Column(
            "captured_at",
            sa.DateTime(),
            nullable=True,
            comment="UTC timestamp when ArtifactVersion was created; NULL while pending",
        ),
        # ----------------------------------------------------------------
        # State machine
        # ----------------------------------------------------------------
        sa.Column(
            "status",
            sa.String(),
            nullable=False,
            server_default="pending",
            comment="State: pending | captured | skipped | expired",
        ),
        sa.Column(
            "trigger_source",
            sa.String(),
            nullable=False,
            server_default="manual",
            comment="Attribution: manual | on_access | periodic | fs_watcher",
        ),
        # ----------------------------------------------------------------
        # Created timestamp
        # ----------------------------------------------------------------
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
            comment="UTC timestamp when this debounce entry was first inserted",
        ),
        # ----------------------------------------------------------------
        # CHECK constraints
        # ----------------------------------------------------------------
        sa.CheckConstraint(
            "status IN ('pending', 'captured', 'skipped', 'expired')",
            name="ck_sync_debounce_entries_status",
        ),
        sa.CheckConstraint(
            "trigger_source IN ('manual', 'on_access', 'periodic', 'fs_watcher')",
            name="ck_sync_debounce_entries_trigger_source",
        ),
    )

    # ----------------------------------------------------------------
    # Indexes (created after the table so they are named explicitly)
    # ----------------------------------------------------------------
    logger.info("SYNC-1.1: creating indexes on %s", _TABLE)

    # Primary poller query: WHERE status = 'pending' AND quiet_until <= now()
    op.create_index(
        "idx_debounce_status_quiet_until",
        _TABLE,
        ["status", "quiet_until"],
    )

    # Upsert / exists check: find pending entry for a given artifact
    op.create_index(
        "idx_debounce_artifact_status",
        _TABLE,
        ["artifact_id", "status"],
    )

    # Project-scoped lookups
    op.create_index(
        "idx_debounce_project_id",
        _TABLE,
        ["project_id"],
    )

    logger.info("SYNC-1.1 upgrade: %s table created successfully", _TABLE)


def downgrade() -> None:
    """Drop sync_debounce_entries table and associated indexes."""
    logger.info("SYNC-1.1 downgrade: removing %s table", _TABLE)

    conn = op.get_bind()
    inspector = sa.inspect(conn)
    if _TABLE not in inspector.get_table_names():
        logger.info("Table %s does not exist — skipping removal", _TABLE)
        return

    # Drop indexes explicitly before table (belt-and-suspenders; most
    # engines cascade index drops with the table, but being explicit is
    # safer and more readable in migration history).
    for idx in (
        "idx_debounce_project_id",
        "idx_debounce_artifact_status",
        "idx_debounce_status_quiet_until",
    ):
        try:
            op.drop_index(idx, _TABLE)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not drop index %s: %s", idx, exc)

    op.drop_table(_TABLE)

    logger.info("SYNC-1.1 downgrade: %s table removed", _TABLE)
