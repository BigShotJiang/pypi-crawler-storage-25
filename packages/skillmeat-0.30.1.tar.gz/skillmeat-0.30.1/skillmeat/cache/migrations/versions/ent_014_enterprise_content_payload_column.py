"""Add content_payload JSONB column to enterprise artifact_versions (CAS-1.2).

Revision ID: ent_014_enterprise_content_payload_column
Revises: ent_013_enterprise_artifact_blobs_cas
Create Date: 2026-03-31 00:00:00.000000+00:00

Background
----------
CAS-1.2 enterprise schema change.  Adds a nullable JSONB column
``content_payload`` to the enterprise ``artifact_versions`` table
(PostgreSQL only).

This column carries structured file-content metadata captured at version
ingest time.  Its shape is left intentionally open at the schema level —
the JSONB type imposes no structural constraint, allowing the application
layer to evolve the payload schema without further migrations.

Schema change
-------------
    Table:  artifact_versions  (enterprise PostgreSQL; __tablename__ on
                                EnterpriseArtifactVersion in models_enterprise.py)

    New column:
        content_payload   JSONB   NULL   DEFAULT NULL

Design notes
------------
- No backfill.  Existing rows retain NULL; the application reads NULL as
  "no structured payload captured for this version" and falls back to
  ``markdown_payload`` for content operations.
- Backward-compatible.  Old code that does not reference this column
  continues to work without modification.
- JSONB is used instead of JSON or TEXT so that the payload is indexable
  and supports GIN indexing in follow-up migrations if needed.
- The column is placed after the existing audit columns; column order is
  cosmetic in PostgreSQL but mirrors the model attribute order in
  models_enterprise.py.

Downgrade
---------
Drop the ``content_payload`` column from ``artifact_versions``.  No data
loss beyond the column itself — all other version data is preserved.

This migration is PostgreSQL-only.  It is a no-op on any other dialect.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_014_enterprise_content_payload_column"
down_revision: Union[str, Sequence[str], None] = "ent_013_enterprise_artifact_blobs_cas"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_VERSIONS_TABLE = "artifact_versions"
_COL_CONTENT_PAYLOAD = "content_payload"


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(bind: sa.engine.Connection, table: str, column: str) -> bool:
    """Return True if *column* already exists on *table* (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name   = :tname
              AND column_name  = :cname
            """),
        {"tname": table, "cname": column},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add nullable content_payload JSONB column to artifact_versions (CAS-1.2)."""
    if not _is_postgresql():
        log.info(
            "ent_014_enterprise_content_payload_column: non-PostgreSQL dialect detected; "
            "skipping enterprise-only migration."
        )
        return

    log.info(
        "ent_014_enterprise_content_payload_column upgrade: running PostgreSQL path."
    )
    _upgrade_content_payload()


def _upgrade_content_payload() -> None:
    """Add the content_payload JSONB column to artifact_versions."""
    bind = op.get_bind()

    if _column_exists(bind, _VERSIONS_TABLE, _COL_CONTENT_PAYLOAD):
        log.info(
            "ent_014: column %s.%s already exists; skipping ADD COLUMN.",
            _VERSIONS_TABLE,
            _COL_CONTENT_PAYLOAD,
        )
        return

    op.add_column(
        _VERSIONS_TABLE,
        sa.Column(
            _COL_CONTENT_PAYLOAD,
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=True,
            server_default=text("NULL"),
            comment=(
                "Structured file-content metadata captured at version ingest time. "
                "Shape is intentionally open — JSONB allows schema evolution without "
                "further migrations. "
                "NULL for versions ingested before CAS-1.2; callers fall back to "
                "markdown_payload when this column is NULL."
            ),
        ),
    )
    log.info(
        "ent_014: added column %s to %s.",
        _COL_CONTENT_PAYLOAD,
        _VERSIONS_TABLE,
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop content_payload column from artifact_versions."""
    if not _is_postgresql():
        log.info(
            "ent_014_enterprise_content_payload_column downgrade: "
            "non-PostgreSQL dialect detected; skipping."
        )
        return

    log.info(
        "ent_014_enterprise_content_payload_column downgrade: running PostgreSQL path."
    )
    _downgrade_content_payload()


def _downgrade_content_payload() -> None:
    """Drop the content_payload JSONB column from artifact_versions."""
    bind = op.get_bind()

    if not _column_exists(bind, _VERSIONS_TABLE, _COL_CONTENT_PAYLOAD):
        log.info(
            "ent_014: column %s.%s does not exist; skipping DROP COLUMN.",
            _VERSIONS_TABLE,
            _COL_CONTENT_PAYLOAD,
        )
        return

    op.drop_column(_VERSIONS_TABLE, _COL_CONTENT_PAYLOAD)
    log.info(
        "ent_014: dropped column %s from %s.",
        _COL_CONTENT_PAYLOAD,
        _VERSIONS_TABLE,
    )
