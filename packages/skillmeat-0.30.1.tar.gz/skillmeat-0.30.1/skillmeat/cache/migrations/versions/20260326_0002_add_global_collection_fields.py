"""Add is_global_collection and auto_bind boolean columns to enterprise_collections.

Revision ID: 20260326_0002_add_global_collection_fields
Revises: 20260326_0001_add_enforce_override_column
Create Date: 2026-03-26 00:02:00.000000+00:00

Background
----------
Enterprise Governance 3-Tier feature (EG-1.5).  Two new boolean flags are
introduced on ``enterprise_collections`` to support global collection
distribution and Day-0 auto-binding:

  is_global_collection
  ~~~~~~~~~~~~~~~~~~~~
  * Type:           BOOLEAN (NOT NULL)
  * Default:        False  (application layer)
  * Server default: 'false'  (database layer)
  * Comment:        "When True, marks this collection as enterprise-wide;
                     it is automatically distributed to all users and teams
                     in the tenant"

  auto_bind
  ~~~~~~~~~
  * Type:           BOOLEAN (NOT NULL)
  * Default:        False  (application layer)
  * Server default: 'false'  (database layer)
  * Comment:        "When True, new users and teams automatically receive
                     this collection on Day-0 provisioning"

Affected tables
---------------
Enterprise (PostgreSQL) schema only:
  1. ``enterprise_collections`` — adds ``is_global_collection`` and ``auto_bind``

These columns are enterprise-only.  The local (SQLite) ``collections`` table is
not modified because global distribution and auto-binding are enterprise
governance concepts with no equivalent in local / single-user mode.

Backward Compatibility
----------------------
All existing rows receive ``false`` via the server_default, preserving
current behavior.  No data migration is required.

Rollback
--------
``downgrade()`` drops both columns from ``enterprise_collections``.
Idempotency checks guard both directions.

Schema reference
----------------
skillmeat/cache/models_enterprise.py         (EnterpriseCollection)
.claude/progress/enterprise-governance-3-tier/
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

from skillmeat.cache.migrations.dialect_helpers import is_postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260326_0002_add_global_collection_fields"
down_revision: Union[str, None] = "20260326_0001_add_enforce_override_column"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ---------------------------------------------------------------------------
# Column definitions
# ---------------------------------------------------------------------------

_TABLE = "enterprise_collections"
_SERVER_DEFAULT = "false"

_NEW_COLUMNS = [
    (
        "is_global_collection",
        "When True, marks this collection as enterprise-wide; "
        "it is automatically distributed to all users and teams in the tenant",
    ),
    (
        "auto_bind",
        "When True, new users and teams automatically receive this collection "
        "on Day-0 provisioning",
    ),
]


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(
    bind: sa.engine.Connection, table_name: str, column_name: str
) -> bool:
    """Return True if *column_name* already exists on *table_name*.

    Uses ``sa.inspect()`` which is dialect-agnostic.
    """
    insp = sa.inspect(bind)
    columns = [col["name"] for col in insp.get_columns(table_name)]
    return column_name in columns


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add ``is_global_collection`` and ``auto_bind`` to enterprise_collections."""
    if not is_postgresql():
        log.info(
            "add_global_collection_fields upgrade: non-PostgreSQL dialect; skipping "
            "(these columns are enterprise-only)."
        )
        return

    bind = op.get_bind()
    log.info("add_global_collection_fields upgrade: running PostgreSQL dialect path.")

    for column_name, comment in _NEW_COLUMNS:
        if _column_exists(bind, _TABLE, column_name):
            log.info(
                "add_global_collection_fields (PostgreSQL): %s.%s already exists; skipping.",
                _TABLE,
                column_name,
            )
            continue

        log.info(
            "add_global_collection_fields (PostgreSQL): adding %s.%s.",
            _TABLE,
            column_name,
        )
        op.add_column(
            _TABLE,
            sa.Column(
                column_name,
                sa.Boolean(),
                nullable=False,
                server_default=_SERVER_DEFAULT,
                comment=comment,
            ),
        )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove ``is_global_collection`` and ``auto_bind`` from enterprise_collections."""
    if not is_postgresql():
        log.info(
            "add_global_collection_fields downgrade: non-PostgreSQL dialect; skipping."
        )
        return

    bind = op.get_bind()
    log.info("add_global_collection_fields downgrade: running PostgreSQL dialect path.")

    # Drop in reverse order for cleanliness
    for column_name, _ in reversed(_NEW_COLUMNS):
        if not _column_exists(bind, _TABLE, column_name):
            log.info(
                "add_global_collection_fields (PostgreSQL): %s.%s does not exist; skipping drop.",
                _TABLE,
                column_name,
            )
            continue

        log.info(
            "add_global_collection_fields (PostgreSQL): dropping %s.%s.",
            _TABLE,
            column_name,
        )
        op.drop_column(_TABLE, column_name)
