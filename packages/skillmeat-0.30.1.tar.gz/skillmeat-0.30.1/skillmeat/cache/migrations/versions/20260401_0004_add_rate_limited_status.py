"""Add 'rate_limited' to sync_debounce_entries status CHECK constraint (SYNC-5.3).

Revision ID: 20260401_0004_add_rate_limited_status
Revises: 20260401_0003_add_sync_capture_config
Create Date: 2026-04-01 00:03:00.000000+00:00

Background
----------
Introduces the ``rate_limited`` status value for ``sync_debounce_entries`` to
support per-artifact capture rate limiting in ``SyncCaptureService`` (SYNC-5.3).

When an artifact exceeds the configured ``max_captures_per_hour`` threshold,
the debounce entry is transitioned to ``rate_limited`` rather than being
deleted.  This preserves an audit trail of throttled capture events.

Changes
-------
1. Extend the ``ck_sync_debounce_entries_status`` CHECK constraint on
   ``sync_debounce_entries`` to include ``'rate_limited'``:
   ``status IN ('pending', 'captured', 'skipped', 'expired', 'rate_limited')``

Dialect Strategy
----------------
- **SQLite**: CHECK constraints cannot be altered in-place.  The table is
  recreated via ``batch_alter_table`` with the updated constraint.
- **PostgreSQL**: The existing constraint is dropped and recreated with the
  expanded value set.

Downgrade
---------
Restores the original CHECK constraint (without ``'rate_limited'``).  Any
existing ``rate_limited`` rows are transitioned to ``skipped`` before the
constraint is tightened to avoid violating the restored CHECK.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260401_0004_add_rate_limited_status"
down_revision: Union[str, tuple[str, ...], None] = (
    "20260401_0003_add_sync_capture_config"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_TABLE = "sync_debounce_entries"
_CONSTRAINT_NAME = "ck_sync_debounce_entries_status"
_STATUS_VALUES_OLD = ("pending", "captured", "skipped", "expired")
_STATUS_VALUES_NEW = ("pending", "captured", "skipped", "expired", "rate_limited")

_CHECK_OLD = "status IN ({})".format(", ".join(f"'{v}'" for v in _STATUS_VALUES_OLD))
_CHECK_NEW = "status IN ({})".format(", ".join(f"'{v}'" for v in _STATUS_VALUES_NEW))


def upgrade() -> None:
    """Extend sync_debounce_entries status CHECK to include 'rate_limited'."""
    conn = op.get_bind()
    dialect = conn.dialect.name

    log.info(
        "add_rate_limited_status upgrade: extending status CHECK on %s (dialect=%s)",
        _TABLE,
        dialect,
    )

    if dialect == "sqlite":
        _upgrade_sqlite(conn)
    elif dialect == "postgresql":
        _upgrade_postgresql()
    else:
        log.warning(
            "add_rate_limited_status upgrade: unknown dialect %r; skipping.",
            dialect,
        )


def _upgrade_sqlite(conn) -> None:
    """Recreate sync_debounce_entries with the updated CHECK constraint (SQLite)."""
    inspector = sa.inspect(conn)
    columns = {col["name"]: col for col in inspector.get_columns(_TABLE)}

    with op.batch_alter_table(_TABLE, recreate="always") as batch_op:
        # Drop old constraint and recreate with expanded values.
        batch_op.drop_constraint(_CONSTRAINT_NAME, type_="check")
        batch_op.create_check_constraint(_CONSTRAINT_NAME, _CHECK_NEW)

    log.info("add_rate_limited_status (SQLite): updated %s status CHECK.", _TABLE)


def _upgrade_postgresql() -> None:
    """Drop and recreate the status CHECK constraint (PostgreSQL)."""
    op.drop_constraint(_CONSTRAINT_NAME, _TABLE, type_="check")
    op.create_check_constraint(_CONSTRAINT_NAME, _TABLE, _CHECK_NEW)
    log.info("add_rate_limited_status (PG): updated %s status CHECK.", _TABLE)


def downgrade() -> None:
    """Restore sync_debounce_entries status CHECK, removing 'rate_limited'."""
    conn = op.get_bind()
    dialect = conn.dialect.name

    log.info(
        "add_rate_limited_status downgrade: restoring status CHECK on %s "
        "(dialect=%s)",
        _TABLE,
        dialect,
    )

    # Before tightening the constraint, convert any rate_limited rows to
    # skipped so the restored CHECK does not reject existing data.
    conn.execute(
        sa.text(f"UPDATE {_TABLE} SET status = 'skipped' WHERE status = 'rate_limited'")
    )

    if dialect == "sqlite":
        _downgrade_sqlite()
    elif dialect == "postgresql":
        _downgrade_postgresql()
    else:
        log.warning(
            "add_rate_limited_status downgrade: unknown dialect %r; skipping.",
            dialect,
        )


def _downgrade_sqlite() -> None:
    """Restore original CHECK constraint (SQLite)."""
    with op.batch_alter_table(_TABLE, recreate="always") as batch_op:
        batch_op.drop_constraint(_CONSTRAINT_NAME, type_="check")
        batch_op.create_check_constraint(_CONSTRAINT_NAME, _CHECK_OLD)

    log.info("add_rate_limited_status (SQLite) downgrade: restored %s CHECK.", _TABLE)


def _downgrade_postgresql() -> None:
    """Restore original CHECK constraint (PostgreSQL)."""
    op.drop_constraint(_CONSTRAINT_NAME, _TABLE, type_="check")
    op.create_check_constraint(_CONSTRAINT_NAME, _TABLE, _CHECK_OLD)
    log.info("add_rate_limited_status (PG) downgrade: restored %s CHECK.", _TABLE)
