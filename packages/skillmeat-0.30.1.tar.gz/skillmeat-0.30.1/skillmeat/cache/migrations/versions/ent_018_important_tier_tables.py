"""Create enterprise important-tier tables: context entity categories, artifact-category
associations, and artifact history events.

Revision ID: ent_018_important_tier_tables
Revises: ent_017_marketplace_column_promotion
Create Date: 2026-04-02 00:00:00.000000+00:00

Background
----------
This migration creates 3 new PostgreSQL tables introduced in EGCF Phase 5
(tasks 5.1 – 5.2).  All tables are enterprise-only (PostgreSQL dialect) and
participate in the tenant-isolation invariant — every query against them MUST
include a ``WHERE tenant_id = ?`` predicate.

Tables created (dependency order)
----------------------------------
Important tier (EGCF-5.1, 5.2):
    1.  enterprise_context_entity_categories      — tenant-scoped category taxonomy
    2.  enterprise_artifact_category_associations — junction: artifacts ↔ categories
    3.  enterprise_artifact_history_events        — audit log of artifact lifecycle events

Design notes
------------
- All tables use ``gen_random_uuid()`` as the server-side PK default.
- JSONB columns default to ``'{}'::jsonb``.
- Indexes use ``op.create_index()``; GIN indexes are not required here.
- Foreign keys reference ``enterprise_artifacts`` (created in a prior migration).

Downgrade order
---------------
Tables are dropped in reverse dependency order so that FK references are
satisfied at the time each DROP TABLE executes:
    3 → 2 → 1
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_018_important_tier_tables"
down_revision: Union[str, Sequence[str], None] = "ent_017_marketplace_column_promotion"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Upgrade helpers — one function per domain for readability
# ---------------------------------------------------------------------------


def _create_context_entity_categories_table() -> None:
    """Create enterprise_context_entity_categories (EGCF-5.1)."""

    op.create_table(
        "enterprise_context_entity_categories",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "name",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "slug",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "description",
            sa.Text,
            nullable=True,
        ),
        sa.Column(
            "sort_order",
            sa.Integer,
            nullable=True,
            server_default=sa.text("0"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "slug",
            name="uq_enterprise_cec_tenant_slug",
        ),
    )

    op.create_index(
        "idx_enterprise_cec_tenant_id",
        "enterprise_context_entity_categories",
        ["tenant_id"],
    )
    op.create_index(
        "idx_enterprise_cec_tenant_slug",
        "enterprise_context_entity_categories",
        ["tenant_id", "slug"],
    )


def _create_artifact_category_associations_table() -> None:
    """Create enterprise_artifact_category_associations (EGCF-5.1)."""

    op.create_table(
        "enterprise_artifact_category_associations",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "artifact_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "category_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.ForeignKeyConstraint(
            ["artifact_id"],
            ["enterprise_artifacts.id"],
            ondelete="CASCADE",
            name="fk_enterprise_aca_artifact_id",
        ),
        sa.ForeignKeyConstraint(
            ["category_id"],
            ["enterprise_context_entity_categories.id"],
            ondelete="CASCADE",
            name="fk_enterprise_aca_category_id",
        ),
        sa.UniqueConstraint(
            "artifact_id",
            "category_id",
            "tenant_id",
            name="uq_enterprise_aca_artifact_category_tenant",
        ),
    )

    op.create_index(
        "idx_enterprise_aca_tenant_id",
        "enterprise_artifact_category_associations",
        ["tenant_id"],
    )
    op.create_index(
        "idx_enterprise_aca_artifact_id",
        "enterprise_artifact_category_associations",
        ["artifact_id"],
    )
    op.create_index(
        "idx_enterprise_aca_category_id",
        "enterprise_artifact_category_associations",
        ["category_id"],
    )


def _create_artifact_history_events_table() -> None:
    """Create enterprise_artifact_history_events (EGCF-5.2)."""

    op.create_table(
        "enterprise_artifact_history_events",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "artifact_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "event_type",
            sa.Text,
            nullable=False,
        ),
        sa.Column(
            "actor_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
        sa.Column(
            "payload",
            postgresql.JSONB(),
            nullable=True,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.ForeignKeyConstraint(
            ["artifact_id"],
            ["enterprise_artifacts.id"],
            ondelete="CASCADE",
            name="fk_enterprise_ahe_artifact_id",
        ),
    )

    op.create_index(
        "idx_enterprise_ahe_tenant_id",
        "enterprise_artifact_history_events",
        ["tenant_id"],
    )
    op.create_index(
        "idx_enterprise_ahe_artifact_id",
        "enterprise_artifact_history_events",
        ["artifact_id"],
    )
    op.create_index(
        "idx_enterprise_ahe_tenant_event_type",
        "enterprise_artifact_history_events",
        ["tenant_id", "event_type"],
    )


# ---------------------------------------------------------------------------
# Upgrade / downgrade entry points
# ---------------------------------------------------------------------------


def upgrade() -> None:
    if not _is_postgresql():
        log.info(
            "Skipping ent_018_important_tier_tables: non-PostgreSQL dialect detected."
        )
        return

    log.info("Creating enterprise important-tier tables (ent_018).")
    _create_context_entity_categories_table()
    _create_artifact_category_associations_table()
    _create_artifact_history_events_table()
    log.info("ent_018_important_tier_tables upgrade complete.")


def downgrade() -> None:
    if not _is_postgresql():
        log.info(
            "Skipping ent_018_important_tier_tables downgrade: non-PostgreSQL dialect detected."
        )
        return

    log.info("Dropping enterprise important-tier tables (ent_018).")
    op.drop_table("enterprise_artifact_history_events")
    op.drop_table("enterprise_artifact_category_associations")
    op.drop_table("enterprise_context_entity_categories")
    log.info("ent_018_important_tier_tables downgrade complete.")
