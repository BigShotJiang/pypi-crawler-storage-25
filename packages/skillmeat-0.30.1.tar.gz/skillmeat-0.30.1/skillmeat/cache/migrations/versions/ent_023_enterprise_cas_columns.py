"""Add CAS columns to enterprise artifact_versions table.

Revision ID: ent_023_enterprise_cas_columns
Revises: ent_022_admin_sync_prereq
Create Date: 2026-04-06 00:00:00.000000+00:00

Background
----------
The local migration ``20260330_0005_add_artifact_blobs_cas.py`` adds Content-
Addressed Storage (CAS) columns to ``artifact_versions``, but it skips on
PostgreSQL because it expects the enterprise migration chain to handle it.
However, ``ent_013_enterprise_artifact_blobs_cas`` only creates the
``artifact_blobs`` table — it does NOT add the CAS columns to
``artifact_versions``.

This migration back-fills the schema gap by adding the four CAS columns that
were missing from enterprise deployments:

    - content_tree        TEXT         NULL — JSON map of {path: sha256_hex}
    - upstream_hash       VARCHAR(64)  NULL — SHA-256 of upstream at capture
    - upstream_tier       INTEGER      NULL — upstream source tier (0=direct)
    - is_complete_capture BOOLEAN      NULL — True when all blobs are stored

Schema change
-------------
    Table:  artifact_versions  (enterprise PostgreSQL)

    New columns (all nullable):
        content_tree        TEXT         NULL
        upstream_hash       VARCHAR(64)  NULL
        upstream_tier       INTEGER      NULL
        is_complete_capture BOOLEAN      NULL DEFAULT FALSE

Design notes
------------
- All columns are nullable so existing rows remain valid after the ALTER.
- ``is_complete_capture`` has a server default of FALSE for new rows.
- Idempotent via ``_column_exists`` guard — safe to re-run.
- PostgreSQL-only; no-op on other dialects.

Downgrade
---------
Drop all four CAS columns from ``artifact_versions``.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_023_enterprise_cas_columns"
down_revision: Union[str, Sequence[str], None] = "ent_022_admin_sync_prereq"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_VERSIONS_TABLE = "artifact_versions"

# CAS columns to add (name, type, comment)
_CAS_COLUMNS: list[tuple[str, sa.types.TypeEngine, str]] = [
    (
        "content_tree",
        sa.Text(),
        "JSON map of {relative_path: sha256_hex} for CAS blob references. "
        "NULL until CAS backfill migration runs (DVCS-1.4).",
    ),
    (
        "upstream_hash",
        sa.String(64),
        "SHA-256 hex of upstream content at capture time (64 chars).",
    ),
    (
        "upstream_tier",
        sa.Integer(),
        "Upstream source tier (0 = direct/canonical, >0 = fork depth).",
    ),
    (
        "is_complete_capture",
        sa.Boolean(),
        "True when all content_tree blob hashes are present in artifact_blobs. "
        "Set by DVCS-1.4 backfill migration.",
    ),
]


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(bind: sa.engine.Connection, table: str, column: str) -> bool:
    """Return True if *column* already exists on *table* (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name   = :tname
              AND column_name  = :cname
            """),
        {"tname": table, "cname": column},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add content_tree, upstream_hash, upstream_tier, is_complete_capture to artifact_versions."""
    if not _is_postgresql():
        log.info(
            "ent_023_enterprise_cas_columns: non-PostgreSQL dialect detected; "
            "skipping enterprise-only migration."
        )
        return

    log.info("ent_023_enterprise_cas_columns upgrade: running PostgreSQL path.")
    _upgrade_cas_columns()


def _upgrade_cas_columns() -> None:
    """Add each CAS column to artifact_versions if not already present."""
    bind = op.get_bind()

    for col_name, col_type, col_comment in _CAS_COLUMNS:
        if _column_exists(bind, _VERSIONS_TABLE, col_name):
            log.info(
                "ent_023: column %s.%s already exists; skipping ADD COLUMN.",
                _VERSIONS_TABLE,
                col_name,
            )
            continue

        # is_complete_capture has a server default
        if col_name == "is_complete_capture":
            op.add_column(
                _VERSIONS_TABLE,
                sa.Column(
                    col_name,
                    col_type,
                    nullable=True,
                    server_default="false",
                    comment=col_comment,
                ),
            )
        else:
            op.add_column(
                _VERSIONS_TABLE,
                sa.Column(col_name, col_type, nullable=True, comment=col_comment),
            )
        log.info(
            "ent_023: added column %s to %s.",
            col_name,
            _VERSIONS_TABLE,
        )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop content_tree, upstream_hash, upstream_tier, is_complete_capture from artifact_versions."""
    if not _is_postgresql():
        log.info(
            "ent_023_enterprise_cas_columns downgrade: "
            "non-PostgreSQL dialect detected; skipping."
        )
        return

    log.info("ent_023_enterprise_cas_columns downgrade: running PostgreSQL path.")
    _downgrade_cas_columns()


def _downgrade_cas_columns() -> None:
    """Drop each CAS column from artifact_versions if it exists."""
    bind = op.get_bind()

    # Drop in reverse order of addition for cleanliness
    for col_name, _, _ in reversed(_CAS_COLUMNS):
        if not _column_exists(bind, _VERSIONS_TABLE, col_name):
            log.info(
                "ent_023: column %s.%s does not exist; skipping DROP COLUMN.",
                _VERSIONS_TABLE,
                col_name,
            )
            continue

        op.drop_column(_VERSIONS_TABLE, col_name)
        log.info(
            "ent_023: dropped column %s from %s.",
            col_name,
            _VERSIONS_TABLE,
        )
