"""Add git_scan_artifacts table for Git Repo Connector feature (GRC-DB-003).

Revision ID: 20260330_0004_add_git_scan_artifacts
Revises: 20260330_0003_add_git_repo_scans
Create Date: 2026-03-30 00:04:00.000000+00:00

Background
----------
Phase 1 of the Git Repo Connector (GRC) feature.  A ``git_scan_artifacts``
row records a single artifact discovered or observed during a scan run.  Every
scan produces zero or more artifact rows; together they constitute the complete
index of Claude Code artifacts found at a particular Git ref.

Table Created
-------------
``git_scan_artifacts``

    Stores one artifact observation per scan run.

    Schema:
        id              INTEGER PRIMARY KEY AUTOINCREMENT
        scan_id         INTEGER NOT NULL  FK -> git_repo_scans.id ON DELETE CASCADE
        artifact_path   TEXT NOT NULL     Repository-relative path (e.g. '.claude/skills/foo/')
        artifact_type   TEXT(64) NOT NULL Detected artifact type (e.g. 'skill', 'agent')
        detected_name   TEXT NULL         Human-readable name parsed from metadata
        content_hash    TEXT(64) NULL     SHA-256 hex digest of artifact content
        change_type     TEXT NOT NULL     CHECK ('new', 'changed', 'removed', 'unchanged')
        indexed_at      DATETIME NULL     Set when the artifact is imported into the cache
        artifact_id     TEXT NULL         FK -> artifacts.id once indexed (soft reference)
        created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP

    Constraints:
        ck_git_scan_artifacts_change_type
            change_type IN ('new', 'changed', 'removed', 'unchanged')

    Indexes:
        idx_git_scan_artifacts_scan_id       (scan_id)
        idx_git_scan_artifacts_artifact_path (artifact_path)
        idx_git_scan_artifacts_change_type   (change_type)
        idx_git_scan_artifacts_artifact_id   (artifact_id)

Dialect Strategy
----------------
``sa.CheckConstraint`` for the ``change_type`` enum is enforced on PostgreSQL
and silently ignored on SQLite.  The ``artifact_id`` FK references
``artifacts.id`` (a String/TEXT PK in the local schema) and is intentionally
nullable so that newly discovered artifacts can be recorded before they are
imported and assigned a cache ID.

Downgrade
---------
Drop ``git_scan_artifacts``.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0004_add_git_scan_artifacts"
down_revision: Union[str, None] = "20260330_0003_add_git_repo_scans"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_TABLE = "git_scan_artifacts"


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create the git_scan_artifacts table."""
    op.create_table(
        _TABLE,
        # Primary key
        sa.Column(
            "id",
            sa.Integer(),
            primary_key=True,
            autoincrement=True,
            comment="Auto-incrementing surrogate primary key",
        ),
        # Parent scan (cascade-delete: removing a scan removes all its artifact observations)
        sa.Column(
            "scan_id",
            sa.Integer(),
            sa.ForeignKey(
                "git_repo_scans.id",
                ondelete="CASCADE",
                name="fk_gsa_scan_id",
            ),
            nullable=False,
            comment="FK to git_repo_scans.id; cascade-delete when the parent scan is removed",
        ),
        # Artifact location
        sa.Column(
            "artifact_path",
            sa.String(),
            nullable=False,
            comment="Repository-relative path to the artifact directory or file",
        ),
        sa.Column(
            "artifact_type",
            sa.String(64),
            nullable=False,
            comment="Detected artifact type label (e.g. 'skill', 'agent', 'command')",
        ),
        # Parsed metadata
        sa.Column(
            "detected_name",
            sa.String(),
            nullable=True,
            comment="Human-readable artifact name parsed from CLAUDE.md or SKILL.md frontmatter",
        ),
        sa.Column(
            "content_hash",
            sa.String(64),
            nullable=True,
            comment="SHA-256 hex digest (64 chars) of the artifact's content at scan time",
        ),
        # Change classification relative to the previous scan
        sa.Column(
            "change_type",
            sa.String(),
            nullable=False,
            comment=(
                "How this artifact changed since the last scan: "
                "'new', 'changed', 'removed', or 'unchanged'"
            ),
        ),
        # Import linkage
        sa.Column(
            "indexed_at",
            sa.DateTime(),
            nullable=True,
            comment="UTC timestamp when this artifact was imported into the local cache",
        ),
        sa.Column(
            "artifact_id",
            sa.String(),
            sa.ForeignKey(
                "artifacts.id",
                name="fk_gsa_artifact_id",
            ),
            nullable=True,
            comment=(
                "FK to artifacts.id once the artifact has been indexed/imported. "
                "NULL until import completes."
            ),
        ),
        # Audit timestamp
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
            comment="UTC timestamp when this observation record was created",
        ),
        # CHECK constraint — enforced on PostgreSQL; silently ignored on SQLite.
        sa.CheckConstraint(
            "change_type IN ('new', 'changed', 'removed', 'unchanged')",
            name="ck_git_scan_artifacts_change_type",
        ),
    )

    op.create_index(
        "idx_git_scan_artifacts_scan_id",
        _TABLE,
        ["scan_id"],
    )
    op.create_index(
        "idx_git_scan_artifacts_artifact_path",
        _TABLE,
        ["artifact_path"],
    )
    op.create_index(
        "idx_git_scan_artifacts_change_type",
        _TABLE,
        ["change_type"],
    )
    op.create_index(
        "idx_git_scan_artifacts_artifact_id",
        _TABLE,
        ["artifact_id"],
    )

    log.info("upgrade: created %s table.", _TABLE)


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop git_scan_artifacts table."""
    op.drop_table(_TABLE)
    log.info("downgrade: dropped %s table.", _TABLE)
