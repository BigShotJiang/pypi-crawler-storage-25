"""Add search_vector TEXT column to marketplace_catalog_entries for SQLite.

Revision ID: 20260407_0001_add_search_vector_sqlite
Revises: 20260404_0001_add_cascade_policy_tables
Create Date: 2026-04-07 00:01:00.000000+00:00

Background
----------
The `MarketplaceCatalogEntry` model defines a `search_vector` column using
`TSVectorType()`, which falls back to `Text` on SQLite.  PostgreSQL databases
receive this column via `pg_001_fulltext_search.py` (native TSVECTOR + GIN
index + trigger).  SQLite databases created before that migration file was
added are missing the column entirely, which causes runtime errors when
SQLAlchemy tries to read or write it.

This migration adds the missing `search_vector TEXT NULL` column on SQLite
only.  It is an idempotent no-op on PostgreSQL (that dialect is handled by
`pg_001_fulltext_search`).

On SQLite the column is never populated — the TSVectorType() comment in
models.py notes that it is "managed by PostgreSQL trigger — do not set
manually".  We only add it here so that SQLAlchemy's ORM layer does not
encounter a missing-column error on local/single-tenant installations.

What this migration does (SQLite only)
---------------------------------------
1. Checks whether `search_vector` already exists on
   `marketplace_catalog_entries` (idempotent guard).
2. Adds `search_vector TEXT NULL` if absent.

Downgrade (SQLite only)
-----------------------
Drops the `search_vector` column.  SQLite does not support
`DROP COLUMN` before version 3.35.0 (released 2021-03-12), but the minimum
supported Python/SQLite combination in this project targets 3.35+.

Schema reference
----------------
skillmeat/cache/models.py  (MarketplaceCatalogEntry.search_vector, lines 2460-2471)
skillmeat/cache/migrations/versions/pg_001_fulltext_search.py  (PostgreSQL counterpart)
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect as sa_inspect

from skillmeat.cache.migrations.dialect_helpers import is_sqlite

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260407_0001_add_search_vector_sqlite"
down_revision: Union[str, Sequence[str], None] = (
    "20260404_0001_add_cascade_policy_tables"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TABLE = "marketplace_catalog_entries"
_COLUMN = "search_vector"

# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add search_vector TEXT NULL to marketplace_catalog_entries on SQLite."""
    if not is_sqlite():
        # PostgreSQL already has this column from pg_001_fulltext_search.
        log.debug(
            "Skipping %s upgrade: not SQLite (dialect=%s)",
            revision,
            op.get_bind().dialect.name,
        )
        return

    bind = op.get_bind()
    inspector = sa_inspect(bind)
    existing_columns = {col["name"] for col in inspector.get_columns(_TABLE)}

    if _COLUMN in existing_columns:
        log.debug(
            "Skipping %s upgrade: column %r already exists on %r",
            revision,
            _COLUMN,
            _TABLE,
        )
        return

    log.info(
        "Adding column %r TEXT NULL to table %r (SQLite)",
        _COLUMN,
        _TABLE,
    )
    op.add_column(
        _TABLE,
        sa.Column(_COLUMN, sa.Text(), nullable=True),
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop search_vector column from marketplace_catalog_entries on SQLite."""
    if not is_sqlite():
        log.debug(
            "Skipping %s downgrade: not SQLite (dialect=%s)",
            revision,
            op.get_bind().dialect.name,
        )
        return

    bind = op.get_bind()
    inspector = sa_inspect(bind)
    existing_columns = {col["name"] for col in inspector.get_columns(_TABLE)}

    if _COLUMN not in existing_columns:
        log.debug(
            "Skipping %s downgrade: column %r not present on %r",
            revision,
            _COLUMN,
            _TABLE,
        )
        return

    log.info(
        "Dropping column %r from table %r (SQLite)",
        _COLUMN,
        _TABLE,
    )
    op.drop_column(_TABLE, _COLUMN)
