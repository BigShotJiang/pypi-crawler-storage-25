"""GCD access token and git_credentials table (local / SQLite edition).

Revision ID: 20260403_0002_gcd_access_token_credentials
Revises: ent_020_enterprise_git_connection_join_table
Create Date: 2026-04-03 00:02:00.000000+00:00

Background
----------
Task GCD-2.1 / GCD-2.2 — Phase 2 (Token Management) of the Git Connection
Decoupling feature.

This migration extends the local (SQLite) edition with two changes that
enable per-connection and scoped credential storage:

1. ``access_token`` column on ``git_repo_connections``
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   A nullable TEXT column that holds a Fernet-encrypted personal access token
   directly associated with a single connection.  Encryption/decryption is
   handled transparently by the ``EncryptedString`` TypeDecorator in
   ``skillmeat/cache/column_types.py``.

   Adding the column as nullable (rather than NOT NULL with a default) avoids
   a full-table rewrite on SQLite and is safe for existing rows that have no
   token.

2. ``git_credentials`` table
   ~~~~~~~~~~~~~~~~~~~~~~~~~
   A flexible credential store that allows a PAT or App Installation token to
   be scoped to an org, team, or individual developer — and optionally linked
   to a specific connection.

   Schema::

       id              TEXT PK  (UUID string)
       scope_type      TEXT NOT NULL  CHECK IN ('org', 'team', 'developer')
       scope_id        TEXT NOT NULL
       connection_id   TEXT NULL  FK -> git_repo_connections.id  ON DELETE CASCADE
       token_encrypted TEXT NOT NULL  (Fernet ciphertext via EncryptedString)
       credential_type TEXT NOT NULL DEFAULT 'pat'
                            CHECK IN ('pat', 'app_installation')
       created_by      TEXT NULL
       created_at      DATETIME DEFAULT CURRENT_TIMESTAMP

   Indexes::

       ix_git_creds_scope  (scope_type, scope_id)
       ix_git_creds_conn   (connection_id)

Dialect Strategy
----------------
Local (SQLite) only.  Enterprise has its own migration (``ent_021_*``).

``op.add_column`` is used for step 1 because SQLite supports adding a
nullable column without a full table rebuild.  The ``git_credentials`` table
is created fresh via ``op.create_table``.

Downgrade
---------
1. Drop ``ix_git_creds_conn`` and ``ix_git_creds_scope`` indexes.
2. Drop the ``git_credentials`` table.
3. Drop ``access_token`` column from ``git_repo_connections`` via
   ``op.batch_alter_table`` (required for SQLite column removal).
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260403_0002_gcd_access_token_credentials"
down_revision: Union[str, None] = "ent_020_enterprise_git_connection_join_table"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_GRC_TABLE = "git_repo_connections"
_CREDS_TABLE = "git_credentials"

# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add access_token column and create git_credentials table."""

    bind = op.get_bind()

    # PostgreSQL guard: enterprise schema is managed by ent_021 which
    # uses UUID PKs and the correct FK types. This local migration uses
    # TEXT FKs referencing INTEGER PKs, which PostgreSQL rejects.
    if bind.dialect.name == "postgresql":
        log.info(
            "20260403_0002: PostgreSQL detected — "
            "git_credentials schema managed by ent_021; skipping."
        )
        return

    # ------------------------------------------------------------------
    # Step 1: Add access_token column to git_repo_connections
    # ------------------------------------------------------------------
    log.info("upgrade: adding access_token column to %s", _GRC_TABLE)

    op.add_column(
        _GRC_TABLE,
        sa.Column(
            "access_token",
            sa.Text(),
            nullable=True,
            comment=(
                "Fernet-encrypted PAT associated directly with this connection. "
                "Encrypted/decrypted transparently by EncryptedString TypeDecorator."
            ),
        ),
    )

    log.info("upgrade: access_token column added to %s", _GRC_TABLE)

    # ------------------------------------------------------------------
    # Step 2: Create git_credentials table
    # ------------------------------------------------------------------
    log.info("upgrade: creating %s table", _CREDS_TABLE)

    op.create_table(
        _CREDS_TABLE,
        sa.Column(
            "id",
            sa.Text(),
            primary_key=True,
            comment="UUID string primary key",
        ),
        sa.Column(
            "scope_type",
            sa.Text(),
            nullable=False,
            comment="Credential scope: 'org', 'team', or 'developer'",
        ),
        sa.Column(
            "scope_id",
            sa.Text(),
            nullable=False,
            comment="Identifier of the scoped entity (org name, team ID, developer ID)",
        ),
        sa.Column(
            "connection_id",
            sa.Text(),
            sa.ForeignKey(
                "git_repo_connections.id",
                ondelete="CASCADE",
                name="fk_git_creds_connection_id",
            ),
            nullable=True,
            comment="Optional FK to git_repo_connections.id; row deleted when connection is deleted",
        ),
        sa.Column(
            "token_encrypted",
            sa.Text(),
            nullable=False,
            comment="Fernet-encrypted credential token (plaintext never stored)",
        ),
        sa.Column(
            "credential_type",
            sa.Text(),
            nullable=False,
            server_default=sa.text("'pat'"),
            comment="Token type: 'pat' (personal access token) or 'app_installation'",
        ),
        sa.Column(
            "created_by",
            sa.Text(),
            nullable=True,
            comment="Optional identifier of the actor that created this credential",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=True,
            server_default=sa.text("CURRENT_TIMESTAMP"),
            comment="UTC timestamp when this credential was stored",
        ),
        sa.CheckConstraint(
            "scope_type IN ('org', 'team', 'developer')",
            name="ck_git_creds_scope_type",
        ),
        sa.CheckConstraint(
            "credential_type IN ('pat', 'app_installation')",
            name="ck_git_creds_credential_type",
        ),
    )

    # ------------------------------------------------------------------
    # Step 3: Create indexes on git_credentials
    # ------------------------------------------------------------------
    op.create_index(
        "ix_git_creds_scope",
        _CREDS_TABLE,
        ["scope_type", "scope_id"],
    )
    op.create_index(
        "ix_git_creds_conn",
        _CREDS_TABLE,
        ["connection_id"],
    )

    log.info("upgrade: %s table and indexes created", _CREDS_TABLE)
    log.info("upgrade: 20260403_0002 complete")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop git_credentials table and remove access_token column."""

    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        log.info("20260403_0002 downgrade: skipping on PostgreSQL (managed by ent_021).")
        return

    # ------------------------------------------------------------------
    # Step 1: Drop git_credentials indexes and table
    # ------------------------------------------------------------------
    log.info("downgrade: dropping %s indexes and table", _CREDS_TABLE)

    op.drop_index("ix_git_creds_conn", table_name=_CREDS_TABLE)
    op.drop_index("ix_git_creds_scope", table_name=_CREDS_TABLE)
    op.drop_table(_CREDS_TABLE)

    log.info("downgrade: dropped %s", _CREDS_TABLE)

    # ------------------------------------------------------------------
    # Step 2: Remove access_token column from git_repo_connections
    #
    # SQLite does not support DROP COLUMN in older versions, so we use
    # batch_alter_table to handle the removal safely across SQLite versions.
    # ------------------------------------------------------------------
    log.info("downgrade: removing access_token column from %s", _GRC_TABLE)

    with op.batch_alter_table(_GRC_TABLE) as batch_op:
        batch_op.drop_column("access_token")

    log.info(
        "downgrade: access_token column removed from %s; 20260403_0002 complete",
        _GRC_TABLE,
    )
