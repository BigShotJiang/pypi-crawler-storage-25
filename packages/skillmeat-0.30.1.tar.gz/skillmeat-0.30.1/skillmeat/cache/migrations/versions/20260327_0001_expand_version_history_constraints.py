"""Expand change_origin and event_type CHECK constraints for version history restore/promote.

Revision ID: 20260327_0001_expand_version_history_constraints
Revises: 20260324_0001_add_new_artifact_types_to_constraints
Create Date: 2026-03-27 00:01:00.000000+00:00

Background
----------
Artifact Version History & Restore feature (Phase 1, DB-1.1 and DB-1.2).

Two CHECK constraints must be extended to permit new lifecycle event values
introduced by the restore and promotion workflows:

1. ``artifact_versions.change_origin``    — constraint ``check_artifact_versions_change_origin``
   Adds: ``'restore'``, ``'promotion'``

2. ``artifact_history_events.event_type`` — constraint ``check_artifact_history_event_type``
   Adds: ``'restore'``, ``'promote'``, ``'force_sync'``, ``'baseline_set'``

Changes
-------
1. ``artifact_versions`` — extend ``check_artifact_versions_change_origin``:

   Old values:
     ``('deployment', 'sync', 'local_modification')``

   New values:
     ``('deployment', 'sync', 'local_modification', 'restore', 'promotion')``

2. ``artifact_history_events`` — extend ``check_artifact_history_event_type``:

   Old values:
     ``('create', 'update', 'delete', 'deploy', 'undeploy', 'sync')``

   New values:
     ``('create', 'update', 'delete', 'deploy', 'undeploy', 'sync',
       'restore', 'promote', 'force_sync', 'baseline_set')``

SQLite Strategy
---------------
SQLite does not support ``ALTER TABLE ... DROP/ADD CONSTRAINT``.  The
``batch_alter_table(recreate="always")`` approach performs a transparent
full-table rebuild (create new table, copy rows, drop old table, rename).

For ``artifact_versions``, FK enforcement is temporarily disabled around the
rebuild (``PRAGMA foreign_keys = OFF/ON``) to prevent FK violations from
child tables that reference ``artifact_versions`` during the rebuild.

For ``artifact_history_events``, no child tables hold FKs referencing it so
FK enforcement does not need to be toggled.

PostgreSQL Strategy
-------------------
PostgreSQL supports native ``ALTER TABLE ... DROP CONSTRAINT`` followed by
``ALTER TABLE ... ADD CONSTRAINT``.  No table rebuild is required.

Both operations run in the same migration on both dialects.

Idempotency
-----------
The upgrade paths check for the presence of the sentinel value (``'restore'``)
in the existing constraint definition before modifying.  If the constraint
already contains the new values (e.g. from a prior partial run or a
``Base.metadata.create_all()`` against an updated model), the operation is
skipped.

Backward Compatibility
----------------------
All previously valid values remain in the updated constraints.  Existing code
that writes ``'deployment'``, ``'sync'``, or ``'local_modification'`` to
``change_origin``, and any existing ``event_type`` values, continues to work
unchanged.

Rollback
--------
Rebuilds both tables (SQLite) or re-applies ``ALTER TABLE`` (PostgreSQL) with
the original constraint definitions.  Rows carrying one of the new values will
violate the restored constraints; callers are responsible for removing or
migrating such rows before running the downgrade.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260327_0001_expand_version_history_constraints"
down_revision: Union[str, None] = "20260324_0001_add_new_artifact_types_to_constraints"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ---------------------------------------------------------------------------
# Canonical constraint value strings — single source of truth.
# ---------------------------------------------------------------------------

# artifact_versions.change_origin
_CHANGE_ORIGIN_NEW = (
    "('deployment', 'sync', 'local_modification', 'restore', 'promotion')"
)
_CHANGE_ORIGIN_OLD = "('deployment', 'sync', 'local_modification')"

# artifact_history_events.event_type
_EVENT_TYPE_NEW = (
    "('create', 'update', 'delete', 'deploy', 'undeploy', 'sync', "
    "'restore', 'promote', 'force_sync', 'baseline_set')"
)
_EVENT_TYPE_OLD = "('create', 'update', 'delete', 'deploy', 'undeploy', 'sync')"

# Constraint names — must match ORM model definitions.
_CHANGE_ORIGIN_CONSTRAINT = "check_artifact_versions_change_origin"
_EVENT_TYPE_CONSTRAINT = "check_artifact_history_event_type"

# Sentinel: a new value used for idempotency checks.
_SENTINEL = "'restore'"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _constraint_already_updated_sqlite(
    bind: sa.engine.Connection, table_name: str
) -> bool:
    """Return True if the CHECK constraint on *table_name* already contains the sentinel (SQLite).

    SQLite stores the original SQL text of CHECK constraints in
    ``sqlite_master``.  We check for the presence of ``'restore'`` to
    determine whether this migration has already run.
    """
    result = bind.execute(
        text("SELECT sql FROM sqlite_master WHERE type='table' AND name=:tname"),
        {"tname": table_name},
    )
    row = result.fetchone()
    if row is None:
        return False
    create_sql: str = row[0] or ""
    return _SENTINEL in create_sql


def _constraint_already_updated_pg(
    bind: sa.engine.Connection, constraint_name: str, table_name: str
) -> bool:
    """Return True if *constraint_name* on *table_name* already contains the sentinel (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT pg_get_constraintdef(c.oid)
            FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :cname
              AND t.relname = :tname
              AND c.contype = 'c'
            """),
        {"cname": constraint_name, "tname": table_name},
    )
    row = result.fetchone()
    if row is None:
        return False
    constraint_def: str = row[0] or ""
    return "restore" in constraint_def


def _get_pg_constraint_name(
    bind: sa.engine.Connection, constraint_name: str, table_name: str
) -> str | None:
    """Return the constraint name if it exists on *table_name* (PostgreSQL), else None."""
    result = bind.execute(
        text("""
            SELECT c.conname
            FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            WHERE c.conname = :cname
              AND t.relname = :tname
              AND c.contype = 'c'
            """),
        {"cname": constraint_name, "tname": table_name},
    )
    row = result.fetchone()
    return row[0] if row else None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Extend change_origin and event_type CHECK constraints with new lifecycle values."""
    bind = op.get_bind()

    if is_sqlite():
        log.info(
            "expand_version_history_constraints upgrade: running SQLite dialect path."
        )
        _upgrade_change_origin_sqlite(bind)
        _upgrade_event_type_sqlite(bind)
    elif is_postgresql():
        log.info(
            "expand_version_history_constraints upgrade: running PostgreSQL dialect path."
        )
        _upgrade_change_origin_postgresql(bind)
        _upgrade_event_type_postgresql(bind)
    else:
        log.warning(
            "expand_version_history_constraints upgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _upgrade_change_origin_sqlite(bind: sa.engine.Connection) -> None:
    """Extend artifact_versions.change_origin constraint on SQLite via table rebuild."""
    if _constraint_already_updated_sqlite(bind, "artifact_versions"):
        log.info(
            "expand_version_history_constraints (SQLite): artifact_versions constraint "
            "already contains new values; skipping."
        )
        return

    # Disable FK enforcement to prevent violations from child tables that
    # reference artifact_versions during the rebuild.
    op.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table("artifact_versions", recreate="always") as batch_op:
            batch_op.drop_constraint(_CHANGE_ORIGIN_CONSTRAINT, type_="check")
            batch_op.create_check_constraint(
                _CHANGE_ORIGIN_CONSTRAINT,
                f"change_origin IN {_CHANGE_ORIGIN_NEW}",
            )
    finally:
        op.execute(text("PRAGMA foreign_keys = ON"))


def _upgrade_event_type_sqlite(bind: sa.engine.Connection) -> None:
    """Extend artifact_history_events.event_type constraint on SQLite via table rebuild."""
    if _constraint_already_updated_sqlite(bind, "artifact_history_events"):
        log.info(
            "expand_version_history_constraints (SQLite): artifact_history_events constraint "
            "already contains new values; skipping."
        )
        return

    with op.batch_alter_table("artifact_history_events", recreate="always") as batch_op:
        batch_op.drop_constraint(_EVENT_TYPE_CONSTRAINT, type_="check")
        batch_op.create_check_constraint(
            _EVENT_TYPE_CONSTRAINT,
            f"event_type IN {_EVENT_TYPE_NEW}",
        )


def _upgrade_change_origin_postgresql(bind: sa.engine.Connection) -> None:
    """Extend artifact_versions.change_origin constraint on PostgreSQL.

    The enterprise artifact_versions schema does not include change_origin
    (it uses a different versioning model), so skip gracefully if the column
    is absent.
    """
    # Enterprise PG schema lacks change_origin — nothing to constrain.
    col_check = bind.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = 'artifact_versions' AND column_name = 'change_origin'"
        )
    )
    if not col_check.fetchone():
        log.info(
            "expand_version_history_constraints (PostgreSQL): artifact_versions.change_origin "
            "does not exist (enterprise schema); skipping."
        )
        return

    if _constraint_already_updated_pg(
        bind, _CHANGE_ORIGIN_CONSTRAINT, "artifact_versions"
    ):
        log.info(
            "expand_version_history_constraints (PostgreSQL): artifact_versions constraint "
            "already contains new values; skipping."
        )
        return

    existing_name = _get_pg_constraint_name(
        bind, _CHANGE_ORIGIN_CONSTRAINT, "artifact_versions"
    )
    if existing_name:
        op.execute(
            text(f"ALTER TABLE artifact_versions DROP CONSTRAINT {existing_name}")
        )

    op.execute(
        text(
            f"ALTER TABLE artifact_versions ADD CONSTRAINT {_CHANGE_ORIGIN_CONSTRAINT} "
            f"CHECK (change_origin IN "
            f"('deployment', 'sync', 'local_modification', 'restore', 'promotion'))"
        )
    )


def _upgrade_event_type_postgresql(bind: sa.engine.Connection) -> None:
    """Extend artifact_history_events.event_type constraint on PostgreSQL."""
    # Table may not exist yet if this runs before 20260311_0003 on a fresh DB.
    tbl_check = bind.execute(
        text(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_name = 'artifact_history_events'"
        )
    )
    if not tbl_check.fetchone():
        log.info(
            "expand_version_history_constraints (PostgreSQL): artifact_history_events "
            "does not exist; skipping."
        )
        return

    if _constraint_already_updated_pg(
        bind, _EVENT_TYPE_CONSTRAINT, "artifact_history_events"
    ):
        log.info(
            "expand_version_history_constraints (PostgreSQL): artifact_history_events constraint "
            "already contains new values; skipping."
        )
        return

    existing_name = _get_pg_constraint_name(
        bind, _EVENT_TYPE_CONSTRAINT, "artifact_history_events"
    )
    if existing_name:
        op.execute(
            text(f"ALTER TABLE artifact_history_events DROP CONSTRAINT {existing_name}")
        )

    op.execute(
        text(
            f"ALTER TABLE artifact_history_events ADD CONSTRAINT {_EVENT_TYPE_CONSTRAINT} "
            f"CHECK (event_type IN "
            f"('create', 'update', 'delete', 'deploy', 'undeploy', 'sync', "
            f"'restore', 'promote', 'force_sync', 'baseline_set'))"
        )
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Restore both CHECK constraints to exclude the new version history values.

    WARNING: rows carrying one of the new values
    (``'restore'``, ``'promotion'`` in change_origin;
    ``'restore'``, ``'promote'``, ``'force_sync'``, ``'baseline_set'`` in event_type)
    will violate the restored constraints.  Remove or migrate those rows before
    running the downgrade.
    """
    bind = op.get_bind()

    if is_sqlite():
        log.info(
            "expand_version_history_constraints downgrade: running SQLite dialect path."
        )
        _downgrade_change_origin_sqlite()
        _downgrade_event_type_sqlite()
    elif is_postgresql():
        log.info(
            "expand_version_history_constraints downgrade: running PostgreSQL dialect path."
        )
        _downgrade_change_origin_postgresql(bind)
        _downgrade_event_type_postgresql(bind)
    else:
        log.warning(
            "expand_version_history_constraints downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _downgrade_change_origin_sqlite() -> None:
    op.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table("artifact_versions", recreate="always") as batch_op:
            batch_op.drop_constraint(_CHANGE_ORIGIN_CONSTRAINT, type_="check")
            batch_op.create_check_constraint(
                _CHANGE_ORIGIN_CONSTRAINT,
                f"change_origin IN {_CHANGE_ORIGIN_OLD}",
            )
    finally:
        op.execute(text("PRAGMA foreign_keys = ON"))


def _downgrade_event_type_sqlite() -> None:
    with op.batch_alter_table("artifact_history_events", recreate="always") as batch_op:
        batch_op.drop_constraint(_EVENT_TYPE_CONSTRAINT, type_="check")
        batch_op.create_check_constraint(
            _EVENT_TYPE_CONSTRAINT,
            f"event_type IN {_EVENT_TYPE_OLD}",
        )


def _downgrade_change_origin_postgresql(bind: sa.engine.Connection) -> None:
    existing_name = _get_pg_constraint_name(
        bind, _CHANGE_ORIGIN_CONSTRAINT, "artifact_versions"
    )
    if existing_name:
        op.execute(
            text(f"ALTER TABLE artifact_versions DROP CONSTRAINT {existing_name}")
        )

    op.execute(
        text(
            f"ALTER TABLE artifact_versions ADD CONSTRAINT {_CHANGE_ORIGIN_CONSTRAINT} "
            f"CHECK (change_origin IN "
            f"('deployment', 'sync', 'local_modification'))"
        )
    )


def _downgrade_event_type_postgresql(bind: sa.engine.Connection) -> None:
    existing_name = _get_pg_constraint_name(
        bind, _EVENT_TYPE_CONSTRAINT, "artifact_history_events"
    )
    if existing_name:
        op.execute(
            text(f"ALTER TABLE artifact_history_events DROP CONSTRAINT {existing_name}")
        )

    op.execute(
        text(
            f"ALTER TABLE artifact_history_events ADD CONSTRAINT {_EVENT_TYPE_CONSTRAINT} "
            f"CHECK (event_type IN "
            f"('create', 'update', 'delete', 'deploy', 'undeploy', 'sync'))"
        )
    )
