"""Add polymorphic bundle membership columns (member_type + context_entity_id).

Revision ID: 20260320_0001_add_polymorphic_bundle_membership
Revises: 20260318_0001_add_scaffold_templates_table
Create Date: 2026-03-20 00:01:00.000000+00:00

Background
----------
Extends ``bundle_memberships`` to support two kinds of members:

1. ``artifact``       — an ``artifacts`` row, referenced via
   ``bundle_memberships.artifact_uuid`` (the existing column).
2. ``context_entity`` — a context-entity row, referenced via the new
   ``context_entity_id`` column.

This "polymorphic membership" model allows a bundle to include both
concrete artifacts and context entities (documentation, reference
materials, etc.) without requiring a separate join table.

Columns Added
-------------
``member_type`` TEXT NOT NULL DEFAULT 'artifact'
    Discriminator column. Valid values enforced at the application layer:
    * ``'artifact'``       → ``artifact_uuid`` must be non-null
    * ``'context_entity'`` → ``context_entity_id`` must be non-null

    Existing rows receive the default value ``'artifact'`` automatically,
    maintaining backward compatibility with all pre-existing membership
    rows that reference artifacts.

``context_entity_id`` TEXT NULL
    Application-layer foreign key to the context entity.  No DB-level FK
    constraint is added here for SQLite compatibility (SQLite does not
    support adding FK constraints via ALTER TABLE after table creation).
    Referential integrity is enforced in the application layer.

Why No DB-level CHECK Constraint
---------------------------------
SQLite does not allow ``ALTER TABLE ... ADD CONSTRAINT CHECK (...)`` after
the table has been created, making a portability-safe CHECK impractical in
a pure-Alembic migration.  Application-layer validation (Pydantic model or
service-layer guard) is used instead.

Dialect Strategy
----------------
* ``op.add_column()`` — supported by both SQLite and PostgreSQL.
* ``sa.text('artifact')`` server_default — portable across both dialects.
* No table-level DDL changes (no new indexes required at this stage).

Downgrade
---------
Drops both columns in reverse order (``context_entity_id`` first, then
``member_type``).  On SQLite, ``op.drop_column()`` performs a full
table-rebuild internally, which is handled transparently by Alembic.

Schema reference
----------------
skillmeat/cache/models.py  (BundleMembership)
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260320_0001_add_polymorphic_bundle_membership"
down_revision: Union[str, None] = "20260318_0001_add_scaffold_templates_table"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add member_type and context_entity_id columns to bundle_memberships."""

    # ------------------------------------------------------------------
    # 1. member_type — discriminator, NOT NULL, defaults to 'artifact'
    #    so all existing rows are transparently migrated.
    # ------------------------------------------------------------------
    op.add_column(
        "bundle_memberships",
        sa.Column(
            "member_type",
            sa.Text(),
            nullable=False,
            server_default=sa.text("'artifact'"),
        ),
    )

    # ------------------------------------------------------------------
    # 2. context_entity_id — nullable app-layer FK, no DB constraint
    #    (SQLite compat: ALTER TABLE cannot add FK after creation).
    # ------------------------------------------------------------------
    op.add_column(
        "bundle_memberships",
        sa.Column(
            "context_entity_id",
            sa.Text(),
            nullable=True,
        ),
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove member_type and context_entity_id columns from bundle_memberships."""

    op.drop_column("bundle_memberships", "context_entity_id")
    op.drop_column("bundle_memberships", "member_type")
