"""Add Backstage v2 deployment and drift-check schema (backstage-plugin-v2 TASK-1.2)

Revision ID: 20260315_0001_add_backstage_v2_deployment_drift
Revises: 20260312_0001_add_bom_signature_fields
Create Date: 2026-03-15 00:01:00.000000+00:00

Background
----------
backstage-plugin-v2 feature — Phase 1 DB migrations.

Two schema changes are required to support Backstage v2 integration:

1. Four nullable columns added to ``deployment_sets``:
   - ``bundle_id``      (String(36))  — UUID of the associated bundle
   - ``bundle_version`` (String(100)) — Version string of the associated bundle
   - ``platform``       (String(50))  — Target deployment platform
   - ``requested_by``   (String(255)) — Identity of the requesting actor

2. New table ``drift_check_results`` — append-only log of drift-check runs
   against a DeploymentSet.  Each row records boolean drift indicators for
   three dimensions (version, content, policy) plus a JSON details blob and
   a staleness flag.

Dialect Strategy
----------------
* ``op.add_column`` is used for the four new nullable columns.  Adding
  nullable columns requires no batch/rebuild on either SQLite or PostgreSQL.
* ``op.create_table`` is used for the new table — supported by both dialects.
* ``sa.JSON`` maps to TEXT on SQLite and JSONB/JSON on PostgreSQL.
* All new columns are nullable — no server_default migration-time data
  fill required (except ``checked_at`` / ``is_stale`` which carry
  server defaults).

Idempotency
-----------
Each ``add_column`` call is guarded by a pre-flight column-existence check
so the migration is safe to re-run against databases that were partially
migrated or created via ``Base.metadata.create_all``.  The table creation
uses ``if_not_exists=True`` via the ``checkfirst`` parameter.

Downgrade
---------
1. Drop ``drift_check_results`` table.
2. Drop the four columns from ``deployment_sets`` using ``batch_alter_table``
   (required for SQLite, which cannot DROP COLUMN natively before v3.35.0).

Schema reference
----------------
skillmeat/cache/models.py  (DeploymentSet, DriftCheckResult)
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260315_0001_add_backstage_v2_deployment_drift"
down_revision: Union[str, None] = "20260314_0001_fix_workflow_execution_fk"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

_DEPLOYMENT_SETS_TABLE = "deployment_sets"
_DRIFT_TABLE = "drift_check_results"

# Columns being added to deployment_sets
_NEW_COLUMNS = [
    ("bundle_id", sa.String(36)),
    ("bundle_version", sa.String(100)),
    ("platform", sa.String(50)),
    ("requested_by", sa.String(255)),
]


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(bind: sa.engine.Connection, table: str, column: str) -> bool:
    """Return True if *column* already exists on *table*."""
    if is_sqlite():
        result = bind.execute(text(f"PRAGMA table_info({table})"))
        return any(row[1] == column for row in result.fetchall())
    else:
        result = bind.execute(
            text("""
                SELECT 1
                FROM information_schema.columns
                WHERE table_name = :tbl
                  AND column_name = :col
                """),
            {"tbl": table, "col": column},
        )
        return result.fetchone() is not None


def _table_exists(bind: sa.engine.Connection, table: str) -> bool:
    """Return True if *table* already exists in the current schema."""
    if is_sqlite():
        result = bind.execute(
            text("SELECT name FROM sqlite_master WHERE type='table' AND name=:tbl"),
            {"tbl": table},
        )
        return result.fetchone() is not None
    else:
        result = bind.execute(
            text("""
                SELECT 1
                FROM information_schema.tables
                WHERE table_name = :tbl
                """),
            {"tbl": table},
        )
        return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add Backstage v2 columns to deployment_sets and create drift_check_results."""
    bind = op.get_bind()

    # ------------------------------------------------------------------
    # 1. Add four nullable columns to deployment_sets
    # ------------------------------------------------------------------
    for col_name, col_type in _NEW_COLUMNS:
        if _column_exists(bind, _DEPLOYMENT_SETS_TABLE, col_name):
            log.info(
                "add_backstage_v2_deployment_drift: column %r already exists on %r; skipping.",
                col_name,
                _DEPLOYMENT_SETS_TABLE,
            )
            continue
        log.info(
            "add_backstage_v2_deployment_drift: adding column %r to %r.",
            col_name,
            _DEPLOYMENT_SETS_TABLE,
        )
        op.add_column(
            _DEPLOYMENT_SETS_TABLE,
            sa.Column(col_name, col_type, nullable=True),
        )

    # ------------------------------------------------------------------
    # 2. Create drift_check_results table
    # ------------------------------------------------------------------
    if _table_exists(bind, _DRIFT_TABLE):
        log.info(
            "add_backstage_v2_deployment_drift: table %r already exists; skipping creation.",
            _DRIFT_TABLE,
        )
    else:
        log.info(
            "add_backstage_v2_deployment_drift: creating table %r.",
            _DRIFT_TABLE,
        )
        op.create_table(
            _DRIFT_TABLE,
            sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
            sa.Column(
                "deployment_set_id",
                sa.String(),
                sa.ForeignKey(
                    f"{_DEPLOYMENT_SETS_TABLE}.id",
                    ondelete="CASCADE",
                    name="fk_drift_check_results_deployment_set_id",
                ),
                nullable=False,
            ),
            sa.Column("version_drift", sa.Boolean(), nullable=True),
            sa.Column("content_drift", sa.Boolean(), nullable=True),
            sa.Column("policy_drift", sa.Boolean(), nullable=True),
            sa.Column(
                "checked_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("CURRENT_TIMESTAMP"),
            ),
            sa.Column(
                "is_stale",
                sa.Boolean(),
                nullable=False,
                server_default=sa.text("false"),
            ),
            sa.Column("details", sa.JSON(), nullable=True),
        )
        op.create_index(
            "idx_drift_check_results_deployment_set_id",
            _DRIFT_TABLE,
            ["deployment_set_id"],
        )
        op.create_index(
            "idx_drift_check_results_checked_at",
            _DRIFT_TABLE,
            ["checked_at"],
        )

    log.info("add_backstage_v2_deployment_drift: upgrade complete.")


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop drift_check_results table and remove Backstage v2 columns from deployment_sets.

    Uses batch_alter_table for the column drops so that SQLite (which cannot
    drop columns natively before v3.35.0) gets a full table-rebuild.
    """
    # Drop drift_check_results first (has FK dependency on deployment_sets)
    log.info(
        "add_backstage_v2_deployment_drift: dropping table %r.",
        _DRIFT_TABLE,
    )
    op.drop_index("idx_drift_check_results_checked_at", table_name=_DRIFT_TABLE)
    op.drop_index("idx_drift_check_results_deployment_set_id", table_name=_DRIFT_TABLE)
    op.drop_table(_DRIFT_TABLE)

    # Drop the four new columns from deployment_sets
    log.info(
        "add_backstage_v2_deployment_drift: dropping Backstage v2 columns from %r.",
        _DEPLOYMENT_SETS_TABLE,
    )
    with op.batch_alter_table(_DEPLOYMENT_SETS_TABLE) as batch_op:
        for col_name, _ in reversed(_NEW_COLUMNS):
            batch_op.drop_column(col_name)

    log.info("add_backstage_v2_deployment_drift: downgrade complete.")
