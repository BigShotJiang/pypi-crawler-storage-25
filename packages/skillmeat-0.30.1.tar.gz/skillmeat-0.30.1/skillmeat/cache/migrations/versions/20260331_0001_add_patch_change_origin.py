"""Add 'patch' to artifact_versions change_origin CHECK constraint (DVCS-5b).

Revision ID: 20260331_0001_add_patch_change_origin
Revises: 20260330_0009_add_tier_fqan_columns
Create Date: 2026-03-31 00:01:00.000000+00:00

Background
----------
DVCS Phase 5b introduces the ability to create patch versions of artifacts via
``POST /api/v1/versions/artifacts/{artifact_id}/versions/patch``.  These versions
are recorded with ``change_origin='patch'``.

The existing CHECK constraint on ``artifact_versions.change_origin`` does not
include ``'patch'``, so any INSERT with that value would be rejected.

Changes
-------
1. Update the CHECK constraint ``check_artifact_versions_change_origin`` on
   ``artifact_versions`` to include ``'patch'`` in the allowed values list.

Dialect Strategy
----------------
- **SQLite**: Use ``batch_alter_table(recreate='always')`` to swap the table
  and replace the CHECK constraint.  ``PRAGMA foreign_keys`` must be disabled
  during the recreation to avoid FK constraint failures from referencing tables
  (``bundle_commit_members``, ``artifact_collection_versions``).
- **PostgreSQL**: Drop the old CHECK constraint, then create a new one that
  includes ``'patch'``.

Both upgrade and downgrade paths are idempotent.

Downgrade
---------
Restores the CHECK constraint to exclude ``'patch'`` (the DVCS-5b predecessor
state after ``20260330_0009_add_tier_fqan_columns``).
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_postgresql, is_sqlite

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260331_0001_add_patch_change_origin"
down_revision: Union[str, None] = "20260330_0009_add_tier_fqan_columns"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_VERSIONS_TABLE = "artifact_versions"
_CK_ORIGIN = "check_artifact_versions_change_origin"

_ORIGIN_VALUES_WITHOUT_PATCH = (
    "'initial_seed', 'deployment', 'sync', 'local_modification', "
    "'restore', 'promotion', 'push', 'github_update', 'import', "
    "'policy_enforcement', 'composite_update', 'rename'"
)
_ORIGIN_VALUES_WITH_PATCH = (
    "'initial_seed', 'deployment', 'sync', 'local_modification', "
    "'restore', 'promotion', 'push', 'github_update', 'import', "
    "'policy_enforcement', 'composite_update', 'rename', 'patch'"
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _constraint_exists_pg(
    bind: sa.engine.Connection, constraint: str, table: str
) -> bool:
    """Check whether a named constraint exists on a PostgreSQL table.

    Args:
        bind: Active database connection.
        constraint: Constraint name.
        table: Table name.

    Returns:
        True if the constraint exists.
    """
    result = bind.execute(
        text(
            "SELECT 1 FROM pg_constraint c "
            "JOIN pg_class t ON t.oid = c.conrelid "
            "WHERE c.conname = :cname AND t.relname = :tname"
        ),
        {"cname": constraint, "tname": table},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add 'patch' to artifact_versions change_origin CHECK constraint."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_patch_change_origin upgrade: SQLite path.")
        _upgrade_sqlite()
    elif is_postgresql():
        log.info("add_patch_change_origin upgrade: PostgreSQL path.")
        _upgrade_postgresql(bind)
    else:
        log.warning(
            "add_patch_change_origin upgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _upgrade_sqlite() -> None:
    """Recreate artifact_versions with updated CHECK to include 'patch'."""
    bind = op.get_bind()
    bind.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table(_VERSIONS_TABLE, recreate="always") as batch_op:
            batch_op.create_check_constraint(
                _CK_ORIGIN,
                f"change_origin IN ({_ORIGIN_VALUES_WITH_PATCH})",
            )
        log.info(
            "add_patch_change_origin (SQLite): updated %s change_origin CHECK to include 'patch'.",
            _VERSIONS_TABLE,
        )
    finally:
        bind.execute(text("PRAGMA foreign_keys = ON"))


def _upgrade_postgresql(bind: sa.engine.Connection) -> None:
    """Update artifact_versions CHECK constraint on PostgreSQL."""
    # Enterprise PG schema lacks change_origin — nothing to constrain.
    col_check = bind.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = 'artifact_versions' AND column_name = 'change_origin'"
        )
    )
    if not col_check.fetchone():
        log.info(
            "add_patch_change_origin (PG): artifact_versions.change_origin "
            "does not exist (enterprise schema); skipping."
        )
        return
    if _constraint_exists_pg(bind, _CK_ORIGIN, _VERSIONS_TABLE):
        op.drop_constraint(_CK_ORIGIN, _VERSIONS_TABLE, type_="check")
    op.create_check_constraint(
        _CK_ORIGIN,
        _VERSIONS_TABLE,
        f"change_origin IN ({_ORIGIN_VALUES_WITH_PATCH})",
    )
    log.info(
        "add_patch_change_origin (PG): updated %s change_origin CHECK to include 'patch'.",
        _VERSIONS_TABLE,
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove 'patch' from artifact_versions change_origin CHECK constraint."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_patch_change_origin downgrade: SQLite path.")
        _downgrade_sqlite()
    elif is_postgresql():
        log.info("add_patch_change_origin downgrade: PostgreSQL path.")
        _downgrade_postgresql(bind)
    else:
        log.warning(
            "add_patch_change_origin downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


def _downgrade_sqlite() -> None:
    """Restore artifact_versions CHECK to exclude 'patch'."""
    bind = op.get_bind()
    bind.execute(text("PRAGMA foreign_keys = OFF"))
    try:
        with op.batch_alter_table(_VERSIONS_TABLE, recreate="always") as batch_op:
            batch_op.create_check_constraint(
                _CK_ORIGIN,
                f"change_origin IN ({_ORIGIN_VALUES_WITHOUT_PATCH})",
            )
        log.info(
            "add_patch_change_origin (SQLite) downgrade: restored %s change_origin CHECK "
            "to exclude 'patch'.",
            _VERSIONS_TABLE,
        )
    finally:
        bind.execute(text("PRAGMA foreign_keys = ON"))


def _downgrade_postgresql(bind: sa.engine.Connection) -> None:
    """Restore artifact_versions CHECK to exclude 'patch' on PostgreSQL."""
    col_check = bind.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = 'artifact_versions' AND column_name = 'change_origin'"
        )
    )
    if not col_check.fetchone():
        log.info(
            "add_patch_change_origin (PG) downgrade: artifact_versions.change_origin "
            "does not exist (enterprise schema); skipping."
        )
        return
    if _constraint_exists_pg(bind, _CK_ORIGIN, _VERSIONS_TABLE):
        op.drop_constraint(_CK_ORIGIN, _VERSIONS_TABLE, type_="check")
    op.create_check_constraint(
        _CK_ORIGIN,
        _VERSIONS_TABLE,
        f"change_origin IN ({_ORIGIN_VALUES_WITHOUT_PATCH})",
    )
    log.info(
        "add_patch_change_origin (PG) downgrade: restored %s change_origin CHECK "
        "to exclude 'patch'.",
        _VERSIONS_TABLE,
    )
