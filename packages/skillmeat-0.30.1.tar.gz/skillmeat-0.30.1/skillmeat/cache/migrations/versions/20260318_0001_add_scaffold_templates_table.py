"""Add scaffold_templates table (template-management).

Revision ID: 20260318_0001_add_scaffold_templates_table
Revises: bundle_001
Create Date: 2026-03-18 00:01:00.000000+00:00

Background
----------
template-management feature.  Adds the ``scaffold_templates`` table that
stores the Backstage scaffold template configuration for a given bundle.

Each ``BundleEntity`` may have at most one ``ScaffoldTemplate`` row; the
``bundle_id`` column carries a UNIQUE constraint to enforce this at the
database level.

Table Created
-------------
``scaffold_templates`` — Scaffold template configuration linked 1-to-1 to a
``BundleEntity``.  Stores variable contracts, Backstage metadata (owner, type,
tags), an optional skeleton GitHub URL, and a capped generation-event history.

Schema reference
----------------
skillmeat/cache/models.py  (ScaffoldTemplate class)
docs/project_plans/PRDs/ template-management/
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260318_0001_add_scaffold_templates_table"
down_revision: Union[str, None] = "bundle_001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create scaffold_templates table."""
    op.create_table(
        "scaffold_templates",
        # Primary key
        sa.Column("id", sa.String(), nullable=False),
        # Foreign key to bundles (1-to-1)
        sa.Column("bundle_id", sa.String(), nullable=False),
        # Activation flag
        sa.Column(
            "enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
        # Variable contract
        sa.Column(
            "required_variables",
            sa.JSON(),
            nullable=True,
            comment="JSON list of required variable name strings",
        ),
        sa.Column(
            "variable_type_map",
            sa.JSON(),
            nullable=True,
            comment="JSON dict mapping variable names to Backstage UI field types",
        ),
        # Skeleton source
        sa.Column(
            "skeleton_ref",
            sa.String(),
            nullable=True,
            comment="GitHub URL for the fetch:template step in template.yaml",
        ),
        # Backstage metadata
        sa.Column("backstage_owner", sa.String(), nullable=True),
        sa.Column(
            "backstage_type",
            sa.String(),
            nullable=False,
            server_default="service",
        ),
        sa.Column(
            "backstage_tags",
            sa.JSON(),
            nullable=True,
            comment="JSON list of tag strings for the Backstage template spec",
        ),
        # Generation tracking
        sa.Column(
            "bundle_version_at_last_generation",
            sa.String(),
            nullable=True,
            comment="Bundle version string at the time of the last template generation",
        ),
        sa.Column(
            "generation_history",
            sa.JSON(),
            nullable=True,
            comment="JSON list of generation event dicts, capped at 20 by service layer",
        ),
        # Timestamps
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
        ),
        # Constraints
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("bundle_id", name="uq_scaffold_templates_bundle_id"),
        sa.ForeignKeyConstraint(
            ["bundle_id"],
            ["bundles.id"],
            name="fk_scaffold_templates_bundle_id",
            ondelete="CASCADE",
        ),
    )

    op.create_index(
        "idx_scaffold_templates_bundle_id",
        "scaffold_templates",
        ["bundle_id"],
    )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop scaffold_templates table."""
    op.drop_index(
        "idx_scaffold_templates_bundle_id",
        table_name="scaffold_templates",
    )
    op.drop_table("scaffold_templates")
