"""Add artifact_version_scopes table and tenant_id to artifact_history_events (enterprise).

Revision ID: ent_010_version_scopes_and_history_tenant
Revises: ent_009_telemetry_tables
Create Date: 2026-03-27 00:10:00.000000+00:00

Background
----------
Artifact Version History & Restore feature (Phase 1, DB-1.3 and DB-1.4).
Enterprise-PostgreSQL-only migration.  This migration is a no-op on any
non-PostgreSQL dialect.

Changes
-------
DB-1.3 — Create ``artifact_version_scopes`` table:

    New table that tracks per-owner-per-project version scope state for an
    artifact.  Each row pins one (tenant, project, artifact, owner) combination
    to a ``head_hash`` (current content hash), an optional ``baseline_hash``
    (last approved state), a divergence flag, and a promotion workflow state
    machine.

    Schema:
        id                      UUID PRIMARY KEY DEFAULT gen_random_uuid()
        tenant_id               UUID NOT NULL
        project_id              UUID NOT NULL
        artifact_id             UUID NOT NULL REFERENCES enterprise_artifacts(id) ON DELETE CASCADE
        owner_type              TEXT NOT NULL CHECK (owner_type IN ('user','team','enterprise'))
        owner_id                UUID NOT NULL
        head_hash               TEXT NOT NULL CHECK (length(head_hash) = 64)
        baseline_hash           TEXT
        is_diverged             BOOLEAN NOT NULL DEFAULT FALSE
        promotion_state         TEXT CHECK (promotion_state IN ('none','pending','approved','rejected'))
        promotion_requested_at  TIMESTAMPTZ
        promotion_reviewed_by   UUID
        promotion_reviewed_at   TIMESTAMPTZ
        created_at              TIMESTAMPTZ NOT NULL DEFAULT now()
        updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()

    Indexes (all 4 required):
        uq_version_scopes_owner_artifact_project  UNIQUE (tenant_id, project_id, artifact_id, owner_type, owner_id)
        idx_version_scopes_tenant_project         (tenant_id, project_id)
        idx_version_scopes_artifact               (artifact_id)
        idx_version_scopes_diverged               (tenant_id, is_diverged) WHERE is_diverged = TRUE

    An ``updated_at`` trigger is created via dialect_helpers so the column is
    maintained automatically on every UPDATE.

DB-1.4 — Add ``tenant_id`` to ``artifact_history_events``:

    The ``artifact_history_events`` table exists in the local SQLite schema
    (20260311_0003_add_skillbom_attestation_tables.py) but does NOT yet have a
    ``tenant_id`` column in the enterprise PostgreSQL schema.  This migration
    adds:

        tenant_id   UUID NOT NULL DEFAULT '<zero-uuid>'
        index       idx_history_events_tenant_artifact_time ON
                    artifact_history_events (tenant_id, artifact_id, created_at DESC)

    Because existing enterprise rows (if any) need a non-null value, a
    temporary server default is applied during the ADD COLUMN, then the default
    is dropped after the index is created.  The zero-UUID
    (00000000-0000-0000-0000-000000000000) is used as the sentinel for rows that
    pre-date tenant scoping — callers must backfill these rows with real tenant
    IDs before relying on tenant-scoped queries.

    Idempotency:
        The upgrade checks whether ``tenant_id`` already exists on the table
        before issuing the ALTER TABLE statement.  If the column is already
        present the step is skipped silently.

Downgrade
---------
DB-1.4 downgrade drops the index then the column (if it exists).
DB-1.3 downgrade drops the ``updated_at`` trigger then the table.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

from skillmeat.cache.migrations.dialect_helpers import (
    create_updated_at_trigger,
    drop_updated_at_trigger,
)

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_010_version_scopes_and_history_tenant"
down_revision: Union[str, Sequence[str], None] = (
    "ent_009_telemetry_tables",
    "20260311_0003_add_skillbom_attestation_tables",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ZERO_UUID = "00000000-0000-0000-0000-000000000000"

_VERSION_SCOPES_TABLE = "artifact_version_scopes"
_HISTORY_TABLE = "artifact_history_events"

_TENANT_ID_INDEX = "idx_history_events_tenant_artifact_time"


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(
    bind: sa.engine.Connection, table_name: str, column_name: str
) -> bool:
    """Return True if *column_name* already exists on *table_name* (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.columns
            WHERE table_name = :tname
              AND column_name = :cname
            """),
        {"tname": table_name, "cname": column_name},
    )
    return result.fetchone() is not None


def _table_exists(bind: sa.engine.Connection, table_name: str) -> bool:
    """Return True if *table_name* already exists (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.tables
            WHERE table_name = :tname
            """),
        {"tname": table_name},
    )
    return result.fetchone() is not None


def _index_exists(bind: sa.engine.Connection, index_name: str) -> bool:
    """Return True if *index_name* already exists (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM pg_indexes
            WHERE indexname = :iname
            """),
        {"iname": index_name},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create artifact_version_scopes and add tenant_id to artifact_history_events."""
    if not _is_postgresql():
        log.info(
            "ent_010_version_scopes_and_history_tenant: non-PostgreSQL dialect detected; "
            "skipping enterprise-only migration."
        )
        return

    log.info(
        "ent_010_version_scopes_and_history_tenant upgrade: running PostgreSQL path."
    )
    _upgrade_version_scopes()
    _upgrade_history_tenant_id()


def _upgrade_version_scopes() -> None:
    """DB-1.3: Create artifact_version_scopes table with all required indexes."""
    bind = op.get_bind()

    if _table_exists(bind, _VERSION_SCOPES_TABLE):
        log.info(
            "ent_010 (DB-1.3): %s already exists; skipping table creation.",
            _VERSION_SCOPES_TABLE,
        )
    else:
        op.create_table(
            _VERSION_SCOPES_TABLE,
            sa.Column(
                "id",
                postgresql.UUID(as_uuid=True),
                primary_key=True,
                server_default=text("gen_random_uuid()"),
                comment="Primary key; server-generated UUID",
            ),
            sa.Column(
                "tenant_id",
                postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
            ),
            sa.Column(
                "project_id",
                postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="Project that this scope entry belongs to",
            ),
            sa.Column(
                "artifact_id",
                postgresql.UUID(as_uuid=True),
                sa.ForeignKey(
                    "enterprise_artifacts.id",
                    ondelete="CASCADE",
                    name="fk_version_scopes_artifact_id",
                ),
                nullable=False,
                comment="Parent artifact; cascade-deletes all scope rows when artifact is removed",
            ),
            sa.Column(
                "owner_type",
                sa.Text(),
                nullable=False,
                comment="Owner category: 'user', 'team', or 'enterprise'",
            ),
            sa.Column(
                "owner_id",
                postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="UUID of the owning user, team, or enterprise entity",
            ),
            sa.Column(
                "head_hash",
                sa.Text(),
                nullable=False,
                comment="SHA-256 hex digest (64 chars) of the current head content",
            ),
            sa.Column(
                "baseline_hash",
                sa.Text(),
                nullable=True,
                comment="SHA-256 hex digest of the last approved baseline; NULL until first baseline is set",
            ),
            sa.Column(
                "is_diverged",
                sa.Boolean(),
                nullable=False,
                server_default=text("FALSE"),
                comment="True when head_hash differs from baseline_hash",
            ),
            sa.Column(
                "promotion_state",
                sa.Text(),
                nullable=True,
                comment="Promotion workflow state: 'none', 'pending', 'approved', or 'rejected'",
            ),
            sa.Column(
                "promotion_requested_at",
                sa.DateTime(timezone=True),
                nullable=True,
                comment="Wall-clock time when promotion was requested; NULL if not in promotion flow",
            ),
            sa.Column(
                "promotion_reviewed_by",
                postgresql.UUID(as_uuid=True),
                nullable=True,
                comment="UUID of the reviewer who approved or rejected the promotion",
            ),
            sa.Column(
                "promotion_reviewed_at",
                sa.DateTime(timezone=True),
                nullable=True,
                comment="Wall-clock time when the promotion was reviewed",
            ),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=text("now()"),
                comment="Immutable creation timestamp",
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=text("now()"),
                comment="Last-modified timestamp; maintained by trigger",
            ),
            # CHECK constraints
            sa.CheckConstraint(
                "owner_type IN ('user', 'team', 'enterprise')",
                name="ck_version_scopes_owner_type",
            ),
            sa.CheckConstraint(
                "length(head_hash) = 64",
                name="ck_version_scopes_head_hash_length",
            ),
            sa.CheckConstraint(
                "promotion_state IN ('none', 'pending', 'approved', 'rejected')",
                name="ck_version_scopes_promotion_state",
            ),
        )
        log.info("ent_010 (DB-1.3): created table %s.", _VERSION_SCOPES_TABLE)

    # Unique index: one scope entry per (tenant, project, artifact, owner)
    bind = op.get_bind()
    if not _index_exists(bind, "uq_version_scopes_owner_artifact_project"):
        op.create_index(
            "uq_version_scopes_owner_artifact_project",
            _VERSION_SCOPES_TABLE,
            ["tenant_id", "project_id", "artifact_id", "owner_type", "owner_id"],
            unique=True,
        )
        log.info(
            "ent_010 (DB-1.3): created unique index uq_version_scopes_owner_artifact_project."
        )

    # B-tree: fast tenant + project filter
    if not _index_exists(bind, "idx_version_scopes_tenant_project"):
        op.create_index(
            "idx_version_scopes_tenant_project",
            _VERSION_SCOPES_TABLE,
            ["tenant_id", "project_id"],
        )
        log.info("ent_010 (DB-1.3): created index idx_version_scopes_tenant_project.")

    # B-tree: FK index
    if not _index_exists(bind, "idx_version_scopes_artifact"):
        op.create_index(
            "idx_version_scopes_artifact",
            _VERSION_SCOPES_TABLE,
            ["artifact_id"],
        )
        log.info("ent_010 (DB-1.3): created index idx_version_scopes_artifact.")

    # Partial B-tree: diverged-only filter (is_diverged = TRUE rows only)
    if not _index_exists(bind, "idx_version_scopes_diverged"):
        op.execute(
            text(
                "CREATE INDEX idx_version_scopes_diverged "
                f"ON {_VERSION_SCOPES_TABLE} (tenant_id, is_diverged) "
                "WHERE is_diverged = TRUE"
            )
        )
        log.info("ent_010 (DB-1.3): created partial index idx_version_scopes_diverged.")

    # updated_at trigger
    create_updated_at_trigger(_VERSION_SCOPES_TABLE)
    log.info(
        "ent_010 (DB-1.3): created updated_at trigger for %s.", _VERSION_SCOPES_TABLE
    )


def _upgrade_history_tenant_id() -> None:
    """DB-1.4: Add tenant_id column and index to artifact_history_events."""
    bind = op.get_bind()

    if _column_exists(bind, _HISTORY_TABLE, "tenant_id"):
        log.info(
            "ent_010 (DB-1.4): tenant_id already exists on %s; skipping column add.",
            _HISTORY_TABLE,
        )
    else:
        # Add the column with a temporary server default to satisfy NOT NULL for
        # existing rows.  After the column is added we drop the server default so
        # new inserts must always supply an explicit tenant_id.
        op.add_column(
            _HISTORY_TABLE,
            sa.Column(
                "tenant_id",
                postgresql.UUID(as_uuid=True),
                nullable=False,
                server_default=text(f"'{_ZERO_UUID}'::uuid"),
                comment=(
                    "Tenant scope for enterprise multi-tenancy.  "
                    f"Rows with the zero UUID ({_ZERO_UUID}) pre-date tenant scoping "
                    "and must be backfilled."
                ),
            ),
        )
        # Drop the server default — new inserts must supply tenant_id explicitly.
        op.alter_column(_HISTORY_TABLE, "tenant_id", server_default=None)
        log.info("ent_010 (DB-1.4): added tenant_id column to %s.", _HISTORY_TABLE)

    # Create the composite index whether or not the column was just added
    # (idempotent: no-op if already present).
    if not _index_exists(bind, _TENANT_ID_INDEX):
        op.execute(
            text(
                f"CREATE INDEX {_TENANT_ID_INDEX} "
                f"ON {_HISTORY_TABLE} (tenant_id, artifact_id, timestamp DESC)"
            )
        )
        log.info(
            "ent_010 (DB-1.4): created index %s on %s.",
            _TENANT_ID_INDEX,
            _HISTORY_TABLE,
        )
    else:
        log.info(
            "ent_010 (DB-1.4): index %s already exists; skipping.", _TENANT_ID_INDEX
        )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Reverse DB-1.3 and DB-1.4 enterprise changes.

    WARNING: dropping tenant_id from artifact_history_events is destructive if
    the column contains non-zero tenant UUIDs.  Ensure data is backed up or
    migrated before running this downgrade.
    """
    if not _is_postgresql():
        log.info(
            "ent_010_version_scopes_and_history_tenant downgrade: "
            "non-PostgreSQL dialect detected; skipping."
        )
        return

    log.info(
        "ent_010_version_scopes_and_history_tenant downgrade: running PostgreSQL path."
    )
    _downgrade_history_tenant_id()
    _downgrade_version_scopes()


def _downgrade_history_tenant_id() -> None:
    """DB-1.4: Remove tenant_id index and column from artifact_history_events."""
    bind = op.get_bind()

    if _index_exists(bind, _TENANT_ID_INDEX):
        op.execute(text(f"DROP INDEX IF EXISTS {_TENANT_ID_INDEX}"))
        log.info("ent_010 (DB-1.4): dropped index %s.", _TENANT_ID_INDEX)

    if _column_exists(bind, _HISTORY_TABLE, "tenant_id"):
        op.drop_column(_HISTORY_TABLE, "tenant_id")
        log.info("ent_010 (DB-1.4): dropped tenant_id column from %s.", _HISTORY_TABLE)


def _downgrade_version_scopes() -> None:
    """DB-1.3: Drop artifact_version_scopes table and its trigger."""
    bind = op.get_bind()

    if not _table_exists(bind, _VERSION_SCOPES_TABLE):
        log.info(
            "ent_010 (DB-1.3): %s does not exist; skipping drop.", _VERSION_SCOPES_TABLE
        )
        return

    # Drop trigger before table
    drop_updated_at_trigger(_VERSION_SCOPES_TABLE)

    # Indexes are dropped automatically with the table; explicit drops not needed.
    op.drop_table(_VERSION_SCOPES_TABLE)
    log.info("ent_010 (DB-1.3): dropped table %s.", _VERSION_SCOPES_TABLE)
