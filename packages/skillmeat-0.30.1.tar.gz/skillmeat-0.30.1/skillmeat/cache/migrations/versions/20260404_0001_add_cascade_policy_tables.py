"""Add enterprise_cascade_policies and enterprise_cascade_policy_audit tables (DS-4, BE-4.T3).

Revision ID: 20260404_0001_add_cascade_policy_tables
Revises: ent_022_admin_sync_prereq, 20260403_0002_gcd_access_token_credentials
Create Date: 2026-04-04 00:01:00.000000+00:00

Background
----------
Phase 4 of the Enterprise Unified Sync UX feature.  Implements the cascade
policy data model specified in DS-4 §2.3 and §5.1.

Two new enterprise-only (PostgreSQL) tables are created:

1. ``enterprise_cascade_policies``
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   Stores cascade policy configuration entries at three scope levels:

   * Org-default   — artifact_id IS NULL AND team_id IS NULL
   * Per-artifact  — artifact_id IS SET, team_id IS NULL
   * Per-team      — artifact_id IS SET, team_id IS SET

   The policy_type column holds one of two values ('soft_update' /
   'hard_update').  is_auto_propagate controls whether the policy fires
   automatically on upstream version bumps or only on explicit admin action.

   Unique constraint ``uq_ent_cascade_policy_scope`` on (org_id, artifact_id,
   team_id) guarantees at most one policy per scope combination.  A CHECK
   constraint enforces that team_id can only be set when artifact_id is also
   set (no team-only org-wide policy exemptions, per DS-4 §2.2).

2. ``enterprise_cascade_policy_audit``
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   Append-only audit log.  Every create, update, or delete on
   ``enterprise_cascade_policies`` writes one row here within the same DB
   transaction.  Rows are immutable once written.

Both tables are PostgreSQL-only.  The migration is idempotent (table
existence is checked before creation).  The upgrade() body skips table
creation on SQLite, which is the local-mode database and does not host
enterprise tables.

This migration merges two previously divergent heads:
  - ent_022_admin_sync_prereq       (enterprise track)
  - 20260403_0002_gcd_access_token_credentials  (GCD / community track)

Indexes
-------
enterprise_cascade_policies:
  idx_ent_cp_tenant_id       (tenant_id)
  idx_ent_cp_org_id          (org_id)
  idx_ent_cp_tenant_artifact (tenant_id, artifact_id)
  idx_ent_cp_tenant_team     (tenant_id, team_id)

enterprise_cascade_policy_audit:
  idx_ent_cpa_tenant_id       (tenant_id)
  idx_ent_cpa_org_id          (org_id)
  idx_ent_cpa_tenant_artifact (tenant_id, artifact_id)
  idx_ent_cpa_changed_at      (tenant_id, changed_at)

Rollback
--------
downgrade() drops both tables (audit first, then policy) on PostgreSQL,
preserving referential integrity.  On SQLite, no tables are created, so
downgrade() is a no-op.

Schema reference
----------------
skillmeat/cache/models_enterprise.py  (EnterpriseCascadePolicy, EnterpriseCascadePolicyAudit)
docs/project_plans/design-specs/tier-cascade-policy-configuration-spec.md  (DS-4 §2, §5)
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import (
    create_updated_at_trigger,
    drop_updated_at_trigger,
    is_postgresql,
    is_sqlite,
)

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260404_0001_add_cascade_policy_tables"
down_revision: Union[str, Sequence[str], None] = (
    "ent_022_admin_sync_prereq",
    "20260403_0002_gcd_access_token_credentials",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# ---------------------------------------------------------------------------
# Table names
# ---------------------------------------------------------------------------

_POLICY_TABLE = "enterprise_cascade_policies"
_AUDIT_TABLE = "enterprise_cascade_policy_audit"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _table_exists(bind: sa.engine.Connection, table_name: str) -> bool:
    """Return True if *table_name* already exists in the connected database."""
    insp = sa.inspect(bind)
    return table_name in insp.get_table_names()


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create enterprise_cascade_policies and enterprise_cascade_policy_audit tables."""
    if is_sqlite():
        log.info(
            "add_cascade_policy_tables upgrade: SQLite dialect detected; "
            "enterprise tables are PostgreSQL-only — skipping."
        )
        return

    if not is_postgresql():
        log.warning(
            "add_cascade_policy_tables upgrade: unknown dialect %r; skipping.",
            op.get_bind().dialect.name,
        )
        return

    bind = op.get_bind()

    # -----------------------------------------------------------------
    # 1. enterprise_cascade_policies
    # -----------------------------------------------------------------
    if _table_exists(bind, _POLICY_TABLE):
        log.info(
            "add_cascade_policy_tables: %s already exists; skipping creation.",
            _POLICY_TABLE,
        )
    else:
        log.info("add_cascade_policy_tables: creating %s.", _POLICY_TABLE)
        op.create_table(
            _POLICY_TABLE,
            # Identity
            sa.Column(
                "id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                primary_key=True,
                server_default=text("gen_random_uuid()"),
                comment="Globally unique cascade policy identifier",
            ),
            sa.Column(
                "tenant_id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
            ),
            # Org linkage
            sa.Column(
                "org_id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                sa.ForeignKey(
                    "enterprise_settings.id",
                    ondelete="CASCADE",
                    name="fk_ent_cp_org_id",
                ),
                nullable=False,
                comment="FK to enterprise_settings.id — the organisation this policy is scoped to",
            ),
            # Scope selectors
            sa.Column(
                "artifact_id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                sa.ForeignKey(
                    "enterprise_artifacts.id",
                    ondelete="CASCADE",
                    name="fk_ent_cp_artifact_id",
                ),
                nullable=True,
                comment=(
                    "NULL → org-level default policy. "
                    "Set  → per-artifact override or per-team exemption."
                ),
            ),
            sa.Column(
                "team_id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                sa.ForeignKey(
                    "enterprise_teams.id",
                    ondelete="CASCADE",
                    name="fk_ent_cp_team_id",
                ),
                nullable=True,
                comment=(
                    "NULL → applies to all teams. "
                    "Set  → per-team exemption; requires artifact_id to also be set."
                ),
            ),
            # Policy configuration
            sa.Column(
                "policy_type",
                sa.String(20),
                nullable=False,
                comment="Cascade action: 'soft_update' or 'hard_update'",
            ),
            sa.Column(
                "is_auto_propagate",
                sa.Boolean,
                nullable=False,
                server_default=text("false"),
                comment=(
                    "True  → triggers automatically on upstream version bump; "
                    "False → requires explicit admin action."
                ),
            ),
            # Audit / provenance
            sa.Column(
                "created_by",
                sa.dialects.postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="UUID of the enterprise user who created this policy row",
            ),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=text("now()"),
                comment="Timezone-aware creation timestamp; server-generated",
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=text("now()"),
                comment="Timezone-aware last-modified timestamp; updated by app on every write",
            ),
            # Table-level constraints
            sa.UniqueConstraint(
                "org_id",
                "artifact_id",
                "team_id",
                name="uq_ent_cascade_policy_scope",
            ),
            sa.CheckConstraint(
                "policy_type IN ('soft_update', 'hard_update')",
                name="ck_ent_cascade_policy_type",
            ),
            sa.CheckConstraint(
                "team_id IS NULL OR artifact_id IS NOT NULL",
                name="ck_ent_cascade_policy_team_requires_artifact",
            ),
        )

        # Indexes
        op.create_index(
            "idx_ent_cp_tenant_id",
            _POLICY_TABLE,
            ["tenant_id"],
        )
        op.create_index(
            "idx_ent_cp_org_id",
            _POLICY_TABLE,
            ["org_id"],
        )
        op.create_index(
            "idx_ent_cp_tenant_artifact",
            _POLICY_TABLE,
            ["tenant_id", "artifact_id"],
        )
        op.create_index(
            "idx_ent_cp_tenant_team",
            _POLICY_TABLE,
            ["tenant_id", "team_id"],
        )

        # updated_at auto-maintenance trigger (PostgreSQL function + trigger)
        create_updated_at_trigger(_POLICY_TABLE)

    # -----------------------------------------------------------------
    # 2. enterprise_cascade_policy_audit
    # -----------------------------------------------------------------
    if _table_exists(bind, _AUDIT_TABLE):
        log.info(
            "add_cascade_policy_tables: %s already exists; skipping creation.",
            _AUDIT_TABLE,
        )
    else:
        log.info("add_cascade_policy_tables: creating %s.", _AUDIT_TABLE)
        op.create_table(
            _AUDIT_TABLE,
            # Identity
            sa.Column(
                "id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                primary_key=True,
                server_default=text("gen_random_uuid()"),
                comment="Globally unique audit log entry identifier",
            ),
            sa.Column(
                "tenant_id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="Tenant scope; every query MUST include WHERE tenant_id = ?",
            ),
            # Scope selectors (mirror the corresponding policy row)
            sa.Column(
                "org_id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="UUID of the org whose cascade policy was mutated",
            ),
            sa.Column(
                "artifact_id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                nullable=True,
                comment="Artifact scope of the mutated policy row; NULL for org-level default",
            ),
            sa.Column(
                "team_id",
                sa.dialects.postgresql.UUID(as_uuid=True),
                nullable=True,
                comment="Team scope of the mutated policy row; NULL for org or artifact level",
            ),
            # Who / when
            sa.Column(
                "changed_by",
                sa.dialects.postgresql.UUID(as_uuid=True),
                nullable=False,
                comment="UUID of the enterprise user who triggered this policy mutation",
            ),
            sa.Column(
                "changed_at",
                sa.DateTime(timezone=True),
                nullable=False,
                server_default=text("now()"),
                comment="Timezone-aware timestamp when the mutation was recorded; immutable once written",
            ),
            # Mutation type
            sa.Column(
                "action",
                sa.String(10),
                nullable=False,
                comment="Mutation type: 'create', 'update', or 'delete'",
            ),
            # Before / after snapshot
            sa.Column(
                "old_policy_type",
                sa.String(20),
                nullable=True,
                comment="policy_type before this change; NULL when action is 'create'",
            ),
            sa.Column(
                "new_policy_type",
                sa.String(20),
                nullable=True,
                comment="policy_type after this change; NULL when action is 'delete'",
            ),
            sa.Column(
                "old_auto_propagate",
                sa.Boolean,
                nullable=True,
                comment="is_auto_propagate before this change; NULL when action is 'create'",
            ),
            sa.Column(
                "new_auto_propagate",
                sa.Boolean,
                nullable=True,
                comment="is_auto_propagate after this change; NULL when action is 'delete'",
            ),
            # Optional context
            sa.Column(
                "change_reason",
                sa.Text,
                nullable=True,
                comment="Optional free-text rationale provided by the admin at change time",
            ),
            # Table-level constraint
            sa.CheckConstraint(
                "action IN ('create', 'update', 'delete')",
                name="ck_ent_cpa_action",
            ),
        )

        # Indexes
        op.create_index(
            "idx_ent_cpa_tenant_id",
            _AUDIT_TABLE,
            ["tenant_id"],
        )
        op.create_index(
            "idx_ent_cpa_org_id",
            _AUDIT_TABLE,
            ["org_id"],
        )
        op.create_index(
            "idx_ent_cpa_tenant_artifact",
            _AUDIT_TABLE,
            ["tenant_id", "artifact_id"],
        )
        op.create_index(
            "idx_ent_cpa_changed_at",
            _AUDIT_TABLE,
            ["tenant_id", "changed_at"],
        )
        # Note: no updated_at trigger on the audit table — rows are append-only
        # and immutable; there is no updated_at column to maintain.


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop enterprise_cascade_policy_audit and enterprise_cascade_policies tables."""
    if is_sqlite():
        log.info(
            "add_cascade_policy_tables downgrade: SQLite dialect; nothing to drop."
        )
        return

    if not is_postgresql():
        log.warning(
            "add_cascade_policy_tables downgrade: unknown dialect %r; skipping.",
            op.get_bind().dialect.name,
        )
        return

    bind = op.get_bind()

    # Drop audit table first (no FK to policy table, but logical ordering is
    # cleaner: audit references policy conceptually, so drop it first).
    if _table_exists(bind, _AUDIT_TABLE):
        log.info("add_cascade_policy_tables: dropping %s.", _AUDIT_TABLE)
        op.drop_index("idx_ent_cpa_changed_at", table_name=_AUDIT_TABLE)
        op.drop_index("idx_ent_cpa_tenant_artifact", table_name=_AUDIT_TABLE)
        op.drop_index("idx_ent_cpa_org_id", table_name=_AUDIT_TABLE)
        op.drop_index("idx_ent_cpa_tenant_id", table_name=_AUDIT_TABLE)
        op.drop_table(_AUDIT_TABLE)
    else:
        log.info(
            "add_cascade_policy_tables: %s does not exist; skipping drop.",
            _AUDIT_TABLE,
        )

    # Drop policy table (FK children — artifacts, teams, settings — are not
    # dropped; only this table is removed).
    if _table_exists(bind, _POLICY_TABLE):
        log.info("add_cascade_policy_tables: dropping %s.", _POLICY_TABLE)
        drop_updated_at_trigger(_POLICY_TABLE)
        op.drop_index("idx_ent_cp_tenant_team", table_name=_POLICY_TABLE)
        op.drop_index("idx_ent_cp_tenant_artifact", table_name=_POLICY_TABLE)
        op.drop_index("idx_ent_cp_org_id", table_name=_POLICY_TABLE)
        op.drop_index("idx_ent_cp_tenant_id", table_name=_POLICY_TABLE)
        op.drop_table(_POLICY_TABLE)
    else:
        log.info(
            "add_cascade_policy_tables: %s does not exist; skipping drop.",
            _POLICY_TABLE,
        )
