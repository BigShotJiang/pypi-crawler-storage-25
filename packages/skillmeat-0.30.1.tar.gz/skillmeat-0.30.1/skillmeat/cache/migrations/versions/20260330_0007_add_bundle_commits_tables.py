"""Add bundle_commits, bundle_commit_members, artifact_dependencies tables (DVCS-2.1).

Revision ID: 20260330_0007_add_bundle_commits_tables
Revises: 20260330_0006_backfill_artifact_blobs_from_payload
Create Date: 2026-03-30 00:07:00.000000+00:00

Background
----------
Introduces the BundleCommit schema described in the DVCS Atomic Versioning
SPIKE (docs/dev/architecture/spikes/dvcs-atomic-versioning/) and codified in
ADR-012.

Three new tables are created and one existing table is amended:

1. ``bundle_commits``
   Primary log of atomic composite snapshots.  Each row records a complete
   state of a composite artifact (Plugin, Bundle, ContextModule) at a point
   in time, identified by a deterministic ``bundle_hash`` over its member
   content hashes.

2. ``bundle_commit_members``
   Snapshot payload for each commit.  One row per member artifact per commit,
   recording the exact ``ArtifactVersion`` and content hash at commit time.
   ON DELETE RESTRICT on ``artifact_version_id`` prevents orphaned members.

3. ``artifact_dependencies``
   General-purpose DAG edge table for cross-tier dependency traversal.
   Supersedes ad-hoc JSON-column approaches for topological sort and reverse
   lookups.  Enforces uniqueness of (composite_artifact_id, parent_artifact_id,
   child_artifact_id) per edge.

4. ``artifact_collection_versions.composite_commit_id`` (FK amendment)
   Nullable FK pointing to the active ``BundleCommit`` for composite-type
   artifacts.  NULL for Tier 0 atoms.  Enables full reconstruction of
   collection state including which BundleCommit was active.

Dialect Strategy
----------------
Both SQLite and PostgreSQL are supported.  SQLite uses TEXT primary keys and
plain DATETIME columns.  PostgreSQL path is additive (ALTER TABLE ADD COLUMN +
CREATE INDEX CONCURRENTLY is NOT used here — standard CREATE INDEX for
simplicity; a follow-up migration can add CONCURRENTLY if needed).

All three new tables are additive — no existing tables are modified except
``artifact_collection_versions`` where a single nullable column is added via
``op.batch_alter_table`` for SQLite compatibility.

Indexes
-------
All indexes use non-unique names prefixed with ``idx_bc_``, ``idx_bcm_``,
``idx_ad_``, and ``idx_acv_`` to match the project naming convention.

Downgrade
---------
``downgrade()`` drops in strict dependency order:
1. Drop ``composite_commit_id`` column from ``artifact_collection_versions``
2. Drop ``artifact_dependencies``
3. Drop ``bundle_commit_members``
4. Drop ``bundle_commits``
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

from skillmeat.cache.migrations.dialect_helpers import is_sqlite, is_postgresql

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "20260330_0007_add_bundle_commits_tables"
down_revision: Union[str, None] = "20260330_0006_backfill_artifact_blobs_from_payload"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Table/column name constants
# ---------------------------------------------------------------------------

_BC_TABLE = "bundle_commits"
_BCM_TABLE = "bundle_commit_members"
_AD_TABLE = "artifact_dependencies"
_ACV_TABLE = "artifact_collection_versions"
_ACV_NEW_COL = "composite_commit_id"
_ACV_NEW_IDX = "idx_acv_composite_commit"

# change_origin valid values for CHECK constraint
_CHANGE_ORIGIN_VALUES = "('manual', 'sync', 'deploy', 'capture', 'rollback')"
_CHANGE_ORIGIN_CONSTRAINT = "ck_bundle_commits_change_origin"

# artifact_dependencies.dependency_type valid values
_DEP_TYPE_VALUES = "('composition', 'reference', 'build')"
_DEP_TYPE_CONSTRAINT = "ck_artifact_dependencies_dependency_type"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _table_exists_sqlite(bind: sa.engine.Connection, table: str) -> bool:
    result = bind.execute(
        text("SELECT 1 FROM sqlite_master WHERE type='table' AND name=:t"),
        {"t": table},
    )
    return result.fetchone() is not None


def _column_exists_sqlite(bind: sa.engine.Connection, table: str, column: str) -> bool:
    result = bind.execute(text(f"PRAGMA table_info({table})"))
    return any(row[1] == column for row in result.fetchall())


def _index_exists_sqlite(bind: sa.engine.Connection, index: str) -> bool:
    result = bind.execute(
        text("SELECT 1 FROM sqlite_master WHERE type='index' AND name=:i"),
        {"i": index},
    )
    return result.fetchone() is not None


def _table_exists_pg(bind: sa.engine.Connection, table: str) -> bool:
    result = bind.execute(
        text(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_name = :t AND table_schema = 'public'"
        ),
        {"t": table},
    )
    return result.fetchone() is not None


def _column_exists_pg(bind: sa.engine.Connection, table: str, column: str) -> bool:
    result = bind.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = :t AND column_name = :c"
        ),
        {"t": table, "c": column},
    )
    return result.fetchone() is not None


def _index_exists_pg(bind: sa.engine.Connection, index: str) -> bool:
    result = bind.execute(
        text("SELECT 1 FROM pg_indexes WHERE indexname = :i"),
        {"i": index},
    )
    return result.fetchone() is not None


def _constraint_exists_pg(
    bind: sa.engine.Connection, constraint: str, table: str
) -> bool:
    result = bind.execute(
        text(
            "SELECT 1 FROM pg_constraint c "
            "JOIN pg_class t ON t.oid = c.conrelid "
            "WHERE c.conname = :cname AND t.relname = :tname"
        ),
        {"cname": constraint, "tname": table},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Create bundle_commits, bundle_commit_members, artifact_dependencies,
    and add composite_commit_id to artifact_collection_versions."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_bundle_commits_tables upgrade: SQLite dialect path.")
        _upgrade_sqlite(bind)
    elif is_postgresql():
        log.info("add_bundle_commits_tables upgrade: PostgreSQL dialect path.")
        _upgrade_postgresql(bind)
    else:
        log.warning(
            "add_bundle_commits_tables upgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


# ---------------------------------------------------------------------------
# SQLite upgrade
# ---------------------------------------------------------------------------


def _upgrade_sqlite(bind: sa.engine.Connection) -> None:
    # 1. bundle_commits
    if not _table_exists_sqlite(bind, _BC_TABLE):
        op.create_table(
            _BC_TABLE,
            sa.Column("id", sa.String(), nullable=False, primary_key=True),
            sa.Column("composite_artifact_id", sa.String(), nullable=False),
            sa.Column("composite_type", sa.String(), nullable=False),
            sa.Column("bundle_hash", sa.String(), nullable=False),
            sa.Column("parent_id", sa.String(), nullable=True),
            sa.Column("sequence_number", sa.Integer(), nullable=False),
            sa.Column(
                "change_origin",
                sa.String(),
                nullable=False,
                comment="Enum: manual, sync, deploy, capture, rollback",
            ),
            sa.Column("created_at", sa.DateTime(), nullable=False),
            sa.Column("created_by", sa.String(), nullable=True),
            sa.Column("message", sa.Text(), nullable=True),
            sa.Column("is_rollback", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("rolled_back_to", sa.String(), nullable=True),
            # FKs
            sa.ForeignKeyConstraint(
                ["composite_artifact_id"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["parent_id"], ["bundle_commits.id"], ondelete="SET NULL"
            ),
            sa.ForeignKeyConstraint(
                ["rolled_back_to"], ["bundle_commits.id"], ondelete="SET NULL"
            ),
            # Constraints
            sa.UniqueConstraint(
                "composite_artifact_id",
                "sequence_number",
                name="uq_bc_composite_sequence",
            ),
            sa.CheckConstraint(
                f"change_origin IN {_CHANGE_ORIGIN_VALUES}",
                name=_CHANGE_ORIGIN_CONSTRAINT,
            ),
        )
        # Indexes
        op.create_index("idx_bc_composite_id", _BC_TABLE, ["composite_artifact_id"])
        op.create_index("idx_bc_parent_id", _BC_TABLE, ["parent_id"])
        op.create_index(
            "idx_bc_composite_hash", _BC_TABLE, ["composite_artifact_id", "bundle_hash"]
        )
        log.info("add_bundle_commits_tables (SQLite): created %s.", _BC_TABLE)

    # 2. bundle_commit_members
    if not _table_exists_sqlite(bind, _BCM_TABLE):
        op.create_table(
            _BCM_TABLE,
            sa.Column("bundle_commit_id", sa.String(), nullable=False),
            sa.Column("artifact_id", sa.String(), nullable=False),
            sa.Column("artifact_uuid", sa.String(), nullable=False),
            sa.Column("artifact_version_id", sa.String(), nullable=False),
            sa.Column("content_hash", sa.String(), nullable=False),
            # FKs
            sa.ForeignKeyConstraint(
                ["bundle_commit_id"], ["bundle_commits.id"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["artifact_uuid"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["artifact_version_id"],
                ["artifact_versions.id"],
                ondelete="RESTRICT",
                name="fk_bcm_artifact_version_id",
            ),
            # Composite PK
            sa.PrimaryKeyConstraint("bundle_commit_id", "artifact_uuid"),
        )
        # Indexes
        op.create_index("idx_bcm_artifact_uuid", _BCM_TABLE, ["artifact_uuid"])
        op.create_index("idx_bcm_version_id", _BCM_TABLE, ["artifact_version_id"])
        log.info("add_bundle_commits_tables (SQLite): created %s.", _BCM_TABLE)

    # 3. artifact_dependencies
    if not _table_exists_sqlite(bind, _AD_TABLE):
        op.create_table(
            _AD_TABLE,
            sa.Column("id", sa.String(), nullable=False, primary_key=True),
            sa.Column("composite_artifact_id", sa.String(), nullable=False),
            sa.Column("parent_artifact_id", sa.String(), nullable=False),
            sa.Column("child_artifact_id", sa.String(), nullable=False),
            sa.Column(
                "dependency_type",
                sa.String(),
                nullable=False,
                comment="Enum: composition, reference, build",
            ),
            sa.Column("ordering", sa.Integer(), nullable=True),
            sa.Column("created_at", sa.DateTime(), nullable=False),
            # FKs
            sa.ForeignKeyConstraint(
                ["composite_artifact_id"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["parent_artifact_id"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["child_artifact_id"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            # Constraints
            sa.UniqueConstraint(
                "composite_artifact_id",
                "parent_artifact_id",
                "child_artifact_id",
                name="uq_ad_composite_parent_child",
            ),
            sa.CheckConstraint(
                f"dependency_type IN {_DEP_TYPE_VALUES}",
                name=_DEP_TYPE_CONSTRAINT,
            ),
        )
        # Indexes
        op.create_index("idx_ad_composite_id", _AD_TABLE, ["composite_artifact_id"])
        op.create_index("idx_ad_parent_id", _AD_TABLE, ["parent_artifact_id"])
        op.create_index("idx_ad_child_id", _AD_TABLE, ["child_artifact_id"])
        log.info("add_bundle_commits_tables (SQLite): created %s.", _AD_TABLE)

    # 4. artifact_collection_versions.composite_commit_id
    #
    # Use plain op.add_column() instead of batch_alter_table.  The column is
    # nullable, so ALTER TABLE ADD COLUMN works natively on SQLite.
    # batch_alter_table triggers a table recreation which fails when
    # PRAGMA foreign_keys=ON and other tables hold FK references.
    #
    # Note: SQLite ALTER TABLE ADD COLUMN does not support inline FK
    # constraints, so we add the column without the FK.  The FK is
    # enforced at the application/ORM layer.  PostgreSQL path adds the
    # proper FK constraint.
    if not _column_exists_sqlite(bind, _ACV_TABLE, _ACV_NEW_COL):
        op.add_column(
            _ACV_TABLE,
            sa.Column(
                _ACV_NEW_COL,
                sa.String(),
                nullable=True,
                comment=(
                    "FK to bundle_commits.id — active BundleCommit for composite "
                    "artifacts; NULL for Tier 0 atoms."
                ),
            ),
        )
        if not _index_exists_sqlite(bind, _ACV_NEW_IDX):
            op.create_index(_ACV_NEW_IDX, _ACV_TABLE, [_ACV_NEW_COL])
        log.info(
            "add_bundle_commits_tables (SQLite): added %s.%s.",
            _ACV_TABLE,
            _ACV_NEW_COL,
        )


# ---------------------------------------------------------------------------
# PostgreSQL upgrade
# ---------------------------------------------------------------------------


def _upgrade_postgresql(bind: sa.engine.Connection) -> None:
    from sqlalchemy.dialects import postgresql

    # 1. bundle_commits
    if not _table_exists_pg(bind, _BC_TABLE):
        op.create_table(
            _BC_TABLE,
            sa.Column("id", sa.String(), nullable=False, primary_key=True),
            sa.Column("composite_artifact_id", sa.String(), nullable=False),
            sa.Column("composite_type", sa.String(), nullable=False),
            sa.Column("bundle_hash", sa.String(), nullable=False),
            sa.Column("parent_id", sa.String(), nullable=True),
            sa.Column("sequence_number", sa.Integer(), nullable=False),
            sa.Column(
                "change_origin",
                sa.String(),
                nullable=False,
                comment="Enum: manual, sync, deploy, capture, rollback",
            ),
            sa.Column(
                "created_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("NOW()"),
            ),
            sa.Column("created_by", sa.String(), nullable=True),
            sa.Column("message", sa.Text(), nullable=True),
            sa.Column(
                "is_rollback",
                sa.Integer(),
                nullable=False,
                server_default="0",
            ),
            sa.Column("rolled_back_to", sa.String(), nullable=True),
            # FKs
            sa.ForeignKeyConstraint(
                ["composite_artifact_id"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["parent_id"], ["bundle_commits.id"], ondelete="SET NULL"
            ),
            sa.ForeignKeyConstraint(
                ["rolled_back_to"], ["bundle_commits.id"], ondelete="SET NULL"
            ),
            # Constraints
            sa.UniqueConstraint(
                "composite_artifact_id",
                "sequence_number",
                name="uq_bc_composite_sequence",
            ),
            sa.CheckConstraint(
                f"change_origin IN {_CHANGE_ORIGIN_VALUES}",
                name=_CHANGE_ORIGIN_CONSTRAINT,
            ),
        )
        op.create_index("idx_bc_composite_id", _BC_TABLE, ["composite_artifact_id"])
        op.create_index("idx_bc_parent_id", _BC_TABLE, ["parent_id"])
        op.create_index(
            "idx_bc_composite_hash", _BC_TABLE, ["composite_artifact_id", "bundle_hash"]
        )
        log.info("add_bundle_commits_tables (PG): created %s.", _BC_TABLE)

    # 2. bundle_commit_members
    if not _table_exists_pg(bind, _BCM_TABLE):
        op.create_table(
            _BCM_TABLE,
            sa.Column("bundle_commit_id", sa.String(), nullable=False),
            sa.Column("artifact_id", sa.String(), nullable=False),
            sa.Column("artifact_uuid", sa.String(), nullable=False),
            sa.Column("artifact_version_id", postgresql.UUID(as_uuid=True), nullable=False),
            sa.Column("content_hash", sa.String(), nullable=False),
            # FKs
            sa.ForeignKeyConstraint(
                ["bundle_commit_id"], ["bundle_commits.id"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["artifact_uuid"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["artifact_version_id"],
                ["artifact_versions.id"],
                ondelete="RESTRICT",
                name="fk_bcm_artifact_version_id",
            ),
            # Composite PK
            sa.PrimaryKeyConstraint("bundle_commit_id", "artifact_uuid"),
        )
        op.create_index("idx_bcm_artifact_uuid", _BCM_TABLE, ["artifact_uuid"])
        op.create_index("idx_bcm_version_id", _BCM_TABLE, ["artifact_version_id"])
        log.info("add_bundle_commits_tables (PG): created %s.", _BCM_TABLE)

    # 3. artifact_dependencies
    if not _table_exists_pg(bind, _AD_TABLE):
        op.create_table(
            _AD_TABLE,
            sa.Column("id", sa.String(), nullable=False, primary_key=True),
            sa.Column("composite_artifact_id", sa.String(), nullable=False),
            sa.Column("parent_artifact_id", sa.String(), nullable=False),
            sa.Column("child_artifact_id", sa.String(), nullable=False),
            sa.Column(
                "dependency_type",
                sa.String(),
                nullable=False,
                comment="Enum: composition, reference, build",
            ),
            sa.Column("ordering", sa.Integer(), nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("NOW()"),
            ),
            # FKs
            sa.ForeignKeyConstraint(
                ["composite_artifact_id"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["parent_artifact_id"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            sa.ForeignKeyConstraint(
                ["child_artifact_id"], ["artifacts.uuid"], ondelete="CASCADE"
            ),
            # Constraints
            sa.UniqueConstraint(
                "composite_artifact_id",
                "parent_artifact_id",
                "child_artifact_id",
                name="uq_ad_composite_parent_child",
            ),
            sa.CheckConstraint(
                f"dependency_type IN {_DEP_TYPE_VALUES}",
                name=_DEP_TYPE_CONSTRAINT,
            ),
        )
        op.create_index("idx_ad_composite_id", _AD_TABLE, ["composite_artifact_id"])
        op.create_index("idx_ad_parent_id", _AD_TABLE, ["parent_artifact_id"])
        op.create_index("idx_ad_child_id", _AD_TABLE, ["child_artifact_id"])
        log.info("add_bundle_commits_tables (PG): created %s.", _AD_TABLE)

    # 4. artifact_collection_versions.composite_commit_id
    if not _column_exists_pg(bind, _ACV_TABLE, _ACV_NEW_COL):
        op.add_column(
            _ACV_TABLE,
            sa.Column(
                _ACV_NEW_COL,
                sa.String(),
                nullable=True,
                comment=(
                    "FK to bundle_commits.id — active BundleCommit for composite "
                    "artifacts; NULL for Tier 0 atoms."
                ),
            ),
        )
        op.create_foreign_key(
            "fk_acv_composite_commit_id",
            _ACV_TABLE,
            _BC_TABLE,
            [_ACV_NEW_COL],
            ["id"],
            ondelete="SET NULL",
        )
        if not _index_exists_pg(bind, _ACV_NEW_IDX):
            op.create_index(_ACV_NEW_IDX, _ACV_TABLE, [_ACV_NEW_COL])
        log.info(
            "add_bundle_commits_tables (PG): added %s.%s.",
            _ACV_TABLE,
            _ACV_NEW_COL,
        )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Remove bundle_commits tables and composite_commit_id FK column."""
    bind = op.get_bind()

    if is_sqlite():
        log.info("add_bundle_commits_tables downgrade: SQLite dialect path.")
        _downgrade_sqlite(bind)
    elif is_postgresql():
        log.info("add_bundle_commits_tables downgrade: PostgreSQL dialect path.")
        _downgrade_postgresql(bind)
    else:
        log.warning(
            "add_bundle_commits_tables downgrade: unknown dialect %r; skipping.",
            bind.dialect.name,
        )


# ---------------------------------------------------------------------------
# SQLite downgrade
# ---------------------------------------------------------------------------


def _downgrade_sqlite(bind: sa.engine.Connection) -> None:
    # 1. Drop composite_commit_id from artifact_collection_versions
    # Disable FK checks — batch_alter_table recreates the table and the
    # INSERT copy fails when foreign_keys=ON and other tables reference it.
    if _column_exists_sqlite(bind, _ACV_TABLE, _ACV_NEW_COL):
        if _index_exists_sqlite(bind, _ACV_NEW_IDX):
            op.drop_index(_ACV_NEW_IDX, table_name=_ACV_TABLE)
        bind.execute(sa.text("PRAGMA foreign_keys = OFF"))
        try:
            with op.batch_alter_table(_ACV_TABLE) as batch_op:
                batch_op.drop_column(_ACV_NEW_COL)
        finally:
            bind.execute(sa.text("PRAGMA foreign_keys = ON"))
        log.info(
            "add_bundle_commits_tables (SQLite): dropped %s.%s.",
            _ACV_TABLE,
            _ACV_NEW_COL,
        )

    # 2. Drop artifact_dependencies
    if _table_exists_sqlite(bind, _AD_TABLE):
        op.drop_table(_AD_TABLE)
        log.info("add_bundle_commits_tables (SQLite): dropped %s.", _AD_TABLE)

    # 3. Drop bundle_commit_members (references bundle_commits)
    if _table_exists_sqlite(bind, _BCM_TABLE):
        op.drop_table(_BCM_TABLE)
        log.info("add_bundle_commits_tables (SQLite): dropped %s.", _BCM_TABLE)

    # 4. Drop bundle_commits (self-referential; drop last)
    if _table_exists_sqlite(bind, _BC_TABLE):
        op.drop_table(_BC_TABLE)
        log.info("add_bundle_commits_tables (SQLite): dropped %s.", _BC_TABLE)


# ---------------------------------------------------------------------------
# PostgreSQL downgrade
# ---------------------------------------------------------------------------


def _downgrade_postgresql(bind: sa.engine.Connection) -> None:
    # 1. Drop composite_commit_id from artifact_collection_versions
    if _column_exists_pg(bind, _ACV_TABLE, _ACV_NEW_COL):
        if _index_exists_pg(bind, _ACV_NEW_IDX):
            op.drop_index(_ACV_NEW_IDX, table_name=_ACV_TABLE)
        if _constraint_exists_pg(bind, "fk_acv_composite_commit_id", _ACV_TABLE):
            op.drop_constraint(
                "fk_acv_composite_commit_id", _ACV_TABLE, type_="foreignkey"
            )
        op.drop_column(_ACV_TABLE, _ACV_NEW_COL)
        log.info(
            "add_bundle_commits_tables (PG): dropped %s.%s.",
            _ACV_TABLE,
            _ACV_NEW_COL,
        )

    # 2. Drop artifact_dependencies
    if _table_exists_pg(bind, _AD_TABLE):
        op.drop_table(_AD_TABLE)
        log.info("add_bundle_commits_tables (PG): dropped %s.", _AD_TABLE)

    # 3. Drop bundle_commit_members (references bundle_commits)
    if _table_exists_pg(bind, _BCM_TABLE):
        op.drop_table(_BCM_TABLE)
        log.info("add_bundle_commits_tables (PG): dropped %s.", _BCM_TABLE)

    # 4. Drop bundle_commits (self-referential; drop last)
    if _table_exists_pg(bind, _BC_TABLE):
        op.drop_table(_BC_TABLE)
        log.info("add_bundle_commits_tables (PG): dropped %s.", _BC_TABLE)
