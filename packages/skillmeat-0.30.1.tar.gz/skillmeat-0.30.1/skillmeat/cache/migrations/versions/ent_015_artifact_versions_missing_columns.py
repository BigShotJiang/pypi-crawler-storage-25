"""Add missing columns to enterprise artifact_versions table.

Revision ID: ent_015_artifact_versions_missing_columns
Revises: ent_014_enterprise_content_payload_column
Create Date: 2026-04-01 00:00:00.000000+00:00

Background
----------
Four columns defined on the ``EnterpriseArtifactVersion`` ORM model were absent
from the ``artifact_versions`` table on existing PostgreSQL deployments, causing
``UndefinedColumn`` errors at query time:

    - parent_hash     VARCHAR(64)  NULL  — SHA-256 of the predecessor version
    - change_origin   VARCHAR(50)  NULL  — source that produced this version
    - version_lineage JSONB        NULL  — ordered ancestor hash list
    - metadata        JSONB        NULL  — arbitrary structured version metadata

These columns were present in the ``ent_001_enterprise_schema`` CREATE TABLE
statement but were omitted from the live table on databases that ran ent_001
before the columns were added to that statement.  This migration back-fills the
schema gap for all such deployments.

Schema change
-------------
    Table:  artifact_versions  (enterprise PostgreSQL)

    New columns (all nullable, no default):
        parent_hash     VARCHAR(64)  NULL
        change_origin   VARCHAR(50)  NULL
        version_lineage JSONB        NULL
        metadata        JSONB        NULL

Design notes
------------
- All four columns are nullable with no server default so that existing rows
  remain valid after the ALTER; the application reads NULL as "not set".
- ``IF NOT EXISTS`` semantics are achieved via the ``_column_exists`` guard so
  that re-running the upgrade on a database that already has these columns is
  a safe no-op.
- This migration is PostgreSQL-only.  It is a no-op on any other dialect.

Downgrade
---------
Drop all four columns from ``artifact_versions``.  No data loss beyond the
columns themselves — all other version data is preserved.
"""

from __future__ import annotations

import logging
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "ent_015_artifact_versions_missing_columns"
down_revision: Union[str, Sequence[str], None] = (
    "ent_014_enterprise_content_payload_column"
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# --- dialect declaration ----------------------------------------------------
dialect_compatibility: str = "postgresql_only"
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_VERSIONS_TABLE = "artifact_versions"

_NEW_COLUMNS: list[tuple[str, sa.types.TypeEngine]] = [
    ("parent_hash", sa.String(64)),
    ("change_origin", sa.String(50)),
    ("version_lineage", postgresql.JSONB()),
    ("metadata", postgresql.JSONB()),
]


# ---------------------------------------------------------------------------
# Dialect guard
# ---------------------------------------------------------------------------


def _is_postgresql() -> bool:
    """Return True when the migration is running against a PostgreSQL database."""
    return op.get_bind().dialect.name == "postgresql"


# ---------------------------------------------------------------------------
# Idempotency helpers
# ---------------------------------------------------------------------------


def _column_exists(bind: sa.engine.Connection, table: str, column: str) -> bool:
    """Return True if *column* already exists on *table* (PostgreSQL)."""
    result = bind.execute(
        text("""
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name   = :tname
              AND column_name  = :cname
            """),
        {"tname": table, "cname": column},
    )
    return result.fetchone() is not None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """Add parent_hash, change_origin, version_lineage, metadata to artifact_versions."""
    if not _is_postgresql():
        log.info(
            "ent_015_artifact_versions_missing_columns: non-PostgreSQL dialect detected; "
            "skipping enterprise-only migration."
        )
        return

    log.info(
        "ent_015_artifact_versions_missing_columns upgrade: running PostgreSQL path."
    )
    _upgrade_missing_columns()


def _upgrade_missing_columns() -> None:
    """Add each missing column to artifact_versions if not already present."""
    bind = op.get_bind()

    for col_name, col_type in _NEW_COLUMNS:
        if _column_exists(bind, _VERSIONS_TABLE, col_name):
            log.info(
                "ent_015: column %s.%s already exists; skipping ADD COLUMN.",
                _VERSIONS_TABLE,
                col_name,
            )
            continue

        op.add_column(
            _VERSIONS_TABLE,
            sa.Column(col_name, col_type, nullable=True),
        )
        log.info(
            "ent_015: added column %s to %s.",
            col_name,
            _VERSIONS_TABLE,
        )


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """Drop parent_hash, change_origin, version_lineage, metadata from artifact_versions."""
    if not _is_postgresql():
        log.info(
            "ent_015_artifact_versions_missing_columns downgrade: "
            "non-PostgreSQL dialect detected; skipping."
        )
        return

    log.info(
        "ent_015_artifact_versions_missing_columns downgrade: running PostgreSQL path."
    )
    _downgrade_missing_columns()


def _downgrade_missing_columns() -> None:
    """Drop each added column from artifact_versions if it exists."""
    bind = op.get_bind()

    # Drop in reverse order of addition for cleanliness
    for col_name, _ in reversed(_NEW_COLUMNS):
        if not _column_exists(bind, _VERSIONS_TABLE, col_name):
            log.info(
                "ent_015: column %s.%s does not exist; skipping DROP COLUMN.",
                _VERSIONS_TABLE,
                col_name,
            )
            continue

        op.drop_column(_VERSIONS_TABLE, col_name)
        log.info(
            "ent_015: dropped column %s from %s.",
            col_name,
            _VERSIONS_TABLE,
        )
