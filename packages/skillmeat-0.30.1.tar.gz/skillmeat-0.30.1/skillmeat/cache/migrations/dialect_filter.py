"""Dialect-based migration filtering helpers for Alembic env.py.

This module is intentionally importable *without* an active Alembic
``EnvironmentContext`` so that the logic can be unit-tested in isolation
(importing ``env.py`` directly triggers Alembic context setup which fails
outside a real ``alembic upgrade`` run).

The functions here are imported by ``env.py`` and wired into Alembic's
migration step function to provide centralized dialect-based filtering.

Layer 1 of two-layer defense
-----------------------------
Each migration module may declare a module-level ``dialect_compatibility``
string constant (convention defined in ``dialect_helpers.py``).  The filter
factory here reads that constant and skips migrations that are incompatible
with the active database dialect — Layer 1.

Layer 2 is the top-of-function dialect guard inside each migration
(``if not is_postgresql(): return``).

See ``dialect_helpers.py`` for the ``dialect_compatibility`` convention docs.
"""

from __future__ import annotations

import importlib.util
import logging
from pathlib import Path
from typing import Any, Callable, Optional

from skillmeat.cache.migrations.dialect_helpers import is_compatible

logger = logging.getLogger(__name__)


def _get_dialect_from_url(db_url: Optional[str]) -> str:
    """Infer the SQLAlchemy dialect name from a database URL string.

    Returns ``"sqlite"`` for SQLite URLs, ``"postgresql"`` for PostgreSQL
    URLs, and ``"unknown"`` for anything else.  ``"unknown"`` is treated as
    compatible with all migrations by ``is_compatible`` so it never causes
    silent skips.

    Args:
        db_url: SQLAlchemy-style database URL string, e.g.
            ``"sqlite:///path/to/db"`` or ``"postgresql://user@host/db"``.
            May be ``None`` or empty.

    Returns:
        ``"sqlite"``, ``"postgresql"``, or ``"unknown"``.

    Examples::

        >>> _get_dialect_from_url("sqlite:///:memory:")
        'sqlite'
        >>> _get_dialect_from_url("postgresql://user:pass@localhost/db")
        'postgresql'
        >>> _get_dialect_from_url(None)
        'unknown'
    """
    if not db_url:
        return "unknown"
    url_lower = db_url.lower()
    if url_lower.startswith("sqlite"):
        return "sqlite"
    if url_lower.startswith("postgresql") or url_lower.startswith("postgres"):
        return "postgresql"
    return "unknown"


def _load_revision_dialect_compatibility(revision_path: str) -> str:
    """Import a migration module from its file path and return its declared
    ``dialect_compatibility``.  Defaults to ``"all"`` if the attribute is absent
    or if the module cannot be imported (e.g. import-time errors in an
    incompatible migration).

    The safe default ``"all"`` ensures that any module that fails to import is
    *not* silently skipped — it will attempt to run and surface the real error.

    Args:
        revision_path: Absolute or relative path to the migration ``.py`` file.

    Returns:
        The ``dialect_compatibility`` string from the module, or ``"all"``.
    """
    try:
        spec = importlib.util.spec_from_file_location(
            f"_rev_{Path(revision_path).stem}", revision_path
        )
        if spec is None or spec.loader is None:
            return "all"
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)  # type: ignore[union-attr]
        return str(getattr(module, "dialect_compatibility", "all"))
    except Exception:
        # Any import-time error (e.g. missing dependency, syntax error) →
        # default to "all" and let the migration attempt to run, surfacing
        # the real error rather than silently skipping.
        return "all"


def _make_dialect_filter_fn(
    current_dialect: str,
    script_dir_path: str,
    original_fn: Callable,
) -> Callable:
    """Return a wrapped Alembic migration plan function that neutralises
    revisions whose ``dialect_compatibility`` does not match *current_dialect*.

    Alembic's ``EnvironmentContext`` calls ``fn(rev, context)`` **once** per
    run to build the migration plan.  The argument *rev* is the *current*
    revision of the database (not a script to execute); *original_fn* returns
    a list of ``RevisionStep`` objects describing which scripts to run and
    in what order.

    We must NOT filter the input *rev*: doing so changes the DAG traversal's
    starting point and can truncate the plan (this was the original
    regression — see PR #168 follow-up).  Instead we let *original_fn* compute
    the full plan and then neutralise any step whose target revision is
    incompatible with the active dialect by replacing that step's migration
    callable with a no-op.  Alembic still advances ``alembic_version`` as it
    walks the plan, so the revision chain stays consistent while no
    dialect-incompatible DDL is ever executed.

    This is Layer 1 of two-layer defense.  Layer 2 is the top-of-function
    ``if not is_postgresql(): return`` guard inside each migration — kept in
    place so manual ``alembic upgrade`` runs are also safe.

    Args:
        current_dialect: SQLAlchemy dialect name, e.g. ``"sqlite"`` or
            ``"postgresql"``.
        script_dir_path: Filesystem path to the Alembic ``versions/``
            directory used to resolve revision file paths.
        original_fn: The original Alembic plan callable set by
            ``alembic.command.upgrade`` on the ``EnvironmentContext``.

    Returns:
        A wrapped callable with the same signature as *original_fn*.
    """
    versions_dir = Path(script_dir_path)

    def _step_target_revision(step: Any) -> Optional[str]:
        """Best-effort extraction of the target revision ID from a
        ``RevisionStep``.  Alembic's internal structure varies slightly
        between versions, so we try a few attribute paths."""
        rev_obj = getattr(step, "revision", None)
        if rev_obj is not None:
            rid = getattr(rev_obj, "revision", None)
            if isinstance(rid, str):
                return rid
        # Fallback: some RevisionStep variants expose `.from_revisions_no_deps`
        # / `.to_revisions_no_deps`.  Use the destination tuple if present.
        to_revs = getattr(step, "to_revisions", None)
        if isinstance(to_revs, tuple) and to_revs:
            return to_revs[0]
        return None

    def _revision_compat(revision_id: str) -> str:
        candidate_files = list(versions_dir.glob(f"{revision_id}*.py"))
        if not candidate_files:
            candidate_files = list(versions_dir.glob(f"*{revision_id}*.py"))
        if not candidate_files:
            return "all"
        return _load_revision_dialect_compatibility(str(candidate_files[0]))

    def _neutralise_step(step: Any, revision_id: str) -> None:
        """Replace the step's migration callable with a no-op so Alembic
        advances ``alembic_version`` without executing DDL."""

        def _noop(*_args: Any, **_kwargs: Any) -> None:
            return None

        # RevisionStep stores the callable on its wrapped Script's module.
        # The attribute Alembic invokes is ``step.migration_fn``; for
        # upgrades this resolves to ``script.module.upgrade`` and for
        # downgrades ``script.module.downgrade``.  Patching
        # ``migration_fn`` directly is the least-invasive override.
        try:
            step.migration_fn = _noop  # type: ignore[attr-defined]
        except Exception:
            # Fallback: patch the underlying module functions.
            rev_obj = getattr(step, "revision", None)
            module = getattr(rev_obj, "module", None)
            if module is not None:
                try:
                    module.upgrade = _noop  # type: ignore[attr-defined]
                    module.downgrade = _noop  # type: ignore[attr-defined]
                except Exception:
                    logger.warning(
                        "Unable to neutralise migration %s — dialect guard "
                        "in the migration itself must handle the skip.",
                        revision_id,
                    )

    def _filtered_fn(rev: Any, context_: Any) -> Any:
        # Pass *rev* through unchanged — it is the current DB revision and
        # must not be mutated.  Let Alembic compute the full plan first.
        plan = original_fn(rev, context_)

        try:
            steps = list(plan)
        except TypeError:
            # Not iterable (shouldn't happen in practice) — return as-is.
            return plan

        for step in steps:
            rid = _step_target_revision(step)
            if rid is None:
                continue
            compat = _revision_compat(rid)
            if not is_compatible(compat, current_dialect):
                logger.info(
                    "Neutralising migration %s (dialect_compatibility=%r, "
                    "current dialect=%r) — version stamp will advance but "
                    "no DDL will execute.",
                    rid,
                    compat,
                    current_dialect,
                )
                _neutralise_step(step, rid)

        return steps

    return _filtered_fn


__all__ = [
    "_get_dialect_from_url",
    "_load_revision_dialect_compatibility",
    "_make_dialect_filter_fn",
]
