"""Custom SQLAlchemy column type decorators for SkillMeat cache layer.

This module provides transparent encryption/decryption of column values at the
persistence boundary, following the design decision in
``docs/dev/architecture/adrs/ADR-0001-encryption-at-persistence-boundary.md``.
"""

from __future__ import annotations

import base64
import logging
import os
import platform
from typing import Any, Optional

import sqlalchemy as sa
import sqlalchemy.types
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Key derivation helpers
# ---------------------------------------------------------------------------

_SALT = b"skillmeat-column-encryption-v1"
_PBKDF2_ITERATIONS = 100_000


def _derive_machine_key() -> bytes:
    """Derive a deterministic Fernet key from machine-specific data.

    Uses the same hostname + home-directory seed strategy as
    ``skillmeat.core.auth.storage.EncryptedFileStorage._get_encryption_key``
    so that tokens are recoverable across process restarts on the same machine.

    Returns:
        URL-safe base64-encoded 32-byte key suitable for ``Fernet``.
    """
    seed = f"{platform.node()}-{os.path.expanduser('~')}-skillmeat-column-enc"
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=_SALT,
        iterations=_PBKDF2_ITERATIONS,
    )
    raw_key = kdf.derive(seed.encode())
    return base64.urlsafe_b64encode(raw_key)


def _get_fernet() -> Fernet:
    """Return a ``Fernet`` instance using the configured encryption key.

    Key resolution order:
    1. ``SKILLMEAT_ENCRYPTION_KEY`` environment variable (raw Fernet key,
       URL-safe base64-encoded 32 bytes).
    2. Machine-derived key via PBKDF2 (deterministic per hostname).

    Returns:
        Configured ``Fernet`` cipher.
    """
    env_key = os.environ.get("SKILLMEAT_ENCRYPTION_KEY")
    if env_key:
        try:
            return Fernet(env_key.encode() if isinstance(env_key, str) else env_key)
        except Exception as exc:  # pragma: no cover
            log.warning(
                "SKILLMEAT_ENCRYPTION_KEY is set but invalid (%s); "
                "falling back to machine-derived key.",
                exc,
            )

    return Fernet(_derive_machine_key())


# ---------------------------------------------------------------------------
# EncryptedString TypeDecorator
# ---------------------------------------------------------------------------


class EncryptedString(sqlalchemy.types.TypeDecorator):
    """SQLAlchemy TypeDecorator that transparently encrypts/decrypts values.

    Column values are stored as Fernet-encrypted ciphertext (URL-safe base64
    string prefixed with the Fernet token marker).  At read time the ciphertext
    is decrypted back to the original plaintext string.

    Usage
    -----
    ::

        class GitCredential(Base):
            token_encrypted = Column(EncryptedString(), nullable=False)

    The column is backed by a ``TEXT`` (or ``VARCHAR``) database column; no
    schema changes are required beyond the initial ``ADD COLUMN``.

    Key management
    --------------
    Set ``SKILLMEAT_ENCRYPTION_KEY`` to a valid Fernet key for explicit key
    control (recommended in production).  When the variable is absent a
    machine-derived key is used (suitable for local / single-host deployments).

    Decryption failures (corrupted data, key rotation) are handled gracefully:
    ``None`` is returned and a warning is logged rather than raising an
    exception that would crash a read query.
    """

    impl = sa.Text
    cache_ok = True  # The TypeDecorator itself is stateless; Fernet is lazily created.

    # ------------------------------------------------------------------
    # Bind (Python → DB)
    # ------------------------------------------------------------------

    def process_bind_param(
        self,
        value: Optional[str],
        dialect: Any,
    ) -> Optional[str]:
        """Encrypt *value* before writing to the database.

        Args:
            value: Plaintext string, or ``None``.
            dialect: Active SQLAlchemy dialect (unused).

        Returns:
            URL-safe base64 Fernet token string, or ``None`` if *value* is
            ``None``.
        """
        if value is None:
            return None

        fernet = _get_fernet()
        ciphertext: bytes = fernet.encrypt(value.encode("utf-8"))
        return ciphertext.decode("ascii")

    # ------------------------------------------------------------------
    # Result (DB → Python)
    # ------------------------------------------------------------------

    def process_result_value(
        self,
        value: Optional[str],
        dialect: Any,
    ) -> Optional[str]:
        """Decrypt *value* after reading from the database.

        Args:
            value: Fernet token string from the database, or ``None``.
            dialect: Active SQLAlchemy dialect (unused).

        Returns:
            Plaintext string, or ``None`` if *value* is ``None`` or
            decryption fails (invalid token / key mismatch).
        """
        if value is None:
            return None

        fernet = _get_fernet()
        try:
            plaintext: bytes = fernet.decrypt(value.encode("ascii"))
            return plaintext.decode("utf-8")
        except InvalidToken:
            log.warning(
                "EncryptedString: decryption failed for stored value "
                "(InvalidToken — possible key rotation or data corruption). "
                "Returning None."
            )
            return None
        except Exception as exc:  # pragma: no cover
            log.warning(
                "EncryptedString: unexpected decryption error (%s). Returning None.",
                exc,
            )
            return None
