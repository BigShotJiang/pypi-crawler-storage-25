"""Click command group for scaffold template management.

Provides the ``skillmeat template`` subcommand tree:

    skillmeat template list
    skillmeat template create --bundle <bundle_id>
    skillmeat template configure --bundle <id> [--var <name:type>] [--skeleton <url>] [--platform <platform>]
    skillmeat template preview --bundle <bundle_id>
"""

from __future__ import annotations

import sys
from typing import List, NoReturn, Optional, Tuple

import click
import requests
from rich.console import Console
from rich.table import Table

from skillmeat.config import ConfigManager

console = Console(force_terminal=True, legacy_windows=False)

_config_mgr = ConfigManager()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _api_base() -> str:
    """Return the configured API base URL."""
    return _config_mgr.get("api.base_url", "http://localhost:8080")


def _connection_error_hint() -> str:
    return "Make sure the API server is running: skillmeat web dev --api-only"


def _handle_http_error(exc: requests.exceptions.HTTPError, operation: str) -> NoReturn:
    """Print a user-friendly error from an HTTPError and exit with code 1."""
    try:
        body = exc.response.json()
        detail = body.get("detail") or body.get("message") or str(exc)
    except Exception:
        detail = str(exc)
    console.print(f"[red]Error ({operation}): {detail}[/red]")
    sys.exit(1)


def _handle_connection_error(url: str) -> NoReturn:
    """Print a connection-refused error and exit with code 1."""
    console.print(f"[red]Error: Could not connect to API server at {url}[/red]")
    console.print(f"[yellow]{_connection_error_hint()}[/yellow]")
    sys.exit(1)


# ---------------------------------------------------------------------------
# template group
# ---------------------------------------------------------------------------


@click.group("template")
def template_group() -> None:
    """Manage scaffold templates for Backstage Software Templates.

    Scaffold templates link bundles to Backstage scaffolder configuration,
    enabling one-click project creation from curated artifact bundles.

    \b
    Examples:
      skillmeat template list
      skillmeat template create --bundle my-python-bundle
      skillmeat template configure --bundle my-python-bundle --skeleton https://github.com/org/skeletons
      skillmeat template preview --bundle my-python-bundle
    """


# ---------------------------------------------------------------------------
# list sub-command
# ---------------------------------------------------------------------------


@template_group.command("list")
def list_cmd() -> None:
    """List all scaffold templates.

    Displays a Rich table with name (bundle ID), bundle version at last
    generation, enabled status, variable count, and skeleton ref.

    \b
    Examples:
      skillmeat template list
    """
    api_base = _api_base()
    url = f"{api_base}/api/v1/templates/scaffold/"

    all_items: list = []
    data: dict = {}
    try:
        resp = requests.get(url, params={"page_size": 100}, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        all_items = data.get("items", [])
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "list templates")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    # Paginate if needed
    total = data.get("total", 0)
    page_size = data.get("page_size", 100)
    if total > page_size:
        pages = (total + page_size - 1) // page_size
        for page_num in range(2, pages + 1):
            try:
                r = requests.get(
                    url,
                    params={"page_size": page_size, "page": page_num},
                    timeout=30,
                )
                r.raise_for_status()
                all_items.extend(r.json().get("items", []))
            except Exception:
                break

    if not all_items:
        console.print("[dim]No scaffold templates found.[/dim]")
        return

    table = Table(
        title=f"Scaffold Templates ({len(all_items)})",
        show_header=True,
        header_style="bold",
        box=None,
    )
    table.add_column("Bundle ID", style="cyan")
    table.add_column("Bundle Version")
    table.add_column("Enabled", justify="center")
    table.add_column("Variables", justify="right")
    table.add_column("Skeleton Ref")

    for item in all_items:
        bundle_version = item.get("bundle_version_at_last_generation") or "-"
        enabled_str = (
            "[green]yes[/green]" if item.get("enabled", True) else "[red]no[/red]"
        )
        var_count = str(len(item.get("required_variables", [])))
        skeleton = item.get("skeleton_ref") or "-"
        table.add_row(
            item.get("bundle_id", ""),
            bundle_version,
            enabled_str,
            var_count,
            skeleton,
        )

    console.print(table)


# ---------------------------------------------------------------------------
# create sub-command
# ---------------------------------------------------------------------------


@template_group.command("create")
@click.option(
    "--bundle",
    "bundle_id",
    required=True,
    metavar="ID",
    help="ID of the bundle to create a scaffold template for.",
)
def create_cmd(bundle_id: str) -> None:
    """Create a new scaffold template for a bundle.

    Associates the given bundle with a default Backstage scaffolder
    configuration.  Use ``template configure`` to customise variables,
    skeleton ref, and platform.

    \b
    Examples:
      skillmeat template create --bundle my-python-bundle
    """
    api_base = _api_base()
    url = f"{api_base}/api/v1/templates/scaffold/"

    payload: dict = {"bundle_id": bundle_id}

    result: dict = {}
    try:
        resp = requests.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "create template")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    console.print(f"[green]Scaffold template created successfully.[/green]")
    info = Table(show_header=False, box=None, padding=(0, 1))
    info.add_column("Field", style="bold")
    info.add_column("Value")
    info.add_row("ID", result.get("id", ""))
    info.add_row("Bundle ID", result.get("bundle_id", ""))
    info.add_row("Enabled", "yes" if result.get("enabled", True) else "no")
    info.add_row("Variables", str(len(result.get("required_variables", []))))
    if result.get("skeleton_ref"):
        info.add_row("Skeleton Ref", result["skeleton_ref"])
    console.print(info)


# ---------------------------------------------------------------------------
# configure sub-command
# ---------------------------------------------------------------------------


@template_group.command("configure")
@click.option(
    "--bundle",
    "bundle_id",
    required=True,
    metavar="ID",
    help="ID of the bundle whose scaffold template should be updated.",
)
@click.option(
    "--var",
    "vars_",
    multiple=True,
    metavar="NAME:TYPE",
    help=(
        "Variable definition in NAME:TYPE format.  Repeatable.  "
        "TYPE must be a Backstage field type such as string, owner, or repoUrl."
    ),
)
@click.option(
    "--skeleton",
    "skeleton_ref",
    default=None,
    metavar="GIT-URL",
    help="Git URL or path to the Backstage skeleton directory.",
)
@click.option(
    "--platform",
    "platform",
    default=None,
    metavar="PLATFORM",
    help="Target platform tag for the generated template (e.g. claude_code, codex).",
)
def configure_cmd(
    bundle_id: str,
    vars_: Tuple[str, ...],
    skeleton_ref: Optional[str],
    platform: Optional[str],
) -> None:
    """Update the scaffold configuration for a bundle's template.

    Looks up the scaffold template by bundle ID and applies the provided
    changes.  All options are optional; only supplied values are modified.

    \b
    Examples:
      skillmeat template configure --bundle my-bundle --skeleton https://github.com/org/skeletons
      skillmeat template configure --bundle my-bundle --var name:string --var owner:owner
      skillmeat template configure --bundle my-bundle --platform claude_code
    """
    api_base = _api_base()

    # First, look up the template ID by bundle_id
    list_url = f"{api_base}/api/v1/templates/scaffold/"
    template_id: Optional[str] = None
    try:
        resp = requests.get(
            list_url,
            params={"bundle_id": bundle_id, "page_size": 10},
            timeout=30,
        )
        resp.raise_for_status()
        items = resp.json().get("items", [])
        for item in items:
            if item.get("bundle_id") == bundle_id:
                template_id = item["id"]
                break
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "find template")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    if not template_id:
        console.print(
            f"[red]Error: No scaffold template found for bundle '{bundle_id}'.[/red]"
        )
        console.print(
            f"[yellow]Hint: Create one first with: skillmeat template create --bundle {bundle_id}[/yellow]"
        )
        sys.exit(1)

    # Build the update payload (only include supplied fields)
    payload: dict = {}

    if vars_:
        variable_type_map: dict = {}
        required_variables: List[str] = []
        for var_spec in vars_:
            if ":" in var_spec:
                name, var_type = var_spec.split(":", 1)
            else:
                name, var_type = var_spec, "string"
            required_variables.append(name.strip())
            variable_type_map[name.strip()] = var_type.strip()
        payload["required_variables"] = required_variables
        payload["variable_type_map"] = variable_type_map

    if skeleton_ref is not None:
        payload["skeleton_ref"] = skeleton_ref

    if platform is not None:
        payload["backstage_type"] = platform

    if not payload:
        console.print("[yellow]No changes specified — nothing to update.[/yellow]")
        return

    update_url = f"{api_base}/api/v1/templates/scaffold/{template_id}"
    result: dict = {}
    try:
        resp = requests.put(
            update_url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "configure template")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    console.print(f"[green]Scaffold template updated successfully.[/green]")
    info = Table(show_header=False, box=None, padding=(0, 1))
    info.add_column("Field", style="bold")
    info.add_column("Value")
    info.add_row("ID", result.get("id", ""))
    info.add_row("Bundle ID", result.get("bundle_id", ""))
    info.add_row("Enabled", "yes" if result.get("enabled", True) else "no")
    if result.get("required_variables"):
        info.add_row("Variables", ", ".join(result["required_variables"]))
    if result.get("skeleton_ref"):
        info.add_row("Skeleton Ref", result["skeleton_ref"])
    if result.get("backstage_type"):
        info.add_row("Type", result["backstage_type"])
    console.print(info)


# ---------------------------------------------------------------------------
# preview sub-command
# ---------------------------------------------------------------------------


@template_group.command("preview")
@click.option(
    "--bundle",
    "bundle_id",
    required=True,
    metavar="ID",
    help="ID of the bundle to preview the scaffold template for.",
)
def preview_cmd(bundle_id: str) -> None:
    """Preview the generated Backstage YAML for a scaffold template.

    Calls the generate-without-save endpoint and prints the rendered
    Backstage Software Template YAML to stdout.  Does not persist the
    result.

    \b
    Examples:
      skillmeat template preview --bundle my-python-bundle
      skillmeat template preview --bundle my-python-bundle > template.yaml
    """
    api_base = _api_base()
    url = f"{api_base}/api/v1/templates/scaffold/{bundle_id}/preview"

    result: dict = {}
    try:
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        result = resp.json()
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "preview template")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    yaml_content = result.get("template_yaml", "")
    if not yaml_content:
        click.echo("Warning: API returned an empty template.", err=True)

    # Print warnings to stderr so stdout contains only valid YAML
    warnings = result.get("validation_warnings", [])
    for warning in warnings:
        click.echo(f"Warning: {warning}", err=True)

    # Print YAML to stdout directly (not via Rich) so it is pipe-friendly
    click.echo(yaml_content)
