"""Pipeline orchestrator for ``skillmeat scaffold --from-context``.

This module keeps :mod:`skillmeat.cli.commands.scaffold` readable by isolating
the multi-step ``--from-context`` pipeline here.

Pipeline stages:

1. **Load context** — detect file / directory / free text; read and truncate.
2. **Analyze** — produce an IntentSet via the heuristic fallback analyzer, or
   load a pre-existing ``.intent-set.yaml`` / ``.intents.yaml`` file directly.
3. **Interview gate** — check aggregate confidence; warn when low.
4. **Curator search** — call :func:`search_all_legs` for each intent; apply
   scope filter.
5. **Preview** — render candidates and prompt for confirmation (or auto-confirm).
6. **Assemble** — create a Bundle entity via the API (skipped in dry-run mode).
7. **Print summary** — rich summary panel with bundle ID, member count, etc.

Public API::

    run_scaffold_from_context — orchestrate the full pipeline; returns exit code.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from rich.console import Console
from rich.panel import Panel

from skillmeat.core.scaffolder.assembly import AssemblyError, assemble_bundle
from skillmeat.core.scaffolder.curator import (
    CandidateArtifact,
    CuratorError,
    dedupe_candidates,
    rank_candidates,
)
from skillmeat.core.scaffolder.heuristic_analyzer import analyze_context, analyze_text
from skillmeat.core.scaffolder.intent_schema import (
    IntentSet,
    dump_intent_set,
    load_intent_set,
)
from skillmeat.core.scaffolder.interview import (
    generate_questions,
    should_trigger_interview,
)
from skillmeat.core.scaffolder.preview import run_preview_flow
from skillmeat.core.scaffolder.scope_filter import get_filter_for_scope
from skillmeat.core.scaffolder.search import search_all_legs
from skillmeat.observability.tracing import trace_operation

logger = logging.getLogger("skillmeat.scaffolder")

_console = Console()

# ─────────────────────────────────────────────────────────────────────────────
# Intent Set YAML detection
# ─────────────────────────────────────────────────────────────────────────────

_INTENT_SET_SUFFIXES = (
    ".intent-set.yaml",
    ".intent-set.yml",
    ".intents.yaml",
    ".intents.yml",
)


def _is_intent_set_file(context: str) -> bool:
    """Return True when *context* looks like a path to a pre-existing intent-set YAML."""
    lower = context.lower()
    return any(lower.endswith(suffix) for suffix in _INTENT_SET_SUFFIXES)


# ─────────────────────────────────────────────────────────────────────────────
# Search with graceful degradation for dry-run / offline
# ─────────────────────────────────────────────────────────────────────────────


def _search_with_fallback(
    iset: IntentSet,
    base_url: str,
    dry_run: bool,
) -> List[CandidateArtifact]:
    """Run curator search for all intents; degrade gracefully when the API is down.

    In dry-run mode a ``CuratorError`` (API unavailable) is caught and an
    empty candidate list is returned with a user-visible warning.  In live
    mode the error is re-raised so the caller can surface it.

    Args:
        iset:     The IntentSet whose intents drive the search queries.
        base_url: SkillMeat API base URL.
        dry_run:  When True, network failures degrade to an empty result set.

    Returns:
        Merged, de-duplicated, ranked list of ``CandidateArtifact`` objects
        (may be empty when the API is unavailable and *dry_run* is True).

    Raises:
        CuratorError: When the API is unreachable and *dry_run* is False.
    """
    from skillmeat.core.scaffolder.curator import merge_search_results

    all_candidates: List[CandidateArtifact] = []
    for intent in iset.intents:
        try:
            match_results, metadata_results, marketplace_results = search_all_legs(
                intent, base_url=base_url
            )
        except CuratorError as exc:
            if dry_run:
                _console.print(
                    f"[yellow]Warning: API unavailable ({exc}) — "
                    "showing Intent Set only (no candidates).[/yellow]"
                )
                logger.warning("search_all_legs failed in dry-run mode: %s", exc)
                return []
            raise

        per_intent = merge_search_results(
            intent, match_results, metadata_results, marketplace_results
        )
        all_candidates.extend(per_intent)

    candidates = dedupe_candidates(all_candidates)
    candidates = rank_candidates(candidates)
    return candidates


# ─────────────────────────────────────────────────────────────────────────────
# Main pipeline entry point
# ─────────────────────────────────────────────────────────────────────────────


def run_scaffold_from_context(
    *,
    context: str,
    project_root: Path,
    scope: str,
    auto_confirm: bool,
    dry_run: bool,
    intent_set_dir: Optional[Path],
    api_base_url: str,
) -> int:
    """Orchestrate the full scaffold-from-context pipeline.

    Args:
        context:        File path, directory path, or free-text description.
                        When the value ends with ``.intent-set.yaml`` or
                        ``.intents.yaml`` the file is loaded directly as a
                        pre-existing IntentSet (skipping heuristic analysis).
        project_root:   Target project directory.  Created if it does not exist.
        scope:          Scope variant — ``"whole-project"`` or ``"feature"``.
        auto_confirm:   Skip interactive preview prompts.
        dry_run:        Suppress bundle creation and API writes.
        intent_set_dir: Directory for the Intent Set YAML sidecar.  Defaults to
                        *project_root* when ``None``.
        api_base_url:   SkillMeat API base URL (e.g., ``http://localhost:8080``).

    Returns:
        Exit code: ``0`` on success, ``1`` on abort or unrecoverable error.
    """
    sidecar_dir = intent_set_dir or project_root

    # Determine input kind for tracing/logging (file | dir | text)
    _ctx_path = Path(context)
    if _is_intent_set_file(context) or _ctx_path.is_file():
        _input_kind = "file"
    elif _ctx_path.is_dir():
        _input_kind = "dir"
    else:
        _input_kind = "text"

    logger.info(
        "scaffold.run.start",
        extra={
            "scaffold_run_id": "pending",  # resolved after analyze step
            "context_kind": _input_kind,
        },
    )

    with trace_operation(
        "scaffold.run", scope_variant=scope, dry_run=dry_run
    ) as root_span:

        # ------------------------------------------------------------------
        # Step 1: Load + analyse context
        # ------------------------------------------------------------------
        _console.print(f"[dim]Loading context from: {context!r}[/dim]")

        iset: IntentSet

        with trace_operation(
            "scaffold.analyze",
            input_kind=_input_kind,
        ) as analyze_span:
            if _is_intent_set_file(context):
                path = Path(context)
                if not path.is_file():
                    _console.print(
                        f"[red]Error: Intent Set file not found: {path}[/red]"
                    )
                    return 1
                try:
                    iset = load_intent_set(path)
                    _console.print(
                        f"[dim]Loaded pre-existing Intent Set: "
                        f"{iset.scaffold_run_id} ({len(iset.intents)} intent(s))[/dim]"
                    )
                except (ValueError, Exception) as exc:
                    _console.print(f"[red]Error loading Intent Set YAML: {exc}[/red]")
                    return 1
            else:
                # Heuristic fallback analysis
                text, source_summary = analyze_context(context)
                if not text.strip():
                    _console.print(
                        "[yellow]Warning: Context resolved to empty text. "
                        "No intents will be detected.[/yellow]"
                    )
                _console.print(
                    f"[dim]Analysing context via heuristic analyzer "
                    f"(source: {source_summary!r}, {len(text)} chars)[/dim]"
                )
                iset = analyze_text(
                    text, source_summary=source_summary, scope_variant=scope
                )
                _console.print(
                    f"[dim]Detected {len(iset.intents)} intent(s) "
                    f"(aggregate confidence: {iset.aggregate_confidence:.0%})[/dim]"
                )
                analyze_span.set_attribute("source_summary", source_summary)

            analyze_span.set_attribute("intent_count", len(iset.intents))
            analyze_span.set_attribute(
                "aggregate_confidence", iset.aggregate_confidence
            )

        root_span.set_attribute("scaffold_run_id", iset.scaffold_run_id)

        if not iset.intents:
            _console.print(
                "[yellow]No intents detected. "
                "Try providing more specific context (e.g., a README or PRD file).[/yellow]"
            )
            if dry_run:
                _print_summary(iset, None, 0, None, dry_run=True)
                return 0
            return 1

        # ------------------------------------------------------------------
        # Step 2: Interview gate
        # ------------------------------------------------------------------
        interview_triggered = should_trigger_interview(iset)
        if interview_triggered:
            questions = generate_questions(iset)
            if auto_confirm:
                logger.warning(
                    "Low-confidence scaffold (run_id=%s, confidence=%.2f) — "
                    "proceeding automatically due to --auto-confirm",
                    iset.scaffold_run_id,
                    iset.aggregate_confidence,
                )
                _console.print(
                    "[yellow]Warning: Low-confidence scaffold detected "
                    f"(confidence: {iset.aggregate_confidence:.0%}). "
                    "Proceeding due to --auto-confirm.[/yellow]"
                )
            else:
                _console.print(
                    "[yellow]Low-confidence scaffold detected. "
                    "Consider refining input and re-running. Proceeding anyway...[/yellow]"
                )
                if questions:
                    _console.print(
                        "[dim]Open questions that would improve accuracy:[/dim]"
                    )
                    for q in questions:
                        _console.print(f"  [dim]• {q}[/dim]")

        # ------------------------------------------------------------------
        # Step 3: Curator search
        # ------------------------------------------------------------------
        _console.print("[dim]Searching for matching artifacts...[/dim]")
        with trace_operation(
            "scaffold.search",
            intent_count=len(iset.intents),
            scope_variant=scope,
        ) as search_span:
            try:
                candidates = _search_with_fallback(iset, api_base_url, dry_run=dry_run)
            except CuratorError as exc:
                _console.print(f"[red]Error during curator search: {exc}[/red]")
                return 1

            # Apply scope filter (excludes already-deployed artifacts in feature mode).
            # get_filter_for_scope returns None for "whole-project" scope — skip filter in that case.
            scope_filter = get_filter_for_scope(scope, project_root)
            if scope_filter is not None:
                candidates = [c for c in candidates if scope_filter(c)]

            search_span.set_attribute("candidate_count", len(candidates))

        _console.print(f"[dim]{len(candidates)} candidate(s) after scope filter[/dim]")

        # ------------------------------------------------------------------
        # Step 4: Preview + confirmation
        # ------------------------------------------------------------------
        if not candidates:
            _console.print(
                "[yellow]No candidate artifacts found for the detected intents.[/yellow]"
            )
            if dry_run:
                _print_summary(iset, None, 0, None, dry_run=True)
                return 0
            return 1

        final_candidates, decision = run_preview_flow(
            iset,
            candidates,
            dry_run=dry_run,
            auto_confirm=auto_confirm,
        )

        if decision.aborted:
            _console.print("[yellow]Scaffold aborted.[/yellow]")
            logger.info(
                "scaffold.run.complete",
                extra={
                    "scaffold_run_id": iset.scaffold_run_id,
                    "scope_variant": scope,
                    "intent_count": len(iset.intents),
                    "artifact_count": 0,
                    "confidence_avg": iset.aggregate_confidence,
                    "interview_triggered": interview_triggered,
                    "confirmed": None,
                    "deploy_path": None,
                },
            )
            return 1

        # ------------------------------------------------------------------
        # Step 5: Assemble (skipped in dry-run)
        # ------------------------------------------------------------------
        result = None
        intent_set_path: Optional[Path] = None

        with trace_operation(
            "scaffold.assemble",
            dry_run=dry_run,
        ) as assemble_span:
            if dry_run:
                # Write Intent Set sidecar even in dry-run so the user can review it
                _console.print("[dim]DRY-RUN: skipping bundle creation.[/dim]")
                # Compute where the sidecar *would* be written
                intent_set_path = (
                    sidecar_dir / f"{iset.scaffold_run_id}.intent-set.yaml"
                )
                assemble_span.set_attribute(
                    "bundle_id", f"dry-run-{iset.scaffold_run_id}"
                )
                assemble_span.set_attribute("member_count", len(final_candidates))
            else:
                try:
                    # Ensure target directory exists before writing anything
                    project_root.mkdir(parents=True, exist_ok=True)
                    result = assemble_bundle(
                        iset,
                        final_candidates,
                        base_url=api_base_url,
                        dry_run=False,
                        intent_set_dir=sidecar_dir,
                    )
                    intent_set_path = result.intent_set_path
                    assemble_span.set_attribute("bundle_id", result.bundle_id)
                    assemble_span.set_attribute("member_count", result.member_count)
                except AssemblyError as exc:
                    _console.print(f"[red]Error during bundle assembly: {exc}[/red]")
                    return 1
                except Exception as exc:
                    logger.exception("Unexpected error during assembly")
                    _console.print(
                        f"[red]Unexpected error during assembly: {exc}[/red]"
                    )
                    return 1

        # ------------------------------------------------------------------
        # Step 6: Write intent set sidecar in dry-run mode (best-effort)
        # ------------------------------------------------------------------
        with trace_operation(
            "scaffold.deploy",
            bundle_id=(
                result.bundle_id
                if result is not None
                else f"dry-run-{iset.scaffold_run_id}"
            ),
        ) as deploy_span:
            if dry_run:
                try:
                    sidecar_dir.mkdir(parents=True, exist_ok=True)
                    intent_set_path = (
                        sidecar_dir / f"{iset.scaffold_run_id}.intent-set.yaml"
                    )
                    dump_intent_set(iset, intent_set_path)
                    _console.print(
                        f"[dim]Intent Set written to: {intent_set_path}[/dim]"
                    )
                except OSError as exc:
                    _console.print(
                        f"[yellow]Warning: Could not write Intent Set sidecar: {exc}[/yellow]"
                    )
                    intent_set_path = None

            deploy_span.set_attribute(
                "intent_set_path", str(intent_set_path) if intent_set_path else ""
            )

        # ------------------------------------------------------------------
        # Step 7: Print summary + emit run-complete log
        # ------------------------------------------------------------------
        bundle_id = (
            result.bundle_id
            if result is not None
            else f"dry-run-{iset.scaffold_run_id}"
        )
        member_count = (
            result.member_count if result is not None else len(final_candidates)
        )
        _print_summary(iset, bundle_id, member_count, intent_set_path, dry_run=dry_run)

        logger.info(
            "scaffold.run.complete",
            extra={
                "scaffold_run_id": iset.scaffold_run_id,
                "scope_variant": scope,
                "intent_count": len(iset.intents),
                "artifact_count": member_count,
                "confidence_avg": iset.aggregate_confidence,
                "interview_triggered": interview_triggered,
                "confirmed": not decision.aborted,
                "deploy_path": str(intent_set_path) if intent_set_path else None,
            },
        )

        return 0


# ─────────────────────────────────────────────────────────────────────────────
# Summary renderer
# ─────────────────────────────────────────────────────────────────────────────


def _print_summary(
    iset: IntentSet,
    bundle_id: Optional[str],
    member_count: int,
    intent_set_path: Optional[Path],
    *,
    dry_run: bool,
) -> None:
    """Print a rich summary panel after the pipeline completes."""
    mode_label = "[yellow]DRY-RUN[/yellow]" if dry_run else "[green]SUCCESS[/green]"
    lines = [
        f"Status       : {mode_label}",
        f"Run ID       : [green]{iset.scaffold_run_id}[/green]",
        f"Intents      : {len(iset.intents)}",
        f"Confidence   : {iset.aggregate_confidence:.0%}",
        f"Members      : {member_count}",
    ]
    if bundle_id:
        lines.append(f"Bundle ID    : [cyan]{bundle_id}[/cyan]")
    if intent_set_path:
        lines.append(f"Intent Set   : [dim]{intent_set_path}[/dim]")
    if dry_run:
        lines.append("")
        lines.append("[dim]Re-run without --dry-run to create the bundle.[/dim]")

    _console.print(
        Panel(
            "\n".join(lines),
            title="Scaffold Summary",
            border_style="cyan" if dry_run else "green",
        )
    )
