"""Click command for rendering and writing scaffold files from a bundle.

Provides the ``skillmeat scaffold`` top-level command:

    skillmeat scaffold --bundle <id> --project <path> [--set KEY=VALUE]...
                       [--platform <platform>] [--dry-run] [--no-register]

When ``--bundle`` refers to a Bundle entity (resolved via BundleResolver), the
command delegates to the same deploy pipeline used by ``skillmeat bundle
deploy``.  The legacy composite scaffold path (render_in_memory) is preserved
for non-bundle targets.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import List, Optional, Tuple

import click
import requests
from rich.console import Console
from rich.table import Table
from rich.tree import Tree

from skillmeat.config import ConfigManager
from skillmeat.cache.models import get_session
from skillmeat.core.services.bundle_resolver import (
    BundleResolutionError,
    BundleResolver,
)
from skillmeat.core.services.template_service import render_in_memory
from skillmeat.observability.tracing import trace_operation
from skillmeat.cli.commands.bundle import (
    _deploy_artifact_files,
    _deploy_context_entity,
    _resolve_bundle_id,
)

console = Console(force_terminal=True, legacy_windows=False)

_config_mgr = ConfigManager()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _api_base() -> str:
    """Return the configured API base URL."""
    return _config_mgr.get("api.base_url", "http://localhost:8080")


def _parse_set_values(set_values: Tuple[str, ...]) -> dict[str, str]:
    """Parse ``KEY=VALUE`` strings into a dict.

    Args:
        set_values: Tuple of strings in ``KEY=VALUE`` format.

    Returns:
        Mapping of variable name to value.

    Raises:
        SystemExit: If any entry does not contain ``=``.
    """
    result: dict[str, str] = {}
    for entry in set_values:
        if "=" not in entry:
            console.print(
                f"[red]Error: --set value must be in KEY=VALUE format. Got: {entry!r}[/red]"
            )
            sys.exit(1)
        key, _, value = entry.partition("=")
        result[key.strip()] = value
    return result


# ---------------------------------------------------------------------------
# scaffold command
# ---------------------------------------------------------------------------


@click.command("scaffold")
@click.option(
    "--bundle",
    "bundle_id",
    required=False,
    default=None,
    metavar="ID",
    help=(
        "Bundle ID to scaffold.  Required unless --from-context is given.  "
        "Mutually exclusive with --from-context."
    ),
)
@click.option(
    "--from-context",
    "from_context",
    default=None,
    metavar="PATH_OR_TEXT",
    help=(
        "Invoke the project-scaffolder pipeline from a PRD file, project "
        "directory, or free-text description.  When provided, --bundle becomes "
        "optional — the pipeline will produce one.  Mutually exclusive with "
        "--bundle."
    ),
)
@click.option(
    "--scope",
    "scope",
    type=click.Choice(["whole-project", "feature"], case_sensitive=False),
    default="whole-project",
    show_default=True,
    help="Curation scope when using --from-context.",
)
@click.option(
    "--auto-confirm",
    "auto_confirm",
    is_flag=True,
    default=False,
    help="Skip interactive confirmation prompts (useful for CI / non-interactive runs).",
)
@click.option(
    "--intent-set-dir",
    "intent_set_dir",
    default=None,
    metavar="PATH",
    type=click.Path(file_okay=False, resolve_path=True),
    help=(
        "Directory where the Intent Set YAML sidecar is written.  "
        "Defaults to the target project directory."
    ),
)
@click.option(
    "--project",
    "project_path",
    required=True,
    metavar="PATH",
    help="Target project directory.",
    type=click.Path(file_okay=False, resolve_path=True),
)
@click.option(
    "--set",
    "set_values",
    multiple=True,
    metavar="KEY=VALUE",
    help=(
        "Variable override in KEY=VALUE format.  Repeatable.  "
        "Allowed keys: PROJECT_NAME, PROJECT_DESCRIPTION, AUTHOR, DATE, ARCHITECTURE_DESCRIPTION."
    ),
)
@click.option(
    "--platform",
    "platform",
    default=None,
    metavar="PLATFORM",
    help="Platform filter (e.g. claude-code, cursor, windsurf, vscode, generic).",
)
@click.option(
    "--dry-run",
    "dry_run",
    is_flag=True,
    default=False,
    help="Print the file tree that would be written without writing any files.",
)
@click.option(
    "--no-register",
    "no_register",
    is_flag=True,
    default=False,
    help="Skip registering the deployment with the IDP integration endpoint.",
)
def scaffold_cmd(
    bundle_id: Optional[str],
    from_context: Optional[str],
    scope: str,
    auto_confirm: bool,
    intent_set_dir: Optional[str],
    project_path: str,
    set_values: Tuple[str, ...],
    platform: Optional[str],
    dry_run: bool,
    no_register: bool,
) -> None:
    """Render and write scaffold files from a bundle into a project.

    When ``--bundle`` is given, calls ``render_in_memory()`` to produce the
    full rendered file tree, writes each file under ``<project>/.claude/``, and
    (unless ``--no-register`` is given) registers the deployment with the IDP
    integration endpoint.

    When ``--from-context`` is given, the project-scaffolder pipeline is
    invoked: context is analysed for technology intents, matching artifacts are
    curated, the user confirms the selection (unless ``--auto-confirm``), and a
    Bundle entity is assembled via the API.

    Use ``--dry-run`` to preview without writing any files or creating bundles.

    \b
    Examples:
      skillmeat scaffold --bundle my-python-bundle --project ./my-project
      skillmeat scaffold --bundle fin-serv --project . --set PROJECT_NAME=payments
      skillmeat scaffold --bundle my-bundle --project . --dry-run
      skillmeat scaffold --from-context ./README.md --project ./my-project
      skillmeat scaffold --from-context "fastapi postgres react" --project . --dry-run
      skillmeat scaffold --from-context ./prd.md --project . --scope feature --auto-confirm
    """
    # ------------------------------------------------------------------
    # Mutual-exclusivity check
    # ------------------------------------------------------------------
    if from_context is not None and bundle_id is not None:
        console.print(
            "[red]Error: --from-context and --bundle are mutually exclusive.[/red]"
        )
        sys.exit(1)

    if from_context is None and bundle_id is None:
        console.print(
            "[red]Error: one of --bundle or --from-context is required.[/red]"
        )
        sys.exit(1)

    # ------------------------------------------------------------------
    # --from-context pipeline
    # ------------------------------------------------------------------
    if from_context is not None:
        from skillmeat.cli.commands.scaffold_from_context import run_scaffold_from_context

        project_dir = Path(project_path)
        sidecar_dir = Path(intent_set_dir) if intent_set_dir else None

        exit_code = run_scaffold_from_context(
            context=from_context,
            project_root=project_dir,
            scope=scope,
            auto_confirm=auto_confirm,
            dry_run=dry_run,
            intent_set_dir=sidecar_dir,
            api_base_url=_api_base(),
        )
        sys.exit(exit_code)

    # ------------------------------------------------------------------
    # Legacy --bundle path (bundle_id is guaranteed non-None here)
    # ------------------------------------------------------------------
    assert bundle_id is not None  # guarded by the mutex check above
    variables = _parse_set_values(set_values)

    project_dir = Path(project_path)
    target_id = f"bundle:{bundle_id}"

    # Require PROJECT_NAME unless doing a dry run where it may not matter
    if not dry_run and "PROJECT_NAME" not in variables:
        variables.setdefault("PROJECT_NAME", project_dir.name)

    with trace_operation(
        "scaffold_cli",
        bundle_id=bundle_id,
        platform=platform or "",
        dry_run=dry_run,
    ) as _scaf_span:
        # ------------------------------------------------------------------
        # Detect whether bundle_id refers to a Bundle entity.
        # Try resolving via BundleResolver; fall back to render_in_memory()
        # for composite / template-based targets.
        # ------------------------------------------------------------------
        _UUID_RE = re.compile(
            r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
            re.IGNORECASE,
        )

        resolved_bundle_uuid: Optional[str] = None
        try:
            if _UUID_RE.match(bundle_id):
                resolved_bundle_uuid = bundle_id
            else:
                resolved_bundle_uuid = _resolve_bundle_id(bundle_id)
        except SystemExit:
            # _resolve_bundle_id calls sys.exit(1) when not found — treat as
            # "not a Bundle entity" and fall through to the legacy path.
            resolved_bundle_uuid = None

        if resolved_bundle_uuid is not None:
            # ----------------------------------------------------------------
            # Bundle deploy path — mirrors ``skillmeat bundle deploy`` exactly.
            # ----------------------------------------------------------------
            try:
                with get_session() as session:
                    resolver = BundleResolver()
                    result = resolver.resolve(resolved_bundle_uuid, session)
            except ValueError as exc:
                console.print(f"[red]Error: {exc}[/red]")
                sys.exit(1)
            except BundleResolutionError as exc:
                console.print(f"[red]Error resolving bundle '{bundle_id}': {exc}[/red]")
                sys.exit(1)
            except Exception as exc:
                console.print(
                    f"[red]Unexpected error resolving bundle '{bundle_id}': {exc}[/red]"
                )
                sys.exit(1)

            total_members = len(result.artifacts) + len(result.context_entities)
            if total_members == 0:
                console.print(
                    f"[yellow]Warning: Bundle '{bundle_id}' has no members to deploy.[/yellow]"
                )
                sys.exit(0)

            if dry_run:
                console.print(
                    f"[dim]Dry run — {total_members} member(s) would be deployed to "
                    f"[cyan]{project_path}[/cyan][/dim]"
                )

            table = Table(
                title=f"Bundle scaffold: {bundle_id}",
                show_header=True,
                header_style="bold",
                box=None,
                padding=(0, 1),
            )
            table.add_column("Type", style="dim")
            table.add_column("Name")
            table.add_column("Files", justify="right")
            table.add_column("Status")
            table.add_column("Detail")

            any_failure = False

            for artifact in result.artifacts:
                if not artifact.file_content_map:
                    table.add_row(
                        artifact.type,
                        artifact.name,
                        "0",
                        "[yellow]skipped[/yellow]",
                        "no files in file_content_map",
                    )
                    continue

                written_paths, error = _deploy_artifact_files(
                    project_dir,
                    artifact.name,
                    artifact.type,
                    artifact.file_content_map,
                    dry_run,
                )
                file_count = str(len(written_paths))

                if error:
                    any_failure = True
                    table.add_row(
                        artifact.type,
                        artifact.name,
                        file_count,
                        "[red]failed[/red]",
                        error,
                    )
                else:
                    action = "would deploy" if dry_run else "deployed"
                    table.add_row(
                        artifact.type,
                        artifact.name,
                        file_count,
                        f"[green]{action}[/green]",
                        "",
                    )

            for entity in result.context_entities:
                if not entity.content:
                    table.add_row(
                        entity.entity_type,
                        entity.name,
                        "0",
                        "[yellow]skipped[/yellow]",
                        "no content",
                    )
                    continue

                dest_path, error = _deploy_context_entity(project_dir, entity, dry_run)
                if error:
                    any_failure = True
                    table.add_row(
                        entity.entity_type,
                        entity.name,
                        "1",
                        "[red]failed[/red]",
                        error,
                    )
                else:
                    action = "would deploy" if dry_run else "deployed"
                    table.add_row(
                        entity.entity_type,
                        entity.name,
                        "1",
                        f"[green]{action}[/green]",
                        dest_path,
                    )

            console.print(table)

            if any_failure:
                console.print(
                    "[red]One or more members failed to deploy.  "
                    "Already-written files have NOT been rolled back.[/red]"
                )
                sys.exit(1)

            if not dry_run:
                console.print(
                    f"[green]Bundle '{bundle_id}' scaffolded successfully to "
                    f"[cyan]{project_dir}[/cyan].[/green]"
                )

        else:
            # ----------------------------------------------------------------
            # Legacy composite scaffold path — render_in_memory() unchanged.
            # ----------------------------------------------------------------
            try:
                with get_session() as session:
                    rendered_files = render_in_memory(session, target_id, variables)
            except ValueError as exc:
                console.print(f"[red]Error: {exc}[/red]")
                sys.exit(1)
            except Exception as exc:
                console.print(f"[red]Error rendering bundle '{bundle_id}': {exc}[/red]")
                sys.exit(1)

            if not rendered_files:
                console.print(
                    f"[yellow]Warning: Bundle '{bundle_id}' produced no rendered files.[/yellow]"
                )
                sys.exit(0)

            # Filter by platform if requested.
            if platform:
                filtered = [
                    f
                    for f in rendered_files
                    if not f.path
                    or platform.lower() in f.path.lower()
                    or "/" not in f.path
                ]
                if filtered:
                    rendered_files = filtered

            # Capture bundle_version from the first rendered file metadata if available.
            bundle_version = (
                getattr(rendered_files[0], "bundle_version", None)
                if rendered_files
                else None
            )
            if bundle_version:
                _scaf_span.set_attribute("bundle_version", str(bundle_version))

            # Dry-run: print tree and exit.
            if dry_run:
                tree = Tree(f"[bold]{project_path}/[/bold]")
                for rf in rendered_files:
                    size_kb = len(rf.content) / 1024
                    label = f"{rf.path}  [dim]({size_kb:.1f} KB)[/dim]"
                    tree.add(label)
                console.print(tree)
                console.print(
                    f"\n[dim]Dry run complete — {len(rendered_files)} file(s) would be written.[/dim]"
                )
                return

            # Write files to <project>/.claude/.
            written: List[Path] = []

            for rf in rendered_files:
                # rf.path is a project-relative path such as ".claude/CLAUDE.md".
                # Strip any leading "./" so Path joining works correctly.
                rel = rf.path
                while rel.startswith("./"):
                    rel = rel[2:]
                rel = rel.lstrip("/")
                dest = project_dir / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(rf.content)
                written.append(dest)

            # Success summary.
            console.print(
                f"[green]Scaffold complete.[/green] "
                f"{len(written)} file(s) written to [cyan]{project_dir}[/cyan]."
            )

        # ------------------------------------------------------------------
        # Register deployment (unless --no-register)
        # ------------------------------------------------------------------
        if no_register:
            return

        api_base = _api_base()
        register_url = f"{api_base}/api/v1/integrations/idp/register-deployment"
        repo_url = project_dir.as_uri()  # local path as file:// URI

        payload: dict = {
            "repo_url": repo_url,
            "target_id": target_id,
            "bundle_id": bundle_id,
            "metadata": {"scaffold_source": "skillmeat-cli"},
        }
        if platform:
            payload["platform"] = platform

        try:
            resp = requests.post(
                register_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=30,
            )
            resp.raise_for_status()
            reg_result = resp.json()
            deployment_id = reg_result.get("deployment_set_id", "")
            created = reg_result.get("created", False)
            verb = "Registered" if created else "Updated"
            console.print(f"[dim]{verb} deployment set: {deployment_id}[/dim]")
        except requests.exceptions.HTTPError as exc:
            # Non-fatal: warn but do not fail the overall command
            try:
                body = exc.response.json()
                detail = body.get("detail") or body.get("message") or str(exc)
            except Exception:
                detail = str(exc)
            console.print(
                f"[yellow]Warning: Deployment registration failed: {detail}[/yellow]"
            )
            console.print(
                "[yellow]Files were written successfully. "
                "Re-run with --no-register to suppress this warning.[/yellow]"
            )
        except requests.exceptions.RequestException:
            console.print(
                f"[yellow]Warning: Could not connect to API server at {api_base} "
                "to register deployment.[/yellow]"
            )
            console.print(
                "[yellow]Files were written successfully. "
                "Re-run with --no-register to suppress this warning.[/yellow]"
            )
