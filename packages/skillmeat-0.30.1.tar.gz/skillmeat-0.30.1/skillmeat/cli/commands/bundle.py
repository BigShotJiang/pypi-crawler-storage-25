"""Click command group for Bundle entity management.

Provides the ``skillmeat bundle`` subcommand tree:

    skillmeat bundle create NAME [--description TEXT] [--version VER] [--tags TAG]... [--license TEXT]
    skillmeat bundle add-member BUNDLE_NAME ARTIFACT_ID
    skillmeat bundle remove-member BUNDLE_NAME ARTIFACT_ID
    skillmeat bundle list [--status STATUS] [--json]
    skillmeat bundle show BUNDLE_NAME
    skillmeat bundle version BUNDLE_NAME SEMVER
    skillmeat bundle publish BUNDLE_NAME
    skillmeat bundle export BUNDLE_NAME [--output PATH]
    skillmeat bundle import PATH [--dry-run] [--conflict-strategy STRATEGY]
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import NoReturn, Optional, Tuple

import click
import requests
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from skillmeat.cache.models import get_session
from skillmeat.config import ConfigManager
from skillmeat.core.artifact_detection import ArtifactType
from skillmeat.core.services.bundle_resolver import (
    BundleResolutionError,
    BundleResolver,
    ResolvedContextEntity,
)
from skillmeat.core.tier_enforcement import TierEnforcementEngine, ValidationResult

console = Console(force_terminal=True, legacy_windows=False)

_config_mgr = ConfigManager()

# Semver pattern: X.Y.Z with optional pre-release / build metadata
_SEMVER_RE = re.compile(
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)"
    r"(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?"
    r"(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$"
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _api_base() -> str:
    """Return the configured API base URL."""
    return _config_mgr.get("api.base_url", "http://localhost:8080")


def _connection_error_hint() -> str:
    return "Make sure the API server is running: skillmeat web dev --api-only"


def _handle_http_error(exc: requests.exceptions.HTTPError, operation: str) -> NoReturn:
    """Print a user-friendly error from an HTTPError and exit with code 1."""
    try:
        body = exc.response.json()
        detail = body.get("detail") or body.get("message") or str(exc)
    except Exception:
        detail = str(exc)
    console.print(f"[red]Error ({operation}): {detail}[/red]")
    sys.exit(1)


def _handle_connection_error(url: str) -> NoReturn:
    """Print a connection-refused error and exit with code 1."""
    console.print(f"[red]Error: Could not connect to API server at {url}[/red]")
    console.print(f"[yellow]{_connection_error_hint()}[/yellow]")
    sys.exit(1)


def _resolve_bundle_id(bundle_name: str) -> str:
    """Resolve a bundle name to its UUID by listing all bundles.

    Raises SystemExit(1) if not found or API is unreachable.
    """
    api_base = _api_base()
    url = f"{api_base}/api/v1/bundles/entities"
    data: dict = {}
    items: list = []
    try:
        resp = requests.get(url, params={"page_size": 100}, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        items = data.get("items", [])
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "resolve bundle")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    # Paginate if needed
    total = data.get("total", 0)
    page_size = data.get("page_size", 100)
    if total > page_size:
        pages = (total + page_size - 1) // page_size
        for page_num in range(2, pages + 1):
            try:
                r = requests.get(
                    url, params={"page_size": page_size, "page": page_num}, timeout=30
                )
                r.raise_for_status()
                items.extend(r.json().get("items", []))
            except Exception:
                break

    for item in items:
        if item.get("name") == bundle_name:
            return item["id"]

    console.print(f"[red]Error: Bundle '{bundle_name}' not found.[/red]")
    sys.exit(1)


def _resolve_artifact_uuid(artifact_id: str) -> str:
    """Resolve a type:name artifact ID to its stable UUID.

    Raises SystemExit(1) if not found or API is unreachable.
    """
    api_base = _api_base()
    url = f"{api_base}/api/v1/artifacts/{artifact_id}"
    data: dict = {}
    try:
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, f"resolve artifact '{artifact_id}'")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    uuid = data.get("uuid")
    if not uuid:
        console.print(
            f"[red]Error: Artifact '{artifact_id}' has no UUID in the DB cache.[/red]"
        )
        sys.exit(1)
    return uuid


def _resolve_context_entity_id(name: str) -> str:
    """Resolve a context entity name to its ID.

    Uses GET /api/v1/context-entities?search=<name> and returns the ID of the
    first exact-name match.  Raises SystemExit(1) if not found or the API is
    unreachable.
    """
    api_base = _api_base()
    url = f"{api_base}/api/v1/context-entities"
    items: list = []
    try:
        resp = requests.get(url, params={"search": name, "page_size": 50}, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        items = data.get("items", [])
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, f"resolve context entity '{name}'")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    # Prefer an exact name match; fall back to the first result.
    for item in items:
        if item.get("name") == name:
            return item["id"]

    if items:
        return items[0]["id"]

    console.print(f"[red]Error: Context entity '{name}' not found.[/red]")
    sys.exit(1)


# ---------------------------------------------------------------------------
# bundle group
# ---------------------------------------------------------------------------


@click.group("bundle")
def bundle_group() -> None:
    """Manage Bundle entities (create, curate, publish, export).

    Bundles are curated collections of artifacts that can be versioned,
    published to a marketplace, and exported as portable .skillmeat-pack
    archives.

    \b
    Examples:
      skillmeat bundle create my-bundle --description "My toolkit"
      skillmeat bundle add-member my-bundle skill:canvas-design
      skillmeat bundle list
      skillmeat bundle show my-bundle
      skillmeat bundle publish my-bundle
      skillmeat bundle export my-bundle --output my-bundle.skillmeat-pack
    """


# ---------------------------------------------------------------------------
# create sub-command
# ---------------------------------------------------------------------------


@bundle_group.command("create")
@click.argument("name", metavar="NAME")
@click.option(
    "--description",
    "-d",
    "description",
    default=None,
    metavar="TEXT",
    help="Human-readable description of the Bundle.",
)
@click.option(
    "--version",
    "-v",
    "version",
    default=None,
    metavar="VER",
    help="Initial semantic version (e.g. 0.1.0).  Defaults to 0.1.0.",
)
@click.option(
    "--tags",
    "-t",
    "tags",
    multiple=True,
    metavar="TAG",
    help="One or more tags to apply to the Bundle (repeatable).",
)
@click.option(
    "--license",
    "-l",
    "license_id",
    default=None,
    metavar="TEXT",
    help="SPDX license identifier (e.g. MIT, Apache-2.0).",
)
def create_cmd(
    name: str,
    description: Optional[str],
    version: Optional[str],
    tags: Tuple[str, ...],
    license_id: Optional[str],
) -> None:
    """Create a new Bundle entity.

    Creates a named Bundle in the local collection.  The Bundle can then
    be populated with artifacts using ``bundle add-member``.

    \b
    Examples:
      skillmeat bundle create my-bundle
      skillmeat bundle create my-bundle --description "My toolkit" --version 1.0.0
      skillmeat bundle create my-bundle --tags productivity --tags writing --license MIT
    """
    api_base = _api_base()
    url = f"{api_base}/api/v1/bundles/entities"

    payload: dict = {"name": name}
    if description:
        payload["description"] = description
    if version:
        payload["version"] = version
    if tags:
        payload["tags"] = list(tags)
    if license_id:
        payload["license"] = license_id

    result: dict = {}
    try:
        resp = requests.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "create bundle")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    console.print(f"[green]Bundle created successfully.[/green]")
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("ID", result["id"])
    table.add_row("Name", result["name"])
    table.add_row("Status", result.get("status", "draft"))
    if result.get("version"):
        table.add_row("Version", result["version"])
    if result.get("description"):
        table.add_row("Description", result["description"])
    if result.get("tags"):
        table.add_row("Tags", ", ".join(result["tags"]))
    if result.get("license"):
        table.add_row("License", result["license"])
    console.print(table)


# ---------------------------------------------------------------------------
# add-member sub-command
# ---------------------------------------------------------------------------


@bundle_group.command("add-member")
@click.argument("bundle_name", metavar="BUNDLE_NAME")
@click.argument("member_ref", metavar="MEMBER_REF")
def add_member_cmd(bundle_name: str, member_ref: str) -> None:
    """Add an artifact or context entity to a Bundle.

    BUNDLE_NAME is the name of the target Bundle.
    MEMBER_REF is either:

    \b
      * An artifact in ``type:name`` format (e.g. ``skill:canvas-design``)
      * A context entity prefixed with ``context:`` (e.g. ``context:my-rules``)

    \b
    Examples:
      skillmeat bundle add-member my-bundle skill:canvas-design
      skillmeat bundle add-member my-bundle command:git-commit
      skillmeat bundle add-member my-bundle context:project-guidelines
    """
    api_base = _api_base()
    bundle_id = _resolve_bundle_id(bundle_name)

    is_context = member_ref.startswith("context:")

    if is_context:
        # Context entity path — no tier enforcement (not an artifact type).
        context_name = member_ref[len("context:") :]
        if not context_name:
            console.print("[red]Error: 'context:' prefix requires a name.[/red]")
            sys.exit(1)

        context_entity_id = _resolve_context_entity_id(context_name)

        url = f"{api_base}/api/v1/bundles/entities/{bundle_id}/members"
        payload: dict = {
            "member_type": "context_entity",
            "context_entity_id": context_entity_id,
        }
    else:
        # Artifact path — validate tier before any further API calls.
        type_prefix = member_ref.split(":")[0] if ":" in member_ref else member_ref
        try:
            member_artifact_type = ArtifactType(type_prefix)
        except ValueError:
            member_artifact_type = None  # type: ignore[assignment]

        engine = TierEnforcementEngine()
        if member_artifact_type is not None:
            tier_result: ValidationResult = engine.validate_bundle_member(
                member_artifact_type
            )
        else:
            tier_result = ValidationResult(
                ok=False,
                error_code="TIER_VIOLATION",
                message=f"TIER_VIOLATION: Unknown artifact type '{type_prefix}' defaults to rejection",
            )

        if not tier_result.ok:
            click.echo(f"Error: {tier_result.message}", err=True)
            sys.exit(1)

        artifact_uuid = _resolve_artifact_uuid(member_ref)

        url = f"{api_base}/api/v1/bundles/entities/{bundle_id}/members"
        payload = {"member_type": "artifact", "artifact_uuid": artifact_uuid}

    result: dict = {}
    try:
        resp = requests.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
    except requests.exceptions.HTTPError as exc:
        status_code = exc.response.status_code if exc.response is not None else 0
        if status_code == 422:
            try:
                body = exc.response.json()
                detail = body.get("detail") or body.get("message") or str(exc)
            except Exception:
                detail = str(exc)
            console.print(f"[red]Error: Cannot add member — {detail}[/red]")
            console.print(
                "[yellow]Hint: Check artifact tier restrictions or bundle status.[/yellow]"
            )
            sys.exit(1)
        _handle_http_error(exc, "add member")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    if is_context:
        console.print(
            f"[green]Added context entity '{member_ref[len('context:'):]}' "
            f"(id: {payload['context_entity_id']}) to bundle '{bundle_name}'.[/green]"
        )
    else:
        console.print(
            f"[green]Added '{member_ref}' (uuid: {payload['artifact_uuid']}) "
            f"to bundle '{bundle_name}'.[/green]"
        )
    if result.get("added_at"):
        console.print(f"  Added at: {result['added_at']}")


# ---------------------------------------------------------------------------
# remove-member sub-command
# ---------------------------------------------------------------------------


@bundle_group.command("remove-member")
@click.argument("bundle_name", metavar="BUNDLE_NAME")
@click.argument("artifact_id", metavar="ARTIFACT_ID")
def remove_member_cmd(bundle_name: str, artifact_id: str) -> None:
    """Remove an artifact from a Bundle.

    BUNDLE_NAME is the name of the target Bundle.
    ARTIFACT_ID is the artifact identifier in ``type:name`` format
    (e.g. ``skill:canvas-design``).

    \b
    Examples:
      skillmeat bundle remove-member my-bundle skill:canvas-design
      skillmeat bundle remove-member my-bundle command:git-commit
    """
    api_base = _api_base()

    bundle_id = _resolve_bundle_id(bundle_name)
    artifact_uuid = _resolve_artifact_uuid(artifact_id)

    url = f"{api_base}/api/v1/bundles/entities/{bundle_id}/members/{artifact_uuid}"

    try:
        resp = requests.delete(url, timeout=30)
        resp.raise_for_status()
    except requests.exceptions.HTTPError as exc:
        status_code = exc.response.status_code if exc.response is not None else 0
        if status_code == 422:
            try:
                body = exc.response.json()
                detail = body.get("detail") or body.get("message") or str(exc)
            except Exception:
                detail = str(exc)
            console.print(f"[red]Error: Cannot remove member — {detail}[/red]")
            console.print(
                "[yellow]Hint: Published bundles may not allow member removal.[/yellow]"
            )
            sys.exit(1)
        _handle_http_error(exc, "remove member")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    console.print(
        f"[green]Removed '{artifact_id}' from bundle '{bundle_name}'.[/green]"
    )


# ---------------------------------------------------------------------------
# list sub-command
# ---------------------------------------------------------------------------


@bundle_group.command("list")
@click.option(
    "--status",
    "status",
    default=None,
    metavar="STATUS",
    type=click.Choice(["draft", "published", "archived"], case_sensitive=False),
    help="Filter bundles by lifecycle status.",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    default=False,
    help="Output results as JSON.",
)
def list_cmd(status: Optional[str], as_json: bool) -> None:
    """List Bundle entities.

    Displays all Bundles in the local collection.  Optionally filter by
    lifecycle status or request machine-readable JSON output.

    \b
    Examples:
      skillmeat bundle list
      skillmeat bundle list --status published
      skillmeat bundle list --json
    """
    api_base = _api_base()
    url = f"{api_base}/api/v1/bundles/entities"

    params: dict = {"page_size": 100}
    if status:
        params["status"] = status

    all_items: list = []
    data: dict = {}
    try:
        resp = requests.get(url, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        all_items = data.get("items", [])
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "list bundles")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    total = data.get("total", 0)
    page_size = data.get("page_size", 100)
    if total > page_size:
        pages = (total + page_size - 1) // page_size
        for page_num in range(2, pages + 1):
            try:
                p = dict(params)
                p["page"] = page_num
                r = requests.get(url, params=p, timeout=30)
                r.raise_for_status()
                all_items.extend(r.json().get("items", []))
            except Exception:
                break

    if as_json:
        click.echo(json.dumps(all_items, indent=2))
        return

    if not all_items:
        console.print("[dim]No bundles found.[/dim]")
        return

    table = Table(
        title=f"Bundles ({len(all_items)})",
        show_header=True,
        header_style="bold",
        box=None,
    )
    table.add_column("Name", style="cyan")
    table.add_column("Status")
    table.add_column("Version")
    table.add_column("Members", justify="right")
    table.add_column("Tags")
    table.add_column("ID", style="dim")

    for item in all_items:
        table.add_row(
            item.get("name", ""),
            item.get("status", ""),
            item.get("version") or "",
            str(item.get("member_count", 0)),
            ", ".join(item.get("tags") or []),
            item.get("id", "")[:12] + "...",
        )

    console.print(table)


# ---------------------------------------------------------------------------
# show sub-command
# ---------------------------------------------------------------------------


@bundle_group.command("show")
@click.argument("bundle_name", metavar="BUNDLE_NAME")
def show_cmd(bundle_name: str) -> None:
    """Show Bundle detail.

    Displays full metadata and member list for the named Bundle.

    \b
    Examples:
      skillmeat bundle show my-bundle
    """
    api_base = _api_base()

    bundle_id = _resolve_bundle_id(bundle_name)
    url = f"{api_base}/api/v1/bundles/entities/{bundle_id}"

    result: dict = {}
    try:
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        result = resp.json()
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "show bundle")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    # Metadata panel
    meta_table = Table(show_header=False, box=None, padding=(0, 1))
    meta_table.add_column("Field", style="bold")
    meta_table.add_column("Value")
    meta_table.add_row("ID", result.get("id", ""))
    meta_table.add_row("Name", result.get("name", ""))
    meta_table.add_row("Status", result.get("status", ""))
    if result.get("version"):
        meta_table.add_row("Version", result["version"])
    if result.get("description"):
        meta_table.add_row("Description", result["description"])
    if result.get("tags"):
        meta_table.add_row("Tags", ", ".join(result["tags"]))
    if result.get("license"):
        meta_table.add_row("License", result["license"])
    if result.get("homepage"):
        meta_table.add_row("Homepage", result["homepage"])
    if result.get("repository"):
        meta_table.add_row("Repository", result["repository"])
    meta_table.add_row("Created", result.get("created_at", ""))
    meta_table.add_row("Updated", result.get("updated_at", ""))
    if result.get("published_at"):
        meta_table.add_row("Published", result["published_at"])
    meta_table.add_row("Members", str(result.get("member_count", 0)))

    console.print(Panel(meta_table, title=f"Bundle: {bundle_name}", expand=False))

    # Members table — partition by member_type
    members = result.get("members") or []
    artifact_members = [
        m for m in members if m.get("member_type", "artifact") == "artifact"
    ]
    context_members = [m for m in members if m.get("member_type") == "context_entity"]

    if artifact_members:
        m_table = Table(
            title="Artifacts",
            show_header=True,
            header_style="bold",
            box=None,
        )
        m_table.add_column("Artifact UUID", style="dim")
        m_table.add_column("Tier", justify="right")
        m_table.add_column("Relationship")
        m_table.add_column("Added")
        for m in artifact_members:
            m_table.add_row(
                m.get("artifact_uuid", ""),
                str(m.get("artifact_tier", 0)),
                m.get("relationship_type", ""),
                m.get("added_at", ""),
            )
        console.print(m_table)

    if context_members:
        ce_table = Table(
            title="Context Entities",
            show_header=True,
            header_style="bold",
            box=None,
        )
        ce_table.add_column("Entity ID", style="dim")
        ce_table.add_column("Name")
        ce_table.add_column("Type")
        ce_table.add_column("Added")
        for m in context_members:
            ce_table.add_row(
                m.get("context_entity_id", ""),
                m.get("name") or "",
                m.get("entity_type") or "",
                m.get("added_at", ""),
            )
        console.print(ce_table)

    if not members:
        console.print("[dim]No members.[/dim]")


# ---------------------------------------------------------------------------
# version sub-command
# ---------------------------------------------------------------------------


@bundle_group.command("version")
@click.argument("bundle_name", metavar="BUNDLE_NAME")
@click.argument("semver", metavar="SEMVER")
def version_cmd(bundle_name: str, semver: str) -> None:
    """Set Bundle version.

    Updates the semantic version of the named Bundle to SEMVER
    (e.g. ``1.2.3``).  The version must follow SemVer 2.0 format.

    \b
    Examples:
      skillmeat bundle version my-bundle 1.0.0
      skillmeat bundle version my-bundle 2.0.0-beta.1
    """
    if not _SEMVER_RE.match(semver):
        console.print(
            f"[red]Error: '{semver}' is not a valid SemVer 2.0 version "
            f"(expected format X.Y.Z or X.Y.Z-pre+build).[/red]"
        )
        sys.exit(1)

    api_base = _api_base()
    bundle_id = _resolve_bundle_id(bundle_name)
    url = f"{api_base}/api/v1/bundles/entities/{bundle_id}"

    result: dict = {}
    try:
        resp = requests.patch(
            url,
            json={"version": semver},
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "update bundle version")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    console.print(
        f"[green]Bundle '{bundle_name}' version set to {result.get('version', semver)}.[/green]"
    )


# ---------------------------------------------------------------------------
# publish sub-command
# ---------------------------------------------------------------------------


@bundle_group.command("publish")
@click.argument("bundle_name", metavar="BUNDLE_NAME")
def publish_cmd(bundle_name: str) -> None:
    """Publish a Bundle.

    Transitions the named Bundle to ``published`` status, making it
    available in the marketplace catalog.

    \b
    Examples:
      skillmeat bundle publish my-bundle
    """
    api_base = _api_base()

    bundle_id = _resolve_bundle_id(bundle_name)

    # Fetch current state to show member count before confirming
    detail_url = f"{api_base}/api/v1/bundles/entities/{bundle_id}"
    try:
        detail_resp = requests.get(detail_url, timeout=30)
        detail_resp.raise_for_status()
        detail = detail_resp.json()
        member_count = detail.get("member_count", 0)
    except requests.exceptions.RequestException:
        detail = {}
        member_count = 0

    if member_count > 0:
        if not click.confirm(
            f"Publish bundle '{bundle_name}' with {member_count} member(s)?",
            default=True,
        ):
            console.print("[yellow]Publish cancelled.[/yellow]")
            sys.exit(0)

    url = f"{api_base}/api/v1/bundles/entities/{bundle_id}/publish"
    result: dict = {}
    try:
        resp = requests.post(url, timeout=30)
        resp.raise_for_status()
        result = resp.json()
    except requests.exceptions.HTTPError as exc:
        _handle_http_error(exc, "publish bundle")
    except requests.exceptions.RequestException:
        _handle_connection_error(api_base)

    console.print(f"[green]Bundle '{bundle_name}' published successfully.[/green]")
    if result.get("published_at"):
        console.print(f"  Published at: {result['published_at']}")


# ---------------------------------------------------------------------------
# export sub-command
# ---------------------------------------------------------------------------


@bundle_group.command("export")
@click.argument("bundle_name", metavar="BUNDLE_NAME")
@click.option(
    "--output",
    "-o",
    "output",
    default=None,
    metavar="PATH",
    type=click.Path(),
    help="Output path for the .skillmeat-pack archive.  Defaults to <BUNDLE_NAME>.skillmeat-pack.",
)
def export_cmd(bundle_name: str, output: Optional[str]) -> None:  # noqa: ARG001
    """Export Bundle to .skillmeat-pack.

    Creates a portable .skillmeat-pack archive containing all Bundle
    metadata and member artifacts.  The archive can be shared and
    imported on another machine using ``bundle import``.

    \b
    Examples:
      skillmeat bundle export my-bundle
      skillmeat bundle export my-bundle --output /tmp/my-bundle.skillmeat-pack
    """
    console.print(
        Panel(
            "[yellow]Pack format not yet implemented (Phase 3).[/yellow]\n"
            "Export will be available in a future release.",
            title="bundle export",
            expand=False,
        )
    )


# ---------------------------------------------------------------------------
# import sub-command (import is a Python keyword; registered as 'import')
# ---------------------------------------------------------------------------


@bundle_group.command("import")
@click.argument("path", metavar="PATH", type=click.Path())
@click.option(
    "--dry-run",
    "dry_run",
    is_flag=True,
    default=False,
    help="Preview what would be imported without making any changes.",
)
@click.option(
    "--conflict-strategy",
    "conflict_strategy",
    default="skip",
    metavar="STRATEGY",
    type=click.Choice(["skip", "overwrite", "rename"], case_sensitive=False),
    show_default=True,
    help="Strategy for handling name conflicts: skip, overwrite, or rename.",
)
def import_bundle(path: str, dry_run: bool, conflict_strategy: str) -> None:
    """Import a .skillmeat-pack.

    Reads the archive at PATH and installs the contained Bundle and its
    member artifacts into the local collection.

    Use --dry-run to inspect what would be imported without writing any
    files.  Use --conflict-strategy to control behaviour when an artifact
    with the same name already exists.

    \b
    Examples:
      skillmeat bundle import my-bundle.skillmeat-pack
      skillmeat bundle import my-bundle.skillmeat-pack --dry-run
      skillmeat bundle import my-bundle.skillmeat-pack --conflict-strategy overwrite
    """
    console.print(
        Panel(
            "[yellow]Import not yet implemented (Phase 3).[/yellow]\n"
            "Import will be available in a future release.",
            title="bundle import",
            expand=False,
        )
    )


# ---------------------------------------------------------------------------
# deploy sub-command
# ---------------------------------------------------------------------------

#: Context entity types that map to known deploy paths inside .claude/
_CONTEXT_ENTITY_PATH_MAP: dict = {
    "spec_file": ".claude/specs",
    "rule_file": ".claude/rules",
    "doc_file": ".claude/context",
}

#: Default fallback deploy directory for context entities with unknown types.
_CONTEXT_ENTITY_DEFAULT_DIR = ".claude/context"

#: Artifact type → subdirectory under .claude/ (mirrors the existing deploy logic).
_ARTIFACT_TYPE_DIR_MAP: dict = {
    "skill": "skills",
    "command": "commands",
    "agent": "agents",
    "hook": "hooks",
    "mcp_server": "mcp",
}


def _deploy_artifact_files(
    project_dir: "Path",
    artifact_name: str,
    artifact_type: str,
    file_content_map: "dict[str, str]",
    dry_run: bool,
) -> "tuple[list[str], Optional[str]]":
    """Write all files in *file_content_map* to *project_dir*.

    Returns ``(written_paths, error_message)`` where *error_message* is
    ``None`` on success.  In dry-run mode no files are written and
    *written_paths* contains the paths that *would* be written.
    """
    type_subdir = _ARTIFACT_TYPE_DIR_MAP.get(artifact_type, artifact_type)
    base_dir = project_dir / ".claude" / type_subdir / artifact_name

    written: list[str] = []
    try:
        for rel_path, content in file_content_map.items():
            # Normalise the relative path — strip any leading ./ or /
            while rel_path.startswith("./"):
                rel_path = rel_path[2:]
            rel_path = rel_path.lstrip("/")

            dest = base_dir / rel_path
            written.append(str(dest.relative_to(project_dir)))
            if not dry_run:
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_text(content, encoding="utf-8")
    except OSError as exc:
        return written, str(exc)

    return written, None


def _deploy_context_entity(
    project_dir: "Path",
    entity: "ResolvedContextEntity",
    dry_run: bool,
) -> "tuple[str, Optional[str]]":
    """Write a context entity's content to *project_dir*.

    Returns ``(dest_path_str, error_message)``.
    """
    content = entity.content
    if not content:
        # Nothing to write — treat as a skip (no error).
        return "", None

    # Determine destination path.
    if entity.path_pattern:
        # path_pattern is project-relative (may contain placeholders — use as-is).
        pattern = entity.path_pattern
        while pattern.startswith("./"):
            pattern = pattern[2:]
        dest = project_dir / pattern.lstrip("/")
    else:
        # Fall back to type-based directory.
        type_dir = _CONTEXT_ENTITY_PATH_MAP.get(
            entity.entity_type, _CONTEXT_ENTITY_DEFAULT_DIR
        )
        # Use entity name as filename; sanitise any path separators.
        safe_name = entity.name.replace("/", "_").replace("\\", "_")
        dest = project_dir / type_dir / safe_name

    dest_rel = str(dest.relative_to(project_dir))
    try:
        if not dry_run:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(content, encoding="utf-8")
    except OSError as exc:
        return dest_rel, str(exc)

    return dest_rel, None


@bundle_group.command("deploy")
@click.argument("bundle_name", metavar="BUNDLE_NAME_OR_UUID")
@click.option(
    "--project",
    "project_path",
    default=None,
    metavar="PATH",
    type=click.Path(file_okay=False, resolve_path=True),
    help="Target project directory.  Defaults to the current working directory.",
)
@click.option(
    "--dry-run",
    "dry_run",
    is_flag=True,
    default=False,
    help="List what would be deployed without writing any files.",
)
def deploy_cmd(bundle_name: str, project_path: Optional[str], dry_run: bool) -> None:
    """Deploy all members of a Bundle to a project directory.

    Resolves BUNDLE_NAME_OR_UUID through the dependency graph and writes
    each artifact's files into <PROJECT>/.claude/<type>/<name>/ and each
    context entity's content to the path specified by its path_pattern (or
    a sensible default under <PROJECT>/.claude/).

    Use --dry-run to preview the full deployment plan without writing any
    files.

    Exit code is non-zero if any member fails to deploy.  Already-deployed
    members are NOT rolled back on failure.

    \b
    Examples:
      skillmeat bundle deploy my-bundle
      skillmeat bundle deploy my-bundle --project /path/to/project
      skillmeat bundle deploy my-bundle --dry-run
    """

    project_dir = Path(project_path) if project_path else Path.cwd()

    # ------------------------------------------------------------------
    # Resolve the bundle ID (accepts name or UUID).
    # ------------------------------------------------------------------
    bundle_id = bundle_name
    # If it doesn't look like a UUID (no hyphens / wrong length), resolve by name.
    _UUID_RE = re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
        re.IGNORECASE,
    )
    if not _UUID_RE.match(bundle_name):
        bundle_id = _resolve_bundle_id(bundle_name)

    # ------------------------------------------------------------------
    # Resolve the bundle dependency graph via BundleResolver.
    # ------------------------------------------------------------------
    try:
        with get_session() as session:
            resolver = BundleResolver()
            result = resolver.resolve(bundle_id, session)
    except ValueError as exc:
        console.print(f"[red]Error: {exc}[/red]")
        sys.exit(1)
    except BundleResolutionError as exc:
        console.print(f"[red]Error resolving bundle '{bundle_name}': {exc}[/red]")
        sys.exit(1)
    except Exception as exc:
        console.print(
            f"[red]Unexpected error resolving bundle '{bundle_name}': {exc}[/red]"
        )
        sys.exit(1)

    total_members = len(result.artifacts) + len(result.context_entities)
    if total_members == 0:
        console.print(
            f"[yellow]Warning: Bundle '{bundle_name}' has no members to deploy.[/yellow]"
        )
        sys.exit(0)

    if dry_run:
        console.print(
            f"[dim]Dry run — {total_members} member(s) would be deployed to "
            f"[cyan]{project_dir}[/cyan][/dim]"
        )

    # ------------------------------------------------------------------
    # Build status table and deploy each member.
    # ------------------------------------------------------------------
    table = Table(
        title=f"Bundle deploy: {bundle_name}",
        show_header=True,
        header_style="bold",
        box=None,
        padding=(0, 1),
    )
    table.add_column("Type", style="dim")
    table.add_column("Name")
    table.add_column("Files", justify="right")
    table.add_column("Status")
    table.add_column("Detail")

    any_failure = False

    # --- Artifacts -------------------------------------------------------
    for artifact in result.artifacts:
        if not artifact.file_content_map:
            table.add_row(
                artifact.type,
                artifact.name,
                "0",
                "[yellow]skipped[/yellow]",
                "no files in file_content_map",
            )
            continue

        written_paths, error = _deploy_artifact_files(
            project_dir,
            artifact.name,
            artifact.type,
            artifact.file_content_map,
            dry_run,
        )
        file_count = str(len(written_paths))

        if error:
            any_failure = True
            table.add_row(
                artifact.type,
                artifact.name,
                file_count,
                "[red]failed[/red]",
                error,
            )
        else:
            action = "would deploy" if dry_run else "deployed"
            table.add_row(
                artifact.type,
                artifact.name,
                file_count,
                f"[green]{action}[/green]",
                "",
            )

    # --- Context entities ------------------------------------------------
    for entity in result.context_entities:
        if not entity.content:
            table.add_row(
                entity.entity_type,
                entity.name,
                "0",
                "[yellow]skipped[/yellow]",
                "no content",
            )
            continue

        dest_path, error = _deploy_context_entity(project_dir, entity, dry_run)
        if error:
            any_failure = True
            table.add_row(
                entity.entity_type,
                entity.name,
                "1",
                "[red]failed[/red]",
                error,
            )
        else:
            action = "would deploy" if dry_run else "deployed"
            table.add_row(
                entity.entity_type,
                entity.name,
                "1",
                f"[green]{action}[/green]",
                dest_path,
            )

    console.print(table)

    if any_failure:
        console.print(
            "[red]One or more members failed to deploy.  "
            "Already-written files have NOT been rolled back.[/red]"
        )
        sys.exit(1)

    if not dry_run:
        console.print(
            f"[green]Bundle '{bundle_name}' deployed successfully to "
            f"[cyan]{project_dir}[/cyan].[/green]"
        )
