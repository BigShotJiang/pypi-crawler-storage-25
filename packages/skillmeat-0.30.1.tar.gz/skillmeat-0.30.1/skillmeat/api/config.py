"""Configuration management for SkillMeat API service.

This module provides environment-based configuration using Pydantic Settings.
Supports both development and production environments with secure defaults.
"""

import logging
import os
import warnings
from enum import Enum
from pathlib import Path
from typing import List, Optional

from pydantic import AliasChoices, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Environment(str, Enum):
    """Application environment types."""

    DEVELOPMENT = "development"
    PRODUCTION = "production"
    TESTING = "testing"


class APISettings(BaseSettings):
    """API service configuration.

    Configuration is loaded from environment variables with SKILLMEAT_ prefix.
    Example: SKILLMEAT_ENV=production, SKILLMEAT_PORT=8080

    For development, a .env file can be used in the project root.
    """

    model_config = SettingsConfigDict(
        env_prefix="SKILLMEAT_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        populate_by_name=True,
    )

    # Environment
    env: Environment = Field(
        default=Environment.DEVELOPMENT,
        description="Application environment (development, production, testing)",
    )

    # Edition — controls repository implementation selection (local vs enterprise)
    edition: str = Field(
        default="local",
        description="Deployment edition: 'local' (default) or 'enterprise'. "
        "Used by factory providers to choose between repository implementations. "
        "Configurable via SKILLMEAT_EDITION env var.",
    )

    # Server configuration
    host: str = Field(
        default="127.0.0.1",
        description="Host address to bind the server",
    )

    port: int = Field(
        default=8080,
        ge=1024,
        le=65535,
        description="Port number to bind the server",
    )

    reload: bool = Field(
        default=False,
        description="Enable auto-reload on code changes (dev only)",
    )

    workers: int = Field(
        default=1,
        ge=1,
        le=8,
        description="Number of worker processes",
    )

    # API configuration
    api_version: str = Field(
        default="v1",
        description="API version prefix",
    )

    api_title: str = Field(
        default="SkillMeat API",
        description="API title for OpenAPI documentation",
    )

    api_description: str = Field(
        default="REST API for SkillMeat collection manager",
        description="API description for OpenAPI documentation",
    )

    # CORS configuration
    cors_enabled: bool = Field(
        default=True,
        description="Enable CORS middleware",
    )

    cors_origins: List[str] = Field(
        default=[
            "http://localhost:3000",
            "http://localhost:3001",
            "http://localhost:5173",
            "http://localhost:8080",
        ],
        description="Allowed CORS origins",
    )

    cors_allow_credentials: bool = Field(
        default=True,
        description="Allow credentials in CORS requests",
    )

    cors_allow_methods: List[str] = Field(
        default=["*"],
        description="Allowed HTTP methods for CORS",
    )

    cors_allow_headers: List[str] = Field(
        default=["*"],
        description="Allowed headers for CORS",
    )

    # Logging configuration
    log_level: str = Field(
        default="INFO",
        description="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
    )

    log_format: str = Field(
        default="json",
        description="Log format (json or text)",
    )

    # Collection configuration
    collection_dir: Optional[Path] = Field(
        default=None,
        description="Override default collection directory (defaults to ~/.skillmeat/collections)",
    )

    # Security
    api_key_enabled: bool = Field(
        default=False,
        description="Enable API key authentication",
    )

    api_key: Optional[str] = Field(
        default=None,
        description="API key for authentication (if enabled)",
    )

    # Token authentication
    auth_enabled: bool = Field(
        default=False,
        description="Require bearer token authentication for API routes",
    )

    # Auth provider selection (AUTH-007)
    # Valid values: "local" (LocalAuthProvider) or "clerk" (ClerkAuthProvider)
    auth_provider: str = Field(
        default="local",
        description=(
            "Authentication provider to use. "
            "Valid values: 'local' (default, LocalAuthProvider) or "
            "'clerk' (ClerkAuthProvider, requires CLERK_JWKS_URL and CLERK_ISSUER). "
            "Configurable via SKILLMEAT_AUTH_PROVIDER env var."
        ),
    )

    # Clerk authentication config (only required when auth_provider="clerk")
    clerk_jwks_url: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices("CLERK_JWKS_URL", "SKILLMEAT_CLERK_JWKS_URL"),
        description=(
            "Clerk JWKS endpoint URL for JWT public key discovery. "
            "Required when auth_provider='clerk'. "
            "Configurable via CLERK_JWKS_URL env var."
        ),
    )

    clerk_issuer: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices("CLERK_ISSUER", "SKILLMEAT_CLERK_ISSUER"),
        description=(
            "Expected JWT issuer claim for Clerk tokens. "
            "Required when auth_provider='clerk'. "
            "Configurable via CLERK_ISSUER env var."
        ),
    )

    clerk_audience: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices("CLERK_AUDIENCE", "SKILLMEAT_CLERK_AUDIENCE"),
        description=(
            "Expected JWT audience claim for Clerk tokens. "
            "When set, the aud claim in incoming JWTs must match this value. "
            "Configurable via CLERK_AUDIENCE or SKILLMEAT_CLERK_AUDIENCE env var."
        ),
    )

    # Enterprise PAT authentication (ENT-3.4)
    enterprise_pat_secret: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices(
            "SKILLMEAT_ENTERPRISE_PAT_SECRET",
            "ENTERPRISE_PAT_SECRET",
        ),
        description=(
            "Shared secret used to authenticate enterprise clients via "
            "``Authorization: Bearer <token>``.  Must be set before the "
            "enterprise download endpoint will accept requests.  "
            "Primary env var: ``SKILLMEAT_ENTERPRISE_PAT_SECRET``.  "
            "Legacy alias ``ENTERPRISE_PAT_SECRET`` is also accepted for "
            "backward compatibility but will emit a deprecation warning."
        ),
    )

    # Rate limiting
    rate_limit_enabled: bool = Field(
        default=False,
        description="Enable rate limiting",
    )

    rate_limit_requests: int = Field(
        default=100,
        ge=1,
        description="Maximum requests per minute",
    )

    # Discovery feature flags
    enable_auto_discovery: bool = Field(
        default=True,
        description="Enable artifact auto-discovery feature",
    )

    enable_auto_population: bool = Field(
        default=True,
        description="Enable automatic GitHub metadata population",
    )

    discovery_cache_ttl: int = Field(
        default=3600,
        ge=0,
        description="Cache TTL for discovery metadata in seconds (default: 1 hour)",
    )

    github_token: Optional[str] = Field(
        default=None,
        description="GitHub personal access token for higher API rate limits (5000/hr vs 60/hr)",
    )

    # Composite artifact feature flags
    composite_artifacts_enabled: bool = Field(
        default=True,
        description="Enable composite artifact detection during discovery. "
        "When disabled, discover_artifacts() always performs flat discovery "
        "and skips detect_composites(). "
        "Configurable via SKILLMEAT_COMPOSITE_ARTIFACTS_ENABLED env var.",
    )

    # Deployment Sets feature flag
    deployment_sets_enabled: bool = Field(
        default=True,
        description="Enable deployment sets feature. "
        "When disabled, all /api/v1/deployment-sets endpoints return 404. "
        "Configurable via SKILLMEAT_DEPLOYMENT_SETS_ENABLED env var.",
    )

    # Memory & Context Intelligence System feature flags
    memory_context_enabled: bool = Field(
        default=True,
        description="Enable Memory & Context Intelligence System (memory items, context modules, context packing)",
    )

    # Workflow Orchestration Engine feature flag
    workflow_engine_enabled: bool = Field(
        default=True,
        description="Enable Workflow Orchestration Engine. "
        "When disabled, all /api/v1/workflows and /api/v1/workflow-executions endpoints return 404 "
        "and CLI workflow commands display a 'coming soon' message. "
        "Configurable via SKILLMEAT_WORKFLOW_ENGINE_ENABLED env var.",
    )

    workflow_artifact_sync_enabled: bool = Field(
        default=True,
        description="Enable workflow-artifact sync. "
        "Configurable via SKILLMEAT_WORKFLOW_ARTIFACT_SYNC_ENABLED env var.",
    )

    # Modular Content Architecture feature flag (CECO-4.1)
    modular_content_architecture: bool = Field(
        default=True,
        description=(
            "Enable Modular Content Architecture for context entities. "
            "When enabled, create/update endpoints split incoming content into "
            "platform-agnostic core_content and an assembled `content` output. "
            "The deploy endpoint assembles platform-specific content at deploy "
            "time via skillmeat.core.content_assembly.assemble_content(). "
            "Configurable via SKILLMEAT_MODULAR_CONTENT_ARCHITECTURE env var."
        ),
    )

    memory_auto_extract: bool = Field(
        default=True,
        description="Enable automatic memory extraction from conversations (Phase 5 feature)",
    )

    marketplace_import_scan_delay_seconds: float = Field(
        default=5.0,
        description="Delay in seconds between staggered discovery scans after source import. "
        "Controls the gap between each background rescan to avoid API flooding.",
        ge=0.0,
        le=300.0,
    )

    # SkillBOM feature flag (skillbom-attestation)
    skillbom_enabled: bool = Field(
        default=True,
        description="Enable SkillBOM generation and attestation features. "
        "When disabled, all /api/v1/bom endpoints return 404 and CLI bom commands "
        "display a 'coming soon' message. "
        "Configurable via SKILLMEAT_SKILLBOM_ENABLED env var.",
    )

    # Enterprise Governance feature flag (enterprise-governance-3-tier)
    enterprise_governance_enabled: bool = Field(
        default=False,
        description="Enable enterprise governance features including hierarchy-aware sync, "
        "forced rollout cascades, and enterprise scope enforcement. "
        "Env var: SKILLMEAT_ENTERPRISE_GOVERNANCE_ENABLED.",
    )

    # Team Sync Dashboard feature flag (enterprise-unified-sync-ux)
    team_sync_dashboard_enabled: bool = Field(
        default=True,
        description="Enable Team Sync Dashboard endpoints for enterprise edition. "
        "When enabled, /api/v1/enterprise/teams/* endpoints surface team-level "
        "sync health for team_admin and system_admin roles. "
        "Configurable via SKILLMEAT_TEAM_SYNC_DASHBOARD_ENABLED env var.",
    )

    # Compositions page feature flag (HTAM)
    compositions_page_enabled: bool = Field(
        default=True,
        description="Enable the Compositions page grouping higher-tier artifacts (Bundles, Deployment Sets, Scaffold Templates).",
    )

    # Admin Sync Management feature flag (enterprise-unified-sync-ux)
    admin_sync_management_enabled: bool = Field(
        default=True,
        description="Enable Admin Sync Management endpoints for enterprise edition. "
        "When enabled, /api/v1/enterprise/admin/sync/* endpoints surface org-wide "
        "sync health, compliance audits, operation logs, and propagation controls "
        "for the enterprise_admin role. "
        "Configurable via SKILLMEAT_ADMIN_SYNC_MANAGEMENT_ENABLED env var.",
    )

    # Cascade Policy Configuration feature flag (enterprise-unified-sync-ux Phase 4, DS-4)
    cascade_policy_enabled: bool = Field(
        default=True,
        description="Enable Cascade Policy CRUD and resolution endpoints for enterprise "
        "edition. When enabled, /api/v1/enterprise/cascade-policies/* endpoints allow "
        "enterprise admins to configure org-level, per-artifact, and per-team cascade "
        "policies governing how tier propagation behaves across the enterprise hierarchy. "
        "Configurable via SKILLMEAT_CASCADE_POLICY_ENABLED env var.",
    )

    # Enterprise Context Sync feature flag (feat-enterprise-context-sync)
    enterprise_sync_enabled: bool = Field(
        default=False,
        description="Enable enterprise context synchronization service. "
        "When enabled, context sync endpoints in enterprise edition are served "
        "by EnterpriseContextSyncService (DB-backed) instead of returning 501. "
        "Has no effect in local edition. "
        "Configurable via SKILLMEAT_ENTERPRISE_SYNC_ENABLED env var.",
    )

    # Bundle Authoring feature flag (BAV1-017)
    bundle_authoring_enabled: bool = Field(
        default=True,
        description="Enable Bundle entity CRUD endpoints. "
        "When disabled, all /api/v1/bundles/entities* endpoints return 404. "
        "Configurable via SKILLMEAT_BUNDLE_AUTHORING_ENABLED env var.",
    )

    # IDP service-to-service authentication (backstage-plugin-v2)
    idp_service_token: Optional[str] = Field(
        default=None,
        description=(
            "Shared secret for service-to-service authentication on IDP endpoints. "
            "When set, all /integrations/idp/* requests must supply a matching "
            "``X-SkillMeat-Service-Token`` header.  When unset, the check is "
            "skipped (permissive / dev-demo mode). "
            "Configurable via SKILLMEAT_IDP_SERVICE_TOKEN env var."
        ),
    )

    # IDP integration feature flags (backstage-plugin-v2)
    idp_bundle_resolution_enabled: bool = Field(
        default=False,
        description="Enable bundle resolution in the IDP scaffold endpoint. "
        "When disabled, POST /integrations/idp/scaffold rejects 'bundle:*' target IDs "
        "with 422 feature_disabled. "
        "Configurable via SKILLMEAT_IDP_BUNDLE_RESOLUTION_ENABLED env var.",
    )

    idp_drift_detection_enabled: bool = Field(
        default=False,
        description="Enable IDP drift detection features. "
        "Configurable via SKILLMEAT_IDP_DRIFT_DETECTION_ENABLED env var.",
    )

    idp_content_drift_enabled: bool = Field(
        default=False,
        description="Enable IDP content drift tracking features. "
        "Configurable via SKILLMEAT_IDP_CONTENT_DRIFT_ENABLED env var.",
    )

    # Version History UI feature flag (artifact-version-history-restore)
    version_history_ui_enabled: bool = Field(
        default=True,
        description="Enable the version history UI (artifact history tab and admin version "
        "management page). "
        "When enabled, the History tab on artifact modals and the /admin/versions page "
        "become accessible. "
        "Configurable via SKILLMEAT_VERSION_HISTORY_UI_ENABLED env var.",
        validation_alias=AliasChoices(
            "SKILLMEAT_VERSION_HISTORY_UI_ENABLED",
            "VERSION_HISTORY_UI_ENABLED",
        ),
    )

    # DVCS CAS storage feature flag (dvcs-v1)
    dvcs_cas_enabled: bool = Field(
        default=True,
        description=(
            "Enable Content-Addressed Storage (CAS) write path for new ArtifactVersion "
            "rows.  When True, version creation routes through CASService (blob upsert + "
            "content_tree JSON).  When False (default), the legacy content_payload inline "
            "storage path is used and existing behaviour is preserved exactly.  "
            "Configurable via DVCS_CAS_ENABLED env var."
        ),
        validation_alias=AliasChoices(
            "SKILLMEAT_DVCS_CAS_ENABLED",
            "DVCS_CAS_ENABLED",
        ),
    )

    # Modal vertical sidebar UI feature flag
    modal_vertical_sidebar_enabled: bool = Field(
        default=True,
        description="Enable vertical sidebar tabs in artifact modal. "
        "When enabled, the artifact operations modal renders tabs in a vertical sidebar "
        "layout instead of the default horizontal tab bar. "
        "Configurable via SKILLMEAT_MODAL_VERTICAL_SIDEBAR_ENABLED env var.",
    )

    # SAM telemetry ingestion feature flag (integrations/sam-backstage-telemetry-integration)
    sam_telemetry_ingestion_enabled: bool = Field(
        default=False,
        description="Enable SAM telemetry ingestion endpoints "
        "(POST /analytics/execution-outcomes and POST /analytics/project-rollups). "
        "When disabled, those routes are not registered and return 404. "
        "Configurable via SKILLMEAT_SAM_TELEMETRY_INGESTION_ENABLED env var.",
    )

    # DVCS Signature Verification feature flag (DVCS-4.5)
    dvcs_signature_verification: bool = Field(
        default=True,
        description=(
            "Enable DVCS signature verification and cryptographic governance features. "
            "When enabled, the /api/v1/governance endpoints become available for "
            "admin users to perform hard updates, compliance checks, and version signing. "
            "When disabled, all governance endpoints return 404. "
            "Configurable via SKILLMEAT_DVCS_SIGNATURE_VERIFICATION env var."
        ),
        validation_alias=AliasChoices(
            "SKILLMEAT_DVCS_SIGNATURE_VERIFICATION",
            "DVCS_SIGNATURE_VERIFICATION",
        ),
    )

    # DVCS BOM Trailer Injection feature flag (DVCS-6.2)
    dvcs_bom_trailer_injection: bool = Field(
        default=False,
        description=(
            "Enable automatic injection of SkillBOM-Ref trailers into git commit messages. "
            "When enabled, the prepare-commit-msg hook will append a SkillBOM-Ref: <bom_hash> "
            "trailer to commits in project directories with active SkillBOM snapshots. "
            "This provides permanent traceability between commits and BOM states. "
            "Configurable via SKILLMEAT_DVCS_BOM_TRAILER_INJECTION env var."
        ),
        validation_alias=AliasChoices(
            "SKILLMEAT_DVCS_BOM_TRAILER_INJECTION",
            "DVCS_BOM_TRAILER_INJECTION",
        ),
    )

    # DVCS Phase 3 — FQAN resolution ambiguity policy (DVCS-3.2)
    fqan_ambiguity_policy: str = Field(
        default="warn-and-return-closest",
        description=(
            "FQAN resolution ambiguity policy used by FQANResolver when a bare "
            "artifact name matches candidates in multiple collection tiers. "
            "Valid values: "
            "'warn-and-return-closest' (default) — return the closest-tier match "
            "and emit a warning; "
            "'error' — raise AmbiguousFQANError when multiple tiers match; "
            "'return-all' — return all candidates from all tiers. "
            "Configurable via SKILLMEAT_FQAN_AMBIGUITY_POLICY env var."
        ),
    )

    # Diff operation configuration
    diff_exclude_dirs: List[str] = Field(
        default=[
            ".git",
            "node_modules",
            "__pycache__",
            ".venv",
            "venv",
            ".tox",
            ".pytest_cache",
            ".mypy_cache",
            "dist",
            "build",
            ".next",
            ".turbo",
        ],
        description="Directories to exclude from artifact diff operations. "
        "Files inside these directories are skipped during collection/project/upstream diff comparisons. "
        "Add patterns like 'vendor' or '.cache' for your environment.",
    )

    # DVCS CCDash Circuit Breaker feature flag (DVCS-6.3)
    dvcs_ccdash_circuit_breaker: bool = Field(
        default=False,
        description=(
            "Enable CCDash webhook-driven circuit breaker for automated rollback. "
            "When enabled, POST /api/v1/webhooks/ccdash becomes available to receive "
            "workflow effectiveness degradation notifications and trigger automatic "
            "bundle rollbacks when thresholds are breached. "
            "Configurable via SKILLMEAT_DVCS_CCDASH_CIRCUIT_BREAKER env var."
        ),
        validation_alias=AliasChoices(
            "SKILLMEAT_DVCS_CCDASH_CIRCUIT_BREAKER",
            "DVCS_CCDASH_CIRCUIT_BREAKER",
        ),
    )

    # CCDash webhook HMAC secret for signature verification
    ccdash_webhook_secret: Optional[str] = Field(
        default=None,
        description=(
            "HMAC-SHA256 shared secret for CCDash webhook signature verification. "
            "When set, all POST /api/v1/webhooks/ccdash requests must include a valid "
            "X-CCDash-Signature header with sha256=<hmac_digest> signature. "
            "When unset, signature verification is skipped (dev/testing only). "
            "Configurable via SKILLMEAT_CCDASH_WEBHOOK_SECRET env var."
        ),
        validation_alias=AliasChoices(
            "SKILLMEAT_CCDASH_WEBHOOK_SECRET",
            "CCDASH_WEBHOOK_SECRET",
        ),
    )

    # CCDash circuit breaker threshold (0.0-1.0)
    ccdash_rollback_threshold: float = Field(
        default=0.75,
        ge=0.0,
        le=1.0,
        description=(
            "Workflow effectiveness threshold below which automatic rollback is triggered. "
            "CCDash webhook payloads with workflow_effectiveness < threshold will "
            "initiate a rollback to the previous bundle commit. "
            "Range: 0.0-1.0, default: 0.75 (trigger rollback when effectiveness drops below 75%). "
            "Configurable via SKILLMEAT_CCDASH_ROLLBACK_THRESHOLD env var."
        ),
    )

    # DVCS Hard Update Enforcement feature flag (DVCS-6.4)
    dvcs_hard_update_enforcement: bool = Field(
        default=False,
        description=(
            "Enable hard update enforcement with GitOps PR automation. "
            "When enabled, projects with linked GitHub repositories will receive "
            "automated pull requests when upstream artifacts are updated and "
            "hard update policies are violated. "
            "Configurable via SKILLMEAT_DVCS_HARD_UPDATE_ENFORCEMENT env var."
        ),
        validation_alias=AliasChoices(
            "SKILLMEAT_DVCS_HARD_UPDATE_ENFORCEMENT",
            "DVCS_HARD_UPDATE_ENFORCEMENT",
        ),
    )

    # Redis Configuration for Compliance Gate caching (DVCS-6.5)
    redis_host: str = Field(
        default="localhost",
        description="Redis server hostname for compliance gate caching",
    )

    redis_port: int = Field(
        default=6379,
        ge=1,
        le=65535,
        description="Redis server port",
    )

    redis_db: int = Field(
        default=0,
        ge=0,
        le=15,
        description="Redis database number (0-15)",
    )

    redis_password: Optional[str] = Field(
        default=None,
        description="Redis password (if authentication enabled)",
    )

    redis_enabled: bool = Field(
        default=False,
        description="Enable Redis for compliance gate caching and other features",
    )

    # Git Connection Decoupling — credential store feature flag (GCD-2.10)
    git_credentials_enabled: bool = Field(
        default=False,
        description="Enable git credential store for per-connection token management. "
        "When enabled, the /api/v1/git-credentials endpoints are served and "
        "TokenResolverService walks the full five-level fallback chain. "
        "Configurable via SKILLMEAT_GIT_CREDENTIALS_ENABLED env var.",
    )

    # Sync Capture feature flags and configuration (dvcs-unified-sync)
    sync_capture_enabled: bool = Field(
        default=True,
        description=(
            "Master feature flag for the Sync Capture system. "
            "When False (default), no sync capture activity occurs and all "
            "sync_capture_* sub-settings are ignored. "
            "Configurable via SKILLMEAT_SYNC_CAPTURE_ENABLED env var."
        ),
    )

    sync_capture_quiet_seconds: int = Field(
        default=30,
        ge=5,
        le=300,
        description=(
            "Debounce quiet window in seconds. After the last filesystem event, "
            "the capture engine waits this many seconds of inactivity before "
            "triggering a sync capture. "
            "Range: 5–300 seconds. Default: 30 seconds. "
            "Configurable via SKILLMEAT_SYNC_CAPTURE_QUIET_SECONDS env var."
        ),
    )

    sync_capture_scan_interval_seconds: int = Field(
        default=300,
        ge=30,
        le=3600,
        description=(
            "Background periodic scan interval in seconds. "
            "When sync_capture_auto_scan_enabled is True, the background scanner "
            "runs a full collection scan at this cadence. "
            "Range: 30–3600 seconds. Default: 300 seconds (5 minutes). "
            "Configurable via SKILLMEAT_SYNC_CAPTURE_SCAN_INTERVAL_SECONDS env var."
        ),
    )

    sync_capture_fs_watcher_enabled: bool = Field(
        default=False,
        description=(
            "Enable filesystem watcher for real-time change detection. "
            "Phase 3 feature — config field is added now for forward-compatibility "
            "but the watcher implementation is not yet active. "
            "Has no effect until Phase 3 is shipped. "
            "Configurable via SKILLMEAT_SYNC_CAPTURE_FS_WATCHER_ENABLED env var."
        ),
    )

    sync_capture_auto_scan_enabled: bool = Field(
        default=True,
        description=(
            "Enable background periodic scan for sync capture. "
            "When True and sync_capture_enabled is True, a background task runs "
            "a collection scan every sync_capture_scan_interval_seconds seconds. "
            "Configurable via SKILLMEAT_SYNC_CAPTURE_AUTO_SCAN_ENABLED env var."
        ),
    )

    # Git Credential Management feature flag (GCD Phase 2)
    git_credentials_enabled: bool = Field(
        default=False,
        description=(
            "Enable the git-credentials CRUD endpoints for managing per-scope "
            "access tokens (PATs and app-installation tokens).  "
            "When False (default on local edition), all /api/v1/git-credentials "
            "endpoints return HTTP 403.  Set to True on enterprise edition to "
            "allow token storage and retrieval.  "
            "Configurable via SKILLMEAT_GIT_CREDENTIALS_ENABLED env var."
        ),
        validation_alias=AliasChoices(
            "SKILLMEAT_GIT_CREDENTIALS_ENABLED",
            "GIT_CREDENTIALS_ENABLED",
        ),
    )

    @model_validator(mode="after")
    def _auto_enable_enterprise_sync(self) -> "APISettings":
        """Auto-enable enterprise_sync_enabled when running in enterprise edition.

        When ``edition == "enterprise"`` and the operator has not explicitly set
        ``SKILLMEAT_ENTERPRISE_SYNC_ENABLED`` in the environment, this validator
        promotes the flag to ``True`` so that context-sync endpoints are served
        by ``EnterpriseContextSyncService`` without requiring any extra
        configuration.

        Explicit opt-out is preserved: if the operator sets
        ``SKILLMEAT_ENTERPRISE_SYNC_ENABLED=false`` the field will already be
        ``False`` after Pydantic parses it, and this validator leaves it alone.
        """
        if self.edition == "enterprise" and not self.enterprise_sync_enabled:
            # Only auto-enable when the operator has NOT explicitly disabled it.
            explicit = os.environ.get("SKILLMEAT_ENTERPRISE_SYNC_ENABLED")
            if explicit is None:
                self.enterprise_sync_enabled = True
        return self

    @model_validator(mode="after")
    def _warn_legacy_enterprise_pat_env(self) -> "APISettings":
        """Emit a deprecation warning when the legacy ENTERPRISE_PAT_SECRET env var is used.

        Pydantic resolves ``validation_alias=AliasChoices(...)`` by trying each
        alias in order, so ``SKILLMEAT_ENTERPRISE_PAT_SECRET`` takes priority.
        This validator detects when only the legacy name is set and warns the
        operator to migrate.
        """
        primary = os.environ.get("SKILLMEAT_ENTERPRISE_PAT_SECRET")
        legacy = os.environ.get("ENTERPRISE_PAT_SECRET")
        if legacy and not primary:
            warnings.warn(
                "The ENTERPRISE_PAT_SECRET environment variable is deprecated. "
                "Please use SKILLMEAT_ENTERPRISE_PAT_SECRET instead. "
                "Support for the legacy name may be removed in a future release.",
                DeprecationWarning,
                stacklevel=2,
            )
        return self

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """Validate log level is a valid logging level."""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        v_upper = v.upper()
        if v_upper not in valid_levels:
            raise ValueError(f"Invalid log level: {v}. Must be one of {valid_levels}")
        return v_upper

    @field_validator("log_format")
    @classmethod
    def validate_log_format(cls, v: str) -> str:
        """Validate log format is either json or text."""
        valid_formats = ["json", "text"]
        v_lower = v.lower()
        if v_lower not in valid_formats:
            raise ValueError(f"Invalid log format: {v}. Must be one of {valid_formats}")
        return v_lower

    @property
    def is_development(self) -> bool:
        """Check if running in development mode."""
        return self.env == Environment.DEVELOPMENT

    @property
    def is_production(self) -> bool:
        """Check if running in production mode."""
        return self.env == Environment.PRODUCTION

    @property
    def is_testing(self) -> bool:
        """Check if running in testing mode."""
        return self.env == Environment.TESTING

    @property
    def api_prefix(self) -> str:
        """Get API path prefix."""
        return f"/api/{self.api_version}"

    def configure_logging(self) -> None:
        """Configure application logging based on settings."""
        # Get numeric log level
        numeric_level = getattr(logging, self.log_level)

        if self.log_format == "json":
            # JSON structured logging
            import json
            import sys
            from datetime import datetime

            class JSONFormatter(logging.Formatter):
                """JSON log formatter."""

                def format(self, record: logging.LogRecord) -> str:
                    """Format log record as JSON."""
                    log_data = {
                        "timestamp": datetime.utcnow().isoformat(),
                        "level": record.levelname,
                        "logger": record.name,
                        "message": record.getMessage(),
                        "module": record.module,
                        "function": record.funcName,
                        "line": record.lineno,
                    }

                    # Add exception info if present
                    if record.exc_info:
                        log_data["exception"] = self.formatException(record.exc_info)

                    # Add extra fields
                    if hasattr(record, "extra"):
                        log_data.update(record.extra)

                    return json.dumps(log_data)

            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(JSONFormatter())
        else:
            # Text logging with color support (development mode)
            format_string = (
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
                if not self.is_development
                else "%(levelname)s:     %(name)s - %(message)s"
            )
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(format_string))

        # Configure root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(numeric_level)
        root_logger.handlers.clear()
        root_logger.addHandler(handler)

        # Configure uvicorn loggers
        for logger_name in ["uvicorn", "uvicorn.access", "uvicorn.error"]:
            logger = logging.getLogger(logger_name)
            logger.setLevel(numeric_level)
            logger.handlers.clear()
            logger.addHandler(handler)
            logger.propagate = False

    def get_collection_dir(self) -> Path:
        """Get the collection directory path.

        Returns:
            Path to collections directory
        """
        if self.collection_dir:
            return self.collection_dir

        # Use default from SkillMeat config
        return Path.home() / ".skillmeat" / "collections"


# Global settings instance
_settings: Optional[APISettings] = None


def get_settings() -> APISettings:
    """Get or create settings instance.

    This function provides a singleton pattern for settings,
    ensuring configuration is loaded only once.

    Returns:
        APISettings instance
    """
    global _settings
    if _settings is None:
        _settings = APISettings()
    return _settings


def reload_settings() -> APISettings:
    """Force reload settings from environment.

    Useful for testing or when environment changes at runtime.

    Returns:
        New APISettings instance
    """
    global _settings
    _settings = APISettings()
    return _settings
