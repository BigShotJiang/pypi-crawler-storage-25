"""Enterprise cascade policy CRUD and resolution endpoints.

Exposes:
  GET    /enterprise/cascade-policies                  — list policies
  POST   /enterprise/cascade-policies                  — create policy
  PUT    /enterprise/cascade-policies/{id}             — update policy
  DELETE /enterprise/cascade-policies/{id}             — delete policy
  GET    /enterprise/cascade-policies/resolve          — resolve effective policy
  GET    /enterprise/cascade-policies/{id}/audit       — audit log for a policy

All endpoints require ``enterprise_admin`` role via ``EnterpriseAdminDep``.

Feature flag gate
-----------------
``settings.edition != "enterprise"`` or ``settings.cascade_policy_enabled is False``
→ HTTP 501.

RBAC enforcement
-----------------
All endpoints are guarded by ``EnterpriseAdminDep`` (requires enterprise_admin role).
"""

from __future__ import annotations

import logging
from typing import Annotated, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from skillmeat.api.dependencies import (
    EnterpriseAdminDep,
    EnterpriseContext,
    EnterpriseContextDep,
    SettingsDep,
    get_db_session,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.enterprise_cascade_policy import (
    CascadePolicyAuditResponse,
    CascadePolicyCreate,
    CascadePolicyListResponse,
    CascadePolicyResponse,
    CascadePolicyUpdate,
    EffectivePolicyResponse,
)
from skillmeat.core.services.cascade_policy_service import (
    CascadePolicyService,
    EffectivePolicyResolution,
)
from skillmeat.cache.models_enterprise import EnterpriseCascadePolicy

# ---------------------------------------------------------------------------
# Optional OpenTelemetry import — silently skipped when not installed.
# ---------------------------------------------------------------------------

try:
    from opentelemetry import trace as _otel_trace

    _tracer = _otel_trace.get_tracer(__name__)
    _OTEL_AVAILABLE = True
except ImportError:  # pragma: no cover — OTel is optional
    _OTEL_AVAILABLE = False
    _tracer = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# OTel helpers (best-effort; isolated so handlers stay readable)
# ---------------------------------------------------------------------------


def _emit_list_policies_span(auth: "AuthContext", org_id: "UUID") -> None:
    """Emit a best-effort OTel span for a list-policies request.

    Span name: ``enterprise.cascade_policy.list``

    Args:
        auth: Enterprise admin auth context.
        org_id: Organization UUID being queried.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.cascade_policy.list") as span:
            span.set_attribute("org_id", str(org_id))
            span.set_attribute("user_id", str(auth.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for cascade-policy list", exc_info=True)


def _emit_create_policy_span(auth: "AuthContext", org_id: "UUID") -> None:
    """Emit a best-effort OTel span for a create-policy request.

    Span name: ``enterprise.cascade_policy.create``

    Args:
        auth: Enterprise admin auth context.
        org_id: Organization UUID the policy is created for.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.cascade_policy.create") as span:
            span.set_attribute("org_id", str(org_id))
            span.set_attribute("user_id", str(auth.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for cascade-policy create", exc_info=True)


def _emit_update_policy_span(auth: "AuthContext", policy_id: "UUID") -> None:
    """Emit a best-effort OTel span for an update-policy request.

    Span name: ``enterprise.cascade_policy.update``

    Args:
        auth: Enterprise admin auth context.
        policy_id: UUID of the policy being updated.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.cascade_policy.update") as span:
            span.set_attribute("policy_id", str(policy_id))
            span.set_attribute("user_id", str(auth.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for cascade-policy update", exc_info=True)


def _emit_delete_policy_span(auth: "AuthContext", policy_id: "UUID") -> None:
    """Emit a best-effort OTel span for a delete-policy request.

    Span name: ``enterprise.cascade_policy.delete``

    Args:
        auth: Enterprise admin auth context.
        policy_id: UUID of the policy being deleted.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.cascade_policy.delete") as span:
            span.set_attribute("policy_id", str(policy_id))
            span.set_attribute("user_id", str(auth.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for cascade-policy delete", exc_info=True)


def _emit_resolve_policy_span(
    auth: "AuthContext", artifact_id: "UUID", org_id: "UUID"
) -> None:
    """Emit a best-effort OTel span for a resolve-policy request.

    Span name: ``enterprise.cascade_policy.resolve``

    Args:
        auth: Enterprise admin auth context.
        artifact_id: Artifact UUID being resolved.
        org_id: Organization UUID providing the policy context.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.cascade_policy.resolve") as span:
            span.set_attribute("artifact_id", str(artifact_id))
            span.set_attribute("org_id", str(org_id))
            span.set_attribute("user_id", str(auth.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for cascade-policy resolve", exc_info=True)


def _emit_audit_span(auth: "AuthContext", policy_id: "UUID") -> None:
    """Emit a best-effort OTel span for a policy-audit request.

    Span name: ``enterprise.cascade_policy.audit``

    Args:
        auth: Enterprise admin auth context.
        policy_id: UUID of the policy whose audit log is being fetched.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return
    try:
        with _tracer.start_as_current_span("enterprise.cascade_policy.audit") as span:
            span.set_attribute("policy_id", str(policy_id))
            span.set_attribute("user_id", str(auth.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for cascade-policy audit", exc_info=True)


# ---------------------------------------------------------------------------
# Feature flag gate
# ---------------------------------------------------------------------------


def _check_feature_flags(settings: SettingsDep) -> None:
    """Raise HTTP 501 when cascade policy endpoints are unavailable.

    Two independent checks:
    1. ``edition != "enterprise"`` — cascade policy hierarchy only exists in
       enterprise edition.
    2. ``cascade_policy_enabled is False`` — may be administratively disabled
       even in enterprise edition.

    Args:
        settings: Current application settings.

    Raises:
        HTTPException 501: When edition is not enterprise, or when
            ``cascade_policy_enabled`` is disabled.
    """
    if settings.edition != "enterprise":
        logger.debug(
            "cascade-policy: edition=%s is not enterprise — returning 501",
            settings.edition,
        )
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Cascade Policy configuration is only available in the enterprise "
                "edition. Current edition: %s." % settings.edition
            ),
        )

    if not settings.cascade_policy_enabled:
        logger.debug("cascade-policy: cascade_policy_enabled=False — returning 501")
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Cascade Policy endpoints are not enabled in this deployment. "
                "Set SKILLMEAT_CASCADE_POLICY_ENABLED=true to activate."
            ),
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _policy_to_response(policy: EnterpriseCascadePolicy) -> CascadePolicyResponse:
    """Convert an ORM row to the API response schema.

    The ``scope_level`` is derived from the nullable pattern of
    ``artifact_id`` and ``team_id``.

    Args:
        policy: :class:`~skillmeat.cache.models_enterprise.EnterpriseCascadePolicy`
            row to convert.

    Returns:
        :class:`~skillmeat.api.schemas.enterprise_cascade_policy.CascadePolicyResponse`
    """
    if policy.artifact_id is None:
        scope_level = "org"
    elif policy.team_id is None:
        scope_level = "artifact"
    else:
        scope_level = "team"

    return CascadePolicyResponse(
        id=policy.id,
        tenant_id=policy.tenant_id,
        org_id=policy.org_id,
        artifact_id=policy.artifact_id,
        team_id=policy.team_id,
        policy_type=policy.policy_type,
        is_auto_propagate=policy.is_auto_propagate,
        scope_level=scope_level,
        created_by=policy.created_by,
        created_at=policy.created_at,
        updated_at=policy.updated_at,
    )


def _get_service(session: Session, ctx: EnterpriseContext) -> CascadePolicyService:
    """Construct a :class:`CascadePolicyService` scoped to the resolved enterprise context.

    Args:
        session: SQLAlchemy session for the enterprise database.
        ctx: Resolved enterprise context providing tenant identity.

    Returns:
        A :class:`CascadePolicyService` instance ready for use within the
        request lifecycle.
    """
    return CascadePolicyService(session=session, tenant_id=ctx.tenant_id)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(
    prefix="/enterprise",
    tags=["Enterprise Cascade Policies"],
    dependencies=[Depends(_check_feature_flags)],
)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/cascade-policies",
    summary="List cascade policies",
    description=(
        "Return all cascade policy entries for an organization, optionally "
        "filtered by artifact UUID or scope level.\n\n"
        "**Scope levels:**\n"
        "- ``org`` — org-level default policy (artifact_id NULL)\n"
        "- ``artifact`` — per-artifact override (artifact_id set, team_id NULL)\n"
        "- ``team`` — per-team exemption (artifact_id + team_id both set)\n\n"
        "Requires ``enterprise_admin`` role."
    ),
    response_model=CascadePolicyListResponse,
    responses={
        200: {"description": "List of cascade policies matching the filters."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        501: {
            "description": (
                "Cascade policy endpoints are not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def list_cascade_policies(
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
    org_id: Optional[UUID] = Query(
        default=None,
        description=(
            "Organization UUID to scope the policy listing. "
            "When omitted, the org is derived from the authenticated context."
        ),
    ),
    artifact_id: Optional[UUID] = Query(
        default=None,
        description=(
            "Optional artifact UUID filter. When provided, only policies for "
            "this artifact (overrides and team exemptions) are returned."
        ),
    ),
    scope_level: Optional[str] = Query(
        default=None,
        description="Optional scope level filter: 'org', 'artifact', or 'team'",
    ),
) -> CascadePolicyListResponse:
    """Return all cascade policies for the specified organization.

    Parameters
    ----------
    auth:
        Enterprise admin auth context (enforces role requirement).
    ctx:
        Resolved enterprise tenant and org context derived from auth.
    session:
        Database session.
    org_id:
        Optional organization UUID to scope results. Defaults to the org
        derived from the authenticated context when not supplied.
    artifact_id:
        Optional artifact UUID filter.
    scope_level:
        Optional scope level filter ('org', 'artifact', or 'team').

    Returns
    -------
    CascadePolicyListResponse
        Items list and total count.

    Raises
    ------
    HTTPException(400)
        If scope_level is not a recognised value.
    HTTPException(403)
        Insufficient role.
    HTTPException(501)
        Feature not available.
    """
    # Feature gate fires via router dependency before this handler is entered.

    resolved_org_id = org_id if org_id is not None else ctx.org_id

    # OTel span (best-effort)
    _emit_list_policies_span(auth=auth, org_id=resolved_org_id)

    if scope_level is not None and scope_level not in ("org", "artifact", "team"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Invalid scope_level {scope_level!r}. "
                "Must be one of: 'org', 'artifact', 'team'."
            ),
        )

    svc = _get_service(session, ctx)
    policies = svc.list_policies(
        org_id=resolved_org_id,
        artifact_id=artifact_id,
        scope_level=scope_level,
    )
    items = [_policy_to_response(p) for p in policies]
    return CascadePolicyListResponse(items=items, total=len(items))


@router.post(
    "/cascade-policies",
    summary="Create cascade policy",
    description=(
        "Create a new cascade policy entry for an organization.\n\n"
        "**Scope is determined by the combination of optional fields:**\n"
        "- ``artifact_id=None``, ``team_id=None`` → org-level default\n"
        "- ``artifact_id`` set, ``team_id=None`` → per-artifact override\n"
        "- Both set → per-team exemption\n\n"
        "Only ``soft_update`` and ``hard_update`` policy types are supported "
        "in Phase 4.  Requires ``enterprise_admin`` role."
    ),
    response_model=CascadePolicyResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        201: {"description": "Policy created successfully."},
        400: {"description": "Invalid policy_type or scope (team_id without artifact_id)."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        501: {
            "description": (
                "Cascade policy endpoints are not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def create_cascade_policy(
    body: CascadePolicyCreate,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
) -> CascadePolicyResponse:
    """Create a new cascade policy and write its creation audit entry.

    Parameters
    ----------
    body:
        Policy creation parameters.
    auth:
        Enterprise admin auth context.
    ctx:
        Resolved enterprise tenant and org context derived from auth.
    session:
        Database session.

    Returns
    -------
    CascadePolicyResponse
        The newly created policy.

    Raises
    ------
    HTTPException(400)
        If policy_type is invalid or team_id is set without artifact_id.
    HTTPException(409)
        If a policy for this (org, artifact, team) scope already exists
        (unique constraint violation).
    HTTPException(501)
        Feature not available.
    """
    # Feature gate fires via router dependency before this handler is entered.

    resolved_org_id = body.org_id if body.org_id is not None else ctx.org_id

    # OTel span (best-effort)
    _emit_create_policy_span(auth=auth, org_id=resolved_org_id)

    svc = _get_service(session, ctx)

    try:
        policy = svc.create_policy(
            org_id=resolved_org_id,
            artifact_id=body.artifact_id,
            team_id=body.team_id,
            policy_type=body.policy_type,
            is_auto_propagate=body.is_auto_propagate,
            created_by=auth.user_id,
            change_reason=body.change_reason,
        )
        session.commit()
    except ValueError as exc:
        logger.info("cascade-policy create: validation error — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        session.rollback()
        # Surface unique constraint violations as 409
        exc_str = str(exc).lower()
        if "unique" in exc_str or "duplicate" in exc_str:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "A cascade policy already exists for this "
                    "(org, artifact, team) scope combination."
                ),
            ) from exc
        logger.exception(
            "cascade-policy create: unexpected error for org=%s artifact=%s",
            body.org_id,
            body.artifact_id,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating cascade policy.",
        ) from exc

    return _policy_to_response(policy)


@router.put(
    "/cascade-policies/{policy_id}",
    summary="Update cascade policy",
    description=(
        "Update the ``policy_type`` and/or ``is_auto_propagate`` setting for "
        "an existing cascade policy.  Scope fields (org_id / artifact_id / "
        "team_id) are immutable after creation.\n\n"
        "An audit entry is written for the change.  "
        "Requires ``enterprise_admin`` role."
    ),
    response_model=CascadePolicyResponse,
    responses={
        200: {"description": "Policy updated successfully."},
        400: {"description": "Invalid policy_type value."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        404: {"description": "Policy not found."},
        501: {
            "description": (
                "Cascade policy endpoints are not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def update_cascade_policy(
    policy_id: UUID,
    body: CascadePolicyUpdate,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
) -> CascadePolicyResponse:
    """Update an existing cascade policy.

    Parameters
    ----------
    policy_id:
        UUID of the policy to update.
    body:
        Fields to update (all optional — omit to leave unchanged).
    auth:
        Enterprise admin auth context.
    ctx:
        Resolved enterprise tenant and org context derived from auth.
    session:
        Database session.

    Returns
    -------
    CascadePolicyResponse
        The updated policy.

    Raises
    ------
    HTTPException(400)
        If policy_type is invalid.
    HTTPException(404)
        Policy not found.
    HTTPException(501)
        Feature not available.
    """
    # Feature gate fires via router dependency before this handler is entered.

    # OTel span (best-effort)
    _emit_update_policy_span(auth=auth, policy_id=policy_id)

    svc = _get_service(session, ctx)

    try:
        policy = svc.update_policy(
            policy_id=policy_id,
            changed_by=auth.user_id,
            policy_type=body.policy_type,
            is_auto_propagate=body.is_auto_propagate,
            change_reason=body.change_reason,
        )
    except ValueError as exc:
        logger.info("cascade-policy update: validation error — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        session.rollback()
        logger.exception(
            "cascade-policy update: unexpected error for policy_id=%s", policy_id
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating cascade policy.",
        ) from exc

    if policy is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Cascade policy '{policy_id}' not found.",
        )

    session.commit()
    return _policy_to_response(policy)


@router.delete(
    "/cascade-policies/{policy_id}",
    summary="Delete cascade policy",
    description=(
        "Delete a cascade policy entry and write a deletion audit record.\n\n"
        "Requires ``enterprise_admin`` role."
    ),
    status_code=status.HTTP_204_NO_CONTENT,
    responses={
        204: {"description": "Policy deleted."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        404: {"description": "Policy not found."},
        501: {
            "description": (
                "Cascade policy endpoints are not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def delete_cascade_policy(
    policy_id: UUID,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
    change_reason: Optional[str] = Query(
        default=None,
        description="Optional free-text reason for deletion (written to audit log)",
        max_length=1000,
    ),
) -> None:
    """Delete a cascade policy and write its deletion audit entry.

    Parameters
    ----------
    policy_id:
        UUID of the policy to delete.
    auth:
        Enterprise admin auth context.
    ctx:
        Resolved enterprise tenant and org context derived from auth.
    session:
        Database session.
    change_reason:
        Optional rationale for the deletion.

    Raises
    ------
    HTTPException(404)
        Policy not found.
    HTTPException(501)
        Feature not available.
    """
    # Feature gate fires via router dependency before this handler is entered.

    # OTel span (best-effort)
    _emit_delete_policy_span(auth=auth, policy_id=policy_id)

    svc = _get_service(session, ctx)

    try:
        found = svc.delete_policy(
            policy_id=policy_id,
            deleted_by=auth.user_id,
            change_reason=change_reason,
        )
    except Exception as exc:
        session.rollback()
        logger.exception(
            "cascade-policy delete: unexpected error for policy_id=%s", policy_id
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while deleting cascade policy.",
        ) from exc

    if not found:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Cascade policy '{policy_id}' not found.",
        )

    session.commit()


@router.get(
    "/cascade-policies/resolve",
    summary="Resolve effective cascade policy",
    description=(
        "Resolve the effective cascade policy for a specific (artifact, team) "
        "context by applying the three-level inheritance chain:\n\n"
        "1. Org-level default (system fallback: soft_update / no auto-propagate)\n"
        "2. Per-artifact override (if one exists)\n"
        "3. Per-team exemption (if one exists for this artifact + team)\n\n"
        "The ``resolved_from`` field in the response indicates which level "
        "provided the effective value.  Requires ``enterprise_admin`` role."
    ),
    response_model=EffectivePolicyResponse,
    responses={
        200: {"description": "Resolved effective cascade policy."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        501: {
            "description": (
                "Cascade policy endpoints are not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def resolve_effective_policy(
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
    artifact_id: UUID = Query(
        ...,
        description="Artifact UUID to resolve the effective policy for",
    ),
    org_id: Optional[UUID] = Query(
        default=None,
        description=(
            "Organization UUID providing the policy context. "
            "When omitted, the org is derived from the authenticated context."
        ),
    ),
    team_id: Optional[UUID] = Query(
        default=None,
        description=(
            "Optional team UUID. When provided, the per-team exemption level "
            "is also checked. Omit for org-default context."
        ),
    ),
) -> EffectivePolicyResponse:
    """Resolve the effective policy for an artifact in a team's context.

    Parameters
    ----------
    auth:
        Enterprise admin auth context.
    ctx:
        Resolved enterprise tenant and org context derived from auth.
    session:
        Database session.
    artifact_id:
        Artifact UUID.
    org_id:
        Optional organization UUID. Defaults to the org derived from the
        authenticated context when not supplied.
    team_id:
        Optional team UUID.

    Returns
    -------
    EffectivePolicyResponse
        Resolved policy with source scope level indicated.

    Raises
    ------
    HTTPException(501)
        Feature not available.
    """
    # Feature gate fires via router dependency before this handler is entered.

    resolved_org_id = org_id if org_id is not None else ctx.org_id

    # OTel span (best-effort)
    _emit_resolve_policy_span(auth=auth, artifact_id=artifact_id, org_id=resolved_org_id)

    svc = _get_service(session, ctx)
    resolution: EffectivePolicyResolution = svc.resolve_effective_policy(
        artifact_id=artifact_id,
        org_id=resolved_org_id,
        team_id=team_id,
    )

    return EffectivePolicyResponse(
        artifact_id=artifact_id,
        team_id=team_id,
        org_id=resolved_org_id,
        policy_type=resolution.policy_type,
        is_auto_propagate=resolution.is_auto_propagate,
        resolved_from=resolution.resolved_from,
        policy_id=resolution.policy_id,
    )


@router.get(
    "/cascade-policies/{policy_id}/audit",
    summary="Get audit log for a cascade policy",
    description=(
        "Return the immutable audit log for a specific cascade policy, "
        "ordered newest-first.  Includes create, update, and delete events "
        "for the policy's scope (org / artifact / team).\n\n"
        "Requires ``enterprise_admin`` role."
    ),
    response_model=CascadePolicyAuditResponse,
    responses={
        200: {"description": "Audit log entries for the policy."},
        403: {"description": "Insufficient role — requires enterprise_admin."},
        404: {"description": "Policy not found."},
        501: {
            "description": (
                "Cascade policy endpoints are not enabled, or deployment is "
                "not in enterprise edition."
            )
        },
    },
)
def get_policy_audit(
    policy_id: UUID,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    session: Annotated[Session, Depends(get_db_session)],
    limit: int = Query(
        default=50,
        ge=1,
        le=200,
        description="Maximum number of audit entries to return",
    ),
    offset: int = Query(
        default=0,
        ge=0,
        description="Number of entries to skip for pagination",
    ),
) -> CascadePolicyAuditResponse:
    """Return the audit log for a specific cascade policy.

    Parameters
    ----------
    policy_id:
        UUID of the policy whose audit log is requested.
    auth:
        Enterprise admin auth context.
    ctx:
        Resolved enterprise tenant and org context derived from auth.
    session:
        Database session.
    limit:
        Maximum results to return (1–200).
    offset:
        Pagination offset.

    Returns
    -------
    CascadePolicyAuditResponse
        Paginated audit entries, newest first.

    Raises
    ------
    HTTPException(404)
        Policy not found.
    HTTPException(501)
        Feature not available.
    """
    # Feature gate fires via router dependency before this handler is entered.

    # OTel span (best-effort)
    _emit_audit_span(auth=auth, policy_id=policy_id)

    svc = _get_service(session, ctx)
    entries, total = svc.get_policy_audit(policy_id=policy_id, limit=limit, offset=offset)

    if total == 0:
        # Distinguish "policy not found" from "policy exists but no audit entries".
        # A policy must have at least one audit entry (its creation record).
        if svc.get_policy(policy_id) is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Cascade policy '{policy_id}' not found.",
            )

    from skillmeat.api.schemas.enterprise_cascade_policy import CascadePolicyAuditEntry

    audit_items = [
        CascadePolicyAuditEntry(
            id=e.id,
            tenant_id=e.tenant_id,
            org_id=e.org_id,
            artifact_id=e.artifact_id,
            team_id=e.team_id,
            changed_by=e.changed_by,
            changed_at=e.changed_at,
            action=e.action,
            old_policy_type=e.old_policy_type,
            new_policy_type=e.new_policy_type,
            old_auto_propagate=e.old_auto_propagate,
            new_auto_propagate=e.new_auto_propagate,
            change_reason=e.change_reason,
        )
        for e in entries
    ]

    return CascadePolicyAuditResponse(
        policy_id=policy_id,
        items=audit_items,
        total=total,
    )
