"""Auth session router — exposes the resolved AuthContext for the current user.

Provides GET /auth/me so the frontend can read roles and scopes as resolved
by the backend (including DB-level overrides such as system_admin elevation
stored in the enterprise_users table), rather than reading raw claims from
the Clerk SDK directly.
"""

from __future__ import annotations

import logging
import uuid

from fastapi import APIRouter

from skillmeat.api.dependencies import AuthContextDep, SettingsDep
from skillmeat.api.schemas.auth_session import (
    AuthSessionResponse,
    TeamMembershipResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["auth"])


def _lookup_user_profile(user_id_str: str) -> tuple[str | None, str | None]:
    """Look up display_name and email for a user from the DB cache.

    Queries the ``users`` table by ``external_id`` (which stores the Clerk
    user_id or LOCAL_ADMIN_USER_ID for local mode).  Returns ``(None, None)``
    when no matching row exists or when the DB is unavailable.

    Args:
        user_id_str: String representation of the user's UUID (``auth.user_id``).

    Returns:
        Tuple of ``(display_name, email)`` — either or both may be ``None``.
    """
    try:
        from skillmeat.cache.models import User, get_session

        with get_session() as session:
            row = (
                session.query(User.display_name, User.email)
                .filter(User.external_id == user_id_str)
                .first()
            )

        if row is not None:
            return row[0], row[1]
        return None, None

    except Exception:  # noqa: BLE001
        logger.debug(
            "User profile lookup failed; returning empty display_name/email",
            extra={"user_id": user_id_str},
        )
        return None, None


def _lookup_enterprise_teams(
    user_id: uuid.UUID,
    tenant_id: uuid.UUID,
) -> list[TeamMembershipResponse]:
    """Look up enterprise team memberships for the current user.

    Queries ``enterprise_team_members`` joined with ``enterprise_teams`` for
    all active teams belonging to the given user within the specified tenant.
    Tenant isolation is enforced by filtering on ``tenant_id`` in both the
    membership and team rows.

    This function is only called when ``settings.edition == "enterprise"``.
    In all other paths ``teams`` remains ``[]`` without any DB access.

    Args:
        user_id:   UUID of the authenticated user (``auth.user_id``).  In the
            enterprise edition this corresponds to ``enterprise_team_members.user_id``
            which references ``enterprise_users.id``.
        tenant_id: UUID of the tenant (``auth.tenant_id``).  Used to enforce
            tenant isolation — no cross-tenant rows will be returned.

    Returns:
        List of ``TeamMembershipResponse`` objects, one per team membership.
        Returns an empty list when the user has no memberships, the query finds
        no rows, or any exception is encountered (graceful degradation).
    """
    try:
        from sqlalchemy import select

        from skillmeat.cache.models import get_session
        from skillmeat.cache.models_enterprise import (
            EnterpriseTeam,
            EnterpriseTeamMember,
        )

        with get_session() as session:
            stmt = (
                select(
                    EnterpriseTeam.id,
                    EnterpriseTeam.name,
                    EnterpriseTeamMember.role,
                )
                .join(
                    EnterpriseTeamMember,
                    EnterpriseTeamMember.team_id == EnterpriseTeam.id,
                )
                .where(EnterpriseTeamMember.user_id == user_id)
                .where(EnterpriseTeamMember.tenant_id == tenant_id)
                .where(EnterpriseTeam.tenant_id == tenant_id)
                .where(EnterpriseTeam.is_active.is_(True))
            )
            rows = session.execute(stmt).fetchall()

        return [
            TeamMembershipResponse(
                team_id=str(row[0]),
                team_name=row[1],
                role=row[2],
            )
            for row in rows
        ]

    except Exception:  # noqa: BLE001
        logger.debug(
            "Enterprise team membership lookup failed; returning empty teams list",
            extra={"user_id": str(user_id), "tenant_id": str(tenant_id)},
        )
        return []


@router.get(
    "/me",
    response_model=AuthSessionResponse,
    summary="Get current user's resolved auth context",
    description=(
        "Returns the resolved authentication context for the authenticated caller, "
        "including roles and scopes after any DB-level overrides (e.g. system_admin "
        "elevation stored in enterprise_users)."
    ),
)
async def get_current_user(
    auth: AuthContextDep,
    settings: SettingsDep,
) -> AuthSessionResponse:
    """Return the resolved auth context for the current user.

    Args:
        auth:     Injected AuthContext carrying user_id, tenant_id, roles, and scopes.
        settings: Injected APISettings for edition and configuration.

    Returns:
        AuthSessionResponse with all resolved identity fields.  ``display_name``
        and ``email`` are populated from the ``users`` DB table when available;
        ``teams`` is populated from ``enterprise_team_members`` in enterprise
        edition and is always ``[]`` in local edition; ``edition`` always
        reflects the current deployment edition.
    """
    user_id_str = str(auth.user_id)
    display_name, email = _lookup_user_profile(user_id_str)

    teams: list[TeamMembershipResponse] = []
    if settings.edition == "enterprise" and auth.tenant_id is not None:
        teams = _lookup_enterprise_teams(auth.user_id, auth.tenant_id)

    return AuthSessionResponse(
        user_id=user_id_str,
        tenant_id=str(auth.tenant_id) if auth.tenant_id else None,
        roles=auth.roles,
        scopes=auth.scopes,
        display_name=display_name,
        email=email,
        teams=teams,
        edition=settings.edition,
    )
