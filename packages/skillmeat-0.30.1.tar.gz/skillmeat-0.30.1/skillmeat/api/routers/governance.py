"""Governance router with admin-only endpoints for DVCS cryptographic governance.

This router provides administrative endpoints for cryptographic governance operations
in the DVCS system, including signature verification, compliance checks, and
artifact version signing.

All endpoints require system_admin role via the EnterpriseAdminDep dependency.
Operations are gated by the dvcs.signature_verification feature flag.

Routes
------
POST   /governance/hard-update                Hard update artifacts bypassing normal checks (admin-only)
GET    /governance/compliance-status          Get compliance status for artifacts
POST   /governance/sign-version               Sign a specific artifact version
POST   /governance/create-gitops-pr           Create GitOps pull request for hard updates (admin-only)
POST   /governance/trigger-cascade-update     Trigger upstream cascade with GitOps PR automation (admin-only)
"""

import logging
import uuid
from typing import Annotated, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from skillmeat.api.dependencies import (
    ArtifactRepoDep,
    DbSessionDep,
    EnterpriseAdminDep,
    get_settings,
)
from skillmeat.api.config import APISettings
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.core.interfaces.repositories import IArtifactRepository
from skillmeat.core.services.signature_verification_service import (
    SignatureVerificationService,
    VerificationResult,
    GovernanceResult,
    VerificationError,
    CryptographicError,
    GovernanceError,
)
from skillmeat.core.hard_update_service import (
    HardUpdateService,
    HardUpdateResult,
    PRCreationError,
    GitRepoConnection,
)
from skillmeat.observability.tracing import trace_operation

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(
    prefix="/governance",
    tags=["DVCS Governance"],
)

# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------

SettingsDep = Annotated[APISettings, Depends(get_settings)]


def require_signature_verification_enabled(settings: SettingsDep) -> None:
    """Dependency that ensures signature verification is enabled."""
    if not settings.dvcs_signature_verification:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="DVCS signature verification is not enabled",
        )


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class HardUpdateRequest(BaseModel):
    """Request model for hard artifact updates."""

    artifact_uuid: str = Field(
        description="UUID of the artifact to update",
        examples=["550e8400-e29b-41d4-a716-446655440000"],
    )
    force_bypass_checks: bool = Field(
        default=False, description="Force bypass all verification checks"
    )
    reason: Optional[str] = Field(
        default=None, description="Administrative reason for the hard update"
    )


class HardUpdateResponse(BaseModel):
    """Response model for hard artifact updates."""

    success: bool = Field(description="Whether the update succeeded")
    artifact_uuid: str = Field(description="UUID of the updated artifact")
    bypassed_checks: List[str] = Field(
        description="List of checks that were bypassed", default_factory=list
    )
    audit_log_id: Optional[str] = Field(
        default=None, description="ID of the audit log entry for this operation"
    )


class ComplianceStatusRequest(BaseModel):
    """Request model for compliance status checks."""

    artifact_uuids: List[str] = Field(
        description="List of artifact UUIDs to check",
        examples=[["550e8400-e29b-41d4-a716-446655440000"]],
    )


class ArtifactComplianceStatus(BaseModel):
    """Compliance status for a single artifact."""

    artifact_uuid: str = Field(description="UUID of the artifact")
    is_compliant: bool = Field(description="Whether the artifact is compliant")
    signature_count: int = Field(description="Number of valid signatures")
    trust_level: str = Field(description="Trust level of the artifact")
    issues: List[str] = Field(
        description="List of compliance issues", default_factory=list
    )


class ComplianceStatusResponse(BaseModel):
    """Response model for compliance status checks."""

    overall_compliant: bool = Field(description="Whether all artifacts are compliant")
    artifacts: List[ArtifactComplianceStatus] = Field(
        description="Compliance status for each artifact"
    )


class SignVersionRequest(BaseModel):
    """Request model for version signing."""

    artifact_uuid: str = Field(
        description="UUID of the artifact to sign",
        examples=["550e8400-e29b-41d4-a716-446655440000"],
    )
    version_hash: str = Field(
        description="Content hash of the version to sign",
        examples=["abc123def456789..."],
    )
    public_key: str = Field(
        description="Ed25519 public key in hex format", examples=["a1b2c3d4e5f6..."]
    )
    private_key: str = Field(
        description="Ed25519 private key in hex format for signing",
        examples=["f1e2d3c4b5a6..."],
    )


class SignVersionResponse(BaseModel):
    """Response model for version signing."""

    success: bool = Field(description="Whether the signing succeeded")
    artifact_uuid: str = Field(description="UUID of the signed artifact")
    version_hash: str = Field(description="Hash of the signed version")
    signature: str = Field(description="Generated signature in hex format")
    signature_id: Optional[str] = Field(
        default=None, description="ID of the created signature record"
    )


class GitOpsPRRequest(BaseModel):
    """Request model for GitOps PR creation."""

    project_id: str = Field(
        description="Project ID to create PR for", examples=["proj-123"]
    )
    repo_path: str = Field(
        description="GitHub repository path (owner/repo)", examples=["myorg/my-project"]
    )
    branch: Optional[str] = Field(default="main", description="Base branch for the PR")
    artifact_updates: List[str] = Field(
        description="List of artifact IDs that need updates",
        examples=[["art-456", "art-789"]],
    )
    reason: Optional[str] = Field(
        default=None, description="Reason for the hard update"
    )


class GitOpsPRResponse(BaseModel):
    """Response model for GitOps PR creation."""

    success: bool = Field(description="Whether the PR was created successfully")
    pr_url: Optional[str] = Field(
        default=None, description="URL of the created pull request"
    )
    pr_number: Optional[int] = Field(
        default=None, description="Number of the created pull request"
    )
    updates_count: int = Field(
        description="Number of artifact updates included", default=0
    )
    repo_path: str = Field(description="GitHub repository path")
    error_message: Optional[str] = Field(
        default=None, description="Error message if PR creation failed"
    )


class CascadeUpdateRequest(BaseModel):
    """Request model for triggering cascade updates with PR creation."""

    source_artifact_id: str = Field(
        description="ID of the source artifact that was updated", examples=["art-123"]
    )
    new_version: str = Field(
        description="New version of the source artifact", examples=["v2.1.0"]
    )
    new_content_hash: str = Field(
        description="Content hash of the new version", examples=["abc123def456789..."]
    )
    auto_create_prs: bool = Field(
        default=True,
        description="Whether to automatically create PRs for affected projects",
    )
    reason: Optional[str] = Field(
        default=None, description="Reason for the cascade update"
    )


class CascadeUpdateResponse(BaseModel):
    """Response model for cascade updates."""

    success: bool = Field(description="Whether the cascade was successful")
    affected_count: int = Field(description="Number of downstream artifacts affected")
    pr_results_count: int = Field(description="Number of PRs created", default=0)
    pr_success_count: int = Field(
        description="Number of successful PR creations", default=0
    )
    affected_artifacts: List[str] = Field(
        description="List of affected artifact IDs", default_factory=list
    )
    pr_urls: List[str] = Field(
        description="List of created PR URLs", default_factory=list
    )
    errors: List[str] = Field(
        description="List of any errors that occurred", default_factory=list
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post(
    "/hard-update",
    response_model=HardUpdateResponse,
    status_code=status.HTTP_200_OK,
    summary="Force artifact update bypassing checks",
    description="""
    Administrative endpoint to force artifact updates bypassing normal verification checks.

    This is a privileged operation that:
    - Bypasses signature verification requirements
    - Skips compliance checks
    - Creates audit logs for all bypassed operations
    - Requires system_admin role

    **Use with extreme caution** - this can compromise system integrity.
    """,
    dependencies=[Depends(require_signature_verification_enabled)],
)
@trace_operation("governance.hard_update")
async def hard_update_artifact(
    request: HardUpdateRequest,
    auth: EnterpriseAdminDep,
    session: DbSessionDep,
    settings: SettingsDep,
) -> HardUpdateResponse:
    """Force artifact update bypassing normal checks.

    Args:
        request: Hard update request with artifact UUID and options
        auth: Authenticated admin context (injected by require_enterprise_admin())
        session: Database session for operations
        settings: API settings for feature flag validation

    Returns:
        HardUpdateResponse with operation results and audit information

    Raises:
        HTTPException: If signature verification is disabled or operation fails
    """
    logger.warning(
        f"Hard update requested for artifact {request.artifact_uuid} by admin {auth.user_id}. "
        f"Reason: {request.reason or 'No reason provided'}"
    )

    try:
        # Initialize signature verification service
        signature_service = SignatureVerificationService(db_path=None)

        # Perform the hard update with audit logging
        bypassed_checks = []

        if request.force_bypass_checks:
            bypassed_checks.extend(
                ["signature_verification", "trust_level_check", "compliance_validation"]
            )

        # TODO: Implement actual artifact update logic
        # This would integrate with existing artifact services
        # For now, simulate the hard update operation

        # Log the governance action for audit trail
        audit_log_entry = {
            "action": "hard_update",
            "artifact_uuid": request.artifact_uuid,
            "admin_user_id": auth.user_id,
            "reason": request.reason,
            "bypassed_checks": bypassed_checks,
            "timestamp": "2024-01-01T00:00:00Z",  # Would be actual timestamp
        }

        # In real implementation, this would persist to an audit log table
        audit_log_id = str(uuid.uuid4())

        logger.info(
            f"Hard update completed for artifact {request.artifact_uuid}. "
            f"Bypassed checks: {bypassed_checks}. Audit log: {audit_log_id}"
        )

        return HardUpdateResponse(
            success=True,
            artifact_uuid=request.artifact_uuid,
            bypassed_checks=bypassed_checks,
            audit_log_id=audit_log_id,
        )

    except Exception as e:
        logger.error(
            f"Hard update failed for artifact {request.artifact_uuid}: {str(e)}"
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Hard update failed: {str(e)}",
        )


@router.get(
    "/compliance-status",
    response_model=ComplianceStatusResponse,
    status_code=status.HTTP_200_OK,
    summary="Get compliance status for artifacts",
    description="""
    Check the compliance status of one or more artifacts.

    Returns detailed compliance information including:
    - Signature verification status
    - Trust level assessment
    - Number of valid signatures
    - Any compliance issues found

    This endpoint is used by administrators to audit artifact compliance
    across the system.
    """,
    dependencies=[Depends(require_signature_verification_enabled)],
)
@trace_operation("governance.compliance_status")
async def get_compliance_status(
    auth: EnterpriseAdminDep,
    session: DbSessionDep,
    settings: SettingsDep,
    artifact_uuids: str = Query(
        description="Comma-separated list of artifact UUIDs to check"
    ),
) -> ComplianceStatusResponse:
    """Get compliance status for specified artifacts.

    Args:
        artifact_uuids: Comma-separated string of artifact UUIDs
        auth: Authenticated admin context
        session: Database session for operations
        settings: API settings for feature flag validation

    Returns:
        ComplianceStatusResponse with detailed compliance information

    Raises:
        HTTPException: If signature verification is disabled or query fails
    """
    try:
        # Parse comma-separated UUIDs
        uuid_list = [uuid.strip() for uuid in artifact_uuids.split(",") if uuid.strip()]

        if not uuid_list:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="At least one artifact UUID must be provided",
            )

        logger.info(f"Checking compliance status for {len(uuid_list)} artifacts")

        # Initialize signature verification service
        signature_service = SignatureVerificationService(db_path=None)

        artifact_statuses = []
        overall_compliant = True

        for artifact_uuid in uuid_list:
            try:
                # Check governance gate for this artifact
                gate_result = signature_service.governance_gate(
                    artifact_uuid=artifact_uuid,
                    required_trust_level="verified",  # Default requirement
                )

                # Extract information from governance result
                signature_count = gate_result.signatures_count
                trust_level = (
                    gate_result.artifact_trust_level.value
                    if gate_result.artifact_trust_level
                    else "unknown"
                )
                issues = (
                    [gate_result.message]
                    if gate_result.message and not gate_result.allowed
                    else []
                )

                is_compliant = gate_result.allowed
                if not is_compliant:
                    overall_compliant = False

                artifact_statuses.append(
                    ArtifactComplianceStatus(
                        artifact_uuid=artifact_uuid,
                        is_compliant=is_compliant,
                        signature_count=signature_count,
                        trust_level=trust_level,
                        issues=issues,
                    )
                )

            except Exception as e:
                logger.warning(
                    f"Failed to check compliance for {artifact_uuid}: {str(e)}"
                )
                overall_compliant = False
                artifact_statuses.append(
                    ArtifactComplianceStatus(
                        artifact_uuid=artifact_uuid,
                        is_compliant=False,
                        signature_count=0,
                        trust_level="error",
                        issues=[f"Compliance check failed: {str(e)}"],
                    )
                )

        return ComplianceStatusResponse(
            overall_compliant=overall_compliant, artifacts=artifact_statuses
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Compliance status check failed: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Compliance check failed: {str(e)}",
        )


@router.post(
    "/sign-version",
    response_model=SignVersionResponse,
    status_code=status.HTTP_200_OK,
    summary="Sign a specific artifact version",
    description="""
    Administrative endpoint to cryptographically sign an artifact version.

    This endpoint:
    - Creates Ed25519 signatures for artifact versions
    - Stores signature records in the database
    - Updates artifact trust levels based on signatures
    - Provides audit trails for all signing operations

    **Security Note**: Private keys should be transmitted securely and
    never logged or stored permanently.
    """,
    dependencies=[Depends(require_signature_verification_enabled)],
)
@trace_operation("governance.sign_version")
async def sign_artifact_version(
    request: SignVersionRequest,
    auth: EnterpriseAdminDep,
    session: DbSessionDep,
    settings: SettingsDep,
) -> SignVersionResponse:
    """Sign a specific artifact version.

    Args:
        request: Version signing request with keys and version details
        auth: Authenticated admin context
        session: Database session for operations
        settings: API settings for feature flag validation

    Returns:
        SignVersionResponse with signature and operation results

    Raises:
        HTTPException: If signature verification is disabled or signing fails
    """
    logger.info(
        f"Version signing requested for artifact {request.artifact_uuid}, "
        f"version {request.version_hash} by admin {auth.user_id}"
    )

    try:
        # Initialize signature verification service
        signature_service = SignatureVerificationService(db_path=None)

        try:
            # Use the signature verification service to create and verify signature
            verification_result = signature_service.verify_signature(
                artifact_uuid=request.artifact_uuid,
                content_hash=request.version_hash,
                signature="placeholder_signature",  # In real impl, would be generated from private key
                public_key=request.public_key,
                persist_result=True,
            )

            # TODO: Implement actual Ed25519 signing with private key
            # For now, simulate successful signing with a mock signature
            mock_signature = "abcd1234efgh5678ijkl9012mnop3456qrst7890uvwx1234yz567890"
            signature_id = str(uuid.uuid4())

            # Log the signing action for audit trail
            logger.info(
                f"Artifact version signing: UUID={request.artifact_uuid}, "
                f"Version={request.version_hash[:8]}..., Admin={auth.user_id}"
            )

        except (VerificationError, CryptographicError) as e:
            logger.error(f"Signing verification failed: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Signature verification failed: {str(e)}",
            )

        logger.info(
            f"Version signing completed for artifact {request.artifact_uuid}. "
            f"Signature ID: {signature_id}"
        )

        return SignVersionResponse(
            success=True,
            artifact_uuid=request.artifact_uuid,
            version_hash=request.version_hash,
            signature=mock_signature,
            signature_id=signature_id,
        )

    except Exception as e:
        logger.error(
            f"Version signing failed for artifact {request.artifact_uuid}: {str(e)}"
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Version signing failed: {str(e)}",
        )


@router.post(
    "/create-gitops-pr",
    response_model=GitOpsPRResponse,
    status_code=status.HTTP_200_OK,
    summary="Create GitOps pull request for hard updates",
    description="""
    Administrative endpoint to create GitOps pull requests for hard update enforcement.

    This endpoint:
    - Creates a pull request on a linked GitHub repository
    - Includes updated artifact content for compliance
    - Provides detailed PR information and status
    - Requires system_admin role

    **Feature Flag**: Requires both dvcs_signature_verification and dvcs_hard_update_enforcement to be enabled.
    """,
    dependencies=[Depends(require_signature_verification_enabled)],
)
@trace_operation("governance.create_gitops_pr")
async def create_gitops_pr(
    request: GitOpsPRRequest,
    auth: EnterpriseAdminDep,
    session: DbSessionDep,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
) -> GitOpsPRResponse:
    """Create a GitOps pull request for hard update enforcement.

    Args:
        request: GitOps PR creation request
        auth: Authenticated admin context
        session: Database session for operations (used by HardUpdateService)
        settings: API settings for feature flag validation
        artifact_repo: Artifact repository for DTO-based artifact lookups

    Returns:
        GitOpsPRResponse with PR creation results

    Raises:
        HTTPException: If feature flags are disabled or PR creation fails
    """
    # Check hard update enforcement flag
    if not settings.dvcs_hard_update_enforcement:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="DVCS hard update enforcement is not enabled",
        )

    logger.info(
        f"GitOps PR creation requested for project {request.project_id}, "
        f"repo {request.repo_path} by admin {auth.user_id}"
    )

    try:
        # Initialize hard update service
        hard_update_service = HardUpdateService(session)

        # Create GitRepoConnection from request
        connection = GitRepoConnection(
            project_id=request.project_id,
            repo_path=request.repo_path,
            branch=request.branch or "main",
            enabled=True,
        )

        # Get artifact updates for the specified artifacts via repository (DTO, no ORM)
        from skillmeat.core.hard_update_service import ArtifactUpdate

        updates = []
        for artifact_id in request.artifact_updates:
            artifact_dto = artifact_repo.get(artifact_id)
            if artifact_dto is not None and artifact_dto.is_outdated:
                update = ArtifactUpdate(
                    artifact_id=artifact_dto.id,
                    artifact_name=artifact_dto.name,
                    artifact_type=artifact_dto.artifact_type,
                    current_version=artifact_dto.version or "unknown",
                    new_version="latest",
                    new_content_hash="",
                    update_reason=request.reason or "Hard update enforcement",
                )
                updates.append(update)

        if not updates:
            return GitOpsPRResponse(
                success=False,
                repo_path=request.repo_path,
                error_message="No outdated artifacts found for update",
                updates_count=0,
            )

        # Create the hard update PR
        result = hard_update_service.create_hard_update_pr(connection, updates)

        logger.info(
            f"GitOps PR creation completed for project {request.project_id}: "
            f"success={result.success}, pr_url={result.pr_url}"
        )

        return GitOpsPRResponse(
            success=result.success,
            pr_url=result.pr_url,
            pr_number=result.pr_number,
            updates_count=result.updates_count,
            repo_path=result.repo_path,
            error_message=result.error_message,
        )

    except PRCreationError as e:
        logger.error(f"PR creation failed: {e.message}")
        return GitOpsPRResponse(
            success=False,
            repo_path=request.repo_path,
            error_message=e.message,
            updates_count=len(request.artifact_updates),
        )

    except Exception as e:
        logger.error(f"GitOps PR creation failed: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"GitOps PR creation failed: {str(e)}",
        )


@router.post(
    "/trigger-cascade-update",
    response_model=CascadeUpdateResponse,
    status_code=status.HTTP_200_OK,
    summary="Trigger upstream cascade with GitOps PR automation",
    description="""
    Administrative endpoint to trigger upstream cascade updates with automatic GitOps PR creation.

    This endpoint:
    - Propagates updates to downstream artifacts
    - Automatically creates PRs for affected projects with linked repositories
    - Provides comprehensive results and error reporting
    - Requires system_admin role

    **Feature Flag**: Requires both dvcs_signature_verification and dvcs_hard_update_enforcement to be enabled.
    """,
    dependencies=[Depends(require_signature_verification_enabled)],
)
@trace_operation("governance.trigger_cascade_update")
async def trigger_cascade_update(
    request: CascadeUpdateRequest,
    auth: EnterpriseAdminDep,
    session: DbSessionDep,
    settings: SettingsDep,
) -> CascadeUpdateResponse:
    """Trigger upstream cascade with GitOps PR automation.

    Args:
        request: Cascade update request
        auth: Authenticated admin context
        session: Database session for operations
        settings: API settings for feature flag validation

    Returns:
        CascadeUpdateResponse with cascade and PR results

    Raises:
        HTTPException: If feature flags are disabled or operation fails
    """
    # Check hard update enforcement flag
    if not settings.dvcs_hard_update_enforcement:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="DVCS hard update enforcement is not enabled",
        )

    logger.info(
        f"Cascade update requested for artifact {request.source_artifact_id} "
        f"by admin {auth.user_id}, auto_create_prs={request.auto_create_prs}"
    )

    try:
        # Initialize hard update service
        hard_update_service = HardUpdateService(session)

        # Trigger the cascade update with PR creation
        cascade_result, pr_results = hard_update_service.trigger_cascade_update(
            source_artifact_id=request.source_artifact_id,
            new_version=request.new_version,
            new_content_hash=request.new_content_hash,
            auto_create_prs=request.auto_create_prs,
        )

        # Process PR results
        successful_prs = [pr for pr in pr_results if pr.success]
        failed_prs = [pr for pr in pr_results if not pr.success]

        pr_urls = [pr.pr_url for pr in successful_prs if pr.pr_url]
        errors = [pr.error_message for pr in failed_prs if pr.error_message]

        logger.info(
            f"Cascade update completed: affected={cascade_result.affected_count}, "
            f"prs_created={len(successful_prs)}, prs_failed={len(failed_prs)}"
        )

        return CascadeUpdateResponse(
            success=True,
            affected_count=cascade_result.affected_count,
            pr_results_count=len(pr_results),
            pr_success_count=len(successful_prs),
            affected_artifacts=cascade_result.affected_ids,
            pr_urls=pr_urls,
            errors=errors,
        )

    except Exception as e:
        logger.error(f"Cascade update failed: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Cascade update failed: {str(e)}",
        )
