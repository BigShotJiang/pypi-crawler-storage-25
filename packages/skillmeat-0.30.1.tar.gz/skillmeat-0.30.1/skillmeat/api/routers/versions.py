"""Version management API endpoints.

Provides snapshot and rollback operations for collection versioning,
plus artifact version history, restore, diff, and enterprise scope endpoints.
"""

import base64
import logging
import shutil
import tarfile
import tempfile
from pathlib import Path
from typing import Annotated, List, Literal, Optional, cast

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ArtifactRepoDep,
    DbArtifactHistoryRepoDep,
    DbSessionDep,
    SettingsDep,
    get_auth_context,
    require_auth,
    require_local_edition,
    verify_api_key,
)
from skillmeat.api.routers.artifacts._helpers import resolve_enterprise_artifact_id
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.auth import AuthContext, Role
from skillmeat.api.schemas.common import ErrorResponse, PageInfo
from skillmeat.api.schemas.version import (
    AdminBulkActionRequest,
    AdminVersionSummaryItem,
    AdminVersionSummaryResponse,
    ArtifactVersionDiffResponse,
    BackfillStatusResponse,
    BatchSyncError,
    BatchSyncRequest,
    BatchSyncResponse,
    ConflictMetadataResponse,
    DiffSummary,
    ForceSyncRequest,
    OwnerScope,
    PatchVersionRequest,
    PatchVersionResponse,
    PromotionRequest,
    RestoreRequest,
    RestoreResponse,
    ReviewRequest,
    RollbackRequest,
    RollbackResponse,
    RollbackSafetyAnalysisResponse,
    SnapshotCreateRequest,
    SnapshotCreateResponse,
    SnapshotListResponse,
    SnapshotResponse,
    VersionDiffRequest,
    VersionDiffResponse,
    VersionGroup,
    VersionGroupDeployment,
    VersionGroupedTopology,
    VersionHistoryItem,
    VersionHistoryResponse,
    VersionScopeResponse,
)
from skillmeat.core.artifact_restore import (
    ArtifactRestoreService,
    CompositeArtifactRestoreService,
)
from skillmeat.core.diff_engine import DiffEngine
from skillmeat.core.version import VersionManager

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/versions",
    tags=["versions"],
    dependencies=[Depends(verify_api_key)],  # All endpoints require API key
)


# ====================
# Dependency Injection
# ====================


def get_version_manager() -> Optional[VersionManager]:
    """Get VersionManager dependency.

    Returns ``None`` in enterprise mode (or when the underlying
    ``CollectionManager`` is unavailable), so that endpoints can return a
    structured 501 instead of a 503 from ``FilesystemErrorMiddleware``.

    Returns:
        VersionManager instance, or None when unavailable
    """
    try:
        return VersionManager()
    except Exception:
        return None


def get_diff_engine() -> DiffEngine:
    """Get DiffEngine dependency.

    Returns:
        DiffEngine instance
    """
    return DiffEngine()


def get_artifact_restore_service() -> ArtifactRestoreService:
    """Get ArtifactRestoreService dependency (local edition, manages own session).

    Returns:
        ArtifactRestoreService instance
    """
    return ArtifactRestoreService()


def get_composite_restore_service() -> CompositeArtifactRestoreService:
    """Get CompositeArtifactRestoreService dependency.

    Returns:
        CompositeArtifactRestoreService instance
    """
    restore_svc = ArtifactRestoreService()
    return CompositeArtifactRestoreService(restore_service=restore_svc)


# Type aliases for dependency injection
VersionManagerDep = Annotated[Optional[VersionManager], Depends(get_version_manager)]
DiffEngineDep = Annotated[DiffEngine, Depends(get_diff_engine)]
ArtifactRestoreServiceDep = Annotated[
    ArtifactRestoreService, Depends(get_artifact_restore_service)
]
CompositeRestoreServiceDep = Annotated[
    CompositeArtifactRestoreService, Depends(get_composite_restore_service)
]


# ====================
# Cursor Utilities
# ====================


def encode_cursor(value: str) -> str:
    """Encode a cursor value to base64.

    Args:
        value: Value to encode

    Returns:
        Base64 encoded cursor string
    """
    return base64.b64encode(value.encode()).decode()


def decode_cursor(cursor: str) -> str:
    """Decode a base64 cursor value.

    Args:
        cursor: Base64 encoded cursor

    Returns:
        Decoded cursor value

    Raises:
        HTTPException: If cursor is invalid
    """
    try:
        return base64.b64decode(cursor.encode()).decode()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid cursor format: {str(e)}",
        )


# ====================
# Snapshot Endpoints
# ====================


@router.get(
    "/snapshots",
    response_model=SnapshotListResponse,
    summary="List snapshots",
    description="Retrieve a paginated list of collection snapshots",
    responses={
        200: {"description": "Successfully retrieved snapshots"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def list_snapshots(
    version_mgr: VersionManagerDep,
    settings: SettingsDep,
    token: TokenDep,
    collection_name: Optional[str] = Query(
        default=None,
        description="Collection name (uses active collection if not specified)",
    ),
    limit: int = Query(
        default=20,
        ge=1,
        le=100,
        description="Number of items per page (max 100)",
    ),
    after: Optional[str] = Query(
        default=None,
        description="Cursor for pagination (next page)",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> SnapshotListResponse:
    """List all snapshots with cursor-based pagination.

    Args:
        version_mgr: Version manager dependency
        settings: API settings dependency
        token: Authentication token
        collection_name: Optional collection name
        limit: Number of items per page
        after: Cursor for next page

    Returns:
        Paginated list of snapshots

    Raises:
        HTTPException: On error
    """
    # Enterprise edition: filesystem snapshots are not available.
    # Enterprise versioning is tracked per-artifact in artifact_versions table
    # (see get_artifact_version_history / get_artifact_version_diff endpoints).
    # A dedicated enterprise snapshot backend is tracked for a future phase.
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "Collection snapshots are not available in enterprise edition. "
                "Use GET /versions/artifacts/{artifact_id}/history for per-artifact "
                "version history."
            ),
        )
    assert version_mgr is not None, "version_mgr required in local edition"
    try:
        logger.info(
            f"Listing snapshots (collection={collection_name}, limit={limit}, after={after})"
        )

        # Decode cursor if provided
        cursor = decode_cursor(after) if after else None

        # Get snapshots from VersionManager
        snapshots, next_cursor = version_mgr.list_snapshots(
            collection_name=collection_name,
            limit=limit,
            cursor=cursor,
        )

        # Convert to response models
        items: List[SnapshotResponse] = [
            SnapshotResponse(
                id=snapshot.id,
                timestamp=snapshot.timestamp,
                message=snapshot.message,
                collection_name=snapshot.collection_name,
                artifact_count=snapshot.artifact_count,
            )
            for snapshot in snapshots
        ]

        # Build pagination info
        has_next = next_cursor is not None
        has_previous = cursor is not None

        start_cursor = encode_cursor(snapshots[0].id) if snapshots else None
        end_cursor = encode_cursor(next_cursor) if next_cursor else None

        page_info = PageInfo(
            has_next_page=has_next,
            has_previous_page=has_previous,
            start_cursor=start_cursor,
            end_cursor=end_cursor,
            total_count=None,  # Total count not efficiently available
        )

        logger.info(f"Retrieved {len(items)} snapshots")
        return SnapshotListResponse(items=items, page_info=page_info)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing snapshots: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list snapshots: {str(e)}",
        )


@router.get(
    "/snapshots/{snapshot_id}",
    response_model=SnapshotResponse,
    summary="Get snapshot details",
    description="Retrieve detailed information about a specific snapshot",
    responses={
        200: {"description": "Successfully retrieved snapshot"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Snapshot not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_snapshot(
    snapshot_id: str,
    version_mgr: VersionManagerDep,
    settings: SettingsDep,
    token: TokenDep,
    collection_name: Optional[str] = Query(
        default=None,
        description="Collection name (uses active collection if not specified)",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> SnapshotResponse:
    """Get details for a specific snapshot.

    Args:
        snapshot_id: Snapshot identifier
        version_mgr: Version manager dependency
        settings: API settings dependency
        token: Authentication token
        collection_name: Optional collection name

    Returns:
        Snapshot details

    Raises:
        HTTPException: If snapshot not found or on error
    """
    # Enterprise edition: filesystem snapshots are not available — see list_snapshots.
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "Collection snapshots are not available in enterprise edition. "
                "Use GET /versions/artifacts/{artifact_id}/history for per-artifact "
                "version history."
            ),
        )
    assert version_mgr is not None, "version_mgr required in local edition"
    try:
        logger.info(f"Getting snapshot: {snapshot_id} (collection={collection_name})")

        snapshot = version_mgr.get_snapshot(snapshot_id, collection_name)

        if not snapshot:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Snapshot '{snapshot_id}' not found",
            )

        return SnapshotResponse(
            id=snapshot.id,
            timestamp=snapshot.timestamp,
            message=snapshot.message,
            collection_name=snapshot.collection_name,
            artifact_count=snapshot.artifact_count,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting snapshot '{snapshot_id}': {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get snapshot: {str(e)}",
        )


@router.post(
    "/snapshots",
    response_model=SnapshotCreateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create snapshot",
    description="Create a new snapshot of a collection",
    responses={
        201: {"description": "Successfully created snapshot"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Collection not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def create_snapshot(
    request: SnapshotCreateRequest,
    version_mgr: VersionManagerDep,
    settings: SettingsDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> SnapshotCreateResponse:
    """Create a new snapshot of a collection.

    Args:
        request: Snapshot creation request
        version_mgr: Version manager dependency
        settings: API settings dependency
        token: Authentication token

    Returns:
        Created snapshot details

    Raises:
        HTTPException: If collection not found or on error
    """
    # Enterprise edition: filesystem snapshots are not available — see list_snapshots.
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "Collection snapshots are not available in enterprise edition. "
                "Use GET /versions/artifacts/{artifact_id}/history for per-artifact "
                "version history."
            ),
        )
    assert version_mgr is not None, "version_mgr required in local edition"
    try:
        logger.info(
            f"Creating snapshot (collection={request.collection_name}, message={request.message})"
        )

        snapshot = version_mgr.create_snapshot(
            collection_name=request.collection_name,
            message=request.message,
        )

        logger.info(f"Snapshot created: {snapshot.id}")
        return SnapshotCreateResponse(
            snapshot=SnapshotResponse(
                id=snapshot.id,
                timestamp=snapshot.timestamp,
                message=snapshot.message,
                collection_name=snapshot.collection_name,
                artifact_count=snapshot.artifact_count,
            ),
            created=True,
        )

    except ValueError as e:
        logger.warning(f"Snapshot creation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error creating snapshot: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create snapshot: {str(e)}",
        )


@router.delete(
    "/snapshots/{snapshot_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete snapshot",
    description="Delete a specific snapshot",
    responses={
        204: {"description": "Successfully deleted snapshot"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Snapshot not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def delete_snapshot(
    snapshot_id: str,
    version_mgr: VersionManagerDep,
    settings: SettingsDep,
    token: TokenDep,
    collection_name: Optional[str] = Query(
        default=None,
        description="Collection name (uses active collection if not specified)",
    ),
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> None:
    """Delete a specific snapshot.

    Args:
        snapshot_id: Snapshot identifier
        version_mgr: Version manager dependency
        settings: API settings dependency
        token: Authentication token
        collection_name: Optional collection name

    Raises:
        HTTPException: If snapshot not found or on error
    """
    # Enterprise edition: filesystem snapshots are not available — see list_snapshots.
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "Collection snapshots are not available in enterprise edition. "
                "Use GET /versions/artifacts/{artifact_id}/history for per-artifact "
                "version history."
            ),
        )
    assert version_mgr is not None, "version_mgr required in local edition"
    try:
        logger.info(f"Deleting snapshot: {snapshot_id} (collection={collection_name})")

        version_mgr.delete_snapshot(snapshot_id, collection_name)

        logger.info(f"Snapshot deleted: {snapshot_id}")
        return None

    except ValueError as e:
        logger.warning(f"Snapshot deletion failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error deleting snapshot '{snapshot_id}': {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete snapshot: {str(e)}",
        )


# ====================
# Rollback Endpoints
# ====================


@router.get(
    "/snapshots/{snapshot_id}/rollback-analysis",
    response_model=RollbackSafetyAnalysisResponse,
    summary="Analyze rollback safety",
    description="Analyze potential conflicts and safety before executing rollback",
    responses={
        200: {"description": "Successfully analyzed rollback safety"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Snapshot not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def analyze_rollback_safety(
    snapshot_id: str,
    version_mgr: VersionManagerDep,
    settings: SettingsDep,
    token: TokenDep,
    collection_name: Optional[str] = Query(
        default=None,
        description="Collection name (uses active collection if not specified)",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> RollbackSafetyAnalysisResponse:
    """Analyze whether rollback is safe before attempting.

    Performs a dry-run analysis to detect potential conflicts BEFORE
    attempting rollback. This helps users understand what will happen
    and avoid data loss from bad rollbacks.

    Args:
        snapshot_id: Snapshot identifier
        version_mgr: Version manager dependency
        settings: API settings dependency
        token: Authentication token
        collection_name: Optional collection name

    Returns:
        Rollback safety analysis

    Raises:
        HTTPException: If snapshot not found or on error
    """
    # Enterprise edition: filesystem rollback is not available.
    # Enterprise artifact restore is handled at the artifact level (ArtifactRestoreService).
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "Collection snapshot rollback is not available in enterprise edition. "
                "Use artifact-level restore endpoints for individual artifact recovery."
            ),
        )
    assert version_mgr is not None, "version_mgr required in local edition"
    try:
        logger.info(
            f"Analyzing rollback safety: {snapshot_id} (collection={collection_name})"
        )

        analysis = version_mgr.analyze_rollback_safety(snapshot_id, collection_name)

        return RollbackSafetyAnalysisResponse(
            is_safe=analysis.is_safe,
            files_with_conflicts=analysis.files_with_conflicts,
            files_safe_to_restore=analysis.files_safe_to_restore,
            warnings=analysis.warnings,
        )

    except ValueError as e:
        logger.warning(f"Rollback analysis failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(
            f"Error analyzing rollback safety for '{snapshot_id}': {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to analyze rollback safety: {str(e)}",
        )


@router.post(
    "/snapshots/{snapshot_id}/rollback",
    response_model=RollbackResponse,
    summary="Execute rollback",
    description="Rollback to a specific snapshot with optional intelligent merge",
    responses={
        200: {"description": "Successfully executed rollback"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Snapshot not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def rollback(
    snapshot_id: str,
    request: RollbackRequest,
    version_mgr: VersionManagerDep,
    settings: SettingsDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> RollbackResponse:
    """Rollback to a specific snapshot.

    Supports both simple rollback and intelligent merge-based rollback
    with selective path restoration.

    Args:
        snapshot_id: Snapshot identifier
        request: Rollback request
        version_mgr: Version manager dependency
        settings: API settings dependency
        token: Authentication token

    Returns:
        Rollback result

    Raises:
        HTTPException: If snapshot not found or on error
    """
    # Enterprise edition: filesystem rollback is not available — see analyze_rollback_safety.
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "Collection snapshot rollback is not available in enterprise edition. "
                "Use artifact-level restore endpoints for individual artifact recovery."
            ),
        )
    assert version_mgr is not None, "version_mgr required in local edition"
    try:
        logger.info(
            f"Executing rollback: {snapshot_id} "
            f"(collection={request.collection_name}, "
            f"preserve_changes={request.preserve_changes}, "
            f"selective_paths={request.selective_paths})"
        )

        # Use intelligent rollback with merge support
        result = version_mgr.intelligent_rollback(
            snapshot_id=snapshot_id,
            collection_name=request.collection_name,
            preserve_changes=request.preserve_changes,
            selective_paths=request.selective_paths,
            confirm=False,  # API doesn't support interactive confirmation
        )

        # Convert conflicts to response models
        conflicts = [
            ConflictMetadataResponse(
                file_path=conflict.file_path,
                conflict_type=conflict.conflict_type,
                auto_mergeable=conflict.auto_mergeable,
                is_binary=conflict.is_binary,
            )
            for conflict in result.conflicts
        ]

        logger.info(
            f"Rollback completed: {snapshot_id} "
            f"(success={result.success}, "
            f"files_merged={len(result.files_merged)}, "
            f"files_restored={len(result.files_restored)}, "
            f"conflicts={len(conflicts)})"
        )

        return RollbackResponse(
            success=result.success,
            files_merged=result.files_merged,
            files_restored=result.files_restored,
            conflicts=conflicts,
            safety_snapshot_id=result.safety_snapshot_id,
        )

    except ValueError as e:
        logger.warning(f"Rollback failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error executing rollback to '{snapshot_id}': {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to execute rollback: {str(e)}",
        )


# ====================
# Diff Endpoints
# ====================


@router.post(
    "/snapshots/diff",
    response_model=VersionDiffResponse,
    summary="Compare snapshots",
    description="Generate a diff showing changes between two snapshots",
    responses={
        200: {"description": "Successfully generated diff"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Snapshot not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def diff_snapshots(
    request: VersionDiffRequest,
    version_mgr: VersionManagerDep,
    settings: SettingsDep,
    diff_engine: DiffEngineDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> VersionDiffResponse:
    """Compare two snapshots and generate a diff.

    Args:
        request: Diff request with snapshot IDs
        version_mgr: Version manager dependency
        settings: API settings dependency
        diff_engine: Diff engine dependency
        token: Authentication token

    Returns:
        Diff result with changes summary

    Raises:
        HTTPException: If snapshots not found or on error
    """
    # Enterprise edition: filesystem snapshot diff is not available.
    # Use GET /versions/artifacts/{artifact_id}/diff for per-artifact version diffs.
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "Collection snapshot diff is not available in enterprise edition. "
                "Use GET /versions/artifacts/{artifact_id}/diff for per-artifact "
                "version diffs."
            ),
        )
    assert version_mgr is not None, "version_mgr required in local edition"
    try:
        logger.info(
            f"Generating diff between snapshots: "
            f"{request.snapshot_id_1} -> {request.snapshot_id_2} "
            f"(collection={request.collection_name})"
        )

        # Get both snapshots
        snapshot1 = version_mgr.get_snapshot(
            request.snapshot_id_1, request.collection_name
        )
        snapshot2 = version_mgr.get_snapshot(
            request.snapshot_id_2, request.collection_name
        )

        if not snapshot1:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Snapshot '{request.snapshot_id_1}' not found",
            )
        if not snapshot2:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Snapshot '{request.snapshot_id_2}' not found",
            )

        # Extract both snapshots to temporary directories
        with (
            tempfile.TemporaryDirectory() as tmpdir1,
            tempfile.TemporaryDirectory() as tmpdir2,
        ):
            tmpdir1_path = Path(tmpdir1)
            tmpdir2_path = Path(tmpdir2)

            # Extract tarballs
            with tarfile.open(snapshot1.tarball_path, "r:gz") as tar:
                tar.extractall(tmpdir1_path)

            with tarfile.open(snapshot2.tarball_path, "r:gz") as tar:
                tar.extractall(tmpdir2_path)

            # Find the extracted collection directories
            # (tarball contains collection_name as root directory)
            extracted1 = tmpdir1_path / snapshot1.collection_name
            extracted2 = tmpdir2_path / snapshot2.collection_name

            # Run diff engine
            diff_result = diff_engine.diff_directories(extracted1, extracted2)

            # Get modified file paths from FileDiff objects
            modified_files = [fd.path for fd in diff_result.files_modified]

            logger.info(
                f"Diff completed: "
                f"added={len(diff_result.files_added)}, "
                f"removed={len(diff_result.files_removed)}, "
                f"modified={len(modified_files)}, "
                f"lines_added={diff_result.total_lines_added}, "
                f"lines_removed={diff_result.total_lines_removed}"
            )

            return VersionDiffResponse(
                files_added=diff_result.files_added,
                files_removed=diff_result.files_removed,
                files_modified=modified_files,
                total_lines_added=diff_result.total_lines_added,
                total_lines_removed=diff_result.total_lines_removed,
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error generating diff between '{request.snapshot_id_1}' "
            f"and '{request.snapshot_id_2}': {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate diff: {str(e)}",
        )


# ====================
# Artifact Version History Endpoints (Phase 4)
# ====================


@router.get(
    "/artifacts/{artifact_id}/history",
    response_model=VersionHistoryResponse,
    summary="Get artifact version history",
    description="Retrieve paginated version history for a specific artifact",
    responses={
        200: {"description": "Successfully retrieved version history"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact_version_history(
    artifact_id: str,
    token: TokenDep,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    history_repo: DbArtifactHistoryRepoDep,
    limit: int = Query(
        default=50,
        ge=1,
        le=100,
        description="Maximum number of history items to return (1-100)",
    ),
    after: Optional[str] = Query(
        default=None,
        description="Cursor for keyset pagination (content_hash of the last seen item)",
    ),
    owner_type: Optional[str] = Query(
        default=None,
        description="Owner type filter for enterprise scoping (user, team, enterprise)",
    ),
    owner_id: Optional[str] = Query(
        default=None,
        description="Owner identifier for enterprise scoping",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> VersionHistoryResponse:
    """Get paginated version history for a specific artifact.

    Args:
        artifact_id: Artifact identifier in type:name format (e.g. skill:canvas-design)
        token: Authentication token
        limit: Maximum items per page (1-100, default 50)
        after: Cursor hash for pagination
        owner_type: Optional enterprise owner type filter
        owner_id: Optional enterprise owner ID filter
        auth_context: Authenticated user context

    Returns:
        Paginated version history response

    Raises:
        HTTPException: On error or not found
    """
    try:
        logger.info(
            "Getting version history for artifact=%s (limit=%d, after=%s)",
            artifact_id,
            limit,
            after,
        )

        if settings.edition == "enterprise":
            # Enterprise path: resolve artifact_id to UUID then delegate to
            # the repository layer (eliminates raw text() SQL at CS-1/CS-2).
            artifact_uuid_str: str = await resolve_enterprise_artifact_id(
                artifact_id, settings, artifact_repo
            )
            items_raw, has_next_page = history_repo.get_paginated_version_history(
                artifact_id=artifact_uuid_str,
                limit=limit,
                after=after,
                owner_type=owner_type,
                owner_id=owner_id,
            )
        else:
            # Local path: delegate to the repository layer (eliminates direct
            # CacheRepository() instantiation at CS-18).
            items_raw, has_next_page = history_repo.get_paginated_version_history(
                artifact_id=artifact_id,
                limit=limit,
                after=after,
                owner_type=owner_type,
                owner_id=owner_id,
            )

        if not items_raw and after is None:
            # Check if artifact exists at all — empty history is valid for a new artifact
            # but we want to surface 404 for truly unknown artifact IDs
            pass

        history_items: List[VersionHistoryItem] = []
        for item in items_raw:
            diff_summary = None
            raw_diff = item.get("diff_summary")
            if raw_diff and isinstance(raw_diff, dict):
                diff_summary = DiffSummary(
                    lines_added=raw_diff.get("lines_added", 0),
                    lines_removed=raw_diff.get("lines_removed", 0),
                )

            created_at_raw = item.get("created_at")
            from datetime import datetime

            if isinstance(created_at_raw, str):
                try:
                    created_at = datetime.fromisoformat(
                        created_at_raw.replace("Z", "+00:00")
                    )
                except ValueError:
                    created_at = datetime.utcnow()
            elif isinstance(created_at_raw, datetime):
                created_at = created_at_raw
            else:
                created_at = datetime.utcnow()

            change_origin_raw = item.get("change_origin") or "manual"
            event_type_raw = item.get("event_type") or "updated"

            # Normalise change_origin to allowed literals
            allowed_origins = {"manual", "sync", "restore", "deploy", "import", "merge"}
            if change_origin_raw not in allowed_origins:
                change_origin_raw = "manual"
            change_origin = cast(
                Literal["manual", "sync", "restore", "deploy", "import", "merge"],
                change_origin_raw,
            )

            # Normalise event_type to allowed literals
            allowed_events = {
                "created",
                "updated",
                "restored",
                "synced",
                "deployed",
                "force_sync",
            }
            if event_type_raw not in allowed_events:
                event_type_raw = "updated"
            event_type = cast(
                Literal[
                    "created", "updated", "restored", "synced", "deployed", "force_sync"
                ],
                event_type_raw,
            )

            history_items.append(
                VersionHistoryItem(
                    content_hash=item["content_hash"],
                    parent_hash=item.get("parent_hash"),
                    change_origin=change_origin,
                    created_at=created_at,
                    actor_id=item.get("actor_id"),
                    event_type=event_type,
                    diff_summary=diff_summary,
                    metadata=item.get("metadata_json"),
                )
            )

        # Build cursor from last item's content_hash
        end_cursor = (
            encode_cursor(history_items[-1].content_hash) if history_items else None
        )
        start_cursor = (
            encode_cursor(history_items[0].content_hash) if history_items else None
        )

        page_info = PageInfo(
            has_next_page=has_next_page,
            has_previous_page=after is not None,
            start_cursor=start_cursor,
            end_cursor=end_cursor,
            total_count=None,
        )

        logger.info(
            "Retrieved %d history items for artifact=%s (has_next=%s)",
            len(history_items),
            artifact_id,
            has_next_page,
        )

        return VersionHistoryResponse(
            artifact_id=artifact_id,
            items=history_items,
            page_info=page_info,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error retrieving version history for artifact '%s': %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve version history: {str(e)}",
        )


@router.get(
    "/artifacts/{artifact_id}/diff",
    response_model=ArtifactVersionDiffResponse,
    summary="Get diff between two artifact versions",
    description="Generate a unified diff between two specific content hashes for an artifact",
    responses={
        200: {"description": "Successfully generated version diff"},
        400: {"model": ErrorResponse, "description": "Invalid hash format"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact or hash not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact_version_diff(
    artifact_id: str,
    token: TokenDep,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    history_repo: DbArtifactHistoryRepoDep,
    from_hash: str = Query(
        description="SHA-256 content hash of the older (base) version",
        min_length=64,
        max_length=64,
        pattern=r"^[0-9a-f]{64}$",
    ),
    to_hash: str = Query(
        description="SHA-256 content hash of the newer (head) version",
        min_length=64,
        max_length=64,
        pattern=r"^[0-9a-f]{64}$",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> ArtifactVersionDiffResponse:
    """Generate a unified diff between two artifact content hashes.

    Args:
        artifact_id: Artifact identifier in type:name format
        token: Authentication token
        from_hash: SHA-256 hash of the base (older) version
        to_hash: SHA-256 hash of the head (newer) version
        auth_context: Authenticated user context

    Returns:
        Unified diff response with line statistics

    Raises:
        HTTPException: If hashes not found or on error
    """
    try:
        logger.info(
            "Generating version diff for artifact=%s (%s -> %s)",
            artifact_id,
            from_hash[:12],
            to_hash[:12],
        )

        import difflib

        # Resolve artifact_id to a UUID string when running in enterprise mode.
        # ArtifactVersion.artifact_id is uuid.UUID in enterprise schema, so
        # passing a type:name string directly causes a DB cast error.
        resolved_artifact_id: str = await resolve_enterprise_artifact_id(
            artifact_id, settings, artifact_repo
        )

        # Verify both version rows exist before attempting content retrieval.
        # Use the DI-provided repository (eliminates CS-3 raw session leak).
        from_version_dto = history_repo.get_by_composite_key(
            resolved_artifact_id, from_hash
        )
        to_version_dto = history_repo.get_by_composite_key(
            resolved_artifact_id, to_hash
        )

        # Fetch ORM rows for content retrieval (still needed for payload access).
        from skillmeat.cache.models import ArtifactVersion, get_session

        session = None
        from_version = None
        to_version = None
        try:
            session = get_session()
            if from_version_dto is not None:
                from_version = (
                    session.query(ArtifactVersion)
                    .filter(
                        ArtifactVersion.artifact_id == resolved_artifact_id,
                        ArtifactVersion.content_hash == from_hash,
                    )
                    .first()
                )
            if to_version_dto is not None:
                to_version = (
                    session.query(ArtifactVersion)
                    .filter(
                        ArtifactVersion.artifact_id == resolved_artifact_id,
                        ArtifactVersion.content_hash == to_hash,
                    )
                    .first()
                )
        finally:
            if session:
                session.close()

        if from_version_dto is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    f"Version hash '{from_hash[:12]}...' not found "
                    f"for artifact '{artifact_id}'"
                ),
            )
        if to_version_dto is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    f"Version hash '{to_hash[:12]}...' not found "
                    f"for artifact '{artifact_id}'"
                ),
            )

        restore_svc = ArtifactRestoreService()
        unified_diff = ""
        lines_added = 0
        lines_removed = 0

        # Retrieve content for both versions.  Tries (in order):
        # 1. ArtifactVersion.content_payload (inline storage)
        # 2. Enterprise markdown_payload
        # 3. Current filesystem match (if hash matches)
        # 4. Snapshot scan
        # In enterprise mode, artifact_id may be a UUID (no colon).
        # Skip filesystem path resolution; content retrieval falls back to DB.
        with restore_svc._get_session() as svc_session:
            if ":" in artifact_id:
                artifact_type_str, artifact_name = artifact_id.split(":", 1)
                artifact_path = restore_svc._resolve_artifact_path(
                    svc_session, artifact_id, artifact_type_str, artifact_name
                )
            else:
                artifact_path = None
            from_content = restore_svc._retrieve_version_content(
                session=svc_session,
                artifact_id=artifact_id,
                artifact_path=artifact_path,
                target_content_hash=from_hash,
            )
            to_content = restore_svc._retrieve_version_content(
                session=svc_session,
                artifact_id=artifact_id,
                artifact_path=artifact_path,
                target_content_hash=to_hash,
            )

        is_binary = False
        if (
            from_content is not None
            and b"\x00" in from_content.encode("utf-8", errors="replace")[:8192]
        ):
            is_binary = True
        if (
            to_content is not None
            and b"\x00" in to_content.encode("utf-8", errors="replace")[:8192]
        ):
            is_binary = True

        if not is_binary:
            if from_content is None or to_content is None:
                # Content not available — return empty diff
                logger.warning(
                    "Cannot retrieve raw content for diff (artifact=%s, "
                    "from=%s available=%s, to=%s available=%s) — returning empty diff",
                    artifact_id,
                    from_hash[:12],
                    from_content is not None,
                    to_hash[:12],
                    to_content is not None,
                )
            else:
                from_lines = from_content.splitlines(keepends=True)
                to_lines = to_content.splitlines(keepends=True)
                diff_lines = list(
                    difflib.unified_diff(
                        from_lines,
                        to_lines,
                        fromfile=f"a/{artifact_id}@{from_hash[:12]}",
                        tofile=f"b/{artifact_id}@{to_hash[:12]}",
                    )
                )
                unified_diff = "".join(diff_lines)
                lines_added = sum(
                    1
                    for ln in diff_lines
                    if ln.startswith("+") and not ln.startswith("+++")
                )
                lines_removed = sum(
                    1
                    for ln in diff_lines
                    if ln.startswith("-") and not ln.startswith("---")
                )

        logger.info(
            "Version diff for artifact=%s: +%d/-%d lines (binary=%s)",
            artifact_id,
            lines_added,
            lines_removed,
            is_binary,
        )

        return ArtifactVersionDiffResponse(
            artifact_id=artifact_id,
            from_hash=from_hash,
            to_hash=to_hash,
            unified_diff=unified_diff,
            lines_added=lines_added,
            lines_removed=lines_removed,
            is_binary=is_binary,
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning("Version diff failed for artifact '%s': %s", artifact_id, e)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(
            "Error generating version diff for artifact '%s': %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate version diff: {str(e)}",
        )


@router.post(
    "/artifacts/{artifact_id}/restore",
    response_model=RestoreResponse,
    summary="Restore artifact to a previous version",
    description=(
        "Restore an artifact to a previously recorded content hash. "
        "For composite artifacts, optionally restores member artifacts atomically."
    ),
    responses={
        200: {"description": "Successfully restored artifact"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact or hash not found"},
        409: {"model": ErrorResponse, "description": "Concurrent restore conflict"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def restore_artifact(
    artifact_id: str,
    request: RestoreRequest,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> RestoreResponse:
    """Restore an artifact to a previous version hash.

    Implements the write-through restore pattern:
    1. Retrieve target version content from snapshots or DB.
    2. Write content to the artifact's filesystem path.
    3. Sync the DB cache via refresh_single_artifact_cache.
    4. Append a new ArtifactVersion row (change_origin='restore').

    For composite artifacts with restore_members=True, restores all member
    artifacts atomically (all-or-nothing with rollback on failure).

    Args:
        artifact_id: Artifact identifier in type:name format
        request: Restore request with target_hash and options
        token: Authentication token
        auth_context: Authenticated user context with write scope

    Returns:
        Restore result with new version hash and event ID

    Raises:
        HTTPException: 404 on missing artifact/hash, 409 on concurrent restore,
                       500 on internal error
    """
    try:
        logger.info(
            "Restoring artifact=%s to hash=%s (restore_members=%s, actor=%s)",
            artifact_id,
            request.target_hash[:12],
            request.restore_members,
            getattr(auth_context, "user_id", None),
        )

        actor_id = str(getattr(auth_context, "user_id", "")) or None

        if request.restore_members and request.member_hashes:
            # Composite restore: use CompositeArtifactRestoreService
            restore_svc = ArtifactRestoreService()
            composite_svc = CompositeArtifactRestoreService(restore_service=restore_svc)

            composite_result = composite_svc.restore_with_members(
                composite_artifact_id=artifact_id,
                member_hashes=request.member_hashes,
                restoring_user=actor_id,
            )

            if not composite_result.get("success"):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=composite_result.get("message", "Composite restore failed"),
                )

            members_restored = [
                m["artifact_id"]
                for m in composite_result.get("members_restored", [])
                if m.get("success")
            ]

            # For composite, also restore the composite parent if target_hash was provided
            restore_svc_parent = ArtifactRestoreService()
            parent_result = restore_svc_parent.restore_single(
                artifact_id=artifact_id,
                target_content_hash=request.target_hash,
                restoring_user=actor_id,
            )

            new_version_hash = parent_result.get("restored_hash", request.target_hash)
            event_id = f"evt_{new_version_hash[:16]}"

        else:
            # Single artifact restore
            restore_svc = ArtifactRestoreService()
            result = restore_svc.restore_single(
                artifact_id=artifact_id,
                target_content_hash=request.target_hash,
                restoring_user=actor_id,
            )

            if not result.get("success"):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=result.get("message", "Restore failed"),
                )

            new_version_hash = result.get("restored_hash", request.target_hash)
            members_restored = []
            event_id = f"evt_{new_version_hash[:16]}"

        logger.info(
            "Artifact %s successfully restored to hash %s (event_id=%s)",
            artifact_id,
            request.target_hash[:12],
            event_id,
        )

        return RestoreResponse(
            artifact_id=artifact_id,
            restored_to_hash=request.target_hash,
            new_version_hash=new_version_hash,
            members_restored=members_restored,
            event_id=event_id,
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning("Restore failed for artifact '%s': %s", artifact_id, e)
        error_msg = str(e)
        if "not found" in error_msg.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=error_msg,
            )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error_msg,
        )
    except Exception as e:
        logger.error("Error restoring artifact '%s': %s", artifact_id, e, exc_info=True)
        if "concurrent" in str(e).lower() or "integrity" in str(e).lower():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Concurrent restore conflict detected. Please retry.",
            )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to restore artifact: {str(e)}",
        )


@router.get(
    "/artifacts/{artifact_id}/restore-preview",
    response_model=ArtifactVersionDiffResponse,
    summary="Preview restore diff (no side effects)",
    description=(
        "Preview the diff between the current artifact state and a target version hash. "
        "This is a read-only operation with no side effects."
    ),
    responses={
        200: {"description": "Successfully generated restore preview"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact or hash not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_restore_preview(
    artifact_id: str,
    token: TokenDep,
    target_hash: str = Query(
        description="SHA-256 content hash of the version to preview restoring to",
        min_length=64,
        max_length=64,
        pattern=r"^[0-9a-f]{64}$",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> ArtifactVersionDiffResponse:
    """Preview the diff that would result from restoring to a target hash.

    This endpoint is idempotent: it does not write to the filesystem or
    modify the database. Use it to review what a restore would change
    before committing.

    Args:
        artifact_id: Artifact identifier in type:name format
        token: Authentication token
        target_hash: SHA-256 hash of the version to preview
        auth_context: Authenticated user context

    Returns:
        Unified diff showing what the restore would change

    Raises:
        HTTPException: 404 on missing artifact/hash, 500 on error
    """
    try:
        logger.info(
            "Generating restore preview for artifact=%s target_hash=%s",
            artifact_id,
            target_hash[:12],
        )

        restore_svc = ArtifactRestoreService()
        preview = restore_svc.get_restore_preview(
            artifact_id=artifact_id,
            target_content_hash=target_hash,
        )

        current_hash = preview.get("current_hash") or target_hash

        logger.info(
            "Restore preview for artifact=%s: +%d/-%d lines (binary=%s)",
            artifact_id,
            preview.get("lines_added", 0),
            preview.get("lines_removed", 0),
            preview.get("is_binary", False),
        )

        return ArtifactVersionDiffResponse(
            artifact_id=artifact_id,
            from_hash=current_hash,
            to_hash=target_hash,
            unified_diff=preview.get("diff", ""),
            lines_added=preview.get("lines_added", 0),
            lines_removed=preview.get("lines_removed", 0),
            is_binary=preview.get("is_binary", False),
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning("Restore preview failed for artifact '%s': %s", artifact_id, e)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(
            "Error generating restore preview for artifact '%s': %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate restore preview: {str(e)}",
        )


# ====================
# Enterprise Scope Endpoints (Phase 4)
# ====================


def _require_enterprise_or_404(auth_context: AuthContext, operation: str) -> None:
    """Raise 404 if not in enterprise edition context.

    Enterprise scope endpoints return 404 (not 403) to avoid leaking
    edition information to unprivileged callers.

    Args:
        auth_context: Current auth context
        operation: Operation name for logging
    """
    # Local auth contexts have no tenant_id; treat as non-enterprise
    tenant_id = getattr(auth_context, "tenant_id", None)
    if tenant_id is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Enterprise feature '{operation}' not available in this edition",
        )


def _require_admin_role(auth_context: AuthContext) -> None:
    """Raise 403 if the caller does not have team_admin or system_admin role.

    Args:
        auth_context: Current auth context

    Raises:
        HTTPException: 403 if insufficient role
    """
    if not (
        auth_context.has_role(Role.team_admin)
        or auth_context.has_role(Role.system_admin)
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This operation requires team_admin or system_admin role",
        )


@router.get(
    "/artifacts/{artifact_id}/scopes",
    response_model=List[VersionScopeResponse],
    summary="List enterprise version scopes for an artifact",
    description=(
        "List all enterprise version scopes for a specific artifact. "
        "Returns 404 in non-enterprise editions."
    ),
    responses={
        200: {"description": "Successfully retrieved scopes"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Artifact not found or not enterprise edition",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def list_artifact_scopes(
    artifact_id: str,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> List[VersionScopeResponse]:
    """List enterprise version scopes for a specific artifact.

    Args:
        artifact_id: Artifact identifier in type:name format
        db_session: Database session (enterprise PostgreSQL)
        auth_context: Authenticated user context

    Returns:
        List of version scope records for the artifact

    Raises:
        HTTPException: 404 if non-enterprise or artifact missing, 500 on error
    """
    _require_enterprise_or_404(auth_context, "list_scopes")

    try:
        import uuid

        from sqlalchemy import select

        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope
        from skillmeat.core.enterprise_version_scope import (
            EnterpriseVersionScopeService,
        )

        tenant_id = uuid.UUID(str(auth_context.tenant_id))

        # Direct tenant-scoped query on artifact_id (UUID stored as string in
        # some backends; cast both sides to string for portability).
        stmt = (
            select(EnterpriseArtifactVersionScope)
            .where(EnterpriseArtifactVersionScope.tenant_id == tenant_id)
            .order_by(EnterpriseArtifactVersionScope.created_at.asc())
        )
        scope_rows = list(db_session.execute(stmt).scalars().all())

        # Filter client-side by artifact_id string to avoid DB cast issues
        scope_rows = [s for s in scope_rows if str(s.artifact_id) == artifact_id]

        result: List[VersionScopeResponse] = []
        for scope in scope_rows:
            scope_dict = EnterpriseVersionScopeService._scope_to_dict(scope)
            result.append(
                VersionScopeResponse(
                    id=scope_dict["id"],
                    artifact_id=artifact_id,
                    owner_type=scope_dict["owner_type"],
                    owner_id=scope_dict["owner_id"],
                    head_hash=scope_dict["head_hash"],
                    baseline_hash=scope_dict.get("baseline_hash"),
                    is_diverged=scope_dict.get("is_diverged", False),
                    promotion_state=scope_dict.get("promotion_state", "none"),
                    promotion_requested_at=scope_dict.get("promotion_requested_at"),
                    promotion_reviewed_by=scope_dict.get("promotion_reviewed_by"),
                    promotion_reviewed_at=scope_dict.get("promotion_reviewed_at"),
                )
            )

        logger.info(
            "Listed %d scopes for artifact=%s tenant=%s",
            len(result),
            artifact_id,
            tenant_id,
        )
        return result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Error listing scopes for artifact '%s': %s", artifact_id, e, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list artifact scopes: {str(e)}",
        )


@router.post(
    "/artifacts/{artifact_id}/scopes/{scope_id}/promote",
    response_model=VersionScopeResponse,
    summary="Request a promotion for a version scope",
    description="Submit a promotion request for a version scope to the enterprise governance workflow.",
    responses={
        200: {"description": "Successfully submitted promotion request"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid promotion state transition",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Scope not found or not enterprise edition",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def request_scope_promotion(
    artifact_id: str,
    scope_id: str,
    request: PromotionRequest,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> VersionScopeResponse:
    """Submit a promotion request for an enterprise version scope.

    Args:
        artifact_id: Artifact identifier in type:name format
        scope_id: Version scope identifier
        request: Promotion request (approval flag)
        db_session: Database session
        auth_context: Authenticated user context with write scope

    Returns:
        Updated version scope record

    Raises:
        HTTPException: 400 on invalid state, 404 on missing scope, 500 on error
    """
    _require_enterprise_or_404(auth_context, "request_promotion")

    try:
        import uuid

        from skillmeat.core.enterprise_version_scope import (
            EnterpriseVersionScopeService,
        )

        svc = EnterpriseVersionScopeService(db_session)
        tenant_id = uuid.UUID(str(auth_context.tenant_id))
        user_id = uuid.UUID(str(auth_context.user_id))
        scope_uuid = uuid.UUID(scope_id)

        updated = svc.create_promotion_request(
            scope_id=scope_uuid,
            tenant_id=tenant_id,
            requesting_user_id=user_id,
        )

        db_session.commit()

        logger.info(
            "Promotion requested for scope=%s artifact=%s by user=%s",
            scope_id,
            artifact_id,
            user_id,
        )

        return VersionScopeResponse(
            id=updated["id"],
            artifact_id=artifact_id,
            owner_type=updated["owner_type"],
            owner_id=str(updated["owner_id"]),
            head_hash=updated["head_hash"],
            baseline_hash=updated.get("baseline_hash"),
            is_diverged=updated.get("is_diverged", False),
            promotion_state=updated.get("promotion_state", "none"),
            promotion_requested_at=updated.get("promotion_requested_at"),
            promotion_reviewed_by=updated.get("promotion_reviewed_by"),
            promotion_reviewed_at=updated.get("promotion_reviewed_at"),
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning("Promotion request failed for scope '%s': %s", scope_id, e)
        error_msg = str(e)
        if "not found" in error_msg.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=error_msg,
            )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error_msg,
        )
    except Exception as e:
        logger.error(
            "Error requesting promotion for scope '%s': %s", scope_id, e, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to request promotion: {str(e)}",
        )


@router.post(
    "/scopes/{scope_id}/review",
    response_model=VersionScopeResponse,
    summary="Review (approve/reject) a pending promotion",
    description=(
        "Approve or reject a pending promotion request for an enterprise version scope. "
        "Requires team_admin or system_admin role."
    ),
    responses={
        200: {"description": "Successfully reviewed promotion"},
        400: {"model": ErrorResponse, "description": "Invalid review state transition"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        403: {"model": ErrorResponse, "description": "Insufficient role"},
        404: {
            "model": ErrorResponse,
            "description": "Scope not found or not enterprise edition",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def review_scope_promotion(
    scope_id: str,
    request: ReviewRequest,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> VersionScopeResponse:
    """Review (approve or reject) a pending promotion request.

    Requires team_admin or system_admin role.

    Args:
        scope_id: Version scope identifier
        request: Review request (approved flag and optional rejection_reason)
        db_session: Database session
        auth_context: Authenticated user context

    Returns:
        Updated version scope record

    Raises:
        HTTPException: 400 on invalid state, 403 on insufficient role,
                       404 on missing scope, 500 on error
    """
    _require_enterprise_or_404(auth_context, "review_promotion")
    _require_admin_role(auth_context)

    try:
        import uuid

        from skillmeat.core.enterprise_version_scope import (
            EnterpriseVersionScopeService,
        )

        svc = EnterpriseVersionScopeService(db_session)
        tenant_id = uuid.UUID(str(auth_context.tenant_id))
        reviewer_id = uuid.UUID(str(auth_context.user_id))
        scope_uuid = uuid.UUID(scope_id)

        if request.approved:
            updated = svc.approve_promotion(
                scope_id=scope_uuid,
                tenant_id=tenant_id,
                reviewer_id=reviewer_id,
            )
        else:
            updated = svc.reject_promotion(
                scope_id=scope_uuid,
                tenant_id=tenant_id,
                reviewer_id=reviewer_id,
            )

        db_session.commit()

        action = "approved" if request.approved else "rejected"
        logger.info(
            "Promotion %s for scope=%s by reviewer=%s",
            action,
            scope_id,
            reviewer_id,
        )

        # resolve artifact_id from scope
        artifact_id = str(updated.get("artifact_id", ""))

        return VersionScopeResponse(
            id=updated["id"],
            artifact_id=artifact_id,
            owner_type=updated["owner_type"],
            owner_id=str(updated["owner_id"]),
            head_hash=updated["head_hash"],
            baseline_hash=updated.get("baseline_hash"),
            is_diverged=updated.get("is_diverged", False),
            promotion_state=updated.get("promotion_state", "none"),
            promotion_requested_at=updated.get("promotion_requested_at"),
            promotion_reviewed_by=updated.get("promotion_reviewed_by"),
            promotion_reviewed_at=updated.get("promotion_reviewed_at"),
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning("Promotion review failed for scope '%s': %s", scope_id, e)
        error_msg = str(e)
        if "not found" in error_msg.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=error_msg,
            )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error_msg,
        )
    except Exception as e:
        logger.error(
            "Error reviewing promotion for scope '%s': %s", scope_id, e, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to review promotion: {str(e)}",
        )


@router.post(
    "/scopes/{scope_id}/force-sync",
    response_model=VersionScopeResponse,
    summary="Force-sync a version scope to a specific hash",
    description=(
        "Directly set a version scope's head hash, bypassing the normal promotion workflow. "
        "Requires team_admin or system_admin role."
    ),
    responses={
        200: {"description": "Successfully force-synced scope"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        403: {"model": ErrorResponse, "description": "Insufficient role"},
        404: {
            "model": ErrorResponse,
            "description": "Scope not found or not enterprise edition",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def force_sync_scope(
    scope_id: str,
    request: ForceSyncRequest,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> VersionScopeResponse:
    """Force-sync a version scope to a specific content hash.

    Bypasses the promotion workflow and directly updates the scope's head hash.
    Resets promotion state to 'none' after force-sync.
    Requires team_admin or system_admin role.

    Args:
        scope_id: Version scope identifier
        request: Force-sync request with target_hash
        db_session: Database session
        auth_context: Authenticated user context

    Returns:
        Updated version scope record

    Raises:
        HTTPException: 403 on insufficient role, 404 on missing scope, 500 on error
    """
    _require_enterprise_or_404(auth_context, "force_sync")
    _require_admin_role(auth_context)

    try:
        import uuid

        from skillmeat.core.enterprise_version_scope import (
            EnterpriseVersionScopeService,
        )
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseArtifactVersionScopeRepository,
        )

        svc = EnterpriseVersionScopeService(db_session)
        repo = EnterpriseArtifactVersionScopeRepository(db_session)
        tenant_id = uuid.UUID(str(auth_context.tenant_id))
        actor_id = uuid.UUID(str(auth_context.user_id))
        scope_uuid = uuid.UUID(scope_id)

        # Force-sync: update head_hash and reset promotion state
        updated_scope = repo.update_head_hash(
            scope_id=scope_uuid,
            tenant_id=tenant_id,
            new_hash=request.target_hash,
        )

        # Reset promotion state machine after force-sync
        updated = svc.reset_promotion_state(
            scope_id=scope_uuid,
            tenant_id=tenant_id,
        )

        db_session.commit()

        logger.info(
            "Force-synced scope=%s to hash=%s by actor=%s",
            scope_id,
            request.target_hash[:12],
            actor_id,
        )

        artifact_id = str(updated.get("artifact_id", ""))

        return VersionScopeResponse(
            id=updated["id"],
            artifact_id=artifact_id,
            owner_type=updated["owner_type"],
            owner_id=str(updated["owner_id"]),
            head_hash=updated.get("head_hash", request.target_hash),
            baseline_hash=updated.get("baseline_hash"),
            is_diverged=updated.get("is_diverged", False),
            promotion_state=updated.get("promotion_state", "none"),
            promotion_requested_at=updated.get("promotion_requested_at"),
            promotion_reviewed_by=updated.get("promotion_reviewed_by"),
            promotion_reviewed_at=updated.get("promotion_reviewed_at"),
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning("Force-sync failed for scope '%s': %s", scope_id, e)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error("Error force-syncing scope '%s': %s", scope_id, e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to force-sync scope: {str(e)}",
        )


# ====================
# Admin Endpoints (Phase 4)
# ====================


@router.get(
    "/admin/summary",
    response_model=AdminVersionSummaryResponse,
    summary="Admin summary of artifact version scopes",
    description=(
        "Retrieve a paginated admin summary of artifact version scopes across "
        "projects and owners. Requires team_admin or system_admin role."
    ),
    responses={
        200: {"description": "Successfully retrieved admin summary"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        403: {"model": ErrorResponse, "description": "Insufficient role"},
        404: {"model": ErrorResponse, "description": "Not available in this edition"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_admin_version_summary(
    db_session: DbSessionDep,
    project_id: Optional[str] = Query(default=None, description="Filter by project ID"),
    team_id: Optional[str] = Query(default=None, description="Filter by team ID"),
    user_id: Optional[str] = Query(default=None, description="Filter by user ID"),
    artifact_id: Optional[str] = Query(
        default=None, description="Filter by artifact ID"
    ),
    diverged_only: bool = Query(
        default=False, description="Only return diverged scopes"
    ),
    limit: int = Query(
        default=50,
        ge=1,
        le=100,
        description="Maximum items per page (1-100)",
    ),
    after: Optional[str] = Query(default=None, description="Cursor for pagination"),
    auth_context: AuthContext = Depends(require_auth()),
) -> AdminVersionSummaryResponse:
    """Get admin summary of artifact version scopes.

    Requires team_admin or system_admin role. Returns paginated list of
    version scope summaries with divergence and promotion state.

    Args:
        db_session: Database session
        project_id: Optional project filter
        team_id: Optional team filter
        user_id: Optional user filter
        artifact_id: Optional artifact filter
        diverged_only: If True, only return diverged scopes
        limit: Max items per page
        after: Pagination cursor
        auth_context: Authenticated user context

    Returns:
        Paginated admin version summary

    Raises:
        HTTPException: 403 on insufficient role, 404 on non-enterprise, 500 on error
    """
    _require_enterprise_or_404(auth_context, "admin_summary")
    _require_admin_role(auth_context)

    try:
        import uuid

        from sqlalchemy import select

        from skillmeat.cache.models_enterprise import EnterpriseArtifactVersionScope
        from skillmeat.core.enterprise_version_scope import (
            EnterpriseVersionScopeService,
        )

        tenant_id = uuid.UUID(str(auth_context.tenant_id))

        # Build a direct SQLAlchemy query with available filters.
        stmt = select(EnterpriseArtifactVersionScope).where(
            EnterpriseArtifactVersionScope.tenant_id == tenant_id
        )

        if project_id:
            stmt = stmt.where(
                EnterpriseArtifactVersionScope.project_id == uuid.UUID(project_id)
            )

        if team_id:
            # team_id filter: owner_type='team' AND owner_id=team_id
            stmt = stmt.where(
                EnterpriseArtifactVersionScope.owner_type == "team"
            ).where(EnterpriseArtifactVersionScope.owner_id == uuid.UUID(team_id))

        if user_id:
            stmt = stmt.where(
                EnterpriseArtifactVersionScope.owner_type == "user"
            ).where(EnterpriseArtifactVersionScope.owner_id == uuid.UUID(user_id))

        if diverged_only:
            stmt = stmt.where(EnterpriseArtifactVersionScope.is_diverged.is_(True))

        # Cursor-based pagination on the scope's created_at
        if after:
            cursor_val = decode_cursor(after)
            # cursor is formatted as "scope_id" for admin summary
            try:
                cursor_uuid = uuid.UUID(cursor_val)
                from sqlalchemy import and_

                cursor_row = db_session.get(EnterpriseArtifactVersionScope, cursor_uuid)
                if cursor_row is not None:
                    stmt = stmt.where(
                        EnterpriseArtifactVersionScope.created_at
                        < cursor_row.created_at
                    )
            except (ValueError, AttributeError):
                pass  # invalid cursor — skip pagination

        stmt = stmt.order_by(EnterpriseArtifactVersionScope.created_at.desc()).limit(
            limit + 1
        )

        scope_rows = list(db_session.execute(stmt).scalars().all())

        # Client-side artifact_id filter (string comparison)
        if artifact_id:
            scope_rows = [s for s in scope_rows if str(s.artifact_id) == artifact_id]

        has_next = len(scope_rows) > limit
        if has_next:
            scope_rows = scope_rows[:limit]

        # Batch-load artifact names to avoid N+1 queries.
        from skillmeat.cache.models_enterprise import (
            EnterpriseArtifact,
            EnterpriseTeam,
            EnterpriseUser,
        )

        unique_artifact_ids = {
            scope.artifact_id for scope in scope_rows if scope.artifact_id is not None
        }
        artifact_names: dict[str, str] = {}
        if unique_artifact_ids:
            art_stmt = select(EnterpriseArtifact.id, EnterpriseArtifact.name).where(
                EnterpriseArtifact.id.in_(unique_artifact_ids)
            )
            for art_id, art_name in db_session.execute(art_stmt).all():
                artifact_names[str(art_id)] = art_name

        # Batch-load owner display names, split by owner_type.
        user_owner_ids = {
            scope.owner_id
            for scope in scope_rows
            if scope.owner_type == "user" and scope.owner_id is not None
        }
        team_owner_ids = {
            scope.owner_id
            for scope in scope_rows
            if scope.owner_type == "team" and scope.owner_id is not None
        }
        owner_names: dict[str, str] = {}
        if user_owner_ids:
            user_stmt = select(
                EnterpriseUser.id, EnterpriseUser.display_name, EnterpriseUser.email
            ).where(EnterpriseUser.id.in_(user_owner_ids))
            for u_id, display_name, email in db_session.execute(user_stmt).all():
                owner_names[str(u_id)] = display_name or email or str(u_id)
        if team_owner_ids:
            team_stmt = select(EnterpriseTeam.id, EnterpriseTeam.name).where(
                EnterpriseTeam.id.in_(team_owner_ids)
            )
            for t_id, t_name in db_session.execute(team_stmt).all():
                owner_names[str(t_id)] = t_name

        items: List[AdminVersionSummaryItem] = []
        for scope in scope_rows:
            scope_dict = EnterpriseVersionScopeService._scope_to_dict(scope)
            scope_artifact_id = str(scope_dict.get("artifact_id", ""))
            raw_owner_id = scope_dict["owner_id"]
            # For enterprise-scoped owners, provide a literal label rather than
            # a UUID string that would be meaningless in the UI.
            if scope_dict["owner_type"] == "enterprise":
                resolved_owner_name: Optional[str] = "Enterprise"
            else:
                resolved_owner_name = owner_names.get(raw_owner_id)
            items.append(
                AdminVersionSummaryItem(
                    scope_id=scope.id,
                    artifact_id=scope_artifact_id,
                    artifact_name=artifact_names.get(
                        scope_artifact_id, scope_artifact_id
                    ),
                    owner_type=scope_dict["owner_type"],
                    owner_id=raw_owner_id,
                    owner_display_name=resolved_owner_name,
                    head_hash=scope_dict["head_hash"],
                    baseline_hash=scope_dict.get("baseline_hash"),
                    is_diverged=scope_dict.get("is_diverged", False),
                    promotion_state=scope_dict.get("promotion_state", "none"),
                    last_modified_at=scope_dict.get("updated_at"),
                    modified_by=scope_dict.get("promotion_reviewed_by"),
                )
            )

        end_cursor = encode_cursor(str(scope_rows[-1].id)) if scope_rows else None
        start_cursor = encode_cursor(str(scope_rows[0].id)) if scope_rows else None

        page_info = PageInfo(
            has_next_page=has_next,
            has_previous_page=after is not None,
            start_cursor=start_cursor,
            end_cursor=end_cursor,
            total_count=None,
        )

        logger.info(
            "Admin summary: returned %d scopes (diverged_only=%s, has_next=%s)",
            len(items),
            diverged_only,
            has_next,
        )

        return AdminVersionSummaryResponse(items=items, page_info=page_info)

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error generating admin version summary: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate admin version summary: {str(e)}",
        )


@router.post(
    "/admin/bulk-action",
    response_model=List[str],
    summary="Perform a bulk admin action on version scopes",
    description=(
        "Apply a bulk action (force-sync, approve, reject) to multiple version scopes "
        "in a single transactional operation. Requires team_admin or system_admin role."
    ),
    responses={
        200: {"description": "Successfully applied bulk action"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid scope IDs or missing target_hash",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        403: {"model": ErrorResponse, "description": "Insufficient role"},
        404: {"model": ErrorResponse, "description": "Not available in this edition"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def admin_bulk_action(
    request: AdminBulkActionRequest,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> List[str]:
    """Apply a bulk action to multiple version scopes transactionally.

    All scopes are processed in a single transaction: if any operation fails,
    all changes are rolled back.

    Supported actions:
    - force-sync: requires target_hash
    - approve: approve pending promotions
    - reject: reject pending promotions

    Args:
        request: Bulk action request with scope_ids and action
        db_session: Database session
        auth_context: Authenticated user context

    Returns:
        List of affected scope IDs

    Raises:
        HTTPException: 400 on invalid input, 403 on insufficient role,
                       404 on non-enterprise, 500 on error
    """
    _require_enterprise_or_404(auth_context, "admin_bulk_action")
    _require_admin_role(auth_context)

    if request.action == "force-sync" and not request.target_hash:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="target_hash is required when action='force-sync'",
        )

    try:
        import uuid

        from skillmeat.core.enterprise_version_scope import (
            EnterpriseVersionScopeService,
        )
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseArtifactVersionScopeRepository,
        )

        svc = EnterpriseVersionScopeService(db_session)
        repo = EnterpriseArtifactVersionScopeRepository(db_session)
        tenant_id = uuid.UUID(str(auth_context.tenant_id))
        actor_id = uuid.UUID(str(auth_context.user_id))

        # Validate all scope_ids exist before processing any
        scope_uuids: List[uuid.UUID] = []
        for scope_id_str in request.scope_ids:
            try:
                scope_uuids.append(uuid.UUID(scope_id_str))
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid scope_id format: '{scope_id_str}'",
                )

        affected_ids: List[str] = []

        for scope_uuid in scope_uuids:
            if request.action == "force-sync":
                # request.target_hash is guaranteed non-None here: the guard at
                # the top of this handler raises 400 when action=='force-sync'
                # and target_hash is falsy, so cast is safe.
                repo.update_head_hash(
                    scope_id=scope_uuid,
                    tenant_id=tenant_id,
                    new_hash=cast(str, request.target_hash),
                )
                svc.reset_promotion_state(
                    scope_id=scope_uuid,
                    tenant_id=tenant_id,
                )
            elif request.action == "approve":
                svc.approve_promotion(
                    scope_id=scope_uuid,
                    tenant_id=tenant_id,
                    reviewer_id=actor_id,
                )
            elif request.action == "reject":
                svc.reject_promotion(
                    scope_id=scope_uuid,
                    tenant_id=tenant_id,
                    reviewer_id=actor_id,
                )

            affected_ids.append(str(scope_uuid))

        db_session.commit()

        logger.info(
            "Bulk action '%s' applied to %d scopes by actor=%s",
            request.action,
            len(affected_ids),
            actor_id,
        )

        return affected_ids

    except HTTPException:
        db_session.rollback()
        raise
    except ValueError as e:
        db_session.rollback()
        logger.warning("Bulk action failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        db_session.rollback()
        logger.error("Error applying bulk action: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to apply bulk action: {str(e)}",
        )


# ====================
# Backfill Endpoints (VCS v2 — Phase 2)
# ====================


@router.get(
    "/backfill/status",
    response_model=BackfillStatusResponse,
    summary="Get version backfill status",
    description=(
        "Return the current state of the async initial-seed backfill task "
        "that seeds ArtifactVersion rows for artifacts that have none.  "
        "Useful for hydration-banner display in the UI."
    ),
    responses={
        200: {"description": "Backfill status retrieved successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
    },
)
async def get_version_backfill_status() -> BackfillStatusResponse:
    """Return the current progress of the version backfill task.

    The response ``status`` field cycles through:
    - ``idle``: the task has never been started this server session.
    - ``running``: the task is currently executing.
    - ``complete``: the task finished (with or without per-artifact failures).
    """
    from skillmeat.core.version_backfill import get_backfill_status

    state = get_backfill_status()
    return BackfillStatusResponse(
        status=state["status"],
        total=state["total"],
        seeded=state["seeded"],
        failed=state["failed"],
        started_at=state.get("started_at"),
        completed_at=state.get("completed_at"),
    )


@router.post(
    "/backfill/trigger",
    response_model=BackfillStatusResponse,
    summary="Trigger version backfill",
    description=(
        "Start the version backfill task to seed initial versions for all artifacts. "
        "Safe to call multiple times — idempotent guard prevents concurrent runs. "
        "If the backfill is already running, returns current progress without starting a new run."
    ),
    tags=["versions"],
    responses={
        200: {
            "description": "Backfill triggered (or already running); current status returned"
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
    },
)
async def trigger_version_backfill(
    auth_context: AuthContext = Depends(get_auth_context),
) -> BackfillStatusResponse:
    """Trigger the version backfill task.

    Returns the current backfill status after starting. If already running,
    returns the current progress without starting a new run.
    """
    import asyncio

    from skillmeat.core.version_backfill import (
        get_backfill_status,
        run_version_backfill,
    )

    state = get_backfill_status()
    if state["status"] != "running":
        asyncio.create_task(run_version_backfill())

    # Return fresh status (may still show 'idle' briefly before task updates state)
    state = get_backfill_status()
    return BackfillStatusResponse(
        status=state["status"],
        total=state["total"],
        seeded=state["seeded"],
        failed=state["failed"],
        started_at=state.get("started_at"),
        completed_at=state.get("completed_at"),
    )


# ====================
# VCS v2 Topology & Promote Endpoints
# ====================

from skillmeat.api.schemas.vcs_v2 import (  # noqa: E402
    ConflictDTO,
    PromoteArtifactRequestDTO,
    PromoteArtifactResponseDTO,
)


def get_version_topology_service(
    db_session: DbSessionDep,
    settings: SettingsDep,
):
    """Get VersionTopologyService dependency.

    Args:
        db_session: Active database session from request scope.
        settings: API settings (used for edition routing).

    Returns:
        VersionTopologyService instance bound to the request session.
    """
    from skillmeat.core.version_topology_service import VersionTopologyService

    return VersionTopologyService(db_session, edition=settings.edition)


@router.get(
    "/artifacts/{artifact_id}/topology",
    response_model=None,
    summary="Get version topology for an artifact",
    description=(
        "Return the current collection version record and all project deployment "
        "records for the given artifact.  Returns 404 when the artifact has never "
        "been tracked by the VCS layer."
    ),
    responses={
        200: {"description": "Topology retrieved successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Artifact not found in the VCS layer",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact_topology(
    artifact_id: str,
    token: TokenDep,
    db_session: DbSessionDep,
    settings: SettingsDep,
    auth_context: AuthContext = Depends(require_auth()),
):
    """Return the cross-deployment topology for an artifact.

    Args:
        artifact_id: Artifact identifier in type:name format.
        token: Authentication token.
        db_session: Database session.
        settings: API settings for edition routing.
        auth_context: Authenticated user context.

    Returns:
        VersionTopologyDTO with collection version and deployment records.

    Raises:
        HTTPException: 404 when the artifact is unknown to the VCS layer.
        HTTPException: 500 on unexpected errors.
    """
    from skillmeat.core.version_topology_service import VersionTopologyService

    svc = VersionTopologyService(db_session, edition=settings.edition)
    try:
        topology = await svc.get_topology(artifact_id, auth_context)
    except Exception as e:
        logger.error(
            "get_artifact_topology failed for artifact_id=%r: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve topology: {str(e)}",
        )

    if topology is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Artifact '{artifact_id}' has no VCS tracking records.",
        )

    return topology


@router.post(
    "/artifacts/{artifact_id}/promote",
    summary="Promote a project deployment into the collection version",
    description=(
        "Reads the latest deployment hash for the given source project and promotes "
        "it into the artifact's collection version record.  In enterprise edition a "
        "PromotionRequest is created instead of updating the collection directly."
    ),
    responses={
        200: {"description": "Promotion completed (or promotion request created)"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Artifact or source deployment not found",
        },
        409: {"description": "Hash conflict — collection was updated concurrently"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def promote_artifact(
    artifact_id: str,
    request: PromoteArtifactRequestDTO,
    token: TokenDep,
    db_session: DbSessionDep,
    settings: SettingsDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
):
    """Promote a project's latest deployment hash to the collection version.

    Args:
        artifact_id: Artifact identifier in type:name format.
        request: Promote request body (source_project_id, optional hash guard).
        token: Authentication token.
        db_session: Database session.
        settings: API settings for edition routing.
        auth_context: Authenticated user context with write scope.

    Returns:
        PromoteArtifactResponseDTO on success.
        JSONResponse with ConflictDTO and HTTP 409 on hash mismatch.

    Raises:
        HTTPException: 404 when artifact or source deployment is missing.
        HTTPException: 500 on unexpected errors.
    """
    from fastapi.responses import JSONResponse
    from sqlalchemy import select as sa_select

    from skillmeat.cache.models import (
        ArtifactCollectionVersion,
        ProjectVersionDeployment,
    )
    from skillmeat.core.version_service import VersionService
    from skillmeat.observability.tracing import Span

    span = Span("promote.executed")
    span.set_attribute("artifact_id", artifact_id)
    span.set_attribute("source_project_id", request.source_project_id)
    span.set_attribute("edition", settings.edition)

    try:
        # ------------------------------------------------------------------
        # Step 1: Load ArtifactCollectionVersion for conflict check
        # ------------------------------------------------------------------
        acv_row = (
            db_session.execute(
                sa_select(ArtifactCollectionVersion).where(
                    ArtifactCollectionVersion.artifact_id == artifact_id
                )
            )
            .scalars()
            .first()
        )

        # ------------------------------------------------------------------
        # Step 2: Optimistic concurrency conflict check
        # ------------------------------------------------------------------
        if (
            request.expected_collection_hash is not None
            and acv_row is not None
            and acv_row.current_hash != request.expected_collection_hash
        ):
            span.set_attribute("conflict", True)
            span.end(status="conflict")
            conflict = ConflictDTO(
                artifact_id=artifact_id,
                expected_hash=request.expected_collection_hash,
                actual_hash=acv_row.current_hash,
            )
            return JSONResponse(
                status_code=status.HTTP_409_CONFLICT,
                content=conflict.model_dump(),
            )

        # ------------------------------------------------------------------
        # Step 3: Load latest deployment for source_project_id
        # ------------------------------------------------------------------
        from sqlalchemy import func

        latest_sub = (
            sa_select(func.max(ProjectVersionDeployment.deployed_at).label("max_at"))
            .where(
                ProjectVersionDeployment.artifact_id == artifact_id,
                ProjectVersionDeployment.project_id == request.source_project_id,
            )
            .scalar_subquery()
        )
        pvd_row = (
            db_session.execute(
                sa_select(ProjectVersionDeployment).where(
                    ProjectVersionDeployment.artifact_id == artifact_id,
                    ProjectVersionDeployment.project_id == request.source_project_id,
                    ProjectVersionDeployment.deployed_at == latest_sub,
                )
            )
            .scalars()
            .first()
        )

        if pvd_row is None:
            span.end(status="not_found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    f"No deployment found for artifact '{artifact_id}' "
                    f"in project '{request.source_project_id}'."
                ),
            )

        source_content_hash = pvd_row.content_hash

        # ------------------------------------------------------------------
        # Step 4: Enterprise routing — create PromotionRequest, skip writes
        # ------------------------------------------------------------------
        if settings.edition == "enterprise":
            import uuid as _uuid

            from skillmeat.core.enterprise_version_scope import (
                EnterpriseVersionScopeService,
            )

            ent_svc = EnterpriseVersionScopeService(db_session)
            tenant_id = _uuid.UUID(str(auth_context.tenant_id))
            user_id = _uuid.UUID(str(auth_context.user_id))
            promo_req = ent_svc.create_promotion_request_for_artifact(
                artifact_id=artifact_id,
                tenant_id=tenant_id,
                requesting_user_id=user_id,
                content_hash=source_content_hash,
                message=request.message,
            )
            db_session.commit()
            span.set_attribute("promotion_request_id", str(promo_req.get("id", "")))
            span.end(status="success")
            return PromoteArtifactResponseDTO(
                artifact_id=artifact_id,
                new_collection_hash=None,
                promotion_request_id=str(promo_req.get("id", "")),
                was_no_op=False,
            )

        # ------------------------------------------------------------------
        # Step 5: Local edition — write new ArtifactVersion + update ACV
        # ------------------------------------------------------------------
        # No-op guard: if the collection already points at this hash, skip.
        if acv_row is not None and acv_row.current_hash == source_content_hash:
            span.end(status="no_op")
            return PromoteArtifactResponseDTO(
                artifact_id=artifact_id,
                new_collection_hash=source_content_hash,
                promotion_request_id=None,
                was_no_op=True,
            )

        version_svc = VersionService(db_session)
        version_svc.record_mutation(
            artifact_id=artifact_id,
            change_origin="push",
            content_hash=source_content_hash,
            project_id=request.source_project_id,
            message=request.message,
            version_label=request.version_label,
        )
        db_session.commit()

        span.end(status="success")
        logger.info(
            "promote_artifact: artifact_id=%r promoted from project=%r hash=%s",
            artifact_id,
            request.source_project_id,
            source_content_hash[:8],
        )

        return PromoteArtifactResponseDTO(
            artifact_id=artifact_id,
            new_collection_hash=source_content_hash,
            promotion_request_id=None,
            was_no_op=False,
        )

    except HTTPException:
        span.end(status="error")
        raise
    except Exception as e:
        span.end(status="error")
        logger.error(
            "promote_artifact failed for artifact_id=%r: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to promote artifact: {str(e)}",
        )


@router.post(
    "/artifacts/{artifact_id}/sync-all",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Trigger async sync of all outdated project deployments",
    description=(
        "Queues an asynchronous sync of every non-pinned, outdated project "
        "deployment for the artifact. Returns a job_id immediately for polling status. "
        "The actual sync runs in the background and may take several seconds. "
        "Use GET /sync-jobs/{job_id} to poll for completion."
    ),
    responses={
        202: {"description": "Sync job queued successfully; poll job_id for status"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Artifact topology not found",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def sync_all_deployments(
    artifact_id: str,
    token: TokenDep,
    db_session: DbSessionDep,
    settings: SettingsDep,
    background_tasks: BackgroundTasks,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
):
    """Trigger async sync of all outdated, non-pinned project deployments for *artifact_id*.

    Args:
        artifact_id: Artifact identifier in type:name format.
        token: Authentication token.
        db_session: Database session.
        settings: API settings for edition routing.
        background_tasks: FastAPI background tasks for async execution.
        auth_context: Authenticated user context with write scope.

    Returns:
        :class:`~skillmeat.api.schemas.vcs_v2.SyncJobTriggerResponse` with
        ``job_id`` for polling status.

    Raises:
        HTTPException: 404 when no topology exists for the artifact.
        HTTPException: 500 on unexpected errors.
    """
    from skillmeat.api.schemas.vcs_v2 import SyncJobTriggerResponse
    from skillmeat.api.services.sync_job_manager import get_sync_job_manager
    from skillmeat.core.version_topology_service import VersionTopologyService
    from skillmeat.observability.tracing import Span

    span = Span("sync_all.trigger")
    span.set_attribute("artifact_id", artifact_id)
    span.set_attribute("edition", settings.edition)

    try:
        # Quick validation - verify topology exists before creating job
        topo_svc = VersionTopologyService(db_session, edition=settings.edition)
        topology = await topo_svc.get_topology(artifact_id, auth_context)

        if topology is None:
            span.end(status="not_found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No version topology found for artifact '{artifact_id}'.",
            )

        # Create job and schedule background execution
        job_manager = get_sync_job_manager()
        job = job_manager.create_job(artifact_id)

        # Schedule the actual sync work in background
        background_tasks.add_task(
            _execute_sync_job, job.job_id, artifact_id, settings.edition, auth_context
        )

        span.set_attribute("job_id", job.job_id)
        span.end(status="success")

        logger.info(f"Queued sync job {job.job_id} for artifact {artifact_id}")

        return SyncJobTriggerResponse(
            job_id=job.job_id,
            status="pending",
            artifact_id=artifact_id,
            created_at=job.created_at,
        )

    except HTTPException:
        span.end(status="error")
        raise
    except Exception as e:
        span.end(status="error")
        logger.error(
            "sync_all_deployments trigger failed for artifact_id=%r: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to queue sync job: {str(e)}",
        )


async def _execute_sync_job(
    job_id: str, artifact_id: str, edition: str, auth_context: AuthContext
) -> None:
    """Background task to execute the actual sync work.

    This function runs the sync operation that was previously in sync_all_deployments.
    Updates job status throughout the process.
    """
    from skillmeat.api.services.sync_job_manager import get_sync_job_manager
    from skillmeat.api.schemas.vcs_v2 import SyncAllResponseDTO
    from skillmeat.core.version_service import VersionService
    from skillmeat.core.version_topology_service import VersionTopologyService
    from skillmeat.observability.tracing import Span
    from skillmeat.cache.models import get_session

    job_manager = get_sync_job_manager()

    # Mark job as started
    job_manager.start_job(job_id)

    span = Span("sync_all.background_execution")
    span.set_attribute("artifact_id", artifact_id)
    span.set_attribute("job_id", job_id)
    span.set_attribute("edition", edition)

    db_session = None
    try:
        # Create a new database session for background processing
        db_session = get_session()

        # ------------------------------------------------------------------
        # Step 1: Get topology so we know which deployments are outdated
        # ------------------------------------------------------------------
        topo_svc = VersionTopologyService(db_session, edition=edition)
        topology = await topo_svc.get_topology(artifact_id, auth_context)

        if topology is None:
            error_msg = f"No version topology found for artifact '{artifact_id}'"
            job_manager.fail_job(job_id, error_msg)
            span.end(status="not_found")
            return

        collection_version = topology.collection_version
        version_svc = VersionService(db_session)

        synced_count = 0
        skipped_count = 0
        errors: list = []

        # ------------------------------------------------------------------
        # Step 2: Iterate deployments — sync outdated non-pinned ones
        # ------------------------------------------------------------------
        for deployment in topology.deployments:
            staleness = topo_svc.compute_outdated_status(deployment, collection_version)

            if deployment.pinned or staleness != "outdated":
                skipped_count += 1
                continue

            # Determine the target content hash from the collection version.
            target_hash = (
                collection_version.current_hash if collection_version else None
            )
            if target_hash is None:
                skipped_count += 1
                continue

            # ------------------------------------------------------------------
            # Step 3: Record sync mutation — catch per-project failures
            # ------------------------------------------------------------------
            try:
                version_svc.record_mutation(
                    artifact_id=artifact_id,
                    change_origin="sync",
                    content_hash=target_hash,
                    project_id=deployment.project_id,
                )
                db_session.commit()
                synced_count += 1
            except Exception as proj_exc:
                db_session.rollback()
                err_msg = f"project_id={deployment.project_id!r}: {proj_exc}"
                logger.warning(
                    "_execute_sync_job: failed for artifact_id=%r job_id=%r %s",
                    artifact_id,
                    job_id,
                    err_msg,
                    exc_info=True,
                )
                errors.append(err_msg)

        span.set_attribute("synced_count", synced_count)
        span.set_attribute("skipped_count", skipped_count)
        span.set_attribute("failed_count", len(errors))
        span.end(status="success")

        logger.info(
            "_execute_sync_job: artifact_id=%r job_id=%r synced=%d skipped=%d failed=%d",
            artifact_id,
            job_id,
            synced_count,
            skipped_count,
            len(errors),
        )

        # Complete job with results
        result = SyncAllResponseDTO(
            synced_count=synced_count,
            skipped_count=skipped_count,
            errors=errors,
        )
        job_manager.complete_job(job_id, result)

    except Exception as e:
        span.end(status="error")
        error_msg = f"Sync execution failed: {str(e)}"
        logger.error(
            "_execute_sync_job failed for artifact_id=%r job_id=%r: %s",
            artifact_id,
            job_id,
            e,
            exc_info=True,
        )
        job_manager.fail_job(job_id, error_msg)

    finally:
        if db_session:
            db_session.close()


@router.get(
    "/sync-jobs/{job_id}",
    summary="Get sync job status and results",
    description=(
        "Retrieve the status and results of an async sync-all job. "
        "Use this endpoint to poll for completion after triggering a sync "
        "with POST /artifacts/{artifact_id}/sync-all."
    ),
    responses={
        200: {"description": "Job status and results (if completed)"},
        404: {"model": ErrorResponse, "description": "Job not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_sync_job_status(
    job_id: str,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:read"])),
):
    """Get status and results for a sync job.

    Args:
        job_id: Job identifier returned by sync-all trigger
        auth_context: Authenticated user context with read scope

    Returns:
        :class:`~skillmeat.api.schemas.vcs_v2.SyncJobStatusResponse` with
        job status and results if completed.

    Raises:
        HTTPException: 404 when job_id is not found.
        HTTPException: 500 on unexpected errors.
    """
    from skillmeat.api.schemas.vcs_v2 import SyncJobStatusResponse
    from skillmeat.api.services.sync_job_manager import get_sync_job_manager

    try:
        job_manager = get_sync_job_manager()
        job = job_manager.get_job(job_id)

        if job is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Sync job '{job_id}' not found",
            )

        return SyncJobStatusResponse(
            job_id=job.job_id,
            status=job.status,
            artifact_id=job.artifact_id,
            created_at=job.created_at,
            started_at=job.started_at,
            completed_at=job.completed_at,
            result=job.result,
            error_message=job.error_message,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "get_sync_job_status failed for job_id=%r: %s",
            job_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get job status: {str(e)}",
        )


# ====================
# Version-Centric Deployment View Endpoints
# ====================


@router.get(
    "/artifacts/{artifact_id}/topology-by-version",
    summary="Get version-grouped deployment topology for an artifact",
    description=(
        "Returns all project deployments for the artifact grouped by content hash. "
        "Each group includes ArtifactVersion metadata (semver_tag, change_origin, "
        "created_at) and flags whether the hash matches the current collection version."
    ),
    responses={
        200: {"description": "Version-grouped topology returned"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_topology_by_version(
    artifact_id: str,
    token: TokenDep,
    db_session: DbSessionDep,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    _: None = Depends(require_local_edition),
    auth_context: AuthContext = Depends(get_auth_context),
):
    """Return deployment topology grouped by content hash for *artifact_id*.

    In enterprise edition, when ``auth_context.tenant_id`` is present, each
    ``VersionGroup`` is enriched with ``owner_scopes`` — the set of owner
    scope records (user, team, or enterprise) whose ``head_hash`` matches
    that group's content hash.  Non-enterprise requests always receive an
    empty ``owner_scopes`` list.

    Args:
        artifact_id: Artifact identifier in type:name format.
        token: Authentication token.
        db_session: Database session.
        settings: API settings (used to detect enterprise edition).
        auth_context: Authenticated user context.

    Returns:
        :class:`~skillmeat.api.schemas.version.VersionGroupedTopology` with
        all deployments grouped by content hash, enriched with ArtifactVersion
        metadata, an ``is_current`` flag, and (enterprise only) ``owner_scopes``.

    Raises:
        HTTPException: 404 when the artifact does not exist in the DB cache.
        HTTPException: 500 on unexpected errors.
    """
    import uuid as _uuid

    from skillmeat.cache.models import (
        Artifact,
        ArtifactCollectionVersion,
        ArtifactVersion,
        Project,
        ProjectVersionDeployment,
    )
    from skillmeat.cache.repositories import ProjectVersionDeploymentRepository

    try:
        # Verify the artifact exists.
        artifact_row = (
            db_session.query(Artifact).filter(Artifact.id == artifact_id).first()
        )
        if artifact_row is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found.",
            )

        # Retrieve the current collection hash for is_current flag.
        collection_version_row = (
            db_session.query(ArtifactCollectionVersion)
            .filter(ArtifactCollectionVersion.artifact_id == artifact_id)
            .first()
        )
        current_hash: Optional[str] = (
            collection_version_row.current_hash if collection_version_row else None
        )

        # Build a map of project_id → project_path for deployment enrichment.
        project_rows = db_session.query(Project).all()
        project_path_map: dict[str, str] = {p.id: p.path for p in project_rows}

        # Group all deployment records by content hash via the repository.
        pvd_repo = ProjectVersionDeploymentRepository()
        grouped = pvd_repo.group_deployments_by_hash(artifact_id)

        # Build a lookup of content_hash → ArtifactVersion for metadata.
        all_hashes = [h for h, _ in grouped]
        av_rows = (
            (
                db_session.query(ArtifactVersion)
                .filter(
                    ArtifactVersion.artifact_id == artifact_id,
                    ArtifactVersion.content_hash.in_(all_hashes),
                )
                .all()
            )
            if all_hashes
            else []
        )
        av_map: dict[str, ArtifactVersion] = {av.content_hash: av for av in av_rows}

        # ------------------------------------------------------------------
        # Enterprise: build a per-hash map of owner scopes (no N+1 — one
        # query per hash via get_scopes_by_hash; hashes are typically O(10)).
        # ------------------------------------------------------------------
        ent_tenant_id: Optional[_uuid.UUID] = None
        ent_artifact_uuid: Optional[_uuid.UUID] = None
        scope_repo = None

        _raw_tenant = getattr(auth_context, "tenant_id", None)
        if settings.edition == "enterprise" and _raw_tenant is not None:
            try:
                from skillmeat.cache.enterprise_repositories import (
                    EnterpriseArtifactVersionScopeRepository,
                )

                ent_tenant_id = _uuid.UUID(str(_raw_tenant))

                # Resolve type:name → enterprise artifact UUID via the
                # centralized helper (non-fatal — degrade gracefully on failure).
                _resolved_uuid_str = await resolve_enterprise_artifact_id(
                    artifact_id, settings, artifact_repo
                )
                ent_artifact_uuid = _uuid.UUID(_resolved_uuid_str)
                scope_repo = EnterpriseArtifactVersionScopeRepository(db_session)
            except HTTPException:
                # resolve_enterprise_artifact_id raises 404 — treat as non-fatal
                # so topology can still be returned without owner_scopes.
                logger.warning(
                    "enterprise scope resolution failed for artifact=%r: artifact not found",
                    artifact_id,
                )
            except Exception as _ent_err:
                logger.warning(
                    "enterprise scope resolution failed for artifact=%r: %s",
                    artifact_id,
                    _ent_err,
                )
                # Non-fatal — degrade gracefully to empty owner_scopes

        # Build hash → owner_scopes lookup (single query per hash).
        scope_map: dict[str, list[OwnerScope]] = {}
        if (
            scope_repo is not None
            and ent_artifact_uuid is not None
            and ent_tenant_id is not None
        ):
            for content_hash, _ in grouped:
                raw_scopes = scope_repo.get_scopes_by_hash(
                    artifact_id=ent_artifact_uuid,
                    tenant_id=ent_tenant_id,
                    content_hash=content_hash,
                )
                scope_map[content_hash] = [
                    OwnerScope(
                        owner_type=s["owner_type"],
                        owner_id=s["owner_id"],
                        head_hash=s["head_hash"],
                        is_diverged=s["is_diverged"],
                        promotion_state=s["promotion_state"],
                    )
                    for s in raw_scopes
                ]

        version_groups: list[VersionGroup] = []
        for content_hash, deployments in grouped:
            av = av_map.get(content_hash)

            # Build per-deployment rows with project path and status.
            group_deployments: list[VersionGroupDeployment] = []
            for dep in deployments:
                dep_status = (
                    "current" if dep.content_hash == current_hash else "outdated"
                )
                group_deployments.append(
                    VersionGroupDeployment(
                        project_id=dep.project_id,
                        project_path=project_path_map.get(dep.project_id, ""),
                        deployed_at=dep.deployed_at,
                        pinned=dep.pinned,
                        status=dep_status,
                    )
                )

            version_groups.append(
                VersionGroup(
                    content_hash=content_hash,
                    semver_tag=av.version_label if av else None,
                    created_at=(av.created_at if av else deployments[0].deployed_at),
                    change_origin=av.change_origin if av else None,
                    deployment_count=len(deployments),
                    is_current=(content_hash == current_hash),
                    deployments=group_deployments,
                    owner_scopes=scope_map.get(content_hash, []),
                )
            )

        return VersionGroupedTopology(
            artifact_id=artifact_id,
            collection_version=current_hash,
            versions=version_groups,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "get_topology_by_version failed for artifact_id=%r: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve version topology: {str(e)}",
        )


@router.post(
    "/artifacts/{artifact_id}/batch-sync",
    summary="Batch-sync all deployments on source_hash to target_hash",
    description=(
        "Finds all non-pinned project deployments of *artifact_id* that currently "
        "have *source_hash* and records a sync mutation to *target_hash* for each. "
        "Already-synced deployments (target_hash already present) are counted as "
        "synced (idempotent).  Returns per-project error details on partial failure."
    ),
    responses={
        200: {"description": "Batch sync completed; counts reflect synced/failed"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        422: {
            "model": ErrorResponse,
            "description": "Unknown source_hash or target_hash for this artifact",
        },
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def batch_sync_deployments(
    artifact_id: str,
    request: BatchSyncRequest,
    token: TokenDep,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
):
    """Sync all deployments on *source_hash* to *target_hash* for *artifact_id*.

    Args:
        artifact_id: Artifact identifier in type:name format.
        request: Batch sync request with source_hash and target_hash.
        token: Authentication token.
        db_session: Database session.
        auth_context: Authenticated user context with write scope.

    Returns:
        :class:`~skillmeat.api.schemas.version.BatchSyncResponse` with
        ``synced``, ``failed``, and per-project ``errors``.

    Raises:
        HTTPException: 422 when source_hash or target_hash is unknown for
            this artifact.
        HTTPException: 500 on unexpected errors.
    """
    from skillmeat.cache.models import (
        Artifact,
        ArtifactVersion,
        ProjectVersionDeployment,
    )
    from skillmeat.core.version_service import VersionService

    try:
        # Verify the artifact exists.
        artifact_row = (
            db_session.query(Artifact).filter(Artifact.id == artifact_id).first()
        )
        if artifact_row is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found.",
            )

        # Validate that both hashes are known for this artifact.
        known_hashes = {
            row.content_hash
            for row in db_session.query(ArtifactVersion.content_hash)
            .filter(ArtifactVersion.artifact_id == artifact_id)
            .all()
        }
        # Also include hashes that appear only in deployments (no ArtifactVersion row yet).
        known_hashes |= {
            row.content_hash
            for row in db_session.query(ProjectVersionDeployment.content_hash)
            .filter(ProjectVersionDeployment.artifact_id == artifact_id)
            .all()
        }

        if request.source_hash not in known_hashes:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Unknown source_hash '{request.source_hash[:16]}...' for artifact '{artifact_id}'.",
            )
        if request.target_hash not in known_hashes:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Unknown target_hash '{request.target_hash[:16]}...' for artifact '{artifact_id}'.",
            )

        # Find all deployments with source_hash.
        matching_deployments = (
            db_session.query(ProjectVersionDeployment)
            .filter(
                ProjectVersionDeployment.artifact_id == artifact_id,
                ProjectVersionDeployment.content_hash == request.source_hash,
            )
            .all()
        )

        version_svc = VersionService(db_session)
        synced = 0
        failed = 0
        errors: list[BatchSyncError] = []

        # Deduplicate by project_id — take most recent deployment per project.
        seen_projects: set[str] = set()
        for deployment in sorted(
            matching_deployments,
            key=lambda d: d.deployed_at,
            reverse=True,
        ):
            if deployment.project_id in seen_projects:
                continue
            seen_projects.add(deployment.project_id)

            # Skip pinned deployments — they are locked against auto-updates.
            if deployment.pinned:
                continue

            # Idempotency: if this project already has target_hash, count as synced.
            already_synced = (
                db_session.query(ProjectVersionDeployment)
                .filter(
                    ProjectVersionDeployment.artifact_id == artifact_id,
                    ProjectVersionDeployment.project_id == deployment.project_id,
                    ProjectVersionDeployment.content_hash == request.target_hash,
                )
                .first()
            )
            if already_synced is not None:
                synced += 1
                continue

            try:
                version_svc.record_mutation(
                    artifact_id=artifact_id,
                    change_origin="sync",
                    content_hash=request.target_hash,
                    project_id=deployment.project_id,
                )
                db_session.commit()
                synced += 1
            except Exception as proj_exc:
                db_session.rollback()
                err_msg = str(proj_exc)
                logger.warning(
                    "batch_sync_deployments: failed for artifact_id=%r project_id=%r: %s",
                    artifact_id,
                    deployment.project_id,
                    err_msg,
                    exc_info=True,
                )
                errors.append(
                    BatchSyncError(project_id=deployment.project_id, error=err_msg)
                )
                failed += 1

        logger.info(
            "batch_sync_deployments: artifact_id=%r source=%s target=%s synced=%d failed=%d",
            artifact_id,
            request.source_hash[:8],
            request.target_hash[:8],
            synced,
            failed,
        )

        return BatchSyncResponse(synced=synced, failed=failed, errors=errors)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "batch_sync_deployments failed for artifact_id=%r: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to batch sync deployments: {str(e)}",
        )


# ====================
# Patch Version Endpoint (DVCS-5b)
# ====================

_SEMVER_PATTERN = None  # lazy-loaded


def _get_semver_pattern():
    """Return compiled SemVer pattern (lazy init).

    Returns:
        Compiled regex pattern for SemVer v-prefixed tags.
    """
    global _SEMVER_PATTERN
    if _SEMVER_PATTERN is None:
        import re

        _SEMVER_PATTERN = re.compile(
            r"^v(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
            r"(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)"
            r"(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?"
            r"(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$"
        )
    return _SEMVER_PATTERN


@router.post(
    "/artifacts/{artifact_id}/versions/patch",
    response_model=PatchVersionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a patched version",
    description=(
        "Create a new ArtifactVersion with change_origin='patch' derived from a specific "
        "source version.  The new version stores the supplied content and records the source "
        "version's content_hash as its parent_hash."
    ),
    responses={
        201: {"description": "Patched version created successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Artifact or source version not found",
        },
        422: {"model": ErrorResponse, "description": "Invalid SemVer tag format"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def create_patch_version(
    artifact_id: str,
    request: PatchVersionRequest,
    db_session: DbSessionDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> PatchVersionResponse:
    """Create a patched version for a specific artifact.

    Validates that the source version exists and belongs to the artifact, then
    creates a new ``ArtifactVersion`` row with ``change_origin='patch'``.

    Args:
        artifact_id: Artifact identifier in type:name format.
        request: Patch request with source version ID, content, and optional metadata.
        db_session: Database session for ORM access.
        token: Authentication token.
        auth_context: Resolved authentication context.

    Returns:
        PatchVersionResponse with details of the newly created version.

    Raises:
        HTTPException: 404 if source version not found, 422 if invalid SemVer tag.
    """
    import hashlib
    import uuid as _uuid

    from skillmeat.cache.models import ArtifactVersion

    logger.info(
        "create_patch_version: artifact_id=%r source_version_id=%r semver_tag=%r",
        artifact_id,
        request.source_version_id,
        request.semver_tag,
    )

    try:
        # Validate semver_tag format when provided.
        if request.semver_tag is not None:
            if not _get_semver_pattern().match(request.semver_tag):
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=(
                        f"Invalid SemVer tag '{request.semver_tag}'. "
                        "Must match the pattern vMAJOR.MINOR.PATCH (e.g. v1.2.3)."
                    ),
                )

        # Validate source version exists and belongs to this artifact.
        source_version = (
            db_session.query(ArtifactVersion)
            .filter(
                ArtifactVersion.id == request.source_version_id,
                ArtifactVersion.artifact_id == artifact_id,
            )
            .first()
        )
        if source_version is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    f"Source version '{request.source_version_id}' not found "
                    f"for artifact '{artifact_id}'"
                ),
            )

        # Compute content hash from the supplied content.
        content_hash = hashlib.sha256(request.content.encode("utf-8")).hexdigest()

        # Check for an existing version with this (artifact_id, content_hash) pair
        # to avoid duplicate inserts — idempotent if caller retries with same content.
        existing_version = (
            db_session.query(ArtifactVersion)
            .filter(
                ArtifactVersion.artifact_id == artifact_id,
                ArtifactVersion.content_hash == content_hash,
            )
            .first()
        )

        if existing_version is not None:
            # Return the existing version as-is — patch is idempotent for identical content.
            logger.info(
                "create_patch_version: version with hash %s already exists for artifact %r — "
                "returning existing row (id=%r)",
                content_hash[:8],
                artifact_id,
                existing_version.id,
            )
            return PatchVersionResponse(
                id=existing_version.id,
                artifact_id=existing_version.artifact_id,
                content_hash=existing_version.content_hash,
                parent_hash=existing_version.parent_hash,
                change_origin=existing_version.change_origin,
                semver_tag=existing_version.version_label,
                message=existing_version.message,
                created_at=existing_version.created_at,
            )

        # Create the new patched ArtifactVersion.
        now_dt = __import__("datetime").datetime.utcnow()
        new_version = ArtifactVersion(
            id=_uuid.uuid4().hex,
            artifact_id=artifact_id,
            content_hash=content_hash,
            parent_hash=source_version.content_hash,
            change_origin="patch",
            content_payload=request.content,
            version_label=request.semver_tag,
            message=request.message,
        )
        db_session.add(new_version)
        db_session.commit()
        db_session.refresh(new_version)

        logger.info(
            "create_patch_version: created version id=%r artifact=%r hash=%s",
            new_version.id,
            artifact_id,
            content_hash[:8],
        )

        return PatchVersionResponse(
            id=new_version.id,
            artifact_id=new_version.artifact_id,
            content_hash=new_version.content_hash,
            parent_hash=new_version.parent_hash,
            change_origin=new_version.change_origin,
            semver_tag=new_version.version_label,
            message=new_version.message,
            created_at=new_version.created_at,
        )

    except HTTPException:
        raise
    except Exception as e:
        db_session.rollback()
        logger.error(
            "create_patch_version failed for artifact_id=%r: %s",
            artifact_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create patch version: {str(e)}",
        )
