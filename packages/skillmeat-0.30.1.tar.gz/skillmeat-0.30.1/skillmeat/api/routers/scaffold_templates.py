"""Scaffold Templates API router.

Provides REST endpoints for managing Backstage scaffold template configuration
associated with SkillMeat bundles.  Each scaffold template is a 1-to-1 mapping
from a ``BundleEntity`` to a Backstage Software Template (YAML) configuration.

API Endpoints:
    POST   /scaffold-templates          - Idempotent create (200 existing, 201 new)
    GET    /scaffold-templates          - Paginated list with optional enabled_only filter
    GET    /scaffold-templates/{id}     - Single template by UUID
    PUT    /scaffold-templates/{id}     - Update scaffold configuration fields
    DELETE /scaffold-templates/{id}     - Disable scaffold on linked Bundle (204)
    POST   /scaffold-templates/{id}/enable  - Enable scaffold template
    POST   /scaffold-templates/{id}/disable - Disable scaffold template
    GET    /scaffold-templates/{bundle_id}/preview - Preview generated YAML
"""

from __future__ import annotations

import logging
from typing import Annotated, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status

from skillmeat.api.dependencies import (
    DbSessionDep,
    get_auth_context,
    get_scaffold_template_service,
    require_auth,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.scaffold_templates import (
    ScaffoldTemplateCreate,
    ScaffoldTemplateListResponse,
    ScaffoldTemplateResponse,
    ScaffoldTemplateUpdate,
    TemplatePreviewResponse,
)
from skillmeat.core.services.scaffold_template_service import ScaffoldTemplateService
from skillmeat.core.services.template_generator import TemplateGenerationError

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/scaffold-templates",
    tags=["scaffold-templates"],
)

# ---------------------------------------------------------------------------
# Edition-aware service dependency alias
# ---------------------------------------------------------------------------

#: Injected ``ScaffoldTemplateService`` backed by local SQLite or enterprise
#: PostgreSQL depending on ``settings.edition``.  Wired via
#: ``get_scaffold_template_service`` in ``dependencies.py``.
ScaffoldTemplateSvcDep = Annotated[
    ScaffoldTemplateService, Depends(get_scaffold_template_service)
]

# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "",
    response_model=ScaffoldTemplateResponse,
    summary="Create scaffold template (idempotent)",
    description=(
        "Create a new scaffold template for a bundle.  If a template already "
        "exists for the given ``bundle_id`` the existing record is returned "
        "with HTTP 200 instead of 201."
    ),
    responses={
        200: {"description": "Template already exists — existing record returned"},
        201: {"description": "Template created"},
        422: {"description": "Validation error"},
        500: {"description": "Internal server error"},
    },
)
async def create_scaffold_template(
    request: ScaffoldTemplateCreate,
    session: DbSessionDep,
    response: Response,
    svc: ScaffoldTemplateSvcDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> ScaffoldTemplateResponse:
    """Create a scaffold template for a bundle, idempotently.

    When a template for ``bundle_id`` already exists the existing record is
    returned with HTTP 200.  A new template returns HTTP 201.

    Args:
        request: Validated creation payload.
        session: Database session (injected).
        response: FastAPI response object used to override the status code.
        svc: Edition-aware scaffold template service (injected).

    Returns:
        :class:`ScaffoldTemplateResponse` for the created or pre-existing template.

    Raises:
        HTTPException: 500 on unexpected database errors.
    """
    try:
        # Check for pre-existence to decide the status code before delegating.
        existing = svc.repository.get_by_bundle_id(session, request.bundle_id)
        result = svc.create(session, bundle_id=request.bundle_id, data=request)

        if existing is not None:
            # Idempotent hit — return 200.
            response.status_code = status.HTTP_200_OK
        else:
            response.status_code = status.HTTP_201_CREATED

        logger.info(
            "create_scaffold_template bundle_id=%s existing=%s",
            request.bundle_id,
            existing is not None,
        )
        return result

    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to create scaffold template: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create scaffold template: {exc}",
        )


@router.get(
    "",
    response_model=ScaffoldTemplateListResponse,
    summary="List scaffold templates",
    description="Return a paginated list of scaffold templates, optionally filtered to enabled ones.",
    responses={
        200: {"description": "Paginated template list"},
        500: {"description": "Internal server error"},
    },
)
async def list_scaffold_templates(
    session: DbSessionDep,
    svc: ScaffoldTemplateSvcDep,
    enabled_only: Optional[bool] = Query(
        False,
        description="When true, only enabled templates are returned.",
    ),
    page: int = Query(1, ge=1, description="1-based page number."),
    page_size: int = Query(50, ge=1, le=100, description="Items per page."),
    auth_context: AuthContext = Depends(get_auth_context),
) -> ScaffoldTemplateListResponse:
    """List scaffold templates with optional enabled-only filtering and pagination.

    Args:
        session: Database session (injected).
        svc: Edition-aware scaffold template service (injected).
        enabled_only: When ``True``, only enabled templates are included.
        page: 1-based page number.
        page_size: Items per page (1–100).

    Returns:
        :class:`ScaffoldTemplateListResponse` with paginated items and totals.

    Raises:
        HTTPException: 500 on unexpected database errors.
    """
    try:
        all_items = svc.list(session, enabled_only=bool(enabled_only))
        total = len(all_items)
        offset = (page - 1) * page_size
        page_items = all_items[offset : offset + page_size]

        return ScaffoldTemplateListResponse(
            items=page_items,
            total=total,
            page=page,
            page_size=page_size,
        )

    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to list scaffold templates: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list scaffold templates: {exc}",
        )


@router.get(
    "/{id}",
    response_model=ScaffoldTemplateResponse,
    summary="Get scaffold template by ID",
    description="Retrieve a single scaffold template by its UUID.",
    responses={
        200: {"description": "Template found"},
        404: {"description": "Template not found"},
        500: {"description": "Internal server error"},
    },
)
async def get_scaffold_template(
    id: str,
    session: DbSessionDep,
    svc: ScaffoldTemplateSvcDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> ScaffoldTemplateResponse:
    """Retrieve a scaffold template by primary key.

    Args:
        id: UUID hex primary key of the scaffold template.
        session: Database session (injected).
        svc: Edition-aware scaffold template service (injected).

    Returns:
        :class:`ScaffoldTemplateResponse` with ``template_stale`` populated.

    Raises:
        HTTPException: 404 if the template does not exist, 500 on database errors.
    """
    try:
        return svc.get(session, id=id)

    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scaffold template '{id}' not found",
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to get scaffold template id=%s: %s", id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get scaffold template: {exc}",
        )


@router.put(
    "/{id}",
    response_model=ScaffoldTemplateResponse,
    summary="Update scaffold template configuration",
    description=(
        "Partially update a scaffold template's configuration fields.  "
        "Only provided fields are modified; omitted fields retain their "
        "current values.  The linked bundle name is not modifiable here."
    ),
    responses={
        200: {"description": "Template updated"},
        404: {"description": "Template not found"},
        422: {"description": "Validation error"},
        500: {"description": "Internal server error"},
    },
)
async def update_scaffold_template(
    id: str,
    request: ScaffoldTemplateUpdate,
    session: DbSessionDep,
    svc: ScaffoldTemplateSvcDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> ScaffoldTemplateResponse:
    """Update scaffold configuration fields (PATCH semantics via PUT).

    Only fields explicitly set in the request body are written.  The
    ``bundle_id`` and Bundle metadata are not modifiable through this endpoint.

    Args:
        id: UUID hex primary key of the scaffold template to update.
        request: Partial update payload.
        session: Database session (injected).
        svc: Edition-aware scaffold template service (injected).

    Returns:
        Updated :class:`ScaffoldTemplateResponse`.

    Raises:
        HTTPException: 404 if not found, 500 on database errors.
    """
    try:
        return svc.update(session, id=id, data=request)

    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scaffold template '{id}' not found",
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to update scaffold template id=%s: %s", id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update scaffold template: {exc}",
        )


@router.delete(
    "/{id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Disable scaffold template",
    description=(
        "Sets ``scaffold_enabled=false`` on the linked Bundle, effectively "
        "disabling the scaffold template without removing it from the database.  "
        "Returns 204 No Content on success."
    ),
    responses={
        204: {"description": "Scaffold disabled on linked bundle"},
        404: {"description": "Template not found"},
        500: {"description": "Internal server error"},
    },
)
async def delete_scaffold_template(
    id: str,
    session: DbSessionDep,
    svc: ScaffoldTemplateSvcDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> None:
    """Disable the scaffold template associated with the given ID.

    This is a soft-delete: the template record is retained but
    ``enabled`` is set to ``False``, which prevents the template from
    appearing in Backstage catalog sync and generation pipelines.

    Args:
        id: UUID hex primary key of the scaffold template.
        session: Database session (injected).
        svc: Edition-aware scaffold template service (injected).

    Raises:
        HTTPException: 404 if the template does not exist, 500 on errors.
    """
    try:
        svc.disable(session, id=id)
        logger.info("Disabled scaffold template id=%s via DELETE", id)

    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scaffold template '{id}' not found",
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to disable scaffold template id=%s: %s", id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to disable scaffold template: {exc}",
        )


@router.post(
    "/{id}/enable",
    response_model=ScaffoldTemplateResponse,
    summary="Enable scaffold template",
    description="Enable a scaffold template so it participates in Backstage catalog sync.",
    responses={
        200: {"description": "Template enabled"},
        404: {"description": "Template not found"},
        500: {"description": "Internal server error"},
    },
)
async def enable_scaffold_template(
    id: str,
    session: DbSessionDep,
    svc: ScaffoldTemplateSvcDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> ScaffoldTemplateResponse:
    """Enable a scaffold template by primary key.

    Args:
        id: UUID hex primary key of the scaffold template.
        session: Database session (injected).
        svc: Edition-aware scaffold template service (injected).

    Returns:
        Updated :class:`ScaffoldTemplateResponse` with ``enabled=True``.

    Raises:
        HTTPException: 404 if not found, 500 on database errors.
    """
    try:
        result = svc.enable(session, id=id)
        logger.info("Enabled scaffold template id=%s", id)
        return result

    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scaffold template '{id}' not found",
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to enable scaffold template id=%s: %s", id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to enable scaffold template: {exc}",
        )


@router.post(
    "/{id}/disable",
    response_model=ScaffoldTemplateResponse,
    summary="Disable scaffold template",
    description="Disable a scaffold template without deleting it from the database.",
    responses={
        200: {"description": "Template disabled"},
        404: {"description": "Template not found"},
        500: {"description": "Internal server error"},
    },
)
async def disable_scaffold_template(
    id: str,
    session: DbSessionDep,
    svc: ScaffoldTemplateSvcDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> ScaffoldTemplateResponse:
    """Disable a scaffold template by primary key.

    Disabled templates are retained in the database but excluded from
    Backstage catalog sync and generation pipelines.

    Args:
        id: UUID hex primary key of the scaffold template.
        session: Database session (injected).
        svc: Edition-aware scaffold template service (injected).

    Returns:
        Updated :class:`ScaffoldTemplateResponse` with ``enabled=False``.

    Raises:
        HTTPException: 404 if not found, 500 on database errors.
    """
    try:
        result = svc.disable(session, id=id)
        logger.info("Disabled scaffold template id=%s", id)
        return result

    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scaffold template '{id}' not found",
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to disable scaffold template id=%s: %s", id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to disable scaffold template: {exc}",
        )


@router.get(
    "/{bundle_id}/preview",
    response_model=TemplatePreviewResponse,
    summary="Preview generated scaffold YAML",
    description=(
        "Render the Backstage Software Template YAML for a scaffold template "
        "without persisting the result.  Returns 422 when the linked bundle "
        "lacks sufficient metadata to generate a valid template."
    ),
    responses={
        200: {"description": "Preview generated"},
        404: {"description": "Scaffold template not found for id or bundle_id"},
        422: {"description": "Bundle has insufficient metadata for YAML generation"},
        500: {"description": "Internal server error"},
    },
)
async def preview_scaffold_template(
    bundle_id: str,
    session: DbSessionDep,
    svc: ScaffoldTemplateSvcDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> TemplatePreviewResponse:
    """Preview the Backstage YAML that would be generated for a scaffold template.

    Accepts either the template's own ``id`` (primary lookup, used by the
    frontend) or the associated ``bundle_id`` (fallback for backwards
    compatibility).  Renders the YAML using :class:`TemplateGenerator` without
    modifying any database state.

    Args:
        bundle_id: Template ID **or** bundle entity ID to preview.  The
            endpoint tries a direct template-ID lookup first; if that misses it
            falls back to a bundle-ID lookup so existing callers continue to
            work.
        session: Database session (injected).
        svc: Edition-aware scaffold template service (injected).

    Returns:
        :class:`TemplatePreviewResponse` with the rendered YAML and provenance.

    Raises:
        HTTPException: 404 if no template exists for the given id,
            422 when the bundle has insufficient metadata, 500 on other errors.
    """
    try:
        # Try to find by template ID first (primary lookup, used by frontend).
        orm_template = svc.repository.get(session, bundle_id)

        # Fallback: try bundle_id lookup for backwards compatibility.
        if orm_template is None:
            orm_template = svc.repository.get_by_bundle_id(session, bundle_id)

        if orm_template is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No scaffold template found for id='{bundle_id}'",
            )

        return svc.preview(session, id=str(orm_template.id))

    except HTTPException:
        raise
    except TemplateGenerationError as exc:
        logger.warning("Template generation failed for id=%s: %s", bundle_id, exc)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Bundle has insufficient metadata for YAML generation: {exc}",
        )
    except ValueError as exc:
        # Raised by service when template or bundle is missing.
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        )
    except Exception as exc:
        logger.exception(
            "Failed to preview scaffold template for id=%s: %s", bundle_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to preview scaffold template: {exc}",
        )
