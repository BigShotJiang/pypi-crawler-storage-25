"""Enterprise tier-diff endpoint.

Exposes ``GET /enterprise/artifacts/{artifact_id}/tier-diff`` for comparing
an artifact's synchronisation state across enterprise ownership tiers
(enterprise, team, developer).

The endpoint delegates to
:meth:`~skillmeat.core.services.enterprise_context_sync.EnterpriseContextSyncService.get_tier_diff_for_artifact`
after applying two layers of gating:

Feature flag gate (BE-2.3) — router-level dependency
-----------------------------------------------------
Applied via ``dependencies=[Depends(_check_feature_flags)]`` on the
``APIRouter`` so it fires before any endpoint handler is entered.

1. ``settings.edition != "enterprise"`` → HTTP 501.  The tier hierarchy only
   exists in the enterprise edition; local deployments have no owner_type rows.
2. ``settings.enterprise_sync_enabled is False`` → HTTP 501.  The enterprise
   sync subsystem may be administratively disabled even in enterprise edition.

RBAC enforcement (BE-2.2)
--------------------------
Scope-specific access rules applied after the feature gate:

+---------------------------+----------------------------------------------+
| scope                     | required access                              |
+===========================+==============================================+
| enterprise-vs-team        | system_admin                                 |
+---------------------------+----------------------------------------------+
| team-vs-developer         | own developer scope → any authenticated user |
|                           | another user's scope → team_admin or         |
|                           |   system_admin                               |
+---------------------------+----------------------------------------------+
| enterprise-vs-developer   | system_admin                                 |
+---------------------------+----------------------------------------------+

OpenTelemetry
-------------
When OpenTelemetry is installed a best-effort span ``enterprise.tier_diff.get``
is emitted with attributes ``tier_pair``, ``owner_type``, ``artifact_id``,
and ``user_id``.  OTel failures never propagate to the caller.

Routes
------
GET /enterprise/artifacts/{artifact_id}/tier-diff
    Return a partial tier-diff summary for the requested artifact and scope.
"""

from __future__ import annotations

import logging
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ContextSyncServiceDep,
    EnterpriseContextDep,
    SettingsDep,
    require_auth,
)
from skillmeat.api.schemas.auth import AuthContext, Role
from skillmeat.api.schemas.enterprise_tier_diff import TierDiffResponse

# ---------------------------------------------------------------------------
# Optional OpenTelemetry import — silently skipped when not installed.
# ---------------------------------------------------------------------------

try:
    from opentelemetry import trace as _otel_trace

    _tracer = _otel_trace.get_tracer(__name__)
    _OTEL_AVAILABLE = True
except ImportError:  # pragma: no cover — OTel is optional
    _OTEL_AVAILABLE = False
    _tracer = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Valid scope values
# ---------------------------------------------------------------------------

_VALID_SCOPES = frozenset(
    {
        "enterprise-vs-team",
        "team-vs-developer",
        "enterprise-vs-developer",
    }
)

# ---------------------------------------------------------------------------
# Feature flag gate (BE-2.3)
# ---------------------------------------------------------------------------


def _check_feature_flags(settings: SettingsDep) -> None:
    """Raise HTTP 501 when the endpoint is unavailable in the current edition/config.

    Two independent checks are applied:

    1. ``edition != "enterprise"`` — the tier-diff endpoint has no meaning in
       local edition because there is no tier hierarchy.
    2. ``enterprise_sync_enabled is False`` — the enterprise sync subsystem
       may be administratively disabled even in enterprise edition.

    Both failures surface as HTTP 501 (Not Implemented) rather than 403 so
    that clients can distinguish "you lack permission" from "this feature is
    not active in this deployment".

    Args:
        settings: Current application settings.

    Raises:
        HTTPException 501: When edition is not enterprise, or when
            ``enterprise_sync_enabled`` is disabled.
    """
    if settings.edition != "enterprise":
        logger.debug(
            "tier-diff: edition=%s is not enterprise — returning 501",
            settings.edition,
        )
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Tier comparison is only available in the enterprise edition. "
                "Current edition: %s." % settings.edition
            ),
        )

    if not settings.enterprise_sync_enabled:
        logger.debug("tier-diff: enterprise_sync_enabled=False — returning 501")
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Enterprise sync is not enabled in this deployment. "
                "Set SKILLMEAT_ENTERPRISE_SYNC_ENABLED=true to activate "
                "tier comparison endpoints."
            ),
        )


# ---------------------------------------------------------------------------
# RBAC enforcement (BE-2.2)
# ---------------------------------------------------------------------------


def check_tier_diff_rbac(
    scope: str,
    developer_id: Optional[UUID],
    auth_context: AuthContext,
) -> None:
    """Enforce role-based access for tier-diff requests.

    Access rules by scope:

    +---------------------------+----------------------------------------------+
    | scope                     | required access                              |
    +===========================+==============================================+
    | enterprise-vs-team        | system_admin                                 |
    +---------------------------+----------------------------------------------+
    | team-vs-developer         | own developer scope → any authenticated user |
    |                           | another user's scope → team_admin or         |
    |                           |   system_admin                               |
    +---------------------------+----------------------------------------------+
    | enterprise-vs-developer   | system_admin                                 |
    +---------------------------+----------------------------------------------+

    Args:
        scope: One of the valid tier-diff scope strings.
        developer_id: When provided, the UUID of the developer being compared.
            When ``None`` the requesting user's own scope is implied.
        auth_context: Authenticated request context from ``require_auth``.

    Raises:
        HTTPException 403: When the requesting user lacks sufficient privilege
            for the requested scope/developer_id combination.
    """
    is_system_admin = auth_context.is_admin()
    is_team_admin = auth_context.has_role(Role.team_admin)

    # enterprise-vs-team: system_admin only — team admins do not have
    # cross-team enterprise visibility.
    if scope == "enterprise-vs-team":
        if not is_system_admin:
            logger.warning(
                "tier-diff RBAC denied: user=%s scope=%s — requires system_admin",
                auth_context.user_id,
                scope,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="The 'enterprise-vs-team' scope requires system_admin role.",
            )
        return

    # enterprise-vs-developer: system_admin only — widest blast radius.
    if scope == "enterprise-vs-developer":
        if not is_system_admin:
            logger.warning(
                "tier-diff RBAC denied: user=%s scope=%s — requires system_admin",
                auth_context.user_id,
                scope,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="The 'enterprise-vs-developer' scope requires system_admin role.",
            )
        return

    # team-vs-developer: own scope is always permitted; another user's scope
    # requires team_admin (for their team) or system_admin.
    if scope == "team-vs-developer":
        accessing_own_scope = (
            developer_id is None or developer_id == auth_context.user_id
        )
        if accessing_own_scope:
            return

        if not (is_system_admin or is_team_admin):
            logger.warning(
                "tier-diff RBAC denied: user=%s scope=%s developer_id=%s "
                "— requires team_admin or system_admin",
                auth_context.user_id,
                scope,
                developer_id,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    "Accessing another developer's scope in 'team-vs-developer' "
                    "requires team_admin or system_admin role."
                ),
            )


# ---------------------------------------------------------------------------
# OTel helper (best-effort; isolated so the handler stays readable)
# ---------------------------------------------------------------------------

# Left-hand owner_type derived from scope — used as an OTel attribute.
_SCOPE_TO_OWNER_TYPE: dict[str, str] = {
    "enterprise-vs-team": "enterprise",
    "team-vs-developer": "team",
    "enterprise-vs-developer": "enterprise",
}


def _emit_otel_span(
    artifact_id: str,
    scope: str,
    auth_context: AuthContext,
) -> None:
    """Emit a best-effort OpenTelemetry span for the tier-diff request.

    Span name: ``enterprise.tier_diff.get``

    Attributes:
        tier_pair   — scope value
        owner_type  — left-hand owner type derived from scope
        artifact_id — artifact identifier
        user_id     — requesting user UUID as string

    Args:
        artifact_id: Artifact identifier.
        scope: Tier comparison scope string.
        auth_context: Authenticated request context.
    """
    if not _OTEL_AVAILABLE or _tracer is None:
        return

    try:
        with _tracer.start_as_current_span("enterprise.tier_diff.get") as span:
            span.set_attribute("tier_pair", scope)
            span.set_attribute("owner_type", _SCOPE_TO_OWNER_TYPE.get(scope, "unknown"))
            span.set_attribute("artifact_id", artifact_id)
            span.set_attribute("user_id", str(auth_context.user_id))
    except Exception:  # pragma: no cover — OTel failures are always swallowed
        logger.debug("OTel span emission failed for tier-diff", exc_info=True)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(
    prefix="/enterprise",
    tags=["Enterprise Tier Diff"],
    dependencies=[Depends(_check_feature_flags)],
)

# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.get(
    "/artifacts/{artifact_id}/tier-diff",
    summary="Get enterprise tier-diff for an artifact",
    description=(
        "Compare an artifact's synchronisation state between two enterprise "
        "ownership tiers.  The ``scope`` parameter selects the tier pair:\n\n"
        "- ``enterprise-vs-team`` — enterprise root vs. a specific team\n"
        "- ``team-vs-developer`` — a team snapshot vs. a developer's copy\n"
        "- ``enterprise-vs-developer`` — enterprise root vs. a developer's copy\n\n"
        "When CAS (Content-Addressed Storage) blob content is available for "
        "both tiers, the response includes file-level unified diffs "
        "(``partial_result=false``).  Otherwise only hash-level status "
        "information is returned (``partial_result=true``)."
    ),
    response_model=TierDiffResponse,
    responses={
        200: {"description": "Tier-diff summary for the requested artifact and scope."},
        400: {
            "description": (
                "Invalid ``scope`` value.  Must be one of: "
                "``enterprise-vs-team``, ``team-vs-developer``, "
                "``enterprise-vs-developer``."
            )
        },
        403: {
            "description": (
                "Insufficient role for the requested scope or developer_id. "
                "See RBAC rules in module docstring."
            )
        },
        404: {
            "description": "Artifact or scope pair not found for the current tenant."
        },
        501: {
            "description": (
                "Enterprise sync feature is not enabled, or deployment is not "
                "in enterprise edition."
            )
        },
    },
)
def get_artifact_tier_diff(
    artifact_id: str,
    sync_service: ContextSyncServiceDep,
    ctx: EnterpriseContextDep,
    scope: str = Query(
        ...,
        description=(
            "Tier comparison scope.  One of: ``enterprise-vs-team``, "
            "``team-vs-developer``, ``enterprise-vs-developer``."
        ),
        examples=["enterprise-vs-team"],
    ),
    team_id: Optional[UUID] = Query(
        default=None,
        description=(
            "UUID of the team to use as the team-tier owner.  Required when "
            "``scope`` references a team side (``enterprise-vs-team`` or "
            "``team-vs-developer``)."
        ),
    ),
    developer_id: Optional[UUID] = Query(
        default=None,
        description=(
            "UUID of the developer/user to use as the developer-tier owner.  "
            "Required when ``scope`` references a developer side "
            "(``team-vs-developer`` or ``enterprise-vs-developer``)."
        ),
    ),
    auth_context: AuthContext = Depends(require_auth()),
) -> TierDiffResponse:
    """Return a tier-level diff summary for a single artifact.

    The function applies two layers of gating before delegating to the
    service layer:

    1. Feature flag gate (BE-2.3) — rejects non-enterprise editions and
       deployments where ``enterprise_sync_enabled`` is false.
    2. RBAC enforcement (BE-2.2) — scope-specific role checks.

    Parameters
    ----------
    artifact_id:
        Artifact identifier in ``type:name`` format (e.g. ``skill:pdf-reader``)
        or UUID string.
    sync_service:
        :class:`~skillmeat.core.interfaces.context_sync.IContextSyncService`
        injected per-request.
    scope:
        Tier comparison scope string (see description above).
    team_id:
        Optional UUID for the team-tier owner.
    developer_id:
        Optional UUID for the developer-tier owner.
    auth_context:
        Resolved auth context providing ``user_id``, ``tenant_id``, and role
        information for RBAC enforcement.

    Returns
    -------
    TierDiffResponse
        Tier-diff response.  ``partial_result=False`` when CAS blob content
        is available; ``partial_result=True`` otherwise.

    Raises
    ------
    HTTPException(400)
        If *scope* is not one of the recognised values.
    HTTPException(403)
        If the requesting user lacks sufficient role for the requested
        scope/developer_id combination.
    HTTPException(404)
        If the artifact or requested scope pair does not exist for the
        current tenant.
    HTTPException(501)
        If the deployment is not enterprise edition or ``enterprise_sync_enabled``
        is false.
    """
    # ------------------------------------------------------------------
    # 1. RBAC enforcement (BE-2.2) — feature gate fires via router
    #    dependency before any endpoint logic is reached.
    # ------------------------------------------------------------------
    check_tier_diff_rbac(
        scope=scope,
        developer_id=developer_id,
        auth_context=auth_context,
    )

    # ------------------------------------------------------------------
    # 3. OTel span (best-effort)
    # ------------------------------------------------------------------
    _emit_otel_span(
        artifact_id=artifact_id,
        scope=scope,
        auth_context=auth_context,
    )

    # Resolve tenant_id from enterprise context (safe fallback to DEFAULT_TENANT_ID).
    tenant_id: str = str(ctx.tenant_id)

    # Resolve optional UUIDs to plain strings for the service layer.
    team_id_str: Optional[str] = str(team_id) if team_id is not None else None
    developer_id_str: Optional[str] = (
        str(developer_id) if developer_id is not None else None
    )

    logger.info(
        "tier-diff request: artifact_id=%r scope=%r tenant_id=%r team_id=%r developer_id=%r",
        artifact_id,
        scope,
        tenant_id,
        team_id_str,
        developer_id_str,
    )

    try:
        result = sync_service.get_tier_diff_for_artifact(
            artifact_id=artifact_id,
            scope=scope,
            tenant_id=tenant_id,
            team_id=team_id_str,
            developer_id=developer_id_str,
        )
    except ValueError as exc:
        logger.info(
            "tier-diff: invalid scope %r for artifact %r — %s",
            scope,
            artifact_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Invalid scope {scope!r}.  Must be one of: "
                + ", ".join(sorted(_VALID_SCOPES))
                + f".  Detail: {exc}"
            ),
        ) from exc
    except LookupError as exc:
        logger.info(
            "tier-diff: not found — artifact=%r scope=%r: %s",
            artifact_id,
            scope,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc)
            or f"Artifact '{artifact_id}' not found for scope '{scope}'",
        ) from exc
    except Exception as exc:
        logger.exception(
            "tier-diff: unexpected error for artifact=%r scope=%r",
            artifact_id,
            scope,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while computing tier diff.",
        ) from exc

    return result
