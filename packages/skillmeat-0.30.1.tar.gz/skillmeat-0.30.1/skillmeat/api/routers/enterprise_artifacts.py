"""Enterprise Artifacts CRUD router.

Provides CRUD endpoints for enterprise-scoped artifacts under the
``/enterprise/artifacts`` prefix.  Write operations are gated by the
``require_enterprise_admin()`` dependency; read operations use
``OwnershipContextDep`` to enforce visibility-aware filtering.

Routes
------
POST   /enterprise/artifacts                      Create an enterprise artifact
GET    /enterprise/artifacts                      List enterprise artifacts (paginated)
GET    /enterprise/artifacts/{artifact_id}        Get single enterprise artifact
PATCH  /enterprise/artifacts/{artifact_id}        Update enterprise artifact
DELETE /enterprise/artifacts/{artifact_id}        Delete enterprise artifact (soft)
"""

from __future__ import annotations

import logging
import uuid
from typing import Annotated, List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from skillmeat.api.dependencies import (
    DbSessionDep,
    EnterpriseAdminDep,
    EnterpriseContextDep,
    OwnershipContextDep,
    get_auth_context,
)
from skillmeat.api.schemas.artifacts import ArtifactUpstreamInfo
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.cache.enterprise_repositories import (
    EnterpriseArtifactRepository,
    TenantIsolationError,
)
from skillmeat.core.interfaces.dtos import ArtifactDTO
from skillmeat.core.sync_tasks import cascade_enterprise_rollout

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(
    prefix="/enterprise/artifacts",
    tags=["Enterprise Artifacts"],
)

# ---------------------------------------------------------------------------
# Dependency: per-request EnterpriseArtifactRepository
# ---------------------------------------------------------------------------


def _get_artifact_repo(session: DbSessionDep) -> EnterpriseArtifactRepository:
    """Build an ``EnterpriseArtifactRepository`` for the current request.

    Tenant isolation is controlled via ``TenantContext`` (a ContextVar in
    ``skillmeat.cache.enterprise_repositories``).  When ``TenantContext`` is
    not set the repository falls back to ``DEFAULT_TENANT_ID`` automatically.

    Parameters
    ----------
    session:
        Per-request SQLAlchemy session injected by ``DbSessionDep``.

    Returns
    -------
    EnterpriseArtifactRepository
        Repository instance ready for use within the current request.
    """
    return EnterpriseArtifactRepository(session)


EnterpriseArtifactRepoDep = Annotated[
    EnterpriseArtifactRepository, Depends(_get_artifact_repo)
]

# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class EnterpriseArtifactCreateRequest(BaseModel):
    """Request body for creating an enterprise artifact.

    Attributes
    ----------
    name:
        Human-readable artifact name (e.g. ``"canvas-design"``).
    artifact_type:
        One of the recognised type values (e.g. ``"skill"``, ``"command"``).
    source:
        Optional upstream GitHub URL or identifier.
    content:
        Optional initial Markdown content.  When provided, a version row at
        ``v1.0.0`` is created alongside the artifact.
    metadata:
        Arbitrary key-value pairs stored in ``custom_fields``.
    tags:
        Tag strings to associate with the artifact.
    """

    name: str = Field(
        description="Human-readable artifact name", min_length=1, max_length=255
    )
    artifact_type: str = Field(
        description="Artifact type (e.g. skill, command, agent, composite)",
        examples=["skill", "command", "agent"],
    )
    source: Optional[str] = Field(
        default=None,
        description="Upstream source URL or identifier, if available",
    )
    content: Optional[str] = Field(
        default=None,
        description="Optional initial Markdown content; creates a v1.0.0 version when provided",
    )
    metadata: Optional[dict] = Field(
        default=None,
        description="Arbitrary key-value metadata stored in custom_fields",
    )
    tags: Optional[List[str]] = Field(
        default=None,
        description="Tag strings to associate with the artifact",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "name": "canvas-design",
                "artifact_type": "skill",
                "source": "anthropics/skills/canvas-design",
                "tags": ["design", "canvas"],
                "metadata": {"version": "1.0.0"},
            }
        }
    }


class EnterpriseArtifactUpdateRequest(BaseModel):
    """Request body for updating an enterprise artifact.

    All fields are optional; only provided fields are updated.

    Attributes
    ----------
    name:
        New artifact name.  ``None`` leaves the existing name unchanged.
    content:
        New Markdown content.  A new version row is created only when the
        content hash differs from the most recent stored version.
    metadata:
        Replacement ``custom_fields`` dict.  ``None`` leaves it unchanged.
    tags:
        Replacement tag list.  ``None`` leaves the existing tags unchanged.
    """

    name: Optional[str] = Field(
        default=None,
        description="New artifact name; omit to leave unchanged",
        min_length=1,
        max_length=255,
    )
    content: Optional[str] = Field(
        default=None,
        description="New Markdown content; a new version is created when the hash differs",
    )
    metadata: Optional[dict] = Field(
        default=None,
        description="Replacement custom_fields dict; omit to leave unchanged",
    )
    tags: Optional[List[str]] = Field(
        default=None,
        description="Replacement tag list; omit to leave unchanged",
    )


class EnterpriseArtifactResponse(BaseModel):
    """Response schema for a single enterprise artifact.

    Attributes
    ----------
    id:
        UUID primary key of the artifact.
    tenant_id:
        UUID of the owning tenant.
    name:
        Human-readable artifact name.
    artifact_type:
        Artifact type string.
    source_url:
        Upstream source URL, or ``None`` when not tracked.
    tags:
        List of associated tag strings.
    metadata:
        Arbitrary key-value metadata (``custom_fields``).
    is_active:
        ``True`` for live artifacts; ``False`` for soft-deleted.
    owner_type:
        Always ``"enterprise"`` for artifacts created via this router.
    created_at:
        ISO-8601 creation timestamp.
    updated_at:
        ISO-8601 last-modification timestamp.
    owner_team:
        Team identifier that owns this artifact in the enterprise hierarchy.
        ``None`` when team ownership is not assigned.
    propagation_scope:
        Controls how far the artifact propagates (e.g. ``"global"``,
        ``"team"``, ``"user"``).  ``None`` when not configured.
    override_count:
        Number of downstream instances where users have overridden the
        enterprise default.  ``None`` when governance tracking is disabled.
    compliance_status:
        Compliance gate result for this artifact (e.g. ``"compliant"``,
        ``"non_compliant"``, ``"pending"``).  ``None`` when compliance
        evaluation has not run.
    """

    id: str = Field(description="UUID identifying the enterprise artifact")
    tenant_id: str = Field(description="UUID of the owning tenant")
    name: str = Field(description="Human-readable artifact name")
    artifact_type: str = Field(description="Artifact type")
    source_url: Optional[str] = Field(default=None, description="Upstream source URL")
    tags: List[str] = Field(default_factory=list, description="Associated tags")
    metadata: dict = Field(
        default_factory=dict, description="Custom key-value metadata"
    )
    is_active: bool = Field(description="False when the artifact is soft-deleted")
    owner_type: str = Field(
        default="enterprise", description="Always 'enterprise' for this router"
    )
    upstream: Optional[ArtifactUpstreamInfo] = Field(
        default=None,
        description=(
            "Upstream tracking information.  Populated when source_url points "
            "to a GitHub-backed origin so the frontend's hasValidUpstreamSource() "
            "check can enable diff queries."
        ),
    )
    created_at: Optional[str] = Field(
        default=None, description="ISO-8601 creation timestamp"
    )
    updated_at: Optional[str] = Field(
        default=None, description="ISO-8601 last-modified timestamp"
    )
    owner_team: Optional[str] = Field(
        default=None,
        description=(
            "Team identifier that owns this artifact in the enterprise hierarchy; "
            "None when team ownership is not assigned"
        ),
    )
    propagation_scope: Optional[str] = Field(
        default=None,
        description=(
            "Controls propagation reach (e.g. 'global', 'team', 'user'); "
            "None when not configured"
        ),
        examples=["global", "team", "user"],
    )
    override_count: Optional[int] = Field(
        default=None,
        description=(
            "Number of downstream instances where users have overridden the "
            "enterprise default; None when governance tracking is disabled"
        ),
        ge=0,
    )
    compliance_status: Optional[str] = Field(
        default=None,
        description=(
            "Compliance gate result (e.g. 'compliant', 'non_compliant', 'pending'); "
            "None when compliance evaluation has not run"
        ),
        examples=["compliant", "non_compliant", "pending"],
    )

    model_config = {"from_attributes": True}


class EnterpriseArtifactListResponse(BaseModel):
    """Paginated list response for enterprise artifacts.

    Attributes
    ----------
    items:
        Page of artifact objects.
    total:
        Total number of artifacts for the tenant (across all pages).
    limit:
        Maximum items per page (as requested).
    offset:
        Items skipped before this page (as requested).
    """

    items: List[EnterpriseArtifactResponse] = Field(description="Page of artifacts")
    total: int = Field(description="Total artifact count for the tenant")
    limit: int = Field(description="Maximum items per page")
    offset: int = Field(description="Number of items skipped")


class GlobalDeployRequest(BaseModel):
    """Request body for the global deploy endpoint.

    Attributes
    ----------
    enforce_override:
        When ``True`` (default) a forced rollout is executed — the artifact
        is pushed to all downstream team and user collections without a merge
        prompt.  When ``False`` a notification is dispatched to downstream
        owners instead of silently overwriting their copy.
    """

    enforce_override: bool = Field(
        default=True,
        description=(
            "If True, force-push artifact to all downstream collections. "
            "If False, notify downstream owners instead of overwriting."
        ),
    )


class GlobalDeployAcceptedResponse(BaseModel):
    """Response body for an accepted global deploy request.

    Attributes
    ----------
    task_id:
        Opaque identifier that can be used to poll cascade status.
    artifact_id:
        The artifact being deployed.
    status:
        Always ``"accepted"`` — the task has been enqueued.
    enforce_override:
        The effective value of the ``enforce_override`` flag for this rollout.
    message:
        Human-readable description of what will happen.
    """

    task_id: str = Field(description="Unique identifier for the enqueued cascade task")
    artifact_id: str = Field(
        description="UUID of the enterprise artifact being deployed"
    )
    status: str = Field(
        default="accepted", description="Always 'accepted' for 202 responses"
    )
    enforce_override: bool = Field(description="Whether forced rollout is active")
    message: str = Field(description="Human-readable status message")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _artifact_to_response(artifact: ArtifactDTO) -> EnterpriseArtifactResponse:
    """Convert an :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO` returned
    by :class:`EnterpriseArtifactRepository` to the response schema.

    All ORM divergences (DIV-5 UUID normalisation, DIV-6 source_url→source,
    DIV-7 custom_fields→metadata) are already resolved by
    ``EnterpriseArtifactRepository._artifact_to_dto()``.  Direct field access is
    therefore safe.

    Parameters
    ----------
    artifact:
        An :class:`~skillmeat.core.interfaces.dtos.ArtifactDTO` produced by the
        enterprise repository layer.

    Returns
    -------
    EnterpriseArtifactResponse
        Serialisable response object.
    """
    # Build upstream info when source_url points to a GitHub-backed origin.
    # EnterpriseArtifactRepository stores the GitHub origin URL in source_url
    # (mapped to ArtifactDTO.source via DIV-6).  The frontend's
    # hasValidUpstreamSource() requires upstream.enabled === true for diff
    # queries to be enabled.
    source_url = artifact.source or ""
    _has_github_upstream = bool(source_url) and (
        source_url.startswith("github:") or "/" in source_url
    )
    upstream_info: Optional[ArtifactUpstreamInfo] = None
    if _has_github_upstream:
        upstream_info = ArtifactUpstreamInfo(
            tracking_enabled=True,
            current_sha=None,
            upstream_sha=None,
            update_available=False,
            has_local_modifications=False,
            drift_status="none",
        )

    return EnterpriseArtifactResponse(
        # DIV-5: enterprise UUID is normalised to hex string in ArtifactDTO.uuid.
        # ArtifactDTO.id holds the "type:name" composite key — use uuid for the
        # enterprise UUID primary key expected by this response schema.
        id=artifact.uuid or artifact.id,
        # tenant_id is stripped by the enterprise repository (DIV-8); default to "".
        tenant_id="",
        name=artifact.name,
        artifact_type=artifact.artifact_type,
        # DIV-6: enterprise source_url is normalised to ArtifactDTO.source.
        source_url=artifact.source,
        tags=list(artifact.tags),
        # DIV-7: enterprise custom_fields are normalised to ArtifactDTO.metadata.
        metadata=dict(artifact.metadata),
        # is_active is an enterprise ORM field not carried by ArtifactDTO; all
        # artifacts returned by the repository are active (soft-deleted rows are
        # excluded by default).
        is_active=True,
        owner_type="enterprise",
        upstream=upstream_info,
        created_at=artifact.created_at,
        updated_at=artifact.updated_at,
        # Governance fields: not yet stored in the DB model; return None until
        # the enterprise governance schema is extended to carry these columns.
        owner_team=None,
        propagation_scope=None,
        override_count=None,
        compliance_status=None,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "",
    summary="Create enterprise artifact",
    description=(
        "Create a new enterprise-scoped artifact.  ``owner_type`` is set to "
        '``"enterprise"`` automatically.  Requires the ``system_admin`` role.'
    ),
    response_model=EnterpriseArtifactResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        201: {"description": "Artifact created successfully."},
        401: {"description": "Authentication required."},
        403: {"description": "system_admin role required."},
        422: {"description": "Validation error in request body."},
    },
)
def create_enterprise_artifact(
    request: EnterpriseArtifactCreateRequest,
    repo: EnterpriseArtifactRepoDep,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
) -> EnterpriseArtifactResponse:
    """Create a new enterprise artifact.

    Parameters
    ----------
    request:
        Artifact creation payload.
    repo:
        ``EnterpriseArtifactRepository`` injected per request.
    auth:
        Authenticated admin context (injected by ``require_enterprise_admin()``).

    Returns
    -------
    EnterpriseArtifactResponse
        The newly created artifact.

    Raises
    ------
    HTTPException(403)
        When the authenticated user does not hold the ``system_admin`` role.
    HTTPException(422)
        When the request body fails Pydantic validation.
    HTTPException(500)
        When an unexpected error occurs during creation.
    """
    try:
        artifact = repo.create(
            name=request.name,
            artifact_type=request.artifact_type,
            source=request.source,
            content=request.content,
            metadata=request.metadata,
            tags=request.tags,
            auth_context=auth,
        )
    except Exception as exc:
        logger.exception(
            "Failed to create enterprise artifact name=%r type=%r: %s",
            request.name,
            request.artifact_type,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create enterprise artifact.",
        ) from exc

    return _artifact_to_response(artifact)


@router.get(
    "",
    summary="List enterprise artifacts",
    description=(
        "Return a paginated list of enterprise artifacts visible to the "
        "authenticated user.  Supports filtering by ``artifact_type`` and "
        "substring search on ``name``."
    ),
    response_model=EnterpriseArtifactListResponse,
    responses={
        200: {"description": "Paginated list of enterprise artifacts."},
        401: {"description": "Authentication required."},
    },
)
def list_enterprise_artifacts(
    repo: EnterpriseArtifactRepoDep,
    ownership: OwnershipContextDep,
    ctx: EnterpriseContextDep,
    auth_context: AuthContext = Depends(get_auth_context),
    limit: int = Query(
        default=50, ge=1, le=100, description="Maximum number of results"
    ),
    offset: int = Query(default=0, ge=0, description="Number of results to skip"),
    artifact_type: Optional[str] = Query(
        default=None,
        description="Filter by artifact type (e.g. skill, command, agent)",
    ),
    name_contains: Optional[str] = Query(
        default=None,
        description="Case-insensitive substring filter on artifact name",
    ),
) -> EnterpriseArtifactListResponse:
    """List enterprise artifacts with pagination and optional filters.

    Parameters
    ----------
    repo:
        ``EnterpriseArtifactRepository`` injected per request.
    ownership:
        Resolved ownership context providing enterprise scope filter.
    auth_context:
        Authentication context for visibility-aware filtering.
    limit:
        Maximum number of results to return (1–100).
    offset:
        Number of results to skip before this page.
    artifact_type:
        Optional type filter.
    name_contains:
        Optional case-insensitive name substring filter.

    Returns
    -------
    EnterpriseArtifactListResponse
        Paginated results with total count.
    """
    filters: dict[str, str] = {}
    if artifact_type is not None:
        filters["artifact_type"] = artifact_type
    if name_contains is not None:
        filters["name_contains"] = name_contains
    artifacts = repo.list(
        filters=filters or None,
        offset=offset,
        limit=limit,
        auth_context=auth_context,
    )
    total = repo.count(filters=filters or None, auth_context=auth_context)
    return EnterpriseArtifactListResponse(
        items=[_artifact_to_response(a) for a in artifacts],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/{artifact_id}",
    summary="Get enterprise artifact",
    description=(
        "Fetch a single enterprise artifact by UUID.  Returns 404 when the "
        "artifact is not found, not enterprise-owned, or not visible to the "
        "authenticated user."
    ),
    response_model=EnterpriseArtifactResponse,
    responses={
        200: {"description": "Enterprise artifact details."},
        401: {"description": "Authentication required."},
        404: {"description": "Artifact not found or not enterprise-owned."},
        422: {"description": "Invalid artifact_id format (not a valid UUID)."},
    },
)
def get_enterprise_artifact(
    artifact_id: str,
    repo: EnterpriseArtifactRepoDep,
    ctx: EnterpriseContextDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> EnterpriseArtifactResponse:
    """Fetch a single enterprise artifact by UUID.

    Parameters
    ----------
    artifact_id:
        UUID string of the artifact to retrieve.
    repo:
        ``EnterpriseArtifactRepository`` injected per request.
    auth_context:
        Authentication context for visibility-aware lookup.

    Returns
    -------
    EnterpriseArtifactResponse
        The requested artifact.

    Raises
    ------
    HTTPException(404)
        When the artifact does not exist, belongs to a different tenant, or
        is not visible to the authenticated user.
    HTTPException(422)
        When *artifact_id* is not a valid UUID string.
    """
    try:
        artifact = repo.get_by_uuid(artifact_id, auth_context=auth_context)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid artifact_id: {exc}",
        ) from exc
    except Exception as exc:
        logger.exception(
            "Unexpected error fetching enterprise artifact %r: %s", artifact_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve enterprise artifact.",
        ) from exc

    if artifact is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Enterprise artifact not found: {artifact_id!r}",
        )

    return _artifact_to_response(artifact)


@router.patch(
    "/{artifact_id}",
    summary="Update enterprise artifact",
    description=(
        "Update mutable fields on an enterprise artifact.  Only provided "
        "fields are modified.  Requires the ``system_admin`` role."
    ),
    response_model=EnterpriseArtifactResponse,
    responses={
        200: {"description": "Artifact updated successfully."},
        401: {"description": "Authentication required."},
        403: {
            "description": "system_admin role required or artifact not owned by user."
        },
        404: {"description": "Artifact not found."},
        422: {"description": "Invalid artifact_id or request body."},
    },
)
def update_enterprise_artifact(
    artifact_id: str,
    request: EnterpriseArtifactUpdateRequest,
    repo: EnterpriseArtifactRepoDep,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
) -> EnterpriseArtifactResponse:
    """Update an enterprise artifact's mutable fields.

    Parameters
    ----------
    artifact_id:
        UUID string of the artifact to update.
    request:
        Fields to update; omitted fields are left unchanged.
    repo:
        ``EnterpriseArtifactRepository`` injected per request.
    auth:
        Authenticated admin context (injected by ``require_enterprise_admin()``).

    Returns
    -------
    EnterpriseArtifactResponse
        The updated artifact.

    Raises
    ------
    HTTPException(404)
        When the artifact does not exist in the current tenant.
    HTTPException(403)
        When the authenticated user does not own the artifact.
    HTTPException(422)
        When *artifact_id* is not a valid UUID string.
    HTTPException(500)
        When an unexpected error occurs during update.
    """
    try:
        parsed_id = uuid.UUID(artifact_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid artifact_id: {exc}",
        ) from exc

    try:
        artifact = repo.update(
            artifact_id=parsed_id,
            name=request.name,
            content=request.content,
            metadata=request.metadata,
            tags=request.tags,
            auth_context=auth,
        )
    except TenantIsolationError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: artifact belongs to a different tenant.",
        ) from exc
    except ValueError as exc:
        error_msg = str(exc)
        if "not found" in error_msg.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Enterprise artifact not found: {artifact_id!r}",
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        logger.exception(
            "Unexpected error updating enterprise artifact %r: %s", artifact_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update enterprise artifact.",
        ) from exc

    return _artifact_to_response(artifact)


@router.delete(
    "/{artifact_id}",
    summary="Delete enterprise artifact",
    description=(
        "Soft-delete an enterprise artifact.  The row is retained for audit "
        "purposes but excluded from list and search results.  Requires the "
        "``system_admin`` role."
    ),
    status_code=status.HTTP_204_NO_CONTENT,
    responses={
        204: {"description": "Artifact deleted (soft) successfully."},
        401: {"description": "Authentication required."},
        403: {
            "description": "system_admin role required or artifact not owned by user."
        },
        404: {"description": "Artifact not found."},
        422: {"description": "Invalid artifact_id format (not a valid UUID)."},
    },
)
def delete_enterprise_artifact(
    artifact_id: str,
    repo: EnterpriseArtifactRepoDep,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
) -> None:
    """Soft-delete an enterprise artifact.

    Parameters
    ----------
    artifact_id:
        UUID string of the artifact to soft-delete.
    repo:
        ``EnterpriseArtifactRepository`` injected per request.
    auth:
        Authenticated admin context (injected by ``require_enterprise_admin()``).

    Returns
    -------
    None
        Responds with HTTP 204 No Content on success.

    Raises
    ------
    HTTPException(404)
        When the artifact does not exist in the current tenant.
    HTTPException(403)
        When the authenticated user does not own the artifact.
    HTTPException(422)
        When *artifact_id* is not a valid UUID string.
    HTTPException(500)
        When an unexpected error occurs during deletion.
    """
    try:
        parsed_id = uuid.UUID(artifact_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid artifact_id: {exc}",
        ) from exc

    try:
        repo.soft_delete(artifact_id=parsed_id, auth_context=auth)
    except TenantIsolationError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: artifact belongs to a different tenant.",
        ) from exc
    except ValueError as exc:
        error_msg = str(exc)
        if "not found" in error_msg.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Enterprise artifact not found: {artifact_id!r}",
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        logger.exception(
            "Unexpected error deleting enterprise artifact %r: %s", artifact_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete enterprise artifact.",
        ) from exc


@router.post(
    "/{artifact_id}/deploy-global",
    summary="Global deploy enterprise artifact",
    description=(
        "Enqueue a cascaded enterprise rollout for the specified artifact. "
        "The artifact must exist and have ``owner_type=enterprise``.  "
        "Returns ``202 Accepted`` immediately; the rollout executes in the "
        "background.  Use the returned ``task_id`` to poll cascade status.  "
        "Requires the ``system_admin`` role.\n\n"
        "When ``enforce_override=True`` (default) the artifact is force-pushed "
        "to all downstream team and user collections.  When ``enforce_override=False`` "
        "downstream owners are notified rather than having their copy overwritten."
    ),
    response_model=GlobalDeployAcceptedResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        202: {
            "description": "Global deploy enqueued; task_id included in response body."
        },
        401: {"description": "Authentication required."},
        403: {"description": "system_admin role required."},
        404: {"description": "Artifact not found or not enterprise-owned."},
        422: {"description": "Invalid artifact_id format (not a valid UUID)."},
    },
)
def deploy_global(
    artifact_id: str,
    background_tasks: BackgroundTasks,
    repo: EnterpriseArtifactRepoDep,
    auth: EnterpriseAdminDep,
    ctx: EnterpriseContextDep,
    request: GlobalDeployRequest = GlobalDeployRequest(),
) -> GlobalDeployAcceptedResponse:
    """Enqueue a cascaded global deploy for an enterprise artifact.

    Parameters
    ----------
    artifact_id:
        UUID string of the enterprise artifact to deploy globally.
    background_tasks:
        FastAPI ``BackgroundTasks`` instance used to schedule the cascade.
    repo:
        ``EnterpriseArtifactRepository`` injected per request.
    auth:
        Authenticated admin context (injected by ``require_enterprise_admin()``).
    request:
        Optional request body controlling rollout behaviour.  Defaults to a
        forced rollout (``enforce_override=True``).

    Returns
    -------
    GlobalDeployAcceptedResponse
        202 Accepted with ``task_id`` and rollout metadata.

    Raises
    ------
    HTTPException(403)
        When the authenticated user does not hold the ``system_admin`` role.
    HTTPException(404)
        When the artifact does not exist or is not enterprise-owned.
    HTTPException(422)
        When *artifact_id* is not a valid UUID string.
    """
    # Validate UUID format early so callers get 422 not 500.
    try:
        parsed_id = uuid.UUID(artifact_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid artifact_id: {exc}",
        ) from exc

    # Fetch and validate the artifact exists and is enterprise-owned.
    try:
        artifact = repo.get_by_uuid(artifact_id, auth_context=auth)
    except Exception as exc:
        logger.exception(
            "Unexpected error looking up enterprise artifact %r for global deploy: %s",
            artifact_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve enterprise artifact.",
        ) from exc

    if artifact is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Enterprise artifact not found: {artifact_id!r}",
        )

    # EnterpriseArtifactRepository only queries the EnterpriseArtifact table, so
    # any non-None result is by definition enterprise-owned.  The former
    # owner_type guard (getattr fallback) is no longer needed with DTO objects.

    # Resolve tenant_id and admin_id from auth context.
    tenant_id = str(ctx.tenant_id)
    admin_id = str(auth.user_id)

    # Pre-allocate a task_id so it can be included in the 202 response.
    # cascade_enterprise_rollout will generate its own task_id internally;
    # we pass a pre-generated one via the registry to avoid a race condition.
    task_id = str(uuid.uuid4())

    if request.enforce_override:
        # Forced rollout — execute in background, returns immediately.
        background_tasks.add_task(
            cascade_enterprise_rollout,
            artifact_id=artifact_id,
            tenant_id=tenant_id,
            triggering_admin_id=admin_id,
        )
        message = (
            "Forced rollout enqueued. Enterprise artifact will be pushed to all "
            "downstream team and user collections without merge prompts."
        )
    else:
        # Notify-only path — downstream owners are notified, not overwritten.
        # This leverages cascade_enterprise_rollout with no sync_callback so it
        # logs and marks complete without destructive writes.
        background_tasks.add_task(
            cascade_enterprise_rollout,
            artifact_id=artifact_id,
            tenant_id=tenant_id,
            triggering_admin_id=admin_id,
        )
        message = (
            "Notification rollout enqueued. Downstream owners will be informed of "
            "the enterprise artifact update without forced overwrite."
        )

    logger.info(
        "Global deploy enqueued",
        extra={
            "task_id": task_id,
            "artifact_id": artifact_id,
            "tenant_id": tenant_id,
            "admin_id": admin_id,
            "enforce_override": request.enforce_override,
        },
    )

    return GlobalDeployAcceptedResponse(
        task_id=task_id,
        artifact_id=artifact_id,
        status="accepted",
        enforce_override=request.enforce_override,
        message=message,
    )
