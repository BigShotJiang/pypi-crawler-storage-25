"""Sync-capture configuration CRUD endpoints (SYNC-5.2).

Provides endpoints for enterprise admins to manage per-scope configuration
overrides for the sync-capture subsystem.  The hierarchy resolution
(project > tier > global) is enforced by the repository layer.
"""

from __future__ import annotations

import logging
from typing import Annotated, Any, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import require_auth
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.api.schemas.sync_capture_config import (
    ConfigScope,
    SyncCaptureConfigCreate,
    SyncCaptureConfigRead,
    SyncCaptureConfigUpdate,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/sync-capture-config",
    tags=["sync-capture-config"],
)


# ---------------------------------------------------------------------------
# Dependency helpers
# ---------------------------------------------------------------------------


def _get_repo():
    """Return a fresh :class:`SyncCaptureConfigRepository` for each request."""
    from skillmeat.core.repositories.sync_capture_config_repository import (
        SyncCaptureConfigRepository,
    )

    return SyncCaptureConfigRepository()


RepoDep = Annotated[Any, Depends(_get_repo)]


# ---------------------------------------------------------------------------
# GET /sync-capture-config
# ---------------------------------------------------------------------------


@router.get(
    "",
    response_model=List[SyncCaptureConfigRead],
    summary="List sync-capture config overrides",
    description=(
        "Returns all sync-capture configuration rows, optionally filtered by "
        "scope level.  Rows are ordered by scope then scope_id."
    ),
    responses={
        200: {"description": "List of config rows"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
    },
)
async def list_configs(
    repo: RepoDep,
    scope: Optional[ConfigScope] = Query(
        None,
        description=("Filter by scope level. Omit to list all scopes."),
    ),
    _auth=Depends(require_auth()),
) -> List[SyncCaptureConfigRead]:
    """List all sync-capture config overrides, optionally filtered by scope.

    Args:
        repo: Repository dependency.
        scope: Optional scope filter.
        _auth: Auth context (enforces authentication; value unused here).

    Returns:
        List of :class:`SyncCaptureConfigRead` instances.
    """
    scope_str = scope.value if scope is not None else None
    try:
        rows = repo.list_configs(scope=scope_str)
    except Exception as exc:
        logger.exception("list_configs: failed to query sync_capture_config: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve sync-capture configs.",
        ) from exc

    return [SyncCaptureConfigRead.model_validate(row) for row in rows]


# ---------------------------------------------------------------------------
# GET /sync-capture-config/effective
# ---------------------------------------------------------------------------


@router.get(
    "/effective",
    response_model=SyncCaptureConfigRead,
    summary="Get the effective (hierarchy-resolved) sync-capture config",
    description=(
        "Resolves the most specific matching config using the hierarchy: "
        "project > tier > global.  Provide ``scope_id`` for project-level "
        "resolution and/or ``tier`` for tier-level resolution.  Returns the "
        "first matching row in hierarchy order, or 404 if no config exists at "
        "any level."
    ),
    responses={
        200: {"description": "Resolved effective config"},
        404: {
            "model": ErrorResponse,
            "description": "No config found at any hierarchy level",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
    },
)
async def get_effective_config(
    repo: RepoDep,
    scope_id: Optional[str] = Query(
        None,
        description=(
            "Project ID to use for project-scope resolution. "
            "When provided, a project-scope row is tried first."
        ),
    ),
    tier: Optional[str] = Query(
        None,
        description=(
            "Tier name to use for tier-scope resolution. "
            "Tried after project-scope, before global."
        ),
    ),
    _auth=Depends(require_auth()),
) -> SyncCaptureConfigRead:
    """Return the hierarchy-resolved effective config.

    Args:
        repo: Repository dependency.
        scope_id: Optional project ID.
        tier: Optional tier name.
        _auth: Auth context.

    Returns:
        The resolved :class:`SyncCaptureConfigRead` instance.

    Raises:
        HTTPException 404: No config exists at any scope level.
    """
    try:
        row = repo.get_effective_config(scope_id=scope_id, tier=tier)
    except Exception as exc:
        logger.exception(
            "get_effective_config: failed scope_id=%s tier=%s: %s",
            scope_id,
            tier,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to resolve effective sync-capture config.",
        ) from exc

    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "No sync-capture config found for the given scope context. "
                "Create a global config first via PUT /sync-capture-config."
            ),
        )

    return SyncCaptureConfigRead.model_validate(row)


# ---------------------------------------------------------------------------
# PUT /sync-capture-config
# ---------------------------------------------------------------------------


@router.put(
    "",
    response_model=SyncCaptureConfigRead,
    summary="Upsert a sync-capture config override",
    description=(
        "Creates or updates a sync-capture configuration row for the given "
        "scope and scope_id.  The operation is idempotent: if a row already "
        "exists it is updated in-place."
    ),
    responses={
        200: {"description": "Config row created or updated"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid scope / scope_id combination",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        422: {"description": "Validation error"},
    },
)
async def upsert_config(
    request: SyncCaptureConfigCreate,
    repo: RepoDep,
    _auth=Depends(require_auth()),
) -> SyncCaptureConfigRead:
    """Create or update a sync-capture config row.

    Args:
        request: Upsert payload.
        repo: Repository dependency.
        _auth: Auth context.

    Returns:
        The created or updated :class:`SyncCaptureConfigRead` instance.

    Raises:
        HTTPException 400: Invalid scope / scope_id combination.
    """
    try:
        row = repo.upsert_config(
            scope=request.scope.value,
            scope_id=request.scope_id,
            quiet_window_seconds=request.quiet_window_seconds,
            auto_scan_enabled=request.auto_scan_enabled,
            sync_capture_enabled=request.sync_capture_enabled,
            max_captures_per_hour=request.max_captures_per_hour,
        )
    except ValueError as exc:
        logger.warning("upsert_config: validation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        logger.exception("upsert_config: failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to upsert sync-capture config.",
        ) from exc

    return SyncCaptureConfigRead.model_validate(row)


# ---------------------------------------------------------------------------
# DELETE /sync-capture-config/{scope}/{scope_id}
# ---------------------------------------------------------------------------


@router.delete(
    "/{scope}/{scope_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a sync-capture config override",
    description=(
        "Removes the config row for the given scope and scope_id. "
        "For the global scope, use the literal string 'null' as scope_id."
    ),
    responses={
        204: {"description": "Config deleted (no content)"},
        404: {
            "model": ErrorResponse,
            "description": "Config not found",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
    },
)
async def delete_config(
    scope: str,
    scope_id: str,
    repo: RepoDep,
    _auth=Depends(require_auth()),
) -> None:
    """Delete the config override for ``(scope, scope_id)``.

    Args:
        scope: Scope level (``global``, ``tier``, or ``project``).
        scope_id: Discriminator.  Pass the literal string ``null`` to delete
            the global scope row.
        repo: Repository dependency.
        _auth: Auth context.

    Raises:
        HTTPException 404: No matching config row found.
    """
    # Allow clients to DELETE the global row by passing 'null' as scope_id.
    resolved_scope_id: Optional[str] = None if scope_id.lower() == "null" else scope_id

    try:
        deleted = repo.delete_config(scope=scope, scope_id=resolved_scope_id)
    except Exception as exc:
        logger.exception(
            "delete_config: failed scope=%s scope_id=%s: %s", scope, scope_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete sync-capture config.",
        ) from exc

    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"No sync-capture config found for scope='{scope}' "
                f"scope_id='{scope_id}'."
            ),
        )
