"""Context sync API endpoints.

API endpoints for bi-directional synchronization of context entities between
user collections and deployed projects.

Endpoints:
    POST /context-sync/pull - Pull changes from project to collection
    POST /context-sync/push - Push collection changes to project
    GET /context-sync/status - Get sync status for project
    POST /context-sync/resolve - Resolve a sync conflict
"""

import logging
from pathlib import Path
from typing import List, Dict

from skillmeat.core.version_service import VersionService

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ContextSyncServiceDep,
    ContextSyncServiceOptDep,
    SettingsDep,
    verify_api_key,
    get_auth_context,
    require_auth,
)
from skillmeat.api.schemas.context_sync import (
    ComplianceCheckResponse,
    SyncConflictResponse,
    SyncPullRequest,
    SyncPushRequest,
    SyncResolveRequest,
    SyncResultResponse,
    SyncStatusResponse,
)
from skillmeat.core.services.context_sync import ContextSyncService, SyncConflict
from skillmeat.api.schemas.auth import AuthContext

logger = logging.getLogger(__name__)


def _create_push_versions(
    results: list,
    pre_push_hashes: Dict[str, Dict[str, str]],
) -> None:
    """Create version records for successfully pushed entities.

    Push direction is collection → project. The collection_hash is the new
    content being written to the project; the deployed_hash is the prior
    project content (parent version).

    This function is non-blocking: any failure is logged as a warning and
    does not affect the push response.

    Args:
        results: List of SyncResult objects from push_changes().
        pre_push_hashes: Dict mapping entity_id → {"collection_hash", "deployed_hash"}
            captured before the push operation.
    """
    try:
        from skillmeat.cache.models import get_session
    except ImportError:
        logger.debug("DB session not available, skipping push version creation")
        return

    for result in results:
        if result.action != "pushed":
            continue

        entity_id = result.entity_id  # Already in type:name format
        hashes = pre_push_hashes.get(entity_id, {})
        content_hash = hashes.get("collection_hash", "")
        parent_hash = hashes.get("deployed_hash", "") or None

        if not content_hash:
            logger.debug(
                f"No content hash available for {entity_id}, skipping version creation"
            )
            continue

        # TODO: Phase 3 — conflict check before push
        try:
            session = get_session()
            try:
                vs = VersionService(session)
                vs.record_mutation(
                    artifact_id=entity_id,
                    change_origin="push",
                    content_hash=content_hash,
                    parent_hash=parent_hash,
                )
                session.commit()
                logger.info(
                    f"Created push version for {entity_id}: "
                    f"{content_hash[:12]}... (parent: "
                    f"{parent_hash[:12] if parent_hash else 'none'}...)"
                )
            finally:
                session.close()
        except Exception as e:
            logger.warning(
                f"Failed to create push version for {entity_id}: {e}. "
                "Push operation succeeded; version tracking skipped."
            )


router = APIRouter(
    prefix="/context-sync",
    tags=["context-sync"],
    dependencies=[Depends(verify_api_key)],  # All endpoints require API key
)


@router.post(
    "/pull",
    response_model=List[SyncResultResponse],
    summary="Pull changes from project",
    description="Pull changes from project deployed files to collection entities",
    responses={
        200: {
            "description": "Successfully pulled changes",
            "content": {
                "application/json": {
                    "example": [
                        {
                            "entity_id": "spec_file:api-patterns",
                            "entity_name": "api-patterns",
                            "action": "pulled",
                            "message": "Successfully pulled changes from api-patterns.md",
                        }
                    ]
                }
            },
        },
        404: {
            "description": "Project path not found",
            "content": {
                "application/json": {
                    "example": {"detail": "Project path not found: /invalid/path"}
                }
            },
        },
        500: {
            "description": "Sync operation failed",
            "content": {
                "application/json": {"example": {"detail": "Sync failed: <error>"}}
            },
        },
    },
)
async def pull_changes(
    request: SyncPullRequest,
    settings: SettingsDep,
    sync_service: ContextSyncServiceOptDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> List[SyncResultResponse]:
    """Pull changes from project to collection.

    Reads deployed files and updates collection entities with new content.
    This captures manual edits made to deployed files in the project.

    In enterprise edition, pull operates against the DB-backed
    ``EnterpriseContextSyncService``; no filesystem access is required.

    Args:
        request: Pull request with project path and optional entity IDs
        settings: Application settings
        sync_service: IContextSyncService dependency (None when feature disabled)

    Returns:
        List of sync results

    Raises:
        HTTPException: If project path not found or sync fails
    """
    if sync_service is None:
        if settings.edition == "enterprise":
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail=(
                    "Context sync is not yet available in enterprise edition. "
                    "This feature is deferred to v2.2."
                ),
            )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Context sync service unavailable. "
                "In enterprise edition, ensure enterprise_sync_enabled feature flag is set."
            ),
        )

    logger.info(f"Pull request for project: {request.project_path}")

    # Local edition: validate project path exists on disk.
    # Enterprise edition: project_path is a DB registry key, not a FS path.
    if settings.edition != "enterprise":
        project_path = Path(request.project_path)
        if not project_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Project path not found: {request.project_path}",
            )

    try:
        # Pull changes. auth_context is not part of IContextSyncService.pull_changes;
        # enterprise RBAC enforcement is handled inside the service.
        results = sync_service.pull_changes(
            project_path=request.project_path,
            entity_ids=request.entity_ids,
        )

        # Convert to response models
        response = [
            SyncResultResponse(
                entity_id=r.entity_id,
                entity_name=r.entity_name,
                action=r.action,
                message=r.message,
            )
            for r in results
        ]

        logger.info(f"Pull completed: {len(response)} entities processed")
        return response

    except FileNotFoundError as e:
        logger.error(f"File not found during pull: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.exception(f"Pull failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Sync failed: {str(e)}",
        )


@router.post(
    "/push",
    response_model=List[SyncResultResponse],
    summary="Push changes to project",
    description="Push collection entity changes to project deployed files",
    responses={
        200: {
            "description": "Successfully pushed changes",
            "content": {
                "application/json": {
                    "example": [
                        {
                            "entity_id": "spec_file:api-patterns",
                            "entity_name": "api-patterns",
                            "action": "pushed",
                            "message": "Successfully pushed changes to api-patterns.md",
                        }
                    ]
                }
            },
        },
        404: {"description": "Project path not found"},
        409: {
            "description": "Conflict detected (file modified locally)",
            "content": {
                "application/json": {
                    "example": [
                        {
                            "entity_id": "spec_file:api-patterns",
                            "entity_name": "api-patterns",
                            "action": "conflict",
                            "message": "Both collection and project modified, use overwrite=True to force",
                        }
                    ]
                }
            },
        },
        500: {"description": "Sync operation failed"},
    },
)
async def push_changes(
    request: SyncPushRequest,
    settings: SettingsDep,
    sync_service: ContextSyncServiceOptDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> List[SyncResultResponse]:
    """Push collection changes to project.

    Writes collection entity content to deployed files. If overwrite=False
    and file has been modified, returns conflict instead of overwriting.

    In enterprise edition, push operates against the DB-backed
    ``EnterpriseContextSyncService``; no filesystem access is required.

    Args:
        request: Push request with project path, entity IDs, and overwrite flag
        settings: Application settings
        sync_service: IContextSyncService dependency (None when feature disabled)

    Returns:
        List of sync results

    Raises:
        HTTPException: If project path not found or sync fails
    """
    if sync_service is None:
        if settings.edition == "enterprise":
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail=(
                    "Context sync is not yet available in enterprise edition. "
                    "This feature is deferred to v2.2."
                ),
            )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Context sync service unavailable. "
                "In enterprise edition, ensure enterprise_sync_enabled feature flag is set."
            ),
        )

    logger.info(
        f"Push request for project: {request.project_path} (overwrite={request.overwrite})"
    )

    # Local edition: validate project path exists on disk.
    # Enterprise edition: project_path is a DB registry key, not a FS path.
    if settings.edition != "enterprise":
        project_path = Path(request.project_path)
        if not project_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Project path not found: {request.project_path}",
            )

    try:
        # Capture pre-push entity hashes for version tracking.
        # detect_modified_entities returns dicts with collection_hash and deployed_hash.
        # We need these before push so we can record what changed.
        # Skip in enterprise: hash capture is DB-internal to the service.
        pre_push_hashes: Dict[str, Dict[str, str]] = {}
        if settings.edition != "enterprise":
            try:
                modified_entities = sync_service.detect_modified_entities(
                    request.project_path
                )
                for entity in modified_entities:
                    pre_push_hashes[entity["entity_id"]] = {
                        "collection_hash": entity.get("collection_hash", ""),
                        "deployed_hash": entity.get("deployed_hash", ""),
                    }
            except Exception as e:
                logger.warning(
                    f"Failed to capture pre-push hashes for version tracking: {e}"
                )

        # Push changes. The enterprise service accepts auth_context as a
        # keyword-only argument for Tier 1/2 RBAC enforcement; the local service
        # does not declare it. Pass it only for enterprise instances.
        from skillmeat.core.services.enterprise_context_sync import (
            EnterpriseContextSyncService,
        )

        if isinstance(sync_service, EnterpriseContextSyncService):
            results = sync_service.push_changes(
                project_path=request.project_path,
                entity_ids=request.entity_ids,
                overwrite=request.overwrite,
                auth_context=auth_context,
            )
        else:
            results = sync_service.push_changes(
                project_path=request.project_path,
                entity_ids=request.entity_ids,
                overwrite=request.overwrite,
            )

        # Convert to response models
        response = [
            SyncResultResponse(
                entity_id=r.entity_id,
                entity_name=r.entity_name,
                action=r.action,
                message=r.message,
            )
            for r in results
        ]

        logger.info(f"Push completed: {len(response)} entities processed")

        # Create version records for successfully pushed entities.
        # Push is collection → project, so collection_hash is the new content
        # and deployed_hash is the parent (what was in the project before).
        # Version tracking is non-blocking: failures log a warning but don't
        # affect the push result.
        _create_push_versions(results, pre_push_hashes)

        return response

    except FileNotFoundError as e:
        logger.error(f"File not found during push: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.exception(f"Push failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Sync failed: {str(e)}",
        )


@router.get(
    "/status",
    response_model=SyncStatusResponse,
    summary="Get sync status",
    description="Get sync status for a project (modified entities and conflicts)",
    responses={
        200: {
            "description": "Sync status retrieved",
            "content": {
                "application/json": {
                    "example": {
                        "modified_in_project": ["spec_file:api-patterns"],
                        "modified_in_collection": ["rule_file:debugging"],
                        "conflicts": [
                            {
                                "entity_id": "spec_file:api-patterns",
                                "entity_name": "api-patterns",
                                "entity_type": "spec_file",
                                "collection_hash": "abc123",
                                "deployed_hash": "def456",
                                "collection_content": "# API Patterns...",
                                "deployed_content": "# API Patterns (modified)...",
                                "collection_path": "/collection/path",
                                "deployed_path": "/project/.claude/specs/api-patterns.md",
                            }
                        ],
                    }
                }
            },
        },
        404: {"description": "Project path not found"},
        500: {"description": "Status check failed"},
    },
)
async def get_sync_status(
    settings: SettingsDep,
    sync_service: ContextSyncServiceOptDep,
    project_path: str = Query(..., description="Absolute path to project directory"),
    auth_context: AuthContext = Depends(get_auth_context),
) -> SyncStatusResponse:
    """Get sync status for a project.

    Detects modified entities and conflicts between collection and project.

    Args:
        settings: Application settings
        project_path: Absolute path to project directory
        sync_service: ContextSyncService dependency (None in enterprise edition)

    Returns:
        Sync status with modified entities and conflicts

    Raises:
        HTTPException: If project path not found or status check fails
    """
    # Enterprise edition: EnterpriseContextSyncService is now wired via the
    # ContextSyncServiceOptDep factory (enterprise_sync_enabled=True).  When
    # the flag is disabled the factory returns None; fall through to the
    # filesystem guard below.
    if settings.edition != "enterprise":
        # Local edition — validate project path exists on disk.
        path = Path(project_path)
        if not path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Project path not found: {project_path}",
            )

    if sync_service is None:
        if settings.edition == "enterprise":
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail=(
                    "Context sync is not yet available in enterprise edition. "
                    "This feature is deferred to v2.2."
                ),
            )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Context sync service unavailable. "
                "In enterprise edition, ensure enterprise_sync_enabled feature flag is set."
            ),
        )

    logger.info(f"Status request for project: {project_path}")

    try:
        # Get modified entities
        modified = sync_service.detect_modified_entities(project_path)

        # Separate by modification location.
        # Local service uses: "project", "collection", "both".
        # Enterprise service uses: "outdated" (collection-side drift) and
        # "diverged" (both sides moved — content conflict).
        modified_in_project = [
            e["entity_id"]
            for e in modified
            if e["modified_in"] in ("project", "both", "diverged")
        ]
        modified_in_collection = [
            e["entity_id"]
            for e in modified
            if e["modified_in"] in ("collection", "both", "outdated", "diverged")
        ]

        # Get conflicts — enterprise detect_conflicts is implemented in ECS-5;
        # gracefully degrade to empty list when not yet available.
        try:
            conflicts = sync_service.detect_conflicts(project_path)
        except NotImplementedError:
            logger.debug(
                "detect_conflicts not yet implemented for this service; "
                "returning empty conflict list"
            )
            conflicts = []

        # Convert to response models with change attribution
        conflict_responses = [
            SyncConflictResponse(
                entity_id=c.entity_id,
                entity_name=c.entity_name,
                entity_type=c.entity_type,
                collection_hash=c.collection_hash,
                deployed_hash=c.deployed_hash,
                collection_content=c.collection_content,
                deployed_content=c.deployed_content,
                collection_path=c.collection_path,
                deployed_path=c.deployed_path,
                change_origin="conflict",  # Both sides modified
                baseline_hash=c.baseline_hash,  # Hash at deployment time
            )
            for c in conflicts
        ]

        logger.info(
            f"Status check complete: {len(modified_in_project)} project, "
            f"{len(modified_in_collection)} collection, {len(conflicts)} conflicts"
        )

        return SyncStatusResponse(
            modified_in_project=modified_in_project,
            modified_in_collection=modified_in_collection,
            conflicts=conflict_responses,
        )

    except Exception as e:
        logger.exception(f"Status check failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Status check failed: {str(e)}",
        )


@router.post(
    "/resolve",
    response_model=SyncResultResponse,
    summary="Resolve sync conflict",
    description="Resolve a sync conflict using user-selected strategy",
    responses={
        200: {
            "description": "Conflict resolved",
            "content": {
                "application/json": {
                    "example": {
                        "entity_id": "spec_file:api-patterns",
                        "entity_name": "api-patterns",
                        "action": "resolved",
                        "message": "Conflict resolved using strategy: keep_local",
                    }
                }
            },
        },
        400: {
            "description": "Invalid request (e.g., merge without content)",
            "content": {
                "application/json": {
                    "example": {
                        "detail": "merged_content required when resolution='merge'"
                    }
                }
            },
        },
        404: {"description": "Project path or entity not found"},
        500: {"description": "Resolution failed"},
    },
)
async def resolve_conflict(
    request: SyncResolveRequest,
    settings: SettingsDep,
    sync_service: ContextSyncServiceOptDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> SyncResultResponse:
    """Resolve sync conflict.

    Applies user-selected resolution strategy:
    - keep_local: Update collection from project (project wins)
    - keep_remote: Update project from collection (collection wins)
    - merge: Use provided merged_content for both

    In enterprise edition, resolution operates against the DB-backed
    ``EnterpriseContextSyncService``; no filesystem access is required.

    Args:
        request: Resolve request with project path, entity ID, and resolution
        settings: Application settings
        sync_service: IContextSyncService dependency (None when feature disabled)

    Returns:
        Sync result with resolution outcome

    Raises:
        HTTPException: If validation fails or resolution fails
    """
    if sync_service is None:
        if settings.edition == "enterprise":
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail=(
                    "Context sync is not yet available in enterprise edition. "
                    "This feature is deferred to v2.2."
                ),
            )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Context sync service unavailable. "
                "In enterprise edition, ensure enterprise_sync_enabled feature flag is set."
            ),
        )

    logger.info(
        f"Resolve request for {request.entity_id} in {request.project_path}: "
        f"strategy={request.resolution}"
    )

    # Local edition: validate project path exists on disk.
    # Enterprise edition: project_path is a DB registry key, not a FS path.
    if settings.edition != "enterprise":
        project_path = Path(request.project_path)
        if not project_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Project path not found: {request.project_path}",
            )

    # Validate merge has content
    if request.resolution == "merge" and not request.merged_content:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="merged_content required when resolution='merge'",
        )

    try:
        # Find conflict for this entity
        conflicts = sync_service.detect_conflicts(request.project_path)
        conflict = next(
            (c for c in conflicts if c.entity_id == request.entity_id), None
        )

        if not conflict:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No conflict found for entity: {request.entity_id}",
            )

        # Resolve conflict
        result = sync_service.resolve_conflict(
            conflict=conflict,
            resolution=request.resolution,
            merged_content=request.merged_content,
        )

        logger.info(f"Conflict resolved for {request.entity_id}: {result.action}")

        return SyncResultResponse(
            entity_id=result.entity_id,
            entity_name=result.entity_name,
            action=result.action,
            message=result.message,
        )

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except ValueError as e:
        # Validation errors
        logger.error(f"Validation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        logger.exception(f"Conflict resolution failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Resolution failed: {str(e)}",
        )


@router.get(
    "/compliance-check",
    response_model=ComplianceCheckResponse,
    summary="Compliance check for forced artifact updates",
    description=(
        "Check whether a project has any artifacts that have diverged from the "
        "enterprise baseline and require a forced update. Enterprise edition only. "
        "This endpoint is read-only and idempotent — safe for CI service accounts."
    ),
    responses={
        200: {
            "description": "Compliance check result",
            "content": {
                "application/json": {
                    "example": {
                        "updates_required": True,
                        "forced_artifact_ids": ["aaaabbbb-cccc-dddd-eeee-ffffffffffff"],
                    }
                }
            },
        },
        404: {
            "description": "Project path not found in enterprise registry",
            "content": {
                "application/json": {
                    "example": {"detail": "Project path not found: /invalid/path"}
                }
            },
        },
        501: {
            "description": "Enterprise sync feature not enabled or not enterprise edition",
        },
        500: {"description": "Compliance check failed"},
    },
)
async def compliance_check(
    settings: SettingsDep,
    sync_service: ContextSyncServiceOptDep,
    project_path: str = Query(..., description="Absolute path to project directory"),
    auth_context: AuthContext = Depends(get_auth_context),
) -> ComplianceCheckResponse:
    """Check whether a project has forced/mandatory updates pending.

    Queries ``EnterpriseArtifactVersionScope`` for rows where ``is_diverged=True``
    and returns a summary of which artifacts require attention.

    This endpoint accepts both user bearer auth and API key auth so that CI
    service accounts can poll it without a full user session.

    Enterprise edition only.  Returns HTTP 501 in local/community edition.

    Args:
        settings: Application settings.
        sync_service: EnterpriseContextSyncService (None when feature disabled).
        project_path: Filesystem path string identifying the project.
        auth_context: Resolved authentication context.

    Returns:
        ComplianceCheckResponse with updates_required flag and artifact IDs.

    Raises:
        HTTPException 501: Not enterprise edition or feature flag disabled.
        HTTPException 404: Project path not registered in enterprise DB.
        HTTPException 500: Internal error during compliance check.
    """
    if settings.edition != "enterprise":
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Compliance check is only available in enterprise edition. "
                "Local edition does not track diverged version scopes."
            ),
        )

    if sync_service is None:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=(
                "Enterprise sync is not enabled. "
                "Set enterprise_sync_enabled=true to activate."
            ),
        )

    logger.info("Compliance check request: project_path=%r", project_path)

    try:
        from skillmeat.core.services.enterprise_context_sync import (
            EnterpriseContextSyncService,
        )

        if not isinstance(sync_service, EnterpriseContextSyncService):
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="Compliance check requires the enterprise sync service.",
            )

        result = sync_service.compliance_check(project_path)

        # When the project path is unknown compliance_check returns an empty
        # result rather than raising.  Surface this as a 404 so callers can
        # distinguish "no updates needed" from "project not found".
        if not result["forced_artifact_ids"] and result["updates_required"] is False:
            # Double-check: was the project actually registered?
            project_uuid = sync_service._resolve_project_uuid(project_path)
            if project_uuid is None:
                logger.warning(
                    "compliance_check: project path not found: %r", project_path
                )
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Project path not found in enterprise registry: {project_path}",
                )

        logger.info(
            "Compliance check complete: project_path=%r updates_required=%s count=%d",
            project_path,
            result["updates_required"],
            len(result["forced_artifact_ids"]),
        )

        return ComplianceCheckResponse(
            updates_required=result["updates_required"],
            forced_artifact_ids=result["forced_artifact_ids"],
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Compliance check failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Compliance check failed: {str(e)}",
        )
