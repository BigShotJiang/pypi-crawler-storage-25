"""BOM (Bill of Materials) and attestation API endpoints.

Provides endpoints for generating, retrieving, and managing SkillBOM snapshots
and attestation records.  All endpoints are owner-scoped: users see only their
own context's data, filtered by ``AuthContext.user_id`` and ``AuthContext.tenant_id``.

Endpoints:
    GET  /bom/snapshot              -- Current point-in-time BOM snapshot
    POST /bom/generate              -- On-demand BOM generation (with optional auto-sign)
    POST /bom/verify                -- Verify BOM signature on a snapshot
    GET  /attestations              -- Cursor-paginated list of attestation records
    POST /attestations              -- Create a manual attestation record
    GET  /attestations/{id}         -- Retrieve a single attestation record
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Union

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field

from skillmeat.api.dependencies import (
    ArtifactRepoDep,
    DbSessionDep,
    SettingsDep,
    get_auth_context,
)
from skillmeat.api.routers.artifacts._helpers import resolve_enterprise_artifact_id
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.bom import (
    ArtifactEntrySchema,
    AttestationSchema,
    BomSchema,
    EnterpriseAttestationCreateRequest,
    EnterpriseAttestationRecordResponse,
)
from skillmeat.cache.models import AttestationRecord, BomSnapshot

logger = logging.getLogger(__name__)

# Enterprise-edition BOM repository — lazily imported to avoid hard dependency on
# PostgreSQL / enterprise models in local mode.
_EnterpriseBomRepository = None


def _get_enterprise_bom_repo(session):
    """Return an EnterpriseBomRepository instance (lazy import).

    Args:
        session: SQLAlchemy session bound to the enterprise database.

    Returns:
        EnterpriseBomRepository instance.
    """
    global _EnterpriseBomRepository
    if _EnterpriseBomRepository is None:
        from skillmeat.cache.enterprise_repositories import (
            EnterpriseBomRepository as _Repo,
        )

        _EnterpriseBomRepository = _Repo
    return _EnterpriseBomRepository(session=session)


def _enterprise_attestation_dto_to_schema(dto: Any) -> "AttestationSchema":
    """Convert an :class:`AttestationRecordDTO` (enterprise) to :class:`AttestationSchema`.

    The enterprise attestation model uses a different schema than the local model:
    - ``snapshot_id`` is used instead of ``artifact_id`` (attestations are scoped to
      BOM snapshots, not directly to artifacts).
    - ``result`` (pass/fail/warning/error) replaces ``roles``/``scopes``/``visibility``.
    - ``owner_type``/``owner_id`` are inferred from ``tenant_id``.

    These are surfaced in :class:`AttestationSchema` as best-effort mappings so that
    existing API consumers receive a consistent shape.

    Args:
        dto: :class:`~skillmeat.core.interfaces.dtos.AttestationRecordDTO` instance.

    Returns:
        Serializable :class:`AttestationSchema`.
    """
    from skillmeat.api.schemas.bom import AttestationSchema as _AttestationSchema

    return _AttestationSchema(
        id=dto.id,
        artifact_id=dto.snapshot_id,  # Enterprise: snapshot_id plays the role of artifact_id
        owner_type="enterprise",
        owner_id=dto.tenant_id,
        roles=[dto.result] if dto.result else [],  # Result surfaced as first role
        scopes=list(dto.evidence.keys()) if dto.evidence else [],
        visibility="private",
        created_at=dto.created_at,
    )


# =============================================================================
# Response schemas (BOM router-specific)
# =============================================================================


class BomSnapshotResponse(BaseModel):
    """Response schema for a stored BOM snapshot.

    Wraps the deserialized BOM document alongside snapshot storage metadata
    (id, project_id, commit_sha, owner_type, created_at).  Signature fields
    are included when the caller requests ``include_signatures=true``.
    """

    id: Union[int, str] = Field(
        description="Snapshot primary key: integer (local) or UUID string (enterprise)"
    )
    project_id: Optional[str] = Field(
        default=None, description="Project scope for this snapshot"
    )
    commit_sha: Optional[str] = Field(
        default=None, description="Git commit SHA associated with this snapshot"
    )
    owner_type: str = Field(description="Owner context (user / team / enterprise)")
    created_at: str = Field(description="ISO-8601 UTC timestamp of snapshot creation")
    bom: BomSchema = Field(description="Deserialized BOM document")
    signature: Optional[str] = Field(
        default=None,
        description="Hex-encoded Ed25519 signature (present when include_signatures=true)",
    )
    signature_algorithm: Optional[str] = Field(
        default=None,
        description="Signature algorithm identifier (present when include_signatures=true)",
    )
    signing_key_id: Optional[str] = Field(
        default=None,
        description="SHA-256 fingerprint of the signing key (present when include_signatures=true)",
    )

    model_config = ConfigDict(from_attributes=True)


class BomGenerateRequest(BaseModel):
    """Request body for on-demand BOM generation."""

    project_id: Optional[str] = Field(
        default=None,
        description="Project scope to filter artifacts. None generates a collection-level BOM.",
    )
    auto_sign: bool = Field(
        default=False,
        description="Sign the generated BOM with the local Ed25519 signing key.",
    )

    model_config = ConfigDict(from_attributes=True)


class BomGenerateResponse(BaseModel):
    """Response schema for a freshly generated and persisted BOM snapshot."""

    id: int = Field(description="Auto-incrementing snapshot primary key")
    project_id: Optional[str] = Field(default=None)
    owner_type: str = Field(description="Owner context (user / team / enterprise)")
    created_at: str = Field(description="ISO-8601 UTC timestamp")
    bom: BomSchema = Field(description="Deserialized BOM document")
    signed: bool = Field(description="Whether the snapshot was signed")
    signature: Optional[str] = Field(
        default=None,
        description="Hex-encoded signature (present when auto_sign=true and signing succeeded)",
    )
    signing_key_id: Optional[str] = Field(
        default=None,
        description="SHA-256 fingerprint of the signing key (present when signed=true)",
    )

    model_config = ConfigDict(from_attributes=True)


class AttestationPageInfo(BaseModel):
    """Cursor-based pagination metadata for attestation list responses."""

    end_cursor: Optional[str] = Field(
        default=None,
        description="Opaque cursor pointing to the last item on this page",
    )
    has_next_page: bool = Field(
        description="True when more records exist after this page"
    )


class AttestationListResponse(BaseModel):
    """Paginated list of attestation records."""

    items: List[AttestationSchema] = Field(
        default_factory=list, description="Attestation records on this page"
    )
    page_info: AttestationPageInfo = Field(
        description="Cursor-based pagination metadata"
    )


# =============================================================================
# Helper utilities
# =============================================================================

_VALID_OWNER_SCOPES = frozenset({"user", "team", "enterprise"})


def _bom_dict_to_schema(bom_data: Dict[str, Any]) -> BomSchema:
    """Convert a raw BOM dict (from JSON) into a :class:`BomSchema` instance.

    Unknown keys in *bom_data* are placed into the ``metadata`` block so that
    the schema remains stable as the BOM format evolves.

    Args:
        bom_data: Parsed BOM dict as returned by ``BomGenerator.generate()``.

    Returns:
        Populated :class:`BomSchema`.
    """
    artifacts_raw: List[Dict[str, Any]] = bom_data.get("artifacts", [])
    artifact_entries = [
        ArtifactEntrySchema(
            name=entry.get("name", ""),
            type=entry.get("type", ""),
            source=entry.get("source"),
            version=entry.get("version"),
            content_hash=entry.get("content_hash", ""),
            metadata=entry.get("metadata", {}),
            members=entry.get("members"),
        )
        for entry in artifacts_raw
    ]

    # Gather all non-core top-level keys into metadata.
    core_keys = {
        "schema_version",
        "generated_at",
        "project_path",
        "artifact_count",
        "artifacts",
    }
    extra_meta: Dict[str, Any] = {
        k: v for k, v in bom_data.items() if k not in core_keys
    }

    return BomSchema(
        schema_version=bom_data.get("schema_version", "1.0.0"),
        generated_at=bom_data.get("generated_at", ""),
        project_path=bom_data.get("project_path"),
        artifact_count=bom_data.get("artifact_count", len(artifact_entries)),
        artifacts=artifact_entries,
        metadata=extra_meta,
    )


def _snapshot_to_bom_response(
    snapshot: BomSnapshot,
    include_signatures: bool = False,
) -> BomSnapshotResponse:
    """Build a :class:`BomSnapshotResponse` from a :class:`BomSnapshot` ORM row.

    Args:
        snapshot: ORM model row from ``bom_snapshots``.
        include_signatures: When False, signature fields are omitted (None).

    Returns:
        Populated :class:`BomSnapshotResponse`.

    Raises:
        HTTPException: 500 when ``bom_json`` cannot be deserialized.
    """
    try:
        bom_data: Dict[str, Any] = json.loads(snapshot.bom_json)
    except (json.JSONDecodeError, ValueError) as exc:
        logger.error(
            "Failed to deserialize bom_json for snapshot id=%s: %s",
            snapshot.id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="BOM snapshot data is corrupted and cannot be deserialized.",
        )

    return BomSnapshotResponse(
        id=snapshot.id,
        project_id=snapshot.project_id,
        commit_sha=snapshot.commit_sha,
        owner_type=snapshot.owner_type,
        created_at=snapshot.created_at.isoformat() if snapshot.created_at else "",
        bom=_bom_dict_to_schema(bom_data),
        signature=snapshot.signature if include_signatures else None,
        signature_algorithm=(
            snapshot.signature_algorithm if include_signatures else None
        ),
        signing_key_id=snapshot.signing_key_id if include_signatures else None,
    )


def _attestation_to_schema(record: AttestationRecord) -> AttestationSchema:
    """Convert an :class:`AttestationRecord` ORM row to :class:`AttestationSchema`.

    Args:
        record: ORM row from ``attestation_records``.

    Returns:
        Serializable :class:`AttestationSchema`.
    """
    return AttestationSchema(
        id=str(record.id),
        artifact_id=record.artifact_id,
        owner_type=record.owner_type,
        owner_id=record.owner_id,
        roles=record.roles or [],
        scopes=record.scopes or [],
        visibility=record.visibility,
        created_at=record.created_at.isoformat() if record.created_at else None,
    )


# =============================================================================
# Router
# =============================================================================


router = APIRouter(tags=["bom"])


# ---------------------------------------------------------------------------
# GET /bom/snapshot
# ---------------------------------------------------------------------------


@router.get(
    "/bom/snapshot",
    response_model=BomSnapshotResponse,
    summary="Get current BOM snapshot",
    description=(
        "Return the most recent point-in-time Bill of Materials snapshot for "
        "the authenticated caller's scope.  Snapshots are owner-scoped: the "
        "response reflects only artifacts visible to the caller."
    ),
    responses={
        200: {"description": "BOM snapshot retrieved successfully"},
        404: {"description": "No BOM snapshot exists for the caller's scope"},
    },
)
async def get_bom_snapshot(
    db: DbSessionDep,
    settings: SettingsDep,
    auth_context: AuthContext = Depends(get_auth_context),
    project_id: Optional[str] = Query(
        default=None,
        description="Optional project scope filter. When omitted, returns the collection-level snapshot.",
    ),
    include_memory_items: bool = Query(
        default=False,
        description="Include memory-item artifact entries in the BOM (may increase response size).",
    ),
    include_signatures: bool = Query(
        default=False,
        description="Include Ed25519 signature fields (signature, signature_algorithm, signing_key_id).",
    ),
) -> BomSnapshotResponse:
    """Return the most recent BOM snapshot for the caller's owner context.

    Filters snapshots by:
    - ``owner_type`` matching the caller's principal type (``"user"`` by default).
    - Optional ``project_id`` when provided.

    The snapshot with the latest ``created_at`` is returned.

    In enterprise edition, snapshots are served from ``EnterpriseBomSnapshot``
    via the tenant-scoped ``EnterpriseBomRepository``.  The ``snapshot_data``
    JSONB dict is treated as the BOM document.  Signature fields are not stored
    in the enterprise model and will always be ``None``.
    """
    if settings.edition == "enterprise":
        try:
            repo = _get_enterprise_bom_repo(db)
            snapshots = repo.list_snapshots(limit=1)
            if not snapshots:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="No BOM snapshot found for the caller's scope.",
                )
            dto = snapshots[0]
            bom_data: Dict[str, Any] = (
                dict(dto.snapshot_data) if dto.snapshot_data else {}
            )
            bom_schema = _bom_dict_to_schema(bom_data)
            if not include_memory_items and bom_schema.artifacts:
                filtered = [a for a in bom_schema.artifacts if a.type != "memory_item"]
                bom_schema = bom_schema.model_copy(
                    update={
                        "artifacts": filtered,
                        "artifact_count": len(filtered),
                    }
                )
            return BomSnapshotResponse(
                id=dto.id,
                project_id=project_id,
                commit_sha=None,
                owner_type="enterprise",
                created_at=dto.created_at or "",
                bom=bom_schema,
                signature=None,
                signature_algorithm=None,
                signing_key_id=None,
            )
        except HTTPException:
            raise
        except Exception as exc:
            logger.exception("Failed to retrieve enterprise BOM snapshot: %s", exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve BOM snapshot.",
            )

    # --- Local edition path ---
    try:
        # Determine owner_type from auth context (default to "user").
        owner_type = "user"
        if auth_context.tenant_id:
            owner_type = "enterprise"

        query = db.query(BomSnapshot).filter(BomSnapshot.owner_type == owner_type)

        if project_id is not None:
            query = query.filter(BomSnapshot.project_id == project_id)

        snapshot: Optional[BomSnapshot] = query.order_by(
            BomSnapshot.created_at.desc()
        ).first()

        if snapshot is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No BOM snapshot found for the caller's scope.",
            )

        response = _snapshot_to_bom_response(
            snapshot, include_signatures=include_signatures
        )

        # Filter out memory-item artifacts unless explicitly requested.
        if not include_memory_items and response.bom.artifacts:
            response.bom.artifacts = [
                a for a in response.bom.artifacts if a.type != "memory_item"
            ]
            response.bom.artifact_count = len(response.bom.artifacts)

        return response

    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to retrieve BOM snapshot: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve BOM snapshot.",
        )


# ---------------------------------------------------------------------------
# POST /bom/generate
# ---------------------------------------------------------------------------


@router.post(
    "/bom/generate",
    response_model=BomGenerateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Generate a BOM snapshot on demand",
    description=(
        "Trigger an on-demand Bill of Materials generation for the caller's "
        "artifact scope.  The result is persisted as a BomSnapshot row and "
        "optionally signed with the local Ed25519 signing key."
    ),
    responses={
        201: {"description": "BOM generated and persisted successfully"},
        500: {"description": "BOM generation failed"},
    },
)
async def generate_bom(
    request: BomGenerateRequest,
    db: DbSessionDep,
    settings: SettingsDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> BomGenerateResponse:
    """Generate a fresh BOM snapshot and persist it to the database.

    Steps:
    1. Instantiate ``BomGenerator`` with the current DB session.
    2. Call ``generate(project_id=...)`` to produce the BOM dict.
    3. Serialize to JSON via ``BomSerializer.to_json()``.
    4. If ``auto_sign`` is True, sign with ``sign_bom()`` using the default key.
    5. Persist as a ``BomSnapshot`` row and commit the session.
    6. Return the generated snapshot.

    In enterprise edition this operation is not yet supported because
    ``EnterpriseBomSnapshot`` requires an ``artifact_id`` FK (UUID) to an
    existing ``enterprise_artifacts`` row, which is not available in the
    collection-level generation flow.  Callers in enterprise mode receive
    a 503 until the per-artifact BOM generation API is implemented.
    """
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Enterprise BoM generation pending future release.  "
                "On-demand BOM generation requires an artifact_id FK to "
                "enterprise_artifacts which is not available in the "
                "collection-level generation flow. "
                "See enterprise-stub-promotion Phase 3 findings."
            ),
        )

    from skillmeat.core.bom.generator import BomGenerator, BomSerializer

    # Determine owner_type from auth context.
    owner_type = "user"
    if auth_context.tenant_id:
        owner_type = "enterprise"

    try:
        generator = BomGenerator(session=db)
        bom_dict = generator.generate(project_id=request.project_id)
    except Exception as exc:
        logger.exception("BOM generation failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"BOM generation failed: {exc}",
        )

    serializer = BomSerializer()
    bom_json_str = serializer.to_json(bom_dict)

    # Optional Ed25519 signing.
    signature_hex: Optional[str] = None
    signing_key_id: Optional[str] = None
    signing_algorithm: Optional[str] = None
    signed = False

    if request.auto_sign:
        try:
            from skillmeat.core.bom.signing import sign_bom

            sig_result = sign_bom(bom_json_str.encode())
            signature_hex = sig_result.signature_hex
            signing_key_id = sig_result.key_id
            signing_algorithm = sig_result.algorithm
            signed = True
        except Exception as sign_exc:
            logger.warning(
                "BOM auto-sign requested but signing failed (key missing or error): %s",
                sign_exc,
            )
            # Non-fatal: persist the BOM without a signature.

    try:
        snapshot = BomSnapshot(
            bom_json=bom_json_str,
            project_id=request.project_id,
            owner_type=owner_type,
            signature=signature_hex,
            signature_algorithm=signing_algorithm,
            signing_key_id=signing_key_id,
        )
        db.add(snapshot)
        db.commit()
        db.refresh(snapshot)
    except Exception as exc:
        db.rollback()
        logger.exception("Failed to persist BOM snapshot: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to persist BOM snapshot.",
        )

    return BomGenerateResponse(
        id=snapshot.id,
        project_id=snapshot.project_id,
        owner_type=snapshot.owner_type,
        created_at=snapshot.created_at.isoformat() if snapshot.created_at else "",
        bom=_bom_dict_to_schema(bom_dict),
        signed=signed,
        signature=signature_hex,
        signing_key_id=signing_key_id,
    )


# ---------------------------------------------------------------------------
# GET /attestations
# ---------------------------------------------------------------------------


@router.get(
    "/attestations",
    response_model=AttestationListResponse,
    tags=["attestations"],
    summary="List attestation records",
    description=(
        "Return a cursor-paginated list of attestation records visible to the "
        "authenticated caller.  Results are owner-scoped: each caller sees only "
        "records belonging to their own principal context."
    ),
    responses={
        200: {"description": "Attestation records retrieved successfully"},
        400: {"description": "Invalid query parameters"},
    },
)
async def list_attestations(
    db: DbSessionDep,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    auth_context: AuthContext = Depends(get_auth_context),
    owner_scope: Optional[str] = Query(
        default=None,
        description=(
            "Filter by owner scope: 'user', 'team', or 'enterprise'. "
            "When omitted, returns all records accessible to the caller."
        ),
    ),
    artifact_id: Optional[str] = Query(
        default=None,
        description="Filter by artifact identifier in 'type:name' or UUID format.",
    ),
    limit: int = Query(
        default=50,
        ge=1,
        le=200,
        description="Maximum number of records to return per page.",
    ),
    cursor: Optional[str] = Query(
        default=None,
        description=(
            "Opaque pagination cursor from a previous response's "
            "``page_info.end_cursor``.  When provided, results begin after "
            "the record identified by this cursor."
        ),
    ),
) -> AttestationListResponse:
    """List attestation records with owner-scope filtering and cursor pagination.

    Cursor semantics:
    - The cursor is the string representation of the last returned record's
      integer primary key (``id``).
    - Passing ``cursor=N`` returns records with ``id < N`` (newest-first ordering
      within each page is by ``id DESC``).
    """
    # Validate owner_scope when provided.
    if owner_scope is not None and owner_scope not in _VALID_OWNER_SCOPES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Invalid owner_scope '{owner_scope}'. "
                f"Must be one of: {sorted(_VALID_OWNER_SCOPES)!r}."
            ),
        )

    # --- Enterprise edition path ---
    if settings.edition == "enterprise":
        try:
            repo = _get_enterprise_bom_repo(db)
            dtos = repo.list_attestations(limit=min(limit, 100), after=cursor)
            has_next_page = len(dtos) > limit
            page_dtos = dtos[:limit]
            end_cursor: Optional[str] = None
            if page_dtos:
                end_cursor = page_dtos[-1].id
            return AttestationListResponse(
                items=[_enterprise_attestation_dto_to_schema(d) for d in page_dtos],
                page_info=AttestationPageInfo(
                    end_cursor=end_cursor,
                    has_next_page=has_next_page,
                ),
            )
        except HTTPException:
            raise
        except Exception as exc:
            logger.exception("Failed to list enterprise attestation records: %s", exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve attestation records.",
            )

    # --- Local edition path ---
    try:
        # Determine the caller's effective owner context.
        caller_owner_type = "user"
        caller_owner_id = (
            str(auth_context.user_id) if auth_context.user_id else "local_admin"
        )
        if auth_context.tenant_id:
            caller_owner_type = "enterprise"
            caller_owner_id = str(auth_context.tenant_id)

        # Build the base query — restrict to caller's owner context.
        query = db.query(AttestationRecord).filter(
            AttestationRecord.owner_type == caller_owner_type,
            AttestationRecord.owner_id == caller_owner_id,
        )

        # Optional owner_scope secondary filter (refines owner_type).
        if owner_scope is not None:
            query = query.filter(AttestationRecord.owner_type == owner_scope)

        # Optional artifact filter — resolve type:name → UUID in enterprise mode.
        if artifact_id is not None:
            resolved_artifact_id = await resolve_enterprise_artifact_id(
                artifact_id, settings, artifact_repo
            )
            query = query.filter(AttestationRecord.artifact_id == resolved_artifact_id)

        # Cursor-based pagination: records with id < cursor, newest-first.
        if cursor is not None:
            try:
                cursor_id = int(cursor)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid cursor value '{cursor}'. Must be an integer.",
                )
            query = query.filter(AttestationRecord.id < cursor_id)

        # Fetch one extra record to determine hasNextPage.
        records: List[AttestationRecord] = (
            query.order_by(AttestationRecord.id.desc()).limit(limit + 1).all()
        )

        has_next_page = len(records) > limit
        page_records = records[:limit]

        end_cursor: Optional[str] = None
        if page_records:
            end_cursor = str(page_records[-1].id)

        return AttestationListResponse(
            items=[_attestation_to_schema(r) for r in page_records],
            page_info=AttestationPageInfo(
                end_cursor=end_cursor,
                has_next_page=has_next_page,
            ),
        )

    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to list attestation records: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve attestation records.",
        )


# =============================================================================
# Request/response schemas for new endpoints
# =============================================================================


_VALID_VISIBILITY = frozenset({"private", "team", "public"})


class AttestationCreateRequest(BaseModel):
    """Request body for manual attestation creation (TASK-7.5)."""

    artifact_id: str = Field(
        description="Artifact identifier in 'type:name' format.",
    )
    owner_scope: Optional[str] = Field(
        default=None,
        description=(
            "Owner scope override: 'user', 'team', or 'enterprise'. "
            "When omitted the caller's principal type is used."
        ),
    )
    roles: Optional[List[str]] = Field(
        default=None,
        description="RBAC roles to assert for this attestation.",
    )
    scopes: Optional[List[str]] = Field(
        default=None,
        description="Permission scopes covered by this attestation.",
    )
    visibility: str = Field(
        default="private",
        description="Visibility policy: 'private', 'team', or 'public'.",
    )
    notes: Optional[str] = Field(
        default=None,
        description="Free-text notes for offline / manual attestation workflows.",
    )

    model_config = ConfigDict(from_attributes=True)


class BomVerifyRequest(BaseModel):
    """Request body for BOM signature verification (TASK-7.7)."""

    snapshot_id: Optional[int] = Field(
        default=None,
        description=(
            "Primary key of the BomSnapshot to verify.  When omitted the "
            "most recent snapshot for the caller's owner scope is used."
        ),
    )
    signature: Optional[str] = Field(
        default=None,
        description=(
            "Hex-encoded Ed25519 signature to verify against.  When omitted "
            "the signature stored in the snapshot row is used."
        ),
    )

    model_config = ConfigDict(from_attributes=True)


class BomVerifyResponse(BaseModel):
    """Result of BOM signature verification."""

    valid: bool = Field(
        description="True when the signature is cryptographically valid."
    )
    details: str = Field(
        description="Human-readable verification outcome or error message."
    )
    key_id: Optional[str] = Field(
        default=None,
        description="SHA-256 fingerprint of the public key used to verify (when available).",
    )
    snapshot_id: Optional[int] = Field(
        default=None,
        description="ID of the snapshot that was verified.",
    )

    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# POST /attestations  (TASK-7.5)
# ---------------------------------------------------------------------------


_VALID_ATTESTATION_RESULTS = frozenset({"pass", "fail", "warning", "error"})


@router.post(
    "/attestations",
    status_code=status.HTTP_201_CREATED,
    tags=["attestations"],
    summary="Create a manual attestation record",
    description=(
        "Create a manual attestation record.  "
        "In **local** edition the body must supply ``artifact_id`` + optional "
        "``roles``/``scopes``/``visibility`` (RBAC schema).  "
        "In **enterprise** edition the body must supply ``snapshot_id`` + "
        "``result`` (one of ``pass``, ``fail``, ``warning``, ``error``) and "
        "optionally ``policy_id``, ``attested_at``, and ``evidence``.  "
        "The discriminator is the ``settings.edition`` value — no explicit "
        "``type`` field is required in the request body."
    ),
    responses={
        201: {"description": "Attestation created successfully"},
        400: {
            "description": "Invalid request body fields (bad result/owner_scope/visibility)"
        },
        404: {"description": "Referenced artifact or snapshot not found"},
    },
)
async def create_attestation(
    request: Union[AttestationCreateRequest, EnterpriseAttestationCreateRequest],
    db: DbSessionDep,
    settings: SettingsDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> Union[EnterpriseAttestationRecordResponse, AttestationSchema]:
    """Create a manual attestation record (dual-schema, edition-discriminated).

    **Local edition** (``settings.edition != 'enterprise'``):
        Accepts :class:`AttestationCreateRequest` (``artifact_id``, ``roles``,
        ``scopes``, ``visibility``).  Returns :class:`AttestationSchema`.

    **Enterprise edition** (``settings.edition == 'enterprise'``):
        Accepts :class:`EnterpriseAttestationCreateRequest` (``snapshot_id``,
        ``result``, optional ``policy_id`` / ``attested_at`` / ``evidence``).
        Delegates to ``EnterpriseBomRepository.create_attestation()`` and
        returns :class:`EnterpriseAttestationRecordResponse`.

    The request body is discriminated by edition at runtime — FastAPI will
    try to parse the body against whichever model is appropriate for the path
    that executes.  Because both models are listed in the ``Union`` signature,
    OpenAPI will document both shapes.
    """
    # ------------------------------------------------------------------
    # Enterprise edition path
    # ------------------------------------------------------------------
    if settings.edition == "enterprise":
        import uuid as _uuid
        from datetime import datetime, timezone

        # The incoming body must be an EnterpriseAttestationCreateRequest.
        # FastAPI passes it as a dict-like body; we reparse if necessary.
        if not isinstance(request, EnterpriseAttestationCreateRequest):
            # When FastAPI resolves Union[A, B] it picks the first matching
            # model — since AttestationCreateRequest also accepts unknown
            # extra fields the body may have been parsed as the local type.
            # Re-validate explicitly.
            try:
                request = EnterpriseAttestationCreateRequest.model_validate(
                    request.model_dump()
                )
            except Exception:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=(
                        "Enterprise edition requires 'snapshot_id' and 'result' fields "
                        "in the request body."
                    ),
                )

        # Validate result enum.
        if request.result not in _VALID_ATTESTATION_RESULTS:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Invalid result '{request.result}'. "
                    f"Must be one of: {sorted(_VALID_ATTESTATION_RESULTS)!r}."
                ),
            )

        # Parse snapshot_id UUID.
        try:
            snapshot_uuid = _uuid.UUID(request.snapshot_id)
        except (ValueError, AttributeError):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Invalid snapshot_id '{request.snapshot_id}'.  "
                    "Must be a valid UUID string."
                ),
            )

        # Parse optional policy_id.
        policy_uuid: Optional[_uuid.UUID] = None
        if request.policy_id is not None:
            try:
                policy_uuid = _uuid.UUID(request.policy_id)
            except (ValueError, AttributeError):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        f"Invalid policy_id '{request.policy_id}'.  "
                        "Must be a valid UUID string."
                    ),
                )

        # Parse optional attested_at.
        attested_at_dt: Optional[datetime] = None
        if request.attested_at is not None:
            try:
                attested_at_dt = datetime.fromisoformat(request.attested_at)
                if attested_at_dt.tzinfo is None:
                    attested_at_dt = attested_at_dt.replace(tzinfo=timezone.utc)
            except (ValueError, TypeError):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        f"Invalid attested_at '{request.attested_at}'.  "
                        "Must be an ISO-8601 datetime string."
                    ),
                )

        # Evidence: ensure it is a dict (JSONB may arrive as str in some PG configs).
        evidence: Dict[str, Any] = {}
        if request.evidence is not None:
            raw_ev = request.evidence
            if isinstance(raw_ev, str):
                try:
                    raw_ev = json.loads(raw_ev)
                except (json.JSONDecodeError, ValueError):
                    raw_ev = {}
            evidence = dict(raw_ev) if isinstance(raw_ev, dict) else {}

        try:
            repo = _get_enterprise_bom_repo(db)
            dto = repo.create_attestation(
                snapshot_id=snapshot_uuid,
                result=request.result,
                policy_id=policy_uuid,
                attested_at=attested_at_dt,
                evidence=evidence or None,
            )
        except ValueError as exc:
            # Raised by the repository when the snapshot does not exist or
            # belongs to a different tenant.
            logger.warning("Enterprise attestation creation rejected: %s", exc)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(exc),
            )
        except Exception as exc:
            logger.exception("Failed to create enterprise attestation record: %s", exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create enterprise attestation record.",
            )

        return EnterpriseAttestationRecordResponse(
            id=dto.id,
            tenant_id=dto.tenant_id,
            snapshot_id=dto.snapshot_id,
            policy_id=dto.policy_id,
            result=dto.result,
            attested_at=dto.attested_at,
            evidence=dto.evidence if isinstance(dto.evidence, dict) else {},
            created_at=dto.created_at,
        )

    # ------------------------------------------------------------------
    # Local edition path
    # ------------------------------------------------------------------

    # Validate owner_scope when provided.
    if (
        request.owner_scope is not None
        and request.owner_scope not in _VALID_OWNER_SCOPES
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Invalid owner_scope '{request.owner_scope}'. "
                f"Must be one of: {sorted(_VALID_OWNER_SCOPES)!r}."
            ),
        )

    # Validate visibility.
    if request.visibility not in _VALID_VISIBILITY:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Invalid visibility '{request.visibility}'. "
                f"Must be one of: {sorted(_VALID_VISIBILITY)!r}."
            ),
        )

    # Confirm the artifact exists.
    from skillmeat.cache.models import Artifact

    artifact_row = db.query(Artifact).filter(Artifact.id == request.artifact_id).first()
    if artifact_row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Artifact '{request.artifact_id}' not found.",
        )

    # Resolve owner identity from auth context.
    if request.owner_scope is not None:
        owner_type = request.owner_scope
    elif auth_context.tenant_id:
        owner_type = "enterprise"
    else:
        owner_type = "user"

    owner_id: str = str(auth_context.user_id) if auth_context.user_id else "local_admin"
    if auth_context.tenant_id:
        owner_id = str(auth_context.tenant_id)

    try:
        record = AttestationRecord(
            artifact_id=request.artifact_id,
            owner_type=owner_type,
            owner_id=owner_id,
            roles=request.roles or [],
            scopes=request.scopes or [],
            visibility=request.visibility,
        )
        db.add(record)
        db.commit()
        db.refresh(record)
    except Exception as exc:
        db.rollback()
        logger.exception("Failed to persist attestation record: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create attestation record.",
        )

    return _attestation_to_schema(record)


# ---------------------------------------------------------------------------
# GET /attestations/{attestation_id}  (TASK-7.6)
# ---------------------------------------------------------------------------


@router.get(
    "/attestations/{attestation_id}",
    response_model=AttestationSchema,
    tags=["attestations"],
    summary="Get a single attestation record",
    description=(
        "Retrieve full metadata for a single attestation record.  The record "
        "is returned only when it belongs to the authenticated caller's owner "
        "scope — cross-owner access is denied with a 404 to prevent information "
        "leakage."
    ),
    responses={
        200: {"description": "Attestation record retrieved successfully"},
        404: {"description": "Attestation record not found or not owned by caller"},
    },
)
async def get_attestation(
    attestation_id: str,
    db: DbSessionDep,
    settings: SettingsDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> AttestationSchema:
    """Retrieve a single attestation record by primary key.

    Owner-scope guard: the record is returned only when it belongs to the
    authenticated caller's owner scope.  A missing or mismatched record
    surfaces as a 404 to prevent enumeration.

    In local edition the ``attestation_id`` must be an integer string.
    In enterprise edition the ``attestation_id`` must be a UUID string.
    """
    # --- Enterprise edition path ---
    if settings.edition == "enterprise":
        import uuid as _uuid

        try:
            att_uuid = _uuid.UUID(attestation_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Invalid attestation_id '{attestation_id}'. "
                    "Enterprise attestation IDs are UUID strings."
                ),
            )
        try:
            repo = _get_enterprise_bom_repo(db)
            dto = repo.get_attestation(att_uuid)
        except Exception as exc:
            logger.exception(
                "Failed to query enterprise attestation id=%s: %s",
                attestation_id,
                exc,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve attestation record.",
            )
        if dto is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Attestation record '{attestation_id}' not found.",
            )
        return _enterprise_attestation_dto_to_schema(dto)

    # --- Local edition path ---
    try:
        att_id_int = int(attestation_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Invalid attestation_id '{attestation_id}'. "
                "Local attestation IDs are integers."
            ),
        )

    # Resolve caller's owner identity.
    caller_owner_type = "user"
    caller_owner_id = (
        str(auth_context.user_id) if auth_context.user_id else "local_admin"
    )
    if auth_context.tenant_id:
        caller_owner_type = "enterprise"
        caller_owner_id = str(auth_context.tenant_id)

    try:
        record: Optional[AttestationRecord] = (
            db.query(AttestationRecord)
            .filter(
                AttestationRecord.id == att_id_int,
                AttestationRecord.owner_type == caller_owner_type,
                AttestationRecord.owner_id == caller_owner_id,
            )
            .first()
        )
    except Exception as exc:
        logger.exception(
            "Failed to query attestation record id=%s: %s", attestation_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve attestation record.",
        )

    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Attestation record '{attestation_id}' not found.",
        )

    return _attestation_to_schema(record)


# ---------------------------------------------------------------------------
# POST /bom/verify  (TASK-7.7)
# ---------------------------------------------------------------------------


@router.post(
    "/bom/verify",
    response_model=BomVerifyResponse,
    tags=["bom"],
    summary="Verify BOM signature",
    description=(
        "Verify the Ed25519 signature stored on (or supplied for) a BOM snapshot. "
        "When ``snapshot_id`` is omitted the most recent snapshot for the caller's "
        "owner scope is used.  When ``signature`` is omitted the signature already "
        "stored in the snapshot row is used.  Returns 422 when the snapshot has no "
        "verifiable signature."
    ),
    responses={
        200: {"description": "Verification result (check ``valid`` field for outcome)"},
        404: {"description": "No BOM snapshot found for the caller's scope"},
        422: {"description": "Snapshot has no signature to verify"},
    },
)
async def verify_bom(
    request: BomVerifyRequest,
    db: DbSessionDep,
    settings: SettingsDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> BomVerifyResponse:
    """Verify the Ed25519 signature of a BOM snapshot.

    Steps:
    1. Resolve the target snapshot (by ``snapshot_id`` or latest for caller).
    2. Determine the signature to verify (from request or stored on snapshot).
    3. Call ``verify_signature()`` with the snapshot's ``bom_json`` as content.
    4. Return :class:`BomVerifyResponse` with the verification outcome.

    In enterprise edition this operation is not yet supported because
    ``EnterpriseBomSnapshot`` stores the BOM payload as a JSONB
    ``snapshot_data`` dict and does not have ``bom_json``, ``signature``,
    ``signature_algorithm``, or ``signing_key_id`` columns.  Signature
    verification for enterprise snapshots requires a dedicated migration and
    enterprise-native signing workflow.
    See enterprise-stub-promotion Phase 3 findings.
    """
    if settings.edition == "enterprise":
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Enterprise BoM signature verification pending future release.  "
                "EnterpriseBomSnapshot stores payload as JSONB snapshot_data without "
                "bom_json/signature columns.  A dedicated signing workflow is required. "
                "See enterprise-stub-promotion Phase 3 findings."
            ),
        )

    from skillmeat.core.bom.signing import verify_signature

    # Resolve owner_type for scope filtering when no explicit snapshot_id given.
    owner_type = "user"
    if auth_context.tenant_id:
        owner_type = "enterprise"

    # --- Fetch the target snapshot ---
    if request.snapshot_id is not None:
        snapshot: Optional[BomSnapshot] = (
            db.query(BomSnapshot).filter(BomSnapshot.id == request.snapshot_id).first()
        )
        if snapshot is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"BOM snapshot '{request.snapshot_id}' not found.",
            )
    else:
        snapshot = (
            db.query(BomSnapshot)
            .filter(BomSnapshot.owner_type == owner_type)
            .order_by(BomSnapshot.created_at.desc())
            .first()
        )
        if snapshot is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No BOM snapshot found for the caller's scope.",
            )

    # --- Resolve signature to verify ---
    signature_hex: Optional[str] = request.signature or snapshot.signature
    if not signature_hex:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=(
                "No signature available for verification.  "
                "Supply a 'signature' in the request body or generate a signed snapshot first."
            ),
        )

    try:
        signature_bytes = bytes.fromhex(signature_hex)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Signature is not valid hex-encoded data.",
        )

    # --- Run verification ---
    try:
        result = verify_signature(
            bom_content=snapshot.bom_json.encode(),
            signature=signature_bytes,
        )
    except Exception as exc:
        logger.exception("Unexpected error during BOM signature verification: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Verification failed with an unexpected error: {exc}",
        )

    if result.valid:
        details = "Signature is valid."
    else:
        details = result.error or "Signature verification failed."

    return BomVerifyResponse(
        valid=result.valid,
        details=details,
        key_id=result.key_id,
        snapshot_id=snapshot.id,
    )
