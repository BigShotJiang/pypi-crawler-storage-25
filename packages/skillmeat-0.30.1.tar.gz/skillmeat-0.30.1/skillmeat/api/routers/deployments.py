"""Deployment management API endpoints.

Provides REST API for deploying artifacts to projects and managing deployments.
"""

import base64
import logging
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ArtifactRepoDep,
    CollectionManagerOptDep,
    DeploymentRepoDep,
    SettingsDep,
    get_auth_context,
    require_auth,
    verify_api_key,
)
from skillmeat.api.routers.artifacts._helpers import resolve_enterprise_artifact_id
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.api.schemas.deployments import (
    DeploymentInfo,
    DeploymentListResponse,
    DeploymentResponse,
    DeployRequest,
    UndeployRequest,
    UndeployResponse,
)
from skillmeat.cache.deployment_stats_cache import get_deployment_stats_cache
from skillmeat.cache.models import get_session
from skillmeat.core.artifact import ArtifactType
from skillmeat.core.deployment import DeploymentManager
from skillmeat.core.version_tracking import create_deployment_version
from skillmeat.observability.timing import PerfTimer

logger = logging.getLogger(__name__)


def validate_dest_path(dest_path: Optional[str]) -> Optional[str]:
    """Validate and normalize custom destination path.

    Args:
        dest_path: Custom destination path relative to project root

    Returns:
        Normalized path string with trailing slash, or None if not provided

    Raises:
        ValueError: If path contains directory traversal or is absolute
    """
    if not dest_path:
        return None

    # Check for directory traversal
    if ".." in dest_path:
        raise ValueError("Directory traversal ('..') not allowed in dest_path")

    # Check for absolute path
    if dest_path.startswith("/"):
        raise ValueError("Absolute paths not allowed in dest_path")

    # Check for Windows-style absolute paths
    if len(dest_path) >= 2 and dest_path[1] == ":":
        raise ValueError("Absolute paths not allowed in dest_path")

    # Check for dangerous characters (null bytes, etc.)
    dangerous_chars = ["\x00", "\n", "\r"]
    for char in dangerous_chars:
        if char in dest_path:
            raise ValueError(f"Invalid character in dest_path")

    # Normalize: ensure trailing slash for directory path
    return dest_path.rstrip("/") + "/"


router = APIRouter(
    prefix="/deploy",
    tags=["deployments"],
    dependencies=[Depends(verify_api_key)],  # All endpoints require API key
)


def get_deployment_manager(
    collection_mgr: CollectionManagerOptDep,
) -> Optional[DeploymentManager]:
    """Get DeploymentManager dependency.

    Returns ``None`` in enterprise edition (no collection manager available).
    The router endpoints branch on ``settings.edition`` and only call this
    in the local path.

    Args:
        collection_mgr: Collection manager dependency.  ``None`` in enterprise
            edition (``get_collection_manager_optional`` returns None rather
            than raising 501 so that the router can choose the enterprise path).

    Returns:
        DeploymentManager instance, or None when collection_mgr is unavailable.
    """
    if collection_mgr is None:
        return None
    return DeploymentManager(collection_mgr=collection_mgr)


@router.post(
    "",
    response_model=DeploymentResponse,
    status_code=status.HTTP_200_OK,
    summary="Deploy artifact to project",
    description=(
        "Deploy an artifact from collection to a project's deployment profile root "
        "(for example: .claude, .codex, or .gemini)."
    ),
    responses={
        200: {"description": "Artifact deployed successfully"},
        400: {
            "model": ErrorResponse,
            "description": "Invalid request or artifact not found",
        },
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {
            "model": ErrorResponse,
            "description": "Artifact or collection not found",
        },
        500: {"model": ErrorResponse, "description": "Deployment failed"},
    },
)
async def deploy_artifact(
    request: DeployRequest,
    settings: SettingsDep,
    artifact_repo: ArtifactRepoDep,
    deployment_repo: DeploymentRepoDep,
    deployment_mgr: Optional[DeploymentManager] = Depends(get_deployment_manager),
    token: TokenDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> DeploymentResponse:
    """Deploy an artifact to a project.

    In local edition, copies an artifact from the collection to the selected
    deployment profile root via ``DeploymentManager``.

    In enterprise edition, delegates to ``IDeploymentRepository.deploy()``
    which records the deployment in the DB without filesystem access.

    Args:
        request: Deployment request with artifact and project details.
        settings: API settings for edition routing.
        deployment_repo: Deployment repository (DB-backed).
        deployment_mgr: Deployment manager (local edition only; None in enterprise).
        token: Authentication token.
        auth_context: Resolved authentication context.

    Returns:
        DeploymentResponse with deployment details.

    Raises:
        HTTPException: On validation or deployment failure.
    """
    try:
        logger.info(
            f"Deploying artifact: {request.artifact_id} "
            f"(project={request.project_path or 'CWD'}, dest_path={request.dest_path}, "
            f"version_id={request.version_id})"
        )

        # Validate version_id when provided — must reference a valid ArtifactVersion
        # belonging to the specified artifact.
        if request.version_id is not None:
            try:
                resolved_artifact_id = await resolve_enterprise_artifact_id(
                    request.artifact_id, settings, artifact_repo
                )
                vt_session = get_session()
                try:
                    from skillmeat.cache.models import (
                        ArtifactVersion as _ArtifactVersion,
                    )

                    version_row = (
                        vt_session.query(_ArtifactVersion)
                        .filter(
                            _ArtifactVersion.id == request.version_id,
                            _ArtifactVersion.artifact_id == resolved_artifact_id,
                        )
                        .first()
                    )
                    if version_row is None:
                        raise HTTPException(
                            status_code=status.HTTP_404_NOT_FOUND,
                            detail=(
                                f"Version '{request.version_id}' not found "
                                f"for artifact '{request.artifact_id}'"
                            ),
                        )
                finally:
                    vt_session.close()
            except HTTPException:
                raise
            except Exception as ve:
                logger.warning("version_id validation error (non-fatal): %s", ve)

        # Validate custom destination path
        try:
            validated_dest_path = validate_dest_path(request.dest_path)
        except ValueError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )

        if request.all_profiles and request.deployment_profile_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=("deployment_profile_id cannot be set when all_profiles=true"),
            )

        # Parse artifact type
        try:
            artifact_type = ArtifactType(request.artifact_type)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid artifact type: {request.artifact_type}",
            )

        # Resolve project path
        project_path = (
            Path(request.project_path) if request.project_path else Path.cwd()
        )
        project_path = project_path.resolve()

        # ------------------------------------------------------------------ #
        # Enterprise edition: delegate entirely to IDeploymentRepository      #
        # ------------------------------------------------------------------ #
        if settings.edition == "enterprise":
            logger.info(
                "deploy_artifact: enterprise path for artifact_id=%s project=%s",
                request.artifact_id,
                str(project_path),
            )
            try:
                project_id = base64.b64encode(str(project_path).encode()).decode()
                options: dict = {
                    "overwrite": request.overwrite,
                    "profile_id": request.deployment_profile_id,
                    "all_profiles": request.all_profiles,
                    "artifact_name": request.artifact_name,
                    "artifact_type": request.artifact_type,
                    "collection_name": request.collection_name,
                }
                if validated_dest_path:
                    options["dest_path"] = validated_dest_path

                dto = deployment_repo.deploy(
                    artifact_id=request.artifact_id,
                    project_id=project_id,
                    options=options,
                )
            except KeyError as exc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=str(exc),
                )
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=str(exc),
                )

            from datetime import datetime

            deployed_at_dt: Optional[datetime] = None
            if dto.deployed_at:
                try:
                    deployed_at_dt = datetime.fromisoformat(dto.deployed_at)
                except ValueError:
                    pass

            platform_val = None
            if dto.platform:
                try:
                    from skillmeat.core.enums import Platform as _Platform

                    platform_val = _Platform(dto.platform)
                except ValueError:
                    pass

            response = DeploymentResponse(
                success=True,
                message=f"Artifact '{dto.artifact_name}' deployed successfully",
                deployment_id=dto.id,
                stream_url=None,
                artifact_name=dto.artifact_name,
                artifact_type=dto.artifact_type,
                project_path=str(project_path),
                deployed_path=dto.target_path or "",
                deployed_at=deployed_at_dt,
                deployment_profile_id=dto.deployment_profile_id,
                deployed_profiles=[dto.deployment_profile_id or "claude_code"],
                platform=platform_val,
                profile_root_dir=None,
            )
            logger.info(
                "deploy_artifact (enterprise): success artifact=%s project=%s",
                dto.artifact_name,
                str(project_path),
            )
            get_deployment_stats_cache().invalidate_all()
            return response

        # ------------------------------------------------------------------ #
        # Local edition: filesystem-backed DeploymentManager path            #
        # ------------------------------------------------------------------ #
        if deployment_mgr is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Deployment manager not available",
            )

        # Deploy artifact (non-interactive mode for API)
        # We'll need to handle overwrite without prompting
        try:
            existing_deployments = [
                deployment
                for deployment in deployment_mgr.list_deployments(
                    project_path=project_path,
                    profile_id=request.deployment_profile_id,
                )
                if (
                    deployment.artifact_name == request.artifact_name
                    and deployment.artifact_type == request.artifact_type
                )
            ]

            if existing_deployments:
                if not request.overwrite:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=f"Artifact '{request.artifact_name}' already deployed. "
                        "Set overwrite=true to replace.",
                    )
                else:
                    for existing_deployment in existing_deployments:
                        logger.info(
                            "Removing existing deployment before overwrite "
                            "(profile=%s)",
                            existing_deployment.deployment_profile_id,
                        )
                        deployment_mgr.undeploy(
                            artifact_name=request.artifact_name,
                            artifact_type=artifact_type,
                            project_path=project_path,
                            profile_id=existing_deployment.deployment_profile_id,
                        )

            # Perform deployment — timed as the primary expensive operation
            with PerfTimer(
                "router.deploy_artifact.execute",
                artifact_name=request.artifact_name,
                artifact_type=request.artifact_type,
                project_path=str(project_path),
            ):
                deployments = deployment_mgr.deploy_artifacts(
                    artifact_names=[request.artifact_name],
                    collection_name=request.collection_name,
                    project_path=project_path,
                    artifact_type=artifact_type,
                    overwrite=request.overwrite,
                    dest_path=validated_dest_path,
                    profile_id=request.deployment_profile_id,
                    all_profiles=request.all_profiles,
                )

            if not deployments:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Artifact '{request.artifact_name}' not found in collection",
                )

            deployment = deployments[0]
            deployed_profiles = sorted(
                {
                    deployed.deployment_profile_id or "claude_code"
                    for deployed in deployments
                }
            )

            # Build response
            response = DeploymentResponse(
                success=True,
                message=f"Artifact '{request.artifact_name}' deployed successfully",
                deployment_id=f"{deployment.artifact_type}:{deployment.artifact_name}",
                stream_url=None,  # SSE streaming not yet implemented
                artifact_name=deployment.artifact_name,
                artifact_type=deployment.artifact_type,
                project_path=str(project_path),
                deployed_path=str(deployment.artifact_path),
                deployed_at=deployment.deployed_at,
                deployment_profile_id=deployment.deployment_profile_id,
                deployed_profiles=deployed_profiles,
                platform=deployment.platform,
                profile_root_dir=deployment.profile_root_dir,
            )

            logger.info(
                f"Deployment successful: {deployment.artifact_name} "
                f"({deployment.artifact_type}) to {project_path}"
            )

            # Update DB cache with deployment info (write-through pattern)
            with PerfTimer(
                "router.deploy_artifact.cache_write",
                artifact_name=request.artifact_name,
                project_path=str(project_path),
            ):
                if deployment_repo is not None:
                    for deployed in deployments:
                        artifact_id = (
                            f"{deployed.artifact_type}:{deployed.artifact_name}"
                        )
                        deployment_repo.sync_deployment_cache(
                            artifact_id=artifact_id,
                            project_path=str(project_path),
                            project_name=project_path.name,
                            deployed_at=deployed.deployed_at,
                            content_hash=deployed.content_hash,
                            deployment_profile_id=deployed.deployment_profile_id,
                            local_modifications=deployed.local_modifications,
                            platform=(
                                deployed.platform.value if deployed.platform else None
                            ),
                        )

            # Record version tracking for each deployed artifact (non-blocking)
            try:
                vt_session = get_session()
                try:
                    for deployed in deployments:
                        if deployed.content_hash:
                            artifact_id = (
                                f"{deployed.artifact_type}:{deployed.artifact_name}"
                            )
                            create_deployment_version(
                                session=vt_session,
                                artifact_id=artifact_id,
                                content_hash=deployed.content_hash,
                            )
                    vt_session.commit()

                    # VCS v2: record via VersionService so ProjectVersionDeployment is inserted
                    from skillmeat.core.version_service import VersionService

                    vs = VersionService(vt_session)
                    for deployed in deployments:
                        if deployed.content_hash:
                            artifact_id = (
                                f"{deployed.artifact_type}:{deployed.artifact_name}"
                            )
                            vs.record_mutation(
                                artifact_id=artifact_id,
                                change_origin="deployment",
                                content_hash=deployed.content_hash,
                                project_id=base64.b64encode(
                                    str(project_path).encode()
                                ).decode(),
                            )
                finally:
                    vt_session.close()
            except Exception as vt_err:
                logger.warning(
                    "Failed to record deployment version (non-blocking): %s",
                    vt_err,
                )

            # Invalidate deployment stats cache
            get_deployment_stats_cache().invalidate_all()

            return response

        except ValueError as e:
            # Artifact not found
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Deployment failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Deployment failed: {str(e)}",
        )


@router.post(
    "/undeploy",
    response_model=UndeployResponse,
    status_code=status.HTTP_200_OK,
    summary="Remove deployed artifact",
    description="Remove an artifact from a project's deployment profile root",
    responses={
        200: {"description": "Artifact removed successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not deployed"},
        500: {"model": ErrorResponse, "description": "Removal failed"},
    },
)
async def undeploy_artifact(
    request: UndeployRequest,
    settings: SettingsDep,
    deployment_repo: DeploymentRepoDep,
    deployment_mgr: Optional[DeploymentManager] = Depends(get_deployment_manager),
    token: TokenDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> UndeployResponse:
    """Remove a deployed artifact from a project.

    In local edition, removes the artifact via ``DeploymentManager`` (filesystem).
    In enterprise edition, removes via ``IDeploymentRepository.undeploy()``.

    Args:
        request: Undeploy request with artifact details.
        settings: API settings for edition routing.
        deployment_repo: Deployment repository (DB-backed).
        deployment_mgr: Deployment manager (local edition only; None in enterprise).
        token: Authentication token.
        auth_context: Resolved authentication context.

    Returns:
        UndeployResponse with removal confirmation.

    Raises:
        HTTPException: On validation or removal failure.
    """
    try:
        logger.info(
            f"Undeploying artifact: {request.artifact_name} "
            f"({request.artifact_type}, project={request.project_path or 'CWD'})"
        )

        # Parse artifact type
        try:
            artifact_type = ArtifactType(request.artifact_type)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid artifact type: {request.artifact_type}",
            )

        # Resolve project path
        project_path = (
            Path(request.project_path) if request.project_path else Path.cwd()
        )
        project_path = project_path.resolve()

        # ------------------------------------------------------------------ #
        # Enterprise edition: delegate to IDeploymentRepository.undeploy()   #
        # ------------------------------------------------------------------ #
        if settings.edition == "enterprise":
            logger.info(
                "undeploy_artifact: enterprise path for artifact=%s type=%s project=%s",
                request.artifact_name,
                request.artifact_type,
                str(project_path),
            )
            deployment_id = f"{request.artifact_type}:{request.artifact_name}"
            removed = deployment_repo.undeploy(id=deployment_id)
            if not removed:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=(
                        f"Artifact '{request.artifact_name}' "
                        f"({request.artifact_type}) is not deployed in this project"
                    ),
                )
            logger.info(
                "undeploy_artifact (enterprise): removed artifact=%s project=%s",
                request.artifact_name,
                str(project_path),
            )
            get_deployment_stats_cache().invalidate_all()
            return UndeployResponse(
                success=True,
                message=f"Artifact '{request.artifact_name}' removed successfully",
                artifact_name=request.artifact_name,
                artifact_type=request.artifact_type,
                project_path=str(project_path),
            )

        # ------------------------------------------------------------------ #
        # Local edition: filesystem-backed DeploymentManager path            #
        # ------------------------------------------------------------------ #
        if deployment_mgr is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Deployment manager not available",
            )

        # Undeploy artifact — timed as the expensive filesystem operation
        try:
            with PerfTimer(
                "router.undeploy_artifact.execute",
                artifact_name=request.artifact_name,
                artifact_type=request.artifact_type,
                project_path=str(project_path),
            ):
                deployment_mgr.undeploy(
                    artifact_name=request.artifact_name,
                    artifact_type=artifact_type,
                    project_path=project_path,
                    profile_id=request.profile_id,
                )

            # Write through to DB cache after successful undeploy
            with PerfTimer(
                "router.undeploy_artifact.cache_write",
                artifact_name=request.artifact_name,
                project_path=str(project_path),
            ):
                if deployment_repo is not None:
                    artifact_id = f"{request.artifact_type}:{request.artifact_name}"
                    deployment_repo.remove_deployment_cache(
                        artifact_id=artifact_id,
                        project_path=str(project_path),
                        profile_id=request.profile_id,
                    )

            response = UndeployResponse(
                success=True,
                message=f"Artifact '{request.artifact_name}' removed successfully",
                artifact_name=request.artifact_name,
                artifact_type=request.artifact_type,
                project_path=str(project_path),
            )

            logger.info(
                f"Undeploy successful: {request.artifact_name} "
                f"({request.artifact_type}) from {project_path}"
            )

            # Invalidate deployment stats cache
            get_deployment_stats_cache().invalidate_all()

            return response

        except ValueError as e:
            # Artifact not deployed
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )

    except HTTPException:
        # Re-raise HTTP exceptions
        raise

    except Exception as e:
        logger.error(f"Undeploy failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Undeploy failed: {str(e)}",
        )


@router.get(
    "",
    response_model=DeploymentListResponse,
    status_code=status.HTTP_200_OK,
    summary="List deployments",
    description="List all deployed artifacts in a project",
    responses={
        200: {"description": "Deployments retrieved successfully"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        500: {"model": ErrorResponse, "description": "Failed to retrieve deployments"},
    },
)
async def list_deployments(
    settings: SettingsDep,
    deployment_repo: DeploymentRepoDep,
    token: TokenDep = None,
    project_path: Optional[str] = Query(
        default=None,
        description="Path to project directory (uses CWD if not specified)",
    ),
    profile_id: Optional[str] = Query(
        default=None,
        description="Optional deployment profile ID filter",
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> DeploymentListResponse:
    """List all deployed artifacts in a project.

    In local edition, retrieves deployment metadata from the filesystem via
    DeploymentManager, including sync status computed against collection state.

    In enterprise edition, retrieves deployment records from the DB cache via
    DeploymentRepoDep.  Sync-status and profile_root_dir fields are not
    available in enterprise (no filesystem access) and default to ``"unknown"``
    and ``None`` respectively.

    Args:
        settings: API settings (edition routing).
        deployment_repo: DeploymentRepository dependency (DB-backed).
        token: Authentication token.
        project_path: Optional project path.
        profile_id: Optional deployment profile ID filter.
        auth_context: Resolved authentication context.

    Returns:
        DeploymentListResponse with list of deployments.

    Raises:
        HTTPException: On retrieval failure.
    """
    try:
        # Resolve project path
        resolved_path = Path(project_path) if project_path else Path.cwd()
        resolved_path = resolved_path.resolve()

        logger.info(f"Listing deployments for project: {resolved_path}")

        if settings.edition == "enterprise":
            # Enterprise path: serve entirely from DB cache — no filesystem access
            filters: dict = {"project_path": str(resolved_path)}
            if profile_id:
                filters["profile_id"] = profile_id

            with PerfTimer(
                "router.list_deployments.fetch",
                project_path=str(resolved_path),
                profile_id=profile_id,
            ):
                dto_deployments = deployment_repo.list(filters=filters)

            deployment_infos = []
            deployments_by_profile: dict = {}
            for dto in dto_deployments:
                info = DeploymentInfo(
                    artifact_name=dto.artifact_name,
                    artifact_type=dto.artifact_type,
                    from_collection=dto.from_collection,
                    deployed_at=dto.deployed_at,
                    artifact_path=dto.target_path or "",
                    project_path=str(resolved_path),
                    collection_sha=dto.collection_sha,
                    local_modifications=dto.local_modifications,
                    sync_status="unknown",
                    deployment_profile_id=dto.deployment_profile_id,
                    platform=dto.platform,
                    profile_root_dir=None,
                )
                deployment_infos.append(info)
                grouped_profile = dto.deployment_profile_id or "claude_code"
                deployments_by_profile.setdefault(grouped_profile, []).append(info)

            response = DeploymentListResponse(
                project_path=str(resolved_path),
                deployments=deployment_infos,
                deployments_by_profile=deployments_by_profile,
                total=len(deployment_infos),
            )
            logger.info(
                "Retrieved %d deployments (enterprise/DB path)", len(deployment_infos)
            )
            return response

        # Local edition path: use filesystem-backed DeploymentManager
        from skillmeat.api.dependencies import get_app_state
        from skillmeat.core.deployment import DeploymentManager as _DeploymentManager

        # Obtain the collection manager from app state directly — avoids
        # injecting CollectionManagerDep (which raises 501 in enterprise) into
        # the list endpoint signature where it is only needed in local mode.
        from skillmeat.api.dependencies import app_state as _app_state

        if _app_state.collection_manager is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Collection manager not available",
            )
        deployment_mgr = _DeploymentManager(
            collection_mgr=_app_state.collection_manager
        )

        # Get deployments — timed separately from status check to isolate costs
        with PerfTimer(
            "router.list_deployments.fetch",
            project_path=str(resolved_path),
            profile_id=profile_id,
        ):
            deployments = deployment_mgr.list_deployments(
                project_path=resolved_path,
                profile_id=profile_id,
            )

        # Compute sync status in a single pass, reusing the already-fetched
        # deployment list to avoid a redundant read_deployments() call.
        with PerfTimer(
            "router.list_deployments.check_status",
            project_path=str(resolved_path),
            deployment_count=len(deployments),
        ):
            status_map = deployment_mgr.compute_deployment_statuses_batch(
                project_path=resolved_path,
                profile_id=profile_id,
                deployments=deployments,
            )

        # Convert to response format
        deployment_infos = []
        deployments_by_profile = {}
        for deployment in deployments:
            key = f"{deployment.artifact_name}::{deployment.artifact_type}"
            profile_key = f"{key}::{deployment.deployment_profile_id or 'claude_code'}"
            sync_status = status_map.get(profile_key, status_map.get(key, "unknown"))

            info = DeploymentInfo(
                artifact_name=deployment.artifact_name,
                artifact_type=deployment.artifact_type,
                from_collection=deployment.from_collection,
                deployed_at=deployment.deployed_at,
                artifact_path=str(deployment.artifact_path),
                project_path=str(resolved_path),
                collection_sha=deployment.collection_sha,
                local_modifications=deployment.local_modifications,
                sync_status=sync_status,
                deployment_profile_id=deployment.deployment_profile_id,
                platform=deployment.platform,
                profile_root_dir=deployment.profile_root_dir,
            )
            deployment_infos.append(info)
            grouped_profile = deployment.deployment_profile_id or "claude_code"
            deployments_by_profile.setdefault(grouped_profile, []).append(info)

        response = DeploymentListResponse(
            project_path=str(resolved_path),
            deployments=deployment_infos,
            deployments_by_profile=deployments_by_profile,
            total=len(deployment_infos),
        )

        logger.info(f"Retrieved {len(deployment_infos)} deployments")
        return response

    except HTTPException:
        raise

    except Exception as e:
        logger.error(f"Failed to list deployments: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list deployments: {str(e)}",
        )
