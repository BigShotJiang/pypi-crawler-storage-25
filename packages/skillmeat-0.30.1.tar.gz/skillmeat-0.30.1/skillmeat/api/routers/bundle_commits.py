"""Bundle commit API endpoints (DVCS-2.5).

Provides REST endpoints for creating and querying atomic composite snapshots
(BundleCommit) and performing rollback operations.
"""

import logging
from typing import Annotated, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from skillmeat.api.dependencies import (
    DbSessionDep,
    require_auth,
)
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.cache.bundle_commit_repository import BundleCommitRepository
from skillmeat.cache.models import BundleCommit
from skillmeat.cache.repositories import ConstraintError, RepositoryError
from skillmeat.core.schemas.bundle_commit import (
    BundleCommitCreateRequest,
    BundleCommitHistoryResponse,
    BundleCommitMemberResponse,
    BundleCommitResponse,
    RollbackPreview,
)
from skillmeat.core.services.bundle_commit_service import (
    BundleCommitService,
    CompositeNotFoundError,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/bundle-commits",
    tags=["bundle-commits"],
)


# ---------------------------------------------------------------------------
# Helper: ORM → response schema
# ---------------------------------------------------------------------------


def _commit_to_response(commit: BundleCommit) -> BundleCommitResponse:
    """Convert a BundleCommit ORM instance to the API response schema.

    Args:
        commit: A :class:`~skillmeat.cache.models.BundleCommit` instance with
            ``members`` eagerly loaded.

    Returns:
        :class:`~skillmeat.core.schemas.bundle_commit.BundleCommitResponse`
        ready for serialization.
    """
    return BundleCommitResponse(
        id=commit.id,
        composite_artifact_id=commit.composite_artifact_id,
        composite_type=commit.composite_type,
        bundle_hash=commit.bundle_hash,
        parent_id=commit.parent_id,
        sequence_number=commit.sequence_number,
        change_origin=commit.change_origin,
        created_at=commit.created_at.isoformat() if commit.created_at else "",
        created_by=commit.created_by,
        message=commit.message,
        is_rollback=bool(commit.is_rollback),
        rolled_back_to=commit.rolled_back_to,
        members=[
            BundleCommitMemberResponse(
                artifact_id=m.artifact_id,
                artifact_uuid=m.artifact_uuid,
                artifact_version_id=m.artifact_version_id,
                content_hash=m.content_hash,
            )
            for m in (commit.members or [])
        ],
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "",
    response_model=BundleCommitResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a bundle commit",
    description=(
        "Create an atomic composite snapshot (BundleCommit). "
        "Returns the existing commit when the bundle_hash already exists for "
        "this composite (idempotent)."
    ),
)
async def create_bundle_commit(
    request: BundleCommitCreateRequest,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(require_auth()),
) -> BundleCommitResponse:
    """Create a new bundle commit (atomic composite snapshot).

    Args:
        request: Bundle commit creation payload.
        db_session: Injected SQLAlchemy session.
        auth_context: Authenticated request context.

    Returns:
        The newly created (or idempotently retrieved) BundleCommitResponse.

    Raises:
        HTTPException 400: When member_versions is empty or change_origin is
            invalid.
        HTTPException 404: When the composite artifact does not exist.
        HTTPException 409: On concurrent write constraint violations.
        HTTPException 500: On unexpected database errors.
    """
    svc = BundleCommitService(db_session)
    try:
        member_dicts = [
            {
                "artifact_id": m.artifact_id,
                "artifact_uuid": m.artifact_uuid,
                "artifact_version_id": m.artifact_version_id,
                "content_hash": m.content_hash,
            }
            for m in request.member_versions
        ]
        commit = svc.create(
            composite_artifact_id=request.composite_artifact_id,
            composite_type=request.composite_type,
            member_versions=member_dicts,
            change_origin=request.change_origin,
            message=request.message,
            created_by=request.created_by,
        )
        db_session.commit()
        return _commit_to_response(commit)
    except CompositeNotFoundError as exc:
        logger.warning("create_bundle_commit: composite not found — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc
    except ValueError as exc:
        logger.warning("create_bundle_commit: validation error — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    except ConstraintError as exc:
        logger.warning("create_bundle_commit: constraint violation — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    except RepositoryError as exc:
        logger.exception("create_bundle_commit: repository error — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create bundle commit.",
        ) from exc


@router.get(
    "/{commit_id}",
    response_model=BundleCommitResponse,
    summary="Get a bundle commit",
    description="Get a single bundle commit with its member list.",
)
async def get_bundle_commit(
    commit_id: str,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(require_auth()),
) -> BundleCommitResponse:
    """Get a single bundle commit with its members.

    Args:
        commit_id: UUID hex primary key of the commit.
        db_session: Injected SQLAlchemy session.
        auth_context: Authenticated request context.

    Returns:
        :class:`BundleCommitResponse` for the requested commit.

    Raises:
        HTTPException 404: When no commit with ``commit_id`` exists.
    """
    repo = BundleCommitRepository(db_session)
    commit = repo.get_by_id(commit_id)
    if commit is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"BundleCommit '{commit_id}' not found.",
        )
    return _commit_to_response(commit)


@router.get(
    "",
    response_model=BundleCommitHistoryResponse,
    summary="List bundle commits",
    description=(
        "Paginated list of bundle commits for a composite artifact. "
        "Results are ordered newest-first by sequence_number."
    ),
)
async def list_bundle_commits(
    composite_id: str = Query(
        ...,
        description="composite_artifact_id (FK to artifacts.uuid) to filter by.",
    ),
    limit: int = Query(50, ge=1, le=200, description="Maximum commits to return."),
    offset: int = Query(0, ge=0, description="Number of commits to skip."),
    db_session: DbSessionDep = ...,
    auth_context: AuthContext = Depends(require_auth()),
) -> BundleCommitHistoryResponse:
    """Get paginated commit history for a composite artifact.

    Uses ``?composite_id=<uuid>`` as a query parameter filter so this
    endpoint fits naturally under the ``/bundle-commits`` prefix without
    requiring a separate ``/composites/{id}/history`` router.

    Args:
        composite_id: ``composite_artifact_id`` to filter on (required).
        limit: Page size, 1-200.
        offset: Number of records to skip (cursor-style pagination).
        db_session: Injected SQLAlchemy session.
        auth_context: Authenticated request context.

    Returns:
        :class:`BundleCommitHistoryResponse` with paginated commits.
    """
    repo = BundleCommitRepository(db_session)
    commits = repo.get_history(composite_id, limit=limit, offset=offset)
    total = repo.count_history(composite_id)
    return BundleCommitHistoryResponse(
        commits=[_commit_to_response(c) for c in commits],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.post(
    "/{commit_id}/rollback/preview",
    response_model=RollbackPreview,
    summary="Preview a rollback (dry run)",
    description=(
        "Dry-run rollback analysis. Returns conflict details without making any "
        "changes to the database."
    ),
)
async def rollback_preview(
    commit_id: str,
    db_session: DbSessionDep,
    auth_context: AuthContext = Depends(require_auth()),
) -> RollbackPreview:
    """Preview a rollback to a prior bundle commit (no DB changes).

    Args:
        commit_id: Primary key of the BundleCommit to roll back *to*.
        db_session: Injected SQLAlchemy session.
        auth_context: Authenticated request context.

    Returns:
        :class:`RollbackPreview` with conflict analysis.  ``is_dry_run=True``,
        ``new_commit_id=None``.

    Raises:
        HTTPException 404: When ``commit_id`` does not exist.
        HTTPException 500: On unexpected errors.
    """
    svc = BundleCommitService(db_session)
    try:
        return svc.rollback(commit_id, dry_run=True)
    except ValueError as exc:
        logger.warning("rollback_preview: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc
    except RepositoryError as exc:
        logger.exception("rollback_preview: repository error — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to compute rollback preview.",
        ) from exc


@router.post(
    "/{commit_id}/rollback/execute",
    response_model=RollbackPreview,
    status_code=status.HTTP_201_CREATED,
    summary="Execute a rollback",
    description=(
        "Execute a rollback to a prior bundle commit. Creates a new forward "
        "commit with ``is_rollback=True`` that restores the target state."
    ),
)
async def rollback_execute(
    commit_id: str,
    db_session: DbSessionDep,
    message: Optional[str] = Query(
        None, description="Optional rollback commit message."
    ),
    auth_context: AuthContext = Depends(require_auth()),
) -> RollbackPreview:
    """Execute rollback — creates a new forward commit restoring the target state.

    Args:
        commit_id: Primary key of the BundleCommit to roll back *to*.
        db_session: Injected SQLAlchemy session.
        message: Optional human-readable description for the new rollback commit.
        auth_context: Authenticated request context.

    Returns:
        :class:`RollbackPreview` with ``is_dry_run=False`` and the
        ``new_commit_id`` of the newly created rollback commit.

    Raises:
        HTTPException 404: When ``commit_id`` does not exist.
        HTTPException 409: On concurrent write constraint violations.
        HTTPException 500: On unexpected errors.
    """
    svc = BundleCommitService(db_session)
    try:
        preview = svc.rollback(
            commit_id,
            dry_run=False,
            message=message,
            created_by=str(auth_context.user_id) if auth_context else None,
        )
        db_session.commit()
        return preview
    except ValueError as exc:
        logger.warning("rollback_execute: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc
    except ConstraintError as exc:
        logger.warning("rollback_execute: constraint violation — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    except RepositoryError as exc:
        logger.exception("rollback_execute: repository error — %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to execute rollback.",
        ) from exc
