"""Association and consolidation endpoints for the artifacts router — dual-mode (local + enterprise).

Contains:
  - get_consolidation_clusters     GET    /artifacts/consolidation/clusters
  - ignore_duplicate_pair          POST   /artifacts/consolidation/pairs/{pair_id}/ignore
  - unignore_duplicate_pair        DELETE /artifacts/consolidation/pairs/{pair_id}/ignore
  - merge_consolidation_cluster    POST   /artifacts/consolidation/clusters/{cluster_id}/merge
  - replace_consolidation_cluster  POST   /artifacts/consolidation/clusters/{cluster_id}/replace
  - get_artifact_associations      GET    /artifacts/{artifact_id}/associations

Route ordering is intentional: the fixed ``/consolidation/...`` paths are registered
BEFORE ``/{artifact_id}/associations`` so that FastAPI does not match the literal
string ``"consolidation"`` as an artifact_id path parameter.

Each endpoint branches on ``settings.edition == "enterprise"`` and delegates
to the appropriate handler.  The local handler is copied verbatim from
``_legacy.py`` so behaviour is identical.  The enterprise handler uses the
``*RepoDep`` DI aliases only — it never accesses filesystem managers directly.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from skillmeat.api.dependencies import (
    ArtifactManagerDep,
    ArtifactManagerOptDep,
    ArtifactRepoDep,
    DbSessionDep,
    DbUserCollectionRepoDep,
    DuplicatePairRepoDep,
    CollectionManagerDep,
    CollectionManagerOptDep,
    SettingsDep,
    get_auth_context,
    require_auth,
    require_local_edition,
    verify_api_key,
)
from skillmeat.api.middleware.auth import TokenDep
from skillmeat.api.schemas.artifacts import (
    ConsolidationActionRequest,
    ConsolidationActionResponse,
    ConsolidationClustersResponse,
    SimilarityClusterDTO,
)
from skillmeat.api.schemas.associations import AssociationItemDTO, AssociationsDTO
from skillmeat.api.schemas.auth import AuthContext
from skillmeat.api.schemas.common import ErrorResponse
from skillmeat.core.artifact import ArtifactType

from ._helpers import parse_artifact_id, _find_artifact_in_collections

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/artifacts",
    tags=["artifacts"],
    dependencies=[Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# Helper — auto-snapshot before destructive consolidation actions
# ---------------------------------------------------------------------------


def _create_auto_snapshot_for_consolidation(
    cluster_id: str,
    action: str,
) -> str:
    """Create an auto-snapshot before a destructive consolidation action.

    Args:
        cluster_id: Cluster identifier (used in snapshot message).
        action: Action name (``'merge'`` or ``'replace'``).

    Returns:
        Snapshot ID string.

    Raises:
        RuntimeError: If snapshot creation fails for any reason.
    """
    from skillmeat.core.version import VersionManager

    version_mgr = VersionManager()
    snapshot = version_mgr.auto_snapshot(
        message=f"Before consolidation {action}: cluster {cluster_id}",
    )
    return snapshot.id


# ---------------------------------------------------------------------------
# NOTE: Fixed-path consolidation routes are defined BEFORE /{artifact_id}/*
# to prevent FastAPI from matching "consolidation" as an artifact_id value.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# GET /consolidation/clusters  — list consolidation clusters
# ---------------------------------------------------------------------------


@router.get(
    "/consolidation/clusters",
    response_model=ConsolidationClustersResponse,
    summary="List consolidation clusters",
    description=(
        "Returns groups of similar artifacts identified for potential consolidation. "
        "Clusters are formed by union-find grouping of DuplicatePair records whose "
        "similarity_score meets the min_score threshold, then paginated via cursor."
    ),
    responses={
        200: {"description": "Successfully retrieved consolidation clusters"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_consolidation_clusters(
    db_session: DbSessionDep,
    settings: SettingsDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    min_score: float = Query(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Minimum similarity score threshold (0.0–1.0, default 0.5)",
    ),
    limit: int = Query(
        default=20,
        ge=1,
        le=100,
        description="Maximum number of clusters to return per page (1–100, default 20)",
    ),
    cursor: Optional[str] = Query(
        default=None,
        description="Opaque pagination cursor returned by a previous call",
    ),
) -> ConsolidationClustersResponse:
    """Return paginated consolidation clusters for deduplication review.

    Loads non-ignored DuplicatePair records that meet the min_score threshold,
    groups them using union-find clustering, and returns a sorted, paginated
    result.  Use ``next_cursor`` from the response to fetch subsequent pages.

    Args:
        db_session: Injected SQLAlchemy session.
        settings:   API settings (controls edition-based branching).
        token:      Authentication token (dependency injection).
        min_score:  Minimum pairwise similarity score (0.0–1.0, default 0.5).
        limit:      Page size (1–100, default 20).
        cursor:     Opaque cursor from a previous page, or ``None`` for the first page.

    Returns:
        ConsolidationClustersResponse with clusters and optional next_cursor.

    Raises:
        HTTPException 500: On unexpected errors.

    Example:
        GET /api/v1/artifacts/consolidation/clusters?min_score=0.7&limit=10
    """
    try:
        logger.info(
            "Getting consolidation clusters (min_score=%.2f, limit=%d, cursor=%r)",
            min_score,
            limit,
            cursor,
        )

        # -----------------------------------------------------------------------
        # Enterprise path
        # -----------------------------------------------------------------------
        if settings.edition == "enterprise":
            # Enterprise edition delegates to the same SimilarityService backed
            # by the injected db_session, which in enterprise mode connects to
            # the multi-tenant database rather than the local SQLite cache.
            from skillmeat.core.similarity import SimilarityService

            service = SimilarityService(session=db_session)
            result = service.get_consolidation_clusters(
                min_score=min_score,
                limit=limit,
                cursor=cursor,
            )

            clusters: List[SimilarityClusterDTO] = [
                SimilarityClusterDTO(
                    artifacts=cluster["artifacts"],
                    max_score=cluster["max_score"],
                    artifact_type=cluster["artifact_type"],
                    pair_count=cluster["pair_count"],
                )
                for cluster in result["clusters"]
            ]

            logger.info(
                "Consolidation clusters (enterprise): returned %d cluster(s), next_cursor=%r",
                len(clusters),
                result["next_cursor"],
            )

            return ConsolidationClustersResponse(
                clusters=clusters,
                next_cursor=result["next_cursor"],
            )

        # -----------------------------------------------------------------------
        # Local path (copied verbatim from _legacy.py)
        # -----------------------------------------------------------------------
        from skillmeat.core.similarity import SimilarityService

        service = SimilarityService(session=db_session)
        result = service.get_consolidation_clusters(
            min_score=min_score,
            limit=limit,
            cursor=cursor,
        )

        clusters = [
            SimilarityClusterDTO(
                artifacts=cluster["artifacts"],
                max_score=cluster["max_score"],
                artifact_type=cluster["artifact_type"],
                pair_count=cluster["pair_count"],
            )
            for cluster in result["clusters"]
        ]

        logger.info(
            "Consolidation clusters: returned %d cluster(s), next_cursor=%r",
            len(clusters),
            result["next_cursor"],
        )

        return ConsolidationClustersResponse(
            clusters=clusters,
            next_cursor=result["next_cursor"],
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to get consolidation clusters: %s",
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get consolidation clusters: {str(e)}",
        )


# ---------------------------------------------------------------------------
# POST /consolidation/pairs/{pair_id}/ignore  — ignore a duplicate pair
# ---------------------------------------------------------------------------


@router.post(
    "/consolidation/pairs/{pair_id}/ignore",
    summary="Ignore a duplicate pair",
    description=(
        "Marks the specified DuplicatePair as ignored so it is excluded from "
        "consolidation cluster results.  Idempotent: calling this on an already-"
        "ignored pair still returns 200."
    ),
    responses={
        200: {"description": "Pair successfully marked as ignored"},
        404: {"model": ErrorResponse, "description": "Pair not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    status_code=status.HTTP_200_OK,
)
async def ignore_duplicate_pair(
    pair_id: str,
    pair_repo: DuplicatePairRepoDep,
    settings: SettingsDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> dict:
    """Mark a DuplicatePair as ignored (consolidation skip action).

    Args:
        pair_id:   Primary key (UUID hex string) of the DuplicatePair record.
        pair_repo: DuplicatePair repository.
        settings:  API settings (controls edition-based branching).
        token:     Authentication token (dependency injection).

    Returns:
        JSON object ``{"pair_id": "<id>", "ignored": true}``.

    Raises:
        HTTPException 404: If no pair with ``pair_id`` exists.
        HTTPException 500: On unexpected database errors.

    Example:
        POST /api/v1/artifacts/consolidation/pairs/abc123/ignore
    """
    try:
        logger.info("Marking duplicate pair %r as ignored", pair_id)

        # -----------------------------------------------------------------------
        # Enterprise path — same repository interface, routes to enterprise DB
        # -----------------------------------------------------------------------
        if settings.edition == "enterprise":
            found = pair_repo.mark_pair_ignored(pair_id)

            if not found:
                logger.info("Duplicate pair not found (enterprise): %r", pair_id)
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Duplicate pair '{pair_id}' not found",
                )

            logger.info("Duplicate pair %r marked as ignored (enterprise)", pair_id)
            return {"pair_id": pair_id, "ignored": True}

        # -----------------------------------------------------------------------
        # Local path (copied verbatim from _legacy.py)
        # -----------------------------------------------------------------------
        found = pair_repo.mark_pair_ignored(pair_id)

        if not found:
            logger.info("Duplicate pair not found: %r", pair_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Duplicate pair '{pair_id}' not found",
            )

        logger.info("Duplicate pair %r marked as ignored", pair_id)
        return {"pair_id": pair_id, "ignored": True}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to ignore duplicate pair '%s': %s",
            pair_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to ignore duplicate pair: {str(e)}",
        )


# ---------------------------------------------------------------------------
# DELETE /consolidation/pairs/{pair_id}/ignore  — unignore a duplicate pair
# ---------------------------------------------------------------------------


@router.delete(
    "/consolidation/pairs/{pair_id}/ignore",
    summary="Unignore a duplicate pair",
    description=(
        "Clears the ignored flag on the specified DuplicatePair, making it "
        "visible again in consolidation cluster results.  Idempotent: calling "
        "this on a pair that is already active still returns 200."
    ),
    responses={
        200: {"description": "Pair ignore flag successfully cleared"},
        404: {"model": ErrorResponse, "description": "Pair not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    status_code=status.HTTP_200_OK,
)
async def unignore_duplicate_pair(
    pair_id: str,
    pair_repo: DuplicatePairRepoDep,
    settings: SettingsDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> dict:
    """Clear the ignored flag on a DuplicatePair (undo consolidation skip).

    Args:
        pair_id:   Primary key (UUID hex string) of the DuplicatePair record.
        pair_repo: DuplicatePair repository.
        settings:  API settings (controls edition-based branching).
        token:     Authentication token (dependency injection).

    Returns:
        JSON object ``{"pair_id": "<id>", "ignored": false}``.

    Raises:
        HTTPException 404: If no pair with ``pair_id`` exists.
        HTTPException 500: On unexpected database errors.

    Example:
        DELETE /api/v1/artifacts/consolidation/pairs/abc123/ignore
    """
    try:
        logger.info("Clearing ignored flag on duplicate pair %r", pair_id)

        # -----------------------------------------------------------------------
        # Enterprise path — same repository interface, routes to enterprise DB
        # -----------------------------------------------------------------------
        if settings.edition == "enterprise":
            found = pair_repo.unmark_pair_ignored(pair_id)

            if not found:
                logger.info("Duplicate pair not found (enterprise): %r", pair_id)
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Duplicate pair '{pair_id}' not found",
                )

            logger.info("Duplicate pair %r ignore flag cleared (enterprise)", pair_id)
            return {"pair_id": pair_id, "ignored": False}

        # -----------------------------------------------------------------------
        # Local path (copied verbatim from _legacy.py)
        # -----------------------------------------------------------------------
        found = pair_repo.unmark_pair_ignored(pair_id)

        if not found:
            logger.info("Duplicate pair not found: %r", pair_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Duplicate pair '{pair_id}' not found",
            )

        logger.info("Duplicate pair %r ignore flag cleared", pair_id)
        return {"pair_id": pair_id, "ignored": False}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to unignore duplicate pair '%s': %s",
            pair_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to unignore duplicate pair: {str(e)}",
        )


# ---------------------------------------------------------------------------
# POST /consolidation/clusters/{cluster_id}/merge  — merge cluster into primary
# ---------------------------------------------------------------------------


@router.post(
    "/consolidation/clusters/{cluster_id}/merge",
    response_model=ConsolidationActionResponse,
    summary="Merge consolidation cluster (secondary into primary)",
    description=(
        "Merges all secondary artifacts in the cluster into the primary artifact, "
        "then removes the secondaries from the collection.  An auto-snapshot is "
        "always created before any data is modified.  If the snapshot step fails "
        "the action is aborted and a 500 is returned — the collection is never "
        "modified without a confirmed snapshot."
    ),
    responses={
        200: {"description": "Merge completed successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters"},
        404: {
            "model": ErrorResponse,
            "description": "Cluster or primary artifact not found",
        },
        500: {
            "model": ErrorResponse,
            "description": "Snapshot failed or internal error",
        },
    },
    status_code=status.HTTP_200_OK,
)
async def merge_consolidation_cluster(
    cluster_id: str,
    request: ConsolidationActionRequest,
    artifact_mgr: ArtifactManagerOptDep,
    artifact_repo: ArtifactRepoDep,
    db_session: DbSessionDep,
    pair_repo: DuplicatePairRepoDep,
    settings: SettingsDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> ConsolidationActionResponse:
    """Merge secondary artifacts into the primary for a consolidation cluster.

    The endpoint:
    1. Creates an auto-snapshot (aborts with HTTP 500 if this fails).
    2. Resolves the cluster members from ``DuplicatePair`` records.
    3. Removes each secondary artifact from the collection.
    4. Marks all pairs in the cluster as resolved (ignored).

    Args:
        cluster_id:   Opaque cluster identifier (used in snapshot message).
        request:      Request body with ``primary_artifact_uuid`` and optional
                      ``collection_name``.
        artifact_mgr: Injected ArtifactManager.
        artifact_repo: Artifact repository for UUID resolution.
        db_session:   Injected SQLAlchemy session.
        pair_repo:    DuplicatePair repository.
        settings:     API settings (controls edition-based branching).
        token:        Authentication token (dependency injection).

    Returns:
        ConsolidationActionResponse describing what was done.

    Raises:
        HTTPException 500: If the auto-snapshot fails (action is aborted).
        HTTPException 404: If the primary artifact UUID is not found.
        HTTPException 500: On unexpected errors during the merge.

    Example:
        POST /api/v1/artifacts/consolidation/clusters/abc123/merge
        {"primary_artifact_uuid": "deadbeef...", "collection_name": null}
    """
    # --- Step 1: Auto-snapshot (mandatory gate — identical for all editions) ---
    try:
        snapshot_id = _create_auto_snapshot_for_consolidation(cluster_id, "merge")
        logger.info(
            "Auto-snapshot created before merge of cluster %r: snapshot_id=%r",
            cluster_id,
            snapshot_id,
        )
    except Exception as snap_err:
        logger.error(
            "Snapshot failed before merge of cluster %r: %s",
            cluster_id,
            snap_err,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Snapshot failed — action aborted",
        )

    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            primary_uuid = request.primary_artifact_uuid

            primary_dto = artifact_repo.get_by_uuid(primary_uuid)
            if primary_dto is None:
                logger.warning(
                    "Merge cluster %r (enterprise): primary artifact UUID %r not found",
                    cluster_id,
                    primary_uuid,
                )
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Primary artifact '{primary_uuid}' not found",
                )

            pairs = pair_repo.list_pairs_for_artifact(primary_uuid)

            secondary_uuids: List[str] = []
            for pair in pairs:
                other = (
                    pair.artifact2_uuid
                    if pair.artifact1_uuid == primary_uuid
                    else pair.artifact1_uuid
                )
                if other not in secondary_uuids:
                    secondary_uuids.append(other)

            pair_ids = [pair.id for pair in pairs]

            logger.info(
                "Merge cluster %r (enterprise): primary=%r, secondaries=%r",
                cluster_id,
                primary_uuid,
                secondary_uuids,
            )

            removed_uuids: List[str] = []
            for sec_uuid in secondary_uuids:
                sec_dto = artifact_repo.get_by_uuid(sec_uuid)
                if sec_dto is None:
                    logger.warning(
                        "Merge cluster %r (enterprise): secondary UUID %r not found, skipping",
                        cluster_id,
                        sec_uuid,
                    )
                    continue

                try:
                    artifact_repo.delete(sec_dto.id)
                    removed_uuids.append(sec_uuid)
                    logger.info(
                        "Merge cluster %r (enterprise): removed secondary %r (%r)",
                        cluster_id,
                        sec_dto.name,
                        sec_uuid,
                    )
                except Exception as rm_err:
                    logger.warning(
                        "Merge cluster %r (enterprise): could not remove secondary %r: %s",
                        cluster_id,
                        sec_uuid,
                        rm_err,
                    )

            pairs_resolved = 0
            for pid in pair_ids:
                if pair_repo.mark_pair_ignored(pid):
                    pairs_resolved += 1

            logger.info(
                "Merge cluster %r (enterprise) completed: removed=%d, pairs_resolved=%d",
                cluster_id,
                len(removed_uuids),
                pairs_resolved,
            )

            return ConsolidationActionResponse(
                action="merge",
                cluster_id=cluster_id,
                primary_artifact_uuid=primary_uuid,
                removed_artifact_uuids=removed_uuids,
                pairs_resolved=pairs_resolved,
                snapshot_id=snapshot_id,
            )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(
                "Merge cluster %r (enterprise) failed: %s",
                cluster_id,
                e,
                exc_info=True,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to merge consolidation cluster: {str(e)}",
            )

    # -----------------------------------------------------------------------
    # Local path (copied verbatim from _legacy.py)
    # -----------------------------------------------------------------------
    assert artifact_mgr is not None, "artifact_mgr required for local edition"
    try:
        primary_uuid = request.primary_artifact_uuid

        # Validate primary artifact exists via repository
        primary_dto = artifact_repo.get_by_uuid(primary_uuid)
        if primary_dto is None:
            logger.warning(
                "Merge cluster %r: primary artifact UUID %r not found",
                cluster_id,
                primary_uuid,
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Primary artifact '{primary_uuid}' not found",
            )

        # Collect all UUIDs in the cluster via DuplicatePair records via repository
        pairs = pair_repo.list_pairs_for_artifact(primary_uuid)

        secondary_uuids = []
        for pair in pairs:
            other = (
                pair.artifact2_uuid
                if pair.artifact1_uuid == primary_uuid
                else pair.artifact1_uuid
            )
            if other not in secondary_uuids:
                secondary_uuids.append(other)

        pair_ids = [pair.id for pair in pairs]

        logger.info(
            "Merge cluster %r: primary=%r, secondaries=%r",
            cluster_id,
            primary_uuid,
            secondary_uuids,
        )

        # --- Step 3: Remove each secondary artifact from the collection ---
        removed_uuids = []
        for sec_uuid in secondary_uuids:
            sec_dto = artifact_repo.get_by_uuid(sec_uuid)
            if sec_dto is None:
                logger.warning(
                    "Merge cluster %r: secondary artifact UUID %r not found, skipping",
                    cluster_id,
                    sec_uuid,
                )
                continue

            try:
                from skillmeat.core.enums import ArtifactType as CoreArtifactType

                art_type = CoreArtifactType(sec_dto.artifact_type)
                artifact_mgr.remove(
                    artifact_name=sec_dto.name,
                    artifact_type=art_type,
                    collection_name=request.collection_name,
                )
                removed_uuids.append(sec_uuid)
                logger.info(
                    "Merge cluster %r: removed secondary artifact %r (%r)",
                    cluster_id,
                    sec_dto.name,
                    sec_uuid,
                )
            except Exception as rm_err:
                logger.warning(
                    "Merge cluster %r: could not remove secondary %r: %s",
                    cluster_id,
                    sec_uuid,
                    rm_err,
                )

        # --- Step 4: Mark pairs as resolved (ignored) ---
        pairs_resolved = 0
        for pid in pair_ids:
            if pair_repo.mark_pair_ignored(pid):
                pairs_resolved += 1

        logger.info(
            "Merge cluster %r completed: removed=%d, pairs_resolved=%d",
            cluster_id,
            len(removed_uuids),
            pairs_resolved,
        )

        return ConsolidationActionResponse(
            action="merge",
            cluster_id=cluster_id,
            primary_artifact_uuid=primary_uuid,
            removed_artifact_uuids=removed_uuids,
            pairs_resolved=pairs_resolved,
            snapshot_id=snapshot_id,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Merge cluster %r failed: %s",
            cluster_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to merge consolidation cluster: {str(e)}",
        )


# ---------------------------------------------------------------------------
# POST /consolidation/clusters/{cluster_id}/replace  — keep primary, discard secondaries
# ---------------------------------------------------------------------------


@router.post(
    "/consolidation/clusters/{cluster_id}/replace",
    response_model=ConsolidationActionResponse,
    summary="Replace consolidation cluster (keep primary, discard secondaries)",
    description=(
        "Keeps the primary artifact unchanged and discards all secondary artifacts "
        "in the cluster.  An auto-snapshot is always created before any data is "
        "modified.  If the snapshot step fails the action is aborted and a 500 is "
        "returned — the collection is never modified without a confirmed snapshot."
    ),
    responses={
        200: {"description": "Replace completed successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters"},
        404: {
            "model": ErrorResponse,
            "description": "Cluster or primary artifact not found",
        },
        500: {
            "model": ErrorResponse,
            "description": "Snapshot failed or internal error",
        },
    },
    status_code=status.HTTP_200_OK,
)
async def replace_consolidation_cluster(
    cluster_id: str,
    request: ConsolidationActionRequest,
    artifact_mgr: ArtifactManagerOptDep,
    artifact_repo: ArtifactRepoDep,
    db_session: DbSessionDep,
    pair_repo: DuplicatePairRepoDep,
    settings: SettingsDep,
    token: TokenDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["artifact:write"])),
) -> ConsolidationActionResponse:
    """Keep the primary artifact and discard all secondaries in the cluster.

    Unlike merge, no content from the secondaries is incorporated — the primary
    is kept exactly as-is while the secondaries are deleted from the collection.

    The endpoint:
    1. Creates an auto-snapshot (aborts with HTTP 500 if this fails).
    2. Resolves the cluster members from ``DuplicatePair`` records.
    3. Removes each secondary artifact from the collection.
    4. Marks all pairs in the cluster as resolved (ignored).

    Args:
        cluster_id:   Opaque cluster identifier (used in snapshot message).
        request:      Request body with ``primary_artifact_uuid`` and optional
                      ``collection_name``.
        artifact_mgr: Injected ArtifactManager.
        artifact_repo: Artifact repository for UUID resolution.
        db_session:   Injected SQLAlchemy session (unused in local path but
                      injected for signature parity with enterprise path).
        pair_repo:    DuplicatePair repository.
        settings:     API settings (controls edition-based branching).
        token:        Authentication token (dependency injection).

    Returns:
        ConsolidationActionResponse describing what was done.

    Raises:
        HTTPException 500: If the auto-snapshot fails (action is aborted).
        HTTPException 404: If the primary artifact UUID is not found.
        HTTPException 500: On unexpected errors during the replace.

    Example:
        POST /api/v1/artifacts/consolidation/clusters/abc123/replace
        {"primary_artifact_uuid": "deadbeef...", "collection_name": null}
    """
    # --- Step 1: Auto-snapshot (mandatory gate — identical for all editions) ---
    try:
        snapshot_id = _create_auto_snapshot_for_consolidation(cluster_id, "replace")
        logger.info(
            "Auto-snapshot created before replace of cluster %r: snapshot_id=%r",
            cluster_id,
            snapshot_id,
        )
    except Exception as snap_err:
        logger.error(
            "Snapshot failed before replace of cluster %r: %s",
            cluster_id,
            snap_err,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Snapshot failed — action aborted",
        )

    # -----------------------------------------------------------------------
    # Enterprise path
    # -----------------------------------------------------------------------
    if settings.edition == "enterprise":
        try:
            primary_uuid = request.primary_artifact_uuid

            primary_dto = artifact_repo.get_by_uuid(primary_uuid)
            if primary_dto is None:
                logger.warning(
                    "Replace cluster %r (enterprise): primary artifact UUID %r not found",
                    cluster_id,
                    primary_uuid,
                )
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Primary artifact '{primary_uuid}' not found",
                )

            pairs = pair_repo.list_pairs_for_artifact(primary_uuid)

            secondary_uuids: List[str] = []
            for pair in pairs:
                other = (
                    pair.artifact2_uuid
                    if pair.artifact1_uuid == primary_uuid
                    else pair.artifact1_uuid
                )
                if other not in secondary_uuids:
                    secondary_uuids.append(other)

            pair_ids = [pair.id for pair in pairs]

            logger.info(
                "Replace cluster %r (enterprise): primary=%r, secondaries=%r",
                cluster_id,
                primary_uuid,
                secondary_uuids,
            )

            removed_uuids: List[str] = []
            for sec_uuid in secondary_uuids:
                sec_dto = artifact_repo.get_by_uuid(sec_uuid)
                if sec_dto is None:
                    logger.warning(
                        "Replace cluster %r (enterprise): secondary UUID %r not found, skipping",
                        cluster_id,
                        sec_uuid,
                    )
                    continue

                try:
                    artifact_repo.delete(sec_dto.id)
                    removed_uuids.append(sec_uuid)
                    logger.info(
                        "Replace cluster %r (enterprise): removed secondary %r (%r)",
                        cluster_id,
                        sec_dto.name,
                        sec_uuid,
                    )
                except Exception as rm_err:
                    logger.warning(
                        "Replace cluster %r (enterprise): could not remove secondary %r: %s",
                        cluster_id,
                        sec_uuid,
                        rm_err,
                    )

            pairs_resolved = 0
            for pid in pair_ids:
                if pair_repo.mark_pair_ignored(pid):
                    pairs_resolved += 1

            logger.info(
                "Replace cluster %r (enterprise) completed: removed=%d, pairs_resolved=%d",
                cluster_id,
                len(removed_uuids),
                pairs_resolved,
            )

            return ConsolidationActionResponse(
                action="replace",
                cluster_id=cluster_id,
                primary_artifact_uuid=primary_uuid,
                removed_artifact_uuids=removed_uuids,
                pairs_resolved=pairs_resolved,
                snapshot_id=snapshot_id,
            )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(
                "Replace cluster %r (enterprise) failed: %s",
                cluster_id,
                e,
                exc_info=True,
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to replace consolidation cluster: {str(e)}",
            )

    # -----------------------------------------------------------------------
    # Local path (copied verbatim from _legacy.py)
    # -----------------------------------------------------------------------
    assert artifact_mgr is not None, "artifact_mgr required for local edition"
    try:
        primary_uuid = request.primary_artifact_uuid

        # Validate primary artifact exists via repository
        primary_dto = artifact_repo.get_by_uuid(primary_uuid)
        if primary_dto is None:
            logger.warning(
                "Replace cluster %r: primary artifact UUID %r not found",
                cluster_id,
                primary_uuid,
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Primary artifact '{primary_uuid}' not found",
            )

        # Collect all UUIDs in the cluster via DuplicatePair records via repository
        pairs = pair_repo.list_pairs_for_artifact(primary_uuid)

        secondary_uuids = []
        for pair in pairs:
            other = (
                pair.artifact2_uuid
                if pair.artifact1_uuid == primary_uuid
                else pair.artifact1_uuid
            )
            if other not in secondary_uuids:
                secondary_uuids.append(other)

        pair_ids = [pair.id for pair in pairs]

        logger.info(
            "Replace cluster %r: primary=%r, secondaries=%r",
            cluster_id,
            primary_uuid,
            secondary_uuids,
        )

        # --- Step 3: Remove each secondary artifact from the collection ---
        removed_uuids = []
        for sec_uuid in secondary_uuids:
            sec_dto = artifact_repo.get_by_uuid(sec_uuid)
            if sec_dto is None:
                logger.warning(
                    "Replace cluster %r: secondary artifact UUID %r not found, skipping",
                    cluster_id,
                    sec_uuid,
                )
                continue

            try:
                from skillmeat.core.enums import ArtifactType as CoreArtifactType

                art_type = CoreArtifactType(sec_dto.artifact_type)
                artifact_mgr.remove(
                    artifact_name=sec_dto.name,
                    artifact_type=art_type,
                    collection_name=request.collection_name,
                )
                removed_uuids.append(sec_uuid)
                logger.info(
                    "Replace cluster %r: removed secondary artifact %r (%r)",
                    cluster_id,
                    sec_dto.name,
                    sec_uuid,
                )
            except Exception as rm_err:
                logger.warning(
                    "Replace cluster %r: could not remove secondary %r: %s",
                    cluster_id,
                    sec_uuid,
                    rm_err,
                )

        # --- Step 4: Mark pairs as resolved (ignored) ---
        pairs_resolved = 0
        for pid in pair_ids:
            if pair_repo.mark_pair_ignored(pid):
                pairs_resolved += 1

        logger.info(
            "Replace cluster %r completed: removed=%d, pairs_resolved=%d",
            cluster_id,
            len(removed_uuids),
            pairs_resolved,
        )

        return ConsolidationActionResponse(
            action="replace",
            cluster_id=cluster_id,
            primary_artifact_uuid=primary_uuid,
            removed_artifact_uuids=removed_uuids,
            pairs_resolved=pairs_resolved,
            snapshot_id=snapshot_id,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Replace cluster %r failed: %s",
            cluster_id,
            e,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to replace consolidation cluster: {str(e)}",
        )


# ---------------------------------------------------------------------------
# GET /{artifact_id}/associations  — composite-membership associations
# (registered AFTER all /consolidation/* routes — see note at top of file)
# ---------------------------------------------------------------------------


@router.get(
    "/{artifact_id}/associations",
    response_model=AssociationsDTO,
    summary="Get artifact associations",
    description=(
        "Return the composite-artifact associations for a given artifact. "
        "``parents`` lists composites that contain this artifact as a child; "
        "``children`` lists the child artifacts when this artifact is itself a composite."
    ),
    responses={
        200: {"description": "Successfully retrieved associations"},
        400: {"model": ErrorResponse, "description": "Invalid artifact ID format"},
        401: {"model": ErrorResponse, "description": "Unauthorized"},
        404: {"model": ErrorResponse, "description": "Artifact not found"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
)
async def get_artifact_associations(
    artifact_id: str,
    artifact_repo: ArtifactRepoDep,
    collection_mgr: CollectionManagerOptDep,
    db_user_coll_repo: DbUserCollectionRepoDep,
    settings: SettingsDep,
    _token: TokenDep,
    auth_context: AuthContext = Depends(get_auth_context),
    include_parents: bool = Query(
        default=True,
        description="Include composites that contain this artifact as a child",
    ),
    include_children: bool = Query(
        default=True,
        description="Include child artifacts of this composite",
    ),
    relationship_type: Optional[str] = Query(
        default=None,
        description="Filter by relationship type (e.g. 'contains')",
    ),
    collection: Optional[str] = Query(
        default=None,
        description="Collection name or UUID (uses active collection if omitted)",
    ),
) -> AssociationsDTO:
    """Return composite-membership associations for an artifact.

    Queries the ``composite_memberships`` cache table to return:

    - ``parents``: Composite artifacts (plugins, stacks, suites) that list
      this artifact as a member.
    - ``children``: Artifacts that belong to this composite (only populated
      when ``artifact_id`` itself is a composite).

    Both lists may be empty — an empty response is **not** a 404.  A 404 is
    only returned when the ``artifact_id`` cannot be resolved to any known
    artifact in the active collection.

    Args:
        artifact_id:      Artifact identifier in ``type:name`` format
                          (e.g. ``"skill:canvas"`` or ``"composite:my-plugin"``).
        artifact_repo:    Artifact repository for UUID resolution.
        collection_mgr:   Collection manager dependency.
        db_user_coll_repo: DB user-collection repository for collection UUID resolution.
        settings:         API settings (controls edition-based branching).
        _token:           Authentication token (dependency injection).
        include_parents:  When ``False``, ``parents`` is always ``[]``.
        include_children: When ``False``, ``children`` is always ``[]``.
        relationship_type: Optional filter applied to both parent and child
                           lists after retrieval.
        collection:       Collection name or UUID; defaults to the active collection.

    Returns:
        AssociationsDTO with ``parents`` and ``children`` lists.

    Raises:
        HTTPException 400: Invalid ``artifact_id`` format.
        HTTPException 404: Artifact not found in the resolved collection.
        HTTPException 500: Unexpected database or service error.

    Example:
        GET /api/v1/artifacts/composite:my-plugin/associations

        Returns::

            {
                "artifact_id": "composite:my-plugin",
                "parents": [],
                "children": [
                    {
                        "artifact_id": "skill:canvas",
                        "artifact_name": "canvas",
                        "artifact_type": "skill",
                        "relationship_type": "contains",
                        "pinned_version_hash": null,
                        "created_at": "2025-01-01T00:00:00"
                    }
                ]
            }
    """
    try:
        logger.info(
            "Getting associations for artifact: %s (collection=%s, "
            "include_parents=%s, include_children=%s, relationship_type=%s)",
            artifact_id,
            collection,
            include_parents,
            include_children,
            relationship_type,
        )

        # Validate artifact ID format
        try:
            artifact_type_str, artifact_name = parse_artifact_id(artifact_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid artifact ID format. Expected 'type:name'",
            )

        try:
            artifact_type_enum = ArtifactType(artifact_type_str)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unknown artifact type: '{artifact_type_str}'",
            )

        # -----------------------------------------------------------------------
        # Enterprise path — uses repository DI for all DB access
        # -----------------------------------------------------------------------
        if settings.edition == "enterprise":
            # Resolve collection and confirm artifact exists via repository
            preferred_collection = collection
            if collection_mgr is not None:
                preferred_collection = collection or collection_mgr.get_active_collection_name()
            elif preferred_collection is None:
                preferred_collection = "default"
            artifact_obj, resolved_collection_name = _find_artifact_in_collections(
                artifact_name=artifact_name,
                artifact_type=artifact_type_enum,
                collection_mgr=collection_mgr,
                preferred_collection=preferred_collection,
                artifact_repo=artifact_repo,
            )
            if artifact_obj is None or resolved_collection_name is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Artifact '{artifact_id}' not found",
                )

            collection_id: Optional[str] = None
            col_dto = db_user_coll_repo.get_by_name(resolved_collection_name)
            if col_dto is None and collection is not None:
                col_dto = db_user_coll_repo.get_by_id(collection)
                if col_dto is None:
                    col_dto = db_user_coll_repo.get_by_name(collection)
            if col_dto is not None:
                collection_id = col_dto.id
            if collection_id is None:
                collection_id = resolved_collection_name or ""

            from skillmeat.cache.composite_repository import (
                CompositeMembershipRepository,
            )

            repo = CompositeMembershipRepository()
            raw = repo.get_associations(artifact_id, collection_id)

            def _build_parent_dto_ent(record: dict) -> AssociationItemDTO:
                parent_id: str = record.get("composite_id", "")
                if ":" in parent_id:
                    p_type, p_name = parent_id.split(":", 1)
                else:
                    p_type, p_name = "composite", parent_id
                raw_ts = record.get("created_at")
                created_at: datetime = (
                    raw_ts
                    if isinstance(raw_ts, datetime)
                    else datetime.now(timezone.utc)
                )
                return AssociationItemDTO(
                    artifact_id=parent_id,
                    artifact_name=p_name,
                    artifact_type=p_type,
                    relationship_type=record.get("relationship_type", "contains"),
                    pinned_version_hash=record.get("pinned_version_hash"),
                    created_at=created_at,
                )

            def _build_child_dto_ent(record: dict) -> AssociationItemDTO:
                child_info = record.get("child_artifact") or {}
                child_id: str = child_info.get(
                    "id", record.get("child_artifact_uuid", "")
                )
                if ":" in child_id:
                    c_type, c_name = child_id.split(":", 1)
                else:
                    c_type = str(child_info.get("type", "unknown"))
                    c_name = str(child_info.get("name", child_id))
                raw_ts = record.get("created_at")
                created_at = (
                    raw_ts
                    if isinstance(raw_ts, datetime)
                    else datetime.now(timezone.utc)
                )
                return AssociationItemDTO(
                    artifact_id=child_id,
                    artifact_name=c_name,
                    artifact_type=c_type,
                    relationship_type=record.get("relationship_type", "contains"),
                    pinned_version_hash=record.get("pinned_version_hash"),
                    created_at=created_at,
                )

            parents: List[AssociationItemDTO] = []
            if include_parents:
                parents = [_build_parent_dto_ent(r) for r in raw.get("parents", [])]
                if relationship_type is not None:
                    parents = [
                        p for p in parents if p.relationship_type == relationship_type
                    ]

            children: List[AssociationItemDTO] = []
            if include_children:
                children = [_build_child_dto_ent(r) for r in raw.get("children", [])]

                if artifact_type_str == "skill" and not children:
                    skill_uuid = artifact_repo.resolve_uuid_by_type_name(
                        "skill", artifact_name
                    )
                    if skill_uuid is not None:
                        skill_members = repo.get_skill_composite_children(
                            skill_artifact_uuid=skill_uuid,
                            collection_id=collection_id,
                        )
                        children = [_build_child_dto_ent(r) for r in skill_members]
                        if skill_members:
                            logger.debug(
                                "Associations (enterprise): found %d embedded member(s) "
                                "via skill composite for '%s'",
                                len(skill_members),
                                artifact_id,
                            )

                if relationship_type is not None:
                    children = [
                        c for c in children if c.relationship_type == relationship_type
                    ]

            logger.info(
                "Associations (enterprise) for '%s': %d parent(s), %d child(ren)",
                artifact_id,
                len(parents),
                len(children),
            )

            return AssociationsDTO(
                artifact_id=artifact_id,
                parents=parents,
                children=children,
            )

        # -----------------------------------------------------------------------
        # Local path (copied verbatim from _legacy.py)
        # -----------------------------------------------------------------------
        # Resolve collection name/UUID and find artifact on filesystem.
        # Uses the shared fallback helper so UUIDs and stale collection hints
        # don't incorrectly return 404.
        preferred_collection = collection or collection_mgr.get_active_collection_name()
        artifact_obj, resolved_collection_name = _find_artifact_in_collections(
            artifact_name=artifact_name,
            artifact_type=artifact_type_enum,
            collection_mgr=collection_mgr,
            preferred_collection=preferred_collection,
            artifact_repo=artifact_repo,
        )
        if artifact_obj is None or resolved_collection_name is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact '{artifact_id}' not found",
            )
        if collection and preferred_collection != resolved_collection_name:
            logger.warning(
                "Associations collection fallback: requested '%s', resolved '%s' "
                "for artifact '%s'",
                preferred_collection,
                resolved_collection_name,
                artifact_id,
            )

        # Resolve the collection_id used in the DB (the collection UUID / name key).
        # The composite_memberships table stores collection_id as the Collection.id.
        # Use the repository to look up the canonical DB id by name.
        collection_id = None
        col_dto = db_user_coll_repo.get_by_name(resolved_collection_name)
        if col_dto is None and collection is not None:
            # Backward-compatible fallback when callers provide UUIDs or
            # human-friendly collection names.
            col_dto = db_user_coll_repo.get_by_id(collection)
            if col_dto is None:
                col_dto = db_user_coll_repo.get_by_name(collection)
        if col_dto is not None:
            collection_id = col_dto.id

        # Fall back to resolved filesystem name when DB row is unavailable.
        # resolved_collection_name is guaranteed non-None by the 404 check above.
        if collection_id is None:
            collection_id = resolved_collection_name or ""

        # Query associations via the repository
        from skillmeat.cache.composite_repository import CompositeMembershipRepository

        repo = CompositeMembershipRepository()
        raw = repo.get_associations(artifact_id, collection_id)

        def _build_parent_dto(record: dict) -> AssociationItemDTO:
            """Convert a parent membership record dict to AssociationItemDTO."""
            parent_id: str = record.get("composite_id", "")
            if ":" in parent_id:
                p_type, p_name = parent_id.split(":", 1)
            else:
                p_type, p_name = "composite", parent_id
            raw_ts = record.get("created_at")
            created_at: datetime = (
                raw_ts if isinstance(raw_ts, datetime) else datetime.now(timezone.utc)
            )
            return AssociationItemDTO(
                artifact_id=parent_id,
                artifact_name=p_name,
                artifact_type=p_type,
                relationship_type=record.get("relationship_type", "contains"),
                pinned_version_hash=record.get("pinned_version_hash"),
                created_at=created_at,
            )

        def _build_child_dto(record: dict) -> AssociationItemDTO:
            """Convert a child membership record dict to AssociationItemDTO."""
            child_info = record.get("child_artifact") or {}
            child_id: str = child_info.get("id", record.get("child_artifact_uuid", ""))
            if ":" in child_id:
                c_type, c_name = child_id.split(":", 1)
            else:
                # UUID fallback — use type from child_artifact dict if available
                c_type = str(child_info.get("type", "unknown"))
                c_name = str(child_info.get("name", child_id))
            raw_ts = record.get("created_at")
            created_at = (
                raw_ts if isinstance(raw_ts, datetime) else datetime.now(timezone.utc)
            )
            return AssociationItemDTO(
                artifact_id=child_id,
                artifact_name=c_name,
                artifact_type=c_type,
                relationship_type=record.get("relationship_type", "contains"),
                pinned_version_hash=record.get("pinned_version_hash"),
                created_at=created_at,
            )

        parents = []
        if include_parents:
            parents = [_build_parent_dto(r) for r in raw.get("parents", [])]
            if relationship_type is not None:
                parents = [
                    p for p in parents if p.relationship_type == relationship_type
                ]

        children = []
        if include_children:
            children = [_build_child_dto(r) for r in raw.get("children", [])]

            # For skills: look up the companion CompositeArtifact whose
            # metadata_json encodes this skill's UUID as the originating
            # artifact (written by create_skill_composite()).  This surfaces
            # embedded member artifacts (commands, agents, etc.) that live
            # inside the skill directory.
            if artifact_type_str == "skill" and not children:
                # Resolve UUID via repository (ADR-007 stable identity)
                skill_uuid = artifact_repo.resolve_uuid_by_type_name(
                    "skill", artifact_name
                )
                if skill_uuid is not None:
                    skill_members = repo.get_skill_composite_children(
                        skill_artifact_uuid=skill_uuid,
                        collection_id=collection_id,
                    )
                    children = [_build_child_dto(r) for r in skill_members]
                    if skill_members:
                        logger.debug(
                            "Associations: found %d embedded member(s) via "
                            "skill composite for '%s'",
                            len(skill_members),
                            artifact_id,
                        )

            if relationship_type is not None:
                children = [
                    c for c in children if c.relationship_type == relationship_type
                ]

        logger.info(
            "Associations for '%s': %d parent(s), %d child(ren)",
            artifact_id,
            len(parents),
            len(children),
        )

        return AssociationsDTO(
            artifact_id=artifact_id,
            parents=parents,
            children=children,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "Failed to get associations for '%s': %s", artifact_id, e, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get associations: {str(e)}",
        )
